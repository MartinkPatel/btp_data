Bihar Financial Rules, 1950
BIHAR
India
Bihar Financial Rules, 1950
Rule BIHAR-FINANCIAL-RULES-1950 of 1950
Published on 17 September 1962• 
Commenced on 17 September 1962• 
[This is the version of this document from 17 September 1962.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Bihar Financial Rules, 1950
Chapter I
Introductory
1.
The Rules contained in this volume, which are essentially executive orders of the Governor describe
primarily the financial powers of different authorities subordinate to the State Government and the
procedure prescribed which should be followed by them in the securing and spending of funds
necessary for the discharge of the functions entrusted to them. In the matter of receipt, custody and
disbursement of Government moneys the Rules are supplementary to the Rules in the Bihar
Treasury Code. Departmental authorities should follow these Rules, supplemented or modified by
the special rules and instructions, if any, contained in their departmental regulations and other
special orders applicable to them.Definitions
2.
Unless there be anything repugnant in the subject or context, the terms defined in this chapter are
used in these rules in the sense hereby explained.(i)Accountant General. - Means the head of the
office of audit and accounts subordinate of the Comptroller and Auditor General of India, who keeps
the accounts of the State and exercises audit functions in relation to those accounts on behalf of the
Comptroller and Auditor General of India.(ii)Appropriation. - Means the assignment to meet
specified expenditure of funds at the disposal of the assigning authority.(iii)Comptroller and Auditor
General. - Means the Comptroller and Auditor General of India.(iv)The Bank. - Means the Reserve
Bank of India or any office or agency of The Reserve Bank of India and includes any branch of the
[Imperial Bank of India] [Now, State Bank of India.] acting as the agent of the Reserve Bank of IndiaBihar Financial Rules, 1950

in accordance with the provisions of the Reserve Bank of India Act, 1934 (Act II of 1934),(v)Reserve
Bank. - Means the Reserve Bank of India.(vi)Competent Authority. - Means Government or any
other authority to which the relevant powers may be delegated by Government.(vii)Constitution. -
Means the Constitution of India.(viii)Controlling officer. - Means a head of a department or other
departmental officer who is entrusted with the responsibility of controlling the incurring of
expenditure and/or the collection of revenue by the authorities subordinate to the
department.(ix)Finance Department. - Means the Finance Department of the Government of
Bihar.(x)Financial year. - Means the year beginning on the 1st of April and ending on the 31st of
March, following.(xi)Government or State Government. - Means the Government of
Bihar.(xii)Governor. - Means the Governor of the State of Bihar.(xiii)Head of Department. - Means
the Government servant mentioned in Appendix 3 of the Bihar Service Code or any other
Government servants declared to be such by the State Government.(xiv)Non-recurring expenditure.
- Means expenditure sanctioned as lump sum charge, whether the money be paid as a lump sum or
by instalments.(xv)Primary unit of Appropriation. - Means a lump sum of money placed by the
Government at the disposal of a subordinate authority by the method prescribed in Rule 473 and in
Rule 99 of the Bihar Budget Manual.(xvi)Public Account or Public Account of the State. - Means the
consolidated fund into which moneys received on account of the revenues of the State are paid or
credited and from which all disbursements of, or on behalf of the State are met. See Article 266 of
the Constitution.Note. - Without prejudice to anything contained in Article 266 of the Constitution,
the revenue of the State would include all money's received by Government servants on behalf of the
Government as such not only the proceeds of taxation and the yield of ordinary revenues but also
capital receipts, such as the proceeds of sales of land, the proceeds of borrowing operations,
unfunded debt; and unless the contrary intention appears, such receipts of a banking or deposit
nature as by virtue of any statutory provision or of any general or special executive orders of the
Government have to be held in the custody of the Government.(xvii)Public Works. - Means civil
works and irrigation, navigation, embankment and drainage works.(xviii)Re-appropriation. - Means
the transfer of funds from one unit of appropriation to another such unit.(xix)State. - Means the
State of Bihar.(xx)Subordinate authority. - Means a Department of the State Government or any
authority subordinate to it.(xxi)Treasury Rules. - Means the Treasury Rules (Bihar) given in the
Bihar Treasury Code, Vol. I, Chapter 1.
Chapter 2
General System of Financial Management and Control.
Section 1Receipt of Money General
3.
All transactions to which any officer of Government is a party in his official capacity must be
brought to account without delay.Bihar Financial Rules, 1950

4.
Money received as dues of Government or for deposit in the custody of Government should be
credited into the Public Account in accordance with the Treasury Rules.
5.
[(i) All moneys received by or deposited with any officer employed in connection with the affairs of
the State in his capacity as such other than Revenue of public money raised or received by
Government shall be paid into the public account;(ii)All moneys received by or deposited with any
court to the credit of any cause (matter account or persons), shall also be paid into the public
account;(iii)The head of account to which such moneys shall be credited and the withdrawal of
moneys therefrom shall be governed by the relevant provisions of Accounts Code, Volumes I and II
and the Bihar Treasury Code or such other general, or special order as may be issued in this
behalf.]Withdrawal of Moneys from the Public Account
6.
Unless otherwise expressly authorized by any law or rule or order having the force of law, moneys
may not be removed from the Public Account for investment or deposit elsewhere without the
consent of the Finance Department.Assessment, Collection and Check of Revenues
7.
Subject to such general or specific instructions as may be issued by Government in this behalf, it is
the duty of the controlling officer concerned, to see that the dues of Government are correctly and
promptly assessed, collected and paid into the treasury. Detailed instructions on the subject are
contained in Chapter 3.Section IIExpenditure and Payment of Moneys Essential Conditions
Governing Expenditure from Public Funds
8.
As a general rule no authority may incur any expenditure or enter into any liability involving
expenditure from public funds until the expenditure has been sanctioned by general or special
orders of the Government or by an authority to which power has been duly delegated in this behalf
and the expenditure has been provided for in the authorised grants and appropriation for the
year.Standards of Financial Propriety
9.
Every Government servant incurring or authorising expenditure from public funds should be guided
by high standards of financial propriety. Among the principles on which emphasis is generally laid
are as follows :(i)Every public officer is expected to exercise the same vigilance in respect ofBihar Financial Rules, 1950

expenditure incurred from public moneys as a person of ordinary prudence would exercise in
respect of expenditure of his own money.(ii)The expenditure should not be prima facie more than
the occasion demands.(iii)No authority should exercise its power sanctioning expenditure to pass an
order which will be directly or indirectly to its own advantage.(iv)Public moneys should not be
utilised for the benefit of a particular person or section of the community unless-(1)the amount of
expenditure involved is insignificant; or(2)a claim for the amount could be enforced in a court of
law; or(3)the expenditure is in pursuance of recognised policy; or custom.(v)The amount of
allowances granted to meet expenditure of a particular type should be so regulated that the
allowances are not on the whole a source of profit to the recipients.Control of Expenditure
10.
Each head of a department is responsible for enforcing financial order and strict economy at every
step. He is responsible for observance of all relevant financial rules and regulations both by his own
office and by subordinate disbursing officer.(See also Rules 471 to 483)
11.
A controlling officer must see not only that the total expenditure is kept within the limits of the
authorised appropriation but also that the funds allotted to spending units are expended in the
public interest and upon objects for which the money was provided. In order to maintain a proper
control, he should arrange to be kept informed, not only of what has actually been spent from an
appropriation but also what commitments and liabilities have been and will be incurred against it.
He must be in a position to assume before Government and the Public Accounts Committee, if
necessary complete responsibility for departmental expenditure and to explain or justify any
instance of excess or financial irregularity that may be brought to notice as a result of audit scrutiny
or otherwise.Internal Check Against Irregularities, Waste and Fraud
12.
In the discharge of his ultimate responsibilities for the administration of an appropriation or part of
an appropriation placed at his disposal, every controlling officer must satisfy himself not only that
adequate provisions exist within the departmental organisation for systematic internal checks
calculated to prevent and detect errors and irregularities in the financial proceedings of his
subordinate officers and to guard against waste and loss of public money and stores but also that the
prescribed checks are effectively applied.
13.
Delay in the payment of money indisputably due by Government is contrary to all rules and
budgetary principles and should be avoided, vide also under Rule 107, Bihar Budget Manual.Section
IIIPayments, Drawing of Money from the TreasuryBihar Financial Rules, 1950

14.
Detailed rules for the preparation of bills in which the different classes of charges are drawn, and as
to the method of obtaining money from treasury, whether by bills or by cheques for subsequent
disbursements, are laid down in the rules in Chapter V, of the Bihar Treasury Code.
15.
In the Public Works Department, the Divisional Officer is primarily the responsible disbursing
officer of the division, but he may delegate this function to his sub-divisional officer in certain cases,
and with a view to enable him to set a monthly limit on the drawings of any of his Sub-divisional
officers he may require the submission, by a convenient date, of an estimate of the probable
requirement of each such sub-divisional officer in a suitable form.Note. - Divisional Officers may
authorise the payment of contractors' bills or other demand by sub-divisional officers subject to the
maximum detailed below according to rank.
 OfficialPayment of bills or
demands in rupees
On
accountFinal
1. Assistant Executive Engineers, No limit 5,000
2.Assistant Engineer, Upper Subordinates and Overseers of
theSubordinate Engineering Service in charge of
Sub-divisions5,000 2,000
The above limits represent the value of the work done or supply made upto date.
16.
In departments where funds are issued from the treasury on cheques, the departmental officers
should see that the drawings are regulated by budget grants and appropriations.
17.
In the Public Works Department a Divisional Officer authorised to draw cheques, on the treasury
may empower any of his sub-divisional officers to draw against his own account and may in such
cases impose a limitation on their drawings, for any month. The procedure to be followed in such
cases are explained in Rule 492 of the Bihar Treasury Code. But in cases where no monthly limit has
been imposed the drawing officer should record on the reverse of the counterfoil of each cheque the
amount of the next cheque drawn and of the total of drawings during the month and carry forward
their total to the next counterfoil. This will enable him, from time to time to exercise an independent
check on the postings of his cash book.Bihar Financial Rules, 1950

18.
Counterfoil of used cheque books should be returned promptly by the Sub-divisional Officer to the
Divisional Officer for record.
19.
Cheques should not be used for the transfer of funds from one division to another.Section
IVVouchers for Departmental Payment
20.
The general rules for preparation and completion of vouchers in cases of departmental payments are
contained in Rule 210 to 216 of the Bihar Treasury Code but the following supplementary
instructions should also be observed in that connection.(a)When the payee signs in a vernacular, he
should be required to note the amount acknowledged in the vernacular in his own handwriting. In
transliterating his acknowledgement, the amount acknowledged, as well as any remarks made by
him, should also be reproduced in English.(b)The disbursing officer is responsible that the full name
of the work as given in the estimate, or the name of the component part (or subhead) of it, or the
head of account, to which the charges admitted on a voucher are debitable, or to which the
deductions or other credits shown in the voucher are creditable, is clearly indicated on it in the
space provided for the purpose, or in some prominent position.Section VAdvances to Disbursers of
the Forest Departments
21.
A subordinate officer of the Forest Department who is not authorised to draw cheques may be given
a cash advance of suitable amount to enable him to make the disbursements entrusted to his charge,
and the advance may be remitted to him by postal money orders.Section VICash Book, Cash Book of
Forest Departments
22.
The general rules for the maintenance of cash book are given in rule 86 of the Bihar Treasury Code.
The following rules regulate the maintenance of cash book in the Forest Department:-(i)All revenue
and expenditure must be recorded at once in the accounts of the division within which it is collected
or incurred, without reference to its origin or object. When revenue is collected or expenditure
incurred in one division on account of another, (e.g.,) advances of pay, travelling allowances etc.,
made to Government servants on transfer from the division to another, inter-divisional adjustment
should be made within the month in which they occur.Note. - This Rule is subject to the condition
that, when adjustment between different Governments are involved, the rules regarding Inter-State
adjustments will apply.(ii)Bills on which the pay and travelling allowance charges of the Forest
Department are paid by the Divisional Officer and not at the treasury, are entered in theBihar Financial Rules, 1950

Cash-Book.Section VIIFinancial Control over Departmental Accounts
23.
(a)The Chief Conservator of Forest exercises strict control over the whole outlay of the Forest
Department for conservancy and works. To facilitate the exercise of the control, the Chief
Conservator is furnished by the Divisional Officer with duplicate copies of the abstracts of the
receipts and expenditure submitted to audit.(b)He is further required specially to control the
adjustment of advances for which purpose the monthly abstracts of the contractors' and disbursers'
ledger, submitted to Audit by the Divisional Officer, are required to pass through the Chief
Conservator.(c)He is responsible for seeing that the accounts returns are submitted punctually to
the Accountant-General by Divisional Officers.(d)Under the authority of the State Government he
can delegate all or a portion of his duties with regard to the control of accounts to the Gazetted
Government servant in charge of his office.Section VIIISecurity Deposits
24.
Cashiers, store-keepers, sub store-keepers and subordinates entrusted with the custody of cash or
stores may be required to furnish security the amount being regulated according to the
circumstances and local conditions in each case, under the sanction of the competent authority, who
will determine whether the amount shall be paid in a lump sum or by deduction from pay.When
promissory notes [and/or stock certificate of the Central Government or of State Government]
[Inserted by C.S. No. 2 dated 3.1.1957.], are deposited as security their realizable cash value should
be approximate to the amount of the security required.Note. - The list of competent authorities will
be found in Annexure A to this Chapter.Section IXDestruction of Accounts Records
25.
The Rules regarding the destruction of accounts record appertaining to the accounts audited by the
Indian Audit Department are contained in Annexure B to this chapter.Section XDuties as Regards
Accounts, Maintenance of Accounts
26.
Every Government servant whose duty it is to prepare and render any accounts or returns in respect
of public money or stores is personally responsible for their completeness and strict accuracy and
their despatch within the prescribed date.
27.
A Government servant who signs or countersigns a certificate is personally responsible for the facts
certified to, so far as it is his duty to know or to the extent to which he may reasonably be expected
to be aware of them. The fact that a certificate is printed is no justification for his signing it unless itBihar Financial Rules, 1950

represents the facts of case. If in its printed form it does not represent the facts, it is his duty to
make any necessary amendment which will call attention to the deviation and so to give the
authority concerned the opportunity of deciding whether the amendments cover
requirements.Demand for Information by Audit
28.
It is the duty of every departmental and controlling officer to see that the Accountant General is
afforded all reasonable facilities in the discharge of his functions and furnished with the fullest
possible information for which he may ask for the preparation of any account or report, which it is
his duty to prepare. No such information nor any books or other documents to which the
Comptroller and Auditor General has a statutory right of access may be withheld from the
Accountant-General.Section XIContract [Management] [Substituted by Bihar Finance (Amdt.)
Rules, 2005, Published in Bihar Gazette (Extraordinary) dated 11.11.2005.] General Principles
29. [ [Published in Bihar Gazette (Extraordinary) dated 11.11.2005.]
(1)All contracts shall be made by an authority empowered to do so by or under the orders of the
Governor in terms of Article 299(1) of the Constitution of India.(2)All the contracts and assurances
of property made in the exercise of the executive power of the State shall be executed on behalf of
the Governor. The words "for and on behalf of the Governor of Bihar" should follow the designation
appended below the signature of the officer authorized in this behalf.] [Substituted by C.S. No. 61
dated 2.11.1964.]
30. General principles for contract.
- The following general principles should be observed while entering into contracts:(i)The terms of
contract must be precise, definite and without any ambiguities. The terms should not involve an
uncertain or indefinite liability, except in the case of a cost plus contract or where there is a price
variation clause in the contract.(ii)Standard forms of contracts should be adopted wherever
possible, with such modifications as are considered necessary in respect of individual contracts. The
modifications should be carried out only after obtaining financial and legal advice.(iii)In cases
where standard forms of contracts are not used, legal and financial advice should be taken in
drafting the clauses in the contract.(iv)(a)A Ministry or Department may, at its discretion, make
purchases of value upto Rupees one lakh by issuing purchase orders containing basic terms and
conditions.(b)In respect of Works Contracts, or Contracts for purchases valued between Rupees one
lakh to Rupees ten lakhs, where tender documents include the General Conditions of Contract
(GCC), Special Conditions of Contract (SCC) and scope of work, the letter of acceptance will result in
a binding contract.(c)In respect of contracts for works with estimated value of Rupees ten lakhs or
above or for purchase above Rupees ten lakhs, a Contract document should be executed, with all
necessary clauses to make it a self-contained contract. If however, these are preceded by Invitation
to Tender, accompanied by GCC and SCC, with full details of scope and specifications, a simple one
page contract can be entered into by attaching copies of the GCC and SCC, and details of scope and
specifications, Offer of the Tenderer and Letter of Acceptance.(d)Contract document should beBihar Financial Rules, 1950

invariably executed in cases of turn-key works or agreements for maintenance of equipment,
provision of services etc.(v)No work of any kind should be commenced without proper execution of
an agreement as given in the foregoing provisions.(vi)Contract document, where necessary, should
be executed within 21 days of the issue of letter of acceptance. Non fulfilment of this condition of
executing a contract by the Contractor or Supplier would constitute sufficient ground for annulment
of the award and forfeiture of Earnest Money Deposit.(vii)Cost plus contracts should ordinarily be
avoided. Where such contracts become unavoidable, full justification should be recorded before
entering into the contract. Where supplies or special work covered by such cost plus contracts have
to continue over a long duration, efforts should be made to convert future contracts on a firm price
basis after allowing a reasonable period to the suppliers/contractors to stabilize their production
execution methods and processes.Explanation. - A cost plus contract means a contract in which the
price payable for supplies or services under the contract is determined on the basis of actual cost of
production of the supplies or services concerned plus profit either at a fixed rate per unit or at a
fixed percentage on the actual cost of production.(viii)(a)Price Variation Clause can be provided
only in long-term contracts, where the delivery period extends beyond 18 months. In short term
contracts firm and fixed prices should be provided for. Where a price variation clause is provided,
the price agreed upon should specify the base level viz, the month and year to which the price is
linked, to enable variations being calculated with reference to the price levels prevailing in that
month and year.(b)A formula for calculation of the price variations that have taken place between
the Base level and the Scheduled Delivery Date should be included in this clause.The variations are
calculated by using indices published by Governments or Chambers of Commerce periodically. An
illustrative formula has been appended to these Rules at Appendix-1 A for guidance.(c)The Price
variation clause should also specify cut off dates for material and labour, as these inputs taper off
well before the Scheduled Delivery Dates.(d)The price variation clause should provide for a ceiling
on price variations, particularly where escalations are involved. It could be a percentage per annum
or an overall ceiling or both. The buyer should ensure a provision in the contract for benefit of any
reduction in the price in terms of the price variation clause being passed on to him.(e)The clause
should also stipulate a minimum percentage of variation of the contract price above which price
variations will be admissible (e.g. where resultant increase is lower than two per cent, no price
adjustment will be made in favour of the supplier).(f)Where advance or stage payments are made
there should be a further stipulation that no price variations will be admissible on such portions of
the price, after the dates of such payment.(g)Where deliveries are accepted beyond the Scheduled
Delivery Date subject to levy of liquidated damages as provided in the Contract, the liquidated
damages (if a percentage of the price) will be applicable on the price as varied by the operation of the
Price variation clause.(h)No price variation will be admissible beyond the original Scheduled
Delivery Date for defaults on the part of the supplier.(i)Price variation may be allowed beyond the
original Scheduled Delivery Date, by specific alteration of that date through an amendment to the
contract in cases of Force Majeure or defaults by Government.(j)Where contracts are for supply of
equipment, goods etc, imported (subject to customs duty and foreign exchange fluctuations) and/ or
locally manufactured (subject to excise duty and other duties and taxes), the percentage and element
of duties and taxes included in the price should be specifically stated, along with the selling rate of
foreign exchange element taken into account in the calculation of the price of the imported item.The
mode of calculation of variations in duties and taxes and Foreign exchange rates and the documents
to be produced in support of claims for such variations, should also be stipulated in theBihar Financial Rules, 1950

Contract.(k)The clause should also contain the mode and terms of payment of the price variation
admissible.(ix)Contracts should include provision for payment of all applicable taxes by the
contractor or supplier.(x)"Lumpsum" contracts should not be entered into, except in cases of
absolute necessity. Where lumpsum contracts become unavoidable, full justification should be
recorded. The contracting Authority should ensure that conditions in the lump sum contract
adequately safeguard and protect the interests of the Government.(xi)Departmental issue of
materials should be avoided as far as possible. Where it is decided to supply materials
departmentally, a schedule of quantities with the issue rates of such material as are required to
execute the contract work, should form an essential part of the contract.(xii)(a)In contracts where
government property is entrusted to a contractor either for use on payment of hire charges or for
doing further work on such property, specific provision for safeguarding government property
(including insurance cover) and for recovery of hire charges regularly, should be included in the
contracts.(b)Provision should be made in the contract for periodical physical verification of the
number and the physical condition of the items at the contractors premises. Results of such
verification should be recorded and appropriate penal action taken where necessary.(xiii)Copies of
all contracts and agreements for purchases of the value of Rupees Twenty-five Lakhs and above, and
of all rate and running contracts entered into by civil departments of the Government other than the
for which a special audit procedure exists, should be sent to the Audit Officer and/or the Accounts
officer as the case may be.(xiv)(a)The terms of a contract, including the scope and specification once
entered into, should not be materially varied.(b)Wherever material variation in any of the terms or
conditions in a contract becomes unavoidable, the financial and other effects involved should be
examined and recorded and specific approval of the authority competent to approve the revised
financial and other commitments obtained, before varying the conditions.(c)All such changes should
be in the form of an amendment to the contract duly signed by all parties to the
contract.(xv)Normally no extensions of the Scheduled Delivery or completion dates should be
granted except where events constituting Force Majeure as provided in the contract, have occurred
or the terms and conditions include such a provision for other reasons. Extensions as provided in
the contract may be allowed through formal amendments to the contract duly signed by parties to
the contract.(xvi)All contracts shall contain a provision for recovery of liquidated damages for
defaults on the parts of the contractor.(xvii)A warranty clause should be incorporated in every
contract, requiring the supplier to, without charge, repair or rectify defective goods or to replace
such goods with similar goods free from defect. Any goods repaired or replaced by the supplier shall
be delivered at the buyers premises without costs to the buyer.(xviii)All contracts for supply of goods
should reserve the right of Government to reject goods which do not conform to the
specifications.(xix)[ In Externally Aided Projects, namely World Bank, ADB,DFID etc, where
compliance of Financial Agreement/Procurement Guidelines is compulsory/mandatory, the rules,
contained in Bihar Financial (Amendment) Rules, 2005 will not Applicable.] [Added by Bihar
Notification No. M-4-12/2015(Part) 8478/F, dated 28.10.2016.](xx)[ Goods upto Rs. 50,000/- may
be bought through any of the available supplies on the GeM, meeting the requisite quality,
specification and supply period thereof. Goods above Rs. 50,000/- may be bought through the
supplier having lowest price amongst the available supplies on the GeM, meeting the requisite
quality, specification and supply period thereof using online bidding and online reverse auction
made available on GeM.] [Added by Bihar Notification No. M-4-48/2012(Part-I) 3457/F, dated
19.5.2017.](xxi)[ The Womens/Women Self Help Groups, fullfilling prescribed qualifications,Bihar Financial Rules, 1950

conditions and specifications of the tender, will be given priority in case of their bid equivalent to
the other lowest bidder.] [Added by Bihar Notification No. M-4-12/2015(Part)-8327/F, dated
20.10.2017.]
30A. [ Management of Contracts. [Inserted vide Bihar Finance (Amendment)
Rules, 2005. Dated 10th November, 2005. Notify No. S.S.M-4-35/2002-6076
F(2). Published in Bihar Gazette (Ex. Ord.) dated. 11.11.2005.]
(1)Implementation of the contract should be strictly monitored and notices issued promptly
whenever a breach of provisions occur.(2)Proper procedure for safe custody and monitoring of Bank
Guarantees or other Instruments should be laid down. Monitoring should include a monthly review
of all Bank Guarantees or other instruments expiring after three months, alongwith a review of the
progress of supply or work. Extensions of Bank Guarantees or other instruments, where warranted,
should be sought immediately.(3)Wherever disputes arise during implementation of a contract,
legal advice should be sought before initiating action to refer the dispute to conciliation and/or
arbitration as provided in the contract or to file a suit where the contract does not include an
arbitration clause. The draft of the plaint for arbitration should be got vetted by obtaining legal and
financial advice. Documents to be filed in the matter of resolution of dispute, if any, should be
carefully scrutinized before filing to safeguard government interest.]Section XIIDeclaration, Losses,
etc.Report of Losses
31.
(1)With the exceptions noted below, any loss of public money, departmental revenue or receipts,
stamps, opium, stores or other property, held by or on behalf of Government caused by defalcation
or otherwise, which is discovered in a treasury or other office or department, should be immediately
reported by the other concerned to his immediate official superior and [Finance Department]
[Added by C.S. No. 30 dated 11.3.1959.] as well as to the Accountant General even when such loss
has been made good by the party responsible for it. Such reports must be submitted as soon as a
suspicion arises that there has been a loss; they must not be delayed while detailed enquiries are
made. When the matter has been fully investigated, further and complete report should be
submitted of the nature and extent of the loss, showing the errors or neglect of rules by which such
loss was rendered possible and the prospects of effecting a recovery.(2)If the irregularity be detected
by Audit in the first instance, the Accountant General will report it immediately to the
administrative authority concerned, and if he considers necessary, to Government as well.Note. -
See also rule 44, Bihar Treasury Code quoted below:-
44. The Collector shall send immediate notice to the Accountant General,
Finance Department and other concerned authorities of any defalcation or
loss of public money, stamps, or opium and other property discovered in the
treasury or any sub-treasury, even when such loss has been made good by
the person responsible for it. Such notice shall be supplemented as soon asBihar Financial Rules, 1950

possible afterwards by a detailed report after personal investigation into the
case.
Exception. - Petty cases, that is, cases involving losses not exceeding Rs. 200 each, need not be
reported to the Accountant General unless there are, in any case, important features which merit
detailed investigation and consideration.
32.
The officers receiving a report submitted to them under Rule 31 must forward it forthwith to
Government through the usual channel with such comments as may be considered necessary. He
should also submit a detailed report, after completing such departmental investigations as may be
necessary or expedient, on the causes or circumstances which led to the defalcation or loss, the steps
taken to prevent its recurrence and the disciplinary or any other action proposed as regards the
person responsible.[Note. - All cases of embezzlement of public funds in any department involving
amounts exceeding Rs. 500, shall be submitted by the Secretary after taking orders of the
Minister-in-charge of that Department before final orders in such case issue.] [Inserted by C.S. No.
35, dated 1.8.1959.]Accidents
33.
Any serious loss of immovable property, such as building, communications or other works, caused
by fire, flood, cyclone, earthquake, or any other natural cause, should be reported at once by the
departmental officer, to the head of the department and by the latter to Government. When a full
enquiry as to the causes and extent of the loss has been made the detailed report should be sent by
the departmental officer concerned to the head of the department, a copy of the report or an abstract
thereof, being simultaneously forwarded to the Accountant-General.Responsibility for Losses, etc.
34.
Every Government servant should realise fully and clearly that he will be held personally responsible
for any loss sustained by Government through fraud or negligence on his part and that he will also
be held personally responsible for any loss arising from fraud or negligence on the part of any other
Government servant to the extent to which it may be shown that he contributed to the loss by his
own action or negligence. Detailed instructions for regulating the enforcement of such responsibility
are embodied in Appendix 2.Write-off of Losses, etc.
35.
The powers delegated to different authorities to write of the irrecoverable value of public money or
stores lost through fraud or negligence of Individuals or other causes are indicated in Chapter
4.Section XIIIDepartmental RegulationsBihar Financial Rules, 1950

36.
All departmental regulations in so far as they embody orders, or instructions of a financial character
or have important financial bearings should be made by, or with the approval of the Finance
Department.Annexure AList of Competent Authorities for Regulating The Amount of Security(See
note below Rule 24)
Name of Department Competent authorities Remarks
1 2 3
Land Revenue-  
I. Revenue Offices under
theCollector. - 
(i) when full security is
takenin a single payment;Collector
(ii) when reduction is made
ofthe security deposits;Collector up to Rs. 100. Commissioner above Rs. 100.
(iii) when security is taken
bymonthly payment;1. Collector. - When monthly contribution is (a) not lessthan
25 per cent of the pay or (b) not less than 18 ¾ percent of the
pay in the case of Government servants whocontribute 6 ¼
per cent to a provident fund constitutedin any Wards,
Encumbered Trust and attached estates.
 2. Board of Revenue. - When the monthly contribution is
(i)less than 25 per cent of pay or (ii) less than 18 ¾ percent of
the pay in the case of Government servants noted at
(b)above.
(iv) in the case of
treasurers;State Government, Finance Deptt.
(v) in the case
ofsub-treasurers.Commissioners.
II. Offices of the Survey
andSettlement DepartmentSettlement Officer.
III. Offices directly under
theCommissioners of
Divisions and Board of
Revenue.Commissioners of Divisions, and Board of
Revenuerespectively.
Excise Commissioner of Excise, Collectors of District,
ForestDivisional Forest Officers except (a) security of head clerksof
Forest divisions and (b) when payment is made by
instalments
 Conservator of Forests in the case of (a) security of headclerk
of Forest divisions and (b) when payment is madeBihar Financial Rules, 1950

byinstalments.
Irrigation and Electricity
Department.Chief Engineer, Irrigation Department; Chief
Engineer,Electricity Department.
General Administration:  
Appointment Department State Government, Appointment Department.
Translator's Department State Government, Appointment Department.
Administration of Justice-  
" High Court Registrar, High Court
" Civil Courts District Judges.
" Legal Remembrancers
establishment.Superintendent and Remembrancer of Legal affairs.
Jails State Government, Law Department.
Police Deputy Inspector General of Police.
Education Director of Public Instruction.
Medical Inspector General of Civil Hospitals.
Public Health Director of Public Health.
Agriculture Director of Agriculture.
Veterinary Director, Veterinary Services.
Co-operation Registrar, Co-operative Societies.
Industries Director of Industries.
Factory Inspection Chief Inspector of Factories.
Public Works Department Chief Engineer, Public Works Department.
 Chief Engineer, Public Health Engineering.
Stationary and Printing State Government, Finance Department.
Annexure BRules Regarding Destruction of Accounts Records(See Rule 25)The destruction of
records [including correspondence] connected with accounts is governed by the following rules and
such other subsidiary rules consistent therewith as may be prescribed by State Government in this
behalf with the concurrence of the Accountant General.(a)the following should on no account be
destroyed :-(i)Records connected with expenditure which is within the period of limitation fixed by
law.(ii)Records connected with expenditure on projects, schemes, or works not completed, although
beyond the period of limitation.(iii)Records connected with claims to service and personal matters
affecting persons in the service.(iv)Orders and sanctions of a permanent character until
revised.(b)The following should be preserved for not less than the period specified against them:
 Description of records  Period of Preservation Years
(1)Annual Establishment Returns (Book of
Establishment)....35 years.
(2) Register of contingent expenditure ...5 "
(3) Detailed budget estimate of an office ...5 "
(4) ...3 "Bihar Financial Rules, 1950

Travelling allowance bills and
acquittance rolls relatingthereto
(5) Service books ...5 years after death or retirement
whichever is earlier.
(6)Leave accounts of non-gazetted
Government Servants...3 years after death or retirement.
(7) [ [Substituted
by C.S. No. 6
dated 12.8.1957.]Pension cases ...7 years after retirement/death in
service of the Governmentservants
as the case may be, in all cases.]
(8) [ [Substituted
by C.S. No. 6
dated 12.8.1957.]Nomination papers under the
Liberalised Pension Rules whetherthese
relates to Gazetted or non-Gazetted
Government Servant:  
 (a) If the gratuity and/or family pension
are paid to minors....30 years.
 (b) To other than minors-   
 (i) If not in accordance with theorder in
which nomination have been made....30 years.
 (ii) If in accordance with theorder in
which nomination has been made....6 years after the payment of gratuity
or the last instalmentof the family
pension.]
(9)Statement of monthly progressive
expenditure andcorrespondence relating
to discrepancy in the figures...2 years.
(10)Pay-bills, and acquittance rolls where
these are maintainedseparately, of
Government servants for whom no
establishmentreturns are submitted or
no service books or service rolls
aremaintained....35 years.
(11)Pay-bills of other classes of Government
servants andacquittance rolls for pay and
allowance (other than
travellingallowances) when maintained
separately (see notes 1 and 2 below)....6 years.
(12) Muster rolls ...Such period as may be prescribed in
this behalf in thedepartmental
regulations subject to a minimum of
three accountyears excluding the
year of payment.
(13) Cash-book ...[20 years.] [Substituted by C.S. No.
19 dated 9.5.1958.]Bihar Financial Rules, 1950

Note 1. - Before any pay-bills are destroyed the periods of temporary and officiating service, as
recorded in the service books or service rolls (as the case may be) of the Government servant
concerned, should be verified by the head of the office from the pay bill and the fact of such
verification should be recorded under proper attestation in the service books or service rolls (as the
case may be). In regard to temporary and officiating service, the head of the office should also
invariably give necessary particulars with reference to Rules 63 and 64 of the Bihar Pension Rules,
with a view to enable the Audit Office to decide later on by reference merely to such particulars
whether the temporary or officiating service will qualify for pension or not. For example, in the case
of officiating service the nature of the vacancy in which the Government servant officiated and in the
case of temporary service whether the temporary post was subsequently made permanent, should be
stated.Note 2. - The periods of preservation of account records in Public Works Offices are
prescribed separately by Government.(c)Where a minimum period after which any record may be
destroyed has been prescribed, the head of a department or any other authority empowered to do so,
may order in writing the destruction of such record in their own and subordinate offices on the
expiry of that period counting from the last day of the latest official year covered by the
record.(d)Heads of departments are competent to sanction the destruction of such other records in
their own and subordinate offices as may be considered useless, but a list of such records as properly
appertain to the accounts audited by the Indian Audit Department should be forwarded to the
Accountant General for his concurrence in their destruction before the destruction is ordered by the
head of department.(e)Full details should be maintained permanently in each office, of all records
destroyed from time to time.
Chapter 3
Revenue and Receipts
Section IGeneral
37.
Subject to any special arrangement that may be authorised by competent authority with respect to
any particular class of receipts it is the duty of the departmental controlling officers to see that all
sums due to Government are regularly and promptly assessed, realised and duly credited in the
Public Account. They should accordingly arrange to obtain from their subordinates monthly
accounts and returns in suitable form claiming credit for so much paid into the treasury or
otherwise accounted for and compare them with the statements of treasury credits furnished by the
Accountant General to see that the amounts reported as collected have been duly credited in the
Public Account.If wrong credits thus come to the notice of the controlling officer, he should at once
inform the Accountant General, with a view to the correction of the accounts. If any credits are
claimed but not found in the accounts, enquiries should be made first of the responsible
departmental officer concerned.Note 1. - For this purpose, the Accountant General will send to the
departmental controlling officer, an extract from his accounts showing the amounts brought to
credit in them in each month.Note 2. - It is essential that the departmental accounts of revenue
should not be compiled from the returns prepared by the treasury. But the Treasury Officer may beBihar Financial Rules, 1950

required, where necessary to verify the returns prepared for submission to the departmental
controlling authority.Note 3. - In order to minimise the difference between the treasury figures and
the departmental figures, it is essential that the challan with which money is remitted to the treasury
should bear full and correct accounts classification.
38.
Detailed rules and procedure regarding assessment, collection, remission etc., of revenue should be
laid down in the departmental regulations of the revenue and collecting departments
concerned.Note 1. - In departments in which officers are required to receive moneys on behalf of
Government and issue receipts therefor, in T.C. Form 7 of the Bihar Treasury Code, the
departmental regulations should prescribe the procedure rules for the maintenance of a proper
account of the receipt, and issue of the receipt book, the number of receipt books to be issued at a
time to each officer and check with the officer's accounts of the used books when returned.Note 2. -
Receipts of the Public Works Department in the prescribed form can be issued only by Divisional
Officers, sub-divisional officers, ziladars and other Government servants specially authorised by the
State Government. Receipt books should be obtained from the head treasury of the district
concerned and the books should be examined carefully to see that the number of forms contained in
each is intact and a certificate of count recorded on the fly leaf. Counterfoils of used receipt books
should be returned promptly to the divisional officer, for record.Note 3. - A list of officers other than
Divisional Officers, sub-divisional officers and ziladars who have been specially authorised by the
State Government from time to time to issue such money receipts is noted below -(1)All divisional
accountants of the Public Works Department (including Public Health Engineering Department),
and Irrigation and Electricity Department during the absence of the Executive Engineers from
headquarters are authorised (i) to grant receipts for cash upto the limit of Rs. 100 for each receipt
(ii) to make urgent petty payments up to Rs. 50 for one payment-cash payment to contractor being
prohibited.(2)All Sub-divisional cashiers and clerks of the Public Works Department (including
Public Health Engineering Department) and Irrigation and Electricity Department, who have
furnished security during the absence of the Sub-divisional Officer from headquarters up to Rs.
20.(3)All [Sectional Officers] [Substituted by C.S. No. 24 dated 5.6.1958.] of the Public Works
Department (including Public Health Engineering Department) and Irrigation and Electricity
Department upto Rs. 50.
39.
No amount due to Government should be left outstanding without sufficient reason, and where any
dues appears to be irrecoverable the orders of competent authority for their adjustment must be
sought.
40.
Unless specially authorised by any rule or order made by competent authority, no sums may be
credited as revenue by debit to a suspense head : the credit must follow and not precede actual
realisation.Bihar Financial Rules, 1950

41.
Heads of department in charge of important sources of revenue should keep the Finance
Department fully informed of the progress of collection of revenue under their control and of all
important variations in such collections as compared with the budget estimates.Revenue Receipts of
the Public Works Department
42.
Public works revenue is assessed and realised in accordance with the following rules:-(a)Divisional
Officer of the Public Works Department are responsible that demands are made as revenue falls
due, that steps are taken with a view to effect prompt realization of all revenues, regular or
occasional and that proper records are kept to show, in respect of all items of revenue, recurring or
non-recurring, the assessments made, the progress of recovery and the outstanding debts due to
Government.(1)The object of this Rule is that all classes of revenue whether accruing from property
of any kind, from leases of rights and concessions (e.g. right from fishing, grazing, etc. and use of
water-power, or from any other source are properly watched.(2)A register of miscellaneous
properties should be maintained for this purpose in each subdivision in F.R. Form I, in order that no
item of revenue is lost sight of. This register should be submitted to the divisional office monthly
and also at the time of the audit inspection.If, however, the registers cannot be spared by the
sub-divisional officers in any particular month (e.g., in the month in which gross sales have to be
conducted) they should be sent to the Divisional office as soon as the sales are over. On the first page
of the register there should be clear information available to show :-(1)that the register is signed by
the sub-divisional officer every month, whether there are transactions during the month or
not;(2)when the register is sent to the Divisional Office; and(3)when it is received back in the
sub-divisional office.When there are no transactions in a month, the register need not be submitted
by the sub-divisional officer to the Divisional Office. The reason for the non-submission should be
recorded in the register against the month under the signature of the sub-divisional officer and the
fact intimated to the Divisional Office.(b)The recovery of all debts due to Government should receive
the special attention of the Divisional Officer, and no debt should be remitted or written off except
under the orders of competent authority.Irrigation Revenue Collected in the Civil Department
43.
When revenue from irrigation and navigation works, etc. is realized in the civil department, the
Divisional Officer should receive from the Collector a monthly statement of the amounts realized, to
enable him to watch the progress of recovery against demands or assessments.
44.
The Divisional Officer should also submit to the Accountant General a half-yearly statement
showing, separately for each civil district the monthly realizations, as compared with assessments,
in respect of each canal or other works.Section IISpecial Rules for Particular Classes ofBihar Financial Rules, 1950

ReceiptsRents of Government Buildings, Lands, etc.
45.
The detailed rules and procedure regarding the demand and recovery of rents of Government
buildings and lands are contained in the departmental regulations of the departments in charge of
those buildings. Some of the general rules on the subject are given in the following rules in the
Section.When the maintenance of any rentable building is entrusted to a civil department other than
the Public Works Department, the head of the department concerned will be responsible for the due
recovery of the rents thereof. The procedure for the assessment and recovery of the rents of such
buildings will be regulated generally by the rules applicable to residences under the direct charge of
the Public Works Department.Recoveries of Rent on Buildings and Lands
46.
(a)When a public building, land or other property is let to a person not in the service of Government,
the full assessed rent must be recovered in advance.(b)The recovery of rents from Government
servants occupying rentable buildings in charge of the department may be made either in cash or by
deduction from their pay-bills through the Treasury Officer or other disbursing officers concerned,
as may be directed by the State Government.Note 1. - The system of direct recovery in cash from
employees of other divisions and departments is ordinarily not suitable when the rent recoverable is
dependent upon the rate of pay of the occupant.Note 2. - The method of recovery of house rents and
taxes from the pay bills of Government servants occupying Government buildings is explained in
rule 299 of the Bihar Treasury Code.
47.
A tenant, who is in receipt of a pension from Government should be treated as a private individual
for the purpose of these rules. But if he desires to make payments by deductions from his pension,
recoveries from him may be made through the Treasury Officer or other disbursing officer
concerned on the pensioner furnishing the Divisional Officer with a written request authorizing such
deduction. This authority should be transmitted to the treasury or disbursing officer with the first
demand.
48.
Where rent is recoverable in cash, a bill in suitable form should be sent to the tenant on or before
the last day of each month. The tenant should be required to pay in the rent before the expiry of the
following month.Bihar Financial Rules, 1950

49.
If a Government servant vacates his quarter before the last day of a month, owing to his departure
on transfer, leave or retirement, the demand for the rent for the broken period should be made at
once in order that the amount may be entered in the last pay certificate in the case of Government
servants transferred within the same audit circle or proceeding on leave in India. In cases, in which
a Government servant is paid up to the day of giving over charge, i.e., when retiring, proceeding to
another audit circle, taking leave out of India, the Treasury Officer should take steps to see that the
rent for the broken period is deducted from the Government servant's last pay bill which is
pre-audited by the Accountant General.
50.
Except as provided in Rule 51, pending orders on a representation against the Divisional Officer's
assessment, the amount assessed must be paid by tenants on demand. Should the representation
prove successful, the excess amount charged should be adjusted as soon as orders are issued, by
reduction in the assessment of a subsequent month or, if this is not practicable or convenient by an
actual repayment.Note. - The recoveries of rents of non-Public Works Residences should be
regulated generally by the rules applicable to Public Works residences.
51.
When a rent demand purports to have accrued more than three months before the date on which the
pay bill from which it is proposed to recover it becomes due for payment, the Divisional Officer
should give full particulars to the Government servant, concerned direct or through the head of the
office according as he is a gazetted ora non-gazetted Government servant with a formal intimation
that he will be allowed one month in which to make any representation against enforcement of the
claim, failing which amount will be recovered under Rule 229 of the Bihar Treasury Code. On
receipt of notice that a representation has been made against the recovery of the whole or any
portion of the amount claimed, the Divisional Officer shall take no steps for recovery of that amount
until orders have been passed on the representation by a competent authority.Fines
52.
It is the duty of every Court or authority having the power to fine, to see that the money realised
reaches the treasury and that adequate precautions are taken against double refunds of fines or
refund of fines not actually paid into the treasury.
53.
The duty of realizing fines and of checking the receipts and refunds rests with the departmental
officer. Each court, civil or criminal, is required to submit to the District Judge or to the District
Magistrate, as the case may be, on the last working day of each calendar month, a statement in aBihar Financial Rules, 1950

form showing the demand, collection and balance of fines levied and written off by it as well as of
the refunds therefrom, the statement being made up for the account month of the treasury or
sub-treasury with which the court deals.The District Judge and District Magistrate should each
consolidate these returns into a monthly fines statement for the courts under him and for his own
and forward it to the Treasury Officer, as soon as possible after the beginning of the month, for
verification of the amounts shown as remitted into the treasury with the credit appearing in the
treasury account. The Treasury Officer should certify to the correctness or otherwise of these
amounts. Where there is any discrepancy between a consolidated statement and the treasury
account, the Treasury Officer may if necessary, before giving his certificate, request the District
Judge or the District Magistrate as the case may be, to explain the discrepancy.Note 1. - The
statement should exhibit the amounts under each head of accounts, e.g. Magisterial fines, fines
under the Prevention of Cruelty to Animals Act, etc. separately.Compensation fines due to an
injured party which are creditable to deposits and fines which under the orders of competent
authority are creditable to a municipal or local fund, should be excluded from this statement.Note 2.
- When fines are received in another district, an intimation should be given by the recovering officer
to the officer concerned, who should note the fact in his monthly fine statement.Convict Charges
Recoverable from other States
54.
Where other States are responsible for the cost of maintenance of convicts imprisoned in Bihar jails
for offences committed in such States, the jail officials should communicate to the Accountant
General any amount recoverable on this account and the Accountant General will then see to its due
recovery.Miscellaneous Demands
55.
Realisation of miscellaneous demands of Government not falling under the ordinary revenue
administration will be watched by the Accountant General. Such are payments due from other
States, local funds, contractors and others towards establishment charges etc.Section IIIRemissions
of and abandonment of Claims to Revenue
56.
The sanction of the competent authority is necessary for the remission of, and abandonment of
claims to revenue.Note. - The powers of subordinate authorities to sanction the write off of loss of
revenue are indicated in Compendium of Financial Delegations.
57.
Heads of department should submit annually on the first of June to the Accountant-General
statements showing the remissions of revenue and abandonment of claims to revenue sanctioned
during the preceding year by competent authorities in exercise of the discretionary powers vested inBihar Financial Rules, 1950

them otherwise than by law or rule having the force of law. For inclusion in these statements
remissions and abandonments should be classified broadly with reference to the grounds on which
they were sanctioned and a total figure should be given for each class. A brief explanation of the
circumstances leading to the remission should be added in the case of each class.Subject to any
general or special orders issued by Government, individual remissions below Rs. 100 need not be
included in the statement.Note. - The State Government may make rules in consultation with the
Accountant General defining remissions and abandonments of revenues for the purposes of this
Rule.Section IVAudit of Receipts
58.
When the audit of the receipts or of stores and stock accounts of any department of Government is
entrusted to the Comptroller and Auditor General under the provision of paragraph 13(2) of the
Government of India (Audit and Accounts) Order, 1936, it will be conducted in accordance with the
regulations reproduced in Appendix 3.
Chapter 4
Powers of sanction
Section IGeneral
59.
The more important of the powers to sanction expenditure, which are exercised by Heads of
Departments and other officers, are detailed in the Compendium of Financial Delegations.
60.
The financial powers of the State Government, which have not been delegated to any other
department or authority vest in the Finance Department.
61.
Unless otherwise provided by any special rule or order of Government, a higher authority may
exercise the powers delegated to an authority subordinate to it.Section IIPowers in Regard to
Certain Special Matters Grants of Land, Assignments of Revenue and Other Concessions, etc.
62.
No department or authority may, without previous consent of the Finance Department issue any
orders (other than orders in pursuance of general delegation made by or with the approval of the
Finance Department which-(i)involve any grant of land, or assignment of revenue, or concessionBihar Financial Rules, 1950

grant, lease, or licence of mineral or forest rights, or right to water, power, or any easement or
privilege in respect of such concessions; or(ii)in any way involve any relinquishment of
revenue.Note. - The powers to execute instrument are governed by the orders given in Appendix I.
(Execution of deeds, contracts, and other instruments and other departmental and local orders on
the subject.[See also Rule 10 of the Rules of Executive Business, Bihar.]Write-off of Losses
63.
(a)The irrecoverable value of stores or public money lost by fraud or the negligence of individuals or
other causes may be written off finally by Government.Where public money or stores are lost
through culpable negligence of any Government servant, Government will not agree to write off the
loss without a definite expression of the opinion of the departmental authorities concerned
regarding the desirability of recovering the whole or part of the loss from the Government servant or
Government servants through whose negligence the loss occurred. Any proposal to remit part or
whole of the sum lost in such cases must be supported by full reasons and will require the special
orders of the State Government.Heads of Departments or other subordinate authorities have power
to write off losses in accordance with the orders of delegation passed in this behalf subject, to the
conditions-(1)that the loss does not disclose a defect of system the amendment of which requires the
orders of Government; and(2)that there has not been any serious negligence on the part of some
individual Government servant or Government servants which might possibly call for disciplinary
action requiring the orders of higher authority.(b)All sanctions to write off should be communicated
to the Accountant-General, Bihar, for scrutiny in each case and for bringing to notice any defect of
system which appears to require attention.[See also Appendix 2][Note 1. - This Rule applies also to
irrecoverable advances and losses of revenue.] [Substituted by C.S. No. 33 dated 4.4.1959.][Note 2. -
Write off of Civil Court decrees will continue to be regulated by Rule 109 of Chapter VI of the Bihar
Practice and Procedure Manual.] [Inserted by C.S. No. 48 dated 12.4.1961.]Note 3. - The delegations
made under first paragraph of this Rule will be found in the Compendium of Financial Delegations.
64.
The orders contained in the preceding Rule do not apply to loss of cash in treasuries, whether in the
course of remittance or out of treasury balance, small coin depot or currency chest. Individual cases
of such losses should be reported to the Finance Department and its specific approval obtained
before any item can be written off in the accounts of the State Government.Note 1. - The
Government of India have decided with concurrence of the State Government and the Comptroller
and Auditor General, that, in general, losses sustained by the Union Government through the
negligence or culpability of the staff paid by the State Government, and vice versa, should be borne
as they occur i.e., by the Union Government, if the loss occurs in connection with Central
transactions and by the State Government, if it is on account of State transaction.In cases where
recoveries are made in cash, e.g., by deductions from pay or otherwise, from the persons responsible
for a loss, the entire amount recovered should be credited to the Government which, under the
above arrangement, would bear the loss for this purpose. Recoveries made indirectly e.g., by
stoppage of increment or promotion as a measure of punishment, should not be treated as
recoveries made in cash. Where the staff is paid for by one Government and the loss is borne byBihar Financial Rules, 1950

another Government a copy of the orders regarding the action taken against the persons responsible
for the loss should be communicated by the former to the later.[Note 2. - As soon as a loss on
account of withdrawal of money from treasury connected with the Defence Service Payments, comes
to light, the Civil authorities will carryout the necessary investigation under their own procedure
and communicate the result thereof, together with their findings and orders regarding action taken
against the official responsible for the loss to the concerned administrative authority of Defence
Service under intimation to the Controller of Defence Accounts concerned for the preparation of loss
statements and its submission to the competent financial authority for regularisation.] [Inserted by
C.S. No. 38 dated 28.4.1950.]Remission of Disallowances by Audit and Writing off of over-payments
made to Government Servants
65.
The State Government may waive the recovery of an amount placed under objection by the
Accountant General or otherwise found to have been overpaid to a Government servant if-(i)the
amount disallowed has been drawn by the Government servant concerned under a reasonable belief
that he was entitled to it;(ii)the enforcement of recovery will, in the opinion of the State
Government, cause undue hardship, or it will be physically impossible to effect the recovery;
and(iii)in the case of disallowance of emoluments of the nature of pay as defined in Bihar Service
Code, Rule 34 made within one year of the date of payment:-(1)the Government servant is not in
receipt of pay exceeding Rs. 12,000 a year or, in the case of others the over-drawal has not the effect
of raising the Government servant's pay beyond Rs. 12,000 in any year,and(2)the over-drawal has
not been occasioned by delay in notifying a promotion or reversion.[Note. - If an amount due from a
person has to be written off on the ground that he/she is no longer in Government service and no
recovery is, therefore possible, the orders sanctioning write off should invariably contain a clause
that any sums which may be subsequently found due to the person concerned shall be adjusted
against the amount written off.] [Inserted by C.S. No. 37 dated 28.4.1950.]
66.
All sanctions to foregoing recovery under the foregoing Rule should be communicated to the
Accountant-General.Section IIICommunication of Sanction
67.
Financial sanctions and orders of competent authorities under these or any other authorised Rules,
e.g., the Fundamental Rules, Supplementary Rules, the Bihar Service Code, the Bihar Pension Rules,
the Bihar Travelling Allowance Rules, Bihar Treasury Code, the Bihar General Provident Funds
Rules, the Bihar Contributory Provident Fund Rules, the Public Works Department Code, the Public
Works Account Code, etc., will be communicated to the Accountant-General in accordance with the
procedure set out below :-(i)All financial sanctions and orders issued by a department within its own
financial powers as a department of the State Government will be communicated direct to the
Accountant-General by department, concerned. All other orders involving financial sanctions which
may be issued by departments of the State Government after consultation with the FinanceBihar Financial Rules, 1950

Department i.e., sanction beyond their financial powers will be communicated to the Accountant
General through the Finance Department.(ii)Sanction and orders of any other authority to which
the power of sanction has been delegated will be communicated to the Accountant-General by that
authority.(iii)In cases referred to in clause (i) above, if an order sanctioning expenditure is sent to
the Accountant-General direct by a Department of Government and that Department is not
competent to sanction the expenditure, the Accountant-General will not act upon it but will report
to the Finance Department, that such an order has been issued and will simultaneously request the
Administrative Department concerned that the order may be communicated to him through the
Finance Department as soon as possible.(iv)If an order or sanction has been issued with the
concurrence of the Accountant-General the fact should be mentioned in the endorsement to the
Accountant-General.(v)In all orders conveying sanctions to expenditure of a definite amount or up
to a specified limit the amount of sanction should always be expressed both in words and in
figures.(vi)All letters or orders conveying sanctions to expenditure, appointments, etc. must be
signed by an authorised Gazetted Government servant.Note. - In cases in which the documents
relating to any sanction of order are deemed secret, the Accountant-General will accept a statement
of fact signed by a Secretary to Government in lieu of those documents.
68.
All letters or memoranda conveying sanction to the grant of additions to pay such as special pay and
compensatory allowance, should contain a brief but clear summary of the reasons for the grant of
the additions so as to enable the Accountant-General to see that it is correctly classified as special
pay or compensatory allowance, as the case may be. In cases in which an official record in an open
letter is considered undesirable, the reasons for the grant of such additions to pay should be
communicated confidentially to the Accountant-General. A similar procedure should also be
followed in all other cases in which the rules require that the reasons for the grant of special
concessions or allowances should be recorded.
69.
Sanctions accorded by Government to grants of land and alienations of land revenue, other than
those in which assignments of land revenue are treated as cash payments, should be communicated
to the Accountant-General in a consolidated monthly return giving the details necessary for
enabling the Audit Officer to audit the sanctions accorded.
70.
When proposals for a new scheme or a new service not contemplated in the budget are placed at a
meeting of the Council of Ministers, details should be furnished showing the nature and condition of
the scheme.To enable the Accountant-General to compare the details and conditions with those
enumerated by the sanctioning authority in its subsequent orders of sanction, the Accountant
General should be supplied when the sanction is conveyed to him under Rule 67, with relevant
extracts from the proceedings of the meeting of the Council of Ministers.Section IVIndication of the
Source of Appropriations in the Sanction to ExpenditureBihar Financial Rules, 1950

71.
In all applications for sanction to expenditure it should be distinctly stated whether provision for the
proposed charge has, or has not, been made, in the budget estimates of the year, and, if it has not
been made, whether the funds can be found by valid re-appropriation.
72.
Authorities which sanction new expenditure after funds have been communicated, should be careful
to indicate the source of appropriation.Where it is desired to sanction expenditure before funds have
been communicated as may be necessary in order to avoid delay in starting work at the beginning of
a new financial year or to prevent duplication of orders, the authority which does so should be
careful to add the words "Subject to funds being communicated in the budget of the year".Note. -
Vague expression such as, "Subject to budget provision" should be carefully avoided in conveying
sanction to expenditure.Section VDate of Effect of Sanction
73.
Unless otherwise specially provided in the orders or rules themselves, the executive orders of
Government should take effect from the date of issue of the despatch, letter or telegram in which
sanction is conveyed, and statutory rules from the date on which they were passed. Similarly
sanctions of subordinate authorities will have effect from the date of the orders conveying them.The
general principle in all such cases should be-Sanction to any given expenditure becomes operative as
soon as funds have been appropriated to meet the expenditure, and does not become operative until
funds have been so appropriated.Sanction to recurring expenditure covering a specified term of
years becomes operative when funds are appropriated to meet the expenditure of the first year, and
remains in operation for each year of the specified term subject to appropriation in such
year.Section VIRetrospective Sanction
74.
All authorities which are competent to sanction revision of pay or the grant of concessions to
Government servants should bear in mind that retrospective effect should not be given to financial
sanctions, except in exceptional circumstances, without the special approval of Government.Section
VIILapse of Sanction
75.
A sanction for any fresh charge which has not been acted on for a year must be held to have lapsed,
unless it is specifically renewed with necessary provision in the budget estimates.Note 1. - This Rule
does not apply to a case where an allowance sanctioned for a post or a class of Government servants
has not been drawn by a particular incumbent of the post or a particular set of Government servants
nor does it apply to additions made gradually from year to year to a permanent establishment underBihar Financial Rules, 1950

a general scheme which has been sanctioned by proper authority.[Note 2. - The portion of one year
should be calculated from the date of issue of the sanction and the sanction should be considered to
have been acted on if payment in whole or in part, has been made in pursuance of the sanction
within twelve months from the date of its issue. In cases in which part payment has been made
within the stipulated period, the subsequent payment of the balance may subject to the existence of
budget provision be made without a fresh expenditure sanction. The bill for the subsequent
payment, besides containing a reference to the expenditure sanction, should also contain a reference
to the number and date of of the voucher under which the first payment was made.] [Inserted by
C.S. No. 4 dated 5.8.1957.][Note 3. - When there is a specific provision in a sanction for any fresh
charge that the expenditure would be met from the Budget provision of a specified year, such
sanction will lapse on the expiry of the specified financial year.] [Inserted by C.S. No. 31 dated
4.4.1959.]
76.
An order of the Government of India, in the absence of any indication to the contrary in the order
itself, will lapse only if and when it is superseded by an order of a latter date.Section VIIISpecial
Rule for Works Expenditure
77.
The sanction to an estimate for a public work will ordinarily cease to operate after a period of five
years from the date upon which it was accorded, but the acceptance by competent authority of a
budget estimate which includes specified provision for expenditure upon a work which is in progress
may be regarded as reviving, for the year in which the provision is made, the sanction to the
estimate.
Chapter 5
Budget
Responsibility for the preparations of the Budget Estimates
78.
The responsibility for the preparation of the statement of estimated revenue and expenditure under
Article 202 of the Constitution of India, which is laid before the legislature in each year, as well as
any supplementary estimates or demands for extra grants, lies with the Finance Department. The
material on which such estimates are based is obtained by that department from the departments
concerned, which are responsible for the correctness of the material itself. The Accountant-General
is, however, responsible for rendering such assistance in the preparation of the budget estimates as
may be settled in consultation with the Finance Department, and is bound to supply any
information in connection with budget estimates which he is in a position to furnish, and to offer
any opinion or advice in connection therewith which may be required by Government.The Heads ofBihar Financial Rules, 1950

Department and other subordinate authorities are responsible for the submission of correct detailed
estimates punctually on the date fixed by the Finance Department.
79.
Detailed rules regulating the procedure for preparation of budget estimates are embodied in the
Bihar Budget Manual, separately published. Rules for control of expenditure and for sanction of
re-appropriations will be found in Chapter 16 of these Rules.
Chapter 6
Establishment
Section IAlterations of Establishment
80.
No permanent post under Government can be created without the sanction of Government. In
respect of temporary posts powers have been delegated to Departments of Government and certain
Heads of Department and other subordinate authorities within specified limits. These powers are
generally embodied in the Compendium of Financial Delegations.All proposals for additions to
establishment, whether permanent or temporary, or for any increase in the emoluments of existing
post should be scrutinised with the greatest care by Heads of Departments and other authorities
concerned. In submitting such proposals, the instructions contained in the following Rules should
be carefully observed.
81.
When the entertainment of a new establishment or a change, temporary or permanent, is proposed
in an office, a letter fully explaining the proposals and the conditions which have given rise to them,
together with the proposition statement, if necessary under Rule 83 should be submitted to the
competent authority. In this letter should be set out inter alia-(i)the present cost, either of the
Section or Sections affected, or of the total establishment as the circumstances of the case may
indicate to be necessary;(ii)details of the pay of the post or posts and the number of posts which it is
proposed to add or modify; and(iii)as accurate an estimate as possible of the extra cost
involved.Note 1. - In determining the extra cost, allowance, whether fixed or variable, should be
included.Note 2. - The authorities submitted the proposal should take into account any claim to
pension that may arise in consequence of their proposal with reference to Rule 113 of the Bihar
Pension Rules and certify to that their having done so in their proposals.
82.
If the expenditure is proposed to be incurred in the current year, the proposals should show clearlyBihar Financial Rules, 1950

whether it can be met within the grant or appropriation of the year. If the expenditure can be met by
re-appropriation, a re-appropriation statement prescribed in Rule 494 should be submitted with the
proposals.
83.
Whenever any large scale or complicated proposals are made, for the revision of existing or the
creation of new establishments, the letter explaining the proposals should be accompanied by a
proposition statement in duplicate in F.R. Form 2 and submitted through the Accountant-General
who will verify the correctness of the statement.
84.
The details to be shown in proposition statements should be determined by the following principles
:-(i)The proposition statement should relate strictly to the section or part of the office affected by the
proposals. As regards the other parts or sections of the office, neither details nor figures of total cost
need be included.(ii)Where a sanction consists of both inferior and superior servants, details need
be given only of the class affected if a saving of labour will result from the adoption of the
procedure.(iii)Where the pay of any post existing or proposed rises from a minimum to a maximum
by periodical increments, the average monthly cost and not the actual or commencing cost must be
given. The average monthly cost for the purpose of this Rule should be calculated in accordance with
one or other of the following four formulae. Formula (1) should be used in the case of Gazetted
appointments and formula (2) in the case of non-gazetted appointments. In cases where one grade
is the channel of promotion to another grade, that is to say, where everybody in the first grade is
ultimately promoted to the second grade, formula (3) may be adopted to find the average cost of
appointments in the first grade. The use of formula (4) should be restricted to cases involving an
elaborate scale, consisting of two or more sections with efficiency bars at one or more
stages.Formula I
Average pay =| A + B2| +| (B - A)2| [| 1 - (R + 1)| {| 0.14 +| 1 - .01RF - E| }| ]
Formula 2
Average pay =| A + B2| +| (B - A)2| [| 1 - (R + 1)| {| 0.21 +| 1 - .015RF - E| }| ]
In the formulae (1) and (2)A = minimum pay.B = maximum pay.R = period of rise.E = average age
at entry in the grade, andF = average age at retirement on superannuation pension. This may be
taken to be 55 in almost every case unless there are special reasons to take it either at a lower or
higher figure.Formula 3
Average pay =| A + C2| +| (C - A)2| [| 1 - (S + 1)| {| .006 +| 1 - .004SG - E| }| ]
In formula (3)A - minimum pay.C - pay just before promotion to the second grade.S - period of rise
from A to C.E - average age at entry in the first grade, andG - average age at the time of promotion to
the second grade.Formula 4Average pay = ½(A + W1B1 + W2B2 + X1C1 + X2C2).Where A = the
initial pay of the scale,B1 B2 = the maximum pay of the different sections of the scale such as the
ordinary scales, the scale for passed clerks,W1 W2 = the proposition of the establishment which
would normally reach the maxima of B1 B2 respectively,C2, C2 = the pay at the different efficiencyBihar Financial Rules, 1950

bars, andX2, X2 = the proportion of the establishment which would normally be detained at C1 C2
respectively.(iv)The fixed allowances referred to in note 1 below Rule 81 should be entered in the
proposition statement but the variable allowances need not be included therein.Section IIVariation
in Sanctioned Pay of a Post
85.
The head of an office is not at liberty to re-adjust the pay of Government servants by giving one
Government servant more and another less than the sanctioned pay of his post, nor may be
distribute the pay of an absentee otherwise than as provided in the Rules governing the service to
which the Government servant belongs. But in the case of non-gazetted establishment divided into
separate units or cadres carrying different scales of pay there is no objection to excess appointments
made in a lower unit or cadre, against an equal or greater number of vacancies left unfilled in the
higher.Section IIITransfer of Office
86.
Every transfer of charge of a Gazetted Government servant should be reported by post on the same
day to the Accountant-General. The report should be made in F.R. Form 3 unless any other form has
been duly authorised and should be signed both by the relieved and the relieving Governments
servant. [Copies of the report should simultaneously be sent to the Treasury or Sub-treasury where
the officer draws his pay and to the head of the department or other controlling authority
concerned.] [Substituted by C.S. No. 8 dated 24.1.1957.]
87.
In cases in which the transfer of charge involves assumption of responsibility for cash, stores, etc.,
the following instructions should be observed :-(i)The cash book or imprest account should be
closed on the date of transfer and a note recorded in it over the signature of both the relieved and
the relieving Government servant, showing the cash and imprest balances, and the number of
unused cheques, if any, made over and received by them respectively.'(ii)The relieving Government
servant in reporting that the transfer has been completed should bring to notice anything irregular
or objectionable in the conduct of business that may have come officially to his notice. He should
examine the accounts, count the cash, inspect the stores, count, weigh and measure certain selected
articles in order to test the accuracy of the returns. He should also describe the state of the account
records.(iii)In the case of any sudden casualty occurring or any emergent necessity arising for a
Government servant to quit his charge the next senior Government servant of the department
present will take charge. When the person who takes charge is not a Gazetted Government servant,
he must at once report the circumstances to his nearest departmental superior, and obtain orders as
to the cash in hand, if any.Note. - The special procedure to be followed when there is a 'change in the
incumbency of independent charge of a treasury is laid down in Rule 48 of the Bihar Treasury
Code.Section IVSpecial Rules for the Public Works DepartmentBihar Financial Rules, 1950

88.
The relieving Government servant will take up the expenditure of cash and stores from and for the
first day of the month during which the relief took place, and submit the next monthly accounts in
the same manner as if he has been in charge during the whole month. But the relieved Government
servant remains responsible that a proper explanation is forthcoming for transactions during his
incumbency.
89.
If the relieving Government servant fails to bring to notice within a reasonable period any deficiency
or defect in work or stores taken over from his predecessor, he will be held responsible for the same,
both as to quantity and quality, so far as he was in a position to ascertain it.
90.
The receipts of cash and stores balances should be prepared by the relieved Government servant,
but the relieving Government servant should note any instruction therein so that the
Superintending Engineer or the Executive Engineer as the case may be, may pass such orders in
respect of any deficient articles as may be necessary. A copy of the receipts may be given to the
relieved Government servant, if desired by him.
91.
The relieving Government servant should then unless otherwise ordered proceed with the relieved
Government servant to inspect the records, cash, stores, works and materials at site of works
incharge of subordinates, but in the case of the transfer of a divisional charge, the relieved
Government servant should accompany the relieving Government servant in inspection of the
outstations only when so directed by the Superintending Engineer.The relieving Government
servant should examine the accounts, count the cash, inspect the stores, and count, weigh and
measure certain selected articles, in order to test the accuracy of the returns, and should minutely
examine the work in progress as to their quality, and as to their accordance with the sanction, plans,
and estimates; he should also record his opinion as to the correctness of accounts of materials at
site.
92.
The relieved Government servant should further furnish the relieving Government servant with a
complete statement of all unadjusted claims with the reasons for their not having been adjusted in
due course and a report as to any complication likely to arise owing to their non-adjustment.Bihar Financial Rules, 1950

93.
The relieving Government servant, in reporting that the transfer has been completed should bring to
notice anything irregular or objectionable in the conduct of business that may have come officially to
his notice. In the case of the transfer of a divisional charge, he should describe the state of the
records, cash, stores and works mentioning what outstations he has yet to inspect and when he
proposes to visit each.
94.
The relieving Divisional Officer should mention specially in his transfer report whether the accounts
may be considered fairly to represent the progress of the work.
95.
In the case of transfer of charges other than divisions and subdivisions, the Executive Engineer
should issue instructions as to the works to be inspected jointly by the relieved and relieving
Government servants.Section VDate of Birth
96.
Every person newly appointed to a service or post under Government should at the time of the
appointment declare the date of his birth by the Christian era with as far as possible confirmatory
documentary evidence such as a Matriculation Certificate, Municipal Birth Certificate and so on. If
the exact date is not known, an approximate date may be given. The actual date or the assumed date
determined under Rule 97 should be recorded in the history of service, service book, or any other
record that may be kept in respect of the Government servant's service under Government and once
recorded, it cannot be altered, except in the case of a clerical error without the orders of the State
Government.[Note 1. - No representation for rectification of mistake in the date of birth as entered
in the records of service of a Government servant shall be entertained, if it is not submitted within a
period of ten years of the date of his entry into Government service. Representation submitted
thereafter will be summarily rejected by the authority competent to pass final orders under this Rule
unless there are very exceptional cases to relax this time-limit.] [Inserted by C.S. No. 47 dated
23.1.1961.]Note 2. - Heads of departments are authorised to exercise this power in the case of
non-Gazetted Government servants under their control.
97.
(1)If a Government servant is unable to state his exact date of birth but can state the year, or year
and month of birth, the 1st July or the 16th of the month respectively, may be treated as the date of
his birth.(2)If he is only able to state his approximate age, his date of birth may be assumed to be the
corresponding date, after deducting the number of years representing his age from his date of
appointment.(3)When a person who first entered Military employ is subsequently employed in aBihar Financial Rules, 1950

civil department, under the State Government, the date of birth for the purpose of the civil
employment should be the date stated by him at the time of attestation or if at the time of attestation
he stated only his age, the date of birth should be deduced with reference to that age according to
the method indicated in sub-paragraph (2) above.Note. - Cases in which the date of birth has been
deduced from the age at appointment or attestation by any other method, need not be
re-opened.Section VILeave Applications
98.
Subject to any special rules or orders issued by the competent authority, all applications for leave
should be submitted to the sanctioning authority concerned, on F.R. Form 4.Section VIIAnnual
Returns of Non-Gazetted Establishments
99.
Early in [March] [Substituted by April vide C.S. No. 46. 3.12.1960.], each year, a detailed statement
of the permanent establishment existing on the 1st [March] [Substituted by April vide C.S. No. 46.
3.12.1960.], should be prepared by each head of office and transmitted to the Accountant-General
direct, as soon as possible, not later than the 15th May. The directions given by the Comptroller and
Auditor-General with regard to the form, preparation and submission of those returns are contained
in Appendix 4.Note. - The detailed statement should be prepared in two parts, one for permanent
establishment including permanent and officiating incumbents of permanent posts and the other
covering all temporary posts in existence on the first of [March] [Substituted by April vide C.S. No.
46. 3.12.1960.].Section VIIIService Books
100.
Detailed Rules regarding maintenance of service books are contained in Rules 288 to 296 of the
Bihar Service Code.
101.
(1)At a fixed time early in the year the service books should be taken up for verification by the head
of the office [or by any senior Gazetted Officer under him] [Inserted by C.S. No. 18 dated 15.4.1958.]
who after, satisfying himself that the services of the Government servant concerned are correctly
recorded in each service book, should record in it a certificate in the following form over his
signature :"Service verified up to (date) from (the record from which the verification is made)".Note.
- The verification of service referred to above should be in respect of all service qualifying for
pension whether permanent, provisional, temporary or officiating.(2)The head of the office in
recording the annual certificate of verification should, in the case of any portion of service that
cannot be verified from office records, distinctly state that for the excepted periods (naming them) a
statement in writing by the Government servant, as well as a record of the evidence of his
contemporaries, is attached to the book.When, however, a non-Gazetted Government servant isBihar Financial Rules, 1950

transferred from one office to another the head of the office under whom he was originally employed
should record [himself or authorise any senior Gazetted Officer under him to record in the service
book under this signature the result of the verification of service, which reference to pay bills and
acquittance rolls, in respect of the [whole period for which the Government servant concerned was
paid in his office, was employed under him, before forwarding the service book to the office where
the services are transferred.] [Inserted by C.S. No. 18 dated 15.4.1958.](3)When non-Gazetted
Government servants are officiating in Gazetted Posts, their service books should be kept by the
head of the office to which each such Government servant permanently belongs, but when they are
confirmed in such posts, their service books should be forwarded to the Accountant-General's office
for record.Service Rolls
102.
Service rolls for Government servants, when they are maintained under Rule 297 of the Bihar
Service Code, should be taken up every year for verification of service and record of necessary
certificate in the manner laid down in Rule 101.Section IXArrear Claims
103.
Detailed Rules regarding arrear claims are given in Rule 143 of the Bihar Treasury Code.
104.
Claims against Government, which are barred by time under the provisions contained in Section 3,
read with the First Schedule of the Indian Limitation Act of 1908, or under any other provisions of
law relating to limitation, should ordinarily be refused and no claim on account of such a time
barred item should be paid without the sanction of Government. The onus is upon the claimant to
establish a claim to special treatment for a time barred item, and it is the duty of the authority
against which such a claim is made to refuse the claim until a case for other treatment is made out.
All petty time barred claims are to be rejected forthwith and only important claims of this nature
considered.It is the duty of the authority against which a claim is made to consider in the first
instance the question of a time-bar before submitting it to the Accountant-General for the issue of
authority for payment. The Accountant-General will refuse payment of all claims found to be
time-barred until the sanction of Government has been obtained.
Chapter 7
Contingencies
Section IIntroductoryBihar Financial Rules, 1950

105.
The Rules in this Chapter are supplementary to the general rules of procedure prescribed in Section
V of Chapter V of the Bihar Treasury Code and have to be applied, where necessary, in conjunction
with them.
106.
The orders relating to the supply of articles for the public service are contained in the Store Rules in
Appendix 8; and miscellaneous rules regarding contingent expenditure on certain other objects are
given in Annexure A to Appendix 5.
107.
Special Rules applicable to particular departments are contained in the Manuals, Code, etc., of the
departments concerned.
108.
The different classes into which contingent charges incurred on the public service are divided, and
conditions governing them, are laid down in Section V of Chapter V of the Bihar Treasury Code. The
classification to be adopted in each department of office is regulated by general or special orders of
Government.Note. - Contingent charges are to be recorded and treated in the accounts and charges
of the month in which they are actually disbursed from treasury.
109.
Departments of Government exercise powers in respect of contingent charges of officers directly
subordinate to them in accordance with any general or specific rule or orders, such as those
contained in Annexure 'A' to Appendix 5, restricting their financial powers to sanction
expenditure.Section IIPowers of Subordinate Authorities to Sanction Contingent Charges
110.
(1)The financial powers of subordinate authorities to sanction contingent expenditure are regulated
generally by the orders embodied in Annexure A to Appendix 5 and in the Compendium of Financial
Delegations and by such other general or special orders as may be issued by Government in this
behalf.Subject as aforesaid, the head of an office may incur or sanction expenditure on contingencies
within the amount of appropriation placed at his disposal for the purpose, provided that-(i)in cases
where any special rules, restrictions, limit or scale has been prescribed by competent authority
regarding any particular item or class of contingent expenditure, it should be strictly observed.Note.
- (i) Special rules, restrictions, etc., prescribed by the Government regarding individual items of
contingencies are laid down in Annexure 'A' to Appendix 5.(ii)Contingent expenditure of an unusualBihar Financial Rules, 1950

character or involving departure from any general or special rule or order made by Government
should not be incurred, nor should any liability be undertaken in connection therewith, without the
previous sanction of Government.(2)In respect of contract contingent charges for which a lump sum
is placed annually at the disposal of a disbursing officer, no formal sanction will be required for
expenditure incurred within the annual allotment, except in so far as the authority fixing the
contract allotment issues directions to the contrary.(3)The head of an office may authorise any
Gazetted Government servant serving under him to incur expenditure under sub-paragraph (1)
above, subject to the conditions specified in Rule 148 of the Bihar Treasury Code.
111.
In the case of non-recurring contingencies the competent authority may, where this course is more
convenient, accord sanction by signing or countersigning the bill or voucher, whether, before or
after the money is drawn instead of by a separate sanction.Section IIIPermanent Advances
112.
Permanent 'advances' may be granted to officers who may have to make payments before they can
place themselves in funds by drawing on the treasury.They are subject to the following rules :-(i)The
amount of the advance will be fixed by Government, except in cases falling under clause
(ii).(ii)Heads of department may sanction the grant of permanent advances for offices subordinate
to them up to the amount advised as appropriate by the Accountant General subject to a limit of Rs.
500 for each office. Permanent advances exceeding Rs. 500 for any office subordinate to a head of a
department and all permanent advances for offices of heads of departments must require sanction
of the State Government.(iii)Applications for the grant or revision of a permanent advances must be
submitted to the sanctioning authority through the Accountant General who will advise as to the
appropriate amount of the advance. In cases falling under clause (ii) above, if there is any difference
of opinion between the Accountant General and the sanctioning authority on this point, the matter
should be referred for the orders of Government.Note. - The applications, for permanent advances
should be accompanied by a statement showing month by month for the preceding twelve months
the amounts of contingent bills cashed with classified details of items of expenditure.(iv)As these
advances involve the permanent retention of money outside the treasury, they must not be larger
than is absolutely essential.(v)These advances should not be multiplied unnecessarily. An officer's
advance should meet the needs of every branch of his office. If he has subordinates who require
petty sums, he should spare a small portion of his own advance for their use rather than apply for
separate advances for them, taking acknowledgments from them in the same way as he himself
furnishes acknowledgments to the Accountant General and retaining them in his office.(vi)The
advance is intended to provide, on the responsibility of the officer entrusted with it, for emergent
petty advances of all kinds, though it is seldom and they will be needed for other than contingent
charges; thus, if an inferior servant is required to travel by rail, his fare must sometimes necessarily
be advanced from his amount.(vii)The holder of a permanent advance is responsible for the safe
custody of the money placed in this hands and he must at all times be ready to account for the total
amount of the money.(viii)In the case of transfer of charges and yearly on the 15th April, each officer
holding a permanent advance must send an acknowledgment to the Accountant General of theBihar Financial Rules, 1950

amount due from and accountable for by himself as on the 31st March, preceding.[Note. - Advances
made out of the permanent advance to inferior and other non-Gazetted Government servant for
journey on tour, need not appear in the Government account. Travelling allowance bills may be
made out for the full claims admissible as soon as the journeys are completed and any advances
made out of the permanent advance may be recovered out of the accounts drawn from the treasury
on such travelling allowances bills.] [Note I deleted & Note 2 made as 'Note' by C.S. No. 8 dated
2.12.1957.]Section IVControl of Contingent Expenditure
113.
For purposes of control and audit, Government will issue orders specifying the nature or object of
contingent charges of particular disbursing officers which should be classed as countersigned
contingent charges to be drawn and accounted for in accordance with the procedure prescribed in
Rule 318 et seq of the Bihar Treasury Code.Expenditure incurred by a disbursing officer on objects
classed as countersigned contingencies must come under the direct supervision and scrutiny of the
head of the department or the controlling officer who will sign the detailed bills relating to them.
Monthly detailed bills in respect of countersigned contingent charges incurred by each officer
should be submitted to the controlling authority concerned for detailed scrutiny and transmission
after countersignature to the Accountant General. Full details of such charges need not be entered in
the abstract bills presented for payment at the treasury.A competent authority may in respect of
specified items of countersigned contingent charges require the abstract contingent bills to be sent
to the controlling authority for scrutiny and countersignature before it is presented for payment at
the treasury.Note. - The provisions of this Rule do not apply to contingent charges of heads of
departments and other controlling authorities, which will be drawn and accounted for in accordance
with the procedure laid down in the following Rule.
114.
No detailed bills need be submitted to a higher authority for contingent charges which are not
classed as countersigned contingencies; each bill presented at treasury should, therefore, contain
full details of the expenditure, supported by necessary sub-vouchers for individual payments
included in the bill.
115.
The duties and responsibilities of disbursing and controlling officers with regard to contingent
expenditure incurred on the public service are defined in Rules 305, 305A, 306, 306A of the Bihar
Treasury Code. The head of each department should issue such subsidiary instructions as may be
necessary for the guidance of controlling and disbursing officers sub-ordinate to him.
116.
Detailed instructions as to the general procedure of control for the expenditure againstBihar Financial Rules, 1950

appropriation are contained in Chapter 16. The following special instructions are laid down for the
control of contingent expenditure :-(i)Where the appropriation for contingent charges covers
expenditure on a number of distinct and individually important objects or class of expenditure, such
appropriation should be distributed by the controlling authority among the important items
comprised in it. If some of the items are not important, those items taken as a whole may be treated
as a single important item for this purpose. The expenditure on each important item should be
watched and controlled separately against the allotment for it, especially when the charges are of a
fluctuating nature. The contingent register prescribed in Rule 308 of the Bihar Treasury Code,
should be so designed that this can be done conveniently.(ii)For countersigned contingencies the
monthly detailed bills provide all the information required by the controlling authority for checking
the expenditure against the appropriation, if, in any month, expenditure exceeds the monthly
proportion of the appropriation for the year, the disbursing officer should send a report to the
controlling authority along with the detailed bill, furnishing special reasons for incurring the excess
expenditure.(iii)For non-countersigned contingencies, the controlling authority should get
periodical statements from each disbursing officer (monthly or at least quarterly) of the progressive
expenditure compared with the allotment under each item for which there is a specific
appropriation or allotment. If the expenditure is progressing too rapidly, he should instruct the
disbursing officer to curtail it to the necessary extent. He should also during his local inspections
scrutinize the contingent registers of the offices under his control and satisfy himself generally that
the charges are necessary and not excessive, the rates correct, the sanction obtained adequate,
etc.Section VSpecial Rules Relating to Particular Kinds of Contingencies Contract Contingencies
117.
When under any special order of competent authority a lump sum is placed annually at the disposal
of a disbursing officer for expenditure on specified items of contingencies without further
restrictions, the officer incurring expenditure against the lumpsum allotment should be held entirely
responsible for the regularity of such expenditure, and for any expenditure in excess of such
allotment until the excess is sanctioned by competent authority.Contingencies Regulated by Scales
118.
Contingencies regulated by scales include such charges as liveries to inferior servants, rewards for
destruction of wild animals, batta to witnesses and the like.The State Government may lay down
conditions precedent to the application of the scale and may make it clear whether the bill must be
countersigned before or after payment and what certificates, if any, should support the bill. It should
be the duty of the controlling officer to see that the charges incurred are in accordance with the
prescribed scales and the conditions which govern them.Section VISpecial Rules for Public Works
Department When Cheques are drawn on Treasuries for Contingent Charges
119.
Payment should be made out of the regular cash or imprest balances of the division and not out of
undisbursed balances of cash drawn from treasuries for payment of establishment charges.WhenBihar Financial Rules, 1950

bills are drawn on Treasuries
120.
Payments made out of the cash drawn by bills from the treasury are subject to the rule in this
chapter, in regard to the manner of authorising and making payment.
121.
Debits from other departments or State for supplies chargeable to contingencies, intimations of
which may be received from the Accountant General, Bihar, should be dealt with in the manner
indicated in Rule 326 of the Bihar Treasury Code, without being formally responded to in the
accounts of the division. Other debits, of which intimations may be received direct through Advices
of Transfer Debit, and stock and adjustment transactions arising within the division, should be
cleared, by an entry in the regular accounts by debits to "the Accountant General's office on account
of the contingencies of the division", the transaction being incorporated in due course in the
contingent bill as laid down in the rule already quoted.
122.
The cash obtained for contingent charges should not be mixed up with the balances of cash obtained
for other purposes.Section VIIExpenditure for Other Officers
123.
The conditions under which a department of Government may make charges for services rendered
or articles supplied by it and the procedure to be observed in dealing with such charges are laid
down in the Comptroller and Auditor General's Account Code, Volume I, and in Rule 326 of the
Bihar Treasury Code. When a Government servant makes purchases or incurs expenditure through
a Government servant in another district the procedure indicated in Rule 329 of the Bihar Treasury
Code, should generally be followed.
Chapter 8
[Procurement of Goods and Services] [Substituted by Bihar
Finance (Amdt.) Rules, 2005. Published in Bihar Gazette (Ed.
Ordinary) dated 11.11.2005.]
124. [ [Substituted by Bihar Finance (Amdt.) Rules, 2005. Published in Bihar
Gazette (Ed. Ordinary) dated 11.11.2005.]
This chapter contains the general Rules applicable to all Ministries or Departments, regardingBihar Financial Rules, 1950

procurement of goods required for use in the public service. Detailed instructions relating to
procurement of goods may be issued by the procuring departments broadly in conformity with the
general Rules contained in this Chapter.]
125. Definition of goods.
- The term 'goods' used in this chapter includes all articles, material, commodities, livestock,
furniture, fixtures, raw material, spares, instruments, machinery, equipment, industrial plant etc.
purchased or otherwise acquired for the use of Government but excludes books, publications,
periodicals, etc. for a library.
126. Fundamental principles of public buying.
- Every authority delegated with the financial powers of procuring goods in public interest shall have
the responsibility and accountability to bring efficiency, economy, transparency in matters relating
to public procurement and for fair and equitable treatment of suppliers and promotion of
competition in public procurement.The procedure to be followed in making public procurement
must conform to the following yardsticks :-(i)the specifications in terms of quality, type etc. as also
quantity of goods to be procured, should be clearly spelt out keeping in view the specific needs of the
procuring organisations. The specifications so worked out should meet the basic needs of the
organisation without including superfluous and non-essential features, which may result in
unwarranted expenditure. Care should also be taken to avoid purchasing quantities in excess of
requirement to avoid inventory carrying costs;(ii)offers should be invited following a fair,
transparent and reasonable procedure;(iii)the procuring authority should be satisfied that the
selected offer adequately meets the requirement in all respects;(iv)the procuring authority should
satisfy itself that the price of the selected offer is reasonable and consistent with the quality
required;(v)at each stage of procurement the concerned procuring authority must place on record,
in precise terms, the considerations which weighed with it while taking the procurement decision.
127. Authorities competent to purchase goods.
- An authority which is competent to incur contingent expenditure may sanction the purchase of
goods required for use in public service in accordance with Appendix 5, Compendium of Financial
Delegations and Bihar Stationary Manual, following the general procedure contained in the
following rules.
128. Powers for procurement of goods.
- The Departments have been delegated full powers to make their own arrangements for
procurement of goods. In case however, a Department does not have the required expertise, it may
purchase through the Central Purchase Organisation (e.g. DGS&D) or State Purchase Organisation
with the approval of competent authority. The purchase shall be done on direct payment basis and
not on book transfer basis.Bihar Financial Rules, 1950

129. Designation of State Purchase Organisation.
- State Government can designate one or more organizations as State Purchase Organisation for the
procurement of any particular class of goods keeping in view the expertise developed or to be
developed.
130. Rate Contract.
- The State Purchase Organisation shall conclude rate contracts with the registered suppliers, for
goods and items of standard types, which are identified as common user items and are needed on
recurring basis by various Departments.Definition of Registered suppliers is given in Rule 131
below. The State Purchase Organisation will furnish and update all the relevant details of the rate
contracts in its web site. The Departments shall follow those rate contracts to the maximum extent
possible on direct payment basis and not on book transfer basis.
131. Registration of Suppliers.
- (i) With a view to establishing reliable sources for procurement of goods commonly required for
Government use, the State Purchase Organisation will prepare and maintain item-wise lists of
eligible and capable suppliers. Such approved suppliers will be known as "Registered Suppliers". All
Departments may utilise these lists as and when necessary. Such registered suppliers are prima facie
eligible for consideration for procurement of goods through Limited Tender Enquiry.They are also
ordinarily exempted from furnishing bid security along with their bids. A Head of Department may
also register suppliers of goods which are specifically required by that Department or
Office.(ii)Credentials, manufacturing capability, quality control systems, past performance,
after-sales service, financial background etc. of the supplier(s) should be carefully verified before
registration.(iii)The supplier(s) will be registered for a fixed period (between 1 to 3 years) depending
on the nature of the goods. At the end of this period, the registered supplier(s) willing to continue
with registration are to apply afresh for renewal of registration. New supplier(s) may also be
considered for registration at any time, provided they fulfil all the required
conditions.(iv)Performance and conduct of every registered supplier is to be watched by the
concerned Department. The registered supplier(s) are liable to be removed from the list of approved
suppliers if they fail to abide by the terms and conditions of the registration or fail to supply the
goods on time or supply substandard goods or make any false declaration to any Government
agency or for any ground which, in the opinion of the Government, is not in public interest.
131A. Enlistment of Indian Agents.
- As per the Compulsory Enlistment Scheme of the Department of Expenditure, Ministry of Finance,
Government of India it is compulsory for Indian agents, who desire to quote directly on behalf of
their foreign principals, to get themselves enlisted with the Central Purchase Organisation (eg. DGS
& D). Such Indian agents will have to get themselves registered with State Purchase Organisation.
However, such enlistment is not equivalent to registration of suppliers as mentioned under Rule 131Bihar Financial Rules, 1950

above.
131B. Price Preference and other concessions for public sector and state
suppliers.
- A maximum of 2 (two) per cent price preference will be given to the goods produced by the
large/medium industries (including Public Sector Undertakings) located and registered in the State
over the goods produced by the large/medium industries located outside the State of Bihar.
Similarly, 7 (seven) per cent price preference will be given to the goods produced by the small scale
units located and permanently registered in the State of Bihar over the goods produced by the
small/medium/large industries located outside the State. While giving price preference, no
relaxation is to be made in terms of quality and specifications. The small scale units located in Bihar
shall not be liable to deposit earnest money. They will have to deposit only 20 per cent of the general
security amount, however, after receiving the purchase order, if they fail to supply the goods,
without any appropriate reason, they will be blacklisted as per the procedure laid down.
131C. Purchase of goods without quotation.
- Purchase of goods upto the value of Rs. 15,000/- (Rupees Fifteen Thousand) only on each occasion
may be made without inviting quotations or bids on the basis of a certificate to be recorded by the
competent authority in the following format."I,..........., am personally satisfied that these goods
purchased are of the requisite quality and specification and have been purchased from a reliable
supplier at a reasonable price."
131D. Purchase of goods by purchase committee.
- Purchase of goods costing above Rs. 15,000/ (Rupees Fifteen Thousand) only and upto Rs.
1,00,000/-(Rupees One lakh) only on each occasion may be made on the recommendations of a
duly constituted Local Purchase Committee consisting of three members of an appropriate level as
decided by the Head of the Department. The committee will survey the market to ascertain the
reasonableness of rate, quality and specifications and identify the appropriate supplier. Before
recommending placement of the purchase order, the members of the committee will jointly record a
certificate as under."Certified that we .........., members of the purchase committee are jointly and
individually satisfied that the goods recommended for purchase are of the requisite specification
and quality, priced at the prevailing market rate and the supplier recommended is reliable and
competent to supply the goods in question."
131E. Purchase of goods directly under rate contract.
(1)In case a Department directly procures Central Purchase Organisation (e.g. DGS & D)/State
Purchase Organisation rate contracted goods from suppliers, the prices to be paid for such goods
shall not exceed those stipulated in the rate contract and the other salient terms and conditions of
the purchase should be in line with those specified in the rate contract. The Department shall makeBihar Financial Rules, 1950

its own arrangement for inspection and testing of such goods where required.(2)The State Purchase
Organisation (e.g. DGS&D) should host the specifications, prices and other salient details of
different rate contracted items, appropriately updated, on the web site for use by the procuring
Department.
131F.
A demand for goods should not be divided into small quantities to make piece meal purchases to
avoid the necessity of obtaining the sanction of higher authority required with reference to the
estimated value of the total demand.
131G. Purchase of goods by obtaining bids.
- Except in cases covered under Rule 131C, 131D and 131 E(1), Departments shall procure goods
under the powers referred to in Rule 128 above by following the standard method of obtaining bids
in.(i)Advertised Tender Enquiry;(ii)Limited Tender Enquiry;(iii)Single Tender Enquiry.
131H. Advertised Tender Enquiry.
- (i) Subject to exceptions incorporated under Rules 131 I and 131 J, invitation to tenders by
advertisement should be used for procurement of goods of estimated value Rs. 25 lakh (Rupees
Twenty Five Lakh) and above. Advertisement in such case should be given in the Indian Trade
Journal (ITJ), published by the Director General of Commercial Intelligence and Statistics, Kolkata
and at least in one national daily having wide circulation.(ii)An organisation having its own website
should also publish all its advertised tender enquiries on the website and provide a link with NIC
website. It should also give its website address in the advertisements in ITJ and newspapers.(iii)The
organisation should also post the complete bidding document in its website and permit prospective
bidders to make use of the document downloaded from the website. If such a downloaded bidding
document is priced, there should be clear instructions for the bidder to pay the amount by demand
draft etc. along with the bid.(iv)Where the Department feels that the goods of the required quality,
specifications etc., may not be available in the country and it is necessary to also look for suitable
competitive offers from abroad, the Department may send copies of the tender notice to the Indian
Embassies abroad as well as to the foreign Embassies in India. The selection of the Embassies will
depend on the possibility of availability of the required goods in such countries.(v)Ordinarily, the
minimum time to be allowed for submission of bids should be three weeks from the date of
publication of the tender notice or availability of the bidding document for sale, whichever is later.
Where the department also contemplates obtaining bids from abroad, the minimum period should
be kept as four weeks for both domestic and foreign bidders.
131I. Limited Tender Enquiry.
- (i) This method may be adopted when estimated value of the goods to be procured is up to Rupees
Twenty five Lakhs. Copies of the bidding document should be sent directly by speed post/registeredBihar Financial Rules, 1950

post/courier/e-mail to firms which are borne on the list of registered suppliers for the goods in
question as referred under Rule 131 above. The number of supplier firms in Limited Tender Enquiry
should be more than three. Further, web based publicity should be given for limited tenders. Efforts
should be made to identify a higher number of approved suppliers to obtain more responsive bids
on competitive basis.(ii)Purchase through Limited Tender Enquiry may be adopted even where the
estimated value of the procurement is more than Rupees Twenty Five Lakhs, in the following
circumstances.(a)The competent authority in the Department certifies that the demand is urgent
and any additional expenditure involved by not procuring through advertised tender enquiry is
justified in view of urgency. The Department should also put on record the nature of the urgency
and reasons why the procurement could not be anticipated.(b)There are sufficient reasons, to be
recorded in writing by the competent authority, indicating that it will not be in public interest to
procure the goods through advertised tender enquiry.(c)The sources of supply are definitely known
and possibility of fresh source(s) beyond those being tapped, is remote.(iii)Sufficient time should be
allowed for submission of bids in Limited Tender Enquiry cases.
131J. Two bid system.
- For purchasing high value plant, machinery etc. of a complex and technical nature, bids may be
obtained in two parts as under:-(a)Technical bid consisting of all technical details alongwith
commercial terms and conditions; and(b)Financial bid indicating item-wise price for the items
mentioned in the technical bid.The technical bid and the financial bid should be sealed by the bidder
in separate covers duly superscribed and both these sealed covers are to be put in a bigger cover
which should also be sealed and duly superscribed.The technical bids are to be opened by the
purchasing Department at the first instance and evaluated by a competent committee or authority.
At the second stage financial bids of only the technically acceptable offers should be opened for
further evaluation and ranking before awarding the contract.
131K. Late Bids.
- In the case of advertised tender enquiry or limited tender enquiry, late bids (i.e. bids received after
the specified date and time for receipt of bids) should not be considered.
131L. Single Tender Enquiry.
- Procurement from a single source may be resorted to in the following circumstances.(i)It is in the
knowledge of the user department that only a particular firm is the manufacturer of the required
goods.(ii)In a case of emergency, the required goods are necessarily to be purchased from a
particular source and the reason for such decision is to be recorded and approval of competent
authority obtained.(iii)For standardisation of machinery or spare parts to be compatible to the
existing sets of equipment (on the advice of a competent technical expert and approved by the
competent authority, the required item is to be purchased only from a selected firm.Note :
Proprietary Article Certificate in the following form is to be provided by the Department before
procuring the goods from a single source under the provision of sub Rule 131L (i) and 131L (iii) as
applicable.(i)The indented goods are manufactured by M/s..............(ii)No other make or model isBihar Financial Rules, 1950

acceptable for the following reasons.(iii)Concurrence of internal finance wing/Finance Department
to the proposal vide:..............(iv)Approval of the competent authority vide :.......(Signature with date
and designation of the procuring officer)'
131M. Contents of Bidding Document.
- All the terms, conditions, stipulations and information to be incorporated in the bidding document
are to be shown in the appropriate chapters as below :-Chapter - 1 : Instructions to Bidders.Chapter
- 2 : Conditions of Contract.Chapter - 3 : Schedule of Requirements.Chapter - 4 : Specifications and
allied Technical Details.Chapter - 5 : Price Schedule (to be utilised by the bidders for quoting their
prices).Chapter - 6 : Contract Form.Chapter - 7 : Other Standard Forms, if any, to be utilised by the
purchaser and the bidders.
131N. Maintenance Contract.
- Depending on the cost and nature of the goods to be purchased, it may also be necessary to enter
into maintenance contract(s) of suitable period either with the supplier of the goods or with any
other competent firm, not necessarily the supplier of the subject goods. Such maintenance contracts
are especially needed for sophisticated and costly equipment and machinery. It may however be
kept in mind that the equipment or machinery is maintained free of charge by the supplier during its
warranty period or such other extended periods as the contract terms may provide and the paid
maintenance should commence only thereafter.
131O. Bid Security.
- (i) To safeguard against a bidder's withdrawing or altering its bid during the bid validity period in
the case of advertised or limited tender enquiry, Bid Security (also known as Earnest Money) is to be
obtained from the bidders except those who are registered with the Central Purchase
Organisation/State Purchase Organisation, National Small Industries Corporation (NSIC) or the
concerned Department. The bidders should be asked to furnish bid security along with their bids.
Amount of bid security should ordinarily range between two percent to five percent of the estimated
value of the goods to be procured. The exact amount of bid security, should be determined
accordingly by the Department and indicated in the bidding documents. The bid security may be
accepted in the Form of Account Payee Demand Draft, Fixed Deposit Receipt, Banker's Cheque or
Bank Guarantee from any of the Commercial Banks in an acceptable form, safeguarding the
purchaser's interest in all respects. The bid security is normally to remain valid for a period of forty
five days beyond the final bid validity period.(ii)Bid securities of the unsuccessful bidders should be
returned to them at the earliest after expiry of the final bid validity and latest on or before the 30th
day after the award of the contract.
131P. Performance Security.
- (i) To ensure due performance of the contract, Performance Security is to be obtained from theBihar Financial Rules, 1950

successful bidder awarded the contract. Performance Security is to be obtained from every
successful bidder irrespective of its registration status etc. Performance Security should be for an
amount of five to ten percent, of the value of the contract. Performance Security may be furnished in
the Form of an Account payee Demand Draft, Fixed Deposit Receipt from a Commercial Bank, Bank
Guarantee from a Commercial Bank in an acceptable form safeguarding the purchasers interest in
all respects.(ii)Performance Security should remain valid for a period of sixty days beyond the date
of completion of all contractual obligations of the supplier including warranty obligations.(iii)Bid
security should be refunded to the successful bidder on receipt of Performance Security.
131Q.
(1)Advance payment to supplier. - Ordinarily, payments for services rendered or supplies made
should be released only after the services have been rendered or supplies made. However, it may
become necessary to make advance payments in the following types of cases :-(i)Advance payment
demanded by firms holding maintenance contracts for servicing of Air-conditioners, computers,
other costly equipment, etc.(ii)Advance payment demanded by firms against fabrication contracts,
turn-key contracts etc Such advance payments should not exceed the following limits:-(i)Thirty per
cent, of the contract value to private firms;(ii)Forty per cent, of the contract value to a State or
Central Government agency or a Public Sector Undertaking; or(iii)In case of maintenance contract,
the amount should not exceed the amount payable for six months under the contract.Departments
may relax, in consulation with Internal Finance Advisor/Finance Department concerned, the
ceilings (including percentage laid down for advance payment for private firms) mentioned above.
While making any advance payment as above, adequate safeguards in the form of bank guarantee
etc should be obtained from the firm.(2)Part payment to suppliers : Depending on the terms of
delivery incorporated in a contract, part payment to the supplier may be released after it despatches
the goods from its premises in terms of the contract.
131R. Transparency, competition, fairness and elimination of arbitrariness in
the procurement process.
- All Government purchases should be made in a transparent, competitive and fair manner, to
secure best value for money. This will also enable the prospective bidders to formulate and send
their competitive bids with confidence. Some of the measures for ensuring the above are as
follows:-(i)the text of the bidding document should be self-contained and comprehensive without
any ambiguities. All essential information, which a bidder needs for sending responsive bid, should
be clearly spelt out in the bidding document in simple language. The bidding document should
contain, inter alia;(a)the criteria for eligibility and qualifications to be met by the bidders such as
minimum level of experience, past performance, technical capability, manufacturing facilities and
financial position etc.;(b)eligibility criteria for goods indicating any legal restrictions or conditions
about the origin of goods etc which may require to be met by the successful bidder;(c)the procedure
as well as date, time and place for sending the bids;(d)date, time and place of opening of the
bid;(e)terms of delivery;(f)special terms affecting performance, if any.(ii)Suitable provision should
be kept in the bidding document to enable a bidder to question the bidding conditions, bidding
process and/or rejection of its bid.(iii)Suitable provision for settlement of disputes, if any,Bihar Financial Rules, 1950

emanating from the resultant contract, should be kept in the bidding document.(iv)The bidding
document should indicate clearly that the resultant contract will be interpreted under Indian
Laws.(v)The bidders should be given reasonable time to send their bids.(vi)The bids should be
opened in public and authorised representatives of the bidders should be permitted to attend the bid
opening.(vii)The specifications of the required goods should be clearly stated without any ambiguity
so that the prospective bidders can send meaningful bids. In order to attract sufficient number of
bidders, the specification should be general and broad based to the extent feasible. Efforts should
also be made to use standard specifications which are widely known to the industry.(viii)Pre-bid
conference : In case of turn-key contract(s) or contract(s) of special nature for procurement of
sophisticated and costly equipment, a suitable provision is to be kept in the bidding documents for a
pre-bid conference for clarifying issues and clearing doubts, if any, about the specifications and
other allied technical details of the plant, equipment and machinery projected in the bidding
document.The date, time and place of pre-bid conference should be indicated in the bidding
document.This date should be sufficiently ahead of bid opening date.(ix)Criteria for determining
responsiveness of bids, criteria as well as factors to be taken into account for evaluating the bids on a
common platfrom and the criteria for awarding the contract to the responsive lowest bidder should
be clearly indicated in the bidding documents.(x)Bids received should be evaluated in terms of the
conditions already incorporated in the bidding documents; no new condition which was not
incorporated in the bidding documents should be brought in for evaluation of the bids.
Determination of a bid's responsiveness should be based on the contents of the bid itself without
recourse to extrinsic evidence.(xi)Bidders should not be permitted to alter or modify their bids after
expiry of the deadline for receipt of bids.(xii)Negotiation with bidders after bid opening must be
severely discouraged. However, in exceptional circumstances where price negotiation against an
ad-hoc procurement is necessary due to some unavoidable circumstances, the same may be resorted
to only with the lowest evaluated responsive bidder.(xiii)In the rate contract system, where a
number of firms are brought on rate contract for the same item, negotiation as well as counter
offering of rates are permitted with the bidders in view and for this purpose special permission
should be given to the State Purchase Organisation.(xiv)Contract should ordinarily be awarded to
the lowest evaluated bidder whose bid has been found to be responsive and who is eligible and
qualified to perform the contract satisfactorily as per the terms and conditions incorporated in the
corresponding bidding document. However, where the lowest acceptable bidder against ad-hoc
requirement is not in a position to supply the full quantity required, the remaining quantity, as far
as possible, be ordered from the next higher responsive bidder at the rates offered by the lowest
responsive bidder.(xv)The name of the successful bidder awarded the contract should be mentioned
in the Departments Notice Board or Bulletin or website 66.
131S. Efficiency, Economy and Accountability in Public Procurement
System.
- Public procurement procedure is also to ensure efficiency, economy and accountability in the
system. To achieve the same, the following key areas should be addressed :-(i)To reduce delay,
appropriate time frame for each stage of procurement should be prescribed by the Department.
Such a time frame will also make the concerned purchase officials more alert.(ii)To minimise the
time needed for decision making and placement of contract, every Department, with the approval ofBihar Financial Rules, 1950

the competent authority, may delegate, wherever necessary, appropriate purchasing powers to the
lower functionaries.(iii)The Departments should ensure placement of contract within the original
validity of the bids. Extension of bid validity must be discouraged and resorted to only in exceptional
circumstances.(iv)The designated State Purchase Organisation(s) should bring into the rate contract
system more and more common user items which are frequently needed in bulk by various
Government Departments.The State Purchase Organisation should also ensure that the rate
contracts remain available without any break.
131T. Buy-Back Offer.
- When it is decided with the approval of the competent authority to replace an existing old item(s)
with a new and better version, the department may trade the existing old item while purchasing the
new one. For this purpose, a suitable clause is to be incorporated in the bidding document so that
the prospective and interested bidders formulate their bids accordingly. Depending on the value and
condition of the old item to be traded, the time as well as the mode of handing over the old item to
the successful bidder should be decided and relevant details in this regard suitably incorporated in
the bidding document. Further, suitable provision should also be kept in the bidding document to
enable the purchaser either to trade or not to trade the item.II. Procurement of Services
131U.
The Departments may hire external professionals, consultancy firms or consultants (referred to as
consultant hereinafter) for a specific job, which is well defined in terms of content and time frame
for its completion or outsource certain services.
131V.
This chapter contains the fundamental principles applicable to all Departments regarding
engagement of consultant(s) and outsourcing of services. Detailed instructions to this effect may be
issued by the concerned Ministries or Departments. However, the Departments shall ensure that
they do not contravene the basic rules contained in this chapter.
131W. Identification of Work/Services required to be performed by
Consultants.
- Engagement of consultants may be resorted to in situations requiring high quality services for
which the concerned Department does not have requisite expertise. Approval of the competent
authority should be obtained before engaging consultant(s).
131X. Preparation of scope of the required work/service.
- The Departments should prepare in simple and concise language the requirement, objectives and
the scope of the assignment. The eligibility and pre-qualification criteria to be met by theBihar Financial Rules, 1950

consultants should also be clearly identified at this stage.
131Y. Estimating reasonable expenditure.
- Department proposing to engage consultant(s) should estimate reasonable expenditure for the
same by ascertaining the prevalent market conditions and consulting other organisations engaged in
similar activities.
131Z. Identification of likely sources.
- (i) Where the estimated cost of the work or service is upto Rupees Twenty Five Lakhs, preparation
of a long list of potential consultants may be done on the basis of formal or informal enquiries from
other Departments or Organisations involved in similar activities, Chambers of Commerce &
Industry, Association of consultancy firms etc.(ii)Where the estimated cost of the work or service is
above Rupees Twenty Five Lakhs, in addition to (i) above, an enquiry for seeking 'Expression of
Interest' from consultants should be published in atleast one national daily and the Department's
website. The website address should also be given in the advertisements. Enquiry for seeking
Expression of Interest should include in brief, the broad scope of work or service, inputs to be
provided by the Department, eligibility and the pre-qualification criteria to be met by the
consultant(s) and consultant's past experience in similar work or service.The consultants may also
be asked to send their comments on the objectives and scope of the work or service projected in the
enquiry. Adequate time should be allowed for getting responses from interested consultants.
131ZA. Short listing of consultants.
- On the basis of responses received from the interested parties as per Rule 131Z above, consultants
meeting the requirements should be short listed for further consideration. The number of
shortlisted consultants should not be less than three.
131ZB. Preparation of Terms of Reference (TOR).
- The TOR should include:-(i)Precise statement of objectives;(ii)Outline of the tasks to be carried
out;(iii)Schedule for completion of tasks;(iv)The support or inputs to be provided by the
Department to facilitate the consultancy.(v)The final outputs that will be required of the Consultant;
131ZC. Preparation and Issue of Request for Proposal (RFP).
- RFP is the document to be used by the Department for obtaining offers from the consultants for
the required work/service. The RFP should be issued to the shortlisted consultants to seek their
technical and financial proposals. The RFP should contain :-(i)A letter of Invitation.(ii)Information
to Consultants regarding the procedure for submission of proposal.(iii)Terms of Reference
(TOR).(iv)Eligibility and pre-qualification criteria in case the same has not been ascertained
through Enquiry for Expression of Interest.(v)List of key position whose CV and experience wouldBihar Financial Rules, 1950

be evaluated.(vi)Bid evaluation criteria and selection procedure.(vii)Standard formats for technical
and financial proposal.(viii)Proposed contract terms.(ix)Procedure proposed to be followed for
midterm review of the progress of the work and review of the final draft report.
131ZD. Receipt and opening of proposals.
- Proposals should ordinarily be asked for, from consultants in 'Two-bid' system with technical and
financial bids sealed separately. The bidder should put these two sealed envelops in a bigger envelop
duly sealed and submit the same to the Department by the specified date and time at the specified
place. On receipt, the technical proposals should be opened first by the Department at the specified
date, time and place.
131ZE. Late Bids.
- Late bids i.e. bids received after the specified date and time of receipt, should not be considered.
131ZF. Evaluation of Technical Bids.
- Technical bids should be analysed and evaluated by a Consultancy Evaluation Committee (CEC)
constituted by the Department.The CEC shall record in detail the reasons for acceptance or rejection
of the technical proposals analysed and evaluated by it.
131ZG. [ Evaluation of Financial Bids of the technically qualified bidders. [In
Gazette dated 11.11.2005, there are two items having indentical numbering
viz. 131ZG but in Hindi Version of Gazette the said two have been numbered
separately, so they are being given for ready reference. - Ed.]
- The Department shall open the financial bids of only those bidders who have been declared
technically qualified by the Consultancy Evaluation Committee as per Rule 131ZF above for further
analysis or evaluation and ranking and selecting the successful bidder for placement of the
consultancy contract.
131ZG. Consultancy by nomination.
- Under some special circumstances, it may become necessary to select a particular consultant
where adequate justification is available for such single-source selection in the context of the overall
interest of the Department. Full justification for single source selection should be recorded in the file
and approval of the competent authority obtained before resorting to such single-source selection.]
131ZH. Monitoring the Contract.
- The Department should be involved throughout in the conduct of consultancy, preferably by takingBihar Financial Rules, 1950

a task force approach and continuously monitoring the performance of the consultant(s) so that the
output of the consultancy is in line with the Department's objectives.Outsourcing of Services
131ZI. Outsourcing of Services.
- A Department may outsource certain services in the interest of economy and efficiency and it may
prescribe detailed instructions and procedures for this purpose without, however, contravening the
following basic guidelines.
131ZJ. identification of likely contractors.
- The Departments should prepare a list of likely and potential contractors on the basis of formal or
informal enquiries from other Ministries or Departments and Organisations involved in similar
activities, scrutiny of 'Yellow pages', and trade journals, if available, website etc.
131ZK. Preparation of Tender enquiry.
- Department should prepare a tender enquiry containing, inter alia :-(i)The details of the work or
service to be performed by the contractor;(ii)The facilities and the inputs which will be provided to
the contractor by the Department;(iii)Eligibility and qualification criteria to be met by the
contractor for performing the required work/service; and(iv)the statutory and contractual
obligations to be complied with by the contractor.
131ZL. Invitation of Bids.
(a)For estimated value of the work or service upto Rupees ten lakhs or less ; The Department should
scrutinise the preliminary list of likely contractors as identified as per Rule 131ZJ above, decide the
prima facie eligible and capable contractors and issue limited tender enquiry to them asking for
their offers by a specified date and time etc. as per standard practice. The number of the contractors
so identified for issuing limited tender enquiry should not be less than six.(b)For estimated value of
the work or service above Rupees ten lakhs:The Department should issue advertised tender enquiry
asking for the offers by a specified date and time etc. in at least one popular largely circulated
national newspaper and website of the Department.
131ZM. Late Bids.
- Late bids i.e. bids received after the specified date and time of receipt, should not be considered.
131ZN. Evaluation of Bids Received.
- The Department should evaluate, segregate, rank the responsive bids and select the successful
bidder for placement of the contact.Bihar Financial Rules, 1950

131ZO. Outsourcing by Choice.
- Should it become necessary, in an exceptional situation to outsource a job to a specifically chosen
contractor, the Competent Authority in the Department may do so in consultation with the Internal
Financial Adviser. In such cases the detailed justification, the circumstances leading to the
outsourcing by choice and the special interest or purpose it shall serve shall form an integral part of
the proposal.
131ZP. Monitoring the Contract.
- The Department should be involved throughout in the conduct of the contract and continuously
monitor the performance of the contractor.[Inventory Management] [The title 'Receipts of stores'
has been Substituted by 'Inventory Management' vide Bihar Finance (Amdt.) Rules, 2005.]
132. [ [Substituted of Rules 132 to 153 by Rules 132 to 148 vide Bihar Finance
(Amdt.) Rules, 2005.]
This chapter contains the basic rules applicable to all Ministries or Departments regarding inventory
management. Detailed instructions and procedures relating to inventory management may be
prescribed by various Ministries or Departments broadly in conformity with the basic Rules
contained in this chapter.]
133. Receipt of goods and materials from private suppliers.
(1)While receiving goods and materials from a supplier, the Officer-ln-Charge of stores should refer
to the relevant contract terms and follow the prescribed procedure for receiving the materials.(2)All
materials shall be counted, measured or weighed and subjected to visual inspection at the time of
receipt to ensure that the quantities are correct, the quality is according to the required
specifications and there is no damage or deficiency in the materials. Technical inspection where
required should be carried out at this stage by Technical Inspector or Agency approved for the
purpose. An appropriate receipt, in terms of the relevant contract provisions may also be given to
the supplier on receiving the materials.(3)Details of the material so received should thereafter be
entered in the appropriate stock register. The Officer-ln-Charge of stores should certify that he has
actually received the material and recorded it in the appropriate stock registers.
134. Receipt/issue of goods and materials from internal divisions of the same
organisation.
(1)The indenting officer requiring goods and materials from internal division(s) of the same
organisation should project an indent in the prescribed form for this purpose. While receiving the
supply against the indent, the indenting officer shall examine, count, measure or weigh the
materials as the case may be, to ensure that the quantities are correct, the quality is in line with the
required specifications and there is no damage or deficiency in the materials. An appropriate receiptBihar Financial Rules, 1950

shall also be given to this effect by the indenting officer to the division sending the materials.(2)In
the case of issue of materials from stock for departmental use, manufacture, sale, etc., the
Officer-ln-Charge of the stores shall see that an appropriate indent, in the prescribed form has been
projected by the indenting officer. A written acknowledgement of receipt of material issued shall be
obtained from the indenting officer or his authorised representative at the time of issue of
materials.(3)In case of materials issued to a contractor, the cost of which is recoverable from the
contractor, all relevant particulars, including the recovery rates and the total value chargeable to the
contractor should be got acknowledged from the contractor duly signed and dated.(4)If the
Officer-ln-Charge of the stores is unable to comply with the indent in full, he should make the
supply to the extent available and make suitable entry to this effect in the indentor's copy of the
indent. In case alternative materials are available in lieu of the indented materials, a suitable
indication to this effect may be made in the document.
135. Custody of goods and materials.
- The Officer-ln-Charge of stores having custody of goods and materials, especially valuable and/or
combustible articles, shall take appropriate steps for arranging their safe custody, proper storage
accommodation, including arrangements for maintaining required temperature, dust free
environment etc.
136. Lists and Accounts.
(1)The Officer-ln-Charge of stores shall maintain suitable item wise lists and accounts and prepare
accurate returns in respect of the goods and materials in his charge making it possible at any point
of time to check the actual balances with the book balances.The form of the stock accounts
mentioned above shall be determined with reference to the nature of the goods and materials, the
frequency of the transactions and the special requirements of the concerned
Ministries/Departments.(2)Separate accounts shall be kept for:-(i)Fixed Assets such as plant,
machinery, equipment, furniture, fixtures etc. in the Form F.R. - 5A.(ii)Consumables such as office
stationery, chemicals, maintenance spare parts etc. in the Form F.R. - 5B.(iii)Library Books in the
Form F.R. 5C(iv)Assets of historical/artistic value held by museum/Government Departments in the
Form F.R. 5D.Note : These Forms can be supplemented with additional details by Departments as
required.
137. Hiring out of Fixed Assets.
- When a fixed asset is hired to local bodies, contractors or others, proper record should be kept of
the assets and the hire and other charges as determined under rules prescribed by the competent
authority, should be recovered regularly. Calculation of the charges to be recovered from the local
bodies, contractors and others as above should be based on the historical cost.Bihar Financial Rules, 1950

138. Physical verification of Fixed Assets.
(1)The inventory for fixed assets shall ordinarily be maintained at site. Fixed assets should be
verified at least once in a year and the outcome of the verification recorded in the corresponding
register. Discrepancies, if any, shall be promptly investigated and brought to account.(2)Verification
of Consumables : A physical verification of all the consumable goods and materials should be
undertaken at least once in a year and discrepancies, if any, should be recorded in the stock register
for appropriate action by the competent authority.(3)Procedure for verification : (i) Verification
shall always be made in the presence of the officer, responsible for the custody of the inventory
being verified.(ii)A certificate of verification alongwith the findings shall be recorded in the stock
register.(iii)Discrepancies, including shortages, damages and unserviceable goods, if any, identified
during verification, shall immediately be brought to the notice of the competent authority for taking
appropriate action in accordance with provision given in Rules 31 to 35.
139. Buffer Stock.
- Depending on the frequency of requirement and quantity thereof as well as the pattern of supply of
a consumable material, optimum buffer stock should be determined by the competent
authority.Note : As the inventory carrying cost is an expenditure that does not add value to the
material being stocked, a material remaining in stock for over a year shall generally be considered
surplus, unless adequate reasons to treat it otherwise exist.
140. Physical verification of Library books.
- (i) Complete physical verification of books should be done every year in case of libraries having not
more than twenty thousand volumes. For libraries having more than twenty thousand volumes and
upto fifty thousand volumes, such verification should be done at least once in three years. Sample
physical verification at intervals of not more than three years should be done in case of libraries
having more than fifty thousand volumes. In case such a verification reveals unusual or
unreasonable shortages, complete verification shall be done.(ii)Loss of five volumes per one
thousand volumes of books issued/consulted in a year may be taken as reasonable provided such
losses are not attributable to dishonesty or negligence. However, loss of a book of a value exceeding
Rs. 1,000/- (Rupees One thousand only) and rare books irrespective of value shall invariably be
investigated and appropriate action taken.
141. Transfer of charge of goods, materials etc.
- In case of transfer of Officer-in-Charge of the goods, materials etc., the transferred officer shall see
that the goods or material are made over correctly to his successor. A statement giving all relevant
details of the goods, materials etc., in question shall be prepared and signed with date by the
relieving officer and the relieved officer. Each of these officers will retain a copy of the signed
statement.Bihar Financial Rules, 1950

142. Disposal of Goods.
- (i) An item may be declared surplus or obsolete or unserviceable if the same is of no use to the
Department. The reasons for declaring the item surplus or obsolete or unserviceable should be
recorded by the authority competent to purchase the item.(ii)The competent authority may, at his
discretion, constitute a committee at appropriate level to declare item(s) as surplus or obsolete or
unserviceable.(iii)The book value, guiding price and reserved price, which will be required while
disposing of the surplus goods, should also be worked out. In case where it is not possible to work
out the book value, the original purchase price of the goods in question may be utilised. A report of
stores for disposal shall be prepared in Form F.R.-5E.(iv)In case an item becomes unserviceable due
to negligence, fraud or mischief on the part of a Government servant, responsibility for the same
should be fixed.
143. Modes of Disposal.
- (i) Surplus or obsolete or unserviceable goods of assessed residual value above Rupees Two Lakh
should be disposed of by :(a)obtaining bids through advertised tender or(b)public auction.(ii)For
surplus or obsolete or unserviceable goods with residual value less than Rupees Two Lakh, the mode
of disposal will be determined by the competent authority, keeping in view the necessity to avoid
accumulation of such goods and consequential blockage of space and, also, deterioration in value of
goods to be disposed of.(iii)Certain surplus or obsolete or unserviceable goods such as expired
medicines, food grain, ammunition etc., which are hazardous or unfit for human consumption,
should be disposed of or destroyed immediately by adopting suitable mode so as to avoid any health
hazard and/or environmental pollution and also the possibility of misuse of such goods.(iv)Surplus
or obsolete or unserviceable goods, equipment and documents, which involve security concerns (e.g.
currency, negotiable instruments, receipt books, stamps, security press etc.) should be disposed
of/destroyed in an appropriate manner to ensure compliance with rules relating to official secrets as
well as financial prudence.
144. Disposal through Advertised Tender.
- (i) The broad steps to be adopted for this purpose are as follows:-(a)Preparation of bidding
documents.(b)Invitation of tender for the surplus goods to be sold.(c)Opening of bids.(d)Analysis
and evaluation of bids received.(e)Selection of highest responsive bidder.(f)Collection of sale value
from the selected bidder.(g)Issue of sale release order to the selected bidder.(h)Release of the sold
surplus goods to the selected bidder.(i)Return of bid security to the unsuccessful bidders.(ii)The
important aspects to be kept in view while disposing the goods through advertised tender are as
under:-(a)The basic principle for sale of such goods through advertised tender is ensuring
transparency, competition, fairness and elimination of discretion. Wide publicity should be ensured
of the sale plan and the goods to be sold. All the required terms and conditions of sale are to be
incorporated in the bidding document comprehensively in plain and simple language. Applicability
of taxes, as relevant, should be clearly stated in the document.(b)The bidding document should also
indicate the location and present condition of the goods to be sold so that the bidders can inspect
the goods before bidding.(c)The bidders should be asked to furnish bid security along with theirBihar Financial Rules, 1950

bids. The amount of bid money should ordinarily be ten per cent of the assessed or reserved price of
the goods. The exact bid security amount should be indicated in the bidding document.(d)The bid of
the highest acceptable responsive bidder should normally be accepted. However, if the price offered
by that bidder is not acceptable, negotiation may be held only with that bidder. In case such
negotiation does not provide the desired result, the reasonable or acceptable price may be
counter-offered to the next highest responsive bidders(s).(e)In case the total quantity to be disposed
of cannot be taken up by the highest acceptable bidder, the remaining quantity may be offered to the
next higher bidder(s) at the price offered by the highest acceptable bidder.(f)Full payment, i.e. the
residual amount after adjusting the bid security should be obtained from the successful bidder
before releasing the goods.(g)In case the selected bidder does not show interest in lifting the goods,
the bid security should be forfeited and other actions initiated including re-sale of the goods in
question at the risk and cost of the defaulter, after obtaining legal advice.(iii)Late bids i.e. bids
received after the specified date and time of receipt should not to be considered.
145. Disposal through Auction.
- (i) A Department may undertake auction of goods to be disposed of either directly or through
approved auctioneers.(ii)The basic principles to be followed here are similar to those applicable for
disposal through advertised tender so as to ensure transparency, competition, fairness and
elimination of discretion. The auction plan including details of the goods to be auctioned and their
location, applicable terms and conditions of the sale etc. should be given wide publicity in the same
manner as is done in case of advertised tender.(iii)While starting the auction process, the condition
and location of the goods to be auctioned, applicable terms and conditions of sale etc., (as already
indicated earlier while giving vide publicity for the same), should be announced again for the benefit
of the assembled bidders.(iv)During the auction process, acceptance or rejection of a bid should be
announced immediately on the stroke of the hammer. If a bid is accepted, earnest money (not less
than twenty-five per cent, of the bid value) should immediately be taken on the spot from the
successful bidder either in cash or in the form of Deposit-at-Call-Receipt (DACR), drawn in favour
of the Department selling the goods. The goods should be handed over to the successful bidder only
after receiving the balance payment.(v)The composition of the auction team will be decided by the
competent authority. The team should however include an officer of the Internal Finance Wing of
the department.
146. Disposal at scrap value or by other modes.
- If a Department is unable to sell any surplus or obsolete or unserviceable item in spite of its
attempts through advertised tender or auction, it may dispose off the same at its scrap value with
the approval of the competent authority in consultation with Finance division. In case the
Department is unable to sell the item even at its scrap value, it may adopt any other mode of
disposal including destruction of the item in an eco-friendly manner.Bihar Financial Rules, 1950

147.
A sale account should be prepared for goods disposed of in Form F.R. 5F duly signed by the officer
who supervised the sale or auction.
148. Powers to write off.
(1)All profits and losses due to revaluation, stock-taking or other causes shall be duly recorded and
adjusted where necessary. Formal sanction of the competent authority shall be obtained in respect
of losses, even though no formal correction or adjustment in Government accounts is involved.
Power to write off, of losses are available under the Compendium of Financial Delegations.(2)Losses
due to depreciation : Losses due to depreciation shall be analyzed, and recorded under following
heads, as applicable :-(i)normal fluctuation of market prices;(ii)normal wear and tear;(iii)lack of
foresight in regulating purchases; and(iv)negligence after purchase.(3)Losses not due to
depreciation : Losses not due to depreciation shall be grouped under the following heads:-(i)losses
due to theft or fraud;(ii)losses due to neglect;(iii)anticipated losses on account of obsolescence of
stores or of purchases in excess of requirements;(iv)losses due to damage, and(v)losses due to extra
ordinary situations under Force Majeure conditions like fire, flood, enemy action, etc.,"[Editorial
Note. - As per Section 8 of the Bihar Finance (Amendment) Rules, 2005. Rules 132 to 153 of the Old
Rules stand substituted by the Amended Rules but text of Rules 149 to 153 is absent in the Amended
Rules, 2005. Therefore, Old Rules have been reproduced for the sake of record and ready reference.
- Ed.]Old Rule read as :
149.
(1)Losses due to depreciation should be analysed and recorded under following heads, according as
they are due to-(i)normal fluctuation of market prices;(ii)fair wear and tear;(iii)lack of foresight in
regulatinig purchases;(iv)neglect after purchase.(2)Losses not due to depreciation should be
grouped under the following heads:-(i)losses due to theft or fraud;(ii)losses due to neglect;(iii)losses
due to an act of God and other calamities such as fire, enemy action, etc.;(iv)anticipated losses on
account of surplusage of obsolete stores or of purchases in excess requirements;(v)other losses due
to damage, etc.Sale and Disposal of Stores and Writes Off of Stores
150.
The previous sanction of competent authority should be obtained to the writing off of all losses,
deficiencies or depreciation in the value of stores. (See Compendium of Financial Delegations.)
151.
Subject to any special Rules or orders applicable to any particular department, stores which are
reported to be obsolete, surplus or unserviceable may be disposed of by sale, or otherwise, under the
orders of the authority competent to sanction the writing off of a loss caused by deficiencies andBihar Financial Rules, 1950

depreciation equivalent to their value. (Vide Compendium of Financial Delegations.)Each order
declaring stores as unserviceable should record the full reason for condemning them and how the
condemned stores are to be disposed of i.e. whether by sale, public auction or otherwise. The head of
the office should record full particulars regarding all condemned stores in suitable lists from which
their disposal can be watched.ProformaForm A
Item
No.Particulars
of storesQuantity/weightBook
Value/Original
purchase priceCondition
and year of
purchaseMode of disposal
(Sale, public
auction
orotherwise)Remarks
1 2 3 4 5 6 7
 SignatureDesignationDate
Form B
Item
No.Particulars
of StoresQuantity
weightName &
full address
of
purchasersHighest
bid
acceptedHighest
bid
rejectedE.M.
Realised
on the
spotDate on
which the
complete
amount
is
realised
&credited
into
treasury.Whether
the articles
were
actually
handed
over onthe
spot. If
not, the
actual date
of handing
over of the
articleswith
quantities.Auctioner's
commission and
acknowledgement
forits payment
1 2 3 4 5 6 7 8 9 10
 SignatureDesignationDate
152.
Sales to private persons of stores other than those which are found to have become obsolete or
unserviceable are regulated by special rules and orders applicable to particular departments. When
stock materials are sold to the public or any other department or authority at their full value, a
suitable percentage as determined by competent authority should be added to the book value to
cover charges on account of supervision, storage and contingencies. This addition may, however, be
waived by the Government servant empowered to sanction the sale in the case of surplus stock
which in his opinion would otherwise be unsaleable.Opium Stock in the Custody of Treasury
Officers
153.
The opium in store must be kept in the treasury strong room and not elsewhere and all receipts into
and issues from stock should be entered in a store register maintained for the purpose over theBihar Financial Rules, 1950

initials of the Treasury Officer. The Treasury Officer should give out opium to the treasurer as
required for sale to the public, an account of opium so issued to and sold by him being kept by the
treasurer in a sub-register in suitable form to be determined by the Treasury Officer. The Treasury
Officer should see that all issues to the treasurer are entered up in the register and the proceeds of
opium sold are duly credited into the treasury account. The balance of opium in the hands of the
treasurer should be checked by the Treasury Officer at least once every month. No more opium
should be issued to the treasurer than is necessary to meet current demands.Section IIISpecial
Rules for the Public Works DepartmentI - GeneralStores
154.
The stores of the Public Works Department are divided into the following classes, viz., (i) Stock or
general stores, (ii) Tools and Plant, (iii) Road metal and (iv) Material charged direct to works.
Unless there are orders to the contrary, the Officer In Charge of a sub-division will be responsible
for all the stores belonging to it.
155.
The Divisional Officer is responsible that proper arrangements are made throughout his division for
the custody of public property. He must be careful to keep all tools and implements in efficient
order, protect surplus stock from deterioration, and take proper precaution to prevent the loss of
public stores by fire.
156.
Every officer is bound to take charge of departmental stores, which from the death or departure of
the person lately in charge, or from any other cause, may be left at or near, his station without
adequate protection.II - Acquisition of Stores(i)Stores (other than Tools and Plants)
157.
Stock, road metal and other materials (not being articles of European manufacture which must be
indented for in England) required in ordinary course for the execution of sanctioned works, may be
procured on the responsibility of the Divisional Officer without special authority, though the
Superintending Engineer's approval should be obtained to the measures proposed for the purchase
of stock in large quantities. If the stores are to be manufactured, a separate estimate for their
preparation may be required, as laid down in Rule 160 et seq.(ii)Tools and Plant
158.
The articles comprised under the head "Tools and Plant" can only be purchased or manufactured on
estimate sanctioned by competent authority with the exception of purchases or manufactures not
exceeding Rs. 500, for which estimates are not required.Bihar Financial Rules, 1950

159.
The general rules for the supply of articles required for the public service, whether of indigenous
origin or otherwise will be found in the Store Rules in Appendix 8. The restrictions imposed by the
Store Rules, do not apply to purchases made by, or on behalf of, municipalities, or local funds,
except when the stores purchased are paid for from Government revenue on behalf of Government
or from funds advanced by Government; in the latter circumstances Government may however,
direct that the provisions of the Store Rules need not apply. When a Public Works Department
officer carries out a work for any of the local bodies referred to above, the rules shall apply except
when the local body specially desires to have the stores purchased otherwise, with approval of the
State Government. It should, however, be stipulated that the stores must be approved by the officer
carrying out the work, before the purchase is concluded.
160.
The manufacture or collection of material involving an outlay of Rs. 10,000 or upwards must, in all
cases, be covered by an estimate showing the proposed outlay and the material to be received.
161.
If the material be for a work already duly sanctioned, or for reserve stock within sanctioned limit for
the division, the estimate will merely require the approval of the Superintending Engineer but in all
other cases the estimate must be duly sanctioned by competent authority, as though for an original
work.III - Reserve of Stock
162.
Reserve of stock will only be maintained when necessitated by the remoteness of the division or
works from the market or source of supply or for use in emergency. When it is considered necessary
that a reserve should be maintained, the maximum limit will be fixed by the Chief Engineer.
Divisional Officers are empowered to purchase or manufacture stores to maintain the reserve,
subject to the approval or sanction to estimate, vide Rules 160 and 161.
163.
The fixed maximum should be kept at the lowest point compatible with efficiency, and the stock
returns of divisions should be scrutinized carefully by Superintending Engineers from time to time
with reference to this point.Stock
164.
The stock of a division is sometimes kept in a single godown or yard in charge of a store keeper or
other officer, or each Sub-divisional Officer may have a separate stock in his charge, either at hisBihar Financial Rules, 1950

headquarters or scattered over the subdivision in the direct custody of sub-ordinates or other
sectional officers. Again, the stock although scattered over the entire division may be in the general
charge of a single official, and the Sub-divisional Officers may merely indent upon him, while he
keeps all the accounts. The stock account should be kept in accordance with the rules detailed below
whatever be the arrangement in force in the division.Quantity Accounts(a)Receipts
165.
Materials may be received on stock from the following sources :-(a)Suppliers;(b)Stores Department,
London;(c)Other sub-divisions, divisions or departments (including Government
workshops);(d)Manufacture; and(e)Works, buildings, etc.In all cases there should be proper
authority for the receipt by the storekeeper or the sectional officer concerned or materials to be
brought on stock. The authority should be given in writing by the Divisional Officer (or if so
authorised under local orders, by the Sub-divisional Officer).
166.
All materials received should be examined and counted, or measured as the case may be, when
delivery is taken. Any certificate that the storekeeper or sectional officer concerned may be called
upon to record in respect of the receipt of stores, giving an acknowledgement to a supplier or for any
other purposes, should be in the following form.Received on..............and recorded duly in the
register of stock receipts. See also page .............. of measurement book no ............ Date
............(Signature)(b)Issues
167.
Materials may be issued from stock for the following purposes. -(a)for use on works either by issue
to contractor or direct (vide Rule 284);(b)for despatch to other sub-divisions, divisions or
departments;(c)for sale to contractors, employees, other persons or local bodies.They should be
issued only on receipt of an indent in F.R. Form 5 signed by the Divisional or the Sub-divisional
Officer. But when a sectional officer has to issue stock materials for the requirements of works under
himself, the use of this form is not obligatory, if the sectional officer has been authorized under local
orders to draw such materials from his stock up to any assigned limit not exceeding the provision
made for materials in sanctioned estimates.(1)When examining registers of stock issues and works
abstracts, Sub-divisional Officers should see that in practice this rule is observed strictly and they
should deal suitably with instances of unauthorised and excessive issues to works made by sectional
officers without due cause.(2)The term "work" includes manufacture operations.
168.
When issuing materials from stock, the stock-keeper or sectional officer should examine the indent
and sign it after making suitable alterations under his dated initials, in the description and
quantities of materials, if he is unable to comply with the indent in full. He should then prepare andBihar Financial Rules, 1950

sign the form of the invoice attached to the indent, according to the supply as actually made. The
indent should then be returned at once to the indenting officer for signature on the invoice
portion.It should be seen that the acknowledgement of materials is signed by the person to whom
they are ordered to be delivered or despatched, or by a duly authorized agent. This applies also to
issues made to contractors and private persons.
169.
Ordinarily all transactions of receipts and issues should be recorded strictly in accordance with the
rules in the order of occurrence and as soon as they take place, but, as an exception to this rule the
issues of petty stores by a sectional officer direct to works under his supervision may be shown in
the accounts collectively once a month, when closing the accounts of the month.Value
Accounts(a)Payment for stock received
170.
Bills of supplies should, before payment, be examined and dealt with in the manner prescribed in
Rules 413 to 422 of the Bihar Treasury Code.Special attention is invited to Rule 274, the object of
which is to prevent erroneous or double claims being put forward successfully. Store-keepers and
sectional officers may, if desired, be required to verify supplier's bills before payment (Vide Rule
166), but the disbursing officer is responsible that no payment is made unless the precautions
referred to above have been observed.
171.
Cash payment should not be made for stock received from other sources, except in accordance with
the Rules in the Bihar Treasury Code, Appendix 16. When under those rules payment for supplies
made by any department is made in cash, the claims of such department should be dealt with in the
same way as those of suppliers.Issue Rates(b)Recoveries for stock issued
172.
(i)An issue rate is assigned to each new article as it is brought to stock. This rate is fixed on the
principle that the cost to be charged to works on which the materials are to be used should
approximately be equal the actual cost of the stores and that there may be no ultimate profit or loss
in the stock accounts. It should provide, beyond the original price paid and the cost of carriage, etc.,
for-(1)the expenditure on work charged establishment employed on handling and keeping the initial
accounts;(2)the expenditure on the custody of stock.(3)the expenditure on the maintenance of the
store, godown or yards and(4)loss from depreciation or wastage, but should in no case be in excess
of the market rate.(ii)It is not necessary that the issue for an item should be the same in all
subdivisions but an uniform rate should ordinarily be prescribed for all localities in a
subdivision.(iii)The issue rate should be worked out to the nearest *anna, as far as possible, [*now
five paise],Bihar Financial Rules, 1950

173.
As purchases are made, or contracts for the supply of materials are entered into, variations in cost
should be watched, and if these are appreciable, issue rates may, and in important cases, shall, at
once be raised or lowered, as may be necessary. Further when closing the half-yearly register of
stock, all rates must be reviewed and revised, if necessary, to bring them within the market rates.
174.
If the issue rate, of an article of stock is appreciably less than the market rate, the following
precautions should be taken, in addition to any restrictions on sales or on issues outside the division
which the Divisional Officer may prescribe :-(a)Issues to contractors and sales shall be made at
market rates (See Rules 285 and 286.)(b)Issues to other divisions and departments may be made at
a rate higher than the issue rate.Mode of Recovery
175.
(a)The Sub-divisional Officer is responsible that the value of materials sold to municipalities, local
funds, and the public and of issues made to contractors for private use, is recovered in cash at the
earliest opportunity.(b)The Sub-divisional Officer is also responsible for the clearance, from works
accounts of all outstandings against contractors on account of the recoverable value of materials
issued to them by charge to work.(c)The 10 percent supervision charges should be realized in
addition to the value of stock, in all cases in which it is recoverable under Rule 176 (see also Rule
174).
176.
When stock materials are sold to the public or other departments (including State Railways) or are
issued on account of any work executed for them in workshop at their full value, an addition of 10
per cent must be made to cover charges on account of supervision, storage and contingencies. This
addition may however be waived by the officer empowered to sanction the sale in the case of surplus
stock which in his opinion, would otherwise be unsaleable (see also Rule 174).Fictitious Adjustments
177.
Fictitious store adjustment are strictly prohibited, such, for example as (1) the debiting to a work of
the cost of materials not required, or in excess of actual requirements, (2) the debiting to a
particular work, for which funds are available of the value of materials intended to be utilised on
another work for which no funds are available, (3) the writing back of the value of materials used on
a work to avoid excess outlay over appropriation, etc. Any breach of this rule constitutes a serious
irregularity which will be brought promptly to the notice of the State Government by the Accountant
General.Half-Yearly Register of StockBihar Financial Rules, 1950

178.
A person other than a ministerial sub-ordinate should, under the orders of the Divisional Officer, fill
up column 24 (market rates) of the half yearly register of stock at or about the close of the half-year.
179.
(1)On completion of the half-yearly register of stock the Divisional Officer should review the register
and record his remark and orders.(2)The review should be directed to see especially that stores are
priced in accordance with the rules, that stock is taken periodically by responsible officer and that
stock of individual items are regulated on consideration of actual requirements of the near future
and with due regard to the average consumption of the past. The object to secure is that the stock on
the register shall consist only of efficient and necessary articles priced within the rates at which they
could be purchased at the time.(3)The maintenance, closing and review of the stock register on a
yearly, instead of half-yearly basis, is sometimes permitted under special order of the State
Government in consultation with the Accountant General. Important revisions of issue rates which
may be necessitated by fluctuation of cost should however, be made at once and not deferred till the
close of the year.Stock Taking
180.
Divisional Officers should have stock-taking throughout their divisions at least once a year.
Important stores should, as a rule be counted by a member of the engineer establishment, but this
duty may be entrusted to a subordinate holding charge of a sub-division.The Superintending
Engineer when he thinks proper, may depute an officer from one division to aid in the stock-taking
of another. Whenever it is possible, verification should be entrusted to Government servant
independent of, and unconnected with the staff responsible for the custody of the stores; it should
also include a certain amount of surprise check.
181.
It is not necessary that all the stores of a division, or even of a subdivision should be checked and
counted at the same time; and the stock taking may be arranged so as to go on gradually in the
manner most convenient. When the stock of an article are scattered in a sub-division it may not be
possible to test the aggregate book-balance of any article for the sub-division by an actual
verification of all the stocks of it at the same time. In such cases, the various stocks of each article in
charge of a sectional officer should as far as possible, be verified at or about the same time.
182.
The procedure of verification outlined in the foregoing rules is suitable primarily for division
executing ordinary works. In the cases of special stores, depots or divisions or of construction
divisions, where there may be a large concentration of stores, a continuous and periodicalBihar Financial Rules, 1950

verification of stores by an officer of the Audit Department should be arranged for, whenever
possible, in consultation with the Accountant General.
183.
The results of all verifications of stock should be reported to the Divisional Officer for orders, but as
soon as a discrepancy is noticed, the book balance must be set right by the verifying officer with a
suitable remark.Tools and PlantNumerical account - receipts
184.
All articles of tools and plant received should be examined and counted when delivery is
taken.Payments For Supplies
185.
Payment for tools and plant received from suppliers and other sources should be made generally in
the manner prescribed for stock receipts. But when the Mathematical Instrument Department is
unable to supply any instruments indented for and arranges for their purchase the supplier's will, if
that department so desires, be paid in cash or by a remittance transfer receipt.Recoveries(a)For use
of tools and plant.-
186.
When tools and plant are lent to local bodies, contractors or others, the hire and other charges
should be determined by local rules, and should be recovered regularly.Note. - The rules framed by
the State Government under this rule are given in F.R. Appendix 6.(b)For Sale and Transfer.-
187.
The Sub-divisional Officer is responsible that, when tools and plants are disposed by sale or
otherwise, with the sanction of competent authority, the amount recoverable from the parties
concerned is realized at the earliest opportunities.Verification
188.
The rule regarding verification of stock applies also to verification of tools and plant, except that
when any articles are found deficient, a note of the deficiency should only be made in the account of
issues, without any correction of the book balance.Road MetalBihar Financial Rules, 1950

189.
Supplies of road metal should be measured and paid for in the same way as supplies of other
materials for works.
190.
The verification of road metal should be measured generally on the lines of the verification of
materials charged to works (vide Rule 294).
of Rates
191.
A rate book or schedule of rates, showing the lowest rate at which metal can be supplied to the
road-side through the division, should be kept in the divisional office in F.R. Form 6 with such
modification as may be considered necessary to suit local conditions. The rates should be revised,
from time to time, as old quarries are exhausted or new ones opened, or as other circumstances
affect the rates.Section IVPrevention of unnecessary Accumulation of Stock and Tools and Plant in
Public Works and Public Health Engineering DepartmentOriginal Works
192.
(1)No materials shall be obtained for original works except to the extent necessary for each
particular work. A strict observance of this principle should not render any materials surplus after
the completion of work, should, however, for exceptional reasons, materials be found surplus on the
completion of a work statement of serviceable and unserviceable materials should be prepared by
the Executive Engineer and submitted with a full explanation of the causes leading to the surplus to
the Superintending Engineer.(2)If the whole or any part of the serviceable materials are considered
likely to be of any use within one year for any work whether original or repairs, they should with the
approval of the Superintending Engineer be brought on to stock.(3)The rest of the materials which
are not likely to be of any use within one year shall, if they can be disposed of at not less than their
full value, be disposed of forthwith by the Executive Engineer. If, however, they cannot be disposed
of at full value enquiries shall be made from other Executive Engineers in the same circle and from
the Superintending Engineers of other circles as to whether any of the materials are likely to be
required by the Executive Engineers under them within one year. If they are not so required the
materials may be sold at less than their full value by calling for sealed tenders or by public auction,
with the previous sanction of the Superintending Engineer. The gain or loss, as the case may be,
shall be credited or charged to work.(4)In order to see that serviceable materials taken to stock are
utilised on work at the earliest possible dates, provision should be made in future contracts for the
supply of all available materials from stock in accordance with Rule 285.Note. - The expression "full
value" occurring in the above rule shall be taken to include railway freight, storing charges,
etc.Dismantled MaterialsBihar Financial Rules, 1950

193.
When any Public Works Department building is dismantled or partially dismantled, serviceable
materials which it may be possible to utilise within one year shall, with the approval of the
Superintending Engineer, be brought on to stock and utilised in the manner indicated in Rule 192(1)
above. Unserviceable materials shall not be brought to stock. If the value of such materials as
estimated by the Executive Engineer after dismantlement be not more than Rs. 1,000 they should be
disposed of immediately by the Executive Engineer by selling them by public auction. Otherwise the
Superintending Engineer's prior sanction to their disposal must be obtained.Repairs
194.
Materials required for maintenance and repairs to works shall be indented for by the Sub-divisional
Officers to the extent that can be consumed within a year. Executive Engineers will be held
personally responsible for the strict observance of this rule, unless such materials can be straightway
made over for specific repair works, they should be brought on to stock.Unused Stock
195.
When submitting his second half-yearly return of stock the Sub-divisional Officer shall submit a list
of items for which there have been no transactions for the last two years. The Executive Engineer
shall obtain the orders of the Superintending Engineer as to the disposal of such materials. The
Superintending Engineer should make every attempt to obtain the utilisation of the stock by other
Executive Engineers in his own or other circles and if they cannot be so disposed of order them to be
sold.Tools and Plant
196.
When submitting their annual return of tools and plant the Sub-divisional Officers shall submit a
list of all tools that have not been used for two years and of plant that has not been used for three
years and the Executive Engineer shall obtain the orders of the Superintending Engineer regarding
their disposal. The Superintending Engineer shall ascertain whether these tools and plant are
required in any other circles and if not sanction their sale by calling for sealed tenders or by public
auction (with reserve price) whichever is more likely to obtain the better price. In case where either
method is unlikely to fetch a good price; a private sale may be accepted with previous permission of
the Superintending Engineer, who will satisfy himself as to the adequacy of the offer before
according his permission.Before any new tools and plant are indented for by any Executive
Engineer, he must ascertain from the Superintending Engineer whether they can be made available
from other circle.Powers of SanctionBihar Financial Rules, 1950

197.
(a)(i)The Superintending Engineer shall have full power to dispose of all unserviceable stores
including stock and tools and plant materials at site of work, materials received from works
dismantled or undergoing repairs and to sanction their write off wherever necessary.(ii)The
Superintending Engineer shall have full power to sanction write off of the irrecoverable value of
unserviceable stores mentioned in item (i) above.(b)(i)The Superintending Engineer shall have
power to dispose of surplus stores including stock and tools and plant materials at site of work the
book value of which is up to Rs. 5,000 in each case. In the case of tools and plant where the book
value cannot be ascertained the estimated value should be taken into account.(ii)The
Superintending Engineer shall have power to sanction the write off of the loss from the book value
of surplus stores mentioned in item (i) above up to Rs. 1.000 in each case.(iii)In all other cases
where the book value of surplus materials exceeds Rs. 5.000 the Superintending Engineer shall
obtain the sanction of the Chief Engineer before the sale of surplus materials is undertaken and in
such cases the Superintending Engineer shall have power to write off the irrecoverable loss if it does
not exceed 20 per sent of the book or estimated value, otherwise, sanction of the Chief Engineer
should be obtained.(c)The Superintending Engineer shall have full power to sanction estimates for
losses due to depreciation of stock or due to reduction in the rates of prices of stock or due to
disposal of all unserviceable stores, etc., up to Rs. 10,000.(d)The Superintending Engineer has
power to sanction the write off of the irrecoverable value of stores lost by fraud or the negligence of
individuals or other causes up to Rs. 500. (See also Compendium of Financial Delegations).Note. -
[* * *] [Deleted by C.S. No. 20 dated 30.1.1959.]Audit of Stores and Stock Accounts
198.
When audit of the accounts of stores and stock kept in any office or department is undertaken by the
Comptroller and Auditor General, it will be conducted in accordance with the regulation embodied
in Appendix 3.
Chapter 9
Works
Section IIntroductory
199. [ [Substituted of Rules 199 to 322 by Rules 199 to 210 vide Bihar Finance
(Amdt.) Rules, 2005.]
Original works means all new constructions, additions and alterations to existing works, special
repairs to newly purchased or previously abandoned buildings or structures, including remodeling
or replacement.Repair works means works undertaken to maintain building and fixtures.]Bihar Financial Rules, 1950

200. Administrative control of works includes.
- (i) assumption of full responsibility for construction, maintenance and upkeep;(ii)proper
utilization of buildings ard allied works;(iii)provision of funds for execution of these functions.
201. Powers to sanction works.
- The powers delegated to various subordinate authorities to accord administrative approval,
sanction expenditure and re-appropriate funds for works are regulated by the Compendium of
Financial Delegation and other orders contained in the respective departmental regulations.
202.
(1)A Ministry or Department at its discretion may directly execute repair works estimated to cost
upto Rupees Ten Lakhs after following due procedure indicated in Rule 208.(2)A Ministry or
Department may, at its discretion, assign repair works estimated to cost above Rupees Ten Lakhs
and upto Rupees Thirty Lakhs to any Public Works Organisation, which includes State Public Works
Divisions, other Central Government Organisations authorised to carry out civil or electrical works
such as Central Public Works Department (CPWD), Military Engineering Service (MES), Border
Roads Organisation etc. or Public Sector Undertakings set up by the Central or State Government to
carry out civil or electrical works.(3)All original works costing upto Rupees Ten Lakhs may be
assigned by the Ministry or Department concerned to a Public Works. Organisations as defined in
Rule 202(2).(4)All original works estimated to cost above Rupees Ten Lakhs and repair works
estimated to cost above Rupees Thirty Lakhs may be got executed through a Public Works
Organisations as defined in Rule 202(2) after consultation with the Building Construction
Department.
203. Work under the administrative control of the Public Works Departments.
- Works not specifically allotted to any Ministry or Department shall be included in the Grants for
Civil Works to be administered by Building Construction Department. No such work may be
financed partly from funds provided in departmental budget and partly from the budget for Civil
works as mentioned above.
204. General Rules.
- Subject to the observance of these general rules, the initiation, authorization and execution of
works allotted to a particular Ministry or Department shall be regulated by detailed rules and orders
contained in the respective departmental regulations and by other special orders applicable to them.Bihar Financial Rules, 1950

205.
(1)No works shall be commenced or liability incurred in connection with it until:-(i)administrative
approval has been obtained from the appropriate authority in each case;(ii)sanction to incur
expenditure has been obtained from the competent authority;(iii)a properly detailed design has
been sanctioned;(iv)estimates containing the detailed specifications and quantities of various items
have been prepared on the basis of the Schedule of Rates maintained by PWD or other Public Works
Organisations and sanctioned;(v)funds to cover the charge during the year have been provided by
competent authoruty;(vi)tenders invited and processed in accordance with rules;(vii)a Work Order
issued.(2)On grounds of urgency or otherwise, if it becomes necessary to carry out a work or incur a
liability under circumstances when the provisions set out under sub-rule 1 of Rule 205 cannot be
complied with, the concerned executive officer may do so on his own judgment and
responsibility.Simultaneously, he should initiate action to obtain approval from the competent
authority and also to initiate the concerned Accounts Officer.(3)Any development of a project
considered necessary while a work is in progress, which is not contingent on the execution of work
as first sanctioned, shall have to be covered by a supplementary estimate.
206.
For purpose of approval and sanctions, a group of works which forms one project, shall be
considered as one work. The necessity for obtaining approval or sanction of higher authority to a
project which consists of such a group of work should not be avoided because of the fact that the cost
of each particular work in the project is within the powers of such approval or sanction of a lower
authority. This provision, however, shall not apply in case of works of similar nature which are
independent of each other.
207.
Any anticipated or actual savings from a sanctioned estimate for a definite project, shall not, without
special authority, be applied to carry out additional work not contemplated in the original project.
208. Procedure for Execution of Works.
- The broad procedure to be followed by a Department for execution of works under its own
arrangements shall be as under:-(i)the detailed procedure relating to expenditure on such works
shall be prescribed by departmental regulations framed in consultation with the Finance
Department, generally based on the procedures and the principles underlying the financial and
accounting rules prescribed for similar works carried out by the Public Works Department
(PWD);(ii)preparation of detailed design and estimates shall precede any sanction for works;(iii)no
work shall be undertaken before Issue of Administrative Approval and expenditure Sanction by the
Competent Authority on the basis of estimates framed;(iv)open tenders will be called for works
costing Rupees Five Lakhs to Rupees Ten Lakhs;(v)limited tenders will be called for works costing
less than Rupees Five Lakhs;(vi)execution of Contract Agreement or Award of work should be doneBihar Financial Rules, 1950

before commencement of the work;(vii)final payment for work shall be made only on the personal
certificate of the Officer-In-Charge of execution of the work in the format given below:"I Executing
Officer of (Name of the Work), am personally satisfied that the work has been executed as per the
specifications laid down in the Contract, Agreement and the workmanship is upto the standards
followed in the Industry."
209.
For original works and repair works entrusted to a 'Public Works Organisation' as defined in Rule
202(2), the administrative approval and expenditure sanction shall be accorded and funds allotted
by the concerned authority under these Rules and in accordance with the Compendium of Financial
Delegation. The Public Works Organisation shall then execute the work entrusted to it in accordance
with the rules and procedures prescribed in that organisation.
210. Review of Projects.
- After a project costing Rupees Ten Crores or above is approved, the Administrative Ministry or
Department will set up a Review Committee consisting of a representative each from the
Administrative Ministry, Finance (Internal Financial Advisor) and the Executing Agency to review
the progress of the work. The Review Committee shall have the powers to accept variation within
10% of the approved estimates. For works costing less that Rupees Ten Crores, it will be at the
discretion of the Administrative Department to set up a Review Committee on the above
lines.[Editorial Note. - Section 9 of the Bihar Finance (Amendment) Rules, 2005 although states
that "Rules 199 to 322 of the Bihar Finance Rules will be substituted by the following Rules" but
practically, only new Rules up to 210 are present. Under the abovementioned circumstances Old
Rules beginning from Rule 211 and ending at Rule 322 have been given under their suitable
headings and chapters for the sake of record and ready reference. - Ed.]Old Rule read as :Section
IVSpecial Rules for Sanitary, Water Supply and Electric Installation to Government Buildings, etc.
211.
Except as otherwise provided in this or any other rule or as ordered by Government in special cases,
all works and repairs in connection with sanitary, water supply and electric installations to
Government buildings should be carried out by or through the agency of the Public Works
Department.Note. - The rule relating to the provision of these installations in Government buildings
occupied as residents are laid down in Rules 129-131 of the Bihar Service Code.
212.
Civil Officers may incur expenditure in connection with these installations where it does not exceed
Rs. 2,500. Such expenditure may be charged as contingent expenditure of the department carrying
out the work. (See also Rule 400, Bihar Treasury Code).Section VMiscellaneous RulesBihar Financial Rules, 1950

213.
In respect of buildings available for occupation as residences, capital and revenue account are
prepared periodically by the Accountant General in accordance with the directions given in the
Account Code, Volume IV and any further orders that Government may issue in this behalf. All
officers concerned should furnish the Accountant-General annually with the necessary data in
respect of such building in such form as may be prescribed by the Accountant-General.
214.
Government may sanction expenditure on ceremonies connected with the inauguration of important
public works, e.g. the laying of foundation stones of public buildings, the opening of canals, the
opening of bridges other than those constructed from railway funds, etc.Note. - The expenditure on
such functions should be limited to the minimum absolute necessary and the Finance Department
should be afforded full justification for any such contemplated outlay before any commitments are
entered into with regard to it.
215.
The preparatory stages of a major work may take anything from three months to a year and
attempts to expedite the execution of works contrary to code rules lead to bad estimating and
computing and, to actual losses of money. These unfortunate results have been commented upon
adversely by the Public Accounts Committee on various occasions, and is desirable that the tendency
to rush the preparatory stages for works should be checked. The Chief Engineer and his subordinate
officers should accordingly take, in all cases, such time as is considered necessary, for the
preparation of proper estimates, the grant of technical sanction, and the invitation and examination
of tenders and refrain from entertaining requests from administrative departments for special
treatment. In emergent cases, however, where circumstances warrant a departure from methods
laid down by the Codes, the Public Works Department may issue special instructions on a reference
received from the administrative department concerned (See also Rule 247).Section VISpecial Rules
for the Forest Departments
216.
When a work or supply is of sufficient magnitude, a contract should be made on a written agreement
duly stamped and registered, so that it can be maintained in a court of law in the event of
dispute.Measurements
217.
Work done otherwise than on a lump sum contract, and supplies made by a contractor, should,
unless impracticable be measured (weighed or counted) before payment therefore, is made. The
details of the measurement made should be systematically recorded in a book called measurementBihar Financial Rules, 1950

book, which will form the basis of all accounts of quantities. The description of the work or supply
must be lucid so as to admit of easy identification and check.The pages of the book should be
machine numbered, and no page may be torn out nor may any entry be erased or effaced so as to be
illegible. All corrections must be duly attested by a responsible Government servant.
218.
A reference to the vouchers in which the quantities are entered for payments, as well as the date of
entry, should be given by an endorsement upon the original entries in the measurement book, and
no contract certificate or bill should be signed without thus crossing of the connected entry in the
measurement book.The document in which payment is made should invariably bear a reference to
the number and page of the book in which the detail measurements are recorded.Record of Sanction
and Expenditure
219.
Works requiring sanction of an authority higher than the Divisional Officer cannot ordinarily be
commenced until the sanction has been accorded. All such sanction will be numbered consecutively
by the Conservator of Forests for each financial year, and they will be communicated by him to the
Accountant General in monthly lists.
220.
When a sanctioned work is completed all outstanding liabilities should be discharged as soon as
possible, and the accounts of the work should be closed. A completion report showing the amounts
sanctioned and actually expended in the same details as in the monthly accounts, should then be
submitted through the Accountant General to the Conservator, who should forward it to
Government if the work was sanctioned by the State Government.Section VIISpecial Rules for the
Public Works Department Financial Responsibilities of the Officers
221.
(a)The Chief Engineers, Public Works Department (Road and Buildings), Public Health Engineering
Department and Irrigation and Electricity Department will-(1)exercise a concurrent control, with
the Accountant General, over the duties of the officers of the department in maintaining accounts,
and give legitimate support to the Accountant General in enforcing strict attention to the rules
concerning the disbursement of any money, the custody of stores, and submission of
accounts;(2)see that the budget appropriation of the year are fully expended in so far as is consistent
with general economy and the prevention of large expenditure in the closing months of the year for
the sole purpose of avoiding lapses; and(3)be responsible for ensuring that any money which is not
likely to be needed during the year is promptly surrendered so as to allow of its appropriation for
other purpose by the proper authority.(b)The Superintending Engineer is responsible for the
maintenance of authorised system of accounts throughout his circle. He should see that theBihar Financial Rules, 1950

Divisional Officers submit their accounts to the Accountant General punctually. He should examine
the books of the Executive Engineers and their subordinates, and see that the matters relating to the
primary accounts are attended to personally by Divisional and Sub-divisional Officers, and that the
accounts fairly represented the progress of each work. It will also be his duty to examine the
registers of works, so as to keep a vigilant watch over the rates of work, and, if he considers it
necessary, he may require an Executive Engineer to report to him monthly, or at longer intervals on
a works slip, the total expenditure to date under each sub-head of work in contrast with the
sanctioned estimate. He will also-(1)see that different articles in stock are duly verified according to
the rules laid down, and there is no accumulation of stock in any division beyond its
requirements;(2)see that no delay is allowed to occur in the submission of completion
reports;(3)forward for the information of the Chief Engineer reports of his inspections of divisional
offices, detailing therein the results of his examination of initial accounts, accounts of stock, tools
and plant and stock manufacture, register of works and other divisional book, mode of preparation
of estimates, contract agreements, contractors' accounts, system of recording plans and papers, and
office work generally;(4)see that the authorised system of account is maintained throughout his
circle;(5)examine the books of Divisional Officers and their sub-ordinates, and see that matters
relating to the primary accounts are attended to personally by the Divisional and Sub-divisional
Officer, and that the accounts fairly represent the progress of each work; and(6)examine the register
of works, watch the total expenditure to date under each sub-head of work in contrast with the
sanctioned estimate and see that revised estimates for any work if required, are submitted in due
time to the sanctioning authority.(c)The Divisional Officers will-(1)not commence the construction
of any work, or spend public funds without the sanction of competent authority;(2)close the
accounts immediately the work is finished, and prepare the completion report if required by the
rules;(3)take the necessary steps for obtaining cash for the works under their control, keep their
accounts and submit them punctually to the audit office, under the rules for the time being in
force;(4)exercise a thorough and efficient control and check over their divisional accounts and
examine carefully the books, returns and papers from which the monthly accounts are
compiled;(5)be responsible for the correctness, in all respects, of the original records of cash and
stores, receipts and expenditure, and for seeing that complete vouchers are obtained; and(6)afford
information in cases of probability of excess of actual over estimated cost of work, and report the
fact forthwith to the Superintending Engineer, describing the nature and cause of the probable
excess.Administrative Approval and Technical Sanction
222.
For every work which it is proposed to carry out, except petty works and repairs the cost of which is
not likely to exceed Rs. 1,000 and annual repairs for which a lump sum provision has been
sanctioned by the Superintending Engineer, a properly detailed estimate must be prepared for the
sanction of competent authority; this sanction is known as the "technical sanction" of the estimate.
Such sanction can only be accorded by Government in the Public Works Department, or where
power has been delegated to them, by officers of that department. Sanction accorded to the
construction of a work by any other department of Government is to be regarded merely as an
"administrative approval" to the work, as defined in the following rule, and the fact that such
approval has been accorded in no way dispenses with the necessity for a further technical sanction,Bihar Financial Rules, 1950

which must be obtained before the construction of the work is commenced.
223.
For every work (excluding repairs and petty work) initiated by or connected with the requirements
of another department, it is necessary to obtain the concurrence of the department concerned to the
proposals before technical sanction to the work is accorded in the Public Works Department. The
formal acceptance by the department concerned is termed "administrative approval" of the work,
and is in effect, an order to the Public Works Department to execute certain specified works at a
stated sum to meet the administrative needs of the department requiring the work. Such approval
should not, however, be accorded until the professional authorities have intimated that the
proposals are structurally sound, and that the preliminary estimate is sufficiently correct for the
purpose. A similar procedure should be followed in the case of works required to meet the
administrative needs of the Public Works Department, both the administrative approval and the
technical sanction being accorded, in such cases, in the Public Works Department.Note. - The words
"approval" and"sanction" respectively, when used in respect of estimates for works, bear throughout
this chapter the meanings indicated in this and the foregoing Rule.
224.
An application for administrative approval should be submitted to the authority competent to
accord it accompanied by a preliminary report by an approximate estimate and by such preliminary
plans, information as to the site and other details as may be necessary fully to elucidate the
proposals and the reasons therefor. The approximate estimate and the preliminary plans should be
obtained from the Public Works Department. If, however, the work is not likely to cost more than
Rs. 10,000 detailed plans and estimates may be prepared in the first instance and submitted to the
authority competent to accord administrative approval, being returned thereafter to the officer of
the Public Works Department competent to accord technical sanction.
225.
This procedure will also apply to modifications of the proposals originally approved, if likely to
necessitate eventual submission of a revised estimate, to material deviations from the original
proposals, even though the cost of the same may possibly be covered by savings on other items, and
to cases where the detailed estimates, when prepared, exceed the amount administratively approved
by more than 10 per cent or 5 per cent in the case of residential buildings involving excess over the
admissible outlay. In these cases, as also in cases in which it becomes apparent, during the execution
of the work that the amount administratively approved will be exceeded by more than 10 percent or
5 per cent, as the case may be, owing to increase of rates or other causes, the revised administrative
approval of competent authority must be obtained to the increased expenditure without delay, and
in the case of modifications during construction, without awaiting the preparation of a detailed
supplementary or revised estimate.Bihar Financial Rules, 1950

226.
For works required not for a particular department but in the interests of the general public, e.g.,
communications, irrigation works, and miscellaneous improvements, preliminary designs and
estimates should be submitted for scrutiny by the administrative department concerned before a
detailed estimate is prepared for the purpose of technical sanction.Requisition by Civil Officers
227.
When an application is made for a new building or for additions or alterations to existing buildings
required for the use of any department, the Divisional Officer must in each case exercise his
judgment on the demand made, giving all proper weight to the opinions of the departmental officer
concerned; but it is his duty to oppose any application of the funds at his disposal to works of real
necessity for which he is not satisfied and in every case in which he thinks that he cannot
recommend the execution of a work called for by a duly constituted authority, he should explain his
objections to the officers concerned, and, if he fails to convince him, should refer the matter for the
orders of the Superintending Engineer.
228.
The actual execution of works, asked for by civil officers, must in every case be dependent on the
necessary funds being available.Preparation of estimates
229.
Ordinarily a detailed working estimate will provide for the work expenditure, but the complete
estimate for a project should include indirect at well as direct charges.Contracts
230.
The recognised systems for carrying out work, otherwise than by the employment of daily labour,
are "Piece-work" and "Contract work". Piecework is that for which only a rate is agreed upon,
without reference to the total quantity of work to be done, or the quantity to be done within a given
period. The term "contract" as used in this chapter, does not include agreements for the execution of
work by piece-work, nor does it include more ordinarily purchase of materials or stores. All other
work done under agreement is termed "Contract work", and in agreements for such work, which
should invariably be in writing there should generally be a stipulation as to the quantity of work to
be done, and the time within which it is to be completed.
231.
The following Rules regulate the acceptance of piece-work agreement:-(1)Except as provided in Rule
3 below, piece-work agreement should not be accepted for any work, being the whole or part of anyBihar Financial Rules, 1950

sanctioned project, the sanctioned estimate for which exceeds [Rs. 10,000] [Substituted For Rs.
5,000 by C.S. No. 23 dated 5.6.1958.](2)If the sanctioned estimate of the work exceeds Rs. 2,500 the
previous approval of the Superintending or Chief Engineer should be obtained before the piece-work
system is adopted.(3)[With the approval of the Superintending Engineer, piece-work system may be
adopted for earthwork, dressing and turfing in road and irrigation projects upto a limit of Rs.
50,000] [Substituted For Rs. 5,000 by C.S. No. 23 dated 5.6.1958.], It may also be adopted for
works on the collection and consolidation of road metal even when the estimate for such works
exceeds [Rs. 10.000] [Substituted by C.S. No. 23 dated 5.6.1958.]. It may also be adopted for works
on the collection and consolidation of road metal even when the estimate for such works exceeds
[Rs. 1000] [Substituted by C.S. No. 23 dated 5.6.1958.] provided that the cost of the work given out
to an individual contractor does not exceed [Rs. 10.000] [Substituted For Rs. 5,000 by C.S. No. 23
dated 5.6.1958.],(4)The provisions, of Rules 236, 241 and 247 should be strictly observed and no
tender for piece-work should be accepted by an Executive Engineer, if in similar circumstances it
would not be within his power to accept a tender for contract.
232.
"Contracts" may be of three kinds, viz. Lump sum, Schedule and a combination of these two.In a
lump sum contract, the contractor engages to execute the work, with all its contingencies, for a fixed
sum.
contracts are those in which the contractor undertakes to
execute the work at fixed rates, the sum he is to receive
depending on the quantities and kind of work done or material
supplied (See Rule 246).
The third kind of contract is a combination of both these. Thus a fixed, sum is proposed for
completion of the work as specified and a schedule of rates is agreed upon by which to regulate the
price to be paid or to be deducted for additions or alterations.
233.
In works of great magnitude the contract deeds should be prepared specially by the Government
Law Officers, but for ordinary contracts, including all such as are based on tenders which a
Superintending Engineer is competent to accept, all contract deeds should be executed on one or
other of the approved forms.Tenders
234.
Tenders, which should always be sealed should invariably be invited in the most open and public
manner possible.(a)[ Whenever tender is invited for any work and single tender is received either on
scheduled rate or on the rate higher or lower than that, immediately second tender should be
invited. [Inserted by Notification No. 1730 F.(2) dated 5.3.2003.](b)If after second invitation moreBihar Financial Rules, 1950

than one tenders are received or single tender is received on scheduled rate or on the rate lower than
that, that will be decided by the competent authority itself.(c)If after second invitation single tender
is received on the rate higher than the scheduled rate that should be decided by the tender execution
authority level higher than the Competent Authority.(d)This procedure should be made applicable
for all the Works Departments.]
235.
It is not necessary to call for tenders for works the sanctioned estimate of which does not exceed Rs.
200.
236. [ [Substituted by C.S. No. 9 dated 30.12.1957.]
No tender for the execution of works of any description of work branches of the Public Works
Department should be received unless accompanied by a challan showing the deposit of earnest
money into a treasury, to the extent notified as necessary by the Executive Engineer or other
officer.Contractors may however be permitted to deposit the earnest money either by 12-year
National Plan Saving Certificates, Treasury Saving Deposit Certificates, State Development Loan or
National Plan Loan Certificates, vide Rule 239 (b), duly endorsed to the Executive Engineer, if they
prefer to do so.Explanation - The term Public Works Department includes all the four work
branches of the Public Works Department viz. Buildings and Roads, Irrigation, Electricity and
Public Health Department.]
237.
The amount of earnest money to be deposited should be sufficiently large to be a security against
loss in case of the contractor failing to furnish the required security within the appointed time after
the acceptance of his tender, or until the sums due to him form a sufficient guarantee, as the case
may be.
238. [ [Substituted by C.S. No. 32 dated 4.4.1959.]
Usually the lowest tender should be accepted, unless there is some objection to the capability of the
contractor, the security offered by him or his execution of former work. Whenever the lowest tender
for projects costing Rs. 500 and above is not accepted by the authority accepting the tender, he
should immediately communicate the reasons for the same to his immediate superior authority
confidentially for approval. At the same time the acceptance or the rejection of tenders is left
entirely to the discreation of the officer to whom the duty is entrusted and no explanation can be
demanded for the cause of rejection of his offer by any person making a tender.Note. - Reasons for
not accepting the lowest tender and the orders of the superior authority thereon shall be made
available to the audit staff during inspection.]Security for performance of contractsBihar Financial Rules, 1950

239. [ [Substituted by C.S. No. 10 dated 30.12.1957.]
Security should in all cases be taken for the due fulfilment of a contract. This security may be-(a)A
deposit of cash up to Rs. 500, or up to any larger amount deposited as earnest money under Rule
237, Government securities, municipal debentures and Port Trust Bonds duly endorsed to the
Executive Engineer.(b)12 year National Plan Saving Certificates, Treasury Savings Deposit
Certificates, State Development Loan or National Plan Loan Certificates, for the amount at which
the certificates and papers were purchased, but not for their face value duly endorsed to the
Executive Engineer.(c)A deduction of 10 per cent from the monthly payments to be made on
account of work done.(d)Personal security of two persons of known probity and wealth.Note. -
Parties concerned may be permitted to make, either by a suitable deposit or a guarantee
arrangements with any bank which lodges with the Reserve Bank of India requisite securities in
respect of the guarantee to be executed or fixed deposit receipts to be tendered by it on terms and
conditions laid down by Government in this behalf from time to time:[Provided the cottage and
small scale units, duly registered, shall be permitted to deposit half the amount of the security that is
required to be deposited by other tenders.]
240.
In the case of piece-work agreement the Divisional Officer may, if he deems it necessary, make
deductions from the bill of a sum not exceeding 10 per cent of the value of work done as security for
the rectification of such defects in the work as may be noticed within three months after completion
of the work.Provision in contracts for imported stores
241.
In framing contracts of any description care should be taken to retain in the hands of Government
the supply of imported materials, if required to any considerable extent, and to arrange the terms
accordingly. Such stores should either be supplied from the existing Government stock, or be
obtained in ordinary course by indent on the [India Supply Mission] [Substituted for 'India Stores'
by No. T.M. B-34-1022 dated 20-9-1964.] or by purchases in the local market. In important
construction works let out on contract, such stores may be supplied by the contracting firm, subject
to the conditions stated in the Stores Rules (Appendix 8).Enforcement of terms of contract
242.
Engineers and their sub ordinates are responsible that the terms of contracts are strictly enforced,
and that no act is done tending to nullify or vitiate a contract. All contract deeds must be executed
on one or other of the standard forms but they may be modified to suit local requirements after
consultation with the legal advisers of Government. All agreements or security bonds entered into
with the Public Works Department by contractors for the execution of work, or for securing the due
performance of contracts, are exempt for stamp duty.Officers empowered to execute contractsBihar Financial Rules, 1950

243.
No authority other than the Officer In Charge of sub-division can accept any tender or make a
contract for public works. The officers legally empowered to execute the different classes of deeds,
contracts and other instruments are detailed in the specific orders of delegation made in this behalf.
(See Rule 29).
244.
It is permissible to give out to different contractors a number of contracts relating to one work, even
though such work may be estimated to cost more than the amount up to which officers are
empowered to accept tenders. But no individual contractor may receive a contract, amounting to
more than this sum nor if he has received one contract, may he receive a second in connection with
the same work or estimate while the first is still in force, if the sum of the contracts exceeds the
power of acceptance of the authority concerned.
245.
Departures from the rules for contracts specified above may be permitted or condoned by the State
Government subject to any restrictions they may impose in each case.Accounts procedure for lump
sum contractsA - General
246.
The following accounts procedure should be observed in connection with lump sum contracts: -(1)In
a lump sum contract the contractor agrees to execute a complete work with all its contingencies in
accordance with the specification for a fixed sum the following being its essential characteristics.(i)A
Schedule of rates specified in order to regulate the amount to be added to or deducted from the fixed
sum on account of additions and alterations not covered by the contract.(ii)Except as provided in
clause (i), no allusion is made in the contract to the departmental estimate of the work, Schedule of
rates or quantities of work to be done.(iii)Detailed measurements of the work done are not required
to be recorded except in respect of additions and alterations.(2)The form of contract will be
prescribed by the State Government in consultation with its law officers. It is necessary that, before
the form is finally determined, the advice of the Accountant General should be sought on the
question whether the form proposed meets the requirement of audit.B - Payment for the work
done(3)Subject to the terms of the contract and such subsidiary instructions as may be laid down by
the State Government to ensure that the works are executed in accordance with the prescribed
specification plans and drawings, payments for work done are not made to the contractor otherwise
than on the certificates of the Officers In Charge of the work, as detailed in sub-rules (4) and (5)
below.(4)Whenever it is proposed to make any intermediate payment, a certificate should be
obtained from a responsible officer of Government not below the rank of Sub divisional Officer to
the effect that, by superficial or general measurement or by some other suitable method laid down
by the State Government (vide Rule 419 of the Bihar Treasury Code), he has satisfied himself thatBihar Financial Rules, 1950

value of the work done is less than specified amount in conformity with contract agreement and that
with the exception of authorized additions and alterations, it has been done according to the
prescribed specifications.Note. - In case where the statues and experiences of the certifying officer
are adequate the Comptroller and Auditor General may, on the recommendation of the State
Government, allow exemption from the rule requiring specification in the bill of the method
employed in estimating the value of work done.(5)In the case of final payment, in addition to a
record of detailed measurements in respect of additions and alterations, there should be a certificate
of completion of the work according to the prescribed specification signed by the Divisional
Officer.Note. -In exceptional cases, such as that of the execution of a work in a border country under
the supervision of a responsible civil officer without the intervention of the Public Works
Department a completion certificate signed by the civil officer concerned may be accepted if he is
empowered by the State Government to sign it.(6)In order that a proper financial control may be
exercised over the payments made, it is necessary that the accounts of additions and alterations
should be kept quite distinct from those of the rest of the work. There is no objection to payment for
additions and alterations being made before the completion of the work, if the detailed
measurements of them have been made.C - Forms of Bills(7)The forms of bills used for payments in
connection with lump sum contracts are T.C. Forms 55 and 56 of the Bihar Treasury Code. The State
Governments may modify these, in consultation with the Accountant General in order to provide for
any additional precautions that be deemed necessary (See Rules 419 and 420 of the Bihar Treasury
Code.)Note. - The Form of final bill may be printed on yellow paper to distinguish it from that of the
running bill [See note 2 under Rule 275 (b)].D - Subsidiary Works Accounts.(8)Rules 299 to 308
regarding the maintenance of Work Abstracts and Register of Works apply mutatis mutandis to the
accounts of lump sum contracts. In the case of major estimates, the expenditure need not, however,
be booked by subheads of works if all the charges represent nothing but payments on a lump sum
contract.(9)All "intermediate payments" made to the contractor and so acknowledged by him are
regarded as advances made to him on account of the work concerned, and are brought in accordance
with sub-rules (10) and (11) below.(10)Payments for measured up additions and alterations as well
as for the work covered by the lump sum for which no detailed measurement are necessary are
treated like advance payments and should be brought to account in the works accounts under the
suspense head "Contractors-Advance payments". This will not only simplify accounting but will
facilitate a watch over the prompt adjustment of the payments made.Note. - If a percentage or any
other portion of the value of work done is withheld as security for the due fulfilment of the terms of
the contract, the net amount remaining after the deductions of the portion withheld should be
entered as the advance payment.(11)Payments other than those specified in sub-rule (10) above may
be either "secured Advance" made on T. C. Form 55 of Bihar Treasury Code or other recoverable
payments including the value of materials supplied, which may have been made to the contractor or
to others on his behalf. These should be entered in the accounts under the suspense heads,
"Contractors-Secured Advances" and "Contractors-Other Transactions" respectively.(12)From the
final bill paid to the contractor (T. C. Form 56 of Bihar Treasury Code the total advances made to
him in the running account bills (T. C. Form 55 of Bihar Treasury Code) or other recoverable
payments will be deducted by short payments from the total value of work done, and the recoveries
so made will be shown as minus figures under the suspense heads concerned, in which the plus
figures will already be outstanding.E - Contractor's Ledger(13)Accounts of the transactions relating
to lump sum contracts should be maintained in the contractor's ledger in P.W. A. Form No. 43 in theBihar Financial Rules, 1950

manner described in Section G' of Chapter X of the P.W.A Code 1st Edition Reprint, 1935 subject to
the following subsidiary instructions.(14)As all "intermediate payments" made on T. C. Form 55 of
Bihar Treasury Code are regarded as advances, no figure therefrom will be posted in column 9,
which is intended to show the amounts creditable to contractors account on account of the value of
work done. The first and last entry which will appear in this column will be the figure "F" given in
part 1 of the final bill (T. C. Form 56 of Bihar Treasury Code) column 10 need not be posted at
all.(15)Figures for posting the other columns 4, 5, 6 and 8 are indicated in the bills (T. C. Forms 55
and 56 of Bihar Treasury Code) by the same distinguishing letters, D.E.G. and H. respectively, which
have been used to denote the corresponding entries in the ordinary bill in T.C. Forms 52, 53 and 54
of the Bihar Treasury Code.Commencement of Work
247.
No work shall be commenced unless a properly detailed design and estimate have been sanctioned,
appropriation of funds made, and orders for its commencement issued by competent authority.
Provision in the budget estimate for expenditure on a work convey no authority for the
commencement of outlay.Alterations in Design During Construction
248.
No material alterations in sanctioned still less in standard, designs may be made by an Executive
Engineer in carrying out any work, without the approval of the Superintending Engineer. Should
any alteration of importance, involving additional expense, be considered necessary, a revised or
supplementary estimate should be submitted for sanction. In urgent cases, where the delay thus
caused would be inconvenient, an immediate report of the circumstances must be made to superior
authority and dealt with as the case may require.Note. - Revised administrative approval is
necessary in the cases indicated in Rule 225.
249.
In works, the estimates for which have been sanctioned by a competent authority, no additions or
alterations, likely to cause an excess which will not fall within the powers of sanction of that
authority should be permitted without the previous approval of a higher authority.
250.
Where important structural alterations are contemplated though not necessarily involving an
increased outlay, the orders of the original sanctioning authority should be obtained. A revised
estimate should be submitted for technical sanction if the alterations involve any substantial change
in the cost of the work.Supplementary and Revised EstimatesI - Supplementary EstimatesBihar Financial Rules, 1950

251.
Any development of the project thought necessary while a work is in progress, which is not fairly
contingent on the proper execution of the work as first sanctioned, must be covered by a
supplementary estimate accompanied by a full report of the circumstances which render it
necessary. The abstract must show the amount of the original estimate, and the total of the sanction
required, including the supplementary amount.II - Revised Estimates
252.
A revised estimate must be submitted when a sanctioned estimate is likely to be exceeded by more
than 5 per cent, either owing to the rates being found insufficient, or from any cause whatever,
except as mentioned in the foregoing rule (See also Rule 250).
253.
It is the duty a like of the Executive and of the Superintending Engineer to watch carefully the
progress of expenditure, and to see that a revised estimate is submitted directly, if the necessity
arises.
254.
When the submission of a revised estimate under the above rule is found necessary, it is essential
that the revised estimate should be compared with the latest existing sanction of competent
authority. When by reason of intermediate modifications, such existing sanction differs from that
accorded from the highest authority concerned, statement should be prepared showing how the
sanction with which the revised estimate is compared has been arrived at.III - Utilization of
completion report as revised estimate
255.
When excesses occur at such an advanced period in the construction of a work as to render the
submission of a revised estimate purposeless, the excesses, if beyond the power of the Executive
Engineer to pass, may be explained in a completion report or statement prepared under Rule 301.
256.
For all large works or group of works, labour reports in the prescribed form will be submitted either
daily or periodically as may be directed by the Divisional Officer. These reports show the number of
each class of labourers employed on each work or sub-head. Discrepancies between labour reports
and muster roll (T. C. Form 49 of the Bihar Treasury Code) should be investigated as soon as the
latter are received after the close of the month.Measurement BooksBihar Financial Rules, 1950

257.
The measurement book must be looked upon as most important record, since it is the basis of all
accounts of quantities, whether of work done by daily labour, or by the piece or by contract or of
materials received, which have to be counted or measured. The description of the work must be
lucid, so as to admit of easy identification and check.Detailed measurements may be dispensed with
in the case of periodical repairs when the quantities are recorded in efficiently maintained standard
measurement books. (Vide Rule 278).Detailed measurements may also be dispensed with in cases in
which payments on-account for work actually executed are made on the certificate of a responsible
officer (not below the rank of Sub-divisional Officer) to the effect that not less than the quantity of
work paid for has actually been done and the officer granting such a certificate will be held
personally responsible for any overpayment which may occur on the work in consequence. Final
payments may, however, in no case be made without detailed measurements.Similarly detailed
measurements may be dispensed with in connection with works done on lump sum contracts :-(i)in
the case of an intermediate payment if a certificate is given in the bill, by the Sub divisional Officer
when the payment does not exceed Rs. 5,000 and by the Divisional Officer when it exceeds Rs.
5,000 to the effect that by a rough measurement he has satisfied himself that the value of work done
is not less than a specified amount in conformity with the contract agreement, and that with the
exception of authorised additions and alterations, the work has been done according to the
prescribed specifications; and(ii)in the case of final payments if a certificate of completion of the
work according to prescribed specification is signed by the Divisional Officer in the bill. Detailed
measurements must invariably be taken in respect of additions and alterations.
258.
The Superintending Engineer is required to see that measurement books are carefully kept and
measurements properly recorded, and that there are complete records of the actual measurements
of each kind of work done for which certificates have been granted.
259.
Sub divisional Officers should be required to submit the measurement books in use to the Divisional
Office from time to time so that at least once a year the entries recorded in each book may be
subjected to a percentage check by the Divisional Accountant under the supervision of the Divisional
Officer.Note. - Detailed instructions on the subject are contained in Appendix 9.Works AccountsA -
General Principles
260.
The Divisional Officer should utilize the recorded transactions of the cost of the works as a means of
control. His personal knowledge of the executive arrangements for the execution of a work, and of
the actual progress of work, must be supplemented by a monthly comparison of the cost as recorded
in the accounts with the value received in the shape of work done. In large works, especially whereBihar Financial Rules, 1950

the period of construction is a prolonged one, this monthly comparison is obviously impossible,
unless the total cost is split up in to convenient parts in such a way that as far as possible, the cost of
each distinct part may be compared with the work done thereon. This comparison should be made
in connection with the examination and review of the Works Abstract and Register of Work.
261.
In the case of recoverable charges it should be seen particularly that the contractors or others, on
whose behalf the charges are incurred, do not get the benefit of any concession to which they would
not be entitled if they had themselves incurred the charges.B - Labour engaged through contractors
262.
The payment of daily labour through a contractor, instead of by muster roll in the usual way is
objectionable in principle. In a case of great emergency, it may sometime be found impossible to
employ labour otherwise than through a contractor, should it be possible, in such a case, to
determine the quantity of work done after its completion or at intervals during its progress, it is
expedient to pay the contractor, at suitable rates, on the basis of work actually executed. But if, as in
urgent repairs of canal branches this method of payment is not practicable, it is permissible to pay
the contractor on the basis of number of labourers employed, day by day, his own profit or
commission being either included in the rates allowed, or paid separately in a lump sum or at a
percentage rate.C - Travelling expenses
263.
When it is necessary to bring labourers and articles from a distance, they may be allowed wages for
the number of days occupied in the journey and from the site of the work, if they join the work with
proper despatch. At the discretion of the Divisional Officer, bona fide travelling expenses may also
be allowed to them. The above charges must be borne by the estimate of the work.Note. - The above
Rule does not apply to work charged establishment.Preparation, Examination and Payment of Bills
264.
Subject to compliance with the Rules 266 to 270 for the check measurements by superior officers of
the department, contractors bills and other demands for payments must invariably be prepared,
examined or verified and passed for payment, respectively, by the undermentioned authorities;-
Item
No.Nature of claimAuthority competent to
prepare, examine
toverifyAuthority competent to pass
for payment.
1 2 3 4
1. Wages of labourers, current or
arrears, except thosementioned inOfficer or Sub ordinate
incharge of work.Sub-divisional Officer.Bihar Financial Rules, 1950

item 2 below.
2.Unpaid wages removed from the
accounts of a work underparagraph
278 (f), Public Works Accounts Code
1st Edition,Reprint 1935.Sub-divisional Officer. Divisional Officer.
3.Petty payment of a work done or
supplies made not exceedingRs. 25
in value.Officer or subordinate
concerned.Imprest holder.
4.Final bills of contractors or
suppliers involving work doneor
supply made in excess of Rs. 1,000,
bills for advances (bothsecured and
others and claims for refunds.Sectional Officer and
Sub divisional Officer as
laid down inRules 265
and 271.Divisional Officer or Sub
divisional Officers authorised
byhim under Rule 15 subject
to the limit prescribed therein.
5.Claims or demands relating to
payments of bills ofcontractors or
suppliers, for work done or supply
made to thevalue of Rs. 1,000 and
less but exceeding Rs. 25.Ditto Ditto.
265.
Before the bill of a contractor is prepared the entries relating to the description and quantities of
work of supplies and the calculations of "contents or area" should be entered by the Sectional Officer
In Charge of the work in the measurement book. The bill should then be prepared by him in
duplicate from the measurement entries in one of the forms prescribed in Rules 413 to 422 of Bihar
Treasury Code, applicable to the case and submitted to the Sub divisional Officer. The rates allowed
should be entered by the Sectional Officer both on the abstract of measurements and the bill itself.
Full rates as per agreement, catalogue, indent or other order should be allowed only if the quality of
work done or supplies made is up to the stipulated specification. When the work or supplies fall
short of that standard and the standard is not so low as to warrant total rejection of the work or
supplies, and under the agreement it is permissible to make a final payment if the contract is
determined or an "on account" payment if the contract is to run on, only such a fraction of the full
rate should be allowed as is considered reasonable with due regard to the work remaining to be done
on the general terms of the agreement.It should be made widely known to contractor that all entries
of rates made by the Sectional Officer in the abstracts of measurement and bills are subject to the
approval of the proper disbursing officer.Note 1. - If the contract agreement does not specify the
rates to be paid for the several classes of work or supply but merely states that the estimated rates,
or a certain percentage below or above them, will be allowed, it should be seen that the standard
rates adopted are those of the sanctioned estimate which was in force at the time the agreement was
executed, or, if the agreement was preceded by a tender, on the date the tender was signed by the
contractor. Subsequent sanctions to original or revised estimates have no effect on the terms of such
an agreement. If no sanctioned estimate is in existence at the time of signing the agreement or the
tender, as the case may be, the rates payable for each item of work should be specified, as any
reference to an estimate not yet sanctioned is meaningless and cannot be acted upon.Note 2. - As aBihar Financial Rules, 1950

general rule, payment for supplies is not possible until the stores have been received and
surveyed.Note 3. - Payment for materials supplied free on rail whether despatched at railway risk or
otherwise, should be made on receipt of the railway receipt, any claims for shortage being settled
subsequently with the railway company or the supplying firm after the necessary measurements
have been made. Such payments will however, be held under objection in audit till the bills are
presented after actual measurement and after the discrepancies, if any, have been settled by the
disbursing officer either with the railway company or the firm concerned, or by obtaining the
sanction of competent authority to write off of the loss or shortage.Note 4. - Advance payment for
supply of materials up to an amount not exceeding 75 per cent of the value of materials subject to
limit of Rs. 10,000 in case of payment by an Executive Engineer, and Rs. 20,000 in case of payment
by a Superintending Engineer, may be made on submission of Railway Receipts. The balance will be
paid on receipt of the goods subject to the usual verification.Note 5. - Such advance payment is
made only on receipt of a certificate of personal inspection of goods by the consignee who may
employ an officer of not below the rank of Assistant Engineer for this purpose. In very special cases
on the specific request of the intending officer the Special Officer, Materials and Plants will be
deputed.Note 6. - Whenever any advance payment is made, it should be made clear to the supplier
that they are in no way absolved of the responsibility in respect of quality and quantity of stores
despatched by them and recoveries are liable to be made if the stores received are found in any way
to be defective or short in quantity.
266.
The Sub-divisional Officer is expected to take all final measurements of important works himself. He
will also check not less than 50 per cent of the measurements (judged by their money value) made
by his sub ordinate in the case of other works i.e., works other than important.Note - The
determining of important works is left to the discretion of the Divisional Officer.
267.
Similarly, the Divisional Officer is expected to check, measure, not less than 10 per cent, of the
measurements (judged by their money value) made by his sub ordinates. This check should,
however, not be less than 10 per cent of total number of bills prepared in any year.
268.
The check measurements referred to above should, so far as possible be carried out before payment
is made.
269.
The individual items checked should be clearly shown in the measurement book, and the result
recorded by the officer concerned on the date of check under his dated initial; all entries to be in ink
or indelible pencil.Bihar Financial Rules, 1950

270.
A collective record of all the checks carried out from time to time will also be prepared at the end of
each measurement book in the following form.Record of check measurements by superior officers
Date of
checkPages recording
measurements
subjected to testcheckValue of
measurement
checkedNumber of
bills check
measuredResult of the
check
exercisedDate, initials and
designation of the
checkingofficer
1 2 3 4 5 6
  Rs.    
N.B. - This result will be indicated by the word "satisfactory" or"unsatisfactory" as judged at the time
on the merits of each case.
271.
Before signing the bill the Sub divisional Officer, must satisfy himself that work has been actually
done in accordance with the claims preferred. He should personally inspect all works of any
magnitude before authorising final payment in connection therewith. He should scrutinise and
compare the quantities in the bill with those recorded in the measurement book and check all the
rates with the tender. When the bill is based on standard measurements he should invariably record
the following certificate on the bill:-"Certified that the whole of the work billed for herein has been
actually done and that no portion thereof has been previously billed for any shape." He should also
have all calculations checked arithmetically in his office by the sub divisional clerk who is primarily
responsible for the accuracy of all figures in column "contents or area" and abstract in the
measurement book relating to the bills passed by the Sub divisional Officer. When the bill is on a
running account it should be compared with the previous bill. The memorandum of payments
should then be made up, any recoveries, which should be made on account of the work or supply or
on other accounts, being shown therein. If the Sub divisional Officer is empowered to pay the bill, he
should then record a formal pay order specifying both in words and figures, only the net amount
payable, though the payee should be required to acknowledge in his acquittance the gross amount
payable inclusive of the recoveries made from the bill.No payments for work done under lump sum
contract should be made otherwise than on certificates of the Officer-In-Charge of the work in
accordance with the provisions of Rule 257 (Vide also Rules 419 to 420, Bihar Treasury Code).'Note
1. - In calculating the value of each item of work the nearest * anna should be taken, *pies one to five
being ignored, and *pies six to eleven taken as one anna; but 'pies must not be omitted from the
rates, [*now Paise],Note 2. - Whenever fractions of a rupee occur in the totals of contractors bills or,
in the case of supplies chargeable to more than one estimate, in the totals chargeable to each
estimate, fraction less than half may be disregarded, and half a rupee and over taken as a rupee.Note
3. - If the contract is for the completed items of works and, under the provisions of Rule 285 the
contractor is required to obtain materials of any description from Government, it should be seen
that this condition is being complied with, and that necessary recoveries of the cost of the materials
supplied to him are being made in accordance with Rule 288. In such a case it is not permissible for
the contractor to obtain the materials otherwise, unless in an emergency, the supply has beenBihar Financial Rules, 1950

entrusted by the Divisional Officer, for recorded reasons, to the contractor himself at suitable
rates.Note 4. - Before signing a fresh and final bill or the first bill on a running account, the Sub
divisional Officer should see that the relevant measurement entries have been marked as pertaining
to such bill by the person taking the measurement.
272.
In all cases where the duty of passing claims for payment devolves on the Divisional Officer or when
the Sub-divisional Officer is not allowed to act as a disbursing officer the measurement book or
other relevant documents on which the claim is based should be submitted, with the bill to the
Divisional Officer where calculations of measurements will inter alia be fully checked under
supervision of the divisional accountant before payment. A clerk in the divisional office should be
made responsible for the arithmetical check of such figures and abstracts relating to all bills passed
by the Divisional Officer.
273.
In other cases, divisional accountant will be required to make a percentage check of the entries
recorded in each measurement book at least once a year, under the supervision of the Divisional
Officer, with a view to test check the accuracy of calculations and to ensure that the books are
otherwise in order, with reference to the instructions contained in paragraph 281 of Public Works
Account Code, First Edition, Reprint 1935, or any subsidiary rules framed thereunder. The
procedure to be observed will be as follows :-(a)The measurement books in each sub-division should
be submitted by the Sub-divisional Officer concerned so as to reach the Divisional Officer by the
date prescribed by the Divisional Officer. A register showing the date of their receipt and return
from and to the Sub-divisional Offices should also be maintained by the divisional accountant in the
following form :-
Sl.
No.Date of
issueName of
officer to
whom issuedDate receipt in
divisional office for
checkDate of
returnDate of receipt in
divisional officer for
checkDate of
returnDate of
final
return
1 2 3 4 5 6 7 8
 
(b)On receipt, by the divisional office, of all the measurement books the Divisional Officer, should
indicate in column 2 of the "Review Notes" in each measurement book referred to in sub-rule (c)
below which of the calculations are to be test-checked by the divisional accountant. Such check
should not, however, be less than 10 per cent of the value of total measurement recorded in each
book since the last review (excluding those which have already been checked fully under Rule 272
above) and should cover complete sets of measurements. Payments based on the entries reviewed
should be traced into the various accounts and verified. Similarly, supplies or issues of materials
should be traced into ti ? various accounts, contractor's ledger, etc., and verified.(c)The defects,
discrepancies etc. noticed should be communicated to Sub-divisional Officer concerned and
summarised in the following form in the measurement book which have been audited :-ReviewBihar Financial Rules, 1950

notes by the divisional accountant
Pages reviewed
generallyCalculation selected by the
Divisional Officerfor re-checkDefects, discrepancies
etc. noticeDated initial
of -
Page. Dated initial Divisional accountantDivisional
officer
1 2 3 4 56
 
(d)Measurement books completed and returned for record during the year should also be similarly
examined prior to their final record in the divisional office.(e)The divisional accountant must not
retain a measurement book longer than ten days after receipt. He should submit the register
prescribed by sub-rule (2) above for the scrutiny of the Divisional Officer periodically.(f)No
measurement book will remain in use for a longer period than two years, it must at the expiry of this
period be returned for final record. But if any book is then found to contain a large number of blank
pages it may be reissued by the Divisional Officer recording the fact in the register.(g)On the
occasion of transfer Sub-divisional Officer will see that all measurement books in custody of the
relieved sub-ordinate were acknowledged by the relieving sub-ordinate. Similarly, the divisional
accountant will see that all measurement books in a subdivision are acknowledged by a relieving
Sub-divisional Officer in his transfer papers.
274.
From the measurement book all quantities should be clearly traceable in the documents on which
payments are made. When a bill is prepared for the work or supplies measured, every page
containing the detailed measurement must invariably be scored out by a diagonal red ink line, and
when the payment is made an endorsement must be made, in red ink, on the abstract of
measurement, giving a reference to the number and date of the voucher of payment.The documents
on which payment is made should invariably show, in the space provided for the purpose, the
number, and page of the measurement book in which the detailed measurements are recorded, and
the date on which the measurement was made.
275.
(a)Payments for work done or supplies made on a running account should ordinarily be made
monthly. Both the "quantities" and "amount" of each distinct item of work or supply should be
shown separately in the bill, except in the case of advance payment when quantities need not be
specified.(b)Such payments should be treated as payments on account, subject to adjustment in the
final bill which should be drawn, in the appropriate form but printed on yellow paper, when the
work or supply is completed or the running account is to be closed for other reasons. When a final
payment is made on a running account, the payee, if he is able to write, should add in his own
handwriting that the payment is "in full settlement of all demands". If the payee is illiterate, or is
unable to write beyond signing his name, these words should be filled in by the officer making the
payment-Note 1. - If the contractor refuses to give an acknowledgement to the effect that the
payment made to him was in full settlement of all demands, it is not necessary to insist on obtainingBihar Financial Rules, 1950

a qualified acknowledgement.Note 2. - A Form printed on yellow paper is never to be used except for
final payment.(c)A separate running account is maintained in respect of each contract. Transactions
relating to two or more separate working estimates should not be brought on to the same running
account; they should, therefore, not be covered by a single contract. Transactions relating to two or
more separate parts of the same working estimate, for which separate works abstracts are prepared
under Rule 301 should also appear in separate running accounts.
276.
(a)If the system of making advance payments to contractors for works has been adopted certificate
2, printed on Running Account Bill A or B (T.C. Form 52 or 53 of Bihar Treasury Code) as the case
may be, must be signed by the Sub-divisional Officer, and the lump sum amount paid on account of
each item should be specified against it in Part I of the bill. If a secured advance has previously been
allowed to a contractor on the security of any materials and such materials have been used in the
construction of an item, the amount of the advance payment for that item should not exceed a sum
equivalent to the value of work done less the proportionate amount of secured advance ultimately
recoverable on account of the materials used.(b)Actual measurement should, however, be taken at
the earliest opportunity, any when this has been done, the lump sum payment previously made on
account of the items of work concerned should first be adjusted in full, so that the contractor may
not be paid twice over in respect of the same quantities of work. Delay in adjusting advance
payments should be investigated, and adjustments made otherwise than by crediting the value of
work actually measured should be specially looked into as being prima facie indicative of over
payment in the first instance.
277.
When secured advances [vide Rule 411 (a), Bihar Treasury Code] are allowed by the Divisional
Officer to a contractor whose contract is for finished work, it should be seen that an Indenture in
F.R. Form 7 has been signed by the contractor, and a detailed account of the advances must be kept
in Part II of the Running Account Bill (T.C. Form 53, Bihar Treasury Code). There should be
separate entries in respect of each class of materials of the quantities brought to site by the
contractor and the amount advanced under the orders of the Divisional Officer. These advances
must be recovered by deduction from the contractor's bill for work done as the materials are used in
construction and the items of work in which they are used are billed for on the basis of actual
measurements. Parts I and II of the bill should be compared to see that this order is being complied
with. As recoveries are made, the outstanding accounts of the items concerned in Part II should be
reduced by making deduct entries in the column "Deduct quantity utilised in work measured since
previous bill", equivalent to the quantities of the materials used by the contractor on items of work
shown as executed in Part I of the bill.Note. - No record should be kept in measurement books of the
quantities of the materials, but certificate 3 printed on the bill should be signed by the
Sub-divisional or Divisional Officer.Standard MeasurementsBihar Financial Rules, 1950

278.
It is usual in the Public Works Department to maintain standard measurement books of buildings in
order to facilitate the preparation of estimates for periodical repairs. Where such standard books are
maintained it is also permissible to utilise them for the purpose of preparing contractor's bills for
such repairs, so that it may not be necessary to take detailed measurements on each occasion.The
following rules should be observed in maintaining the standard measurement books:-(a)Standard
measurement books will invariably be written legibly in ink only, and maintained by the Public
Works Department for the purposes specified in paragraph 282 of the Public Works Account Code,
1st Edition, Reprint 1935. The work of preparing these books will ordinarily be undertaken in
accordance with a programme for each sub-division or such other suitable unit as may be fixed by
the Divisional Officer.(b)All the standard measurement books thus maintained in a Division will be
numbered in an alphabetical series, so as to be readily distinguished from ordinary measurement
books and a register of them maintained in the Divisional Office in P.W.D. Form No. 92 (Part II). A
similar register should be maintained in each subdivision showing the books belonging to it, and the
registers kept under lock and key in the custody of Divisional or Sub-divisional Officer
concerned.(c)In view of the fact that these books will form the basis of both the annual repair
estimates and contractors bill for work done, they should be written up either by the Sub-divisional
Officer himself or by a member of the sub-ordinate engineering service under his orders. Each set of
measurements taken by the latter class of officers should, however, be fully checked by the
Sub-Divisional Officer concerned, after which it should be examined by the Divisional Officer and
declared in writing in the book itself as finally approved by him for one or both of the purposes
specified above. Until this is done, the books will not be entered in the register of standard
measurement books, nor will a number be assigned to it.(d)Thereafter, the standard measurement
books will be brought up to date, under the supervision of the Sub-divisional Officer with reference
to any additions and alterations which may be carried out to the building or work concerned within
one month of the closing of the accounts of the estimate therefor. All such corrections will be duly
attested by the Sub-divisional Officer.(e)The Divisional Officer will also be expected to exercise a
check over the completion of standard measurement book at least once a year. To this end, the
programme of work should ordinarily be as follows :-(1)As soon after the close of the official year as
possible, the Subdivisional Officer concerned will arrange for a personal examination of these books
with a view to satisfying himself that they have been brought up-to-date with reference to the
additions, alterations or special repairs carried out in the building or work during the preceding
year, and ensuring their submission on such dates as may be fixed for the purpose for the inspection
of the Divisional Officer.(2)On receipt in the Divisional Office, the books will be compared with the
register of standard measurement books which have been submitted for inspection. They will then
be subjected to such scrutiny as the Divisional Officer may direct. A comparison of these books with
the accounts of expenditure and the record of connected measurements relating to estimates for
additions, alterations or special repairs to buildings and works in the division should, however, form
a feature of check to be applied.Note. - A record of the results of the scrutiny referred to should
invariably be retained, and produced, if required, for the Superintending Engineer's or, the
Accountant General's inspection.(3)Finally, a report should be made to the Superintending Engineer
so as to reach him not later than the 31st August, of each year, to the effect:-(i)that all the standard
measurement books of the division have been inspected by the Divisional Officer;(ii)that the entriesBihar Financial Rules, 1950

made therein have not been tampered with;(iii)that all corrections due to additions or alterations to
the building or work concerned have been carried out; and(iv)that the books are reliable up-to-date
records.A copy of this report should be furnished to the Audit Office.
279.
The Superintending Engineer should submit a report to the State Government in September each
year to the effect that all the standard measurement books of the divisions have been inspected by
the Executive Engineer and that the books are reliable and up-to-date records and that the entries in
the books have been certified as correct by the Sub-divisional Officers.
280.
It is necessary sometimes in the interest of work, to engage labourers or contractors, or to incur
other liabilities on behalf of the contractor concerned, with a view to complete work which he has
neglected or failed to complete. In such a case it is permissible to spend Government funds on behalf
of the contractor in accordance with the terms of agreement. Otherwise no advance or recoverable
payment should be made to, or on behalf of, a contractor, nor should financial aid be given to him in
any form, except in accordance with Rule 411 of the Bihar Treasury Code.(1)For rules relating to the
issue of materials to contractor, see Rules 285 and 286.(2)With a view to avoid subsequent disputes
with the contractor, suitable intimation should be sent to him (a) soon as action is taken under this
Rule, and (b) subsequently, as charges are incurred on his account.Work Charged Establishment
281.
Works establishment will include such establishment as is employed upon the actual execution, as
distinct from the general supervision, of a special work or of sub-works of a specific project, or upon
the subordinate supervision of the departmental labour, stores and machinery, in connection with
such a work or sub-works. When employees borne on the temporary establishment are employed on
work of this nature, their pay should, for the time being, be charged direct to the work.Note. -
Competent authority may waive the rule, which prescribes that works establishments must be
employed upon a specific work, and determine in such cases the proportions in which the cost of
such establishment shall be allocated between the works concerned.
282.
The cost of works establishment must be shown as a separate subhead of the estimate.Conditions of
Employment
283.
In all cases, previous sanction of the Divisional Officer, the Superintending Engineer, or the State
Government, as the case may be, is necessary, which should specify in respect of each appointmentBihar Financial Rules, 1950

(1) the consolidated rate of pay, (2) the period of sanction, and (3) the full name (as given in the
estimate) of the work and the nature of the duties on which the man engaged would be
employed.Issues of MaterialsI - General
284.
Issues of materials to works whether from stock or by purchase, transfer or manufacture, are
divided into two classes :-(1)Issues to contractors. - Issues of materials to contractors with whom
agreements in respect of completed items of works, i.e., for both labour and materials, have been
entered into.(2)Issues direct to works. - Issues of materials when work is done departmentally or by
contractors whose agreements are for labour only.II - To Contractors(a)General Conditions
285.
(a)The issue of materials to contractors who have contracted for completed items of work is
generally permissible only in the following circumstances:-(i)when, under the operation of Rule 241,
it is necessary to retain in the hands of Government the supply of imported materials, and(ii)when,
in the interest of work, or with the object of utilising existing stocks of materials, it is desirable to
retain in the hands of Government the supply of certain other materials as well, and a condition to
this effect has been inserted in the contract.(b)In both cases the contract should specify (1) the
materials to the supplied by Government for use on the work, (2) the place or places of delivery, and
(3) the rates to be charged to the contractor for each description of materials. The contractor should
be held responsible for obtaining from Government all such materials required for the work and for
making payment therefor, by deduction from his bills, at the rate specified, regardless of
fluctuations in the market rates or in the stock rates of the division.Note 1. - The rates to be charged
to the contractor for materials to be supplied should be specified definitely, vague quotations, e.g.,
"at stock rates", being avoided; and if intending contractors have been told that the materials would
be supplied at a certain rate and asked to tender on that assumption, then that rate should be
adhered to in the contract.Note 2. - Similarly, the rates to be allowed to the contractor for items of
work should be stated definitely. But if, for any special reasons, the contract provides for the
payments for work done to be made at a specified percentage below, or above, the rates entered in
the sanctioned estimate of the work (or the schedule of rates), it should be stated in clear terms in
the contract that the deduction or addition, as the case may be, of the percentage will be calculated
on the gross, and not the net amount of the bills for work done, and in fixing the percentage it
should be borne in mind that the calculations will be so made.(c)No carriage or incidental charges
are borne by Government for moving the materials beyond the place where the contractor has
agreed to take delivery thereof.
286.
(a)As a general rule no other materials should be supplied to such contractors for use on works but
this restriction may be waived by the Sub-divisional Officer in respect of petty issues (at full Issue
Rates) of materials from existing stock not exceeding Rs. 50 in any month for any one contract.(b)If
at any time subsequent to the execution of a contract on a through rate basis, the contractor desiresBihar Financial Rules, 1950

the issue to him, for use on a work, of materials which exist in Government stock but the supply
whereof by Government was not provided for in the contract, the material should not be issued
except with the express authority of the Divisional Officer, who would specify in each case the rate to
be charged for the materials inclusive of delivery at the place where they are stored. The rate
charged should be the market rate prevailing at the time of the supply or the Issue Rate, whichever
may be greater, and no carriage or incidental charges should be borne by Government in connection
with the supply.The intention of this rule is to prohibit the supply of materials to contractors with
the object of giving them financial aid, vide Rule 411 of the Bihar Treasury Code and Rule
280.(c)Issues of stock materials to contractors for bona fide use on works are exempt from the usual
charge of 10 per cent, on account of supervision, storage and contingencies, which is made when
stock materials are sold to the public Rule 175 (c)].
287.
All materials required for issue to a contractor under the foregoing rules should be made over to him
as soon as they are received.(b)Accounts procedure
288.
The recovery from a contractor on account of the cost of materials issued to him for use on work
should ordinarily be made by deduction from the first bill authorising an advance payment or an 'on
account' payment to him for the work, should, however, a lump sum recovery be undesirable in any
case, the Divisional Officer may permit, for recorded reasons, the recovery to be effected gradually
as the materials issued to the contractor are actually used in construction and the items of work in
which they are used are paid for, whether by an advance payment or by an "on account" payment.
289.
As the issue of materials to contractors under the foregoing rules is permissible solely for the bona
fide requirements of Government works, Sub-divisional Officers should make such agreements as
may be deemed suitable for limiting the total issue to a contractor in connection with a particular
work, to the reasonable needs at that work. This precaution is particularly necessary when the rates
on which any materials are issued under Rule 285 are lower than the prevailing market rates, or the
latter are expected to rise appreciably. In such cases if the transactions are of any importance, the
use of F.R. Form 8 without values is recommended for watching that the aggregate of the quantities
of any or all materials issued to a contractor from time to time, for use on a work, remains within the
estimated requirements of his contract.(c)Return of surplus materials
290.
Government do not undertake to take over from contractors, whether before or after the completion
or determination of contracts, surplus materials which were originally procured by the contractors
for themselves or were issued to them and charged to their accounts. Such materials are theBihar Financial Rules, 1950

property of the contractors and can be taken over by Government if required for use on other works
in progress, only by special arrangement and at the prevailing market rates. If the materials were
originally supplied by Government, the price allowed to the contractor on re-acquisition should not
exceed the amount charged to the contractor.Contractors, are however, not at liberty to remove
from site of works, without the written permission of the Divisional Officer, materials which have
been issued to them for use on a work, and a stipulation to this effect should ordinarily be entered in
their agreement.(d)Tools and plant lent for use.
291.
Rules 285 to 290 do not apply to tools and plant. Articles borne on the tools and plant account of
division may, in accordance with any general or special orders of the Superintending Engineer or the
Executive Engineer on the subject, be lent temporarily to contractors for use on Government works
being executed or maintained by them. It should be seen that the articles are returned without
unnecessary delay, and in good condition.III - Direct to Works(a)Control over issues of stores.
292.
The Sub-divisional Officer should exercise a detailed control over issues of stores direct to works,
and should see that the issue do not exceed the reasonable needs for each work. In cases where no
detailed accounts are maintained in F.R. Form 8, for these works, he should make his own
arrangements for maintaining control over the issues.(b)Disposal of surplus materials.
293.
(a)Materials issued to works in excess of requirements may be transferred to stock, provided they
are serviceable and certain to be required.(b)All surplus materials at site of works which have been
completed or stopped, or on which outlay has been prohibited for any considerable length of time,
should, if likely to be of use on other works within a reasonable time, be transferred to works in
progress or brought on to stock account.(c)If the surplus materials are unlikely to be of any use
within a reasonable time, a list of such materials should be maintained in the Sub-divisional and
Divisional Offices, as a supplement to the half-yearly stock return, unless the Superintending
Engineer considers this unnecessary.(d)Materials returned to store or transferred to other works
should be priced within current market rates, any resultant loss being borne by the work to which
they were originally issued.These rules do not apply to surplus materials which were originally
procured by contractors for themselves, or were issued to them and charged off to their
accounts.(c)Verification of unused balances
294.
Unused balances of materials charged direct to works should be verified at least once a year in the
manner prescribed in Rules 180 and 181. Whenever the verification is made, a report of verification
of the materials should be prepared by the Sub-divisional Officer in F.R. Form 9 and submitted toBihar Financial Rules, 1950

the divisional office. The following instructions should be observed in preparing the report:-(a)As no
continuous account is maintained of the materials actually used in construction, it is necessary first
to calculate the quantities of principal items probably used. This should be done in the detailed
statement at the top of the form, on the basis of the "progress" of work done on each sub head, such
authorised formula being adopted as may be in general use locally.(b)Deducting these quantities
from the total quantities of the materials issued to the work as per F.R. Form 8 the proper balances
of the unused materials should next be arrived at and set forth against line C.(c)The actual balances
should be entered again against line D, and the differences between the actual and proper balances
should be set forth against line E. These differences should be priced at the actual rate of cost which
should be deducted from the total value and quantity recorded in the Account of Receipts, Issues
and Balances of Materials.(d)The report should then be completed by recording against line F,
remarks explaining action taken (1) to adjust the difference as per line E, and (2), if the work has
been completed, to dispose of the surplus balances as per line D, and by signing the printed
certificates applicable to the case and scoring out the others.(e)The difference as per line E may be
due to (i) the adoption of inaccurate, formula for determining the actual consumption, (ii)
unreasonable wastage, or (iii) shortage in some other form. All these differences should be
investigated.
295.
A similar verification of the unused balance of materials must invariably be made on the completion
of a work, but on or before the completion of a work, when no more materials are required for use in
construction, steps should first be taken to dispose of all surplus materials by transfer or sale, so
that (1) the accounts of the work may promptly receive such credits as may, be admissible, (2) the
balance at debit of suspense head "Materials" may, as far as possible, represent the net cost of the
materials actually used in construction and (3) the surplus balances awaiting clearance may be
reduced to a minimum.The report in F.R. Form 9 should in this case set forth both quantities and
value throughout.
296.
If the Gazetted Government servant or sub-ordinate in direct charge of a work, the accounts of
which are kept by sub-heads, is transferred before the accounts of it are closed, the unused materials
at site of the work should be verified by the relieving officer in company with the relieved officer and
the report prescribed in Rule 293 should be prepared by the Sub-divisional Officer and submitted to
the Divisional Officer.
297.
A report is required annually of the value of materials at site of all works the accounts of which were
open on the last day of the official year. This report should be prepared in F.R. Form 9 and
submitted to the divisional office, as on completion of a work, but it is not necessary that the balance
should be verified at the close of the year, if-(1)the work has been under construction for not more
than three months.(2)the accounts of the work are expected to be closed within three months,Bihar Financial Rules, 1950

or(3)the balances were verified at any time during the year.When the balances are not verified at the
close of the year the figures against line C, "Paper balances of unused materials", of the report
should be assumed to be the value of the materials at site, and lines D and E should be left blank.
298.
The foregoing rules are intended primarily for cases where detailed accounts are kept in F.R. Form
8. In other cases the Sub-divisional Officer should make his own arrangements to verify the unused
balances.Works Abstracts and Working Estimates(a)Records of charges in the Works Abstracts
299.
The Works Abstract records the main action relating to a work during a month in respect of cash,
stock and other charges. In the case of a major estimate a separate account is kept for each sub-head
estimated to cost not less than Rs. 1,000 while the expenditure on the remaining sub-heads is
lumped together. In minor estimates the account of expenditure is not kept by sub-heads. The
expenditure need not, also, be booked by sub-heads of work if all the charges represent nothing but
payment on a lump sum contract.The abstract of the estimate may be framed to show merely the
quantity and cost of each completed item of artificer's work, e.g. brick work, or it may be framed to
show the cost of labour and materials separately. The adoption of either form of abstract should be
determined with reference to the mode in which it is proposed to carry on the work. If it is proposed
to contract for the completed item or artificer's work such as masonry, etc., then the first mentioned
form of abstract will suffice, if it is intended to purchase or procure materials and to employ labour
for construction separately, then the second form of abstract will admit of a closer, easier and earlier
check on the outlay and it will, therefore, be preferable.
300.
After a major estimate has been sanctioned it may be decided to make a change in the method
originally contemplated for the execution of the work. In such a case the original abstract should be
recast in accordance with the instructions laid down in Rule 299. The details of cost and quantities
already approved by competent authority should be rearranged, and the revised abstract should be
approved by the Divisional Officer.
301.
If the number of sub-heads in the working estimate for a work or sub-work is large, it is permissible
to break up the estimate into two or more parts and to treat each part as a sub-work.(b)Watch over
the liabilities and balancesBihar Financial Rules, 1950

302.
Disbursing Officers are responsible for keeping a strict watch over all liabilities and balances under
the suspense accounts in the works accounts with a view to settle them promptly. This should be
done at the time of review of the works abstract and the register of works.Money indisputably
payable should never be left unpaid. It is no economy to postpone inevitable payments, and it is very
important to ascertain, liquidate, and record the payments of all actual obligations at the earliest
possible date.
303.
If any liabilities on works are incurred on behalf of contractors under the provisions of Rule 280,
arrangements should be made for withholding sufficient balances from their bills or for making
necessary recoveries from them in due course.(c)Record of progress
304.
Entries of "progress" in the works abstracts should be supported by details in the statement
provided for the purpose on the reverse of the Works Abstract Form (vide Section E, Chapter X,
Public Works Account Code, First Edition, Reprint 1935). These details should be furnished by the
Engineer or Subordinate In Charge of the work or any Executive Officer or sub-ordinate detailed for
the purpose and should be based on entries already made in the measurement book. Their
compilation from measurement books, vouchers or other records, by members of the office
establishment should not be permitted. The following points should be specially borne in mind
:-(i)Only "quantities" actually measured and paid for should be reported as "progress".(ii)The
progress reported should specify the quantities executed "up to-date", sets of earlier measurement
covered or superseded by later ones being ignored.(iii)The progress of an item of work should be so
reported as to describe as approximately as possible, in terms of the unit adopted, the quantities of
work executed upto the required standard.It is recognised that perfect accuracy cannot always be
secured in making intermediate reports of progress. A fairly reliable record is all that is necessary
but if the nature of the work makes it impossible or difficult to achieve this in practice, reports of
progress may be dispensed with during the progress of construction in the following cases :-(1)If the
duration of construction under a sub-head is not expected to be more than three months.(2)If the
quantities executed are not in the same units as those specified in the estimate, or if they cannot be
expressed, even roughly, except on or towards the completion of the work.Register of
Works(a)Closing the accounts on completion of works
305.
It is important to close the accounts of work as soon as possible after the actual work of construction
is completed (See Rule 307). If there is necessarily any delay in the closing of the accounts, it should
be seen in particular, that further charges are not incurred without the permission of the Divisional
Officer.Bihar Financial Rules, 1950

306.
Before closing the accounts all outstanding liabilities should be discharged and balances in the
suspense accounts cleared.(b)Completion reports and statements
307.
A consolidated completion statement should be prepared monthly of all completed works other than
those referred to in Rule 308 the actual expenditure on which is in excess of the sanctioned estimate
by an amount greater than that which the Executive Engineer is empowered to pass. This statement
should show for each work or groups of works the estimated amount, the outlay and the excess. In
cases in which the completion statement is utilised instead of a revised estimate, sufficient details
must be given, if the excess is more than 5 per cent, to satisfy the authority whose sanction is
necessary.
308.
A detailed completion report in F.R. Form 9 need only be prepared in respect of work on which the
outlay has been recorded by sub-heads :-(i)when, if the work was sanctioned by higher authority,
the total estimate has been exceeded by more than 5 per cent; and(ii)when, if the work was
sanctioned by the Executive Engineer, the total estimate has been exceeded by an amount greater
than that which he is empowered to pass.This report should give a comparison and explanation of
differences between the quantity, rate and cost of the work executed and those entered in the
estimate, and should mention the names of the Engineers and sub-ordinates by whom the work was
supervised.The Superintending Engineer may, if he so desires, require a detailed completion report
to be prepared on the completion of any other work.
309.
If an excess over estimate is not within the Divisional Officer's power to deal with detailed
completion report in F.R. Form 10 should be prepared or the item should be included in a
consolidated completion statement of works and repairs in F.R. Form 1.1.Contractor's
LedgerScrutiny of accounts by contractors
310.
A contractor requiring a copy of his running account bill or an extract from his account in the
Contractor's Ledger should be furnished with one. He should be encouraged to look at his account in
the ledger and sign it in token of his acceptance (See also Rule 2 under Rule 280).Sundry
RulingsEmployment of Military LabourBihar Financial Rules, 1950

311.
When military labour is employed on the execution of a work, no advance should be granted by the
Public Works Department, the officer commanding the unit can obtain advances from the Controller
of Military Accounts concerned.Sale of Government land and immovable property.
312.
The rules about sale of land and of transfer of public property to a local authority for religious and
other purposes are contained in Section II of Chapter 15.Workshops(a)General
313.
No work is to be undertaken in workshops of the department other than work required for the
various branches of the department, except under some general or special order of Government.
314.
No work should be undertaken for municipalities or private parties before the whole estimated cost,
including all charges for supervision, profit, etc., that may be leviable under the rules for the time
being in force, has been paid to the Executive Engineer, or into a Government treasury to the credit
of the Public Works Department.This rule may be relaxed at the discretion of the Executive
Engineer or Superintending Engineer, in the case of Government servants where the full recovery is
not open to doubt. In such cases a rough estimate of the probable cost must be prepared in advance
and the Government servant concerned required to give an undertaking that he agrees to pay the
actual charges in full on completion of the work. In all cases prior to work being put in land, an
undertaking should be procured from the party concerned that it will not hold the department
responsible for loss by fire or theft of any other factor which could not be foreseen when the estimate
was prepared. In cases where it is found that the original estimate is likely to be exceeded
appreciably, a revised estimate should be prepared and the procedure outlined above
adopted.(b)Estimate
315.
The estimate should provide for all charges, including the prescribed percentage for indirect charges
enumerated below, and should be sanctioned by competent authority and accepted by the indenting
Government servant, local body or individual:-(a)Storage charges, under Rule 176.(b)Interest on
capital cost of building and plant and machinery.(c)Maintenance charge of buildings, plant and
machinery.(d)Depreciation of plant and machinery.(e)Establishment charges, including one per
cent on account of audit and accounts establishment.(f)Profit.The amount to be realised from the
indenting party will, however, be based on the actual cost, though the authorised limit of cost, which
the officer incharge of the workshop may incur without further authority, is that shown in the
accepted estimate.(1)If the execution of a job for another division or department is likely to extendBihar Financial Rules, 1950

beyond one financial year, the limit of the cost which may be incurred in each official year should
also be settled before hand.(2)The profit referred to in clause (f) above is not charged in jobs
executed for other divisions of the State.The percentage for storage charges should be calculated on
the book value of materials issued to each job. The other charges are ordinarily calculated on the
total cost of labour and stores pertaining to job.(c)Annual review of account
316.
The Accountant General, Bihar, reviews the annual accounts of a workshop, in consultation with the
Government servant incharge of it, and submits a report to the State Government on its financial
working, specially bringing out the necessity, or otherwise of revising the percentages fixed by the
State Government for the several charges referred to in Rule 315.To facilitate the review of
percentages it will be found convenient to show, in the profit and loss account, not only the figures
of the year but also the progressive figures to the close of the year, commencing from a suitable
date.Non-Government Works(a)Estimates
317.
For every non-Government work there must be a duly sanctioned detailed estimate or requisition, as
the case may be, in the same way as for a Government work.
318.
Outlay on Deposit Works is required to be limited to the amount of deposit received.(b)Local loan
works
319.
(a)No public department or public officer may incur any expenditure or liability against local loan
funds, unless a statement in writing is first obtained from the Accountant General, that the amount
is available out of the loan funds, and has been placed in a separate account by the Accountant
General so as to be available for the proposed expenditure. The amount so placed should be treated
as the appropriation for the work, and should not be exceeded without special orders.(b)Funds so
spent under the above rule shall reckon for interest as if they were drawn on the last day of the
month in the accounts of which they were included by the spending department or Government
servant.
320.
The limit of funds set aside for expenditure on work during the year should be ascertained from the
Accountant General, by the Government servant authorising the expenditure, and communicated to
the Divisional Officer for guidance. This limit should be treated as the appropriation for work and
should not be exceeded without special orders.Takavi Works(i)Provision of fundsBihar Financial Rules, 1950

321.
It is not imperative that the estimated cost of a takavi work shall be deposited by the person or
persons interested in the work before any expenditure is incurred on it, as, if the amount due is not
received in cash direct from them, it is recoverable through the Civil Department in the same was as
arrears of land revenue. Endeavour should however, be made to effect direct and prompt recoveries
of the probable cost of Takavi Works as recoveries through the Civil Department cause considerable
trouble and delay in adjustment.(Recovery)through the Civil Department
322.
The following procedure is prescribed for effecting recoveries, through the Civil Department, on
account of the cost of individual Takavi works not covered by cash deposits received direct from the
cultivators concerned :A certificate showing (1) the full name of the works, (2) the name and address
of the responsible cultivator or cultivators, (3) the authority for undertaking the work, (4) the total
expenditure incurred, (5) the amount (with full particulars), if any, recovered in cash, and (6) the
net amount still recoverable should be prepared in duplicate, by the Divisional Officer on the
completion of the work, and submitted to the Collector or Deputy Commissioner of the district
concerned.Section VIIIPublic Buildings(i)Fixtures and Furniture
323.
The term "Public Buildings" as used in these rules applies to buildings borne on the books of the
Public Works Department and maintained from the appropriation for Public Works in charge of
Public Works Officers.
324.
Every public building should be provided with all necessary fixtures.The periodical repair of these
fixtures should be carried out by the Public Works Department and charged to the repair estimate of
the buildings. All petty repairs of fixture and replacement of broken glass in doors and windows
required in the intervals between the periodical repairs should be carried out by the Government
servant in occupation of the building (See Appendix 7 and note 4 to Rule 400 of the Bihar Treasury
Code) and charged to his contingent accounts. The Executive Engineer will not supply nor repair
furniture, screens, purdahs or tatties, nor will he perform any of the duties specified above as
devolving on the departmental officer in charge. Furniture for new offices may, however, be
supplied by the Executive Engineer, provided the cost of such furniture is included in the estimates
of the offices concerned. This rules does not apply to furniture of travellers, rest houses, staging
bungalows or circuit houses, the outlay on the supply and repair of which will be treated as charges
of the Civil Department. For Public Works inspection bungalows, the furniture should be supplied
and repaired at the cost of the Public Works Department.Bihar Financial Rules, 1950

325.
The administration of the furniture funds of the official residences of the Governor including the
upkeep of stock list and the purchase, repair and maintenance of furniture, will be conducted by the
Government servant charged with these duties under rules issued by Government. The Executive
Engineer's duty will be to satisfy himself that the furniture is being maintained properly in good and
serviceable order. It is important that the furniture should not be allowed to deteriorate to an extent
that will give rise to large demands for renewals on change of incumbents.The detailed rules issued
by Government for the administration of the furniture funds of the official residences of the
Governor will be found in Appendix 10.(ii)Purchases and sale of Government Buildings
326.
No building may be purchased for public purposes without the orders of the State Government to
whom a survey and valuation report by the Executive Engineer of the Division should in all cases, be
submitted.
327.
Permanent public buildings, whatever be their book value, constructed from State funds may be sold
or dismantled under the orders of the State Government. The limits and conditions on which sale
and dismantlement may be conducted by sub-ordinate authorities are regulated by special orders of
delegation in this behalf.Temporary buildings erected during the construction of the work may
under the sanction, previously obtained, of the Superintending Engineer, be sold or dismantled on
the completion of the work or when the purpose for which they were erected has been
served.Superintending Engineers have been empowered to sanction the dismantling and sale of
non-residential Public buildings, the book value of which does not exceed Rs. 5,000 after
ascertaining from the local Civil Government servants that buildings cannot be put to any other
use.(iii)Hire of office accommodation
328.
[(a) When no suitable Government building is available, private building may be hired for public
purposes, the rent being paid by the public officer or department occupying it. When the building is
entirely used for office accommodation the rent is wholly chargeable to Government while when it is
partly used for office purposes and partly for residential purposes by Government servants for
whom residential accommodation is not provided elsewhere, the share of the rent payable by
Government will be proportionate to the floor area of the main building set aside solely for office use
on the following conditions :-(i)Government's share will be sanctioned in respect of building not
owned by Government on a certificate from the Executive Engineer to the effect that no Government
building is available for office purposes and that no other suitable building can be hired for the office
at lower rate of rent.(ii)The Executive Engineer shall certify that the building hired for office
purposes does not provide more accommodation than what is necessary on the basis of staff andBihar Financial Rules, 1950

other requirements of the office, and that accommodation set apart for residential purpose in the
building does not exceed the sale of accommodation to which the Government concerned is entitled
by virtue of his pay and status.(iii)The State Government will pay their share of the rent after they
have fully satisfied themselves of the genuineness of the claim in each case.(iv)When the building is
used for office-cum-residential purpose Government have an absolute right to decide the
appropriate amount of space to be utilized for office purpose.(v)After the sanction of the
apportioned rent the Government servant concerned shall not keep in his private possession any
portion of hired building set apart for office purpose.Powers of various authorities to sanction hire
of office accommodation are given in the special power of delegation in this behalf vide item 33 of
Annexure 'A' to Appendix 5 of the Bihar Financial Rules, Volume II.] [Substituted by C.S. No. 39
dated 28.9.1959.](b)The municipal tax assessed on the annual value of building in which office
accommodation is provided or on the land appertaining to them, shall be treated as separate from
the rent. If it is the local rule or custom for the tax to be chargeable to the owner, the tax for the
entire building will be paid by Government otherwise, the Government servant concerned should
pay the share of such tax corresponding with the share of the rent payable by him and Government
should be debited with the difference. See also item 45 of Annexure 'A' to Appendix 5.(iv)Use of
Government Buildings by Auxiliary Force
329.
The following principles should be observed in dealing with questions regarding the conditions on
which the Auxiliary Force should be allowed the use of buildings which are the property of the State
:-(i)If the buildings are likely to be required again by the State, they should be retained in State
Public Works charge and be repaired at the cost of Government, the Force being charged rent for the
accommodation. Any alterations or additions required by the Force should be carried out at the
expense of the State, and considered in fixing the rent.(ii)When the buildings are no longer required
by the State Government and when there is no probability of letting them to advantage, they may,
with the approval of the State Government be handed over altogether to the Auxiliary Force free of
charge. The force should then keep them in repair, and may alter or adopt them as they think fit, the
cost being met from their own funds. The site will remain the property of the State and a small
ground rent may be charged.(iii)If the buildings should in any circumstances be resumed, the State
Government, will compensate the Auxiliary Force for any expenditure they may have incurred in
alterations or additions to the buildings but not for outlay on repairs.(iv)In the case of an Auxiliary
Force ceasing to exist, buildings handed over to them free of charge will revert to
Government.(v)Register of Buildings
330.
Each Superintending Engineer will keep a register of all buildings in charge of the department
within his circle, and each Executive Engineer a similar register of all the buildings within his
division. In these registers the value of the land comprised in a property will be shown separately
from the value of the building or buildings thereon. The value of each separate structure being also
shown separately. For a purchased property the price paid will be apportioned between the various
items comprising the property e.g., land, main building, servants, compound wall, well, etc.TheBihar Financial Rules, 1950

capital value of any portion of the building which is abandoned or dismantled without replacement
should be written of the total capital value of the building.(vi)Residences for Government Servants
331.
Residences for public servants may be built or purchased by Government:-(i)When it is the
recognised duty or established custom of Government to do so;(ii)When it is necessary on public
grounds for the Government servant to reside in, or close to the locality in which his duties are
performed;(iii)When it is necessary to provide residence in parts of country where no civil station or
cantonment exists, and where a lengthened term of residence would render camp accommodation
unsuitable, e.g., buildings along lines of roads or canals, for housing of officials employed on their
construction or maintenance;(iv)When it is shown to the satisfaction of the State Government that
suitable house accommodation for Government servants whose appointments are permanent in
respect of locality is not available in the vicinity or is available only in circumstances which will be
likely to place such Government servants in an undesirable position in relation to house
proprietors.Leasing
332.
I. Before recommending the construction or purchase of a residence for the Government official,
local and departmental Government servants should always consider whether the requisite
accommodation cannot more conveniently and economically be provided by taking an existing
building on lease for such a term and on such conditions as may be appropriate. No such lease can,
however, be entered into without the express sanction of the State Government.The present and
future incumbents for whom accommodation is leased shall pay rent and taxes according to the
rules prescribed in the relevant Codes.II. Leases should ordinarily provide that the lessor will
execute all structural repairs before the building is occupied and will carry out such additions,
alterations, and repairs as are necessary to render the building habitable and suitable for the
purpose for which it is required. In the event of any addition or alteration to the building being
made subsequent to the signing of the lease at the request of the occupant and at Government
expense, the consent of the owner must first be obtained in writing unless the work is considered by
the State Government to be essential for sanitary reasons. The rent payable by the occupant in such
cases will be increased according to the prescribed rules.III. Capital expenditure under Clause II
should not be incurred when absolutely necessary and should not ordinarily be incurred when such
expenditure is likely to increase the accommodation beyond the scale considered appropriate to the
status of the occupant. [See Rule 131 of the Bihar Service Code.]
333.
When a building is rendered uninhabitable by reason of extensive repairs being in progress, or from
any other cause, partial or total remission of rent may be sanctioned by the State Government
provided that the occupant at once reports the circumstances to the Executive Engineer. The
Executive Engineer will at once inspect the building or, where this is impossible, will depute a
responsible officer to do so, and will submit a full report of the inspection to the SuperintendingBihar Financial Rules, 1950

Engineer, who will take any action considered necessary, and will then submit the case with his
recommendation to Government. Special responsibility for avoiding delay attaches to cases in which
an incoming tenant refuses to enter into occupation on the plea that white washing or repairs are
necessary before he can do so.Inconvenience caused by petty or ordinary annual repairs is
insufficient to warrant remission of rent, which should be granted only when extensive structural
repaid, justifying in the opinion of the State Government the vacation of the building, are carried
out.Note. - Superintending Engineers have been authorised to sanction remission of rent in respect
of residential buildings allotted to officers who are classed as second class or below for the purpose
of travelling allowance rules subject to the condition that the amount of rent remitted in each case
does not exceed Rs. 500.
Chapter 10
Miscellaneous Expenditure
Section IGeneral
334.
The term "miscellaneous expenditure" applies generally to all expenditure in the civil departments,
which does not fall under the category of pay and allowances of Government servants, pensions,
contingencies, grant-in-aid, contributions, stores or work.Note. - Grant-in-aid & contributions have,
however, been dealt with in this chapter for the sake of convenience.
335.
Miscellaneous expenditure is subject generally to the rules of procedure which apply to contingent
expenditure, except in so far as it may be governed by any special rules or orders made by competent
authority.Section IIRefunds of Revenue
336.
Refunds of revenue are broadly classified as-(i)refunds to which the claimants are legally entitled,
and(ii)refunds which are made ex gratia, Government being under no legal obligation to make
them.Note 1. - Refunds of revenues are not regarded as expenditure for purposes of grants of
appropriations.Note 2. - Remissions of revenue allowed before collection are to be treated as
reduction of demands and not as refunds.
337.
Remissions of irrigation revenue allowed before collection should be treated as reductions of
demands and cash repayment of such revenue after collection as outlay against the appropriation for
the head "Deduct Refunds" subordinate to Direct Receipts. All other refunds of revenue andBihar Financial Rules, 1950

repayments of "Receipts and Recoveries on Capital Account" should be taken in reduction of the
receipts under the heads concerned.
338.
Subject to the provisions of the relevant Acts and rules made thereunder the sanction necessary for
refunds of revenue will be regulated by the orders of the State Government and by departmental
rules and orders contained in departmental manuals etc.The general procedure for refunds, of
revenue and the authorities competent to sanction refunds in certain cases are given in Rules 423 to
428 and in Appendix 17 of the Bihar Treasury Code.
339.
Before a refund of any kind, otherwise in order, is allowed, the original demand or realisation as the
case may be, must be traced, and a reference to the refund should be so recorded against the original
entry in the cash book or other documents as to make the entertainment of a double or erroneous
claim impossible. Any acknowledgement previously granted should, if possible, be taken back and
destroyed and a note of the repayment recorded on the counterfoil of the receipt. "See also Rule 424
of the Bihar Treasury Code."Section IIIGrants-In-Aid, Contributions, Etc.Grants to Public Bodies
Institution, Etc.
340.
The sanction necessary for payment of grants-in-aid or contributions to education and other
institutions, local bodies and co-operative societies and of educational scholarships is regulated by
departmental rules or orders. The following instructions are issued for the general guidance of
subordinate authorities in the matter of according sanctions for grants-in-aid.Note. - For procedure
regarding disbursement of grants-in-aid, contributions, scholarships, etc., at the treasury, See Rules
429-433 of the Bihar Treasury Code.
341.
(1)Unless in any case Government direct otherwise, every order sanctioning a grant should specify
clearly the object for which it is given and the conditions, if any attached to the grant. In the case of
non-recurring grants for specified objects, the order should also specify the time limit within which
the grant or each instalment of it is to be spent.(2)Only so much of the grant should be paid during
any financial year as is likely to be expended during that year. In the case of grants for specific works
or services such as buildings, water supply schemes and the like, the sanctioning authority should
use its discretion in authorising payments according to the needs of the works. The authority signing
or countersigning a bill for grants in aid under Rule 431 of the Bihar Treasury Code, should see that
money is not drawn in advance of requirement. There should be no occasion for a rush for payment
of these grants in the month of March.(3)Before a grant is paid to any public body or institution, the
sanctioning authority should as far as possible insist on obtaining an audited statement of theBihar Financial Rules, 1950

account of the body or institution concerned in order to see that the grants-in-aid is justified by the
financial position of the grantee and to ensure that any previous grant was spent for the purpose for
which it was intended. It is not essential for this purpose, however, that the account should be
audited in every case by the Indian Audit Department and it will be sufficient therefore if the
accounts are certified as correct by a registered accountant or other recognised body of auditors. In
the case of small institutions, which cannot afford to obtain the services of a registered accountant
or the registered body of auditors, the sanctioning authority may exercise its discretion of exempting
any such institution from the submission of accounts audited in this fashion.The authority
sanctioning a grant, while communicating the sanction to the Accountant General should state
whether the audited statement of accounts has been received when required, or whether the grantee
has been exempted from submitting the statement.Note. - This order is applies both to non-official
institutions and to semiofficial ones, such as public clubs, etc.
342.
In cases in which conditions are attached to the utilisation of a grant in the form of specification of
particular objects of expenditure or the time within which the money must be spent or otherwise,
the departmental officer on whose signature or countersignature the grant-in-aid bill was drawn
should be primarily responsible for certifying to the Accountant General, where necessary, the
fulfilment of the conditions attaching to the grant, unless there is any special rule or order to the
contrary. The certificate should be furnished in such form and at such intervals as may be agreed
between the Accountant General and the head of the department concerned. Before recording the
certificate, the certifying officer should take steps to satisfy himself that the conditions on which the
grant was sanctioned have been or are being fulfilled. For the purpose he may require the
submission to him at suitable intervals of such reports, statements, etc., in respect of the
expenditure from the grants as may be considered necessary. Where the accounts of expenditure
from grant are inspected or audited locally the inspection or audit report, as the case may be, will
either include a certificate that the conditions attaching to the grant have been or are being fulfilled
or will give details of the breaches of those conditions.
343.
Unless it is otherwise ordered by Government, every grant made for a specific object is subject to the
implied conditions :-(i)that the grant will be spent upon the object within a reasonable time, if no
time-limit has been fixed by the sanctioning authority; and(ii)that any portion of the amount which
is not ultimately required for expenditure upon that object should be duly surrendered to
Government.Expenditure From Discretionary Grants
344.
When under orders of competent authority, an allotment for discretionary grants is placed at the
disposal of a particular officer, the expenditure from such grants will be regulated by general or
special orders of the State Government, specifying the objects for which the grants can be made and
any other condition that should apply to them. Such grants must be non-recurring i.e. not involvingBihar Financial Rules, 1950

any future commitments.Note. - The general orders in respect of expenditure from discretionary
grants will be found in Rules 435-441 of the Bihar Treasury Code.Other Grants
345.
Grants, subventions, etc., other than those dealt with in the foregoing rules, can be made only under
special orders of Government.Section IVCompensation to Civil Officers for Loss of Property
346.
(1)All cases in which it is proposed to grant compensation to any Civil Officers for the accidental loss
of his property should be referred to Government for orders through the Administrative Department
concerned.(2)Compensation will not ordinarily be granted to a Government servant for any loss to
his property, which is caused by an act of God as earthquake, floods, etc., or which due to an
ordinary accident, which may occur to any citizen, e.g., loss by theft or as the result of railway
accident, fire, etc. The mere fact that, at the time of the accident, the Government servant is
technically on duty or is living in Government quarters in which he is forced to reside for the
performance of his duties will not be considered as a sufficient ground for the grant of
compensation. These points should be borne in mind while submitting proposals to Government.
"See also Rule 434, Bihar Treasury Code.
Chapter 11
Rupee debt
Section 1Debt and Miscellaneous Obligations of Government
347.
In pursuance of resolutions passed by the Houses of all State Legislatures the consolidation and
amendment of the law relating to securities issued by the State Government and the management by
the Reserve Bank of India of the Public Debt of the State is regulated by the Act of the Union
Parliament, the Public Debt (Central Government) Rules, 1946 as amended.The management of the
Public Debt of the State and the maintenance of accounts relating thereto are vested in the Central
Public Debt Office, which is managed on behalf of Government by the Reserve Bank. Certain
functions of the Central Public Debt Office are entrusted to the Public Debt Office at Madras,
Bombay and Delhi, which are managed by the local Officers of the Reserve Bank. A substantial part
of the work however falls on treasuries and sub-treasuries including those of certain Indian States.
348.
The procedure to be followed in treasuries and other Government offices in dealing with securities
of rupee loans issued by Government and in making payment of interest in respect thereof isBihar Financial Rules, 1950

regulated by the provisions of the Indian Securities Act (Act X of 1920) as amended from time to
time, and the Statutory Rules (Indian Securities Rules) issued the re-under. Detailed rules, based
mostly on the Statutory Rules, referred to above and the supplementary orders issued by
Government from time to time are to be found in the Government Securities Manual, issued by
Reserve Bank under the authority of the Government of India.Note. - The Governor has decided that
unless there be anything repugnant in the subject or context, and without prejudice to the
provisions of the law and the statutory rules mentioned above, the rules in the Government
Securities Manual in so far as they deal with the procedure relating to disbursement of money from,
and payment of money into the Public Account are to be regarded as rules framed under Article 283
of the Constitution of India. Likewise, the rules in the Manual which prescribe the form of initial
accounts to be kept at treasuries in respect of payment of interest on Government Securities,
repayment of principal of terminable loans, receipt of subscriptions to new loans and of other allied
transactions and the form in which the account of such transactions are to be rendered to the
Accountant General should be regarded as direction given by the Comptroller and Auditor-General
of India with the approval of the President of India and will be subject to any directions contained in
this behalf in Volume II of the Account Code.
349.
Treasury Bills, National Savings Certificates, etc., are special forms of Government Securities, which
are issued and repaid under special rules and orders made by Government in this behalf. (See also
Rules 515 and 516 of the Bihar Treasury Code.)Section IIProvident Funds
350.
The term "Provident Funds" is strictly applicable to air 'Provident Funds" within the meaning of the
Provident Funds Act, 1925 (XIX of 1925), as amended, which have been constituted for the benefit
of Government servants. The procedure relating to the recovery of subscriptions to, and withdrawals
from, such funds will be regulated strictly in accordance with the provisions of the respective
Provident Fund Rules and the subsidiary instructions contained in Section III of Chapter VIII of the
Bihar Treasury Code.The legal aspect of the provisions in the Provident Fund Rules has been dealt
with in the "Memorandum Explanatory of Government Provident Fund Rules vis-a-vis the law on
the subject" which has been prepared by the Government of India in consultation with its legal
advisers (Appendix II). The Memorandum, as stated in the preface thereto, is not exhaustive and
exceptional cases may arise which are not covered by the instructions in the Memorandum but it
will be found useful in dealing with the generality of cases arising under the various Provident Fund
Rules.
351.
The following instructions should be carefully observed by heads of offices with a view to the correct
preparation of the Fund Schedules referred to in Rule 524 of the Bihar Treasury Code :-(i)A
complete list of subscribers to each fund should be maintained in each disbursing office in the form
of the Schedule.(ii)Each new subscriber should be brought on this list and any subsequent changeBihar Financial Rules, 1950

resulting from his transfer or in the rate of subscription, etc., clearly indicated.(iii)Except where it is
otherwise provided in the rules of the fund concerned, changes in the monthly rates of subscription
will be permissible only from the first of April, each year, i.e., with effect from the pay for March
drawn in April.Note. - Subscribers are permitted to increase the rate of subscription only once at any
time during the course of the financial year.(iv)When a subscriber dies, quits the service or is
transferred to another office, full particulars should be duly recorded in the list.(v)In the case of the
transfer of a subscriber to another office, the necessary note of transfer should be made in the list of
both the offices.(vi)From this list the monthly Schedule to be appended to the pay bill should be
prepared and agreed with the recoveries made before the submission of the bill to the treasury for
payment.Section IIIService and other fundsIndian Civil Service Family Pension Fund.Superior
Services (Indian) Family Pension Fund.Indian Civil Service (Non-European Members) Provident
Fund.Postal Insurance Fund.
352.
Contributions, donations, etc., recoverable, and pensions and other benefits payable, in respect of
the funds specified above will be regulated in accordance with the rules of the respective funds and
the subsidiary instructions contained in Section III, Chapter VIII and Rule 522 of the Bihar Treasury
Code.
353.
Subscriptions to Family Pensions or other fund not under Government management may not be
received in cash or by deduction from pay or pension bills except under special orders of
Government. (See Rule 523 of the Bihar Treasury Code).Note. - It must be distinctly understood
that in the case of the General Family Pension Fund, the Hindu Family Annuity Fund and the
Bengal Christian Family Pension Fund, Government exercises no supervision over the management
of the Funds and is in no way responsible for their solvency.
354.
A detailed list of the subscriptions realised in cash on behalf of each fund showing the date and
amount of each receipt and the name of the person on whose behalf it is paid in, should be
submitted by the Treasury Officer to the Accountant-General with the cash account of each
month.This list will be a copy of a register maintained in the treasury.
355.
The deposit accounts of these funds on the Government book will be credited with interest at such
rates and at such intervals as may be prescribed by Government in each case.Note. - Except in the
case of the Bengal Uncovenanted Service Family Pension Fund, an important difference with regard
to interest is made between subscriptions paid by deduction from pay bill and subscriptions paid in
cash, no interest being allowed for the month of payment on cash subscriptions received after theBihar Financial Rules, 1950

4th of the month, whereas subscriptions deducted from a bill bear interest as though they had been
received on the 1st of the month.
Chapter 12
Local Funds
Introductory
356.
(1)The transactions of local funds (as defined in Rule 573 of the Bihar Treasury Code) are not
included as such in the Public Account, except in so far as their cash balances may be deposited with
Government under Rule 575 of Bihar Treasury Code and accounted for under the deposit head
"Deposits of Local Funds." The function of Government in regard to such deposits is that of a bank.
(See Rule 576 of the Bihar Treasury Code.)(2)The main classes of local funds are-(i)District
Funds;(ii)Municipal Funds;(iii)Union Committees and Union Boards' Fund; and(iv)Other
Miscellaneous Funds.Note. - The expression "local body" as used in this Chapter means the
authority legally entitled, or specially empowered by Government to administer a local fund.
357.
The financial transactions between Government and local bodies will be regulated by the following
rules and by such other general and special orders as may be issued by Government in this
behalf.Grants to Local Bodies
358.
The payments of the various classes of grants to local bodies will be governed by general instructions
contained in Rules 340 to 343 and by such special orders as may be issued by Government in regard
to each class of grant.Loans to local bodies
359.
The detailed procedure to be followed in connection with the grant of loans to local bodies will be
regulated by the provisions of the Local Authorities' Loans Act and other special Acts and by rules
made thereunder (See also Rule 370).Charges Recoverable From Local Bodies
360.
Unless any of the following arrangements have been authorised by Government, a local fund should
be required to pay in advance the estimated amount of charges to be in curred on cost of services to
be rendered by Government on account of the Fund :-(i)payments as made by Government may beBihar Financial Rules, 1950

debited to the balance of the deposits of the local fund in Government books;(ii)recovery from the
local fund may be postponed till the time when Government has to make payment for the
charges;(iii)payments may be made as advances from Government funds in the first instance,
pending recovery from the local fund.Note. - In cases where a local fund has to pay for medicines
supplied but its liability cannot be accurately known within the year owing to the account of supplies
not being available from the Supplying Department by the 31st March, the local' fund concerned
should be required to pay during March, a sum roughly estimated as the value of the medicines, any
short or excess recovery being re-adjusted in the following year.
361.
Any amount due to Government by a local body, including any amount overdue for payment in
respect of a loan is subject to recovery by adjustment from any non-statutory grant sanctioned for
payment to it. The authority signing or countersigning a bill for such a grant should see that this rule
is observed as far as practicable.Revenue Collected on behalf of local bodies
362.
Unless it be expressly authorised by law, proceeds of taxes, fines or other revenue levied or collected
by Government may not be appropriated direct to a local fund without passing them through the
general revenue account of Government, whether or not such taxes, etc., are earmarked from the
start for the purposes of the fund.
363.
Subject to the provisions of relevant Acts and rules made there under, the adjustments with local
bodies in respect of revenue and other money raised or received by Government on their behalf will
be made in such manner and on such dates as may be authorised by general or special orders of
Government.Use of Service Postage Stamps
364.
The Government of India have ruled that service postage stamps may not be used by a local fund
officer or any Government officer acting in a capacity connected with a local fund such as Chairman
or Secretary of a local fund authority), but they may be used on the correspondence of a public
officer acting as such, even though the correspondence relates to the affairs of a local body.Note. -
Telegraphic messages, the charges for which are to be borne by local funds, should be classified as
"Private" and not as "State".Audit of Accounts
365.
Subject to the provisions of any law or rule having the force of law, the accounts of local bodies will
be audited by the Indian Audit Department under general agreement reached between the StateBihar Financial Rules, 1950

Government and the Comptroller and Auditor General of India.The agreement extends also to the
accounts of other non-Government bodies or institutions, which, under any general or special order
of Government, have to be audited through Government agency.
366.
Audit fees on the basis of daily rates prescribed by Government from time to time will be charged for
the audit by the Indian Audit Department of the accounts of local and other non-Government funds,
excluding funds for the audit of which the rates of fees recoverable are prescribed by law or by rules
having the force of law.Nothing contained in this paragraph shall be held to override any special
instructions of Government exempting any particular local body or institution wholly or partly from
the payment of audit fees.Elimination of Pies
367.
Except in respect of dues fixed by or under any law or under any special order of Government,
financial transactions between Government and local bodies should be rounded off to the nearest
'anna, six pies', and over being treated as one whole anna and amounts less than six pies being
omitted.(See also Rule 145 of the Bihar Treasury Code.) [ Now Paisa.]
Chapter 13
Loans and Advances
Section 1Introductory
368.
Loans and advances made by the State Government fall under the following main head :-A. Interest
bearing loans and advances :-(i)Loans to local funds, private individuals, etc. These
comprise-(1)Loans to Municipalities.(2)Loans to District Boards and other Local Fund
Committees.(3)Loans to Land-holders and other Notabilities.(4)Loans to cultivators under various
Acts.(5)Advances under special laws.(6)Miscellaneous loans and advances.Advances to Government
servants for purchase of conveyances, etc.B. Interest free advances :-(i)Advances
repayable-comprising mostly miscellaneous advances to Government servants for various public
purposes.(ii)Permanent advances.Note. - Although advances to Government servants for journeys
on tour and for certain miscellaneous purposes e. g. the advances mentioned in Rule 431 are debited
to the service heads concerned, they have been dealt with in this and the following chapter for the
sake of convenience.
369.
The rules in this chapter should be observed generally by all departments, etc., in making loans andBihar Financial Rules, 1950

advances of public money, unless there be any special rule or order of Government to the
contrary.Section IIGeneral RulesSanction
370.
Except as otherwise provided in any departmental rules or orders, loans and advances to local funds
and private individuals under clause A (i) of Rule 368 require the sanction of Government. Advances
to Government servants are regulated by rules in Chapter relating to Miscellaneous Advances of
these Rules. Permanent advances are dealt with in Rule 112.Estimates
371.
Provision should be made in the budget for all loans and advances which can be foreseen.
Estimating and Controlling Officers should make timely estimates both of the gross advances and
recoveries of the coming year and include them in their annual estimates for submission to the
proper authorities concerned.Conditions of Repayments
372.
Recovery of the amounts advanced to Government servants is governed by detailed instructions laid
down in Rules 386 and 405 et seq.
373.
The following general instructions apply to all loans and advances to local bodies, etc., other than
advances to cultivators, etc. which are governed by special rules, and subject to the provisions of
relevant Acts or rules made thereunder, the conditions under which the loans are granted should be
regulated accordingly -(i)A specific term should be fixed which should be as short as possible, within
which each loan or advance should be fully repaid with interest due. The term may in very special
cases extend to 30 years.(ii)The term is to be calculated from the date on which the loan is
completely taken up or declared by the competent authority to be closed.(iii)The repayment of loans
should be effected by instalments, which should ordinarily be fixed on a half-yearly basis, due dates
for payment being specifically prescribed.(iv)Instalments paid before the due date will be taken
entirely to principal unless, of course, any interest for a preceding period is overdue.
374.
When a loan of public money is taken out in instalments, the first half yearly repayment should not
be demanded until six months after the last instalment is taken; meanwhile simple interest only
should be realised. But should it appear that there is an undue delay on the part of the debtor in
taking out the last instalment of a loan, the authority sanctioning the loan may at any time declare
the loan closed, and order repayment of capital to begin. The Accountant General will bring to notice
any delay that appears to him to require this remedy and he will take this step whether there are anyBihar Financial Rules, 1950

dates fixed for taking of instalments or not.Note 1. - If, in any case particular dates have been fixed
for the payment of interest, or the repayment of instalments of a loan, then such repayments should
not begin until the second of the half yearly dates so fixed, after the loan has been completely taken
up, simple interest only being recovered on the first half-yearly date after the completion of the loan.
For example, supposing a loan, the interest on which is recoverable half-yearly to be completely
taken up on 31st March and the interest to be payable on 30th June and 31st December, the first
half-yearly instalment in repayment of principal will not be due until 31st December following
simple interest only will be due on the intermediate 30th June.Note 2. - These instructions are
applicable mutatis mutandis to loans the repayments of which are made by other than half-yearly
instalments.Note 3. - It must be remembered that the calculation fixing the amount of equal
periodical instalments, by which an advance is repaid with interest presupposes, punctual payment
of the instalment and that, if any instalment is not punctually repaid, the fixed instalment will not in
the end discharge the loan.
375.
Borrowers should be required to adhere to strictly to the terms settled for the loans made to them.
Modifications of these terms in their favour can be made subsequently only for very special
reasons.Interest
376.
(1)Interest should be charged at the rate prescribed by Government for any particular loan or for the
class of loans concerned.(2)A loan bears interest for the day of advance, but not for the day of
repayment. Interest for any shorter period than a complete half-year should be number of days
calculated as
number of days365| x yearly rate of interest, unless any other method of calculation is prescribed in
any particular case or class of cases.
Defaults In Payments
377.
(1)Any default in the payment of interest upon a loan or advances or in the repayment of the
principal, will be promptly reported by the Accountant General to the authority which sanctioned
the loan or the advance. On receipt of such a report the authority concerned should immediately
take steps to get the default remedied.Note. - The responsibility of the Accountant General under
this rule refers only to the loans the detailed account for which are kept up by him. (See Rule
380).(2)The authority which sanctions a loan may, in so far as the law allows, enforce a penal rate of
compound interest upon all overdue instalments of interest or principal and interest. If a penal rate
is enforced it should not except under special orders of Government, be less than 8 percent per
annum.Revenue Department ReturnsBihar Financial Rules, 1950

377A.
(a)With every return of revenue advances made to the Revenue authorities a memorandum should
be submitted setting forth the figures of the treasury plus and minus account and agreeing them
with the figures of the return.(b)The Accountant-General, will at the close of every half year's
accounts, send to the Board of Revenue a return in such form as may be agreed on, showing the
figures that pass upon his books in respect of revenue advances.The object of the statement is to
enable the Board of Revenue to check reconciliation prescribed in clause (a).Irrecoverable Loans
and Advances
378.
A competent authority may remit or write off any loans or advances owing to their irrecoverability
or otherwise. (See Rule 63).
379.
In respect of Revenue and other advances, for the detailed control, accounting and supervision of
which departmental officers are responsible, it is the duty of the departmental authorities
concerned, as soon as any such advance is ascertained to be irrecoverable, to take the necessary
steps to get it written off the accounts under the sanction of competent authority, and to advise the
Accountant General in order that he may make the necessary adjustment in the Accounts.
Irrecoverable advances written off should nevertheless be registered by the departmental authorities
in a separate account or record, in order that any possible eventual recovery may be made.Accounts
and Control
380.
Subject to such general or specific directions as may be given by the Comptroller and Auditor
General in this behalf, detailed accounts of individual loans and advances other than those
mentioned below will be maintained by Accountant-General who will watch their recovery and see
that the conditions attached to each loan or advance are fulfilled. In the case of Revenue and other
advances mentioned in Rules 607 and 611 of the Bihar Treasury Code, the responsibility for
supervision, accounting and control devolves upon the departmental authorities and detailed rules
and instructions governing them are contained in the departmental regulations.Annual Returns
381.
Government receive an annual report upon outstanding loans from the Accountant General, for
purposes of review. The statement is submitted in F.R. Form 12 not later than the 20th September of
the following year.Bihar Financial Rules, 1950

Chapter 14
Advances to Government Servants
Section 1General
382.
The following rules regulate the grant of advances to Government servants and others. In cases not
covered by these rules or by the rules in Chapter 13 advances cannot be made except under the
special orders of the State Government.
383.
It is not permissible to sanction an advance which involves a breach of any of the basic principles
laid down in Rule 9. In any case where a cash grant would be within the powers of sanction of a
particular authority, the grant of an advance not exceeding the cash grant will not require the
sanction of a higher authority.
384.
Simple interest will be charged on advances granted to Government servants for house building,
purchase of motor cars, motor cycles and other conveyances and for purchase of type-writers, or
tents and in certain circumstances, for the payment of special passage advances made in England by
the High Commissioner for India and for passage overseas. The rate is fixed from time to time with
reference to the borrowing rate of the State Government. The interest will be calculated on balances
outstanding on the last day of each month.Note 1. - In cases where pay bills for a month are
disbursed before the end of the month an instalment in payment of an advance received through the
pay bill will be taken as having been refunded on the first of the following month, the normal date
for the disbursement of pay.Note 2. - If in any particular case any advance is drawn in more than
one instalment the rate of interest will be determined with reference to the date on which the first
instalment is drawn.
385.
Rules 389 to 430 do not ordinarily apply to Government servants who are not in permanent
Government employ. As the pay of such Government servants does not constitute adequate security
for a loan, advances should not ordinarily be granted to them. In special cases, however, if the
circumstances admit of provision of adequate security advances may be granted in accordance with
the terms of these rules to officiating or temporary. Government servants without any substantive
appointment under the [general] [Inserted by C.S. No. 1 dated 18.4.1958.] or special sanction of
Government in the Finance Department.Bihar Financial Rules, 1950

386.
All advances are subject to adjustment by the Government servants receiving them in accordance
with the rules applicable to each case. When an advance is adjustable by recovery, the amount to be
recovered monthly should not be affected by the fact of the borrowing Government servant going on
leave of any kind with leave salary or his drawing subsistence grant. The sanctioning authority may,
in exceptional cases, order a reduction in the amount of the monthly instalment provided that in the
case of interest bearing advances to Government servants the whole amount due should be
completely recovered within the period originally fixed.
387.
In the case of interest bearing advances to Government servants an authority empowered to deal
with an application for an advance, should not issue an order of sanction until the Accountant
General has certified that funds are available in the year in which the payment of the advance will be
made.Section IIInterest Bearing AdvancesSub-Section (1) - House Building Advances
388.
With the sanction of the State Government advances may be granted to Government servants who
desire to build houses for occupation by themselves, at places where no house are available or where
house rent is exceptionally high. No advance is permissible for the construction of a house except at
the place in which the Government servant is actually serving or at which he is permitted to reside
while performing the duties at his headquarters station. Also no advance is permissible to a
Government servant who is likely to retire before complete recovery can be effected.[Note 1. -
Administrative Departments of Government can sanction advances under this Section without
consulting the Finance Department, Secretaries to Government (including the Chief Secretary) and
Heads of Department are also authorised to sanction such advances which are in strict accordance
with the rules, to Government servants whom they or other heads of offices sub-ordinate to them
can appoint. In the case of Deputy Magistrates and Deputy Collectors the power to sanction house
building advances is exercised by the State Government. ['Note' made Note 1 and Note 2 added by
C.S. No. 52 dated 9.6.1958.]Note 2. - The pay, service condition viz. permanent or temporary and
the date of birth of the grantee of the advance should invariably be mentioned in the sanction order
to facilitate audit check and issue of authority slip by the Accountant General, Bihar.][N.B. -
Reference may be made to State Government's Decisions under Rule 403.]
388A. [ [Added by C.S. No. 61 dated 29.8.1967.]
A Government servant in foreign employee shall also be granted advance for house building
purposes as admissible under this sub-section but in this case the advances would be met from the
funds of his foreign employer and would be sanctioned by the State Government on the
recommendation of the foreign employer.The advances so granted shall be subject to the same
terms and conditions as would apply to the Government Servant if he were serving directly underBihar Financial Rules, 1950

Government. In special cases where a Government Servant's services have been lent to a foreign
employer whose financial position will not permit of the advance for house building purposes being
met from its funds, the advance may, under the special orders of the State Government, be met from
Government funds.]Note 1. - An advance under this rule will be sanctioned subject to the same
terms and conditions applicable to other Government servants who are not in foreign service. The
Government servants concerned will remain directly responsible for the regular payment of the
instalment till the recovery of the advance together with the interest. Government will sanction the
advance after obtaining the consent of the foreign employers that they will make prompt recoveries
of monthly instalments of advance from the pay of the Government servant in case it is noticed from
the challan handed over to the foreign employers that the instalment of a particular month has not
been deposited into the Treasury. Necessary recoveries will also be made by the foreign employers
from the Government servant concerned if the Accountant General takes steps under Rules 218 to
221 of the Bihar Treasury Code. Vol. I. The Government servant to whom the advance is sanctioned
will deposit the monthly instalment of repayment in the local Treasury with quadruplicate challans
classified under the head"766 Loans and advances by State Government - Advances to Government
Servants for house building purposes". Two copies of the challan will be obtained from the Treasury
Officer concerned and given to the foreign employer. One of the two copies received by the foreign
employer should be retained by the foreign employer for record in his office and the other should be
sent to the Accountant General, Bihar with a statement to be sent every month showing the Name(s)
and designation(s) of the Officers(s), amount(s) of advance(s) drawn, the amounts(s) deposited
during the month towards repayment of the advance(s) and balance(s) due [Substituted by
Classification of Budget.]Note 2. - Pay for the purpose of this rule will mean the pay which the
Government servant would been have drawn had he remained in the service of Government and not
in foreign service.
389.
All such advances must be bona fide required for the purpose of building suitable houses for the
personal residences of the Government servants concerned, and if more is advanced than shall be
actually expended for the purpose, the surplus shall be refunded to Government.
390.
An advance shall not exceed eighteen months' pay of the Government servant to whom it is made;
not more than one advance shall be made for the same house; and no Government servant may
receive a second advance while any portion of a previous advance with interest accrued thereon is
outstanding against him. (Pay means pay as defined in Rule 34, Bihar Service Code).[N.B. -
Reference may be made to State Government's Decisions under Rule 403.]
391.
The advances should be drawn by instalments the amount of each instalment being such as is likely
to be required for expenditure in the next three months. Satisfactory evidence should be produced to
show that the amount of the instalment has been actually utilised for the purpose for which it wasBihar Financial Rules, 1950

drawn before the next instalment is paid.The repayment shall commence from the fourth issue of
pay after the first instalment is taken and be completed in five years.[N.B. - Reference may be made
to State Government's Decisions under Rule 403.]
392.
Advances will be recovered by the deduction of monthly instalments, equal to one-sixth part of the
total advance, from the pay bills of the Government servants concerned. The authority sanctioning
an advance may however, permit recovery to be made in a smaller number of instalments if the
Government servant receiving the advance so desires.The amount of interest calculated in
accordance with Rule 384 will be recovered in one or more instalments, each such instalment being
not appreciably greater than the instalments by which the principal was recovered.The recovery of
interest will commence from the month following that in which the whole of the principal has been
repaid.Note. - The amount of the advance to be recovered monthly should be fixed in whole rupees
except in the case of the last instalment when the remaining balance including any fraction of a
rupee should be recovered.
393.
In order to secure Government from loss consequent on a Government servant dying or quitting the
service before complete repayment of the advance with interest accrued thereon in accordance with
Rule 384, the house so built together with the land it stands upon, must be mortgaged to
Government by whom the mortgage will be released on liquidation of the full amount due.Note. -
The mortgage bond will be prepared in F.R.Form 13 and the reconveyance in F.R. Form 15.
394.
The Government servant must satisfy the sanctioning authority regarding his title to the land upon
which the house is or is proposed to be built.Note 1. - This rule does not preclude the grant of an
advance to a person who does not possess full proprietary rights in the land upon which he intends
to build, provided the sanctioning authority is satisfied that the applicant has a lease of which the
unexpired portion is of a term and value sufficient to justify the grant of the advance and that there
is no danger of the lease lapsing or of Government being unable to dispose of it, should it become
necessary to foreclose the mortgage. In examining the mortgagor's title care should be taken to see
that the lease does not prevent any sub-demise by the lessee (the mortgagor). The mortgage bond in
such cases will be prepared in F.R. Form 1.Note 2. - In cases in which ground rent Municipal taxes
and similar dues are payable to local authorities on account of and taken on lease, the sanctioning
authority may, at its discretion ask the Government servant taking the advance to produce for the
inspection receipts for these payments within fifteen days of their falling due. If the sanctioning
authority finds that such dues have not been paid by the borrower steps may be taken to recover the
said dues including interest thereon, if any, from the pay of the Government servant concerned for
payment to the parties concerned.Bihar Financial Rules, 1950

395.
The applicant's title to the property should be examined by the sanctioning authority before the
advance is actually paid, in cases where there is any doubt as to the validity of that title, the Revenue
and Registration authorities or, if technical legal advice is necessary the Law Officers of
Government, should be consulted. It should be seen that in the case of a house-building advance, he
has undisputed title to the land on which it is proposed to build and that, in the case of an advance
for the purchase of a house, he will obtain such title as soon as the purchase price is paid; that there
will be no legal obstacle in either case to the property being mortgaged to Government, and that
Government will have the right of foreclosing on the conditions mentioned in the mortgage bond.
396.
The head of the office in the case of a non-Gazetted Government servant and the controlling officer
in the case of a Gazetted Government Servant should, when asking for the authority for payment
(vide Rule 603 of the Bihar Treasury Code) send to the Accountant General a certificate either in the
bill in which the advance is drawn, or separately, to the effect that the mortgage bond in F.R. Form
13 has been executed by the Government servant taking the advance and that it has been duly
registered.
397.
A Government servant quitting or removed from the station where he has built a house, before the
whole amount due has been liquidated, will continue liable to the deductions of his monthly
instalments until the advance with interest accrued thereon in accordance with Rule 384 has been
repaid; but, with the special sanction of the State Government he may be allowed to dispose of the
house, provided he is thereby enabled to clear off at once the whole amount due, or to transfer it or
to any Government servant of his own or higher rank, the future deductions being made from the
pay of such Government servant.
398.
Applications for advance must be made through the applicant's departmental superior, who will
record his opinion as to the necessity for the assistance solicited. The applicant must certify that the
sum is to be expended in building only, and pledge himself that, should there be any surplus funds
after the house is completed, they will be at once refunded to Government.
399.
The last pay certificate granted to Government servants under advances must specify the original
amount of such advance, the amount repaid and the balance together with interest accrued thereon
remaining due.Bihar Financial Rules, 1950

400.
Advances may also be given where considered necessary, for the purchase of land on which to
construct a house, if the other conditions laid down in the foregoing rules are satisfied and the total
amount of the advance for purchase of the land and the construction of the house does not exceed
forty five month's pay of the Government servant concerned.The Government servant should sign
an agreement in F.R. Form 16 at the time of taking an advance for the purchase of land and the
amount should not exceed what is required for the purpose. A mortgage deed in F.R. Form 17 should
be carefully executed before any further advance is drawn for the purpose of constructing the
house.The mortgage deed must be registered within four months of its execution.In order to save
Government from loss, the applicant's title to the property should be carefully examined by the
sanctioning authority and the instructions laid down in Appendix 12 should be followed.[It was
raised to "thirty six months" from 18 months by Memo No. A2-4041/61/11891 F1, dated 17.9.1962
and again raised to "forty five" months by Memo No. A2-40262/66-3522 F, dated 31.5.1968.]
401.
An advance may be made to a Government servant for the purchase of a house (including the costs
of effecting repairs and improvements to it), the general principles of the foregoing rules about
house building advances being applicable, and the Government servant being required in addition
to a mortgage deed, to deposit with Government satisfactory evidence of a clear title to the
house.Note 1. - The advance may be drawn in full at once, but satisfactory evidence should be
produced before the Accountant General to show that the amount advanced for the purchase has
been spent within three months of its drawal and the amount advanced for repairs or improvements
within a further period of two months. A certificate to this effect from the head of the office will
ordinarily suffice. The repayment in the case shall commence with the first issue of pay after the
advance is taken and be completed in five years. Interest will be calculated in accordance with Rule
384 and the recovery thereof, will be made as laid down in Rule 386.Note 2. - When asking for the
authority for payment of the advance (vide Rule 603 of the Bihar Treasury Code), the Controlling
Officer should record on the bill a certificate to the effect that he has secured and retained with him
an agreement in F.R. Form 16 signed by the applicant pending execution of the final mortgage bond
in F.R. Form 13, after the house is actually purchased. The fact of execution and registration of the
latter bond should also be intimated to the Accountant-General as soon as possible.[N.B. -
Reference may be made to State Government's Decisions under Rule 403.]
402.
An advance may also be given for the purpose of repaying a private loan taken by Government
servant expressly (i) for the purchase of land for building a house or (ii) for the purchase of a house,
provided:(1)that the usual conditions specified in Rules 400 and 441 are satisfied;(2)that the
applicant has through his private loan acquired an unencumbered title to the land or the house
purchased; and(3)that the original loan for the purchase of the land or the house, as the case may
be, was taken not more than twelve months before the date of receipt of the application for an
advance to discharge the private debt.Bihar Financial Rules, 1950

403.
An Advance may be made under the following rules to a Government servant to enable him to effect
repairs to his house-I. An advance may be made only if (1) the repairs are required to make the
house habitable, (2) they are not in the nature of ordinary repairs and (3) they involve an outlay
large in comparison with the value of the house.II. Not more than one advance is admissible in
respect of the same house.III. No advance shall exceed nine months' pay of the Government servant
to whom it is made, and it will be drawn as laid down in Rule 391.IV. An advance may be made to a
Government servant to repair a house which he has built or purchased with a previous advance
under Rules 388 or 401, but unless the State Government permits otherwise, at least five years must
elapse since the previous advance was drawn.V. Subject to the above, the general principles of Rules
388 to 400 or 401 as the case may be, shall apply, the maximum period for repayment of such
advances being two and a half years. Interest will be calculated and recovered in accordance with
Rule 392.Note 1. - An advance for repairs of a house is admissible even if it was not built or
purchased out of an advance taken from Government.Note 2. - Instructions laying down the
procedure to be followed in dealing with applications for advances for the construction, purchase or
repair of houses are contained in Appendix 12.Sub-Section (2) - Advances For Purchase of Motor
Cars
404.
The State Government may sanction an advance to a Government servant for the purchase of a
motor car if they consider that it is in interest of the public service that the Government servant
should use a car in the discharge of his duties.[Note. - Advances under this rule may also be granted
to the officer engaged on contract basis subject to the following conditions :- [Inserted by C.S. No.
49 dated 27.4.1961.](i)The amount of advance together with interest thereon should be repaid by
them in full before the expiry of the period of contract. In order to ensure this, the rate of recovery of
the advance should be so fixed that the advance together with interest thereon is recovered at the
time of issue of the last pay of the officer. In all such cases the renewal of contract at the end of the
prescribed period of contract should not be taken for granted while fixing the number of instalments
of recovery.(ii)The advance should be sanctioned to these officers subject to the production of surety
of a permanent State Government servant of comparable or higher status.(iii)Other terms and
conditions for grant of such advances contained in this sub-section (2) will remain unaltered.]
405.
The total amount to be advanced to a Government servant for purchase of a motor car shall not
exceed [Rs. 60,000,] [Enhanced from Rs. 40,000 to Rs. 60,000 by Memo No. 10-A/A2-27/84/1560
F., dated 28.4.1984. Rs. 40,000 enhanced from Rs. 25,000, Rs. 25,000 enhanced from Rs. 20,000/-
and twenty four months from eighteen months respectively. Initially the provision of Rs. 12,000 was
enhanced to Rs. 15,000 by C.S. No. 43 dated 11.8.1960 and again enhanced to Rs. 20,000 by C.S.
No. 63 dated 1.4.1969.] or [twenty-four months'] [Substituted by Memo. No. A2-102/66/6567 FI
dated 30.7.1965.] pay, or the anticipated price of car whichever is less. If the actual price is less than
the advance taken the balance should forthwith be refunded to Government.[Note 1. - For thisBihar Financial Rules, 1950

purpose "pay" includes"special pay" "personal pay", "cost of living allowance" and emoluments
especially classed as "pay".] [Substituted by C.S. No. 43 dated 11.8.1969.][Note 2. - Government
servant whose pay is less than [Rs. 2,000 per month] [Substituted by Memo No. A2-102/66/6567 FI
dated 30.7.1965.] inclusive of cost of living allowance, will not be eligible for the grant of motor car
advances except in very exceptional cases where relaxation of this rule may be necessary on public
grounds.]Note 3. - The pay limits mentioned in the rule and note I will not be relaxed except in very
special circumstances for reasons to be recorded in writing.Note 4. - For the purposes of an advance
drawn in England in respect of a motor car, "actual price" will also include, in cases in which the
advance drawn included estimates of these charges, the amount of freight actually paid on the car up
to an Indian port, the cost of its insurance during the voyage and the customs duty paid in India.
406.
(1)A Government servant who is on leave or about to proceed on leave for whom an advance has
been approved by the State Government will not be allowed to draw the advance earlier than a week
before the expiry of the leave; but a Government servant who is on leave elsewhere than in India,
Burma, Nepal, Ceylon, Pakistan and Aden, or is about to proceed on such leave may be allowed to
take it from the High Commissioner six weeks before his departure for India.(2)A Government
servant taking an advance from the High Commissioner within six weeks of his departure for India
under sub-clause (1) may include in the amount of the advance required, charges separately
estimated on account of freight on the motor car to an Indian port and of the customs duty thereon
payable in India, as also the cost of its insurance during the voyage. In the case of an officer who
purchases a car in Europe prior to six weeks of his departure back to India, no advance will be
allowed to be drawn in England but on bringing the car into India such a Government servant may
apply for an advance to cover the price of the car as valued in India for customs purposes (which will
include the freight), and the cost of insurance plus the customs duty paid on the car. The customs
receipt should be produced in both cases.Note. - A Government servant who purchases a car in
Europe prior to six weeks of his departure back to India and who does not hold a post for which a
motor car has been definitely recognised by Government to be necessary, should, if he proposes to
apply for an advance on return to India, inform the State Government of his intention and obtain
their consent before he brings a car to India.The clause relating to drawal of a motor car advance
from the High Commissioner of India, London, should be treated as having been held in abeyance
until further orders.[Government of India, Ministry of Finance No. F-50 (13) - EV/52. dated the 6th
June, 1952.]
407.
[The amount of advance will be payable in more than [one hundred consecutive] [Substituted by
C.S. No. 21 dated 15.5.1958. Note 2 below Rule 407 deleted and Note I made Note by this C.S.]
monthly instalments equal to one thirty six part of the advance from the pay bill of the Government
servant concerned and [shown in a separate Schedule in F.R. Form 17A] [Added by C.S. No. 50
dated 27.4.1961.], It will commence from the first issue of pay after the advance is drawn. A
Government servant may however if he so desires be permitted to repay the advance in a smaller
number of instalments or he may pay more than one instalment at a time. The amount of interestBihar Financial Rules, 1950

calculated in accordance with rule 384 will be recovered in one or more instalments by which the
principal was recovered. The recovery of interest will commence from the month following that in
which the whole of the principal has been repaid.]Note. - The amount of the advance to be recovered
monthly should be fixed in whole rupees except in the case of the last instalment when the
remaining balance including any fraction of a rupee should be recovered.
408.
Except when a Government servant proceeds on leave not being leave on average pay not exceeding
four months or privilege leave/earned leave not exceeding 90 days or any other leave which is
treated as equivalent to leave on average pay not exceeding four months, or retires from the service
or is transferred to an appointment the duties of which do not render the possession of a motor car
necessary, the previous sanction of the State Government is necessary to the sale by him of a car
purchased with the aid of an advance which with interest accrued has not been fully repaid. If a
Government servant wishes to transfer such a care to another Government servant who performs
the duties of a kind that renders the possession of a motor car necessary the State Government may
permit the transfer of the liability attaching to the car to the latter Government servant provided
that he records a declaration that he is aware that the car transferred to him remains subject to the
mortgage bond and that he is bound by its terms and provisions.
409.
In all cases in which a car is sold before the advance received for its purchase from Government with
interest accrued thereon has been fully repaid, the sale proceeds must be applied, so far as may be
necessary, towards the repayment of such outstanding balance. Provided that when the car is sold
only in order that another car may be purchased the State Government may permit a Government
servant to apply the sale proceeds towards such purchases, subject to the following
conditions:-(a)the amount outstanding shall not be permitted to exceed the cost of the new
car;(b)the amount outstanding shall continue to be repaid at the rate previously fixed;(c)the new car
must be insured and mortgaged to Government as required by these rules.
410.
A Government servant may be allowed advances to purchase more than one car at a time if it can be
shown that such action is clearly desirable in the public interest and provided that the total amount
outstanding at any one time by way of such advances against a particular Government servant does
not exceed the limit within which advances may be given.
411.
A Government servant who draws an advance in India, for the purchase of a motor car is expected to
complete his negotiation for the purchase and to pay finally for the car within one month from the
date on which he draws the advance; failing such completion and payment, the full amount of theBihar Financial Rules, 1950

advance drawn with interest thereon for one month, must be refunded to Government. At the time
of drawing the advance the Government servant will be required to execute an agreement in F.R.
Form 18 and on completing the purchase, he will further be required to execute a mortgage bond in
F.R. Form 19 hypothecating the car to the Government of Bihar as security for the advance. The cost
price of the car purchased should be entered in the schedule of specifications attached to the
mortgage bond. In the case of advance drawn in England, similar agreement and a personal security
bond in the form prescribed by the Government will be executed at the time of drawing the advance
and at the time of purchase, respectively.[Note 1. - The following procedure should be followed when
an officer intends to purchase a new car out of the advance sanctioned to him :- [Inserted by C.S.
No. 51 dated 27.4.1961.](i)Furnishing of security at the time of registration as prospective purchaser
as required under the Motor Car {Distribution and Sales) Control Order of 1959, will be the
responsibility of the officer concerned; no advance will be given to him from Government Funds in
this respect.(ii)The request of the officer to the Accountant General, Bihar for issue of authority for
drawal of the advance should indicate whether he is going to purchase a new or an used car. In the
case of former, it should be accompanied by a written assurance from the dealer and a certificate
from the Officer who countersigns his travelling allowance bill that the supply to be available within
a month. A certificate to this effect should also be recorded on the body of bill for the drawal of
advance.(iii)In the event of any delay in supply despite the written assurance referred to at (ii)
above, the Officer concerned should apply for extension for the time limit within the permissible
limit of one month and seek permission for retaining the advance for a further period which should
be specified. Each request should be supported with a letter from the dealer concerned indicating
the likely period of supply and will be considered on its own merits.Note 2. - The procedure
contained in note I above will not apply to the case in which Government servants purchase used
cars with the help of the advance, where the conditions laid down in the main rule will apply.]
412.
The order sanctioning an advance will remain valid for only six months from the date of issue.
413.
(1)A Government servant to whom an advance is sanctioned shall execute an agreement in F.R.
Form 18 which should be presented at the treasury along with the bill for drawing the advance. The
Treasury Officer shall scrutinise the agreement before payment is made and forward the same, after
payment has been made, to the head of the department concerned, or, if the Government servant
drawing the advance is himself the head of department or is serving under the direct control of the
Government; to the administrative department of Government concerned. The Treasury Officer
should at the same time record on the bill, for purposes of audit, a certificate to the following
effect:-"Certified that the requisite agreement has been executed in the proper form and presented
before me with the bill and I have forwarded the same to the..........The Treasury Officer should also
report to Government in the Finance Department the date on which the advance has been drawn
and in doing so he shall also state that the requisite agreement has been forwarded to the head of
the department/administrative department of Government concerned.The head of the department
or the departments of Government may destroy the agreement when a mortgage bond executed inBihar Financial Rules, 1950

the prescribed form is furnished by the Government servant drawing the advance.(2)In the case of
advances drawn in England a similar agreement and a personal security bond in the prescribed form
will be executed at the time of drawing the advance and at the time of purchase
respectively.[Similarly all grantees of the motor car advance shall report the fact of drawal to the
Finance Department and the Accountant General, Bihar, simultaneously within three days of the
date of drawal of the amount from the treasury.] [Added by C.S. No. 52 dated 27.4.1961.]
414.
The mortgage bond referred to in Rule 411 should be executed within one month from the date of
receipt of the advance and sent through the head of the department or the administrative
department concerned to the Accountant General who will transmit it to the Inspector General of
Registration, Bihar for safe custody.
415.
(1)The car must be insured against full loss by the fire, theft or accident. Insurance on owner-driven
or other similar qualified terms is not sufficient for purpose of this rule. Insurance policies at a
reduced rate of premium shall, however, be accepted as adequate in cases where-(a)the owner of the
car undertakes to meet [up to the first Rs. 250] [Substituted for 'Rs. 50' by C.S. No. 54 dated
12.6.1961.] or so of a claim preferred against an insurance company in the event of an accident;
or(b)the car is not insured against accident for any season of the year during which it is not in use
but is stored in a garage.(2)[ Such insurance should be effected from the date of purchase of the car.]
[Substituted by C.S. No. 40 dated 4.12.1959.](3)A clause as in F.R. Form 20 should be inserted in all
policies of insurance in respect of motor car purchased by Government servants with the help of
advances taken from Government. All officers of Government taking advances for purchase of
vehicles should disclose to the insurer the fact of the vehicle having been purchased with the help of
such advances and also have the clause referred to inserted in the policies of insurance of such
vehicles. The vehicle should in no case, be insured with Insurance Companies which do not agree to
include the clause in the policy.(4)On receipt of the certificate prescribed in Rule 413 the Accountant
General will obtain from the Government servant drawing the advances a letter to the Motor
Insurance Company with whom the motor car is insured to notify to them the fact that the State
Government are interested in the insurance policy secured. He will himself forward this letter to the
Company and obtain their acknowledgment. In the case of insurance effected on annual basis the
process prescribed above shall be repeated every year until the advance has been fully repaid to
Government.(5)Contravention of these orders will render the Government servant liable to refund
the whole of the amount advanced with interest accrued unless good reason is shown to the
contrary. The amount for which the car is insured during any period should not be less than the
outstanding balance of the advance with interest accured at the beginning of that period and the
insurance should be renewed from time to time until the amount due is completely repaid. If at any
time and for any reason the amount insured under a current policy is less than the outstanding
balance of the advance, including interest already accrued, the Government servant should refund
the difference to Government. The amount to be refunded must be recovered in not more than three
monthly instalments.Bihar Financial Rules, 1950

416.
Advances for the purchase of motor cars to Government servants in foreign employ should be
granted from the funds of the foreign employer and when the latter desires to make such advance,
he should apply to the State Government for the necessary sanction. If the sanction is accorded it
will be subject to the proviso that the advance by the foreign employer shall be regulated by the
same conditions as would apply if the Government servant were serving directly under Government.
[* * *] [Lines beginning with words 'In special cases' and ending with word 'necessity' deleted by C.S.
No. 42 dated 12.7.1960.]
416A. [ [Inserted by C.S. No. 42 dated 12.7.1960.]
In special cases where a Government servant's service have been lent to a foreign employer whose
financial position will not permit of the advance for the purchase of a motor car being met from its
funds, the advance may under the special order of the State Government be met from Government
funds provided that the Government servant's duties are such as to render the possession of a motor
car practically a necessity.Note 1. - An advance under this rule will be sanctioned subject to the same
terms and conditions as applicable to other Government servants who are not in foreign service. The
Government servant concerned will remain directly responsible for the regular payment of the
instalment till the recovery of the advance together with the interest. Government will sanction the
advance after obtaining the consent of the foreign employers that they will make prompt recoveries
of monthly instalment of advance from the pay of the Government servant, in case it is noticed from
the challan handed over to the foreign employers that the instalment of a particular month has not
been deposited into the Treasury. Necessary recoveries will also be made by the foreign employers
from the Government servant concerned if the Accountant General take steps under Rules 218 to
221 of the Bihar Treasury Code, Vol. I. The Government servant to whom the advance is sanctioned
will deposit the monthly instalments of repayment in the local Treasury with quarduplicate challans
classified under the head [766 - Loans and Advances by State Government - Advances to
Government servants - Advances for the purchase of Motor conveyances']. Two copies of the challan
will be obtained from the Treasury Officer by the officer concerned and given to the foreign
employer. One of the two copies received by the foreign employer for record in his office and the
other copy should be sent by it (the foreign employer) to the office of the Accountant General, Bihar
with a statement to be sent every month showing the name (s) and designation (s) of the officer (s),
amount (s) of advance (s) drawn, the amount (s) deposited during the month towards repayment of
the advance (s) and the balance (s) due.Note 2. - Pay for the purpose of this rule will mean the pay
which the Government servant would have drawn had he remainded in the service of Government
and not in foreign service.]
417.
The grant of an advance for the purchase of a motor car to a Government servant who proceeds on
deputation out of India and desires a motor care for use during his deputation is not
admissible.Application Form For Advance For The Purchase of Motor Car/motor Cycles.Bihar Financial Rules, 1950

1. Name of applicant (in full)
2. Applicant's designation
3. District and Station
4. Whether permanent or temporary
5. Pay
(i)Substantive pay(ii)Officiating pay drawn in temporary post(iii)Special/Personal pay(iv)Cost of
Living Allowance
6. Anticipated price of motor car/motorcycle
7. Amount of advance required
8. Date of superannuation or retirement or date of expiry of contract in case
of a contract officer
9. Number of instalment in which the advance is desired to be repaid
10. Whether advance for similar purpose was obtained previously and if so-
(i)date of drawal of the advance(ii)the amount of advance and/or interest thereon still outstanding if
any.
11. Whether the intention is to purchase-
(a)a new or an old motor car/cycle(b)if the intention is to purchase motor car/ motor cycle through
a person other than a regular or reputed dealer or agent, whether previous sanction of the
competent authority has been obtained as required under Rule 15(2) of the Bihar Government
Servant (Conduct) Rules.
12. Whether the officer is on leave or is about to proceed on leave
(a)The date of commencement of leave(b)The date of expiry of leave
13. Are any negotiations or preliminary enquiries being made so that delivery
may be taken of the motor car/motor cycle within one month from the date of
drawal of the advance?Bihar Financial Rules, 1950

14. Special reason, if any
15. (a) Certified that the information given above is complete and true.
Sub-Section (3) - Advances For Purchase of Motor Cycles
418.
An advance for the purchase of a motor cycle may be sanctioned by the State Government to a
Government servant whose substantive pay does not exceeds Substituted for 7000 by Memo No.
10A-A2-27/84/1559 F, dated 28.4.1984. Earlier 7000 [Rs. 1,200] [Substituted for 5000 by Memo
No. A2-101/79/3993 F., dated 22.3.79 and 5000 Substituted for Rs. 3,000 by F.D. Memo No.
A2-102/76-4060 F. dated 16.4.1976.], The amount of the advance should not exceed [Rs. 10,000]
[Substituted for 5000 by Memo No. A2-101/79/3993 F., dated 22.3.79 and 5000 Substituted for Rs.
3,000 by F.D. Memo No. A2-102/76-4060 F. dated 16.4.1976.] or the anticipated price whichever is
less. If the actual price paid is less than the advance taken, the balance should be forthwith refunded
to Government.[Note. - Advance under this Rule may also be granted to the Officers engaged on
contract basis subject to the conditions applicable to grant of advance for purchase of motor cars to
such Officers vide 'Note' below Rule 404.] [Inserted by C.S. No. 53 dated 27.1.1961.]
419.
The general Rules and conditions prescribed in sub-section (2) above relating to advances for
purchase of motor cars apply mutatis mutandis to advances for purchase of motor cycles as well
[except Rule 405] [Inserted by C.S. No. 36 dated 22.8.1959.].[Sub Section 3(A) - Pony Advance To
The Sub-Inspectors of Police [Inserted by C.S. No. 22 dated 15.5.1958.]
419A.
An advance upto a maximum of Rs. 400 for the purchase of a pony may be sanctioned by the State
Government to a Sub-Inspector of Police on the following Rules and conditions :-(i)The application
for advance should reach the State Government through proper channel.(ii)The advance will be
interest bearing and the interest will be charged at the rate prescribed by the Government from time
to time.(iii)If the actual price of the pony paid is less than the advance taken, the balance should
forthwith be refunded to the Government.(iv)The pony purchased with the advance will be
considered the property of the Government until the advance together with the interest thereon is
fully paid.(v)Recovery of the advance will be made in thirty-six monthly instalments, and the
interest accruing thereon at the prescribed Rules should be repaid in one or two additional
instalments.(vi)Recovery of the advance will commence from the first issue of pay after the advance
is drawn.(vii)No advance will be granted to those who are due to reach the age of superannuation
within three years.]Sub-Section (4) - Advances For Purchase of BicycleBihar Financial Rules, 1950

420.
All heads of department and all Secretaries to Government are authorised to sanction advances for
purchase of bicycles to Government servants under their control subject to the following Rules and
conditions :-(i)Advance should be granted only to permanent Government servants in superior
service. But in exceptional cases, an advance may also be allowed to temporary Government
servants in superior service whose term of employment is sufficiently long, and the circumstances
admit of the provision of adequate security for due recovery of the advance.[Note. - [Collectors]
[Added by C.S. No. 17 dated 26.3.1958.] are empowered to sanction advances under this Rule to the
non-Gazetted Government servants under their administrative control.](ii)No advance will be given
to a Government servant whose pay exceeds [Rs. 375.] [Inserted by C.S. No. 22 dated
15.5.1958.][Note. - For this purpose "pay" will not include Cost of living Allowances.] [Added by C.S.
No. 17 dated 26.3.1958.](iii)The amount of advance shall be limited to three months' pay of the
Government servant concerned subject to a [minimum of Rs. 250] [Added by C.S. No. 17 dated
26.3.1958.], and maximum of Rs. 375. In case of temporary Government servants the amount of
advance should be limited to two month's pay or [Rs. 250] [Inserted by C.S. No. 67 1.5.1969.]
whichever is less.(iv)If the actual price of the cycle is less than the advance taken, the balance should
forthwith be refunded to Government.Note. - Production of receipts or cash memos, showing the
actual price of the cycle purchased with the advance to the head of office where the Government
servant obtaining the advance is employed should invariably be insisted upon by the authorities
sanctioning a cycle advance to Government servant under their administrative control.(v)Recovery
will be made by deducting monthly instalments equal to one twenty-fourth part of the advances
from the pay-bill of the officer concerned except in case of temporary Government servants in whose
case the recovery should be made in not more than 12 monthly instalments. Recovery will
commence from the first issue of pay after the advance is drawn.Note. - The provision of Note 1 to
Rule 407 apply mutatis mutandis to the recovery of advances granted under this Rule.(vi)No
advance shall be given to a Government servant who has obtained a cycle advance previously until
after the lapse of seven years from the date of the last drawal.(vii)No advance shall be given to those
who are due to reach the age of superannuation within three years.(viii)Advances should not be
granted to Government servants who are bound by Rules to keep a pony or who possess a motor car
or a motor cycle.(ix)The bicycle purchased with the advance will be considered to be the property of
Government until the advance is fully repaid.(x)The advance will be interest bearing and the interest
will be charged at the rate prescribed by Government from time to time.Note. - The amount of
interest recoverable under Rule 384 shall be recovered in one instalment after the principal has
been repaid.
420A. [ [Added by C.S. No. 16 dated 26.3.1958.]
Advances for the purchase of bicycle to permanent class IV Government servants may be sanctioned
by the authorities competent to sanction such advances to Government servants in superior service
subject to the following Rules and conditions :-(i)The amount of advance shall be limited to six
months pay of the Government servant or [Rs. 200] or the price of the cycle purchased whichever is
less.(ii)Recovery will be made by deducting monthly instalments equal to the one thirtieth part of
the advance from the pay of the Government servant concerned together with interest accruingBihar Financial Rules, 1950

thereon at the prescribed rate in one or two additional instalments. Recovery shall commence from
the first issue of pay after the advance is drawn.(iii)The pay of the Government servant and the fact
that he holds permanent post should invariably be stated in the order sanctioning the
advance.(iv)Other terms and conditions prescribed in Rule 420 above shall mutatis mutandis apply
in cases of advances to permanent class IV Government servants.]Note 1. - Collectors are
empowered to sanction advance to permanent class IV Government servants under their
administrative control.Note 2. - No advance under this Rule should however, be sanctioned to a
Government servant who has been provided with a Government cycle.
421.
In making an application for advance for purchase of a bicycle a Government servant will state what
means of conveyance he possesses. In forwarding the application the superior officer should satisfy
himself that the applicant does not already possess a serviceable bicycle.
422.
A specimen form in which an advance for purchase of a bicycle may be sanctioned after suitable
modification is given in F.R. Form 21.Sub-Section (5) - Passage Advances
423.
Special Rules for the grant of advances of pay for passages overseas of certain Government servants
of non-Asiatic domicile and their families are laid down in Appendix 13.Note. - Special passage
advance, made in England by the High Commissioner for India at his discretion to enable
Government servants to return to duty should be recovered in 36 monthly instalments and bear
interest at the rate fixed by Government. [See Rule 384.]Sub-Section (6) - Advances For Purchase of
Tents
424.
Superintending Engineers may sanction advance to the Engineering sub-ordinates for the purchase
of a tent on the first occasion of their requiring one; such an advance should be limited to a
reasonable amount and should be recovered in twelve equal monthly deductions from pay
commencing three months' after the date of the advance.Note. - These advances will bear interest at
the usual rate, vide, Rule 384.Sub-Section (7) - Advances for Purchase of Typewriters
425.
An advance of Rs. 336 may be made to any judicial officer (Deputy Magistrate or Munsif) who
wishes to purchase a typewriter on the understanding that this advance will be recovered by
twenty-four consecutive monthly deductions of Rs. 14 each from the officer's pay. All applications
for sanction to such advances should be submitted through District Magistrates or District Judges toBihar Financial Rules, 1950

the State Government.Note. - These advances will bear interest at the usual rates, vide Rule 384.
426.
The following Rules will in future govern the grant of advances for the purchase of typewriters for
copyists :-(i)The head of an office desiring to purchase a typewriter for the use of a copyist in his
office may apply to the State Government through the Divisional Commissioner or the District
Judge, as the case may be for sanction to the grant of an advance not exceeding Rs. 320 for the
purpose.(ii)In his application for an advance the head of the office will, after an examination of the
past figures showing the total monthly fees derived from copies for a sufficiently long period, state
whether the proceeds from copying fees will in his opinion be sufficient to provide the necessary
minimum remuneration (Rs. 50) for an additional typist.(iii)Every advance will be recovered in
twenty-four monthly instalments by deduction from the remuneration of the typist for whom the
machine is purchased who will be held responsible for its maintenance in good order.(iv)If a typist
for whom a machine has been purchased by means of an advance leaves Government service or is
appointed to a different post before the advance has been fully repaid, he may be allowed the option
of removing the typewriter on payment in full of the outstanding instalments, or transferring it,
together with the obligation to meet outstanding instalments to his successor in receipt from the
latter of a sum of money calculated on fair valuation of the machine.(v)The head of the office on
whose application the advance is granted will be responsible to Government for its due
repayment.As an increase in the number of typists will result in a decrease in the total number of the
copying staff, the conversions of copyists into typists should be effected with discretion and no
application for an advance which, if granted, would necessitate the dismissal of another copyist not
otherwise liable to removal should be recommended for sanction.
426A. [ [Inserted by C.S. No. 45 dated 17.11.1960.]
Advance of an amount not exceeding Rs. 600 in each case may be sanctioned by Divisional
Commissioners, District Judges or District Magistrates, as the case may be, to copyists and typists
intending to purchase Hindi typewriters for preparing copies or Hindi documents in their offices,
subject to the following terms and conditions:-(a)The copyist and typist applying for the advance
should have been serving as a copyist and typist at the place from where he applies for the advance,
for a period not less than three years.(b)His average income from remuneration of typing and
copying work should not be less than Rs. 60 per month.(c)He will be required to furnish a surety
from a permanent Government servant for the entire amount of advance together with interest due
on it. The permanent Government servant, who stands as surety, will have to execute a bond in F.R.
Form 21-A. The bond should be executed in duplicate and one copy of the same should be forwarded
to the Audit Office along with the sanctioning order while the other will be retained by the
sanctioning authority.(d)The advance shall be repayable in not more than 50 monthly instalments
and shall be recovered from the remuneration of the copyists and typists. The amount of interest
due shall be realised in one, and, if the sanctioning authority so orders, in two instalments.(e)So
long as the amount with interest is not fully repaid the typewriter shall remain Government property
and the surety's responsibility for the amount of advance with interest shall continue.(f)If the
copyist and typist goes away to some other place, or give up his work as copyist and typist in theBihar Financial Rules, 1950

particular Court, he may transfer the typewriting machine to another copyist and typist for which
order in writing of sanctioning authority shall have to be obtained.(g)The copyist or typist to whom
a typewriter is transferred as in clause no. (f) shall have to furnish afresh surety for the balance of
the advance remaining unpaid at the time of such transfer.The surety bond shall be executed and
other conditions shall remain the same, as in the case of a surety furnished at the time of purchasing
a new machine by the copyist and typist who has transferred the machine.(h)The machine should be
made available for inspection by the sanctioning authority or any officer authorised by him for the
purpose, and, it shall be the responsibility of the copyist and typist whom the advance has been
sanctioned or to whom the typewriter machine has been transferred by the person to whom the
advance was sanctioned, to keep it in proper and workable condition.]Section IIIInterest Free
AdvancesSub-Section (1) - Advances On Transfer
427.
An advance may be allowed to Government servant under orders of transfer, up to an amount not
exceeding one month's substantive pay plus the travelling allowance to which he may be entitled
under the Rules in consequence of the transfer. Such advances may be sanctioned by the head of the
office or by any other sub-ordinate officer to whom the power may be delegated. The advances
should be recorded on the Government Servant's last pay certificate. The advance of pay should be
recovered from the pay of the Government servant in not more than three monthly instalments the
recovery commencing from the month in which the Government servant concerned draws full
month's pay or/and leave salary on joining his new appointment.The advance of travelling
allowance should be recovered in full on submission of the Government servants travelling
allowance bill.[Note 1. - All heads of offices and controlling officers are empowered to grant
advances under this Rule to officiating and temporary Government servants.] [Added by C.S. No. 12,
dated 17.1.1958 Existing Notes 1 to 7 made, Notes 2 to 8 by ibid.]Note 2. - Authorities competent to
sanction advances under this Rule may sanction such advances for themselves also, [but when the
controlling officer or head of office who is competent to sanction an advance to himself is a
temporary officer such advance can be sanctioned to him by his immediate superior officer and not
by himself] [Added by C.S. No. 12, dated 17.1.1958 Existing Notes 1 to 7 made, Notes 2 to 8 by
ibid.].Note 3. - An advance under this Rule is also admissible to a Government servant who receives
orders of transfer during leave.Note 4. - This Rule does not preclude the grant of a second advance
to a Government servant to cover the travelling expenses of any member of his family who follows
him within six months from the date of his transfer and in respect of whom an advance of travelling
allowance has not already been drawn.Note 5. - When a single lump sum advance is drawn to cover
the travelling expenses both of the Government servant himself and of his family, it may be adjusted
by the submission of more than one bill if it so happens that the members of the Government
servant's family do not actually make or complete the journey with him. In such a case, the
Government servant should certify on each adjustment bill submitted by him that a further bill in
respect of travelling allowance of the members of his family (to be specified) who have not yet
completed the journey will be submitted in due course and is expected to include an amount not less
than the balance of the advance left unadjusted in this bill.Note 6. - The advance of pay under this
Rule may be allowed to be drawn at the new station soon after the arrival of the Government servant
there, on production of the last-pay certificate showing that no advance was drawn at the oldBihar Financial Rules, 1950

station.Note 7. - The amount of the advance to be recovered monthly should be fixed in whole
rupees, the balance being reserved in the last instalment.Note 8. - Advances to Government servants
"moving between Patna and Ranchi with the headquarters of the State Government are regulated by
the Ranchi Rules. (Appendix 5, Bihar Travelling Allowance Rules).[Note 9. - Advances to
Government servants on transfer to foreign service may be sanctioned by the authorities competent
to sanction the transfer. The reimbursement of the advance to the State Government by the Foreign
Employer should be made in lump sum by sending a cheque or Demand Draft in favour of the
Accounts Officer on whose books the advance is generally booked. [Inserted by C.S. No. 59 dated
8.8.1963.]Advance of a pay to a Government servant on his reversion from foreign service should be
granted by the Foreign Employer from the funds of the Foreign Employer only after consultation
with the authority competent to sanction the transfer of the Government servant to foreign service.
As for the repayment of the advance to the Foreign Employer, immediately on receipt to a demand
from the Foreign Employer, duly supported by the cash receipt obtained from the officer concerned
at the time of the Bank Draft, may be debited in the accounts under the head "S - Deposits and
advance - Part III - Advances not bearing interest - Departmental Advance - Civil Advance -
Objection books advance." The recovery of the advance should be watched in the same manner as in
case of advance of pay sanctioned to a Government servant under rule above. Since the T.A. for the
return journey on Government servant's reversion to Government service is to be borned by the
Foreign Employer, the advance of T.A. granted by the Foreign Employer in this regard may be
adjusted only on the Government servant furnishing the T.A. bill, which should be sent straight to
the Foreign Employer.]Sub-Section (2) - Advances on Return from leave or Deputation Out of India
428.
An advance may be made to a Government servant on return from leave or deputation elsewhere
than in India, Ceylon, Nepal, Burma, Aden, Pakistan and foreign possessions in India, of an amount
not exceeding two months' substantive pay or Rs. 1,000 whichever is less, in addition to any advance
made in England, provided that the leave was not leave on average pay not exceeding four months
or any other leave equivalent thereto (see Rule 408) and that no advance has been drawn under
Rule 423.Note. - The advance under this Rule may be drawn under the orders of the
Accountant-General from any treasury in Bihar to be specified in such orders. Such advances as well
as similar advances made in England are recoverable by monthly instalments of one-third of pay
fixed in whole rupees.Sub-Section (3) - Advances For Journeys On Tour
429.
Advances for journeys on tour may be made under the Rules specified below;-(i)To a Government
servant, other than an Inspecting Officer, proceeding on tour, up to an amount sufficient to cover for
a month his contingent charges, such as those for the hire of conveyances or animals for the carriage
of records, tents or other Government property, subject to adjustment upon the Government
servant's return to headquarters or 31st March, whichever is earlier.Note. - Advances under this
sub-clause may be granted by heads of offices but they should not be applied to the expenditure of
any Gazetted Government servant, except that of a Government servant of the Forest Department
which is meant to be covered by his travelling allowance.(ii)[ To a Government servant proceedingBihar Financial Rules, 1950

on tour, of an amount sufficient to cover his personal travelling expenses for a month, subject to
completion of the tour on 31st March, whichever is earlier. [Substituted by C.S. No. 5 dated
22.6.1956.]Note 1. - (i) Advances under this sub-clause may be granted by heads of office to officers
sub-ordinate to them.(ii)Such advances may be sanctioned to themselves by all officers declared to
be their own controlling officers.(iii)Such advances to heads of offices, who were not their own
controlling officers, may be sanctioned be the respective controlling officers.][Note 2. - All heads of
offices and controlling officers are empowered to grant advances under this Rule to officiating and
temporary Government servants also like permanent Government servants, except when the
controlling officer or head of the office who is competent to sanction an advance to himself is a
temporary officer, such advances can be sanctioned to him by his immediate superior officer and not
by himself. [Inserted by C.S. No. 13.]Note 3. - A second advance cannot be made to a Government
servant under this Rule until an account has been given of the first.A Government servant who has
taken an advance under this Rule for any particular journey may not take payment of travelling
allowance or other bills drawn in respect of the same journey while the advance or any portion of it
still remains unadjusted.Note 4. - Subject to the restrictions specified above advances under this
Rule may be granted in all cases of journeys in respect of which travelling allowance is admissible as
for a journey on tour.]
430.
Advances may be granted by the Collector to a Treasury Officer, or Superintendent of Police for
expenses connected with a remittance of treasure to be adjusted when the duty is completed.
431.
Advances are permissible for expenditure on law-suits to which Government is a party. Such
advances are sanctioned by the Legal Remembrancer and Commissioners of Divisions and other
officers empowered to do so. The expenditure on law-suits is regulated by Rules 108 to 121 of the
Bihar and Orissa Practice and Procedure Manual, 1939.Note. - Advances under this Rule are treated
as final charges not as advances recoverable and are to be drawn and accounted for as contingent
charges.
432.
An advance of half a month's pay is permissible to each accepted recruit of the Police Department
under the Rules of the Police Manual. No special sanction of the State Government, or the Inspector
General of Police is necessary. The advance is recoverable from the pay of the recruit in two monthly
instalments. This concession applies also to recruits for the Military Police Companies at Ranchi and
Bhagalpur.
433.
Advances to patients proceeding to a Pasteur Institute are regulated by Rules in Appendix 14.Bihar Financial Rules, 1950

Chapter 15
Miscellaneous Subjects
Section ISecurity Deposits
434.
Rules regarding the security of Treasurers in district treasuries and the form of security bond to be
executed by Treasurers are given in Rules 57 and 58 of the Bihar Treasury Code. The following
instructions apply generally to security to be taken from other officials entrusted with the custody of
cash or stores.
435.
Subject to any special rule or order made by Government in this behalf every cashier, store-keeper
and other subordinate who is entrusted with the custody of cash or stores, should be required to
furnish security, the amount being regulated according to circumstances and to local conditions in
each case under the sanction of competent authority, and to execute a security bond setting forth the
conditions under which Government will hold the security and may ultimately refund or appropriate
it.Note 1. - Other general rules on the subject will be found in Chapter X of the Bihar Board's
Miscellaneous Rules, 1947. The rules in that Chapter are applicable mutatis mutandis to all
departments of Government which have no special rules of their own on the subject.Note 2. - For a
list of competent authorities referred to in this Rule see Annexure A to Chapter 2.
436.
When a Government servant who has furnished security takes regular leave or is deputed to other
duty, the Government servant who is appointed to officiate for him should be required to furnish the
full amount of security prescribed for the post, unless the head of the department concerned has
authorised a relaxation of the Rules regarding security applicable to his case.
437.
Whenever a private person or firm contracts with Government to supply stores or execute a work, he
or it should unless exempted by the [prior concurrence of Finance Department] [Substituted by
Memo No. A3-10151/58-943F, dated 14.3.1969.], be required to give security for the due fulfilment
of the contract and suitable provisions regarding the security should be incorporated in the
agreement.Section IITransfer of Government Land and BuildingBihar Financial Rules, 1950

438.
Except as expressly provided otherwise in any Rule or order made by Government, no land
belonging to Government may be sold or made over to a local authority, private party or institution
for public, religious, educational or any other purpose, except with the previous sanction of
Government.
439.
When any immovable public property is made over to a local authority for public, religious,
educational or any other purposes, the grant should be made expressly on the conditions in addition
to any others that may be settled, that the property shall be liable to be resumed by Government if
used for other than the specific purposes for which it is granted and that should the property be at
any time resumed by Government, the compensation payable therefor shall in no case exceed the
amount, if any, paid to Government for the grant together with the cost, or their present value,
whichever may be less, of any buildings erected, or other works executed, on the land by the local
authority.Note. - The orders regarding the alienation of land and assignment of land revenue which
is to be distinguished always from the alienation of the land itself are contained in Chapter VIII,
Rules 167-173 of the Government Estates Manual, 1941.
440.
All land, the property of Government, should ordinarily be sold when necessary, through the
Revenue Department.
441.
(1)The transfer of Government land or building from one department of the State Government to
another is regulated by Rule 327 of the Bihar Treasury Code.(2)The transfer of land and buildings
between the Union and the State Governments is regulated by the provisions of Articles 256, 257
and 298 of the Constitution of India and subsidiary instructions issued by the Central Government
which are reproduced in Appendix 15. (Transfer of lands and buildings between the Central and the
State Governments.)Section IIIInsurance of Government property
442.
The normal policy of Government is not to insure its properties and no expenditure should be
incurred without the prior consent of the Finance Department on the insurance of any Government
property.Section IVCharitable Endowments and other TrustsBihar Financial Rules, 1950

443.
General instructions relating to charitable Endowments and other Trusts are embodied in the Bihar
Trust Fund Rules, First Edition, 1947.Payment of arrear Claims to persons not in Government
service
444.
The provisions of Rule 143 et seq of the Bihar Treasury Code apply mutatis mutandis to old claims
preferred against Government by persons not in Government service.(See also Rule 143, Note 5 of
the Bihar Treasury Code.)Supply of Forms
445.
The Deputy Superintendent, Government Printing incharge of Press and Forms, Gaya, maintains
stock of the standard Forms which are prescribed for use by Government offices, and which are to
be printed and supplied by Government. Heads of offices and other Government servants should
send their indents to him, subject to the observance of the procedure prescribed in the Bihar Forms
Rules.Destruction of Records
446.
The general Rules for destruction of records are contained in Annexure B to Chapter 2. Special Rules
applicable to particular departments are prescribed in the respective departmental manuals.
Chapter 16
Government Accounts
Section IGeneralForm of Accounts
447.
The form in which and the general principles and methods according to which the accounts of
Government should be kept have been prescribed by the Comptroller and Auditor-General of India,
with the approval of the President of India and the main directions in respect thereof are contained
in Volume I of the Account Code. Volumes II and III of that Code embody the directions of the
Comptroller and Auditor-General of India, regarding the form of initial and subsidiary accounts to
be kept in treasuries and by officers of the Public Works and the Forest Departments. Detailed rules
and instructions relating to the forms of the initial and subsidiary accounts to be kept and rendered
by officers of the technical departments whose accounts are not finally settled through the treasury
accounts, may be laid down in the departmental regulations relating to the departments
concerned.Major, Minor and other Heads of AccountsBihar Financial Rules, 1950

448.
The structure of the accounts consists mainly of the following divisions :-(a)Major heads.(b)Minor
heads.(c)Sub-heads.(d)Primary units(e)Secondary units(f)Detailed heads.Intermediate heads of
account known as sub-major heads, are sometime introduced between a major head and a minor
head under it when the minor heads are numerous and conveniently be grouped together under
such intermediate heads. In similar circumstances minor heads are divided into sub-heads (group
heads).
449.
A list of authorised major and minor heads of account is given in Appendix 2 of the Account Code,
Volume I. The introduction of any new major or minor head as well as the abolition or change of
nomenclature of any of the existing heads requires the approval of the Comptroller and Auditor
General.The opening of a new sub-head or a detailed head in the Demands for grants will be
sanctioned by the Finance Department according to administrative requirements after consultation
with the Accountant-General. As regards heads of expenditure, the subdivisions of minor heads will
follow as far as possible the subheads and other units of appropriation selected by the Finance
Department for Demands, for Grants and Appropriation Accounts.
450.
In the matter of accounting and for control of expenditure, the nomenclature of the budget cum
accounts heads should be strictly followed by departmental officers. Whenever provision made in
the budget estimate or in any order of appropriation does not conform to the prescribed head or
unit, the corresponding receipt or expenditure should be accounted for against the particular head
or unit under which the provision has been made or the appropriation has been communicated by
competent authority unless there be strong reasons for a contrary course, e.g., when such
accounting would be contrary to law. All such cases should be brought to the notice of the Finance
Department so that in the estimates of the following year the error may be rectified, unless the
Finance Department agrees to give effect to the correct classification in the accounts of the current
year because of the magnitude of the amounts involved or because the mis-classification affects the
accounts of commercial departments or allocation between Capital and Revenue heads.
451.
Changes in nomenclature of account or budget heads or in the classification of receipts or
expenditure will not be introduced in the course of a financial year except under special orders of
Government.Responsibility of Departmental OfficersBihar Financial Rules, 1950

452.
Every officer responsible for the collection of Government dues or expenditure of Government
money should see that proper accounts are maintained in such form as may have been prescribed
for all financial transactions of Government with which he is concerned and render accurately and
promptly all such accounts and returns relating to them as may be required by Government, the
Accountant-General or the controlling authority concerned. It is essential that all accounts should
be so kept and the details so fully recorded and that the initial records of payments, measurement
and transactions in general are so clear, explicit and self-contained as to be produceable, where
necessary, as satisfactory and convincing evidence of facts.Note 1. - The classification on bills should
be recorded by the drawing officers. Similarly, the classification on challans should be recorded by
the officers responsible for the collection of Government dues and making the remittance to the
treasuries. In cases of doubt the classification in the accounts may at the outset follow the budget,
but the matter should be referred to Government for orders in any case of doubt.Note 2. - The
responsibilities of disbursing officers, controlling officers and heads of departments in regard to the
control over expenditure incurred against the grants allotted to them are laid down in Rule 471 et
seq and in the Bihar Budget Manual.Section IICapital and Revenue Accounts General Rules
453.
Expenditure of a capital nature is broadly defined as expenditure incurred with the object of either
increasing concrete assets of a material and permanent character or of extinguishing or reducing
recurring liabilities, such as those for future pensions by payment of commuted values. Expenditure
on a temporary asset cannot ordinarily be considered as expenditure of a capital nature.
454.
Expenditure of a capital nature as defined above, incurred upon a scheme or project may not,
however, be classed as capital expenditure in the Government accounts unless the classification has
been expressly authorized by general or special orders of Government. Ordinarily, such
classification will not be permitted unless-(i)it is essential for the exhibition of financial results of
any special service or undertaking on the basis of generally accepted commercial principles, or in
some other conventional manner, either that the cost of the service or undertaking may be
ascertained or that the full implications of any policy may be clearly demonstrated; or(ii)the
expenditure involved is so large that it cannot reasonably be met from ordinary revenues.Note. - The
term "ordinary revenues" is applied to revenues derived from taxes, duties, fee, fines and similar
items of current Government income including extraordinary receipts, if any, as distinct from
receipt that are of a capital, or debt, deposit and banking character.
455.
When it has been decided by Government that the expenditure on a scheme for the creation of a new
or additional asset should be classed as capital expenditure, and that separate capital and revenueBihar Financial Rules, 1950

accounts should be kept of such a scheme, the allocation of expenditure to capital and revenue
should be determined in accordance with such detailed rules as may be prescribed by Government
according to the circumstances of the department or undertaking in which the expenditure is
incurred. The following are the main principles applicable to the treatment of the expenditure in the
estimates and accounts: -(i)Capital bears all charges for the first construction and equipment of a
project as well as charges for intermediate maintenance of the work while not yet opened for service
and bears also charges for such further additions and improvement as may be sanctioned under
rules made by competent authority.(ii)Subject to clause (iii) below, revenue should bear all
subsequent charges for maintenance and all working expenses. These embrace all expenditure on
the working and upkeep of the project and also on such renewals and replacements and such
additions, improvements or extensions as under rules made by Government are debitable to the
revenue account.(iii)In the case of works of renewal and replacement, which partake both of a
capital and revenue nature, the allocation of expenditure should be regulated by the broad principle
that revenue should pay or provide a fund for the adequate replacement of all wastage or
depreciation of property originally provided out of capital grants and that only the cost of genuine
improvements, whether determined by prescribed rules or formulae, or under special orders of
Government may be debited to Capital. Where under special orders of Government a Depreciation
or Renewals Reserve Fund is established for renewing assets of any commercial department or
undertaking the distribution of expenditure on renewals and replacements between Capital and the
Fund should be so regulated as to guard against over capitalization on the one hand and excessive
withdrawals from the Fund on the other.Expenditure on account of reparation of damage caused by
extraordinary calamities, such as flood, fire, earthquake, enemy action, etc. should be charged to
Capital, or Revenue or divided between them, in such a way as may be determined by Government
according to the circumstances of each case.(iv)Capital receipts in so far as they relate to
expenditure previously debited to Capital, accruing during the process of construction of a project
should be utilized in reduction of capital expenditure. Thereafter their treatment in the accounts will
depend on circumstances, but except under special rule or order of Government, they should never
be credited to the ordinary revenue account of the department or undertaking.
456.
Expenditure debitable to Capital will be booked under the appropriate capital head of accounts
prescribed within or outside the revenue account, according as the funds required to meet such
expenditure are provided from ordinary revenues or from other sources including borrowed money.
As a General rule, the capital cost of all comparatively small schemes will be met from ordinary
revenues. Borrowed money and other resources outside the revenue account will not ordinarily be
spent for unproductive purposes unless the following conditions are fulfilled, viz., firstly that the
objects for which the money is wanted are so urgent and vital that the expenditure can be neither
avoided, postponed nor distributed over a series of years, and secondly that the amount is too great
to be met from ordinary revenues.Except under special orders of Government, no expenditure
previously met from ordinary revenue may be transferred to a capital head outside the revenue
account.Note. - A productive work is one which produces sufficient revenue to afford a surplus over
the charges relevant to its functioning.Interest on CapitalBihar Financial Rules, 1950

457.
Except in special cases regulated by special orders of Government, interest at the rates specified
below should be charged in the accounts of all commercial departments or undertakings for which
separate capital and revenue accounts are maintained within the Government accounts. The charge
should be calculated on the direct capital outlay to end of the previous year plus half the outlay of
the year itself irrespective of whether such outlay has been met from ordinary revenues or from
other sources-(i)For capital outlay met out of specific loans raised by Government at such rate of
interest as may be prescribed by Government having regard to the rate of interest actually paid on
such loans and the incidental charges incurred in raising and managing them.Note. - By specific
loans are meant loans that are raised in the open market for one specific purpose which is clearly
specified in the prospectus and in regard to which definite intimation is given at the time of the
raising of the loans that for the purpose of accounts they are to be regarded as specific loans.(ii)For
capital outlay provided otherwise-in the case of outlay incurred after 1936-37, at the rate of interest
to be determined by the State Government in consultation with the Comptroller and Auditor
General of India.
458.
When under any special order of Government charges for interest during the process of construction
of a project are temporarily met from capital, the writing back of capitalized interest should form the
first charge on any capital receipts or surplus revenue derived from the project when opened for
working.Section IIIAdjustments with other Government's Departments etc.Adjustment With The
Government of India and Other State Governments
459.
(i)Subject to the relevant provisions of the Constitution of India adjustments in respect of financial
transactions with the Government of India or other State Governments will, unless otherwise
provided for, be made in such manner and to such extent as may be mutually agreed upon between
the Government of India or other State Governments and the State Government of
Bihar.(2)Adjustments should, however, always be made unless otherwise agreed upon-(i)if a
commercial department or undertaking or a regularly organised store department or store section of
a department is concerned; or(ii)if, under the operation of any rule or order, an adjustment would
have been made if the particular transaction with the Government of India or other State
Governments were a transaction between two departments of the State Government.Note. - The
procedure for the settlement of these adjustments will be regulated by the directions contained in
Chapter 4 of the Account Code, Volume I.(3)Adjustments with the Government of India or other
State Governments in respect of the matters mentioned below will be regulated by the Rules
contained in Appendix 3 to the Account Code, Volume I. The Rules are based on reciprocal
arrangements made between the Government of India and all the State Governments and are
therefore binding on all of them.I. Pay and allowances, other than Leave Salaries.II. Leave
Salaries.III. Cost of Passages.IV. Pensions.V. Charges for Bonus in respect of Government servants
who are employed on Bonus terms and who serve under more than one Government.VI.Bihar Financial Rules, 1950

Government contribution to Indian Civil Service Family Pensions.VII. Government contribution to
the Indian Civil Service (None European Members) Provident Fund.VIII. Expenditure involved in
Audit and keeping Accounts.IX. Grants of Land and Alienations.X. Cost of Police functions on
Railways including the cost of protecting Railway Bridges.XI. Cost of (1) Forest Surveys carried out
by the Survey of India, and (2) Forest maps prepared by that department.XII. Cost of Maintenance
and Demarcation of Boundaries and of Settlement of Boundary Disputes.XIII. Leave Salary and
Pension contributions recovered in respect of Government servants lent on Foreign Service.
460.
A period of three years has been accepted by the Central Government and other State Governments
and State Government of Bihar for re-audit of past transactions involving errors in
classification.This limitation should be regarded as a convention rather than a rigid accounting rule.
461.
Payment made by the Government of India on account of the cost of agency functions entrusted to
the State Government under Article 258 of the Constitution are treated as contributions from the
Government of India.In preferring claims against the Government of India under clause (3) of that
Article the following principles should be generally observed:-(i)If the agency work involves the
employment of a State Commercial Department it would be open to that department to charge its
normal commercial costs.(ii)Public Works Department agency costs should be represented by such
percentage charges on the cost of Central Works executed by the State as may be agreed between the
Government of India and the State Government, the works outlay being treated as an amount placed
at the disposal of the State Government for actual expenditure on the execution of the work.(iii)The
cost of regular joint establishments should be shared as far as practicable on the basis of fixed
annual sums settled in agreement with the Government of India.(iv)In other cases, the following
procedure should be adopted unless there are special orders to the contrary : -(1)Details of claims
preferred should be furnished. (They may include pay, leave salary and pension contributions,
contingencies, etc.)(2)If the work has been performed by the State in the past the charges claimed
should bear relations with those charged in the past. It is not necessary to be meticulous in the
matter, the Finance Department will assist in taking fairly general view.(3)If the charges do not
exceed Rs. 20,000 per annum for any individual item (or connected group of items), a five year
contract is generally offered by the Government of India during which the Central Government
would pay the fixed sum per annum for the works. The amount is subjected to review at the end of
each period of five years.(4)If the amount agreed upon exceeds Rs. 20,000 the Government of India
may want to have an annual statement of proposed charges from the State at the time of the
preparation of the budget unless in any individual case, the charges are obviously static, when the
contract system may be adopted by the Government of India in these cases also.(v)In exceptional
cases in which arbitration has to be resorted to the requisite arrangement in the matter will be made
by the Finance Department.(vi)The Finance Department should be consulted on all matters arising
under Article 258 (3) of the Constitution.Bihar Financial Rules, 1950

462.
No inter-Governmental adjustments can be carried out after the 15th of April, on which date the
books of the Bank are closed for the month of March. Every endeavour must, therefore, be made to
settle as far as possible all transactions with the Government of India or other State Government's
before the close of the year.Adjustments with Foreign Governments, Outside Bodies, etc.
463.
Payment must be required in all cases in respect of services rendered to any Foreign Government, or
non-Government body or institution, or to a separate fund constituted as such either inside or
outside the Public Account, unless Government by general or special order gives directions to the
contrary. Relief in respect of payment for services rendered or supplies made to any outside body or
fund should ordinarily be given through a grant-in-aid rather than by remission of dues.Inter
departmental adjustments
464.
(1)The conditions under which a Department of Government may make charge for services rendered
or articles supplied by it and the procedure to be observed for the settlement of such charges are
regulated by the directions of the Comptroller and Auditor General of India contained in Chapter 4
of the Account Code, Volume 1.See also Rules 33, 326 and 330-331 of the Bihar Treasury
Code.(2)Except in regard to transactions affecting the accounts of commercial departments and
undertakings or allocation to capital heads, adjustments between different departments of
Governments should be restricted to the narrowest limits. Such adjustments, when they are
essential, should, as far as possible, be based on lump sum figures fixed for a period of years with
reference to some suitable formula easy of application and maintained for a series of years.
Elaborate or meticulous calculations should be avoided as a general rule.Note 1. - The provisions of
Rule 460 apply mutatis mutandis to transactions between commercial and non-commercial
departments as they apply to transactions between the Central and State Governments.Note 2. -
Under the directions contained in the Account Code, Volume IV, inter-departmental and other
adjustments are not to be made in the accounts of the past year, if they could not have been
reasonably anticipated in time for funds being obtained, from the proper authority. In all cases,
where the adjustment could have reasonably been anticipated as, for example, recurring payments
to another Government or department, and payments which, though not of fixed amount, are of a
fixed character etc., the Accountant-General will automatically make the adjustment in the accounts
before they are finally closed. The onus of proving that the adjustments could not have been
reasonably anticipated should lie with the controlling officer.Adjustment of Pensionary Charges of
Certain Commercial Departments
465.
The pensionary charges of the Irrigation and Electricity Departments are adjusted on a liability basisBihar Financial Rules, 1950

i.e., at a percentage based on establishment charges, the actual payments of pensions being booked
under the appropriate head for such charges.Note. - In the case of irrigation major heads, the
pensionary charges should ordinarily be calculated at a percentage of the total pay and leave salary
of the pensionable establishment including such portion of the temporary staff as may be estimated
to have the likelihood of ultimately being made permanent. The percentage which should be
adopted should be based upon the cost of borrowing of the Government for the particular year in
which the pensionary charge is adjusted in the accounts.The percentages corresponding to the
several rates of interest are as follows: -(i)12.500 per cent of the total pay and leave salary of the
pensionable establishment on a basis of 3 per cent rate of interest;(ii)11.890 per cent of the total pay
and leave salary of the pensionable establishment on a basis of 3 ¼ per cent rate of
interest;(iii)11.236 per cent of the total pay and leave salary of the pensionable establishment on a
basis of 3 ½ per cent rate of interest;(iv)[ 10.593 per cent of the total pay and leave salary of the
pensionable establishment on a basis of 3 ¾ per cent rate of interest; [Inserted by (iv) & (v) inserted
by C.S. No. 7 dated 2.12.1957 and previous items (iv) to (vi) renumbered (vi) to (viii).](v)9.982 per
cent of the total pay and leave salary of the pensionable establishment on a basis of 4 per cent rate of
interest;(vi)9.427 per cent of the total pay and leave salary of the pensionable establishment on a
basis of 4 ¼ per cent rate of interest;(vii)8.899 per cent of the total pay and leave salary of the
pensionable establishment on a basis of 4 ½ per cent rate of interest;(viii)7.893 per cent of the total
pay and leave salary of the pensionable establishment on a basis of 5 per cent rate of interest.]
466.
The pensionary liability of commercial departments and undertakings, for which pro forma
commercial accounts are maintained outside the regular Government accounts, is assessed on a
contribution basis at rates fixed by Government, the actual method of adjustment in the regular
Government accounts being determined in consultation with the Accountant-General. As regards
other departments and undertakings, for which no regular commercial accounts are maintained
either within or outside the regular Government accounts but which are allowed to charge for their
products or services rendered, the pensionary liability is taken into account in the estimate of
overhead charges and manufacturing costs for the purpose of calculating the issue price of goods
manufactured or fees for services rendered, the calculation being made at rates prescribed for the
purpose by Government.Section IVPro forma AccountsSubsidiary Accounts of Government
Commercial Undertakings
467.
When the operations of a department include undertakings of a commercial or quasi commercial
character, and the nature and scope of the activities of the undertaking are such as cannot suitably
be brought within the normal system of Government account, the head of the undertaking should be
required to maintain such subsidiary and pro forma accounts in commercial form as may be agreed
between Government and the Accountant-General. The methods and principles in accordance with
which such accounts are to be kept including inter alia the basis to be adopted for valuation of assets
and for allocation of expenditure between capital and revenue accounts and the extent to which
provision should be made in those accounts for bad debts, depreciation and other forms of indirectBihar Financial Rules, 1950

charges, e.g., cost of management and supervision, audit charges, interest on capital expenditure,
etc., will be regulated by orders and instructions issued by Government in each case. Where the
commercial accounts are maintained for the purpose of assessment of the cost of an article or
service, the head of the undertaking should see that adequate regulations are framed with the
approval of Government in order to ensure that the cost deduced from the accounts is the accurate
and true cost. He should also arrange to obtain the orders of Government regarding the nature and
form of subsidiary accounts, and statement, if any, which should be appended to the Appropriation
Accounts of each year, and submit such accounts and statements to the Accountant-General on such
date as may be required by him.Other Pro forma Accounts
468.
Pro forma accounts of regular Government Workshops and Factories will be kept in accordance with
the detailed Rules and procedure prescribed in the departmental regulations. Pro forma accounts of
Irrigation, Navigation, Embankment and Drainage works and of Government residential buildings,
will be prepared by the Accountant-General in accordance with the instructions contained in
Chapter 21 of the Account Code, Volume IV.Section VAnnual Accounts
469.
The annual accounts of receipts and disbursements of the State Government are submitted to
Government by the Comptroller and Auditor General of India in the form of the Finance Accounts
and Report thereon. These, together with the Appropriation Accounts and Reports thereon,
constitute the published accounts of Government.The Finance Accounts and report thereon deal
with the accounts of Government as a whole, including transactions relating to debt, deposits,
advances, suspense and remittance accounts which do not strictly fall within the scope of the
Appropriation Accounts.
470.
The comments or recommendations of the Legislature or of the Public Account's Committee, if any,
arising out of the Audit Reports on the Finance Accounts and the Appropriation Accounts, and the
orders, of Government thereon, will be communicated by the Finance Department to the
Accountant-General, and other authorities concerned. The general responsibility for watching the
action taken on the Audit Report will under directions of the Comptroller and Auditor General of
India devolve on the Accountant-General.Section VIControl of Expenditure
471.
The authority administering a grant is ultimately responsible for watching the progress of
expenditure on public services under its control and for keeping the expenditure within the grant. In
order that the control of departments over such expenditure may be effective and real and that the
controlling officer should be in a position from month to month to estimate the likelihood of savingsBihar Financial Rules, 1950

and excesses over grants and appropriations, the procedure laid down in the following Rules should
be observed by all departments and controlling and disbursing officers subordinate to them, except
where the Finance Department have agreed in writing to some other procedure.
472.
The head of each department will be responsible for controlling expenditure from the grant or
grants at his disposal, and will exercise his control through the controlling officers, if any, and the
disbursing officers subordinate to him.
473.
Control over expenditure must be exercised, with reference to the grant as it stands from time to
time. It is the duty of the head of the departments to distribute the grant as voted by the Assembly
or, in the case of charged appropriation, as sanctioned by the Governor, among the various
controlling and disbursing officers subordinate to him, so far as this has not been done by the
Finance Department. In so doing he must take into account lump sum cuts made by the sanctioning
authority. He must similarly distribute any increases or reductions subsequently made in the grant
or in any part of it by the competent authority, whether the alteration is due to a supplementary
grant, to a lump reduction or to a re-appropriation. When making his distribution, he must
invariably communicate to the officer concerned the complete accounts classification of each item
distributed, including the major, minor and detailed heads of account and the primary unit. Such
distribution is, however not essential in the case of provision for pay of officers and of
establishments. In making a distribution, it is always open to the head of a department to keep a
portion of the grant as an undistributed reserve in his own hands.
474.
The following procedure must be followed by every disbursing officer in submitting claims for
money : -(i)He must attach to each bill a slip in F.R. Form 22, which will be returned by the
Treasury Officer, with the cash or cheque, after noting thereon the voucher number and the date
assigned to the bill.[A register in F.R. Form 22A should be maintained in the treasury for keeping a
record of disposal of theT.V. slips as mentioned above.The treasury clerk, who is required to fill up
the particulars in the T.V. slip should fill in simultaneously the columns 1 to 6 of the register F.R.
Form 22A and keep the T.V. slips properly arranged for making over to the messenger duly
authorized by the drawing and disbursing officer. The drawing and disbursing officer should also
make arrangement for collection of the T.V. slips from the treasury once a week. When the
authorized messenger appears at the treasury for collecting the T.V. slips these should be made over
to him and his signature obtained in column 7 of the register in token of receipt. In cases in which it
may not be possible for a drawing and disbursing officer, whose headquarter is situated away from
the treasury, to collect the T.V. slips through a special messenger, he may request the Treasury
Officer, in writing, to send him the T.V. slips by post. In such cases, the Treasury Officer will send
T.V. slips by post to the drawing and disbursing officer by name, mentioning in column 1 of the
register the number and date of the forwarding memo under which the slips were forwarded.TheBihar Financial Rules, 1950

procedure of transmission ofT.V. slips by post should, however, be avoided as far as possible and in
no case should the Treasury Officer send the T.V. slips by post. If the office of the drawing and
disbursing officer is situated in the same station.] [Added by C.S. No. 26 dated 15.7.1958.](ii)He
must enter on each bill the complete accounts, classification of the proposed expenditure, from
major head down to detailed head of account, and state whether the charge is voted or charged.
When a single bill includes charges falling under two or more detailed heads the charges must be
distributed accurately over the respective heads.(iii)Except in the case of bills for the pay of officers
or establishments and for allowances drawn with pay he must enter on each bill and on each slip in
F.R. Form 22, the progressive total of expenditure up to date under the sub-head or sub-heads to
which the bill relates, including the amount of the bill on which the entry is made.
475.
In order to enable all concerned to watch expenditure against those portions of grants which are
peculiarly liable to fluctuation, the following procedure must be followed in respect of all bills other
than those for pay of officers or of establishments and for allowances drawn with pay :-(i)Every
disbursing officer and in respect of his own expenditure from portions of the grant retained in his
own hands, every controlling officer and head of department, must maintain a separate register in
F.R.Form 23 for each minor or sub-head of account with which he is concerned. In this must be
entered the necessary particulars of the charges drawn on each bill under the appropriate primary
unit and detailed head.(ii)On the [seventh] [Substituted for 'third' by C.S. No. 27 dated 22.12.1958.]
day of each month, a copy of the entries in this register, so far as these records sums actually drawn
from the treasury during the preceding month, must be sent in full detail by the officer maintaining
it to the head of the department or other controlling officer. As certain of the entries in each month
will represent bills which were not actually cashed before the end of that month, the copy sent will
include a few entries of a previous month and exclude a few made in the month for which the return
is submitted. With the copy must be forwarded all the slips in F.R. Form 22 which relate to the bill
entered in it. If there be no entries in the register in any month, a "nill" statement must invariably be
sent.(iii)In order to watch the receipt of the returns prescribed in the foregoing subclause the
controlling officer must maintain a broad-sheet in F.R. Form 24, in which a serial number will be
allotted to each individual disbursing officer. This broadsheet must be carefully watched and
reminders sent if any returns are not received by the 7th of the month, since the accuracy of the
controlling officer's accounts will depend upon the receipt of complete returns. The serial number
allotted to each disbursing officer must be communicated to the Accountant-General.(iv)On receipt
of the returns from disbursing officers the controlling officer must carefully examine them and must
satisfy himself-(1)that the accounts classification has been properly given;(2)that progressive
expenditure has been properly noted on the slips and the available balances worked out;(3)that
expenditure up-to-date is within the grant;(4)that the returns have been signed by the disbursing
officers, and(5)that all relevant slips in F.R. Form 22 have been attached. If he finds defects in any of
these respects, he must take immediate steps to rectify them.(v)When all disbursing officers' returns
for a particular month have been received and found to be in order, the controlling officer must
prepare a statement in FR. Form 25, in which he will incorporate-(1)the totals of the figures
supplied by disbursing officers;(2)the total taken from his own registers in F.R. Form 23; and(3)the
totals of adjustments under the various detailed heads which will be communicated to him by theBihar Financial Rules, 1950

Accountant-General on account of transfer entries and expenditure debited to grant through
accounts current.If any adjustment communicated by the Accountant General affects the
appropriation at the disposal of a sub-ordinate disbursing officer, the fact that it has been made
must be communicated by the controlling officer to the disbursing officer concerned.(vi)On the
receipt of all the necessary returns, the head of the department must prepare an account in F.R.
Form 26, showing the complete expenditure from the grant at his disposal up to the end of the
preceding month. The figures of expenditure upon pay of officers and establishments and upon
allowances drawn with pay will be communicated to him by the Accountant General as prescribed in
Rule 476.(vii)In May of each year, the head of the department must forward to the Accountant
General of copy of his account for April in F.R. Form 26. In subsequent months, it will suffice to
send an abstract of the expenditure up-to-date under the various heads of disbursement in three
columns, showing-(1)expenditure up to the end of the preceding month;(2)expenditure during the
month just concluded; and(3)total expenditure up-to-date, being the total of (1) and (2).The
subsidiary records in F.R. Forms 23 and 25 will be retained by the head of the department in his
own office, unless in any case the Accountant General requires that the whole or any part of them
should be sent to him with the statement.(viii)The head of the department and the Accountant
General will be jointly responsible for the reconciliation of the figures given in the accounts
maintained by the head of the department with those that appear in the Accountant General's books.
Unless in any case there are special rules or orders to the contrary, the reconciliation should be
made monthly, the initial responsibility resting with the Accountant General.The reconciliation need
not be very close; its extent should be determined by the following considerations : -(1)that account
figures finally published will be those maintained by the Accountant General; and(2)that the main
object of the reconciliation is to ensure that the departmental accounts are sufficiently accurate to
render possible an efficient departmental control of expenditure.(ix)If, for certain reasons monthly
verification is not possible the controlling officer will depute an assistant of his office to the office of
the Accountant General for verification, every third month, instead of allowing the discrepancies to
accumulate and sending an assistant at the close of the financial year, as such deputation will cause
much inconvenience in the Accountant General's office and the work of reconciliation will not be
done satisfactorily.
476.
Expenditure on the pay of officers and establishments is not as a rule, liable to violent fluctuation.
Moreover, the provision for such expenditure is frequently not distributed among disbursing
officers. It is, therefore, unnecessary to watch such expenditure through the form and registers
prescribed in (sub-paragraph) 4 above. The figures of such expenditure will be communicated
monthly by the Accountant-General to the head of the department who must enter them in his
account in F.R. Form 26 and watch the progress of expenditure against the grant.
477.
The head of the department and his controlling officers must further take steps to maintain a careful
watch over expenditure incurred from time to time on important non-recurring objects, such as
grants and contributions, purchase of rations and purchase of uniforms. It is necessary to deal withBihar Financial Rules, 1950

such items separately from the accounts of ordinary monthly expenditure since they occur once or
twice only in the course of a year. The head of the department or controlling officer must decide for
himself what method of watching such expenditure he will adopt, it is essential that he should keep
himself informed own control and to order disbursing officers who wish to spend money against it
to apply to him for a special allotment. In other cases, he may prefer to distribute the grant and to
order his disbursing officers to report expenditure against it as soon as they incur such expenditure,
separately from their ordinary monthly accounts. Whatever method he adopts. In some cases he
may prefer to keep the entire grant under his not only of actual expenditure against such grants, but
also of liabilities which have been incurred and must ultimately be met from them. Without such
information, no adequate control over expenditure can be exercised.
478.
Under the procedure prescribed in these rules, a head of department or controlling officer should be
in a position from month to month to estimate the likelihood of savings or excesses and to regularize
them in accordance with the instructions laid down in Rules 111 to 113 of the Bihar Budget Manual.
The processes involved should receive the personal attention of the heads of departments and
controlling officers and must on no account be left to be conducted entirely by subordinates.
479.
In this connection it should be remembered that before money can be spent two conditions must be
fulfilled-it must be sanctioned by the competent authority and funds must have been appropriated
for it-(a)The sanction of any authority to any expenditure becomes operative as soon as funds have
been appropriated to meet it, and does not become operative until funds have been so
appropriated.(b)The sanction of any authority to recurring expenditure covering a specified term of
years becomes operative when funds are appropriated to meet the expenditure of the first year, and
remains in operation for each year of the specified term, subject to appropriation or the voting of
funds in such year.Note. - The practice of submission of proposals for additional grants by the
controlling officers and sanction of re-appropriation of grants late in the financial year leads to a
complete laxity of control over expenditure. Government will not approve of any expenditure in
excess of the budget provision unless sanction to incurring extra expenditure has been obtained
previously. In his application for sanction to exceed the budget grant the controlling officer must
explain the reason for the extra expenditure and at the same time suggest the method of financing
it-(i)If it is considered that the extra amount can be found by re-appropriation within the grant, the
re-appropriation should be suggested and sanctioned at the same time, when approval to incurring
the extra expenditure is obtained; the practice of obtaining sanction to the re-appropriation at the
end of the year which amounts to a formal adjustment of grants is against the spirit of this rule. The
controlling officer must strictly comply with the provisions of this Rule and have a complete grasp
over the progress of expenditure under the various heads under his control.(ii)In cases where it is
not possible to find the extra fund required by re-appropriation and the expenditure is required to
be incurred immediately and it is not possible to wait for the vote of the Legislature to a
Supplementary Demand, the extra fund will be allowed by Government and the controlling officer
must move for a Supplementary Demand at the earliest opportunity and not to wait till the end ofBihar Financial Rules, 1950

the year.Special Rules for the Public Works Department
480.
(a)In charges against suspense accounts, any expenditure which is not expected to cause an excess
over net provision for the year, may be held to be covered thereby.(b)For payments chargeable to
the account of other divisions, departments, or Governments or of non-Government works, and
re-payments of deposits, a Divisional Officer does not require any specific provision of funds within
the appropriations for his own division. It is sufficient to see that such payments are made only in
accordance with the rules.
481.
Controlling officers are responsible for seeing that the grant placed at their disposal is not wasted or
exceeded, and where necessary this responsibility will be enforced by surcharge.They, in turn,
should impose the same responsibility on their subordinate disbursing officers. The Accountant
General will assist by issuing warnings to disbursing officers and, if necessary, to controlling
authorities, when excesses appear to be likely.
482.
The Accountant General will warn the department concerned immediately of the first appearance of
any excessive proportionate outlay under any grant or under any primary unit of appropriation. It
must be clearly understood, however, that the authority administering a grant and not the
Accountant General is ultimately responsible for the control of expenditure against the grant.
483.
The High Commissioner for India, as disbursing authority for charges in England will incur
expenditure within the budget allotments under the respective grants as communicated to him by
the Finance Department. The head of department or controlling officer will be responsible for
keeping watch over expenditure under the unit "Charges in England" with reference to the grant as a
whole and obtain from the Accountant General details of monthly expenditure adjusted in his
accounts from time to time.
484.
All communications to Government regarding re-appropriations and supplementary demands must
be based on the Accountant General's and not the departmental figures.Section
VIIRe-appropriationsBihar Financial Rules, 1950

485.
A demand for grant under each service head represents the total gross expenditure under that head
leaving out of account all deduction on account of recoveries of expenditure shown within that
head.These deductions for recoveries are not available for any kind of re-appropriation or
modification of funds.Note. - A detailed statement of these deductions appear at the end of each
demand.
486.
No re-appropriation shall be made except-(a)from one voted unit to another voted unit within the
same grant;(b)from one unit classed as charged on revenues, to another such unit within the same
grant appropriation.
487.
No re-appropriation shall be made-(a)from a voted unit in one grant to a voted unit in another
grant;(b)from a unit classed as charged on revenues to a voted unit; or(c)from a voted unit to a unit
classed as charged on revenues; or(d)from a charged unit in one grant appropriation to a charged
unit in another grant appropriation.
488.
Although the primary unit of appropriation may be sub-divided in the budget estimates into greater
details, no order of re-appropriation is required to cover a transfer between these detailed
provisions. The Accountant General audits the expenditure classified under each particular unit
against the provision for the whole unit, and so long as that is not exceeded no necessity for
re-appropriation arises.
489.
(a)No re-appropriation shall be made from one major head to another within a grant voted by the
Assembly, except with the sanction of the Finance Department.(b)The Minister-ln-Charge of a
department may sanction any re-appropriation within a grant between the unit subordinate to the
same major head provided that no such re-appropriation-(i)shall create any recurring liability;
or(ii)shall be made for a new service or scheme for which provision has not already been made in
the annual budget estimate of expenditure; or in a supplementary estimate of expenditure;
or(iii)shall be made where both units are not under the charge of the same Minister; or(iv)shall be
sanctioned when the amount involved against a single subhead or primary unit of appropriation
exceeds Rs. 15,000.(c)A copy of every order sanctioning a re-appropriation under this Rule shall be
communicated to the Finance Department as soon as it is passed.(d)The Minister-In-Charge of any
department may with the sanction of the Finance Department, re-appropriate from a unit which is
under the charge of another Minister, to another unit which is under his charge, if both such unitsBihar Financial Rules, 1950

are within the same major head.
490.
(a)No re-appropriation of sums required to meet the expenditure charged on the revenues of the
State shall be made from one major head to another within the same grant appropriation except
with the sanction of the Finance Department.(b)The Minister-In-Charge of a department may
sanction any re-appropriation within a grant appropriation between the unit subordinate to the
same major head provided that no such re-appropriation-(i)shall create any recurring liability;
or(ii)shall be made for a new service or scheme for which provision has not already been made in
the annual budget estimate of expenditure or in a supplementary estimate of expenditure;
or(iii)shall be made where both units are not under the charge of the same Minister; or(iv)shall be
sanctioned when the amount involved against a single subhead or primary unit of appropriation
exceeds Rs. 15,000.(c)A copy of every order sanctioning re-appropriation under this Rule shall be
communicated to the Finance Department as soon as it is passed.(d)The Minister-ln-Charge of any
department, may with the sanction of the Finance Department re-appropriate from a unit classed as
charged on revenues which is under the charge of another Minister to another similar unit which is
under his charge, if both such units are subordinate to the same major head within the same grant
appropriation.Note. - Even in cases where re-appropriation of funds are to be sanctioned by the
Ministers, the Secretaries and Additional Secretaries to Government of the respective departments
will be responsible to scrutinize all proposals for re-appropriation submitted by the Controlling
Officers, carefully and advising the Ministers on these proposals.
491.
A Minister may, with the sanction of the Finance Department delegate to any officer or a class of
officers, the power of re-appropriation conferred on the Minister by Rules 489 and 490 and any
such delegation shall be subject to such conditions and restrictions as the Finance Department may
prescribe.
492.
(1)When a re-appropriation is sanctioned by the Finance Department or by the Minister-in-charge
of a department the procedure prescribed for such re-appropriation in the Secretariat Instructions
shall be observed.(2)When any re-appropriation is made in exercise of the power delegated under
Rule 491, the procedure prescribed by Rules 493 to 495 shall be observed.
493.
(a)When any re-appropriation is made in pursuance of any power delegated under Rule 491, if the
expenditure is sanctioned by Government but the re-appropriation is to be sanctioned by the officer
to whom the power is delegated, the order issued by Government to such officer, shall conclude with
the following direction: -"The charge will be met by re-appropriation ....(specify the unit ofBihar Financial Rules, 1950

appropriation) in the current year's budget. This re-appropriation requires your sanction".(b)The
officer concerned shall on receipt of the said order-(i)sent a copy of the said order to the Accountant
General with the following endorsement: -"Acting under the power delegated to me under. Rule 491
of the Bihar Financial Rules by the Minister-In-Charge, I sanction the above
re-appropriation.",(ii)send a copy of the said order and endorsement to the Finance Department for
information, and(iii)send a copy of the endorsement to the administrative department concerned.
494.
(a)When a re-appropriation is made in pursuance of any power delegated under Rule 491, if both
the expenditure and the re-appropriation are sanctioned by the officer to whom the power is
delegated the order issued by the officer shall conclude with the following direction:-"The charge
will be met by re-appropriation from ...(specify the unit of appropriation) in the current year's
budget. Acting under the power delegated to me under Rule 491 of the Bihar Financial Rules by the
Minister-In-Charge, I sanction the re-appropriation".(b)The officer concerned shall send a copy of
the said order to the Accountant-General, the Finance Department and the Administrative
Department.
495.
(a)Every officer to whom the power to sanction re-appropriation has been delegated shall keep a
register of such re-appropriations.(b)Such register shall ordinarily be kept in a form containing a list
of the provisions under each unit, under the control of the said officer concerned with enough space
opposite to each such unit to permit plus and minus entries to be made.(c)All re-appropriations
sanctioned by an authority superior to an officer concerned shall also be entered in the
register.(d)The officer maintaining the register shall consult the register whenever the revised
estimate is under preparation or whenever any other re-appropriations are being considered.(e)The
register of re-appropriations should be maintained in F.R. Form 27.
496.
All applications for extra grant or re-appropriation requiring the sanction of the Minister in Charge
or of the Finance Department shall be forwarded by the controlling officer to the administrative
department concerned.When an extra grant or re-appropriation is sanctioned by a competent
authority for a sum of Rs. 1000 or more, the explanation for the necessity of the extra grant or of the
re-appropriation shall be set out as briefly as possible in the sanctioning order which is
communicated to the Accountant General, or a copy of the form of application should be attached to
the order of sanction, and the extra grant or re-appropriation should be sanctioned for the reasons
contained in the accompanying form.All orders of re-appropriations shall invariably specify the
exact amount involved, and, in order to ensure this, the standard form of re-appropriation shall be
used whenever any proposal for re-appropriation is submitted for sanction or is sanctioned by
competent authority. (Schedule LIII, Form No. 212, B. M. Form 2 of the Bihar Budget Manual.)Bihar Financial Rules, 1950

497.
No re-appropriation can be sanctioned after the close of the Financial year.Excess expenditure not
covered by grants may occur against individual primary units of appropriation and also against the
total grant or the grant appropriation in the subject. These irregularities are dealt with by the
Accountant-General in the Appropriation Accounts and the Audit Report.As regards excesses under
primary units of appropriation it is the duty of the controlling officer to scrutinise the factors leading
to such excesses so as to be ready to furnish materials to the Accountant General for the
appropriation accounts, and also to satisfy himself that the excess expenditure over the grant was
unavoidable. He should report to the higher authorities for such action as is considered necessary
where he is not satisfied that the excess expenditure was justified and the disbursing officers have
failed to ensure adequate control of expenditure. The excesses against the total grant on the subject,
are dealt with in accordance with Article 205(1)(b) of the Constitution and Rule 154 of the Bihar
Legislative Assembly Rules, after the Appropriation Report has been considered by the Public
Accounts Committee.
498.
Savings in the sub-heads of grants accommodating recoveries will not be available for
re-appropriation to cover excesses under other sub-heads except sub-heads accommodating other
recoveries. The unutilised savings in these subheads will be allowed to lapse and suitably explained
in the appropriation Accounts.
499.
The approval of the Legislative Assembly to any additional expenditure over the amount voted by it
for the gross expenditure in a grant will be taken by means of a Supplementary grant. The
Supplementary grant will take into account the unforeseen additional recoveries in the course of the
year and will be taken for the net excess over the total grant, details of the gross expenditure and of
the recoveries being placed before the Assembly. If the net effect of the additional recoveries is to
reduce the total expenditure against the grant to a figure less than the original grant as to reduce it
to a minus figure the Assembly's approval to the increase in the gross expenditure will be taken by
means of a token grant. The excess under the sub-heads for gross expenditure which would have
been covered by re-appropriation of savings but for the prohibition in Rule 498 will be suitably
explained in the Appropriation Accounts.
500.
The procedure set out in Rules 498 and 499 above, will apply mutatis mutandis to items of
expenditure which are charged on the revenue of the State. The Finance Department will authorise
additional expenditure for which in the case of voted expenditure the Assembly is approached for
Supplementary grant.Note. - The excepting clause as in Rule 498 above which provides for
re-appropriation between sub-heads accommodating recoveries may not be made compulsory afterBihar Financial Rules, 1950

a particular date to be fixed by Government for this purpose. Accordingly in cases where the
excesses and savings under recovery heads are not known by a date to be prescribed by the Finance
Department there will be no occasion for adverse comments in the Appropriation Accounts if effect
to such permissible re-appropriation has not been given or has not been taken into account in
formulating a Supplementary Demand. This date has been fixed by the Finance Department to be
the 20th February each year.FormsF.R. Form 1[See Rule 42]Registry of Miscellaneous
PropertyNotes
1. Every possible source of miscellaneous revenue such as fishery, grass,
produce of trees, lease of land for building, agriculture etc. should be entered
in column 2 irrespective of whether the revenue is realised in any year or not.
The entries should be according to a particular canal or road noting the miles
in the case of canal and roads. The items should be arranged in the order of
the month in which they are to be leased.
2. Column 4 should show the names of canals, roads or situation of buildings
with the mileages in the case of canals and roads.
3. In column 6, the details of the lease, area, agreement number, rate, number
of instalments etc., should be noted when necessary. Sufficient space should
be left between two entries to permit of all realisations of revenue paid in
instalments being posted against the item concerned. Column 12'due dates
of payment' should be filled in as soon as a particular property is leased out.
4. Steps taken to clear the balances outstanding and increases or decreases
of revenue as compared with the figures for previous years, etc., should be
explained with as guide letter in the remarks column.
5. If any of the properties are leased for periods exceeding two years they
should be recorded in a separate register with inter sheets to provide for the
entire period of the lease.
6. The register should be maintained in the Sub-divisional office and extracts
showing the transactions during the month submitted to the Divisional office
along with the accounts of the month. In Headquarters Subdivision the
register itself may be sent to the Divisional office.Bihar Financial Rules, 1950

7. The properties should be verified annually by the Sub-divisional or
sectional officers concerned at the time of sale and a certificate as to the
number of properties actually existing noted in the register and in the sale
lists.
8. The register should be made available for scrutiny by the Executive
Engineer during his inspection of Sub-divisional office.
9. It must be distinctly understood that the S.D.O will be held personally
responsible for the recovery of revenue to Government.
Item number.Description
of Revenue.Locality. Particulars.Name and address
of the lessee
together with
hisfather's name.Particulars
of the lease.Period
of
Lease.
Date of
commencement.Date of
expiry.
1 2 3 4 5 6 7 8
 
Amount
RealisableDue date of
payment.Date of
realisation of
amount &
receipt
no.and/or
treasury
challan.Amount
realisable.Balance
at the
end of
the year.Initials of S.D.O.
or Divisional
Accountantattesting
columns 14 and
15.Remarks.
Arrear
brought
forward.Revenue
realisable
for the
current year.Total
9 10 11 12 13 14 15 1617
 
F. R. FORM 2.[See Rule 83]Statement of Proposition for Revision of Establishment.
Nature of
charges.
Present scale.Proposed
scale
Number. Designation. Pay.Average
costNumber. Designation. PayAverage
cost.
Minimum. Increment. Maximum. Minimum. Increment. Maximum.Bihar Financial Rules, 1950

  † † †    ††† 
Proposition.
Permanent. Temporary
Increase per
month.Decrease per
month.Increase per
monthDecrease per
month.Order of
sanctioning
authority.
Amount. Amount. Period. Amount. Period. Amount.
† †  †  †  
† Money columns.Note. - In preparing this statement particular attention should be paid to the
instruction in Rule 4.F.R. FORM 3.[See Rule 86]Charge Report.Place ......................................I
................. (in Block letters) undersigned have made over charge to Mr. ................ (in Block letters)
undersigned as ................. on the forenoon/afternoon of .............. of year ...................Relieved
Officer. Relieving Officer.A permanent advance of Rs. (in words) ........................ has been made over
by me ................. and taken over by me ..............
2. [ Certified that I ..................... on assuming charge of the officer of
................... have received a copy of the printed instructions for the guidance
of officers receiving, handling or spending the public funds.] [Inserted by
Notification No. A3 - 30387/02/10158 F. dated 10.2.1962.]
Signature ..............................Place ....................................Date .....................................For Use In
Audit Office
Noted in Audit RegisterHistory of Services.Pay slip issued :-
Accountant General's Office.F.R. Form 4[See Rule 98]Form for Application for Leave.Note. - Items 1
to 9 must be tilled in by all applicants whether gazetted or non-gazetted. [* * *] [Words commencing
with 'Item 10 applied as the case may be' in the Note above deleted by C.S. No. 16 dated
26.11.1960.]Item 12 applies only in the case of Gazetted Officers.Items 13 and 14 apply in the case of
non-Gazetted Officers.
1. Name of applicant.  
2. Leave Rules applicable.  
3. Post held.  
4. Department or office.  
5. Pay.  
6.House allowance, conveyance allowance,
or other compensatoryallowances drawn
in the present post. 
7.Nature and period of leave applied for
and date from whichrequired. 
8. Ground on which leave is applied for.  Bihar Financial Rules, 1950

9.Date of return from last leave and the
nature and period ofthat leave. 
10. [
[Substituted
by C.S. No.
16 dated
26.11.1960.]I undertake to refund the difference
between the leave-salarydrawn during
leave on average pay/ commuted leave
and thatadmissible during leave on half
average pay/half pay leave whichwould
not have been admissible, had the proviso
to F.R. 81 (b)(ii)/Rule 17 (b) (ii) of the
Bihar Service Code Rule 11 (c) (iii)of the
Revised Leave Rules, 1993 (India) Rule
234 of the BiharService Code, not been
applied in the event of my retirement
fromservice at the end of during the
currency of the leave]. 
 Date. Signature of applicant.
11.Remarks and/or recommendation of the
Controlling Officer. 
 Date Signature.Designation.
12. Report of the Audit Officer-  
 Date Signature.Designation.
13.Statement of leave granted to applicant
previous to thisapplication. 
 Nature of leave. In current yearDuring
past
year.Total.
 Casual.  
 Privilege.  
 On average pay (includes Earned Leave
under Revised LeaveRules.) 
 On average pay on M.C.  
 On half average pay  
 On half average pay on M.C.  
 On quarter average pay.  
 On half average pay on private affairs.  
 On quarter average pay on M.C.  
 Extraordinary leave.  
 Total   
14. Certified that leave on average pay  
 ____________________Earned leave  Bihar Financial Rules, 1950

 for Months and days from ... 20 to 20
 is admissible.Under
.........._____________
 Date ArticleSignatureDesignation
15. *Orders of the sanctioning authority-  
 Date Signature.Designation.
* If the applicant is drawing any compensatory allowance the sanctioning authority should state
whether on the expiry of leave he is likely to return to the same post or to another post carrying
similar allowance.
F.R. Form 5.[SeeRule 167]Indent for Stores.CounterfoilIndent
No............................On......................................Dated.................................{|
Description.Number
of
quantity.Head of
account,
etc.Name of
work or
sub-work
(with name
of contractor
from
whomvalue
Is
recoverable).
    
Certified that the articlesintended for are not available in my stock.These materials should
be......................... by ......................(Indenting Officer.)(Divisional orSub-divisional Officer.)|| F.R.
Form 5.[SeeRule 167]Indent for Stores.INDENTIndent
No............................On......................................Dated.................................
Description.Number of
quantity.Head of
account, etc.Name of work or sub-work (with name of contractor
from whomvalue Is recoverable).
    
These materials should be......................... by .........................(IndentingOfficer.)(Divisional or
Sub-divisional Officer.)CERTIFICATE OFSUPPLYThis indent has (not)been complied with) in full
.........................(The alteration, which Ihave attested have accordingly been made by
me)to....on...by....Dated ...... 20.Supplying Officer|| F.R. Form 5.[SeeRule 167]INVOICE.Invoice of
StoresSupplied.....To.....................................................By.....................................................On Indent
no ........... dated.................Issued by the.......................................
Description.Number of
quantity.Head of
account, etc.Name of work or sub-work (with name of contractor
from whomvalue Is recoverable).
    
Dated ............... SupplyingOfficer.Received.Dated ............... Receiving Officer.|}F.R. Form 6.[See
Rule 191]Road Metal Rate BookRate table showing lowest rates at which metal can be supplied to
the roadside throughout the Division.
No. of
miles.Quarry from
which dugClass of metals. Distance
carried.Rates for
carrying perRate per
cubicRemarksBihar Financial Rules, 1950

and its
situation.Kilo meter. meter.
Kilometer.Digging and
stacking at
roadside.Charges on account
of royalty,
contractor'sprofit,
tools and plant.Carriage Total.
    Rs. P. Rs. P. Rs. P.Rs.
P.Rs.
P. 
F.R. Form 7.[See Rule 264 (8)]Indenture for Secured Advances.For use in cases in which the
contract is for finished work and contractor has entered into an agreement for the execution of a
certain specified quantity of work in a given timeThis Indenture made the ................................ day of
........................................ 20 between ......................................... (hereinafter called the Contractor
which expression shall where the context so admits or implies be deemed to include his executors,
administrators and assigns) of the one part and the Governor of Bihar (hereinafter called the
Governor which expression shall where the context so admits or implies be deemed to include his
successors in office and assigns) of the other part.Whereas by an agreement, dated
................................... (hereinafter called the said agreement) the Contractor has
agreed.................And Whereas the Contractor has applied to the Governor that he may be allowed
advances on the security of materials absolutely belonging to him and brought by him to the site of
the works the subject of the said agreement for use in the construction of such of the works as he has
undertaken to execute at rates fixed for the finished work inclusive of the cost of materials and
labour and other charges or for a lump sum.And Whereas the Governor has agreed to advance to the
contractor the sum of Rupees ...................... on the security of materials, the quantities and other
particulars of which are detailed in Part II of a Running Account Bill [F.R. Form 6/T.C. Form 53] for
the said works signed by the Contractor on .................... and the Governor has reserved to himself
the option of making any further advance or advances on the security of other materials brought by
the Contractor to the site of the said works.Now This Indenture Witnesseth that in pursuance of the
said agreement and consideration of Rupees ..................... on or before the execution of these
presents paid to the contractor by the Governor (the receipt whereof the Contractor both hereby
acknowledge) and of such further advances (if any as may be) made to him as aforesaid the
Contractor doth hereby covenant and agree with the Governor and declare as follows. -(1)That the
said sum of Rupees .........................so advanced by the Governor to the Contractor as aforesaid and
all or any further sum or sums advanced as aforesaid shall be employed by the Contractor in or
towards expediting the execution of the said works and for no other purpose whatsoever.(2)That the
materials detailed in the said Running Account Bill [F.R., Form 6/ T.C. Form 53] which have been
offered to and accepted by the Governor as security are absolutely the Contractor's own property any
free from encumbrances of any kind and the contractor will not make any application for or receive
a further advance on the security of materials which are not absolutely his own property and free
from encumbrances of any kind and the contractor indemnifies the Governor against all claims to
any materials in respect of which an advance has been made to him as aforesaid.(3)That the
materials detailed in the said Running Account Bill [F.R. Form 6/T-C. Form 53] and all other
materials on the security of which any further advance or advances may hereafter be made as
aforesaid (hereinafter called the said materials), shall be used by the Contractor solely in the
execution of the said works in accordance with the direction of the Executive EngineerBihar Financial Rules, 1950

........................................ Division (hereinafter called the Executive Engineer) and the terms of the
said agreement.(4)That the contractor shall make at his own cost all necessary and adequate
arrangements for the proper watch, safe custody and protection against all risks of the said
materials and that until used in construction as aforesaid the materials shall remain at the site of the
said works in the Contractor's custody and on his own responsibility and shall at all times be open to
inspection by the Executive Engineer or any officer authorised by him. In the event of the said
materials or any part thereof being stolen, destroyed, or damaged or becoming deteriorated in a
greater degree that as due to reasonable use and wear thereof the Contractor will forthwith replace
the same with other materials of like quality or repair and make good the same as required by the
Executive Engineer.(5)That the said materials shall not on any account be removed from the site of
the said works except with the written permission of the Executive Engineer or an oficer authorized
by him on that behalf.(6)That the advances shall be repayable in full when or before the Contractor
receives payment from the Governor of the price payable to him for the said works under the terms
and provisions of the said agreement. Provided that if any intermediate payments are made to the
Contractor on account of work done, then on the occasion of each such payment the Governor will
be at liberty to make a recovery from the Contractor's bill for such payment by deducting therefrom
the value of the said materials than actually used in the construction and in respect of which
recovery has not been made previously the value for this purpose being determined in respect of
each description of materials at the rates at which the amounts of the advances made under these
presents were calculated.(7)That if the Contractor shall at any time make any default in the
performance or observance in any respect of any of the terms and provisions of the said agreement
or of these presents the total amount of the advance or advances that may still be owing to the
Governor shall immediately on the happening of such default be repayable by the Contractor to the
Governor together with interest thereon at twelve per cent per annum from the date or respective
dates of such advance or advances to the date of repayment and with all costs, charges, damages and
expenses incurred by the Governor in or for the recovery thereof, or the enforcement of this security
or otherwise by reason of the default of the Contractor and the Contractor hereby covenants and
agrees with the Governor to repay and pay the same respectively to him accordingly.(8)That the
Contractor hereby charges all the said materials with the repayments to the Governor of the said
sum of Rupees .........................and any further sum or sums advanced as aforesaid and all costs,
charges, damages and expenses payable under these presents Provided Always and it is hereby
agreed and declared that notwithstanding anything in the said agreement and without prejudice to
the powers contained therein if and whenever covenant for payment and repayment hereinbefore
contained shall become enforceable and the money owing shall not be paid in accordance therewith,
the Governor may at any time thereafter adopt all or any of the following courses as he may deem
best:-(a)Seize and utilize the said materials or any part thereof, in the completion of the said works
on behalf of the Contractor in accordance with the provisions in that behalf contained in the said
agreement debiting the contractor with the actual cost of effecting such completion and the amount
due in respect of advances under these presents and crediting the contractor with the value of work
done as if he had carried it out in accordance with the said agreement and at the rates thereby
provided or in the case of a lump sum contract at the rates provided in the sanctioned schedule of
the Division as it stood on the date of the execution of the work. If the balance is against the
Contractor he is to pay the same to the Governor on demand.(b)Remove and sell by public auction
the seized materials or any part thereof and out of the moneys arising from the sale retain all theBihar Financial Rules, 1950

sums aforesaid repayable or payable to the Governor under these presents and pay over the surplus
(if any) to the Contractor.(c)Deduct all or any part of the moneys owing out of the security deposit or
any sum due to the contractor under the said agreement.(9)That except in the event of such default
on the part of the Contractor as aforesaid interest on the said advance shall not be payable.(10)That
in the event of any conflict between the provisions of these presents and the said agreement the
provisions of these presents shall prevail and in the event of any dispute or difference arising over
the construction or effect of these presents the settlement of which has not been hereinbefore
expressly provided for the same shall be referred to the Superintending
Engineer,........................Circle whose decision shall be final and the provisions of the Indian
Arbitration Act for the time being in force shall apply to any such reference.In Witness whereof the
....................for and on behalf of the Governor of Bihar the
said............................................................................................. have hereunto set their respective
hands seals the day and year first above written.Signed, Sealed and Delivered by ......................the
said ................... in the presence of
1st. witness.
2nd. witness,
F.R. Form 8[See Rules 289, 292, 294 (b) and 298.]Account of Receipts, Issues and Balances of
Materials-at-site of the ....................... for the month of ............... 20.
Description of materials Bricks Surkhi Lime     Total
Unit  Rs. P.
Opening balance Quantity
Value
Receipt -
Total - Receipts
Total – Receipts and Balances
Issues
Total - Issues
Closing Balance.
Dated the 20.Sub-divisional OfficerComparison with estimated Requirements
Estimated quantity of materials  
Estimated value of materials  
 Quantity  
Total - Receipts during the month as above.   
 Value  
  
 Quantity  Bihar Financial Rules, 1950

Total - Receipts at end of previous month.   
 Value  
  
 Quantity  
Total - Receipts to date.   
 Value.  
Dated the 20.Subdivisional Officer.F.R. Form 9Report of the Value and Verification of unused
Materials.At Site Of[See Rules 294, 295, 297 and 307]Work - Constructing clerks' quarters at Ranchi
as on ......................... 20 ........................ Statement showing the quantities and values of materials
issued to the work and of those used in construction.
Name of Sub-Head of WorksUp to date
"progress"Description*Principal
Items†Petty
Items.‡Total  
 Ballast Lime Surkhi BricksR.S.
BeamsIron
Unit Cft. Mds. Cft. No.      
Value          
Quantities          
Pucca Masonry Unit Quantity Rate          
Arch MasonryConcreteR.S.
BeamsIron WorkStone mantle
piecesStone mantle pieces,
smallB. - Total used in
construction. 
 
Description of MaterialsPRINCIPAL
ITEMSPetty
ItemsTotal  
Ballast Lime Surkhi BricksR.S.
BeamsIron -
Unit Cft. Mds Cft. No. Cwt. Mds. -   
A. - Total issues as per F.R. Form8B. -
Total used in construction asper
statement overleaf.C. - Paper balances of
unusedmaterials (i.e. A. minus B).D. -
Actual balances afterverification.E -
Differences (i .e. C. minus D)F. - Remarks
explaining action taken to adjust
thedifferences as per E and if the work
has been completed, todispose of the
surplus balance as per line D. 
1 2 3 4 5 6 7 89etc.Bihar Financial Rules, 1950

(1) Due to less wastage. May becredited to
Concrete.(2) Trifling. May be debited
toPucca Masonry.(3) Shortage under
enquiry.(4) Trifling. May be credited
toPucca Masonry.(5) Shortage under
enquiry.(6) Shortage already written off
in S. E.'s no. 52, dated the4th January.
1919. The surplus materials may be sold.
* Both quantities and values should be shown, values being posted in red ink, just above the
corresponding quantities.† Only values should be shown in these two columns.‡ The quantity used
in construction should be calculated on the basis of the quantities of work executed, such authorised
formulae is being adopted for the purpose as may be in general use locally.†1. Certified that the
quantities of principal items and the value of the petty items, as shown in the above statement, have
been worked out as accurately as possible on the basis of the quantities of the work actually done.†2.
Certified that the quantities of the actual balances recorded against line D, are the results of
verification made by me on ....................... 20.†3. Certified that the balances of materials at site of
this work were verified by me on ................... 20 .................... and that the necessary report in this
form was submitted to the Divisional office as per this office no. .................. dated ........................
20†4. The balances of unused materials were not verified at any time during the year ....................
20 ..................... 20, as the accounts of this work are expected to be closed within three months.†5.
The balances of unused materials were not verified at any time during the year .................... 20
........................ 20, as the work was not under construction prior to January of this year.Dated
...................... 20Sub-divisional Officer.*The certificates not applicable to the case should be scored
out.Checked.Divisional Accountant.Dated ...................... 20Divisional Officer's Orders
1. The entries relating to the quantities used in construction are approved.
2. The surplus balances as per item D should be disposed of as under :-
3. (Here enter remarks and orders regarding adjustment of losses and
difference as per item E).
Items (3) and (5). Await S.D. O' s further report.Other items may be adjusted as recommended by
the S.D.O.Divisional Officer.Dated ................... 20F.R. Form 10.[See Rule 309.]
Detailed Completion Report.
DIVISION-
NAME OF WORK-
Amount of estimate- Rs.
Expenditure Rs.
Excess Rs.
Percentage of excess Rs.Bihar Financial Rules, 1950

Date of commencement-
Date of completion-
Names of Engineers and Subordinates by whomthe
work was supervised.
Name Period of Incumbency.
From To
 Immediate Charge.Sub-divisional
Officer.Executive Engineer. 
Explanation of Excesses.Name of work -Major head -Minor head -Detailed head of classification
-Reference to last schedule docket submitted -
Authority- No. For the month of
Sub-head
of
estimate.As-estimated. As-executed. Differences.Reference to
Paragraphs overleaf
explainingexcesses.
Quantity Rate. Amount Quantity. Rate. Amount. Quantity. Rate. Amount.
     
 Rs. Rs. Rs.  
Excesses to be entered in red ink, savings in black ink.Dated the 20 Executive Engineer.N.B. - In the
case of original works and special repairs, if any, considerable deviations from the sanctioned design
have occurred, the report of specification drawings and details of measurement of the work actually
done in the same form.as the estimate should accompany the Completion Report vide Rule 255.F.R.
Form 11.[See Rule 309.]Consolidated completion report of works and repairs outstanding
   Division.
   Month.
1.The statement of works and special
repairs completed duringthe month,
excess in respect of which requires
sanction of anauthority higher than the
Executive Engineer, should be
preparedseparately. Statement showing works and
repairs completed during the
monthor works and repairs in
progress during the month in
respect ofwhich excess has been
passed by the Executive
Engineer.
2.The statement of work and special
repairs completed and thosein progress
should not be included in the same
statement. Forwarded to the Accountant.
General, Bihar, Ranchi, vide
thisoffice no. ............... dated
   {|
for|
RecordVerification|
and transmission to the
Superintending Engineer.|-| 3.| As soon as the Executive Engineer has examined the registersof
works, two statements, one for works and special repairscompleted, and the other for works andBihar Financial Rules, 1950

repairs in progress inrespect of which excess has been passed by the ExecutiveEngineer, should be
submitted to the Audit Office for recordthere.|| Transmitted to the Superintending Engineer
Circle,videthis office no.............. dated, after verification.|-| Accountant General|-| 4.| No
completion statement is required for annual repairsestimates unless the excess is required to be
passed by anauthority higher than the Executive Engineer.|||}F.R. Form 11. -
Concld.DivisionMonthCompletion statement of works and repairs completed during the month of
............ statement of works and repairs in progress in excess in respect of which order has been
passed by the Executive Engineer.[See Rule 309].
Item no.Name of
estimateSanctionAmount
of
estimateExpended. Excess.Percentage
of excessDate of
completion.Remarks
explaining
excess,
steps taken
for
theassessment
of rent,
refund of
unspent
balance of
deposit
works,etc.,
etc.
Authority No. Date
1 2 3 4 5 6 7 8 9 1011
 
Executive Engineer Division.Divisional Accountant.F.R. Form 12[See Rule 381.]Statement of Loans
and Advances sanctioned by the State Government.year.
Name of
person
receiving
the loan.Amount of
loan
sanctioned.Rate of
interest.No. and
date of
orders
authorising
the loan.Balance
from
last
year.Amount
Received
this year.Total.Amount
repaid
during
the
year.Balance
of loan
at close
of the
year.Amount of
interest
reserved
and
credited
torevenueBalance
of
interest
unpaid.Remarks.
1 2 3 4 5 6 7 8 9 10 11 12
Rs. P. Rs. P. Rs. P. Rs. P. Rs. P. Rs. P. Rs. P. Rs. P. Rs. P. Rs. P. Rs. P.  
F.R. Form 13.[See Rule 393 Note.]Form of Mortgage.This Indenture made the ......................... day of
..................... two thousand and ................... between .................... of ................ a Civil Officer of
...................... (hereinafter referred to as the mortgagor which term shall where the context so
admits include his heirs, executors, administrators and assigns) of the one part and The Governor of
Bihar (hereinafter referred to as the mortgagee which term shall where the context so admits
include his successors and assign) of the other part.Whereas the mortgagor is absolutely seized and
possessed of or otherwise well entitled to the land hereditaments and premises hereinafter
described and expressed to be hereby conveyed, transferred and assured (hereinafter referred to as
the said hereditaments).And Whereas the mortgagor has applied to the mortgagee for an advance ofBihar Financial Rules, 1950

sum of the Rs........................ for the purpose of enabling him to defray the expenses [................]
[Insert 'the purchase of the said hereditament', 'building house on the said hereditaments' or
'repairing the said hereditament', as the case may be.] of as a suitable residence for his own use.And
Whereas under the provisions contained in Rule 388, et seq. of the Bihar Financial Rules
(hereinafter referred to as the said Rules which expression shall where the context so admits include
any amendment thereof or addition thereto for the time being in force) the mortgagee has agreed to
advance to the mortgagor the said sum of Rs................... [Payable as follows, that is to say, the sum
of Rs. ................. on or before the execution of these presents and the balance (unless and until the
power of sale applicable hereto shall have become exercisable) by equal instalments payable
quarterly, the first of such instalments to be payable on the ......................day of .................] [Delete
words in crotchets if advance is not to be paid by instalments.].Now This Indenture Witnesseth that
in pursuance of the said agreement and in consideration of the sum of Rs. .................... paid on or
before the execution of these presents to the mortgagor by the mortgagee (the receipt whereof the
mortgagor doth hereby acknowledge for the purpose of enabling the mortgagor to defray the
hereinbefore recited) expenses the mortgagor hereby covenants with the mortgagee to repay to the
mortgagee the said sum of Rs. ......................... [and such further sum as shall hereafter be paid by
him to the mortgagor pursuant to the hereinbefore recited agreement in that behalf)] [Ditto.] and
interest thereon calculated according to the said Rule on the ......................[day of .................next]
[Insert a date two and & half or five years as the case may be from the date of commencement of
repayment of the loan. Where possible the land should also be described with reference to
Government map or survey.] and if the loan shall not be repaid on that date will pay interest in
accordance with the said Rules.And This Indenture Also Witnesseth, that for the consideration
aforesaid the mortgagor doth hereby convey, transfer and assure unto the mortgagee All that piece
of land situate in the ............... district ........................ registration district of ................
sub-registration district of. .............. containing .................. more or less now in the occupation of
the mortgagor and bounded on the North by ................... on the South by .................. on the East by
............... and on the West by .... together with dwelling-house and the out offices, stables,
cook-rooms and out buildings now erected or hereafter to be erected on the said piece of land
together with all rights, easements and appurtenances to the said hereditaments or any of them
belonging To Hold the said hereditaments with their appurtenances including all erections and
buildings hereafter erected and built on the said piece of land unto and to the use of the mortgagee
absolutely subject to the proviso for redemption hereinafter contained Provided Always that if and
as the said advance of rupees .................... and [of such further sums as may have been paid as
aforesaid] [Delete Words in crochets if advance is not to be given by instalments.] made upon the
security of these presents shall have repaid and interest thereon calculated according to the said
Rule by the reduction of monthly instalments of the salary of the mortgagor as in the said Rules
mentioned or by any other means whatsoever than and in such case the mortgagee will upon the
request and at the cost of the mortgagor re-convey, re-transfer or re-assure the said hereditaments
unto and to the use of the mortgagor or as he may direct And it is hereby agreed and declared that if
there shall be any breach by the mortgagor of the covenants on his part herein contained or if he
shall die or quit the service before the said sum of Rupees.....................(and any further sum as may
have been paid as aforesaid) and interest thereon calculated according to the said Rule shall have
been fully paid off then and in any of such cases it shall be lawful for the mortgagee to sell the said
hereditament or any part thereof either together or in parcels and either by public auction or byBihar Financial Rules, 1950

private contract with power to buy in or rescind any contract for sale and to re-sell without being
responsible for any loss which may be occasioned thereby And to do and execute all such acts and
assurances for effectuating any such sale as the mortgagee shall think fit and it is hereby declared
that the receipt of the mortgagee for the purchase money of the premises sold or any part thereof
shall effectually discharge the purchaser or purchasers therefrom And it is hereby declared that the
mortgagee shall hold the moneys to arise from any sale in pursuance of the aforesaid power Upon
Trust in the first place thereout to pay all the expenses incurred on such sale and in the next place to
apply such moneys in or towards satisfaction of the moneys for the time being owing on the security
of these presents and then to pay the surplus (if any) to the mortgagor; And it is hereby agreed and
declared that the said Rules shall be deemed and taken to be part of these presents.The mortgagor
hereby covenants with the mortgagee that he, the mortgagor will during the continuance of this
security observe and perform all the provisions and conditions of the said Rules on his part to be
observed and performed in respect of these presents and the said hereditaments.In Witness
Whereof the mortgagor, hath hereunto set his hand the day and year first above written.Signed by
the said (Mortgagor)In the presence of 1st witnessAddressOccupation
2nd. witness
AddressOccupation(The deed should be registered.)Note. - There must be two witnesses to a
mortgage.F.R. Form 14[See Rule 394 Note.]Form of Mortgage for House Building Advances granted
to Government servants who do not possess full proprietory rights in the land upon which they
intend to build a house.This Indenture made the ........................... day of ..................... between
.................... of .................. a Civil Officer of .................. (hereinafter called the mortgagor which term
shall where not repugnant to the context include his heirs, executors, and administrators and
assigns) of the one part of and The Governor of Bihar (hereinafter referred to as the mortgagee
which term shall where not repugnant to the context include his successors and assigns) of the other
part.Whereas the mortgagor is entitled to the piece of land hereditaments and premises hereinafter
described under a lease date of from ..................... date .......... for a term of years
expiring[........................] [end of lease.] subject to a rental of Rs. ... per [.................] [mensem or
annum.]And Whereas the mortgagor has applied to the mortgagee for an advance of the sum of
rupees ......................... for the purpose of enabling him to defray expenses of [........................]
[Insert 'the purchase of the said hereditaments' building a house on the said a hereditaments' or
'Repairing the said hereditaments' as the case may be.] as a suitable residence for his own use.And
Whereas under the provisions contained in Rule 388 et seq. of the Bihar Financial Rules
(hereinafter referred to as the said Rules which expression shall where the context so admits include
any amendment thereof, or addition thereto for the time being in force and shall be deemed to form
part of these presents) the mortgagee has agreed to advance to the mortgagor the said sum of
Rs..................) payable as follows, that is to say, the sum of Rs. ......... on or before the execution of
these presents and the balance (unless and until the power of sale applicable hereto shall have
become exercisable) by ............... equal instalments payable quarterly the first of such instalments to
be payable on the .................... day of [................] [Delete words in crotchets if further advances are
not to be made.]Now This Indenture Witnesseth that in consideration of the said advance and in
pursuance of the said agreement the mortgagor doth hereby covenant with the mortgagee to pay to
the mortgagee the said sum of rupees...(and such further sums as shall hereafter be paid by him toBihar Financial Rules, 1950

the mortgagor pursuant to the hereinbefore recited agreement in that behalf [and interest thereon
calculated according to the said Rules on the] [Delete words in crotchets if further advances are not
to be made.] day [...................] [Two and a half or five years from date of commencement of
repayment of loan as the case may be.] next and if the loan shall not be repaid on that date, will pay
interest in accordance with the said rules.And The Indenture Also Witnesseth that for the
consideration aforesaid the mortgagor doth hereby demise, let and transfer unto the mortgagee ALL
THAT piece of land situate in...................in the registration district of .............. sub-district
................... thana .................. containing ................... more or less and bounded on the North by
................... on the South by ..................... on the East by ..... and on the West by. ...together with the
dwelling-house and the out-offices, stables, cook-rooms and outbuildings and all kinds used or
intended to be used with the said dwelling house [(lately erected)] [Or 'hereafter to be erected or
now being erected as the case may be.] together with all rights, easements and appurtenances to the
same of any of them belonging to Hold the said premises including all erections and buildings here
after erected on the said land unto the mortgagee, his successors and assigns for all the residue now
unexpired of the said term of years granted by the said lease except the last day of the said term
Provided Always that if and as soon as the said advance of Rs. ................... [and of such further sums
as may have been paid aforesaid] made upon the security of these presents and interest thereon
calculated according to the said Rules shall have been repaid by the deduction of monthly
instalments of the salary of the mortgagor as in the said Rules mentioned or by any other means
whatsoever the demise hereby made shall be void And the mortgagor hereby covenants with the
mortgagee that the lease creating the term or state for which the said land is held by the mortgagor
is now a good, valid and effectual lease and is in full force un-forfeited and un-surrendered and free
from encumbrances and in nowise become void or voidable and that all the rents reserved thereby
and all the covenants, conditions and agreements contained therein and on his part to be paid,
observed and performed have been paid, observed and performed upto the date of these presents
AND also that the mortgagor will at all times so long as any money remains due on the security of
these presents pay, observe and perform or cause to be paid, observed and performed all the said
rents, covenants, conditions and agreements and will keep the mortgagee indemnified against all
actions, proceedings, costs, charges, claims and demands, if any to be incurred or sustained by the
mortgagee by reason of the non-payment of the said rent or the non-observance or
non-performance of such covenants, conditions or agreements or any of them And Also that the
mortgagor now has good right and full powers to demise the said premises to the mortgagee in
manner aforesaid AND THAT IT SHALL BE LAWFUL For The Mortgagee To Enter Into and Upon
and to hold and enjoy the said demised premises during the terms hereby granted without any
interruption or disturbance by the mortgagor or any person claiming through or in trust for him,
And That the mortgagor at the request at any time hereafter of the mortgagee will at his own cost
execute and do all such assurance and things as may be necessary or proper for more effectually
vesting the said premises in the mortgagee in manner aforesaid as may by the mortgagee be
reasonably required Provided Always and it is hereby agreed and declared that if there shall be any
breach by the mortgagor of the covenants on his part here in contained or if he shall die or quit the
service at any time before all sums due or payable to the mortgagee on the security of these presents
shall have been fully paid of, then and in any of such cases it shall be lawful for the mortgagee to sell
the said premises or buildings or any part thereof either together or in parcels and either by public
auction or by private contract with power to buy in or to rescind any contract for sale and to re-sellBihar Financial Rules, 1950

without being responsible for any loss which may be occasioned thereby or to let the same for any
term or period and to do and execute all such acts and assurances for effectuating any such sale or
letting as the mortgagee shall think fit And it is hereby declared that the receipt of the mortgagee for
the purchase money of the premises sold or any part thereof shall effectually discharge the
purchaser or purchasers therefrom And it is hereby declared that after any sale of the said premises
or any part thereof under the aforesaid power the mortgagor shall stand possessed of the premises
so sold for the last day of the term granted to him by the hereinbefore recited lease in trust for the
purchaser, his executors, administrators and assigns to be assigned and disposed of as he or they
may direct and it is hereby declared that the mortgagee shall hold any rents, profits, premiums,
salami or moneys arising from the premises or from any such letting or sale as aforesaid Upon Trust
In The first place there out to pay all expenses attending such sale or otherwise incurred in relation
to this security and in the next place to apply such money in or towards satisfaction of the moneys
for the time being owing on the security of these presents and then to pay the surplus, if any to the
mortgagor And It Is Hereby Declared that no lease made by the mortgagor of the said premises or
any part thereof during the continuance of this security shall have effect unless the mortgagee shall
consent thereto in writing. In Witness Whereof the mortgagor has hereunto set his hand the day and
year first above written.Signed by the said (Mortgagor)In the presence of -
1st. witness -
Address -Occupation -
2nd. witness -
Address -Occupation -(The deed should be registered)Note. - There must be two witnesses to a
mortgagee.F.R. Form 15[See Rule 393, Note.]Form of Re-conveyance for house-building
Advances.This Indenture made the ........................... day of .................. 20 ........................ Between
The Governor of Bihar (hereinafter called the Governor) of the one part and ..................... a Civil
Officer of ................ (hereinafter called the mortgagor) of the other part is supplemental to an
Indenture of mortgage dated the ... day of ... 20 and made Between the mortgagor of the one part
and Governor of the other part and registered at ................... in book .................. volume
...................... pages .................. to ................... as no. ................. for ................... (hereninafter called
the Principal (Indenture) Whereas all moneys due and owing on the security of Principal Indenture
have been fully paid and satisfied and the Governor has accordingly at the request of the mortgagor
agreed to execute such re-conveyance of the mortgaged premises in the within written Indenture
comprised as is hereinafter contained. Now This Indenture Witnesseth That In Pursuance Of The
Said Agreement and in consideration of the premises the Governor doth hereby grant, assign and
reconvey unto the mortgagor, his heirs, executors, administrators and assigns All That the piece of
land situate in the .................... containing ................. more or less bounded on the North by
...................... on the South by .................. on the East by ................. on the West by ............ together
with the dwelling house and out-offices, stables, cook-rooms and out-building thereon And All, and
singular other than the premises in the Principal Indenture comprised or expressed to be thereby
assured or which now are by any means vested in the Governor subject to redemption under or by
virtue of the Principal Indenture with their rights easements and appurtenances as in the PrincipalBihar Financial Rules, 1950

Indenture expressed and all the estates right, title, interest, property, claim and demand whatsoever
of the Governor into, out of or upon them same premises by virtue of the Principal Indenture to
have and to hold the premises hereinbefore expressed to be hereby granted, assigned and
reconveyed unto and to the use of the mortgagor, his heirs, executors, administrators and assigns
for ever freed and discharged from all money intended to be secured by the Principal Indenture and
from all actions, suits, accounts claims and demands for, or, in respect of, the said money, or any
part thereof or, for or in respect of the Principal Indenture or of anything relating to the premises
And the Governor hereby covenants with the mortgagor, his heirs, executors, administrators and
assigns that the Governor has not done or knowingly suffered or been party or privy to any thing
where-by the said premises or any part thereof, are, is or can be impeached, encumbered or affected
in title, estate or other otherwise however. In Witness whereof the parties hereto have hereunto set
their hands and seals the day and year first above written.Signed, sealed and delivered by,
.................... for and on behalf of the Governor of Bihar (acting in the premises for and on behalf of
the Secretary of State for India in Council) in the presence of ...................F.R. Form 16[See Rule 400
sub-paragraph.]Form of Agreement to be executed at the time of drawing an advance for the
purchase of land on which to construct a house or of a house ready-made.An Agreement Made on
............................ day of ..................... two thousand and ; between ... to .....................................
(hereinafter called the Borrower, which expression shall include his legal representatives and
assignees) of the one part and The Governor of Bihar (hereinafter called the Governor) of the other
part. Whereas The Borrower has agreed to purchase for the purpose of erecting a house thereon the
piece of land situated in ................ a house ................ in the registration district of .............
sub-district ......... thana .......................... containing .............. more or less and bounded on the
North by .................. on the South by ............... on the East by ................... and on the West by
............ for the sum of Rupees ............And Whereas The Borrower has under the provisions of the
Bihar Financial Rules (hereinafter referred to as the said Rules which expression shall include any
amendments thereof for the time being in force) applied to the Governor for a loan of Rupees
.................. to enable him to purchase the said piece of house/land and the Governor has agreed to
lend the said sum of Rupees ........................ to the Borrower on the terms and conditions hereinafter
contained. Now It Is Hereby Agreed between the parties hereto that in consideration of the sum of
Rupees ................. paid by the Governor to the Borrower (the receipt of which the Borrower hereby
acknowledges) the Borrower hereby agrees with the Governor (1) to repay the Governor the said
amount with interest calculated according to the said Rules by monthly deductions from his salary
as provided for by the said Rules and hereby authorises the Governor to make such deductions and
(2) within one month from the date of these presents to expend the full amount of the said loan in
the purchase of the said piece of house/land and if the actual price paid is less than the loan to repay
the difference to the Governor forthwith and (3) to execute a document mortgaging the said piece of
house/land and the house to be erected thereon to the Governor as security for the amount lent to
Borrower as aforesaid and interest in the form provided by the said Rules (*And It Is Hereby
Further Agreed that the Borrower shall immediately he has purchased the said piece of land
commence and erect thereon a suitable residence for his own use). And It Is Hereby Lastly Agreed
And Declared that if the said piece of house/land has not been purchased and mortgaged as
aforesaid within one month from the date of these presents or if the Borrower within that period
becomes insolvent or quits the service of Government or dies the whole amount of the loan and
interest accrued thereon shall immediately become due and payable.In Witness Whereof theBihar Financial Rules, 1950

Borrower has hereunto set his hand the day and year first before written.Signed by the said in the
presence of ................* To be omitted in the case of purchase of a house.F.R. Form 17.[See Rule 400
sub-paragraph.]Form of Mortgage Deed to be executed in connection with an advance for the
purchase of land on which to construct a house.This Indenture made the .......................... day of
................. two thousand and ............... Between ....................................... of ...................................... a
Civil Officer of ............... (hereinafter called the mortgagor which term shall where not repugnant to
the context include his heirs, executors and administrators and assignees) of the one part and The
Governor of Bihar (hereinafter referred to as the mortgagee which term shall where not repugnant
to the context include his successors and assignees) of the other part.Whereas by an agreement
dated the ....................... day of ................ 20 ................. and made between the mortgagor of the one
part and the mortgagee of the other part the mortgagee advanced and lend to the mortgagor the sum
of Rs. ....................for the purpose of purchasing the piece of land hereinafter described and
intended to be hereby transferred and assured and as security for such loan the mortgagor agreed to
execute a mortgage in favour of the mortgagee in the form of these presents And Whereas the
mortgagor on the ................ day of ................. 20 ................ duly purchased the said piece of land
and is now absolutely seized and possessed of or otherwise well entitled to the said piece of land And
Whereas the mortgagor has applied to the mortgagee for a further advance of the sum of Rupees
..................... for the purpose of enabling him to defray the expenses of erecting on the said piece of
land a suitable residence for his own use And Whereas under the provisions contained in Rule 388,
etc. of the Bihar Financial Rules (hereinafter referred to as the said Rules which expression shall
where the context so admits include any amendment thereof or addition thereto for the time being
in force and shall be deemed to form part of these presents) the mortgagee has agreed to advance to
the mortgagor the said further sum of Rupees.................. (payable as follows that is to say the sum of
Rupees....................on or before the execution of these present) and the balance (unless and until the
power of sale applicable hereto shall have become exercisable) by .................... equal instalments
payable quarterly the first of such .............. instalments to be payable on the ................. day of
..................................Now This Indenture Witnesseth that in consideration of the said advances of
Rupees .................... and Rupees .................. making a total of Rupees .................. so advanced as
aforesaid and in pursuance of the said agreement the mortgagor doth hereby covenant with the
mortgagee to pay to the mortgagee the said sum of Rupees ..................... (and such further sums as
shall hereafter be paid by him to the mortgagor pursuant to the hereinbefore recited agreement in
that behalf)* and interest thereon calculated according to the said Rules on the .................. day of
................. next and if the loan shall not be repaid on that date will pay interest in accordance with
the said Rules.* To be deleted if the payment is not to be by instalment.And The Indenture Also
Witnesseth that for the consideration aforesaid the mortgagor doth hereby transfer, assign and
assure into the mortgagee All That piece of land situate in ....................... in the registration district
of ................. sub-district ...................... thana ................... containing ..................... more or less and
bounded on the North by .............................. on the South by ...................... on the East by
..................., and on the West by .................. together with the dwelling house and the out offices,
stables, cook-rooms and out-buildings and all kinds used or intended to be used with the said
dwelling house erected or hereafter to be erected on the said piece of land together with all rights,
easements and appurtenances to the same or any of them belonging To Hold the said premises
including all erections and buildings hereafter erected on the said land (hereinafter referred to as
the said premises) and unto and to the use of the mortgagee absolutely subject to the provision forBihar Financial Rules, 1950

redemption hereinafter contained Provided Always that if and as soon as the said advance of Rupees
.................... (and of such further sums as may have been paid as aforesaid) made upon the security
of these presents and interest thereon calculated according to the said Rules shall have been repaid
by the deduction of monthly instalments of the salary of the mortgagor as in the said Rules
mentioned or by any other means whatsoever then and in such case the mortgagee will upon the
request and at the cost of the mortgagor re-convey, re-transfer or re-assure the said premises unto
and to the use of the mortgagor And the mortgagor hereby covenants with the mortgagee that the
mortgagor now hath good right to transfer the said premises unto the mortgagee free from
encumbrance And Further that the mortgagor and all other persons having or lawfully claiming any
estate or interest in the said premises or any part thereof, shall and will from time to time and at all
times hereafter at his or their own cost do and execute or cause to be done and executed all such
acts, deeds and things for further and more perfectly assuring the said premises unto the mortgagee
in manner aforesaid as shall or may be reasonably required Provided Always and it is hereby agreed
and declared that if there shall be any breach by the mortgagor of the covenants on his part herein
contained or if he shall die or quit the service at any time before all sums due or payable to the
mortgagee on the security of these presents shall have been fully paid off then and in any such cases
it shall be lawful for the mortgagee to sell the said premises or buildings standing thereon or any
part thereof, either together or in parcels and either by public auction or by private contract with
power to buy in or to rescind any contract for sale and to re-sell without being responsible for any
loss which may be occasioned thereby or to let the same for any term or period and to do and
execute all such acts and assurances for effectuating any such sale or letting as the mortgagee shall
think fit And It Is Hereby Declared that the receipt of the mortgagee for the purchase money of the
premises sold or any part thereof, shall effectually discharge the purchaser or purchasers therefrom
And It Is Is Hereby Declared that the mortgagee shall hold any rents, profits, premiums, salami or
moneys arising from the premises or from any such letting or sale as aforesaid UPON trust in the
first place thereout to pay all expenses attending such sale or otherwise incurred in relation to this
security and in the next place to apply such moneys in or towards satisfaction of the moneys for the
time being owing on the security of these presents and then to pay the surplus if any to the
mortgagor And It Is Hereby Declared that no lease made by the mortgagor of the said premises or
any part thereof, during the continuance of this security shall have effect unless the mortgagee shall
consent thereto in writing.In Witness whereof the mortgagor hath hereunto set his hand the day and
year first above written.Signed By the said (Mortgagor) in the presence of-
1st. Witness.
Address.Occupation.
2nd. Witness.
Address.Occupation.[F.R. Form 17A] [Inserted by C.S. 19 dated 27.4.1961.][See Rule 407]Bihar Financial Rules, 1950

of the Deduction of Motor Car/Motor Cycle Advances during the
Month... 20.
Full name and
designation of
the officer in
blockletter.Amount of
advance
drawn.No. & date of T.V.
including the name
of theDistrict with
head of Account in
which the Advance
has beendrawn.Number of
instalments.Amount of
instalments.Balance
of
amount
to be
paid.Remarks.
(a) Service to
which the
officer is
member.(b) Head
of
Account.
1 2 3 4 5 6 7 8
 
F.R. Form 18[See Rule 411]Form of Agreement to be executed at the time of drawing an advance for
the purchase of a motor vehicle.An-Agreement Made On ............................. day .................... two
thousand and ....................... between ................... of ................... (hereinafter called the Borrower
which expression shall include his heirs, administrators, executors and legal representatives) of the
one part and the Governor of Bihar (hereinafter called the Governor, which, expression shall include
his successors and assignees) of the other part. Whereas the Borrower has under the provision of the
Bihar Financial Rules hereinafter referred to as the said Rules which expression shall include any
amendments thereof for the time being in force applied to the Governor for a loan of Rs. ... for the
purchase of a motor vehicle and whereas the Governor has agreed to lend the said amount to the
Borrower on the terms and conditions hereinafter contained, Now It Is Hereby Agreed between the
parties hereto that in consideration of the sum of Rs. ................. paid by the Governor the Borrower
(the receipt of which the Borrower hereby acknowledges the Borrower hereby agrees with the
Governor (1) to pay the Governor the said amount with interest calculated according to the said
Rules by monthly deductions from his salary as provided in the said Rules and hereby authorises the
Governor to make such deductions and (2) to expend the full amount of the said loan within one
month from the date of these presents in purchase of a motor vehicle or if the actual price paid is
less than the loan to repay the difference to the Governor forthwith and (3) to execute a document
hypothecating the said motor vehicle to the Governor a security for the amount lent to the Borrower
as aforesaid and interest in the form provided by the said Rules and It Is Hereby Lastly Agreed and
Declared That If The Motor Vehicle has not been purchased and hypothicated as aforesaid within
one month from the date of these presents or if the Borrower within that period becomes insolvent
or quits the service of the Government or dies, the whole amount of the loan and interest accrued
thereon shall immediately become due and payable.In Witness whereof the Borrower and
...................... for and on behalf of the Governor have hereunto set their hands the day and year first
before written.
Signed by the said* in the presence of  
(Signature of witnesses.)Bihar Financial Rules, 1950

(Signature and designation of the
Borrower.)
for and on behalf of the Governor of Bihar in the
presence of- 
(Signature of witnesses.)(Signature and designation of the
Officer.)
* Name and designation of the Borrower.F.R. Form 19[See Rule 411]Form of Mortgage bond for
Motor vehicle advanceThis Indenture Made this .........................day of ................... two thousand
and ..................... Between ..................... (hereinafter called "the Borrower", which expression shall
include his heirs, administrators, executors and legal representatives of the one part and the
Governor of Bihar (hereinafter called "the Governor", which expressions shall include his successors
and assignees) of the other part. Where As the Borrower has applied for and has been granted an
advance of Rs. ................... to purchase a Motor vehicle on the terms of the Rules in Rules 404 to 418
of the Bihar Financial Rules (hereinafter referred to as "the said Rules" which expression shall
include any amendment thereof or addition thereto for the time being in force) And whereas one of
the conditions upon which the said advance has been/was granted to the Borrower is/was that the
Borrower will/would hypothecate the said Motor vehicle to the Governor as security for the amount
lent to the Borrower And Whereas The Borrower has purchased with or partly with the amount so
advanced as aforesaid the Motor vehicle particulars whereof are set out in the Schedule hereunder
written.Now This Indenture Witnesseth that in pursuance of the said agreement and for the
consideration aforesaid the Borrower doth hereby covenant to pay the Governor the sum of
Rs.........................aforesaid or the balance thereof remaining unpaid at the date of these presents by
equal payments of Rs. ................... each on the first day of every month and will pay interest on the
sum for the time being remaining due and owing calculated according to the said Rules and the
Borrower doth agree that such payments may be recovered by monthly deductions from his salary in
the manner provided by the said Rules and in further pursuance of the said agreement the Borrower
doth hereby assign and transfer unto the Governor the Motor vehicle the particulars whereof are set
out in the Schedule hereunto written by way of security for the said advance And The Interest
Thereon as required by the said Rules.And The Borrower doth hereby agree and declare that he has
paid in full the purchase price of the said Motor Vehicle and that the same is his absolute property
and that he has not pledged and so long as any money remains payable to the Governor in respect of
the said advance will not sell, pledge or part with the property in or possession of the said motor
vehicle. Provided always and it is hereby agreed and declared that if any of the said instalments "of
principal or interest" shall not be paid or recovered in manner aforesaid within ten days after the
same are due or if the Borrower shall die or at any time cease to be in Government service or if the
Borrower shall sell or pledge or part with the property in or possession of the said Motor vehicle or
become insolvent or make any composition or arrangement with his creditors or if any person shall
take proceedings in execution of any decree or judgement against the Borrower the whole of the said
principal sum which shall then be remaining due and unpaid together with interest thereon
calculated as aforesaid shall forthwith become payable And It Is Hereby Agreed and declared that
the Governor may on the happening of any of the events hereinbefore mentioned seize and take
possession of the said motor vehicle and either remain in possession thereof, without removing the
same or else may, remove and sell the said Motor vehicle either by public auction or private contract
and may out of the sale moneys retain the balance of the said advance then remaining unpaid andBihar Financial Rules, 1950

any interest due thereon calculated as aforesaid and all costs, charges, expenses and payments
properly incurred or made in maintaining, defending or realising his rights hereunder and shall pay
over the surplus, if any to the Borrower, his executors, administrators or personal representatives
Provided Further that the aforesaid power of taking possession or selling of the said Motor Vehicle
shall not prejudice the right of the Governor to sue the Borrower or his personal representatives for
the said balance remaining due and interest or in the case of the Motor Vehicles being sold the
amount by which the net sale proceeds fall short of the amount owing And the Borrower hereby
further agrees that so long as any money are remaining due and owing to the Governor, he the
Borrower will insure and keep insured the said motor vehicle against loss or damage by fire, theft or
accident with an Insurance Company to be approved by the Accountant General Bihar, and will
produce evidence to the satisfaction of the Accountant General that the Motor Insurance Company
with whom the said Motor vehicle is insured have received notice that the Governor is interested in
the Policy and the Borrower hereby further agrees that he will not permit or suffer the said Motor
vehicle to be destroyed or injured or to deteriorate in a greater degree than it would deteriorate by
reasonable wear and tear thereof And further that in the event of any damage or accident happening
to the said Motor vehicle the Borrower will forthwith have the same repaired and made good.The
ScheduleDescription of Motor vehicle.Maker's nameDescription.No. of cylindersEngine
NumberChasis no.Cost priceIn Witness whereof the said ....................... (Borrower's name) and
...................... for and on behalf of the Governor have hereunto set their respective hands the day
and year first above written.
Signed by the said* in the presence of
1. ... ......... 
2. ... ......... 
(Signature of witnesses)(Signature and designation of the
Borrower)
Signed by (name and designation)
... ... ......... 
for and on behalf of the Governor of Bihar in the
presence of
1. ... ......... 
2. ... ......... 
(Signature of witnesses.)(Signature and designation of the
Officer.)
* Name and designation of the Borrower.Appendix 'A'[See under Rule 417][Form of agreement to be
executed at the time of drawing an advance for the purchase of motor car under Parliamentary
Secretaries (Motor Car Advance) Rules, 1961.] [Published in Bihar Gazette (extraordinary) dated
25.5.1961.]An Agreement made this ........................ day of ................. two thousand and ...................
between .................................. (hereinafter called the Borrower, which expression shall include his
heirs, administrators, executors and legal representatives of the one part and the Governor of Bihar
(hereinafter called the Governor which expression shall include his successors and assignees) of the
other part. Whereas the Borrower has under the provisions of the Rules in the Parliamentary
Secretaries (Motor Car Advance) Rules, 1961 (hereinafter referred to as the said Rules whichBihar Financial Rules, 1950

expression shall include any amendment thereof for the time being in force) applied to the Governor
for a loan of Rs..., for the purchase of a motor car and whereas the Governor has agreed to lend the
said amount to the Borrower on the terms and conditions hereinafter contained, Now It Is Hereby
Agreed between the parties thereto that in consideration of the sum of Rs. ......................................
paid by the Governor to the Borrower hereby agrees with the Governor (1) to pay the Governor the
said amount without any interest accruing thereon by monthly deductions from his salary as
provided in the said Rules and hereby authorise the Governor to make such deduction and (2) to
expand the full amount of the said loan unless otherwise specially permitted by the Governor in
writing within one month from date of these presents in purchase of a motor car or if the actual
price paid is less than the loan, to repay the difference to the Governor forthwith and (3) to execute a
document hypothecating the said motor car to the Governor as security for the amount lent to the
Borrower as aforesaid without any interest accruing thereon and It Is Hereby Lastly Agreed and
Declared that if the motor car not been purchased and hypothecated as aforesaid within one month,
or the period allowed, as the case may be, from the date of these presents, or if the Borrower within
that period ceases to be a Parliamentary Secretary or dies, the whole of the loan shall immediately
become due and payable.In witness whereof Borrower and ................... for and on behalf of the
Governor have hereunto set their hand the day and year first before written.Signed by the said
(Borrower) ....................................................................... in the presence of
......................................................(Signature of witness.)....................................................(Signature
and designation of the Borrower.)Signed by
................................................................................................. (Name and designation) for and on
behalf of the Government of Bihar in respect of-(Signature and designation of the
Officer.).......................................(Signature of witness.)Appendix 'B'Form of Mortgage Bond for
Motor Car Advance under the Parliamentary Secretaries (Motor Car Advance) Rules, 1961.This
Indenture made this ...................... day of ................ two thousand and .................... between
................. (hereinafter called "the Borrower" which expression shall include his heirs,
administrators, executors and legal representatives) of the one part and the Governor of Bihar
(hereinafter called "the Governor", which expression shall include his successors and assignees) of
the other part. Whereas the Borrower has applied for and has been granted an advance of Rs.
................. to purchase a motor car on the terms of the Rules in the Parliamentary Secretaries
(Motor Car Advance) Rules, 1961 (hereinafter referred to as "the said Rules", which expression shall
include any amendment thereof or addition hereto for the time being in force) And Whereas one of
thereon conditions upon which the said advance has been/was granted to the Borrower is/was that
the Borrower will/would hypothecate the said Motor Car to the Governor as security for the amount
lent to the Borrower And Whereas to the Borrower has purchased with or partly with the amount so
advanced as aforesaid the Motor Car the particulars whereof are set out in the Schedule hereunder
written.Now This Indenture Witnesseth that in pursuance of the said agreement and for the
consideration aforesaid the Borrower doth hereby covenant to pay to the Governor the sum of Rs.
.................. aforesaid or the balance thereof remaining unpaid at the date of these presents by equal
payments of Rs. .................. each on the first day of every month without any interest accruing on
the sum for the time being remaining due and the Borrower doth agree that payments may be
recovered by monthly deduction from the salary in the manner provided by the said Rules, and in
further pursuance of the said Agreement, the Borrower doth hereby assign and transfer unto the
Governor the Motor Car the particulars whereof are set out in the Schedule hereunto written by wayBihar Financial Rules, 1950

of security for the said advance without any interest accruing thereon as required by the said Rule.
And Borrower doth hereby agree and declare that he has paid in full the purchase price of the said
Motor Car and that the same is his absolute property and that he has not pledged and so long as any
money remains payable to the Governor in respect of the said advance, will not sell, pledge or part
with the property in or possession of the said Motor Car:Provided Always and it is hereby agreed
and declared that if any of the said instalments shall not be paid or recovered in manner aforesaid
within ten days after the same are due or if the Borrower shall die or at any time ceases to be a
Parliamentary Secretary or if the Borrower shall sell or pledge or part with the property in
possession of the said Motor Car or make any composition or agreement with his creditor or if any
person shall take proceedings in execution of any decree or judgment against the Borrower the
whole of the said sum which shall then be remaining due and unpaid said forthwith become payable.
And it is hereby agreed and declared that the Government may on the happening of any of the
events hereinbefore mentioned seize and take possession of the said Motor Car and either remain in
possession thereof without removing the same or else may remove and sell the said Motor Car either
by public auction or private contract and may out of the sale moneys retain the balance of the said
advance then remaining unpaid without any interest accruing thereon as aforesaid and all costs,
expenses and payments properly incurred or made in maintaining, defending or realising his rights
hereunder and shall pay over the surplus if any to the Borrower, his executors, administrators or
personal representative:Provided Further that the aforesaid power of taking possession or selling of
the said Motor Car shall not prejudice the right to the Governor to use the Borrower or his
representative for the said balance remaining due or in the Motor Car being sold the amount by
which the net sale proceeds fall short of the amount owing and the Borrower hereby further agrees
that so long as any moneys are remaining due and owing to the Government he the Borrower will
insure and keep insured and said Motor Car against loss or damage by fire, theft or accident with an
Insurance Company to be approved by the Accountant-General, Bihar and will produce evidence to
the satisfaction of the Accountant-General, that the Motor Insurance Company with whom the said
Motor Car is insured have received notice that the Governor is interested in the policy and the
Borrower hereby further agrees that he will not permit or suffer the said Motor Car to be destroyed
to injured or to deteriorate in a greater degree than it would deteriorate by reasonable wear and tear
thereof and further that in the event of any damage or accident happening to the said Motor Car the
Borrower will forthwith have the same repaired and made good.The ScheduleDescription of Motor
Car -Maker's name -Description -No. of cylinders -Engine no. -Chasis no. -Cost Price -In Witness
whereof the said ...................... (Borrower's name) and .................... for and on behalf of the
Governor have here-unto set their respective hands the day and year first above written.Signed by
the said ....................... (Borrower's name and designation) in the presence of-
1. ......................................................
2. ......................................................
(Signature of witnesses.)................................................................(Signature and designation of the
Borrower.)Signed by (name and designation) for and on behalf of the Governor of Bihar in the
presence of-Bihar Financial Rules, 1950

1. ......................................................
2. ......................................................
(Signature of witnesses.)Signed by (name and
designation.)...........................................................(Signature and designation of the Officer.)F.R.
Form 20[See Rule 414 (3)]Form of the clause to be inserted in Motor Vehicle Insurance Policies
1. It is hereby declared and agreed that Shri ................... (the owner of the
Motor Car hereinafter referred to as the insured in the schedule to this policy)
has hypothecated the car to the Government of Bihar as security for advance
for the purchase of the Motor Car and it is further declared and agreed that
the Government is interested in any money which but for this endorsement
be payable to the said Shree ...................... (the insured under this policy) in
respect of the loss or damage to the said Motor Car (which loss or damage is
not made good by repairs; re-instalment or replacement, and such moneys
shall be paid to the Government of Bihar as long as he is) the mortgagee of
the Motor Car and receipt passed by a duly authorised officer of the
Government of Bihar shall be a valid discharge to the Company in respect of
such moneys.
2. Save as by this endorsement expressly agreed nothing herein shall modify
or affect the rights or liabilities of the insured or the Company respectively
under or in connection with this policy or any term, provision or condition
thereof.
F.R. Form 21[See Rule 422]Sanction to advance for purchase of a bicycle.To,The
Accountant-General, BiharSubject. - Grant of an advance of Rs. ..................) to Shree .......................
for the purchase of a bicycle.Order - Sanctioned.*2. "Shri ............. is a permanent/temporary
Government servant and his substantive/officiating pay is Rs. ................. per month. He was born in
the ................"
3. The advance will be recovered from his pay in 24 monthly instalments, viz.,
(Rupees ............) 23 instalments of Rs. ...................... each and the 24th
instalment of Rs. ................ only plus an additional instalment representing
interest at the prescribed rate of 4 per cent of the total advance. In the event
of the Government servant retiring or relinquishing the service within the
period, the whole outstanding balance will be recovered in one instalment
from his last pay.Bihar Financial Rules, 1950

4. The bicycle purchased with the advance will remain the property of
Government till the advance has been recovered in full together with interest
thereon.
5. The sanction herein conveyed will remain valid for a period of six months
from the date of issue.
6. Shree ........................ has been instructed not to ask for payment of the
advance until the money is actually required. When he wishes to draw the
amount sanctioned he should write to the Accountant-General, Bihar, for
authority which will remain valid for a period of fortnight from the date of its
issue.
7. The amount is sanctioned on the outstanding that a bicycle is purchased
within a fortnight of the date of drawing the advance and the amount taken as
an advance is limited to the price of it.
* Inserted by Correction Slip No. 3, dated the 9th June, 1958.[F.R. Form 21-A.] [Substituted by F.D.
Memo No. T2-10106/57/100018 F. dated 27.7.1967.][See Rule 426 A]Form of Surety Bond to be
executed by a permanent Government Servant.Know all men by these presents that I ............. son of
............................... a resident of .......... in the district of ........... at present employed as permanent in
the Department hereinafter called "the surety", am firmly bound unto the Governor of Bihar
(hereinafter called "the Governor") in the sum of Rs. .............. together with interest thereon for
which payment to be well and truly made, I hereby bind myself, my heirs, executors, administrators
and representatives by these presents sealed with my seal this day .......................Whereas
...................... son of ....................... resident of ................. in the district of ................... at present
employed as a temporary ................. in the ........................ Department/Office hereinafter called "the
borrower") has at his own request, been granted by Governor a loan of Rs. ...................... for the
purchase of a typewriter for his own use and that the said borrower has undertaken to repay the said
amount in 49 equal monthly instalments of Rs. ........................ each, and the 50th of Rs.
....................... only with interest at the rate from time to time fixed for the purpose by the Governor
and has agreed that until repayment, the typewriter shall remain the property of the Government
and will not be liable to forfeiture in the event of any instalment remaining unpaid.
3. Now the condition of this obligation is such that if the said borrower shall,
while employed in the said ..................... Department/Office duly and regularly
pay or cause to be paid to the Governor the amount of the loan aforesaid in
instalments with interest on the whole or such amount as shall from time to
time remain owing on the first day of each calendar month, the first said sum
being Rs. ................. payable on 1st day of the month, after drawal of advanceBihar Financial Rules, 1950

together with interest thereon shall be fully paid, then this bond shall be void,
otherwise the same shall be and remain in full force. But nevertheless that if
the borrower will make any default in paying the monthly instalments as and
when they will fall due, or die or become insolvent or at any time cease to be
in the service of the Governor, the whole or so much of the said principal
sum of Rs. .................... as shall then remain unpaid, together with interest
which shall have accured thereon, shall immediately become payable to the
Governor and be recoverable from the surety in one instalment by virtue of
this bond.
WitnessSigned by ...........................Place ..................................Date ...................................[F.R. Form
22] [Substituted by F.D. Memo No. T2-10106/57/100018-F. dated 27.7.1967.][See Rule 474.]Slip to
accompany claims for money of disbursing officers on treasuries.(to be returned in original by the
Treasury Officer)Major HeadMinor HeadSub-HeadPrevious ExpenditureExpenditure up-to-date.
  (To be filled in the Treasury)
To  To,
The TreasuryOfficer...............................  The......................
Please furnish the Treasury Voucher No. and date of
the billsent herewith for encashment. Returned with Treasury Voucher No. and
date as noted below :-
Signature ..............................DrawingOfficer
................... Signature..................................Treasury
Officer.......................
B.No. ParticularGross
AmountNet
AmountAmount paid- .....................T.V.
No.....................................Signature
.............................Treasury
Accountant...................
  Rs. P. Rs. P.
 
Signature of
Accountant
........
[F.R. Form 22-A] [Inserted by correction slip no. 7, dated the 15th July, 1958.][See Rule
474]Register of T.V. slips to be maintained in the Treasury.
Sl.
No.Designation
of the
drawing
officer.Gross
amount
of the
bill.Net
amount
of the
bill.Description
of the bill.T.V.
No. &
date.Full
signature of
the person
receiving the
T.V.slip.Treasury's
memo no.
with which for
warded to
thedrawing
officer.Remarks.
1 2 3 4 5 6 7 8 9Bihar Financial Rules, 1950

 
F.R Form 23[See Rule 475]Register showing expenses by Heads of Account.
Office
of.................................Month
...................................Head of account -..................................Major
head.......................................Minor
head..........................................Sub-head
..........................................
No. of Voucher.Sub-head of
Grants
 Deduction if any -Net amount of the
bill.
Allotment.  
Total for the monthTotal from 1st AprilBalance of the
appropriation. 
Note 1. - Allowances not drawn with pay should be shown as a separate detailed head in the
register.Note 2. - If an allotment is changed, the necessary correction of the register, should be in
red ink.Note 3. - This account should be despatched on the 3rd of the following month supported by
slips (Bills extracts).Signature .................................Designation ............................Date
........................Note. - The horizontal column in 3 parts just below the column for"Sub-head of
Grants" is meant for indicating primary units under a sub-head and the vertical columns be low the
horizontal column, for noting the detailed heads that might exist under a primary unit as well as the
amounts of the bills relating the heads. The numbers and dates of treasury vouchers should be noted
in the column prescribed for the purpose.F.R. Form 24[See Rule 475]Broad Sheet of watching
receipt of account from Disbursing Officers.Office of ...............................Major head
.........................Minor head .........................Sub-head ...........................
Serial No. Names of Disbursing Officers. District Date of receipt of account.  
April May - - -March
 
Note 1. - Districts are to be arranged according to alphabetical order.Note 2. - Dates of receipts
should be noted in monthly columns. Reminder should be sent if not received by the 7th of the
month.F.R. Form 25[See Rule 475]Compilation Sheet.Major head .............................Minor head
.............................Sub-head ................................
Month. Serial no. of the Disbursing Officer.  Total of
each
officer.Remarks
 Total Expenditure cash.Add Adjustment communicated by
A.G.Grand totalAdd total up to previous month.Progressive total up
to date.   
Note. - The column "serial no. of the disbursing officers" should have sufficient space to
accommodate the figures supplied by the Disbursing Officers under the Controlling Officer.F.R.
Form 26[See Rule 475]Consolidated AccountsName of office ..........................Year
...........................................
1 2 3 4Bihar Financial Rules, 1950

Heads of
Disbursement.Grant
sanctionedGrant
distributed.(Monthly
columns)
April MayTotal from
April to
date.
Charged. Voted. Charged. Voted. Charged. Voted. Charged. Voted. Charged. Voted.
Total of all
primary units
including pay
ofofficers and
establishment
temporary and
permanent. 
Note - Progressive actual should be checked against budged appropriation in columns 2 and 3 every
month.F.R. Form 27.[See Rule 494]Register of alterations in Appropriations from one unit of
appropriation to another for the year 20.Major head .......................................... Minor head
.......................................
Authority. Sub-head.Unit of
appropriationOriginal
appropriation.Supplementary
appropriation.
FromNumber and
date.Voted. Charged Voted Charged
1 2 3 4 5 6 78
        
Re-appropriation
by Competent
Authority.Surrenders.Net appropriation
after each
modification.Remarks
Additions. Deductions.Major Minor
Sub-head and units
of
appropriationfrom
or to which
transferred.Voted Charged. Voted. Charged.
Voted. Charged Voted. Charged.
9 10 11 12 13 14 15 161718
          
F.R. Form 28[See Rule 1 of Appendix 4]Detailed statement of the Permanent Establishment of the
................... as it stood on the 1st March 20.
Order of
competent
authority
creating
the post.Date of
appointment
of present
incumbent to
postwithName
of
section
and
post.Date of
incumbents
birth by
Christian
era (asnearSerial
number
of post
in each
class.Name of
incumbent.Pay
of
Post.Pay of
present
incumbent
and total of
eachsection.Date of last
increment.Remarks.
(including note of
efficiency bar
whereapplicable.)Bihar Financial Rules, 1950

Indication of
nature of
appointment
e.g.
officiating,provisional
or
permanent.as possible.)
1 2 3 4 5 6 7 8 9 10
 
Compared with Service Books and found correct.Signature of the Head of Office.F.R. Form 29[See
Rule 11 of Appendix 4]Statement of new names, leave, etc.
New
namesFrom what office
and on what date
transferred or(in
he case of new
entrants) with
what bill the health
and agecertificate
were furnished.Name which
were in
Form A or
the previous
yearare now
omitted.From what date
ceased to be
borne on
theestablishment
and why.Names of
Government
servants who
were on leave
orunder
suspension
during the
previous year.Description and
period of leave or
suspension(from
and to what date)
whether it has been
expressly
declaredthat the
suspension period
will count towards
pension.
1 2 3 4 5 6
 
F.R. Form 30[See Rule 10 of Appendix 13.]Agreement Form For PassageMemorandum of
Agreement made ....................... the .............................. day ............... of ............ 19 ................
between ............... of .............. (hereinafter called the Borrower) of the one part and the Governor of
Bihar (hereinafter called the Lender) of the other part.Whereas the Borrower's (family) is
proceeding to/returning from on leave/expiry of leave with his family and has in accordance with
Appendix 13 to the Bihar Financial Rules, (hereinafter referred to as the said Rules which expression
shall where the context so admits include any amendment thereof or addition thereto for the time
being in force), requested the Lender to lend him Rs. ................... to wards defraying the cost of
his/their journey (s) to ............. (and back) which the Lender has agreed to do on the terms and
conditions hereinafter mentioned.Witnesseth that in consideration of the said loan (receipt of which
the Borrower hereby acknowledges) the Borrower for himself, his heirs, executors and
administrators covenants with the Lender to repay the said loan (with interest calculated according
to the said Rules) by monthly instalments as specified in the said Rules and hereby authorizes the
Lender to deduct the amount of such monthly instalments from the pay of the Borrower provided
always and it is hereby further agreed and declared that in the event of the Borrower dying or
retiring or receiving permission to retire from Government Service before the whole amount of the
said loan (and interest) is repaid or if he does not produce receipts for the said journey or does not
comply with any of the conditions on which the loan is made, as specified in clause (4) of Rule 8 of
the said Rules, the loan (and interest calculated in accordance with the said Rules) is to become
immediately due and payable.In Witness whereof the Borrower has hereunto set his hand the dayBihar Financial Rules, 1950

and the year first above written.Signed by the said (Borrower) in the presence
of:-Witness.Address.Occupation.Bihar Financial Rules, 1950

