Babanrao S/O Parbatrao Chavan And Ors. vs State Of
Maharashtra And Ors. on 5 March, 2004
Equivalent citations: 2004(6)BOMCR936, 2004(4)MHLJ664
Author: A.P. Deshpande
Bench: A.P. Deshpande, V.G. Munshi
JUDGMENT
A.P. Deshpande, J.
1. The petitioners are presently working as Assistant Engineers (Grade-II) in the employment of
Zilla Parishad, Aurangabad. The petitioners from serial Nos. 1 to 4 came to be initially appointed by
the orders of appointments dated 17-11-1980, 8-10-1984, 23-1-1986 and 27-14986, respectively, in
the post of Junior Engineers. The petitioners were appointed on clear, vacant and sanctioned posts
in the prescribed pay scale. The petitioners continued in the employment of the Zilla Parishad,
Aurangabad, and were in due course of time, granted confirmation. After completion of 5 years
service, in the post of Junior Engineer, all the petitioners were upgraded to the post of Sectional
Engineer. While being in the employment, the petitioners improved their qualifications by acquiring
a Degree of Bachelor of Engineering (Civil). In the year 2000, the petitioners were eligible and
qualified to be absorbed in the post of Assistant Engineer (Grade-II), and were accordingly granted
the said higher grade post.
It is relevant to note that higher grade post for candidates possessing the Degree of Bachelor of
Engineering is Assistant Engineer (Grade-II); whereas for under Graduates i.e. Diploma holders, the
higher grade post is Sectional Engineer. The petitioners names also figure in the seniority list
prepared as on 1st January, 2001 (Part I) which is final seniority list of Assistant Engineers
(Grade-II) maintained at the State level and the petitioners names appear at serial Nos. 110, 130,
140 and 141, respectively.
2. As against the said service record of the petitioners, the respondent Nos. 4 and 5 were appointed
as Junior Engineers on ad hoc basis temporarily under 'Jawahar Rojgar Yojana', that too, having
regard to the short broken period of service rendered by them under the Zilla Parishad prior in point
of time. 'Jawahar Rojgar Yojana' was a scheme floated by the Central Government and the
Government of Maharashtra was to implement the said scheme through the Zilla Parishads and
Village Panchayats. Respondent Nos. 4 and 5 had worked in Zilla Parishad for few months
temporarily in the year 1987 and thereafter were discontinued.Babanrao S/O Parbatrao Chavan And Ors. vs State Of Maharashtra And Ors. on 5 March, 2004

3. On 11-12-1989, the Government by issuing a Resolution took a decision, where under the Zilla
Parishads were directed to grant employment to the respondents No. 4 and 5 and other similarly
situated employees under 'Jawahar Rojgar Yojana', who had at some point of time, worked
temporarily with the Zilla Parishads. The respondent Nos. 4 and 5 along with other similarly
situated employees, came to be appointed on 23rd February, 1990 by the respondent/Zilla Parishad
and the appointment order clearly mentions the temporary nature of the appointments being for a
period of 6 months, under the 'Jawahar Rojgar Yojana'. The appointment was to come to an end by
10th June, 1990. The posts of 'Junior Engineers' under the Government Resolution dated 11th
December, 1989 were created for temporary period of 6 months. As the petitioners were
apprehending termination of their services by 10th June, 1990 i.e. on expiry of the period of
appointment, the respondent Nos. 4 and 5, and others. filed writ petitions in the High Court bearing
Nos. 1481/1990 and 1474/1990 and this Court by its order dated 8th June, 1990, passed an interim
order and restrained the Zilla Parishad from terminating services of the petitioners (in the said
petitions), so also, issued Rule. Under the interim order, the petitioners (in the said petitions)
continued in service till the time the State Government took a decision to regularize their services.
The State Government, after calling for information in regard to all the candidates, who were
irregularly appointed in breach of the rules of recruitment in various departments of the State
Government, so also, under the Zilla Parishads, identified that there were in all 3,761 temporary
employees working in different departments of the State Government and out of them 1,672 were
under the Zilla Parishads. The State Government, on the basis of the data collected by it, in regard to
irregular appointments made without following the recruitment rules, took a policy decision on 8th
March, 1999 and decided to regularize their services. The said decision further reveals that the
irregular appointments made in defiance of the prescribed mode of recruitment, were to be
regularized by giving one time concession. The said decision was followed by another Government
Resolution dated 29th April, 1999, which deals exclusively with the temporary appointees under the
Zilla Parishads. Under the Government Resolution dated 8th March, 1999, it was decided to grant
the seniority to the regularized employees from the date of issuance of the Government Resolution
viz. 8th March, 1999. The Government Resolution dated 29th April, 1999 provided that the seniority
would be granted from 29th April, 1999 and, as such, this discrepancy came to be rectified by
issuing a corrigendum, making it clear that all the candidates whose services were regularized would
be entitled to have their seniority counted from 8th March, 1999.
When the Writ Petition Nos. 1481/1990 and 1474/1990 came up for hearing, the attention of the
Court was drawn to the Government Resolution which regularized the services of the petitioners
therein and, as such, the Court disposed of the petitions, leaving the question of seniority and
consequential benefits to be adjudicated upon by State Government, as the same was pending
consideration with the Government. While disposing of the writ petitions, the Division Bench of this
Court has drawn attention of the State Government to the judgment of the Apex Court in the case of
"Delhi Development Horticulture Employees Union v. Delhi Administration and Ors." and more
particularly, the observations made in paras 13 to 15. The said judgment was referred to indicate the
temporary nature of the appointments under the 'Jawahar Rojgar Yojana'. Under the said Yojana, it
was never intended to provide permanent/regular employment to a handful of persons and as such,
the said appointments were temporary and ad hoc in nature, which did not confer any right ofBabanrao S/O Parbatrao Chavan And Ors. vs State Of Maharashtra And Ors. on 5 March, 2004

regularization on the appointees.
4. As indicated hereinabove, as the decision to grant regularization to 3,761 temporary employees
working in different Departments of the Government, so also, the Zilla Parishads involved more
than one Department of the State Government, the Government Resolution dated 8th March, 1999
which reveals the policy of the Government, was taken by the General Administration Department
in consultation with the Rural Development Department. The temporary employees working in
various Government Departments fell under the jurisdiction of the General Administration
Department; whereas the employee working in Zilla Parishads fell within the domain of Rural
Development Department. A uniform decision was reached on 8th March, 1999 in regard to all the
temporary employees being 3,761 in numbers who were not appointed by following the prescribed
procedure of recruitment.
The Government Resolution dated 8th March, 1999 was followed by another Resolution dated 29th
April, 1999. This was issued by the Rural Development Department but in consultation with the
General Administration Department. The Resolution in its body makes a reference about the
consultation. The Resolution dated 29th April, 1999 toed in line with the policy decision taken in the
Government Resolution dated 8th March, 1999, but for a discrepancy in regard to the date from
which seniority was to be granted to the Zilla Parishad employees. The Resolution dated 8th March,
1999 granted deemed date of seniority to all the temporary employees being 3,761 in numbers from
the date of issuance of the Government Resolution viz. 8th March, 1999; whereas mistakenly the
Government Resolution dated 29th April, 1999 granted the same from the date of the said
Resolution i.e. 29th April, 1999. The said discrepancy was removed by issuing a corrigendum which
clarified that the seniority would be reckoned from 8th March, 1999.
After this Court disposed of the earlier petitions, leaving it open for the State Government to decide
the question of seniority, it appears that the respondent Nos. 4 and 5, and similarly situate other
Junior Engineers and Assistants to Junior Engineers appointed mainly under Jawahar Rojgar
Yojana persuaded the State Government to grant them seniority from the date of their initial
appointment i.e. from the year 1990. The demand was acceded to and said decision is reflected in
the third Government Resolution dated 20th November, 2003. A peculiar anomalous situation has
emerged as a result of the third Government Resolution, inasmuch as, the first two Government
Resolutions are holding the field granting seniority to all the temporary employees who were not
appointed in accordance with the rules of recruitment with effect from 8th March, 1999; whereas
the third Resolution which deals with only a handful of employees, bestows^ a much favourable
date of deemed seniority i.e. from the year 1990 viz. the date of initial appointment.
5. We proceed to explain the anomaly. The first Government Resolution dated 8th March, 1999
takes a policy decision in the matter of grant of seniority to all the temporary employees who were
not appointed in accordance with the rules of recruitment, being 3,761 in numbers, working in
various Government Departments and the Zilla Parishads. Out of 3,761 temporary employees, 1,372
are working with the Zilla Parishads. The second Government Resolution which deals with only the
Zilla Parishad employees being 1,372 in numbers, again grants them the deemed date of seniority
from 8th March, 1999. So, all the temporary employees working in Zilla Parishads, as well, underBabanrao S/O Parbatrao Chavan And Ors. vs State Of Maharashtra And Ors. on 5 March, 2004

the said Resolutions are to be granted the deemed date of seniority from 8th March, 1999; whereas
the third Government Resolution carves out a small portion of employees from and out of 1,372
temporary employees working in Zilla Parishads and grants them the special treatment. Out of 1,372
temporary employees working in Zilla Parishads, only such of them who are working as Junior
Engineers and Assistants to Junior Engineers have been dealt under the third Government
Resolution dated 20th November, 2003 and they alone are granted a deemed date of seniority from
the date of their initial irregular appointment.
It is, as such, evident that all the employees working in different Departments of the Government
who formed one class along with the Junior Engineers and Assistants to Junior Engineers would be
granted seniority from 8th March, 1999. So also, all other temporary employees working in Zilla
Parishads barring the Junior Engineers and Assistants to Junior Engineers would also be granted
the deemed date of seniority from 8th March, 1999. Only the Junior Engineers and the Assistants to
Junior Engineers would be granted seniority from the date of their initial appointment. This
anomalous situation which cannot be reconciled has been brought about by the third Government
Resolution dated 20th November, 2003, which is impugned in the present petition.
6. It is reiterated and it is not in dispute that the third Government Resolution dated 20th
November, 2003 came to be issued by the Rural Development Department without the issue being
considered and/or without consultation of the General Administration Department. It is also
relevant to note that all the three Resolutions are holding the field and the Resolution dated 20th
November, 2003 did not and could not supersede the earlier Government Resolutions as the third
Government Resolution dated 20th November, 2003 deals with only a small group of temporary
appointees. In the above factual background, the learned Counsel for the petitioners raised two fold
challenges to the impugned Government Resolution and the same are : (i) that, the Government
Resolution dated 20th November, 2003 is in breach of mandatory rules framed by the Governor of
the State in exercise of powers under Article 166(3) of the Constitution of India, and (ii) that, the
impugned Government Resolution violates the petitioners' fundamental right to equality in the
matter of employment and appointment contained in Articles 14 and 16 of the Constitution of India.
7. The learned Counsel for the petitioners has contended that the State Government had taken a
policy decision to regularize the services of all the temporary employees who were not appointed in
accordance with the recruitment rules working in various Departments of the Government and the
Zilla Parishads which specifically grants the deemed date of seniority from 8th March, 1999. The
petitioners have no quarrel with the said decision. In regard to the impugned Government
Resolution, it is submitted that the anomalous situation has been created by the Rural Development
Department by not following the Rules of Business and the Instructions issued by the Governor of
the State. The learned Counsel for the petitioner submits that only a class of temporary employees
viz. Junior Engineers and Assistants to Junior Engineers have been granted more favourable
treatment from and out of 'one class of temporary employees'. It is then submitted that the
Governor has framed the rules for regulating the conduct of business of the Government which lays
down that if the subject falls within the jurisdiction of two or more Departments of the Government,
then unless and until each of the Departments considers the issue, no order shall be passed,
meaning thereby, no final decision to be reached by the Government. The grievance is in regard toBabanrao S/O Parbatrao Chavan And Ors. vs State Of Maharashtra And Ors. on 5 March, 2004

breach of the rules framed under Article 166(3) of the Constitution of India which, according to the
petitioners, renders the impugned Government Resolution, illegal, requiring it to be struck down.
8. The learned Counsel appearing for the respondent/Zilla Parishad supports the case of the
petitioners and claims that the Junior Engineers and Assistants to Junior Engineers working with
the Zilla Parishads cannot be picked and chosen for grant of special favour. He joins in the
submissions made by the petitioners' Advocate, that there is no reason whatsoever to grant
differential treatment to the temporary employees covered by the Resolution dated 8th March, 1999.
9. The learned Assistant Government Pleader, Smt. Gondhalekar, appearing for the
respondent/State has justified the grant of deemed date to the Junior Engineers and Assistants to
Junior Engineers, vide Government Resolution dated 20th November, 2003. She is unable to state
any criteria on the basis of which the temporary employees covered by the Resolution dated 20th
November, 2003 have been granted the deemed date of seniority from the year 1990 when other
similarly situate employees are granted the deemed date of seniority from 8th March, 1999. In reply
to a pertinent query made by the Court, the Assistant Government Pleader, on instructions,
informed the Court that the impugned Government resolution was not issued in consultation with
the General Administration Department, so also, admits the fact that the issue in regard to grant of
deemed date of seniority to the Junior Engineers and Assistants to Junior Engineers was not
considered by the General Administration Department.
10. Clause 3 of Article 166 of the Constitution of India obliges the Governor to make rules for the
more convenient transaction of the business of the Government of the State, and for the allocation
among Ministers of the said business insofar as it is not business with respect to which the Governor
is by or under the Constitution of India required to act in his discretion. Under the said powers, the
Governor has framed the rules known as the Maharashtra Government Rules of Business and
Instructions Issued Thereunder (for short, hereinafter referred to as "the Rules"). Rule 4 reads thus:
"The Business of the Government shall be transacted in the Departments specified in
the First Schedule and shall be classified and distributed between those Departments
as laid down therein."
At serial No. 1 in First Schedule, is the General Administration Department and the Rural
Development Department finds place at serial No. 12, The instructions regarding the business of the
Government are issued under rule 15 of the Rules. The said instructions regarding the conduct of the
business are issued in exercise of powers under rule 15 of the Rules. Rule 15 and Instruction No. 9
reads thus :
Rule 15 :
"These Rules may to such extent as necessary be supplemented by instructions to be
issued by the Governor on the advice of the Chief Minister."
Instruction No. 9:Babanrao S/O Parbatrao Chavan And Ors. vs State Of Maharashtra And Ors. on 5 March, 2004

"Where the subject of a case concerns more than one Department, then unless the
case is one of extreme urgency, no order shall be issued nor shall the case be laid
before the Council or Cabinet until it has been considered by all the Departments
concerned."
Reading of rule 4 conjointly with Instruction No. 9 reveals that when the case concerned more than
one Department, then no order shall be issued until the case is considered by all the Departments
concerned except when the case is one of extreme urgency. In the matter in hand, the issue pertains
to the grant of deemed date to irregularly appointed persons who were serving since the year 1990.
Hence, there is no question of urgency, much less, extreme. If this be so, then unless and until all the
concerned Departments consider the subject, no orders can be issued by one of the Departments.
11. The learned Counsel for the petitioners submits that, as a matter of fact, regularization of
irregular appointees was a subject squarely falling within domain of the General Administration,
Department. He submits that the Government had identified such irregular appointees from all the
Departments and the Zilla Parishads, as well, and had taken a policy decision which was uniformly
to be applied to all the irregular appointees. It is categorically pointed out that the first Resolution
dated 8th March, 1999 was issued by the General Administration Department; whereas the second
Resolution dated 29th April, 1999 was issued by the Rural Development Department and to the
extent of departure from the decision reached by the earlier Government Resolution, a corrigendum
was issued and the issue of seniority was brought in line with the decision reached by the General
Administration Department.
Strangely enough, the Rural Development Department has issued the impugned Government
Resolution without consulting the General Administration Department and carved out few officers
only from and out of the irregular appointees working in Zilla Parishads viz. Junior Engineers and
Assistants to Junior Engineers and they are given a special favourable treatment which is not made
available to rest of the employees working in Zilla Parishads and/or other employees working in
other Departments of the State Government. As a matter of fact, the State Government by its policy
decision, after the matter was considered by all the concerned Departments, had taken a decision
contained in Resolution dated 8th March, 1999. It is obvious that the Rural Development
Department should not have singled out few irregularly appointed employees and bestowed them a
seniority right since their date of initial appointment, more so, when the appointments were not in
conformity with the rules of recruitment.
12. The rules framed under Article 166(3) of the Constitution of India are statutory in nature. By
virtue of rule 15, instructions are issued by the Governor which are to supplement the rules and the
said instructions are framed on the advice of the Chief Minister. Whatever instructions are issued in
furtherance of Rule 15, are mean to supplement the rule and hence it partakes the nature of binding
instructions. Neither the Government nor any of its Departments can violate the instructions. Even
assuming that the instructions are directory in nature and not mandatory, still substantial
compliance of the instructions would be insisted upon. In the present case, admittedly though the
issue of grant of seniority fell within the domain of two Departments of the State Government, one
of the two Departments have chosen to issue the Government Resolution impugned, keeping theBabanrao S/O Parbatrao Chavan And Ors. vs State Of Maharashtra And Ors. on 5 March, 2004

other Department in dark. Had the Rural Development Department brought it to the notice of the
General Administration Department, the said issue, the Government could have taken a uniform
decision. There appears absolutely no reason, much less, just, to grant dissimilar treatment to
persons who constitute one class of employees.
13. The learned Counsel for the petitioners has placed reliance on the judgment of the Apex Court ,
in the case of Haridwar Singh v. Bagun Sumbrui and Ors. The Apex Court was called upon to
interpret similar rule framed under Article 166(3) of the Constitution of India viz. Bihar Rules of
Executive Business, and the question arose as to whether said rule is mandatory or directory which
provided for prior consultation with the Finance Department in regard to certain matter. While
dealing with the issue, the Apex Court observed in para 13 of the judgment, thus :
"Several tests have been propounded in decided cases for determining the question
whether a provision in a statute, or a rule is mandatory or directory. No universal rule
can be laid down on this matter. In each case one must look to the subject matter and
consider the importance of the provision disregarded and the relation of that
provision to the general object intended to be secured. Prohibitive or negative words
can rarely be directory and are indicative of the intent that the provision is to be
mandatory (See Earl T. Crawford. The Construction of Statutes, pp. 5234)."
14. In the case in hand, the Government was dealing with an issue of regularization of services of
thousands of employees working in all the Departments of Government besides the Zilla Parishads
and, as such, rightly it was prerogative of the General Administration Department. Without
consulting and/or without affording an opportunity to the General Administration Department to
consider the issue, the Rural Development Department has issued the Government Resolution
dealing with only handful of employees and granted them seniority from the date of initial
appointment which has been denied to other similarly situated employees working in other
Departments of the Government, so also, some of the employees working in Zilla Parishads, as well.
Not only this, a peculiar situation has surfaced, inasmuch as, the Government Resolution issued by
the General Administration Department, dated 8th March, 1999, so also, the Government
Resolution dated 29th April, 1999 issued by the Rural Development Department in consultation
with General Administration Department are holding the field, they are not superseded and could
not have been superseded, inasmuch as, the first Government Resolution deals with all irregular
appointees and the second Government Resolution deals with all irregular appointees working in
Zilla Parishads; whereas the impugned Government Resolution deals with only the Junior
Engineers and Assistants to junior Engineers working in Zilla Parishads. The two earlier Resolutions
and the impugned Resolution do not go hand in hand, inasmuch as, the earlier Resolution grant
seniority from 8th March, 1999 to all irregular appointees; whereas the impugned Resolution grants
deemed date of seniority only to Junior Engineers and Assistants to Junior Engineers from the date
of their initial appointment. It is impossible to reconcile anomalies resulted from the impugned
Government Resolution.Babanrao S/O Parbatrao Chavan And Ors. vs State Of Maharashtra And Ors. on 5 March, 2004

In this view of the matter, we have no doubt, that had the mandatory instructions issued by the
Governor under Rule 15 of the Rules been complied with, than disregarded, the general object
intended to be secured by the instruction viz. uniformity in decision making, could have been
achieved. Placing reliance on the judgment of the Apex Court supra, we hold that the Rules of
Business and the Instructions issued thereunder which are supplemental to the Rules, as is
indicated by Rule 15, to the extent they relate to consultation and/or consideration by the respective
Departments, is mandatory. As the impugned Government Resolution is in violation of the Rules
and the Instructions, the Government Resolution must fall to the ground. We hold that the
Government Resolution dated 20th November, 2003 is illegal besides being arbitrary, unfair and
unjust.
15. To buttress the second submission, the learned Counsel for the petitioners submit that as Article
16 is a facet of Article 14 of the Constitution of India, the State Government's decision in the matter
of employment or appointment falling under Article 16(1) must also be just, fair and reasonable. It
cannot be arbitrary or irrational.
The next limb of submission is that on the one hand, the petitioners were appointed regularly in
adherence to the recruitment rules, whereas the respondent Nos. 4 and 5 and other similarly situate
persons were appointed in defiance to the rules of recruitment and their appointments were neither
regular nor were in sanctioned posts. In the submission of the petitioners, the posts created under
'Jawahar Rojgar Yojana' by their very nature were temporary and ad hoc and, as such, the State
Government could not grant the benefit of seniority from the initial date of appointment. The
petitioners apprehend that some of the persons who are presently shown junior to the petitioners,
would supersede the petitioners taking advantage of the seniority granted to the said appointees
from their initial date of appointment. In this factual background, it is emphatically canvassed that
the decision reached by the Rural Development Department of the State Government contained in
the Resolution dated 20th November, 2003 goes to abridge the petitioners rights contained in
Articles 14 and 16 of the Constitution of India. The main thrust of the submission is that the State
Government has no power, authority or jurisdiction to grant deemed date of seniority from the date
of initial appointment, if the said appointment is not a regular appointment, meaning thereby, an
appointment in accordance with the rules of recruitment and the State Government would have
jurisdiction only to grant the deemed date of seniority from the date of regularization of the service
and not prior thereto.
16. Now, we come to the question as to whether the impugned Government Resolution granting
deemed date of seniority to the Junior Engineers and Assistants to Junior Engineers could be
sustained having regard to the settled position in law propounded by catena of judgment of the Apex
Court. The judgment of the Apex Court , in the case of The Direct Recruit Class-II Engineering
Officers' Association and Ors. v. State of Maharashtra and Ors., has laid down the following
propositions while summing up the said judgment. In the instant case, as we are concerned with
propositions (A) and (B), we reproduce the two propositions :
"(A) Once an incumbent is appointed to a post according to rule, his seniority has to
be counted from the date of his appointment and not according to the date of hisBabanrao S/O Parbatrao Chavan And Ors. vs State Of Maharashtra And Ors. on 5 March, 2004

confirmation. The corollary of the above rule is that where the initial appointment is
only ad hoc and not according to rules and made as a stop-gap arrangement, the
officiation in such post cannot be taken into account for considering the seniority.
(B) If the initial appointment is not made by following the procedure laid down by
the rules but the appointee continues in the post uninterruptedly till the
regularisation of his service in accordance with the rules, the period of officiating
service will be counted."
With a view to explain the conclusions in regard to the two propositions, observations made by the
Apex Court, in para 13 of the judgment, are relevant and hence reproduced below :--
"When the cases were taken up for hearing before us, it was faintly suggested that the
principle laid down in Patwardhan's case was unsound and fit to be overruled, but no
attempt was made to substantiate the plea. We were taken through the judgment by
the learned counsel for the parties more than once and we are in complete agreement
with the ratio decidendi, that the period of continuous officiation by a Government
servant, after his appointment by following the rules applicable for substantive
appointments, has to be taken into account for determining his seniority; and
seniority cannot be determined on the sole test of confirmation, for, as was pointed
out, confirmation is one of the inglorious uncertainties of Government services
depending neither on efficiency of the incumbent nor on the availability of
substantive vacancies. The principle for deciding inter se seniority has to conform to
the principles of equality spelt out by Articles 14 and 16. If an appointment is made by
way of stop-gap arrangement, without considering the claims of all the eligible
available persons and without following the rules of appointment, the experience on
such appointment cannot be equated with the experience of a regular appointee,
because of the qualitative difference in the appointment. To equate the two would be
to treat two unequals as equal which would violate the equality Clause. But if the
appointment is made after considering the claims of all eligible candidates and the
appointee continues in the post uninterruptedly till the regularisation of his service in
accordance with the rules made for regular substantive appointments, there is no
reason to exclude the officiating service for purpose of seniority. Same will be the
position if the initial appointment itself is made in accordance with the rules
applicable to substantive appointments as in the present case. To hold otherwise will
be discriminatory and arbitrary. The principle has been followed in innumerable
cases and has been further elaborated by this Court in several judgments including
those in Baleshwar Dass v. State of U. P., , and Delhi Water Supply and Sewage
Disposal Committee v. R. K. Kashyap, , with which we are in agreement. In Narender
Chadha v. Union of India, the officers were promoted although without following the
procedure prescribed under the rules, but they continuously worked for long periods
of nearly 15-20 years on the posts without being reverted. The period of their
continuous officiation was directed to be counted for seniority as it was held that any
other view would be arbitrary and violative of Articles 14 and 16. There isBabanrao S/O Parbatrao Chavan And Ors. vs State Of Maharashtra And Ors. on 5 March, 2004

considerable force in this view also. We, therefore, confirm the principle of counting
towards seniority the period of continuous officiation following an appointment
made in accordance with the rules prescribed for regular substantive appointments in
the service."
17. A useful reference can be made to the judgment of the Apex Court, delivered by the three
Honourable Judges, , in the case of Keshav Chandra Joshi and Ors. etc. v. Union of India and Ors. In
para 23 of the said judgment, the Apex Court has observed thus :
"Ad hoc or fortuitous appointments on a temporary or stop gap basis cannot be taken
into account for the purpose of seniority, even if the appointee was subsequently
qualified to hold the post on a regular basis. To give benefit of such service would be
contrary to equality enshrined in Article 14 read with Article 16(1) of the Constitution
as unequals would be treated as equals."
In para 24 of the judgment, the Apex Court has explained propositions (A) and (B) enunciated by
the Constitution Bench of the Apex Court in Direct Recruits case (supra). The Apex Court observed
thus :
"24. In Direct Recruits case the Constitution Bench of this Court in which one of us
(K. Ramaswamy, J.) was a member, in propositions 'A' and 'B' in paragraph 47 at
page 745 (of SCC): (Para 44, at p. 1627 of AIR) stated :--
"(A) Once an incumbent is appointed to a post according to rule, his seniority has to
be counted from the date of his appointment and not according to the date of his
confirmation.
The corollary of the above rule is that where the initial appointment is only ad hoc and not according
to rules and made as stop gap arrangement, the officiation in such post cannot be taken into account
for considering the seniority.
(B) If the initial appointment is not made by following the procedure laid down by the rules but the
appointee continues in the post uninterruptedly till the regularisation of his service in accordance
with the rules, the period of officiating service will be counted."
M/s Mukhoty and Garg repeatedly asked us to apply the ratio in the cases of Narendra Chadha, ,
Baleshwar Das, and Chauhan, contending that the promotees were appointed to the same post, are
discharging the same duties, drawing the same salary, therefore, they should be deemed to be given
promotion from their initial dates of appointment. We express our inability to travel beyond the
ratio in Direct Recruits case. While reiterating insistence upon adherence to the rule that seniority
between direct recruits and the promotees has to be from the respective dates of appointment, this
Court noticed that in certain cases. Government by deliberate disregard of the rules promotions
were made and allowed the promotees to continue for well over 15 to 20 years without reversion and
thereafter seniority is sought to be fixed from the date of ad hoc appointment. In order to obviateBabanrao S/O Parbatrao Chavan And Ors. vs State Of Maharashtra And Ors. on 5 March, 2004

unjust and inequitious results, this Court was constrained to evolve "rule of deemed relaxation of the
relevant rules" and directed to regularise the services giving the entire length of temporary service
from the date of initial appointment for seniority, To lay down binding precedent the cases were
referred to a Constitution Bench. In Direct Recruits case, this Court has laid down clear propositions
of general application in items A to K. Therefore, to keep the law clear and certain and to avoid any
slant, we are of the considered view that it is not expedient to hark back into the past precedents and
we prefer to adhere to the ratio laid down in the Direct Recruits case.
25. As stated, the counsel for the promotees placed strong reliance on proposition 'B' while the
counsel for the Direct Recruits relied on proposition 'A'. The controversy is as to which of the
propositions would apply to the facts of this case. The proposition 'A' lays down that once an
incumbent is appointed to a post according to rules, his seniority has to be counted from the date of
his appointment and not according to the date of his confirmation. The latter part thereof amplifies
postulating that where the initial appointment is only ad hoc and not according to rules and is made
as a stop-gap arrangement, the period of officiation in such post cannot be taken into account for
reckoning seniority. The quintessence of the propositions is that the appointment to a post must be
according to rules and not by way of ad hoc or stop-gap arrangement made due to administrative
exigencies. If the initial appointment thus made was de hors the rules, the entire length of such
service cannot be counted for seniority. In other words, the appointee would become a member of
the service in the substantive capacity from the date of his appointment only if the appointment was
made according to rules and seniority would be counted only from that date. Propositions 'A' and 'B'
cover different aspects of one situation. One must discern the difference critically. Proposition 'B'
must, therefore, be read along with para 13 of the judgment wherein the ratio decidendi of Narendra
Chadha was held to have considerable force. The latter postulated that if the initial appointment to a
substantive post or vacancy was made deliberately, in disregard of the rule and allowed the
incumbent to continue on the post for well over 15 to 20 years without reversion and still the date of
regularization of the service in accordance with the rules, the period of officiating service has to be
counted towards seniority. This Court in Narendra Chadha's case was cognizant of the fact that the
rules empower the Government to relax the rule of appointment. Without reading paragraph 13 and
Proposition 'B' and Narendra Chadha's ratio together the true import of the proposition would not
be appreciated. We would deal with the exercise of power of relaxing the rule later. After giving
anxious consideration, we are of the view that the latter half of Proposition 'A' would apply to the
facts of the case and the rule laid down in that half is to be followed. If the concerned rules provide
the procedure to fix inter se seniority between direct recruits and promotees, the seniority has to be
determined in that manner."
The judgment of the Constitution Bench of the Apex Court in Direct Recruits' case (supra), as
explained in (supra), holds the field and is consistently followed in many later judgments of the
Apex Court.
In the judgment , in the case of Union of India through Chandigarh Administration (U.T.)
Chandigarh and Anr. v. Sh. S.K. Sharma, Professor of Civil Engineering Punjab Engineering College,
Chandigarh, the Apex Court has categorically held that ad hoc service cannot be counted for
determining seniority, so also, ad hoc service would not confer any right to claim seniority on theBabanrao S/O Parbatrao Chavan And Ors. vs State Of Maharashtra And Ors. on 5 March, 2004

post reckoning ad hoc service. The Apex Court has placed reliance on the judgment of the
Constitution Bench of the Apex Court, , in the case of Direct Recruit Class II Engineering Officers'
Association v. State of Maharashtra, and more particularly on the below quoted observations :
"Once an incumbent is appointed to a post according to rule, his seniority has to be
counted from the date of his appointment and not according to the date of his
confirmation. Seniority cannot be determined on the sole test of confirmation, for,
confirmation is one of the inglorious uncertainties of government service depending
neither on efficiency of the incumbent nor on the availability of substantive
vacancies. The principle for deciding inter se seniority has to conform to the
principles of equality spelt out by Articles 14 and 16. The corollary of the above rule is
that where the initial appointment is only ad hoc and not according to rules and
made as a stopgap arrangement, the officiation in such post cannot be taken into
account for considering the seniority."
In the judgment of the Apex Court, , in the case of Excise Commissioner, Karnataka and Anr. v. V.
Sreekanta, the same proposition is reiterated by holding that the candidates appointed on ad hoc
basis cannot claim that the ad hoc service can be counted for the purpose of seniority. It is clearly
laid down that the seniority of ad hoc appointees need to be counted from the date of regularization
of their service and not from the date of an ad hoc appointment.
In another judgment of the Apex Court, , in the case of P.K. Singh v. Bool Chand Chablani and Ors.,
it is held that for determination of seniority, services rendered on ad hoc basis prior to
regularization cannot be taken into account for determining seniority. This very position is
reiterated in the recent judgment of the Apex Court, , in the case of Santosh Kumar and Ors. v. G.R.
Chawala and Ors.. In the said judgment, it is held that the inclusion of ad hoc services for the
purposes of seniority is impermissible even though they are made after satisfying all tests for regular
appointments. It is further held that the ad hoc appointments being in nature of stopgap or
fortuitous appointments, the said services cannot be counted for seniority.
A common thread which runs through these judgments clearly indicate that a deemed date of
seniority cannot be granted from the date of initial appointment, if the initial appointment is not in
accordance with the rules of recruitment. If this be the position in law, and as all the Junior
Engineers and Assistants to Junior Engineers who are granted such a seniority by the impugned
Government Resolution, the same would be illegal, impermissible and unsustainable in law.
18. The Maharashtra Civil Services (Regulation of Seniority) Rules, 1982, regulates the issue of
seniority. Rule 4 lays down the general principles of seniority. Sub-rule (1) lays down that the
seniority of a Government servant in any post, cadre or service shall ordinarily be determined on the
length of his continuous service therein. The first proviso thereto deals with leave, deputation on
foreign service, etc. and we are not concerned with the same. The second proviso is crucial and the
same reads thus:Babanrao S/O Parbatrao Chavan And Ors. vs State Of Maharashtra And Ors. on 5 March, 2004

"Provided further that, the service, if any, rendered by him as result of a fortuitous
appointment except in a case where the competent authority certifies that, it was not
expedient/possible or practicable to make a regular appointment strictly in
accordance with the ratio of recruitment as prescribed in relevant recruitment rules,
with the brief reasons recorded therefor, shall be excluded in computing the length of
service and for the purpose of seniority he shall be deemed to have been appointed to
the post or in the cadre or service on the date on which his regular appointment is
made in accordance with the provisions of the relevant recruitment rules."
In the instant case, the Junior Engineers and Assistants to Junior Engineers, such as, the
respondent Nos. 4 and 5 were appointed for a temporary period of six months and the appointment
was ad hoc. But the said persons continued in service till the date of regularization, because of
fortuitous circumstance viz. grant of interim order by this Court pending decision of the Writ
Petitions which ultimately came to be disposed of as the petitioners therein were granted
regularization. The Court left the issue of seniority for adjudication to the Government. The term
"fortuitous appointment" is defined in Rule 3(f) and the same reads thus:
" "Fortuitous appointment" means a temporary appointment made pending a regular
appointment in accordance with the provisions of the relevant recruitment rules."
Under the rules dealing with seniority, even a temporary appointment pending a regular
appointment is termed as a 'fortuitous appointment'. We have no iota of doubt, that the respondent
Nos. 4 and 5's continuation in service from 1990 till their regularization was a fortuitous one which
cannot bestow the persons irregularly appointed with the right of seniority vis-a-vis regularly
appointed candidates. No doubt, the State Government is empowered to assign deemed date of
appointment, rather it could be said that by having recourse to the power under Rule 5, and other
enabling powers, the State Government has issued the Resolution dated 8th March, 1999 and 29th
April, 1999 and thereby granted the deemed date of seniority i.e. 8th March, 1999 to the irregularly
appointed employees.
If that be so, we fail to understand what justification could there be for the State Government to
issue a Government Resolution dated 20th November, 2003, more so, when the same goes to
abridge the accrued rights of the regularly appointed persons, such as, the petitioners. We hold that
the decision contained in the Government Resolution dated 20th November, 2003 is violative of the
petitioners right contained in Articles 14 and 16 of the Constitution of India besides the said decision
being contrary to various judgments of the Apex Court referred to herein above, including the Direct
Recruits' case (supra). The petitioners grievance, that they have been discriminated, is justified.
19. This bring us to the adjudication of technical objection raised by the learned Assistant
Government Pleader, to the effect that unless and until all the persons who would be benefitted by
the impugned Government Resolution are impleaded as party/respondents, the petition ought not
to be entertained on merits. It is contended by the learned Assistant Government Pleader, that the
petitioners are apprehending that some of the persons who are presently shown below the
petitioners in the seniority list of Junior Engineers (Grade-II) would supersede the petitioners byBabanrao S/O Parbatrao Chavan And Ors. vs State Of Maharashtra And Ors. on 5 March, 2004

virtue of the impugned Government Resolution and, as such, it was incumbent to implead the said
persons, at least, as party/respondents to the petition. In her submission, the said persons are
necessary parties and non-joinder ought to result in dismissal of the petition.
As against this, the learned Counsel for the petitioners has submitted that what is under challenge is
a decision taken by the State Government and the same is challenged on the ground of violation of
fundamental rights. In this view of the matter, it is contended that it is not necessary to implead any
one who could be said to be beneficiary under the said Government Resolution and nonjoinder of
such persons would not, in any way, affect the maintainability of the petition. Alternatively, it is
submitted that the respondent Nos. 4 and 5 are beneficiaries of the impugned Government
Resolution and they could be taken to be representing all the beneficiaries under the said
Government Resolutions. Though the respondent Nos. 4 and 5 are not in the seniority list of Junior
Engineers (Grade-II), but they are the beneficiaries. In case, the petition succeeds, the respondent
Nos. 4 and 5 are put to lose the deemed date of seniority granted by the Government Resolution
and, as such, it is claimed that all the beneficiaries are properly represented before the Court as they
are represented by respondent Nos. 4 and 5.
The learned Counsel for the petitioners has relied upon a judgment of Andhra Pradesh High Court ,
in the case of B. Gopalaiah and Ors. v. Government of Andhra Pradesh Represented by its Secretary,
Education Dept., Hyderabad and Anr.. The learned Judge of the Andhra Pradesh High Court
(Coram: Chinnappa Reddy, J.) observed thus :
"This is not case of discrimination of individual against individual. This is a case
where a whole class of citizens have been discriminated against and the court cannot
refuse to give relief to them on the ground that the class of persons who will be
benefitted as a result of the discrimination are not before the Court. The person who
complains of discrimination cannot be expected to search the country for all persons
who are likely to be benefitted by its discriminatory policy, of course, if the
discrimination is in favour of an individual against an individual different
considerations might arise."
The learned Judge further proceeded to observe :
"In my opinion, where a scheme formulated by the Government is attacked on the
ground of its being discriminatory the position is precisely the same as if a statute is
attacked as being discriminatory and it can never be an answer to such an attack that
persons likely to be benefitted by a discriminatory statute should be brought before
the Court before the statute is struck down."
The said judgment was quoted with approval by the Apex Court in the judgment , in the case of The
General Manager, South Central Railway, Secunderabad and Anr. v. A. V. R. Siddhanti and Ors.. In
para 20 of the judgment, the Apex Court while repelling a similar objection, held thus :Babanrao S/O Parbatrao Chavan And Ors. vs State Of Maharashtra And Ors. on 5 March, 2004

"The respondents-petitioners are impeaching the validity of those policy decisions on
the ground of their being violative of Articles 14 and 16 of the Constitution. The
proceedings are analogous to those in which the constitutionality of a statutory rule
regulating seniority of Government servant is assailed. In such proceedings the
necessary parties to be impleaded are those against whom the relief is sought, and in
whose absence no effective decision can be rendered by the Court. In the present
case, the relief is claimed only against the Railway which has been impleaded through
its representative. No list or order fixing seniority of the petitioners vis-a-vis
particular individuals, pursuant to the impugned decisions, is being challenged. The
employees who were likely to be affected as a result of the re-adjustment of the
petitioner's seniority in accordance with the principles laid down in the Board's
decision of October 16, 1952, were, at the most, proper parties and not necessary
parties, and their non-joinder could not be fatal to the writ petition."
In the case of A. Janadhana v. Union of India and Ors., , similar question arose before the Apex
Court, as to who are necessary parties when a policy decision of the State is under challenge. In the
said judgment, ratio laid down by the Apex Court in the judgment (supra) was followed by holding
that when the dispute is not an individual dispute against another individual, and a Government
decision is under challenge, every beneficiary is not a necessary party.
20. In the result, the writ petition is allowed. The impugned Government Resolution dated 20th
November, 2003 is quashed and set aside.
21. Rule made absolute in the above terms. Needless to mention, that the interim order stands
vacated. In the circumstances of the case, there shall be no order as to costs.
22. At this stage, the learned Assistant Government Pleader appearing for respondent Nos. 1 and 2,
prays for stay of this judgment for a period of six weeks.
No case for stay is made out. Hence prayer is rejected.Babanrao S/O Parbatrao Chavan And Ors. vs State Of Maharashtra And Ors. on 5 March, 2004

