Cdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022
Author: D.Y. Chandrachud
Bench: Hima Kohli, Dhananjaya Y Chandrachud
                                                        1
                                                                                       Reportable
                                        IN THE SUPREME COURT OF INDIA
                                         CIVIL APPELLATE JURISDICTION
                                         Civil Appeal Nos 841-843 of 2022
                      Cdr Amit Kumar Sharma etc                               .... Appellants
                                                     Versus
                      Union of India & Ors etc                                ....Respondents
                                                      WITH
                                           Civil Appeal No 846 of 2022
                                       (@ Civil Appeal Nos 845-846 of 2022)
                                                      WITH
                                            Civil Appeal No 2457/2022
                                                      WITH
                                         Civil Appeal Nos 2059-2060/2022
                                                      WITH
                                            Civil Appeal No 2216/2022
                                                      WITH
                                          Civil Appeal Nos 856-858/2022
                                                      WITH
                                             Civil Appeal No 855/2022
Signature Not VerifiedCdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

Digitally signed by
                                                      WITH
GULSHAN KUMAR
ARORA
Date: 2022.11.07
                                          Civil Appeal Nos 852-854/2022
11:50:25 IST
Reason:
               2
             WITH
  Civil Appeal Nos 844/2022
             WITH
Civil Appeal Nos 847-851/2022
             WITH
Civil Appeal No          of 2022
      (Diary No 20730/2022)
          AND WITH
Civil Appeal No         of 2022
     (Diary No. 23503/2022)
                                                         3
                                          JUDGMENT
Dr Dhananjaya Y Chandrachud, J
1. Leave to appeal under Section 31(1) of the Armed Forces Tribunal Act 2007 is granted.
2. Delay condoned.
3. This batch of appeals arises from a judgment dated 3 January 2022 of the Principal Bench of the
Armed Forces Tribunal 1. The AFT dismissed the applications challenging the denial of Permanent
Commission 2 in the Indian Navy. The principle issue is whether the AFT could have adjudicated on
the validity of the selection proceedings when relevant material was disclosed only to the AFT in a
sealed cover. The Facts
4. On 26 September 2008, the Ministry of Defence notified that women Short Service Commission 3
Officers would be eligible for grant of PC prospectively. In Union of India v. Lieutenant CommanderCdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

Annie Nagaraj 4, the issue for consideration before this court was whether women who were
inducted in various branches of the Indian Navy prior to 2008 were entitled to the grant of PC. By
its judgment dated 17 March 2020, this Court observed, inter alia, that5:
(i) As a result of the policy decision of the Union Government dated 25 1 “AFT” 2
“PC” 3 “SSC” 4 (2020) 13 SCC 1 5 Paragraphs 109.5, 109.6 and 109.7 of the judgment
in Annie Nagaraj.
February 1999, the terms and conditions of service of SSC Officers including women with regard to
the grant of PC were governed by Regulation 203 of Chapter IV of Part III of the Naval Ceremonial,
Conditions of Service and Miscellaneous Regulations 19636;
(ii) The stipulation in the policy letter dated 26 September 2008 making it prospective and
applicable only to specified branches/cadres of the Indian Navy (Education, Law and Naval
Construction) was not enforceable;
(iii) All SSC Officers in the Education, Law and Logistics cadres, who were “presently in service”
shall be considered for the grant of PCs;
(iv) The officers were entitled to the grant of PC in view of the policy letter of the Union Government
dated 25 February 1999 read with Regulation 203;
(v) SSC women officers in the batch of cases before the High Court and the AFT who are “presently
in service” shall be considered for the grant of PC on the basis of the vacancy position as on the date
of the judgment of the Delhi High Court and the AFT or as it “presently stands”, whichever is higher;
(vi) The applications of the serving officers for the grant of PC shall be considered on the basis of the
norms contained in Regulation 203, namely,
(a) availability of vacancies in the stablised cadre at the relevant time;
(b) determination of suitability;
(c) recommendation of the Chief of Naval Staff; and 6 “Regulations”
(d) empanelment shall be based on the inter-se merit evaluated on the ACRs of the officers under
consideration, subject to the availability of vacancies.
5. There are three points in time, which were taken into consideration by the authorities for the
determination of vacancies, namely
(i) August 2015, when the judgment of the High Court in Annie Nagaraj (supra) was pronounced;Cdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

(ii) September 2016, when the decision of the AFT in Commander Priya Khurana v. Union of India 7
was pronounced; and
(iii) March 2020, when the decision of this Court in Annie Nagaraj (supra) case was pronounced.
6. Following the above directions, the process for implementing the judgment was carried out. The
respondents worked out a total of 88 vacancies. 306 officers were considered for PC against the 88
vacancies after which 80 of them were granted PC. The second respondent (Integrated
Headquarters of Ministry of Defence (Navy)) issued a signal order releasing many SSC officers from
service on the ground that they had not obtained PC. The Signal order only notes the date of
commission, date of release and the Unit of the officer without any reference to the process of
selection that was undertaken or the relative merit. Many of the SSC officers, both men and women,
who were not granted PC filed writ petitions before this Court challenging the rejection of their
claim for PC. In the alternative, they sought directions for the grant of pension. 7OA No 143 of 2016
7. By an order dated 24 August 2021, this Court dismissed the writ petitions on the ground that the
Court had already laid down the principles for granting PC in Annie Nagaraj (supra) and Lt. Col.
Nitisha v. Union of India 8. It was observed that the officers who were denied PC would assail the
decision on the basis of individual facts and thus, it would be necessary for them to claim their
reliefs before the AFT. The relevant observations are extracted below:
“12 The petitioners who are considered for the grant of PC and were denied it would
have to assail the decision not to grant them PC on the basis of the individual facts in
each case. Bearing this in mind, it would be necessary for them to pursue their
remedies before the AFT where the facts of each case can be scrutinized. If the
petitioners were to succeed on their plea for the grant of PC, the alternative claim for
invoking the jurisdiction under Article 142 would cease to have any practical
significance. It is only if the denial of PC is upheld that the alternate plea can be
pressed and this can be pursued after the decision of the AFT, by following the
remedies available under the statute. Hence, on a considered view of the matter we
are inclined not to entertain the petitions under Article 32 on merits.” (emphasis
supplied)
8. The second respondent, in the written submissions before the AFT, filed in Cdr AK Sharma v.
Union of India9 submitted that the vacancy calculation is more than an exercise of simple
mathematics and that the “minute details of vacancy calculation cannot be put in the open domain
for the obvious reasons. Accordingly, this Hon’ble Tribunal will be provided with a detailed note
with respect to vacancy calculation in a sealed envelope (as and when sought).” It was also
submitted that the fairness of the selection process “would be amply clear from the selection Board
Proceedings which would be provided to this Hon’ble Tribunal for perusal in the sealed cover, if
need for the same arises.” Similarly, in the counter affidavit filed in Commander Barsha 8 (2021)
SCCOnLine SC 261 9 O.A 2167 of 2021 Agrawal v. Union of India 10 , it was submitted:Cdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

“Accordingly, this Hon’ble Tribunal has been provided with a detailed note with
respect to vacancy calculation in a sealed envelope”.
(emphasis supplied)
9. The AFT by the impugned judgment dated 3 January 2022 disposed the cases
transferred to the AFT pursuant to the order of this Court along with cases where the
denial of PC was challenged before the AFT. The impugned judgment of the AFT in
paragraph 54 indicates that the respondents submitted :
(i) All the files connected with the Selection Board convened in December 2020;
(ii) The previous Selection Boards held for the grant of PC;
(iii) The management of SSC Officers; and
(iv) The dossiers containing the confidential reports of 32 applicants before the AFT.
10. In addition to the above, the AFT noted in paragraph 81 that on a perusal of “various records and
files submitted by the respondents”, the second respondent had considered the following issues:
          (a)    Selection Boards held prior to 2020;
          (b)    Baseline for consideration and batches to be considered;
          (c)    Categorization of officers for consideration;
          (d)    Determination of vacancies;
          (e)    Suitability criteria;
          (f)    Inter-se merit criteria;
 10 OA 2008 of 2021
       (g)      Conduct of Board and results; and
       (h)      Analysis of the Selection Board Proceedings.
11. In paragraph 99 of the judgment, it is observed that the Board conducted its proceedings on 18
December 2020 according to the criteria approved in the Approach paper. Paragraph 37 of the
impugned judgment extracts the selection procedure that was adopted by Indian Navy. ParagraphCdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

37 of the judgment is extracted below:
“37. The Counsel then took us through the criteria for selection and said that marks
were apportioned as given below to work out inter-se merit. He added that there was
no ‘Value Judgment’ mark as was applicable in promotion boards. He also stated that
no one has been rejected based on medical criteria and all had been recommended by
the CNS. He further added that the merit list was computer generated based on the
criteria mentioned below; and that out of a total of 381 officers, 80 had been granted
PC (41 women and 39 male officers). The counsel then elaborated on the factors and
their weightage.
 Ser         Factor                   Weightage        Unsuitability Criteria
 (a)         ACR Merit                90%
 (b)         SLt Seniority            04%
 (c)         War                      02%              Officer should not have been recommended G
and below any time in the last five CR cycles held on record
(d) Peer 02% Officer should not have been recommended G and below any time in
the last five CR cycles held on record
(e) Recommendation for 02% Officer should not have been graded ‘No’ in PC
recommendation for PC thrice or more in the last five CRs
12. On perusing the records disclosed in a sealed cover, the AFT recorded the status of the remaining
applicants as follows:
Ser OA Applicants Current Relief Merit 1st Merit 2nd Disposal Case Ref Status sought
Consideration Consideration 1 OA 433/ 2016 Lt Cdr Ravinder Retired PC/Pension
5/6 Low merit No vacancy Was Pal Singh Released considered SLP (C) 834-
Engineering/NC 31.12.2020 only for first 36/ 2021 Batch- 2005 look. To be Service-
16 given second look 2 OA 435/2016 Lt Cdr Amit Retired PC/Pension 6/6 Low merit
No vacancy Was Khajuria Released considered SLP (C) 834- Engineering /
31.12.2020 only for first 36/2021 NC look. To be Batch-2005 given Service -16
second look 3 OA 436/2016 Lt Cdr Manish Retired PC/ Pension 3/6 Low merit No
vacancy Was Kumar Singh considered SLP (C) 834- Engineering/ Released only for
first 36/2021 NC 31.12.2020 look. To be Batch- 2005 given Service- 16 second look 4
OA 1203/2017 Cdr Saroj Singh Released PC 5/10 Low 4/9 Low merit Not eligible
Exec/gs 31.12.2020 merit for PC WP 1471/2020 Batch- 2003 Rel stayed
(Tfr-Rajkumar) Service- 18 in service Already Granted Pension 5 OA 838/2018 Cdr
Swati Released PC 12/14 Low 18/20 Low Not eligible Bhatia 31.12.2020 merit merit
for PC WP 1471/2020 Education/ GS (Tfr-Rajkumar) Batch -2004 Rel stayed Already
Service- 17 In service Granted Pension 6 OA 840/2018 Cdr Vijayeta Released PC 8/14
Low 14/20 Low Not eligible Education GS 31.12.2020 merit merit for PC WP
1478/2020 Batch-2004 (Tfr- Service – 17 Rel stayed Already Rajkumar) In serviceCdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

Granted Pension 7 OA 1959/2018 Cdr Kumar Released PC Not Not Not eligible
Dhiraj 9.01.2019 considered considered for PC and Old matter Batch- 2007 since not
in since not in not granted Service- 14 Retired service on service on pension date of
date of being judgment judgment inadmissible under Para 96(x) and
(xi) of the judgment 8 OA 2118/2018 Cdr Mandip Released PC 7/9 Low merit 10/12
Low Not eligible Kaur Exec/Lgd 31.12.2020 NR for PC in merit NR for for PC WP
1478/2020 Batch -2005 ACR PC ON acr (Tfr- Service- 16 Rel stayed Already
Rajkumar) in service Granted Pension 9 OA 816/2019 Cdr YK Singh Released
PC/Pension 15/20 10/13 Low Not eligible Education/GS 31.12.2020 Low merit merit
for PC and WP 1269/2020 Batch- 2005 Rel stayed not granted (Tfr-Rajkumar)
Service – 16 in service pension being inadmissible under Para 96(x) and
(xi) of the judgment 10 OA 1361/2021 Cdr Sarita Released PC/Pension 07/15 13/20
Not eligible Fresh case Nagayach 05.08.2021 Low merit Low merit for PC and Exec/
Lgs NR for PC in NR for PC in not grated Batch- 2007 Retired ACR ACR pension
Service -14 being inadmissible under Para 96(x) and
(xi) of the judgment 11 OA 1454/2021 Cdr Sandeep Rel Order PC/Pension 4/15 8/20
Not eligible Singh 24.03.2021 Low merit Low merit for PC and WP 646/2021
Exec/Lgs not grated Dismissed as Batch-2007 Released pension withdrawn by
Service – 14 06.08.2021 being applicant. inadmissible under Para 96(x) and
(xi) of the judgment 12 OA 1964/2021 Cdr Pooja Released PC 5/7 7/14 Not eligible
Rajput 31.12.2020 Low merit Low merit for PC WP 1471/2020 Exec/Lgs Already
(Tfr-Rajkuamr) Batch- 2002 Rel stayed granted Service- 19 in service pension 13 OA
2008/2021 Cdr Barsha Rel Order PC/Pension 9/11 7/9 Not eligible Agarwal
05.08.2020 / Low merit Low merit for PC and WP 703/2021 & 03 Ors Permit to not
grated (Tfr-Rajkumar) Education/GS Released service till pension Batch- 2007
05.08.2021 20 yrs (Ref being Service- 14 BP/ N case) inadmissible under Para 96(x)
and
(xi) of the judgment 14 Joint with Ser Cdr Shweta Rel Order PC/Pension 11/11 09/09
Not eligible
13 Kapoor 5.8.2020 / Low merit Low merit for PC and Education/ GS Permit to not grated Batch-
2007 Released service till pension Service- 14 05.08.2021 20 yrs (Ref being BP/ N case)
inadmissible under Para 96(x) and
(xi) of the judgment 15 Joint with Ser Cdr Sapna C Rel Order PC/Pension 7/11 05/09 Not eligible 13
Lanjewar 05.08.2020 / Low merit Low merit for PC and Education/GS Permit to not grated Batch-
2007 Released service till pension Service- 14 05.08.2021 20 yrs (Ref being BP/ N case)
inadmissible under Para 96(x) andCdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

(xi) of the judgment 16 Joint with Ser Cdr SS Naik Rel Order PC/Pension 8/11 06/09 Not eligible 13
Education/GS 05.08.2020 / Low merit Low merit for PC and Batch- 2007 Permit to not grated
Service-14 Released service till pension 05.08.2021 20 yrs (Ref being BP/ N case) inadmissible
under Para 96(x) and
(xi) of the judgment 17 OA 2064/2021 Cdr Annie Released PC 5/8 6/9 Not eligible Nagaraja
31.12.2020 NR for PC in NR for PC in for PC WP 1471/2020 Education/GS Reframe ACR ACR
Already (Tfr-Rajkumar) Batch- 1999 Rel guidelines granted Service- 22 stayed- SC of pension order
15.10.2020?
24.08.2020 In service 18 OA 2065/2021 Lt Cdr Barkha Released PC 10/10 9/9 Not eligible Rathore
31.12.2020 Low merit Low merit NR for PC WP Exec/Lgs Reframe NR for PC in for PC in Already
1471/2020(Tfr- Batch- 2003 Rel stayed guidelines ACR ACR granted Rajkumar) Service- 18 In
service of pension 15.10.2020?
19   OA 2066/2021     Cdr Urmila       Released     PC             7/8            8/9            Not eligible
                      Bhat             31.12.2020                  Low merit NR   Low merit NR   for PC
     WP 1471/2020     Education/Met                                for PC in      for PC in      Already
     (Tfr-Rajkumar)   Batch- 1999      Rel stayed                  ACR            ACR            granted
                      Service- 22      In service                                                pension
20   OA 2067/2021     Cdr Puneet Pal   Released     PC/Pension     5/12           6/15           Not eligible
                      Kaur             12.05.2021                  Low merit      Low merit      for PC and
     WP 507/2021      Exec/Lgs                                                                   not grated
     (Tfr-Rajkumar)   Batch-2006       Rel stayed                                                pension
                      Service- 14      in service                                                being
                                                                                                 inadmissible
                                                                                                 under Para
                                                                                                 96(x) and
                                                                                                 (xi) of the
                                                                                                 judgment
21   OA 2068/2021     Cdr Shruti       Released     PC             6/8            7/9 NR for     Not eligible
                      Dhawan           31.12.2020                  NR for PC in   PC in ACR      for PC
     WP 1471/2020     Education/GS                                 ACR                           Already
       (Tfr-Rajkumar)     Batch- 1999       Rel stayed                                                      granted
                          Service- 22       in service                                                      pension
22     OA 2069/2021       Cdr Bhanu         Released      PC/ Pension     10/15              15/20          Not eligible
       Fresh case         Pratap Singh      31.12.2020                    Low merit NR       Low merit NR   for PC and
                          Exec/Lgs                                        for PC in          for PC in      not grated
                          Batch- 2007       Retired                       ACR                ACR            pension
                          Service- 14                                                                       being
                                                                                                            inadmissible
                                                                                                            under Para
                                                                                                            96(x) and
                                                                                                            (xi) of the
                                                                                                            judgmentCdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

23     OA 2167/2021       Cdr Amit          Released      PC/Pension      2/3 NR for         9/14           Not eligible
       (Tfr-RB            Kumar Sharma      31.12.2020                    PC in ACR          Low merit NR   for PC and
       Mumbai)            Education/GS                                                       for PC in      not grated
                          Batch- 2003       Rel stayed                                       ACR            pension
       WP No.             Service- 18       in service                                                      being
       1269/2020                                                                                            inadmissible
       (Tfr-Rajkumar)                                                                                       under Para
                                                                                                            96(x) and
                                                                                                            (xi) of the
                                                                                                            judgment
24     OA 2168/2021       Lt Cdr Yogita     Released      PC/ Pension     3/3                14/14          Not eligible
       (Tfr-RB            Rani              31.12.2020                    Low merit          Low merit      for PC
       Mumbai) Old        Education/GS                                                                      Already
       matter,            Batch- 2003                                                                       granted
       transferred        Service- 18                                                                       pension
       from AFT
       (RB0 Mumbai
25     OA 2169/2021       Cdr               Released      PC/ Pension     13/14              19/20          Not eligible
       (OA 105/2017       PS Soodan         31.12.2020                    Low merit NR       Low merit NR   for PC and
       RB Mumbai)         Education/ GS                   Permit to       for PC in          for PC in      not grated
                          Batch- 2004       Rel stayed    serve till 20   ACR                ACR            pension
       WP 1269/2020       Service- 17       In service    yrs (Ref                                          being
       (Tfr-Rajkumar)                                     BP/N case)                                        inadmissible
                                                                                                            under Para
                                                                                                            96(x) and
                                                                                                            (xi) of the
                                                                                                            judgment
13. On an examination of the Board proceedings, the AFT observed that there were no mala fides in
the parameters which were prescribed or the procedure adopted. It was also observed that the
officers were not granted PC because of their comparative merit against limited vacancies and, in
certain cases, the officers were not found suitable. The relevant observations are extracted below:
“110. Having heard all parties and examined various records, it is well established
that the IN has formulated a proper procedure with suitable parameters, and has
applied it uniformly to all eligible SSCOs, both men and women, of all affected
Branches/Cadres in their consideration for grant of PC. We find no mala fide in the
parameters laid down or the procedure adopted. No gender discrimination has been
observed in the Selection Board held in Dec 2020 and those held prior to the decision
of the Hon’ble Supreme Court in Annie Nagaraj (supra). […]
121. The merit position and status of the rest of the applicants are given below. The
inputs on recommendations for PC; Peer and War Report entries have all been
verified from the CRs. It is seen from the records that the applicants have not been
granted PC only because their comparative merit against limited vacancy and in
certain cases, not being found suitable as per the laid down criteria.”Cdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

14. The decision of the AFT has led to the institution of twelve Civil Appeals before this Court.
Twenty-six officers of the Indian Navy are appellants before this Court in the Civil Appeals. Of these
twenty six officers, thirteen are still in service pursuant to interim orders. The remaining thirteen
officers are out of service since varying dates in 2020, 2021 and 2022. Apart from the twenty six
officers who are appellants before this Court in the twelve civil appeals, eight officers have filed IAs
for intervention. Seven out of eight officers are protected by interim orders while the tenure of the
eighth officer (Commander Navneet Sharma) is to end in the month of December 2022.
15. Notice was issued in this batch of Civil Appeals on 31 January 2022. The grievance of the
appellants is that the sealed cover procedure, which was followed by the AFT, has resulted in
substantial prejudice.
The Submissions
16. Mr Huzefa A Ahmadi and Mr C U Singh, senior counsel appearing on behalf of the appellants
together with the other counsel - Ms Kamini Jaiswal, Ms Haripriya Padmanabhan and Ms Puja Dhar
have submitted that the AFT, in the course of its decision, has extensively relied upon material
which was submitted by the Naval Authorities in a sealed cover. It has been urged that this material
was never disclosed to the appellants and if the material had been disclosed to them, they would
have been in a position to demonstrate that much of the data which has been relied upon is seriously
in dispute and is not reflective of the correct position. Mr. R. Balasubramaniam, senior counsel
appearing on behalf of the respondent, submitted that it is not as if the respondents voluntarily
chose to place the data in a sealed cover and the files which were produced were on the directions of
the AFT.
17. During the course of hearing, three principal submissions have been urged by Mr. Huzefa A
Ahmadi, senior counsel:
(i) In its decision in Annie Nagaraj (supra), this Court directed that the highest
number of vacancies were to be considered in determining the claims of the SSC
officers for the grant of PC but this has not been done;
(ii) Several batches have been clubbed together as a consequence of which vacancies
have not been considered batch-wise and inter se merit has been skewed; and
(iii) Consideration for the grant of PC was effected on the basis of ACRs which were
written casually at a time when the officers concerned were not eligible for the grant
of PC as observed in a subsequent decision of this Court (albeit in the case of the
Army) in Nitisha (supra).
18. While formulating the objections to the findings of the AFT on merits, it has been submitted by
the counsel for the appellants that:Cdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

(i) The respondents have made no distinction between officers who were inducted
prior to 2008 and those inducted after 2008;
(ii) Data submitted by the Navy shows that vacancies at the material time were not
properly calculated;
(iii) There is sufficient data to indicate that many more vacancies exist in most cadres
than what is depicted in the impugned order;
(iv) The adoption of the 60:40 ratio (PC: SSC Officers) based on the AV Singh
Committee report is flawed since various other aspects of the report are yet to be
implemented by the Naval Authorities including the disbursal of monetary benefits;
(v) The computation of yearly vacancies has proceeded on an arbitrary basis of 15
years’ distribution;
(vi) The methodology of dividing the total number of vacancies by 15 is arbitrary;
(vii) The chart which has been set out in paragraph 95 of AFT’s decision shows that as many as 14
batches were considered together; and
(viii) The grievances of individual officers have not been adjudicated. For instance, in the case of
Commanders Annie Nagaraj and Amit Sharma, though they were recommended for the grant of PC
and would fall within the existing vacancies, they have been denied PC on the ground that they were
not recommended.
19. On the other hand, Mr R Balasubramaniam, senior counsel appearing on behalf of the
respondents made the following submissions:
(i) While computing the vacancies, the Naval Authorities have correctly borne in
mind:
(a) The overall cadre structure of the Indian Navy;
(b) The policies which have been consistently followed; and
(c) The pattern of future inductions and retirements; and the need to maintain a
youthful profile in the Indian Navy and a balanced cadre structure.
(ii) Grant of PC is governed by Regulation 203 according to which the availability of
vacancies should be in the stabilised cadre;
(iii) While the stabilised cadre normally comprises only of government sanctioned
posts in the permanent cadre, in the spirit of the judgment of this Court, temporaryCdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

vacancies and Training Drafting Leave Reserve (TDLR) vacancies were also added to
the stabilised cadre;
(iv) The vacancies of the stabilised cadre were worked out with reference to August
2015, September 2016 and March 2020;
(v) The ratio of 60:40 (PC:SSC) has been approved by the Government of India on 3
November 2008 based on the AV Singh Committee report;
(vi) Based on the above, the deficiencies in each stream were divided by a 15 year cycle which is the
difference between the life of a PC Officer and SSC Officer in service;
(vii) The deficiencies in manning strength cannot be given to any particular batch or a few batches
because of the policy of the Navy to have a balanced cadre structure, a youthful profile and a proper
induction/retirement pattern in the long run;
(viii) The vacancies assigned to each batch worked out in terms of the above model provided the
maximum vacancies as on March 2020, the date of the judgment of this Court;
(ix) Pursuant to the directions given by the AFT, the Navy carried out a fresh exercise and allotted
seven more vacancies to the Naval Construction Cadre and seven officers were approved for the
grant of PC;
(x) In regard to the clubbing of batches, each SSC Officer was given two ‘looks’ (the first and the
second ‘look’) pursuant to consistent practice. The first look is with officers of the preceding batch,
who were not granted PC in their first look and the second look is with the available next fresh
batch. Hence, each batch was given consideration separately and it would not be correct to postulate
that 14 batches of the Logistics Cadre were clubbed together. The distribution of vacancies per batch
on the basis of a 15 year cycle is justified;
(xi) The manner of writing ACRs is not erroneous. The judgment in Nitisha (supra) pertained to the
Indian Army which is distinguishable since :
(a) Unlike the Indian Army where male officers were being granted PC, in the case of
the Indian Navy neither men nor women officers were granted PC;
(b) The ACRs written by officers in the last five years preceding the conduct of the
Board were taken into consideration which had a specific column on whether or not a
recommendation was being made for PC, since 2015; and
(c) If an officer has not been recommended for PC in three or more ACRs, it would be
a disqualification and hence an officer would not be eligible for grant of PC, even if
higher in merit.Cdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

20. The second respondent in the written submissions before this Court submitted that (i) it is a
norm for the Board proceedings to only be provided to the AFT in a sealed cover; (ii) the AFT on a
perusal of the proceedings of the Selection Board as well as confidential dossiers of the individual
applicants found that the Navy had considered the claims of the officers for PC based upon the
parameters laid down by this Court in Annie Nagaraja (supra).
The Analysis
21. The AFT, inter alia, had to determine if (i) the Naval Authorities had correctly computed the
vacancies against which the claims of the SSC Officers would be considered for the grant of PC; and
(ii) the Selection Board considered the applications for the grant of PC fairly. The judgment of the
AFT indicates that in assessing the validity of the exercise undertaken to determine vacancies and
the fairness of the selection process, it placed extensive reliance on material drawn from the data
emerging from the files which were submitted by the Union Government and the Naval Authorities
in a sealed cover. The judgment of AFT sets out in paragraph 92, a summary of the cadre-wise
strength and vacancies to be considered for granting PC to the affected SSC officers. In paragraphs
93 and 94, the AFT has set out, in a similar manner, tabulated statements in regard to the utilisation
of vacancies. This data did not form the subject matter of deliberations before the AFT. In fact, the
counter affidavits in Commander Barsha Agrawal (supra) and Commander AK Sharma (supra)
indicate that the data was submitted in the form of a sealed note.
22. Similarly, the Board proceedings were not disclosed to the appellants. The written submissions
before this court and the submissions in Commander AK Sharma (supra) before the AFT indicate
that the Board proceedings were not disclosed to the officers and were submitted to the AFT in a
sealed cover. The AFT on a perusal of the Board proceedings has observed that the second
respondent had adopted proper procedure and suitable parameters that it had uniformly applied. It
was also observed on a perusal of the documents that there was no gender bias and that the
appellants’ applications for PC were rejected only because they were lower in inter se merit.
23. This Court in Annie Nagaraj (supra) had directed that the applications of the serving officers for
PC shall be considered on the basis of norms in Regulation 203 and paragraph 4 of the
implementation guidelines. The parameters that were directed to be considered were: (i) availability
of vacancies in stabilized cadre at the material time; (ii) determination of suitability; and (iii)
recommendation of the Chief of Naval Staff. In terms of paragraph 4 of the implementation
guidelines, the empanelment has to be based on inter-se merit evaluated on the ACRs of the officers.
The Tribunal in paragraph 105 of the judgment observed that on a perusal of record it was evident
that the Indian Navy had considered the SSC officers for PC based on the parameters laid down in
Annie Nagaraj (supra). However, the material that has been relied on to arrive at the finding that
there was no infirmity in the process has not been disclosed to the appellants. The AFT observed
that the weightage to the individual parameters in the selection process for PC is the same as it
existed before the judgment of this Court in Annie Nagaraj (supra). Even if the parameters for
selection and the weightage of the individual parameters have been in the public domain, there is no
material on record to determine if the selection has been made in accordance with the criteria. The
AFT has recorded that there are ‘no mala fides’ and ‘no gender bias’ in the selection process.Cdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

However, there is no material available to the appellants to challenge these findings since the
material was disclosed to the AFT in a sealed envelope. The orders granting PC to other officers also
did not contain any reasoning on the inter-se merit of the applicants. The AFT on a perusal of the
files submitted in a sealed cover recorded the status of the applicants in a tabular format that has
been extracted in the earlier part of the judgment. However, the appellants were not privy to such
information.
24. Material prejudice has been caused by the process which has been followed of disclosing the
information of vacancies and the board proceedings to the AFT in a sealed cover. In Khudiram Das
v. State of West Bengal 11, this Court held that the test for determining if material must be disclosed
is whether in all ‘reasonable probability’, the material would influence the decision of the authority.
Ruling in the context of preventive detention, a four-Judge Bench of this Court observed:
“15. Now, the proposition can hardly be disputed that if there is before the District
Magistrate material against the detenu which is of a highly damaging character and
having nexus and relevancy with the object of detention, and proximity with the time
when the subjective satisfaction forming the basis of the detention order was arrived
at, it would be legitimate for the Court to infer that such material must have
influenced the District Magistrate in arriving at his subjective satisfaction and in such
a case the Court would refuse to accept the bald statement of the District Magistrate
that he did not take such material into account and excluded it from consideration. It
is elementary that the human mind does not function in compartments. When it
receives impressions from different sources, it is the totality of the impressions which
11 (1975) 2 SCC 81 goes into the making of the decision and it is not possible to
analyse and dissect the impressions and predicate which impressions went into the
making of the decision and which did not. Nor is it an easy exercise to erase the
impression created by particular circumstances so as to exclude the influence of such
impression in the decision making process. Therefore, in a case where the material
before the District Magistrate is of a character which would in all reasonable
probability be likely to influence the decision of any reasonable human being, the
Court would be most reluctant to accept the ipse dixit of the District Magistrate that
he was not so influenced and a fortiori, if such material is not disclosed to the detenu,
the order of detention would be vitiated, both on the ground that all the basic facts
and materials which influenced the subjective satisfaction of the District Magistrate
were not communicated to the detenu as also on the ground that the detenu was
denied an opportunity of making an effective representation against the order of
detention.” (emphasis supplied)
25. In T. Takano v. Securities and Exchange Board of India 12, a two- Judge Bench of this Court held
that the all relevant information must be disclosed. In this case, the issue for consideration before
this Court was whether an investigation report under Regulation 9 of the SEBI (Prohibition of
Fraudulent and Unfair Trade Practices) Regulations 2003 must be disclosed to the person to whom
a notice to show cause is issued. SEBI had not disclosed the investigation report. It was the
contention of SEBI that it had not relied on the investigation report to issue the show cause notice.Cdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

The two Judge Bench observed that disclosure of information to the parties to the adjudication
serves three purposes: (i) Reliability: The possession of information by both the parties can aid the
courts in determining the truth of the contentions; (ii) Fair Trial: There is a legitimate expectation
that parties are provided all the information for them to effectively participate in the proceedings;
(iii) Transparency and accountability: It is necessary that the adjudication is not opaque but
transparent. Transparency aids in establishing accountability. The observations on disclosure of
information and its impact on transparency are extracted below:
“22. […] Keeping a party bereft of the information that influenced the decision of an
authority undertaking an adjudicatory function also undermines the transparency of
the judicial process. It denies the concerned party and the public at large the ability to
effectively scruitinise the decisions of the authority since it creates an information
asymmetry.”
23. The purpose of disclosure of information is not merely individualistic, that is to
prevent errors in the verdict but is also towards fulfilling the larger institutional
purpose of fair trial and transparency. Since the purpose of disclosure of information
targets both the outcome (reliability) and the process (fair trial and transparency), it
would be insufficient if only the material relied on is disclosed. Such a rule of
disclosure, only holds nexus to the outcome and not the process. Therefore, as a
default rule, all relevant material must be disclosed.
26. This court observed that the right to disclosure is not absolute. Portions that involve information
on third-parties or confidential information on the securities market may be withheld by SEBI. The
court directed that the Board is duty bound to disclose parts of the investigative report that concern
the specific allegations that have been levelled in the show cause notice. However, the court also
observed that it does not entitle a person to whom the notice is issued to receive unrelated sensitive
information. The court held that it must first be prima facie established by SEBI that the disclosure
of the information would affect third party rights. Once a prima facie case of sensitivity is
established, the onus would then shift to the appellant to prove that the information is necessary to
defend his case appropriately. The conclusions are extracted below:
51 […]
(v) The right to disclosure is not absolute. The disclosure of information may affect
other third-party interests and the stability and orderly functioning of the securities
market. The respondent should prima facie establish that the disclosure of the report
would affect third-party rights and the stability and orderly functioning of the
securities market. The onus then shifts to the appellant to prove that the information
is necessary to defend his case appropriately; and
(vi) Where some portions of the enquiry report involve information on third parties
or confidential information on the securities market, the respondent cannot for that
reason assert a privilege against disclosing any part of the report. The respondentsCdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

can withhold disclosure of those sections of the report which deal with third-party
personal information and strategic information bearing upon the stable and orderly
functioning of the securities market.
52 The Board shall be duty-bound to provide copies of such parts of the report which
concern the specific allegations which have been levelled against the appellant in the
notice to show cause. However, this does not entitle the appellant to receive sensitive
information regarding third parties and unrelated transactions that may form part of
the investigation report.”
27. The elementary principle of law is that all material which is relied upon by either party in the
course of a judicial proceeding must be disclosed. Even if the adjudicating authority does not rely on
the material while arriving at a finding, information that is relevant to the dispute, which would with
‘reasonable probability’ influence the decision of the authority must be disclosed. A one-sided
submission of material which forms the subject matter of adjudication to the exclusion of the other
party causes a serious violation of natural justice. In the present case, this has resulted in grave
prejudice to officers whose careers are directly affected as a consequence.
28. The non-disclosure of relevant material to the affected party and its disclosure in a sealed-cover
to the adjudicating authority (in this case the AFT) sets a dangerous precedent. The disclosure of
relevant material to the adjudicating authority in a sealed cover makes the process of adjudication
vague and opaque. The disclosure in a sealed cover perpetuates two problems. Firstly, it denies the
aggrieved party their legal right to effectively challenge an order since the adjudication of issues has
proceeded on the basis of unshared material provided in a sealed cover. The adjudicating authority
while relying on material furnished in the sealed cover arrives at a finding which is then effectively
placed beyond the reach of challenge. Secondly, it perpetuates a culture of opaqueness and secrecy.
It bestows absolute power in the hands of the adjudicating authority. It also tilts the balance of
power in a litigation in favour of a dominant party which has control over information. Most often
than not this is the state. A judicial order accompanied by reasons is the hallmark of the justice
system. It espouses the rule of law. However, the sealed cover practice places the process by which
the decision is arrived beyond scrutiny. The sealed cover procedure affects the functioning of the
justice delivery system both at an individual case- to case level and at an institutional level.
However, this is not to say that all information must be disclosed in the public. Illustratively,
sensitive information affecting the privacy of individuals such as the identity of a sexual harassment
victim cannot be disclosed. The measure of non- disclosure of sensitive information in exceptional
circumstances must be proportionate to the purpose that the non-disclosure seeks to serve. The
exceptions should not, however, become the norm.
29. During the course of the hearing, it has clearly emerged before this Court that material which
was relied upon by the AFT for determining the vacancies which were available and for assessing as
to whether they were utilised correctly has not been disclosed to the appellants. Similarly, the Board
proceedings that were relied upon by AFT to determine if the selection for PC was fair have not been
disclosed to the appellants. We are cognizant of the wide range of sensitive information in the
records of board proceedings. The respondents are not required to disclose the deliberations on theCdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

selection for PC within the closed Board setting. While the AFT on a perusal of the records
concluded that there was no gender bias or mala fides in the grant of PC, it must be borne in mind
that the officers do not possess the material to challenge this observation. The respondents while
protecting the confidentiality of the proceedings of the Board must disclose the position in merit of
the appellants vis-à-vis the parameters and their weightage devised by the respondents.
30. We permitted counsel to address the Court briefly on the nature of objections which arise on the
basis of the data as disclosed. Counsel for the appellants submitted that instead of a remand to AFT,
this Court may carry out the exercise. We are not inclined to do so for two reasons. Firstly, a primary
fact-finding role is entrusted to the AFT under the Armed Forces Tribunal Act 2007. While
exercising its appellate jurisdiction, it would be appropriate if this Court has the benefit of a
considered view of the AFT. To decide the issues for the first time in appeal, as a matter of first
impression, would not be appropriate. Secondly, the issues which arise before the AFT primarily
turn upon the determination of vacancies, the manner of utilising them and the fairness of the
selection process. This is an exercise which had to be carried out by the Naval Authorities while
implementing the judgment of this Court. The correctness of that determination fell for
consideration before the AFT. In arriving at its conclusion upholding the determination, the AFT
has not had the benefit of considering the objections of the appellants to the manner in which the
exercise was carried out by the authorities. The objections of the appellants noted above would have
been set out before the AFT if the material was disclosed to the appellants. The failure to disclose
relevant material has caused substantial prejudice to the appellants. This case exposes the danger of
following a sealed cover procedure.
31. For the above reasons we are of the view that a remand to the AFT would be necessitated. We are
conscious of the fact that the AFT carried out a painstaking exercise while disposing of the OAs but
there has been a clear breach of the principles of natural justice. We are of the considered opinion
that the AFT should be directed to reconsider the entire matter afresh.
32. We accordingly allow the appeals and set aside the impugned judgment of the AFT. The OAs
corresponding to the appeals which are filed before this Court are restored for fresh adjudication by
the AFT. During the pendency of these proceedings, as already noted, some of the officers in this
batch of appeals including some interveners have continued in service as a result of the protective
orders operating in their favour while the tenure of one officer is to end in December 2022. We
direct that the officers who are protected by interim orders of this Court shall continue to have the
benefit of those orders pending the disposal of the proceedings before the AFT and thereafter for a
period of eight weeks from the date of the decision of the AFT should it become necessary for them
to assail the judgment before this Court in appeal. The officer whose tenure is to end in December
2022 shall also be entitled to the benefit of the same protection.
33. We request the AFT to dispose of the OAs which have been restored to the file of the AFT
expeditiously and preferably by the end of February 2023.
34. Pending applications, if any, including applications for impleadment/intervention, stand
disposed of.Cdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

.…………...…...….......………………........J. [Dr Dhananjaya Y Chandrachud]
…..…..…....…........……………….…........J. [Hima Kohli] New Delhi;
October 20, 2022
-GKA-Cdr. Amit Kumar Sharma vs Union Of India on 20 October, 2022

