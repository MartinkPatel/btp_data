Basti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11
September, 1978
Equivalent citations: 1979 AIR 262, 1979 SCR (1) 590, AIR 1979 SUPREME
COURT 262, 1979 LAB. I. C. 129, 54 FJR 55, (1979) SCR 590 (SC), 37 FACLR
265, 1979 SCC (L&S) 61, 1979 (2) SCC 88, (1978) 2 LAB LN 468, (1979) 1 SCJ
480, (1978) 2 LABLJ 412
Author: V.R. Krishnaiyer
Bench: V.R. Krishnaiyer, D.A. Desai
           PETITIONER:
BASTI SUGAR MILLS co. LTD.
        Vs.
RESPONDENT:
STATE OF U.P. & ANR.
DATE OF JUDGMENT11/09/1978
BENCH:
KRISHNAIYER, V.R.
BENCH:
KRISHNAIYER, V.R.
DESAI, D.A.
CITATION:
 1979 AIR  262            1979 SCR  (1) 590
 1979 SCC  (2)  88
ACT:
Payment  of Bonus  Act  1965-Sec.  34-U.P.  Industrial
Disputes Act,  -1947 s.  3(b) 3(c) Trade Unions Act 1926 (S.
2h) Whether  bonus can be paid under order passed under s. 3
of  U.P.  I.D.  Act-Whether  appointment.  of  a  Tripartite
Committee amounts  to agreement  within meaning  of s. 31 of
Bonus Act-Whether  an  association  of  employers  can  bind
individual employer.
HEADNOTE:
     The appellant runs two Sugar Factories at two different
places. There  are about  71  such  factories  in  U.P.  The
economy of  U.P. in  large measure  , depends  on the  sugar
industry. Moreover,  sugar is  an essential commodity. Thus,Basti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

these factories  and the  army of  workers employed  therein
fall within  the strategic  sector  of  the  State  economy.
Section 3 of the U.P. Industrial Disputes Act, 1947 provides
that if  in the  opinion of the State Govt., it Iq necessary
or expedient  so to  do for  securing the  public safety  or
convenience or  the maintenance  of public order or supplies
and services  essential to  the life of the community or for
maintaining employnnent  it may  by general or special order
make provision  for prohibiting  strikes lock-outs  and  for
appointing committees  representative both  of employers and
workmen for  securing amity  and good  relations between the
employer  and   the  workmen  and  for  settling  industrial
disputes by  conciliation. The  Payment of  Bonus Act,  1965
lays down  what bonus  is payable  to the workmen. Using the
power under  S. 3(c)  of the  1947  Act  and  based  on  the
suggestion of the State Labour Conference (Sugar), the State
Govt. appointed  a  tripartite  committee  in  October  1968
consisting  of   3  nominees   of  the  Indian  Sugar  Mills
Association and their. u representatives of the workmen, the
Labour Commissioner  being Chairman  of the  Committee.  The
notification under  s. 3  (b) who  issued we  have  view  to
consider and  make  recommendations  to  Government  on  The
question of  grant of  bonus for  1967-68 by  the Vacuum Pan
Sugar Factories of the State  on the basis of the Payment of
Bonus Act  1965, subject  to such  modifications as  may  be
mutually agreed  upon. The  Association  is  a  Trade  Union
registered under  the Trade  Unions Act, 1926. Its functions
are indicated  in the definition of 'trade union' in Section
2(h) of  that  Act,  and  include  regulation  of  relations
between the workmen and employers. Thus, the Association was
within its  competence to  nominate three representatives to
sit on  the Committee  to regulate the relations between the
Member-employees and the  workmen employed. The appellant is
a Member of the said Association.
      The Committee held several sitting and at some stages,
the appellant or his representative did participate directly
or   indirectly   in   the   deliberations.   The   workers'
representatives actually accepted the formula put forward by
the President of the Management's Association. On receipt of
the recommendation  under Section  3(c) the  Govt. issued an
order under  s.  3(b)  implementing  Those  recommendations.
Although section  3(b) does  not depend for Coming into play
upon any  report under  5. 3(c),  the Govt.  constituted the
Committee under  s. 3  (c) before taking any step under 5. 3
(b) as  a measure  to ensure  the fairness  to the concerned
parties. The appellant filed a writ petition in
591
the High  Court. The learned single Judge dismissed the writ
petition taking a view that an agreement which is recognised
by s.  34 of  the Bonus  Act,  existed  in  this  case  and,
therefore, the  order  which  merely  gave  effect  to  that
agreement was  not bad  in law.  On appeal the two Judges of
the Bench  disagreed and  the case  went  before  the  thirdBasti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

learned Judge  of the High Court who upheld the order of the
learned single  Judge  on  the  ground  that  there  was  an
agreement under s. 34 of the Bonus Act.
     The appellant contended:-
       1.  The State  Govt. cannot  act in the area of bonus
without breach  of the  embargo in  s. 34  of the Bonus Act,
and, therefore, the impugned notification must fail for want
of power.
       2.  Since the  Bonus Act  is a complete Code covering
profit sharing  bonus, no  other law  can  be  pressed  into
service to force payment of Bonus by the Management.
       3. Section 3(b) of the U.P. Act is independent of any
agreement between  the affected parties and the notification
there under  operates  on  its  own  and  not  by  force  of
consensus  or   contract  between   the  workmen   and   the
management. It  was, therefore,  wrong for the High Court to
have salvaged  the notification  under s.  3(b) as embodying
the agreement to pay bonus.
      4. As a matter of fact, there was no agreement between
the appellant  and the workmen within the meaning of section
34 since the representatives or the Association had no power
to bind  its members  by any  agreement on bonus having been
appointed  solely   to  make  certain  recommendations.  The
appellant had  specifically informed the Association that it
did not  agree to  any variation  from the approved balance-
sheet of the Company. E
     Dismissing the appeal the Court.
^
     HELD: The effect of s. 34 is that anything inconsistent
with the  Bonus Act  in any  other law  will bow.  and  bend
before it.  If concluded  agreement could  be read  into the
recommendations of tripartite committee relating to bonus it
would  be   valid  despite   s.  34.  The  two  Courts  have
accordingly found that there was an agreement. This Court is
rarely   disposed   to   reverse   a   factual   affirmation
concurrently reached by the High Court at two tiers. [601 A,
B, D]
       The  contention that  the authority of the tripartite
committee  was  limited to  making  recommendations  on  the
grant of  bonus subject  to such  modifications as  mutually
agreed upon  is formally correct but why could the committee
which had  representatives of both the wings of the industry
not mutually agree upon bonus formula ? There was nothing in
the notification prohibiting it. There was everything in the
notification promoting  it. The  whole process was geared to
mutually  agreed  solutions.  Once  the  representatives  of
management and labour reached an agreement, substantially on
the basis  of the Bonus Act, they would proceed to recommend
to  Govt.  the  acceptance  of  that  agreement.  The  first
notification did  not shut  out, but,  on  the  other  hand,
welcomed mutual  agreement. As  between the  two  wings,  an
agreement  materialised.   Then   it   became   Government's
responsibility effectively to resolve the crisis and behovedBasti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

it to  rut teeth  into the  agreement by making it a binding
order under  s. 3(b).  The Association  is a Trade Union. It
can bind its members. The notifi-
 4-549SCI/78
592
cation  under   s.  3(c)   itself  authorised  the  Committee
consider the  grant of  bonus on terms mutually agreed upon.
The authority  to reach agreement on behalf of the appellant
is implicit under the notification under s. 3(b). Throughout
the several  meetings and  investigations of  the tripartite
Committee, the  appellant supplied all the facts and details
sought concerning  the formulation and the data for arriving
at an  acceptable solution. The formula of the Committee was
based  largely   on  the  Bonus  Act .  What  the  employees'
representatives did was merely to accept the proposal of the
President of  the Association  of  employers.  There  was  a
written  agreement   dt.  5th   June,  1969   to  which  the
representatives of  both sides  were signatories. To dismiss
the whole  consensual adventure  and the culminating written
agreement as  nothing but  an exercise  in recommendatory or
advisory futility  is to  bid  farewell  to  raw  realities.
Social  justice   is  made   of  rugged   stuff.  Industrial
jurisprudence does  not brook  nice nuances  and torturesome
technicalities to stand in the way of just solutions reached
in a rough and ready manner. Broad consensus between the two
parties does  exist here,  as is  emphatically underlined by
the circumstances  that, all  the  mill  owners  except  the
appellant have  stood by it and all the workers. There is no
substance in  the submission of the appellant that there was
no agreement  for payment  of bonus within the meaning of s.
34. [601 E-H, 602 F, G, 603 A-C, F]
      Section 3 of the U.P. Act is not inconsistent with the
Bonus Act.  The Bonus  Act is a long range remedy to produce
peace. The  U.P. Act provides a distress solution to produce
truce. The Bonus Act adjudicates rights of parties, The U.P.
provision meets  an emergency situation on an administrative
basis. [604 B-C]
     These social projections and operational limitations of
the two statutory  provisions must be grasped to resolve the
legal conundrum.  A broad national  policy on bonus, however
admirable, needs  negotiation, consultation, inter-state co-
ordination and  diplomacy and  causes delay. Hungry families
of restive  workman in militant moods urgently ask for bonus
for onam  in Kerala,  Puja in  Bengal, Dewali in Gujarat, or
other festivals  elsewhere for  a short  spell of cheer in a
long span  of sombre  life. The  State Govt.  with  economic
justice and  welfare of  workers brooding  order its head is
hard pressed  for public  order and maintenance of essential
supplies. [604 D-607 G, H]
JUDGMENT:Basti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

CIVIL APPELLATE JURISDICTION : Civil Appeal No. 2148 of 1977.
Appeal by Special Leave from the Judgment and order dated 19-10-76 of the Allahabad High Court
in Special Appeal No. 412 of 1971. .
Y. S. Chitale, S. Swarup and Sri Narain for the Appellants.
G. N. Dikshit, M. V. Goswami and o. P. Rana for Respondent No. Yogeshwar Prasad, Miss Meera
Bali and Rani Chhabra for Respondent No. 2.
The Judgment of the Court was delivered by KRISHNA IYER, J. Undaunted by a direction of the
State Government under the Uttar Pradesh Industrial Disputes Act, 1947 (the U.P. Act, for short),
unsuccessfully attacked before a learned Single Judge and in appeal from his judgment, the
appellant-owner of two sugar factories in Uttar Pradesh-has secured special leave to reach this Court
and press before us few jurisdictional points which, it' valid, are deprivatory us a few impugned
notification under s. 3(b) of the Act. Before we open the discussion, and, indeed, as paving the way
for it, we may remind ourselves of a jural fundamental articulated elegantly ill a different context by
Mr. Justice Cardozo(1):
"More and more we lawyers are awaking to a perception of the truth that what
divides and distracts us in the solution of a Legal problem is not so much uncertainty
about the law as uncertainty About the facts-the facts which generate the law. Let the
facts be known as they are, and the law will sprout from the need and turn its
branches toward the light."
Social realities mould social justice and the compulsions of social justice, in the context of given
societal conditions" constitute the basic facts from which blossom law which produces order.
The search for the social facts behind s. 3 of the U.K.. Act takes us to the Objects and Reasons Act set
out therein:
"Following the lapse of Rule 81-A of the Defence of India Rules, the Government of
India enacted the Industrial Disputes Act, 1947 but this Act was found inadequate to
deal with the spate of strikes, lock-outs and industrial disputes occurring in the
province. Government were, therefore, compelled to promulgate the United
Provinces Industrial Disputes ordinance, 1947, as an emergency measure till more
comprehensive Legislation on the subject was enacted.
Although more than two years have passed since the termination of the war, normal
life is still far from sight. There is a shortage of foodgrains and all other essential
commodities and necessities of life. Maximum production is required to relieve the
common want and misery. Prices continue to be rising and life has become very
difficult for the common man. The loss of every working hour adds to the suffering of
the community. In these circumstances, it is essential that Government should haveBasti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

powers for maintaining industrial peace and production and for the speedy and
amicable settlement of industrial disputes. The bill, which is similar to the ordinance
already in force, provides for such powers."
(emphasis added) (1) Benjamin Nathan Cardozo "what Medicine can do for Law" address before the
New York Academy of Medicine, Nov. 1. 1928-Readings in law and Psychiatry.
The immediate concern of the court in this case is with s. 3 which, in its opening part, luminously
projects the State control obligated by community well-being. Even here, we may read the relevant
part of s. 3.
3. Power to prevent strikes, lock-outs, etc.-If, ill the opinion of the State Government it is necessary
or expedient so to do for securing the public other or convenience or the maintenance of public
order or supplies and services essential to the life of the community, or for maintaining
employment, it may, by general or special order, make provision-
(emphasis. added)
(a) for prohibiting, subject to the provisions of the order, strikes or lock-outs generally, or a strike or
lock-out in connection with any industrial dispute;
(b) for requiring employers, workman or both to observe for such period, as may be specified in the
order, I) such terms and conditions of employment as may he determined in accordance with the
order;
(c) for appointing committees, representative both of the. employer and workmen for securing amity
and good relations between the employer and workmen and for settling industrial disputes by
conciliation; for consultation and advice on matters relating to production, organisation, welfare
and efficiency:
          (d)  for   constitution    and   functioning    of
               Conciliation   Board    for   settlement   of
industrial disputes in the manner specified in the order;
Provided that no order made under clause (b)-
(i) shall require an employer to observe terms and conditions of employment less favourable to the
workmen than those which were applicable to them at any time within three months preceding the
date of the order;
The testimony from these texts, which are part of the legislative package, is the critical factor
underlying governmental order in our constitutional system. An insight into it is worth while as a
tool of interpretation of s. 3 of the U.P. Act and its harmonisation with s. 34  of the Payment of
Bonus Act, 1965 (the Bonus Act, for brief). A A synthesis of these two statutes is the key to theBasti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

problems posed by Shri Chitale before us, arguing the case for the appellant.
When crisis conditions grip the community the first imperative of good government, 'order', takes
precedence; and the Executive transfixed between 'govern' or 'get out' and guided by value
judgments resorts to firm action. Exigent solution of problems affecting the well-being of the
have-nots, in a social justice setting, desiderates provisional directives to the haves to disgorge
payments, not as final pronouncements on rights but as immediate palliatives to preserve the peace,
This is police power at its sensitive finest when State and society are con- fronted by the dilemma of
'do or die'. And, in a broader perspective, Governments of the Third World must hear the voice
which moved the objective Resolution in the Constituent Assembly, while seeking light to keep
loving peace:
`'The service of India means the service of the millions who suffer. It means the
ending of poverty and ignorance and disease and inequality of opportunity. The
ambition of the greatest man of our generation has been to wipe every tear from
every eye. That may be beyond us, but as long as there are tears and sufferings, so
long our work will not be over.(l) E The problems of law are, at bottom, projections of
life.
"Law is a form of order and good law must necessarily mean good order."(2) We
touch these chords because the roots of jurisprudence lie ill the soil of society's urges,
and its bloom in the nourishment from the humanity it serves. To petrify statutory
construction by pedantic impediments and to forget the law of all laws, viz. the
welfare of the people is to bid farewell to the grammar of our constitutional order. Its
practical application arises in the present case. Before going further we sketch the
facts of the present case and then on to the larger principles, an understanding of
which will unlock the crucial questions arising in the case.
The appellant, as stated earlier, runs two sugar factories . It two different places.
There are around 71 such factories in Uttar Pradesh whose economy, in large
measure, depends on the sugar industry.
(1) The Indian Constitution-Cornerstone of a Nation by Granville Austin, (2) Politica.
Book VII Chapter 4 Section 5.
Moreover, sugar is an essential commodity. Thus, these factories and the any of workers employed
therein fall within the strategic sector of the State economy. It is but natural that Governments is
highly sensitive in the matter of maintenance of sugar supplies and the smooth working of the sugar
factories., Any explosive situation in the shape of an industrial dispute and any disruptive factor
throwing out of gear the employment in factories is sure to throw into disarray public safety, public
order, public production and distribution system and public employment, using these expressions in
their social connotation. Roscoe Pounds' words are jurisprudentially apt : (1) "Law is; more than a
set of abstract norms or legal order. It is a process of balancing conflicting interests and securing the
satisfaction of the maximum wants with tile minimum friction."Basti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

And, Paton has set the tone for Part IV of our Constitution to be used as background music, if we
may say so:
"the law itself cannot be impartial...for its very raison d'etre is to prefer one social
interest of another."(2) As was the wont, presumably, there was apparently a clamour
in 1968 for workers' bonus which hotted up, threatening community tranquillity,
smooth supplies essential to the life of the community and maintenance of
employment and public safety.
Every industrial dispute has a potential for large scale breach of the peace when the
factories and workmen affected are numerous. But the general unrest induced by
industrial demands and resistance may, on critical occasions, blow up unless quia
timet action to de-fuse are taken. This measure has necessarily to be at the
administrative level, since the judicial process is prone to suffer from slow motion.
The U.P. Legislature, with comprehensive vision, provided for long-range
adjudicative resolution of industrial disputes and short-run executive remedies to
pre-empt and contain outbreaks which may get out of control once ignited, and may
even cost human lives in the. 'firefighting' police actions:
"A government ought to contain in itself every power requisite to the full
accomplishment of the objects committed to its care, and to the complete execution
of the trusts for (1) Interpretation of Legal History, p. 165, quoted in "Criminal law -
Principles of Liability by T. S. Batra, p. 612`.
(2) A Text Book of Jurisprudence p.31, quoted in ' Criminal Law Principles of
Liability by T. S. Batra, p. 612.
which it is responsible, free from every other control but a regard to the public good and to the sense
of the people.(') From this angle, s. 3 has been designed as an emergency provision to be exercised in
an excited phase of industrial collision.
Using the power under s. 3(c) of the Act and based on the suggestion of the state Labour Conference
(Sugar) the state Government appointed a tripartite committee in October, 1968 consisting of three
nominees of the Indian Sugar Mills Association and three representatives of the workmen, the
Labour Commissioner being the Chairman of the Committee. The notification under s. 3(c) Was
issued with a view to-
"consider and make its recommendations to Government on the question of grant of
bonus for 1967- 68 to workmen by the Vacuum pall Sugar factories of the State on the
basis of the Payment of Bonus Act 1965, subject to such modifications as may be
mutually agreed upon."(2) No one, at any stage, has assailed the presence of the
statutory preconditions of social urgency. We proceed on the footing that a flare-up
was in the offing and the state acted to pre-empt a break-down.Basti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

It is pertinent to note that the Association is a trade union registered under the Trade
Unions Act, 1926. Its functions are indicated in the definition of "trade union"
in s. 2(h) of that Act and include regulating The relations "between workmen and employers". Thus,
the Association was functionally within its competence to nominate three representatives to sit on
the Committee to regulate the relations between the member-employers and the workmen
employed. The appellant is a member of the said Association.
It is significant to remember that the State Government constituted the tripartite committee under
s, 3(c) as an emergency measure before taking steps under s. 3(b) of the Act so that it may inform
itself in a responsible way through the recommendations made by the Committee which represents
both the wings of the industry. Although s. 3(b) does not depend, for coming into play, upon any
report under s. 3(c) this was a measure to ensure fairness to the concerned elements. The
Committee held several sittings and, at some stages, the appellant or his representative did
participate directly or indirectly in the deliberations. Equally relevant is the circumstance that the
worker's representatives (1) The Administration of Justice-Melvin P. Sikes, Chapter 7, Pawns of
Politics and of power, P. 120 (2) Notification dated 17.10. 1968 of the U.P. Govt. Labour (C) Dept.
actually accepted the formula put forward by the President of the Managements' Association. We
mention these circumstances to indicate that the scales, if at all, were tilted in favour of the mill
owners and Government, on receipt of the recommendations and anxious to freeze the situation,
issued an order under s. 3(b) incorporating and implementing those recommendations. That
notification which was impugned before the High Court and is challenged before us reads:
"WHEREAS on the recommendations of the state Labour Tripartite Conference
(Sugar) held on June 16, 1968, a Committee was constituted under Labour (C)
Department, notification No. 7548(HI)XXXVI-C-109(HI)/ 68, dated October 17,
1968, to consider the question of grant of bonus for the season 1967-68 to their
workmen by the vacuum pan sugar factories of the state on the basis of the Payment
of Bonus Act, 1965 subject to such modifications as may be mutually agreed upon and
to make its recommendations.
AND WHEREAS, the said Committee has considered this question in various
meetings the last meeting having been held on June 5? 1969, and has submitted its
recommendations to the state Government:
AND WHEREAS, the said Committee has succeeded in bringing about an agreement
in regard to the payment of bonus for the season 1967-68 between the
representatives of employers and employees on the basis of Payment of Bonus Act,
1965, with certain modifications and adjustments and has made recommendations
on the subject accordingly which have been accepted by the state Government:
AND WHEREAS, in the opinion of the state Government it is necessary to enforce the
recommendation of the said Committee for securing the public convenience and the
maintenance of public order and supplies and services essential to the life of theBasti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

community and for maintaining employment; NOW, THEREFORE, in exercise of the
powers under clause (b) of section 3 of the U.P. Industrial Disputes Act, 1947 (U.P.
Act No. XXVIII of 1947), the Governor of Uttar Pradesh is pleased to make the
following order and to direct with reference to section 19 of the said Act that the
notice of this be given by publication in the office Gazette;
                           ORDER
     xx             xx                     xx
2. (a) All the Vacuum Pan Sugar Factories in the state whose names have been
mentioned in the Annexure 'A' except the Kisan Co-operative Sugar Factory, Majhola
(Pilibhit), shall pay bonus for the year 1967-68 to all their employees, permanent
seasonal or temporary including contract labour who have worked for not less than
30 working days in the accounting year 1967-68;
xx xx xx The High Court repelled the challenge and upheld the notification, taking the view that an
agreement as recognised in S. 34 of the Bonus Act existed in this case and so the order which merely
gave effect to that agreement was not bad in law.
The main ground of attack before us is that the state Government cannot act in the area of bonus
without breach of the embargo in s. 34 of the Bonus Act and so the impugned notification must fail
for want of power. Although this is the thrust of the submission, Shri Chitale has trichotomised it, as
it were. First, the Bonus Act being a complete Code covering profit-sharing bonus, no other law can
be pressed into service to force payment of bonus by the managements. Secondly, s.3(b) of the U.P.
Act is independent of any agreement between the affected parties and the notification thereunder
operates on its own and not by force of consensus or contract between the workmen and the
managements. In this view, it was wrong for the High Court to have salvaged the notification under
s. 3(b? as embodying an agreement to pay bonus. The third submission of counsel was that ac a fact
there was no agreement between the appellant and his workmen within the scope of s. 34 of the
Bonus Act since the representatives of the Association had no power to bind its members by any
agreement on bonus, having been appointed solely to make certain recommendations. Moreover,
the appellant had specifically informed the representatives of the Association that it did not agree to
any variation from the approved balance-sheet of the company and had withdrawn its consent to the
formula which found favour with the Committee, Finally, though feebly, it was argued that if an
agreement could be spelt out under s. 34 of the Bonus Act enforcement should be left to s. 21 of that
Act and not to the punitive recovery provisions of the U.P. Act.
The Single Judge of the High Court dismissed the writ petition reading an agreement into the
Committee's recommendations and the eventual order under s. 3(b) of the Act. This agreement was
valid under s. 3(b) of the Bonus Act. On appeal, the Two Judges on the Bench disagreed and the case
went before a third Judge, who in an elaborate judgment, agreed with the learned Single Judge and
upheld the order of the Government as an agreement under s. 34 of the Bonus ACT. We now
proceed to discuss the merits of counsel's contentions.Basti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

We focus our attention on two principal facets of the question. They are (a) whether s. 3(b) is
inconsistent with the Bonus Act; and (b) whether an agreement within the meaning of S. 34(1) (as
the law then stood) could be spelt out of the facts of the present case.
There is no challenge to the competence of the state Legislature to enact s. 3 of the Act. Indeed,
more than one item in Lists II and III will embrace legislation of the pattern of s. 3. Even so the
short point sharply raised by Shri Chitale is that Parliaments having enacted the Bonus Act in 1965,
occupied that part of industrial law, and s. 34 in terms contains a non-obstante clause. That section
reads:
Effect of laws and agreements inconsistent with the Act.
34. (1) Save as otherwise provided in this section, the provisions of this Act shall have
effect notwithstanding anything inconsistent therewith contained in any other law for
the time being in force or in the terms of any award, agreement, settlement or
contract of service made before the 29th May, 1965.
34. (2)........................................
...................................................... ...................................................... ......................................................
34. ( 3 ) Nothing contained in this Act shall be constructed to preclude employees employed in any
establishment or class of establishments from entering into agreement with their employer for
granting them an amount of bonus under a formula which is different from that under this Act:
Provided that any such agreement whereby the employees relinquish their right to
receive the minimum bonus under section 10 shall be null and void ill so far as it
purports to deprive them of such right."
The effect of this provision is that anything inconsistent with the Bonus Act contained
in any other law will bow and bend before it. Secondly, agreements made after 29th
May 1965 will be valid regarding bonus even if they be inconsistent with the formulae
in the bonus Act.
Shri Chitale did not dispute the proposition that if a concluded agreement could be
read into the recommendations of the tripartite Committee relating to Bonus, it
would be valid despites. 34; but he urged before us that it was impossible to weave
out of mere recommendations the web of a concluded contract on bonus. He
canvassed before us, further, that if an agreement on bonus was necessarily inferable
from the proceedings of the tripartite committee, the enforcement thereof could be
only under s. 21 of the Bonus Act and not by reliance on the more drastic processes of
the U.P. Act.Basti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

A torrent of objective circumstances has emerged in this case to wash out these
submissions. This Court is rarely disposed to reverse a factual affirmation
concurrently reached by the High Court at two tiers. Even so, we may rush past the
more potent circumstances which have a compulsive force in arriving at the
conclusion aforesaid.
Shri Chitale stressed that the Committee itself had a functional limitation writ on the
face of the order under s. 3(c) . Its authority was limited to making recommendations
on the grant of bonus for 1967-68 on the basis of the Bonus Act, subject to such
modifications as mutually agreed upon. Formally, this is correct. But why could the
Committee which had representative of both the wings of the industry not mutually
agree upon a bonus formula ? There was nothing in the notification prohibiting it.
There was everything in the notification promoting it. The whole process was geared
to mutually agreed solutions. Of course, once the representatives of managements
and labour reached an agreement, substantially on the basis of the Bonus Act, they
would proceed to recommend to Government the acceptance of that agreement. The
notification under s. 3(c) contemplated mutual agreement upon bonus as the first
step and the recommendation of the formula so reached as the second step. The good
offices of the Labour Commissioner was also available. In short, the first notification
did not shut out, but, on the other hand, welcomed mutual agreement. As between
the two wings, an agreement materialised. Then it became Government's
responsibility effectively to resolve the crisis and behoved it to put teeth into the
agreement by making it a binding order under s. 3(b). Thereafter, the arm of the law,
as provided in the U.P. Act.
went into action if there was violation. The object of the Government being to keep
the peace and to interdict disruption it did not rest content with an agreement within
the meaning of s. 34 and resort to the leisurely processes of s. 21. Exigent situations
demand urgent enforcement; and therefore government went a step further than the
agreement and embodied it in an order under s. 3(b). This incorporation in a
notification under s. 3(b) did not negate the anterior agreement between the parties.
The order of Government under s. 3(b) makes the dual stages perfectly plain. For
instance, there is the following tell-tale recital "Whereas the said Committee has
succeeded in bringing about an agreement in regard to the payment of bonus for the
season 1967-68 between the representatives of the employers and employees on the
basis of Payment of Bonus Act, 1965, with certain modifications and adjustments". In
unmincing language, the notification states that an agreement on the payment of
bonus has been successfully brought about substantially on the lines of the Bonus
Act. In the same notification, Government proceeds to state that the said agreement
has been forwarded to it in the shape of recommendations which have been accepted
and enforced in exercise of the powers conferred by clause (b) of s. 3 of the Act. The
anatomy of the order under s. 3(b) being what we have explained above, the inference
is inevitable that there is a clear agreement in regard to the payment of bonus for the
relevant season between the employers and employees and ingenious argumentBasti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

cannot erode that effect.
The next limb of the argument of Shri Chitale is that in fact there is no evidence of
his. client having authorise the representatives of the Association to act on its behalf
in agreeing to the bonus formula. On the contrary, he had withdrawn the authority
originally conferred. We cannot agree with this specious, though plausible,
submission. lt admits of no doubt that the Association is a trade union registered
under the Trade Unions Act and the functional competence of a trade union
definitionally extends to regulating the relations between workmen and employers. S.
2(h) to negotiate an agreement on. payment of bonus surely falls within the scope of
regulation of the relations between the workmen and the employers. Secondly, the
notification under s. 3(c) itself authorises the Committee to consider the grant of
bonus on terms mutually agreed upon. Authority to reach agreement on behalf of the
managements is thus implicit in the notification under s. 3(c). Moreover, the
Association, having the capacity to represent all the members within the area of its
authority, sat on the committee though its representatives and became effective
proxies of the appellant was present in the tripartite Conference at Naini Tal on June
16, 1968 and it was at that Conference the decision to set up the Committee was made
and a resolution to that effect passed, leading to the notification of October 17, 1968.
Moreover, throughout the several meetings and investigations of the tripartite
Committee. the appellant supplied all the facts and details sought concerning the
formulation and the data for arriving at an acceptable solution. The formula of the
Committee was based largely on the Bonus Act itself with some variation regarding
the valuation of the closing stock. Importantly, what the employees` representatives
did was merely to accept the proposal of the President of the Association of
employers. There was a written agreement dated June 5, 1969 to which the
representative of both sides were signatories. To dismiss the whole consensual
adventure and the culminating written agreement as nothing but an exercise in
recommendatory or advisory futility is to bid farewell to raw realities. Industrial
jurisprudence does not brook nice nuances and torturesome technicalities to stand in
the way of just solutions reached in a rough and ready manner. Grim and grimy life
situations have no time for the finer manners of elegant jurisprudence. Social justice
is made of rugged stuff. Broad consensus between the two parties does exist here, as
is emphatically underline by circumstance that 'all the mill owners except the
appellant have stood by it-and all the workers'. Where social justice is the touch-
stone, where industrial peace is the goal, where the weak and the strong negotiate to
reach workable formulae unruffled by the rigidities and formalisms of the law of
contracts, it is impermissible to Frown down the fair bonus agreement reached by the
representatives of both camps and accepted by the employees in entirety and the
whole block of employers minus the appellant, on a narrow construction of the
notification under s. 3 (b) of the U.P. Industrial Disputes Act, 1947 or s. 34'. Of the
Bonus Act or s. 2(c) of the Contract Act. Labour law is rough hewn and social justice
sings a different tune. We reject, without hesitation, the appellant's submission that
there was no agreement for payment of bonus within the meaning of s. 34 of theBasti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

Bonus Act and affirm the concurrent finding of the High Court on that issue.
The second seminal problem of power that falls for consideration here has deeper
jurisprudential import and wider political constitutional portent, so much so
decisional elucidation becomes necessitous. We have stated earlier that s. 34 of the
Bonus Act has a monopolistic tendency of excluding other laws vis-a-vis
profit-sharing bonus. The basic condition for nullification of s.3(b) of the U.P. Act is
that. when it enters the area of bonus, it is inconsistent with the provisions of the
Bonus Act.
"Inconsistent", according to black's Legal Dictionary, means 'mutually repugnant or
contradictory; contrary, the one to the other so that both cannot stand, but the
acceptance or establish ment of the one implies the abrogation or abandonment of
the other'. So we have to see whether mutual co-existence between s. 34 of the Bonus
Act and s. 3(b) of the U.P. Act is impossible. If they relate to the same subject-matter,
to the same situation, and both substantially overlap and are co-extensive and at the
same time so contrary and repugnant in their terms and impact that one must perish
wholly if the other were to prevail at all-then, only then, are they inconsistent. In this
sense, we have to examine the two provisions. Our conclusion, based on the
reasoning which we will presently indicate, is that 'inconsistency' between the two
provisions is the produce of ingenuity and consistency between the two laws flows
from imaginative under standing informed by administrative realism. The Bonus Act
is a long- range remedy to produce peace; the U.P. Act provides a distress solution to
produce truce. The Bonus Act adjudicate rights of parties; The U.P. provision meets
on emergency situation on an administrative basis. These social projections and
operational limitations of the two statutory provisions must be grasped to resolve the
legal conundrum. When 'the sequestered vale of life' is in imminent peril of
disruption immediate tranquillisers are the desideratum. The escalating danger to
law and order, to public safety, to maintenance of supplies essential to the life of the
community, the break-down of production and employment-these anti-social
consequence of 'the madding crowds' 'ignoble strife' are sought to be controlled by a
quick shot in the arm by use of s. 3(2). It is a balm for the time, not a cure which
endures. Indeed, it is an administrative action, not a quasi-Judicial determination.
We may easily visualise other explosive occasions which traumatise society and so
attract s. 3(b).
The specific fact-situation which confronted the State must be seen in perspective.
Labour and capital are partners in production. When one of the partners numerous
but needy, demands a share in the profits, beyond wages, to better its lot, industrial
legislation chalks out rights and limits, prescribes formulae, creates adjudicatory
machinery, awards are made, reviewed and enforced and parties seek social justice
through the judicial process. The Bonus Act, read with the Industrial Disputes Act,
codifies this branch of rights and remedies. But it is a notorious infirmity of the noble
judicative methodology that adherence to certain basic processual norms makesBasti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

procrastinatory delay a besetting sin and an inevitable evil. The end product is good
were it delivered promptly but the operation tantalises and sometimes self-defeats.
The working class though a weaker class, when organised, is militant. Their
privations are too desperate to stand delay Policy formu-
lation by Government takes time, involves consultation; adjudication involves long
hearing and appeal upon appeal.
The discussion of legal prophylaxis as part of the dynamics of Jurisprudence becomes
relevant at this stage. Necessity is the mother of tension; tension frays temper and
maddened men turn violent. When both sides are psyched up into frenzy, public
safety, maintenance of essential supplies, people's employment and societal order
become.. casualties. A wise administration anticipates and acts before the flams
spread. Once the industrial war is sparked off, the use of force become unobviale.
And police force pitted against mob fury may mean blood and tears. And Indian lives
in Free India, even though of workers, are more precious than the profits of the
corporate sector, Confronted by escalating disorder, the wise ruler cannot afford wait
for lethargic legal justice to deliver its verdict but armed with crisis pouters and
anxious to arrest a blow-up, adopts administrative nostrums which give quick relief
but do not frustrate ultimate justice. Prophylatic processes are not the enemy of
normative law. Sociallyoriented prompt action tranquillises where- drift, vacillation
and inaction may traumatize. Section 3 serves this limited purpose of legalising
administrative intervention to prevent disorder without prejudice to judicial justice
which will eventually be allowed to take its course. An order under Sec. 3(b) is
administrative; a proceeding under the Bonus Act is judicial. The former manages a
crisis, the latter determines rights. Even when a direction under. the exigency power
involve payments towards bonus or other claim it never can possess finality and is
subject to judicial decision-except, of course, where parties agree to settle their
claims, and then the agreement gives it vitality.
The jural scheme of Sec. 3 is duel, each operating in its own stage and without
contradicting the power of the other. The first say, in crisis management, belongs to
the administrator; the last word in settlement of substantive rights belongs to the
tribunal. The pragmatic dichotomy of the law is flexible enough not to put all its
peacekeeping eggs in the judicial basket. Government acts when the trouble brews
and when the storm has blown over, judicial technology takes over. There are no rigid
compartmentalisations. Sometimes, the judicial process itself has quick-acting
procedures. Likewise, sometimes the executive prefers to consult before going into
action. Under our constitutional order, guidelines are given by the status to ensure
reasonableness in administrative orders. And in a Government with social justice as
the watchword, value judgments are essential to exclude arbitrariness. So it is that
the executive power under Sec. 3 has the leading strings writ right at the top. The
power shall be used only for 'public safety or convenience or the maintenance ofBasti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

public order or supplies and services' essential to the life of the community or for
maintaining employment. It prevails for the nonce, produces (hopefully) tentative
truce, and then the judicial process decides decisively. It is like an executive
magistrate passing a prohibitory order regarding disputed possession or unruly
assembly to prevent breach of the peace and making over to a judicial magistrate to
hear and decide who is in actual possession or whether the restriction on movement
was right. Or, maybe, it is like a magistrate quickly passing orders regarding a
possessory dispute leaving it to the civil court to adjudicate on valid title. No one can
argue that preventive magisterial power, admittedly provisionally and reasonably. is
inconsistent with the civil judicial machinery which speaks finally.
Dealing with the identical provisions in an identical situation where dn appeal
reached this Court and the parties were identical, Mudholker, J., speaking for the
Court, explained the scheme or the same Section(1) 3 and its scope which fits into the
pattern we have explained. The learned judge observed(2):-
"The opening words of s. 3 themselves indicate that the provisions thereof are to be
availed of in an emergency. It is true that even reference to an arbitrator or a
conciliator could he made only if there is an emergency. But then an emergency may
be acute. Such an emergency may necessitate the exercise of powers under cl. (b) and
a mere resort to those under cl. (d) may be inadequate to meet this situation.
Whether to resort to one provision or other must depend upon the subjective
satisfaction of the State Government upon which powers to act under s. 3 have been
conferred by the legislature. Dealing with the canons of statutory construction the
learned judge observed: No doubt this result is arrived at by placing a particular
construction on the provisions of that section but we think where justified in doing
so. As Mr. Pathak himself suggested in the course of his arguments, we must try and
construe a statue ill such a way, where it is possible to so construe it, as to obviate a
conflict between its various provisions and also so as to render the statute or any of
its provisions constitutional. By limiting the operation of the provisions of cl. (b) to
an (1) An amendment to Sec 3 (e) has since been made. (2) [1961] 2 SCR 330 at
342-343, State of U.P. & Ors.
v. Basti Sugar Mills Co. Ltd.
emergency we do not think that we are doing violence assuming that the width of the language could
not be limited by construction it can be said that after the coming into force of the Constitution the
provisions can, by virtue of Art. 13, have only a limited effect as stated above and to the extent that
they are inconsistent with the Constitution, they have been rendered void.
In the strain, the court rebuffed the unreasonable argument based on 'reasonableness' in Art. 19(6):
In our view, therefore, the provisions of cl. (b) of s. 3 are not in any sense alternative to those of cl.
(d) and that the former could be availed of by the State Government only in an emergency and as a
temporary measure. The right of the employer or the employee to require the dispute to be referredBasti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

for conciliation or adjudication would still be there and could be exercised by them by taking
appropriate steps. Upon the construction we place on the provisions of cl. (b) of S. 3 it is clear that
no question of discrimination at all arises. Similarly the fact that action was taken by the
Government in all emergency in the public interest would be a complete answer to the argument
that action is violative of the provisions of Art. 19(1) (g). The restriction placed upon the employer by
such an order is only a temporary one and having been placed in the public interest would fall under
cl. (6) of Art. 19 of the Constitution".
(emphasis added) In a practical sense, this dichotomous reconciliation has humanistic value in
administration. Let us take the case of bonus. A broad national policy on bonus, however admirable,
needs negotiation, consultation inter-state co- ordination, diplomacy and causes delay. Likewise, an
industrial adjudication on bonus, with all the trappings of natural justice, appeal and writ
proceedings, consumes considerable time. Hungry families of restive workers in militant moods
urgently ask for bonus for Onam in Kerala, Pooja in Bengal, Dewali in Gujarat or other festival
elsewhere, for a short spell of cheer in a long span of sombre life. The State Government, with
economic justice and welfare of workers brooding over its head, is here-pressed for public order and
maintenance of essential supplies. Immediate action may take trigger-happy policing, shape or
emergency direction to make ad hoc payments, worked out in 5-549SCI/78 administrative fairness.
This latter course may often be favoured, given the correct orientation. But even here some
governments may prefer to confer, persuade parties to concur and make binding order. This
requires legislative backing. So Sec. 3. But such an improvised solution may leave one or the other or
even both dissatisfied with regard to ultimate rights. While enforcing the ad interim directive by the
authority of law, the door is left ajar for judicial take- over of the industrial dispute. If workers have
got more, the excess will have to be adjusted; if less the employers will pay over. This will be taken
care of by Section 3(e) (before amendment) and by the Bonus Act now. A crisis is best solved by this
procedure at the State level on a fair administrative basis. But lasting policy solutions are best
produced at the Central level and final rights crystallised at the tribunal level. The lengthy judicial
process may, as here, be obviated if, by a tripartite arrangement an agreement within the scope of s.
34 of the Bonus Act is reached.
The ruling of this court in State of U.P. & Anr. v. Basti Sugar Mills Co. Ltd. (Supra) supports the
synthesis we have evolved. The only difference is that there is now Mo reference of a bonus dispute
under S. 3 (e) of the U.P. Act. Instead, the same dispute will-where no agreement or settlement
stands in the way, as it does here-on application, be referred for adjudication under the Bonus Act
read with the Industrial Disputes Act, 1947.
The analysis shows the absence of basic inconsistency and presence f intelligent method in the U.P.
and the Central provisions.
We hold. after this long tour, that the goal of social justice and public peace, essential to good
Government is best reached by reading together and not apart. The High Court's order is upheld and
the appeal dismissed, of course, with costs.
P.H.P.                                     Appeal dismissed.Basti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

Basti Sugar Mills Co. Ltd vs State Of U.P. & Anr on 11 September, 1978

