Arunachal Pradesh (Horticultural Produce, Marketing and
Processing) Board Act, 2014
ARUNACHAL PRADESH
India
Arunachal Pradesh (Horticultural Produce, Marketing
and Processing) Board Act, 2014
Act 9 of 2014
Published on 30 May 2014• 
Commenced on 30 May 2014• 
[This is the version of this document from 30 May 2014.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Arunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014(Act No. 9 of
2014)Last Updated 24th February, 2020(Received the assent of the Governor on 30th May, 2014
and published in the Arunachal Pradesh E.O. Gazette No 100, Vol. XXI dated 5th June, 2014)An Act
to provide for improved regulation in marketing of horticultural produce, development of efficient
marketing system by constituting State Marketing and Processing Board for promotion of
horticultural processing and horticultural exports, establishment and proper administration of
markets for horticultural produce in the State of Arunachal Pradesh and to ensure level playing field
for competitive markets to operate through setting up of minimum standards for facilities,
procedures and system, thereby promoting the establishment of well administered and efficient
infrastructure for marketing of horticultural produce in and from the State of Arunachal Pradesh
and matters connected therewith and incidental thereto.Be it enacted by the Government of
Arunachal Pradesh in the Sixty-fifth Year of the Republic of India, as follows:Chapter - I Preliminary
1. Short title, Extent and commencement.
(1)This Act may be called the Arunachal Pradesh Horticultural Produce Marketing and Processing
Board Act, 2014,(2)It shall extend to whole of Arunachal Pradesh.(3)It shall come into force on such
date as the State Government may by notification in the Official Gazette appoint.
2. Definition.
- In this Act unless the context otherwise requires -(i)"Horticultural Produce" means all produce and
commodities whether processed or unprocessed, of Horticulture produce as are specified in the
Schedule to this Act or declared by the Government of Arunachal Pradesh by notification under
section 19 of this Act and also includes a mixture of two or more than two products.(ii)"HorticultureArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

grower/Producer" means a person who is bonafide Arunachalee and possesses land in Arunachal
Pradesh who is engaged in production of horticultural produce by himself/herself or by hired labour
or otherwise, but not include any market functionary.(iii)"Board" means Arunachal Pradesh
Horticultural Produce Marketing and Processing Board established under section 3 of this
Act.(iv)"Business" means purchase, sale, processing, value addition, storage, transportation and
connected to activities of Horticultural produce.(v)"Buyer" means a firm, a company or a
Cooperative Society or Government agency, Public Undertaking/Public Agency or on behalf of any
other person or agent who buys or agrees to buy horticultural produce in the market
areas.(vi)"Bye-Laws" means the bye-laws made by the Board for the Committee under section of 78
of this Act.(vii)"Chairman" means Chairman of the Board.(viii)"Commission agent" means a person
who on behalf of his principal trader and in consideration of a commission or percentage on the
amount involved in such transaction buys horticultural produces and makes payment, keeps it in his
custody and delivers it to the principal trader in due course or who receives and takes in his custody
horticultural produce for sale within the market areas or from outside the market area and sells the
same in the market area and collect payment thereof from the buyer and remits the sale proceeds to
his principal trader.(ix)"Committee" means horticultural produce market committee established
under section 29;(x)"Contract farming" means farming by a person called "contract farming
producer" under a written agreement with another person called "contract farming sponsor" to the
effect that his farm produce shall be purchased as specified in the agreement;Explanation. -
"Contract Farming Producer" means an individual horticultural growers or an association of
growers by whatever name called registered under any law for the time being
enforce.(xi)"Cooperative Society" means a Cooperative Society of producers registered under the
provisions of the Arunachal Pradesh Cooperative Society Act 1979 which deals in the purchase, sale,
processing, or storage of Horticultural produce or is otherwise engaged in the business of disposal of
horticultural produce.(xii)"Export" means dispatch of horticultural produce outside
India.(xiii)"Exporter" means a person who exports horticultural produce.(xiv)"E-trading" means
trading in which billing, booking, contracting, negotiating, information exchange, record keeping,
and other connected activities are done electronically on computer/Internet.(xv)"Labour" means, a
person engaged in loading, unloading, filling, stitching, emptying, carrying, cleaning, drying,
grading, storing,stacking,bagging,stamping etc of any horticultural produce in the notified market
area.(xvi)"Import" means bringing horticultural produce from outside India.(xvii)"Importers"
means a person who imports horticultural produce from outside India.(xviii)"License" means
license granted under section 25 of the Act.(xix)"Licensee" means a person or association, firm,
company, public sector undertaking or society holding a license issued under this Act.(xx)"Market"
means a market established under section 19 of this Act which includes market area, market
yard/sub-yards and principal market.(xxi)"Market area" means area notified under section 19 of this
Act.(xxii)"Market charges" includes on account of or in respect of commission, brokerage, weighing,
measuring, loading, unloading, or carrying, cleaning, drying, sieving, stitching, stacking, hiring,
gunny bags, stamping, bagging, storing, warehousing, grading, surveying, transporting and
processing.(xxiii)"Market functionaries" means a trader, a commission agent, buyer, processor, a
stockiest, and any other person as may be declared by the State Government.(xxiv)"Market Yards"
in relation to a market area means a specified place and includes any enclosures, buildings or
locality declared as such in any market by the State Government by notification.(xxv)"Member"
means Member of the Board and including the Chairman of the Board.(xxvi)"Marketing" means allArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

activities involved in the flow of Horticultural produce from the production points commencing
from the stage of harvest till they reach the ultimate consumers, viz, grading, processing, storage,
transport, channels of distribution and ail other functions involved in the
process.(xxvii)"Notification" means notification issued under this Act and published in the official
gazette.(xxviii)"Notified horticultural produce" means any horticultural produce notified under
section 19 of this Act.(xxix)"Person" means includes any individual, any company, or association
whether corporate or not.(xxx)"Producer" means a person who in his normal course of avocation,
grows, manufactures, rears or produces, as the case may be, horticultural produce personally,
through or otherwise but not doesn't includes a person who work as trader or a brokers or who is
partner of the company or firm of traders or brokers otherwise engaged in the business of disposal
or storage of horticultural produce other than grown, manufactured, reared or by himself through
tenants or otherwise.(xxxi)"Prescribed" means prescribed by rule made under this
Act.(xxxii)"Processing" means any one or more of a series of treatments relating to powdering,
crushing, decorticating, de-husking,parboiling, polishing, Ginning, pressing, curing, cleaning, or any
other manual, Mechanical, chemical or physical treatments to the raw horticultural produce or its
products is subjected to.(xxxiii)"Processor" means a person who undertakes processing of any
notified horticultural produce on his own accord or on payment of a charge.(xxxiv)"Private market
yard" means such place other than the market yard/sub-market yard in the notified market area
where infrastructure has been developed and managed by a person for making of notified
horticultural produce holding a license for this purpose under this Act.(xxxv)"Registration" means
registration done under this Act.(xxxvi)"Regulation" means regulations made by the Board under
section-70 of this Act.(xxxvii)"Retail rate" means sale of horticultural produce not exceeding such
amount as may be prescribed.(xxxviii)"State Government" means the Government of Arunachal
Pradesh.(xxxix)"Seller" a person who sells or agrees to sell any horticultural produce.(xxxx)"Trader"
means a person who in his course of business buys or sells any notified horticultural produce and
includes a person engaged in processing of horticultural produce but doesn't includes
growers,(xxxxi)"Transportation" means taking horticultural produce by push cart, bullock cart,
truck other vehicle etc. in course of business for marketing from one place to
another.(xxxxii)"Transporter" means a person who transport horticultural produce.(xxxxiii)"Value
addition" means processing, grading, packaging or other activities due to which value is added to
horticultural produce.(xxxxiv)"Managing Director" means any person appointed by the State
Government for the purpose of this Act.(xxxxv)"Secretary" means the Secretary of the market
committee and includes any other officers empowered to exercise such powers and functions of the
secretary.Chapter - II Establishment, Constitution, Powers and Functions of The Board
3. Establishment of the Board.
(1)The State Government may, by notification, for coordinating the activities of market and for
development, promotions, and regulation of horticultural produce marketing, establish the
Arunachal Pradesh Horticultural Produce marketing and Processing Board.(2)The Board shall be a
body corporate having perpetual succession and a common seal and may sue and be sued in its
corporate name and shall be competent to acquire and hold property both movable and immovable
and to lease, sale or otherwise transfer any such property aimed to contract and to do all other
things necessary for the purpose which it is established.Arunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

4. Constitution of the Board.
- The Board shall consist of one non-official Chairman, seven other Ex- Officio members and two
non-official members to be nominated/ appointed by the State Government in the following
manner, namely(A)Ex-Officio Members(i)The Commissioner/Secretary (Horticulture) to the
Government of Arunachal Pradesh - ViceChairman.(ii)The Commissioner/Secretary (Agriculture) to
the Government of Arunachal Pradesh.(iii)The Secretary (Finance) or his representative to the
Government of Arunachal Pradesh.(iv)The Registrar Cooperative Society or his Representative,
Arunachal Pradesh.(v)The Director of Horticulture, Arunachal Pradesh.(vi)The Director of
Agriculture, Arunachal Pradesh.(vii)The Managing Director, of the Horticultural Marketing Board
who shall be the Member Secretary.(viii)One representative of NABARD, Itanagar.(B)Non-official
members(i)The President of Arunachal Chamber of Commerce and Industry.(ii)One of the
horticultural progressive farmer.
5. Term of office of the Chairman and the non-official members of the Board.
(1)The term and tenure of the Board shall be for 5 (five) years.(a)"The term of the office of Chairman
of the Board shall be for five years and the Chairman of the Board shall be appointed or nominated
by the Government from such non-official members of prominent public leaders or elected
representative and shall not be removed from the post before the expiry of tenure as specified under
the Act, unless, his removal is extremely warranted under law on ground of his/her involvement in
the corrupt practice. If State Government feel appropriate, the Chairman of the Board may be
re-appointed for another term as deem fit.(b)The Chairman of the Board shall exercise such powers
and functions as may be delegated to him by the Board or as may be prescribed."(2)The tenure of
the Non-Official members of the Board shall hold office during the pleasure of the State Government
and shall come to an end as soon as he ceases to hold the office by virtue of which he was
nominated.(3)Whenever there is a temporary vacancy in the office of the Chairman, the
Vice-Chairman shall act as the Chairman during the period.
6. Disqualification of Member of the Board.
- No person shall be eligible to become a member of the Board who -(a)Does not ordinarily reside
within Arunachal Pradesh;(b)Is below 25 years of age;(c)Has been removed under section 8 or
Section 33 of this Act;(d)Is of unsound mind; or(e)Has been declared insolvent or sentenced by a
criminal court, whether within or outside Arunachal Pradesh for an offence involving immoral
turpitude.Provided that the disqualification under clause (e) on the ground of a sentence by a
criminal court shall not apply after the expiry of tenure from the date on which the sentence of such
person has expired.
7. Resignation of Members of Board.
- The Chairman of the Board may resign by tendering his resignation to the State Government and a
member other than the Chairman of the Board may resign from membership by tendering hisArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

resignation to the State Government through the Chairman of the Board, and the seat of such
Chairman or the member, as the case may be, shall become vacant on the date of acceptance of his
resignation.
8. Removal of member of board.
- The State Government may remove any non-official of member of the Board who has become
subject to any of the disqualification specified in section 6 or who is, in its opinion, is unfit to act, as
a member or remiss in the discharge of his duties.Provided that before removing a member, the
reasons for the proposed action to be taken shall be conveyed to him/her and his/her reply invited
within a specified period and duly considered:Provided further that any vacancy of the non-official
member shall be filled in as early as practicable.
9. Appointment of officers and servants of the board.
(1)The Board shall have a Managing Director who shall be appointed by the State Government and
consist of the following other officers (i) One General Manager (ii) Two Assistant General Manager
(Personnel, Accounting & Packaging) (Re-designated from the existing Deputy Manager) (iii)
Seventeen Marketing Manager and Seventeen Assistant Marketing Managers (iv) One Accountant
cum Cashier and such other office bearer as may be appointed by the State Government.(2)The
Managing Director appointed under sub-section (1) shall also function as the Member Secretary of
the Board and shall be appointed from amongst the officers of Department of Horticulture or
Department of Marketing or from the serving General Manager of the Board.(3)The General
Manager shall function as Chief Executive Officer of the Board and shall be nominated/appointed
from the Deputy Managers of the Board on seniority basis by the State Government.(4)For the
efficient discharge of duties and functions of the Board and the Committees, the State Government,
may appoint such other officers and employees including Civil Engineer on deputation as may be
necessary.(5)The Superintendence and control over all the officers and employees of the Board and
Committees shall vest in the Managing Director of the Board.
10. Allowances to Chairman and Non-Official members of the Board.
- The Chairman and Non-Official members of the Board shall be paid from the Marketing
Development Fund for such sitting fees and allowances as may be prescribed.
11. Powers and functions of Board.
(1)The Board shall, subject to the provisions of this Act perform the following functions and shall
have power to do such thing as may be necessary or expedient for carrying out the following
functions.(i)Exercise superintendence and control over all the Committees established and
constituted under this Act.(ii)Coordinate the working of the Committees and other affairs thereof
including programmes undertaken by such Committees for the development of markets and market
areas;(iii)Undertake the State Level Planning of the Development of Horticulture produceArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

markets;(iv)Administration of the Marketing Development Fund;(v)To give directions to the
Committees in general or any Committees in particular with a view to ensure improvement
thereof;(vi)Any other functions specifically entrusted to it by this Act; and(vii)Such other functions
as may be entrusted to the Board by the State Government.(2)Without prejudice to the generality of
the foregoing provisions, such functions of the Board shall also include-(i)To approve proposals for
selection of new sites by the Committees for establishment of principal or sub-market yard;(ii)To
approve proposal for constructing infrastructure facilities in the market area such as grading, pack
houses, storage's, processing, other post harvest management facilities etc;(iii)To supervise and
guide the Committees in the preparation of plans and estimates of construction programme
undertaken by the Committee;(iv)To execute all works chargeable to the board fund.(v)to maintain
accounts and get the same audited in such form and in such manner as may be prescribed.(vi)To
publish annually at the close of the financial year its progress report, balance sheet and statement of
assets and liabilities and sent copies thereof to each member of the Board and the State
Government.(vii)To undertake marketing extension activities in the Board for the transfer of
marketing technology and extension services. It may also make necessary arrangement for
propaganda and publicity on matters related to regulate marketing of an Horticulture produce and
development of marketing;(viii)To provide facilities for the training of officers and staff of
Committees and the Board after assessing the demand for trained personnel in Horticulture at all
levels:To prepare and adopt budget for the ensuing financial year;(sic)or organize
seminars/workshop/ (sic) etc; on subjects related to (sic) marketing;(xi)To do such other things as
may be of general interest to Committees or considered necessary for the efficient functioning of the
Board;(xii)To organize and promote grading and standardization of notified Horticulture produce
and e-trading; and(xiii)To set up Horticulture Produce Marketing Standards Bureau to perform
such functions and duties as may be prescribed for the purpose of promotion of grading,
standardization and quality certification of Horticulture produce in the State;
12. Powers and functions of the Managing Director of the Board.
- The Managing Director of the Board shall(i)Exercise supervision and control over officers and staff
of the Board in matters of executive administration, concerning accounts and records and disposal
of all questions relating to the service of the employees in accordance with the procedure as may be
prescribed;(ii)Incur expenditure from the Marketing Development /corpus fund on the sanctioned
items of work;(iii)Have the same powers as are conferred under the financial rules of the State
Government on the Head of the Department and declared as head of the Department and exercise
such other powers and discharge such other duties as may be prescribed:(iv)To sanction all type of
leave, draw salaries, T.A. Bills etc of all categories of employees under the Board;(v)To be the
appointing authority of group C and D employees including contingency staff.(vi)Have the power to
transfer employees Committee of the Board and vice-versa administrative grounds;(vii)In case of
emergency, direct (sic) or stoppage of any work and (sic) which requires the sanction
(sic).(viii)Prepare annual budget of the Board;(ix)Arrange for internal audit of the Board and
maintain records of the proceedings of the meeting of the Board in accordance with the procedure as
may be prescribed:(x)Take such steps as deemed necessary for execution of the decision of the
Board;(xi)Inspect the construction work undertaken by the Committees either from their own funds
or loans and or grants provided by the Board or any other agencies and take correctiveArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

measures;(xii)Report such acts either of the Committees or of the Board which are contrary to the
provisions laid down under this Act or rules and bye-laws made thereunder to the State
Government; and(xiii)Take such steps as deemed necessary for effective discharge of the functions
of the Board.
13. Meeting of the board.
(1)The Board shall meet for the transaction of its business at least once in every three months at
such place and at such time as the Chairman may determine.(2)All proceeding of the Board shall be
authenticated by the Chairman and the Managing Director of the Board.(3)The Board shall conduct
the business in such manner as may be prescribed by regulation.
14. Quorum.
- One third of the total members shall constitute a quorum for meeting of the Board. All questions
that may come up before a meeting of the Board shall be determined by a majority of votes of the
members present and voting; and in case of equality of votes, the Chairman shall have a casting vote
or the Chairman may overrule any decision of the Board as may be deemed necessary.Provided that
if a meeting is adjourned for want quorum, no quorum shall be necessary at the next (sic) called for
transacting the same business.
15. Act of the Board not be invalidated.
- No act or proceeding of the board shall be invalid by reason only on of the existence of any vacancy
among its members or any defect in the constitution thereof.
16. Appointment of Sub-Committee.
- The Board may appoint Sub-Committees consisting of three or more members which shall include
Chairman or Vice Chairman for the performance of any of its duties or functions or for giving advice
on any matter incidental thereof and may delegate to such Sub-Committee any of its duties or
functions as it may deem necessary.
17.
The State Government shall exercise superintendence and control over the Board and its officers
and may call for such information as it may deem necessary and, in the event of its being satisfied
that the Board is not functioning properly, or is abusing its powers or is guilty of corruption or
mis-management, it may suspend the Board and, till such time as a new Board is constituted, make
such arrangement for the exercise of the functions of the Board, as it may think fit:Provided that the
Board shall be constituted within six months from the date of its suspension.Arunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

18. Delegation of Powers.
(1)The State Government may conferred any power to the Board under this Act except power to
make rules.(2)Subject to the provisions of this Act, the Board may by general or special order
delegate to the Managing Director of the Board or Sub-Committee appointed by it or to any officer
of the Board any of powers and duties conferred on it by or under this Act as it may deem fit.Chapter
- II Regulation of Trading and Contract Farming
19. Notification of intention of developing and regulating Marketing of
Notified Horticultural Produce.
(1)The State Government on its own or on the representation made by the growers or on the
recommendation of the Board may, by notification, declare its intention of exercising control over
the purchase, storage, processing and sale of' Horticultural produce, in such area as may (sic)
specified in the notification, by inviting (sic) or suggestions from the general (sic) period of thirty
days from the date (sic) of notification which shall be cons (sic).(2)After the expiry of the period
specified in the notification issued under Sub-section (1), and after considering objections and
suggestions, if any, received before the expiry of the specified period, and after making such inquiry,
as may be necessary, the State Government may by notification, declare the area specified in the
notification, or any portion thereof to be a market area for the purpose of this Act and that
marketing of all or any of the kinds of Horticultural produce specified in the notification shall be
developed and regulated in such market area in accordance with the provisions of this Act.
20. Notification of intention to alter Limits of or to split up market area to De-
stablish a market.
(1)The State Government may, by notification;(a)Alter the limits of a market area by including,
within it any other area in the vicinity thereof or by excluding therefrom any area comprised therein;
or(b)Amalgamate two or more market areas and constitute one committee thereof; or(c)Split up a
market area and constitute two or more committees thereof; or(d)De-Establish a market.(2)Every
notification issued under sub-section (1) shall define the limits of the area to be included in or
excluded from a market area, or of the market area to be amalgamated into one. or of the area of
each of the markets to be de-established, as the case may, be and shall also specify the period which
shall not be less than six weeks from the date of publication of the notification within which
objections or suggestions, if any, may be received by the State Government.Any person likely to be
affected by the notification objections issued under Sub-section (1) may, submit his objections or
suggestions in writing to (sic) State Government.(4)Objections and suggestions received under
sub-section (3) within the stipulated period shall be considered and decided by the State
Government and thereafter the State Government may by notification:-(a)Include the area or any
part thereof in the market area or exclude it therefrom;(b)Constitute a new Committee for the
market area amalgamated; or(c)Split up an existing market area and constitute two or more
Committees for such areas, as the case may be; or(d)De-Establish a market.(5)Where a notification
under sub-section (4) has been issued excluding such area in other market area, the StateArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

Government shall, after consulting the Board and the Committee concerned frame a scheme to
determine what portion of the assets and other properties vested in one Committee shall vest in the
Committees and in what manner the liabilities of the Committees shall be apportioned between the
two Committees and such scheme shall come into force on the date of publication of the scheme in
the Official Gazette.
21. Market yards, Sub-Market Yards, farmer's Consumer and private Market
Yards.
(1)In every market area, there may be-(i)Market yard managed by the Committee;(ii)One or more
than one sub-market yards managed by the Committee; and(iii)Private market yards, private
markets farmers and consumer markets managed by a person other than a Committee.(2)The Board
may with the prior approval of (sic) Government, by notification, declare any (sic) place including
any structure, enclose (sic) place, or locality in the market area (sic) yard or sub-market yards for
the (sic) area.
22. Establishment of private yards, and direct purchase of Horticulture
Produce from Horticultural producers.
- Any person who desires to establish private yard for the purchase of Horticulture produce direct
from Horticulture, or for providing infrastructure facilities, in any market area for(a)The process of
the notified Horticultural produce.(b)The Trade of notified Horticultural produce of particular
specification;(c)The export of notified Horticulture produce; and(d)The grading, packing and
transaction in other way by value addition of notified Horticultural produce, shall make an
application for obtaining license in accordance with the provisions of section 25 of this Act.
23. Establishment of consumer's or farmers markets and creation of post
harvest management Facilities by the Farmers/ Horticulturist or Horticultural
producer.
(1)Consumer's or farmer's market may be established by developing infrastructure as may be
prescribed, by any person in any market area, and producer may, himself sell his Horticulture
produce direct to the consumer in such market area, in the manner as may be prescribed.(2)Market
service charge shall be collected on sale of Horticulture produce by the seller and shall be remitted
to the proprietor of the consumer market.(3)Save as otherwise provided in this Act, no market fee
shall be leviable on the transactions undertaken in the consumer's or farmer's
market.(4)Notwithstanding anything contained in this Act, any farmers and Horticulturist may, for
his bonafide use, create post harvest management infrastructure facilities at the farm level such as
grading standardization pack houses, storage (including cold storage's), primary processing for
Horticultural produce and other post harvest management facilities for which the Central or State
Government may provide different scheme and the scheme under Horticulture Technology Mission
being executed by the Department of Horticulture through (sic)ectorate of Marketing under the
Inspection of (sic) Government of India.Arunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

24. Contract Farming.
- No person shall undertake contract farming unless registered under Section 37 of this Act, and
shall have to enter into an agreement with contract farming producer on such form and in such
manner as may be prescribed.
25. Grant and renewal of license of Private yard.
(1)Any person who under section 22 desires to purchase notified Horticulture produce direct from
the Horticulture or the producer or wishes to establish a private market yard or under subsection (1)
of section 23 desires to establish consumer or farmer market in one or more than one market area,
shall apply to the Managing Director of the Board for grant or renewal of license, as the case may be,
for such period, in such form, on such conditions and on payment of such fees as may be
prescribed.(2)Application received under sub section (1) for grant or renewal of license may be
accepted or rejected for the reason to be accorded in writing, provided that license shall not be
granted or renewed if(i)The Committee dues are outstanding against the applicants.(ii)The
applicants are minor or bonafide;(iii)The applicant has been declared defaulter under the Act and
the rules and bye-laws made thereunder;(iv)The applicant having been declared guilty in any
criminal case and convicted with imprisonment;(v)The State Government is satisfied that granting
or renewal of license to the applicant is not going to promote the interest of the producers;(vi)There
is any other reasons which the Managing Director of Board may consider to be against the interest
of producers or consumers.
26. Power to cancel or suspend license.
- Subject to the provisions of this Act, any license issued or renewed under section 25, may be
suspended (sic) cancelled by the Managing Director of the Board (sic) affording the holder of such
license the (sic) being heard, on the following grounds:-(a)If the license has been obtained (sic)
misrepresentation or fraud; or (sic)(b)If the holder of the license or any of his/her servant or any
person acting on his/her behalf, commits a breach of any of the terms or conditions of license;
or(c)If the holder of the license in combination with other license commits any act or abstains from
carrying on his/her normal business in the market area with the intention of will fully obstructing,
suspending or stopping the marketing of notified horticultural produce in the market
yard/sub-market yard and in consequences whereof the marketing of the notified horticultural
produce has been obstructed, suspended;(d)If the holder of the license has become an insolvent;
or(e)If the holder of the license incurs any disqualification as may be prescribed; or(f)If the holder of
the license has committed of any offence under this Act, for the first time and committed the same
offence within three years for subsequent convictions.
27. Regulation of marketing of Notified horticultural produce.
(1)No person shall, except in accordance with the provisions of this Act and the rules and bye-laws
made thereunder(i)Use any place in the market area for the marketing of notified horticulturalArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

produce and(ii)Operate in the market area as a market functionaries.(2)Nothing in sub-section (1)
shall apply to the following sale or purchase of such horticultural produce:-(i)Where the sale is made
by the producer himself to any person for his/her domestic consumption in the quantity up to
prescribed limit;(sic)Purchase or sale of which is made by a petty (sic)der as may be prescribed;
28. Sale of notified horticultural Produce in the market.
(1)All notified horticultural produce shall ordinarily be sold in the market yards, sub-market yard or
in the private yards of the license holder, subject to the provision of sub-section (2);Provided that
notified horticultural produce may be sold at other places to a license holder especially permitted in
his behalf under section 22 and 23 of this Act:Provided further that it may not be necessary to bring
Horticulture produce covered under contract farming to the market yard, sub-market yard or
private yard and such Horticulture produce may be directly sold to contract farming sponsor from
farmers fields.(2)The price of the notified Horticulture produce, brought for sale into the market
yard, shall be settled by open auction or by any other transparent system as may be prescribed and
no deduction shall be made from the agreed price on any account whatsoever from the
seller:Provided that the price of notified Horticulture produce in the private yards shall be settled in
the manner as may be prescribed.(3)Weighment or measurement or counting of all the notified
Horticulture produce so purchased shall be done by such person and in such manner as may be
provided in the bye-laws.Chapter - IV Establishment, Constitution. Powers and Functions of The
Committee In Districts
29. Establishment of the Committee in district.
(1)The State Government shall notify, establish a Horticulture produce market Committee for every
notified market area and shall specify its headquarter.(2)Every Committee established under (sic)
(1) shall be a body corporate, (sic) succession and a common (sic) and be sued in its corporate (sic)
the provisions of section 7 (sic) acquire and hold property both movable and immovable and to
cease. sell or otherwise transfer any such property which may have become vested in, or been
acquired by it, and to contract and to do ail other things necessary for the purposes for which it is
established:Provided that no Committee shall permanently transfer any immovable property except
in pursuance of a resolution passed at a meeting convened specify for the purpose by a majority of
not less than three-forth of the members of the Committee and with the prior approval of the Board.
30. Constitution of the Committee in Districts.
(1)The District Committee shall consist of the following members of whom 8 (eight) shall be
ex-officio members and two non-official members.(2)Ex-officio members(i)Deputy
Commissioner/ADC - Chairman;(ii)DHO/District Marketing Officer-Vice-
Chairman(iii)DAO(iv)DVO(v)ARCS(vi)DFDO.(vii)SDHOs shall function as Marketing
Manager-cum-Secretary/HDO Headquarter.(viii)Assistant Marketing Managers or HMOs(3)The
two non-official member shall be appointed by the State Government out of a panel of names duly
recommended by the Deputy Commissioner concerned to be filled in the manner provided
hereunderOne non-official member from the producers of the notified market area;Arunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

and(sic)non-official member from the traders (sic) under section 37 from the notified (sic) area.
31. Term of office of the member of the Committee.
(1)Subject to the provisions of section 33 every non- official member of the Committee shall hold
office at the pleasure of the State Government.(2)The term of an ex-officio member of the
Committee shall come to an end as soon as he cease to hold the office by virtue of which he was
nominated.
32. Disqualification of member of the Committee.
- No person shall be eligible to become a member of the Committee if he incurs any of the
disqualification specified under section 6 of this Act.
33. Removal of members of the Committee.
- The State Government may, at any time during the period of his office remove by notification, any
member, if such member has, in its opinion,been guilty of misconduct or neglect of duty or has lost
the qualification on the strength of which he was nominated:Provided that before the Board notifies
the removal of a member under this section, the reasons for his proposed removal shall be
communicated to the member concerned and he shall be given an opportunity of tendering an
explanation in writing:Provided further that any vacancy of the non-official members arising as a
result of death, resignation, retirement, transfer or removal shall be filled in as early as practicable.
34. Meeting of the Committee.
(1)Committee shall meet for the transaction of its business at least once in three months provided
that the Committee may in special circumstances meet at any time and at any place in the market
area.(2)The Chairman shall preside over meetings of the Committee and if he/she is absent, the
Vice-Chairman shall preside over the meeting of (sic) committee and if both are absent one (sic)
members present in the meeting as (sic) chosen by the members present (sic) Chairman.(3)Subject
to the provisions of this (sic) shall conduct its business as (sic)
35. Act of Committee not to be invalidated.
- No act of Committee or of any Sub-Committee thereof or of any person acting as a member,
Chairman, Vice Chairman, presiding Authority or Secretary of the Committee shall be deemed to be
invalid by reason only of some defect in the constitution or appointment of such Committee,
Sub-Committee, Members, Chairman, Vice-Chairman, presiding authority or Secretary of the
Committee or on the ground that they or any of them were disqualified for such office, or that formal
notice of the intention to hold meeting of the Committee or of the Sub-Committee was not given
duly or by reason of such act having been done during the period of any vacancy in the office of the
Chairman, Vice Chairman, or Secretary of the Committee or member of such Committee orArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

Sub-Committee or for any other infirmity not affecting the merits of the case.
36. Powers and functions of the Committee.
(1)Subject to the provisions of this Act, the Committee may(a)enforce the provisions of this Act, and
the rules and bye-laws made thereunder in the notified markets.(b)establish a market in the market
area and provide such facilities for persons visiting in connection with the purchase, sale, storage,
weighment and processing of horticultural produce concerned as the Board may, from time to time
direct.(c)do such other act as may be required in the relation to the superintendence, direction and
control of market or for regulating marketing of horticultural produce in any place in the market
area and for the purposes connected with the matters aforesaid, and for that purpose may exercise
such powers provided under this Act; and(d)do all such other acts which may bring complete
transparency in the pricing system and transaction taking place in the market area.(2)Without
prejudice to the generality of the foregoing provisions, the Committee may:-(i)Maintain and manage
the market yards and sub-yard market yards within the market area.(ii)Provide necessary facilities
for the marketing and facilities for the transportation of horticultural produce within the market
yards and sub-market yards and outside the yards and within the sub-market yards and outside sub-
market yards in the market area.(iii)Regulate, conduct or supervise the auction of notified
Horticultural produce in accordance with the provision and procedure laid down under the rules
made under this Act or bye-laws of the Committee.(iv)Regulate the making, carrying out and
enforcement or cancellation of agreements of sales weighment, delivery, payment and all other
matters relating to the market of notified Horticultural produce in the manner prescribed.(v)Provide
for the settlement of all disputes between the seller and the buyer arising out on any kind of
transaction Horticultural produce and all matters ancillary thereof.(vi)Take all possible steps to
prevent adulteration of notified Horticulture produce.(vii)Make registration for weighmen and
labour for weighing and transporting of goods in respect of transactions held in the market yard or
sub-yards(viii)Set up and promote public-private partnership in management of the
markets.(ix)Promote public -private partnership for carrying out extension activities in its area viz,
collection, maintenance and dissemination of information in respect of production, sale, storage,
processing, prices and movement of notified Horticulture produce.(x)Levy, take, recover and receive
rates, charges, fees and other sums of money to which the Committee is entitled.(xi)Regulate the
entry of persons and vehicles, traffic into the market yard and sub-market yard visiting the
market.(xii)Compound offences committed under this Act (except section 27) or rules and bye-laws
made thereunder.(xiii)Acquire land and dispose off any movable or immovable property for the
purpose of efficiently carrying out its duties.(xiv)Institute or defend any suit., prosecution, action,
proceeding, application or arbitration and compromise such suit, action, proceeding, application or
arbitration.(xv)Keep a set of standard weights and measures in each principal market yard and
sub-market yard against which weighment and measurement may be checked.(xvi)Inspect and
verify scales, weight and measures in use in a market area and also the books of accounts and other
documents maintained by the market functionaries in such form and in such manner as may be
prescribed.(xvii)Arrange to obtain fitness (health) certificates from which are bought or sold in the
market yard or market area.(xviii)Carry out publicity about the benefits of regulation, the system of
transaction, facilities provided in the market yard etc; through various means such as poster,
pamphlets, hoardings, cinema slides, film shows, group meetings, electronic media etc; or throughArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

any other means considered more effective or necessary.(xix)Ensure payment in respect of
transaction which take place in the market yard to be made on same day to the seller, and in default
to seize the Horticultural produce in question alongwith other property of the person concerned and
to arrange for re-sale thereof and in the event of loss, to recover with charges for recovery of the
losses, if any, from the original buyer and effect payment of the price of the Horticulture produce to
the seller.(xx)Recover the charges in respect of weigh men and distribute the same to the weighmen
and labour if not paid by the purchaser or seller, as the case may be.(xxi)Collect and maintain
information in respect of production, sale, storage, processing prices and movement of notified
Horticulture produce and disseminate such information as may be directed by the Board.(xxii)With
a view to maintain stability in the market, take suitable measures to ensure that traders do not buy
Horticultural produce beyond their capacity and avoid risk to the sellers in disposing off the
produce, and grant licenses only after obtaining necessary security in cash as bank guarantee
according to the capacity of the buyers; and(xxiii)Promote and undertake Horticulture processing
including activity for value addition in Horticultural produce.(3)With the prior sanction of the
Board, the Committee may undertake the following functions(i)Construction of roads, godowns,
rope ways and other infrastructure in the market area to facilitate marketing of Horticultural
produce and for the purpose give funds by the Board.(ii)To provide on rent storage facilities for
stocking of Horticulture produce to Horticultural producers.(iii)To promote and encourage
e-trading, system, create infrastructure and undertake other activities and steps needed
thereof.(iv)To maintain and circulate from time to time the data of arrivals and rates of Horticulture
produces standard-wise brought into the market area for sale as may be prescribed.
37. Registration of market functionaries.
(1)Every person who, in respect of notified Horticulture produce, desires to operate in the market
area as trader, commission agent, weigh men, labour, surveyor, ware housemen, contract farming
buyer, owner or occupier of processing factory or any other market functionaries, shall apply to the
Secretary of registration in such manner and within such period as may be prescribed. The Secretary
of the Committee shall be the authority to grant registration certificate with the prior approval of the
Committee.Provided that any person may buy Horticultural produce in the market yard/sib-market
yard on day to day basis even without getting registered.Provided further that any person who
desires to trade or transact or deal in any notified Horticultural produce in more than one market
area, shall get registered, for respective function from the Secretary of the Board.(2)No broker,
trader, weigh men, surveyor, godown keeper or other functionaries shall, unless duly registered,
carry on his occupation in a notified market area in respect of the notified Horticultural produce
under this Act.(3)Every application for such registration shall be accompanied with such fee as may
be prescribed.(4)The Committee may register or renew the registration or refuse registration or
renewal of the registration or cancel the registration on any of the following grounds(i)If the
applicant is a minor.(ii)If the applicant has been declared defaulter; or(iii)If the applicant has been
found guilty under this Act, the rules and bye-laws made thereunder.Arunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

38. Appointment of Secretary of the Committee.
(1)Every Committee shall have a Secretary who shall be appointed by the State Government in
accordance with the recruitment and promotion rules as may be prescribed.(2)The Secretary of the
Committee shall be the ex-officio Secretary of the Committee and shall be custodian of all the
records and properties of the Committee.
39. Appointment of Sub-Committee and delegation of powers.
- The Committee may appoint a Sub-Committee for the conduct of any work or to report on any
matter and may delegate to such sub-committee such of its powers or duties as it think fit.
40. Powers and duties of the Secretary of Committee.
- The Secretary of the Committee shall exercise and perform following powers and duties in addition
to such other powers and duties as may be specified in this Act, or the rules or bye-laws made
thereunder, namely:-(i)To convene the meetings of the Committee and the Sub-Committees, if any,
and maintain minutes of the meetings thereof.(ii)To attend the meetings of the Committee and
Sub-Committee and take part in the discussion.(iii)To take steps to give effect to the resolution of
the Committee and of the Sub-Committee and report all actions taken in pursuance of such
resolution to the Committee in the next meeting.(iv)To prepare the annual budget proposal of the
Committee.(v)To furnish to the Committee such returns, statement, estimates, statistics and reports
as the Committee may from time to time, require including following information(a)The fines and
penalties imposed on and any disciplinary action taken against the members or the staff and the
market functionaries and others.(b)Over trading by traders.(c)Regarding contravention of the Act,
the rules, the bye-laws or the standing orders, if any, by any person.(d)Regarding the suspension or
cancellation of licence by the Managing Director of the Board.(e)Regarding the administration of the
Committee and the regulation of the marketing.(vi)Produce before the Committee books, registers
and other documents as may be necessary for the transaction of the business of the Committee or
the Sub-Committee, and also whenever called upon by the Committee to do so.(vii)Exercise
supervision and control over the acts of all officers and servants of the Committee.(viii)Collect fees
and other money leviable by or due to the Committee.(ix)Be responsible for all money credited to or
received on behalf of the Committee.(x)Make disbursement of ail money lawfully payable by the
Committee.(xi)Operate, Maintain and transact the Committee fund.(xii)Report to the Managing
Director of the Board, as soon as possible, in respect of fraud, embezzlement, theft or shortage of
Committee fund or property; and(xiii)Prefer complaints in respect of prosecutions to be launched
on behalf of the Committee and conduct proceedings, Civil or criminal on behalf of the
Committee.Chapter - V Finance, Accounts and Audit of The Board and The Committee
41. Levy of market Fee.
- Every Committee shall levy, charge and collect market fee in the manner as may be prescribed on
basis at the rate not exceeding two rupees for every one hundred rupees as may be fixed by the StateArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

Government.(i)On the sale or purchase of notified Horticultural produce, whether brought from
within the State or from outside the State into the market area; and(ii)On the notified Horticulture
produce whether brought from within the State or from outside the State into the market area for
processing.
42. Single Point levy.
(1)Market fee specified in section 41 shall not be levied for the second time in any market area
within the State provided that market fee has already been paid on the Horticultural produce in any
market area of the State and the information to this context has to be furnished by the concerned
person that the payment of market fee has already been paid in other market of the State on
demand.(2)On the Horticulture produce brought in the market area for commercial transaction or
for processing, the market fee shall be deposited by the buyer or processor, as the case may be. in
the office of the Committee, within fourteen days but before sale or resale or processing or export
outside the market area of such Horticultural produce.(3)In case any notified Horticulture produce
is found to have been processed, sold, or resold or dispatched outside the market area without
payment of market fee payable on such produce, the market fees shall be levied and recovered five
time the market value of the processed produce or value of the Horticulture produce, as the case
may be.
43. Marketing Development Fund/corpus fund.
(1)All money received by or on behalf of the Board shall be credited into a fund to be called the
Marketing Development Fund. The account shall be operated in the Joint Signatures of the
Chairman of the Board, Managing Director-cum- Member Secretary and Finance & Account Officer
of the Board in State level. The fund shall be deposited in any nationalized bank.(2)All payments
made by the Board shall be defrayed out of the said fund.(3)The Board may for carrying out the
provisions of this Act, borrow money from the State Government or may borrow with the previous
approval of the State Government(i)From any other agency; or(ii)Issue debentures on the authority
of any property vested in it or on the security of a part of its future income accruing to it under this
Act, or the rules made thereunder.(4)The Marketing Development/Corpus Fund shall be utilized by
the Board either or its own or through public-private partnership for the discharge of functions
entrusted to the Board under this Act. Without prejudice to generality of this provision, the
Marketing Development Fund may be utilized for the following purposes:-(i)Payment of
administrative expenditure of the Board.(ii)Travelling and other allowance to the employees of the
Board. Chairman and its members.(iii)Payment of wages/salaries of contingencies staff.(iv)Meeting
any legal expenses incurred by the Board.(v)Giving aid to financially week Committees in the shape
of loans and grants on the term and conditions as may be prescribed Propaganda and publicity on
matters relating to marketing of Horticulture produce.(vi)Training of the and staff of the
Committees and Board and also to Horticulturists.(vii)Meeting expenditure in marketing extension
activities and e-trading.(viii)Organizing and arranging workshops, seminars, exhibitions, etc; on
development of marketing.(ix)Maintenance of the office of the Board and construction and repair of
its office buildings, rest house, and staff quarters.(x)General improvement of the regulation of
marketing in the State.(xi)Loans and advances to the employees.(xii)Expenses incurred in auditingArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

the accounts of the board.(xiii)Providing technical and administrative assistance to the Committee,
including execution of works.(xiv)Market survey and research, grading and standardization, quality
certification of horticulture produce and other allied subjects.(xv)Grading and standardization of
Horticultural produce.(xvi)Collection and dissemination of market rates and news.(xvii)Better
marketing of Horticultural produce; and(xviii)With the previous sanction of the State Government,
any other purpose which is calculated to promote the general interest of the Board, Committees or
national or public interest.
44. Annual budget of the Board.
(1)An estimate of the annual income and expenditure of the Board for the ensuing year shall be
prepared by the Board and submitted for sanction to the State Government not later than first week
of February each year. On the sanction of the budget by the State Government, the Board shall have
power to operate upon it.(2)The State Government shall sanction and return the budget as soon as
practicable, enabling the Board to operate the fund within two months.
45. Accounts, Audit and Annual Report of the Board.
(1)The Board shall prepare once in every year, in such form and at such time as may be prescribed,
an annual report, giving a true and full account of its activities during the previous year, and shall
forward a copy thereof to the State Government.(2)The accounts of the Board shall be audited
annually by the Examiner of the Local Audit Department or by such other person as the State
Government may direct.(3)As soon as the accounts of the Board are audited the Board shall send a
copy of the audit, report to the State Government.
46. Committee Fund.
(1)Save as provided in sub-section (2) all moneys received by a Committee shall be paid into a fund
to be called the "Committee Fund" and all expenditure incurred by the Committee under or for the
purposes of this Act shall be defrayed out of the said fund. Any surplus remaining with the
Committee after such expenditure has been met, shall be invested in such manner as may be
prescribed.(2)Any money received by the Committee by way of arbitration fee or as security for costs
in arbitration proceedings relating to disputes or any money received by the Committee by way of
security deposit, contribution to provident fund or for payment in respect of any notified
Horticulture produce, or other charges payable by the Committee or such other money received by
the Committee as may be provided in the rules or bye- laws, shall not form part of Committee Fund,
and shall be kept in such manner as may be prescribed.(3)Every Committee, out of its fund, shall
pay to the Board, fifty per-cent of the total market fee collected under section 41 during the year, to
meet the expenses of establishment of the Board and expenses incurred in execution of the functions
assigned to the Board under this Act.(4)All money and receipts specified in this section and forming
part of the fund of the Committee shall be deposited in any Nationalized Bank or any other Bank
having National Computerized Network. The account shall be operated in the Joint signatures of
Chairman, Vice Chairman and member secretary in District level. The Secretary of the Committee
shall be the Head of office and shall exercise such financial powers as have been conferred under theArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

Financial Rules of the State Government on the Head of office.
47. Preparation and sanction of budget of Committee.
(1)Every Committee shall prepare and pass the budget of its income and expenditure for the ensuing
year In such manner and in such form and within such period as may be prescribed and shall submit
it to the Managing Director of the Board and the Managing Director shall place the same before the
Board for approval. The board shall approve the budget with or without modification within two
months from the date of receipt thereof. If the budget is not returned by the Managing Director
within two months, it shall be deemed to have been approved.(2)A Committee at any time during
the year for which any budget has been sanctioned, cause a revised or supplementary budget to be
passed and sanction in the same manner as if it were an original budget.(3)No expenditure shall be
incurred by a Committee on any item if there is no provision in the sanctioned budget thereof unless
it can be met by re-appropriation from saving under any other head. The sanction for
re-appropriation may be obtained from the Board. Provided that in case of re-appropriation from
minor heads under one major head, sanction for re-appropriation shall not be required.
48. Purpose for which the Committee fund may be expended.
- Subject to the provisions of section 46, the Committee in order to discharge functions and duties
entrusted to it under this Act, may use the Committee Fund. Without prejudice to generality of this
provision the Committee fund may be used for the following purposed, namely:-(i)The acquisition of
a site or sites for the market.(ii)The establishment, maintenance and improvement of the market
yard.(iii)The convenience and repairs of buildings necessary for the purpose of the market yard and
for convenience or safety of the persons using the market yard.(iv)The maintenance of standard
weights and measures.(v)The meeting of establishment charges including payments and
contributions towards provident fund, pension and gratuity of the officers and servants etc. of the
Committee.(vi)Loans and advances to the employees of the committee.(vii)The payment of interest
on the loans that may be raised for the purpose of the market and provisions of sinking fund in
respect of such loans.(viii)The collection and dissemination of information relating to the
Horticultural produce.(ix)The expenses incurred in auditing the accounts of the Committee and
expenses incurred in the maintenance of the offices.(x)Payment of honorarium and travelling
allowance to the Chairman and other non-employees of the committee and employees of the
committee as may be prescribed.(xi)Contribution to Marketing Development Fund.(xii)Contribution
to any scheme for development of Horticultural marketing including transport.(xiii)For providing
facilities like grading, standardization, and quality certification services and communication to
Horticulturist in the market area.(xiv)Incurring expenses on research and development, extension
and training to farmers in marketing of Horticultural produce.(xv)Prevention, in conjunction with
other Agencies, State, Central, and others of distress sale of Horticultural produce.(xvi)Fostering
cooperative marketing and assisting cooperative marketing societies in the procurement and
profitable disposal of produce particularly the produce belonging to small and marginal
farmers.(xvii)Create and promote on its own or through public- private partnership infrastructure
and post harvest handling of Horticulture produce, cold storage's, proceeding facilities, pack houses
and all such infrastructure to develop modern market system.(xviii)Meeting any legal expensesArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

incurred by the committee.(xix)On the training and skill enhancement of staff of the committee;
and(xx)With the previous sanction of the board, any other purpose which is calculated to promote
the general interests of the committee or the notified market area or any other purpose calculated to
promote the national interest.
49. Power to borrow.
(1)The committee may, with the previous sanction of the board, raise the money required for
carrying on the purposes for which it is established on the security of any property vested in and
belonging to the committee and of any fees leviable by the committee under this Act.(2)The
Committee may, for the purpose of meeting the initial expenditure on lands, building, and
equipments required for establishment of the market, obtain loan from the State Government or the
Board or other committee or financial institution on such conditions, as may be prescribed.Chapter
- VI Control
50. Inspection of Markets and enquiry into the affairs of the Committee.
(1)The Managing Director of the Board may(a)Inspect or cause to be inspected the accounts and
offices of the committee.(b)Hold inquiry into the affairs of a committee.(c)Call from a committees
return, statement, accounts or reports which he may think fit to require such committee to
furnish.(d)Require the committee to take into consideration(i)Any objection on the ground of
illegality, inexpediency, impropriety which appears to him to exist to the doing of anything which is
about to be done or is being done by or on behalf of such committee; or(ii)Any information he is
able to furnish and which appears to him to necessitate the doing of a certain thing by such
committee.(2)When the affairs of a market are investigated under this section or the proceedings of
any committee are examined by the Managing Director of the Board under section 52, the
Chairman, Secretary and all other officers and servants and members of such committee shall
furnish such information in their possession in regard to the affairs or proceedings of the committee
as the Managing Director of the Board or other officer authorized, as the case may be, may
require.(3)An officer investigating the affairs of a committee under sub-section (1) or the State
Government examining the proceedings of any committee under section 51 shall have the power to
summon and enforce the attendance of officers or members of the committee and to compel them to
give evidence and to produce documents by the same means and as far as possible in the same
manner as is provided in the case of a Civil Court by the Code of Civil Procedure, 1908. Where the
Managing Director of the board has reason to believe that the books and records of a committee are
likely to be tempered with or destroyed or the funds or property of a committee are likely to be
misappropriated or misapplied, the Managing Director of the Board may issue orders directing a
person duly authorized by him in writing to seize and take possession of such books and records,
funds and property of the committee and the officer or officers of the committee responsible for the
custody of such books, records, funds, and property shall give delivery thereof to the person so
authorized.Arunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

51. Power to Call for proceedings of committee or Board.
(1)The Managing Director of the Board or the State Government as the case may be, may on its own
motion or, on an application made to it, call for and examine the proceedings of any committee or of
the Board, as the case any may be, for the purpose of satisfying itself as to the legality or propriety of
any decision taken or order passed and as to the regularity of the proceedings of the committee or
the Board, as the case may be. If any case, it appears to the Managing Director of the Board or the
State Government that any such decision or order or proceedings so called for should be modified,
annulled, reversed, or remitted for reconsideration it may pass such order thereon as it may deem
fit.Provided that every application to the Managing Director of the Board or the State Government,
as the case may be, shall be preferred within sixty days from the date of such decision or order to the
Communication of applicant.Provided further that no such order shall be passed under sub-section
(1) without giving a reasonable opportunity of being heard to the parties affected thereby.(2)The
Managing Director of the Board or the State Government, as the case may be, may suspend the
execution of the decision taken or order passed by the Committee or the Board, as the case may be,
pending the exercise of its powers under sub-section (1).
52. Power to Prohibit execution or further execution of resolution passed or
order made by the committee.
- The Managing Director of the Board may, on its own motion, or on report or compliant received,
by order prohibit the execution or further execution of a resolution passed or order made by the
committee or its Chairman or any of its officers or servants, if he is of the opinion that such
resolution or order is prejudicial to the public interest, or is likely to affect efficient running of the
business in any market area, principal market yards or sub-market yards or is against the provisions
of this Act or the rules or bye-laws made thereunder.
53. Liability of Chairman, Members and employees for loss, wastes or
misappropriation etc.
(1)If in the course of enquiry of inspection under section 50 or in the course of audit under this Act,
it is found that any person who is or was entrusted with the management of the Board or the
committee, as the member or any other officer or employee of the Board or the committee or an
officer of the State Government has made or directed by assenting or concurring or participating in
any affirmative vote or proceeding related thereto, any payment or application of any money or
other property belonging to, or under the control of such committee to any purpose contrary to the
provisions of this Act, rules or bye-laws made thereunder or has caused any deficiency or loss by
gross negligence or misconduct or has misappropriated or fraudulently retained any money or other
property belonging to the Board or the committee, the Secretary of the Board may, on his own
motion or on an application, inquire himself or direct any officer subordinate to him duly authorized
by him by an order in writing in this behalf to inquire into the conduct of such person.(2)If on
enquiry made under sub-section (1), the Managing Director of the Board is satisfied that there are
good grounds for an order under this sub-section, he may make an order requiring such person, orArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

in the case of a deceased person, his legal representative who inherits his estate, to repay or restore
the money or property and any part thereof, with interest at such rate, or to pay contribution and
costs or compensation to such extend as the Managing Director of the Board may consider just and
equitable.Provided that no order under this sub-section shall be made unless the person concerned
has been given a reasonable opportunity of being heard in the matter.Provided further that the
liability of a legal representative of the deceased shall be to the extend of the property of the
deceased which is inherited by such legal representative.(3)Any person aggrieved by an order made
under sub-section (2) may, within thirty days from the date of communication of the order to him,
appeal to the State Government and the order of the State Government shall be final and
conclusive:Provided that in computing the period of limitation the time required for obtaining a
copy of the order of appealed against shall be excluded.(4)Any order made under sub-section (2) or
sub-section (3) shall, be enforced in a manner as if it were a decree of civil court having local
jurisdiction and any sum directed to be paid by such order may be recovered as arrears of land
revenue.(5)If the Secretary of the Board is satisfied on affidavit, enquiry or otherwise that any
person with intention to delay or obstruct the enforcement of any order that may be passed against
him under this section is about to dispose of the whole or any part of his property, or is about to
remove the whole or any part of his property from the State, he may, unless adequate security is
furnished, direct, the conditional attachments of the said property or such part thereof as he thinks
necessary and such attachment shall have the same effect as an order a competent civil court.
54. Members, Officers and Officials of the Board and Committee to be public
servants.
- All members, officers and servants of the Board and the committee shall be deemed to be public
servant within the meaning of section 21 of the Indian Penal Code 1860,
55. Prohibition of trade Allowances.
- No trade allowance or deduction, other than as prescribed by or under this Act or rules or bye-laws
made thereunder, shall be made or received by any person in any market area in any transaction in
respect of the notified Horticulture produce.
56. Power to order production of accounts, entry, inspection and seizure.
(1)The Secretary of the Committee or any officer of the State Government or the Board, empowered
by the State Government in this behalf may, for the purposes of this Act, require any person carrying
on business in any kind of notified Horticultural produce to produce before him the accounts and
other documents and to furnish any information relating to stocks of such Horticultural produce or
purchase, sale, processing, value addition and delivery of such Horticulture produce by such person
and also to furnish any other information relating to payment of market fee by such person.(2)All
accounts and registers maintained by any person in the ordinary course of business of any notified
Horticultural produce and documents relating to stocks or such Horticultural produce or purchase,
sale, processing, value addition of such Horticultural produce in his possession and offices,Arunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

establishment, godown's, vessels or vehicles of such persons shall be kept open for inspection at all
reasonable time by such officers of the State Government, the Board or the committee as may be
authorized by the State Government in this behalf.(3)If any officer has reasons to suspect that any
person is attempting to evade the payment of any market fee due from him under this Act or that
any person has purchased, sold, processed of value added any notified horticultural produce in
contravention of any of the provisions of this Act or rules or the bye-laws in force in the market
areas, he/she may communicate in writing to such person, seize such accounts, registers, and
documents of such person, as may be necessary and shall grant a receipt for the same and shall
retain the same only so long as it may be necessary for examination therefore or for a
prosecution.(4)For the purposes of sub-section (2) or (3) such officer may enter or search any place
of business, office, establishment, godown, vessel or vehicle where such officer has reason to believe
that such person keeps or for the time being has kept accounts, registers of documents of his/her
business, or stock of notified horticultural produce relating to this business.(5)The provisions of
section 100 (4) to (8) of the Code of Criminal Procedure, 1973 shall, so far as may be, apply to a
search under sub- section (4).(6)Where any books of accounts or other documents are seized from
any place and there are such entries therein making reference to quantity, quotations, rates, receipts
or payment of money or sale or purchase of goods, such books of accounts or other documents shall
be admitted in evidence without witness having to appear to prove the same, and such entries shall
be prima-facie evidence of matters, transactions and accounts purported to have been recorded
therein.
57. Submission of annual accounts by license and registered functionaries
and assessment.
(1)Every trader, processor, proprietor of a private yard, proprietor of consumer farmer market or
Commission agent, carrying on business of notified Horticultural produce shall, before the 30th
June, every year submit to the Secretary of the Committee a statement of transaction undertaken by
or through him during the previous financial years ending on the 31st March, in such form and in
such manner as may be the prescribed.(2)The Secretary of the Committee shall accept or reject the
statement submitted to him under sub-section (1) after necessary examination and verification on
the basis of information duly available with the Committee and shall assess the balance amount
payable by the functionary and levy the assessed amount.(3)Any person aggrieved by the proceeding
of the Secretary of the Committee may, within thirty days from the date of Communication of notice
to him. appeal to the Committee,(4)Any officer authorized by the Board may, on his own motion or
on application made to the Board start process of re-verification of the statement verified by the
Secretary of the Committee within two months from the date of verification and for this purpose
such officer shall exercise the powers under section 59; and the re-verification made by such officer
shall be final.
58. Assessment of Market fee.
(1)If any person required to produce accounts or furnish information under sub-section (1) of
section 57, fails to produce such accounts or information or knowingly furnishes incomplete or
incorrect accounts of the business of the notified Horticultural produce, the Secretary of theArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

Committee, on his own motion, shall assess such person for fee levied under section 41 on the basis
of information available with the committee.
59. Power to stop Vehicles.
(1)At any time when so required, any officer of the Board empowered by the board or any officer of
the Committee empowered by the Committee in this behalf, as the case may be, may direct the
driver or any other person in charge of the vehicle, vessel or other conveyance and inspect all
records relating to notified Horticultural produce carried, and give his name, address and name and
address of owner of the vehicle, vessel or other conveyance and name and address of the owner of
the notified Horticultural produce carried in such vehicle, vessel or other conveyance.(2)Persons
empowered under sub-section (1) may seize any notified Horticultural produce brought into or
taken out or proposed to be taken out of the market area in any vehicle, vessel or other conveyance,
if he has reason to believe that any fee or other amount due under this Act or the value payable to
the seller in respect of such Horticultural produce has not been paid.(3)if any person empowered
under sub-section (1) has reason to suspect that any person is attempting to evade the payment of
any market fee due from him under section 41 or that any person has purchase or stored any
notified Horticultural produce in contravention of any of the provisions of this Act or the rules or the
bye-laws made thereunder in the market area, he may enter and search any place of business,
warehouse, office, establishment or godown where the person empowered under sub-section (1) has
reason to believe that such person keeps or has for the time being kept stock of notified
Horticultural produce and may seize the notified Horticultural produce and such seized notified
Horticultural produce may be confiscated in favour of the market committee in accordance with the
provisions of the code of Criminal Procedure, 1973.(4)The provisions of section 100, 457, 458 and
459 of the Code of Criminal Procedure, 1973 (No. 2 of 1974) shall apply to entry, search and seizure
under sub-section (1), (2) and (3) as they apply in relation to the entry, search and seizure of
property by the police officer. Such seizure shall forthwith be reported by the person aforesaid to a
Magistrate having jurisdiction to try the offence under this Act.
60. Power to remove encroachments in market yard.
(1)Any officer or servant of the Committee or the Board empowered by the State Government, by
notification, in this behalf shall have the power to remove any encroachment over the property
owned by the Board/or the Committee including the market yard, and the expenses of such removal
shall be paid by the encroacher, if he fails to pay such expenses, the same shall be recovered in the
same manner as arrears of land revenue.(2)All Police Officers shall be bound to assist the officers
empowered under sub-section (1), when required, in the performance of their duties under this Act,
and for that purpose, shall have the same powers which they have in the discharge of their ordinary
police duties.(3)If any officer or servant of the Board or the committee empowered under
sub-section (1) fails to remove the encroachment within the market yard, he shall be punished with
simple imprisonment for fifteen days or with fine which may extend to one thousand rupees or with
both.Arunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

61. Power to grant exemption from market fees.
(1)The State Government may, by notification and subject to such conditions and restrictions, as
may be specified therein, exempt in whole or in part any Horticultural produce brought for sale or
bought or sold in the payment of market fee for such period as may be specified therein.(2)Any
notification issued under sub-section (1) may be rescinded before the expiry of the period specified
therein and on rescission, such notification shall cease to be in force.
62. Power to write off irrecoverable fee etc.
- Whenever it is found that any amount due to the Board or a committee is irrecoverable or should
be remitted, or whenever any loss of the Board's or a committee's money or stores or other
properties occur through fraud or negligence of any person for any other cause and such property or
money is found to be irrecoverable, the facts shall be reported to the Board or the committee, as the
case may be, and the board, with the approval of the State Government, and the committee, with the
approval of the board, may order the amount or value of the property to be written off as loss
irrecoverable or remitted, as the case may beProvided that in case of a committee, if in any case the
amount due or the value of such property is in excess of five thousand rupees, such order shall not
take effect without the approval of the State Government.
63. Recovery of Sums due to the Board or the committee.
- Any sum due to the Board or the Committee from any person on account of any charges, costs,
expenses, fees, rent and any other account under the provisions of this Act or any rules or bye-laws
made thereunder shall be recoverable as arrear of land revenue
64. Redressal of dispute between Private Market or Consumer Market and
Committee.
- Any dispute between the private market or consumer market and committee, shall be referred to
the Secretary of the Board or any other officer authorized by the State Government in this behalf and
shall be resolved after giving both the parties a reasonable opportunity of being heard.Provided that
the decision of the authority under this Election shall be final.
65. Appeal.
(1)Any person aggrieved by an order passed under section 25, 26, or 37 may prefer an appeal, in
such form and in such manner as may be prescribed, to(a)The Committee, where such order is
passed by the Secretary of the Committee with in thirty days from the date of order;(b)The Board,
where such order is passed by the committee of the Board within thirty days from the date of order;
and(c)The State Government, where such order is passed by the Managing Director of the Board or
by the Board, within thirty days from the date of such order.(2)The Appellate Authority, if it
considers necessary so to do grant stay of the order appealed against for such period as it may deemArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

fit.(3)The order passed by the State Government under this section shall be final.
66. Bar to civil suit and Protection to person acting in good faith.
- No suit, prosecution or legal proceedings shall lie in respect of anything done in good faith or
intended to be done under this Act or rule or bye-laws made thereunder, against the officer of the
State Government or against the Board or any committee or against any person acting under the
directions of such Board, Committee or any officer or servant of State Government Board or
Committee.
67. Bar to suit in absence of notice.
- Notwithstanding anything contained in this Act, no suit shall be instituted against the Board or any
Committee, until the expiration of two months next after notice in writing stating the cause of
action, name and place of abode of the intending plaintiff, and the relief which he claims has been
delivered or left at its office. Every such suit shall be dismissed unless it is instituted within six
months from the date of the accrual of alleged cause of action.
68. Power of the State Government to amend the Schedule.
(1)The State Government may, by notification, add to or delete therefrom any of the Horticultural
produce specified under column-2 in the SCHEDULE and thereupon the said SCHEDULE shall
stand amended accordingly.(2)Every notification issued under sub-section (1) shall, as soon as may
be, after it is issued, be laid on the table of the Legislative Assembly.Chapter - VII Penalty
69. Penalty for contravention of Act, Rules and Bye-laws.
- Any person who contravenes any of the provisions of this Act, of any rule or bye-laws or order
issued thereunder or fails to perform the duties assigned under this Act shall, on conviction, be
punished with simply imprisonment which may extend to three months or with months or with fine
which may extend to one thousand rupees or with both.Provided that in the case of a continuing
contravention, he shall be liable to be punished with a further fine which may extend to fifty rupees
for every day during which the contravention is continued after the first conviction.
70. Recovery of Market dues.
- Whenever any person is convicted of any offence punishable under this Act, the Magistrate shall in
addition to any fine which may be imposed, recover summarily and pay over to the Board or the
Committee, as the case may be, the amount of fee or any other amount due from him under this Act
or rules or bye-laws made thereunder and may, recover and pay over to the Board or committee, as
the case may be, costs of the prosecution.Arunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

71. Cognizance of offences.
- No court inferior to that of a Magistrate of the first class shall take cognizance of any offence
punishable under this Act or rule or Bye-laws made thereunder except on a compliant made by the
Managing Director of the Board or by the Secretary of the Committee or, by any other person duly
authorized by the Board or the Committee in this behalf.
72. Power to Compound offences.
(1)The committee may accept, from any person who has committed or is reasonably suspected of
having committed an offence under this Act (other than contravention of section 27 of this Act), or
the rules or bye-laws, by compounding of such offence:(a)Where the offence consists of the failure to
pay or the evasion of any fee, or other amount recoverable under this Act or the rules or the bye-laws
made thereunder in addition to the fee or other amounts so recoverable, a sum of money not less
than the amount of the fee or other amount and not more than five times the amount of fee or other
amount; and(b)In other cases a sum of money not exceeding five thousand rupees.(2)On the
compounding of any offences under sub-section (1), no proceeding shall be taken or continued
against the person concerned in respect of such an offence, and if any proceedings in respect of that
offence have already been instituted against him in any court, the compounding shall have effect of
his acquittal.Chapter - VIII Miscellaneous
73. Mode of making Contract.
(1)Subject to the provisions of this Act, no contract or agreement on behalf of the Committee for the
purchase, sale, lease, mortgage or other transfer of, or acquisition of interest in immovable property
shall be executed except with the previous sanction of the Committee.(2)Save as provided in
sub-section (1)(a)Secretary of the Committee may execute contract or agreement on behalf of the
Committee where the amount or value of such contract or agreement does not exceed rupees five
thousand regarding matters in respect of which he is generally or specifically authorized to do so by
a resolution of the Committee.(b)The Chairman and the Secretary of the Committee may jointly
execute a contract or an agreement on behalf of the committee when the amount or value of such
contract or agreement does not exceed rupees twenty thousand.(c)In any case other than those
referred to in clauses (a) and (b), a contract or agreement on behalf of the Committee may be
executed by the Chairman, Secretary and two other Members of the committee of whom one shall be
ex-officio member who have been generally or specially authorized by a resolution of the Committee
to do so.(3)Every contract entered into by the committee shall be in writing and shall be signed on
behalf of the committee by the person or persons authorized to do so under sub-section (2).(4)No
contract other than a contract executed under the provisions of sub-section (1), (2) or (3) shall be
binding on the committee.(5)Where a contract or agreement is entered into on behalf of a
Committee, the Secretary of the committee shall report the fact to the committee in its next meeting
held after the date of entering into such contract or agreement.Arunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

74. Acquisition of Land for the Board and Committee.
(1)When any land is required for the purposes of this Act, the State Government may, on the request
of the Board or a committee, as the case may be, requiring it, proceed to acquire land under the
provisions of the Land Acquisition Act or any other law for the time being enforce and on payment
by the Board or Committee, as the case may be, of the compensation awarded under that Act and of
all other charges incurred by the State Government on account of the acquisition, the land shall vest
in the Board or the Committee, as the case may be.(2)The board or a Committee shall be deemed to
be a local authority for the purposes of the Land Acquisition Act.
75. Supersession of the board and the Committee.
(1)When the State Government is of the opinion that the Board has failed in the performance of its
functions or discharge of its duties or has exceeded or abused the powers conferred on it by or under
this Act, it may, by notification published in the Official Gazette, supersede the Board.Provided that
no order of supersession shall be passed unless the State Government has afforded reasonable
opportunity to the Board by showcase and seeking a written explanation in respect of the allegations
against it.(2)Where the State Government is of the opinion that a committee has failed in the
performance of its functions or discharge of its duties or has exceeded or abused the powers
conferred on it by or under this Act, it may, by notification in the official Gazette, supersede the
Committee.Provided that no order of supersession shall be passed unless the State Government has
afforded reasonable opportunity to the Committee by showcase and seeking a written explanation in
respect of the allegations against it.(3)Upon publication of the notification superseding a Committee
under sub-section (2), ail the members including the Chairman shall, cease to hold the office, and
the State Government shall take steps to constitute a new Committee under section 30 and till such
time a new Committee is constituted, the Board shall make such arrangement for carrying out the
functions of the Committee as it may deem fit for the period not exceeding six months and may, for
that purpose, direct that all the functions, powers and duties of the Committee and its Chairman,
under this Act, shall be performed, exercised and discharged by such person or authority as the
Board may appoint in this behalf and such person or authority shall be deemed be the Committee or
the Chairman, as the case may be.
76. Reference to arbitrator in case of dispute.
(1)If any dispute arises out of any agreement or contract entered into, under the provisions of this
Act, rules or bye-laws made thereunder, between the sponsor and contract farming producer or
between the Board and the trader or between the committee and the trader, the same shall be
resolved through conciliation and arbitration.(2)The Arbitration and conciliation Act, 1996 (26 of
1996) shall apply to the conciliation and arbitration proceedings referred under sub-section
(1).(3)For the purpose the Arbitrator shall be appointed by the Board and the proceeding shall be
within the Jurisdiction of Itanagar and its decision shall be final and binding to the parties.Arunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

77. Power to make Rules.
(1)The State Government may after previous publication, make rules,consistent with this Act, for
carrying out all or any of the purpose of this Act.(2)In particular and without prejudice to the
generality of the foregoing power, such rules may provide Act «f(a)The quantity of Horticultural
produces for retail sale under section-2.(b)The sitting fee and allowances to be paid from the fund of
the Board to the Chairman and non-official members of the Board under section 10.(c)The
procedure and form for maintaining the accounts of the Board and audit thereof under sub-section
(2) (v) of section 11.(d)The duties and functions to be discharged by the Horticultural Produce
Marketing Standards Bureau for the promotion of grading, standardization and quality certification
of Horticultural produce under sub-section (2) (xii) of section 11.(e)The procedure to be followed in
exercise of supervision and control over officers and staff of the Board by the Secretary in the matter
of administration, accounts and records and disposal of all questions relating to the service of the
employees.(f)The powers and duties to be exercised and discharged by the Secretary of the Board
under section 12 (iii).(g)The procedure to be followed in maintaining records of the proceedings of
the meetings of the Board under section 12 (ix).(h)The development of infrastructure to establish
consumers or farmers markets and the procedure for the sale of Horticultural produce by the
producer direct to the consumer in the market area under section 23 (1).(i)The form of agreement
for contract farming and the manner in which a person shall enter into agreement with contract
farming producer under section 24.(j)The application for grant and renewal of license for
establishment of private yard, consumer and farmer market, the period for which the license is to be
issued, the form of licence and the conditions and the fee to be charged for grant of such licence
under section 25 (1).(k)The disqualifications for suspension/ cancellation of licence under section
26 (e).(i)The maximum quantity which can be sold by the producer direct to any person for
domestic consumption and the maximum quantity of the Horticultural produce purchase or sale of
which can be undertaken by petty trader under sub-section (2) of section 27.(m)The transparent
system to be followed for settlement of price of the notified Horticultural produce for sale into the
market yard under sub-section (2) of section 28.(n)The manner and procedure to be followed by the
Committee for the conduct of its business under sub-section (3) of section 34.(o)The procedure to be
followed by the Committee to regulate the making, carrying out and enforcement or cancellation of
agreements of sales weight men, delivery, payment and other matters relating to the market of
notified Horticultural produce under clause (iv) of sub-section (2) of section 36.(p)The form and the
manner and procedure to be followed for the maintaining of books of accounts and other documents
by the market functionaries under clause (xvi) of sub-section (2) section.(q)The procedure and the
manner to be followed for maintain and circulating the date of arrivals and rates of Horticultural
produce standard wise brought into the market area for sale under clause (iv) of sub-section (3) of
section 36.(r)The form of application for registration or renewal of registration, the form of
registration/certificate or renewal of registration certificate, the period within which application for
registration or renewal of registration is to be made and the fee for such registration or renewal of
registration under section 40 (1) (3).(s)The manner and the procedure to be followed by the
Committee for levy and collection of market fee under section 41.(t)The terms and conditions
subjects to which financial weak committees may be aided by granting loans and grants out of the
marketing development fund under clause (v) of sub-section (4) of section 43.(u)The form, time and
procedure to be followed in preparation of annual report by the board under sub-section (1) ofArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

section 48.(v)The manner in which the surplus remaining with the committee shall be invested
under sub-section (1) of section 46(w)The manner in which any money received by the committee by
way of arbitration fee, security for cost in arbitration proceeding, security deposit, contribution to
provident fund, payment in respect of any notified Horticultural produce, other charges payable by
the Committee or such other money received by the Committee under the rules or bye-laws, shall be
kept under sub-section (2) of section 46(x)The form, procedure and manner and the period within
which the Committee shall prepare and pass the budget and its income and expenditure for the
ensuing year under sub-section (1) of section 47.(y)The manner and procedure for payment of
honorarium and travelling allowance to the Chairman and other non-official members of the
Committee and to the employees of the Committee under clause (x) of section 48.(z)The conditions
subject to which the committee for the purpose for meeting the initial expenditure on lands,
buildings and equipments required of the establishment of market, may obtain loan from the State
Government or the board or other Committees or financial institutions under sub-section (2) of
section 49.(za)The form and the manner in which a statement of transaction shall be submitted to
the Secretary of the Committee for the previous financial year ending on 31st March under
sub-section (1) of section 57.(zb)The form and the manner in which an appeal may be filed under
sub-section (1) of section 65; and(zc)Any other matter which is to be or may be prescribed.(3)All
rules made under this Act, shall be laid, on soon as may be, after they are made, before the
Legislative Assembly, while it is in session, for a total period of fifteen days which may be comprised
in one session or in two successive sessions and, if before the expiry of the session in which they are
so laid or of the session immediately following, Assembly agrees in making any modifications in the
rules or Assembly decides that the rule should not be made, such rules shall have effect only in such
modified form or be of no effect, as the case may be. However, that any such modification or
annulment shall be without prejudice to the validity of anything done earlier under that rule.
78. Power to make Regulations.
(1)Subject to any rules made by the State Government under section 77. the Board may, in respect of
the notified market area, make bye- laws relating to(i)The regulation of business of the Market
Committee.(ii)The conditions of trading in market,(iii)The delegation of powers, duties and
functions to a sub-committee, if any.(iv)Enabling and regulating e-trading.(v)Any other matters for
which bye-laws are to be made under this Act or it may be necessary to frame bye-laws for effectively
implementing the provisions of this Act and the rules made thereunder in the market area.(2)No
bye-laws shall take effect until it has been published or and notified in the Arunachal Pradesh
Gazette.
79. Power to make Rules.
- Subject to the rules made under this Act, the Board may with the previous approval of the State
Government frame regulations for:-(a)Summoning and holding of meetings of the Board, the time
and date when such meetings are to be held, the conduct of business at such meetings.Arunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

80. Repeal and savings.
- In the Arunachal Pradesh Agricultural Produce and Marketing (Regulation) Act, 1989 (No. 6 of
1990), in section 2 (1), the word, (horticultural" appearing after the word " agriculture" and before
the word "apiculture" is hereby deleted and repealed. Notwithstanding such deletion and repeal.
anything done or any action taken including any appointment, or delegations made, notification,
notice, order, instruction or direction issued, rules, regulation, bye-laws, form, scheme framed,
certificate obtained, permit or license granted, registration affected, fee levied under that Act shall,
in so after as it in force immediately before the coming into force of this Act and is not inconsistent
with the provisions of this Act shall be deemed to have been done or taken under the corresponding
provisions of this Act and shall continue to be in enforce accordingly, until and unless superseded by
anything done or any action taken under this Act.(b)Powers and duties of the officers and other
employees of the Board.(c)Salaries and allowances and other conditions of service of officers and
other employees of the Board and the market Committee.(d)Management of accounts and the
preparation of balance sheet by the Board.(e)Execution of contracts on behalf of the
Board.(f)Maintenance of accounts and the preparation of balance sheet by the Board.(g)Procedure
for carrying out the functions of the Board under this Act.(h)Other matter for which provision is to
be or may be made in regulation.The Schedule(See section 2 (a) and section 68)
Item English Name Hindi Name
1 2 3
1. Fruits 1. Mango Am
 2. Banana Kela
 3. Litchi Litchi
 4. Sweet Orange Malta
 5. Lemon Neembo
 6. Grapes Angoor
 7. pomegranate Anar
 8. Apple Saib
 9. Orange Santra
 10. Peach Aru
 11. Kiwi Kiwi
 12. Plum Alucha
 13. Pears Naspati
 14. Gauva Amrud
 15. Apricot Khurmani
 16. Persimon Japani Phal
 17. Watermelon Tarbuz
 18. Walnut Akhrot
 19. Almond BadamArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

 20. Musk-Melon Kharbuza
 21. Papaya Papita
 22. Jackfruit Kathal
 23. Ber Ber
 24. Aonla Amla
 25. Cherry -
 26. Egg fruit -
 27. Avcoda -
 28. Fig -
 29. Date palm -
 30. Jamun -
 31. karonda -
 32. Baet -
 33. Loqout -
 34. Passion Fruit -
 35. Pine Apple Anarash
 36. Phalsa -
 37. Sapota -
 38. Strawberry -
 39. Stone fruits -
 40. Minor tropical fruits -
 41. Peacan nut -
2. Vegetables 42. Bottle gourd Ghia
 43. Brinjal Baingan
 44. Ladi's Finger Bhindi
 45. Tomato Tamator
 46. Cauliflower Phulgobhi
 47. Cabbage Bandhgobhi
 48. Sponge gourd Ghia tori
 49. Carrot Gajar
 50. French Bean Pharas bean
 51. Raddish Muli
 52. Leave of Indian Sag
 53. Capsicum Mirch badi
 54. Bitter gourd Karela
 55. Cucumber Khira
 56. Chilli mirchArunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

 57. Lettuce falak
 58. Spinach Dhaina
 59. Knol-Khol  
3. Floriculture 60. Annul floers -
 61. Anthurium  
 62. Carnation  
 63. Rose  
 64. Gladiolus  
 65. Jasmine  
 66. Orchids  
 67. Chrsanthimum  
 68. All ornamental and Avenue plantations.  
 69. Binneal and perennial flowers.  
4. Medicinal and Aromatic plants. 70. All medicinal and Aromatic plants.  
5. Spices 71. Ginger  
 72. Tamarind  
 73. Cardamom(small & Large).  
 74. Turmeric  
 75. Black Peeper  
 76. and all other Spices crops.  
6. Mushrooms 77. Button Mushrooms  
 78. Oyster Mushrooms  
 79. Paddy Straw Mushrooms,  Arunachal Pradesh (Horticultural Produce, Marketing and Processing) Board Act, 2014

