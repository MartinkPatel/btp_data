Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal
& Ors on 22 April, 2024
Author: Debangsu Basak
Bench: Debangsu Basak
                                                1
                            IN THE HIGH COURT AT CALCUTTA
                               Constitutional Writ Jurisdiction
                                        Appellate Side
              Present:
              The Hon'ble Justice Debangsu Basak
                         And
              The Hon'ble Justice Md. Shabbar Rashidi
                                      WPA 30649 of 2016
                           Baishakhi Bhattacharyya (Chatterjee) & Ors.
                                              Vs.
                                  State of West Bengal & Ors.
                                              With
                                       WPA 2613 of 2018
                                           Basanta Das
                                               Vs.
                                   State of West Bengal & Ors.
                                              With
                                      WPA 22522 of 2018
                                 Saddam Hossain Biswas & Ors.
                                              Vs.
                                  State of West Bengal & Ors.
                                              With
                                       WPA 22523 of 2018
                                      Purbita Ray & others.
                                               Vs.
                                   State of West Bengal & Ors.
                                              With
                                       WPA 22550 of 2018
                                     Prasanta Mandal & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

                                                Vs.
                                  State of West Bengal & others.
                                              With
Signed By :
SUBHA
KARMAKAR                               WPA 22773 of 2018
High Court of
Calcutta                               Jearul Islam & Ors.
22 nd of April
2024 12:36:10 PM                               Vs.
                       2
         State of West Bengal & Ors.
                    With
             WPA 22780 of 2018
         Kapil Kumar Mistry & Ors.
                     Vs.
         State of West Bengal & Ors.
                    With
             WPA 22782 of 2018
           Sk. Insan Ali & others.
                     Vs.
         State of West Bengal & Ors.
                    With
             WPA 22785 of 2018
             Rupali Nath & Ors.
                     Vs.
         State of West Bengal & Ors.
                    With
             WPA 22973 of 2018
             Senarul Islam & Ors.
                      Vs.
        State of West Bengal & others.
                    With
             WPA 16844 of 2019
               Swagata Biswas
                     Vs.
         State of West Bengal & Ors.
                    WithBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

              WPA 18355 of 2019
              IA NO: CAN/1/2020
               Mousumi Mondal
                      Vs.
W.B. Central School Service Commission & Anr.
                    With
             WPA 19273 of 2019
               Mamoni Basak
                     Vs.
         State of West Bengal & Ors.
              3
           With
    WPA 19278 of 2019
     Masuma Parveen
            Vs.
State of West Bengal & Ors.
           With
    WPA 19749 of 2019
    Chandra Rani Paul
            Vs.
State of West Bengal & Ors.
           With
    WPA 20404 of 2019
      Julekha Mandal
            Vs.
State of West Bengal & Ors.
           With
    WPA 20776 of 2019
     Phalguni Rakshit
            Vs
State of West Bengal & Ors.
           With
    WPA 20778 of 2019
       Soma Biswas
            Vs.
State of West Bengal & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

           With
    WPA 21665 of 2019
Biswajit Debnath & others.
           With
State of West Bengal & Ors.
           With
    WPA 18100 of 2019
       Pradyut Dutta
            Vs.
State of West Bengal & Ors.
           With
                           4
                WPA 18627 of 2019
             Haimanti Kundu & others.
                        Vs.
West Bengal Central School Service Commission & Ors.
                        With
                WPA 20045 of 2019
                  Debashree Patra
                        Vs.
West Bengal Central School Service Commission & anr.
                        With
                 WPA 21923 of 2019
                Kartick Sau & others.
                         Vs.
             State of West Bengal & Ors.
                        With
                WPA 22119 of 2019
                IA NO:CAN/1/2020
                  Shampa Sarkar
                        Vs.
  The WB Central School Service Commission & anr.
                        With
                 WPA 23259 of 2019
                   Satadal Mondal
                         Vs.
             State of West Bengal & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

                        With
                 WPA 23454 of 2019
               Mohasin Kamal & Ors.
                         Vs.
             State of West Bengal & Ors.
                        With
                 WPA 23946 of 2019
              Moumita Samanta & Ors.
                        Vs.
   W.B. Central School Service Commission & Ors.
                        With
                             5
                   WPA 4835 of 2020
                      Md. Jinnat Sk
                           Vs.
               State of West Bengal & Ors.
                          With
                   WPA 8078 of 2020
                   Nadia Parvin Mou
                           Vs.
The West Bengal Central School Service Commission & Ors.
                          With
                   WPA 8555 of 2020
                       Ajoy Mondal
                           Vs.
  West Bengal Central School Service Commission & anr.
                          With
                  WPA 11455 of 2020
                    Mallika Thander
                           Vs.
The West Bengal Central School Service Commission & anr.
                          With
                   WPA 7592 of 2021
                     Rina Karmakar
                           Vs.
               State of West Bengal & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

                          With
                   WPA 8003 of 2021
                    Amarjeet Kumar
                           Vs.
               State of West Bengal & Ors.
                          With
                   WPA 8264 of 2021
                Hafizur Rahaman & anr.
                           Vs.
               State of West Bengal & Ors.
                          With
                  WPA 10938 of 2021
                  IA NO:CAN/1/2021
              6
  Tridib Sundar Bahadur
            Vs.
State of West Bengal & Ors.
           With
    WPA 10947 of 2021
    IA NO:CAN/1/2024
      Gobinda Mandal
            Vs.
State of West Bengal & Ors.
           With
    WPA 10949 of 2021
       Prasanta Das
            Vs.
State of West Bengal & Ors.
           With
    WPA 10960 of 2021
         Sudip Bala
            Vs.
State of West Bengal & Ors.
           With
   WPA 13700 of 2021
   IA NO: CAN/3/2023
       CAN/4/2023Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

       CAN/5/2023
       CAN/6/2023
       CAN/8/2023
      CAN/13/2023
      CAN/16/2023
      CAN/17/2023
      CAN/18/2023
      CAN/20/2023
      CAN/21/2023
      CAN/22/2023
      CAN/23/2023
      CAN/24/2024
      CAN/25/2024
      CAN/26/2024
      CAN/27/2024
      CAN/28/2024
      CAN/29/2024
      CAN/30/2024
      CAN/31/2024
      CAN/32/2024
                7
      Setab Uddin & Ors.
              Vs.
The State of West Bengal & Ors.
             With
      WPA 13701 of 2021
      IA NO: CAN/1/2022
     Md Abdul Gani Ansari
              Vs.
  State of West Bengal & Ors.
             With
      WPA 13721 of 2021
         Sovan Kundu
              Vs.
  State of West Bengal & Ors.
             With
      WPA 13727 of 2021
       Suvankar Mondal
              Vs.
  State of West Bengal & Ors.
             With
      WPA 13863 of 2021Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

        Shireen Mustafi
              Vs.
  State of West Bengal & Ors.
             With
      WPA 13885 of 2021
         Kanai Haldar
              Vs.
  State of West Bengal & Ors.
             With
      WPA 15137 of 2021
   Md Ismail Hossain & anr.
              Vs.
  State of West Bengal & Ors.
             With
     WPA 15154 of 2021
        Ainal Hoque
              8
            Vs.
State of West Bengal & Ors.
           With
    WPA 16443 of 2021
     Ruksana Khatun
            Vs.
State of West Bengal & Ors.
           With
    WPA 16444 of 2021
  Samsuzzaman Mondal
            Vs.
State of West Bengal & Ors.
           With
    WPA 16448 of 2021
       Runa Khatun
            Vs.
State of West Bengal & Ors.
           With
    WPA 16450 of 2021Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

       Nasrin Khatun
            Vs.
State of West Bengal & Ors.
           With
    WPA 16476 of 2021
     Md Masikul Anam
            Vs.
State of West Bengal & Ors.
           With
    WPA 16481 of 2021
Mostafizur Rahaman & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 16484 of 2021
      Ashoke Biswas
            Vs.
State of West Bengal & Ors.
              9
           With
    WPA 16487 of 2021
       Sukanta Malik
            Vs.
State of West Bengal & Ors.
           With
    WPA 16489 of 2021
      Pallabbi Naskar
            Vs.
State of West Bengal & Ors.
           With
    WPA 16505 of 2021
         Rekha Roy
            Vs.
State of West Bengal & Ors.
           With
    WPA 16519 of 2021Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

      Prasanta Barui
            Vs.
State of West Bengal & Ors.
           With
    WPA 16858 of 2021
   Bilkis Khatun & anr.
            Vs.
State of West Bengal & Ors.
           With
    WPA 16859 of 2021
  Ishita Debsarma & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 16860 of 2021
 Raghabendra Garai & Ors.
            Vs.
State of West Bengal & Ors.
           With
             10
    WPA 16879 of 2021
   Tama Hossain & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 16880 of 2021
   Rubia Khatun & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 16889 of 2021
     Rakibur Sk & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 16896 of 2021Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

   Shrabani Saha & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 16902 of 2021
    Soma Biswas & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 16930 of 2021
   Anima Ghosh & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 16948 of 2021
       Poli Das& Ors.
             Vs.
State of West Bengal & Ors.
           With
   WPA 16960 of 2021
             11
     Md. Tasiul Haque
            Vs.
State of West Bengal & Ors.
           With
    WPA 16968 of 2021
   Mithun Sarkar & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 17273 of 2021
    IA NO: CAN/1/2022
       Nasrin Khatun
            Vs.
State of West Bengal & Ors.
           WithBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

    WPA 18379 of 2021
   Kalyan Mandal & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 18381 of 2021
    IA NO: CAN/1/2023
Sarmin Nahar Khatun & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 18383 of 2021
    Barnali Saha & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 18385 of 2021
    IA NO:CAN/1/2023
  Haimanti Bitter & Ors.
            Vs.
State of West Bengal & Ors.
           With
             12
    WPA 18387 of 2021
     Baki Balla & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 18388 of 2021
 Mogibar Rahaman & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 18460 of 2021
        Saranjit Roy
            Vs.
State of West Bengal & Ors.
           WithBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

    WPA 18470 of 2021
     Hara Sankar Roy
            Vs.
State of West Bengal & Ors.
           With
    WPA 18487 of 2021
   Prokash Ghosh & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 18491 of 2021
          Amit Let
            Vs.
State of West Bengal & Ors.
           With
    WPA 18496 of 2021
       Atikuzzaman
            Vs.
State of West Bengal & Ors.
           With
   WPA 18499 of 2021
      Rijia Begum
             13
            Vs.
State of West Bengal & Ors.
           With
    WPA 18801 of 2021
     Sangita Banerjee
            Vs.
State of West Bengal & Ors.
           With
    WPA 18994 of 2021
        Lipi Khatun
             Vs.
State of West Bengal & Ors.
           WithBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

    WPA 18995 of 2021
       Samim Islam
            Vs.
State of West Bengal & Ors.
           With
    WPA 19475 of 2021
      Dilruba Khatun
            Vs.
State of West Bengal & Ors.
           With
    WPA 19477 of 2021
        Shilpa Patra
             Vs.
State of West Bengal & Ors.
           With
    WPA 19478 of 2021
       Monoj Ghosh
            Vs.
State of West Bengal & Ors.
           With
    WPA 19580 of 2021
       Sewly Khatun
            Vs.
State of West Bengal & Ors.
             14
           With
    WPA 20906 of 2021
  Prosanta Ruidas & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 21258 of 2021
    Barnali Bhar & Ors.
            Vs.
State of West Bengal & Ors.
           WithBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

    WPA 21261 of 2021
    Sk.Toyab Rahaman
            Vs.
State of West Bengal & Ors.
           With
    WPA 21263 of 2021
    Samim Seikh & anr.
            Vs.
State of West Bengal & Ors.
           With
    WPA 21266 of 2021
  Sumaitri Biswas & anr.
            Vs.
State of West Bengal & Ors.
           With
    WPA 21267 of 2021
  Md Jasimuddin & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 21268 of 2021
        Anup Gupta
            Vs.
State of West Bengal & Ors.
           With
                      15
             WPA 21317 of 2021
             Rathin Roy & Ors.
                     Vs.
         State of West Bengal & Ors.
                    With
             WPA 21430 of 2021
Priyanka Dutta Samaddar @ Priyanka Samaddar
                     Vs.
         State of West Bengal & Ors.
                    WithBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

              WPA 781 of 2022
                  Sudip Saha
                     Vs.
         State of West Bengal & Ors.
                    With
             WPA 1618 of 2022
              Dipti Saha & anr.
                     Vs.
         State of West Bengal & Ors.
                    With
              WPA 5538 of 2022
             IA NO:CAN/2/2022
                CAN/3/2022
                CAN/4/2024
                CAN/5/2024
                CAN/6/2024
                Anindita Bera
                     Vs.
         State of West Bengal & Ors.
                    With
             WPA 5786 of 2022
              Rajkumar Middya
                     Vs.
         State of West Bengal & Ors.
                    With
             WPA 5788 of 2022
              Papia Tahmin
                   Vs.
             16
State of West Bengal & Ors.
           With
    WPA 6550 of 2022
    Pamela Das & Ors.
            vs.
State of West Bengal & Ors.
           With
    WPA 7346 of 2022Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

 Salauddin Hossain & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 7347 of 2022
Meherunnessa Khatun & Ors.
            Vs.
State of West Bengal & Ors.
           With
     WPA 8059 of 2022
    IA NO: CAN/1/2024
        Soma Sinha
            Vs.
State of West Bengal & Ors.
           With
    WPA 16935 of 2022
      Amit Karmakar
            Vs.
State of West Bengal & Ors.
           With
    WPA 20389 of 2022
    IA NO: CAN/1/2022
    Md Rukumuddin Sk
            Vs.
State of West Bengal & Ors.
           With
             17
    WPA 21332 of 2022
Suman Chakraborty & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 21334 of 2022
Srikanta Chatterjee & Ors.
            Vs.
State of West Bengal & Ors.
           WithBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

    WPA 21340 of 2022
Debasmita Pradhan & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 21344 of 2022
  Madhusudan Pal & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 21346 of 2022
  Moumita Ghosh & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 21349 of 2022
   Sk Hasib Imam & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 21350 of 2022
   Swarup Sarkar & Ors.
            Vs.
State of West Bengal & Ors.
           With
   WPA 25380 of 2022
   IA NO: CAN/1/2023
             18
       CAN/3/2023
       CAN/4/2023
       CAN/5/2023
       CAN/6/2024
        CAN 7/2024
 Subhamay Bhunia & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 26770 of 2022Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

     Prabir Chatterjee
            Vs.
State of West Bengal & Ors.
           With
    WPA 27886 of 2022
   Sk Mustafa Ali & Ors.
            Vs.
State of West Bengal & Ors.
           With
    WPA 28197 of 2022
          Riya Pal
            Vs.
State of West Bengal & Ors.
           With
     MAT 85 of 2023
     CAN 3 of 2024
 Gopinath Bhanja & Ors.
          Vs.
   Setab Uddin & Ors
          With
           .
MAT 124 of 2023 Hafizur Rahaman & Ors.
Vs. Setab Uddin With MAT 244 of 2023 IA No.: CAN/1/2023 Soumen Kumar Das & Ors.
Vs. State of West Bengal & Ors.
With MAT 245 of 2023 Arup Sarkar & Ors.
Vs. Subhamay Bhunia & Ors.
With MAT 290 of 2023 Pritisha Das & Ors.
Vs. Subhamoy Bhunia & Ors.
With MAT 304 of 2023 Nirupam Das & Ors.
Vs. State of West Bengal & Ors.
With WPA 362 of 2023 CAN 1 of 2023 Shyamal Dutta & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

Vs. State of West Bengal & Ors.
With MAT 557 of 2023 IA NO: CAN/1/2023 Brajadulal Giri & Ors.
Vs. State of West Bengal & Ors.
With WPA 1062 of 2023 Kushik Ghosh & anr.
Vs. State of West Bengal & Ors.
With WPA 1066 of 2023 Rima Dutta Vs. State of West Bengal & Ors.
With WPA 1070 of 2023 Rumpa Mondal Vs. State of West Bengal & Ors.
With WPA 1072 of 2023 Laltu Mistry Vs. State of West Bengal & Ors.
With WPA 1075 of 2023 Soumen Biswas Vs. State of West Bengal & Ors.
With WPA 1369 of 2023 Gopal Manna & Others.
Vs. State of West Bengal & Others.
With WPA 1466 of 2023 Taimur Rahaman & anr.
Vs. State of West Bengal & Others.
With WPA 3771 of 2023 Sultana Khatun & anr.
Vs. State of West Bengal & Ors.
With WPA 4206 of 2023 Mousumi Khatun Vs. State of West Bengal & Ors.
With WPA 4841 of 2023 Biman Mondal Vs. State of West Bengal & Ors.
With WPA 4989 of 2023 Sanchita Das & Ors.
Vs. State of West Bengal & Ors.
With WPA 5087 of 2023 Lopa Mudra Naskar Vs. State of West Bengal & Ors.
With WPA 5379 of 2023 Sewli Ghosh & anr.
Vs. State of West Bengal & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

With WPA 5604 of 2023 Ratan Bauldas & Ors.
Vs. State of West Bengal & Ors.
With WPA 5609 of 2023 Samima Yasmin & anr.
Vs. State of West Bengal & Ors.
With WPA 2081 of 2023 Ali Zinna & Ors.
Vs. State of West Bengal & Ors.
With WPA 2149 of 2023 Sukanta Malik Vs. State of West Bengal & Ors.
With WPA 2151 of 2023 Subir Naskar Vs. State of West Bengal & Ors.
With WPA 2154 of 2023 Ataul Ali Mallick Vs. State of West Bengal & Ors.
With WPA 2172 of 2023 Monia Khatun Vs. State of West Bengal & Ors.
With WPA 2175 of 2023 Asanur Ali Mallick Vs. State of West Bengal & Ors.
With WPA 2179 of 2023 Sampa Debnath Vs. State of West Bengal & Ors.
With WPA 2182 of 2023 Sk Ekramul Ali Vs. State of West Bengal & Ors.
With WPA 2215 of 2023 Hirak Sinha Roy & Ors.
Vs. State of West Bengal & Ors.
With WPA 2496 of 2023 Riya Roy Khanra Vs. State of West Bengal & Ors.
With WPA 2760 of 2023 Barnali Saha Vs. State of West Bengal & Ors.
With WPA 2967 of 2023 Gopinath Bhanja & Ors.
Vs. State of West Bengal & Ors.
With WPA 2984 of 2023 Shrabanti Halder Vs. State of West Bengal & Ors.
With WPA 3126 of 2023 Subrata Ghosh & Ors.
Vs. State of West Bengal & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

With WPA 3399 of 2023 Shraboni Dutta & Anr.
Vs. State of West Bengal & Ors.
With WPA 3652 of 2023 Abbus Sk.
Vs. State of West Bengal & Ors.
With WPA 3658 of 2023 Rumpa Kar Vs. State of West Bengal & Ors.
With WPA 3661 of 2023 Paramita Rit Vs. State of West Bengal & Ors.
With WPA 3664 of 2023 Ratan Let Vs. State of West Bengal & Ors.
With WPA 3666 of 2023 Sumaitri Biswas & anr.
Vs. State of West Bengal & Ors.
With WPA 3846 of 2023 CAN/1/2024 Baby Biswas & Anr.
Vs. State of West Bengal & Ors.
With WPA 3859 of 2023 Asima Nayak.
Vs. State of West Bengal & Ors.
With WPA 3926 of 2023 Lubana Parvin Vs. State of West Bengal & Ors.
With WPA 3931 of 2023 Pallabi Naskar Vs. State of West Bengal & Ors.
With WPA 3935 of 2023 Ganesh Mahata.
Vs. State of West Bengal & Ors.
With WPA 3990 of 2023 Suvadip Manna Vs. State of West Bengal & Ors.
With WPA 4117 of 2023 Kalyan Kumar Giri Vs. State of West Bengal & others.
With WPA 4213 of 2023 Pragati Saha Vs. State of West Bengal & others.
With WPA 4313 of 2023 Sarama Ghosh Vs. State of West Bengal & Ors.
With WPA 4522 of 2023 Sreenandaa Bhattacharyya & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

Vs. State of West Bengal & Ors.
With WPA 4556 of 2023 Susmita Pal & Ors.
Vs. State of West Bengal & Ors.
With WPA 5134 of 2023 Ananya Mahapatra Vs. The State of West Bengal & Ors.
With WPA 5464 of 2023 Sima Ghosh Vs. State of West Bengal & Ors.
With WPA 5526 of 2023 Namita Adak & Ors.
Vs. State of West Bengal & Ors.
With WPA 5531 of 2023 Hasanur Jaman and Ors.
Vs. State of West Bengal & Ors.
With WPA 5797 of 2023 Prasanjit Paul & Ors.
Vs. State of West Bengal & Ors.
With WPA 5799 of 2023 Md Mamun Rasid & Ors.
Vs. State of West Bengal & Ors.
With WPA 5953 of 2023 Brajadulal Giri & Ors.
Vs. State of West Bengal & Ors.
With WPA 6164 of 2023 Sanatan Mondal & Ors.
Vs. State of West Bengal & Ors.
With WPA 6210 of 2023 Jhuma Malakar Vs. State of West Bengal & Ors.
With WPA 6213 of 2023 Jui Barman Vs. State of West Bengal & Ors.
With WPA 6282 of 2023 Pratima Maiti, Vs. State of West Bengal & Ors.
With WPA 6577 of 2023 Kuheli Ghosh and Ors.
Vs. State of West Bengal & others.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

With WPA 6854 of 2023 Nafisa Khatun Vs. State of West Bengal & Ors.
With WPA 6859 of 2023 Shaoli Mukherjee Vs. State of West Bengal & Ors.
With WPA 6915 of 2023 Arpita Hazra Vs. State of West Bengal & Ors.
With WPA 7370 of 2023 Palash Mondal & Ors.
Vs. State of West Bengal & Ors.
With WPA 7528 of 2023 Setab Uddin & Ors.
Vs. State of West Bengal & Ors.
With WPA 7831 of 2023 Jayati Pal Vs. State of West Bengal & Ors.
With WPA 7952 of 2023 Supriti Paria Vs. State of West Bengal & Ors.
With WPA 9105 of 2023 Pravati Das Vs. State of West Bengal & Ors.
With WPA 9327 of 2023 Krishnendu Dutta & Ors.
Vs. State of West Bengal & Ors.
With WPA 10387 of 2023 Rita Gayen Vs. State of West Bengal & Ors.
With WPA 10614 of 2023 IA NO: CAN/1/2023 Khayrul Anam Mondal & anr.
Vs. State of West Bengal & Ors.
With WPA 12557 of 2023 Md. Golam Yeasdani & others.
Vs. State of West Bengal & others.
With WPA 13588 of 2023 Mithun Sarkar & Ors.
Vs. State of West Bengal & Ors.
With WPA 14824 of 2023 Prabir Chatterjee Vs. State of West Bengal & Ors.
With WPA 17679 of 2023 Aribillah Gazi Vs. State of West Bengal & Ors.
With WPA 18401 of 2023 Jagannath Sadhukhan & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

Vs. State of West Bengal & Ors.
With WPA 19126 of 2023 Nazima Begum Vs. State of West Bengal & Ors.
With WPA 19604 of 2023 Arpita Seth Vs. State of West Bengal & Ors.
With WPA 19605 of 2023 Arnab Datta Vs. State of West Bengal & Ors.
With WPA 19869 of 2023 Bibhas Biswas Vs. State of West Bengal & Ors.
With WPA 21000 of 2023 Pradyut Ghosh.
Vs. State of West Bengal & Ors.
With WPA 21211 of 2023 Priyanka Mukhopadhyay.
Vs. State of West Bengal & Ors.
With WPA 22796 of 2023 Taslim Arif Vs. State of West Bengal & Ors.
With WPA 23761 of 2023 Barnali Saha Vs. State of West Bengal & Ors.
With WPA 24247 of 2023 Aditi Jana Vs. State of West Bengal & Ors.
With WPA 26848 of 2023 Yakub Alam Vs. State of West Bengal & Ors.
With WPA 366 of 2024 Suman Kumar Dey Vs. State of West Bengal & Ors.
With WPA 13113 of 2018 Tulasi Santra Vs. State of West Bengal & Ors.
With WPA 18034 of 2018 Krishnapada Mondal Vs. State of West Bengal & Ors.
With WPA 20034 of 2019 Mahadeb Duley & Ors.
Vs. State of West Bengal & Ors.
With WPA 3665 of 2021 Srikanta Mandal & Ors.
Vs. State of West Bengal & Ors.
With WPA 10772 of 2021 Tathagata Nandy & Ors.
Vs. State of West Bengal & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

With WPA 12266 of 2021 IA NO: CAN/1/2021 CAN/2/2021 CAN/3/2021 CAN/4/2021 CAN/5/2021
CAN/6/2022 CAN/8/2024 CAN/9/2024 Sandeep Prasad & Ors.
Vs. State of West Bengal & Ors.
With WPA 17068 of 2021 Jhantu Das & Ors.
Vs. State of West Bengal & Ors.
With WPA 18585 of 2021 IA NO: CAN/5/2023 CAN/6/2024 CAN/7/2024 CAN/8/2024
CAN/10/2024 Laxmi Tunga & Ors.
Vs. State of West Bengal & Ors.
With WPA 19977 of 2021 Milan Roy & Ors.
Vs. State of West Bengal & Ors.
With WPA 20070 of 2021 Rishav Sarkar.
Vs. State of West Bengal & Ors.
With WPA 6754 of 2022 Sanchita Payra Chanda & Ors.
Vs. State of West Bengal & Ors.
With WPA 8598 of 2022 Anirban Bhattacharya Vs. State of West Bengal & Ors.
With WPA 10211 of 2022 Most Nur Momtaj & Ors.
Vs. State of West Bengal & Ors.
With WPA 14630 of 2022 Soumen Bhattacharya & Ors.
Vs. State of West Bengal & Ors.
With WPA 14670 of 2022 Delip Ruidas Vs. State of West Bengal & Ors.
With WPA 15359 of 2022 Sovan Sahoo & Ors.
Vs. State of West Bengal & Ors.
With WPA 19053 of 2022 Tonmay Bera & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

Vs. State of West Bengal & Ors.
With WPA 19916 of 2022 Joyanta Das & Ors.
Vs. State of West Bengal & Ors.
With WPA 20028 of 2022 Sanjib Maity & Ors.
Vs. State of West Bengal & Ors.
With WPA 27164 of 2022 Sarbani Mondal Vs. State of West Bengal & Ors.
With WPA 27166 of 2022 Asha Singha Vs. State of West Bengal & Ors.
With WPA 27168 of 2022 Arjun Barui & Ors.
Vs. State of West Bengal & Ors.
With MAT 250 of 2023 IA NO:CAN/1/2023 CAN/2/2023 CAN/3/2023 Achinta Kr. Mondal Vs.
Laxmi Tunga & Ors.
& State of West Bengal & Ors.
With MAT 259 of 2023 IA No.: CAN 1 of 2023 CAN 2 of 2023 CAN 3 of 2023 CAN 4 of 2024
Samiran Maity & Ors.
Vs. Laxmi Tunga & Ors.
& State of West Bengal & Ors.
With MAT 274 of 2023 IA No.: CAN 1 of 2023 Achinta Kr Mondal & Ors.
Vs. Laxmi Tunga & Ors.
& State of West Bengal & Ors.
With MAT 275 of 2023 Aritra Saha Vs. Laxmi Tunga & Ors.
With MAT 276 of 2023 IA No.: CAN/ 1/ 2023 CAN/ 2/2023 Susovan Satpathi & Ors.
Vs. Laxmi Tunga & Ors.
& State of West Bengal & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

With MAT 284 of 2023 IA No.: CAN 1 of 2023 CAN 2 of 2023 Arnab Paul Chowdhury & Ors.
Vs. Laxmi Tunga & Ors.
With MAT 318 of 2023 IA NO:CAN/1/2023 Rakhi Das Maity & Ors.
Vs. Laxmi Tunga & Ors.
& State of West Bengal & Ors.
With MAT 334 of 2023 IA NO:CAN/1/2023 Prodip Kumar Roy & Ors.
Vs. Laxmi Tunga & Ors.
& State of West Bengal & Ors.
With MAT 336 of 2023 IA NO:CAN/1/2023 Bablu Sardar & Ors.
Vs. Laxmi Tunga & Ors.
& State of West Bengal & Ors.
With MAT 338 of 2023 IA NO:CAN/1/2023 Pandab Gorai & Ors.
Vs. Laxmi Tunga & Ors.
& State of West Bengal & Ors.
With MAT 342 of 2023 IA NO:CAN/1/2023 Tanmoy Dey and Ors.
Vs. Laxmi Tunga & Ors.
& State of West Bengal & Ors.
With MAT 343 of 2023 IA NO:CAN/1/2023 Gobinda Biswas & Ors.
Vs. Laxmi Tunga & Ors.
& State of West Bengal & Ors.
With MAT 344 of 2023 IA NO:CAN/1/2023 Juel Sarkar & Ors.
Vs. Laxmi Tunga & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

& State of West Bengal & Ors.
With MAT 345 of 2023 IA NO:CAN/1/2023 Nuralam Sk. & Ors.
Vs. Laxmi Tunga & Ors.
& State of West Bengal & Ors.
With MAT 346 of 2023 IA NO:CAN/1/2023 Papiya Dutta & Ors.
Vs. Laxmi Tunga & Ors.
& State of West Bengal & Ors.
With MAT 358 of 2023 IA NO:CAN/1/2023 Biplab Sarkar & Ors.
Vs. Laxmi Tunga & Ors.
& State of West Bengal & Ors.
With MAT 359 of 2023 IA NO:CAN/1/2023 Nimai Barman & Ors.
Vs. Laxmi Tunga & Ors.
& State of West Bengal & Ors.
With MAT 361 of 2023 IA NO:CAN/1/2023 Anup Dutta & Ors.
Vs. Laxmi Tunga & Ors.
& State of West Bengal & Ors.
With MAT 382 of 2023 IA NO:CAN/1/2023 Bishnupriya Mondal & Ors.
Vs. Laxmi Tunga & Ors.
& State of West Bengal & Ors.
With WPA 20022 of 2019 Pampa Biswas Vs. State of West Bengal & Ors.
With WPA 20029 of 2019 Mallika Mandal & anr.
Vs. State of West Bengal & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

With WPA 20039 of 2019 Javed Hyder & Ors.
Vs. State of West Bengal & Ors.
With WPA 3654 of 2021 Saikat Adhikari & Ors.
Vs. State of West Bengal & Ors.
With WPA 10764 of 2021 Prasenjit Mandal & Ors.
Vs. State of West Bengal & Ors.
With WPA 12270 of 2021 IA NO:CAN/1/2022 CAN/2/2022 CAN/3/2022 CAN/7/2023
CAN/8/2024 CAN/9/2024 CAN/10/2024 Sabina Yeasmin & Ors.
Vs. State of West Bengal & Ors.
With WPA 17048 of 2021 Sampa Roy & Ors.
Vs. State of West Bengal & Ors.
With WPA 18589 of 2021 Saikh Dil Mahammad & Ors.
Vs. State of West Bengal & Ors.
With WPA 18590 of 2021 Amit Ghosh Vs. State of West Bengal & Ors.
With WPA 18593 of 2021 Biswajit Roy Vs. State of West Bengal & Ors.
With WPA 19975 of 2021 Prodip Dey & Ors.
Vs. State of West Bengal & Ors.
With WPA 8614 of 2022 Sanju Panda & Ors.
Vs. State of West Bengal & Ors.
With WPA 10213 of 2022 Sayani Deb & Ors.
Vs. State of West Bengal & Ors.
With WPA 14525 of 2022 Abhranil Das Vs. State of West Bengal & Ors.
With WPA 14634 of 2022 Joydeb Mondal & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

Vs. State of West Bengal & Ors.
With WPA 15360 of 2022 Uttam Das & Ors.
Vs. State of West Bengal & Ors.
With WPA 17340 of 2022 Sk Nagimul Haque Vs. State of West Bengal & Ors.
With WPA 19060 of 2022 Kanchan Rani Maicap & Ors.
Vs. State of West Bengal & Ors.
With WPA 20030 of 2022 Titab Roy & Ors.
Vs. State of West Bengal & Ors.
With WPA 27161 of 2022 Krishna Nandi & Ors.
Vs. State of West Bengal & Ors.
With MAT 443 of 2023 IA NO:CAN/1/2023 Arup Ratan Show & Ors.
Vs. Sabina Yeasmin & Ors.
& State of West Bengal & Ors.
With MAT 457 of 2023 IA NO:CAN/1/2023 Subhadip Saha & Ors.
Vs. Sabina Yeasmin & Ors.
With MAT 458 of 2023 IA NO: CAN/2/2023 CAN/3/2024 CAN/4/2024 Subhadip Paik & Ors.
Vs. Sabina Yeasmin & Ors.
With MAT 476 of 2023 Kousik Mukherjee.
Vs. Sabina Yeasmin & Ors.
& State of West Bengal & Ors.
With MAT 502 of 2023 IA NO:CAN/1/2023 Goutam Patra & Ors.
Vs. Sabina Yeasmin & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

& State of West Bengal & Ors.
With MAT 470 of 2023 IA NO:CAN/1/2023 Debasis Roy & Ors.
Vs. Sabina Yeasmin & Ors.
& State of West Bengal & Ors.
With MAT 480 of 2023 Arpita Maiti Vs. Sabina Yeasmin & Ors.
& State of West Bengal & Ors.
With MAT 521 of 2023 IA NO:CAN/1/2023 Kaji Enamul Hoque & Ors.
Vs. Sabina Yeasmin & Ors.
& State of West Bengal & Ors.
With WPA 30653 of 2016 Baishakhi Bhattacharyya (Chatterjee) & Ors.
Vs. State of West Bengal & Ors.
With WPA 30065 of 2017 Prasanta Kumar Dey Vs. State of West Bengal & Ors.
With WPA 12662 of 2018 Biswajit Biswas & others.
Vs. State of West Bengal & Ors.
With WPA 13105 of 2018 IA NO: CAN/1/2018(Old No:CAN/8494/2018) Munshi Wasim Asgar Vs.
State of West Bengal & Ors.
With WPA 22777 of 2018 Abu Torap Molla & Ors.
Vs. State of West Bengal & Ors.
With WPA 22971 of 2018 IA NO:CAN/1/2020(Old No:CAN/2737/2020) Ashrafun Nessa & Ors.
Vs. State of West Bengal & Ors.
With WPA 18352 of 2019 IA NO:CAN/1/2020 Madhumita Mondal Vs. W.B. Central School Service
Commission & anr.
With WPA 21154 of 2019 Swastika Jana Vs. State of West Bengal & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

With WPA 22076 of 2019 Madhumita Pan & Ors.
Vs. State of West Bengal & Ors.
With WPA 23064 of 2019 Sabari Adak @ Sabari Adak Modak Vs. State of West Bengal & Ors.
With WPA 23480 of 2019 Tumpa Pal Vs. State of West Bengal & Ors.
With WPA 23481 of 2019 Mahamud Hasan Gazi Vs. State of West Bengal & Ors.
With WPA 3476 of 2020 Snehangshu Rout Vs. State of West Bengal & Ors.
With WPA 6887 of 2020 Apu Bej Vs. State of West Bengal & Ors.
With WPA 7425 of 2020 IA NO:CAN/1/2020 Kakali (Ranjit) Mondal Vs. State of West Bengal &
Ors.
With WPA 7616 of 2020 IA NO:CAN/1/2020 Sathi Mondal Das Vs. State of West Bengal & Ors.
With WPA 7630 of 2020 IA NO:CAN/1/2020 Sarmistha Pandit Vs. State of West Bengal & Ors.
With WPA 8536 of 2020 Latarani As.
Vs. State of West Bengal & Ors.
With WPA 2898 of 2021 Moumita Paul Vs. State of West Bengal & Ors.
With WPA 2903 of 2021 Mousumi Ghosh Das Vs. State of West Bengal & Ors.
With WPA 7982 of 2021 Bapi Das Vs. State of West Bengal & Ors.
With WPA 8266 of 2021 Monika Sarkar.
Vs. State of West Bengal & Ors.
With WPA 10316 of 2021 Sabita Biswas Vs. State of West Bengal & Ors.
With WPA 10929 of 2021 Laxmi Paul.
Vs. State of West Bengal & Ors.
With WPA 16936 of 2021 Sk. Najirul Hoque & Ors.
Vs. State of West Bengal & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

With WPA 18475 of 2021 Ilias Sk Vs. State of West Bengal & Ors.
With WPA 19000 of 2021 Arpita Karmakar Vs. State of West Bengal & Ors.
With WPA 21312 of 2021 Srimanta Maity & Ors.
Vs. State of West Bengal & Ors.
With WPA 21386 of 2021 Arif Sarkar Vs. State of West Bengal & Ors.
With WPA 1637 of 2022 Debasish Chaudhury Vs. State of West Bengal & Ors.
With WPA 5405 of 2022 Priti Mukherjee Vs. State of West Bengal & Ors.
With WPA 5406 of 2022 IA NO:CAN/1/2022 CAN/3/2022 CAN/4/2022 CAN/5/2022
CAN/6/2022 CAN/7/2022 CAN/11/2023 CAN/12/2023 CAN/21/2023 CAN/22/2023
CAN/23/2023 CAN/24/2023 CAN/25/2023 CAN/26/2023 CAN/27/2024 CAN/28/2024
CAN/29/2024 CAN/32/2024 CAN/33/2024 CAN/34/2024 CAN/35/2024 CAN/36/2024
CAN/37/2024 CAN/38/2024 Babita Sarkar.
Vs. State of West Bengal & Ors.
With WPA 13431 of 2022 Sreejeeta Dey Vs. State of West Bengal & Ors.
With WPA 22845 of 2022 Abbasuddin Mollah Vs. State of West Bengal & Ors.
With WPA 25379 of 2022 Paly Debnath & Ors.
Vs. State of West Bengal & Ors.
With WPA 26756 of 2022 Baneshwar Bera & Ors.
Vs. State of West Bengal & Ors.
With WPA 27457 of 2022 Pradip Hait & Ors.
Vs. State of West Bengal & Ors.
With WPA 160 of 2023 Kuheli Ghosh Vs. State of West Bengal & Ors.
With MAT 199 of 2023 IA NO:CAN/1/2023 The West Bengal Central School Service Commission &
Ors.
Vs. Priyanka Shaw & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

With MAT 950 of 2023 IA NO:CAN/1/2023 Babita Sarkar.
Vs. State of West Bengal & Ors.
With WPA 1079 of 2023 Julekha Mandal Vs. State of West Bengal & Ors.
With WPA 1080 of 2023 Dipanwita Das Vs. State of West Bengal & Ors.
With WPA 1083 of 2023 Isha Sk. & Anr.
Vs. State of West Bengal & Ors.
With WPA 1086 of 2023 Rumki Sutradhar Vs. State of West Bengal & Ors.
With MAT 1302 of 2023 Tanmoy Sinha & Ors.
Vs. Babita Sarkar & Ors.
With MAT 1304 of 2023 Supratim Manna & Ors.
Vs. Babita Sarkar & Ors.
With WPA 2077 of 2023 IA NO:CAN/1/2023 Moumita Mondal & Ors.
Vs. State of West Bengal & Ors.
With WPA 2511 of 2023 Bulti Manna Vs. State of West Bengal & Ors.
With WPA 2982 of 2023 Dilip Kumar Mondal & Ors.
Vs. State of West Bengal & Ors.
With WPA 3463 of 2023 Monsur Rahaman.
Vs. State of West Bengal & Ors.
With WPA 4519 of 2023 Sumanta Suin & Ors.
Vs. State of West Bengal & Ors.
With WPA 4715 of 2023 Shilpi Saha Vs. State of West Bengal & Ors.
With WPA 7031 of 2023 Srimanta Ghorai Vs. State of West Bengal & Ors.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

With WPA 9315 of 2023 Biswajit Biswas & Ors.
Vs. State of West Bengal & Ors.
With WPA 10617 of 2023 Nandita Sarkar Vs. State of West Bengal & Ors.
With WPA 10724 of 2023 Ramjan Khan & anr.
Vs. State of West Bengal & Ors.
With WPA 14104 of 2023 Rita Sarkar (Das) Vs. State of West Bengal & Ors.
With WPA 18400 of 2023 Mihir Baral & Ors.
Vs. State of West Bengal & Ors.
With WPA 21210 of 2023 Falguni Dutta Vs. State of West Bengal & Ors.
With WPA 21999 of 2023 Bangiya Nyajya Adhikar Pratistha Mancha & anr.
Vs. State of West Bengal & Ors.
With WPA 22860 of 2023 Lipika Pal Vs. State of West Bengal & Ors.
With WPA 23204 of 2023 Apu Bej Vs. State of West Bengal & Ors.
With WPA 23652 of 2023 Mira Roy Vs. State of West Bengal & Ors.
With WPA 24930 of 2023 Arindam Sarkar & anr.
Vs. State of West Bengal & Ors.
With WPA 25669 of 2023 Shah Alamgir Vs. State of West Bengal & Ors.
For the petitioner in WPA 7592 of Mr. Bikash Ranjan Bhattacharyya, 2021 to WPA 13701/2021,WPA
Ld. Sr. Advocate 13727/2021 to WPA 21268/ 2021, Mr. Sudipta Dasgupta, WPA 781/2022, WPA
1618/2022, Mr. Bikram Banerjee, WPA 5786 of 2022 to WPA 7347 of Mr. Arkadeb Biswas,
2022,WPA 28197 of 2022, WPA Mr. Arka Nandi, 18401 of 2023, WPA 21211 of Ms. Dipa Acharyya
2023, WPA 18585 of 2021, WPA Mr. Sondwip Sutradhar, 20070/2021, WPA 8598 of 2022, Mr.
Saikat Sutradhar, WPA 14630/2022, WPA 27164 of Mr. Sutirtha Nayek, 2022, WPA 27166 of 2022,
WPA Ms. Shalini Ghosh, 27168/2022, WPA 18589/2021 to Ms. Sinjini Chakrabarti WPA
18593/2021, WPA Mr. Baibhav Roy 8614/2022, WPA 14634/2022, Ms. Sagarika Goswami WPA
27161/2022, WPA Mr. Sagar Dey 7616/2020, WPA 7630/2020, WPA Ms. Saptaparni Raha
7982/2021 to WPA 19000/2021, Ms. Suryatapa Das WPA 5405/2022, WPA 5406/2022, ...Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

WPA 2077/2023, WPA 3463/2023, Mr. Bikash Ranjan Bhattacharyya, WPA 18400/2023, WPA Ld.
Sr. Advocate.
21210/2023                               Mr. Firdous Samim,
                                         Ms. Gopa Biswas,
                                         Ms. Payel Shome,
                                         Ms. Sampriti Saha,
                                         Ms. Purba Mukherjee
                                         Mr. Avijit Kar,
                                         Ms. Mohona Das
For the appellant in MAT 950 of          Mr. Bikash Ranjan Bhattacharyya,
2023                                     Ld. Sr. Advocate
                                         Mr. Firdous Samim,
                                         Ms. Gopa Biswas,
                                         Ms. Payel Shome,
                                         Ms. Sampriti Saha,
                                         Mr. Avijit Kar,
                                         Ms. Mohona Das
For the respondents in MAT 85 of         Mr. Bikash Ranjan Bhattacharyya,
2023, MAT 124 of 2023, MAT 250           Ld. Sr. Advocate
of 2023 to MAT 382 of 2023, MAT          Mr. Firdous Samim,
1302 of 2023, MAT 1304 of 2023,          Ms. Gopa Biswas,
                                         Ms. Payel Shome,
                                         Ms. Sampriti Saha,
                                         Mr. Avijit Kar,
                                         Ms. Mohona Das
For the writ petitioners in WPA            Mr. Prasenjit Mukherjee
20045 of 2019, WPA 22119 of                Mr. Golam Mohiuddin,
2019, WPA 8078 of 2020, WPA                Ms. Puja Mondal
8555 of 2020, WPA 11455 of 2020,
WPA 13700 of 2021, WPA 17679 of
2023, WPA 8536 of 2020,
For  the   petitioner    in   WPA          Mr. Asish Kr. Chowdhury
19278/2019                                 Mr. Ashif Iquebal,
                                           Mr. Rameshwar Sinha,
                                           Ms. Debanjana Sen,
For the respondent no.6 to 8 in            Mr. Anindya Bose,
WPA 21665 of 2019.                         Mr. Apalak Basu,
                                           Mr. Arkadipta Sengupta,
                                           Ms. Pritha Bhaumik
                                           Ms. Aayushi MukherjeeBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

 For the petitioners in WPA 3846 of        Mr. Anindya Lahiri,
2023.                                      Mr. Arkadipta Sengupta,
                                           Ms. Aayeshi Mukherjee
For the writ petitioner in WPA             Mr. Milon Mukherjee, Sr. Adv.,
2967 of 2023                               Mr. Anindya Lahiri,
                                           Ms. Tannistha Lahiri,
                                           Mr. Samrat Dey Paul,
                                           Ms. Pranati Das,
                                           Mr. A. Chakraborty
For the petitioner in WPA 5406 of          Mr. Vishak Bhattacharya,
2022(CAN 12 of 2023).                      Ms. Biyanka Bhattacharya
For the added respondent of CAN            Mr. Sudip Ghosh Chowdhury,
27 of 2024 in WPA 5406 of 2022             Ms. Shreyeta Mitra
and WPA 10960 of 2021
 For the added party-respondent in        Mr. Ujjal Ray,
CAN 17 of 2023 in WPA 13700 of            Mr. Arpa Chakraborty
2021.
For the added respondents of CAN          Mr. Sakti Pada Jana
1 of 2023 in WPA 13700 of 2021            Mr. Subhajyoti Das
For the added respondents in WPA          Mr. Kalyan Kumar Bandopadhyay,
13700 of 2021                             Sr. Advocate
                                          Mr. Anindya Lahiri,
                                          Ms. Tannistha Lahiri,
                                          Mr. Samrat Dey Paul,
                                          Ms. Pranati Das,
                                          Mr. Anish Chakraborty
For the appellants in MAT                 Mr. Anindya Lahiri,
85/2023, WPA 5526/2023, WPA               Ms. Tannistha Lahiri,
5538 of 2022, WPA 25380 of 2022,          Mr. Samrat Dey Paul,
MAT 124 of 2023, MAT 245 of               Ms. Pranati Das,
2023, WPA 362 of 2023, WPA 5526           Mr. Anish ChakrabortyBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

of 2023, WPA 5531 of 2023, WPA
5797 of 2023, WPA 5799 of 2023,
WPA 6164 of 2023, WPA 10614 of
2023, WPA 18585 of 2021, WPA
7370/2023 and MAT 458 of 2023
and For the added respondents in
WPA 19273 of 2019, 19278 of
2019, 19749 of 2019,20776 of
2019, 20778 of 2019, 13700 of
2021, 1618 of 2022, 8059 of 2022,
5538 of 2022, 25380 of 2022,
10614 of 2023, 18585 of 2021,
12270 of 2021, 18475 of 2021,
2077 of 2023
For the respondent in WPA 362 of          Mr. Anindya Lahiri,
2023                                      Ms. Tannistha Lahiri,
                                          Mr. Samrat Dey Paul,
                                          Ms. Pranati Das,
                                          Mr. Anish Chakraborty
For the State in WPA 23761 of           Mr. Biswabrata Basu Mallick,Ld.
2023 and WPA 26848 of 2023              A.G.P.
                                        Ms. Mrinalini Majumdar
For the State in WPA 16858 of           Mr. Biswabrata Basu Mallick,Ld.
2021, WPA 1066 of 2023, WPA             A.G.P.
1070 of 2023, WPA 4206/2023,
WPA    15359   of  2022  WPA
19053/2022.
For the addition of party in WPA        Mr. Shaktipada Jana,
13700 of 2021.                          Mr. Subhojyoti Das
For the petitioner in WPA 366 of        Mr. Amitava Choudhuri,
2024.                                   Mr. N. Roy,
                                        Mr. Chandan Chakraborty
For the State in WPA 2613 of            Mr. Arindam Chattopadhyay,
2018, WPA 18034 of 2018, WPA            Ms. Lipika Chatterjee
19749 of 2019, WPA 8614 of 2022,
WPA 5406 of 2022, WPA 16936 of
2021, MAT 1302 of 2023, WPA
1080 of 2023, WPA 1072 of 2023,Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

WPA 18627 of 2019,          WPA
3846/23, MAT 199 of 2023, WPA
6213 of 2023 WPA 20070 of 2021,
WPA 2903 of 2021 WPA 10316 of
2021 WPA 3463 of 2023
For the addition of party in WPA        Mr. S.P. Lahiri,
13700 of 2021, WPA 5406 of 2022. Mr. Rajesh Naskar For the appellant in MAT 244 of Mr. Soumya
Majumdar, 2023. Mr. Puspal Chakraborty, Ms. Prisanka Ganguly, Mr. Soumyadeep Sarkar For the
writ petitioner in WPA Mr. Puspal Chakraborty, 4556 of 2023 Mr. Prisanka Ganguly, Mr.
Soumyadip Sarkar For the added respondent in WPA Mr. Anirban Sen, 5406 of 2022 Mr. Anindya
Lahiri Mr. Samrat Dey Paul Ms. Pranati Das Mr. Anish Chakraborty For the added respondent in
MAT Mr. Soumya Majumdar, 1302/2023 Mr. Anindya Lahiri Mr. Puspal Chakraborty, Mr. Samrat
Dey Paul Ms. Pranati Das Mr. Anish Chakraborty For the writ petitioners in WPA Mr. Puspal
Chakraborty, 4556 of 2023 Ms. Prisanka Ganguly, Mr. Soumyadeep Sarkar For the added
respondent nos.476 Mr. Amiya Kumar Datta, to 642 in WPA 12270 of 2021. Mr. Dipanjan
Chatterjee, Mr. Swadesh Priyo Ghosh, Mr. Santanu Talukdar, Ms. Sananda Bhattacharya, Ms. Barna
Das For the added respondent nos.9 to Mr. Amiya Kumar Datta, 20 in WPA 20022 of 2019. Mr.
Dipanjan Chatterjee, Mr. Swadesh Priyo Ghosh, Mr. Santanu Talukdar, Ms. Sananda Bhattacharya,
Ms. Barna Das For the respondent nos.118 to 362 Mr. Kalyan Bandopadhyay, Ld. Sr. in WPA 18585
of 2021 and for the Advocate applicants in CAN 11 of 2024 and Mr. Suman Sengupta, CAN 12 of
2024. Mr. Rahul Kumar Singh For the State in WPA 22522 of Mr. Sirsanya Bandopadhyay, Ld.
2018, WPA 13700 of 2021, WPA Jr. Standing Counsel 25380 of 2022, WPA 12270 of 2021, WPA
14525 of 2022, WPA 5406 of 2022, MAT 85 of 2023, MAT 557 of 2023, MAT 250 of 2023, MAT 274
of 2023, WPA 5393 of 2023.
For the SSC in WPA 2613 of 2018, Mr. Kanak Kiran Bandopadhyay WPA 20778 for 2019, WPA
21923 of 2019, WPA 18034 of 2018, WPA 20039 of 2019, WPA 30065 of 2017, WPA 8536 of 2020,
WPA 18627 of 2029, WPA 18352 of For the State in WPA 16859 of Mr. Supriyo Chattopadhyay, Ld.
2021, WPA 18385 of 2021, WPA AGP 19478 of 2021, WPA 21332 of Ms. Iti Dutta 2022, WPA 20022
of 2019.
For the WBBSE Ms. Koyeli Bhattacharyya For the added respondents in WPA Mr. Sudip Ghosh
Chouwdhury 5406 of 2022, WPA 10964 of 2021. Ms. Shreyata Mitra For the applicant in WPA
18585 of Mr. Pramit Kumar Roy, 2021. Ms. Sahedli Sen, Mr. Rajiv Mullick, Ms. Ayantika Saha, Mr.
A. Bandopadhyay For the applicant in CAN 6 of 2024 Mr. Shaunak Ghosh, in WPA 18585 of 2021
and in CAN Mr. Rajib Mullick, 7 of 2024 in WPA 25380/22. Ms. Ayantika Saha, Mr. Anindya
Sundar Das, Mr. R. D. Banerjee For the applicant in CAN 7 of 2024 Mr. Pramit Kumar Ray, Ld. Sr.
in WPA 18585 of 2021. Advocate Mr. Shaunak Ghosh, Ms. Saheli Sen, Mr. Rajib Mullick, Ms.
Ayantika Saha For the applicant in WPA 25380 of Mr. Siddhartha Banerjee, 2022, MAT 304 of
2023, For the Mr. Rajiv Mullick, petitioners in WPA 7952 of 2023, Ms. Ayantika Saha CAN 5 of
2024 in WPA 25380 of 2022.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

For the applicant in CAN 7 of 2024 Mr. Sounak Ghosh, in WPA 25380 of 2022. Mr. Anindya Sundor
Das, Mr. R. D. Banerjee For the petitioner in WPA 20045 of Mr. Prasenjit Mukherjee 2019, WPA
22119 of 2019, WPA Mr. Golam Mohiuddin 8078 of 2020 to WPA 11455 of Ms. Puja Mondal 2020,
WPA 13700 of 2021, wpa 17679 OF 2023, WPA 18352 of 2019, WPA 8536 of 2020 For the
applicants in CAN 21 of Mr. L.K. Gupta, Ld. Sr. Advocate 2023 and CAN 22 of 2023 in WPA Mr. S.
Banerjee, 5406 of 2022. Mr. A.B. Das, Ms. S. Chongdar, Mr. S.N. Ghosh For the applicant in CAN 3
of Mr. Jaydip Kar, Ld, Sr. Advocate 2023 and CAN 4 of 2023 in WPA Mr. Abhratosh Majumdar, Ld.
Sr. 25380 of 2022, and appellant in Advocate MAT 290 of 2023. Mr. Siddhartha Banerjee, Mr. A.B.
Das, Ms. S. Chongdar, Mr. S.N. Ghosh For the petitioner in MAT 304 of Mr. Jaydip Kar, Ld. Sr.
Advocate 2023, MAT 557 of 2023, WPA 5953 Mr. Siddhartha Banerjee, of 2023. Ms. Saheli Sen, Mr.
Rajib Mullick, Ms. Ayantika Saha For the petitioner in WPA 7952 of Mr. Siddhartha Banerjee, 2023,
the applicant in CAN 5 of Mr. Rajib Mullick, 2023 in WPA 25380 of 2022. Ms. Ayantika Saha For
the applicant in CAN 21/23/ Mr. L. K. Gupta, Sr. Advocate CAN 22/23 in WPA 5405 of 2022. Mr.
Siddhartha Banerjee, Mr. Abhisek Baran Das, Mrs. Srijoni Chongdar, Mr. Sudipta Nayan Ghosh For
the applicant in CAN 3/23 Mr. L. K. Gupta, Sr. Advocate CAN 4/23 in WPA 25380 of 2022. Mr.
Siddhartha Banerjee, Mr. Abhisek Baran Das, Mrs. Srijoni Chongdar, Mr. Sudipta Nayan Ghosh For
the petitioners in WPA 5953 of Mr. Joydeep Kar, Ld. Sr. Advocate 2023. Mr. Abhrotosh Majumdar,
Mr. Siddhartha Banerjee, Ms. Saheli Sen, Mr. Rajiv Mallick, Ms. Ayantika Saha For the applicant in
CAN 3 of 2024 Mr. Sourav Sengupta in MAT 85 of 2023.
For the State in WPA 23652 of Mr. Bhaskar Prasad, Vaisya, Ld. 2023. AGP Mr. Gourav Das For the
State in WPA 16484 of Ms. Rupsha Chakrbaorty For the appellant in MAT 476 of Mr. Tapas Singha
Roy 2023.
For the petitioner in WPA 14670 of Ms. Lakshmi Shaw 2022.
For the addition of parties in MAT Mr. P.S. Bhattacharyaa, 458 of 2023. Mr. G.K. Das, Mr. Kapil
Chandra Sahoo For the ED in WPA 13700 of 2021, Mr. Dhiraj Kumar Trivedi, LD.
WPA 13701 of 2021, WPA 17273 of           DSGI
2021, WPA 5538 of 2022, WPA               Mr. Samrat Goswami
12266 of 2021, WPA 12270 of
2021 and WPA 5406 of 2022.
For CAN 23 of 2023 and CAN 31 of          Mr. S.P. Lahiri,
2024 in in WPA 13700 of 2021 and          Mr. Rajesh Naskar
the applicant in CAN 23, 24 & 25
in WPA 5406 of 2022.
For the respondent no.4 in WPA            Mr. Rittwik Pattanayak,
18355 of 2019. Mr. Prosenjit Debnath For the respondent no.641 and Mr. Rittwik Pattanayak 642 in
WPA 18593 of 2021.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

For the applicant of CAN 22 of Mr. Pratik Dhar, Sr. Adv., 2023 in WPA 13700 of 2021. Mr. Rittwik
Pattanayak, Mr. S. Khandakar, Mr. S. Ghosh, Ms. Swati Jha For the MAT No. 457 of 2023 Mr.
Sakhawat Khandakar Mr. Sounak Ghosh Ms. Swati Jha For the petitioner in WPA 366 of Mr.
Amitava Chowdhury, 2024. Mr. Moniruzzaman, Mr. N. Roy, Mr. Chandan Chakraborty For the
applicant in WPA 5406 of Mr. Arup Kumar Lahiri, 2022. Mr. Debojyoti Dey For the applicant in
WPA 18381 of Mr. Partha Sarathi Das, 2021. Md. Hafiz Ali, Mr. Debojyoti Dey, Mr. Shanta Sarkar
For the appellant in MAT 259 of Mr. Anindya Bose, 2023. Mr. Soumyo Sankar Chini For the
respondent no.7 in WPA Mr. Anindya Bose, 21665 of 2019. Ms. Snehal Seth For the petitioner in
WPA 6282 of Mr. Anindya Bose 2023.
For the petitioner in WPA 1369 of Mr. Sudipta Das Gupta For the respondent nos.6,7 and 8 Mr.
Anindya Bose, in WPA 4556 of 2023. Mr. Arkadipta Sengupta, Ms. Pritha Bhowmik, Mr. Apalak
Basu For the added respondent nos. 6 to Mr. Arkadipta Sengupta 8 in WPA 21665 of 2019 Ms.
Pritha Bhaumicki Mr. Apalak Basu For the appellant in MAT 259 of Mr. Anindya Bose 2023 Mr.
Soumya Sankar Chini For the State in WPA 3399 of Mr. Munmun Tewary, 2023, WPA 3990 of
2023. Mr. Sanatan Panja For the added respondents in WPA Mr. Shaktipada Jana, 13700 of 2021.
Mr. Subhojyoti Das For the appellant in MAT 443 of Mr. Partha Sarathi Deb Barman, 2023, MAT
502 of 2023, MAT 470 Mr. Shaharaya Alam, of 2023, MAT 521 of 2023, MAT Mr. M. Nazar
Chowdhury, 250 of 2023, MAT 274 of 2023, Mr. Amit Gupta, MAT 334 of 2023 (Item No.135) to
Mr. R. D. Banerjee, MAT 382 of 2023 (Item No.146). Mr. Raja Adhikary For the added party in MAT
250 of Mr. Rajnil Mukherjee, 2023. Mr. M.F. Rahaman, Ms. Debolina Sarkar, Mr. M.F. Rahaman,
Mr. Subham Das, Ms. Satabdi Dey For the addition of party in WPA Mr. Keshab Chandra Das 13700
of 2021.
For the petitioner in WPA 23259 of        Mr. Ali Ahsan Alamgir,
2019                                      Ms. Rabia Khatoon,
                                          Ms. Soma Mal,
                                          Ms. June Modak,
                                          Mr. Juel Rana
For the applicant in WPA 13700 of        Mr. Raju Bhatacharyya
2021.
For the WBCSSC                           Dr. Sutanu Kumar Patra,
                                         Ms. Supriya Dubey,
                                         Mr. Sunit Roy
                                         Ms. Debolina Chakraborty
For the added respondent nos.363         Mr. Dilip Kumar Maity,Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

to 408 and 803 In WPA 18585 of           Mr. Chandan Maity
2021.
For        the         respondent        Mr. Subir Sanyal,
nos.21,25,27,30,39,40,41,411,422         Mr. Chitto Priya Ghosh,
,413 in WPA 12266 of 2021, For           Mr. Sourajit Mukherjee,
the added respondent nos.9-20 in         Mr. Amiya Kumar Datta,
WPA 20022 of 2019, For the added         Mr. Dipanjan Chatterjee,
respondent nos.476-642 in WPA            Mr. Swadesh Priya Ghosh,
12270 of 2021                            Mr. Santanu Talukdar,
                                         Ms. Sananda Bhattacharya,
                                         Ms. Barna Das
For the applicant in WPA 5406 of         Mr. Samrat Dey Paul,
2022 and For the respondents in          Ms. Proniti Das,
WPA 362 of 2023                          Mr. Anish Chakraborty
For the writ petitioners in WPA          Mr. Ashis Kumar Chowdhury,
12662 of 2018, WPA 22777 of              Mr. Rajiv Ghosh,
2018, WPA 21312 of 2021                  Mr. Babhru Bahan Bera
For the State in WPA 16450 of 21,        Mr. Supriyo Chattopadhyay,
WPA 18994 of 21, WPA 21430 of            Ms. Sayantanee Bhattacharjee
21, WPA 4313 of 23, WPA 8598 of
22, WPA 18590 of 21, MAT 458 of
23, WPA 19000 of 21 and WPA
10617 of 23
For the State in WPA 2496 of 2023        Mr. Malay Singh
                                         Ms. Neelam Singh
For the State in MAT 480 of 2023         Mr. Jayanta Samanta, Jr. Govt.
                                         Adv.
                                         Mr. Kushal Biswas
For the State in WPA 22523 of 18         Mr. Sanjib Das
and added respondent no.15, in
WPA 18585 of 2021Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

For the added parties/applicants         Mr. Partha Sarathi Bhattacharyya,
in WPA 5406 of 2022.                     Ld. Sr. Adv.,
                                         Mr. Nilankan Banerjee
For the added parties/applicants         Mr. P. S. Bhattacharyya, Ld. Sr.
in CAN/29/24, CAN/30/24 in               Adv.,
WPA 13700 of 2021                        Mr. Nilankan Banerjee
For the writ petitioners in WPA          Mr. Ashis Kumar Chowdhury,
22522 of 2018 to WPA 22973 of            Mr. Rajib Ghosh,
2018, WPA 21923 of 2019, WPA             Mr. Babhru Bahan Bera
4835 of 2020, WPA 21317 of 2021,
WPA 21332 of 2022 to WPA 21350
of 2022, WPA 3859 of 2023, WPA
6859 of 2023, WPA 9327/2023,
WPA 9315/23, WPA 12662/18 to
WPA 22971 of 2018, WPA 21312 of
2021, WPA 9315 of 2023, WPA
14104 of 2023, WPA 21999 of
2023, WPA 25669 of 2023 WPA
4715 of 2023
For the petitioners in WPA 16844         Mr. Ashis Kumar Chowdhury,
of 2019 to WPA 21665 of 2019,            Mr. Rajib Ghosh,
WPA 21923 of 2019, WPA 10387 of          Mr. Babhru Bahan Bera
2023, WPA 24247 of 2023, WPA
18352 of 2019, WPA 8003 of 2021,
WPA 7982 of 2021, WPA 22860 of
2023, WPA 7982 of 2021, WPA
22971 of 2018, WPA 21154 of
2019,
For the applicants in MAT 284 of         Mr. Rajiv Ghosh
For the applicants in WPA 2967 of        Mr. Milon Mukherjee, Ld. Sr. Adv.,
2023.                                    Mr. Anindya Lahiri,
                                         Ms. Tannistha Lahiri,
                                         Ms. Pranati Das,
                                         Mr. Samrat Dey Paul,
                                         Mr. Anish ChakrabortyBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

For the applicants in WPA 5538 of        Mr. Pratik Dhar, Ld. Sr. Avocate
2022, WPA 25380 of 2022, MAT 85          Mr. Anindya Lahiri,
of 2023 to MAT 245 of 2023, WPA          Ms. Tannistha Lahiri,
5526 of 2023, MAT 458 of 2023,           Ms. Pranati Das,
WPA 6164 of 2023, WPA 18585 of           Mr. Anish Chakraborty
2021, WPA 5406 of 2022, MAT
1302 of 2023 MAT 124 of 2023,
WPA 10614 of 2023, WPA 18470 of
2021.
For the added respondents in WPA         Mr. Kalyan Bandyapadhyay, Ld.
13700 of 2021.                           Sr. Adv.,
                                         Mr. Anindya Lahiri,
                                         Ms. Tannistha Lahiri,
                                         Mr. Samrat Dey Paul,
                                         Ms. Pranati Das,
                                         Mr. Anish Chakraborty
For the added respondent WPA             Mr. Kalyan Bandyapadhyay, Ld.
16844 of 2019 to WPA 5786 of             Sr. Adv.,
2022                                     Mr. Anindya Lahiri,
                                         Ms. Tannistha Lahiri,
                                         Ms. Pranati Das,
                                         Mr. Anish Chakraborty
For the added respondent WPA             Mr. Anindya Lahiri,
19273 to WPA 20778 of 2019, WPA          Ms. Tannistha Lahiri,
1618/2022, WPA 5538 of 2022,             Mr. Samrat Dey Paul
WPA       25380/2022,       WPA          Ms. Pranati Das,
10614/2023, WPA 18585/2021,              Mr. Anish Chakraborty
WPA 18585 of 2021, WPA 2077 of
For the respondent Nos. 118 to           Mr. Kalyan Kumar Bandopadhyay,
362 in W.P.A. 18585 of 2021 and          Sr. Adv.,
for the applicants in CAN 11 & 12        Mr. Suman Sengupta,
of 2024                                  Mr. Rahul Kumar Singh
For the appellant in WPA 7370 of         Mr. Anindya Kumar Mitra, Ld. Sr.
2023.                                    Adv.,
                                         Mr. Anindya Lahiri,Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

                                         Ms. Tannistha Lahiri,
                                         Mr. Samrat Dey Paul,
                                         Ms. Pranati Das,
                                         Mr. Anish Chakraborty
For the applicants in CAN 5 of           Mr. Anindya Kumar Mitra, Ld. Sr.
2021 in WPA 12266 of 2021, For           Adv.,
the appellants in MAT 334 of 2023        Mr. P.S. Deb Barman,
to MAT 343 of 2023, MAT 345 of           Mr. Debasis Nandi
2023, MAT 359 of 2023 to MAT             Mr. Amit Gupta,
382 OF 2023, WPA 12270 of 2021,          Mr. Aninda Bose,
MAT 443 of 2023, MAT 502 of              Mr. Raja Adhikary,
2023, MAT 470 of 2023 MAT 521            Mr. S. Alam,
of 2023, MAT 250 of 2023, MAT            Md. M. Nazar Chowdhury,
274 of 2023, applicants of CAN 7         Mr. Marghoob Ahmed Salik
of 2023, CAN 9 of 2024 and CAN           Mr. R. D. Banerjee
10 of 2024 in WPA 12270 of 2021,
applicants of CAN 32 of 2024 and
CAN 38 of 2024 in WPA 5406 OF
2022, applicants of CAN 5 of 2023
and CAN 10 of 2024 in WPA 18585
of 2021.
For the State in WPA 24247 of            Mr. Avijit Sarkar,
2023                                     Mr. Suman Singh
For the writ petitioner in WPA           Mr. Mukul Lahiri, Ld. Sr. Adv.,
12270 of 2021                            Mr. Anindya Lahiri,
                                         Ms. Tannistha Lahiri,
                                         Mr. Samrat Dey Paul,
                                         Ms. Pranati Das,
                                         Mr. Anish Chakraborty
For the applicants in MAT 244 of         Mr. Soumya Majumder,
2023, WPA 4556 of 2023, MAT              Mr. Anindya Lahiri,
1302 of 2023, WPA 5406/2022              Ms. Tannistha Lahiri,
                                         Mr. Puspal Chakraborty,
                                         Mr. Samrat Dey Pal,
                                         Ms. Pranati Das,
                                         Mr. Prisanka Ganguly,
                                         Mr. Soumyadeep Sarkar
For the petitioner in WPA 3859 of        Mr. Subrata BhattacharjeeBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

2023, WPA 6210 of 2023, WPA
6213 of 2023 & WPA 6859 of 2023
For the appellant in MAT 1302 of         Mr. Soumya Majumder,
2023                                     Mr. Anindya Lahiri,
                                         Ms. Tannistha Lahiri,
                                         Ms. Pranati Das,
                                         Mr. Prisanka Ganguly,
                                         Mr. Anish Chakraborty
For the added respondents in WPA         Mr. Anirban Sen,
5406 of 2022                             Mr. Anindya Lahiri,
                                         Mr. Samrat Dey Paul,
                                         Ms. Pranati Das,
                                         Mr. Anish Chakraborty
For the added respondent in WPA          Mr. Anirban Sen,
25380 of 2022                            Mr. Anindya Lahiri,
                                         Mr. Samrat Dey Paul,
                                         Ms. Pranati Das,
                                         Mr. Anish Chakraborty
For the respondent in WPA 362 of         Mr. Anindya Lahiri,
2023                                     Ms. Tannistha Lahiri,
                                         Mr. Samrat Dey Paul,
                                         Ms. Pranati Das,
                                         Mr. Anish Chakraborty
For the respondent in WPA 3846 of        Mr. Anindya Lahiri,
2023                                     Mr. Arkadipta Sengupta,
                                         Ms. Aayushi Mukherjee
For the petitioner in WPA 4556 of        Mr. Puspal Chakraborty,
2023                                     Mr. Prisanka Ganguly,
                                         Mr. Soumyadip Sarkar
For the added respondent nos.9 to        Mr. Biswaroop Bhattacharya,
20 in WPA 12270 of 2021 and For          Mr. Sumitava Chakraborty,
the added respondent nos.476 to          Ms. Bratati Pramanick
640 in WPA 20022 of 2019Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

For the added respondents in WPA         Mr. Biswaroop Bhattacharyya,
5406 of 2022                             Mr. Pratik Majumdar,
                                         Mr. Snehasish Dey
For the appellants in MAT 318 of         Mr. Utkarsh Kaushik,
2023, MAT 276 of 2023                    Ms. Devyani Ashra
For the writ petitioner in WPA           Mr. Anindya Lahiri,
3846 of 2023                             Mr. Arkadipta Sengupta,
                                         Ms. Aayushi Mukherjee
For the writ petitioner in WPA           Mr. Puspal Chakraborty,
4556 of 2023                             Mr. Prisanka Ganguly,
                                         Mr. Soumyadip Sarkar
For the added respondents in WPA           Mr. Anindya Lahiri,
19273 of 2019, WPA 19278 of                Ms. Tannistha Lahiri,
2019, WPA 19749 of 2019, WPA               Mr. Samrat Dey Paul,
20776 of 2019, WPA 20778 of                Ms. Pranati Das,
2019, WPA 7532/2023, WPA                   Mr. A. Chakraborty
2077/2023, WPA 18475/21, WPA
10614 of 2023
For the appellants/writ petitioners        Mr. Anindya Lahiri,
MAT 85 of 2023, MAT 124/23,                Ms. Tannistha Lahiri,
MAT 245/23, WPA 5526/23, WPA               Mr. Samrat Dey Paul,
6164/23, WPA 5531/23, WPA                  Ms. Pranati Das,
5797 of 2023, WPA 5799/23. Mr. A. Chakraborty For the added respondent in WPA Mr. Mukul
Lahiri, Sr. Adv., 12270 of 2021 Mr. Anindya Lahiri, Ms. Tannistha Lahiri, Mr. Samrat Dey Paul, Ms.
Pranati Das, Mr. A. Chakraborty For the respondent nos. 385 and Mr. Ranajit Chatterjee, 386 in
WPA 5406 of 2022 Mr. Aniruddha Mitra For private respondent Nos. 6 & 7 Mr. Partha Sarkar in
WPA 13701 of 2021 and private respondent no. 6 in WPA 10949 of 2021 and Private respondent no.
6 in WPA 13863 of 2021 and private respondent no. 7 in WPA 18487 of 2021.(candidates for Classes
IX & X) For the petitioner in WPA 5134 of Md. Sarwar Jahan, 2023 Ms. Tapati Sarkar For the
petitioner in WPA 3476 of Mr. Rama Haldar For the applicant in CAN 9 of 2024 Mr. Anindya Lahiri,
in WPA 18585 of 2021 Ms. Pranati Das, Mr. Souvik Dere, Mr. Anis Chakraborty For the respondent
nos. 6 and 7 in Mr. Susanta Pal, WPA 20404 of 2019 Mr. Prabir Kumar Ray, Mr. Debasish Kar For
the appellants in MAT 276 of Mr. Utkarsh Kaushik, 2023 and MAT 318 of 2023 Ms. Devyani Ashra
For the CBI Mr. Dhiraj Trivedi, LD. DSGI Mr. Arijit Majumdar, Ms. Supriti Sarkhel For the State inBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

WPA 16844 OF Mr. Anirban Ray, Ld.G.P., 2019, WPA 19273/2019, WPA Mr. Bhaskar Prasad
Vaisya, Ld. 19278/2019, WPA AGP, 21665/2019,WPA 15137 OF 2021, Mr. Suman Dey WPA
17273/2021, WPA 18379/2021, WPA 18470/2021, WPA 5810/23, WPA 18475/2021, WPA
21261/2021, WPA 27164/2022, WPA 12662/2018, WPA 21268 OF 2021,WPA 1079 OF 2023, WPA
2077/23, WPA 3846 OF 2023, , WPA 8059 OF 2022, WPA 13105 OF 2018, WPA 5604 OF 2023,
WPA 9105 OF 2023 For the State in WPA 4841 of 2023 Mr. Anirban Ray, Ld. G.P., Mr. Bhaskar
Prasad Vaisya, A.G.P., Mr. Sanjib Das For the State in WPA 16481/2021, Mr. Anirban Ray, Ld. G.P
WPA 16948/ 2021, WPA Mr. Bhaskar Prasad Vaisya, Ld. 18801/2021, WPA25380/2022, AGP, WPA
30065/2017, WPA 1083/23 Mr. Mrinal Kanti Ghosh WPA 19060 OF 2022, WPA 6859/23 For the
State in WPA 13863 of Mr. Bhaskar Prasad Vaisya, Ld. 2021, WPA 12266 of 2021 AGP, Mr. Niloy
Baran Mondal For the State in WPA 13863 of Mr. Anirban Ray, GP 2021, WPA 12266 of 2021 Mr.
Bhaskar Prasad Vaisya, Ld. AGP, Mr. Joydip Banerjee For the State in WPA 23652/2023 Mr.
Bhaskar Prasad Vaisya, Ld. AGP, Mr. Gourav Das For the State in WPA 22785/2018, Mr. Anirban
Ray, Ld. G.P. WPA 16487 OF 2021, WPA Mr. Bhaskar Prasad Vaisya, Ld. 16960/2021, WPA
18379/2021, AGP, WPA 18995/2021, WPA Mr. Sagnik Chatterjee 5538/2022, WPA 7346/2022,
WPA 21334/2022, WPA 20034/2019, WPA 18401/23, WPA 27168/23, WPA 1072 OF 2023, WPA
10213/22, WPA 18400/23, WPA 21999 OF 2023 For the State in WPA 19749/2019, Mr. Anirban
Ray, Ld. GP WPA 8264/2021, WPA Mr. Bhaskar Prasad Vaisya, Ld. 16487/2021, WPA 18381 /2021,
AGP, WPA 20906/2021, WPA 1072 OF Mr. Arindam Chattopadhyay, 2023, WPA 6213 OF 2023,
WPA 8614/2022, WPA 16936/2021, WPA 5406/2022, WPA 1080 OF For the State in WPA 16968 of
Mr. Bhaskar Prasad Vaisya, 2021, WPA 19477/2023 Mr. Pinaki Bhattacharyya For the State in WPA
21266 of Mr. Anirban Ray, Ld. GP 2021, WPA 21267 of 2021, WPA Mr. Bhaskar Prasad Vaisya, Ld.
21340 of 2021, WPA 6550 of 2022 AGP, Mr. Ranjan Saha For the State in WPA 18589 of Mr.
Bhaskar Prasad Vaisya, Ld. 2021 AGP, For the State in WPA 23652 of Mr. Bhaskar Prasad Vaisya,
Ld. 2023, WPA 30065 of 2017 AGP, Mr. Gourab Das For the State in WPA 13863/21, Mr. Bhaskar
Prasad Vaisya, Ld. WPA 12266/21 AGP Mr. Nilay Baran Mandal For the State in WPA 24247 of Mr.
Avijit Sarkar, 2023 Ms. Suman Singh For the WBBSE Ms. Koyeli Bhattacharyya For the respondent
no.6 in WPA Mr. Tanmoy Biswas, 16844 of 2019. Ms. Antara Mukherjee For the applicant/added
party in Mr. Partha Sarathi Bhattacharya, CAN 29 of 2024, CAN 30 of 2024 Sr. Adv., and for
respondent no.6 in WPA Mr. Nilankan Banerjee 13700 of 2021 and WPA 5406 of 2022 in CAN 28 of
2024 For the petitioners in WPA 6210 of Mr. Partha Sarathi Bhattacharya, 2023 and WPA 6213 of
2023 Sr. Adv., Mr.Nilankan Banerjee For the petitioners in WPA 13700 Mr. Partha Sarathi
Bhattacharyya, of 2021. Ld. Sr. Advocate Mr. Anindya Bose, For the added parties in CAN 2 of Mr.
Partha Sarathi Bhattacharyya, 2023 in MAT 458 of 2023 Ld. Sr. Advocate Mr. G.K. Das, Mr. Kapil
Chandra Sahoo For the applicants of CAN 19 of Mr. Anindya Bose 2023 in WPA 13700 of 2021 For
the State in WPA 20776 of Mr. Santanu Kr. MIira, 2019 & WPA 16505 of 2021 Mr. Amartya Pal For
the added respondent nos. 476 Mr. Amiya Kumar Dutta, to 642 in WPA 12270 of 2021 and Mr.
Dipanjan Chatterjee, added respondent nos. 9-20 in Mr. Swadesh Priya Ghosh, WPA 20022 of 2019
Mr. Santanu Talukdar, Ms. Sananda Bhattacharya, Mr. Barna Das For the added respondents in
WPA Mr. Sudip Ghosh Chowdhury, 10960 of 2021 and WPA 5406 of Ms. Shreyeta Mitra 2022 with
CAN 27 of 2024 For the appellant in MAT 476 of Mr. Tapas Singha Roy For the petitioner in WPA
366 of Mr. Amitava Chaudhuri, 2024 Mr. N. Ray, Mr. Chandan Chakraborty For the added
respondent in CAN Mr. S. N. Mukherjee, sr. adv.
13 of 2021 in WPA 13700 of 2021           Mr. Niraj Gupta,Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

                                          Ms. Afroja Nusrat,
                                          Mr. Hafizul Islam
For the petitioner in WPA 18034 of        Mr. Kamal Mishra,
2018                                      Mr. Pratap Sanfui
For the added parties in CAN 2 of         Mr. Gourango Das,
2023 in MAT 1458 of 2023                  Mr. Kapil Chandra Sahoo
For  the   petitioner in   WPA            Mr. Sankar Prasad Dalapati,
4117/23, WPA 4213 of 2023, WPA            Mr. Pritam Chowdhury,
6577 of 2023 and WPA 160 of               Mr. Safik Dewan,
2023                                      Mr. Sourav Mondal
For   the   applicant in   WPA            Mr. Tamal Taru Panda
30065/2016, WPA 5406/2022 (CAN
26/2024)
For the applicant in CAN 12 of            Mr. Vishak Bhattacharya,
2023 in WPA 5406 of 2022                  Ms. Ruchika Chatterjee,
                                          Ms. Biyanka Bhattacharya
For the petitioner in WPA 362 of          Mr. Dibyendu Chatterjee,
2023                                      Mr. Pritam Majumdar,
                                          Mr. Rahul Deb Goenka,
                                          Mr. Mainak Singh Barma
For the added party in CAN 26 of          Mr. Arup Kr. Lahiri,
2023 in WPA 5406 of 2022                  Mr. Debojyoti De
For the petitioner in WPA 18627 of        Mr. Santanu Maji,
2019, WPA 23946 of 2019,WPA               Ms. Sayani Biswas
19053 of 2022 and WPA 19060 of
For the added party in CAN 1 of           Mr. Partha Sarathi Das,
2023 in WPA 18381 of 2021                 Md. Hyafiz Ali,
                                          Mr. Shanta Sarkar,
                                          Mr. Debojyoti De
For the ED                                Mr. Dhiraj Triwedi, Ld. DSGBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

                                          Mr. Samrat Goswami
For the CBI                               Mr. Dhiraj Trivedi
                                          Mr. Arijit Majumder
                                          Ms. Supriti Sarkhel
For the respondent no.4 in WPA            Mr. Ritwik Pattanayak,
18355 of 2019                             Mr. Prasenjit Debnath
For the applicants in CAN 22 of           Mr. Pratik Dhar, Ld. Sr. Advocate
2023 in WPA 13700 of 2021                 Mr. Ritwik Pattanayak,
                                          Mr. S. Khandakhar,
                                          Mr. S. Ghosh,
                                          Ms. Swati Jha
For the respondent nos.641 & 642          Mr. Ritwick Pattanayak
in WPA 12270 of 2021
For the respondent no.4 in WPA            Mr. Ritwick Pattanayak,
18355/2019                                Mr. Prasenjit Debnath
For the applicant CAN 6 of 2024 in        Mr. Jayanta Mitra, Ld. Sr.
WPA 25380 of 2022                         Advocate
                                          Mr. Yuvraj P. Narvankar, Ld. Sr.
                                          Advocate
                                          Mr. Supratim Dhar,
                                          Ms. Madhupriya,
                                          Mr. Hebzur Rahaman
For the added respondent nos. 3,          Mr. Kamalesh Bhattacharya,
5, 6 & 7 in WPA 18355 of 2019             Mr. Mahadeb Sarkar,
                                          Mr. Bikash Chowdhury
For the petitioners in WPA 4313 of        Ms. Kakoli Samajpaty
2023                                      Ms. Sangita Jangra
                                          Mr. Subhronil Roy
For the appellant in MAT 85 of            Mr. Arunava Ghosh,
2023                                      Mr. Anindya Lahiri,
                                          Ms. Tannistha Lahiri,
                                          Mr. Samrat Dey Paul,
                                          Mr. Pranati Das,
                                          Mr. Anish ChakrabortyBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

For the added respondent in WPA           Mr. Kalyan Bandopadhyay,         Sr.
13700 of 2021                             Adv.,
                                          Mr. Anindya Lahiri,
                                          Ms. Tannistha Lahiri,
                                          Mr. Samrat Dey Paul,
                                          Mr. Pranati Das,
                                          Mr. Anish Chakraborty
For the writ petitioner in WPA            Mr. Milon Mukherjee, Sr. Adv.,
2967 of 2023                              Mr. Anindya Lahiri,
                                          Ms. Tannistha Lahiri,
                                          Mr. Samrat Dey Paul,
                                          Mr. Pranati Das,
                                          Mr. Anish Chakraborty
For the petitioner in WPA 4313 of          Ms. Kakali Samajpaty,
2023                                       Ms. Sangita Jangra
                                           Mr. Subranil Ray
For the respondent no. 4 in WPA            Ms. Kakali Samajpaty,
21430 of 2021                              Ms. Sangita Jangra
                                           Mr. Subranil Ray
For the added respondent in CAN            Mr. Sankar Nath Mukherjee
13 of 2023 in WPA 13700 of 2021            Mr. Niraj Gupta
                                           Ms. Afroja Nusrat
For the applicant in MAT 345 of            Ms. Debyani Ashra
2023, MAT 359 of 2023
For the SSC in WPA 2613/2018,              Mr. Kanak Kiran Bandyoapdhyay
WPA       18627/2019,     WPA
21923/2019, WPA 18034/2018,
WPA       20039/2019,     WPA
For the added respondent in WPA            Mr. Ranajit Chatterjee,
5406 of 2022                               Mr. Aniruddha MitraBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

For the applicant in CAN 31/24 in          Mr.    P.S.    Bhattacharya,   Sr.
WPA 13700/2021                             Advocate
                                           Mr. A. Maitra,
                                           Mr. S. P. Lahiri
For the petitioners in        WPA          Mr. Shuvro P. Lahiri
For the added respondents of CAN           Mr. Shuvro P. Lahiri
23/23 in WPA 13700/21 and CAN              Mr. R. Naskar
23/2023, CAN 24/2023 and CAN
For the petitioners in WPA 4313 of         Mrs. Kakali Samajpaty,
2023    and     for    the  private        Ms. Sangeeta Jangra
respondent in WPA 21266 of 2021
For the added respondent of               Ms. Reshmi Ghosh,
CAN/1/24 in WPA 10947/2021                Ms. Parna Mukherjee,
                                          Ms.Barnali Gantait
For the petitioner of CAN 34/24 in        Mr. Yudhisthir Maity
WPA 5406 of 2022
For the applicant in WPA 5406 of          Mr. Anirban Sen
           Heard on                       : January 15, 2024, January 16,
                                          2024, January 17, 2024, January
                                          18, 2024, January 19, 2024,
                                          January 24, 2024, February 5,
                                          2024, March 4, 2024, March 6,
                                          2024, March 7, 2024, March 8,
                                          2024, March 11, 2024, March12,
                                          2024, March 13, 2024, March 14,
                                          2024, March 19, 2024, March 20,
           Judgement on                   : April 22, 2024
DEBANGSU BASAK, J.:-Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

PREFACE
........................................................................................................................................................ 80
CONTENTIONS OF WRIT PETITIONERS
........................................................................................................... 81 CONTENTIONS OF WRIT
PETITIONERS COMPLAINING OF RANK JUMP .......................................................... 93
CONTENTIONS OF CBI
.................................................................................................................................... 97
CONTENTIONS OF SSC
.................................................................................................................................... 98
CONTENTIONS OF SELECTED CANDIDATES OF GROUP-D
.............................................................................. 100 CONTENTION OF ADDED RESPONDENTS
...................................................................................................... 113 CONTENTION OF WRIT
PETITIONERS IN WPA 7370 OF 2023 ........................................................................ 121
CONTENTIONS OF APPELLANTS IN MAT 274 OF 2023 AND MAT 443 OF 2023
.............................................. 123 CONTENTIONS OF PARTIES OPPOSING THE WRIT PETITIONS
....................................................................... 130
ISSUES..........................................................................................................................................................
152 JURISDICTION
.............................................................................................................................................. 154
MAINTAINABILITY........................................................................................................................................
158 CITED AUTHORITIES ON
MAINTAINABILITY................................................................................................................ 159
ANALYSIS OF THE CITED AUTHORITIES ON MAINTAINABILITY
........................................................................................ 166 NATURE OF THE WRIT PETITIONS
............................................................................................................................ 167 DELAY ON PART
OF WRIT PETITIONERS AND MAINTAINABILITY
..................................................................................... 172 COURT'S ORDERS ON THE WRIT
PETITIONS .............................................................................................................. 178 AFFIDAVITS
AND REPORTS OF SSC ..........................................................................................................................
193 AFFIDAVITS AND REPORTS OF BOARD
...................................................................................................................... 206 REPORTS OF CBI
................................................................................................................................................. 207 ROLE
OF STATE GOVERNMENT
............................................................................................................................... 214 INFERENCES
FROM THE ROLE OF ARTICLE 12 AUTHORITIES
........................................................................................... 218 FINDINGS ON MAINTAINABILITY
............................................................................................................................. 222 CERTIFICATE
ISSUED UNDER SECTION 65B OF THE EVIDENCE ACT ...............................................................
225 UPLOADING OF OMR
SHEETS....................................................................................................................... 246 REMAINING
ISSUES ...................................................................................................................................... 247
OPTIONSBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

AVAILABLE.............................................................................................................................................
247 FIRST OPTION
..................................................................................................................................................... 248
SECOND OPTION
................................................................................................................................................. 248
THIRD OPTION
.................................................................................................................................................... 257
ILLEGALITIES IN THE SELECTION PROCESS
.................................................................................................... 259 RELIEFS
........................................................................................................................................................ 262
EXCEPTION...................................................................................................................................................
270 DIRECTIONS
................................................................................................................................................. 272
CONCLUSION
............................................................................................................................................... 275 Preface
1. Several writ petitions and few appeals have been heard by this Division Bench, relating to the
2016 selection process conducted by the West Bengal Central School Service Commission (SSC for
short), in terms of the order dated November 9, 2023 passed by the Supreme Court.
2. Initially, in terms of such order dated November 9, 2023 of the Supreme Court, we had
commenced hearing of the matters on January 29, 2024. In the midst of hearing, learned counsel
for one of the parties had submitted that, his clients would require inspection of the documents
sought to be relied upon in the proceedings. Pursuant to such request being made, hearing of the
matters had been adjourned and directions for giving inspection were passed on February 5, 2024.
Further directions had been passed to facilitate the inspection. Subsequently, hearing of the matters
had commenced on March 4, 2024. The matters have been heard practically on a day-to-day basis
and for the substantial period of the day on the dates of hearing. Learned counsels for the parties
has submitted written notes on argument. Contentions of Writ Petitioners
3. Mr. Bikash Ranjan Bhattacharjee, learned Senior Advocate appearing for the writ petitioners has
drawn the attention of the Court to the fact that, the 2016 selection process conducted by SSC for
recruitment to the post of Group D and C in terms of the West Bengal School Service Commission
(Selection of Persons for the Appointment to Non- Teaching Staff) Rules, 2009 and to the post of
Assistant Teacher in classes IX and X in terms of West Bengal School Service Commission (Selection
for Appointment to the Post of Teachers for Classes IX and X in Secondary and Higher Secondary
Schools) Rules, 2006 and to the post of Assistant Teacher in classes XI and XII in terms of West
Bengal School Service Commission (Selection for Appointment to Post of Teachers for Classes XI
and XII in Higher Secondary Schools) Rules, 2016 are under challenge. He has pointed out that in
one of such writ petitions being WPA No. 12266 of 2021 (Sandeep Prasad & Ors. vs. State of West
Bengal & Ors.) the writ petitioners approached the learned single Judge pointing out 25 examples
where candidates were recommended by SSC after expiry of the panel prepared in relation to
recruitment process in respect of Group D appointments. Similar writ petitions had been filed in
respect of Group C appointments. In this context, he has drawn the attention of the Court to theBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

affidavit of SSC affirmed on November 18, 2021 and November 22, 2021. The learned single Judge
by an order dated November 21, 2021 passed in WPA 12266 of 2021 had appointed the Central
Bureau of Investigation (CBI) to investigate the illegalities and the money trail, if any. An appeal had
been carried against such order dated November 21, 2021 when the Appeal Court by an order dated
December 6, 2021 found serious irregularities in the recruitment process and held that a
constitutional Court can go deeper into the matter in the interest of justice and mould the relief
accordingly. He has contended that, the issue of non- maintainability of the writ petitions had been
decided by the Division Bench and that the Division Bench had found the writ petitions to be
maintainable.
4. On the aspect of maintainability, Mr. Bhattacharya has contended that, such issue is no longer
germane at this stage of the proceeding, as the Court proceeded all throughout in exercise of
constitutional powers, in order to ensure Articles 14 and 15 of the Constitution of India were not
violated. In support of his contentions, he has relied upon 2003 Volume 6 Supreme Court Cases 581
(T. K. Rangarajan vs. Government of Tamil Nadu and others), 2016 Volume 4 Supreme Court Cases
160 (Dharam Pal vs. State of Haryana and Others), and 2018 Volume 12 Supreme Court Cases 61
(Bharati Reddy vs. State of Karnataka and Others). He has contended that, in facts of the present
case, since a scam relating to public appointments has been discovered a Constitutional Court
should not hesitate to enforce compliance with Article 14 of the Constitution of India.
5. Mr. Bhattacharya has submitted that, the Division Bench appointed a four-member committee
consisting of a representative of SSC, a representative of the Board, a practising advocate of the
Court under the Chairmanship of Justice Ranjit Kumar Bag (retired) for a thorough investigation
with regard to the selection process. Such committee had made a thorough investigation and made
several recommendations. He has pointed out the recommendations and the findings of such
committee.
6. Mr. Bhattacharya has submitted that, SSC filed several affidavits in the matters admitting illegal
appointments and sought to justify them under the garb of inadvertent mistakes. In this regard, he
has referred to the affidavit of SSC affirmed on November 3, 2021 in WPA 13700 of 2021, affidavit
affirmed on March 11, 2022 by SSC in WPA 18590 of 2021, affidavit affirmed by SSC in March 2022
in WPA 21268 of 2021, affidavit of SSC affirmed on March 11, 2022 in WPA 21258 of 2021, affidavit
affirmed in March 2022 by SSC in WPA 18802 of 2021, affidavit affirmed in March 2022 by SSC in
WPA 18381 of 2021, affidavit affirmed on March 10, 2022 by SSC in WPA 18387 of 2021, affidavit
affirmed on March 9, 2022 by SSC in WPA 18379 of 2021. He has also relied upon a report of SSC
where according to him, SSC effectively admitted the illegality with regard to candidates not being in
the merit list at all but still made it to the panel. SSC had admitted that, the beneficiaries of such
illegal act did not have any legal right to challenge the same.
7. Mr. Bhattacharya has contended that, an appeal was preferred against various orders of the
learned single Judge pertaining to different writ petitions relating to the 4 categories of the
recruitment. Such appeal had been dismissed by a judgement and order dated May 18, 2022.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

8. Mr. Bhattacharya has submitted that, CBI produced an interim report with regard to another kind
of discrepancy being the manipulation of the Optical Marks Recognition (OMR) answer scripts. The
learned single Judge has passed an order dated September 20, 2022 with regard thereto. CBI has
filed an affidavit dated December 7, 2022 which stated that scanning of all original OMR sheets had
been done at the office of the SSC by M/s NYSA. He has pointed out that, SSC, Board or the state
government including several candidates who are private respondents in WPA 13700 of 2021 did
not challenge such affidavit of CBI.
9. Mr. Bhattacharya has pointed out that, CBI filed several interim reports before the learned single
Judge on the basis of which learned single Judge directed SSC to file an affidavit. Thereafter SSC has
filed an affidavit affirmed on 2023 wherein it admitted that SSC appointed M/s NYSA for scanning
and assessing the OMR answer scripts in relation to the recruitment processes. Such affidavit had
also acknowledged that 2,819 OMR sheets and four answer strings were lesser than the marks of the
candidates kept in the server of SSC. Similar affidavits had been filed in respect of the other 3
categories of the selection processes. He has pointed out that, these affidavits were the first
threshold reaction of SSC.
10. Mr. Bhattacharya has pointed out that, SSC has filed an affidavit before the Supreme Court
admitting that the Chairman of SSC in exercise of executive powers directed destruction of the
OMRs, answer scripts and other papers within a year after keeping a mirror image of the same. He
has contended that, such decision was arbitrary and illegal and in violation of Section 8 (3) of the
Right to Information Act, 2005.
11. Mr. Bhattacharya has contended that, SSC still retains the mirror image of the OMR sheets in
respect of the candidates and in support of such contention, he has referred to 3 affidavits of 3 of the
petitioners, namely, Anindita Bera affirmed on January 24, 2024, Nasrin Khatun affirmed on
February 5, 2024 and Setab Uddin affirmed on February 5, 2024. He has contended that, SSC
supplied copy of OMR on January 18, 2024 from the data stored in the SSC database. Such OMR for
at least one candidate had been given from the database in 2018. SSC had published some OMR
sheets in terms of the order of the Court dated December 14, 2022. OMRs published in 2018 and
2022 are the same and identical. He has contended that, SSC is still in possession of the OMR
answer sheets.
12. Mr. Bhattacharya has contended that, the Court by an order dated February 5, 2024 gave
opportunity to all interested parties in the litigation to inspect the OMR sheets from the CBI
authorities. After taking such inspection, none has disputed the veracity of the OMR sheets in
possession of CBI. On the contrary, one of the candidates had admitted the OMR sheet to be
genuine and questioned the authority of marks awarded to that particular candidate in variance with
the OMR sheet.
13. Mr. Bhattacharya has contended that, CBI from time to time filed several reports which disclose
that OMR sheets recovered were shown to the SSC who checked and found serious manipulations.
Accordingly, the learned single Judge had directed SSC to publish the list of beneficiaries of such
manipulations. List of beneficiaries of manipulations had been directed to be published in respect ofBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

appointments for classes IX and X as well as for Group C and D. He has pointed out that, the list
published by SSC shows that candidates who secured zero in the OMR sheets were given more than
qualifying marks and subsequently appointed. Supreme Court had stayed the publication of the list
for appointment of Assistants Teachers for classes XI and XII.
14. Mr. Bhattacharya has pointed out that, SSC terminated the appointments of the beneficiaries of
the illegalities by invoking Rule 17 of the Rules. SSC had also stated in an affidavit that there may be
more candidates who were wrongly recommended for appointment by SSC and prayed for time for
verifying the records. In this regard, he has referred to page 334 of volume 2 of the compilation. He
has pointed out that, till date, SSC did not conclusively identify the total number of illegalities. He
has pointed out that before the Division Bench, SSC by an affidavit affirmed on December 20, 2023
stated that with regard to the issue of rank jump for appointments of classes IX and X, out of 183
candidates, 122 candidates have been removed and 61 were still remaining. Subsequently, by
another affidavit affirmed on January 5, 2024, SSC had stated that out of the remaining 61
candidates 40 candidates were neither in the panel nor in the wait list and stated that 2 more
candidates were identified. He has contended that, SSC was still in the process of identifying the
illegal appointments.
15. Mr. Bhattacharya has contended that, the vires of Rule 17 had not been challenged by
appointees. Appointments had been cancelled. He has contended that, vires can be challenged if the
Rule was in violation of the parent statute and if the same was arbitrary. According to him, Rule 17
does not suffer from any infirmity especially on the ground of violation of the principles of natural
justice since there is no scope for any pre decisional hearing in case of appointments made in public
employment which was vitiated by fraud or illegalities.
16. Referring to Section 65B (4) of the Indian Evidence Act, 1872, Mr. Bhattacharya has contended
that, SSC acted upon the disclosures made by CBI. He has contended that, primary document is the
scanned copy of the OMR and that such scanning was prepared at the office of SSC. Assessment had
been made on the basis of such scanned copy. Without prejudice to his contention, he has relied
upon 2014 Volume 10 Supreme Court Cases 473 (Anvar P.V. Vs. P.K. Basheer and Others) and 2020
Volume 7 Supreme Court Cases 1 (Arjun Panditrao Khotkar vs. Kailash Kushanrao Gorantyal and
Others) with regard thereto. He has contended that, requirement of certificate under Section 65B
(4) was procedural in nature and can be relaxed by the Court wherever the interest of justice so
justifies. He has also relied upon paragraph 18.21 of Murphy on Evidence, 5th edition for the
proposition that, if the Court's conscience is satisfied that the evidence is relevant, the Court has
inherent powers to take the affidavit of documents on record for proper adjudication.
17. Mr. Bhattacharya has submitted that, powers under Section 165 of the Indian Evidence Act, 1862
should be exercised by a Constitutional Court in order to effectively adjudicate the disputes, without
even deciding on the question of admissibility of evidence. He has pointed out that, SSC is the
creator of the OMR which invariably contains the signature of the respective candidates, signature
of the respective invigilators, a barcode which is unique to each OMR and a unique identification
number along with the question booklet number to which it relates to. Moreover, SSC had accepted
the electronic data seized by CBI during the course of the investigation. SSC had compared andBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

checked such data with the digital records available in the servers of SSC and admitted the
genuineness of the retrieved OMR. He has contended that, CBI in its affidavit affirmed on December
7, 2022 filed in WPA 13700 of 2021 adequately described the manner in which, such electronic data
was retrieved. According to him, there has been sufficient compliance with the provisions of Section
65B (4) of the Indian Evidence Act, 1872. He has pointed out that, requisite certificate had been
produced by CBI and filed by way of an affidavit affirmed on January 15, 2024.
18. Mr. Bhattacharya has contended that, appointments to any post under the control of a statutory
authority is bound to be in conformity with Articles 14 and 16 of the Constitution. There is no
ground to challenge the report of the CBI which had exposed the nature and variety of the
manipulations and which ultimately snowballed and took the shape of a public scam relating to
appointments of school teachers and non- teaching staff. He has relied upon 1994 Volume 4
Supreme Court Cases 164 (H. R. Adyanthaya and Others vs. Sandoz (India) Limited and Others) and
2023 Volume 9 Supreme Court Cases 749 (Dulu Deka vs. State of Assam and Others) in support of
his contentions. According to him, the appointments have been vitiated also due to infractions of the
declared reservation policy.
19. Referring to 2013 Volume 3 Supreme Court Cases 1 (State of Gujarat and Another vs. Justice
R.A. Mehta and Others) Mr. Bhattacharya has contended that, corruption is a cancer to the
democratic governance. According to him, Court has the duty to reveal the truth to ensure justice.
For revelation of truth, the Court may not always be shackled with the procedural niceties. He has
relied upon 2012 Volume 5 Supreme Court Cases 370 (Maria Margarida Sequeira Fernandes and
Other vs. Erasmo Jack De Sequeira) in this regard.
20. Mr. Bhattacharya has pointed out that SSC filed an application to protect illegal appointments
by creating supernumerary post. He has pointed out that, due to the opposition of the writ
petitioners, such application was not allowed to be withdrawn. He has also pointed out that, on
appeal from the order refusing to grant permission to withdraw such application, the Division Bench
was pleased to decline the permission for withdrawal of such application made by SSC by the order
dated November 24, 2022. A special leave petition had been preferred in which an order dated
November 25, 2022 was passed which did not grant permission to withdraw the application.
Therefore, according to him, SSC had admitted illegal appointments.
21. Mr. Bhattacharya has contended that, in the facts and circumstances of the present case, the
Court has no option but to set aside the entire selection process. In support of such contention, he
has relied upon 2021 Volume 16 Supreme Court Cases 217 (State of Tamil Nadu and Another vs. A.
Kalaimani and Others). Alternatively, he has submitted that the Court will be pleased to direct
preparation of the merit list on the basis of the performance of the candidates reflected in the
scanned OMR and direct issuance of appointment letters in terms of the new merit ranking after
setting aside all appointments made by the tainted process till date.
Contentions of writ petitioners complaining of rank jumpBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

22. Mr Ashish Kumar Chowdhury, learned advocate appearing for another set of writ petitioners has
submitted that, he was representing writ petitioners who had suffered rank jumping. He has
contended that, there were several irregularities in the selection process. Moreover, there has been
wrong assessment of answers. Writ petitioners have raised disputes in the counselling process as
also the vacancy said to be declared. He has contended that, he was representing writ petitioners
who have raised such issues.
23. On the rank jumping issue, Mr. Chowdhury has contended that, SSC adopted 2 types of
irregularities with the intention to give appointments to the lower ranked and less meritorious
candidates. According to him, firstly, lower rank order candidates got the appointment since SSC
did not prepare the panel in terms of Rule 12 (7) of the recruitment Rules on the basis of total marks
obtained by the candidate by adding the marks obtained in the written test and marks of academics
and professional qualification and marks of the personality test. SSC had followed Rule 12 (6) on the
basis of marks obtained by the candidates in the written test and marks obtained in academics and
professional qualification by excluding the marks of the personality test as a result of which the
candidate who obtained higher marks before personality test got the appointment and the candidate
who got high marks in total of the personality test was deprived of the appointment. Secondly, SSC
did not follow Rule 12 (9) of the Recruitment Rules and had given recommendation to the lower
ranked candidates without considering the seniority of age according to date of birth, if more than
one candidate obtained the same aggregate marks in total.
24. Mr. Chowdhury has contended that, in similar circumstances the High Court had from time to
time passed orders that higher ranked candidates in terms of Rule 12 (7) were legally entitled to get
appointments. Subsequently SSC had admitted their mistakes and gave appointments to the
candidates those who were deprived. He has relied upon orders passed in WPA 1310 of 2019 and
WPA 5406 of 2022 in this regard.
25. Referring to the affidavit of SSC that, out of 183 candidates in rank jump issue, 122 candidates
were removed by SSC, Mr Chowdhury has submitted that, the fact is that 122 candidates
recommended did not join the post and as such removal of such a candidate by the SSC is gross
suppression of fact.
26. Mr Chowdhury has contended that, SSC acted in violation of Rule 12 (7) of the recruitment
Rules. The method of categorisation as has been spoken about by SSC does not find place or support
by any Rules. Such a method permits a lower meritorious candidate to obtain appointment over a
better candidate. Such a course of action should not be countenanced.
27. Mr. Chowdhury has contended that, the entire selection process conducted by SSC by not
publishing the interview list, merit list and panel separately in terms of Rule 2 (e), (f) and (g) of the
recruitment Rules in each and every stage of the selection process violated the Rules. Moreover, SSC
did not declare the cut off marks subject-wise and category -wise before the personality test in terms
of Rule 12 (6). SSC had prepared the panel without considering the total marks obtained by the
candidates by following Rule 12 (7) and as a result, lower meritorious candidates got appointment
and higher meritorious candidates were deprived. Appointment had been given without taking intoBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

consideration the marks of the personality test by following Rule 12 (6) and the seniority according
to age by following Rule 12 (9) of the recruitment Rules at the time of preparation of the panel. SSC
did not publish the final answers key as a result of which the candidates were unable to ascertain the
marks granted for the right answers. Before counselling the entire vacant post of the schools was not
declared and as a result the higher rank and higher meritorious candidates had been deprived from
getting opportunity to choose their schools nearest to their residence. SSC had failed to declare
vacancy as per the ratio of 1:1.4.
28. Mr. Chowdhury has referred to the order dated July 12, 2018 passed in AST No. 49 of 2018. He
has pointed out that list of successful candidates was published on August 20, 2018 without the
details of the candidates and without breakup of the marks obtained by the candidates. He has
contended that, the panel published in terms of the order dated May 12, 2022 passed in WPA 19580
of 2021 was without complying with the provisions of Rule 12 (7) and Rule 12 (9) of the recruitment
Rules 2016. In support of his contentions, Mr. Chowdhury has relied upon 2011 Volume 12 Supreme
Court Cases 85 (Bedanga Talukdar vs. Saifudaullah Khan and Others), 2008 Volume 3 Supreme
Court Cases 512 (K. Manjusree vs. State of Andhra Pradesh and Another), 2001 Volume 10 Supreme
Court Cases 51 (Maharashtra State Road Transport Corpn. And Another vs. Rajendra Bhimrao
Mandve and Another) and 2013 SCC OnLine Cal 5639 (Alo Basak vs. The State of West Bengal &
Ors.), and 2023 SCC OnLine SC 1408 (Amitava Sengupta vs. Malati Saha). Contentions of CBI
29. Mr. Dhiraj Trivedi, learned Deputy Solicitor General appearing for CBI has referred to the final
report of the CBI dated February 5, 2024 as also to the report dated January 16, 2024. He has
submitted that, CBI concluded the investigations and submitted chargesheet against the accused
persons before the Jurisdictional Court. He has contended that, there was widespread manipulation
in the selection process.
Contentions of SSC
30. Dr. Sutanu Patra appearing for the School Service Commission has referred to the four affidavits
filed pursuant to the order of this Court. He has drawn the attention of the Court to the steps and
measures that SSC took subsequent to the discovery of the illegalities in the selection process. He
has contended that, SSC took such steps on the basis of the data supplied by CBI. He has pointed out
that, SSC had no material to disbelieve the data supplied by CBI. Moreover, SSC had acted pursuant
to the orders of the Court.
31. Dr. Patra, on the aspect of categorisation, has referred to the various provisions of the Rules and
contended that, the list was prepared and published in the web site on the understanding of the
categorization process as prescribed by the Rules. He has contended that, such categorisation was
uniformly applied for all the candidates. He has pointed out that, pursuant to orders passed by the
Court subsequently, the process for categorisation was altered. However, prior to such orders being
passed by the Court, as there was no judicial pronouncement, SSC had categorised the various
candidates in accordance with what SSC understood of the provisions of categorisation as laid down
in the rules.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

32. Dr. Patra has drawn the attention of the Court to the fact that 7 phases of counselling were held
within the validity period of the panel. The 8th phase of counselling had been held after the expiry of
the panel.
33. In response to the queries of the Court, Dr. Patra has submitted that, should the Court direct
evaluation of the OMR sheets afresh, then, SSC would be in a position to do so. However, the same
would require considerable amount of time. In response to another query of the Court, he and the
Chairman of SSC, who was directed to be present in Court, stated that, SSC did not have any
knowledge of the appointment of M/s. Data Scantech Solutions by M/s. M/s NYSA. SSC does not
have any records with regard to the appointment of M/s. Data Scantech Solutions.
34. Dr. Patra has referred to the quantum of declared vacancy and the recommendations made. He
has also pointed out that, certain recommendations were made after the expiry of the panel and
that, appointments were given to candidates who were not even in the panel.
Contentions of Selected Candidates of Group-D
35. Mr. Kalyan Bandopadhyay learned Senior Advocate appearing for some candidates who had
secured appointments in Group D has referred to a list of dates. From such list of dates, he has
pointed out that, Rules of 2009 which governs such selection process, were notified on June 9,
2009. The notification for the 3rd regional level selection test for recruitment of non-teaching staff
2016 had been published on August 9, 2016. Written examination in that regard had been held on
February 19, 2017. His clients had appeared for verification of the documents and credentials and
for personality test on August 19, 2017. Final result had been published on November 6, 2017. Panel
of successful candidates had been published on November 6, 2017. His clients had been called for
first phase of counselling in February 2018. His clients had been recommended for appointment on
February 21, 2018 and May 11, 2018. Appointment letters had been issued to his client on June 4,
2018. By an order dated March 28, 2019, learned single Judge had directed SSC to opt out the
district by counseling in compliance of the requirement of Rules 14 (13) and 15 of the 2009 Rules.
He has pointed out that, the panel and waitlist in relation to the 2016 recruitment for the post of
Group D staff had expired on May 4, 2019 which was notified by SSC on September 2, 2019. SSC
had published revised panel in compliance with the order dated March 28, 2019 on May 20, 2019.
He has pointed out that on November 22, 2021, 4 unsuccessful candidates who were placed in the
waiting list had filed WPA 18585 of 2021 for setting aside of the memo dated September 2, 2019 and
appointment to the post of Group D. By an order dated November 25, 2021, High Court had directed
stopping of the salary of the Group D employees who were being investigated until further orders.
His clients were not being investigated into. He has pointed out that there was another order dated
February 19, 2022 passed by the High Court in WPA 12266 of 2021. He has also pointed out that
between the period April 2022 and August 2022 services of some of his clients were confirmed by
the Secretary of the West Bengal Board of Secondary Education. The learned single Judge had
passed an order dated September 20, 2022 in WPA 12266 of 2021 observing that persons who were
illegally appointed should resign failing which strict orders would be passed. On November 22,
2022, a list titled Final Panel under 3rd RLST 2016 had been published by SSC containing the
names, roll numbers, marks and ranks of the successful participants according to the respectiveBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

districts. CBI had filed an affidavit on December 6, 2022 stating that OMRs were scanned by M/s
NYSA. On December 22, 2022, CBI had supplied a chart containing names of 1,698 persons who
according to CBI could have been illegally appointed to the post of Group D. He has submitted that
out of 1,698 persons disclosed by CBI, 1,694 were given appointments. High Court had directed SSC
to upload the 1,694 names on the website with the intimation of the pendency of the writ petition.
By an order dated February 9, 2023 passed in WPA 18585 of 2021 the High Court had directed SSC
to take steps in respect of 2,819 candidates whose OMR sheets were found by CBI in the M/s NYSA
hard disks and which according to CBI was manipulated. By an order dated February 10, 2023, the
learned single Judge had directed SSC to cancel the recommendation of 1,911 candidates and
directed such candidates to refund their salary. The learned Single Judge had held that, such
candidates were not required to be heard since the publication of OMR sheets demonstrated the
manipulations and discrepancies. The learned single Judge had also directed SSC to declare 1,911
post as vacant and give recommendation to the waitlisted candidates. By a letter dated February 10,
2023, the Chairman of SSC had cancelled the recommendation letters issued to 1,911 Group D
candidates in connection with the 3rd Regional Level Selection Test (NT) 2016 which included his
clients. West Bengal Board for Secondary Education had also cancelled the appointment letters of
his clients on February 10, 2023. Notification for counselling for recruitment to the post had been
published on February 10, 2023. SSC had issued a tentative list of candidates in such counselling on
February 11, 2023. In appeals directed against the orders dated February 9, 2023 and February 10,
2023, the Division Bench had stayed the part of the order dated February 10, 2023 directing refund
of the salary and refused to grant any other stay on February 16, 2023. On a Special Leave Petition
directed against the order dated February 16, 2023, the Supreme Court on May 1, 2023 had stayed
the orders of the High Court. By the order dated November 1, 2023, the Supreme Court had directed
hearing of all writ petitions and appeals by a Division Bench afresh with the direction that all earlier
findings on the issue should be ignored. Division Bench constituted specially in terms of such order
had by an order dated December 6, 2023 allowed the application of his clients for being added as
party respondents to the writ petition. SSC had filed its first report in the form of an affidavit on
December 12, 2023. SSC had filed its 2nd report in the form of an affidavit of December 18, 2023.
SSC had filed its 3rd report in the form of an affidavit on December 20, 2023. SSC had filed its 4th
report in the form of an affidavit on January 5, 2024 wherein additional documents were furnished.
On January 9, 2024 CBI had filed a comprehensive status report disclosing the names of persons
against whom they filed chargesheet after investigation into the selection processes. His clients had
filed an exception to the comprehensive status report of the CBI as also to the reports filed by the
SSC. CBI had filed an affidavit on January 16, 2024 in compliance with the order dated January 15,
2024 disclosing the alleged certificate under Section 65B of the Indian Evidence Act, 1862 dated
September 16, 2022. His clients had filed an exception to the affidavit of the CBI dated January 16,
2024 on January 18, 2024. He has pointed out that, CBI filed an affidavit in compliance with the
order dated January 24, 2024 which stated that the job of scanning of OMR was sub- delegated by
M/s NYSA to M/s Data Scantech Solutions.
36. Mr. Kalyan Bandopadhyay has submitted that, till the date of the personality test, all the
candidates including the writ petitioners did not raise any objection with regard to the selection
process. Writ petitioners had participated in the selection process with their eyes open. Even on
November 6, 2017 when the result of the 3rd RLST was published, and the respondents had becomeBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

successful candidates, the writ petitioners did not challenge such result. After 3 years of the
successful candidates having joined their respective posts was WPA 18585 of 2021 filed. According
to him, the writ petition was hit by delay and laches and that, the learned single Judge could not
have entertained the writ petitions. None of the present respondents had been made parties in such
writ petitions and therefore the point of maintainability on the ground of delay could not be agitated
at an earlier point of time. He has contended that, in terms of the order dated November 9, 2023,
the Hon'ble Court may be placed to decide the point of maintainability on the ground of delay and
laches and that, unsuccessful candidates cannot challenge the selection process after participating in
the selection.
37. Mr. Kalyan Bandopadhyay has submitted that, the writ petition did not contain any prayer for
setting aside or cancelling the entire selection process including the selection of the successful
candidates. According to him, since the writ petitioners did not seek such relief setting aside the
selection process would be beyond the scope of the writ petition. He has referred to the pleadings of
the writ petition and contended that, the pleadings in the writ petition are vague.
38. Mr. Kalyan Bandopadhyay has contended that, the writ petitions should be considered in terms
of the order dated November 9, 2023 of the Supreme Court. He has pointed out that, the High Court
should examine the admissibility of the OMR sheet images recovered by the CBI before placing full-
scale reliance on them and directing termination of services of concerned candidates. The question
of maintainability had been kept open to the decided. Supreme Court had observed that, the
proceedings have strong attributes of a public interest litigation. Direction for uploading the OMR
sheet can only be passed after deciding on the admissibility of the recovered data in terms of the
prevailing Rules of evidence.
39. Mr. Kalyan Bandopadhyay has submitted that, the burden of proof is on the CBI to establish the
genuineness of the OMR on the basis of the established principles of law and not on the basis of
preponderance of probability. He has referred to the report of the SSC filed by the affidavit affirmed
on December 18, 2023 in this regard. He has contended that, SSC found mismatch only because the
OMR sheets recovered by CBI was directed to be looked into by the Court. He has referred to the
order dated June 24, 2022 passed by the learned single Judge in WPA No. 8059 of 2022. He has
contended that, the marks stored in the server were uploaded and thereafter merit list was
published. He has pointed out that, the position of all successful candidates in the merit lists
published in terms of the order dated June 24, 2022 was the same as the merit list published in
terms of the order of the High Court on May 20, 2019 or November 6, 2017. He has contended that,
therefore there is no question of any irregularity and/or illegality in preparing the merit list.
Moreover, none of the writ petitioners had ever questioned the legality and/or validity of the merit
lists.
40. Mr. Kalyan Bandopadhyay has contended that, his client filed an exception to the report filed by
SSC affirmed on January 15, 2024. In such exception, his clients have contended that, SSC
proceeded on the basis of OMR sheets supplied by CBI. He has contended that, the uploaded version
has lost its force in view of the subsequent order of the Supreme Court dated November 9, 2023.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

41. Mr. Kalyan Bandopadhyay has contended that, it will be evident from the report of the CBI
submitted on December 7, 2022 in WPA 13700 of 2021 that scanning of all original OMR sheets was
done at the office of SSC by M/s. NYSA. The hard disks had been seized from an ex-employee. He
has pointed out that, from paragraph 4 of the affidavit affirmed by CBI on February 5, 2024 that,
M/s NYSA had appointed another entity. He has contended that, the report of CBI was misleading
and that they were taking different stands.
42. Referring to the alleged certificate under Section 65B of the Evidence Act, 1872 Mr. Kalyan
Bandopadhyay has contended that, the same did not fulfil the requirements of Section 65B of the
Evidence Act, 1872. The person who has given the certificate was not in charge of the operations in
respect of the recruitment examination conducted by SSC. Such person had no lawful control over
the computer in terms of Section 65B (2) (a) of the Evidence Act, 1872. The alleged hard disks seized
cannot be said to be computer as understood in Section 65B (2) of the Evidence Act, 1872. He has
pointed out that, in absence of the definition of computer in the Evidence Act itself, general meaning
of computer has to be taken. He has contended that, requirements as mentioned in Section 65B (2)
and (4) of the Evidence Act, 1872 are completely absent in the alleged certificate. The alleged
certificate had been issued from a completely different company. The person did not hold any
sensitive or key position in M/s NYSA. He has referred to 2020 Volume 7 Supreme Court Cases 1
(Arjun Panditrao Khotkar vs. Kailash Kushanrao Gorantyal and Others) in support of his
contentions. He has also pointed out that CBI filed a chargesheet against Mr. Pankaj Bansal who had
given the alleged certificate and therefore, he cannot be relied upon.
43. Mr. Kalyan Bandopadhyay has referred to Section 45A of the Evidence Act, 1872 and contended
that, since the Court is required to form an opinion in respect of the matter where information was
stored in a computer, the examiner of electronic evidence as contemplated in Section 79A of the
Information Technology Act is a relevant fact. He has referred to circulars issued in this regard.
44. Mr. Kalyan Bandopadhyay has contended that, Section 45B of the Evidence Act, 1872 puts
safeguards for the accused person in place in view of the fact that the electronic device may be
misused by an investigating agency. He has contended that right to fair trial is a constitutional right
protected under Article 21 of the Constitution. Moreover, SSC cannot cancel an appointed employee
recommendation without providing an opportunity of hearing to the affected person. The right of
hearing of the affected person is inbuilt in view of the fact that the principles of natural justice have
not been excluded under the recruitment Rules.
45. Mr. Kalyan Bandopadhyay has contended that SSC has already destroyed the OMR after one
year from the date of publication of the panel.
46. Mr. Kalyan Bandopadhyay has relied upon 2002 Volume 1 Supreme Court Cases 113 (State of
Punjab vs. Raghbir Chand Sharma and Another), 2009 Volume 4 Supreme Court Cases 555 (Mohd.
Sohrab Khan vs. Aligarh Muslim University and Others), 1997 Volume 8 Supreme Court Cases 488
(Surinder Singh and Others vs. State of Punjab and Another), 1996 Volume 2 Supreme Court Cases
7 (State of Bihar and Others vs. Md. Kalimuddin and Others, 2006 Volume 8 Supreme Court Cases
686 (Union of India and Others vs. B. Valluvan and Others) on the aspect of panel. On the aspect ofBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

delay, he has relied upon 1975 Volume 4 Supreme Court Cases 285 (Aflatoon and Others vs. Lt.
Governor of Delhi and Others), 2022 Volume 2 Supreme Court Cases 25 (Union of India vs. N.
Murugeshan and others) and 2014 Volume 4 Supreme Court Cases 108 (Chennai Metropolitan
Water Supply and Sewerage Board and others). On the contention that unsuccessful candidates
cannot challenge the selection process and that a Court should not take a microscopic view he has
relied upon 2008 Volume 4 Supreme Court Cases 619 (Sadananda Halo and others vs. Momtaz Ali
Sheikh and others), 2020 Volume 2 Supreme Court Cases 173 (Anupal Singh and others vs. State of
Uttar Pradesh and others), 1995 Volume 3 Supreme Court Cases 486 (Madan Lal and others vs.
State of J & K and others) and 2011 Volume 1 Supreme Court Cases 150 (Vijendra Kumar Verma vs.
Public Service Commission, Uttarakhand and others). On the aspect that the relief cannot be
granted beyond the scope of the writ petition, he has relied upon 2000 Volume 2 Supreme Court
Cases 439 (Commissioner, Bangalore Development Authority vs. S. Vasudeva and others) and 2012
Volume 5 Supreme Court Cases 297 (State of Jharkhand and others vs. K.N. Farms and Industries
Private Limited). On the applicability of Section 65B of the Evidence Act, 1872 he has relied upon
2020 Volume 7 Supreme Court Cases 1 (Arjun Panditrao Khotkar vs. Kailash Kushanrao Gorantyal
and others). On the aspect of Section 45A of the Evidence Act, 1872 he has relied upon 2021 SCC
OnLine Bom 354 (Yogesh Arun Wakure vs. State of Maharashtra and another). With regard to the
evidentiary value of a report of the CBI, he has relied upon 2007 Volume 1 Supreme Court Cases 110
(M.C. Mehta (Taj Corridor Scam) vs. Union of India and others), 2022 Volume 12 Supreme Court
Cases 200 (Rajesh Yadav and another vs. State of Uttar Pradesh) and 2009 Volume 5 Supreme
Court Cases 528 (Syed Askari Hadi Ali Augustine Imam and another vs. State (Delhi
Administration) and another). On the aspect that chargesheet is not a public document, he has
relied upon 2023 SCC OnLine SC 58 (Saurav Das vs. Union of India and others). With regard to the
civil consequences and applicability of natural justice, he has relied upon 1978 Volume 1 Supreme
Court Cases 405 (Mohinder Singh Gill and Another vs. The Chief Electioner Commissioner, New
Delhi and Others). He has contended that, post decision hearing will not cure the lack of hearing on
the breach of principles of natural justice, and relied upon 1989 Volume 1 Supreme Court Cases 764
(H.L. Trehan and others vs. Union of India and others) and 1987 Volume 4 Supreme Court Cases
431 (K.I. Shephard and others vs. Union of India and others) in this regard.
Contention of added Respondents
47. Mr Pratik Dhar learned senior advocate appearing for some of the added respondents in WPA
13700 of 2021 and representing the applicants in CAN 22 of 2023 filed therein, has submitted that,
point of maintainability remains open. According to him, in addition to the issue of maintainability,
the order dated November 9, 2023 of the Supreme Court requires the Division Bench to examine the
admissibility of the OMR sheet images. According to him, allegations of manipulations have to be
established by cogent evidence. Supreme Court has directed the Court to ignore the findings of the
earlier Division Bench on Rule 17 and to decide such matter afresh. Court may consider issuing
directions to upload the CBI recovered OMR sheet only after the authenticity of the images have
been established after applying the prevailing Rules of evidence. CBI has also been directed to
submit its report.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

48. Mr. Pratik Dhar has submitted that, the writ petition is not maintainable on the ground of delay.
He has referred to the list of dates. He has contended that, the writ petition was filed after a lapse of
4 years 10 months from the date of the examination, 3 years 6 months from the publication of final
panel and at 1 year 8 months from the date of expiry thereof. According to him, the writ petitioners
having participated in the selection process and being unsuccessful therein is not entitled to
maintain a writ petition particularly in view of the delay. In support of such contention, he has relied
upon 2013 Volume 11 Supreme Court Cases 309 (Ramesh Chandra Shah and others vs. Anil Joshi
and others), 2022 Volume 1 Supreme Court Cases 294 (Mohd. Mustafa vs. Union of India and
others), 2017 Volume 9 Supreme Court Cases 478 (D. Sarojakumari vs. R. Helen Thilakom and
Others) and 2019 Volume 19 Supreme Court Cases 633 (Union of India and Others vs. C. Girija and
Others).
49. Mr Dhar has contended that, the writ petitions do not contain any pleadings with regard to the
alleged wrongdoings. He has contended that the writ petitions do not contain any prayer for setting
aside the entire selection process. Consequently, according to him, the writ petitioners are not
entitled to any relief. In support of such contentions, he has relied upon 2003 Volume 8 Supreme
Court Cases 40 (V. K. Majotra and others vs. Union of India and others) and 2011 Volume 14
Supreme Court Cases 243 (State of Jammu and Kashmir and others vs. Ajay Dogra).
50. On the interpretation of Rule 17, Mr Dhar has contended that, power given therein is limited.
According to him, the moment appointment is made, such power gets extinguished. Withdrawal of
recommendation cannot be equated with withdrawal of appointment. He has referred to Rule 17 and
contended that, power to withdraw recommendation can at best be till the appointment. Moreover,
once a teacher is appointed, such teacher is governed under separate Rules namely West Bengal
Board of Secondary Education (Appointment, Confirmation, Conduct and Discipline of Teacher and
Non-Teaching Staff) Rules, 2018. Rule 17 cannot have overriding effect over the Rules of 2018.
Moreover, Rule 17 does not have principles of natural justice built into it and therefore, interpreting
Rule 17 as a power to terminate the appointment particularly when other Rules exist for suspension,
dismissal and conduct of a teacher should not be done. According to him, SSC becomes functus
officio upon making the recommendation. In support of such contentions, he has relied upon 2006
SCC OnLine Cal 708 (Rama Bandyopadhyay vs. State of West Bengal and others), 2012 SCC OnLine
Cal 1860 (Ayesha Khatun vs. State of West Bengal and others), 2005 SCC OnLine All 1341 (Dr. Ravi
Shankar Pandey vs. State of U.P. and others) and 2011 SCC OnLine J & K 49 (Renu Bala vs. State of
J & K and others).
51. Mr Dhar has contended that, Rule 17 cannot be invoked since, SSC is proceeding on the basis of
error whereas, CBI has alleged manipulation/corruption. According to him, both cannot go
together. On such issue, he has relied upon 2011 Volume 10 Supreme Court Cases 420 (Cauvery
Coffee Traders, Mangalore vs. Hornor Resources (International) Company Limited). On the issue of
post decisional hearing cannot cure the inherent defect of not hearing an affected party on the
principles of natural justice, he has relied upon 1989 Volume 1 Supreme Court Cases 764 (H.L.
Trehan and others vs. Union of India and others) and 1986 Volume 4 Supreme Court Cases 537
(Institute of Chartered Accountants of India vs. L.K. Ratna and others).Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

52. Mr Dhar has contended that, four conditions must be satisfied for a certificate to be valid under
Section 65B of the Evidence Act. According to him such four conditions are that, the person giving
the certificate must have lawful control as opposed to exclusive custody, the data must be regularly
fed and in ordinary course of activity. Moreover, it has to be established that the computer was
operating properly and that, the information which was ultimately reproduced was what was fed
into the computer in ordinary course of activity. He has contended that, the alleged certificate does
not allude to the person giving the certificate having lawful control or having regularly fed the data
in the ordinary course of activity or the computer operating properly. Consequently, the so called
certificate should not be admitted into evidence. The certificate must have such details and that such
details cannot be filled up by an affidavit of someone else. Moreover, the alleged certificate was not
given by an ex-employee of M/s NYSA. In support of such contentions, he has relied upon 2014
Volume 10 Supreme Court Cases 473 (Anvar P.V. vs. P.K. Basheer and others), 2020 Volume 7
Supreme Court Cases 1 (Arjun Panditrao Khotkar vs. Kailash Kushanrao Gorantyal and others),
2023 Volume 3 Supreme Court Cases 654 (Mohd. Arif alias Ashfaq vs. State (NCT of Delhi) and
2022 Volume 7 Supreme Court Cases 581 (Ravinder Singh alias Kaku vs. State of Punjab).
53. Mr. Dhar has contended that, scanned copy of OMR sheets cannot be in .Dat format. According
to him, some other software had been used to put it into .Dat format. Therefore, the data available in
the hard disks is processed data and not the scanned images of OMR sheets as initially claimed by
CBI. Moreover, matching of Hash value requires the same file format. Consequently, the materials
allegedly seized by CBI should not be relied upon.
54. Mr. Mukul Lahiri learned senior advocate appearing on behalf of respondent No. 643 to 645 and
applicants in CAN 8 of 2024 filed in WP No. 12270 of 2021 has contended that, his clients come
from poor and humble background. His clients had participated in the selection process and fulfil
the prescribed requirements. His clients had never made any misrepresentation. He has pointed out
that, his client received the appointment after following the due process. Board of Secondary
Education had published an order dated March 11, 2023 stating that appointment of 785 of Group C
candidates stood cancelled. Names of his clients had appeared in such list. He has contended that,
his clients were not parties to the writ petition in which an order dated March 10, 2023 was passed.
He has pointed out the prayers made in the writ petition and contended that, there was no prayer
for setting aside the selection process. His clients upon coming to know of the orders dated
December 21, 2022 and March 10, 2023 passed in the writ petition applied for being added as party
respondents to the writ petition.
55. Mr. Mukul Lahiri has contended that, the hard disks and pen drives which CBI has seized cannot
be admitted in evidence. In support of such contentions, he has relied upon 2014 Volume 10
Supreme Court Cases 473 (Anvar P.V. vs. P.K. Basheer and others) and 2020 Volume 7 Supreme
Court Cases 1 (Arjun Panditrao Khotkar vs. Kailash Kushanrao Gorantyal and others).
56. Referring to the reports of the CBI, Mr Mukul Lahiri has contended that, the last affidavit dated
February 5, 2020 of CBI is self-contradictory in nature and no reliance can be placed on it. He has
pointed out that, going by the affidavit of CBI then, scanning job was made by another entity namely
M/s Data Scantech Solutions. Evaluation had been done by M/s NYSA and that there is noBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

allegation to the contrary.
57. Mr Lahiri has contended that, all original OMR sheets have been destroyed by the SSC. Hence
any basis for evaluation of OMR sheets has been lost. What remains in the records of SSC is the
polluted and contaminated data supplied from the hard disks by Mr. Pankaj Bansal. Therefore, it is
not possible for SSC to arrive at any definite conclusion regarding the alleged manipulation of the
evaluation of OMR sheets for the examination results. Distinguishing A. Kalaimani and others
(supra) cited on behalf of the petitioners he has contended that, in that case, the original records of
selection and answer sheets were available unlike the present case. He has adopted the submissions
of other learned advocates appearing for other similarly placed parties. Contention of Writ
Petitioners in WPA 7370 of 2023
58. Mr Anindya Kumar Mitra learned senior advocate appearing for the writ petitioners in WPA
7370 of 2023 has submitted that, his clients sought a declaration that Rule 17 of the West Bengal
School Service Commission (Selection of Appointment to the Post of Teachers for Class IX and X in
Secondary and Higher Secondary Schools) Rules, 2016 is ultra vires. He has contended that the writ
petitioners participated in the selection process initiated by the notification dated September 23,
2016. They have been duly appointed. They had worked for about 3 years. Without giving
opportunity of hearing, suddenly by administrative order dated March 1, 2023 in respect of 618
teachers and March 3, 2023 in respect of 157 teachers the recommendations issued to the
petitioners and similarly circumstanced persons were withdrawn. He has contended that, Rule 17 of
the Rules of 2016 is ultra vires and arbitrary on the grounds that it violates the principles of natural
justice and Article 14 of the Constitution of India. Such Rule does not contemplate granting
opportunity of hearing to the persons against whom SSC has contemplated to cancel or withdraw
the recommendation invoking Rule 17.
59. Mr Mitra has contended that, after the recommendation has been issued under Rule 17 and
acted upon by giving appointment, the recommendation ceased to exist as it merges with the
appointment. SSC then becomes functus officio and loses power to withdraw the recommendation it
had made. In support of such contentions, he has relied upon 2010 (1) CLJ 518 (Mridula Ghosh and
another vs. State of West Bengal and others).
60. Without prejudice to the aforesaid contentions, Mr Mitra has contended that, if SSC decides to
withdraw recommendation at any stage after the appointment, such action has to be made
contemporaneously and within the validity period of the panel so that the commission is in a
position to take steps to fill up such post from the waiting list within the validity period of the panel
and the waiting list. In the facts of the present case, the panel and the waiting list had expired one
year after their publication, on August 28, 2018 and as such Rule 17 could not have been validly
invoked.
61. Mr Mitra has contended that, in accordance with Rule 16 (3) of the Rules of 2016,
recommendations made by SSC remains valid initially for 90 days and if extended till 60 days. This
validity period of the recommendation ends when the appointment is made. Thus there cannot be
any ad infinitum extension of validity of the recommendations issued under Rule 17 by which SSCBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

retains the power to withdraw the recommendation of the teacher till he retires from service.
Recommending body cannot have power of withdrawal after the recommendation has merged into
the appointment. Contentions of Appellants in MAT 274 of 2023 and MAT 443 of 2023
62. Mr Anindya Kumar Mitra, learned senior advocate has also appeared on behalf of Group D
appointees who had preferred appeal being MAT No. 274 of 2023 and appointees of Group C who
had preferred appeal being MAT No. 443 of 2023. On behalf of such clients, he has contended that,
in respect of all the 4 categories, no dispute or complaint regarding due publication of the final list
stored in the server of SSC has been raised in the writ petitions filed by the unsuccessful candidates.
Moreover, the successful candidates have not been impleaded therein.
63. Mr Mitra has contended that, the order dated November 9, 2023 of the Supreme Court does not
permit all matters that have been listed before the Division Bench to be heard by the Division Bench.
He has contended that, only those matters which have been remitted by the order dated November
9, 2023 can be heard by the present Division Bench and that, this Division Bench has no jurisdiction
to hear any of the writ petitions moved by the clients of Mr Ashish Chowdhury, advocate.
64. Mr Mitra has referred to the order dated November 9, 2023 passed by the Supreme Court and
contended that, the core issues involved are whether the OMR sheets received by CBI from Mr
Pankaj Bansal are admissible in evidence and their authenticity has been established by applying the
prevailing rule of evidence or not. If the answer is in the negative, then, can those OMR be uploaded
in the server of SSC to compare with the final list stored therein and can any reliance be placed upon
them to terminate service of any employee. Moreover, whether, revocation of recommendations
under Rule 17 by SSC is valid or not is another core issue.
65. Referring to Section 65B of the Evidence Act he has contended that, 2020 Volume 7 Supreme
Court Cases 1, (Arjun Panditrao Khotkar vs. Kailash Kushanrao Gorantyal and others) has laid down
that there is difference between admissibility and reliability of a document. He has referred to
various paragraphs of such decision. He has contended that, the person who had issued the
certificate was not at all competent to issue the same since, another person who supervising the
process of scanning and evaluation for M/s NYSA. Moreover, none of the 3 hard disks had been
produced in Court for admission as evidence. Inspection of those hard disks have not been given in
spite of the order of the Court. Inspections of OMR sheets have not been given. According to him
there is no other cogent evidence to contradict the final merit list available in the server of SSC.
66. On the aspect of withdrawal of recommendation, Mr Mitra has contended that, grounds on
which recommendations could be withdrawn under Rule 17 are not available in this case.
Withdrawal order has referred to an order of the Court which is not a ground mentioned in Rule
17. Rule 17 in any event applies to Assistant Teacher for class IX and X and not for non-teaching
staff where, the applicable rule is Rule 18 of the Rules of 2009. According to him, the withdrawal of
recommendations was arbitrary. Rule 18 does not confer any specific power on the regional
commission to do away with the name of any candidate from the panel. None of the affected
candidates had been heard prior to the issuance of the order of withdrawal.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

67. Mr Mitra has contended that, questions which did not arise out of the pleadings of the parties or
mentioned in the impugned order of the single Judge were sought to be raised at the hearing of the
writ petitions. He has contended that, Court has no jurisdiction to consider any question which is
not covered by the pleadings of the parties. He has contended that, there was no admission on the
part of SSC before the learned single Judge and that, the so-called admission was irrelevant. He has
contended that there cannot be any estoppel against statute and that, statutory bar under Section
65B of the Evidence Act cannot be overridden.
68. Mr Mitra has contended that so far as the 2nd question which came up for consideration before
the Court as to defect in the selection process leading to the preparation of the final list of candidates
is concerned, no complaint regarding this regard has been raised in the pleadings nor argued before
the learned single Judge. No demands of the irregularity or invalidity in the matter of appointment
of M/s NYSA has been raised by CBI. Writ petitioners have not made any grievance regarding the
appointment of M/s NYSA, scanning and evaluation of OMR sheets even after receipt of CBI report.
According to him, CBI upon investigation has found nothing wrong with the selection process and
uploading of the evaluated marks of candidates prepared by M/s NYSA into the office database
namely server of the SSC which was made public on February 5, 2024. Similar is the stand taken by
SSC in the affidavit dated February 10, 2023. Thus in absence of any illegality regarding the
selection process culminating in preparation of the final list it was not open for the learned single
Judge to set aside the appointment of 1,911 members of Group D.
69. Mr Mitra has contended that the 3rd question raised in the course of the hearing, that, the
appointment of M/s NYSA was bad as no public tender was issued, should not be considered as, no
such case was made out by the parties or by CBI or the SSC. Court cannot consider any point not
raised on affidavits particularly in writ proceedings which are tried on affidavits and in support of
such contention, he is relied upon AIR 1981 SC 588 (S.S. Sharma and others vs. Union of India and
others) and 2003 Volume 8 Supreme Court Cases 40 (V.K. Majotra and others vs Union of India
and others). M/s NYSA is not a party to the proceedings and cancellation of their appointment
would be prejudicial to them. In support of such contention, he has relied upon 2022 Volume 15
Supreme Court Cases 511 (Acqua Borewell Pvt. Ltd. vs. Swayamprabha and others). He has
contended that, appointment by tender is not a must and that it is only desirable that appointments
are made by tender. Nobody has argued that such appointment is void because of non- issuance of
tender. At the highest it can be said that such appointment was irregular but cannot vitiate the
selection process.
70. Mr Mitra has contended that the scope of challenge to a selection process is limited.
Unsuccessful candidates after participation cannot challenge the selection process and in support of
such contention, he has relied upon 1995 Volume 3 Supreme Court Cases 486 (Madan Lal and
others vs. State of J & K and others) and 2008 Volume 4 Supreme Court Cases 619 (Sadananda Halo
and others vs. Momtaz Ali Sheikh and others). He has contended that, no allegation regarding
malpractice or corruption against SSC had been made. No officer of SSC had been named as guilty of
malpractice or corruption in the pleadings.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

71. Mr Mitra has contended that, principles of natural justice stood violated by the order of the
learned single Judge which resulted in the termination of services of the successful candidates. He
has contended that, the successful candidates were entitled to a hearing. In support of such
contention, he has relied upon 2008 Volume 4 Supreme Court Cases 619 (Sadananda Halo and
others vs. Momtaz Ali Sheikh and others).
72. Mr Mitra has contended that, the order dated February 10, 2023 passed by the learned single
Judge in WPA No. 18585 of 2021 and the order dated March 10, 2023 passed in WPA No. 12270 of
2023 should be set aside. He has contended that, concept of community guilt is not accepted in
India. Court has no jurisdiction to pass any order contrary to the provisions of Article 311 of the
Constitution of India.
73. Mr Mitra has contended that, cancelation of the entire selection will not ensure to the benefit of
anybody. Court cannot give any appointment to anybody since the waiting list and the panel of all
expired long back.
74. Mr Mitra has contended that, the report of the CBI regarding OMR sheet is unreliable.
According to him, CBI has not explained why it has not gone to the office of M/s NYSA and looked
into the records maintained by M/s NYSA. What had led CBI to approach an unknown employee of
M/s NYSA at Ghaziabad. It is not explained how the hard disks which are properties of M/s NYSA
could be at the residence of an ex- employee. Mr Pankaj Bansal has not said and CBI has not found
out how any property of M/s NYSA could go out of the office of M/s NYSA. Such deficiencies have
made the investigation report of CBI unreliable.
75. Referring to 2021 Volume 16 Supreme Court Cases 217 (State of Tamil Nadu and Another vs. A.
Kalaimani and Others), Mr Mitra has contended that, such Judgement has no application to the
facts of the present case since, the OMR sheets were available therein which is not the case here.
Contentions of Parties opposing the writ petitions
76. Mr. Jayanta Kumar Mitra learned Senior Advocate appearing for three candidates of Class IX
and X comprised in CAN 6 of 2024 filed in WPA 25380 of 2022 has in response to a query of the
Court, submitted that, his clients did not take inspection of the documents. He has referred to the
orders dated April 12, 2023 and November 9, 2023 of the Supreme Court. He has also referred to
the report of the CBI dated December 7, 2022, and the report of Justice Bag Committee dated
December 15, 2022. He has contended that, SSC is unreliable. According to him SSC is a partner in
the crime. In this regard he has referred to the final report of the CBI dated February 5, 2024.
77. Mr. Anindya Bose learned advocate appearing for added respondent No. 151 and respondent
Nos. 25 to 32 in WPA 13700 of 2021 has contended that, his clients have requisite qualification to
receive the appointment. No hearing had been given nor any reasons assigned as to why the
appointments had been terminated. It has been wrongfully alleged as against his clients that; his
clients received appointment post the expiry of the panel.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

78. Mr. Shankar Prasad Dalapati learned advocate appearing for some of the candidates whose
names feature in the 952 candidates whose recommendations were withdrawn by SSC pursuant to
the orders of the Court, has submitted that, his clients were not involved in any scam. His clients
have not been heard or given a chance of being heard before their services were terminated. His
clients have not been investigated into by CBI nor have his clients being interrogated. His clients has
submitted full-fledged written OMR sheets which did not contain any blank. His clients had
answered all 55 questions. He has contended that, since there is an embargo to re-evaluate OMR
sheets by SSC in terms of the first proviso to Rule 12 (8) of the Rules of 2016, the Court ought not to
have considered the reports or submissions made by SSC in respect of his clients getting low marks
than they have actually secured at the time of evaluation.
79. Mr. Dalapati has contended that, CBI failed to disclose the errors committed by SSC. According
to him, the errors which CBI has hinted towards are illegality and corruption and as such Rule 17
cannot be applied. He has questioned the reliance on the OMR sheet images available in the hard
disks seized by CBI. He has contended that, the only option left to the Court is to set aside the entire
selection process and that Court should direct compensation to be paid to innocent candidates who
are not involved in the corruption.
80. Mr Apalak Basu learned advocate appearing for the added respondent No. 6, 7 and 8 in WPA
21665 of 2019 has contended that, his clients secured the appointments fairly. He has contended
that, none of his clients jumped the rank as alleged by the petitioners. He has compared the marks
obtained by the writ petitioners and his clients. He has contended that SSC categorised the aspirants
in accordance with a declared policy. His client had secured better marks in the academic and
professional categories than the writ petitioners and therefore, his clients were entitled to the
appointment in preference to the writ petitioners.
81. Mr Apalak Basu has relied upon 2023 SCC OnLine SC 344 (Tajvir Singh Sodhi and others vs.
State of Jammu and Kashmir and others), 2020 Volume 18 Supreme Court Cases 673 (Vishal Ashok
Thorat and others vs. Rajesh Shrirambapu Fate and others), 2011 Volume 15 Supreme Court Cases
455 (Sunil vs. State of Maharashtra and others), 2006 Volume 6 Supreme Court Cases 467 (Sanjay
Kumar and others vs. Narinder Verma and others), 2017 SCC OnLine Cal 3799 (The State of West
Bengal & others vs. Chandra Kanta Ganguli & others) in support of his contentions.
82. Mr Anindya Lahiri learned advocate appearing for added respondents in WPA 19278 of 2019,
WPA 19273 of 2019, WPA 19749 of 2019, WPA 20776 of 2019 and WPA 20778 of 2019 has
contended that, his clients received the appointments in accordance with law. He has referred to
Rule 12 (6) of the Rules of 2016 and contended that, the merit list category -wise. He has referred to
the various developments subsequent to the filing of the writ petition. He has contended that, the
writ petitions are infructuous in view of the fact that the panel prepared by SSC expired. He has
referred to the prayers made in the writ petition. He has contended that unsuccessful candidates
cannot challenge the appointments that too after a delay of so many years. He has relied upon 2006
Volume 6 Supreme Court Cases 467 (Sanjay Kumar and others vs. Narinder Verma and others) in
support of his contention.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

83. Mr Anindya Lahiri learned advocate has also appeared for the appellants in MAT 85 of 2023. He
has contended that, the 2016 Rules are not applicable as SSC became functus officio after the
recommendation culminated into appointments. Rule 17 of the SSC Rules cannot be invoked as the
conditions of service became regulated by the Rules of 2018.
84. Mr Lahiri has contended that, the writ petitions cannot be treated as a public interest litigation
as no public interest litigation is maintainable in respect of service matters. In support of such
contention, he has relied upon 2005 Volume 5 Supreme Court Cases 136 (Gurpal Singh vs. State of
Punjab and others).
85. Mr Lahiri has contended that, no negative marks was awarded in the evaluation process. He has
contended that, since there was no negative marking there was no logic as to why any candidate
would submit blank OMR without attempting the answers. The issue as to the appointment of M/s
NYSA and some delegation to M/s Data Scantech Solutions cannot be raised in absence of pleadings
and without opportunity to the contesting parties to meet such allegations. He has pointed out that,
all candidates in respect of whom, mismatch of numbers were found by CBI were not favoured with
appointments. Court has to presume the truth about the server data or the break-up of marks.
According to him, re-evaluation is not possible as there is no basis for the same. He has contended
that, weeding out the illegalities is possible. So far as inspection of OMR sheets are concerned, he
has contended that only one teacher took such inspection. The other teachers who had taken
inspection disputed the authenticity, perversity and contents of such OMR sheets. With regard to
Section 65B of the Evidence Act, he has reiterated the submissions advanced by other learned
advocates.
86. Mr Sudip Ghosh Chowdhury, learned advocate appearing for the added respondents in WPA
5406 of 2022 and applicants in CAN 27 of 2023 has contended that, his clients are working as
school teachers in their respective schools being selected through a proper recruitment process. He
has contended that, services of his clients should not be disturbed.
87. Mr Prasenjit Debnath, learned advocate appearing for respondent No. 4 in WPA 18355 of 2019
has contended that, his client received the appointment without the alleged rank jumping. He has
questioned the maintainability of the writ petition. He has adopted the submissions made by Mr.
Kalyan Bandopadhyay learned senior advocate and Mr Pratik Dhar, learned senior advocate.
88. Mr Milan Mukherjee, learned senior advocate appearing for the writ petitioners in WPA 2967 of
2023 has referred to the list of dates. He has submitted that, his client filed the writ petition seeking
a declaration that the purported OMR sheets published under the notice dated December 29, 2022
are not conclusive and are subject to proof following due process of law. He has referred to the
prayers made in the writ petition.
89. Mr Mukherjee has contended that, till the date of the personality test none of the unsuccessful
candidates raised any objection with regard to the selection process or as to any alleged illegality
while conducting the same. The unsuccessful candidates had participated in the selection process
with their eyes open. Long after the joining of the successful candidates, the writ petitions had beenBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

filed by some unsuccessful candidates. He has contended that, such writ petitions filed by
unsuccessful candidates were hit by delay and laches. He has reiterated the contentions of the
learned counsel appearing for the successful candidates with regard to delay, laches, lack of
pleadings and prayers as also admissibility of the OMR sheets.
90. Mr Mukherjee has contended that, the so-called certificate cannot be treated as a certificate
under Section 65B of the Evidence Act on the ground that the key person who was looking after the
works of M/s NYSA for scanning of the OMR sheets evaluation did not issue the certificate. The
person who had issued the certificate did not have lawful control over the computer at all, in terms
of provisions of Section 65B (2) (a) of the Evidence Act. The hard disks cannot be said to be a
computer as referred to in Section 65B (2) of the Evidence Act. In absence of definition of computer,
in the Evidence Act, general meaning of computer has to be applied. He has contended that
requirements of Section 65B (2) and Section 65B (4) are completely absent in the certificate. The
certificate was issued by a different company. The certificate was contrary to the law laid down in
2020 Volume 7 Supreme Court Cases 1 (Arjun Panditrao Khotkar vs. Kailash Kushanrao Gorantyal
and others). CBI has failed to obtain a valid certificate. He has reiterated the contentions of Mr.
Kalyan Bandopadhyay with regard to Section 45A of the Evidence Act and Section 79A of the
Information Technology Act.
91. Mr Mukherjee has contended that, the writ petitions of the unsuccessful candidates are not
maintainable. In this regard he has reiterated the contentions of other learned advocates appearing
for the successful candidates. He has contended that, burden of proof cannot be shifted upon the
in-service candidates.
92. Mr Pramit Ray learned senior advocate appearing for the applicants of CAN 7 of 2014 in WPA
No. 18585 of 2021 has contended that, the writ petitions are not maintainable. He has referred to a
list of dates on the question of delay. He has contended that, lack of explanation of the SSC
regarding adherence to the Rules cannot take away the employment of his clients in absence of
pleadings and proof that any particular candidate misrepresented any facts relating to his or her
candidature.
93. Mr Ray has contended that, Regional Commission after recommendation cannot cancel the
panel nor can it withdraw the recommendation. He has contended that, the so-called withdrawal of
recommendation that too after the expiry of the validity of the panel is not legal.
94. Mr Ray has contended that, records seized by CBI from the residence of Mr. Pankaj Bansal
cannot be admitted as evidence. The records stored in the server of SSC should not also be admitted
as evidence. In any event, in absence of any pleading or proof that any individual candidate had
misrepresented any fact relating to the selection, services of such candidate cannot be terminated.
Moreover, his clients had worked for a considerable period of time.
95. Mr Ray has contended that, the so-called certificate is dated September 16, 2022 and that the
same was disclosed for the first time by an affidavit of CBI affirmed on January 16, 2024. The late
disclosure has clearly indicated that the document was manufactured. CBI could not produce theBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

records in respect of at least 3 writ petitioners. Therefore, the information collected by CBI is not
genuine. He has pointed out that, there are 2 OMR answer sheets produced by CBI in respect of at
least one writ petitioner namely Mampi Banerjee. He has highlighted the fact that his clients were
denied the right of hearing prior to their services being terminated. He has contended that, SSC has
acted in violation of the principles of natural justice.
96. On the aspect of the options available to the Court in these proceedings, Mr Ray has contended
that, there can be other alternatives than, dismissing all the writ petitions or cancelling all the
appointments or going in for fresh evaluation through the agency of SSC. He has contended that,
conduct of SSC does not inspire confidence and therefore the evaluation through SSC will be a
travesty of justice. Moreover, since the original materials have been destroyed prior to institution of
the proceedings, authenticity of the thing that stood in the server of SSC or the data recovered by
CBI is questionable.
97. Mr Jaydip Kar learned senior advocate appearing for the appellants in MAT 557 of 2023 arising
out of WPA 5953 of 2023 has contended that his clients, numbering 33 assistant teachers for class
IX and X were not parties to the writ petition. He has referred to the sequence of events leading to
the order dated November 9, 2023. He has contended that, evidence produced by CBI on OMR
sheets are not admissible in evidence. The purported certificate issued under Section 65B of the
Evidence Act is not in compliance of Section 65B. He has contended that certification and contents
are not in compliance with Section 65B and in support of such contentions, he has relied upon 2020
Volume 7 Supreme Court Cases 1 (Arjun Panditrao Khotkar vs. Kailash Kushanrao Gorantyal and
others), 2021 Volume 12 Supreme Court Cases 289 (Smriti Madan Kansagra vs. Perry Kansagra)
and 2022 Volume 7 Supreme Court Cases 581 (Ravinder Singh alias Kaku vs. State of Punjab).
98. Mr Kar has contended that, SSC in their affidavit did not admit the genuineness or authenticity
of the OMR sheets, in their affidavit. SSC had taken steps pursuant to orders of Court. He has
contended that, in order to construe a statement made by a party as an enforceable admission, the
admission should be unequivocal. Such admission has to be taken as a whole, the admission must
not be conditional and that there can be no admission contrary to the statutory provisions. In
support of such contentions, he has relied upon 1877 ILR 2 Cal 23 (The Queen vs. Bholanath Sen).
99. Mr Kar has referred to Section 58 of the Evidence Act and contended that, facts need not be
proved does not apply in the case of secondary electronic evidence. Section 3 of the Evidence Act has
excluded electronic evidence. Section 65B of the Evidence Act is the only mandatory provision by
which secondary electronic evidence can be brought on record and proved.
100. Mr Kar has contended that, nullifying the entire recruitment process will be against public
interest as students in schools will suffer because of such mass scale termination of service of
teachers. He has contended that, irregularity does not vitiate the recruitment process because the
same was not an illegality. The portion of the candidates who have been selected on their own merits
cannot be made victim of mistakes/irregularities on the part of SSC if at all there were any
irregularities or mistakes. In any event, State government has stepped in and suggested
amelioration by creating supernumerary post to the candidates who have suffered in the selectionBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

process by these alleged mistakes/irregularities. Cabinet has approved creation of supernumerary
post.
101. Mr Anirban Sen, learned advocate appearing for respondent Nos. 691 and 692 in WPA 5406 of
2022 and applicants in CAN 29 of 2024 has submitted that, Section 65B was inserted into the
Evidence Act in 2000 when digital devices did not make its foray into the Indian legal system. He
has pointed out that Section 65B finds its place under Chapter V pertaining to proof of documentary
evidence and after the Sections of primary evidence, secondary evidence and when secondary
evidence may be given. He has contended that Section 65B is a mechanism introduced to
authenticate emails, website, etc in a Courtroom which was at that time without substantial
computerisation. According to him, the rationale behind Section 65B is to have a human being who
takes responsibility for mainly printing an existing electronic record. Such person certifies and
stands by such record vouching for the authenticity and correctness of the transformation from the
digital record to a physical document. In support of such contentions, he has relied upon 2020
Volume 7 Supreme Court Cases 1 (Arjun Panditrao Khotkar vs. Kailash Kushanrao Gorantyal and
Others).
102. Mr Sen has contended that, Section 65B (2) of the Evidence Act list out various conjunctive
conditions to be met which are also mandatory. He has contended that, in the facts and
circumstances of the present case, such mandatory provisions have not been met.
103. Mr Sen has contended that, the chain of custody of the digital evidence is necessary to establish
that the digital evidence being supplied/used was really from the same source to be believed, and
not a substituted/false source. He has pointed out that the order dated November 9, 2023 of the
Supreme Court requires this Court to decide on both the issue of admissibility as also authenticity of
the OMR data. According to him, whereas the point of admissibility requires a Section 65B
certificate the requirement of authenticity demands hash value/MD5 fingerprint of the created
electronic record to be matched with the last electronic record in the entire chain on data transfers.
He has contended that, neither of the conditions stand satisfied.
104. Mr Dilip Kumar Maiti learned advocate appearing for respondent Nos. 363 to 408 and 803 in
WPA 18585 of 2021 has adopted the submissions of the learned advocates opposing Mr Bikas
Ranjan Bhattacharya.
105. Mr Biswaroop Bhattacharya learned advocate appearing for 76 added respondents in WPA
5406 of 2022 has contended that, his clients were given appointments to the post of assistant
teachers in classes XI and XII. He has pointed out that the writ petitioner in WPA 5406 of 2022 is
an unsuccessful candidate who was placed in the waiting list panel of the selection process. Such
waiting list panel had expired on May 4, 2019. He has reiterated the contentions with regard to
maintainability of the writ petition. He has also reiterated the contentions with regard to Evidence
Act as also Information Technology Act advanced on behalf of similarly circumstanced persons. He
has relied upon AIR 1964 SC 1006 (State of Madhya Pradesh and another vs. Bhailal Bhai and
others), 2008 Volume 2 Supreme Court Cases 479 (Nehru Yuva Kendra Sangathan vs. Mehbub
Alam Laskar), and 2008 Volume 7 Supreme Court Cases 788 (Atma Linga Reddy and others vs.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

Union of India and others) in support of his contentions.
106. Mr Pushpal Chakraborty learned advocate appearing for the petitioners in WPA 4556 of 2023
has submitted that the writ petitioners filed the petition praying for consideration to initiate
new/fresh process for filling up the present and anticipated vacancies by adopting the established
procedures. He has contended that, a wait list cannot be a perennial source for recruitment.
107. Mr Sakti Pada Jana learned advocate appearing for the added respondent and applicant in CAN
1 of 2022 and CAN 18 of 2023 filed in WPA 13700 of 2021 has submitted that, his clients did not
jump the rank as wrongfully alleged. He has contended that, due to the wrongful action of the SSC in
recommending 8 candidates and OMR sheets being allegedly manipulated, his clients cannot be
deprived of the appointment.
108. Mr Shuvro Prokash Lahiri learned advocate appearing for the added respondents and
applicants in CAN 23 of 2023 filed in WPA 13700 of 2021, CAN 23 of 2023, CAN 24 of 2023 and
CAN 25 of 2023 filed in WPA 5406 of 2022 has contended that his clients secured the appointments
on merit and upon performing competitively. No adverse evidence either digital or physical has been
recovered as against his clients. His clients became aware of the writ petitions subsequent to the
notice issued pursuant to the order dated December 6, 2023. He has contended that, the selection
process may not be cancelled in its entirety but an effort should be made to segregate the fair
recruitees from the tainted candidates.
109. Mr Partha Sarathi Bhattacharya learned senior advocate appearing for the added respondent
Nos. 25 to 32 in WPA 13700 of 2021 has submitted that, the application for addition of party filed by
his clients was disposed of by an order dated December 20, 2023 and that his clients were added as
party respondents in the writ petition. His clients have filed an affidavit in the writ petition.
110. Mr Partha Sarathi Bhattacharya has contended that, his clients possess the requisite
qualification and are within prescribed age limit to receive the appointments. His clients had
appeared in the written test and personality test. Names of his clients had appeared in the waiting
list in connection with the selection process. Thereafter, SSC had issued recommendation letters and
the board had issued appointment letters in favour of his clients in the month of March 2020. His
clients have joined the respective post and that the service of his clients was approved by the
competent authority.
111. Mr Bhattacharya has contended that, SSC had published a list of 183 persons claiming that they
were wrongly recommended where names of his clients appear. He has contended that, no hearing
was given to his clients nor any reason assigned regarding the alleged wrong recommendation. He
has pointed out that, the panel expired on December 18, 2019 and the writ petition was filed on
August 26, 2021. He has also pointed out that, state government issued an order on May 19, 2022
for filling up of supernumerary posts of Assistant Teachers. He has also pointed out that, one person
was provided appointment pursuant to the direction of the Court dated April 18, 2022 passed in
WPA 6942 of 2022. He has also pointed out that 102 candidates were dealt with on January 6, 2023
pursuant to an order dated December 14, 2022 passed in WPA 13700 of 2021, WP No. 17273 of 2021Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

and WPA 13701 of 2021. He has contended that, such conduct goes to show that the panel was made
to operate in 2023 after expiry of the panel on December 19, 2019.
112. Mr Bhattacharya has also appeared for the applicants in CAN 31 of 2024 filed in WPA 13700 of
2021. He has pointed out that the applicants were waitlisted candidates based on their merit. Letters
of recommendation had been issued on August 3, 2020, letter of appointment had been issued in
the month of February 2021 and that, the applicants are presently rendering their services as
Assistant Teachers without any blemish. He has contended that during the 8th phase of counselling
the applicants were informed by way of SMS sent to the respective mobile phone numbers as mode
of communication for the purpose of participating in the counselling process. He has contended that
the applicants were part of a valid recruitment process is conducted by the SSC and responded to
the call of authority. His clients had no control over the process at all. He has contended that, the
applicants were part of the wait list and not the panel and therefore the allegation that the panel
expired will have no bearing so far as the applicants were concerned.
113. Mr Lakshmi Kumar Gupta learned senior advocate appearing on behalf of the applicants in
CAN 21 of 2023 and CAN 22 of 2023 filed in WPA 5406 of 2022 has contended that, there was
substantial procedural compliance of the 2016 recruitment rules for the recruitment of assistant
teachers for classes XI and XII. He has in this regard referred to the relevant rules. He has pointed
out that, the writ petition was filed 3 to 4 years after the recruitment process was concluded. He has
contended that, marks obtained by individual candidates are not required to be published as per
Rule 12. There was no judicial interpretation of this Rule and in particular Rule 12 (6) at the relevant
point of time. In absence thereof, he has contended that, an administrative interpretation could be
the only basis for the executing authority to adopt or follow. In support of such contention, he has
relied upon 1992 (Supp 1) Supreme Court Cases 584.
114. Mr Lakshmi Kumar Gupta has contended that, evaluation of OMR sheets is always outsourced
by all examining bodies. He has contended that outsourcing in the present context must not be
through open disclosure and secrecy is necessary to be maintained to protect the sanctity of the
system and to prevent outside influence. Moreover, engagement of M/s. NYSA has not been
questioned by the petitioners and hence such aspect need not be gone into by the Court.
115. Mr Lakshmi Kumar Gupta has contended that the so- called admission by SSC about the
correctness of the data comprised in the hard disk recovered from the ex-employee of M/s. NYSA
was of no consequence. The so-called admission was not unequivocal. In support of such contention,
he has relied upon 2003 SCC OnLine Bom 148 (Western Coalfields Ltd vs. Swati Industries), 2006
SCC OnLine Del 490, 2007 SCC OnLine Del 1213 and 2011 Volume 15 Supreme Court Cases 273
(Himani Alloys Limited vs. Tata Steel Limited).
116. Mr Lakshmi Kumar Gupta has questioned the maintainability of the writ petition. He has
contended that no writ petition can be filed after the expiry of the panel. In support of such
contention, he has relied upon 2002 Volume 9 Supreme Court Cases 650 (M.P. Electricity Board
through the Chief Engineer, M.P. EB and another vs. Virendra Kumar Sharma). He has contended
that the panel remains valid only till the time fixed by the Rule or on completion of appointments,Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

whichever is earlier. He has referred to 1996 Volume 9 Supreme Court Cases 309 (State of U.P. and
others vs. Harash Chandra and others) in this regard. Moreover, the panel is not the reservoir for
filling up vacancies anytime and in this regard, he has relied upon 2010 Volume 6 Supreme Court
Cases 777 (State of Orissa and another vs. Rajkishore Nanda and others). He has contended that, the
point of maintainability of the writ petition is to be considered from the point of view of laches or
unexplained delay. In this regard, he has referred to 2014 Volume 4 Supreme Court Cases 108
(Chennai Metropolitan Water Supply and Sewerage Board and others vs. T.T. Murali Babu). The
contention that documents are required to be preserved for 20 years under the Right to Information
Act is erroneous and in support of such contention, he has relied upon 2013 SCC OnLine Mad 63 (N.
Amirthaguru vs. Syndicate Bank). He has contended that, the issue raised in the writ petitions may
evoke public interest only after authenticity of the data recovered was established by applying the
rules of evidence.
117. Mr Lakshmi Kumar Gupta has contended that, no case for cancellation of the entire selection
process was made out. Entire recruitment need not be interfered with and only wrongful and illegal
appointments after the expiry of the panel needs to be set aside since the grains can be separated
from the chaff. In this regard he has relied upon 2006 Volume 11 Supreme Court Cases 356
(Inderpreet Singh Kahlon and others vs. State of Punjab and others) and 2003 Volume 7 Supreme
Court Cases 285 (Union of India and others vs. Rajesh P.U., Puthuvalnikathu and another). Issues
118. The prevenient adumbrated rival contentions have delineated the following issues for
consideration: -
i. does this Division Bench have jurisdiction to hear all the writ petitions and appeals
listed before it?
ii. are the writ petitions maintainable at the behest of unsuccessful candidates who
has filed the writ petitions subsequent to the expiry of the validity period of the
panel?
iii. can appointments be made subsequent to the expiry of the validity period of the
panel?
iv. is the certificate dated September 19, 2022 valid and admissible in evidence?
v. should the OMR sheets available in the seized hard disks be uploaded in the server
of SSC to compare with the final list stored therein?
vi. should any reliance be placed upon the data stored in the seized hard disks to
terminate the services of any employee?
vii. can the recommendations be withdrawn by SSC without hearing the appointee?
viii. whether revocation of recommendations under rule 17 by SSC is valid or not?Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

ix. to what relief or reliefs are the parties to the appeals and writ petitions entitled to?
Jurisdiction
119. Normally a writ petition filed before the Calcutta High Court is heard by a single Judge. Here we
have heard a number of writ petitions as well as appeals as a Division Bench pursuant to an order
dated November 9, 2023 passed by the Supreme Court and an order of assignment of the Chief
Justice dated November 16, 2023.
120. The order dated November 9, 2023 of the Supreme Court had been passed in a set of
proceedings arising out of the controversy in the selections/appointment of different categories of
employees in state funded schools. It would be apposite to refer to paragraph 1 of such order which
is as follows: -
"1. The present set of proceedings arises out of controversy in selection/appointment
of three categories of employees in different State funded schools in the State of West
Bengal. These are (i) non-teaching staffs belonging to Groups 'C' and 'D', (ii)
Assistant Teachers and Teachers of classes 9 and 10 and (iii) Assistant Teachers of
classes 11 and 12. Recommendations were made by the West Bengal Central School
Service Commission ("the Commission") in the years 2017-2018 for appointment to
these posts. The recruitmen process for these posts was initiated in the year 2016.
Several unsuccessful/wait-listed candidates who had participated in the said
recruitment process had approached the High Court at Calcutta questioning sanctity
of the selection process for these posts. These writ petitions were instituted in the
years 2021-22 and the unsuccessful candidates questioned the recruitments on the
ground of several irregularities."
121. The direction of the Supreme Court in the order dated November 9, 2023 with regard to hearing
of the writ petitions and the appeals by a Division Bench is contained in paragraphs 8, 9 and 11
thereof which are as follows: -
"8. In our opinion, piece-meal proceedings are not warranted in relation to the
disputes of this dimension and termination of service of candidates at the interim
stage before final disposal of the writ petitions also ought to have been avoided
having regard to the nature of the controversy involved in these proceedings. It was
necessary for the High Court to examine admissibility of the OMR sheet images
recovered by the CBI before placing full scale reliance on them in directing
termination of services of the concerned employees. We are not suggesting that in
cases of gross irregularities detected in appointment of certain individuals,
termination at the interim stage is altogether impermissible. If some grave error in
the appointment process can be demonstrated before the Court at the interim stage,
services of such illegally appointed persons can be terminated at the interlocutory
stage only. But in the present set of proceedings, at this stage the unsuccessful
candidates have not been able to make out such outstanding case at the interim stage.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

Investigation by the CBI is yet to be completed. The argument of corrupting the
original OMR sheets is yet to be supported by cogent evidence. In none of the orders
impugned before us, these is no clear cut finding that there was distortion in OMR
sheet evaluation.
9. The question of exercise of power under the aforesaid Rules also arise out of
discovery of electronically stored OMR sheets.
Serious allegations have been made of manipulation of records in exchange of money,
but these allegations would have to be established through evidence. It is also our
opinion, considering the importance of the points of law involved in these cases, the
number of persons who are likely to be affected by the outcome of these proceedings
and also having regard to the fact that majority of the writ petitions giving rise to
these proceedings have strong attributes of Public Interest Litigations (PIL), this
Court would consider it preferable to have these proceedings heard by a Division
Bench of the High Court.
11. We, accordingly, request the Hon'ble Chief Justice of the High Court at Calcutta to
constitute a Division Bench and all the writ petitions and appeals from which this set
of proceedings arise be assigned to the Bench to be constituted in the light of this
order for early adjudication. So far as 19 petitions/appeals pending before us are
concerned, we dispose of the same with an observation that in the cases where
termination orders or withdrawal of recommendations have been directed involving
the appointees described in the first paragraph of this order, such terminations or
withdrawal orders shall not be given effect to until the Division Bench of the High
Court to be constituted in pursuance of this order adjudicates the matters on merit
The direction of the Single Judge to upload the CBI recovered OMR sheets shall stand
invalidated, and the Division Bench may consider issuing a similar order only after
the authenticity of these images are established before it by applying the prevailing
Rules of evidence. We have consciously avoided in this order giving any finding on
merits of the individual cases, lest such observation or findings influence the Bench
to be constituted for hearing the subject-controversy."
122. Subsequent to the order dated November 9, 2023, the Chief Justice had by an order of
assignment dated November 16, 2023 assigned the matters to this Division Bench which is as
follows:-
"Before the Hon'ble Division Bench Presided over by Hon'ble Justice Debangsu
Basak.
The other matters which are said to be arising out of the same recruitment be
mentioned before the Hon'ble Division Bench."Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

123. In our understanding of the order dated November 9, 2023 and the order of assignment of the
Chief Justice, we have been vested with the jurisdiction to decide proceedings arising out of the
controversy in selection/appointment of non-teaching staff belonging to Group C and D as well as
teaching staff being Assistant Teachers and Teachers of classes X and X as also classes XI and XII, in
different State funded schools in the State of West Bengal for the recruitment process initiated in the
year 2016.
124. In our understanding all writ petitions relating to the recruitment process initiated in the year
2016 have not been directed to be heard by the Division Bench but only those writ petitions relating
to the categories as noted above, in respect of the 2016 recruitment process and instituted in
2021/2022 and the appeals arising out of the orders passed in such writ petitions. We have
understood paragraph 1 of the order dated November 9, 2023 to prescribe the categories of matters
as also the time limit of filing of the writ petitions required, to be decided by the Division Bench. We
have understood the order of assignment dated November 16, 2023 of the Chief Justice in such
context.
125. Consequently, we have jurisdiction to hear and dispose of appeals arising out of the orders
passed in the four categories of matters in writ petitions filed in 2021/2022.
126. Contours of our jurisdiction to decide the writ petitions and the appeals emanating out of
orders passed in such writ petitions having been adverted to, we shall now proceed to decide such
matters which fall within such parameters.
127. In view of the discussions above the first issue is answered accordingly.
Maintainability
128. Having understood the parameters of the matters which we have to decide the issue of
maintainability of the writ petitions needs to be answered. Persons opposing the writ petitions have
questioned their maintainability.
129. The order dated November 9, 2023 of the Supreme Court has enjoined upon us the obligation
to decide on the maintainability of the writ petitions.
130. Maintainability of the writ petitions have been questioned on the grounds of delay, laches and
writ petitions being at the behest of unsuccessful candidates who had participated in the selection
process and failed. Various authorities have been cited at the bar on such an issue which we shall
consider presently.
Cited Authorities on Maintainability
131. Aflatoon and others (supra) has considered the issue of delay and laches in filing of a writ
petition in the context of Land Acquisition proceedings. In the facts of that case, there had been a
delay of the 11 years. In the facts of that case, the Supreme Court had found the writ petitioners to beBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

fence sitters allowing third-party rights to intervene and therefore not entitled to reliefs.
132. In Madan Lal and others (supra) locus standi to challenge a selection process on the ground of
unfairness of the interview process and defect in constitution of Selection Committee by
unsuccessful candidates who had taken a chance to get themselves selected at the interview was
found lacking.
133. In Vijendra Kumar Verma (supra), the Supreme Court has held that, once a candidate appeared
in the interview knowing the selection criteria, without any protest at any stage, cannot turn around
to contend that the procedure adopted for selection was wrong and without jurisdiction. Similar
view had been expressed in Anil Joshi and others (supra), D. Sarojkumari (supra), Anupal Singh
and others (supra), and Mohd Mustafa (supra).
134. In Md. Kalimuddin and others (supra) the Supreme Court has held that, of where under the
statutory rule, the period of the life of the select list had already expired, High Court acted without
jurisdiction in directing extension of the validity period of such select list.
135. In Harish Chandra and others (supra) Supreme Court has held that, no mandamus can be
issued either to refrain from enforcing the law or to act contrary to the law.
136. Surinder Singh and others (supra) has explained the scope and extent of a waiting list in the
selection process. It has held that, waiting list cannot be used as an open source of recruitment for
filling up the vacancies not advertised. It has also held that, the candidates in the waiting list have
no vested right to be appointed except to the limited extent that when a candidate selected against
the existing vacancy does not join for some reason and the waiting list is still operative. The
candidates included in the waiting list cannot claim appointment on the ground that the vacancies
were not worked out properly.
137. Raghbir Chand Sharma and another (supra) has held that with the appointment of the first
candidate for the only post in respect of which the select panel was prepared, the panel ceased to
exist and had outlived its utility and no one else in the panel can legitimately contend that he should
have been offered appointment either in the vacancy arising on account of the subsequent
resignation of the person appointed from the panel or any other vacancies arising subsequently.
138. Virendra Kumar Sharma (supra) has held that, denial of appointment to a candidate in the
panel after expiry of the panel on the basis that, all vacancies were not filled up, did not call for
interference by the High Court.
139. Sanjay Kumar and others (supra) has held that, where the writ petition challenging the
selection process did not challenge the rules relating to the selection process, and arguments to such
effect was not made in writ petition, such contentions cannot be raised on appeal.
140. B. Valluvan and others (supra) has held that, period of operation of the panel can be extended
by the State and not by Court. A Selection Committee while preparing the panel is not concernedBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

with the future vacancies.
141. Nehru Yuva Kendra Sangathan (supra) has held that, only in the event of unsatisfactory
performance by the employee, the termination of probation is justified. However, when the
foundation for such an order is not an unsatisfactory performance of the part of the employee but
overt act amounting to misconduct, an opportunity of hearing to the employee concerned is
imperative.
142. Mohd. Sohrab Khan (supra) in the facts of that case has held that, once the first candidate in
the select list was appointed and subsequently his appointment was cancelled, the other person in
the panel cannot claim appointment since there was only one post which stood filled up the
appointment of the 4 selected candidates.
143. In Rajkishore Nanda and others (supra), Supreme Court has held that, select list cannot be
treated as a perpetual reservoir for purpose of appointments. If the selection process was over
whereby select list had expired and appointments had been made, no relief can be granted by the
Court subsequently on the basis of the expired select list.
144. In T. T. Murali Babu (supra) the Supreme Court has held that four years delay in filing writ
petition challenging the dismissal order was fatal. It has observed that, delay comes in way of equity
and although delay and laches may not be fatal in all circumstances, inordinate delay brings in
hazard and cause injury to the lis. In given circumstances, delay may affect others' rights and may
unnecessarily drag others into litigation which in acceptable realm of possibility may have attained
finality.
145. N. Murugesan and others (supra) has considered the issue of delay, laches and acquiescence in
the context of a writ petition and whether, delay/laches/limitation affects the discretionary nature of
relief that may be granted under Article 226 of the Constitution. It has considered a number of
authorities on the subject including T. T. Murali Babu (supra) and held as follows: -
"Delay, laches and acquiescence
20. The principles governing delay, laches, and acquiescence are overlapping and
interconnected on many occasions. However, they have their distinct characters and
distinct elements. One can say that delay is the genus to which laches and
acquiescence are species. Similarly, laches might be called a genus to a species by
name acquiescence. However, there may be a case where acquiescence is involved,
but not laches. These principles are common law principles, and perhaps one could
identify that these principles find place in various statutes which restrict the period of
limitation and create non- consideration of condonation in certain circumstances.
They are bound to be applied by way of practice requiring prudence of the Court than
of a strict application of law. The underlying principle governing these concepts
would be one of estoppel. The question of prejudice is also an important issue to be
taken note of by the Court.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

Laches
21. The word "laches" is derived from the French language meaning "remissness and
slackness". It thus involves unreasonable delay or negligence in pursuing a claim
involving an equitable relief while causing prejudice to the other party. It is neglect
on the part of a party to do an act which law requires while asserting a right, and
therefore, must stand in the way of the party getting relief or remedy.
22. Two essential factors to be seen are the length of the delay and the nature of acts
done during the interval. As stated, it would also involve acquiescence on the part of
the party approaching the Court apart from the change in position in the
interregnum. Therefore, it would be unjustifiable for a Court of Equity to confer a
remedy on a party who knocks its doors when his acts would indicate a waiver of such
a right. By his conduct, he has put the other party in a particular position, and
therefore, it would be unreasonable to facilitate a challenge before the Court. Thus, a
man responsible for his conduct on equity is not expected to be allowed to avail a
remedy.
23. A defence of laches can only be allowed when there is no statutory bar. The
question as to whether there exists a clear case of laches on the part of a person
seeking a remedy is one of fact and so also that of prejudice. The said principle may
not have any application when the existence of fraud is pleaded and proved by the
other side. To determine the difference between the concept of laches and
acquiescence is that, in a case involving mere laches, the principle of estoppel would
apply to all the defences that are available to a party. Therefore, a defendant can
succeed on the various grounds raised by the plaintiff, while an issue concerned alone
would be amenable to acquiescence.
Acquiescence
24. We have already discussed the relationship between acquiescence on the one
hand and delay and laches on the other.
25. Acquiescence would mean a tacit or passive acceptance. It is implied and
reluctant consent to an act. In other words, such an action would qualify a passive
assent. Thus, when acquiescence takes place, it presupposes knowledge against a
particular act. From the knowledge comes passive acceptance, therefore instead of
taking any action against any alleged refusal to perform the original contract, despite
adequate knowledge of its terms, and instead being allowed to continue by
consciously ignoring it and thereafter proceeding further, acquiescence does take
place. As a consequence, it reintroduces a new implied agreement between the
parties.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

Once such a situation arises, it is not open to the party that acquiesced itself to insist
upon the compliance of the original terms. Hence, what is essential, is the conduct of
the parties. We only dealt with the distinction involving a mere acquiescence. When
acquiescence is followed by delay, it may become laches. Here again, we are inclined
to hold that the concept of acquiescence is to be seen on a case-to-case basis."
Analysis of the Cited Authorities on Maintainability
146. The authorities cited at the bar have underscored the underlying principle governing delay,
laches and acquiescence to defeat a writ petition to be estoppel and prejudice. In the facts and
circumstances of a given case, if the writ petitioner is found to be guilty of such delay and laches so
as to have allowed third party rights to intervene and attain finality then such writ petition is not to
be entertained. Similarly, when a writ petitioner is found to have acquiesced in a particular course of
action, he is held to be estopped from questioning the same. However, these defences of delay,
laches and acquiescence would not have application when the existence of fraud is established.
147. No appointment can be made after expiry of the panel as the panel is not a perennial reservoir
for appointments. Panel is valid for the declared vacancy and for the specified period. Appointments
towards future vacancies cannot be made from the panel. Appointments made in violation of
Articles 14 and 16 of the Constitution of India are a nullity. Courts have no jurisdiction to direct
appointment to be made beyond the validity period of the panel. Nature of the writ petitions
148. We have to appreciate the timeline of the cause of action leading to the filing of the writ
petitions as also the events subsequent thereto in order to pronounce whether the defence of delay,
laches and acquiescence setup by the private respondents to the writ petition, merits acceptance or
not.
149. A number of writ petitions relating to the four categories of the 2016 recruitment process had
been filed during the period 2021 and 2022. The learned single Judge had considered a member of
them and passed orders from time to time therein. We shall advert to some of the orders passed
after outlying briefly the cause of action, averments and prayers in some of the writ petitions.
150. A candidate who had participated in the recruitment notification for third Regional Level
Selection Test 2016 for the post of clerk (Group-C) has filed WPA 14612 of 2021. He had averred in
his writ petition that, the Board had issued a provisional appointment letter in his favour for such
post on March 20, 2020. He has stated that, such letter was issued three days before the
commencement of the Covid pandemic. He had gone to the school at which, he was given the
appointment, but was not allowed to join. He had prayed for a writ to allow him to join the post of
clerk in the school on the basis of the appointment letter dated March 20, 2020.
151. Writ petitioners in WPA 12266 of 2021 have alleged that, they participated in the selection
process for Group-D. They have claimed that, the authorities had acted de hors the 2009 Rules by
not publishing the fourth phase counselling list and not calling the petitioners thereto. They have
claimed that the authorities did not prepare and publish the panel in accordance with 2009 RulesBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

and that, the entire panel was full of discrepancies. They have alleged that the entire selection
process lacked transparency. They have claimed that, several candidates holding rank below them
had been given appointment. They have given details of some of the persons who were ranked below
them but given appointments. They have sought appointment to the Group-D post and cancellation
of the notification declaring the panel to be expired.
152. Another candidate who had participated in the selection process for the post of Group-D has
filed WPA 27106 of 2022. He has prayed for consideration of his representation dated October 22,
2022.
153. Writ petitioners in WPA 12270 of 2021 have alleged that, the writ petitioners therein were in
the waiting list in respect of the Group-D post. Writ petitioners have stated that, panel was
published on June 20, 2019 and that, thereafter on June 14, 2021, the authorities had issued a
notification for initiating further process of recruitment. The writ petitioners have prayed for a
direction upon the authorities to call the petitioners for counselling and appoint them in the post of
Group-D in terms of the notifications dated August 8, 2016 and to fill up remaining 44 vacancies by
appointing the writ petitioners therein. The writ petitioners have also sought cancellation of the
memo dated September 2, 2019. Writ petitioners have also sought a direction upon the authorities
to publish the merit list/panels of candidates already appointed in the post of Group-D disclosing
full details including marks obtained by them and the marks obtained by the writ petitioners. In
such writ petition, the writ petitioners have alleged that, several of candidates had been
recommended for appointment to the post of Group-D although they did not feature in the merit
list. Moreover, candidates securing marks below them had been given appointment.
154. Candidates who had participated in selection process for the post of assistant teachers in
Classes IX and X in the subject History has filed WPA 13700 of 2021. They have alleged that; the
authorities did not act in accordance with recruitment rules. The authorities had adopted a pick and
choose formula in selecting candidates for appointment, as a result of which less meritorious
favourite candidate got preference over more meritorious candidates. The writ petitioners have been
denied their legitimate right to get an appointment. The respondent authorities did not call the
petitioners for counselling whimsically and arbitrary. The respondent authorities had given
appointment to the below rank holder and the writ petitioners had given some instance with regard
thereto. They had prayed for appointment to themselves and a direction upon the authorities to
publish a de novo panel and waiting list in accordance with the actual merits and in terms of the
Rules prescribed.
155. Another unsuccessful candidate for the post of assistant Teachers for Classes IX and X has filed
WPA 17273 of 2021. The writ petitioner has given one instance of a candidate not listed either in the
merit list or in the waiting list, given an appointment and such candidate joining the school. Writ
petitioner has prayed for grant of appointment to himself and preparation and the publication of de
novo panel and waiting list in accordance with merits and in terms of Rules.
156. Candidates who had participated in the selection process for the Group-D posts has filed WPA
18585 of 2021. They have alleged, there were various illegalities in the merit list. They have alsoBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

alleged that below rank holders in their category and persons who were not even listed in the merit
list had been given appointment. They have sought a direction for giving appointment to them and
for publication of the merit list.
157. WPA 5406 of 2022 had been filed by a writ petitioner claiming a direction upon the respondent
to issue appointment to such writ petitioner as Assistant Teacher for the subject of Political Science
(PG) in connection with the first State Level Selection Test 2016, recruitment of Assistant Teachers
for classes XI and XII.
158. There are other writ petitions, falling under our determination/jurisdiction, which we have
heard. We are not detailing each one of them for the sake of brevity and as the writ petitions
depicted above largely represents a cross section of the other petitions.
159. Writ petitioners had approached Court essentially for redressal of their private grievances
emanating out of their participation of a public selection process. Have the subsequent events
transformed these writ petitions to public interest litigation needs to be decided. Delay on part of
Writ Petitioners and Maintainability
160. At the time when, the writ petitioners had approached the Court, they were interested in
securing employment for themselves rather than having the entire selection process nullified.
Moreover, most of the writ petitioners had been unsuccessful in the selection process. We say most
since the writ petitioner in WPA 14612 of 2021 claimed to be successful, given an appointment letter
and not allowed to join. He cannot be held guilty of delay as his appointment letter is dated March
20, 2020. Covid intervened thereafter and he has filed the writ petition in 2021 when remnants of
Covid was still continuing.
161. Delay on the part of the writ petitioners as also they being unsuccessful candidates would
ordinarily have visited the writ petitioners with a devastatingly negative result on the writ petition
filed by them. The negative result would however have been after a final hearing in the writ petition.
None of the writ petitions could have been dismissed on the ground that they did not disclose a
cause of action or was barred by law.
162. It has been contended on behalf of the private respondents opposing the writ petitions that,
since on the date of the filing of the writ petition, the same was not maintainable, no order should
have been passed excepting one of dismissal of the writ petition.
163. On a purposive reading of the writ petitions, one cannot arrive at an explicit finding that, any of
the writ petitions or the prayers made therein are barred by law or do not disclose a cause of action.
The writ petitioners are entitled to approach the writ Court with the prayers made on the basis of the
pleadings as existing in the writ petitions. At the bare minimum the writ petitioners allege
misadventure by the authorities in the selection process. The writ petitioners are participants of the
selection process, albeit unsuccessfully by most, in respect of which they allege misadventure. They
are entitled to a fair consideration in the selection process, a fundamental right under Article 14,
denial of which they allege in the writ petitions.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

164. In respect of all categories of the 2016 selection process the common allegations are that, merit
list contemplated under the Rules of the selection process governing the category was never
published, persons not featuring either in the merit list or the waiting list were given appointment,
below ranked candidates were favoured with appointments, and appointments given after expiry of
the panel. None of these allegations can be construed to be unmeritorious of consideration of a writ
Court even if made at the behest of an unsuccessful candidate. Such allegations if proved would
mean that selection process had violated the fundamental right of the unsuccessful candidate to be
treated fairly in the selection process. That would have made the writ petition at the behest of
unsuccessful candidate not only maintainable but entitled the writ petitioner appropriate reliefs.
165. Delay aspect needs consideration from the Covid perspective also. Entire country went into
lockdown for a considerable period in 2020 -2021. The selection process had culminated just prior
to the onset of the Covid lockdown. Therefore, to hold the time period lost due to the Covid
lockdown as against the writ petitioners as they had been unsuccessful would be a travesty of justice.
166. The nature of misadventure alleged is such that, such allegation cannot be dismissed at the
threshold as not disclosing a cause of action to approach a writ Court or such allegation being barred
by law must not be enquired into by a writ Court. Quite to the contrary, if the statements made in
the writ petitions are taken as true and correct then they make out a case of transgression of
fundamental right to be treated fairly in a selection process undertaken by a State authority.
Whether the writ petitioners would ultimately receive any relief on the basis of the pleadings of the
parties completed after affording the parties opportunity of filing affidavits, and the prayers made in
such writ petitions, would be a different issue.
167. On the face of the pleadings contained in the writ petitions and taking such pleadings to be true
and correct, on the principles akin to considerations of an application under Order VII Rule 11 of the
Code of Civil Procedure, 1908, it cannot be said that, any of the writ petitions are barred by law or
does not disclose a cause of action, and that any of them must be dismissed as not maintainable at
the threshold.
168. Having returned the finding that, none of the writ petitions could not have been dismissed as
the threshold on the ground that it was barred by law or did not disclose any cause of action, in our
view, the issue of maintainability should not be decided on the limited prism of the pleadings
available in the writ petitions to the exclusion of all other materials, but a decision on such an issue
should also encompass the sequel of events happening subsequent to the filing of the writ petitions,
affidavits and reports filed therein and the orders passed from time to time.
169. Group-D selection process is governed by the West Bengal Selection Service Commission
(Selection of persons for appointment to the post of Non-Teaching Staff) Rules, 2009 which had
been notified on July 09, 2016. Subsequent thereto, recruitment notification for vacancy had been
published for the post of Group-D staff on August 08, 2016. Written test in respect of such selection
process had been held on February 19, 2017. Panel for both eligible candidates as well as wait-listed
candidates had been prepared and published on November 06, 2017. Personality test and
counseling had been held in 2018. SSC had commenced issuance of recommendation letters fromBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

February, 2018 and in turn West Bengal Board of Secondary Education had issued appointment
letters. Candidates had commenced joining their respective posts since April 2018. Appointment
and service of such candidates had been approved by the District Inspector of Schools, from the
respective date of joining, commencing from the period June, 2018. The panel including the wait-
listed candidate panel had expired on May 04, 2019.
170. Two writ petitions being WPA 12266 and 12270 of 2021 had been filed before the High Court
alleging that, appointment letters in respect of Group-D staff were issued even after expiry of the
term of panel. These writ petitions had been filed in August, 2021. Wait-listed candidates had filed
writ petition relating to appointment to the post of Assistant Teachers for Classes IX and X being
WPA 13700 of 2021 alleging that they had priority in the waiting list as they were placed higher than
some who were given the appointment. This writ petition had been filed in September, 2021. Court's
Orders on the Writ Petitions
171. By an order dated November 09, 2021 passed in WPA 12270 of 2021 (writ petition relating to
Group-D), the High Court has directed the Commission to file an affidavit explaining the situation.
172. On November 22, 2021, wait-listed candidates for Group-D have filed a writ petition being WPA
18585 of 2021 alleging that they had priority in the waiting list and that persons who were placed
lower than them in the waiting list had been given appointment. On the same day, an order was
passed in WPA 12266 of 2021 (Group D writ petition) directing investigation by the CBI after noting
the submissions made on behalf of the Board claiming that they had received recommendations in
the proper manner. Court had also directed 542 persons to be added as parties to such writ petition.
Appeal had been preferred against the order dated November 21, 2021. Order directing investigation
by CBI has not been interfered with upto Supreme Court. CBI had conducted the investigation
pursuant to orders of the Court. CBI has filed charge sheet before the jurisdictional Court.
173. On November 30, 2021, the Court had noted that, SSC in its affidavit denied issuing
recommendation letters annexed to the writ petition. The Court had also allowed 350 other persons
to be added as party respondents in such writ petition.
174. On December 02, 2021, the Court in WPA 12270 of 2021 and WPA 14612 of 2021 had called
upon the Commission to explain by way of an affidavit how the recommendation letters and the
subsequent appointment letters had been issued. The Court had passed another order on December
14, 2021 in the both the above noted writ petitions calling for certain particulars from the SSC with
regard to the vacancies and the persons recommended for appointment in Group-C.
175. In WPA 12266 of 2021 (writ petition relating to Group- D), Court by an order dated February
09, 2022, had directed publication of information relating to 573 candidates, on its official website,
whose appointments were held to be invalid since the recommendations were issued after the expiry
of the panel. SSC had complied with such directions and uploaded the particulars of such candidates
in its website. In the same writ petition, another order dated February 15, 2022 had been passed
directing stopping the salary of 350 persons and requiring those 350 persons to refund their salary
as they had received appointment subsequent to the expiry of the panel.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

176. By an order dated February 22, 2022, passed in WPA 13700 of 2021 (Writ petition relating to
Assistant Teachers for Classes IX and X), the Court after considering the reports of SSC, had found
the respondent no.6 therein not to be entitled for appointment as the writ petitioner was found not
to be within the zone of consideration by SSC. Respondent No.6 was directed to refund the salary
that had been received with liberty to sue the government.
177. The learned single Judge has by an order dated March 3, 2022 passed in WPA 13700 2021
noted that, in paragraph 5 of the affidavit of SSC affirmed on March 3, 2022, it has been stated that,
generally recommendation letters are issued in favour of the empanelled wait listed candidates on
the date of counselling after opting the school by the respective candidates, but in respect of
respondent No. 6, he was not called for counselling and in spite of that recommendation letter was
issued in favour of respondent No. 6.
178. Learned single Judge had held by an order on March 3, 2022 passed in WPA 13700 of 2021
that, there was no delay in filing of the writ petition since, the writ petitioner could not know about
such misconduct in the selection process at the time of filing of the writ petition.
179. By an order dated March 08, 2022, passed in WPA 18585 of 2021, the Court had directed SSC
to submit a report about the status of certain persons. In such writ petition, the Court had directed
adding 98 persons as respondents upon the request of the writ petitioners by an order dated March
17, 2022. Noting that a large number of writ petitions alleging illegal appointment had been filed, by
an order dated March 31, 2022 passed in WPA 18585 of 2021, the Court directed the CBI to question
a member of SSC in order to bust the racket of giving illegal appointments.
180. On April 01, 2022, the Court had passed an order in WPA 18585 of 2021 effectively terminating
the appointments of 90 persons and directing the CBI to register a case and commence
investigations including interrogations.
181. Applications for stay were filed in WPA 18585 of 2021 which were disallowed by an order dated
April 04, 2022 by the Court. On April 05, 2022, the Court had directed the CBI to commence
interrogation of a member of the Board of SSC and if thought fit by CBI, commence custodial
interrogation of such member. Another order was passed on April 06, 2022 in such writ petition
directing two other persons to proceed to the office of the CBI for further interrogation.
182. On April 07, 2022, an order was passed in WPA 5538 of 2022 where the Court had observed
that deliberate false statements had been made by a member of the five-member committee. The
Court had directed investigations to be conducted by CBI and a new case be registered in relation to
appointments of Assistant Teachers for Classes IX and X. CBI had submitted a report in WPA 5538
of 2022 on April 08, 2022 when the Court had given further directions.
183. The Court had adjourned WPA 18585 of 2021 till May 17, 2022 in view of the pending appeals.
On May 18, 2022, the Court had passed an order in WPA 18585 of 2021 directing four persons
named in such order and the then Education Minister to report before CBI and to be interrogated by
CBI. If necessary, CBI had been permitted to take custody of such persons for interrogation.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

184. Three orders had been passed by the learned single Judge on May 18, 2022. In WPA 18585 of
2021, the learned single Judge had directed the officer on special duty, Minister in charge,
Parliamentary affairs, Senior Law Officer in the Department of Education, Deputy Director, School
Education and Joint Secretary cum- Private Secretary of the Minister in Charge to attend the office
of the CBI for interrogation. The learned single Judge had also directed the then Education Minister
to attend the office of the CBI for interrogation.
185. The learned single Judge had passed an order on May 18, 2022 in WPA 5538 of 2022 where the
learned Judge had expressed his expectations that the Minister should step down. Another order
was passed in WPA 12270 on the same date taking note of the contention of the writ petitioners that
some persons had entered the office of the SSC and were interfering with the records including
computer records. The Court had directed the Secretary of SSC to produce the CCTV footage and
directed CRPF to deploy to protect the office of SSC.
186. On May 20, 2022 the learned Single Judge had passed 2 orders, one in WPA 18585 of 2021
where the learned single Judge directed the Minister to be added as a party respondent in such writ
petition. The learned single Judge had also directed affidavit of assets of various respondents to be
kept on record. The learned single Judge had passed another order in WPA 12270 of 2021 where
CRPF were directed to allow employees of SSC into the building without impediment as CBI had
already sealed and taken possession of the assets and the records in the data room.
187. On June 17, 2022, the learned single Judge had kept a report of CBI filed in WPA 18585 of 2021
and WPA 12266 of 2021 in the records of WPA 12266 of 2021. The learned single Judge had allowed
SSC access to the data room, on its prayer, after recording that CBI had already obtained the
necessary information, material and records for its investigation, by an order passed in WPA 12270
of 2021.
188. By an order dated June 23, 2022 passed in WPA 12270 of 2021 the learned single Judge had
allowed certain papers to be handed over to CBI by opening the office of the erstwhile Justice Bag
Committee.
189. The learned single Judge had dealt with the singular case of a daughter of a minister who was
appointed as an Assistant Teacher in the concerned selection process and termed the service of such
daughter as stealing the service of another. The learned single Judge had directed the monies
received by her to be refunded.
190. By an order dated September 9, 2022, the learned single Judge had directed the handing over
of the data room to SSC.
191. By an order dated September 21, 2022 passed in WPA 18585 of 2021, the learned single Judge
had observed that, since appointments given to 573 candidates were declared as invalid, SSC should
take immediate action to fill up such vacancies. In WPA 5538 of 2022, the learned single Judge had
directed SSC to hold meeting with the learned advocate for the petitioner and of the Board and file a
report, regarding how many illegal appointments have been detected. CBI had also been directed toBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

file a report. The learned single Judge had directed that the process of giving appointments to the
genuine candidates should start immediately. In WPA 12270 of 2021 the learned single such had
found that 350 persons had been appointed after expiry of the panel and directed SSC to give
recommendation to 350 persons from the wait list and to hold counselling for such vacancies.
192. On September 28, 2022, the learned single Judge had passed an order in WPA 12266 of 2021,
WPA 12270 of 2021, WPA 13700 2021, WPA 13701 of 2021, WPA 17273 of 2021, WPA 18585 of 2021
and WPA 5528 of 2022 where the learned single Judge had noted that CBI filed four status reports.
The learned single Judge had observed that a large number of blank OMR sheets were found by CBI.
Learned single Judge had directed CBI to give the names and roll numbers of the persons who
submitted such type of OMR sheet for the selection process to be checked by SSC whether such
persons received recommendations and appointments or not. The learned single Judge had
extended a request to the persons receiving such illegal appointments to resign by November 19,
2022 assuring such persons of protection. The learned single Judge had also directed uploading of
the order in the website of SSC and a short advertisement to be published in a prominent place in
newspapers stating that an order in respect of illegal appointments have been passed by the Court
which is available in the website of SSC.
193. The learned single Judge had considered CAN 2 of 2022 filed in WPA 5538 of 2022 on
November 16, 2022. By CAN 2 of 2022, SSC wanted permission for creation of supernumerary post.
The learned single Judge had recorded that such application proposed creation of supernumerary
post to accommodate those appointees whose appointments may subsequently be found to be
invalid. The learned single Judge had directed the Secretary of the SCC to come with the file under
which instructions were issued for drafting and filing such application.
194. On the same day, the learned single Judge had issued directions to the CBI with regard to
investigation and reconstituted the Special Investigating Team. Learned single Judge had also
issued directions with regard to CAN/2/2022.
195. On November 23, 2022, the Chairman of SSC appeared before the High Court and sought to
take responsibility for filing CAN 2 of 2022 in WPA 5538 of 2022 and CAN 6 of 2022 in WPA 12266
of 2021. The learned single Judge had disbelieved the Chairman, SSC with regard to him taking the
responsibility. The learned single Judge had directed the Principal Secretary, Government of West
Bengal to appear personally on the next date for answering the questions pertaining to the matter.
The learned single Judge had directed the CBI to investigate the matter and also directed SSC to
start the counseling process and publish the details of the panel.
196. By an order dated November 25, 2022, passed in WPA 5538 of 2022, the learned single Judge
had taken on record a cabinet note and cabinet memorandum produced before it in a sealed cover.
The learned single Judge had dispensed with the personal appearance of the Principal Secretary,
Department of Education owing to the stay granted by the Hon'ble Supreme Court.
197. By an order dated December 6, 2022 passed in WPA 18585 of 2021, the learned single Judge
had noted the submission of CBI that manipulations were found in the data of 2823 candidates andBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

directed the petitioners to attend the meeting with CBI and SSC in respect of comparative study of
100 OMR sheets.
198. Justice Bag Committee had submitted a report detailing some of the illegalities committed in
the selection process. Such report had been taken into consideration by the coordinate Division
Bench then seisen of the appeals.
199. By an order dated December 15, 2022, the learned single Judge upon being appraised that Mr.
Subiresh Bhattacharayya had been arrested sought a report from the District and Session Judge, 24
Parganas South, Alipur.
200. By an order dated December 21, 2022 passed in WPA 18585 of 2021, the learned single Judge
had noted the report of CBI filed in the form of an affidavit in WPA 13700 of 2021 to the effect that,
there were huge numbers of manipulations/mismatch in the evaluated marks of OMR sheets
pertaining to the selection tests to Group C, D as well as Assistant Teachers of classes IX, X, XI and
XII. The learned single Judge had directed the Enforcement Directorate to be made as a party
respondent in the writ petition. The learned single Judge had directed CBI to continue with the
investigation and that such investigation would be monitored by the High Court.
201. By an order dated January 13, 2023 passed in WPA 18585 of 2021, the learned single Judge had
directed SSC to file a report in form of an affidavit about the figures pertaining to the 2016
recruitment process for Group D post. The learned single Judge had directed SSC to upload all OMR
sheets received from the CBI and the list of 4,487 candidates.
202. By an order dated February 2, 2023 passed in WPA 25380 of 2022, another learned single
Judge had noticed manipulation of marks in the OMR sheet of the candidates named under
paragraph 9 and 10 of the writ petition. Such writ petition had been filed in relation to appointments
granted to Assistant Teachers in classes IX and X. Such order had also noted the submission made
on behalf of SSC that recommendations of appointment in respect of candidates named in
paragraph 9 and 10 of the writ petition was erroneous.
203. The same learned single Judge who had passed the order dated February 2, 2023 in WPA
25380 of 2022 had passed an order dated February 8, 2023 in the same writ petition. The learned
judge had noted an affidavit filed on behalf of SSC in such writ petition. In fact, the learned single
Judge had set out the relevant paragraphs of such writ petition. In such affidavit, SSC had stated
that 937 persons had been identified against whom Rule 17, that is, revoking the recommendation
should be made. The order has recorded the undertaking of SSC to initiate the process in cancelling
the recommendations in 7 days' time.
204. By an order dated February 9, 2023 passed in WPA 18585 of 2021, the learned single Judge
had directed SSC to file an affidavit and directed SSC and the Board to take steps against 2,819
candidates out of which 1,698 were appointed.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

205. By an order dated February 10, 2023, the learned single Judge had cancelled the
recommendation of SSC and appointment letter issued by the Board and directed candidates to
refund the salaries received and not to sit in any examination. SSC and Board had cancelled the
recommendation letters as well as the appointment letters on February 10, 2023 itself. SSC had
published a notification for counseling for the post thereby falling vacant, on February 10, 2023.
206. Appeal directed against invocation of Rule 17 as had been directed by the order dated February
10, 2023 passed in WPA 25380 of 2022 was upheld by the Division Bench on March 1, 2023 in MAT
245 of 2023.
207. SSC had published a list of wait listed candidates for counseling of Group D post on February
11, 2023.
208. Several appeals had been preferred against the order dated February 10, 2023 of the learned
single Judge being MAT/250/2023, MAT/274/2023, MAT/259/2023, MAT/284/2023 and
MAT/276/2023. The Division Bench had stayed a part of paragraph 19 of the order dated February
10, 2023 of the learned single Judge but refused to stay any other portion of such impugned order.
209. Several Special Leave Petitions had been filed before the Hon'ble Supreme Court directed
against the order of the Division Bench dated February 16, 2023 when the Hon'ble Supreme Court
stayed the counselling for wait listed candidates that were scheduled to fill up the vacancies created
after the termination of the employment. The Hon'ble Supreme Court had passed an order on May 1,
2023 staying the impugned order of the Division Bench till the next hearing. Ultimately, such
Special Leave Petition had been disposed of by the order dated November 9, 2023.
210. In the interregnum, another learned Single Judge had passed an order dated December 22,
2022 in WPA 27106 of 2022 directing service of such writ petition on the Group D employees. On
January 24, 2023, some employees of Group D had appeared before the other learned single Judge
and had prayed for being added as parties to such writ petition. Another order by the other learned
Single Judge had been passed in February 8, 2023 in such writ petition.
211. This timeline of events occurring during the selection process up to the orders passed in the writ
petitions largely permeates to the other three categories of employment involved in the batch of writ
petitions under consideration by us. The orders passed in the writ petitions have resonance across
all the categories.
212. The writ petitions have SSC, Board, CBI, ED and State Government as parties. We should take
into consideration the stand taken and role that had been played by these Article 12 authorities
during the proceedings. Affidavits and Reports of SSC
213. SSC had filed several affidavits and reports in the proceedings some of which are noted
thereafter.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

214. SSC by an affidavit affirmed on March 3, 2021 in WPA 13700 of 2021 where SSC has admitted
that the private respondent in such writ petition was "inadvertently and by mistake recommended
by S and after such detection and the Commission has taken a decision for taking appropriate steps
for correction of such mistake regarding recommendation of the respondent No. 6 in terms of Rule
17".
215. It has affirmed an affidavit on March 11, 2022 in WPA No. 18590 of 2021 where SSC referred to
its earlier affidavit affirmed on November 9, 2021 in WPA 12270 2021 and stated that, no
recommendation had been made either by the Central Commission or any of the Regional
Commissions, in the post of Group C staff after expiry of the panel on May 18, 2019 and that the
recommendations made after May 18, 2019 were not issued from any of the offices of the
Commission. It has admitted that a recommendation letter came to be issued in favour of one of the
candidates in such writ petition on December 20, 2019 and that has not been issued by SSC.
216. It has also affirmed an affidavit on the same date in WPA No. 21268 of 2021 where SSC
admitted that, "upon perusal of the office record it appears that the private respondent No. 7 namely
Siddik Gazi was recommended by the Commission without following the extant rules and
procedures and that the said recommendation was a faulty recommendation". It has stated that, SSC
decided to cancel such erroneous recommendation of the private respondent.
217. Similarly, by an affidavit of the same date in WPA No. 21258 of 2021 SSC has admitted that the
private respondent No. 7 in such writ petition was "recommended by the Commission without
moving the relevant provisions of rule and that the said recommendations were faulty and not
tenable".
218. It has affirmed two affidavits in March 2022 one in WPA 18802 of 2021 and the other in WPA
18381 of 2021. In WPA 18802 of 2021 SSC admitted that, the respondent Nos. 6 and 7 in such writ
petition were "neither included in the merit list nor in the waiting list and their recommendation
letters were issued without following the procedure and hence were faulty recommendations".
219. It has in WPA 18381 of 2021 stated that, the private respondent's therein "were recommended
by the Commission without following the relevant rules and procedures and fit to be dealt with in
terms of Rule 17".
220. In WPA 18387 of 2021 SSC has stated that, the private respondents therein were recommended
by the Commission without opening the provisions of the relevant rules and that such
recommendations were faulty and not tenable.
221. It has affirmed an affidavit on March 9, 2022 in WPA 18379 of 2021 where it has stated that,
the respondent No. 6 and 7 in such writ petition had been recommended without following the
extant rules and procedures. SSC has taken steps for cancellation or withdrawal of such
recommendation.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

222. It has submitted a report in the form of affidavit affirmed on February 14, 2022 in WPA 17273
of 2091 pursuant to an order dated January 4, 2022 admitting that the private respondents therein
were recommended without they not being in either the merit list or in the waiting list. Writ
petitioner had taken an exception to the report. SSC has filed another report in the form of an
affidavit were, it stated that, SSC on verification of the records available in the office of the
Commission, it "has managed to detect 183 number of candidates who were wrongly recommended
for appointment by the Commission, 20 of whom have already had their recommendations
cancelled. The 183 number of candidates includes the 16 persons referred to in paragraph 15 of the
said application. It is to mention that in the list as in paragraph 15, the details of first person were
not specified and could not be identified". It has gone on to say that, "there may be more candidates
who were only recommended for appointment by the Commission, for which I most humbly pray for
some time to further verify the records". Referring to the investigations by CBI, the report has stated
that, "the Chairman and the Secretary of the Commission have had several meetings with the
officials of the CBI including the Head of Branch ACB were from it appeared that in the course of
their investigation/interrogation they have also come across a considerable number of illegal
appointments".
223. SSC in a report in the form of an affidavit filed in WPA 13701 of 2021 has admitted that, private
respondents in such writ petition were "inadvertently and by mistake recommended by the
Commission and after such detection the Commission has taken a decision for taking appropriate
steps for correction of such mistake". Writ petitioner therein had taken an exception to such report.
SSC has filed a report in the form of an affidavit therein were, it contended that, the alleged
irregularities in recommendations pointed out in the exception to the report was without any basis.
224. The added respondent No. 7 in WPA 13700 of 2021 has filed an affidavit in compliance with the
order dated February 28, 2022 passed by the learned single Judge. There, he has stated that, he was
appointed as the Chairman of SSC by an order dated January 9, 2019. He had taken charge in the
late evening of January 9, 2019 and that for all practical purposes he was functioning as the
Chairman on and from January 10, 2019 morning. He had been released from the post of Chairman
SSC by the added respondent No. 8 on January 15, 2020 pursuant to an order dated January 13,
2020. He has stated that, while in the office of Chairman, SSC, his mother expired on December 4,
2019 and he went to his native place for performing the last rites. In view of his absence, the then
Secretary of the Commission had been appointed as the Chairman of SSC by an order dated
December 4, 2019. He had resumed his duties as the Chairman of SSC on December 19, 2019 in the
forenoon. According to him, he had discharged duties of the Chairman, SSC on and from January
10, 2019 till January 15, 2020 excluding the period December 4, 2019 till December 18, 2019.
According to him, the first recommendation letter in the name of respondent No. 6 that had been
issued on December 18, 2019 when he was not the Chairman of SSC and that the signature
appearing in such recommendation letter was not his signature. The 2nd recommendation letter in
the name of the respondent No. 6 had been issued on February 25, 2020 when he was no longer in
the office of the Chairman, SSC and that the signature appearing in such recommendation letter was
not his signature. He has stated that, he had no knowledge as to the issuance of such
recommendation letter. He has averred that, on the dates when the 7th phase of counselling of wait
listed candidates was notified and postponed and rescheduled, he was not the Chairman of SSC.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

None of those notifications had been issued under his seal and signature. He did not have any
intimation, idea or knowledge of the issuance of any such notification. He also did not have any idea
or knowledge of issuance of any recommendation letter/letters issued in favour of any candidate
after the expiry of the validity period of the concerned panels and waiting lists. The same were not
issued, if any, at all, with prior consultation with him or after obtaining prior permission or consent
from him. He has stated that, if any letter is found to be issued under his signature, the same was
not issued without his permission or consent and that he did not have any idea or knowledge of the
same and that he was no way responsible for the same.
225. The Assistant Secretary of SSC has filed an affidavit pursuant to the order dated February 28,
2022 in WPA 13700 2021 stating that, he had acted as the Chairman in charge of SSC for the period
from December 4, 2019 till December 18, 2019 and subsequently from January 15, 2020 till
December 16, 2020. He has stated that, the recommendation letters dated December 18, 2019 and
February 25, 2020 issued in favour of the respondent No. 6 were under the scanned signature of the
Chairman, SSC and that, the recommendation letters had been issued in favour of respondent No. 6
without calling him for counselling. He has stated that, for the purpose of issuance of
recommendation letters to the candidates only the Programme Officer can generate
recommendation letter without utilising the scanned signature of the Chairman. He has stated that,
the then Advisor, SSC had looked after the work of issuing recommendation letters.
226. The Secretary of SCC has filed a report in the form of an affidavit in WPA 18585 of 2021. He
has stated that, recommendation letters were issued after the expiry of the panel and that the facts
are similar to the facts of WPA 12266 of 2021. In such affidavit it was stated that, the southern
region did not issue the recommendation letters in favour of two persons, western region stated that
they did not issue recommendation letters in respect of 96 persons. Another report in the form of an
affidavit had been affirmed on behalf of SSC in WPA 18585 of 2021 where, it was denied that any
recommendation was made by SSC in respect of pages 72, 73, 85 and 86 of writ petition.
227. SSC has filed an affidavit in compliance with the order dated November 18, 2021 passed in
WPA 12266 of 2021 where it has stated that, none of the regional SSC had issued the
recommendation letters alleged by the writ petitioner.
228. The Secretary of SSC has affirmed an affidavit in WPA 12270 of 2021 where it was stated that,
no recommendation had been made either by the Central Commission or by any Regional
Commission in the post of Group-C staff after expiry of the panel on May 18, 2019 and that the
recommendations made after May 18, 2019 were not issued from any offices of the Commission.
229. The Assistant Secretary of SSC has submitted a report in the form of an affidavit in WPA 18585
of 2021 in response to order dated January 13, 2023 where, the number of vacancies declared in
Group-D posts were tabulated. Number of candidates recommended was stated, the number of the
candidates empaneled and the number of wait listed candidates were also stated. Significantly, it has
stated that, manipulated OMR sheet supplied to SSC by CBI were 2,819.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

230. Another affidavit of SSC in WPA 18585 of 2021, SSC has stated that M/s Nysa was an agency
appointed by SSC for the purpose of assessing/scanning of the OMR sheet with regard to the Third
Regional Level Selection Test 2016, for appointment of Group-D staff. After receiving the OMR
sheet, and in compliance with the orders of the Court, SSC had checked the OMR sheet and others
data supplied by CBI in the form of hard disks whereupon, it appeared that the marks of 2,819 OMR
sheet were lesser then the marks of the candidates as were kept in the server of SSC. Out of 2823
candidates in which, marks had been manipulated/enhanced, 1,911 candidates had been wrongly
recommended.
231. SSC has submitted a report in the form of an affidavit in WPA 25380 of 2022 stating that in
respect of 937 candidates the mark difference varies from 1 to 53. It has submitted a chart with
regard to the wrong recommendations. It has found discrepancy in 805 cases.
232. At the hearing of the writ petitions, SSC had disclosed relevant documents relating to the
recruitment process. Such documents had been disclosed by a compilation. Pages 89 to 96 have the
photocopies of the tender document and work orders issued to M/s NYSA by SSC.
233. By a writing dated July 12, 2016, SSC had called upon 7 addresses of such letter including M/s.
NYSA to quote rates for 3 types of works enumerated in such letter. The next document disclosed by
SSC has suggested that, M/s. NYSA was selected as it was the lowest bidder. No document has been
disclosed by SSC as to whether, SSC evaluated the expert eyes of any of the 7 addresses of the letter
dated July 12, 2016 with regard to the nature of job required of them to be performed. Technical
qualifications have not been spelt out.
234. By letter dated December 1, 2016, SSC had referred to a work order dated October 24, 2016 and
called upon M/s. 2 start scanning of OMR sheet of both Secondary and Higher Secondary
examinations immediately and process result of the same in due course. The work order dated
October 2016 has not been disclosed.
235. By letter dated March 29, 2017, SSC had called upon M/s NYSA 2 start scanning of OMR sheets
of Group C examination immediately along with other activities as enumerated therein. The other
activities that had been enumerated in such letter are scanning and processes of results, return of
OMR sheet after completion of the process to SSC and handing over scanned images of OMR is and
records of result and other information in soft copy mode with clarifications. This letter dated
March 29, 2017 has referred to a work order dated January 17, 2017 of SSC which has not been
brought on record.
236. By letter dated March 29, 2017, SSC, referring to a work order dated January 17, 2017 had
called upon M/s. NYSA to start scanning of OMR sheet for the post of Group D examinations. Same
other activities as the earlier letter had been specified. Again, the work order spoken of has not been
disclosed.
237. By a letter dated September 7, 2017, SSC had informed M/s. NYSA that, offer of M/s. NYSA had
been accepted and that such entity was requested to take up Type Test of Group C selection process.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

238. In respect of the entrustment of the work for Group C and D examinations to M/s. NYSA, even
the semblance of a selection from amongst other bidders was not undertaken by SSC.
239. In the factual matrix of the present case, we are unable to accept a contention that,
appointment of M/s NYSA in such a process has been an irregularity, and not an illegality.
Appointment of such an entity in such a manner had been unashamedly orchestrated in order to
facilitate, implement and perpetuate the eventual fraud which was subsequently discovered.
240. SSC had submitted a statistical report in respect of the 4 selection processes which is as
follows: -
Alleged Sl. Post Class Total OMR Rank Alleged Irregularity No. Name Level
Recommendation Issue Jumping Irregularity in percentage Assistant IX-X 1 11610
808 185 993 8.50% Teacher Level XI-
Assistant 2 XII 5596 771 39 810 14.47% Teacher Level Group C 3 2037 783 783
38.43% (Clerk) 4 Group D 3880 1741 44.87%
241. These illegalities admiited by SSC cannot be said to be within tolerable errors of
a selection process of a large magnititude. Despite the recalcitrant attitude of SSC, it
had to admit these illegalities.
242. In course of hearing SSC did not discount the fact that possibilities of further
illegatities exists. One would have appreciated an Article 12 authority when show
illegalities to own up the mistakes, identify them, identify the lacunae in the system
causing the illegalities and corrected course so as extend ameoliration to the affected
persons to the extent possible. We however witnessed an SSC persistently treating
the writ petitioners as adversaries, despite a number of them bringing forth credible
informations regarding the illegalities, which ultimately SSC had also acknowledged
as correct.
243. Although litigations in India are adversarial in nature, Article 12 authority is
endowed with the obligation to uphold the rule of law. It must side with rule of law
and in so doing, in the facts and circumstances of the present matters, the writ
petitoners could not be treated by SSC as adverseries.
Objective of SSC should have found common platform of fighting corruption with the candidates
affected by it. Bonafide candidates who had participated in the selection process deserved a lot
better and far more humane treatment than they received from SSC. It is debateable as to whether
the present stance of SSC as has been exhibited in Court would assist in repairing the damage to the
creditiblity of SSC to conduct a free, fair and transparent selection process. Affidavits and Reports of
BoardBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

244. The then president of the Adhoc Committee of the Board has affirmed an affidavit in WPA
12266 of 2021 claiming that board received all the recommendations from different regional offices
of the Commission mostly by hand and some through postal department. He has claimed that the
Board is in possession of original recommendation issued by the regional SSC with DI Memo
mentioned upon each recommendation. He has claimed that the Board had issued approximately
25,000 appointments of teachers and non- teaching staffs since 2018 and that for all such
appointment same methods were followed.
245. The then President of Adhoc Committee of the Board has affirmed an affidavit in WPA 12270 of
2021 claiming that the Board received all the recommendations from the different regional offices of
SSC. Board had given 357 appointments on the basis of the recommendations between the time
period December 2019 to February 2020.
246. The Secretary of the Board has submitted a report in the form of an affidavit in WPA 18585 of
2021 stating that the Board received 4,550 numbers of recommendations for Group- D post from
Regional Commission and issued equal number of appointment letters for the candidates for the
post of the Group-D in different schools. He has tabulated the joining status of the candidates given
such appointments. Reports of CBI
247. From time to time as called upon, CBI has filed several reports as to the progress and result of
the investigations. CBI has submitted a report in the form of an affidavit in terms of the order dated
December 6, 2022 in WPA 13700 of 2021. In such report, it has stated that, during investigation, it
revealed that, SSC awarded a contract to M/s. NYSA Communications Private Limited for scanning
and evaluation of OMR answer sheets of the written answer sheets pertaining to the selection test of
Group D, Group C, Assistant Teachers for classes IX-X, and XI-XII. Scanning of all original OMR
sheets had been done at the office of SSC by M/s. NYSA, scanned OMR sheets were used by M/s.
NYSA for evaluation of such OMR sheets by way of comparing those with the corresponding answer
key of the booklet which the candidate was provided with. Thereafter, M/s. NYSA made a final
tabulation of result of OMR evaluation and shared this evaluation of marks with the SSC. Once SSC
had received the evaluated marks of the candidates from M/s. NYSA they uploaded the same to their
office database. During investigation, the office database of SSC had been seized by CBI containing
all the data pertaining to the selection test for all the 4 categories. The 3 hard disks had been seized
during investigation by way of search of the premises of one ex- employee Mr Pankaj Bansal at
Ghaziabad, Uttar Pradesh. Those hard disks had scanned images and the evaluated marks of the
OMR sheets. On comparison of the data seized from SSC during investigation and the data
contained in the 3 hard disks seized during the investigation from the premises of Mr Pankaj Bansal
it was found that there had been huge number of manipulation/mismatches in the evaluated marks
of OMR sheets pertaining to the all 4 categories of the selection process. The entire data which was
seized during the investigation from the premises of Mr Pankaj Bansal had been provided to SSC for
appropriate action at their end.
248. CBI has filed a comprehensive status report dated January 19, 2024 in relation to the present
proceedings. In such status report, it has stated that in WPA 18585 of 2021, it registered CBI case
dated April 5, 2022 in compliance with the order dated April 4, 2022 passed in such writ petitionBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

inter alia under Sections 120B/420/468/471 of the Indian Penal Code, 1860 and Section 7 of the
Prevention of Corruption Act, 1988 in connection with the irregularities in the recruitment of Group
D post in various sponsored and aided schools under the SSC. It has also stated that, a chargesheet
No. 31/2022 dated December 13, 2022 had been filed against 15 persons under Section 120B read
with Sections 201, 420, 467, 468, 471 of the Indian Penal Code, 1860 and Section 7 and 7A of the
Prevention of Corruption Act, 1988. At that filed a supplementary chargesheet, and 2nd
supplementary chargesheet involving other accused.
249. The status report dated January 19, 2024 of CBI has stated that it registered a case on April 7,
2022 under Section 120 B/420 of the Indian Penal Code, 1860 and Section 7 of the Prevention of
Corruption Act, 1988 in compliance with the order dated April 7, 2022 passed by the High Court in
WPA 5538 of 2022. Such a FIR had been registered against the then convener of 5 members
committee as well as advisor to SSC and unknown other public servants of SSC and other related
departments of the Government of West Bengal for the irregularities in the process of appointment
of candidates in the post of Assistant Teachers for class IX-X first SLST 2016 of SSC. It has filed a
chargesheet on October 21, 2022 under Section 120B read with 109, 201, 420, 467, 468, 471 of the
Indian Penal Code, 1860 and Sections 7, 7A, 8 of the Prevention of Corruption Act, 1988. It has filed
a supplementary chargesheet, 2nd supplementary chargesheet and 3rd supplementary chargesheet
therein.
250. Such status report of CBI has stated that, it registered another case on May 18, 2022 on the
basis of the order dated May 18, 2022 passed in WPA 5406 of 2022 which was registered under
Section 120B, 420, 471 of the Indian Penal Code, 1860 and Section 7 of the Prevention of Corruption
Act, 1988 against several persons for manipulations in the merit list for appointment of Teachers for
classes XI-XII in schools under SSC. It has filed chargesheet No. 32/2022 dated December 13, 2022
against several persons under Section 120B read with 109, 201, 420, 477A of the Indian Penal Code,
1860 and Section 7, 7A and 8 of the Prevention of Corruption Act, 1988. It has filed for
supplementary chargesheet and 2nd supplementary chargesheet therein.
251. Again, such status report of CBI has disclosed that, CBI registered a FIR dated May 20, 2022 in
compliance with order dated May 18, 2022 passed in connection with WPA 12270 of 2021. There,
CBI had registered the FIR in connection with the irregularities in the recruitment of Group C
(Clerks) in various sponsored and aided schools under SSC stop it has submitted chargesheet on
September 13, 2022 against 5 FIRs named accused including the then Minister and 10 other persons
under Sections 120B, 201, 420, 467, 468, 471 of the Indian Penal Code, 1860 and Section 7 of the
Prevention of Corruption Act, 1988 for supplementary chargesheet and final chargesheet therein.
252. In such status report, CBI has stated that, by the order dated November 9, 2023, Supreme
Court has directed completion of the investigation within the period of 2 months. Accordingly,
investigation has been completed in the SSC cases and final chargesheet has been submitted before
the Trial Court.
253. CBI has submitted a report dated January 16, 2024 in compliance with the order dated January
15, 2024 passed by the Division Bench. It has stated in such compliance report as follows: -Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

"3. That during investigation, it was revealed that the West Bengal Central School
Service Commission (hereinafter referred to as 'Commission') has awarded a work
order to M/s. Nysa Communication Private Limited (hereinafter be referred to as
'M/s. NYSA') for scanning and evaluation of OMR answer sheets pertaining to the
selection tests of Group D, Group C, Assistant Teachers for classes IX-X and XI-XII.
4. That, scanning of all original OMR sheets was done at the office of Commission by
M/s. NYSA. The process adopted by M/s. NYSA was when the OMR is scanned, that
generates two outputs, first is the scan image of the OMR and the other is the answer
string, which is a language coded inputs of the responses filled up by the candidate in
the respective OMR sheet.
5. That scanned OMR sheets were used by M/s. NYSA for evaluation of such OMR
sheets by way of comparing those with the corresponding answer key. Thereafter,
M/s. NYSA made a final tabulation of result of OMRs evaluation and shared this
evaluation of marks with the Commission.
6. That once the Commission received the evaluated marks of candidates from M/s.
NYSA, they uploaded the same in their office database.
7. That during investigation the office database of the Commission was seized by the
Central Bureau of Investigation containing all the data pertaining to selection tests of
Group D, Group C, Assistant Teachers for classes IX-X and XI-XII.
8. That, during investigation of the case, three hard disks were recovered on
15.09.2022 and 16.09.2022 from the residence of Pankaj Bansal, ex-employee to
M/s. NYSA, at Ghaziabad. The certificates dated 16.09.2022 u/s 65-B of Indian
Evidence Act, 1872, from Shri. Pankaj Bansal were also obtained, in triplicate, with
regard to genuineness of the data contained in these three hard-disks so recovered.
9. These three hard-disks contained scanned images and the evaluated marks of
above such OMR sheets.
10. That, in compliance to the solemn order dated 15.01.2024 of this Hon'ble Court, a
certificate dated under Section 65-B of the Indian Evidence Act, 1872, obtained from
Pankaj Bansal is being submitted before this Hon'ble Court. Photocopy of such
certificate u/s 65-B of the Indian Evidence Act, 1872 obtained from Shri Pankaj
Bansal dated 16.09.2022 is annexed hereto and marked as "Annexure-A" to this
affidavit.
11. That, the 2nd Supplementary Chargesheet filed before the Learned Trial Court on
08.01.2024 along with the list of witnesses, list of documents and list of material
objects in which three hard disks seized from Pankaj Bansal's residence are made the
part of it."Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

254. Reports in the form of affidavit of SSC, Board and CBI have established that, there had been
serious illegalities/manipulations in the selection process in respect of all the 4 categories of post
involved. Orders of the learned single judge directing investigations by CBI in respect of all the 4
categories, have not been interfered with by the Supreme Court. Rather, by the order dated
November 9, 2023, Supreme Court has directed CBI to conclude the investigations and submit its
report before the jurisdictional Court. CBI has done so.
255. The writ petitions have prompted investigations to be undertaken in respect of illegalities and
manipulations in the selection process. CBI has found serious illegalities and manipulations
involving a swathe of the Indian Penal Code, 1860 and the Prevention of Corruption Act, 1988
relating to cheating and corruption. CBI has filed chargesheet in the 4 several FIRs registered by
pursuant to orders of Court, passed in 4 different writ petitions.
256. Events that have occurred subsequent to the filing of the petition are perturbing and replete
with profound ramifications, transcending the perimeter of the parties to the proceedings and
impacting the society at large. They have therefore, transmuted the issue of maintainability into one
of entertainability and rather to the nature of reliefs that the parties are entitled to.
Role of State Government
257. The role of the State Government in the writ petitions and the appeals that have been heard by
us has to be taken into consideration. As has been noted before, SSC filed CAN 6 of 2022 in WPA
5406 of 2022 and an application being CAN 2 of 2022 in WPA 5538 of 2022. SSC had prayed for
creation of supernumerary post in respect of appointments given illegally. State Government has not
opposed such a prayer. In fact, documents placed on record suggest that the State Government, at
the level of the Cabinet had approved creation of the supernumerary posts to accommodate the
persons who had received employment illegally in the selection process. The Principal Secretary had
appeared before the learned single Judge and produced a Cabinet note and Cabinet memo with
regard to creation of the supernumerary post which such documents were taken on record by an
order dated November 25, 2022.
258. CBI had conducted investigation pursuant to orders of Court. CBI had filed charge sheets and
supplementary charge sheets in the four cases that it registered. CBI had filed charge sheet against
State Government officials. In course of hearing, the Court had been informed that, SIT had applied
for sanction to prosecute the State Government officials in September, 2023 and that, a member of
SIT had met relevant officials trying to persuade expeditious disposal of the application for sanction
to prosecute, since then.
259. Since the SIT had been constituted in these proceeding, and the proceedings are yet to be
disposed of finally, we had called upon the learned Government Pleader to apprise the Court as to
the time required for disposal of the application for prosecution.
260. We had been informed by the learned Government Pleader on March 5, 2024 that in view of
the ensuing elections, Chief Secretary who is the authority to decide on the application for grant ofBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

sanction to prosecute the State Government officials, would not be in position to dispose of the same
before the conclusion of the election and would require further time thereafter. We had requested
the learned Government Pleader to inform us the time frame required by the Chief Secretary to
dispose of such application so that appropriate order may be passed in that regard. We had
requested the learned Government Pleader to inform us on the next date, as the hearing of the
matters were being continued on a day-to-day basis.
261. On March 6, 2024, learned Government Pleader had submitted that one more day's
accommodation may be grant to him to apprise the Court of the time required. Considering such
prayer, we had accommodated the learned Government Pleader as prayed for.
262. On March 7, 2024, the learned Government Pleader had informed the Court that, he will
apprise the Court with regard to the time frame on March 13, 202 as the criminal case was fixed
before the jurisdictional Court on March 12, 2024. We have acceded to such a prayer also.
263. Thereafter, the matters had been heard on several days subsequent to March 13, 2024. Neither
the learned Government Pleader had appeared nor any advocate for the State thought it prudent to
apprise the Court as to the time frame required by the Chief Secretary to dispose the application for
sanction to prosecute.
264. The obdufurate attitude of the Chief Secretary has to yield to his obligation to uphold the rule
of law. Since a coordinate Bench has issued directions for the expeditious disposal of the application
for sanction, we refrain from issuing any directions to the Chief Secretary in this regard. We
however deem it appropriate to grant leave to SIT to seek appropriate directions from Court so that
the investigations and the trials come to their logical conclusions. Inferences from the role of Article
12 authorities
265. State Government therefore has accepted that, there were widespread illegalities in the
selection process and that, the numbers of persons who received appointments illegally could not be
determined with exactitude. They had resolved to create supernumerary posts to accommodate the
illegal appointees. In other words, State has resolved to expend taxpayers' money to accord sanction
to an employment secured dishonestly. Such course of action of the State violates Articles 14 and 16
which enjoins upon the State the obligation to grant appointments in conformity with such
provisions and never otherwise.
266. Learned single Judge had directed investigation by CBI. Learned single Judge had constituted
a Special Investigating Team (SIT) to conduct such investigation. CBI has filed charge sheets and
supplementary charge sheets in the FIR registered pursuant to the order of the Court. SIT had
applied to the competent authority to accord sanction for prosecution as against the State
Government employees against whom the charge sheets and supplementary charge sheets had been
filed in the FIR.
267. State Government has appeared sporadically during the course of hearing of the writ petitions
and the appeals and that to only after learned Advocate for the State was requested to address theBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

Court on the issues in the matters including the issues of consideration of the grant of sanction to
prosecute the government officials against whom CBI had filed chargesheet making them as
accused. Learned Government Pleader has represented the State Government. Learned Government
Pleader, with deepest of respect, has been assiduously evasive, obviously due to the quality of the
instructions, with regard to the time required for the purpose of disposing of the application for
grant of sanction to prosecute.
268. This course of action has been adopted by the State Government in order to prevent discovery
of further manipulations/illegalities in the selection process, if possible.
269. SSC, Board and State Government have consistently stonewalled any queries with regard to the
selection process and have not come clean with regard to the manipulations/illegalities involved.
Conduct of the 3 authorities, during the course of hearing can be classified as anything other than
being cooperative.
270. The Secretary, SSC has submitted a statistical report with regard to the illegalities in the
appointment in the respect of the four categories, by a signed report dated March 6, 2024 to which
we have allude to herein.
271. In course of hearing, SSC, in response to queries of the Court, has submitted details of the
recommendations made by SSC in respect of the 4 categories and number of appointment letters
issued by the Board in respect of the 4 categories. Significantly, SSC had recommended 11,425
candidates for appointments post of Assistant Teachers for classes IX and X whereas, Board
succeeded in generating 12,946 appointment letters thereby issuing 1,539 excess appointment
letters than Board was entitled to similarly, in respect of Assistant Teachers for classes XI and XII
the Board had 5, 756 appointment letters as against a recommendation of 5,557 candidates by SSC
thereby issuing 199 excess appointment letters than entitled to. In respect of Group D Board has
issued 4,550 appointment letters against a recommendation of 3,881 by SSC thereby generating 669
excess appointment letters. In respect of Group C, Board has generated 2,483 appointment letters as
against recommendation of 2,067 by SSC thereby generating 416 excess appointment letters.
Justification that has been sought proffered by Board is that, all appointment letters were on the
basis of the recommendations of SSC. SSC has contradicted such justification of Board by claiming
that no such recommendation letters were issued.
272. Board has no authority to issue appointment letters unless such candidate is recommended by
SSC. In the 4 categories involved, there have been appointments far in excess of the
recommendations. There have been manipulations/illegalities in the recommendations also.
273. SSC had at no stages of hearing, claimed that it was able to check all the records and be definite
as to the number of illegalities in recommendations made but had limited itself to those figure as
stated in the paragraphs above. In fact, reports in the form of affidavit filed by the SSC from time to
time had always stated that, they discovered the illegalities as were brought to their notice by the
litigants or on order of Court.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

274. SSC had proceeded to withdraw/cancel the recommendations issued in favour of candidates
participating in the 4 categories on the basis that there were manipulations in obtaining the
recommendations. SSC had accepted the data found in the hard disks seized from ex-employee of
M/s NYSA namely, Pankaj Bansal by CBI and acted upon it. SSC has filed two applications as noted
above for creation of supernumerary post.
Findings on Maintainability
275. Supreme Court in its order dated November 9, 2023 has observed that, the writ petitions have
strong attributes of Public Interest Litigation. If one understands a public interest litigation to be a
litigation which strives to secure public interest and ensure that the activities of the administration
in violation the Constitutional provisions are attended to by the judiciary, then these batch of
litigations qualify the definition. The sheer number of candidates involved in the subject selection
process and the quantum of illegalities discovered renders the litigations involved as public interest
litigations. In view of the magnitude of the illegalities discovered so far with further discoveries yet
to be made, we are of the view that, the writ petitions have metamorphized themselves into Public
Interest Litigations.
276. It is trite law that, the Court in furtherance of public interest may deem it necessary to enquire
into the subject matter of the litigation in the interest of justice. Court can consider a writ petition
filed with a private grievance and treat it as a public interest litigation, if the fact situation so
warrants.
277. In view of the events happening subsequent to the filing of writ petitions and in the view of the
writ petitions transforming themselves into Public Interest Litigations, and more so in view of the
CBI filing charge sheets and supplementary charge sheets in respect of 4 FIRs alleging widespread
manipulations in the selection process, the second issue is answered in favour of the writ petitioners
and as against the persons opposing the writ petitions. All writ petitions falling with the jurisdiction
of this Division Bench to be heard in terms of the order dated November 9, 2023 of the Supreme
Court, and the orders of assignment are held to be maintainable.
278. Respective stand of SSC, CBI, ED, State and Board as noted above has established, there were
widespread manipulations in the selection process involved. Fraud had been established. At the very
least, persons who were not even in the panel were found to have been blessed with appointments.
OMR sheets of the candidates have been found to be manipulated across all four categories. Exact
numbers of candidates given appointments, whose OMR sheet have been manipulated in all the four
categories are yet to be finally decided.
279. In view of such widespread fraud in a selection process, and such fraud having been discovered
subsequent to filing of the writ petition, it cannot be held that any of the writ petitions are not
maintainable. The fraud discovered subsequent to the filing of the writ petitions have answered the
second issue in favour of the writ petitioners.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

280. None of the writ petitioners can be said to have knowledge of the fraud involved which such
fraud was discovered subsequently. Therefore, the question of the writ petitioners participating in
the selection process with their eyes open and having been unsuccessful therein, not being entitled
to file the writ petition challenging the selection process does not arise.
281. In view of the ratio laid down in Mohd. Kalimuddin and others (supra), Surinder Singh and
others (supra), Raghbir Chand Sharma and another (supra), Virendra Kumar Sharma (supra) B.
Valluvan and others (supra). Mohd. Sohrab Khan (supra) and Rajkishore Nanda and others (supra),
appointments cannot be made subsequent to expiry of the validity period of panel.
282. In the facts of the present case, SSC has placed on record several persons who had been granted
appointments subsequent to the expiry of the validity period of panel. Such appointments therefore
have to be cancelled and are hereby directed to be so.
283. In view of discussions above, the third issue with regard to the appointment made subsequent
to the expiry of the validity period of the panel is answered by holding that, appointments made
subsequent to the expiry of the validity period of the panel are null and void. Certificate Issued
under Section 65B of the Evidence Act
284. CBI has filed an affidavit on January 16, 2024 disclosing a certificate dated September 19, 2022
issued under Section 65B of the Evidence Act, 1872 by Mr. Pankaj Bansal with regard to the
genuineness of the data contained in the 3 hard disks recovered. Such report has stated that, CBI
seized the hard disks containing all the data pertaining to the selection test of all the 4 categories.
CBI has produced the three hard disks in Court.
285. Such certificate dated September 19, 2022 is as follows:-
"CERTIFICATE U/S 65B OF INDIAN EVIDENCE ACT, 1872"
It is certified that the information, enclosed herewith in the form of data stored. in:
(i) One WD 2 TB External Hard Disk bearing Serial No. WX71AC82C54A (Copy of
which was voluntarily provided to CBI by the undersigned)
(ii) One Seagate Back up plus portable Drive, capacity 1 TB, bearing Serial
No.:NA7ZW704 having hash value .SHA1:
28E5D8FBA6A251F41E0BD2CA5A9E1A8A83243944 & MD5 -
304FDD1C49D7D52AC50437F6DB571641 (copy of which was provided to CBI using
Tableau TX1 for the purpose of investigation)
(iii) One Seagate BUP Slim RD SCSI Disc device, capacity 1 TB bearing Serial No.
NA7XR3VB having hash value SHA1 :-Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

A8387158B2C36759ACB2188FCC9D4B7E905A54D6 & MD5 -
7BE5529279BEFFID74074E5BE98AC3AC (copy of which was provided to CBI using
Tableau TX1 for the purpose of investigation) containing relevant data of WBCSSC
pertaining to 1st SLST (AT), 2016 for Class XI-XII, IX-X, Group-C and Group-D; is
the original scanned images of OMRs and corresponding data regarding the same for
the aforesaid examination.
It is further certified that to the best of my knowledge:
All data including the scanned images of OMRs for the aforesaid examinations were
under my exclusive custody throughout and there has been no tampering or
manipulation in any of them at any point of time. Said data is the same which was
extracted during the scanning process of OMRs of respective examinations at the
office of WBCSSC, Acharya Sadan, Salt Lake Kolkata by M/s Nysa Communications
Private Limited.
Authorized signatory:
Sh. Pankaj Bansal Data Analyst, M/s ND Info Systems Pvt. Ltd."
286. Order of remand dated November 9, 2023 passed by the Supreme Court, in relation to the
present matters, has required us to pronounce on the admissibility of the data contained in the three
hard disks on the basis of rules of evidence.
287. Issues of admissibility on the data contained in the three hard disks have been raised by the
beneficiary of the fraud.
288. None of the Article 12 authorities had ever disputed the genuineness, veracity, authenticity and
legality of the data contained in the 3 hard disks seized by the CBI from Mr. Pankaj Bansal at any
material point of time. SSC had accepted such data, acted upon it, found manipulations/illegalities
in the OMR sheets, proceeded on basis of such findings and withdrew/cancelled recommendations
of various candidates. It had utilized such data to arrive at a finding that, OMR sheets had been
manipulated and that, marks obtained by candidates stored in its server were considerably higher
than the marks which such candidate could have received on a thorough and proper evaluation of
the OMR sheets of such individual candidates found in the hard disks seized by the CBI.
289. The 3 hard disks seized by CBI, had been produced in Court. CBI had granted inspection of
documents downloaded from such hard disks, to persons seeking such inspection, pursuant to
orders of this Bench. None of the persons taking inspections have contended that, the OMR sheets
are not theirs. The OMR sheets bear unique bar code and have several features which distinguish
one OMR sheets from the other such as the signature of the candidates as also the invigilator and
other aspects.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

290. Section 3 of the Evidence Act, 1872 has included electronic records produced for the inspection
of the Court as documentary evidence. It has also laid down that a fact is said to be proved when,
after considering the matters before it, the Court either believes it to exist, or considers its existence
so probable that a prudent man ought, under the circumstances of the particular case, to act upon
the supposition that it exists.
291. Section 58 of the Evidence Act, 1872 has laid down that, facts admitted need not be proved.
Section 58 is as follows-
"58. Facts admitted need not be proved. - No fact need be proved in any proceeding
which the parties thereto or their agents agree to admit at the hearing, or which,
before the hearing, they agree to admit by any writing under their hands, or which by
any rule of pleading in force at the time they are deemed to have admitted by their
pleadings.
Provided that the Court may, in its discretion, require the facts admitted to be proved
otherwise than by such admissions."
292. Subsequent to the seizure of the 3 hard disks and subsequent to the certificate dated September
16, 2022, two applications being CAN 2 of 2022 in WPA 5538 of 2022 and CAN 6 of 2022 in WPA
12266 of 2022 had been filed ostensibly by SSC seeking permission to create supernumerary post for
the illegal appointees. In those two applications, orders dated November 16, 2022, November 23,
2022 and November 25, 2022 had been passed. In those two applications, Cabinet note of approval
to grant supernumerary post had been produced in Court.
293. After the seizure of the 3 hard disks by CBI, the data contained therein had been shared by CBI
with SSC. SSC had accepted such data as true and correct. SSC had acted thereon and proceeded to
identify manipulations/illegalities in the recommendations as also appointments. SSC had
proceeded to withdraw/cancel the recommendations acting on the basis of the data contained in 3
hard disks seized by CBI. We shall also examine whether the certificate dated September 19, 2022 is
in conformity with Section 65B of the Evidence Act, 1872 or not.
294. In our view, the fact that the 3 hard disks contained data relating to the 4 categories of the
selection process conducted by SSC had stood proved by SSC and State making admissions with
regard thereto in the applications filed in the writ petition and by their conduct.
295. Section 65B of the Evidence Act, 1872 occurs in Chapter-IV while Section 58 occurs in
Chapter-III thereof. Chapter-IV of the Evidence Act, 1872 deals with oral evidence.
296. In Anvar P.V. (supra) Supreme Court has considered provisions of Sections 62, 65A and 65B of
the Evidence Act, 1872. It has held that, admissibility of secondary evidence of electronic record
depends upon the satisfaction of the conditions as prescribed under Section 64B thereof. It has
enumerated the conditions under Section 65B which are required to be satisfied. It has observed
that, on the other hand, if the primary evidence of the electronic record is adduced, that is, theBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

original electronic record itself is produced in Court under Section 62, then the same is admissible
in evidence, without compliance with the conditions in Section 65B.
297. In Arjun Panditrao Khotkar (supra), Supreme Court has held that, production of the certificate
under Section 65B(4) of the Evidence Act, 1872 is mandatory but only in case of secondary evidence
i.e. where the primary evidence is not led and original is not produced. It has distinguished primary
and secondary evidence with regard to electronic records /documents.
298. In Ravinder Singh alias Kaku (supra), Supreme Court has addressed the issue with regard to
admissibility of the electronic records. It has held that, noncompliance with requirement of
certification of electronic evidence is not permissible. It has observed that, Section 65B(4) is a
mandatory requirement of law.
299. In Mohd. Arif (supra), Supreme Court has summarized the manner in which the electronic
evidence can be introduced under Section 65A and 65B of the Evidence Act, 1872. It has taken note
of the principles laid down in Anvar P.V. (supra) as clarified in Arjun Panditrao Khotkar (supra).
300. Section 65-B of the Evidence Act, 1872 is as follows: -
"65-B Admissibility of electronic records. -- (1) Notwithstanding anything contained
in this Act, any information contained in an electronic record which is printed on a
paper, stored, recorded or copied in optical or magnetic media produced by a
computer (hereinafter referred to as the computer output) shall be deemed to be also
a document, if the conditions mentioned in this Section are satisfied in relation to the
information and computer in question and shall be admissible in any proceedings,
without further proof or production of the original, as evidence or any contents of the
original or of any fact stated therein of which direct evidence would be admissible.
(2) The conditions referred to in sub-Section (1) in respect of a computer output shall
be the following, namely: -
(a) the computer output containing the information was produced by the computer
during the period over which the computer was used regularly to store or process
information for the purposes of any activities regularly carried on over that period by
the person having lawful control over the use of the computer;
(b) during the said period, information of the kind contained in the electronic record
or of the kind from which the information so contained is derived was regularly fed
into the computer in the ordinary course of the said activities;
(c) throughout the material part of the said period, the computer was operating
properly or, if not, then in respect of any period in which it was not operating
properly or was out of operation during that part of the period, was not such as to
affect the electronic record or the accuracy of its contents; andBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

(d) the information contained in the electronic record reproduces or is derived from
such information fed into the computer in the ordinary course of the said activities.
(3) Where over any period, the function of storing or processing information for the
purposes of any activities regularly carried on over that period as mentioned in clause
(a) of sub-
Section (2) was regularly performed by computers, whether -
(a) by a combination of computers operating over that period; or
(b) by different computers operating in succession over that period; or
(c) by different combinations of computers operating in succession over that period; or
(d) in any other manner involving the successive operation over that period, in whatever order, of
one or more computers and one or more combinations of computers, all the computers used for that
purpose during that period shall be treated for the purposes of this Section as constituting a single
computer; and references in this Section to a computer shall be construed accordingly. (4) In any
proceedings where it is desired to give a statement in evidence by virtue of this Section, a certificate
doing any of the following things, that is to say, -
(a) identifying the electronic record containing the statement and describing the manner in which it
was produced;
(b) giving such particulars of any device involved in the production of that electronic record as may
be appropriate for the purpose of showing that the electronic record was produced by a computer;
(c) dealing with any of the matters to which the conditions mentioned in sub-Section (2) relate, and
purporting to be signed by a person occupying a responsible official position in relation to the
operation of the relevant device or the management of the relevant activities (whichever is
appropriate) shall be evidence of any matter stated in the certificate; and for the purposes of this
sub-Section it shall be sufficient for a matter to be stated to the best of the knowledge and belief of
the person stating it.
(5) For the purposes of this Section, -
(a) information shall be taken to be supplied to a computer if it is supplied thereto in any
appropriate form and whether it is so supplied directly or (with or without human intervention) by
means of any appropriate equipment;
(b) whether in the course of activities carried on by any official, information is supplied with a view
to its being stored or processed for the purposes of those activities by a computer operated otherwise
than in the course of those activities, that information, if duly supplied to that computer, shall beBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

taken to be supplied to it in the course of those activities;
(c) a computer output shall be taken to have been produced by a computer whether it was produced
by it directly or (with or without human intervention) by means of any appropriate equipment."
301. Section 65B contains a deeming fiction allowing electronic data stored in the electronic devices
to be admitted as evidence of, the contents of the original, subject to the cumulative satisfaction of
the following conditions: -
(i) computer output was produced by the computer in regular use carried out by a
person in lawful custody over the computer.
(ii) information contained was regularly fed into the computer in the ordinary course.
(iii) computer was working properly.
(iv) certificate is signed by a person enjoying a responsible official position.
302. Section 65B of the Evidence Act, 1872 does not prescribe any format of a certificate that has to
be issued thereunder. What it prescribes is that, a certificate must conform with the essential
requirements of such section. In light of such discussions, we have to consider whether the
certificate dated September 16, 2022 is in accordance with Section 65B or not.
303. The certificate dated September 19, 2022 issued by Mr. Pankaj Bansal has stated that he was
having exclusive custody of the 3 hard disks. He has also stated that, the data fed therein and the
production thereof was what was fed into the hard disk in ordinary course of activity. He has stated
that, the 3 hard disks contained relevant data of the selection process pertaining to all the 4
categories and had the original scanned images of OMRs and corresponding data regarding the
same in respect of such selection process. He has stated that, such data including the scanned
images of the OMR for the selection process had been under his exclusive custody throughout and
there has been no tampering, manipulation of any of them at any point of time. He has also stated
that such data is the same which was extracted during the scanning process of OMRs of the
respective examination at the office of SSC by M/s NYSA.
304. Certificate dated September 16, 2022 had been issued by Mr. Pankaj Bansal as a Data Analyst
of ND Info Systems Pvt. Ltd. When he had issued that certificate, he was working in the post and at
the organization at that material point of time. His working at such post in the new organization
does not militate against the requirements of Section 65B of the Evidence Act, 1872. In the body of
the certificate, he has stated that the three electronic devices contained the necessary data in the
electronic format relating to the selection process concerned.
305. CBI has filed several reports in these proceedings. In its report dated February 5, 2024 filed in
compliance with the order dated January 24, 2024 passed by us, it has stated as follows: -Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

"3. That during investigation, it was revealed that the West Bengal Central School
Service Commission (hereinafter referred to as 'commission' had awarded a work
order to M/s Nysa Communication Private Limited ('hereinafter referred to as M/s.
NYSA') for scanning and evaluation of OMR answer sheets pertaining to the selection
tests of Group - D, Group - C, Assistant Teachers for classes IX - X and XI - XII.
4. Investigation has established that Sh. Puneet Kumar was the then Director and Sh.
Niladri Das was the then Vice President of the said M.s Nysa Communications Pvt.
Ltd. during relevant period. It has been established during investigation that Sh.
Niladri Das was in charge of operations in respect of recruitment examinations
conducted by WBCSSC and frequently visited the officer of WBCSSC to attend to the
actual operational part and did the requisite liaison on behalf of the agency for
necessary compliance of the instructions given by WBCSSC. Sh Puneet Kumar, being
the Director, mainly looked after the financial affairs of the agency and represented it
on records.
5. Investigation has established that the scanning of OMR sheets was undertaken by
the said M/s Nysa Communication Pvt Ltd at WBCSSC office at Acharya Sadan under
direct supervision of Sh Niladri Das and in p[resence of WBCSSC officials. It has been
further established that M/s NYSA communication Pvt. Ltd. had further given work
order w.r.t. scanning the original OMR to M/s Data Scantech Solutions, Noida who
remained present on the premises of WBCSSC for the scanning work. After
completion of scanning, the precessed data in the form of scanned images of OMRs,
scan data etc. were handed over by M/s Data Scantech Solutions to M/s Nysa
Communication Pvt Ltd. who took the same to their officer located at Noida in digital
form (Hard Disks) leaving the original hard copies of OMR sheets in the office of the
WBCSSC, WBCSSC handed over their answer keys in respect of all subjects to M/s
Nysa Communications Pvt Ltd for evaluation of OMR responses.
6. That, while scanning the original OMR sheets by M/s Data Scantech Solutions on
behalf of M/s Nysa, two ".DAT" files were generated containing SCAN NO., Bar Code,
ROLL NO., VENUE CODE, BOOKLET SERIAL NUMBER, SUBJECT CODE,
CATEGORY, GENDER, MEDIUM and RESPONSE CODE. In the process of
scanning, the image copies of the original OMR sheets were also captured.
7. That, a sample of the ".DAT" file generated during sscaning of one OMR sheet is
cited as an example below: -
Bar Code / Roll Number S Venue Booklet Ca G M Scan No u Code te e e Serial bj go n
d Number ec ry d i t Co e u C de r m od e 10000892221167500012 921010000697 5 0
2 F 1 DDA A E A C A A A BBA A A DA DDDA CDDCBCDB A A D BBBAACD
CACBACBCB# Responses of candidates in the OMR is appearing as Response Code
in alphabets, while "#" indicates end of one OMR sheet.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

8. That, two such ".DAT" files are generated since scanning is done twice to avoid any
technical error. Thereafter, a final ".DAT"
file is prepared which is called a clean data file. After receiving the answer keys from Commission,
the same is compared with this final ".DAT" file and a "DBF" File is generated having the score of
the candidates.
9. That during investigation the server database of the Commission was seized by the Central
Bureau of Investigation containing all the data pertaining to selection tests of Group - D, Group - C,
Assistant Teachers for classes IX - X and XI - XII.
10. That, during investigation of the case, three hard disks were recovered on 15/16.09.2022 from
the residence of Pankaj Bansal, ex-employee of M/s. NYSA, located at Ghaziabad. The certificates
dated 16.09.2022 u/s 65-B of Indian Evidence Act, 1872, from Shri. Pankaj Bansal were also
obtained, in triplicate, with regard to genuineness of the date contained in these three hard-disks so
recovered.
11. That, During investigation, data files containing scanned OMRs, ".DAT" files etc. pertaining to
the aforesaid WBCSSC recruitment matters were also seized from M/s Data Scantech Solutions.
During investigation of RC-03(A)/2022-Kol, the hash values of these Data files of Scantech
Solutions were matched with the hash value of the corresponding files recovered from the hard discs
seized from Pankaj Bansal and was found to be matching, which establishes that the data contained
in the three hard disks recovered from Pankaj Bansal's possession were not contaminated.
12. That, a similar exercise of matching the data available on the hard disks of Pankaj Bansal with
the data seized from the Commission was done during the course of investigation and it was found
that there were mismatch between the two, in as much as, the written marks awarded to candidates
as available on the server of the commission had been increased to qualify undeserving candidates.
This mismatch establishes that manipulation in marks of written examination in the case of many
candidates was resorted to and such candidates were identified. The comparison of these
actual/genuine OMR marks with the OMR marks available in WBCSSC Server shows that there is
manipulation in 952 nos. of candidates of IX-X, 907 nos. of candidates of XI-XII, 3481 nos. of Gr. C
candidates and 2823 nos. of Gr. D candidates.
13. That, during the course of investigation, several emails were found to have been exchanged
between the accused officials of the Commission, certain private persons and officials of NYSA.
These emails contained lists of candidates, whose OMR marks were found to be increased in the
server of the Commission. Besides this, emails have been exchanged between the staff of NYSA
themselves containing manipulated data of candidates. This shows the complicity of officials of M/s
NYSA in this conspiracy.
14. That, during investigation, it emerged that in the year 2019, Shri Niladri Das of M/s NYSA
Communications Pvt Ltd left NYSA and started his own business in name & style of M/s ND Info
Systems Pvt Ltd., Noida, and was engaged in the business of Data processing in line of M/s NYSA.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

The said Niladri Das poached Pankaj Bansal, Kuldeep Singh, Anoy Saha, Muzammil Hossain and
others support staff from NYSA.
15. That, it has emerged from the investigation that before leaving NYSA, Niladri Das and his staffs
retained all the data pertaining to recruitment examinations of WBCSSC including the data of Group
C,D, Assistant Teacher (IX-X, XI - XII) with them. Even after leaving NYSA, Niladri Das, Pankaj
Bansal and Muzammil Hossain kept providing assistance to WBCSSC in the matters of RTI on the
basis of the data of NYSA which was manipulated and also hosted on the WBCSSC server. This also
establishes that Niladri Das, Pankaj Bansal and Muzammil Hossain who were involved in the entire
scam and it was in their knowledge that data has been manipulated and therefore they continued to
extend this assistance solely to avoid detection.
16. That, if there would have been no manipulations then the scanned images of OMRs available
with WBCSSC were sufficient to respond to RTI queries. Investigation revealed that WBCSSC had
destroyed the original OMR sheets and the scanned images of original OMR sheets in the year 2019,
which again leads to an inference that the same were destroyed to keep the entire scan under wraps.
17. That, investigation establishes that as a reward for doing aforesaid manipulation in the OMR
score, M/s NDISPL of Niladri das was provided work of recruitment of Teachers in Upper Primary
conducted by WBCSSC. Apart from this, many other recruitment works were also assigned to
Niladri Das by the Government of West Bengal. Various list of candidates related to Upper Primary
were communicated to Niladri Das from S P Sinha, Sharmila Mitra, etc. Were found in the email of
Niladri Das (niladri@ndispl.com) which shows his criminal conduct.
18. Result of comparison of these electronic records collected from M/s Data Scantech Solutions
with that of the hard disks seized from Pankaj Bansal -
(a) As discussed in the preceding paragraphs, the hard disk recovered from Pankaj Bansal contained
the marks of written examination, typing test, etc. This marks when compared with marks available
in WBCSSC server resulted in the identification of candidates whose marks of written examination,
typing test were manipulated.
(b) M/s Data Scantech Solutions made the initial scanned images of OMR's. These scanned images
were given to M/s NYSA. Pankaj Bansal retained a copy of these scanned images.
(c) That in connection with candidates of Class IX - X, XI - XII, the scanned image of OMR sheets as
collected from M/s Data Scantech Solutions pertaining to the alleged candidates whose OMR marks
were found manipulated were matched with the scanned image of OMR sheets as available in the
hard disk of Pankaj Bansal and the same are found identical.
(d) The Response string of candidates pertaining to IX- X and XI- XII as recovered from M/s Data
Scantech Solutions matches with the Response String available in the hard disk seized from Pankaj
Bansal. On the basis of these response strings the actual/ genuine OMR marks of IX-X and XI-XII
candidates were determined. The comparison of these actual/ genuine OMR marks with the OMRBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

marks available in WBCSSC Server shows that there is manipulation in 952 nos. Of candidates of
IX-X and 907 nos. of candidates of XI-XII.
(e) The Response string of candidates pertaining to Gr. C & Gr. D as recovered from M/s Data
Scantech Solutions matches with the Response String available in the hard disk seized from Pankaj
Bansal. On the basis of these response strings the actual/ genuine OMR marks of Gr. C & Gr. D
candidates were determined. The comparison of these actual/ genuine OMR marks with the OMR
marks available in WBCSSC Server shows that there is manipulation in 3481 nos. of Gr. C
candidates and 2823 nos. of Gr. D candidates.
(f) That, the investigation has established the genuineness of the data of hard disks seized from
Pankaj Bansal.
19. THAT, in compliance to the solemn order dated 24.01.2024 of this Hon'ble Court, three
hard-disks, in original, seized from the residence of Pankaj Bansal along with original certificate
dated 16.09.2022 u/s 65-B of Indian Evidence Act, 1872, obtained from Pankaj Bansal are being
submitted before this Hon'ble Court. The three hard-disks are in sealed condition. The certificate
u/s 65-B of Indian Evidence Act, 1872, in original, obtained from Shri. Pankaj Bansal dated
16.09.2022 is annexed hereto and marked as "Annexure - A".
20. That, Hon'ble Division Bench at High Court at Calcutta in WPA 2613 of 2018 (Basanta Das Vs
The State of West Bengal & Ors) directed CBI on 24.01.2024 for production of the above mentioned
three original hard disks seized from Pankaj Bansal and in compliance to such direction all the said
three hard disks were returned back by CFSL, Hyderabad in sealed condition and are now being
produced with this report.
21. That, the present status of all the above mentioned four recruitment cases of CBI is "disposed
-off from investigation", where multiple charge sheets in each such cases have been filed by CBI
before the Learned Trial Court, Alipore. The alleged offences of the First Information Reports and
the subsequent irregularities found during the course of investigation have been substantiated in all
such cases of CBI and all the charge sheets contain the detailed investigation carried out by CBI in
such cases."
306. CBI in its reports have detailed how Mr. Pankaj Bansal along with persons in the control and
management of M/s NYSA kept the mirror images of the OMR sheets and were providing data as
called for from time to time by SSC. SSC, in fact had responded to Right to Information Act
applications providing OMR sheets to individual RTI applicants, claiming that such data was in its
database. Affidavits filed by writ petitioners have borne out such facts. SSC had provided Anindita
Bera, writ petitioner in WPA 5538 of 2022, a copy of OMR sheet in January 18, 2024 from the data
stored in SSC data base. Nasrin Khatun who is the writ petitioner in WPA 17273 of 2021 had been
supplied OMR sheet on October 12, 2023 by SSC from its database. Setab Uddin, writ petitioner in
WPA 13700 of 2021 had been provided OMR Sheet by SSC on October 18, 2018. All OMR sheets
provided are scanned copies. CBI has stated that, when it took possession of the server of SSC, in it
did not find any OMR sheets in the database. Obviously, the then persons in control of SSC hadBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

utilized the same data as are available in the 3 hard disks from Mr. Pankaj Bansal to provide such
information to the RTI applicant.
307. The certificate dated September 16, 2022 issued by Mr. Pankaj Bansal, relates to the data
contained in the 3 hard disks. Adherence to the requirement of the Section 65B, in the facts and
circumstances of the present case, has to be adjudged on the conduct of the parties to the
proceedings. All the relevant parties have admitted the contents of the 3 hard disks and acted on it
without any demur. SSC has acknowledged manipulations/illegalities in the recommendations and
withdrew/cancelled the same. State has decided at the Cabinet level to grant and create
supernumerary posts to accommodate the illegal appointments. Factum, validity, legality,
sufficiency, authenticity of the data stored in the seized hard disks has been proved by the conduct
and actions of the relevant Article 12 authorities subsequent to the seizure of the 3 hard disks and
after CBI had shared such data with the relevant authorities. CBI has given inspection to such of the
parties to the proceedings who wanted inspection of the data stored therein, relevant to the party.
Claim of custody of the three hard disks from the time to seizure thereof by CBI till inspections given
or the data stored therein has not been broken. Insisting on further proof of such data stored in the
3 hard disks seized, for admissible of the same, would be an idle formality. Therefore, it would be
improper and a travesty of justice to allow the beneficiaries of the fraud to question the contents of
the 3 hard disks. They have questioned the data contained in the 3 hard disks in desperation so that
the fraud committed by them remains under wraps.
308. Neither Sections 3 and 58 of the Evidence Act, 1872 on one part and Section 65B thereof on the
other, mutually excludes each other. Section 65B of the Evidence Act, 1872 cannot be read to mean
that Section 3 or Section 58 of the Evidence Act, 1872 stands excluded. A fact sought to be proved
under Section 65B to said to be proved when the Court believes it to exist or considers its existence
probable, in lines of Section 3. A fact which otherwise would attract Section 65B need no further
proof if Section 58 conditions are satisfied.
309. In view of the discussions above, the certificate dated September 19, 2022 is held to be in
conformity with Section 65B of the Evidence Act, 1872 also and the contents of the three hard disks
to which it relates are admissible in evidence. The issue with regard thereto is answered in favour of
the writ petitioners and as against the persons opposing the writ petitioners.
Uploading of OMR sheets
310. The order of remand dated September 9, 2023 has permitted uploading of OMR sheets
available in the seized hard disks upon a finding being returned with regard to the admissibility of
the data contained in such hard disks. Having answered the issue with regard to the admissibility of
such data, in favour of the writ petitioners seeking uploading of such OMR sheets in the server of
SSC, the fifth issue tabulated in paragraph No. 119 herein, is answered by holding that the OMR
sheets available in the seized hard disks be uploaded in the server of SSC in order to compare the
same with the final list available in website of SSC. This direction of uploading is passed so that the
transparency of the selection process, or the lack of it, is available in public domain. Remaining
IssuesBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

311. For the sake of convenience, the last four issues are taken up for consideration together. Writ
petitions and the orders passed therein from time to time have uncovered a scam in relation to the
2016 selection process in respect of all the 4 categories. CBI has been appointed to investigate with a
SIT being constituted by the Court. CBI has registered four cases and filed charge sheets and
supplementary charge sheets in all the four cases. SSC has admitted manipulations/illegalities in
issuance of recommendations. Appointments have been given by the Board far in access of the
recommendations issued in respect of all the 4 categories. The Board could not have issued the
appointment letters without the recommendations.
Options available
312. In the factual context of the present proceedings, we have three options to explore, namely: -
i) Dismiss the writ petitions on the ground of maintainability; or
ii) Explore the possibility of segregating the valid appointments from the illegal ones;
or
iii) Set aside the selection made in the selection process in its entirety.
First Option
313. First option noted above is no longer available to us in view of the decision rendered by us on
the issue of maintainability of the writ petitions by us. Second Option
314. So far as the second option is concerned few authorities have been cited at the bar on such
subject.
315. In A. Kalaimani and others (supra), the selecting authority had cancelled the entire selection
process. Which was challenged. Supreme Court has noted the previous authorities on the subject
which were of the view that there is a vast difference in the cancellation of examination prior to the
selection and the termination of services of appointed persons. In facts of that case, the selecting
authority had initially conducted an inquiry on its own regarding the allegations pertaining to
manipulation of the OMR sheets. Selecting Authority had found that a few people benefited due to
the tampering of the OMR sheets. On a deeper scrutiny sufficient material had been found against
196 persons who were beneficiaries of the fraud in the alteration of marks. The Selecting Authority
had been convinced that there were chances of more people being involved in the manipulation of
marks for which reason a decision to cancel the entire examination. Such decision of the selecting
authority had been upheld.
316. A. Kalaimani and others (supra) has observed that, a bonafide decision taken by the Selecting
Authority to instill confidence regarding the integrity of the selection process could not have been
interfered with by the High Court. More so, sufficiency of the material on the basis of which a
decision had been taken by an authority is not within the purview of the High Court in exercising itsBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

power of judicial review.
317. Inderpreet Singh Kahlon (supra) has held that, only in the event it is found to be impossible or
highly improbable to separate tainted cases from the non-tainted ones, could en masse orders of
termination be issued. It has reviewed various authorities on the subject at that point of time. It has
noticed that, cases where the selection process was perceived to be tainted may be categorised into 4
classes. First being where the event has been investigated. Second being where CBI enquiry had
taken place and completed or a preliminary investigation was concluded. Third where the selection
had been made but appointment not made and fourth where the candidates were also ineligible and
the appointments were found to be contrary to law or rules.
318. Inderpreet Singh Kahlon (supra) has observed that, if after appointment, the services are
required to be terminated then, 3 principles must be satisfied. Firstly, it has to be established
satisfactorily that there are sufficient materials to arrive at the finding that the selection process was
tainted. Secondly, sufficient materials have been gathered by a thorough investigation in a fair and
transparent matter determining the question of the illegalities committed going to the root of the
matter. Thirdly, sufficient materials exist to arrive at a finding that the appointees had been found to
be part of the fraudulent purpose or the system itself was corrupt. It is also observed that an
appointment made in violation of Articles 14 and 16 of the Constitution of India would be void. It
would be a nullity.
319. In Rajesh P.U. Puthuvalnikathu and another (supra), the authorities had cancelled the entire
selection process. Supreme Court in the facts of the that case has found that, there is no justification
to cancel the entire selection when the impact of irregularities into the evaluation on merits could be
identified specifically and was found. In the facts of that case, on a reconsideration of the entire
records, it was found that the selection process had resulted in 31 specific numbers of candidates
being selected undeservedly. In such circumstances, Supreme Court has observed that, in absence of
any specific and categorical finding supported by any concrete and relevant materials that
widespread infirmity of all pervasive nature existed which could be said to undermine the very
process itself in its entirety or as whole and it was impossible to weed out the beneficiaries of one or
other irregularities or illegalities, there was hardly any justification in law to deny appointment to
other selected candidates whose selections were not vitiated.
320. The authorities noted above have observed that cancellation of a selection process without
appointment being given therein stands on a different footing than a selection process where
appointments had been granted. In the second category Courts must shift the grains from the chaff,
if possible. In the event it is impossible or highly improbable to shift the grain from the chaff then
the Court may venture to cancel the entire selection process. Prior to embarking upon such an
exercise, it must be satisfied that, the selection process was tainted on the basis of cogent materials.
There must be sufficient materials gathered through a thorough investigation that there had been
illegalities in the selection process. The appointees had benefited out of the illegalities and were a
part of it and that the appointments made were contrary to law.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

321. In respect of the 4 categories of the selection process involved, written examination has been
held. Written examination was in the form of OMR sheets. Original OMR sheets have been
destroyed by SSC. Mirror image of the destroyed OMR sheets was required to have been preserved
by SSC. CBI had seized the server of SSC and did not find mirror image of such OMR sheets in the
server of SSC.
322. SSC is an authority within the meaning of Article 12 of the Constitution and have been enjoined
with the task of undertaking the selection process. Last report of CBI has stated that, SSC appointed
M/s NYSA for the purpose of scanning and evaluation the OMR sheets. M/s NYSA had engaged
another organization namely, Data Scantech to do so. It is unclear as to whether, the new agency
had merely scanned the OMR sheets or was instrumental in evaluating the same also or not.
Chairman of SSC, in response to a query of the Court, has stated that, he was not aware of the
engagement of Data Scantech in the selection process and that, in fact, he became aware of such
name only from the Court, for the first time. No material has been disclosed as to who authorized
M/s. NYSA to engage Data Scantech or that such instrumentality was lawfully engaged by SSC.
323. Significantly, it is the claim of SSC that scanning of the OMR sheets had taken place at its
office. If that be so, then, SSC had knowingly allowed another organisation to scan the OMR sheets,
namely, Data Scantech who was not authorised at all. These raises serious questions as to the
integrity, sanctity and validity of the entire selection process and giving to the root of the selection
process. The evaluator of the selection process had been selected through a process which, at best,
shrouded in mystery if not downright illegal. Then the conduct of such evaluator is such that it
affects the validity of the process of evaluation itself.
324. Significantly, M/s NYSA had been appointed without an open tender. SSC had selected M/s.
NYSA ostensibly on the ground of it being the lowest tenderer from amongst a chosen few who were
asked to participate. The parameters/qualification required to participate remains undisclosed
despite request being made in Court to SSC. No explanation has been provided by SSC in course of
the hearing as to how and why such a course of action had been undertaken in identifying the
instrumentality who was to scan and evaluate the OMR sheets. Documents that had been made
available on record does not suggest that, competency, efficiency and whether M/s NYSA has the
requisite expertise to undertake such exercise was not considered by SSC at all. Letter of
appointment of M/s NYSA contains only two lines which requires M/s NYSA to scan and evaluate
the OMR sheets. No other terms and conditions of the appointment have been specified. The
appointment letter has been received by one employee of M/s NYSA from the office of SSC.
325. SSC had destroyed the original OMR sheets ostensibly by keeping mirror image thereof in its
server. CBI did not find those mirror images in the server of SSC. These facts have effectively ruled
out an exercise of shifting the grains from the chaff. The non-cooperative stand of SSC, State and
Board had added to the burden.
326. The entire selection process is shrouded in such mystery and in such layers that it is difficult to
fathom the quantum of illegalities performed. That illegalities had vitiated the selection process of
M/s. NYSA stands established. We have discussed the illegalities, so far discovered, vitiating theBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

selection process in course of our discussions herein and will tabulate the same hereafter.
327. The plausible inference from the materials made available on record and the conduct of the
relevant parties is that, the entire machinery was devised for the purpose of effectuating a scam
which will be hard to discover and even if discovered difficult to prove. Appointment of M/s. NYSA,
destruction of original OMR and non-availability of mirror images of OMR are some of the crucial
points in the fraud that came to be perpetuated in the selection process. As noted above, in course of
hearing all these matters, SSC, State and Board have perseveringly non-cooperated so that even the
possibility of trying to separate the grains from the chaff could be rendered nugatory.
328. What has been produced by the selection process is not a cereal comprising of grains and chaff
capable of segregation but a product unfit for human consumption. Fraud perpetrated and
perpetuated is deep and pervasive. Any attempt to shift the proverbial grain from the chaff would be
an unprofitable exercise, prolonging the agony and would put premium on dishonesty.
329. In the facts of the present case, blank OMR sheets have been submitted and such candidates
have been shown to have scored sufficiently higher number so as to be recommended for
appointment and ultimately given an appointment. The exact nature of candidates fraudulently
given the appointments cannot be identified, more so, in view of the attitude of noncooperation
exhibited by SSC. There are other manipulations/illegalities in the selection process which have
come to light. Again, exact number of persons who have benefited out of such manipulations and
illegalities in the selection process cannot be identified in its entirety. Some have been identified.
Identification of some is such that in respect of Group-D appointments, 48 % has been found to be
obtained by manipulations/illegalities. The percentages of manipulated/illegally appointed persons
across the other three categories are on a reducing scale compared to Group-D but none the less
sufficiently significant to question the validity of the entire selection process.
Third Option
330. In such circumstances, with the possibility of the second option of attempting to shift the grain
from the chaff becoming inconsequential, we are left with the only option of cancelling all
appointments in the four categories of the selection process involved.
331. We have given anxious consideration to the passionate plea that persons who had obtained the
appointments legally would be prejudiced, if we cancel the entire selection process. The other two
options being ruled out for the reasons noted above we have hardly been left with a choice. We
would rather have persons of integrity appointed as teachers through an untainted selection process
rather than expose students to elements securing appointments through an unscrupulous selection
process. Retaining appointees selected through such a dubious process would be contrary to public
interest. By dint of the tenure of service of such appointees, successive generations of students
would be exposed to these elements which would be counterproductive to public and national
interest. Individual interest should yield to public interest.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

332. Right to education has been recognized as part of fundamental right to life guaranteed under
Article 21 of the Constitution of India. Right to education as a fundamental right would entail a right
to receive education from duly qualified personnel. The selection process concerned does not inspire
any confidence to hold that, appointed persons had been selected in a fair and transparent manner.
The selection process was so mired that it was incapable of throwing up, the best in accordance with
merit, from amongst the participants. Persons submitting blank OMR sheets had secured
appointments, amongst other stark illegalities.
333. We are therefore constrained to hold that since the entire selection process is vitiated, all
appointments given thereunder are required to be cancelled. All appointments granted thereunder
are declared null and void.
334. In view of our finding that, the entire selection process stands vitiated and the appointments
granted therein, has to be cancelled, issue No. vi need not be answered. Similarly, we need not
detain ourselves, in the facts and circumstances of the present case, after having held that the entire
selection process stands vitiated and the appointments stands terminated, to answer issue Nos. vii
and viii of paragraph 119. Suffice it to say that, appointments that have been granted in violations of
Articles 14 and 16 of the Constitution of India are nullity and void ab initio.
Illegalities in the selection process
335. The evidence placed before us have established the following illegalities in the selection
process: -
(i) SSC had appointed an agency namely M/s.
NYSA for the purpose of scanning and evaluating the OMR sheets by a closed-door tender process in
violation of Articles 14 and 16 of the Constitution of India
(ii) such agency had engaged another agency namely, Data Scantech to scan the OMR sheets
(iii) although scanning was done at the office premises of SSC, it is claimed by SSC that, SSC had
never engaged Data Scantech to scan the OMR sheets or authorised M/s. NYSA to engage Data
Scantech or any other agency
(iv) SSC had destroyed the original OMR sheet ostensibly with scanned mirror image thereof being
preserved in its server
(v) CBI did not find any scanned mirror image of OMR sheets in the server of SSC
(vi) OMR sheets had been destroyed without the scanned mirror images being preserved in the
server of SSCBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

(vii) SSC had provided scanned OMR sheets to RTI applicants in the year 2018 till 2023 claiming
that such OMR sheets were from its database although, CBI did not find any OMR sheets in the
server of SSC
(viii) appointments higher than the declared vacancies had been given in respect of all 4 categories
(ix) appointments had been given to persons who were not even in the panel
(x) appointments had been given to persons who submitted blank OMR sheets
(xi) appointments had been given persons after expiry of the panel
(xii) persons placed lower in rank had been given appointment in preference to persons placed
higher in rank in the merit list
(xiii) merit list containing the marks obtained by the respective candidates had never been
published
(xiv) counselling had been held subsequent to the expiry of the panel
(xv) total beneficiaries of the illegalities are yet to be identified and rendered improbable given the
stand of SSC, Board and State (xvi) SSC had applied for permission to create supernumerary posts
to accommodate the illegal appointees (xvii) Recruitment Rules governing the four categories had
never been adhered to either in letter or spirit
336. These illegalities have been established by Justice Bag Committee Report, Reports and
affidavits of SSC, Reports and affidavits of CBI as well as conduct of State.
337. These established illegalities, singularly and cumulatively have demarcated the contours for the
Court to nagivate with regard to the reliefs ordained. Reliefs
338. Having decided on the issues raised, and the illegalities committed in the selection process we
have to now consider the reliefs warranted in the factual matrix. In considering the reliefs that may
be granted, we have to take into consideration the objections raised on behalf of the persons
opposing the writ petition that, reliefs beyond the pleadings and the prayers of the writ petition
should not be granted. We have to bear in mind that the reliefs granted should be of such nature so
as act as a disincentive if not deterrence for the sordid saga replaying itself in any manner or form.
339. Although, the ordinary rule is that the rights of the party stand crystallized on the date of
institution of the proceedings, yet the Court has powers to mold the reliefs should the reliefs
originally claimed by reason of subsequent events becomes inappropriate or cannot be granted.
Courts can also mold the reliefs when, if a note is taken of the subsequent events, the litigation
between the parties would be shortened. All that is required in such circumstances is that the
subsequent event is brought to the notice of the parties and the Court so that the parties are notBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

taken by surprise. Courts have bounden duty not to ignore subsequent events which have occurred
during the pendency of lis, when such subsequent events are brought to the notice of the Court by
the parties.
340. In the facts of the present case, the writ petitioners had approached the writ Court primarily to
secure employment for themselves. Orders had been passed in the writ petitions; an investigation
had been carried out by CBI which disclosed a scam of an epic proportions. Order of investigation
through CBI has not been interfered with by the Supreme Court. CBI has registered four cases, filed
charge sheets and supplementary charge sheets therein. State has taken into consideration the
subsequent events and at the level of the Cabinet decided to create supernumerary post for persons
who had been granted appointments illegally. Therefore, we are obligated to take into consideration
the subsequent events, mold the reliefs that the parties are entitled to. We have to provide
substantial justice between the parties, take cognizance of the subsequent events and grant such
relief as is just and proper.
341. S.S. Sharma and others (supra) has held that, Court should ordinarily insist on the parties being
confined to their specific written pleadings and should not be permitted to deviate from them by
way of modification or supplementation except through the well-known process of formally applying
for amendment.
342. S. Vasudeva and others (supra) has held that, the High Court should not travel beyond the
scope of the writ petition. In the facts of that case, justification in the allotment as done by the
authorities was found by the Supreme Court.
343. In V.K. Majotra and others (supra), the Supreme Court has held that, the High Court
overstepped the jurisdiction in issuing directions to non-parties and considering questions which
were not raised. The Court had overstepped its jurisdiction in giving a direction beyond the
pleadings or the points raised by the parties during the course of the arguments. It has also observed
that, if additional points are raised then the concerned parties likely to be affected should be put on
notice on such additional points to satisfy the principle of natural justice.
344. In the facts of the case of the Ajay Dogra and others (supra), the Supreme Court has held that,
the High Court was incorrect in issuing direction for relaxation of recruitment rule going beyond the
pleadings.
345. In a challenge thrown to a land acquisition proceeding, Supreme Court in K.N. Farms and
Industries Private Limited (supra), has held that, multiple writ petitions and particularly when the
pleadings and reliefs claimed in the first writ petition affects the subsequent ones more so when
there was delay and laches with the claim being hopelessly barred, the writ petition should be held
to be not maintainable.
346. Authorities cited at the bar with regard to grant of reliefs beyond pleadings have not stated,
that, there is complete embargo on the Court taking note of the subsequent events and moulding the
reliefs so as to render complete justice to the parties.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

347. The events that had occurred subsequently are largely results of investigations conducted by
the CBI and ED which has brought forth the scam. It would be putting premium on dishonesty
should the Court decide to ignore such subsequent events on the plea that the same has not been
raised by the writ petitioners in the writ petitions at the time when they had filed the writ petitions.
It is not the case of opposing parties to the writ petitions that, the writ petitioners had known about
the nature, extent and scope of the scam that had come to light during the pendency of the writ
petitions. None of the parties to the proceedings has been taken by surprise with regard to the
materials that have been brought on the record in the sense that, all the parties are aware of at least
the stand of the State, CBI and SSC with regard to selection process in question. All candidates who
had received appointments through the selection process had been informed by the State as to the
pendency of the proceedings pursuant to our order.
348. While deciding on the reliefs that should be granted, we have to take in consideration the fact
that, the selection processes were for teaching and non-teaching staff in respect of State Funded
Educational Institutions. A school is a place where a ward is sent for holistic development. A school
imparts education that prepares a child for his/her onward journey in life. It is imperative that the
child is placed in company of persons who are not tainted.
349. Since time immemorial, every civilization has placed teachers at a pedestal of reverence. They
are role models which every student by reason of they being of impressionable age have always tried
to emulate. Law has recognized that teachers step into the shoes of loco parentis of the ward once
the ward is placed in the educational institution. Teachers have the onerous task of inculcating
values in the students. They have the task of creating and maintaining a pristine atmosphere around
a student so as to nurture the creativity of the student. It would be naïve to except such qualities
from persons obtaining employment by dubious means.
350. Educational institutions have been admired, accorded special place in the society and have
been ring fenced against the ills that may befall the society. Civilizations have made such attempts so
that, the future generation develops in an environment conducive for attaining the dreams of an
individual student and caters to the holistic development of the student. Educational Institutions
are expected to produce better and evolved citizens who would be a in position to contribute to the
society, nation and to mankind. Parents put their wards into educational institutions with the
expectation that, such educational institution imparts a level of education so as to assist the wards to
develop into a better human being.
351. Human beings are in control of any educational institution, as in other institutions. If the
teacher and the non- teaching staff of such educational institution, or even a portion thereof, obtains
appointments fraudulently, such teacher or nonteaching staff immediately forfeits his integrity,
honesty and his ability to impart wholesome education to a child in such an educational institution.
An educational institution must be protected against such elements attempting to percolate, let
alone permeate into it. It is therefore, imperative and in the beneficial interest of the society that
such elements are removed from an educational institution.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

352. SSC had filed CAN 2 of 2022 in WPA 5538 of 2022 and CAN 6 of 2022 in WPA 5406 of 2022
seeking permission for creation of supernumerary posts for the illegal appointees. When objected to
by the writ petitioner, SSC had sought to withdraw such applications. Learned Single Judge had
declined the request for withdrawal by the order dated November 24, 2022. A Special Leave Petition
had been preferred where; an order dated November 25, 2022 had been passed.
353. In the two applications noted above, the learned Single Judge had directed CBI to undertake
investigations in respect of the creation of supernumerary posts. Division Bench had refused to stay
such directions. Supreme Court had, by the order dated November 25, 2022, stayed such direction.
354. Stay granted by the Supreme Court on November 25, 2022 was against the interim order
passed in the pending writ petitions. Lest it be contended that, we have not directed measures to be
taken in respect of the creation of the supernumerary post, on final hearing of the writ petitions and
the appeals, we deem it appropriate to pass necessary directions with regard thereto also.
355. Investigation by CBI, with regard to the creation of supernumerary posts is imperative to bring
to light, the nature and extent of the scam and persons that are involved therein. It is shocking that,
at the level of the cabinet of the State Government, decision is taken to protect employment
obtained fraudulently in a selection process conducted by SSC for State Funded Schools, knowing
fully well that, such appointments were obtained beyond the panel and after expiry of the panel, at
the bare minimum.
356. The enormity of such wrong doing is accentuated by the fact that the illegal appointments are
sought to be confirmed in educational institutions. Persons involved in such decision-making
process therefore have exposed children to persons who obtained their employment through
fraudulent means.
357. Unless there is a deep and pervasive connection between the persons perpetuating the fraud
and the beneficiaries thereof with persons involved in the decision- making process such course of
action in resolving to create supernumerary posts to protect illegal appointments is inconceivable.
Moreover, each of the persons involved acted in violation Articles 14 and 16 of the Constitution of
India. Whether such violations have resulted in criminal liability should be investigated into.
358. Since at least a portion of the beneficiaries of the scam that is to say that, some of the persons
who were appointed beyond the panel and after expiry of the panel and appointees submitting blank
OMR sheets, stands identified, it would be appropriate to direct such persons to return the benefits
and usufructs they received through fraudulent means. These are proceeds of crime. Therefore, we
propose to issue directions for return and recovery thereof.
359. Their role in the entire episode should also be investigated into. Consequently, we propose to
issue directions with regard thereto also. It is imperative that their role is also investigated into so as
to identify, if possible, the manner in which, the fraud came to be executed. ExceptionBaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

360. During the pendency of these proceedings, learned single Judge had taken note of the plight of
one candidate namely, Ms. Soma Das and directed registration of a writ petition being WPA 6836 of
2022 with regard thereto. Ms. Soma Das had subsequently filed WPA 6942 of 2022 in which an
order dated April 18, 2022 was passed by the learned single Judge. There, the learned single Judge
had taken note of the medical condition of Ms. Soma Das and requested the State Government to
consider providing her an employment purely on humanitarian grounds.
361. In course of hearing of the matters, before us, it has been submitted that, Court should make an
exception so far as Ms. Soma Das is concerned since, her appointment was purely on humanitarian
grounds.
362. We have considered the order dated April 18, 2022 passed in WPA 6942 of 2022 and find that,
request for consideration of appointment of Ms. Soma Das was made purely on humanitarian
grounds due to the medical conditions of such person. Ms. Soma Das had been granted appointment
by the State Government purely on humanitarian grounds. Consequently, we propose not to disturb
her appointment as, the State had granted her appointment on humanitarian grounds. She will
stand outside the directions issued hereafter.
Directions
363. In view of the discussions above, we issue the following directions: -
(i) Writ petitions appearing in the monthly list of March, 2024 of this Bench, which
are not filed and numbered in the years 2021 and 2022 are released from the list due
to lack of jurisdiction/determination.
(ii) All appointments granted in the selection processes involved being violative of
Articles 14 and 16 of the Constitution of India, are declared null and void and
cancelled.
(iii) OMR sheets available in the three hard disks, if not already done or such portion
not done, must be uploaded in the website of SSC forthwith and made available to the
public for viewing.
(iv) Persons who had been appointed outside the panel, after expiry of the panel as
also those who submitted blank OMR sheets but obtained appointments, must return
all remunerations and benefits received by them to the State exchequer along with
interest calculated at 12 percent per annum, from the date of receipt thereof till
deposit, within a period of four weeks from date.
(v) In default, the District Magistrates under whose jurisdictions, such candidates
reside, will take expeditious steps to realize such amount from such persons, as
arrears of land revenue and shall ensure that recovery is made within a period of six
weeks of the date of initiation of proceeding for recovery.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

(vi) Respective District Inspectors of School will report to the respective District
Magistrates as to whether money directed to be paid by the persons concerned have
been paid to the State exchequer or not.
(vii) CBI will undertake further investigation in respect of all the four cases. CBI will
interrogate all persons who had received appointments beyond the panel, after expiry
of the panel and after submitting blank OMR sheets. If necessary, CBI shall
undertake custodial interrogation in respect of each of them.
(viii) CBI will undertake further investigations with regard to the persons involved, in
the State Government approving creation of supernumerary post to accommodate
illegal appointments. If necessary, CBI will undertake custodial interrogation of such
person involved.
(ix) CBI shall submit its reports with regard to further investigations as directed
herein, preferably within three months from date, with the jurisdictional Court.
(x) Leave granted to SIT to seek appropriate directions so that the investigations and
trials come to their logical conclusions.
(xi) SSC shall undertake a fresh selection process in respect the declared vacancies
involved in these selection processes prefereably within a fortnight from the date of
declaration of results of the ensuing elections.
(xii) Appointments for preparation, evaluation and scanning of OMR sheets shall be
made by SSC by open tender and after declaring the eligibility citeria and other terms
and conditions of the contract.
(xiii) SSC shall follow the Rules governing the selection processes in letter and spirit.
(xiv) SSC shall make available all policy decisions with regard to compliance of the
Recruitment Rules governing any of the categories of the selection process in its
website.
Conclusion
364. WPA 7592 of 2021, WPA 8003 of 2021, WPA 8264 of 2021, WPA 10938 of 2021, WPA 10947 of
2021, WPA 10949 of 2021, WPA 10960 of 2021, WPA 13700 of 2021, WPA 13701 of 2021, WPA
13721 of 2021, WPA 13727 of 2021, WPA 13863 of 2021, WPA 13885 of 2021, WPA 15137 of 2021,
WPA 15154 of 2021, WPA 16443 of 2021, WPA 16444 of 2021, WPA 16448 of 2021, WPA 16450 of
2021, WPA 16476 of 2021, WPA 16481 of 2021, WPA 16484 of 2021, WPA 16487 of 2021, WPA
16489 of 2021, WPA 16505 of 2021, WPA 16519 of 2021, WPA 16858 of 2021, WPA 16859 of 2021,
WPA 16860 of 2021, WPA 16879 of 2021, WPA 16880 of 2021, WPA 16889 of 2021, WPA 16896 of
2021, WPA 16902 of 2021, WPA 16930 of 2021, WPA 16948 of 2021, WPA 16960 of 2021, WPABaishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

16968 of 2021, WPA 17273 of 2021, WPA 18379 of 2021, WPA 18381 of 2021, WPA 18383 of 2021,
WPA 18385 of 2021, WPA 18387 of 2021, WPA 18388 of 2021, WPA 18460 of 2021, WPA 18470 of
2021, WPA 18487 of 2021, WPA 18491 of 2021, WPA 18496 of 2021, WPA 18499 of 2021, WPA
18801 of 2021, WPA 18994 of 2021, WPA 19475 of 2021, WPA 18995 of 2021, WPA 19477 of 2021,
WPA 19478 of 2021, WPA 19580 of 2021, WPA 20906 of 2021, WPA 21258 of 2021, WPA 21261 of
2021, WPA 21263 of 2021, WPA 21266 of 2021, WPA 21267 of 2021, WPA 21268 of 2021, WPA
21317 of 2021, WPA 21430 of 2021, WPA 3665 of 2021, WPA 10772 of 2021, WPA 12266 of 2021,
WPA 17068 of 2021, WPA 18585 of 2021, WPA 19977 of 2021, WPA 20070 of 2021, WPA 3654 of
2021, WPA 10764 of 2021, WPA 12270 of 2021, WPA 17048 of 2021, WPA 18589 of 2021, WPA
18590 of 2021, WPA 18593 of 2021, WPA 19975 of 2021, WPA 2898 of 2021, WPA 2903 of 2021,
WPA 7982 of 2021, WPA 8266 of 2021, WPA 10316 of 2021, WPA 10929 of 2021, WPA 16936 of
2021, WPA 18475 of 2021, WPA 19000 of 2021, WPA 21312 of 2021, WPA 21386 of 2021 along with
all other connected applications are disposed of accordingly.
365. WPA 781 of 2022, WPA 1618 of 2022, WPA 5538 of 2022, WPA 5786 of 2022, WPA 5788 of
2022, WPA 6550 of 2022, WPA 7346 of 2022, WPA 7347 of 2022, WPA 8059 of 2022, WPA 16935
of 2022, WPA 20389 of 2022, WPA 21332 of 2022, WPA 21334 of 2022, WPA 21340 of 2022, WPA
21344 of 2022, WPA 21346 of 2022, WPA 21349 of 2022, WPA 21350 of 2022, WPA 25380 of 2022,
WPA 26770 of 2022, WPA 27886 of 2022, WPA 28197 of 2022, WPA 6754 of 2022,WPA 8598 of
2022, WPA 10211 of 2022, WPA 14630 of 2022, WPA 14670 of 2022, WPA 15359 of 2022, WPA
19053 of 2022, WPA 19916 of 2022, WPA 20028 of 2022, WPA 27164 of 2022, WPA 27166 of 2022,
WPA 27168 of 2022, WPA 8614 of 2022, WPA 10213 of 2022, WPA 14525 of 2022, WPA 14634 of
2022, WPA 15360 of 2022, WPA 17340 of 2022, WPA 19060 of 2022, WPA 20030 of 2022, WPA
27161 of 2022, WPA 1637 of 2022, WPA 5405 of 2022, WPA 5406 of 2022, WPA 13431 of 2022,
WPA 22845 of 2022, WPA 25379 of 2022, WPA 26756 of 2022, WPA 27457 of 2022 along with all
other connected applications are disposed of accordingly.
366. WPA 30649 of 2016, WPA 30653 of 2016, WPA 30065 of 2017, WPA 2613 of 2018, WPA 22522
of 2018, WPA 22523 of 2018, WPA 22550 of 2018, WPA 22773 of 2018, WPA 22780 of 2018, WPA
22782 of 2018, WPA 22785 of 2018, WPA 22973 of 2018, WPA 13113 of 2018, WPA 18034 of 2018,
WPA 12662 of 2018, WPA 13105 of 2018, WPA 22777 of 2018, WPA 22971 of 2018, WPA 16844 of
2019, WPA 18355 of 2019, WPA 19273 of 2019, WPA 19278 of 2019, WPA 19749 of 2019, WPA
20404 of 2019, WPA 20776 of 2019, WPA 20778 of 2019, WPA 21665 of 2019, WPA 18100 of 2019,
WPA 18627 of 2019, WPA 20045 of 2019, WPA 21923 of 2019, WPA 22119 of 2019, WPA 23259 of
2019, WPA 23454 of 2019, WPA 23946 of 2019, WPA 20034 of 2019, WPA 20022 of 2019, WPA
20029 of 2019, WPA 20039 of 2019, WPA 18352 of 2019, WPA 21154 of 2019, WPA 22076 of 2019,
WPA 23064 of 2019, WPA 23480 of 2019, WPA 23481 of 2019, WPA 4835 of 2020, WPA 8078 of
2020, WPA 8555 of 2020, WPA 11455 of 2020, WPA 3476 of 2020, WPA 6887 of 2020, WPA 7425
of 2020, WPA 7616 of 2020, WPA 7630 of 2020, WPA 8536 of 2020, WPA 362 of 2023, WPA 1062
of 2023, WPA 1066 of 2023, WPA 1070 of 2023, WPA 1072 of 2023, WPA 1075 of 2023, WPA 1369
of 2023, WPA 1466 of 2023, WPA 3771 of 2023, WPA 4206 of 2023, WPA 4841 of 2023, WPA 4989
of 2023, WPA 5087 of 2023, WPA 5379 of 2023, WPA 5604 of 2023, WPA 5609 of 2023, WPA 2081
of 2023, WPA 2149 of 2023, WPA 2151 of 2023, WPA 2154 of 2023, WPA 2172 of 2023, WPA 2175
of 2023, WPA 2179 of 2023, WPA 2182 of 2023, WPA 2215 of 2023, WPA 2496 of 2023, WPA 2760Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

of 2023, WPA 2967 of 2023, WPA 2984 of 2023, WPA 3126 of 2023, WPA 3399 of 2023, WPA 3652
of 2023, WPA 3658 of 2023, WPA 3661 of 2023, WPA 3664 of 2023, WPA 3666 of 2023, WPA 3846
of 2023, WPA 3859 of 2023, WPA 3926 of 2023, WPA 3931 of 2023, WPA 3935 of 2023, WPA 3990
of 2023, WPA 4117 of 2023, WPA 4213 of 2023, WPA 4313 of 2023, WPA 4522 of 2023, WPA 4556
of 2023, WPA 5134 of 2023, WPA 5464 of 2023, WPA 5526 of 2023, WPA 5531 of 2023, WPA 5797
of 2023, WPA 5799 of 2023, WPA 5953 of 2023, WPA 6164 of 2023, WPA 6210 of 2023, WPA 6213
of 2023, WPA 6282 of 2023, WPA 6577 of 2023, WPA 6854 of 2023, WPA 6859 of 2023, WPA 6915
of 2023, WPA 7370 of 2023, WPA 7528 of 2023, WPA 7831 of 2023, WPA 7952 of 2023, WPA 9105
of 2023, WPA 9327 of 2023, WPA 10387 of 2023, WPA 10614 of 2023, WPA 12557 of 2023, WPA
13588 of 2023, WPA 14824 of 2023, WPA 17679 of 2023, WPA 18401 of 2023, WPA 19126 of 2023,
WPA 19604 of 2023, WPA 19605 of 2023, WPA 19869 of 2023, WPA 21000 of 2023, WPA 21211 of
2023, WPA 22796 of 2023, WPA 23761 of 2023, WPA 24247 of 2023, WPA 26848 of 2023, WPA
160 of 2023, WPA 1079 of 2023, WPA 1080 of 2023, WPA 1083 of 2023, WPA 1086 of 2023, WPA
2077 of 2023, WPA 2511 of 2023, WPA 2982 of 2023, WPA 3463 of 2023, WPA 4519 of 2023, WPA
4715 of 2023, WPA 7031 of 2023, WPA 9315 of 2023, WPA 10617 of 2023, WPA 10724 of 2023,
WPA 14104 of 2023, WPA 18400 of 2023, WPA 21210 of 2023, WPA 21999 of 2023, WPA 22860 of
2023, WPA 23204 of 2023, WPA 23652 of 2023, WPA 24930 of 2023, WPA 25669 of 2023, WPA
366 of 2024 along with all connected applications are released from the list.
367. So far as the appeals are concerned, all appeals emanating out of orders passed by the learned
Single Judge in writ petitions filed in 2021 and 2022 are disposed of in terms of the directions
passed herein. Appeals arising out of orders passed by the larned Single Judge in writ petitions
other than writ petitions filed in 2021 and 2022 are released from the list.
368. MAT 85 of 2023, MAT 124 of 2023, MAT 245 of 2023, MAT 290 of 2023, MAT 304 of 2023,
MAT 250 of 2023, MAT 259 of 2023, MAT 274 of 2023, MAT 275 of 2023, MAT 276 of 2023, MAT
284 of 2023, MAT 318 of 2023, MAT 336 of 2023, MAT 334 of 2023, MAT 338 of 2023, MAT 342 of
2023, MAT 343 of 2023, MAT 344 of 2023, MAT 345 of 2023, MAT 346 of 2023, MAT 358 of 2023,
MAT 359 of 2023, MAT 361 of 2023, MAT 382 of 2023, MAT 443 of 2023, MAT 457 of 2023, MAT
458 of 2023, MAT 476 of 2023, MAT 502 of 2023, MAT 470 of 2023, MAT 480 of 2023, MAT 521 of
2023, MAT 199 of 2023, MAT 950 of 2023, MAT 1302 of 2023, MAT 1304 of 2023 along with all
other connected applications are disposed of accordingly.
369. MAT 244 of 2023 and MAT 557 of 2023 along with all other connected applications are
released from the list.
[DEBANGSU BASAK, J.]
370. I agree.
[MD. SHABBAR RASHIDI, J.] Later :-
Learned advocates opposing the writ petitions as also learned advocate appearing for
SSC have prayed for stay of the operation of the judgement and order.Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

Learned Senior Advocate appearing for the writ petitioners and learned Additional
Solicitor General for CBI have opposed the prayer for stay.
We have considered the respective submissions.
We have passed our judgement and order where we have found the appointments to
be in violation of the constitutional provisions.
In such circumstances, we are unable to accede to the prayer for stay.
Department will take steps to have the judgement and order bound in an appropriate
form.
[DEBANGSU BASAK, J.] I agree.
[MD. SHABBAR RASHIDI, J.]Baishakhi Bhattacharyya (Chatterjee) ... vs State Of West Bengal & Ors on 22 April, 2024

