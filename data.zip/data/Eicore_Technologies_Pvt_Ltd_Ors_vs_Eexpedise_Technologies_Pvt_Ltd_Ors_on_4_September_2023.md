Eicore Technologies Pvt. Ltd. & Ors vs Eexpedise Technologies
Pvt. Ltd. & Ors on 4 September, 2023
Author: Jyoti Singh
Bench: Jyoti Singh
                                    $~
                                    *       IN THE HIGH COURT OF DELHI AT NEW DELHI
                                    +       CS(COMM) 1146/2018
                                            EICORE TECHNOLOGIES PVT. LTD.
                                            & ORS.                              ..... Plaintiffs
                                                         Through: Mr. Jayant Kumar Mehta,
                                                         Senior Advocate with Mr. J. Sai Deepak,
                                                         Mr. Debarshi Dutta, Ms. Manvi Adlakha,
                                                         Mr. Avinash, Mr. Akshat Kaushik and
                                                         Mr. Amrit Singh, Advocates.
                                                                                 versus
                                            EEXPEDISE TECHNOLOGIES PVT. LTD.
                                            & ORS.                               ..... Defendants
                                                         Through: Mr.      Anil       Sapra,   Senior
                                                         Advocate with Ms. Bitika Sharma,
                                                         Ms. Vrinda Pathak, Mr. Lakshay Kaushik
                                                         and Ms. Palak Mittal, Advocates for D-1 to
                                                         D-7 and D-12 to D-19.
                                                         Mr. R.R. Jangu, Advocate for D-10 and
                                                         D-11.
                                            CORAM:
                                            HON'BLE MS. JUSTICE JYOTI SINGH
                                                                                 ORDER
% 04.09.2023 I.A. 13265/2018 (under Order XXXIX Rules 1 and 2 CPC, by Plaintiffs)
1. This is an application filed by the Plaintiffs inter alia seeking restraint against Defendants No. 1 to
19 and/or their agents, franchisees, partners etc. from infringing/offending or violating Plaintiffs
No. 1 and 5's copyright in their original literary work 'HealthBuzz', Plaintiffs' confidential data,
information and trade secrets. Interim injunction is also sought to restrain the Defendants from
printing, publishing, reproducing, copying and plagiarizing or This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:45
otherwise dealing in any manner whatsoever with the literary works of the Plaintiffs and from
holding out as associates or affiliates, or in any manner connected with, any of the Plaintiffs' or their
subsidiaries or associate companies; marketing, selling, using, giving on license, providing supportEicore Technologies Pvt. Ltd. & Ors vs Eexpedise Technologies Pvt. Ltd. & Ors on 4 September, 2023

services, carrying out any form of modification or development on the software 'HealthBuzz' and/or
providing services in relation to 'HealthBuzz' to companies or entities that are already using the said
software in any form or name and style, more particularly, under the name 'HealthIns'. Restraint is
also sought against the Defendants from in any manner using any trademark, trade name,
copyright, logo or any symbol identified with the Plaintiffs or soliciting the employees, directors,
agents or associates of the Plaintiffs besides claim for damages etc.
2. Factual matrix to the extent necessary and relevant is that Plaintiff No. 1 is involved in business of
providing software and other information technology services to its clients in the insurance sector
and holds intellectual property rights in respect of health insurance policy and claims
administration systems like 'HealthBuzz', 'Way2doc', 'Kyor', 'Provider Portal', 'Care Compare Portal',
'I- Buzz' and 'Health X'. Plaintiff No. 5 is the copyright owner of software 'HealthBuzz' and has
licensed his rights in favour of Plaintiff No. 1 who in turn licenses the software to its clients and also
provides Annual Maintenance Cover, customer developments, improvements as well as Customer
Support Services in relation to such software. Plaintiffs No. 1 to 4 are part of global healthcare and
information technology conglomerate called the 'E-Meditek Group' that runs a number of
enterprises and companies in India.
3. As per the averments in the plaint, Defendant No. 4 was working as CEO of Plaintiff No. 1 from
13.08.2012 and resigned on This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:45
11.07.2017. Defendant No. 6 joined Plaintiff No. 1 as Vice-President on 01.04.2010 and resigned on
03.07.2017 as Senior Vice President, Defendant No. 8 joined Plaintiff No. 3 as Senior Manager on
02.06.2008 and was Vice President (Finance and Accounts) on the date of his resignation on
27.03.2017. Defendant No. 10 joined Plaintiff No. 3 on 17.04.2007 as Assistant Branch Manager and
resigned on 24.04.2017 as Vice President. Defendant No. 12 was Project Manager with Plaintiff No.
2 from 01.03.2012 till 24.10.2016 when he resigned. Defendants No. 14 to 19 were other employees
of Plaintiffs No. 1 to 4 companies.
4. Defendant No. 1 is a company incorporated on 04.03.2016 with Defendants No. 7 and 9 as
original subscribers. They are wives of Defendants No. 4 and 8 respectively. Defendant No. 2 is a
company incorporated on 19.05.2016 with Defendant No. 5 (wife of Defendant No. 4), Defendant
No. 11 (wife of Defendant No. 10) and Defendant No. 13 (wife of Defendant No. 12) as original
subscribers albeit at the time of filing the suit Defendants No. 4 and 12 were Directors of Defendant
No. 1 and Defendant No. 2. Defendant No. 3 was incorporated as a company on 22.05.2016 with
Defendants No. 5, 9 and 11 as original subscribers.
5. It is the case of Plaintiffs that Plaintiff No. 1 caters to major insurance companies in India and
abroad and their major clientele includes market leaders in insurance sector such as Future Generali
India Insurance Co. Ltd., Raheja QBE General Insurance Company Limited, Aditya Birla Health
Insurance Company Limited ('ABHICL'), Cigna TTK Healthcare, Cigna Health Solutions India
Private Limited etc. Plaintiff No. 3's expertise spans wide range of activities including Health BenefitEicore Technologies Pvt. Ltd. & Ors vs Eexpedise Technologies Pvt. Ltd. & Ors on 4 September, 2023

Administrations under various health insurance policies and E-Meditek offers a host of services
such This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46 as
pre-policy health checkups, cashless treatment, hospital bill repricing for overseas travel claim etc.
Plaintiff No. 4 provides health and wellness services and has over 70 clients including companies
such as Tata Consultancy Services, Infosys, Maruti, Yes Bank and also operates over 100 Primary
Medical Centres in corporate offices of its clients.
6. The grievances which triggered the filing of the present suit, as alleged in the plaint, are that some
of the Defendants, who were employees of the Plaintiffs, in course of their employment with the
Plaintiffs, fraudulently created parallel business entities i.e. Defendants No. 1 to 3, without Plaintiffs'
knowledge and misused their association with the Plaintiffs to encash on Plaintiffs' formidable
goodwill and reputation. Defendants have misused confidential information and have diverted
legitimate business of the Plaintiffs to Defendants No. 1 to 3 and Defendants are now selling the
software 'HealthIns' which is substantially similar to 'HealthBuzz', apart from servicing the software
'HealthBuzz' installed by the Plaintiffs with their clients under duly executed License/Master Service
Agreements.
7. Contentions raised on behalf of the Plaintiffs can be summarized as follows:
(a) Instant suit is a textbook instance of infringement of copyright of a computer
programme within the meaning of Section 51 of the Copyright Act, 1957 (hereinafter
referred to as the '1957 Act'). The illegal and fraudulent activities of the Defendants
are compounded by the fact that some of them were erstwhile employees of the
Plaintiffs and infringed not only during the course of employment but continued to
do so after their premeditated resignation to float parallel companies as competitors.
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46
(b) Heart of the dispute in the present suit relates to source code of a computer programme and is
not predicated purely on an illegal action for restraint of trade under Section 27 of the Indian
Contract Act, 1872, which red herring forms the substratum of Defendants' defence.
(c) Subject matter of the dispute, namely, the computer programme/software 'HealthBuzz' and its
source code, is the exclusive copyrighted property of Plaintiffs and is an all- encompassing premier
health insurance system, licensed to various insurance companies in India and abroad, designed to
assist various businesses including but not limited to general, life and health insurance companies,
Insurance brokers, third party operators and organisations which run self-managed health schemes.
'HealthBuzz' has number of modules such as provider management, fraud waste and abuseEicore Technologies Pvt. Ltd. & Ors vs Eexpedise Technologies Pvt. Ltd. & Ors on 4 September, 2023

management etc. and is the original 'literary work' of Plaintiff No. 5, in which he has copyright
registration.
(d) Source code of a computer programme, such as 'HealthBuzz' in the present case, is recognized as
'literary work' under Section 2(o) of the 1957 Act, which defines 'literary work' to include computer
programmes, tables and compilations including computer databases. 'Computer programme' is
defined in Section 2(ffc) to mean a set of instructions expressed in words, codes, schemes or in any
other form, including a machine readable medium, capable of causing a computer to perform a
particular task or achieve a particular result. Indian Courts have recognized the existence of
copyright in source code. [Ref. Syed Asifuddin and Others v. The State of Andhra Pradesh and
another, 2005 SCC This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46
OnLine AP 1100]. Source code is also considered confidential information. It is settled law that there
are three important elements for protection of confidence i.e. information itself is confidential; it is
communicated or imparted to the Defendant under circumstances which cast an obligation of
confidence on him; and information shared is actually used or threatened to be used unauthorizedly
by the Defendants. [Ref. Beyond Dreams Entertainment Pvt. Ltd. & Ors. v. Zee Entertainment
Enterprises Ltd. & Anr., 2015 SCC OnLine Bom 4223]. These judgments squarely apply to the
present case as Plaintiffs have copyright in the source code of HealthBuzz and the same also falls
within the definition of confidential information.
(e) Defendants No. 4, 6, 8, 10, 12 and 14 to 19 are ex-
employees of Plaintiffs No. 1 to 4. In the course of their employment, they discreetly incorporated
Defendants No. 1 to 3, while they had complete access to Plaintiffs' proprietary software
'HealthBuzz', its source code and all other confidential data and trade secrets of the Plaintiffs. The
infringing activities include misrepresentation to Plaintiffs' clients and business community that
Defendants No. 1 to 3 were associates of Plaintiffs and authorized to provide services. Actual
servicing/maintenance of the softwares installed by the Plaintiffs for their clients can only be
possible if there is access to the source code of Plaintiffs' software 'HealthBuzz' and therefore, it is
evident that even while servicing the softwares of the clients of the Plaintiffs, Defendants are using
the copyrighted source code. Provision of other services, such as addition of modules or This is a
digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46
functionalities or carrying out other change requests at the instance of the clients is also impossible
without access, use and modification of the source code of 'HealthBuzz'.
(f) Defendant No. 4 while in Plaintiffs' employment, approached Microsoft and its distributors to
make Defendant No. 1 as the Cloud Solution Provider Partner for reselling Azure (Microsoft Cloud
Platform on which 'HealthBuzz' is hosted) to Plaintiff No.1's client, which was to be otherwiseEicore Technologies Pvt. Ltd. & Ors vs Eexpedise Technologies Pvt. Ltd. & Ors on 4 September, 2023

executed in the name of Plaintiff No. 1. Defendants launched a counterfeit software by the name of
'HealthIns' identical to 'HealthBuzz' software. After their clandestine acts were exposed, Defendants
who were employees of the Plaintiffs, abruptly resigned in a short span with almost similarly worded
resignation letters.
(g) The cyber forensic report rendered by Pinkerton Consulting and Investigation Incorporation
revealed that Defendant employees were using laptops to communicate with clients using eExpedise
domain/email address. Laptops contained details of Defendant No. 1's businesses such as
agreements, invoices and were in fact connected to the network of Defendant No. 1.
(h) Based on the report, FIRs were lodged against the Defendant employees under Sections 120-B,
408 and 420 IPC pursuant to which Defendants No. 8 and 10 were arrested and for seeking release
on bail they settled the matter by paying some money to the Plaintiffs. Despite the Ad-Hoc
Agreement of settlement, they are continuing to breach the terms of the settlement as also infringing
the copyrighted source code with impunity. Plaintiffs engaged 'KPMG' for conducting a This is a
digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46
software code and architectural comparison of 'HealthBuzz' and 'HealthIns' and its report
conclusively establishes that 'HealthIns' is a counterfeit software.
(i) Defendant employees are also bound by the terms of their employment agreements to preserve
confidentiality and integrity of Plaintiffs' property including intellectual property as incorporated in
Clause 7 (vi) and (vii) in case of Defendant No. 6 and Defendant No. 4, as an illustration.
(j) Defendants erroneously contend that source code of 'HealthBuzz' amounts to 'tacit knowledge'
and Plaintiffs cannot legally restrain their former employees from using this tacit knowledge/skill
acquired by Defendants in course of and as a result of their employment with the Plaintiffs. Source
code, which is the heart and soul of a computer programme, is subject of statutory protection and
not 'tacit knowledge'. It is a machine-readable instruction to a computer programme in a
programming language.
(k) Similarly, contention of the Defendants that 'HealthIns' being a derivative work is immune to
allegations of infringement is misplaced. By taking this defence, Defendants admit to the use of
Plaintiffs' source code and even otherwise, law draws a distinction between a copy and a derivative
work. KPMG's report demonstrates a substantial match in the two source codes which is unrebutted
and moreover 'HealthIns' is not a derivative work but a substantial copy of 'HealthBuzz'.
(l) The argument of lack of privity of the Defendants to the contracts between Plaintiffs and their
clients, is wholly misconceived. Plaintiffs have only licensed their software and not assigned the
same to the clients to deal with them in any This is a digitally signed order.Eicore Technologies Pvt. Ltd. & Ors vs Eexpedise Technologies Pvt. Ltd. & Ors on 4 September, 2023

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46
manner. The license unlike a sale is limited to not allowing the clients any free reign to let a third
party access Plaintiffs' source code and deal with it in any manner whatsoever.
(m) There is no merit in the argument that servicing the 'HealthBuzz' software does not amount to
infringement. Servicing is a compendious term where, in the name of servicing, Defendants are
accessing, using, modifying and altering the most confidential and proprietary element of Plaintiffs'
software i.e. source code. In fact, documents on record indicate that Defendants have gone to the
extent of creating a software 'HealthIns' which was offered as a replacement to Plaintiffs'
'HealthBuzz'.
(n) Defendants have given undertaking to the Court that they shall not print, publish, reproduce,
copy or plagiarize or otherwise deal in any manner with the software 'HealthBuzz', but this
undertaking is not protecting the source code, which is continuously being infringed by the
Defendants and therefore, there is a need to injunct them from infringing the source code of the
'HealthBuzz' software.
8. Pithily put, contentions on behalf of Defendants No. 1 to 7 and 12 to 19 are as follows:-
(a) Present suit has been filed on account of personal vendetta of the Plaintiffs
against their ex-employees in order to hinder the expansion of their business.
Disputes were amicably settled by entering into an 'Ad-Hoc Agreement' followed by
'Custodial' and 'Addendum' Agreements. Defendants have given an undertaking to
this Court on 28.09.2018, that they have not sold or commercially dealt with the
software 'HealthIns' and also shall not deal with the same as also that This is a
digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46
they will not represent themselves as agents of the Plaintiffs to any third party. It was also
undertaken that Defendants shall not print, publish, reproduce, copy, plagiarize or otherwise deal in
any manner with the software 'HealthBuzz'. There is no breach of the undertaking and assuming
there is any, the remedy is a contempt petition.
(b) Plaintiffs have signed Master Service Agreements (MSAs) with each of their clients stating that
all intellectual property and materials including source codes, belong to the clients. Agreements
contain no stipulation that servicing of the software would be done by the Plaintiffs only and thus, it
is clear that clients can get the software serviced from any third party including the Defendants. In
any case, breach of the Agreement is by the third party clients and not by the Defendants who are
not party to the said Agreements. In fact, Plaintiffs have admittedly instituted arbitration
proceedings against one of the clients ABHICL.Eicore Technologies Pvt. Ltd. & Ors vs Eexpedise Technologies Pvt. Ltd. & Ors on 4 September, 2023

(c) The Ad-hoc Agreement signed between the parties contained a stipulation that Defendants
would pay a sum of Rs.3.5 crores to Plaintiffs and one of the conditions in the Addendum
Agreement was that once half the amount is paid, Plaintiffs would withdraw all pending cases
against the Defendants. It is thus an obligation on the Plaintiffs to withdraw the present suit once
the money has been received. It is not open to a party to a contract to rescind the same unilaterally
once the obligation to perform its duties have been triggered as the other party has complied with
the terms of the contract.
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46
(d) Similarity in the source codes of the rival parties cannot be determined at this interlocutory stage
and is a matter of trial, particularly, when the Defendants contest the accuracy and legitimacy of the
KPMG report dated 22.08.2018 and Pinkerton report dated 18.09.2017. In any case, the reports do
not deal with the aspect of servicing of the software 'HealthBuzz' by the Defendants, which is one of
the allegations by the Plaintiffs.
(e) Defendants have taken a categorical position that they have not copied the source code of the
Plaintiffs' software and have developed their own software with their own skill and expertise and
have also filed for copyright registration of the software 'HealthIns', in which no objection has been
raised by the Plaintiffs. In American Express Bank, Ltd. v. Ms. Priya Puri, 2006 SCC OnLine Del
638, this Court has held that a competitor cannot be restrained from conducting his business under
the garb of confidentiality.
(f) There are no pleadings regarding servicing of the software 'HealthBuzz' by the Defendants, either
in the plaint or in the present application. Present suit falls under the Commercial Courts Act, 2015,
which mandates a party to plead the facts and circumstances necessary for adjudication of the
disputes set out in the plaint. Therefore, no relief can be sought on this count by the Plaintiffs. The
allegations of the Plaintiffs that Defendants are servicing the software 'HealthBuzz' for their clients
and/or third parties has been deliberately confused with the argument of source code as there are no
separate pleadings on that aspect. There are no averments or details of the types of servicing done,
number of This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46
ways in which 'HealthBuzz' can be serviced etc. In Bachhaj Nahar v. Nilima Mandal & Ors., (2008)
17 SCC 491, Supreme Court has held that party cannot be allowed to argue beyond pleadings.
(g) Defendants reiterate that their undertaking as regards 'HealthIns' given on 28.09.2018 be made
absolute till the final disposal of the suit but beyond the said relief no injunction ought to be granted
as Plaintiffs have failed to make out a case which falls within the trinity principles for grant of
interim injunction i.e. prima facie case, balance of convenience and irreparable harm and injury.Eicore Technologies Pvt. Ltd. & Ors vs Eexpedise Technologies Pvt. Ltd. & Ors on 4 September, 2023

9. I have heard learned Senior Counsels for the Plaintiffs and Defendants No. 1 to 7 and 12 to 19 as
well as counsel for the remaining Defendants and examined their respective contentions.
10. From a reading of the prayers in the present application, which are captured in the earlier part of
this order, it is evident that multifarious reliefs have been sought by the Plaintiffs. On 28.09.2018,
when summons were issued in the suit, Defendants entered appearance and gave certain
undertakings/assurances to the Court. Relevant part of the order dated 28.09.2018 is as follows:-
"4. After some arguments, learned senior counsel for the defendant on instructions
states that defendants have not sold or commercially dealt with the software
HealthIns and also shall not deal with the same till the next date of hearing. He
further submits that the defendants will not represent themselves as an agent of the
plaintiffs to any third party.
5. At this stage, learned senior counsel for the plaintiff has, however, submitted that
the defendants are illegally trying to provide service to some of the clients of the
plaintiff who are using the software HealthBuzz. He submits that the defendants
cannot be permitted to service the said software HealthBuzz as in the License
Agreement entered into by the plaintiffs with its customer the right to carry on
servicing of the said software lies exclusively with the plaintiff.
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal
by scanning the QR code shown above. The Order is downloaded from the DHC
Server on 16/09/2023 at 16:14:46
6. This plea of the plaintiffs would be gone into on the next date of hearing.
xxx xxx xxx xxx
9. At this stage, learned senior counsel for the plaintiff submits that this court should
pass an order at least in terms of prayer (a) of the application. Learned senior counsel
for the defendant, however, submits that the defendant does not have any
confidential data or trade secrets of the plaintiff. He also submits that the defendants
are not printing, publishing, reproducing, copying or plagiarizing or otherwise
dealing in any manner with the software "Health Buzz".
10. The statement of defendants is taken on record and they shall be bound by the same."
11. In the instant suit, Plaintiffs allege infringement of copyright in their original 'literary work'
'HealthBuzz', a computer programme within the meaning of Section 51 of the 1957 Act. It is also
their case that in the course of their employment with Plaintiffs No. 1 to 4, Defendant employees,
had complete access to Plaintiffs' software 'HealthBuzz', its source code and all other confidentialEicore Technologies Pvt. Ltd. & Ors vs Eexpedise Technologies Pvt. Ltd. & Ors on 4 September, 2023

data, information and trade secrets, each of which have been misused by the Defendants. Several
incidences have been cited in support of the submissions and some communications between
Plaintiffs' clients and the Defendants as well as inter se the Defendants have been relied on. In a
nutshell, case of the Plaintiffs is that the computer programme/software 'HealthBuzz' and its source
code is the exclusive copyrighted property of the Plaintiffs, designed as an all- encompassing
premier health insurance system, licensed to various insurance companies in India and abroad and
the Defendants have infringed the said copyright. It is also alleged that Defendant employees during
their employment incorporated Defendants No. 1 to 3 and having access to the source code and
other confidential data and trade secrets, they have been providing services to third parties as well
to Plaintiffs' clients, with whom Plaintiffs have service agreements and are continuing to do so in
breach of confidentiality principle.
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46
12. Defendants, on the other hand, urge that they have devised their own software. Access to the
source code of the Plaintiffs' software is denied and on the aspect of servicing the softwares of
Plaintiffs' clients, the stand is that Plaintiffs have transferred all rights pertaining to the service
works in favour of the respective clients, including intellectual property rights and cannot restrain
the Defendants, if the clients engage the Defendants for servicing. Even otherwise in law, there
cannot be a restraint against trade by virtue of Section 27 of the Indian Contract Act, 1872.
Defendants have also heavily relied on the Settlement arrived between the parties and the 3
Agreements executed in furtherance thereof, which according to them, puts an end and quietus to all
the disputes between the parties to the lis.
13. On 28.09.2018, Defendants had given certain assurances and undertakings to this Court, as
aforementioned, which prima facie satisfy some of the reliefs sought by the Plaintiffs in the present
application. In this backdrop, three broad issues arise for consideration in the present application:
(a) infringement of copyright in the source code of Plaintiffs' software 'HealthBuzz'; (b) servicing of
the software 'HealthBuzz' for Plaintiffs' clients with whom Plaintiffs have entered into
license/Master Service Agreements; and (c) effect of the Ad-hoc Agreement, Custodial Agreement
and Addendum Agreement executed between the parties pursuant to the settlements between the
parties.
14. Insofar as the three Agreements i.e. Ad-hoc/Custodial/ Addendum are concerned, it is true that
parties settled the disputes, which form part of the agreements and a total sum of Rs.3,50,00,000/-
was payable to the Plaintiffs by way of 13 instalments by the end of the year 2020. It is equally
undisputed that instalments have been received by the Plaintiffs from time to time. Plaintiffs,
however, state This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46Eicore Technologies Pvt. Ltd. & Ors vs Eexpedise Technologies Pvt. Ltd. & Ors on 4 September, 2023

that the Settlement Agreements do not come to the rescue of the Defendants since they are
continuing with the infringing and other illegal activities, which compelled the Plaintiffs to file the
present suit. Plaintiffs have averred and placed on record documents, which according to them,
indicate that Defendants are persisting in infringing the copyright in the source code and providing
services to third parties, including their clients, with whom they have service agreements. It is also
the stand of the Plaintiffs that the three agreements did not permit the Defendants to use their
copyrighted computer programme/source code and/or confidential data and they cannot be
estopped from enforcing the said rights. Plaintiffs have also cited incidences, which as per them,
amount to breach of Settlement Agreements as well as give rise to fresh cause of action because of
infringing and other illegal activities of the Defendants, post the settlement.
15. In my view, Plaintiffs are right in their submissions that settlement of the disputes at the time
when FIRs were registered against the Defendants did not amount to giving up the copyright owned
by the Plaintiffs in the computer programme/software HealthBuzz, which was and continues to be
the intellectual property of the Plaintiffs. Further, the terms of the settlement did not give a license
to the Defendants to infringe the copyright in the source code of the software 'HealthBuzz' or take
away the right of the Plaintiffs to enforce the copyright and/or take action against the alleged theft
and misuse of confidential data and trade secrets, in the garb of Settlement Agreements, if Plaintiffs
are able to substantiate and establish the same. Therefore, at this stage, this Court is unable to agree
with the Defendants that the Settlement Agreements have put a quietus to the This is a digitally
signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46
litigation of infringement of copyright etc. and on this ground, the suit and the present application
deserve to be dismissed.
16. Coming to the copyrighted 'source code' of the computer programme 'HealthBuzz, which is the
sheet anchor of Plaintiffs' case, as understood from the available literature, a computer 'source code'
is defined as a series of statements written in some human readable computer programming
language constituting several text files and is a piece of computer software. In order to make a
computer perform its functions, it has to be appropriately instructed. The machine language that is
fed into the computer, in the form of instructions is called the computer language. The instructions
or the programming given to a computer in a language known is called 'source code' in computer
parlance and every computer functions with a separate source code. Source code is always protected
and guarded by the computer companies and it has been held in several judgments that if a source
code is copied, it would certainly violate the copyright of the developer. Section 14(b) of the 1957 Act
provides as follows:-
"14. Meaning of copyright.
xxxx xxxx xxxx xxxx
(b) in the case of a computer programme:Eicore Technologies Pvt. Ltd. & Ors vs Eexpedise Technologies Pvt. Ltd. & Ors on 4 September, 2023

(i) to do any of the acts specified in clause (a);
(ii) to sell or give on commercial rental or offer for sale or for commercial rental any
copy of the computer programme:
Provided that such commercial rental does not apply in respect of computer
programmes where the programme itself is not the essential object of the rental."
17. From a reading of Sections 2(o), 2(ffb) and 2(ffc) along with Sections 13 and 14 of the 1957 Act, it
is clear that a computer programme is a 'literary work' and if a person alters the computer
programme of another person or entity, the same amounts to infringement of copyright. The
question that arises is whether the This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46
Court can, at this stage, arrive at a prima facie finding of infringement of copyright in a source code.
18. In support of the allegation of infringement of copyright in the source code, Plaintiffs have
placed on record two reports. The first report is from Pinkerton which conducted a cyber forensic
analysis of the hard drives of the laptops issued to the Defendant employees and the second report is
from KPMG which was engaged by Plaintiffs for conducting a software code and architectural
comparison of the two softwares i.e. 'HealthBuzz' and 'HealthIns'. Both reports have been filed by
the Plaintiffs before this Court. Pinkerton report shows that M/s Pinkerton was tasked by the
Plaintiffs to conduct Cyber Forensic Analysis on the hard drives of the laptops issued to the
employees mentioned in the report and deals with certain communications pertaining to
Defendants' agreements, contracts, business communications, including some confidential
information of the Plaintiffs' companies etc. The report has no relevance to the comparison of the
source codes of the parties. Insofar as the KPMG report is concerned, the letter dated 22.08.2018, by
which the agency was engaged by the Plaintiffs, itself shows that amongst other tasks assigned to the
said agency, one of them was to conduct a source code line matching etc. to assess similarities in the
source code of the Plaintiffs' software 'HealthBuzz' and the 'alleged copied software of the target' and
to conduct a high-level architecture comparison of the two. In paragraph 5 of the letter, it is
stipulated that the Plaintiffs were to provide to the agency: (a) functionality and architecture of
HealthBuzz; (b) source code of the application modules to be compared for HealthBuzz and the
alleged copied software solution of the 'target'; and (c) any other document, as deemed necessary. It
is, therefore, uncertain as to what source code was actually provided by This is a digitally signed
order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46
the Plaintiffs to KPMG for comparison and assessment of similarities. The report is a self-serving
document of the Plaintiffs and having given thoughtful consideration, I am of the opinion that this
issue can only be resolved after both parties submit their respective source codes to the Court and
they are sent for examination to an independent and impartial expert in the field.Eicore Technologies Pvt. Ltd. & Ors vs Eexpedise Technologies Pvt. Ltd. & Ors on 4 September, 2023

19. Courts have taken the help and assistance of an expert opinion for a comparison of the source
codes. In Campus Eai India Pvt. Ltd. v. Neeraj Tiwari & Others, CS(OS) 482/2016, one of the issues
the Court was in seisin was infringement of copyright of the source code of Plaintiff's software, while
deciding an application for interim injunction. Allegations were levelled by the Plaintiff that
Defendant No. 1 at the time of institution of the suit was an employee of the Plaintiff, while
Defendants No. 2 to 4 were ex-employees and had stolen the Plaintiff's copyright, trade secret,
technical proprietary, confidential information and intellectual property in respect of 'QuickLaunch
SSO', a cloud based self-service software from Plaintiff's computers, as well as data bases and
development and repositories sites. In order to decide if there was any similarity in the two
softwares and/or infringement of copyright, the Court directed all the concerned parties to submit
their respective source codes in a sealed envelope to an independent expert i.e. Director, IIT Delhi
for evaluation, before coming to any conclusion albeit prima facie on the infringement of a source
code. It would also be useful to rely on a judgment of the Division Bench of the Gujarat High Court
in Sarine Technologies Ltd. v. Diyora and Bhanderi Corporation & 13, 2017 SCC OnLine Guj 2200,
where the challenge before the Division Bench was to an order passed by the learned Judge,
Commercial Court refusing to grant injunction, observing that Plaintiff had miserably This is a
digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46
failed to prove that the source code or the object code of Plaintiff's and Defendants' softwares were
the same or that the Defendants had copied the source code or the object code of the Plaintiff. The
Division Bench set aside the order on the ground that whether or not the source/object codes are the
same or have been copied by the Defendants, would go to the root of the matter and thus the source
codes are required to be compared by calling upon both parties to provide their respective
source/object codes, which would then be sent to any impartial and independent expert for
comparison. The matter was remanded back to the learned Single Judge for deciding the application
afresh, after calling upon the parties to provide their respective codes and seek a report on the same
from an independent expert. Relevant paragraphs are as follows:-
"12. Having heard learned Counsel appearing for respective parties and considering
the impugned order and the reasoning given by the learned Judge it appears that
while refusing to grant injunction as prayed for, the learned Single Judge has
observed and held that the plaintiff has failed to prove that the source code and
object code of the plaintiff has been copied. While refusing to grant the injunction as
prayed and while considering the prima facie case, balance of convenience and
irreparable loss, the learned Judge, Commercial Court has observed and held that in
the present case the plaintiff has miserably failed to prove that the source code or the
object code of the plaintiff's software and defendants' software are same or the
defendants have copied the source code or the object code of the plaintiffs. However,
it is required to be noted that even according to the defendants also the source code
and the object code of the defendants' software are secret and these cannot be
revealed to anybody without the order of the Court. At this stage it is required to be
noted that even the defendants also declared before the Court that the defendants areEicore Technologies Pvt. Ltd. & Ors vs Eexpedise Technologies Pvt. Ltd. & Ors on 4 September, 2023

ready to provide the source code and object code to the Court and the Court may send
the same to any impartial and independent expert for comparison with the source
code and object code of the plaintiff. The same is reflected from observations made in
para 18 of the impugned order. Therefore, the learned Judge, Commercial Court has
not properly appreciated the fact that if the source code and the object code of the
defendants' software are the secret and the same shall be within the exclusive domain
and custody of the defendants, in that case, the plaintiff would not have any access to
the source code and object code of the defendants' This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal
by scanning the QR code shown above. The Order is downloaded from the DHC
Server on 16/09/2023 at 16:14:46 software. Therefore and even when the defendants
were ready to provide the source code and the object code to the Court so that Court
may send to any impartial and independent expert for comparison with the source
code and the object code of the plaintiff, we are of the opinion that the learned Judge
ought to have called upon the defendants to provide their source code and object
code of their software which could have been sent to an impartial and independent
expert for comparison with the source code and object code of the plaintiff.
Therefore, we are of the opinion that without undertaking the aforesaid exercise the
learned Judge has materially erred in refusing to grant the injunction on the ground
that the plaintiff has failed to prove that the source code or the object code of the
plaintiff's software and the defendants' software are same or the defendants have
copied the source code or the object code of the plaintiffs. The learned Judge has not
properly appreciated the fact that when the source code and the object code of the
defendants' software is within exclusive domain and custody of the defendants as the
same being secret, the plaintiff could not have any access to the same to prove that
the source code or the object code of the plaintiff's software and the defendants'
software are same or the defendants have copied the source code or the object code of
the plaintiff. At this stage it is required to be noted and as observed hereinabove even
the learned Counsel appearing on behalf of the defendants submitted before the
learned Judge, Commercial Court that the defendants are ready to provide the source
code and the object code to the Court and the Court may send the same to any
impartial and independent expert for comparison with the source code or the object
code of the plaintiff. If the aforesaid exercise would have been undertaken by the
learned Judge, Commercial Court while/before deciding the application Exh. 5, in
that case, the defence of the defendants could have been very well appreciated and/or
considered as according to the defendants they have developed their own software
and that they have not copied the software of the plaintiff. Therefore, we are of the
opinion that while/before deciding the application Exh. 5, the learned Judge,
Commercial Court ought to have undertaken the aforesaid exercise.
xxx xxx xxxEicore Technologies Pvt. Ltd. & Ors vs Eexpedise Technologies Pvt. Ltd. & Ors on 4 September, 2023

14. In any case as observed hereinabove whether the source code or the object code of
the plaintiff's software and the defendants' software are the same or not or the
defendants have copied the source code or the object code of the plaintiff's software
or not would go to the root of the matter. The source code or the object code of the
plaintiff's and defendants' software are required to be compared by calling upon both
of them to provide their respective source code and object code which can be send to
any impartial and independent expert for comparison. Therefore, We are of the
opinion that without further entering into the merits of the case and/or expressing
anything on merits, the matter is required to be remanded to the learned Judge,
Commercial Court for deciding the application This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal
by scanning the QR code shown above. The Order is downloaded from the DHC
Server on 16/09/2023 at 16:14:46 Exh. 5 afresh and after calling upon both, the
plaintiff and the defendants to provide their respective source code and object code to
the Court so that the same can be send to any impartial and independent expert for
comparison. On the aforesaid ground alone the impugned order passed by the
learned Judge, Commercial Court deserves to be quashed and set aside and the
matter is required to be remanded to the learned Judge, Commercial Court for
deciding the application Exh. 5 afresh and after undertaking the exercise as stated
hereinabove."
20. This Court is thus of the opinion that in order to arrive at a prima facie finding on the alleged
infringement of the copyright of the Plaintiffs in the source code of the software 'HealthBuzz',
parties must be called upon to provide their respective source codes so that the Court may send the
same to any impartial and independent expert for comparison. In the absence of this exercise, this
Court cannot proceed to give a finding one way or the other on infringement and it would be rather
unfair to both the parties, to do so.
21. The next and the only other plank of the argument of the Plaintiffs that needs consideration is
that Defendants are illegally servicing and maintaining the software 'HealthBuzz' installed by the
Plaintiffs for several clients, with whom they have service agreements. Plaintiffs' case is predicated
on the terms of the various license/Master Service Agreements, entered into and executed between
the Plaintiffs and their customers, under which they have exclusive rights to service the software.
Defendants, on the other hand, urge that there can be no agreement in restraint of trade by virtue of
Section 27 of Indian Contract Act, 1872 and secondly, the agreements between the Plaintiffs and
their clients evidence that the source codes in the service works are the intellectual property of the
respective clients and there is no legal bar for any third party to service the softwares, including the
Defendants. Both sides had taken the Court to numerous clauses in the service agreements placed
on record, some of which show vesting of This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46
intellectual property rights in the service work in favour of the clients while others point out to theEicore Technologies Pvt. Ltd. & Ors vs Eexpedise Technologies Pvt. Ltd. & Ors on 4 September, 2023

non-exclusive rights of the Plaintiffs in the service software/modules.
22. From the copious literature on the servicing and maintenance of softwares, available in public
domain, to this Court it appears that servicing/maintenance contracts of a software are of different
kinds, such as corrective maintenance, adaptive maintenance, perfective maintenance and
preventive maintenance. While some services/ maintenance mechanisms may require access to the
source code of the Plaintiffs as also modification thereof while others may relate strictly to the
service work code/modules requiring no intervention in the source code. Certainly, if while servicing
the softwares, Defendants are accessing the copyrighted source code of the Plaintiffs, it is an
infringement. However, the question that again begs an answer is whether this Court is today
adequately equipped to come to a finding that while servicing the softwares of third parties or the
clients of the Plaintiffs, Defendants are accessing the copyrighted source code of 'HealthBuzz' and
the answer is in the negative. In the absence of an expert opinion on the subject, Court does not have
the necessary material or the expertise to ascertain if the Defendants are accessing Plaintiffs' source
code while servicing the softwares of third parties and/or Plaintiffs' clients. Additionally, several
related and significant questions also arise viz. (a) whether Defendants have access to the source
code of the Plaintiffs; (b) whether it is impossible to service the third party softwares without access,
use and modification of Plaintiffs' copyrighted source code; and (c) scope of work of servicing
assignments and the modules/codes used, which may also require reference for an expert opinion.
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46
23. Judicial precedents show that Courts have been appointing independent and impartial experts
to examine and compare the source codes and also render opinion on related issues, before taking a
decision on grant of injunction, one way or the other, as these are matters which are highly
technical, requiring expert domain knowledge. When the application was heard, parties had not
addressed arguments on this aspect of the matter and any decision in the absence of an expert
opinion of an independent person/body would be unfair to the losing party. Therefore, to be fair to
both sides, this Court deems it appropriate to list the application for further consideration on this
aspect of the matter.
24. Accordingly, the matter is released by this Court to be listed before the Roster Bench on
11.09.2023, subject to orders of Hon'ble Judge-In-Charge (Original Side). The
undertakings/assurances given by the Defendants to the Court on 28.09.2018 shall continue to
operate, in view of Defendants having candidly given their consent to the same.
JYOTI SINGH, J SEPTEMBER 04, 2023/shivam/kks This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 16/09/2023 at 16:14:46Eicore Technologies Pvt. Ltd. & Ors vs Eexpedise Technologies Pvt. Ltd. & Ors on 4 September, 2023

