Esakki Subbiah Dass vs State Of Tamil Nadu on 20 November,
2023
Author: M.Sundar
Bench: M.Sundar
    2023/MHC/5148
                                                                             HCP(MD)No.828 of 2023
                          BEFORE THE MADURAI BENCH OF MADRAS HIGH COURT
                                                DATED: 20.11.2023
                                                       CORAM:
                                    THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                         and
                                  THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                            H.C.P.(MD)No.828 of 2023
                     Esakki Subbiah Dass                                            : Petitioner
                                                         Vs.
                     1.State of Tamil Nadu,
                       Rep. by the Additional Chief Secretary to Government,
                       Home, Prohibition and Excise Department,
                       Secretariat, Chennai – 600 009.
                     2.The Commissioner of Police,
                       Tirunelveli City,
                       Tirunelveli.
                     3.The Superintendent of Prison,
                       Central Prison,
                       Palayamkottai, Tirunelveli.                             : Respondents
                     PRAYER: Petition filed under Article 226 of the Constitution of India to
                     issue a writ of Habeas Corpus, calling for the entire records connected with
                     the detention order passed in No.24/BCDFTISSSV/2023 dated 17.04.2023
                     Page 1 of 24Esakki Subbiah Dass vs State Of Tamil Nadu on 20 November, 2023

https://www.mhc.tn.gov.in/judis
                                                                                    HCP(MD)No.828 of 2023
                     on the file of the 2nd respondent herein and quash the same and direct the
                     respondents to produce the detenu or body of the detenu namely Esakki
                     Subbiah Dass, aged about 24 years, S/o.Nellaiappan, now detained at the
                     Central Prison, Palayamkottai before this Hon'ble Court and set him at
                     liberty forthwith.
                                             For Petitioner    : Mr.N.Pragalathan
                                             For Respondents : Mr.A.Thiruvadi Kumar
                                                                Additional Public Prosecutor
                                                          ORDER
[Order of the Court was made by M.SUNDAR, J.] Captioned 'Habeas Corpus Petition' ['HCP' for the
sake of brevity] was listed in the Admission Board on 10.07.2023 before Hon'ble Coordinate
Division Bench and the following order was made:
https://www.mhc.tn.gov.in/judis
2. Therefore, in this final order, it has become necessary to set out factual matrix in a nutshell.
3. Captioned HCP has been filed by the detenu assailing a 'preventive detention order dated
17.04.2023 bearing No. 24/BCDFGISSSV/2023' [hereinafter 'impugned preventive detention order'
for the sake of brevity and convenience]. To be noted, sponsoring authority has not been arrayed as
a respondent but we find that 'Station House Officer of Tirunelveli Junction Police Station' is the
sponsoring authority [hereinafter 'Sponsoring Authority' for the sake of convenience and clarity]
and second respondent is the detaining authority as impugned preventive detention order has been
made by second respondent.
4. Impugned preventive detention order has been made under 'The Tamil Nadu Prevention of
Dangerous Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-offenders,
Goondas, Immoral traffic offenders, Sand-offenders, Sexual-offenders, Slum-grabbers and Video
Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake of
convenience and clarity] on the premise that the detenu is a 'Goonda' within the meaning of Section
2(f) of Act 14 of 1982. https://www.mhc.tn.gov.in/judis
5. There is no adverse case. The ground case which constitutes sole substratum of the impugned
preventive detention order is Crime No.79 of 2023 on the file of Tirunelveli Junction Police Station
registered under Sections 341, 294(b), 324, 307 and 506(ii) of 'The Indian Penal Code (45 of 1860)'
[hereinafter 'IPC' for the sake of convenience and clarity] which was subsequently, altered intoEsakki Subbiah Dass vs State Of Tamil Nadu on 20 November, 2023

Sections 341, 294(b), 324, 307 and 506(ii) IPC and Sections 3(1)(r), 3(1)(s) and 3(2)(v) of 'Schedule
Caste and Scheduled Tribes (Prevention of Atrocities) Amendment Act, 2015' [hereinafter 'SC/ST
PoA Act' for the sake of convenience and clarity] and later altered into Sections 341, 294(b), 324,
307, 506(ii), 147, 148 and 120(B) of IPC and Sections 3(1)(r), 3(1)(s) and 3(2)(v) of SC/ST PoA Act.
Considering the nature of the challenge to the impugned preventive detention order, it is not
necessary to delve into the factual matrix of the case.
6. Mr.N.Pragalathan, learned counsel on record for HCP petitioner and Mr.A.Thiruvadi Kumar,
learned State Additional Public Prosecutor for all respondents are before us.
https://www.mhc.tn.gov.in/judis
7. When the captioned HCP was in the final hearing board in 16.10.2023 listing, the following
proceedings were made:
'Mr.N.Pragalathan, learned counsel for HCP petitioner commenced his submission
by saying that subjective satisfaction arrived at by the Detaining Authority is
impaired, as the detenu has not moved any bail application in the solitary case, which
constitutes the substratum of the impugned preventive detention order. Learned
counsel submitted that without any statement from any relative and/or any special
report from the Sponsoring Authority such subjective satisfaction has been recorded.
2. Learned Additional Public Prosecutor submitted that post Rekha's case (Rekha Vs.
State of Tamil Nadu reported in (2011) 5 SCC 244) there have been two other
judgments rendered by Hon'ble Supreme Court and wanted to make submissions.
3. List on 30.10.2023.'
8. However, today, Mr.N.Pragalathan, learned counsel for HCP petitioner changed
his line of attack and submitted that impugned preventive detention order does not
pass muster qua acting in any manner prejudicial to the maintenance of public order.
In other words, it is the pointed argument of learned counsel for HCP petitioner that
there is nothing to demonstrate that detenu in the case on hand has acted in any
manner https://www.mhc.tn.gov.in/judis prejudicial to the maintenance of public
order. Learned counsel emphasised that impugned preventive detention order in the
captioned HCP has been made on the basis of a solitary case. To put it differently one
solitary case constitutes the substratum of the impugned preventive detention order
is learned counsel's say.
9. In response to the public order point, learned Additional Public Prosecutor drew
our attention of this Court to the following portion of the grounds of impugned
preventive detention order in sub-paragraph (i) of paragraph 2 thereat. This portion
of paragraph 2(i) of grounds of impugned preventive detention order reads as
follows:Esakki Subbiah Dass vs State Of Tamil Nadu on 20 November, 2023

'.........On seeing this, those who were in the houses of that street closed their house
doors hastily out of fear. Those who were going by that street scattered and ran
towards all the four directions......'
10. Learned Additional Public Prosecutor submitted that the aforementioned two
sentences in the grounds of impugned preventive detention order are good enough to
demonstrate that the detenu has acted in a manner prejudicial to maintenance of
public order.
https://www.mhc.tn.gov.in/judis
11. Learned counsel for HCP petitioner responding to the above argument pressed into service
V.Kalaiselvi Thangam's case [V.Kalaiselvi Thangam Vs. The Additional Chief Secretary to
Government and two others] reported in 2023/MHC/5092 [H.C.P.(MD)No.1008 of 2023, dated
01.11.2023]. A scanned reproduction of Kalaiselvi Thangam's case as reported in Nuetral Website
portal of this Court is as follows:
https://www.mhc.tn.gov.in/judis https://www.mhc.tn.gov.in/judis
https://www.mhc.tn.gov.in/judis https://www.mhc.tn.gov.in/judis
https://www.mhc.tn.gov.in/judis https://www.mhc.tn.gov.in/judis
https://www.mhc.tn.gov.in/judis https://www.mhc.tn.gov.in/judis
https://www.mhc.tn.gov.in/judis https://www.mhc.tn.gov.in/judis
https://www.mhc.tn.gov.in/judis https://www.mhc.tn.gov.in/judis
https://www.mhc.tn.gov.in/judis https://www.mhc.tn.gov.in/judis
https://www.mhc.tn.gov.in/judis
12. We have carefully considered the rival submissions.
13. We find that in Kalaiselvi Thangam's case, there was only one sentence in the
grounds of impugned preventive detention order which says that 'On seeing this
incident those who were in the temple ran outside with hue and cry out of fear'. To be
noted, this is extracted and reproduced in paragraph 5 of Kalaiselvi Thangam's case.
In the case on hand, the aforementioned two sentences pointed out by learned
Additional Public Prosecutor find place in paragraph 2(i) of the grounds of impugned
preventive detention order. In all other aspects, Kalaiselvi Thangam's case and the
case on hand are clearly comparable. Therefore, applying Kalaiselvi Thangam's case
principle, we conclude that the impugned preventive detention order is liable to be
dislodged on the ground that it does not pass muster when it comes to the question as
to whether there is enough material to demonstrate that the detenu has acted in any
manner prejudicial to the maintenance of public order within the meaning of Section
2(a)(iii) of Act 14 of 1982.
https://www.mhc.tn.gov.in/judisEsakki Subbiah Dass vs State Of Tamil Nadu on 20 November, 2023

14. Ergo, the sequitur is, captioned HCP is allowed. Impugned preventive detention order dated
17.04.2023 bearing reference No. 24/BCDFGISSSV/2023 made by the second respondent is set
aside and the detenu Thiru.Esakki Subbiah Dass, male, aged 24 years, son of Thiru.Nellaiappan, is
directed to be set at liberty forthwith, if not required in connection with any other case / cases.
There shall be no order as to costs.
                                                                    [M.S.,J.] & [R.S.V.,J.]
                                                                          20.11.2023
                     Index             : Yes
                     Neutral Citation : Yes
                     vsm
                     Post Script:
(i) Registry to forthwith communicate this order to Jail authorities in Central Prison, Palayamkottai.
(ii)All concerned to act on this order being uploaded in official website of this Court without
insisting on certified copies. To be noted, this order when uploaded in official website of this Court
will be watermarked and will also have a QR code.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J.
and R.SAKTHIVEL, J.
vsm To
1.The Additional Chief Secretary to Government, Home, Prohibition and Excise Department,
Secretariat, Chennai – 600 009.
2.The Commissioner of Police, Tirunelveli City, Tirunelveli.
3.The Superintendent of Prison, Central Prison, Palayamkottai, Tirunelveli.
4.Joint Secretary to Government, Public (Law and Order) Department, Secretariat, Chennai.
5.The Additional Public Prosecutor, Madurai Bench of Madras High Court, Madurai.
20.11.2023 https://www.mhc.tn.gov.in/judisEsakki Subbiah Dass vs State Of Tamil Nadu on 20 November, 2023

