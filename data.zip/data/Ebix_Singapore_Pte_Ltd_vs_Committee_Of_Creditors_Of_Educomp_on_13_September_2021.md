Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp
... on 13 September, 2021
Equivalent citations: AIRONLINE 2021 SC 713
Author: D.Y. Chandrachud
Bench: M. R. Shah, Dhananjaya Y Chandrachud
                                                                       Reportable
                            IN THE SUPREME COURT OF INDIA
                             CIVIL APPELLATE JURISDICTION
                               Civil Appeal No. 3224 of 2020
          Ebix Singapore Private Limited                         .... Appellant
                                           Versus
          Committee of Creditors of Educomp                      .... Respondents
Solutions Limited & Anr.
                                          With
                               Civil Appeal No. 3560 of 2020
          Kundan Care Products Limited                           .... Appellant
                                           Versus
          Mr Amit Gupta and Ors.                                 .... Respondents
                                            With
                                Civil Appeal No. 295 of 2021
          Seroco Lighting Industries Private Limited             .... AppellantEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

                                           Versus
          Ravi Kapoor RP for Arya Filaments
                                                               .... Respondents
          Private Limtied & Ors.
Reason:
                                              JUDGMENT
Dr Dhananjaya Y Chandrachud, J
This judgment has been divided into sections to facilitate analysis. Further, a Glossary of defined
terms which have been used throughout the judgment has also been provided. The sections in the
judgment are as follows:
Glossary ............................................................................................................ 5 A Civil
Appeal No 3224 of 2020 – the Ebix Appeal ...................................... 11 A.1 The appeal
.......................................................................................... 11 A.2 Initiation of CIRP
................................................................................. 11 A.3 Invitation, submission and
approval of Resolution Plan...................... 12 A.4 Investigations into financial
transactions of Educomp ........................ 15 A.5 Applications for withdrawal of the
Resolution Plan ............................. 20 A.6 Orders of NCLT and NCLAT
............................................................... 24 A.7 Present status of SFIO and CBI
investigation ..................................... 28 B Civil Appeal No 3560 of 2020 – the
Kundan Care Appeal ........................ 29 B.1 The appeal
.......................................................................................... 29 B.2 Initiation of CIRP
................................................................................. 30 B.3 Invitation, submission and
approval of Resolution Plan...................... 31 B.4 Astonfield’s dispute with GUVNL
........................................................ 32 B.5 Withdrawal of the Resolution Plan
...................................................... 35 C Civil Appeal No 295 of 2021 – the Seroco
Appeal .................................... 43 C.1 The appeal
.......................................................................................... 43 C.2 Initiation of CIRP
................................................................................. 44 C.3 Submission and Approval ofEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Resolution Plan ..................................... 44 C.4 Modification of the Resolution Plan
..................................................... 45 D Submissions of counsel in the Ebix Appeal
.............................................. 48 D.1 Submissions for the appellant
............................................................. 48 D.2 Submissions for the first respondent
................................................... 56 D.3 Submissions for the second respondent
............................................. 64 E Submissions of counsel in the Kundan Care Appeal
................................ 68 E.1 Submissions for the appellant
............................................................. 68 E.2 Submissions for the first respondent
................................................... 76 E.3 Submissions for the second respondent
............................................. 78 F Submissions of counsel in the Seroco Appeal
.......................................... 80 F.1 Submissions for the appellant
............................................................. 80 F.2 Submissions for the second and third
respondents ............................ 82 G Purpose of a law on
insolvency.............................................................. 84 H Nature of a Resolution Plan
...................................................................... 90 I Statutory framework governing the
CIRP ................................................ 115 J Withdrawal of the Resolution Plan by a
successful Resolution Applicant under the IBC
................................................................................................ 134 J.1 The absence of a
legislative hook or a regulatory tether to enable a withdrawal
.................................................................................................. 134 J.2 Terms of the
Resolution Plan are not sufficient to effect withdrawals or modifications after its
submission to the Adjudicating Authority................. 145 K Factual Analysis
...................................................................................... 158 K.1 The Ebix Appeal
................................................................................ 158 K.1.1 Res Judicata
............................................................................... 159 K.1.2 Analysis of the Resolution
Plan of Ebix ...................................... 167 K.1.3 Duties of the RP
.......................................................................... 175 K.2 The Kundan Care Appeal
.................................................................. 179 K.3 The Seroco Appeal
........................................................................... 183 L
Conclusion............................................................................................... 185 Glossary
Defined Term Definition 2013 Act Companies Act 2013 Committee of Creditors of
Astonfield Renewables A-CoC Private Limited Adjudicating Authority National
Company Law Tribunal Committee of Creditors AMTEK Auto Limited Through
Amtek Auto Corporation Bank v. Dinkar T Venkatasubramanian & Ors.
Appellate Authority National Company Law Appellate Tribunal Company Appeal
(AT) (Insolvency) No 587 of 2020 - Approval Appeal filed by E-CoC before NCLAT
Approval Application CA No 195 (PB) of 2018 - filed by E-RP before NCLT Resolution
Professional for Astonfield Renewables A-RP Private Limited Arya Filaments Arya
Filaments Private Limited Committee of Creditors of Arya Filaments Private
Arya-CoC Limited Resolution Professional for Arya Filaments Private Arya-RP
Limited Astonfield Astonfield Renewables Private Limited Axis Axis Bank Limited
Axis Application IA No 448 (PB) of 2018 - filed by Axis before NCLT BLRC
Bankruptcy Law Reforms Committee Report of the Bankruptcy Law ReformsEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Committee, BLRC Report BSE Bombay Stock Exchange CBI Central Bureau of
Investigation CIRP Corporate Insolvency Resolution Proceedings IBBI (Insolvency
Resolution Process for Corporate CIRP Regulations Persons) Regulations, 2016
Contract Act Indian Contract Act 1872 Chhattisgarh State Electricity Board Gratuity
and CSEB Pension Trust and Chhattisgarh State Electricity Board Provident Fund
Trust CSEB Application CA No 160 (PB) of 2018 - filed by E-RP before NCLT Ebix
Ebix Singapore Private Limited Ebix Appeal Civil Appeal No 3224 of 2020 E-CoC
Committee of Creditors of Educomp Solutions Limited Educomp Educomp Solutions
Limited EMD Earnest Money Deposit EOI Expression of Interest E-RP Resolution
Professional for Educomp Solutions Limited CoC of Essar Steel India Ltd. v. Satish
Kumar Gupta & Essar Steel Ors.
EXIM Bank Export Import Bank of India First Withdrawal CA 1252 (PB) of 2019 in
CP (IB) No 101 (PB) of 2017 -
Application filed by Ebix before NCLT Ghanashyam Mishra and Sons Private Limited
through Ghanshyam Mishra & the Authorized Signatory v. Edelweiss Asset Sons
Reconstruction Company Limited through the Director & Ors.
Gujarat Urja Gujarat Urja Vikas Nigam Limited v. Amit Gupta & Ors.
GUVNL Gujarat Urja Vikas Nigam Limited Civil Appeal No 9241 of 2019 - filed by
GUVNL before GUVNL Appeal Supreme Court IBC Insolvency and Bankruptcy Code,
2016 IBBI Insolvency and Bankruptcy Board of India IFC International Finance
Corporation IFC Application CA No 358 of 2018 - filed by IFC before NCLT IM
Information Memorandum Investigation Audit CA No 793 (PB) of 2018 - filed by
E-RP before NCLT Application IRP Interim Resolution Professional Jaypee
Kensington Boulevard Apartments Welfare Jaypee Association & Ors. v. NBCC
(India) Ltd. & Ors.
     K Sashidhar        K Sashidhar v. IOC
        Kotak           Kotak Mahindra Bank
    Kundan Care         Kundan Care Products Limited
Kundan Care Appeal      Civil Appeal No 3560 of 2020
         LOI            Letter of IntentEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

                        Maharashtra Seamless v. Padmanabhan Venkatesh
Maharashtra Seamless
                        and Ors
        MCA             Ministry of Corporate Affairs
       MSME             Micro, Small and Medium Enterprise
       NCLAT            National Company Law Appellate Tribunal
       NCLT             National Company Law Tribunal
        NSE             National Stock Exchange
        PBG             Performance Bank Guarantee
       PFCL             Power Finance Corporation Limited
        PPA             Power Purchase Agreement
                        Recovery of Debts Due to Banks and Financial
Recovery of Debts Act
                        Institutions Act 1993
       RFRP             Request For Resolution Plan
       Rhino            Re Rhino Enterprises Properties Ltd. Schofield v Smith
         RP             Resolution ProfessionalEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Securitisation and Reconstruction of Financial Assets SARFAESI and Enforcement of
Security Interest Act 2002 SBI State Bank of India SBI Application CA No 639 (PB)
of 2018 - filed by SBI before NCLT Second Withdrawal CA 1310 (PB) of 2019 in CP
(IB) No 101 (PB) of 2017 -
   Application      filed by Ebix before NCLT
     Seroco         Seroco Lighting Industries Private Limited
  Seroco Appeal     Civil Appeal No 295 of 2021
      SFIO          Serious Frauds Investigation Office
      SICA          Sick Industrial Companies Act 1985
  Singapore Act     Companies (Amendment) Act 2017
  Swiss Ribbons     Swiss Ribbons (P) Ltd v. Union of India
Third Withdrawal CA No 1816 (PB) of 2019 in CP (IB) No 101 (PB) of Application
2017 - filed by Ebix before NCLT UBIL Union Bank of India Limited UK Act UK
Insolvency Act 1986 UNCITRAL Guide UNCITRAL Legislative Guide on Insolvency
Laws Uttara Foods Uttara Foods and Feeds (P) Ltd v. Mona Pharmachem Company
Appeal (AT) (Insolvency) No 203 of 2020 -
Withdrawal Appeal
                    filed by E-CoC before NCLATEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

                                                                           PART A
A       Civil Appeal No 3224 of 2020 – the Ebix Appeal
A.1     The appeal
1       This judgment arises out of an appeal from a judgment dated 29 July 2020
of the NCLAT. The NCLAT allowed the Withdrawal Appeal1 instituted by the first
respondent, E-CoC, under Section 61 of the IBC against a judgment dated 2 January
2020 of the NCLT at its Principal Bench in New Delhi.
2 The NCLT allowed the Third Withdrawal Application2 filed by Ebix under Section 60(5) of the IBC
to withdraw its Resolution Plan submitted for Educomp. While reversing that order, the NCLAT
held that the application to withdraw from the Resolution Plan could not have been allowed since:
(i) it was barred by res judicata; and (ii) the NCLT does not have jurisdiction to permit such a
withdrawal. The correctness of the view of the NCLAT comes up for determination in the present
appeal.
A.2     Initiation of CIRP
3       On 5 May 2017, Educomp filed a petition3 under Section 10 of the IBC
seeking to initiate voluntary CIRP. The NCLT admitted this petition on 30 May 2017, and appointed
an IRP. Hence, 30 May 2017 would be taken as the ‘Insolvency Commencement Date’ for the
purposes of Section 5(12) of the IBC. Company Appeal (AT) (Insolvency) No 203 of 2020 CA No
1816 (PB) of 2019 in CP (IB) No 101 (PB) of 2017 CP (IB) No 101 (PB) of 2017 PART A 4 E-CoC was
then constituted on 28 June 2017, following which it appointed Mr Mahender Kumar Khandelwal as
the RP for Educomp on 27 July 2017. This was confirmed by the NCLT on 12 September 2017. On 18
September 2017, the E-RP took over information, documents, reports and records pertaining to
Educomp from the IRP.
5 On an application4 of the E-RP, the NCLT by its order dated 13 November 2017 extended the
period of the CIRP by 90 days, beginning from 26 November 2017 till 24 February 2018.
A.3 Invitation, submission and approval of Resolution Plan 6 In terms of Section 25(2)(h) of the
IBC, the E-RP invited EOI on 18 October 2017 from prospective bidders, investors and lenders. 7 On
10 November 2017, the last date for submission of EOIs was extended to 17 November 2017.
Commencing from 5 December 2017, the E-RP provided access to the Virtual Data Room of
Educomp to prospective Resolution Applicants who had submitted a confidentiality undertaking
and made an upfront payment of Rs 5,00,000.Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

8 On 5 December 2017, the final RFRP was issued in accordance with Section 25(2)(h) of the IBC.
The last date for submission of the Resolution Plans was 8 January 2018. The RFRP was amended
on 17 January 2018 and 20 January 2018 to extend the last date for submission to 20 January 2018.
On 25 CA No 405(PB) of 2017 PART A January 20185, the NCLT again extended the last date for
submission of the Resolution Plans until 27 January 2018.
9 By the last date for submission, Resolutions Plans were received by the E- RP from Ebix and
another entity. These were shared with the E-CoC on 29 January 2018. Following this, both the
Applicants were invited to give their presentations to the E-CoC on 2 February 2018.
10 Ebix was declared as the successful Resolution Applicant by the E-CoC on 9 February 2018. Ebix
had discussions about its Resolution Plan with the E-CoC, and submitted a revised Resolution Plan
on 19 February 2018, with an addendum on 21 February 2018.
11 Upon the directions of the E-RP, the E-CoC commenced e-voting on the Ebix’s Resolution Plan at
7.00 pm on 21 February 2018. The voting lines were kept open till 7.00 pm on 22 February 2018.
According to the results of the e- voting, in terms of the voting share percentage: (i) 74.16 per cent
members of the E-CoC voted to approve the Resolution Plan; (ii) 17.29 per cent members voted to
reject the Resolution Plan; and (iii) the remaining members, having cumulatively 8.55 per cent
share, abstained from voting on the Resolution Plan. The Resolution Plan thus failed to achieve the
minimum percentage of 75 per cent, in accordance with Section 30(4) of the IBC (as it stood then).
12 A day later on 23 February 2018, one of the members of the E-CoC (CSEB) informed the E-RP by
an email that due to a technical error, they could not participate in the e-voting process. CSEB had a
voting share of 1.195 per In applications CA No 30 of 2018 and CA No 42 of 2018 PART A cent in the
E-CoC, and wanted its affirmative vote to be recorded on the Resolution Plan. CSEB’s vote would
enhance the voting share in favour of Ebix’s resolution plan to 75.35 per cent, thus meeting the
threshold under Section 30(4). 13 The E-RP filed the CSEB Application6 under Section 60(5) to seek
the directions of the NCLT in regard to CSEB’s late vote. NCLT by its order dated 28 February 2018,
directed the E-RP to file an application for approval of Ebix’s Resolution Plan under Section 30(6) of
the IBC, clarifying that the issue of CSEB’s vote would be taken up together with the application. On
7 March 2018, the E-RP filed the Approval Application7 seeking NCLT’s approval to Ebix’s
Resolution Plan under Section 30(6).
14 On 2 July 2018, Ebix issued a letter to the E-RP to expedite the CIRP for Educomp. The relevant
portions of the letter are extracted below:
“…we would like to submit that the resolution plan for the Company was submitted
with an expectation that the resolution process shall be completed in a time bound
manner, and the Resolution Applicant shall get the management control of the
Company before the start of new academic session in India i.e. April 2018, subject to
being selected as the successful applicant (as per the terms and conditions provided
in the resolution plan), and the approval of the plan by the NCLT. This would have
provided the Resolution Applicant with sufficient time to restructure the operations
of the Company.Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

As you are aware, the operations of the Company are already under stress and it
would be safe to assume that no new contracts / customers are coming up. Further,
the competitors of the Company may be trying to take undue advantage of the
situation, which may further erode the business value of the Company and may make
the revival process more difficult.
CA No 160 (PB) of 2018 CA No 195 (PB) of 2018 PART A The above negatively
impacts the commercial consideration provided by the Resolution Applicant in the
resolution plan submitted for the Company.
As per the clause 7 of the Resolution Plan dated February 19, 2018 submitted by the
Resolution Applicant, the terms of the resolution plan is valid for six months from the
date of the submission of the plan i.e. August 19th, 2018.
In light the above and fact that delay in completion of the resolution process is
negatively impacting the commercial consideration offered by the Resolution
Applicant in the resolution plan, we request you to ensure that the resolution process
is completed in a time bound manner. Otherwise, the Resolution Applicant will be
forced to re- consider or withdraw the resolution plan on expiry of the term of the
plan in order to protect the interest of all its stakeholders.” A.4 Investigations into
financial transactions of Educomp
15 On 3 April 2018, an Indian online news publication, The Wire, published an article titled “How
Educomp May Have Subverted the Spirit of India’s Insolvency and Bankruptcy Process”8. Another
article titled “Educomp’s Insolvency Process Becomes Murkier as Ebix Buys Smartclass Educational
Services” was published by The Wire on 26 April 20189.
16 The E-RP has stated before this Court that based on these reports, IFC, a financial creditor of
Educomp, filed the IFC Application10 under Section 60(5) of the IBC seeking investigation of the
affairs/transactions of Educomp. On 4 May 2018, when the IFC Application came up before the
NCLT, along with the CSEB Manoj Gairola, “How Educomp May Have Subverted the Spirit of
India’s Insolvency and Bankruptcy Process” (The Wire, 3 April 2018) available at
<https://thewire.in/business/how-educomp-may-have-subverted-the-spirit-of-
indias-insolvency-and-bankruptcy-process> accessed on 26 July 2021 Manoj Gairola, “Educomp’s
Insolvency Process Becomes Murkier as Ebix Buys Smartclass Educational Services” (The Wire, 26
April 2018) available at <https://thewire.in/business/educomps-insolvency-process-
becomes-murkier-as-ebix-buys-smartclass-educational-services> accessed on 26 July 2021 CA No
358 of 2018 PART A Application and the Approval Application, it directed the E-RP to file its reply
and also directed IFC to serve a notice on Ebix.
17 Similar applications- Axis Application11 and SBI Application12, under Section 60(5) of the IBC
read with Section 213 of the 2013 Act were filed by other financial creditors of Educomp, Axis Bank
and SBI, seeking ‘appropriate directions’ from the NCLT in view of the alleged irregularities in the
conduct of the affairs of Educomp.Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

18 In the meantime, on 1 August 2018, due to allegations of financial mismanagement of Educomp
between 2014-2018, the MCA directed an SFIO investigation13 into its affairs.
19 The NCLT, by its order dated 9 August 2018, dismissed the applications filed by IFC, Axis and
SBI and directed that: (i) the E-RP shall convene a meeting of the E-CoC within three days to discuss
the subject matter of the applications; and (ii) the E-RP and E-CoC could move an application
before NCLT according to law, if advised to do so by E-CoC.
20 Pursuant to NCLT’s order dated 9 August 2018, the E-CoC hosted its 13th meeting on 13 August
2018, and a resolution was passed with a 77.85 per cent vote to appoint an independent agency to
conduct a Special Investigation Audit into the affairs of Educomp. The relevant terms of the
resolution are as follows:
“RESOLVED THAT a special investigation audit on the affairs of the Company be
conducted by an independent agency, which shall be appointed by the Committee of
Creditors, for IA No 448 (PB) of 2018 CA No 639 (PB) of 2018 Order No
32/2018/SFIO/CL-II PART A period beginning from [1st January 2014] to [30th
January 2018] having following scope of work:
(i) All the matters/issues (approximate 21 in number) raised in the Annual Audit
Report of the Company for the Financial Year 2016-17 issued by Haribhakti & Co,
basis which adverse opinion has been issued;
(ii) Transactions involving alleged deliberate transfer of business between the
Company and SmartClass Educational Services Private Limited (“SESPL”) prior to
the commencement of the insolvency process of the Company;
(iii) Transactions regarding genuineness of receivables from Edusmart Services
Private Limited including cross-verification with payables to Educomp Solutions
Limited in the books of Edusmart Services Private Limited;
(iv) Transactions involving settlement between the Company, Educomp Learning
Hour Private Limited, Vidya Mandir Classes Limited and ICICI Bank Limited;
(v) Transactions relating to impairment with respect to investment made by the
Company in 4 of its subsidiaries;
(vi) Transaction relating to advance received by the Company from Educomp Raffles
Higher Education Limited;
(vii) Distribution agreement with Digital Learning Solution SDN BHD;
(viii) Transactions referred to in the applications filed by International Finance
Corporation, Axis Bank Limited and State Bank of India with the Hon’ble NationalEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Company Law Tribunal; and
(ix) Review of provisions against receivables done by Educomp Solutions Limited;
(x) All other transactions/points raised in the applications filed by Axis Bank, IFC
and SBI with Hon’ble NCLT;
(xi) Any other issue, which the Committee of Creditors may deem fit RESOLVED
FURTHER THAT the Resolution Professional, be and is hereby authorized by the
Committee of Creditors and directed to file appropriate application/petition with the
Hon’ble National Company Law Tribunal, inter alia, seeking consent/order of the
Hon’ble NCLT on the proposed special investigation audit to be conducted by the
independent agency.
PART A RESOLVED FURTHER THAT given the limitations inherent in the previous audits
conducted on the Company, and in order for the said investigation to be comprehensive, the
Resolution Professional, while filing such application/ petition, shall also, as an additional prayer,
seek consent/ order of the Hon’ble NCLT that SESPL, other group companies of the Company and
the erstwhile customers of the Company, be directed to cooperate with the independent agency so
appointed, or in the alternative, to refer the matter to the Central Government to appoint an
Inspector under the Companies Act, 2013 to conduct said investigation.
RESOLVED FURTHER THAT the entire cost of the proposed investigation (special investigation
audit), shall be included in CIRP Cost and accordingly be paid in terms of the provisions of the
Insolvency and Bankruptcy Code, 2016 and the relevant Regulations.
RESOLVED FURTHER THAT, the independent agency to conduct the special investigation audit,
shall be appointed by the Core Committee, comprising of SBI, IDBI Bank, Axis Bank, IFC, Yes Bank
and J&K Bank” 21 The resolution was placed before the NCLT on 20 August 2018, when it was
hearing the CSEB Application and the Approval Application. The NCLT directed the E-RP to file an
appropriate application. In accordance with the resolution dated 13 August 2018 and NCLT’s order
dated 20 August 2018, the E- RP filed the Investigation Audit Application14 under Section 60(5) of
the IBC seeking directions from NCLT to carry out the Special Investigation Audit of Educomp.
22 It is stated before us that the Investigation Audit Application was heard on 11 September 2018,
20 September 2018, 27 September 2018 and 4 October 2018. On 4 October 2018, while reserving its
order in the Investigation Audit Application, the NCLT also directed the E-RP to file an affidavit in
relation to the CA No 793 (PB) of 2018 PART A transactions carried out by Educomp under Sections
43, 45, 50 and 66 of the IBC.
23 The E-RP states that such an affidavit was filed, stating that on the basis of the books of account
and other relevant material pertaining to Educomp, no transactions which needed to be avoided
under Sections 43, 45, 50 and 66 of the IBC were found. The E-RP also stated that since the NLCT
had not issued specific directions for the conduct of a Special Investigation Audit, no such audit wasEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

conducted.
24 This affidavit was listed before the NCLT on 7 December 2018, along with the Approval
Application. On 10 January 2019, the NCLT reserved its orders on the Approval Application.
25 On 12 June 2019, Educomp made a regulatory disclosure to the BSE and NSE in relation to the
ongoing investigations being conducted by agencies such as SFIO and CBI. The material parts of the
disclosure read thus:
“This is with reference to your mail dated June 10, 2019, related to news appeared in
the "Business Standard"
captioned "Transactions of debt-ridden Educomp Solutions come under SFIO
scanner".
[…]
3. It is pertinent to note that BDO India LLP carried out transaction audit in order to ascertain if
there was any preferential, undervalued, extortionate or fraudulent transactions falling within the
ambit of Section 43, 45, 50 and 66 of the Code. The Transaction review report was prepared by BDO
India LLP in February 2018 which was further circulated and discussed with the CoC. On
examination of the BDO Report and other relevant material available with the Resolution
Professional during the CIRP period, no transaction was found by the Resolution Professional which
was required to be avoided in terms of the said Sections. Further, the two land transactions as
alleged in the Media PART A Report have not been reported by BDO in their Report and hence, the
Resolution Professional is not in a position to comment on the same.
As regards allegation in the Media Report that "Suspect transactions of debt-ridden Educomp
Solutions have come under the lens of Serious Fraud Investigation (SFIO), which is probing the
company for alleged fund-diversion and inflated land deals, we would like to clarify that SFIO
Investigation into the affairs of Educomp Solutions Limited is currently ongoing wherein the
Resolution Professional has been supplying the data/ information/ documents to them as and when
required however, no such information has been brought to the notice of the Resolution
Professional as yet. Moreover, the article appears to be based on a false, motivated, fabricated data.”
A.5 Applications for withdrawal of the Resolution Plan 26 On 5 July 2019, Ebix filed the First
Withdrawal Application15 under Section 60(5) of the IBC, for the following reliefs:
“i. Direct that the Ld. Resolution Professional supply a copy of the Special
Investigation Audit to the Resolution Applicant forthwith;
ii. Direct that the Ld. Resolution Professional supply a copy of the Certificates under
Sections 43, 45, SO and 66 of the Insolvency and Bankruptcy Code, 2016 to the
Resolution Professional forthwith;Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

iii. Withhold approval of the Resolution Plan sanctioned by the Committee of
Creditors of the Corporate Debtor, as filed before this Hon'ble Tribunal on
11.04.2018, pending detailed consideration of the same by the Resolution Applicant;
iv. Grant the Resolution Applicant sufficient time to re- evaluate its proposals
contained in the Resolution Plan, and also to suitably revise/modify and/or withdraw
its Resolution Plan;” (emphasis supplied) CA 1252 (PB) of 2019 in CP (IB) No 101
(PB) of 2017 PART A Ebix contends that the application was necessitated because: (i)
the Approval Application had been pending before the NCLT for 17 months, much
beyond the period envisaged in the RFRP and its Resolution Plan; (ii) Educomp’s
CIRP had been pending for 26 months, beyond the statutory period under the IBC;
(iii) the tenure of the government contracts awarded to Educomp, which was crucial
to its functioning, may have ended, leading to an erosion of its substratum; and (iv)
due to recent media reports, it had misgivings about the management and affairs of
Educomp.
27 On 10 July 2019, the NCLT dismissed the First Withdrawal Application with the following order:
“C.A. No. 1252(PB)/2019 This is an application filed by one Ebix Singapore Ptd.
Limited seeking re-valuation of the Resolution Plan submitted by it before the
Resolution Professional.
No ground for considering the prayer sought in the application is made out.
The application is dismissed as such.”
28 Thereafter, Ebix filed the Second Withdrawal Application16 under Section 60(5) of the IBC,
seeking the following reliefs:
“i. Allow the Resolution Applicant to withdraw the Resolution Plan dated 19.02.2018
(along with the Addendum/Financial Proposal dated 21.02.2019) submitted by it,
and as approved by the Committee of Creditors;
ii. Direct the Ld. Resolution Professional and/or Educomp Solutions Limited and the
Committee of Creditors to refund the Earnest Money Deposit of Rs. 2,00,00,000/-
furnished by the Resolution Applicant in respect of the Resolution Plan;
CA 1310 (PB) of 2019 in CP (IB) No 101 (PB) of 2017 PART A iii. Withhold approval
of the Resolution Plan sanctioned by the Committee of Creditors of the Corporate
Debtor, as filed before this Hon'ble Tribunal on 07.03.2018 and recorded vide order
dated 1.1.04.2018, pending detailed consideration of the same by the Resolution
Applicant;” While repeating the reasons mentioned in the First Withdrawal
Application, it provided a reason for filing the Second Withdrawal Application in the
following terms:Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

“xii. That the present Applicant had also filed an Application dated 05.07.2019
bearing PB/IA/1252/2019 under Section 60(5) of the Code, seeking
revision/revaluation of the Resolution Plan. However, the same was dismissed by this
Hon'ble Tribunal, and during the course of hearing in the said Application, this
Hon'ble Court put it to the Resolution Applicant to withdraw the Resolution Plan by
way of a separate Application. The present Application for withdrawal of the
Resolution Plan is being made in pursuance of the same.”
29 On 5 September 2019, the NCLT dismissed the Second Withdrawal Application with the
following order:
“C.A. No. 1310(PB)/2019 In para 'B (xii)' under the caption 'facts of the case', the
following averments have been made […] The italic portion of the aforesaid para
shows that the prayer for withdrawal of the Resolution Plan has been made inter alia
on the suggestion of the Court which is neither reflected in the order nor is born out
from any record. Such an averments imputing to the Court something which has
never been said is condemnable. The cause of action cannot be based on any such
things.
Accordingly, we dismiss this application with liberty to the applicant to file fresh one
on the same cause of action, if so advised.” PART A
30 Thereafter, Ebix filed the Third Withdrawal Application, seeking the following reliefs:
“i. Allow the Resolution Applicant to withdraw the Resolution Plan dated 19.02.2018
(along with the Addendum/Financial Proposal dated 21.02.2019) submitted by it,
and as approved by the Committee of Creditors;
ii. Direct the Ld. Resolution Professional and/or Educomp Solutions Limited and the
Committee of Creditors to refund the Earnest Money Deposit of Rs. 2,00,00,000/-
furnished by the Resolution Applicant in respect of the Resolution Plan;
iii. Withhold approval of the Resolution Plan sanctioned by the Committee of
Creditors of the Corporate Debtor, as filed before this Hon'ble Tribunal on
07.03.2018 and recorded vid order dated 11.04.2018, pending detailed consideration
of the same by the Resolution Applicant;” The earlier applications for withdrawal
were referred to:
“xiv. It may be noted that, the present Applicant had also filed an Application dated
05.07.2019 bearing PB/IA/1252/2019 under Section 60(5) of the Code, seeking
revision/revaluation and/or withdrawal of the Resolution Plan. The said application
was dismissed by this Hon'ble Tribunal on the basis that modification/revaluation of
the Resolution Plan could not be permitted. The Applicant thereafter filed an
Application bearing PB/IA/1310/2019 seeking withdrawal of the Resolution PlanEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

simpliciter, which was dismissed by the Hon'ble Tribunal vide order dated
07.09.2019, while granting liberty to file a fresh application seeking withdrawal of the
Resolution Plan.” The reasons for withdrawal were the same as those in the previous
applications for withdrawal.
31 On 18 September 2019, the NCLT issued notice in the Third Withdrawal Application and directed
the E-RP to place it before the E-CoC. The E-RP placed PART A the application before the E-CoC at
the 14th meeting on 26 September 2019. The E-CoC resolved not to allow the application for
withdrawal.
A.6    Orders of NCLT and NCLAT
32     By its order dated 2 January 2020, NCLT allowed the Third Withdrawal
Application. The NCLT held that the application for withdrawal was not barred by res judicata since
in the previous proceeding relating to the First Withdrawal Application, it had not consciously
adjudicated on whether the Resolution Plan could be withdrawn. The rationale for the order is
indicated in the following extract:
“11. No doubt there was a prayer for withdrawal of resolution plan amongst others in
CA No.1252 (PB)/2019, the prayer for revaluation was specifically declined dismissal
order dated 10.07.2019. While dismissing CA No.1252(PB)/2019 the prayer for
withdrawal of resolution plan was neither considered nor was ever dealt with. The
issue of withdrawal of the resolution plan by the Applicant has never been considered
consciously on merit and/or adjudicated upon in CA No.1252(PB)/2019.
12. Doctrine of Constructive Res Judicata does not apply to the issues/points, or any
"lis' between parties that has not been decided previously, and despite being pleaded,
has not been considered by a court/tribunal and expressly dealt with in the order so
passed.
13. Even a bare perusal of the Order dated 10.07.2019 would indicate that the issue of
withdrawal of the Resolution Plan by the Resolution Applicant was not dealt with on
merit and that no decision has either been passed or attained finality as regards
allowing the party to withdraw the Resolution Plan.
14. It is also pertinent to note here that the Resolution Applicant had subsequently
taken up the prayer for withdrawal of the Resolution Plan in the Application bearing
CA No.1310 (PB)/2019. While dealing with the said Application, liberty was given to
the Applicant vide order PART A dated 01.09.2019 to re-file an application for
withdrawal of the Resolution Plan. This direction further confirms that there was no
conscious adjudication in CA No.1252(PB)/2019 on the issue of withdrawal of the
resolution plan by the Applicant.” (emphasis supplied) The NCLT held that: (i) aEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Resolution Plan becomes binding after it is approved by it as the Adjudicating
Authority; (ii) under Section 30(2) of the IBC, the Adjudicating Authority has the
power to examine whether the Resolution Plan can be effectively enforced and
implemented; and (iii) in the ‘present circumstances’, an unwilling successful
Resolution Applicant would be unable to effectively implement the Resolution Plan.
The relevant parts of the order are extracted below:
“20. In the instant case the Resolution Plan is still pending before the Adjudicating
Authority for approval. Under the provisions of Section 31 of the Code, a Resolution
Plan becomes binding only after acceptance of a plan by the Adjudicating Authority.
[…]
23. Section 30(2)(d) of the Code mandates the Adjudicating Authority to ensure that
there are effective means of enforcement and implementation of the Resolution Plan.
Similarly, the proviso to sub-section (1) of Section 31 of the Code mandates Adjudicating Authority
to ensure effective implementation of the resolution plan. The object. in approval of the resolution
plan is to save the corporate debtor and to put it back on its feet. An unwilling and reluctant
resolution applicant, who has withdrawn his resolution plan, neither can put the corporate debtor
back to its feet nor the effective implementation of its resolution plan can be ensured.
24. No doubt the withdrawal of the resolution plan at this advance stage has caused great prejudice
to the creditors/stake holders and legal consequences on the withdrawal of the resolution plan shall
follow as per law. The Resolution Professional and CoC are free to take action as PART A per law
consequent upon withdrawal of the resolution plan by the resolution applicant including on the
issue of refund of the earnest money deposited by the applicant.
25. Be that as it may compelling an unwilling and reluctant resolution applicant to implement the
plan may lead to uncertainty. The object of the Code is to ensure that the Corporate Debtor keep
working as a going concern and to safeguard the interest of all the stake holders. The provisions of
the Code mandate the Adjudicating Authority to ensure that the successful resolution applicant
starts running the business of the Corporate Debtor afresh. Besides Court ought not restrict a
litigant's fundamental right to carry on business in its way under Article 19(1)(g) of the Constitution.
Once the applicant is unwilling and reluctant and itself has chosen to withdraw its resolution plan, a
doubt arises as to whether the resolution applicant has the capability to implement the said plan.
Uncertainty in the implementation of the resolution plan cannot also be ruled out.” (emphasis
supplied) The NCLT also directed that Educomp’s CIRP be extended by a period of 90 days,
commencing from 16 November 2019.
33 As a consequence of its order allowing the Third Withdrawal Application, the NCLT also
dismissed the Approval Application on 3 January 2020 as being infructuous.Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

34 E-CoC filed the Withdrawal Appeal assailing NCLT’s order dated 2 January 2020. On 3 February
2020, the NCLAT stayed the order dated 2 January 2020. The Approval Appeal17 was also filed by
the E-CoC under Section 61 of the IBC, assailing NCLT’s order dated 3 January 2020.
Company Appeal (AT) (Insolvency) No 587 of 2020 PART A 35 By its order dated 29 July 2020,
NCLAT set aside the order of the NCLT allowing the withdrawal of the resolution plan. On the issue
of res judicata, the NCLAT held that there being no appeal against the order of the Adjudicating
Authority rejecting the First Withdrawal Application, the issue had attained finality. The NCLAT
held:
“82…in view of the dismissal of said CA 1252(PB)/2019 by the Adjudicating Authority
and the said order which had attained finality and more so in the absence of any
'Appeal' being filed against the said order, then the dismissal order of CA 1252 of
2019 order dated 10.7.2019 binds the 1st Respondent/'Resolution Applicant' as an
'Inter-se' party.
[…]
84.…the Adjudicating Authority in the particular circumstances of the present case
has no power to grant /reserve liberty to bring a fresh application and hence, the
subsequent application filed by the 1st Respondent /'Resolution Applicant is barred
by the principle of 'Res Judicata' notwithstanding the liberty to file fresh one.” On the
merits of the application for withdrawal, the NCLAT held that: (i) once the
Resolution Plan was approved by the CoC, the NCLT did not have jurisdiction to
permit its withdrawal; (ii) the Adjudicating Authority could not enter upon the
wisdom of the decision of the CoC to approve the Resolution Plan; (iii) the Resolution
Applicant had accepted the conditions of the Resolution Plan and no change could be
permitted; (iv) orders have already been reserved in the Approval Application; (v) no
Special Investigation Audit had been conducted; (vi) Section 32A of the IBC grants
full immunity to the Resolution Applicant from any offences committed before the
commencement of the CIRP; and (vii) Ebix had participated in the process from
August 2018 to January 2019 when orders had been reserved on the Approval
Application, and hence it could not claim any right based on delay.
PART A A.7 Present status of SFIO and CBI investigation 36 In an email dated 17 February 2020,
the E-RP informed the E-CoC that the CBI conducted a search of the premises of Educomp on 11
February 2020 and seized numerous documents (a list was enclosed with the email). By another
email dated 19 February 2020, the E-RP informed the E-CoC that CBI had resumed its search for
documents at Educomp’s office. 37 In the 16th meeting of the E-CoC on 30 March 2020, the E-RP
provided the following updates in relation to the CBI and SFIO investigations:
(i) The CBI search at the premises of Educomp on 11 February 2020, was conducted
upon a complaint by SBI on behalf of a consortium of banks;Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

(ii) Since the initiation of an enquiry by the MCA on 1 August 2018, the SFIO has
requisitioned documents/information, which have been provided;
(iii) The last communication from the SFIO was received on 27 February 2020;
and
(iv) In response to the grievance of some members of the E-CoC that the E- RP had only informed
them of the investigations at a belatedly, the Chairperson of the E-CoC justified it by stating that the
communication could only take place once the relevant investigation was completed. However, for
future references, the Chairperson took note of the suggestion that the E-RP would add all members
of the E-CoC to a WhatsApp group, where real-time updates could be shared. PART B At the
meeting, the E-CoC also passed a resolution with 77.05 per cent majority vote directing the E-RP to
invoke and forfeit the EMD of Rs 2 crores furnished by Ebix in accordance with Clause 1.9.1 of
RFRP. The E-RP issued a letter to IDBI on 1 April 2020 for encashment of the EMD.
38 In the 17th meeting of the E-CoC on 8 May 2020, the E-RP provided further updates in relation
to the CBI and SFIO investigations, noting that they were still ongoing and no further action was
required to be taken. 39 The E-RP has informed this Court that the last communication received
from the SFIO was on 4 September 2020. The investigations by the CBI and SFIO are continuing.
B          Civil Appeal No 3560 of 2020 – the Kundan Care Appeal
B.1        The appeal
40         This appeal arises under Section 62 of the IBC from a judgment dated 30
September 2020 of the NCLAT. The NCLAT dismissed an appeal18 instituted by the appellant,
Kundan Care, under Section 61 of the IBC against an order dated 3 July 2020 of the NCLT.
41 The NCLT had dismissed an application19 filed by Kundan Care under Section 60(5) of the IBC
to withdraw its Resolution Plan submitted for the fourth respondent – Corporate Debtor, Astonfield.
In appeal, the NCLAT upheld the NCLT’s decision, relying on its judgment impugned in the Ebix
Appeal. It held that Company Appeal (AT) (Insolvency) No 653 of 2020 IA No 1679 of 2019 in CP
No (IB)-940 (ND) of 2018 PART B an application filed by a Resolution Applicant to withdraw from
the Resolution Plan approved by the CoC could not be allowed since: (i) there was no provision in
the IBC for it; (ii) the Resolution Plan is enforceable as a contract against the Resolution Applicant;
and (iii) the Resolution Applicant was estopped from withdrawing.Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

42 The correctness of this view of the NCLAT now comes up for determination in the present appeal.
While issuing notice on 16 November 2020, this Court had directed for an ad-interim stay on the
judgment of the NCLAT, which continues till date.
B.2        Initiation of CIRP
43         On 20 November 2018, Astonfield filed a petition20 under Section 10 of the
IBC seeking to initiate voluntary CIRP. The NCLT admitted this petition on 27 November 2018 and
appointed an IRP.
44 A CoC was then constituted, which consisted of the second and third respondents, EXIM Bank
and PFCL. The A-CoC appointed the first respondent, Mr Amit Gupta, as the RP and his
appointment was confirmed by the NCLT on 1 February 2019.
CP No (IB)-940 (ND) of 2018 PART B B.3 Invitation, submission and approval of Resolution Plan
45 On 20 February 2019, A-RP invited prospective resolution applicants to submit their EOIs in
accordance with Regulation 36 of the CIRP Regulations and Form G was also published. Form G
was amended by the A-RP, with due approval from the A-CoC, on 2 May 2019 and 17 May 2019.
46 A-RP received nine EOIs, out of which seven were found to be eligible. However, Kundan Care
did not submit its EOI within the time prescribed by the A- RP, and its belated submission was
rejected by the A-RP. 47 Thereafter, A-RP issued the RFRP on 6 March 2019 to the prospective
Resolution Applicants who had been selected. Further, the IM was issued on 13 March 2019. Based
on this, two Resolution Plans were received by the A-RP on 31 May 2019, which were then discussed
with the A-CoC. 48 In the interim, Kundan Care filed an application21 before the NCLT challenging
the A-RP’s rejection of its belated EOI. A-RP received the notice of this application on 30 August
2019. By order dated 6 September 2019, the NCLT allowed Kundan Care’s application. Thereafter, it
was provided access to the RFRP, IM and other documents pertaining to Astonfield in the data
room. 49 Kundan Care submitted its Resolution Plan for consideration on 16 September 2019. The
Resolution Plan was placed before the A-CoC, which requested Kundan Care to submit a revised
proposal. Kundan Care then submitted an updated draft of its Resolution Plan on 29 October 2019.
CA No 1119 of 2019 PART B 50 A-RP then conducted the 17th meeting of the A-CoC on 11 November
2019, to discuss the Resolution Plans submitted by Kundan Care and one more prospective
Resolution Applicant (who had also submitted a revised Resolution Plan after negotiations with the
A-CoC). Thereafter, Kundan Care submitted a revised version of its Resolution Plan on 12 November
2019, along with an addendum on 13 November 2019.
51 The A-CoC voted on the Resolution Plans on 14 November 2019, where the Resolution Plan
submitted by Kundan Care was approved with a majority of 99.28 per cent, with 0.72 per cent
abstaining. On 15 November 2019, the A-RP issued a Letter of Award to Kundan Care. Kundan Care
also deposited a PBG of Rs 5 Crores with the A-RP/A-CoC.Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

52 A-RP then filed an application22 for approval of the Resolution Plan under Section 31 of the IBC
before the NCLT, along with Form H, as mandated under the CIRP Regulations. This application is
currently pending adjudication before the NCLT.
B.4       Astonfield’s dispute with GUVNL
53        Before proceeding further, it is important to discuss the dispute arising out
of Astonfield’s PPA with GUVNL. The PPA was signed on 30 April 2010, came into force in
December 2012. and was valid for a period of 25 years. Crucially, CA No 1526 of 2019 PART B this
PPA was the only agreement entered into by Astonfield and formed the entirety of its business.
54 When CIRP was initiated against Astonfield, GUVNL issued a notice of default under Article
9.2.1(e) of the PPA, stating that the initiation of insolvency was an “event of default”. This was
challenged before the NCLT by A-RP23 and EXIM Bank24 through applications under Section
60(5) of the IBC. 55 It is important to note that Kundan Care was aware of this dispute, and made
specific references to it in its Resolution Plan. Under the heading of “PPA Risk”, it noted:
“GUVNL had served notices to terminate the Agreement since the Company is
undergoing the process of Insolvency. However as per the Order of the Hon'ble NCLT
dated 29 August 2019 (CA) 700/ND/2019 & CA 701/ND/2019) it is concluded that
the Power Purchase Agreement (PPA) is an "instrument" for the applicability of
Section 238 of the IBC, 2016 and clauses 9.2.1 e read with 9.3.1 of the PPA under
reference are inconsistent within the ambit of Section 238 of/BC, 2016, provisions
of/BC, 2016 and process initiated under /BC shall have an overriding effect over the
PPA.
Further, the Hon'ble NCLAT vide order dated 15 October 2019 has clearly stated that
even in the event of Liquidation of the Corporate Debtor the appellant, Gujarat Urja
Vikas Nigam Limited, cannot terminate the Power Purchase Agreement under the
Code. Also, the Liquidator shall ensure that the Corporate Debtor remains a going
concern. It is therefore very evident and clear that the Power Purchase Agreement
cannot be terminated and has to continue even after the Resolution Plan has been
approved by the Hon'ble NCLT.” CA No 700 of 2019 CA No 701 of 2019 PART B
56 On 29 August 2019, the NCLT allowed the applications and set aside the notice of default issued
by GUVNL. It held that allowing the termination of the PPA would adversely affect the ‘going
concern’ status of Astonfield. However, it held that if Astonfield was to undergo liquidation
subsequently, the termination would be permitted.
57 The NCLT’s judgment was challenged by GUVNL in an appeal25 before the NCLAT. By judgment
dated 15 October 2019, the NCLAT dismissed the appeal and partly upheld the decision of the
NCLT, in as much as it disallowed the termination of the PPA during the CIRP. However, it reversedEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

the NCLT’s findings and held that even if Astonfield were to undergo liquidation, the termination of
the PPA would not be allowed.
58 GUVNL challenged NCLAT’s judgment in the GUVNL Appeal26 before this Court. When the
present appeal was filed by Kundan Care, the GUVNL Appeal was pending before this Court.
However, it has been disposed by a judgment dated 8 March 2021, in the following terms:
“165 Given that the terms used in Section 60(5)(c) are of wide import, as recognized
in a consistent line of authority, we hold that the NCLT was empowered to restrain
the appellant from terminating the PPA. However, our decision is premised upon a
recognition of the centrality of the PPA in the present case to the success of the CIRP,
in the factual matrix of this case, since it is the sole contract for the sale of electricity
which was entered into by the Corporate Debtor. In doing so, we reiterate that the
NCLT would have been empowered to set aside the termination of the PPA in this
case because the termination took place solely on the ground of insolvency. The
jurisdiction of the NCLT under Section 60(5)(c) of the IBC cannot be invoked in
matters where a termination may take Company Appeal (AT) Insolvency No 1045 of
2019 Civil Appeal No 9241 of 2019 PART B place on grounds unrelated to the
insolvency of the corporate debtor. Even more crucially, it cannot even be invoked in
the event of a legitimate termination of a contract based on an ipso facto clause like
Article 9.2.1(e) herein, if such termination will not have the effect of making certain
the death of the corporate debtor. As such, in all future cases, NCLT would have to be
wary of setting aside valid contractual terminations which would merely dilute the
value of the corporate debtor, and not push it to its corporate death by virtue of it
being the corporate debtor‘s sole contract (as was the case in this matter‘s unique
factual matrix).” Hence, this Court held that GUVNL would not be allowed to
terminate its PPA with Astonfield since: (i) the termination was solely on account of
Astonfield entering into insolvency proceedings; and (ii) being its sole contract, the
PPA’s termination would necessarily result in the corporate death of Astonfield,
which would derail the entire CIRP.
B.5    Withdrawal of the Resolution Plan
59     On 17 December 2019, Kundan Care filed an application under Section
60(5) of the IBC seeking permission of the NCLT to withdraw its Resolution Plan,
which had been previously approved by the A-CoC and was pending confirmation by
the NCLT under Section 31 of the IBC. In its application, it prayed for the following
reliefs:
“a) Allow the present application and permit the Applicant to withdraw its Resolution
Plan as submitted and approved by the CoC on 14.11.2019;Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

b) Direct that the Performance Bank Guarantee submitted by the Applicant be
cancelled/revoked/returned/refunded to the Applicant;” PART B In its application,
Kundan Care stated that there was no bar under the IBC on it withdrawing its
Resolution Plan before it was confirmed by the NCLT. It sought to withdraw its
Resolution Plan on account of four reasons:
(i) That there was uncertainty in relation to the PPA with GUVNL, since the GUVNL
Appeal was pending before this Court. It noted that the PPA was central to the CIRP,
and its termination would affect its Resolution Plan.
Further, it noted that GUVNL had unilaterally refused permission to Astonfield to change the solar
panels which had been damaged in the floods of 2017, and had not made any payments to Astonfield
for the electricity being supplied currently;
(ii) That due to heavy floods in the State of Gujarat during 2019, the solar panels and other
equipment at the Project Site of Astonfield had been damaged. Further, it alleged that there was
stagnant water at the Project Site, which continued to deteriorate them;
(iii) That Astonfield’s insurance claim of Rs 46.40 crores in relation to floods in 2017 had been
repudiated by the insurer. Further, it also noted that this may also adversely affect the claim for the
floods in 2019; and
(iv) That the IM issued by A-RP represented that since Astonfield had not availed the benefit of
“Accelerated Depreciation” under the PPA, hence, it was entitled to a sum of Rs 6.614 crores from
GUVNL, which was a “Trade Receivable”. However, it noted that Kundan Care had subsequently
discovered a previous judgment of this Court upon identical facts, where it was noted that the
Project Developer shall not be entitled to a higher/revised tariff in case of not availing “Accelerated
Depreciation”. PART B 60 On 6 January 2020, Kundan Care filed an additional affidavit outlining
the additional costs it would face on account of: (i) deterioration of the solar panels due to GUVNL
unilaterally not permitting their replacement, thereby leading to additional cost of Rs 30 crores
(against an initial expected cost of Rs 9 crore); (ii) Astonfield’s Plant not producing electricity at its
optimum level, thereby leading to a loss of revenue up to Rs 150 lacs per month; and (iii) CIRP costs
on account of delay in CIRP, thereby leading to a loss of Rs 12 lacs per month (approx.). It noted:
“5. I say and submit that after submission of the Resolution plan, the Applicant's
representatives had visited the site again and found that almost all the solar panels
installed at the Project site are required to be changed/replaced at a total cost of over
INR 30 crores instead of INR 9 crores ascertained by the Applicant at the time of
submission of the Plan.
[…]
17. I say and submit that the plant is capable of generating 18133200 KWH/Units of
Electricity per annum (11.5 MW * 365 days * 24 hours* 1000 (from MW to KW) *Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

18% CUF = 18133200 KWH/Units), when operating at the optimum capacity which
would only be possible after change/replacement of solar panels, inverters etc. as
contemplated in the Resolution Plan. This translates to generation revenue of roughly
INR 1800 lacs per annum or roughly INR 150 lacs per month which is being incurred
by the Project.
18. I say and submit that in addition to the aforesaid generation loss, a sum of INR 12
lacs (approx.) is being incurred towards monthly CIRP cost on account of the delay in
the CIR process.” PART B
61 Thereafter, Kundan Care also filed an application for impleadment27 in the GUNVL Appeal
pending before this Court, along with an application for directions28 praying, in exercise of this
Court’s jurisdiction under Article 142 of the Constitution of India, for the following reliefs:
“a) Set aside/quash the Notice dated 28.03.2019 issued by Gujarat Urja Vikas Nigam
Limited to Astonfield Solar (Gujarat) Private Limited and declare that the
Applicant/Corporate Debtor shall be free to change/replace the solar panels/modules
and other equipment of the Project, as may be deemed fit by the Applicant/Corporate
Debtor;
b) Declare that the Power Purchase Agreement dated 30.04.2010 executed between
Gujarat Urja Vikas Nigam Limited and Astonfield Solar (Gujarat) Private Limited
shall stand extended by the period of moratorium declared under IBC during the CIR
Process;
c) In alternate to prayers a) and b), permit the Applicant to withdraw its Resolution Plan dated
12.11.2019 and direct that the Performance Bank Guarantee submitted by the Applicant to the
Committee of Creditors shall stand cancelled/revoked and/or returned/refunded to the Applicant;”
62 While the GUVNL appeal and its application remained pending, on 14 May 2020, Kundan Care
requested the NCLT to take up its application for an early hearing. Following this, the application
was listed on 15 June 2020. 63 On 12 June 2020, A-RP filed its reply to Kundan Care’s application
and additional affidavit, where it opposed the withdrawal of the Resolution Plan after its approval by
the A-CoC and stated that:
(i) In relation to the ongoing dispute with GUVNL, Kundan Care was aware of the
same when it submitted the Resolution Plan;
IA No 9679 of 2020 IA No 9682 of 2020 PART B
(ii) In relation to the damage to the solar panels, it pointed out that the A-RP had informed Kundan
Care about the floods in 2019 and an Operation and Management Agency had been hired to clear
the water at the Project Site, which had been done;Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

(iii) In relation to the repudiation of the insurance claim, the RFRP or IM never guaranteed that the
claim would be successful. In any case, the A-RP was actively pursuing the challenge to its
repudiation;
(iv) In relation to the “Accelerated Depreciation”, that the same had been listed as a “doubtful debt”
by the A-RP in the IM. Further, in any case, Kundan Care would have done their own due diligence
surrounding it; and
(v) In relation to Astonfield’s Plant not operating at full capacity, the IM issued by A-RP noted that
the floods in 2017 had affected the Plant and it may not be able to operate at full capacity.
64 Kundan Care filed its rejoinder to the A-RP’s reply on 29 June 2020, in which they argued that
the Resolution Plan proposed by them and approved by the A-CoC, was no longer “feasible” and
“viable” commercially, in accordance with Section 30(2)(d) read with proviso to Section 31(1) of the
IBC, due to the intervening circumstances before its confirmation by the NCLT which had materially
altered the financial projections. Hence, the NCLT should allow it to withdraw the Resolution Plan.
In the alternative, Kundan Care proposed re- negotiation of the Resolution Plan by stating the
following:
“55. That Para 78 of the Reply is the Prayer Clause, which is wrong and denied. The
Prayer Clause of C.A. No. 16798/2019 is reiterated and reaffirmed. Alternatively, and
without prejudice to the above, it is prayed that the Applicant PART B may be
permitted to re-negotiate the financial proposal with the CoC”
65 The A-CoC also filed its reply to Kundan Care’s application on 30 June 2020, where it stated that:
(i) NCLT could not adjudicate upon the application since Kundan Care had filed another application
before this Court in the GUVNL Appeal; and (ii) in any case, Kundan Care knew of the risks while
entering the CIRP and should not be allowed to withdraw at such a belated stage. 66 The NLCT
passed an order dated 3 July 2020, by which it rejected Kundan Care’s application by noting that: (i)
it did not have jurisdiction to permit withdrawal; and (ii) the matter was also sub judice before this
Court by the virtue of Kundan Care’s application in the GUVNL Appeal. The order stated:
Counsels for the Resolution Applicant, COC and IRP are present.
The Resolution Applicant has prayed to withdraw the resolution plan which was
submitted before this Tribunal after approval of the COC. After careful consideration
of the matter, we are of the view that the NCLT has no jurisdiction to permit
withdrawal of the resolution plan which has been placed before the authority with
due approval of the COC. Notwithstanding this fact, it has been pointed out by the
Counsel for the COC that another matter is subjudiced before the Hon'ble Supreme
Court in which inter-alia a similar request has been made. This has been submitted
by the Cotinsel for the COC on page 31 of the reply filed by COC in response to the
application.Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Keeping this in view, it will not be appropriate for this Tribunal to deal with an issue
which is already subjudiced before the Hon'ble Supreme Court. The Application is
hereby rejected.” PART B
67 In view of the NCLT’s order, Kundan Care made an oral request for withdrawal of its application
to this Court when the GUVNL Appeal was listed on 20 July 2020. This request was allowed by this
Court.
68 Thereafter, the appellant filed an appeal before the NCLAT, challenging the order dated 3 July
2020 passed by the NCLT. NCLAT did not issue notice in the appeal, but heard the submissions of
all parties at the stage of admission and directed them to file their written submissions.
69 By the impugned judgment dated 30 September 2020, the NCLAT dismissed the appeal by
Kundan Care, relying on the judgment impugned in the Ebix Appeal. It noted:
“7. Be it seen that the CIRP process undertaken involves filing of Expression of
Interest by the prospective Resolution Applicants which may ultimately manifest in
the form of prospective Resolution Plan after negotiations as regards improvement or
revision in terms of the proposed Resolution Plan. This process is in the nature of a
bidding process where, based on consideration of the provisions of a Resolution Plan
with regard to financial matrix, capacity of the Resolution Applicant to generate
funds, infusion of funds, upfront payment, the distribution mechanism and the
period over which the claims of various stake holders are to be satisfied besides the
feasibility and viability of the Resolution Plan, a Resolution Applicant emerges as the
highest bidder (Hl) eliminating the Resolution Plans of Resolution Applicants, which
are ranked H2 and H3. The approval of a Resolution Plan by the Committee of
Creditors with requisite majority has the effect of eliminating H2 and H3 from the
arena. Though, such approved Resolution Plan would be binding on the Corporate
Debtor and all stake holders only after the Adjudicating Authority passes an order
under Section 31 of the I&B Code approving the Resolution Plan submitted by
Resolution Professional with the approval of Committee of Creditors in terms of
provisions of Section 30(6) of the I&B Code, it does not follow that the Successful
Resolution Applicant would be at liberty to withdraw the Resolution Plan duly
approved by the Committee of Creditors and laid before the Adjudicating Authority
for approval thereby sabotaging the PART B entire Corporate Insolvency Resolution
Process, which is designed to achieve an object. A Resolution Applicant whose
Resolution Plan stands approved by Committee of Creditors cannot be permitted to
alter his position to the detriment of various stake holders after pushing out all
potential rivals during the bidding process. This is fraught with disastrous
consequences for the Corporate Debtor which may be pushed into liquidation as the
CIRP period may by then be over thereby setting at naught all possibilities of
insolvency resolution and protection of a Corporate Debtor, more so when it is a
going concern. That apart, there is no express provision in the I&B Code allowing a
Successful Resolution Applicant to stage a U-tum and frustrate the entire exercise ofEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Corporate Insolvency Resolution Process. The argument advanced on behalf of the
Appellant that there is no provision in the I&B Code compelling specific performance
of Resolution Plan by the Successful Resolution Applicant has to be repelled on four
major grounds:-
(i) There is no provision in the l&B Code entitling the Successful Resolution
Applicant to seek withdrawal after its Resolution Plai1 stands approved by the
Committee of Creditors with requisite majority;
(ii) The successful Resolution Plan incorporates contractual terms binding the
Resolution Applicant but it is not a contract of personal service which may be legally
unenforceable;
(iii) The Resolution Applicant in such case is estopped from wriggling out of the
liabilities incurred under the approved Resolution Plan and the principle of estoppel
by conduct would apply to it;
(iv) The value of the assets of the Corporate Debtor is bound to have depleted because
of passage of time consumed in Corporate Insolvency Resolution Process and in the
event of Successful Resolution Applicant being permitted to walk out with impunity,
the Corporate Debtor's depleting value would leave all stake holders in a state of
devastation.” The NCLAT held that withdrawal of a Resolution Plan by the
Resolution Application after its approval by the CoC cannot be permitted since: (i) it
contravenes the principles of IBC, which require the CIRP to be conducted in a
time-bound manner in order to maximise the value of the assets of the Corporate
Debtor; (ii) permitting Kundan Care to withdraw would sabotage the CIRP, where
PART C the A-CoC had previously rejected other prospective Resolution Applicants
in favor of Kundan Care; (iii) there is no specific provision in the IBC for allowing
withdrawal; (iv) the Resolution Plan incorporated contractual terms binding the
Resolution Applicant, and it is not akin to a contract of personal service which is
legally unenforceable; (v) by the virtue of principle of estoppel of conduct, Kundan
Care is estopped from withdrawing; and (vi) the withdrawal may lead to the
Astonfield’s liquidation, and the value of its assets were bound to have depleted in the
interim.
C          Civil Appeal No 295 of 2021 – the Seroco Appeal
C.1        The appeal
70         This is an appeal under Section 62 of the IBC from an order dated 10
December 2020 of the NCLAT. By its judgment, the NCLAT dismissed an appeal29
instituted by Seroco, under Section 61 of the IBC against an order dated 23 OctoberEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

2020 of the NCLT.
71 The NCLT dismissed an application30 by Seroco under Section 60(5) seeking permission to
modify its Resolution Plan submitted for the Corporate Debtor – Arya Filaments. NCLT relied on
the impugned judgment in the Kundan Care Appeal. Further, it noted that while the application
prayed for a modification of the Resolution Plan, its title was “Application for withdrawal under
section 60(5) of the Insolvency and Bankruptcy Code, 2016”.
Company Appeal (AT) (Insolvency) No 1054 of 2020 IA No 96 of 2020 in CP (IB) No 29 of 2018
PART C 72 In appeal, the NCLAT partly upheld the NCLT’s decision and held that Seroco could not
be allowed to modify or withdraw the Resolution Plan approved by the Arya-CoC since: (i) it was the
sole Resolution Applicant in the CIRP; (ii) Arya Filaments was an MSME; and (iii) it was aware of
Arya Filaments’ financial condition when it submitted the Resolution Plan. However, it set aside the
NCLT’s decision in relation to the costs imposed on Seroco.
C.2        Initiation of CIRP
73         The second respondent, Kotak, being a financial creditor of Arya
Filaments, filed a petition31 under Section 7 of the IBC seeking to initiate CIRP. 74 By an order
dated 17 August 2018, the NCLT initiated CIRP against Arya Filaments and appointed the first
respondent, Mr Ravi Kapoor, as the IRP. Thereafter, a CoC was constituted, which consisted of
Kotak Mahindra and the third respondent, UBIL. The Arya-CoC then appointed Mr Ravi Kapoor as
the RP.
C.3        Submission and Approval of Resolution Plan
75         The Arya-RP thereafter invited Resolutions Plans for Arya Filaments.
Seroco, being a company formed by the former employees of Arya Filaments, submitted a
Resolution Plan on 13 March 2019 where, inter alia, they offered to pay Rs 6,79,22,000. This was
the only Resolution Plan which was received.
CP (IB) No 29 of 2018 PART C 76 At its 4th meeting held on 16 April 2019, the Arya-CoC noted that
Seroco’s Resolution Plan needed some improvements and directed it to submit a revised Plan.
Seroco’s revised Resolution Plan was then approved by the Arya-CoC in its 5th meeting held on 10
May 2019, with 100 per cent approval. 77 On or about 15 May 2019, the Arya-RP filed an
application32 under Section 30(6) before NCLT for confirmation of the Resolution Plan. Form H
under the CIRP Regulations was filed by way of an affidavit on 5 June 2020.
C.4        Modification of the Resolution PlanEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

78         On 9 June 2020, Seroco addressed a letter to the Arya-RP and Arya-CoC
highlighting that their Resolution Plan was based on the economic conditions which prevailed at
that time, which had been significantly altered due to the onset of the COVID-19 pandemic. In
particular, it highlighted that:
(i) The physical condition of Arya Filament’s machinery would have deteriorated;
(ii) Financial losses must have been suffered by Arya Filaments during the COVID-19
pandemic;
(iii) Demand/sale of Arya Filaments’ products must have suffered during pandemic;
and
(iv) Due to the pandemic, the funds of Seroco have also been drastically reduced.
IA No 280 of 2019 in CP (IB) No 29 of 2018 PART C It submitted a revised Resolution Plan to be
considered by the Arya-CoC. In the revised Resolution Plan, Seroco offered to pay, inter alia, an
amount of Rs 5,29,22,000. It also requested the Arya-RP and Arya-CoC to file the revised
Resolution Plan before the NCLT, and keep the proceedings on the confirmation of the previous
Resolution Plan in abeyance.
79 Thereafter, on 10 July 2020, Seroco filed an application before the NCLT praying for the
following reliefs:
“a) permit the Applicant to revise the Resolution Plan dated 13.3.2020 in terms of
letter dated 09/06/2020 at Annexure C hereto;
b) direct the Respondent No. 2 to consider the modified resolution plan as per Letter at Annexure C
and vote afresh on the same;
c) direct the Respondent No.1 to provide an updated Information Memorandum providing financial
condition of the Corporate Debtor as on 1/07/2020;
d) during the hearing of this Application, stay the implementation, operation and execution of the
Resolution Plan dated 13.3.2020 of the Applicant;” It noted that its Resolution Plan was filed
eighteen months ago and was based on an IM published two years previously, following which the
conditions had materially altered. Hence, Seroco stated that while it was genuinely interested in
Arya Filaments, its changed circumstances meant that it could not pay the entire consideration
envisaged in the Resolution Plan approved by the Arya-CoC earlier.
80 Seroco’s application was listed before the bench of the NCLT which was hearing the Arya-RP’s
application for confirmation of the Resolution Plan. By a PART C common order on 23 October
2020, the NCLT allowed the Arya-RP’s application and confirmed Seroco’s Resolution Plan whichEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

had been approved by the Arya- CoC. In relation to Seroco’s application for modification, it noted:
“18. It is the matter of record that the instant application was filed subsequent to the
filling of the above stated IA ie. IA 280 of 2019 filed under Section 30(6) of the IB
Code. It is stated by the Applicant that the Resolution Plan, so submitted by the
Applicant, is based on the Information Memorandum which was published two years
ago. Considering the time of two years and outbreak of Covid-19, the Applicant is not
aware of the current financial condition of the Corporate Debtor and is now not in a
position to bear the costs/losses of the Corporate Debtor and hence, is seeking for
withdrawal of the Resolution Plan. This story is not believable as the Corporate
Debtor, being a MSME, has filed the plan considering the financial ‘condition of the
Corporate Debtor and have shown his interest to take the Company. Hence, having
no knowledge of the financial condition does not arise at all.
19. It is pertinent to mention herein that in view of the judgement passed by Hon’ble
NCLAT in Kundan Care Products Ltd vs. Mr. Amit Gupta Resolution Professional
and-
Ors (Company Appeal (AT) (Insolvency) No. 653 of 2020), the Resolution Plan, once submitted,
cannot be withdrawn as there is no provision in the IB Code which allows withdrawal of an
approved Resolution Plan & the successful Resolution Plan incorporates contractual terms binding
the Resolution Applicant but it is not a contract of personal service which may be legally
unenforceable.
20. Moreover, there is an ambiguity in the instant application with regard to the relief sought for, as
the title of the application states “Application for withdrawal under section 60(5) of the Insolvency
and Bankruptcy Code, 2016” whereas the prayer, as stated above, has no whisper regarding the
withdrawal of the Resolution Plan.” Hence, it rejected Seroco’s application and imposed costs of Rs
50,000. 81 Seroco filed an appeal against the NCLT’s judgment, which came to be dismissed by the
NCLAT by its impugned order dated 10 December 2020, where it noted:
PART D “2. After hearing learned counsel for the Appellant and having regard to the
Judgments rendered by this Appellate Tribunal holding that the Successful
Resolution Applicant cannot be permitted to withdraw the approved Resolution Plan
coupled with the fact that the Appellant in the instant case being the sole Resolution
Applicant in the Corporate Insolvency Resolution Process (CIRP) of the Corporate
Debtor which has been classified as an MSME and admittedly having knowledge of
the financial health of the Corporate Debtor as a promoter or a connected person
cannot be permitted to seek revision of the approved Resolution Plan on that ground
which would not be a material irregularity within the ambit of Section 61(3) of the
Insolvency and Bankruptcy Code, 2016. We are of the considered opinion that there
is no merit in this appeal and the same is liable to be dismissed.” Considering Arya
Filament’s position as an MSME, Seroco being a company formed by its former
employees (who would have been aware of its financial condition) and also being theEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

sole Resolution Applicant, the NCLAT refused to permit modification/withdrawal of
the Resolution Plan.
D     Submissions of counsel in the Ebix Appeal
D.1   Submissions for the appellant
82    Mr K V Vishwanathan, learned Senior Counsel appearing on behalf of Ebix
submitted that a successful Resolution Applicant may be permitted to withdraw the
resolution plan (pending approval of the Adjudicating Authority), on account of: (a)
subsequent developments in relation to Educomp (which in this case relate to
investigations of fraud and mismanagement during the pre-CIRP period); and
(b) due to an inordinate lapse of time, which has resulted in the complete erosion of
the fundamental commercial substratum underlying the Resolution Plan.
PART D Further, he argues that the NCLAT did not correctly apply the doctrine of constructive res
judicata. He has made the following submissions:
(i) Ebix is not bound by the Resolution Plan prior to the approval of the Adjudicating
Authority, in terms of the CIRP documents read with the scheme of IBC. In this
regard, our attention was drawn to:
(a) Section 31(1) of the IBC, which provides that the Resolution Plan is “binding…on
all stakeholders” only upon approval by the Adjudicating Authority;
(b) Section 74(3) of the IBC, which provides that a person can be prosecuted or
punished for contravening the Resolution Plan only after its approval by the
Adjudicating Authority;
(c) The documents underlying the CIRP, i.e., invitation of EOI, the RFRP, sanction
letter and Resolution Plan take effect of a binding contract only upon the approval of
the Adjudicating Authority and the execution of definitive agreements thereafter;
(d) Clause 1.1.6 of the RFRP provides that the Plan submitted by Ebix will have to be
approved by the Adjudicating Authority and will be binding on all the stakeholders in
relation to the Corporate Debtor and Ebix, only after it has been approved by the
Adjudicating Authority;
(e) Clause 1.10(1) of the RFRP provides that Ebix shall be responsible for the
implementation and supervision of the Resolution Plan from the date of approval by
the Adjudicating Authority; andEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

(f) Clause 2.2.9 of the RFRP provides that Ebix shall, pursuant to approval by the
Adjudicating Authority, execute definitive agreements;
PART D
(ii) The Resolution Plan constitutes an offer qualified by time and cannot be enforced against the
parties after such a long period of time has elapsed. In this regard, the following terms of the
documents underlying the CIRP were highlighted:
(a) Clause 1.1.5 of the RFRP, which invites Resolution Plans from prospective
Resolution Applicants. Further, Clause 1 of the covering letter for submission of the
Resolution Plan provides that Ebix is setting out the offer in relation to the insolvency
resolution of Educomp;
(b) The Resolution Plan was valid only for six months, since Clause 1.8.3 of the RFRP
invites resolution plans/offers with a validity of six months;
(c) In accordance with the RFRP, Clause 7 of the Resolution Plan provides that it is
valid for a period of six months from the date of submission.
The appellant is a liberty to withdraw the resolution plan if there is delay of several months beyond
the period of six months. It was emphasized that the Resolution Plan is a qualified offer which is not
open to acceptance for an indefinite period. Reliance was placed on the decision of this Court in Riya
Travel & Tours (India) (P) Ltd. v. C.U. Chengappa33 to support this proposition;
(d) The CSEB Application for the approval of the resolution plan continues to be pending before the
Adjudicating Authority, while the Approval Appeal is pending before the Appellate Authority. A
period of eighteen months has passed from the date of submission of the resolution plan (i.e., 19
February 2018) and twenty-seven months from the CIRP (2001) 9 SCC 512 PART D commencement
date. Such severe and inordinate delay is impermissible under Section 12 of the IBC and justifies the
withdrawal of the Plan;
(e) The delay in the approval was on account of the actions of members of the E-CoC, who had
sought a special audit of Educomp due to the concerns relating to mismanagement of its affairs.
Several members had filed applications (IFC, Axis Bank and SBI) before the Adjudicating Authority
in this regard. The Adjudicating Authority by orders dated 13 August 2018, 20 August 2018 and 31
August 2018 took cognizance of these applications and directed them to be placed before the E-CoC.
The E-CoC approved the Investigation Audit Application filed on its behalf before the Adjudicating
Authority for conducting a special audit by 77.85 per cent votes;
(f) SFIO initiated investigation against Educomp. Ebix became aware of the investigation only
through disclosures made to NSE/BSE and regulators on 12 June 2019;Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

(g) Ebix had sent a notice dated 2 July 2018 to the E-CoC/E-RP stating that the severe delays in the
CIRP have prejudiced the commercial considerations underlying the Resolution Plan and, in any
case, the Resolution Plan was valid only for six months. It urged the E-CoC/E-RP to expedite the
process for obtaining the Adjudicating Authority’s approval. Thereafter, Ebix filed the First
Withdrawal Application for seeking information relating to the financial position and other
commercial aspects of Educomp. After the dismissal of the First PART D Withdrawal Application,
the appellant filed the Second and Third Withdrawal Applications for withdrawal of its Resolution
Plan; and
(h) The above sequence of events shows that Ebix had no role to play in the delays plaguing the
CIRP of Educomp. Section 12 of the IBC stipulates that the insolvency resolution process should be
completed in 270 days with an outer limit of 330 days. This Court in CoC of Essar Steel India Ltd. v.
Satish Kumar Gupta & Ors.34 has held that “[i]t is only in such exceptional cases that time can be
extended, the general rule being that 330 days is the outer limit within which resolution of the
stressed assets of the corporate debtor must take place beyond which the corporate debtor is to be
driven into liquidation”;
(iii) The events that have taken place subsequent to the submission of Resolution Plan justify its
withdrawal. In this regard, it was urged on behalf of Ebix that:
(a) The Resolution Plan was based on certain considerations that were fundamental
to the Ebix’s bid for the business of Educomp, and were crucial for keeping the
business of Educomp as a going concern. These were the government contracts and
IP driven solutions in the education and health industries. However, due to the
inordinate delay in the completion of the CIRP, many of the government contracts
may have ended. Further, various technology driven solutions and intellectual
property owned and operated by Educomp, which Ebix had sought to acquire, were
no longer valid;
(2020) 8 SCC 531 PART D
(b) The E-CoC passed a resolution with 77.85 per cent votes to conduct a special audit
into the affairs of Educomp, which shows that evidence is available to conclude that
the affairs of the company were mismanaged, which materially affect the economic
considerations underlying the Resolution Plan;
(c) The affairs of Educomp are also being investigated by the SFIO and CBI, which
provides further evidence that the affairs of Educomp were severally mismanaged
and are susceptible to criminal investigations;
(d) There has been a lapse of over three years resulting in an erosion of vital business
prospects of Educomp; andEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

(e) The implementation and viability of a Resolution Plan is to be assessed at the time
of consideration of such plan by the competent Court/Tribunal, and not at the time of
submission of the Plan. The subsequent events that have transpired after the
submission of the Resolution Plan are relevant for evaluating the commercial
viability and the capability to implement the plan. In the present case, the substratum
forming the basis of the resolution plan has been eroded by the occurrence of the
abovementioned events. Thus, the successful Resolution Applicant has the right to
withdraw the Resolution Plan in such circumstances;
(iv) Material information relating to the financial position and affairs of Ebix was not
provided to Ebix after the submission of the Resolution Plan, as a consequence of
which, there is an impairment of a fair process in the conduct of a commercial
transaction. In this context:
PART D
(a) Section 29(2) of the IBC, provides that all relevant information should be
provided to the Resolution Applicant;
(b) Regulation 36 of the CIRP Regulations provides that the IM prepared under
Section 29 of the IBC should contain information relating to, inter alia: (1) “assets
and liabilities…”; (2) “the latest annual financial statement”; and (3) details of
“…ongoing investigations or proceedings initiated by Government and statutory
authorities”. While this information is relevant for the preparation of the Resolution
Plan, there is a continuing obligation to disclose such information if there is a
substantial delay in the CIRP (beyond the period prescribed under Section 12 of the
IBC) qua the Corporate Debtor;
(c) The Resolution Applicant’s right to complete and accurate information relating to
the Corporate Debtor has been recognized under the UNCITRAL Guide. The
principle of “equality of information” to all stakeholders, including the resolution
applicant, has been underlined in the BLRC Report; and
(d) The E-CoC/E-RP withheld information relating to mismanagement of affairs of
Educomp between 2014-2018, and also in relation to the investigation into the affairs
of Educomp by governmental authorities;
(v) The Adjudicating Authority has the power to permit the withdrawal of the
Resolution Plan. Under Section 31 of the IBC, it has the power to independently
satisfy itself that the “Resolution Plan as approved by the CoC… meets the
requirements as referred to in sub-section (2) of Section 30”. Section 30(2)(d) of the
IBC provides that the Adjudicating Authority PART D can assess whether adequate
provisions have been made for the “implementation and supervision of the resolution
plan”. This Court in K Sashidhar v. IOC35 has emphasized that the AdjudicatingEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Authority has the discretion to reject the Resolution Plan if it does not conform to the
stated requirements of Section 30(2)(d). The proviso to Section 31(1) of the IBC
expressly prohibits the Adjudicating Authority from approving a plan that is
incapable of being effectively implemented. The NCLAT, in the impugned judgement,
has not considered whether the exercise of the jurisdiction by the Adjudicating
Authority under Section 31(1) read with Section 30(2)(d) was valid. In the present
circumstances, the Resolution Plan is no longer capable of being implemented due to
the erosion of the commercial basis of the Resolution Plan and an inordinate lapse of
time;
(vi) The NCLT had good and valid reasons allowing for the withdrawal of the
resolution plan since:
(a) There was no approval by the E-CoC with the requisite majority of 75 per cent.
When the voting took place on the resolution plan submitted by the Appellant on 22
February 2018, there was a shortage in the votes required to achieve the statutory
requirement of 75 per cent of votes in the E-CoC. On 23 February 2018, one of the
financial creditors who was not present at the meeting of the E-CoC intimated its
agreement with the resolution plan and accordingly the Approval Application was
filed on 7 March 2018. Orders have been reserved on the Approval Application on 10
January 2018; and (2019) 12 SCC 150 PART D
(b) Fulfilment of the Plan cannot be foisted on an unwilling Applicant. This view of
the NCLT is consistent with the legal position which vests it with the power to permit
a withdrawal from a resolution plan for good and substantial reasons; and
(vii) The doctrine of res judicata does not bar the relief that Ebix had sought in its
Third Withdrawal Application of its Resolution Plan. The First Withdrawal
Application arose from a different cause of action, namely seeking information and
re-evaluation of the financial position of Educomp due to a lapse of time. The order
dated 10 July 2019 passed by the Adjudicating Authority in the First Withdrawal
Application had only adjudicated the issue relating to the non-disclosure of
information and material sought by Ebix, and had not considered the relief of
withdrawal of Resolution Plan. This was also confirmed in the express finding of the
Adjudicating Authority in its order dated 2 January 2020, which was appealed before
the NCLAT.
D.2     Submissions for the first respondent
83      Mr Shyam Divan, learned Senior Counsel appearing on behalf of E-CoC,
has urged the following submissions:Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

(i) Ebix submitted its Resolution Plan on 27 January 2018, after month-long
negotiations. Meetings between the E-CoC and Ebix were conducted on 17 February
2018, 19 February 2018 and 21 February 2018. Addendums were submitted on 21
February 2018. The mutually approved and PART D negotiated plan was put to vote,
and approved by 75.36 per cent of the E-
CoC. This constituted a binding contract between Ebix and the E-CoC;
(ii) The IBC is a complete code as held by this Court in M/s Embassy Property Developments Pvt.
Ltd. v. State of Karnataka & Ors.36 and M/s Innoventive Industries Ltd. v. ICICI Bank & Anr.37. It
does not envisage withdrawals of Resolution Plans after mutual negotiations between the Resolution
Applicant and the CoC, which culminates into a binding agreement. The Adjudicating Authority
cannot contravene the text to invoke the spirit/object of the IBC without a conscious statutory
prescription, as held by this Court in Gujarat Urja Vikas Nigam Limited v. Amit Gupta38;
(iii) The basic tenets of any insolvency law are to ensure the sanctity of the prescribed processes and
timelines. Maximization of the value of assets and resolution of the Corporate Debtor are the core
objectives of the IBC, as held by this Court in Swiss Ribbons (P) Ltd v. Union of India 39. Enabling
withdrawals, especially at the tail end of the process, would push financially distressed Corporate
Debtors into liquidation;
(iv) The Specific Relief (Amendment) Act 2018, as is evinced from the speech of the Union Minister
of Law & Justice before the Rajya Sabha while introducing the amendments, shifted the paradigm
on contract enforcement in India where specific performance is now the norm, rather than the
exception;
(2020) 13 SCC 308 (2018) 1 SCC 407 2021 SCCOnLine SC 194, para 181 (2019) 4 SCC 17, paras
27-28 PART D
(v) The resolution process involves significant public money, resources and time. Enabling
withdrawals would undermine the goals of predictability and finality, which the legislature had
recognized as the need of the hour in the Rajya Sabha debates on the IBC;
(vi) Non-implementation of Resolution Plans after approval from the Adjudicatory Authority under
Section 31 of the IBC, pertinently on a narrow scope of judicial review, is liable to criminal
prosecution under Section 74(3) of the IBC. This Court should not allow a successful Resolution
Applicant to withdraw from a duly concluded contract;
(vii) The consequences of permitting a withdrawal by Ebix would push Educomp towards
liquidation, which would risk thousands of crores of public monies owed to public sector banks
during the economic crisis caused by the COVID-19 pandemic;
(viii) Permitting withdrawal of an approved Resolution Plan would tread on the exclusive domain of
the CoC, which has the power to determine the feasibility and viability of a Resolution Plan. TheEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

mandate of Section 30(2)(d) of the IBC, which envisages ‘implementation and supervision of the
resolution plan’, would be breached if the Court would allow withdrawals by holding that an
unwilling Resolution Applicant would make a Resolution Plan itself un-implementable;
(ix) The scope of judicial review with the Adjudicatory Authority, under Section 31 of the IBC, is
confined to parameters delineated in Section 30(2), which does not envisage the withdrawal or
unwillingness of the Resolution Applicant to continue with a CoC-approved Resolution Plan. The
PART D Adjudicating Authority, as a creature of the statute, cannot exercise jurisdiction beyond the
scope of the IBC or second-guess the commercial wisdom of the CoC, as held by this Court in Essar
Steel (supra), after noting the observations of this Court in K Sashidhar (supra);
(x) The Supreme Court, in Essar Steel (supra) and K Sashidhar (supra), has held that the
Adjudicating Authority cannot trespass upon the majority decision of the CoC, except on the
grounds enumerated under Section 30(2)(a) to (e) of the IBC;
(xi) The provisions of the RFRP were designed to ensure predictability and finality. The provisions
which elucidated this aim were:
(a) Clause 1.13.5, which did not envisage any change or supplemental information to
the Resolution Plan, after the submission date;
(b) Clause 1.8.4, which stated that a submitted Resolution Plan shall be irrevocable;
and
(c) Clause 1.10(l), which stipulated that the Resolution Applicant will not be
permitted to withdraw the Resolution Plan;
(xii) The RFRP did not envisage six months to be the validity of the Resolution Plan.
Clause 1.8.3, which stipulated a minimum six-month validity of the Resolution Plan,
is relatable to the acceptance of the plan by the E-CoC and not the Adjudicating
Authority. This is evident from the clauses of the RFRP which stipulate that the
submitted plan is irrevocable;
(xiii) The resolution process belies the claim that withdrawals were permissible after
the six-month period. The process was delineated in the following terms:
PART D
(a) Clause 1.3.1 and 1.3.2 empowers the E-RP to issue an invitation to prospective
resolution applicants, subject to, inter alia, non-disclosure agreements and
participation fees;
(b) Clause 1.3.6, read with Clause 1.9.1, enables a party to submit a Resolution Plan
upon payment of an earnest money deposit of Rs 2 crore. Along with the ResolutionEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Plan, the Resolution Applicant was required to submit an undertaking accepting the
terms of the RFRP, including the minimum six-month period of Resolution Plan
validity;
(c) Clause 1.9.3, read with Clause 1.9.5, ensures that a CoC approved Resolution Plan
becomes a binding contract between the E-CoC and Ebix, since the earnest money
deposit needs to be replaced with a performance guarantee, which is 10 per cent of
the Resolution Plan value. Any violation of the concluded contract, which would be
the approved Resolution Plan in this case, would give the E-CoC the right to invoke
the performance guarantee;
(d) The above clauses, in addition to clause 1.8.3, read with 1.9.5, evince that the
six-month validity is with respect of the EMD alone, and is hence only related to a
period until acceptance by the E-CoC;
(e) The consequence of approval by the Adjudicating Authority under Section 31 of
the IBC is that the parties enter into definitive binding agreements, the
implementation of the Resolution Plan commences and the performance guarantee is
returned. A Section 31-approval binds all stakeholders to a concluded contract
between the Ebix and the E-CoC;
PART D
(f) The CoC or the RP do not have the authority to impose a time limit on the Adjudicating
Authority. Therefore, it would not be plausible to construe Clause 1.8.3 to impose a maximum
validity period on a Resolution Plan; and
(g) In any event, Ebix had waived the term of validity of the plan being six months by pursuing the
plan after six months, i.e., from August 2018 till reserving of orders by the Adjudicating Authority in
January 2019, and not raising any claims till July 2019. Therefore, Ebix is estopped from raising the
plea, after the purported expiry of the validity period;
(xiv) Clause 1.1.6 of the RFRP, which reiterated Section 31 of the IBC and states that the Resolution
Plan will be binding on all stakeholders only after the approval of the Adjudicating Authority, does
not militate against E- CoC’s proposition that the CoC-approved Resolution Plan is a concluded
contract. This is because:
(a) Section 30(4) of the IBC does not contemplate any statutory exit after the
approval of the Resolution Plan by the CoC, which determines its feasibility and
viability;
(b) Clause 1.1.6 paraphrases Section 31(1) of the IBC, which merely makes the
Resolution Plan binding on all other stakeholders. The Adjudicating Authority’s
approval under Section 31(1) amounts to a ‘super-added imprimatur’ to theEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

concluded terms between the CoC and the Successful Resolution Applicant; and
(c) A conjoint reading of Clause 1.1.6, along with Clause 1.8.4, which declares a
submitted Resolution Plan to be irrevocable, and Clause PART D 1.10(l), which
prohibits withdrawal of a submitted Resolution Plan, belies the claim that the
Resolution Plan is binding on the Successful Resolution Applicant only after approval
of the Adjudicating Authority;
(xv) The delay in the resolution process is not attributable to the E-CoC. It cannot be cited to allow
Ebix to withdraw from a legally binding plan;
(a) The E-CoC approved the submitted Resolution Plan within 270 days, and it was promptly filed
before the Adjudicating Authority in March 2018. The orders on the plan approval were reserved in
January 2019 and pronounced only in January 2020. The delay cannot be attributable to the E-CoC
or used to withdraw from a plan which provided a 90 per cent haircut; and
(b) actus curiae neminem gravabit, i.e., the act of Court shall harm no man, is a settled principle in
law;
(xvi) Ebix’s argument that the substratum or commercial viability has eroded due to the subsequent
circumstances is facetious since:
(a) Ebix had conducted its own due diligence, in accordance with the RFRP. Section
29 of the IBC also enabled the appellant to access to an IM on Educomp, which would
include all relevant information, including financial position and pending disputes.
Clause 1.13.7 of the RFRP also stipulates that failure to conduct adequate due
diligence is not a ground to relieve the Resolution Applicant from its obligations
under a submitted Resolution Plan;
(b) Ebix continued to be interested in Educomp as late as 1 June 2020, when it
addressed a letter stating that the software licenses for online PART D education,
issued by Educomp, have become even more relevant in the circumstances of the
pandemic;
(c) The Investigation Audit Application for investigations into the affairs of Educomp
was filed in May 2018 and disposed of by August 2018, which was prior to the
Adjudicating Authority reserving its orders on the Resolution Plan. In any event, no
such audit by the Special Investigation Team was undertaken;
(d) According to the information available with the E-CoC, the E-RP had provided all
the information available with Educomp regarding the CBI and SFIO investigations,
on a best effort basis. Additionally, Ebix was also appearing before the NCLT when
the E-CoC sought an investigation into the affairs of Educomp, as recorded in the
order of the NCLT dated 9 August 2018;Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

(e) Ebix had evaluated the business and business conduct of Educomp, before
submitting a Resolution Plan worth Rs 314 crores, against an admitted financial debt
worth Rs 3003 crores. This 90 per cent haircut indicates that the appellant was aware
of the conditions of Educomp;
and
(f) In any event, Section 32A of the IBC grants immunity to a Resolution Applicant from any
offences committed by the Corporate Debtor, prior to the commencement of the CIRP, and provides
certainty that the assets of the Corporate Debtor, as represented, would be available in the same
manner as at the time of submission of a Resolution Plan. Section 25(2)(j) of the IBC empowers and
obligates the RP to file PART D applications for avoidance of certain transactions, to protect the
interests of the Resolution Applicant; and (xvii) The Third Withdrawal Application is barred by res
judicata since the grounds raised by Ebix were rejected by the NCLT in the First Withdrawal
Application on 10 July 2019. The liberty granted by the NCLT to file a fresh application on 5
September 2019 was with respect to filing a proper pleading without defects, and not on merits. This
conditional liberty cannot be construed as a waiver of the objection of res judicata. In any event, the
issue of limited validity of the approved Resolution Plan and delay of seventeen months, is barred by
the principles of constructive res judicata. 84 In the alternative, if Ebix were to succeed before this
Court, the learned Senior Counsel on behalf of the E-CoC has prayed that this Court exercise its
powers under Article 142 of the Constitution of India, and extend the limitation period for
conducting the insolvency process by three to four months for a fresh process to be initiated, subject
to the consent of the E-CoC.
D.3     Submissions for the second respondent
85      Supporting the submissions of the E-CoC, Mr Nakul Dewan, learned
Senior Counsel, has appeared on behalf of the E-RP. He has submitted that:
(i) Upon the approval of a Resolution Plan by the CoC, a concluded contract comes
into existence between the Resolution Applicant and CoC. Any withdrawal of the
Resolution Plan would violate the concluded contract;
PART D
(ii) In the present case, Clauses 1.9.3 and 1.9.5, give the right to the E-CoC to invoke the PBG
submitted by Ebix if it attempts to renege from its contractual obligation to implement the
Resolution Plan;
(iii) The withdrawal would also be in violation of the objective of the IBC, as noted by this Court in
Swiss Ribbons (supra), which is to ensure the revival and continuation of the Corporate Debtor. The
withdrawal of the Resolution Plan at a belated stage, would lead to the Corporate Debtor going intoEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

liquidation;
(iv) The withdrawal of a Resolution Plan after its approval by the CoC is not contemplated by:
(a) The UNCITRAL Guide, according to which the role of judicial authorities is
limited to approving the Resolution Plan after ensuring that it was approved by the
CoC properly. It does not envisage that the role of the judicial authorities would
extend to questioning the commercial wisdom of the CoC, much less allow for the
withdrawal of the Resolution Plan at the behest of the Resolution Applicant;
(b) The BLRC Report: (1) notes that the UNCITRAL Guide was used as a benchmark
by Parliament while enacting the IBC; (2) opined that the CoC should be the driving
force behind the resolution of the Corporate Debtor; and (3) does not discuss the
withdrawal of a Resolution Plan;
(c) The UK Act does not allow for the withdrawal of a Resolution Plan and limits the
grounds of challenge. In Singapore, the Singapore Act allows challenges to the
Resolution Plan, without envisaging withdrawal;
PART D
(d) The Resolution Plan is a contract executed under the aegis of the IBC and hence the statute must
be interpreted so as to further its objectives. Reliance for this proposition is placed on the following
English decisions: (1) Allied Domecq (Holdings) Ltd v. Allied Domecq First Pension Trust Ltd40; (2)
Reinwood Ltd v. L Brown & Sons Ltd41; (3) Doleman v. Shaw42; and (4) Standard Life Assurance
Ltd v. Oak Dedicated Ltd43; and
(e) If the Parliament while enacting the IBC intended to permit the withdrawal of the Resolution
Plan after its approval by the CoC or NCLT, it would have provided for such an eventuality. Section
12A was inserted by amendment for situations involving a withdrawal from the CIRP. On the
contrary, Section 74 provides for penalties in case the Resolution Applicant does not comply with
the Resolution Plan;
(v) Ebix’s argument, that the RFRP which provides that the Resolution Plan must be approved
within six months would also include its approval by the Adjudicating Authority, is contrary to the
IBC since the parties, through an agreement, cannot impose a restriction/condition on a judicial
authority;
(vi) In any case, Ebix has actively pursued the Resolution Plan even after the period of six months by
communicating with the E-CoC/E-RP, arguing in its favor in the Approval Application and by
extending the EMD. The First Withdrawal Application was filed only on 5 July 2019, after the expiry
of [2008] Pens. L.R. 425, paras 24 and 38 [2008] 1 W.L.R. 696, paras 5 and 11 [2009] Bus. L.R.
1175, paras 40 and 56 [2008] EWHC 222 (Comm), para 16 PART D nearly one year from the expiry
of the period of six months on 19 August 2018;Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

(vii) The investigations by the SFIO and CBI were initiated after the filing of the Approval
Application before the NCLT. Since the E-RP was not aware of any discrepancies or illegalities
committed by the former management of Educomp, information about such activities could not
have been provided to intending Resolution Applicants under Section 29 of the IBC. Section 29 only
envisages that the RP will provide information to prospective Resolution Applicants on a best-effort
basis;
(viii) Ebix is a professional corporate entity, and through the express provisions of its own
Resolution Plan, has stated that it has significant previous experience in the revival of stressed
assets. Before submitting its Resolution Plan for Educomp, Ebix was provided access to the Virtual
Data Room by the E-RP and conducted its due diligence. Hence, it should not be allowed to seek a
withdrawal, by arguing that certain facts were not within its knowledge; and
(ix) In view of the decision of this court in Nagabhushanammal v. C Chandikeswaralingam44, the
Third Withdrawal Application was barred by the principles of res judicata since it sought the same
prayer which was raised in the First Withdrawal Application, and rejected by the NCLT in its order
dated 10 July 2019.
     (2016) 4 SCC 434, para 15
                                                                                 PART E
E          Submissions of counsel in the Kundan Care Appeal
E.1        Submissions for the appellant
86         Mr Ramji Srinivasan, learned Senior Counsel appearing on behalf of
Kundan Care, has urged the following submissions:
(i) The IBC vests the Adjudicating Authority with inherent powers to direct
withdrawal:
(a) Section 60(5)(c) of the IBC vests the Adjudicating Authority with wide powers and
jurisdiction to “entertain and dispose of any question of law or facts, arising out of or
in relation to” the CIRP. Rule 11 of the NCLT Rules 2016 also endows the NCLT with
inherent powers. This Court, in Gujarat Urja (supra), has held that disputes arising in
relation to insolvency can be adjudicated under Section 60(5)(c). Accordingly, theEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

dismissal of Kundan Care’s application on “lack of jurisdiction” is impermissible.
Declining to go into merits of its application amounts to an impermissible refusal to
exercise jurisdiction, as noted by this Court in National Thermal Power Corporation
Ltd. v. Siemens Atkeingesellschaft45;
(b) The NCLT erred in rejecting Kundan Care’s contention by confining its
jurisdiction to Section 31(1) of the IBC which specifically deals with approval or
rejection of Resolution Plans;
(c) The NCLAT incorrectly proceeded on the assumption that its powers in disposing
off Kundan Care’s application seeking withdrawal were circumscribed by Section
61(3) of the IBC, which concerns appeals against AIR 2007 SC 1491, para 5 PART E
approval of a Resolution Plan. Kundan Care sought to invoke jurisdiction under
Section 61(1) of the IBC which provides a right of appeal against any order of the
NCLT;
(d) The facts and circumstances, on the basis of which the ‘feasibility and viability’ of
the Resolution Plan were approved by the A-CoC in its commercial wisdom, have
changed. Since the edifice of the A-CoC’s satisfaction had altered, the NCLT has
power to look into the facts which warrant withdrawal or modification of the
Resolution Plan;
(e) The legislative background of Section 31 of the IBC does not contemplate
circumstances that could arise after submission of the Resolution Plan to the
Adjudicating Authority. The UNCITRAL Guide and the BLRC Report place the
viability of the Corporate Debtor at the heart of the insolvency process. The CIRP
mandates interests of stakeholders to be better preserved by reorganization than
liquidation. The BLRC Report was relied upon by this Court in K Sashidhar (supra) to
propound the principle of “commercial wisdom of the CoC” which the Adjudicating
Authority cannot interfere with as the creditors, as the loss-making party in the
insolvency, are best placed to determine the terms of the resolution. However, this
principle does not touch upon instances where there is a conflict between the CoC
and the Resolution Applicant where the latter will prima facie suffer a loss. The
Resolution Applicant has no stake in the process until their Plan is approved by the
NCLT and the probability of a complete loss, prior to the approval of the Plan, is
justiciable;
PART E
(f) The IBC contemplates strict timelines, and therefore did not envisage a scenario of withdrawal,
prior to approval of the Resolution Plan under Section 31(1) of the IBC. This Court, in Essar Steel
(supra), held that the 330-day outer limit is directory which has resulted in Kundan Care’s Plan
remaining pending before the NCLT for over a year, resulting in unviability and losses. Therefore,
Section 31 cannot be asserted while adjudicating a plea for withdrawal or modification of a plan dueEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

to intervening factors having a material adverse effect in this case;
(g) Kundan Care’s Resolution Plan was contingent on the continuance of the PPA with GUVNL. If
the contingency does not arise, the Plan would become impossible. This Plan was accepted by the
A-CoC on this contingency. Therefore, disabling withdrawals or modifications would in fact violate
the commercial wisdom of the A-CoC;
(h) The Resolution Plan has become unviable and impossible to implement. If mandatorily
implemented, Astonfield is bound to suffer losses and eventually declare itself insolvent. These
events hinder its effective implementation and warrant the Plan’s rejection by the A-CoC since the
first proviso of Section 31(1), read with Sub-section (2)(d) warrants a determination by the
Adjudicating Authority of the Resolution Plan’s effective implementation. The determination by the
Adjudicating Authority under Section 31(1) cannot be equated to that of a rubberstamp where a
holistic analysis is precluded;
(i) BLRC’s Interim Report of February 2015 mentions that ‘viability’ is determined by providing that
the cost of financial arrangement (resolution PART E amount invested by the Resolution
Application) should be lower than the Net Present Value of future cash flows of the Corporate
Debtor. In Kundan Care’s calculation, the computed Net Present Value for future cash flow of
Astonfield demonstrates loss and a potential repeated CIRP; and
(j) The proposition that a Resolution Plan approved by the CoC cannot be withdrawn or modified
under any circumstance, no matter the extent of impossibility or unviability that may have arisen
subsequently, is seriously flawed and is likely to lead to draconian and absurd consequences. In the
event that the basis of the Resolution Plan is completely eroded, a Resolution Applicant’s failure to
implement the Plan would invite penal prosecution under Section 74 of the IBC and a repeated
CIRP. This will discourage prospective Resolution Applicants from coming forward with their Plans
in the future, thus defeating the very purpose and object behind the IBC;
(ii) There is no concluded and binding contract between the Resolution Applicant and the CoC, prior
to approval by the Adjudicating Authority:
(a) There is no concluded contract between the Resolution Applicant and the CoC
until the NCLT approves of the same. Section 7 of the Contract Act requires the
acceptance of offer to be absolute, unconditional and unqualified. Clauses 1.1.9, 1.2,
1.9.4 and 2.2.6 of the RFRP record the fact that the Plan would be binding only after
the approval of the Adjudicating Authority;
(b) The RFRP is in the nature of an invitation to offer. Kundan Care’s Resolution Plan
is an offer that is made in pursuance of the RFRP. A PART E contract is concluded
and becomes binding between the parties, only upon the communication of its
acceptance under Regulation 39(5) of the CIRP Regulation, after the approval of the
Adjudicating Authority under Section 31 of the IBC. It would be incorrect to term it as
a concluded contract, since it would have unforeseeable public ramifications;Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

(c) Since there is no concluded contract, withdrawal of an offer prior to acceptance is a settled
principle in contract law and the Adjudicating Authority can give effect to this under Section 60(5)
of the IBC;
(d) Arguendo, if there is a concluded contract, it has become void under Sections 32 and 35 of the
Contract Act. Clause 1.8.3 of the RFRP provided that the Plan must be valid for not less than six
months. On this representation, Kundan Care prepared financial projections on the assumption that
they would take over the project on 1 January 2020 and make it operational by 1 April 2020. The
projections were based on the continuation of GUVNL’s PPA with Astonfield till 2037. Kundan Care
even furnished revised projections based on the assumption that they would be able to take over the
project by 30 September 2020 and make it operational by 1 January 2021. Owing to this delay,
Kundan Care had noted that its original projections for the year 2038 went from a cumulative profit
of Rs 886.53 lakhs to a cumulative loss of Rs 760.71 lakhs. The A- RP’s statement was recorded by
the NCLT on 20 February 2020 that Astonfield is incurring a daily loss of Rs 5 lakhs. This takes the
cumulative loss of Astonfield to Rs 1647.24 lakhs;
PART E
(e) Sl.No. 5.1 of Kundan Care’s Resolution Plan also clearly stated that they would be at liberty to
withdraw the Resolution Plan in the event that there is any change in the information provided in
the IM or new information is available, which constitutes a ‘material adverse change’. Kundan Care
contends that this was specifically introduced due to GUVNL’s attempts to terminate the PPA. The
A-CoC was not obligated to accept this provision in the Plan, but since it has, the provision must be
enforced;
(f) Withdrawal was necessitated because of uncertainty over the continuation of the sole contract of
Astonfield, deterioration of the assets of Astonfield owing to the floods in Gujarat, repudiation of
Astonfield’s insurance claim due to the alleged failure of the A-RP to provide supporting documents
and misrepresentation in respect of trade receivables towards non-availing the benefit of accelerated
depreciation; and
(g) Kundan Care had also demonstrated good faith since it sought to withdraw the Resolution Plan
on 17 December 2019, soon after GUVNL Appeal was listed before this Court. This interim
application for withdrawal was filed within a month of the A-RP submitting the plan to the
Adjudicating Authority. The NCLAT erred in noting that this was a ploy on behalf of Kundan Care to
frustrate the CIRP after pushing out all rivals during the bidding process;
(iii) Alternatively, the CoC-approved Resolution Plan is a contingent contract under Section 32 of
the Indian Contract Act:
PART E
(a) The contract has become void since the contingency of certainty of PPA with
GUVNL within a specified time through approval of the NCLT has becomeEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

impossible;
(b) GUVNL’s Appeal against the continuation of the PPA, resolved by this Court in
Gujarat Urja (supra), compounded by the COVID-19 pandemic and the lockdown, is
primarily responsible for the delay in the conclusion of the CIRP. The delay, as of 14
July 2021, in concluding the CIRP is 608 days. The CIRP costs (Rs 12 lakhs per
month approx.) are also increasing, which have to be borne entirely by Kundan Care.
The NCLT should have considered the alternative prayer of permission to
re-negotiate the financial proposal with the CIRP;
(c) The A-CoC’s approval through voting constitutes ‘provisional acceptance of offer’,
as was held analogously by this Court in Haridwar Singh v.
Bagun Sumbrui46 which held that the contract was not concluded in the absence of the
confirmation by the Government of the conditional acceptance by the Divisional Forest Officer. A
statutory reading of Resolution Plans as contingent contracts under Section 7 and 32 of the Contract
Act would align with the intention of the IBC in attracting investors to make offers as conditional
acceptance of the Plan, until it becomes binding upon approval under Section 31(1) of the IBC; and
(d) Only section 31(1) of the IBC makes the Resolution Plan binding on all stakeholders, including
the Resolution Applicant and the CoC. This view is bolstered by the fact that criminal sanctions for
non-implementation on a (1973) 3 SCC 889 PART E Resolution Applicant under Section 74(2) of the
IBC are applicable only after approval of the Resolution Plan under Section 31(1). Regulation 36-
A(7)(f) of the CIRP Regulations also states that the refundable deposit can be forfeited only in case
of discovery of any false information or record by the prospective Resolution Applicant. Regulation
36-B(4A) also states that the non-refundable deposit shall be forfeited only on failure to perform
after approval of the Plan under Section 31 of the IBC. The impugned judgement’s effect is to make
it binding prior to the Adjudicating Authority’s approval which does violence to the unambiguous
language of S.31(1). This is further supported by the provisions of the IBC as noted by this Court in
ArcelorMittal India Private Limited v. Satish Kumar Gupta 47, that disapproval by the CoC of a Plan
on the grounds of Section 29A of the IBC is still appealable by the Resolution Applicant before the
NCLT, and therefore an approved Plan by CoC can still be replaced by another Plan which has been
able to satisfy the criteria under section 29A before the NCLT. In other words, a Plan approved by
the CoC does not result in a concluded contract because it is replaceable by another party. 87 In the
course of the final stage of the hearings, Kundan Care submitted that it had mutually negotiated a
settlement with A-RP/A-CoC and requested the exercise of this Court’s powers under Article 142 of
the Constitution of India for a one-time relief of modification, which would enable them to arrive at
a mutually acceptable modification to the Resolution Plan.Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

                                                                             PART E
E.2     Submissions for the first respondent
88      Mr Nakul Dewan, learned Senior Counsel appeared on behalf of the A-RP
in the Kundan Care Appeal. He has also appeared on behalf of the E-RP in the Ebix Appeal, both
being collectively disposed of by this judgement. He has made the following submissions, in
addition to the arguments recorded above in the Ebix Appeal:
(i) There is no direct provision with respect to withdrawal of a Resolution Plan under
the IBC by a Resolution Applicant, once approved by the CoC.
Consequently, the Adjudicating or Appellate Authority has no jurisdiction to direct withdrawals or
modification of Resolution Plans;
(ii) Section 12 of the IBC provides for a time bound period of 180 days extendable up to 330 days for
the completion of the CIRP. Permitting the Resolution Applicant to withdraw the Resolution Plan
after the approval of the CoC sets at naught the entire time period subsumed in negotiating and
voting upon a Resolution Plan;
(iii) Kundan Care was permitted to submit its Resolution Plan in spite of a failure to submit an EOI
in time. Kundan Care was aware of the pending litigation regarding the continuance of the PPA with
GUVNL and had negotiated with the A-CoC on that basis. Yet, Kundan Care filed an application to
withdraw its Plan within a month of its approval and filing before the Adjudicating Authority. The
plea of withdrawal is an opportunistic tactic for re-negotiation;
(iv) Clause 1.8.4 of the RFRP stated that a submitted Resolution Plan shall be irrevocable. The
format of the cover letter annexed to the RFRP also PART E makes statements on the binding effect
of the submission and its irrevocability. The LOI issued by Kundan Care also states that the
Resolution Applicant will not be permitted to withdraw;
(v) Clause 1.6.2 of the RFRP explicitly stated that any ‘Condition Precedents’ to the Plan had to be
set out, for the CoC to specifically consider. Any walk-away conditions also had to be conspicuously
set out with a heading, and under a consolidated paragraph. Sl. No.5.1 of the Resolution Plan was
not set out in this format, which clearly evinces that it is being deployed as an afterthought to evade
the consequences of a submitted Resolution Plan. In any event, none of the claims of Kundan Care
constitute a material adverse change that they did not account for, after perusing the IM;
(vi) Sl.No. 5.1 of Kundan Care’s Resolution Plan was not introduced as a condition precedent to the
Resolution Plan. Sl.No. 12 of the Form H, that is required to be mandatorily submitted by the RP to
the Adjudicating Authority, as per Regulation 39(4) of the CIRP Regulations expressly stipulates
‘Conditionalities’ that need to be specified, for the benefit of the Adjudicating Authority. Attempts atEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

subsequent modification and withdrawal are not supported by the Resolution Plan, the RFRP or the
provisions of the IBC;
(vii) The CIRP costs currently stand at Rs 2.5 crore which Kundan Care had committed to paying in
full. As of 26 July 2021, the unpaid CIRP cost is Rs 1.66 crores which would probably be payable
from the pending insurance claim. A table detailing the financial health of Astonfield for the last
three PART E years was also annexed, to bolster the claim that financial health has improved and
profits can still be generated; and
(viii) The delay in approval of the Resolution Plan by the Adjudicating Authority is an imponderable
which cannot be used to resile from a binding contract. The delay is also not attributable to the A-RP
or the A-CoC.
E.3     Submissions for the second respondent
89      Mr V Giri, learned Senior Counsel appearing for EXIM Bank on behalf of
the A-CoC, has made the following submissions:
(i) A Resolution Plan approved by the CoC is submitted by the RP to the NCLT under Section 30(6)
of the IBC. Once the NCLT is satisfied that the Resolution Plan complies with the requirements of
Section 30(2), it grants its approval to the Plan, which becomes binding on all the stakeholders
involved in the Resolution Plan. Thus, in the above scheme of things, IBC does not contemplate
withdrawal of Resolution Plan once it has been approved by the CoC;
(ii) The penal provision under Section 74(3) is applicable to a successful Resolution Applicant as it is
a stakeholder in the CIRP. The existence of a penal provision indicates that the legislature intended
to deter and discourage withdrawals of Resolution Plans;
(iii) CIRP is a time bound process of 180 days, which can be further extended up to 330 days. If a
successful Resolution Applicant is allowed to withdraw its Resolution Plan, it will set the clock back
on the time spent on receiving PART E the Resolution Plan, evaluating it under Section 30(2) of the
IBC, putting it to vote before the CoC and finally obtaining its approval from the Adjudicating
Authority;
(iv) Withdrawal of the Resolution Plan at this stage would result in the failure of the CIRP and
Astonfield will go into liquidation. IBC envisages liquidation as the last resort;
(v) The process of issuing the RFRP and proposal of a Resolution Plan, and its subsequent approval
by the CoC is statutorily mandated. The formats of the documents underlying the CIRP process are
also provided by the statute and the Regulations made thereunder. There is some room for
maneuverability provided to the parties to negotiate the terms of the documents, however, that does
not make any difference to the statutorily prescribed nature of the documents; andEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

(vi) The approval of the Resolution Plan under Section 30(3) of the IBC by the CoC creates a binding
contract between the CoC and the successful Resolution Applicant because:
(a) The proposed Resolution Plan has been approved by the CoC and has been further
submitted before the NCLT by the RP;
(b) A Resolution Applicant is aware of the conditions stipulated under the IM and
conducts its own due diligence. It is given an opportunity to raise queries on the
information that is provided in the IM. Thus, once the Resolution Applicant decides
to submit a Resolution Plan and a substantial time and effort is spent by the RP and
the CoC in the process of finalizing and approving a Resolution Plan, it cannot simply
PART F withdraw the Resolution Plan without being subjected to necessary
consequences;
(c) The approval of the plan by the CoC indicates the ad idem between the parties to
enter into a contract. The resulting contract is conditional only upon the approval by
the NCLT;
(d) Pursuant to the approval of the Resolution Plan by the CoC, the CoC issues an
unconditional LOI to the successful Resolution Applicant stating that it has been
selected as the successful Resolution Applicant subject to the approval of the NCLT.
The successful Resolution Applicant accepts the LOI and submits a PBG. The
successful Resolution Applicant is required to state that the LOI is “accepted
unconditionally”. It is only after the LOI is unconditionally accepted by the successful
Resolution Applicant and the PBG is furnished, that the RP makes an application to
the NCLT for approval of the Resolution Plan; and
(e) Contracting parties cannot renege on their promise to perform the contract
without facing any consequences.
F       Submissions of counsel in the Seroco Appeal
F.1     Submissions for the appellant
90      Mr Tirth Nayak has made the following submissions on behalf of Seroco:
(i) The Resolution Plan was submitted on the basis of information that was provided
under the IM issued by the Arya-RP in August 2018. Over 18 PART F months have
passed since the Resolution Plan was submitted. The inordinate delay in the approval
of the Resolution Plan by the NCLT, along with the outbreak of COVID-19 pandemic,
has substantially affected the valuation of Arya Filaments, apart from impacting its
business operations and financial position. Thus, Seroco is entitled to re-evaluate and
modify the Resolution Plan based on such considerations;Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

(ii) The delay cannot be attributed to Seroco;
(iii) The value of assets and the working capital funds of Arya Filaments have
plummeted due to the losses that have occurred in the past eighteen months
rendering the implementation of the current Resolution Plan impossible, thereby
making it necessary to modify the Plan to suit the current circumstances;
(iv) Seroco was not made aware of the updated financial status of Arya Filaments. It
will be unjust if it is made to abide by a Resolution Plan that was submitted eighteen
months ago based on the IM that was issued over twenty-four months ago;
(v) Clause 5.3.2. of the BLRC Report provides that the “RP must provide the most
updated information about the entity as accurate as is reasonably possible to this
range of solution providers. In order to do this, the RP has to be able to verify claims
to liabilities as well as the assets disclosed by the entity. The RP has the power to
appoint whatever outside resources that she may require in order to carry out this
task including accounting and consulting services…”. Seroco cannot be expected to
make a huge PART F investment in Arya Filaments without being given information
on its current financial status;
(vi) Seroco is genuinely interested in investing in Arya Filaments, however, due to the
change in circumstances, it is incapable of paying the entire consideration as was
stipulated under the current Resolution Plan; and
(vii) A Resolution Plan is an offer under Section 2(a) of the Contract Act. The
Resolution Applicant becomes bound by the offer only if the Resolution Plan is
approved by the NCLT. At present, the Plan is still under the consideration of the
NCLT. Thus, Seroco can withdraw or seek modification of the Plan.
F.2 Submissions for the second and third respondents 91 Mr Jayant Mehta appearing on behalf of
the Arya-CoC, consisting of Kotak and UBIL, has supported the arguments of the E-CoC and A-CoC.
He has urged the following additional submissions:
(i) There is no scope for modification of a Resolution Plan, once it has been submitted
by the RP to the Adjudicating Authority, after voting by the CoC.
The only ground sought by Seroco for modification of the submitted Resolution Plan here is the
exigency that has arisen due to the pandemic. This is evinced from the fact that the application for
modification was made within 2 months of the outbreak of the pandemic;
(ii) The Resolution Plan of Seroco was approved by the Arya-CoC on 10 May 2019 and submitted to
the Adjudicating Authority for approval on 14 May PART F 2019. When Seroco filed their
application before the NCLT for modification of the Resolution Plan, Kotak and UBIL, by their
emails dated 13 July 2020 and 17 July 2020 respectively, had informed the Arya-RP that they recordEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

their disapproval for any such attempts at modification of the Resolution Plan which sought to
reduce the resolution amount payable to secured creditors by Rs 1.5 crore;
(iii) There has been no material change in the assets or valuation of Arya Filaments. Seventy-five per
cent of the funds were to be generated by Seroco by the sale of the Arya Filament’s assets; and
(iv) The following authorities were cited to elucidate on the power of the Adjudicating Authority,
which is tightly circumscribed by the IBC, and designed to uphold the commercial wisdom of the
CoC: K Sashidhar 48 (supra), Essar Steel49 (supra), Committee of Creditors AMTEK Auto Limited
Through Corporation Bank v. Dinkar T Venkatasubramanian & Ors.50, Kalparaj Dharamshi v.
Kotak Investment Advisors Ltd.51, Jaypee Kensington Boulevard Apartments Welfare Association &
Ors. v. NBCC (India) Ltd. & Ors.52 and Ghanashyam Mishra and Sons Private Limited through the
Authorized Signatory v. Edelweiss Asset Reconstruction Company Limited through the Director &
Ors.53 An appeal under Section 61(3) of IBC, is therefore not maintainable for a Resolution
Applicant seeking modification of its approved Resolution Plan. Paras 52-58, 62, 68, 65 Paras 65,
67, 69 and 88 (2021) 4 SCC 457 2021 SCC OnLine SC 204, para 143 2020 SCC OnLine SC 1192, para
170 2021 SCC OnLine SC 313, paras 55-57, 67, 77 PART G The Adjudicating Authority in allowing
any such modification, cannot do indirectly, what the statute does not permit it to do directly. 92
The rival submissions in the three appeals shall now be considered.
G      Purpose of a law on insolvency
93     An examination of the raison d’etre of the IBC must necessarily precede its
analytical interpretation. A purposive interpretation of the statute, as is argued by the contesting
parties, cannot be evinced without examining the aims and objectives of the legislation. The IBC was
introduced as a water-shed moment for insolvency law in India that consolidated processes under
several disparate statutes such as the 2013 Act, SICA, SARFAESI, Recovery of Debts Act, Presidency
Towns Insolvency Act 1909 and the Provincial Insolvency Act 1920, into a single code. A
comprehensive and time-bound framework was introduced with smooth transitions between
reorganization and liquidation, with an aim to inter alia maximize the value of assets of all persons
and balance the interest of all stakeholders54.
94 Before we analyse the framework of the statute, the UNCITRAL Guide, which was instructive for
the Indian experience on drafting the IBC55, provides some critical guidance on what an insolvency
law represents. Notably, the UNCITRAL Guide explicitly refrains from prescribing mandates for the
specific choices (procedural or substantive) that an insolvency law should provide. Statement of
Objects and Reasons, IBC, 2016 3.3.1, The report of the Bankruptcy Law Reforms Committee
Volume I: Rationale and Design (November 2015), available at
<https://ibbi.gov.in/BLRCReportVol1_04112015.pdf> accessed on 20 August 2021 PART G
Instead, it clarifies that each jurisdiction evolves its own insolvency regime based on its social,
political and economic goals. It notes56:Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

“15. Since an insolvency regime cannot fully protect the interests of all parties, some
of the key policy choices to be made when designing an insolvency law relate to
defining the broad goals of the law (rescuing businesses in financial difficulty,
protecting employment, protecting the interests of creditors, encouraging the
development of an entrepreneurial class) and achieving the desired balance between
the specific objectives identified above. Insolvency laws achieve that balance by
reapportioning the risks of insolvency in a way that suits a State’s economic, social
and political goals. As such, an insolvency law can have widespread effects in the
broader economy…..
[…]
17. There is no universal solution to the design of an insolvency law because States vary significantly
in their needs, as do their laws on other issues of key importance to insolvency, such as security
interests, property and contract rights, remedies and enforcement procedures. Although there may
be no universal solution, most insolvency laws address the range of issues raised by the key
objectives discussed above, albeit with different emphasis and focus. Some laws favour stronger
recognition and enforcement of creditor rights and commercial bargains in insolvency and give
creditors more control over the conduct of insolvency proceedings than the debtor (sometimes
referred to as “creditor-friendly” regimes). Other laws lean towards giving the debtor more control
over the proceedings (referred to as “debtor-friendly” regimes), while yet others seek to strike a
balance in the middle…..” (emphasis supplied) 95 With this legislative guidance from international
law, the BLRC was commissioned by the Government of India for submitting a report with
recommendations of reforms for the existing regime and a draft of the proposed Insolvency and
Bankruptcy Code. In November 2015, the BLRC Report Pgs 14-16 of the UNCITRAL Legislative
Guide to an Insolvency Law, available at
<https://uncitral.un.org/sites/uncitral.un.org/files/media-documents/uncitral/en/05-80722_ebook.pdf>
accessed on 20 August 2021 PART G published its report in two volumes, with the first volume57
delineating the rationale and the second volume providing the design of the proposed legislation. 96
The BLRC report noted that the insolvency regime was due for a major overhaul as the recovery
rates in India were among the lowest in the world58 and a revamped, coherent code was envisaged
with speed and predictability woven into its underlying design to ensure higher recovery rates and
immediate liquidation, in the event of a failed resolution. As noted by this Court in Essar Steel
(supra), the insolvency regime in India was overhauled after the provisions of SICA, SARFAESI and
Recovery of Debts Act, in spite of providing for expeditious determination, were used by defaulting
companies to enjoy extended moratorium periods and failure to enforce timelines meant legal
proceedings would drag on for years and not result in recovery of stressed assets59. Similarly, in its
observation on “Speed is of Essence”, the BLRC report elaborated the commercial purpose of a
revamped insolvency regime in the following terms60:
“Speed is of essence for the working of the bankruptcy code, for two reasons. First,
while the “calm period” can help keep an organisation afloat, without the full clarity
of ownership and control, significant decisions cannot be made. Without effective
leadership, the firm will tend to atrophy and fail. The longer the delay, the more likelyEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

it is that liquidation will be the only answer. Second, the liquidation value tends to go
down with time as many assets suffer from a high economic rate of depreciation.
From the viewpoint of creditors, a good realisation can generally be obtained if the
firm is sold as a going concern. Hence, when delays induce liquidation, there is value
destruction. Further, even in liquidation, the realisation is lower when there are
delays. Hence, delays cause value supra note 55 Executive Summary, BLRC Report,
supra note 55 Para 118, Essar Steel (supra) Executive Summary, BLRC Report, supra
note 55 PART G destruction. Thus, achieving a high recovery rate is primarily about
identifying and combating the sources of delay.” In identifying the sources of delay,
adjudicating mechanisms were identified as one of the two important sources of
delay which need to be equipped with the right resources. In order to respond to the
rapid changes in the economy, the BLRC report recommended the formation of an
IBBI which would function as a regulator and formulate regulations that dynamically
detail the procedural norms of the working of the IBC with the necessary immediacy.
It is also important for this Court, as a constitutional authority which determines
questions of law concerning the IBC framework, to note that a rapid liquidation may
sometimes be preferable to a protracted CIRP. This sentiment was stressed in the
BLRC Report, in its concluding statement in the Executive Summary, which noted:
“Conclusion The failure of some business plans is integral to the process of the
market economy. When business failure takes place, the best outcome for society is to
have a rapid re-negotiation between the financiers, to finance the going concern
using a new arrangement of liabilities and with a new management team. If this
cannot be done, the best outcome for society is a rapid liquidation. When such
arrangements can be put into place, the market process of creative destruction will
work smoothly, with greater competitive vigor and greater competition.
India is in the process of laying the foundations of a mature market economy. This
involves well drafted modern laws, that replace the laws of the preceding 100 years,
and high performance organisations which enforce these new laws. The Committee
has endeavored to provide one critical building block of this process, with a modern
insolvency and bankruptcy code, and the design of associated institutional
infrastructure which reduces delays and transaction costs. We hope that the
implementation of this report will increase GDP growth in India by fostering the
emergence of a modern credit market, and particularly the corporate bond market.
PART G GDP growth will accelerate when more credit is available to new firms
including firms which lack tangible capital. While many other things need to be done
in achieving a sound system of finance and firms, this is one critical building block of
that edifice.”
97 A reading together of the UNCITRAL Guide and the BLRC Report clarifies, in no uncertain
terms, that the procedure designed for the insolvency process is critical for allocating economic
coordination between the parties who partake in, or are bound by the process. This procedureEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

produces substantive rights and obligations. For instance, the composition of the CoC, the method
and percentage of its voting, the timelines for CIRP, the obligation on the RP to file specific forms
after every stage of the process and the obligation to explain to the Adjudicating Authority reasons
for any deviations from the timeline while submitting a Resolution Plan, and other such procedural
requirements create a mechanism which tightly structures the conduct of all participants in the
insolvency process. This process invariably has an impact on the conduct of the Resolution
Applicant who participates in the process and consents to be bound by the RFRP and the broader
insolvency framework. An analysis of the framework of the statute and regulations provides an
insight into the dynamic and comprehensive nature of the statute. Upholding the procedural design
and sanctity of the process is critical to its functioning. The interpretative task of the Adjudicating
Authority, Appellate Authority, and even this Court, must be cognizant of, and allied with that
objective. The UNCITRAL Guide has echoed PART G this position by noting the interplay between
the procedural design of the insolvency law and the corresponding institutional infrastructure by
observing61:
“27. While the institutional framework is not discussed in any detail in the Legislative
Guide, some of the issues are touched upon below. Notwithstanding the variety of
substantive issues that must be resolved, insolvency laws are highly procedural in
nature. The design of the procedural rules plays a critical role in determining how
roles are to be allocated between the various participants, in particular in terms of
decision-making. To the extent that the insolvency law places considerable
responsibility upon the institutional infrastructure to make key decisions, it is
essential that that infrastructure be sufficiently developed to enable the required
decisions to be made.”
98 Any claim seeking an exercise of the Adjudicating Authority’s residuary powers under Section
60(5)(c) of the IBC, the NCLT’s inherent powers under Rule 11 of the NCLT Rules 2016 or even the
powers of this Court under Article 142 of the Constitution must be closely scrutinized for broader
compliance with the insolvency framework and its underlying objective. The adjudicating
mechanisms which have been specifically created by the statute, have a narrowly defined role in the
process and must be circumspect in granting reliefs that may run counter to the timeliness and
predictability that is central to the IBC. Any judicial creation of a procedural or substantive remedy
that is not envisaged by the statute would not only violate the principle of separation of powers, but
also run the risk of altering the delicate coordination that is designed by the IBC framework and
have grave implications on the outcome of the CIRP, the economy of the country and the lives of the
workers and other allied parties who page 20, UNCITRAL Guide, supra note 56 PART H are
statutorily bound by the impact of a resolution or liquidation of a Corporate Debtor.
H     Nature of a Resolution Plan
99    Before we advert to whether withdrawals or modifications by successful
Resolution Applicants are permissible under the IBC, we must begin by understanding the nature of
a Resolution Plan. “Resolution Plan” has been defined in Section 5(26) of the IBC in the followingEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

terms:
“(26) “resolution plan” means a plan proposed by resolution applicant for insolvency
resolution of the corporate debtor as a going concern in accordance with Part II;
Explanation.—For the removal of doubts, it is hereby clarified that a resolution plan
may include provisions for the restructuring of the corporate debtor, including by
way of merger, amalgamation and demerger;” The Explanation to the provision was
added by the Insolvency and Bankruptcy Code (Amendment) Act 2019. Further, the
term “Resolution Applicant” was substituted for “any person” by the Insolvency and
Bankruptcy Code (Amendment) Act 2018.
100 The term “Resolution Applicant” has been defined in Section 5(25) of the IBC as
follows:
“(25) “resolution applicant” means a person, who individually or jointly with any
other person, submits a resolution plan to the resolution professional pursuant to the
invitation made under clause (h) of sub-section (2) of Section 25 or pursuant to
Section 54-K, as the case may be” PART H 101 The IBC provides a roadmap for the
entire CIRP in Chapter II of Part II.
This process is tightly regulated to include, inter alia, timelines of the CIRP specified by Section 12,
duties of the RP to provide adequate information to propose a Resolution Plan in Section 29 and
restrictions on who can be a Resolution Applicant in Section 29A. Thereafter, Section 30 provides
for the submission of a Resolution Plan, and it reads as follows:
“30. Submission of resolution plan.—(1) A resolution applicant may submit a
resolution plan along with an affidavit stating that he is eligible under Section 29-A to
the resolution professional prepared on the basis of the information memorandum.
(2) The resolution professional shall examine each resolution plan received by him to
confirm that each resolution plan—
(a) provides for the payment of insolvency resolution process costs in a manner
specified by the Board in priority to the payment of other debts of the corporate
debtor;
(b) provides for the payment of debts of operational creditors in such manner as may
be specified by the Board which shall not be less than—
(i) the amount to be paid to such creditors in the event of a liquidation of the
corporate debtor under Section 53; orEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

(ii) the amount that would have been paid to such creditors, if the amount to be
distributed under the resolution plan had been distributed in accordance with the
order of priority in sub-section (1) of Section 53, whichever is higher, and provides
for the payment of debts of financial creditors, who do not vote in favour of the
resolution plan, in such manner as may be specified by the Board, which shall not be
less than the amount to be paid to such creditors in accordance with sub-section (1)
of Section 53 in the event of a liquidation of the corporate debtor.
Explanation 1.—For the removal of doubts, it is hereby clarified that a distribution in accordance
with the provisions of this clause shall be fair and equitable to such creditors. Explanation 2.—For
the purposes of this clause, it is hereby declared that on and from the date of commencement of the
Insolvency and Bankruptcy Code (Amendment) Act, 2019, the PART H provisions of this clause
shall also apply to the corporate insolvency resolution process of a corporate debtor—
(i) where a resolution plan has not been approved or rejected by the Adjudicating Authority;
(ii) where an appeal has been preferred under Section 61 or Section 62 or such an appeal is not time
barred under any provision of law for the time being in force; or
(iii) where a legal proceeding has been initiated in any court against the decision of the Adjudicating
Authority in respect of a resolution plan;
(c) provides for the management of the affairs of the corporate debtor after approval of the
resolution plan;
(d) the implementation and supervision of the resolution plan;
(e) does not contravene any of the provisions of the law for the time being in force;
(f) conforms to such other requirements as may be specified by the Board.
Explanation.—For the purposes of clause (e), if any approval of shareholders is required under the
Companies Act, 2013 (18 of 2013) or any other law for the time being in force for the
implementation of actions under the resolution plan, such approval shall be deemed to have been
given and it shall not be a contravention of that Act or law.
(3) The resolution professional shall present to the committee of creditors for its approval such
resolution plans which confirm the conditions referred to in sub-section (2). (4) The committee of
creditors may approve a resolution plan by a vote of not less than sixty-six per cent of voting share of
the financial creditors, after considering its feasibility and viability the manner of distribution
proposed, which may take into account the order of priority amongst creditors as laid down in
sub-section (1) of Section 53, including the priority and value of the security interest of a secured
creditor, and such other requirements as may be specified by the Board:Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Provided that the committee of creditors shall not approve a resolution plan,
submitted before the commencement of the Insolvency and Bankruptcy Code
(Amendment) Ordinance, 2017, where the resolution applicant is ineligible under
Section 29-A and may require the resolution professional to invite a fresh resolution
plan where no other resolution plan is available with it:
PART H Provided further that where the resolution applicant referred to in the first
proviso is ineligible under clause (c) of Section 29-A, the resolution applicant shall be
allowed by the committee of creditors such period, not exceeding thirty days, to make
payment of overdue amounts in accordance with the proviso to clause (c) of Section
29-A:
Provided also that nothing in the second proviso shall be construed as extension of
period for the purposes of the proviso to sub-section (3) of Section 12, and the
corporate insolvency resolution process shall be completed within the period
specified in that sub-section.
Provided also that the eligibility criteria in Section 29-A as amended by the
Insolvency and Bankruptcy Code (Amendment) Ordinance, 2018 (Ord. 6 of 2018)
shall apply to the resolution applicant who has not submitted resolution plan as on
the date of commencement of the Insolvency and Bankruptcy Code (Amendment)
Ordinance, 2018.
(5) The resolution applicant may attend the meeting of the committee of creditors in
which the resolution plan of the applicant is considered:
Provided that the resolution applicant shall not have a right to vote at the meeting of
the committee of creditors unless such resolution applicant is also a financial
creditor.
(6) The resolution professional shall submit the resolution plan as approved by the
committee of creditors to the Adjudicating Authority.” Once a Resolution Applicant
submits a Resolution Plan under sub-Section (1) of Section 30, the RP must assess
whether it conforms with all the requirements of sub-Section (2). Having satisfied
itself, the RP under sub-Section (3) must then present those Resolution Plans to the
CoC which fulfill the criteria under sub-
Section (2). The CoC will then proceed to decide on the approval of the Resolution Plan, with a
majority vote of sixty-six percent, after satisfying itself that the requirements under sub-Section (4)
have been met, including testing the Resolution Plan for its feasibility and viability. A Resolution
Applicant may attend this meeting of the CoC under sub-Section (5), but it does not have a right to
vote PART H unless it is also a financial creditor. The Resolution Plan approved by the CoC under
sub-Section (4) is then placed by the RP before the Adjudicating Authority for its approval under
sub-Section (6).Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

102 Other than the IBC, the process is also regulated by the CIRP Regulations created under the
IBC. Regulation 37 provides an illustration of the solutions which can be proposed in a Resolution
Plan. Regulation 38 provides for the mandatory contents of a Resolution Plan, which are similar to
the pre-conditions mentioned in Section 30(2) of the IBC. Regulation 39 provides for the process of
approval of a Resolution Plan by the CoC, and under sub-Regulation (3), the CoC has to evaluate
every Resolution Plan based on an “evaluation matrix” it has come up with under Regulation 5(ha).
103 Having briefly taken an overview of the process, we now understand that there are broadly three
stages: (i) the first stage is prior to and ends with the approval of the Resolution Plan by the CoC; (ii)
the second stage is the interim period between the Resolution Plan’s approval by the CoC and before
its confirmation by the Adjudicating Authority; and (iii) the third stage is after the approval of the
Resolution Plan by the Adjudicating Authority. In the first stage, the relationship between the
parties is explicitly governed by the provisions of the IBC – such as the right of a prospective
Resolution Applicant to seek the IM and RFRP upon submission of its EOI, which may have been
rejected by the RP (as it happened in the Kundan Care Appeal). In the third stage, the same holds
true since Section 31(1) makes the Resolution Plan binding upon all the stakeholders and its
violation will attract a penalty under Section 74 of the IBC. However, what we are assessing right
now is the interim second stage between both of those. To PART H understand the relationship of
the parties therein, it becomes important to understand the exact “nature” of the Resolution Plan
after it has been submitted to the Adjudicating Authority and before it has been approved under
Section 31(1).
104 To summarize the arguments of the parties, the appellants have argued that Resolution Plans
are in the nature of an offer, which becomes binding as a concluded contract only once the
Adjudicating Authority has approved the Resolution Plan. Section 7 of the Contract Act requires the
acceptance of offer to be absolute, unconditional and unqualified. Since the approval by the CoC is
effectively conditional upon the confirmation of the Plan by the Adjudicating Authority, it cannot be
said that there is absolute acceptance of the Resolution Plan. Alternatively, it has been argued that
Resolution Plans approved by the CoC are contingent contracts, whose enforceability is conditional
upon the approval of the Adjudicating Authority in accordance with Section 32 of the Contract Act.
The Respondents (RPs and the CoCs) have argued that a concluded contract comes into being when
the Resolution Plan is approved by the CoC and a successful Resolution Applicant cannot renege
from their contractual obligation to implement the Resolution Plan. In furtherance of this argument,
Mr Shyam Divan appearing for the E-CoC made a reference to the Specific Relief (Amendment) Act
2018, which has brought a change to the regime on contract enforcement in India by making specific
performance the norm rather than the exception.
105 The determination of the nature of the Resolution Plan would help us establish the source of the
legal force of the Resolution Plan – whether it is the PART H statute, i.e., the IBC or the law of
contract. The insolvency process, as governed by the IBC, does not merely structure the conduct of
all the participants in the process after finalization and approval of a Resolution Plan by a CoC, but
also the conduct stemming from the very first steps of inviting prospective Resolution Applicants.
The RP, with the approval of the CoC62, invites prospective Resolution Applicants through an
RFRP. Once an unconditional EOI has been received from prospective Resolution Applicants whoEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

are otherwise eligible under Section 29A, the RP prepares an IM as per the provisions of Section 29
which furnishes all relevant information of the Corporate Debtor to enable prospective Resolution
Applicants to make an informed decision, before proposing a Resolution Plan. As a consequence of
the IBC and its regulations, prospective Resolution Applicants, who are not disqualified under
Section 29A, propose drafts of their Resolution Plans. The RP examines the Resolution Plan against
the contours of Section 30(2) and submits only the eligible plans to the CoC63. Prior to the IBBI
(CIRP) (Fourth Amendment) Regulations 2020, which now requires the CoC to vote on all Plans
simultaneously after recording its deliberations on the feasibility and viability of each Plan,
Regulation 39(3) earlier enabled the CoC to approve a Resolution Plan with “such modifications as it
deems fit”. This meant that the prospective Resolution Applicants and the CoC would indulge in
several rounds of negotiations, within a strict time-frame, to arrive at a mutually agreeable
Resolution Plan which was then subject to voting by the CoC. Subsequent to the voting, the RP
would submit the plan to the Adjudicating Authority along with receipt of the PBG and a compliance
certificate Section 25(2)(h), IBC Regulation 39(2), CIRP Regulations PART H in the form of Form
H. Each of the stages detailed above correspond to several rights and obligations on all parties that
are specifically created by the statute. 106 Since the interpretation of the IBBI (CIRP)(Fourth
Amendment) Regulations 2020 and the impact on the Resolution Applicants and the CoC to
negotiate the terms of the Resolution Plan is not before this Court and the present appeal essentially
seeks to determine the nature of the Resolution Plan after its approval by the CoC and prior to its
approval by the Adjudicating Authority, this Court will proceed to determine of the nature of such a
Plan, on the assumption of the law as it stood then, i.e., Regulation 39(3) which directed that “[t]he
committee shall evaluate the resolution plans received under sub-regulation (1) strictly as per the
evaluation matrix to identify the best resolution plan and may approve it with such modifications as
it deems fit”64. This power of the CoC to suggest modifications invariably entailed an element of
negotiation with the Resolution Applicants, who would make suitable revisions and re-submit their
Resolution Plans. The scope of a commercial bargain with the Resolution Applicants evinces a sense
of a negotiated agreement that is arrived between the parties, which resembles an exercise of
contractual freedom by the CoC and the Resolution Applicant.
107 If this court were to hold that CoC-approved Resolution Plans are indeed contracts, their
provisions would still have to conform to the statutory provisions of the IBC. However, such an
interpretation would entail that CoC-approved Resolution Plans are at the intersection of the IBC
and the Contract Act. This As substituted by the Notification No. IBBI/2018-19/GN/REG031, dated
3rd July, 2018 (w.e.f. 04-07-2018). Prior to this substitution, Regulation 39(3) stated “the
committee may approve any resolution plan with such modifications as it deems fit.” PART H would
mean that certain principles of contract law, for example those relating to discharge, penalties,
remedies and damages would become applicable to CoC- approved Resolution Plans. For instance,
in the United States, plans confirmed by courts have been characterized as contracts, whose breach
can even give rise to contractual remedies. In In re Hoffinger Indus, Inc65, a bankruptcy court in
Arkansas has held that “a confirmed plan should be enforceable and amenable to damages between
contractually bound parties.” Indeed, it has been argued before us that Resolution Plans should be
enforced through the contractual remedy of specific performance. Further, a determination that
Resolution Plans are contracts in the period between approval by the CoC and the approval of the
Adjudicating Authority would require us to analyse whether all elements of contract formation haveEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

been satisfied, including the question of whether the acceptance of the Resolution Plan by the CoC
fulfils the criteria laid down under Section 7 of the Contract Act or whether the conditionality of
seeking approval from the Adjudicating Authority makes the Resolution Plan a contingent contract.
Our intent of laying down the consequences of our determination of Resolution Plans as contracts is
to highlight the importance of ascertaining the nature of a CoC-approved Resolution Plan, prior to
its approval by the Adjudicating Authority. 108 The text of the IBC does not specify whether
Resolution Plans at the second stage of the process, i.e., in the intervening period of submission to
and approval by the Adjudicating Authority, are pure contracts. As noted previously, by
specifications such as eligibility for resolution applicants, the contents of the IM and duties of the
RP to prospective Resolution Applicants and statutory 327 B.R. 389 (Bankr. E.D. Ark. 2005), United
States Bankruptcy Court, E.D. Arkansas PART H procedures on timelines and voting, strictly govern
the insolvency process even prior to the submission of the Plan to the Adjudicating Authority. The
CoC, who the appellants allege is in the nature of a free contracting party, is governed by the binding
principles of the statute with regard to the contents and nature of the statutory plan that it approves
under Section 30(4) and even its own composition. 109 Section 30(4) provides that the consent of
all the members of the CoC, though a unanimous vote is not required and a sixty-six per cent vote is
sufficient for approval of a resolution plan. The constitution of the CoC is based on specific scenarios
envisaged in the statute and accounts for varying compositions, based on factors such as the nature
and quantum of debt owed. For example, if it comprises of operational creditors alone, the
percentage of debt owed between the operational and financial creditors and other such variables
impact voting thresholds inter se members of the CoC. A sixty-six per cent vote of the CoC is
required to approve a Resolution Plan. The dissenting creditors are deemed to have given their
approval and are bound by the decision of the majority of the CoC. The dissenting creditors are
bound as a result of the statutory provision and not because they have actually consented to be
parties to such an arrangement. Other elements governing the Resolution Plan indicate that the
entire process from initiation and leading up to its acceptance by the CoC takes place within the
framework of the IBC. In addition, the IBC provides penalties for non-compliance with the
Resolution Plan after its approval under Section 31 and forfeiture of the PBG for failing to
implement the Resolution Plan or contributing to the failure of its implementation. The violation of
the terms of the Resolution Plan does not give rise to a claim of damages, rather it leads to
prosecution and imposition of PART H punishment under Section 74 of the IBC. On the contrary, a
CoC’s withdrawal of the CIRP under Section 12A is coupled with a requirement of payment of CIRP
costs, but no damages are statutorily payable to the Resolution Applicant, irrespective of the stage of
the withdrawal.
110 The CoC even with the requisite majority, while approving the Resolution Plan must consider
the feasibility and viability of the Plan and the manner of distribution proposed, which may take into
account the order of priority amongst creditors as laid down in sub-section (1) of section 53 of the
IBC. The CoC cannot approve a Resolution Plan proposed by an applicant barred under Section 29A
of the IBC. Regulation 37 and 38 of the CIRP Regulations govern the contents of a Resolution Plan.
Furthermore, a Resolution Plan, if in compliance with the mandate of the IBC, cannot be rejected by
the Adjudicating Authority and becomes binding on its approval upon all stakeholders – including
the Central and State Government, local authorities to whom statutory dues are owed, operational
creditors who were not a part of the CoC and the workforce of the Corporate Debtor who would nowEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

be governed by a new management. Such features of a Resolution Plan, where a statute extensively
governs the form, mode, manner and effect of approval distinguishes it from a traditional contract,
specifically in its ability to bind those who have not consented to it. In the pure contractual realm, an
agreement binds parties who are privy to the contract. In the context of a resolution Plan governed
by the IBC, the element of privity becomes inapplicable once the Adjudicating Authority confirms
the Resolution Plan under Section 31(1) and declares it to be binding on all stakeholders, who are
not a part of the negotiation stage or parties to the Resolution Plan. In fact, a PART H commentator
has noted that the purpose of bankruptcy law is to actually solve a specific ‘contracting failure’ that
accompanies financial distress. Such a contracting failure arises because “financial distress involves
too many parties with strategic bargaining incentives and too many contingencies for the firm and
its creditors to define a set of rules of every scenario.” Thus, insolvency law recognizes that parties
can take benefit of such ‘incomplete contract’ to hold each other up for their individual gain. In an
attempt to solve the issue of incompleteness and the hold-up threat, the insolvency law provides
procedural protections i.e., “the law puts in place guardrails that give the parties room to bargain
while keeping them from taking position that veer toward extreme hold up”66.
111 It may be useful to refer to how this Court has analyzed instruments that are analogous to a
Resolution Plan. In SK Gupta v. KP Jain67, this Court while discussing the nature of compromise or
arrangements entered between a company and its creditors or members observed that such a
compromise or arrangement once sanctioned by the court is not merely an agreement between
parties because it binds even dissenting creditors or members through statutory force. This Court
made the following observations:
“12…The scheme when sanctioned does not merely operate as an agreement between
the parties but has statutory force and is binding not only on the company but even
dissenting creditors or members, as the case may be. The effect of the sanctioned
scheme is “to supply by recourse to the procedure thereby prescribed the absence of
that Anthony J. Casey, ‘Chapter 11’s Renegotiation Framework and the Purpose of
Corporate Bankruptcy’, Columbia Law Review Vol 120 No 7, available at
<https://columbialawreview.org/content/chapter-11s-
renegotiation-framework-and-the-purpose-of-corporate-bankruptcy/> accessed on 5
September 2021 (1979) 3 SCC 54 PART H individual agreement by every member of
the class to be bound by the scheme which would otherwise be necessary to give it
validity” [see J.K. (Bombay) Pvt. Ltd. v. New Kaiser-i-
Hind Spg. & Wvg. Co. Ltd. [AIR 1970 SC 1041 : (1969) 2 SCR 866, 891 : (1970) 40 Com Cas 689] ]..”
(emphasis supplied) 112 While the above observations were made in the context of a scheme that
has been sanctioned by the Court, the Resolution Plan even prior to the approval of the Adjudicating
Authority is binding inter se the CoC and the successful Resolution Applicant. The Resolution Plan
cannot be construed purely as a ‘contract’ governed by the Contract Act, in the period intervening its
acceptance by the CoC and the approval of the Adjudicating Authority. Even at that stage, its
binding effects are produced by the IBC framework. The BLRC Report mentions that “[w]hen 75% of
the creditors agree on a revival plan, this plan would be binding on all the remaining creditors”68.
The BLRC Report also mentions that, “the RP submits a binding agreement to the AdjudicatorEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

before the default maximum date”69. We have further discussed the statutory scheme of the IBC in
Sections I and J of this judgement to establish that a Resolution Plan is binding inter se the CoC and
the successful Resolution Applicant. Thus, the ability of the Resolution Plan to bind those who have
not consented to it, by way a statutory procedure, indicates that it is not a typical contract. 113 The
BLRC Report, which furnished the first draft of the IBC and elaborated on the aims behind the
overhaul of the insolvency regime, refers to a CoC- approved Resolution Plan as a ‘binding contract’
in one instance and refers to it as a ‘binding agreement’ in other instances. The report also refers to a
CoC-
Page 13, BLRC Report, supra note 55 Page 92, BLRC Report, supra note 55 PART H approved
Resolution Plan as a ‘financial arrangement’70, ‘revival plan’71 or a ‘solution’72. The
interchangeability of the terms – ‘agreement’, ‘contract’, ‘financial arrangement’, ‘revival plan’ and
‘solution’ indicates that there is no clear intention of the BLRC in characterizing the nature of the
Resolution Plan as a contract. The binding effect of the Resolution Plan has the consequence of
preventing the CoC or the Resolution Applicant to renege from its terms after the plan has been
approved by the CoC through a voting mechanism. The fleeting mention of a ‘binding contract’ on
one occasion in the BLRC Report (which was a pre- legislative text that underwent subsequent
modifications by the Legislature) to indicate the binding nature of the Resolution Plan and the
finality of negotiations once it is approved by the CoC, does not establish the legal nature of the
document, especially when it is not complemented by the text and design of the IBC.
114 Certain stages of the CIRP resemble the stages involved in the formation of a contract. Echoes of
the process involved in the formation of a contract resonate in the steps antecedent to the approval
of a Resolution Plan such as: (i) the issuance of an RFRP may be equated to an invitation to offer;
(ii) a Resolution Plan can be considered as a proposal or offer; and (iii) the approval by the CoC may
be similar to an acceptance of offer. The terms of the Resolution Plan contain a commercial bargain
between the CoC and Resolution Applicant. There is also an intention to create legal relations with
binding effect. However, it is the structure of the IBC which confers legal force on the CoC-approved
Page 21, BLRC Report, supra note 55 Page 13, BLRC Report, supra note 55 Pages 21, 75 and 126,
BLRC Report, supra note 55 PART H Resolution Plan. The validity of the Resolution Plan is not
premised upon the agreement or consent of those bound (although as a procedural step the IBC
requires sixty-six percent votes of creditors), but upon its compliance with the procedure stipulated
under the IBC.
115 It was argued for the E-RP that a Resolution Plan is a contract executed in furtherance of a
statutory regime under the IBC. A question arises whether a Resolution Plan can be classified as a
‘statutory contract’. This Court has defined a statutory contract in India Thermal Power Ltd. v. State
of MP73 in the following terms:
“11. Section 43 empowers the Electricity Board to enter into an arrangement for
purchase of electricity on such terms as may be agreed. Section 43-A(1) provides that
a generating company may enter into a contract for the sale of electricity generated
by it with the Electricity Board. As regards the determination of tariff for the sale of
electricity by a generating company to the Board, Section 43(1)(2) provides that theEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

tariff shall be determined in accordance with the norms regarding operation and
plant-load factor as may be laid down by the authority and in accordance with the
rates of depreciation and reasonable return and such other factors as may be
determined from time to time by the Central Government by a notification in the
Official Gazette. These provisions clearly indicate that the agreement can be on such
terms as may be agreed by the parties except that the tariff is to be determined in
accordance with the provision contained in Section 43-A(2) and notifications issued
thereunder. Merely because a contract is entered into in exercise of an enabling
power conferred by a statute that by itself cannot render the contract a statutory
contract. If entering into a contract containing the prescribed terms and conditions is
a must under the statute then that contract becomes a statutory contract. If a contract
incorporates certain terms and conditions in it which are statutory then the said
contract to that extent is statutory. A contract may contain certain other terms and
conditions which may not be of a statutory character and (2000) 3 SCC 379 PART H
which have been incorporated therein as a result of mutual agreement between the
parties. Therefore, the PPAs can be regarded as statutory only to the extent that they
contain provisions regarding determination of tariff and other statutory requirements
of Section 43-A(2)…” (emphasis supplied)
116 The above observations were in the context of a PPA entered into under the provisions of
Electricity Supply Act 1948. Section 43-A(1) of the Act stipulated that the generating company may
enter into a contract with the Electricity Board. Thus, the judgement pre-supposes the existence of a
subsisting contract. The controversy in the case was whether the PPA could be characterized as a
statutory contract. To say that a Resolution Plan is a statutory contract, we must first consider
whether the IBC envisages the CoC-approved Resolution Plan as a contract. There is no provision
under the IBC referring to a Resolution Plan as a contract, unlike Section 43-A(1) of the Electricity
Supply Act 1948 which mentions that a contract may be entered into between the concerned parties.
The legal force of a Resolution Plan arises due to the framework provided under the IBC. The
mechanisms of the IBC provide sufficient guidance on the conduct of all participants in the process
and the binding effect of the CoC- approved Resolution Plan is evidenced by the execution of a PBG
furnished by the successful Resolution Applicant, in compliance with the CIRP Regulations. This
PBG is returnable once the Adjudicating Authority approves the Resolution Plan under Section 31
and makes it binding on all stakeholders. Therefore, the IBC and its regulations institute sufficient
safeguards to ensure the binding effect of a CoC-approved Resolution Plan. In our discussion in
Sections I and J below, PART H we further elaborate on the nature of a CoC-approved Resolution
Plan and the code of conduct that is permissible by the statutory framework. 117 While insolvency
regimes are specific to each jurisdiction, it may be useful to analyze how Resolution Plans or similar
instruments are characterized in foreign jurisdictions.
118 Certain precedents from other jurisdictions have been cited by Mr Nakul Devan for the E-RP, to
argue that contracts entered into, in furtherance of a statutory regime have to be interpreted in
accordance with the objective and intent of the concerned statute. It has been submitted that the
Resolution Plan is one variety of such a statutory contract. However, since we have arrived at the
decision that Resolution Plans are not statutory contracts, it is not required for us to analyzeEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

whether terms of the Resolution Plan can be given effect to, as terms of a contract, as long as they
further the statutory objective. It is also important to note that India adopts a unique insolvency
framework where third-parties have the right to participate in an insolvency regime and acquire the
Corporate Debtor as a going concern. In several jurisdictions, the insolvency arrangements are
between the debtor and the creditors, which has a closer resemblance to ‘repayment plans’ by
corporate debtors, as envisaged by the IBC under Section 105 and broadly prescribed under Chapter
III as opposed to ‘resolution plans’ that are not proposed by debtors. In any event, an analysis of
such arrangements is detailed below.
119 In the United Kingdom, the UK Act allows the directors, administrator or liquidator of a
company to propose a company voluntary arrangement or a ‘CVA’ PART H (similar to Section 10 of
the IBC), which has to be approved by creditors having seventy-five per cent of the vote share.
Section 5(2)(b)74 of the UK Act provides that once the CVA is approved, the company and the
creditors are bound by it. Professor Roy Goode in his authoritative treatise Principles of Corporate
Insolvency Law75 observes that, “[t]he wording of s.5(2)(b), discussed below, has led the courts to
characterise the relationship between the parties to a CVA as essentially contractual in nature and
its scope and effect are determined by its terms, which fall to be interpreted by application of the
ordinary principles of contractual interpretation.” In some judgements of the Court of Appeal,
English Courts have held that a CVA creates a contractual obligation76, is a statutory contract77, or
has a contractual effect and is subject to ordinary principles of interpretation applying to
contracts78. However, the position on this issue is not completely settled. In a recent decision of the
High Court of Justice79, it was held that the CVA is not a contract. Crucially the court made the
following observations:
“83. Further, and as noted by Mr Pymont QC in SHB Realisations Ltd, a voluntary
arrangement is not formed or analysed as a contract. Certain legal principles
applicable to contracts, for example their interpretation, are applied to voluntary
arrangements; that is no less true of other instruments which are not contracts. Other
principles of contract law, for example those relating to penalties, are not applicable
to voluntary arrangements. Mr Pymont QC concluded that a voluntary arrangement
is not a contract.
“5 …(2) The voluntary arrangement— (b) binds every person who in accordance with
the rules — (i) was entitled to vote in the qualifying decision procedure by which the
creditors' decision to approve the voluntary arrangement was made, or (ii) would
have been so entitled if he had had notice of it — as if he were a party to the voluntary
arrangement.” Roy Goode, Principles of Corporate Insolvency Law (5th edn., Sweet
and Maxwell, 2018) Re TBL Realisations Plc, Oakley-Smith v Greenberg, [2004]
B.C.C. 81 (Court of Appeal) Tucker v Gold Fields Mining LCC, [2010] B.C.C. 544
(Court of Appeal) Heis v Financial Services Compensation Scheme Ltd, [2018] EWCA
Civ 1327 (Court of Appeal) Re Rhino Enterprises Properties Ltd. Schofield v Smith
[2020] EWHC 2370 (Ch).Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

PART H Characterising a CVA as a hypothetical agreement or by reference to a
statutory hypothesis neatly and accurately makes clear that a CVA is different from,
and is not in fact, a contract.” (emphasis supplied)
120 In Singapore, under Section 210 (3AA and 3AB) of the Singapore Act, a compromise or
arrangement between the company and its creditors becomes binding when the requisite majority of
creditors agree to it and it is approved by the court. The Singapore Court of Appeal has referred to
such a scheme of arrangement as a ‘contractual scheme’80. Subsequently, a controversy arose
before the Singapore Court of Appeal on whether a scheme can be substantially amended after it has
been approved by the court. The court observed that the answer to this question depends upon the
nature of schemes of arrangement; whether the schemes derived their efficacy from the order of the
court or the statute. The court observed that under the English approach81, a scheme approved by
the majority of the creditors derives its efficacy from the statute and is a statutory contract. Thus,
the court has a limited jurisdiction and cannot make substantial alterations to such a scheme.
However, the court noted that in Australia, the scheme operates as an order of the court. The court
held that its previous decision which referred to a scheme of arrangement as a ‘contractual scheme’
does not mean that in Singapore such schemes are considered as statutory contracts. The court
chose to follow the Australian approach holding that a scheme takes effect as an order of the court
and like any other court order, it can be altered, in certain circumstances. The court observed:
Daewoo Singapore Pte Ltd v CEL Tractors Private Limited, [2001] 4 SLR 35 (Court of
Appeal) Kempe and Another v. Ambassador Insurance Co., [1998] 1 W.L.R. 271 PART
H “66. ….We would also add, in respect of the latter concern, that a court order is in
no way less binding than a statutory contract on the parties to a scheme of
arrangement, and it is trite law as well as common sense that a court order cannot be
altered at will by the parties who are subject to the order….”
121 In Australia, as noted above, the scheme of arrangement operates as a court order82. The
Supreme Court of New South Wales, rejecting the English approach of characterizing schemes
(different from CVAs) as statutory contracts, observed:
“46..
[….]
(b) In Australia, [the] authorities [namely, Hill v Anderson Meat Industries Ltd
[1971] 1 NSWLR 868, Caratti and Bond Corp Holdings Ltd v Western Australia
(1992) 7 ACSR 472] establish that an approved scheme does indeed derive its force
from the court order, [and] not from the antecedent resolutions of members and
creditors.”
122 Under the United States Bankruptcy Code, a restructuring plan becomes binding once it is
confirmed by the court in terms of Section 1141. There are decisions of the bankruptcy courts in the
United States which indicate that such restructuring plans are characterized as contracts83. It hasEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

been held that a confirmed plan is binding on the debtor and the plan proponent and has the same
effect as contract84. However, commentators have noted that the United States Bankruptcy Code’s,
“embrace of a contractual paradigm is somewhat inconsistent…Both bankruptcy courts and the
Code itself are far more Caratti v Hillman [1974] WAR 92 (Supreme Court of Wester Australia) In re
Hoffinger Indus, Inc, 327 B.R. 389 (Bankr. E.D. Ark. 2005), United States Bankruptcy Court, E.D.
Arkansas In Re Shenandoah Realty Partners, L.P. v. Ascend Health Care, Inc, 287 BR 867 (US
Bankruptcy Court, WD) PART H sympathetic to ex post than to ex ante contracting”85. It has been
further observed that, “there are a few provisions in the Bankruptcy Code inviting parties to
“otherwise agree” by contract and in some contexts the Code explicitly overrides ex ante contracts”,
these include provisions of the Code overriding ipso facto clauses in pre-bankruptcy contracts which
stipulate that a necessary condition of default is filing of an insolvency or bankruptcy petition86. 123
The above discussion indicates the law in other jurisdictions, irrespective of differing frameworks, is
not completely settled on whether instruments akin to Resolution Plans are pure contracts. To
recapitulate, in the United Kingdom, while schemes of arrangement are characterized as statutory
contracts, the law on CVAs, which are similar to the insolvency process initiated under Section 10 of
the IBC, is not clear with the High Court of Justice noting that it is not a contract87, even though
principles of interpretation applicable to contracts may be used for constructing the language of
such CVAs. In Singapore, the English approach of denoting schemes as statutory contracts was
rejected and it was held that the schemes operate as orders of court. A similar position was taken
under the Australian law. The Singapore and Australian courts specifically indicate that schemes are
more than mere contracts with a “super-added imprimatur” by a court, rather they envisage an
active role to be played by court in supervising the schemes to the extent of making substantial
alterations to it, if required. In the United States, restructuring plans have been equated to David
Skeel and George Triantis, ‘Bankruptcy’s Uneasy Shift to a Contractual Paradigm’, Faculty
Scholarship at Penn Law, (2018), available at
<https://scholarship.law.upenn.edu/cgi/viewcontent.cgi?article=2993&context=faculty_scholarship>
accessed on 5 September 2021 Ibid.
Rhino supra note 78 PART H contracts, but as noted above there has been some inconsistency in
relation to upholding the contractual bargain.
124 The lack of an apparent international consensus on the issue of whether instruments like
CoC-approved Resolution Plans are contracts, prior to the Court’s sanction, is also attributable to
the peculiarity of the insolvency regime in each jurisdiction. This Court will have to be wary of
transplanting international doctrines that are evolved as responses to the specific features of a
jurisdiction’s insolvency regime, without identifying an analogous framework in our insolvency
regime.
125 The absence of any specific provision in the IBC or the regulations referring to a CoC-approved
Resolution Plan as a contract and the lack of clarity in the BLRC report regarding the nature of such
a Resolution Plan, constrains us from arriving at the conclusion that CoC-approved Resolution
Plans will be governed by the Contract Act and common law principles governing contracts, save
and except for the specific prohibitions and deeming fictions under the IBC. Regulation 39(3) of
CIRP regulations, as it stood before the IBBI (CIRP) (Fourth Amendment) Regulations 2020 andEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

applicable to the three appellants before us, enabled a framework where a draft Resolution Plan
would involve several rounds of negotiations and revisions between the Resolution Applicant and
the CoC, before it is approved by the latter and submitted to the Adjudicating Authority88.
However, this statutorily-enabled room for commercial negotiation is not enough to over-power the
other elements of regulation that detract from the view that “(3) The committee shall evaluate the
resolution plans received under sub-regulation (1) strictly as per the evaluation matrix to identify
the best resolution plan and may approve it with such modifications as it deems fit:
Provided that the committee shall record its deliberations on the feasibility and
viability of the resolution plans"
PART H CoC-approved Resolution Plans are contracts. CoC-approved Resolution
Plans, before the approval of the Adjudicating Authority under Section 31, are a
function and product of the IBC’s mechanisms. Their validity, nature, legal force and
content is regulated by the procedure laid down under the IBC, and not the Contract
Act. The voting by the CoC also occurs only after the RP has verified the contents of
the Resolution Plan and confirmed that it meets the conditions of the IBC and the
regulations therein. The amended Regulation 39(3)89 further regulates the conduct
of the CoC on voting on Resolution Plans and has introduced the requirement of
simultaneous voting. The IBBI’s Discussion Paper issued on 27 August 2021 has
invited comments on regulating the process on revisions that can be made to
resolution plans submitted to the CoC90. These developments bolster the conclusion
that the mechanism prior to submission of a CoC-approved resolution plan is subject
to continuous procedural scrutiny by the IBC and cannot be considered as a simple
contractual negotiation between two parties. Section J below details how a common
law remedies of withdrawal or modification on account of frustration or force
majeure are not applicable to CoC- approved Resolution Plans owing to the nature of
the IBC. Similarly, the whole host of remedies such as liquidated and unliquidated
damages, restitution, novation and frustration, unless specifically provided by the
IBC, are not available “39….(3)The committee shall-
(a) evaluate the resolution plans received under sub-regulation (2) as per evaluation
matrix; (b) record its deliberations on the feasibility and viability of each resolution
plan; and
(c) vote on all such resolution plans simultaneously. (3A) Where only one resolution
plan is put to vote, it shall be considered approved if it receives requisite votes. (3B)
Where two or more resolution plans are put to vote simultaneously, the resolution
plan, which receives the highest votes, but not less than requisite votes, shall be
considered as approved:
Provided that where two or more resolution plans receive equal votes, but not less
than requisite votes, the committee shall approve any one of them, as per the
tie-breaker formula announced before voting:Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Provided further that where none of the resolution plans receives requisite votes, the
committee shall again vote on the resolution plan that received the highest votes,
subject to the timelines under the Code……….” available at
<https://www.ibbi.gov.in/uploads/whatsnew/fbe59358a8c440d001f3b950be4a1c67.pdf>
accessed on 5 September 2021 PART H to a successful Resolution Applicant whose
Plan has been approved by the CoC and is awaiting the approval of the Adjudicating
Authority. The Insolvency Law Committee Report of February 2020 has
recommended the CIRP process to mandate Resolution Plans to provide for the
apportionment of the profit or loss accrued by the Corporate Debtor during the
CIRP91. These reports are periodically commissioned by the parliament to review the
functioning of the Code and suggest amendments. However, if the intention was to
view a CoC- approved Resolution Plan as a contract, the principles of unjust
enrichment would have been sufficient to address the issue and an amendment may
not be considered necessary. A Resolution Applicant, as a third party partaking in the
insolvency regime, seeks to acquire the business of the Corporate Debtor without the
entirety of its debts, statutory liabilities and avoiding certain transactions with third
parties. These benefits are a function of the coercive mechanisms of the IBC which
enable a third party to acquire the assets of a Corporate Debtor without its liabilities,
for a negotiated amount of the debt that is owed by the Corporate Debtor. Typically,
resolution amounts envisage payment of a fraction of debt that is owed to the
creditors and the business is acquired as a going concern with its employees. The
Resolution Plan is drafted in a way that it is implementable in the future and brings
about a quietus to the CIRP. Enabling Resolution Applicants to seek remedies that
are not specified by the IBC, by seeking recourse to the Contract Act would be
antithetical to the IBC’s insolvency regime. The elements of contractual
interpretation can be relied upon to construe the language of the terms of the
Resolution Plan, in the event of a dispute, but not to re-fashion and Pages 55-56,
Report of the Insolvency Law Committee (February 2020), Ministry of Corporate
Affairs, available at
<https://www.mca.gov.in/Ministry/pdf/ICLReport_05032020.pdf> accessed on 20
August 2021 PART H distort the mechanism of the IBC altogether. This Court in
Laxmi Pat Surana v. Union Bank of India92 has held that the IBC is a self-contained
Code. Thus, importing principles of any other law or a statute like the Contract Act
into the IBC regime would introduce unnecessary complexity into the working of the
IBC and may lead to protracted litigation on considerations that are alien to the IBC.
To give an example, the CoC can forfeit the PBG furnished by the successful
Resolution Applicant under certain circumstances in terms of the RFRP and
Resolution Plan including, inter alia, on the ground that the Resolution Applicant has
failed to implement the resolution or has contributed to its failure. Regulation 36B
(4A) of CIRP regulations provides for the furnishing of such performance security
once the plan is approved by creditors. The Regulations do not provide that the
performance security has to be a reasonable estimate of loss as is expected of penalty
clauses under contract law, rather the explanation provides that the performance
security should be of “such nature, value, duration and source, as may be specified inEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

the request for resolution plans with the approval of the committee, having regard to
the nature of resolution plan and business of the corporate debtor”. Further, in the
event that the CoC enters into a settlement with the Corporate Debtor and withdraws
from the CIRP under Section 12A, Regulation 30A provides for only payment of
insolvency costs and not compensation or damages to Resolution Applicant for
investing time and money in the process. The parties may resort to invoking
principles of frustration or force majeure to evade implementation of the Resolution
Plan leading to unnecessary litigation. This Court in Amtek Auto (supra), had curbed
a similar attempt by a (2020) SCC OnLine SC 1187 PART I successful Resolution
Applicant who had relied on a force majeure clause in its Resolution Plan to seek a
direction compelling the CoC to negotiate a modification to its Resolution Plan. The
Court held that there was no scope for negotiations between the parties once the
Resolution Plan has been approved by the CoC. Thus, contractual principles and
common law remedies, which do not find a tether in the wording or the intent of the
IBC, cannot be imported in the intervening period between the acceptance of the CoC
and the approval by the Adjudicating Authority. Principles of contractual
construction and interpretation may serve as interpretive aids, in the event of
ambiguity over the terms of a Resolution Plan. However, remedies that are specific to
the Contract Act cannot be applied, de hors the over-riding principles of the IBC.
I          Statutory framework governing the CIRP
126        The CIRP is a time bound process with a specific aim of maximizing the
value of assets. IBC and the regulations made under it lay down strict timelines which
need to be adhered to by all the parties, at all stages of the CIRP. The CIRP is
expected to be completed within 180 days under Section 12(1) of the IBC. In terms of
sub-Section (2) and (3) of Section 12, an extension can be sought from the
Adjudicating Authority for extending this period up to 90 days.
The first proviso to Section 12(3) clarifies that such an extension can only be granted once. In
Arcelor Mittal (India) (P) Ltd. v. Satish Kumar Gupta93, this Court had held that the time taken in
legal proceedings in relation to the CIRP must be excluded from the timeline mentioned in Section
12. Since this could (2019) 2 SCC 1, para 86 PART I extend the CIRP indefinitely, the Insolvency and
Bankruptcy Code (Amendment) Act 2019, inserted a second proviso to Section 12(3) with effect
from 16 August 2019 to state that the CIRP in its entirety must be mandatorily completed within
330 days from the insolvency commencement date, including the time taken in legal proceedings. A
legislative amendment that takes away the basis of a judicial finding is indicative of the strong
emphasis of the IBC on its timelines and its attempt to thwart the prospect of stakeholders engaging
in multiple litigations, solely with the intent of causing undue delay. Delays are also a cause of
concern because the liquidation value depletes rapidly, irrespective of the imposition of a
moratorium, and a delayed liquidation is harmful to the value of the Corporate Debtor, the recovery
rate of the CoC and consequentially, the economy at large. In Essar Steel (supra) a three judge
Bench of this Court, emphasized the rationale of the Insolvency and Bankruptcy Code (Amendment)Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Act 2019, which introduced the second proviso to Section 12(3). The court adverted to the BLRC
report which underscored delays in legal proceedings as the cause of the failure of the previous
insolvency regime under the SICA and the recovery mechanism in SARFAESI. It also extracted a
Speech of the Union Minister in the Rajya Sabha to explain the proposal for the amendment in 2019,
which was to avoid the same pitfalls in the IBC. The Court, speaking through Justice R F Nariman,
noted:
“119. The speech of the Hon'ble Minister on the floor of the House of the Rajya Sabha
also reflected the fact that with the passage of time the original intent of quick
resolution of stressed assets is getting diluted. It is therefore essential to have
time-bound decisions to reinstate this legislative intent. It was also pointed out on
the floor of the House that the experience in the working of the Code has not been
PART I encouraging. The Minister in her speech to the Rajya Sabha gives the
following facts and figures:
“Now, regarding the Corporate Insolvency Resolution Process (CIRP), under the
Code, I want to give you data again as of 30-6-2019. First, I will talk about the status
of CIRPs. Number of admitted cases is 2162; number of cases closed on appeal, which
I read out about, is 174; number of cases closed by withdrawal under Section 12-A, is
101, I have given you a slightly later data; number of cases closed by resolution is 120;
closed by liquidation, 475; and ongoing CIRPs are 1292.
So, now, I would like to mention the number of days of waiting. I would like to mention here the
details of the ongoing CIRPs, along with the timelines. Ongoing CIRPs are 1292, the figure just now
I gave you. Over 330 days, 335 cases; over 270 days, 445 cases; over 180 days and less than 270
days, 221 cases; over 90 days but less than 180 days, 349 cases; less than 90 days, 277 cases. The
number of days pending includes time, if any, excluded by the tribunals. So, that gives you a picture
on what is the kind of wait and, therefore, why we want to bring the amendments for this speeding
up.” […]
123. As the speech of the Hon'ble Minister on the floor of the House only indicates the object for
which the amendment was made and as it contains certain data which it is useful to advert to, we
take aid from the speech not in order to construe the amended Section 12, but only in order to
explain why the Amending Act of 2019 was brought about.” 127 The decision in Essar Steel (supra)
while reiterating the rationale of the IBC for ensuring timely resolution of stressed assets as a key
factor, had to defer to the principles of actus curiae neminem gravabit, i.e., no person should suffer
because of the fault of the court or the delay in the procedure. In spite of this Court’s precedents
which otherwise strike down provisions which interfere with a litigant’s fundamental right to
non-arbitrary treatment under Article 14 by mandatory conclusion of proceedings without providing
for any exceptions, this Court refused to strike down the second proviso to Section 12(3) in its
entirety. It noted that the previous statutory experiments for insolvency had failed because PART I
of delay as a result of extended legal proceedings and chose to only strike down the word
‘mandatorily’, keeping the rest of the provision intact. Therefore, the law as it stands, mandates the
conclusion of the CIRP – including time taken in legal proceedings, within 330 days with a shortEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

extension to be granted only in exceptional cases. However, the Court has warned that this
discretion must be exercised sparingly and only in the following situations:
“127…Thus, while leaving the provision otherwise intact, we strike down the word
“mandatorily” as being manifestly arbitrary under Article 14 of the Constitution of
India and as being an excessive and unreasonable restriction on the litigant's right to
carry on business under Article 19(1)(g) of the Constitution. The effect of this
declaration is that ordinarily the time taken in relation to the corporate resolution
process of the corporate debtor must be completed within the outer limit of 330 days
from the insolvency commencement date, including extensions and the time taken in
legal proceedings. However, on the facts of a given case, if it can be shown to the
Adjudicating Authority and/or Appellate Tribunal under the Code that only a short
period is left for completion of the insolvency resolution process beyond 330 days,
and that it would be in the interest of all stakeholders that the corporate debtor be
put back on its feet instead of being sent into liquidation and that the time taken in
legal proceedings is largely due to factors owing to which the fault cannot be ascribed
to the litigants before the Adjudicating Authority and/or Appellate Tribunal, the
delay or a large part thereof being attributable to the tardy process of the
Adjudicating Authority and/or the Appellate Tribunal itself, it may be open in such
cases for the Adjudicating Authority and/or Appellate Tribunal to extend time
beyond 330 days. Likewise, even under the newly added proviso to Section 12, if by
reason of all the aforesaid factors the grace period of 90 days from the date of
commencement of the Amending Act of 2019 is exceeded, there again a discretion
can be exercised by the Adjudicating Authority and/or Appellate Tribunal to further
extend time keeping the aforesaid parameters in mind. It is only in such exceptional
cases that time can be extended, the general rule being that 330 days is the outer
limit within which resolution of the stressed assets of the corporate debtor must take
place beyond which the corporate debtor is to be driven into liquidation.” PART I
128 The evolution of the IBC framework, through an interplay of legislative amendments,
regulations and judicial interpretation, consistently emphasizes the predictability and timeliness of
the IBC. The legislature and the IBBI have been proactive to introduce amendments to the
procedural framework, that respond to changes in the economy. For instance, Regulation 40(c),
which came into effect on 20 April 2020, was inserted in the CIRP Regulations to take into account
the delay that may be caused to the CIRP on account of the lockdown being imposed by the Central
Government due to the COVID-19 pandemic. Regulation 40(c) provides that the delay in completing
any activity related to the CIRP because of imposition of lockdown will not be counted for the
purposes of the timeline that has been stipulated under the statutory framework. If the CIRP is not
completed within the prescribed timeline, the Corporator Debtor is sent into liquidation. This
understanding of the evolution of the law is critical to our task of judicial interpretation. We cannot
afford to be swayed by abstract conceptions of equity and ‘contractual freedom’ of the parties to
freely negotiate terms of the Resolution Plan with unfettered discretion, that are not grounded in the
intent of the IBC. 129 The IBC and the regulations provide a detailed procedure for the completion
of CIRP. An application for initiation of CIRP is filed either by the financial creditor, operationalEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

creditor or the Corporate Debtor itself under Sections 7, 9 and 10 of the IBC, respectively. Once the
application is admitted by the Adjudicating Authority, it passes the following orders under Section
13(1) of the IBC: (i) declaration of a moratorium for the purposes referred to in Section 14 of the
IBC; (ii) causing a public announcement to be made for the initiation of CIRP and issuing a call for
submissions of claims as may be specified under PART I Section 15 of the IBC; and (iii) appointing
an IRP in accordance with Section 16 of the IBC.
130 Section 13(2) provides that the public announcement is to be made immediately after the
appointment of an IRP. The word ‘immediately’ here means not later than three days from the date
of appointment as provided in the explanation to Regulation 6(1) of the CIRP Regulations. Section
15 of the IBC lists down the information that should be included in the public announcement of
CIRP. It should specify the last date up to which the claims, i.e., a right of payment or right to
remedy as defined under Section 3(6) of the IBC, can be made by creditors, workmen and
employees. Regulation 6(2)(c) provides that the last date of submission of claims shall be fourteen
days from the date of appointment of the IRP. The public announcement also specifies the date on
which the CIRP shall close, which is the one hundred and eightieth day from the date of the
admission of the application under Sections 7, 9 or 10, as may be applicable. Regulation 6 of the
CIRP Regulations stipulates additional requirements relating to how the public announcement is to
made. 131 On receipt of claims from the operational creditors, financial creditors, workmen and
employees, the IRP prepares a list of creditors after verifying the claims. Regulation 13(1) provides
that the verification of all the claims is to be done within seven days from the last date of receipt of
the claims. Thereafter, the IRP constitutes a CoC in accordance with Section 21(1) of the IBC.
Regulation 17 of the CIRP Regulations stipulates that the IRP must submit a report certifying the
constitution of the CoC within two days of the claims being verified. The IRP is required to hold the
first meeting of the CoC within seven days of filing of the PART I report under the said regulation. If
the appointment of the RP by the CoC is delayed, the IRP is to perform the functions of the RP from
the fortieth day of the insolvency commencement date till the RP is appointed under Section 22 of
the IBC.
132 The CoC, in its first meeting, appoints the RP in terms of Section 22(2) of the IBC. Section 23(1)
provides that the RP is responsible for conducting the entire CIRP and managing the operations of
the Corporate Debtor during the CIRP period. The RP continues to manage the operations of the
Corporate Debtor after the expiry of CIRP period until an order approving the resolution is passed
by the Adjudicating Authority under Section 31(1) of the IBC or a liquidator is appointed under
Section 34 of the IBC. The intent of this Section is to ensure that the Corporate Debtor remains a
going concern until the Resolution Plan is approved by the Adjudicating Authority. The powers and
duties of the RP are listed under Section 23(2) of the IBC.
133 The significant, if not the most important, duty of the RP is to solicit Resolution Plans. The RP is
empowered to invite prospective Resolution Applicants who fulfil the criteria as laid down by the RP
and approved by the CoC, considering the complexity and the scale of the business operations of the
Corporate Debtor and other such conditions specified by the IBBI, to submit a Resolution Plan or
Plans under Section 25(2)(h) of the IBC. Further, a person should not be ineligible to be a
Resolution Applicant under Section 29A of the IBC. Section 5(25) defines a Resolution Applicant inEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

the following terms:
"resolution applicant" means a person, who individually or jointly with any other
person, submits a resolution plan to the PART I resolution professional pursuant to
the invitation made under clause (h) of sub-section (2) of section 25; or pursuant to
section 54K, as the case may be.”
134 The first step in the process of soliciting a Resolution Plan is the preparation of an IM
containing relevant information as specified by the IBBI for formulating a Resolution Plan in
accordance with Section 29(1) of the IBC. The contents of the IM are specified under Regulation
36(2) of the CIRP Regulations. Regulation 36(1) of the CIRP Regulations specifies the timelines
within which the RP must submit the IM to members of the CoC, which is within two weeks of his
appointment but not later than the fifty-fourth day from the insolvency commencement date,
whichever is earlier. Thereafter, the RP issues an invitation of EOI not later than the seventy-fifth
day from the insolvency commencement date to seek expressions of interest from eligible
prospective Resolution Applicants in terms of Regulation 36A of the CIRP Regulations. A
prospective Resolution Applicant is required to submit an unconditional EOI within the time
stipulated under the invitation, which shall not be less than fifteen days from the date of the issue of
invitation. The RP conducts a due diligence of the Resolution Applicant based on material available
on record in terms of Regulation 36A(8) of the CIRP Regulations. Thereafter, the RP issues a
provisional list of eligible prospective Resolution Applicants within ten days of the last date for
submission of EOIs to the CoC and to all the prospective Resolution Applicants who had submitted
the EOI. Regulation 36A also specifies the timeline within which any objection can be made against
the inclusion or exclusion of a prospective Resolution Applicant on the list, which is five days from
the issue of the list. The PART I RP is required to publish a final list of prospective Resolution
Applicants within ten days of the last date for the receipt of objections by the CoC. 135 Under
Regulation 36B of the CIRP Regulations, the RP has to issue the IM, evaluation matrix for
consideration of the Resolution Plan and an RFRP within five days of the date of issue of the
provisional list of Resolution Applicants to every prospective Resolution Applicant on the list and
any other prospective Resolution Applicants who have contested their non-inclusion in the list.
Regulation 36B stipulates that the RFRP shall contain detailed steps of each process and the manner
and purposes of interaction between the RP and the prospective resolution applicant along with the
corresponding timelines. A minimum of thirty days is given to the prospective Resolution Applicant
to submit a Resolution Plan. A Resolution Plan is defined under Section 5(26) of the IBC:
“resolution plan" means a plan proposed by resolution applicant for insolvency
resolution of the corporate debtor as a going concern in accordance with Part II;
Explanation.--For the removal of doubts, it is hereby clarified that a resolution plan
may include provisions for the restructuring of the corporate debtor, including by
way of merger, amalgamation and demerger;”
136 The timeline for the submission of Resolution Plans can be extended by an RP with the approval
of the CoC. The RFRP must require the resolution applicant to furnish a performance security inEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

case their Resolution Plan is approved by the CoC under Regulation 36B(4A). The performance
security shall stand forfeited if, after the approval of the Resolution Plan by the Adjudicating
Authority, the Resolution Applicant fails to implement or contributes to the failure of
implementation of the plan. Under the regulation, a performance security is PART I defined as
“security of such nature, value, duration and source, as may be specified in the request for resolution
plans with the approval of the committee, having regard to the nature of resolution plan and
business of the corporate debtor”. Regulations 37 and 38 list down the mandatory contents of the
Resolution Plan.
137 The RP is required to review the Resolution Plan submitted in terms of Section 30(2) of the IBC,
which provides that:
“Section 30 - Submission of resolution plan […] (2) The resolution professional shall
examine each resolution plan received by him to confirm that each resolution plan--
(a) provides for the payment of insolvency resolution process costs in a manner
specified by the Board in priority to the payment of other debts of the corporate
debtor;
(b) provides for the payment of debts of operational creditors in such manner as may
be specified by the Board which shall not be less than--
(i) the amount to be paid to such creditors in the event of a liquidation of the
corporate debtor under section 53; or
(ii) the amount that would have been paid to such creditors, if the amount to be
distributed under the resolution plan had been distributed in accordance with the
order of priority in sub-section (1) of section 53, whichever is higher and provides for
the payment of debts of financial creditors, who do not vote in favour of the
resolution plan, in such manner as may be specified by the Board, which shall not be
less than the amount to be paid to such creditors in accordance with sub-section (1)
of section 53 in the event of a liquidation of the corporate debtor.
Explanation 1.--For the removal of doubts, it is hereby clarified that a distribution in accordance
with the provisions of this clause shall be fair and equitable to such creditors. Explanation 2.--For
the purposes of this clause, it is hereby declared that on and from the date of commencement of the
Insolvency and Bankruptcy Code (Amendment) Act, 2019, the PART I provisions of this clause shall
also apply to the corporate insolvency resolution process of a corporate debtor--
(i) where a resolution plan has not been approved or rejected by the Adjudicating Authority;
(ii) where an appeal has been preferred under section 61 or section 62 or such an appeal is not time
barred under any provision of law for the time being in force; orEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

(iii) where a legal proceeding has been initiated in any court against the decision of the Adjudicating
Authority in respect of a resolution plan;
(c) provides for the management of the affairs of the Corporate debtor after approval of the
resolution plan;
(d) the implementation and supervision of the resolution plan;
(e) does not contravene any of the provisions of the law for the time being in force;
(f) conforms to such other requirements as may be specified by the Board.
Explanation.-- For the purposes of clause (e), if any approval of shareholders is required under the
Companies Act, 2013 (18 of 2013) or any other law for the time being in force for the
implementation of actions under the resolution plan, such approval shall be deemed to have been
given and it shall not be a contravention of that Act or law.” (emphasis supplied) Sub-Section (3) of
Section 30 of the IBC provides that the RP shall present Resolution Plans which conform to the
above requirements before the CoC for approval. Sub-Section (4) of Section 30 stipulates that the
CoC may approve a Resolution Plan by a vote of not less than sixty-six per cent after considering the
feasibility and viability of the plan and any such requirements specified by the IBBI.
138 The CoC has been given wide powers under the IBC. It can direct the Corporate Debtor into
liquidation any time before the approval by the Adjudicating PART I Authority, under Section 33(2)
of the IBC. Further, under Section 12A of the IBC the Adjudicating Authority may allow withdrawal
of the application submitted under Sections 7, 9 or 10 of the IBC for initiation of the CIRP (i.e.,
initiation of the CIRP by the financial creditor, operational creditor and the corporate applicant,
respectively) if the withdrawal is approved by ninety per cent of the voting share of the CoC. Dealing
with the question whether a successful Resolution Applicant can retreat through the route provided
under Section 12A of the IBC, a three- judge Bench of this Court in Maharashtra Seamless v.
Padmanabhan Venkatesh94 observed that, “[t]he exit route prescribed in Section 12A is not
applicable to a Resolution Applicant. The procedure envisaged in the said provision only applies to
applicants invoking Sections 7, 9 and 10 of the code”. However, this Court left the question whether
a successful Resolution Applicant “altogether forfeits their right to withdraw from such process
[CIRP] or not”, open for subsequent judicial determination95.
139 In terms of Regulation 39(4), the RP shall endeavour to submit the Resolution Plan approved by
the CoC before the Adjudicating Authority for its approval under Section 31 of the IBC, at least
fifteen days before the maximum period for completion of CIRP. Section 31(1) provides that the
Adjudicating Authority shall approve the Resolution Plan if it is satisfied that it complies with the
requirements set out under Section 30(2) of the IBC. Essentially, the Adjudicating Authority
functions as a check on the role of the RP to ensure compliance with Section 30(2) of the IBC and
satisfies itself that the plan (2020) 11 SCC 467 Para 29, Ibid.Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

PART I approved by the CoC can be effectively implemented as provided under the proviso to
Section 31(1) of the IBC. Once the Resolution Plan is approved by the Adjudicating Authority, it
becomes binding on the Corporate Debtor and its employees, members, creditors, guarantors and
other stakeholders involved in the Resolution Plan. Section 31(1) of the IBC is extracted below:
“Section 31 - Approval of resolution plan (1) If the Adjudicating Authority is satisfied
that the resolution plan as approved by the committee of creditors under sub-
section (4) of section 30 meets the requirements as referred to in sub-section (2) of section 30, it
shall by order approve the resolution plan which shall be binding on the corporate debtor and its
employees, members, creditors, including the Central Government, any State Government or any
local authority to whom a debt in respect of the payment of dues arising under any law for the time
being in force, such as authorities to whom statutory dues are owed, guarantors and other
stakeholders involved in the resolution plan. Provided that the Adjudicating Authority shall, before
passing an order for approval of resolution plan under this sub- section, satisfy that the resolution
plan has provisions for its effective implementation.” (emphasis supplied) A contravention of a
Resolution Plan binding under Section 31 is punishable under Section 74 (3) of the IBC. Section 74
(3) of the IBC provides thus:
“Section 74 - Punishment for contravention of moratorium or the resolution plan [….]
(3) Where the corporate debtor, any of its officers or creditors or any person on
whom the approved resolution plan is binding under section 31, knowingly and
wilfully contravenes any of the terms of such resolution plan or abets such
contravention, such corporate debtor, officer, creditor or person shall be punishable
with imprisonment of not less than one year, but may extend to five years, or with
fine which PART I shall not be less than one lakh rupees, but may extend to one crore
rupees, or with both.”
140 If the Resolution Plan is rejected by the Adjudicating Authority, the Corporate Debtor goes into
liquidation in accordance with Section 33(1) of the IBC. The order of the Adjudicating Authority
rejecting a Resolution Plan and directing liquidation under Section 33 of the IBC can be appealed
only on the grounds of material irregularity or fraud, as stipulated under Section 61(4) of the IBC.
The order of the Adjudicating Authority approving a Resolution Plan can be appealed before the
NCLAT under Section 61(3) of the IBC only on the grounds specified in that section. The grounds of
appeal are as follows:
“Section 61 - Appeals and Appellate Authority [….] (3) An appeal against an order
approving a resolution plan under section 31 may be filed on the following grounds,
namely:--
(i) the approved resolution plan is in contravention of the provisions of any law for
the time being in force;Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

(ii) there has been material irregularity in exercise of the powers by the resolution
professional during the corporate insolvency resolution period;
(iii) the debts owed to operational creditors of the corporate debtor have not been
provided for in the resolution plan in the manner specified by the Board;
(iv) the insolvency resolution process costs have not been provided for repayment in
priority to all other debts; or
(v) the resolution plan does not comply with any other criteria specified by the Board.
(4) An appeal against a liquidation order passed under section 33, or sub-section (4)
of section 54L, or sub-section (4) of section 54N, may be filed on grounds of material
irregularity or fraud committed in relation to such a liquidation order.” PART I
141 Under Regulation 39(5) of the CIRP Regulations, the RP is required to send a copy of the order
of the Adjudicating Authority accepting or rejecting the Resolution Plan on a ‘forthwith basis’.
Regulation 39(5A) specifies that within fifteen days of the date of the order of Adjudicating
Authority approving the Resolution Plan, the RP must inform each claimant about the principle or
formulae for the payment of debts under the Resolution Plan. 142 As noted above, Section 12 of the
IBC stipulates the timeline within which the CIRP is to be completed. The RP on the instructions of
the CoC may make an application for extension of the CIRP. Regulation 40A of the CIRP
Regulations provides a detailed model timeline for CIRP which accounts for all the procedural
eventualities that are permitted by the statute and the regulations. Regulation 40A is extracted
below:
“40-A. Model time-line for corporate insolvency resolution process.—The following
Table presents a model timeline of corporate insolvency resolution process on the
assumption that the interim resolution professional is appointed on the date of
commencement of the process and the time available is hundred and eighty days:
             Section/Regulation     Description of         Norm          Latest
                                      Activity                          Timeline
Section 16(1)         Commencement ….                          T
                                  of CIRP and
                                  appointment of
                                  IRP
            Regulation 6(1)       Public              Within 3 Days       T+3
                                  announcement        of Appointment
                                  inviting claims     of IRP
            Section              Submission         of For 14 Days       T+14
            15(1)(c)/Regulations claims                from
            6(2)(c) and 12 (1)                         Appointment of
                                                       IRPEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

                                                                   PART I
Regulation 12(2)    Submission       of Up to 90th day     T+90
                    claims              of
                                        commencement
Regulation 13(1)    Verification   of Within 7 days        T+21
                    claims received from the receipt
                    under             of the claim
Regulation 12(1)
                    Verification   of                      T+97
                    claims received
                    under
Regulation 12(2)
Section       21(6A) Application    for Within 2 days      T+23
(b)/Regulation 16-A appointment of from verification AR of claims received under
Regulation 17(1) Report certifying Regulation T+23 constitution of 12(1) CoC Section
1st meeting of Within 7 days of T+30] 22/Regulation 19(2) the CoC filing of the
report certifying constitution of the CoC, but with five days' notice.
Section 22(2)       Resolution to In   the   first         T+30
                    appoint RP by meeting of the
                    the CoC       CoC
Section 16(5)       Appointment      of On approval by     ……
                    RP                  the AA
Regulation 17(3)    IRP performs the    If RP is not       T+40
                    functions of RP     appointed by
                    till the RP is      40th day of
                    appointed.          commencement
Regulation 27       Appointment      of Within 7 days of   T+47]
                    valuer              appointment of
                                        RP, but not
                                        later than 47th
                                        day           of
                                        commencement
Section             Submission        of Before issue of    W
12(A)/Regulation    application      for EoI
                    withdrawal        ofEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

                                                                  PART I
30-A                application
                    admitted
                    CoC to dispose Within 7 days of       W+7
                    of the application its receipt or 7
                                       days          of
                                       constitution of
                                       CoC, whichever
                                       is later.
                    Filing application Within 3 days of   W+10
                    of withdrawal, if approval      by
                    approved        by CoC
                    CoC with 90%
                    majority voting,
                    by RP to AA
Regulation 35-A     RP to form an Within 75 days          T+75
                    opinion       on of       the
                    preferential and commencement
                    other
                    transactions
                    RP to make a Within       115         T+115
                    determination on days      of
                    preferential and commencement
                    other
                    transactions
                    RP      to    file Within   135       T+135
                    applications to days         of
                    AA             for commencement
                    appropriate relief
Regulation 36 (1)   Submission       of Within 2 weeks    T+54
                    IM to CoC           of appointment
                                        of RP, but not
                                        later than 54th
                                        day          of
                                        commencement
Regulation 36-A     Publish Form G      Within 75 days T+75
                                        of
                    Invitation of EoI   commencement
                    Submission       of At least 15       T+90
                    EoI                 days from issue
                                        of EoI (Assume
                                        15 days)
                    Provisional List Within 10 days       T+100Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

                    of RAs by RP     from the last
                                                                                   PART I
                                                         day of receipt
                                                         of EoI
                                   Submission       of For 5 days from     T+105
                                   objections       to the date of
                                   provisional list    provisional list
                                   Final List of RAs Within 10 days        T+115
                                   by RP             of the receipt of
                                                     objections
             Regulation 36-B       Issue of RFRP, Within 5 days of         T+105
                                   including      the issue of the
                                   Evaluation     provisional list
                                   Matrix and IM
                                   Receipt        of At least 30 T+135
                                   Resolution Plans days from issue
                                                     of      RFRP
                                                     (Assume     30
                                                     days)
             Regulation 39(4)      Submission    of As soon          as    T+165
                                   CoC approved approved             by
                                   Resolution Plan the CoC
                                   to AA
             Section 31(1)         Approval         of                     T=180
                                   resolution    plan
                                   by AA
AA: Adjudicating Authority; AR: Authorised Representative;
CIRP: Corporate Insolvency Resolution Process; CoC:
Committee of Creditors; EoI: Expression of Interest; IM:
Information Memorandum; IRP: Interim Resolution Professional; RA: Resolution
Applicant; RP: Resolution Professional; RFRP: Request for Resolution Plan.”
143 The statutory framework governing the CIRP seeks to create a mechanism for resolving
insolvency in an efficient, comprehensive and timely manner. The IBC provides a detailed linear
process for undertaking CIRP of the Corporate Debtor to minimize any delays, uncertainty in
procedure and disputes. The roles and responsibilities of the important actors in the CIRP areEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

clearly defined under PART I the IBC and its regulations. In Innoventive Industries Ltd v. ICICI
Bank96 a three judge Bench of this Court observed that “one of the important objectives of the Code
is to bring the insolvency law in India under a single unified umbrella with the object of speeding up
of the insolvency process”. Recently, in Gujarat Urja97 (supra) a three judge Bench of this Court
observed that a “delay in completion of the insolvency proceedings would diminish the value of the
debtor’s assets and hamper the prospects of a successful reorganization or liquidation. For the
success of an insolvency regime, it is necessary that insolvency proceedings are dealt with in a
timely, effective and efficient manner”. The stipulation of timelines and a detailed procedure under
the IBC ensures a timely completion of CIRP and introduces transparency, certainty and
predictability in the insolvency resolution process. The UNCITRAL Guide also states that the
insolvency law of a jurisdiction should be transparent and predictable. It notes the value of such
predictability in the following terms98:
“11. An insolvency law should be transparent and predictable. This will enable
potential lenders and creditors to understand how insolvency proceedings operate
and to assess the risk associated with their position as a creditor in the event of
insolvency. This will promote stability in commercial relations and foster lending and
investment at lower risk premiums. Transparency and predictability will also enable
creditors to clarify priorities, prevent disputes by providing a backdrop against which
relative rights and risks can be assessed and help define the limits of any discretion.
Unpredictable application of the insolvency law has the potential to undermine not
only the confidence of all participants in insolvency proceedings, but also their
willingness to make credit and other investment decisions prior to insolvency. As far
as possible, an insolvency law should clearly indicate all provisions of other laws that
may affect the conduct of the (2018) 1 SCC 407, para 13.
(2021) SCC OnLine 194, para 71.
Page 13, UNCITRAL Guide, supra 56 PART J insolvency proceedings (e.g. labour law; commercial
and contract law; tax law; laws affecting foreign exchange, netting and set-off and debt for equity
swaps; and even family and matrimonial law).” This Court should proceed with caution in
introducing any element in the insolvency process that may lead to unpredictability, delay and
complexity not contemplated by the legislature. With this birds’-eye view of the framework of
insolvency through the CIRP, we proceed to answer the question of law raised in this judgement -
whether a Resolution Applicant is entitled to withdraw or modify its Resolution Plan, once it has
been submitted by the Resolution Professional to the Adjudicating Authority and before it is
approved by the latter under Section 31(1) of the IBC.
J Withdrawal of the Resolution Plan by a successful Resolution Applicant under the IBC J.1 The
absence of a legislative hook or a regulatory tether to enable a withdrawal 144 The analysis of the
statutory framework governing the CIRP and periodic reports of the Insolvency Law Committee
indicates that it is a creditor-driven process. The aim of the process, in preferential order, is to: first,
enable resolution of the debt by maintaining the corporate debtor as a going concern, in order to
preserve the business and employment of the personnel; second, maximize the value of the assets ofEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

the corporate debtor and enable a higher pay-back to its creditors than under liquidation; and third,
enable a smoother and PART J faster transition to liquidation in the event that a time bound CIRP
fails, in a bid to avert further deterioration of value.
145 Since the aim of the statute is to preserve the interests of the corporate debtor and the CoC, it
was recognized that settlements between the corporate debtor and the CoC may be in the best
interests of all stakeholders since insolvency is averted. Two decisions of two judge Benches of this
Court, in Lokhandwala Kataria Construction (P) Ltd v. Nisus Finance and Investment Managers
LLP99 and Uttara Foods and Feeds (P) Ltd v. Mona Pharmachem100, (prior to the insertion of
Section 12A which enabled withdrawal of the CIRP on account of settlement between the parties),
had refused to effectuate this remedy by exercising inherent powers of the Adjudicating Authority
under Rule 11 of the NCLT Rules 2016 or the power of parties to make applications to the
Adjudicating Authority under Rule 8 of the Insolvency and Bankruptcy (Application to Adjudicating
Authority) Rules 2016. In Uttara Foods (supra) this Court had granted a one-time relief under
Article 142 of the Constitution since all the parties were present before it and had presented it with
signed consent terms. This course of action, in refraining from the exercise of inherent powers to
effect procedures and remedies that were not specifically envisaged by the statute, was explicitly
affirmed by the Insolvency Law Committee Report dated March 2018101 which proceeded to
suggest amendments to the IBC and recommended a ninety per cent voting threshold by the CoC for
withdrawals of a CIRP and a specific amendment to Rule 8 of the (2018) 15 SCC 589 (2018) 15 SCC
587 Pages 5 and 101, Report of the Insolvency Law Committee, Ministry of Corporate Affairs (March
2018) available at <https://ibbi.gov.in/uploads/resources/ILRReport2603_03042018.pdf>
accessed on 20 August 2021 PART J then existing CIRP Rules to enable parties to file such
applications. This report led to the insertion of Section 12A which vested the CoC with the power to
withdraw the CIRP or vote on such withdrawal, if sought by the Corporate Debtor. This provision
was introduced with retrospective effect on 6 June 2018. Significantly, no such exit routes have been
contemplated for the Resolution Applicant. It is relevant to note that the newly inserted and then
unamended Regulation 30A (w.e.f. 4 July 2018) of the CIRP Regulations stipulated that withdrawal
under Section 12A can be allowed through submitting an application to the IRP or RP (as the case
maybe) before the invitation for EOI is issued to the public. The CoC was to consider the application
within seven days of its constitution and an approval for such application required approval of the
ninety per cent of the voting share of the CoC. However, on 14 December 2018, a two judge Bench of
this Court, held in Brilliant Alloys (P) Ltd v. S Rajagopal102 that Regulation 30A is directory, and
not mandatory in nature since Section 12A of the IBC does not stipulate a deadline by which a
withdrawal from the CIRP can be made. Thus, in exceptional cases withdrawals from the CIRP
under Section 12A of IBC could be permitted even after the invitation of EOI has been issued.
Regulation 30A of the CIRP Regulations was then amended by the IBBI (Insolvency Resolution
Process for Corporate Persons) (Second Amendment) Regulations 2019, w.e.f. 25 July 2019 to
reiterate the decision of this Court. The newly amended provision allows for withdrawals even after
the invitation for expression of interest has been issued, provided that the applicant states the
reasons justifying such withdrawal. Similarly, on 25 January 2019, a two judge (2018) SCC OnLine
SC 3154 PART J Bench of this Court in Swiss Ribbons (supra) interpreted the true import of Section
12A and clarified that if the CoC is not yet constituted, a party can approach the Adjudicating
Authority, which may in exercise of its inherent powers under Rule 11 of the NCLT Rules 2016, allowEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

or reject an application for withdrawal or settlement. On 25 July 2019, the IBBI (Insolvency
Resolution Process for Corporate Persons) (Second Amendment) Regulations, 2019 amended
Regulation 30A in terms of this decision in interpreting Section 12A and now specifically provides
the procedure under the IBC that relates to affecting a withdrawal under Section 12A before the
constitution of the CoC. The applicant submits an application for withdrawal through the IRP,
directly before the Adjudicating Authority, since the CoC is not yet constituted to consider such an
application. To ensure that the process for withdrawal is timely and efficient, the present Regulation
30A provides that the IRP shall submit an application for withdrawal of the CIRP prior to the
constitution of the CoC to the Adjudicating Authority on behalf of the applicant within three days of
the receipt. Alternatively, if the application for withdrawal is made after the constitution of the CoC,
such application will be considered by the CoC within seven days of its receipt. If the CoC approves
such an application with ninety per cent voting share, it is to be submitted to the Adjudicating
Authority within three days of approval. Further, the application for withdrawal has to be
accompanied by a bank guarantee towards estimated expenses relating to costs of the IRP (in case of
a withdrawal prior to constitution of the CoC) or insolvency resolution process costs (where
withdrawal is after constitution of the CoC). It is clear that withdrawal of the CIRP is allowed only if
it upholds the interests of the CoC, is time-bound, and takes into PART J consideration how the
expenses relating to the insolvency process up to withdrawal shall be borne. Thus, even the exit
under Section 12A of the CoC, which is not available to the Resolution Applicant, is regulated by
procedural provisions indicating that the legislature has applied its mind to the timelines and costs
involved in the CIRP. Pertinently, the regulations do not provide for any costs that are payable to the
prospective Resolution Applicants or a successful Resolution Applicant, who must have incurred a
significant expense in participating in the process. This Court, in Maharashtra Seamless (supra) had
denied relief to a Resolution Applicant who had sought to invoke Section 12A to resile from its
Resolution Plan. The nature of the statute indicates the clarity of its purpose – primacy of the
interests of the creditors who are seeking to cut their losses through a CIRP. Traditional models and
understandings of equity or fairness that seek reliefs which are misaligned with the goals of the
statute and upset the economic coordination envisaged between the parties, cannot be read into the
statute through judicial interpretation. While parties have the freedom to negotiate certain
commercial terms of the Resolution Plan to gain wide support, their ability to negotiate is
circumscribed by the governing statute. A court cannot interpret the negotiated arrangements that
are represented in the Resolution Plan in a manner that hampers the objectives of the IBC which is a
speedy, predictable and timely resolution. The Resolution Applicant is deemed to be aware of the
IBC and its mechanisms before it steps into the fray and consents to be bound by its underlying
objectives. A Resolution Applicant, after obtaining the financial information of the Corporate Debtor
through the informational utilities and perusing the IM, is assumed to have analyzed the risks in the
business of the PART J Corporate Debtor and submitted a considered proposal. It cannot demand
vesting of certain powers and rights which have been conspicuously omitted by the legislature under
the statute, in furtherance of the policy objectives of the IBC. A court may not be able to lay down
such detailed guidance on how a mechanism for withdrawal, if any, may be provided to a successful
Resolution Applicant without disturbing the statutory timelines and adequately evaluating the
interests of creditors and other stakeholders, which is ultimately a matter of legislative policy. In
Essar Steel (supra), a three judge Bench of this Court, affirmed a two judge Bench decision in K
Sashidhar103(supra), prohibiting the Adjudicating Authority from second-guessing the commercialEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

wisdom of the parties or directing unilateral modification to the Resolution Plans104. These are
binding precedents. Absent a clear legislative provision, this court will not, by a process of
interpretation, confer on the Adjudicating Authority a power to direct an unwilling CoC to
re-negotiate a submitted Resolution Plan or agree to its withdrawal, at the behest of the Resolution
Applicant. The Adjudicating Authority can only direct the CoC to re-consider certain elements of the
Resolution Plan to ensure compliance under Section 30(2) of the IBC, before exercising its powers of
approval or rejection, as the case may be, under Section 31105. In Government of Andhra Pradesh v.
P Laxmi Devi106, while determining the constitutionality of a statute, this Court observed that it
should be wary of transgressing into the domain of the legislature, especially in matters relating to
economic and regulatory legislation. This Court observed:
Para 62, supra note 35 Paras 64-73, supra note 35 Para 73, Essar Steel supra note 34
(2008) 4 SCC 720 PART J “80. As regards economic and other regulatory legislation
judicial restraint must be observed by the court and greater latitude must be given to
the legislature while adjudging the constitutionality of the statute because the court
does not consist of economic or administrative experts. It has no expertise in these
matters, and in this age of specialisation when policies have to be laid down with
great care after consulting the specialists in the field, it will be wholly unwise for the
court to encroach into the domain of the executive or legislative (sic legislature) and
try to enforce its own views and perceptions.” (emphasis supplied)
146 Judicial restraint must not only be exercised while adjudicating upon the constitutionality of the
statute relating to economic policy but also in matters of interpretation of economic statutes, where
the interpretative maneuvers of the Court have an effect of transgressing into the law-making power
of the legislature and disturbing the delicate balance of separation of powers between the legislature
and the judiciary. Judicial restraint must be exercised in such cases as a matter of prudence, since
the court neither has the necessary expertise nor the power to hold consultations with stakeholders
or experts to decide the direction of economic policy. A court may be inept in laying down a detailed
procedure for exercise of the power of withdrawal or modification by a successful Resolution
Applicant without impacting the other procedural steps and the timelines under the IBC which are
sacrosanct. Thus, judicial restraint must be exercised while intervening in a law governing
substantive outcomes through procedure, such as the IBC. In this case, if Resolution Applicants are
permitted to seek modifications after subsequent negotiations or a withdrawal after a submission of
a Resolution Plan to the Adjudicating Authority as a matter of law, it would dictate the commercial
wisdom and bargaining strategies of all prospective Resolution PART J Applicants who are seeking
to participate in the process and the successful Resolution Applicants who may wish to negotiate a
better deal, owing to myriad factors that are peculiar to their own case. The broader legitimacy of
this course of action can be decided by the legislature alone, since any other course of action would
result in a flurry of litigation which would cause the delay that the IBC seeks to disavow.
147 The IBC is silent on whether a successful Resolution Applicant can withdraw its Resolution Plan.
However, the statutory framework laid down under the IBC and the CIRP Regulations provide a
step-by-step procedure which is to be followed from the initiation of CIRP to the approval by the
Adjudicating Authority. Regulation 40A describes a model-timeline for the CIRP that accounts forEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

every eventuality that may arise between the commencement of the CIRP and approval of the
Resolution Plan by the Adjudicating Authority, including the different stages for pressing a
withdrawal of the CIRP under Section 12A. Even a modification to the RFRP is envisaged by the
CIRP Rules and is subject to a timeline. The absence of any exit routes being stipulated under the
statute for a successful Resolution Applicant is indicative of the IBC’s proscription of any attempts at
withdrawal at its behest. The rule of casus omissus is an established rule of interpretation, which
provides that an omission in a statute cannot be supplied by judicial construction. Justice GP Singh
in his authoritative treatise, Principles of Statutory Interpretation107, defines the rule of casus
omissus as:
“It is an application of the same principle that a matter which should have been, but
has not been provided for in GP Singh, Principles of Statutory Interpretation (1st
edn., Lexis Nexis 2015) PART J a statute cannot be supplied by courts, as to do so will
be legislation and not construction. But there is no presumption that a casus omissus
exists and language permitting the court should avoid creating a casus omissus where
there is none.” (emphasis supplied) The treatise further discusses that a departure
from this rule is only allowed in cases where words have been accidently omitted or
the omission has an effect of making any part of the statute meaningless. Further,
only such words can be supplied to the statute which would have certainly been
inserted by the Parliament, had the omission come to its notice. The relevant
paragraph is extracted below:
“As already noticed it is not allowable to read words in a statute which are not there,
but “where the alternative lies between either supplying by implication words which
appear to have been accidentally omitted, or adopting a construction which deprives
certain existing words of all meaning, it is permissible to supply the words”. A
departure from the rule of literal construction may be legitimate so as to avoid any
part of the statute becoming meaningless. Words may also be read to give effect to
the intention of the Legislature which is apparent from the Act read as a whole.
Application of the mischief rule or purposive construction may also enable reading of
words by implication when there is no doubt about the purpose which the Parliament
intended to achieve. But before any words are read to repair an omission in the Act, it
should be possible to state with certainty that these or similar words would have been
inserted by the draftsman and approved by Parliament had their attention been
drawn to the omission before the Bill passed into law.” In the wake of the COVID-19
pandemic, several Resolution Plans remained pending before Adjudicating
Authorities due to the lockdown and significant barriers to securing a hearing. An
Ordinance was swiftly promulgated on 5 June 2020 which imposed a temporary
suspension of initiation of CIRP under Sections PART J 7, 9 and 10 of the IBC for
defaults arising for six months from 25 March 2020 (extendable by one year). This
was followed by an amendment through the IBC (Second Amendment) Act 2020 on
23 September 2020 which provided for a carve-out for the purpose of defaults arising
during the suspended period. The delays on account of the lockdown were also
mitigated by the IBBI (Insolvency Resolution Process for Corporate Persons) (ThirdEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Amendment) Regulations 2020, which inserted Regulation 40C on 20 April 2020,
with effect from 29 March 2020, and excluded such delays for the purposes of
adherence to the otherwise strict timeline. Recently, the IBC (Amendment)
Ordinance 2021 was promulgated with effect from 04 April 2021 providing certain
directions to preserve businesses of MSMEs and a fast-track insolvency process.
There has been a clamor on behalf of successful Resolution Applicants who no longer
wish to abide by the terms of their submitted Resolution Plans that are pending
approval under Section 31, on account of the economic slowdown that impacted every
business in the country. However, no legislative relief for enabling withdrawals or re-
negotiations has been provided, in the last eighteen months. In the absence of any
provision under the IBC allowing for withdrawal of the Resolution Plan by a
successful Resolution Applicant, vesting the Resolution Applicant with such a relief
through a process of judicial interpretation would be impermissible. Such a judicial
exercise would bring in the evils which the IBC sought to obviate through the
back-door.
148 It is pertinent to note that even the UNCITRAL Guide does not contain any provisions for
withdrawal of a submitted Plan. It only discusses the possibilities of amending a Resolution Plan.
The UNCITRAL Guide indicates that it PART J contemplates that the Legislature should choose if it
wants to allow any amendments to a submitted Resolution Plan. In the event, it does, it should lay
down the detailed steps of proposing amendments to a submitted resolution plan108. In fact, even
the scope of negotiations between the Resolution Applicant and the CoC has to be specifically
envisaged by the statute109. Further, the UNCITRAL Guide envisages that amendments can be
made to the Resolution Plan after it is approved by the creditors only in limited circumstances. It
mentions that, “[a]n insolvency law may include limited provision for a plan to be modified after it
has been approved by creditors (and both before and after confirmation) if its implementation
breaks down or it is found to be incapable of performance, whether in whole or in part, and the
specific problem can be remedied”110. If permitted by the statute, the recommendations strongly
urge the establishment of a mechanism for amendment after approval by creditors which details
requirements of, inter alia, approval by creditors of the modification and consequences of failure to
secure approval to the amendments111. The BLRC Report has relied on the UNCITRAL Guide while
designing the IBC112 and it is a critical tool for ascertaining legislative choice and intent. Parliament
has not introduced an explicit provision under the IBC for allowing any amendment of the
Resolution Plan after approval of creditors, let alone a power to withdraw the IV.A.52., page 225,
and Recommendation 155: “155. The insolvency law should permit amendment of a plan and specify
the parties that may propose amendments and the time at which the plan may be amended,
including between submission and approval, approval and confirmation, after confirmation and
during implementation, where the proceedings remain open.” of the UNCITRAL Guide, supra note
56 Ibid.
IV. A. 66, page 230 of the UNCITRAL Guide, supra note 56 Recommendation 156: “The insolvency
law should establish the mechanism for approval of amendments to a plan that has been approved
by creditors. That mechanism should require notice to be given to the creditors and other parties
affected by the proposed modification; specify the party required to give notice; require the approvalEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

of creditors and other parties affected by the modification; and require the rules for confirmation
(where confirmation is required) to be satisfied. The insolvency law should also specify the
consequences of failure to secure approval of proposed amendments.”, UNCITRAL Guide, supra
note 56 3.3.1, supra note 55 PART J Resolution Plan at that stage. At the same time, the Corporate
Debtor and the CoC have been empowered to withdraw from the CIRP. If it intended to permit
parties to amend the Resolution Plan after submission to the Adjudicating Authority, based on its
specific terms of the Resolution Plan, it would have adopted the critical safeguards highlighted by
the UNCITRAL. J.2 Terms of the Resolution Plan are not sufficient to effect withdrawals or
modifications after its submission to the Adjudicating Authority 149 It has been contended by the
three appellants that a Resolution Plan only becomes binding when it is approved by the
Adjudicating Authority under Section 31(1) of the IBC. Further, since Section 74(3) of the IBC,
provides that a person can be prosecuted or punished for contravening the Resolution Plan only
after its approval by the Adjudicating Authority, the successful Resolution Applicant is entitled to
withdraw the Plan, on the terms of its contractual provisions, as long as it is not made binding under
Section 31(1) of the IBC. We have held in Section H that a CoC-approved Resolution Plan is a
creature of the IBC and cannot be construed as a pure contract between two consenting parties,
prior to its approval under Section 31 of the IBC. In this section, independent of the above finding,
we proceed to examine the contention that the terms of a Resolution Plan can reserve the right to
modify or withdraw its contents after submission to the Adjudicating Authority.
150 The approval of the Adjudicating Authority under Section 31(1) of the IBC has the effect of
making the Resolution Plan binding on all stakeholders. These PART J stakeholders include the
employees of the corporate debtor whose terms of employment would be governed by the
Resolution Plan, the Central and State Governments who would receive their tax dues on the basis
of the terms of the Resolution Plan and local authorities to whom dues are owed. These stakeholders
are not direct participants in the CIRP but are bound by its consequence by virtue of the approval of
the Resolution Plan, under Section 31(1) of the IBC. Section 31(1) ensures that the Resolution Plan
becomes binding on all stakeholders after it is approved by the Adjudicating Authority. The
language of Section 31(1) cannot be construed to mean that a Resolution Plan is indeterminate or
open to withdrawal or modification until it is approved by the Adjudicating Authority or that it is not
binding between the CoC and the successful Resolution Applicant. Regulation 39(4) of CIRP
Regulations mandates that the RP should endeavour to submit the Plan at least fifteen days before
the statutory period of the CIRP under Section 12 is due to expire along with a receipt of a PBG and
a compliance certificate as Form H. It is pertinent to note that sub-Section (3) to Section 12
mandates that the CIRP process, including legal proceedings, must be concluded within 330 days.
This three-hundred-and- thirty-day period can be extended only in exceptional circumstances, if the
process is at near conclusion and serves the object of the IBC, as held by a three judge Bench of this
Court in Essar Steel (supra). Therefore, after accounting for all statutorily envisaged delays which
the RP has to explain in its Form H and otherwise through Regulation 40B, the procedure envisages
a fifteen-day window between submission of Resolution Plan and its approval or rejection by the
Adjudicating Authority. This clearly indicates that the statute envisages a certain PART J level of
finality before the Resolution Plan is submitted for approval to the Adjudicating Authority. Even the
CoC is not permitted to approve multiple Resolution Plans or solicit EOIs after submission of a
Resolution Plan to the Adjudicating Authority, which would possibly be in contemplation if theEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Resolution Applicant was permitted to withdraw from, or modify, the Plan after acceptance by the
CoC. Regulation 36B(4A) requires the furnishing of a performance security which will be forfeited if
a Resolution Applicant fails to implement the Plan. This is collected before the Adjudicating
Authority approves the Plan. Notably, the regulations also direct forfeiture of the performance
security in case the Resolution Applicant “contributes to the failure of implementation”, which could
potentially include any attempts at withdrawal of the Plan. 151 The report of the BLRC also notes
that the negotiations in the CIRP must be time bound and it envisages that one of the ways in which
the CIRP comes to a close is that the RP is able to obtain a binding agreement from the CoC 113.
Such a binding agreement is placed before the Adjudicating Authority, which orders the closure of
the CIRP. If the Adjudicating Authority does not receive a binding agreement, it can send the
Corporate Debtor into liquidation. The relevant paragraphs are extracted below:
“5.3.4 Rules to close the IRP The Committee agrees that it is critical for the Code to
preserve the time value of the entity by ensuring that negotiations in the IRP are time
bound. The Code states that the IRP has a default maximum time limit that is strictly
adhered to, regardless of whether the creditors committee has identified a solution.
On the other side, the Committee is also of the view that, if a solution can be
identified within a 5.3.4, BLRC Report, supra note 55 PART J shorter time frame, the
process must accommodate closing the IRP in a shorter time period also. The
Committee proposes that the IRP can come to a close in either of two ways. Either the
RP is able to get a binding agreement from the majority of the creditors committee or
the calm period reaches the default maximum date set by the Adjudicator at the start
of the IRP. If either condition is met, the Adjudicator will issue an order to close the
IRP.
However, the orders will vary depending upon the condition. If the RP submits a binding agreement
to the Adjudicator before the default maximum date, then the Adjudicator orders the IRP case to be
closed. If the Adjudicator does not receive a binding agreement by this date, the Adjudicator issues
an order to close the IRP case along with an order to liquidate the entity.” (emphasis supplied) 152
The binding nature, as between the CoC and the successful Resolution Applicant, of the Resolution
Plan submitted for approval by the Adjudicating Authority is further evidenced from the fact that
the CoC issues a LOI to a successful Resolution Applicant stating that it has been selected as the
successful Resolution Applicant and its Plan would be submitted to the Adjudicating Authority for
its approval. The successful Resolution Applicant is typically required to accept the LOI
unconditionally and submit a PBG. Sequentially, the issuance of an LOI is followed by its
unconditional acceptance by the successful Resolution Applicant. In Amtek Auto (supra), this court
thwarted a similar attempt by a successful Resolution Applicant who had relied on certain
open-ended clauses in its Resolution Plan to seek a direction compelling the CoC to negotiate a
modification to its Resolution Plan. The Resolution Plan had been approved by the Adjudicating
Authority and the Resolution Applicant’s IA was not entertained. The Resolution Applicant had then
sought to challenge the approval of the Resolution Plan under Section 61(3) of PART J the IBC by
seeking the same relief. This Court rejected the claim and observed that, “[t]o assert that there was
any scope for negotiations and discussions after the approval of the resolution plan by the CoC
would be plainly contrary to the terms of the IBC”.Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

153 Regulation 38(3) mandates that a Resolution Plan be feasible, viable and implementable with
specific timelines. A Resolution Plan whose implementation can be withdrawn at the behest of the
successful Resolution Applicant, is inherently unviable, since open-ended clauses on
modifications/withdrawal would mean that the Plan could fail at an undefined stage, be uncertain,
including after approval by the Adjudicating Authority. It is inconsistent to postulate, on the one
hand, that no withdrawal or modification is permitted after the approval by the Adjudicating
Authority under Section 31, irrespective of the terms of the Resolution Plan; and on the other hand,
to argue that the terms of the Resolution Plan relating to withdrawal or modification must be
respected, in spite of the CoC’s approval, but prior to the approval by the Adjudicating Authority.
The former position follows from the intent, object and purpose of the IBC and from Section 31, and
the latter is disavowed by the IBC’s structure and objective. The IBC does not envisage a dichotomy
in the binding character of the Resolution Plan in relation to a Resolution Applicant between the
stage of approval by the CoC and the approval of the Adjudicating Authority. The binding nature of a
Resolution Plan on a Resolution Applicant, who is the proponent of the Plan which has been
accepted by the CoC cannot remain indeterminate at the discretion of the Resolution Applicant. The
negotiations between the Resolution Applicant and the CoC are brought to an end after the CoC’s
approval. The only PART J conditionality that remains is the approval of the Adjudicating Authority,
which has a limited jurisdiction to confirm or deny the legal validity of the Resolution Plan in terms
of Section 30 (2) of the IBC. If the requirements of Section 30(2) are satisfied, the Adjudicating
Authority shall confirm the Plan approved by the CoC under Section 31(1) of the IBC.
154 If the appellants’ claim were to succeed, a clause enabling a Resolution Applicant to
withdraw/seek modification for reasons such as a ‘Material Adverse Event’ could also be set up by a
Resolution Applicant when it is being prosecuted under Section 74 (3). It was contended before us
that Form H, which is a compliance certificate that is to be submitted by the RP to the Adjudicating
Authority along with the Resolution Plan, mentions that the RP can enter details as to whether the
Resolution Plan is subject to any conditionalities under Clause
12. Thus, the argument goes that this permits the Resolution Applicant to stipulate in the Resolution
Plan certain contingencies under which it can withdraw the Plan, for instance if there is an
occurrence of an ‘Material Adverse Event’. A form is subservient to the statute. The conditionalities
contemplated in Form H could be those which do not strike at the root of the IBC. They can include
commercial conditions and business arrangements with the CoC. However, conditions for
withdrawal or re-negotiation of the Resolution Plan cannot pass the test of ‘viability’ and
‘implementability’ as they would make the resolution process indeterminate and unpredictable. A
two judge Bench of this Court in K Sashidhar (supra), while discussing the jurisdiction of the
Adjudicating Authority under Section 31 to evaluate a Resolution Plan, has observed that the
Resolution Plan should “be an overall credible plan, capable of achieving timelines specified in the
PART J Code generally, assuring successful revival of the corporate debtor and disavowing endless
speculation”114. Section 30(2)(d) of the IBC and Regulation 38 of the CIRP Regulations also provide
that the Resolution Plan should be implementable. In the absence of specific statutory language
allowing for withdrawals or even modifications by the successful Resolution Applicant, it would be
difficult to imply the existence of such an option based on the terms of the Resolution Plan,
irrespective of, and especially when they do not form a part of Clause 12 in Form H, as is the case inEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

all the three Resolution Plans that are in dispute in this present appeal.
155 The Insolvency and Bankruptcy Law Committee in its report released in March 2018115 noted
that many conditional Resolution Plans were being approved by the Adjudicating Authority on
account of the uncertainty on statutory clearances, such as by the Competition Commission of India,
and the approval by the Adjudicating Authority was being regarded as a “single window approval”.
This was in contravention of the intent of the IBC. The relevant extracts of the report are reproduced
below:
“16.1 Regulation 37(l) of the CIRP Regulations states that a resolution plan shall
provide for obtaining necessary approvals from the Central and State Governments
and other authorities. However, the timeline within which such approvals are
required to be obtained, once a resolution plan has been approved by the NCLT, has
not been provided in the Code or the CIRP Regulations. The Committee deliberated
that as the onus to obtain the final approval would be on the successful resolution
applicant as per the resolution plan itself, the Code should specify that the timeline
will be as specified in the relevant law, and if the timeline for approval under the
relevant law is less than one year from the approval Para 60 supra note 35 supra note
100 PART J of the resolution plan, then a maximum of one year will be provided for
obtaining the relevant approvals, and section 31 shall be amended to reflect this.
16.2 Further, the Committee noted that there is no provision in the Code on the
requirement to obtain an indication on the stance of the concerned regulators or
authorities, if required, on the resolution plan prior to the resolution plan being
approved by the NCLT. It was brought to the attention of the Committee that this was
resulting in several conditional resolution plans being approved by the NCLT, and
that the approval by the NCLT was being regarded as a ‘single window approval.’ This
not being the intent of the Code, the Committee deliberated on introduction of a
mechanism for obtaining preliminary observations from the concerned regulators
and authorities in relation to a resolution plan approved by the CoC and submitted to
the NCLT for its approval, but prior to the NCLT’s approval.” (emphasis supplied)
The Insolvency and Bankruptcy Law Committee in its report dated February 2020116
stated that the current practice of obtaining governmental approvals after the
approval of the Resolution Plan has created an uncertainty about the implementation
of the Resolution Plan. The committee suggested that this uncertainty can be
mitigated if amendments are made to the IBC to provide that once the Resolution
Plan is approved by the CoC, it will be shared with the governmental and regulatory
authorities, for approvals that are necessary for running the business of the
Corporate Debtor. If no objections are raised within forty-five days, it would be
deemed that they have granted an approval. If objections are raised or conditional
approvals are granted, the Resolution Applicant should attempt to clear the
objections or meet the conditions before placing the Resolution Plan before the
Adjudicating Authority. This Plan would supra note 90 PART J thereafter be placed
before the Adjudicating Authority for its approval. The committee further suggestedEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

that this timeline of forty-five days should be excluded from calculating the timelines
under Section 12 of the IBC. The relevant extract is reproduced below:
“14.8. To enable approvals or no-objections to be taken within the scheme of the
Code, the Committee decided that amendments should be made to the Code such
that once a resolution plan is approved by the CoC, it should be sent to all concerned
government and regulatory authorities whose approvals are core to the continued
running of the business of the corporate debtor, for their approvals or objections. If
they do not raise their objections within forty-five days, they will be deemed to have
no objections. This plan would then be placed before the Adjudicating Authority for
its approval. If the government and regulatory agencies raise any objections or grant
conditional approvals, the resolution applicant can attempt to clear the objections or
meet the conditions for approval before placing the plan for the approval of the
Adjudicating Authority, where this can be done within the time limit provided under
Section 12. However, where this is not possible, the plan may still be placed before
the Adjudicating Authority for its approval, and the successful resolution applicant
should clear the objections or comply with the conditions for approval within a
period of one year from the approval of the resolution plan.
14.9. To ensure that this aligns with the time-line for resolution provided in the Code,
the Committee recommended that the window of forty-five days given to government
and regulatory agencies should be excluded from the computation of the time limit
under Section 12 of the Code. Although some members of the Committee were of the
view that this time-line should ideally run concurrently with the CIRP period, the
Committee felt that this exclusion would be justified since it would streamline the
process of gaining government approvals considerably, which would lead to more
value maximising resolutions, offsetting value lost, if any, in this forty-five day period
in which the corporate debtor will be run as a going concern.” (emphasis supplied)
PART J The aim to tighten timelines for receiving regulatory approvals through the
provision of in-principal approvals, prior to the approval of the Adjudicating
Authority, indicates that the statutory framework under the IBC has consistently
attempted to avoid situations which may introduce unpredictability in the insolvency
resolution process and has sought to make the process as linear as it can be. Further,
the recommendations made in the Insolvency Law Committee Report of February
2020117 discussed above indicate that the aim is to ensure that the Resolution Plan
placed before the Adjudicating Authority should reach a certain finality, even in the
context of governmental approvals. A conditionality which allows for further
negotiations, modification or withdrawal, once the Resolution Plan is approved by
the CoC would only derail the time-bound process envisaged under the IBC.
156 Regulation 40A envisages a model-time line for the CIRP. Any deviation from this timeline
needs to be specifically explained by the RP in Clause 10 of Form H. Regulation 40B imposes a
time-limit on the RP for filing the requisite forms at different stages of the CIRP, including forms
seeking extensions on account of delays at any stage. The failure to fill these forms within theEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

stipulated deadline results in disciplinary action against the RP by the IBBI. Further, as discussed in
Section I of the judgement, various mandatory timelines have been imposed for undertaking specific
actions under the CIRP. If the legislature intended to allow withdrawals or subsequent negotiations
by successful Resolution Applicants, it would have prescribed specific timelines for the exercise of
such an option. The recognition of a power of withdrawal or modification after supra note 90 PART
J submission of a CoC-approved Resolution Plan, by judicial interpretation, will have the effect of
disturbing the statutory timelines and delaying the CIRP, leading to a depletion in the value of the
assets of a Corporate Debtor in the event of a potential liquidation. Hence, it is best left to the
wisdom of the legislature, based on the experiences gained from the working of the enactment, to
decide whether the option of modification or withdrawal at the behest of the Resolution Applicant
should be permitted after submission to the Adjudicating Authority; if so, the conditions and the
safeguards subject in which it can be allowed and the statutory procedure to be adopted for its
exercise. 157 Based on the plain terms of the statute, the Adjudicating Authority lacks the authority
to allow the withdrawal or modification of the Resolution Plan by a successful Resolution Applicant
or to give effect to any such clauses in the Resolution Plan. Unlike Section 18(3)(b) of the erstwhile
SICA which vested the Board for Industrial and Financial Reconstruction with the power to make
modifications to a draft scheme for sick industrial companies, the Adjudicating Authority under
Section 31(2) of the IBC can only examine the validity of the plan on the anvil of the grounds
stipulated in Section 30(2) and either approve or reject the plan. The Adjudicating Authority cannot
compel a CoC to negotiate further with a successful Resolution Applicant. A rejection by the
Adjudicating Authority is followed by a direction of mandatory liquidation under Section 33. Section
30(2) does not envisage setting aside of the Resolution Plan because the Resolution Applicant is
unwilling to execute it, based on terms of its own Resolution Plan.
PART J 158 Further, no such power can be vested with the Adjudicating Authority under its
residuary jurisdiction in terms of Section 60 (5)(c). In a decision of a three judge Bench of this Court
in Gujarat Urja (supra), it was held that, “the NCLT’s residuary jurisdiction [under Section 60(5)(c)]
though wide, is nonetheless defined by the text of the IBC. Specifically, the NCLT cannot do what
the IBC consciously did not provide it the power to do”. Further, the court observed that “this Court
must adopt an interpretation of the NCLT’s residuary jurisdiction which comports with the broader
goals of the IBC”118. The effect of allowing the Adjudicating Authority to permit withdrawals of
resolution plans that are submitted to it, would be to confer it with a power that is not envisaged by
the IBC and defeat the objectives of the statute, which seeks a timely and predictable insolvency
resolution of Corporate Debtors.
159 After the amendment to Section 12 in 2019 which mandate a 330 days outer-limit for conclusion
of the CIRP (which can be breached only under exceptional circumstances as held in Essar Steel
(supra)), it would be antithetical to the purpose of the IBC to allow the Adjudicating Authority to use
its plenary powers under Section 60(5)(c) to potentially extend these timelines to enable the CoC to
either issue a fresh RFRP if the Resolution Plan is withdrawn by a successful Resolution Applicant
or direct further negotiations with the Resolution Applicant who is seeking a modification of the
plan, whose failure could result in withdrawal as well. The likely consequence of a withdrawal by a
successful Resolution Applicant after going through the stages of the CIRP for nearly 180 days
(provided all statutory timelines have been strictly followed) Para 163-164, supra note 38 PART JEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

would inevitably be a delayed liquidation after the value of the assets has further depreciated. In the
event of intervening delays on account of litigation or otherwise, the delay would be even more
severe. If a CoC, could be compelled by the Adjudicating Authority to negotiate with the successful
Resolution Applicant, it would have to resign itself to a commercial bargain at a much lower value. If
Parliament intended to permit such withdrawals/modifications sought by successful Resolution
Applicants as being beneficial to the economic policy, which it has sought to pursue while enacting
the IBC, it would have prescribed timelines for setting the clock-back or directing immediate
liquidation if the withdrawals occur after a certain period. For instance, under Regulation 36B (5)
any modification to the RFRP or the evaluation matrix is deemed as a fresh issue of the RFRP and
the timeline for submission of Resolution Plan starts afresh. Parliament has not legislated to provide
for the eventuality argued by the appellants.
160 Permitting the Adjudicating Authority to exercise its residuary powers under Section 60(5) to
allow for further modifications or withdrawals at the behest of the successful Resolution Applicant,
would be in the teeth of the decision of this Court in Essar Steel (supra) which held that “[s]ection
60(5)(c) cannot be used to whittle down Section 31(1) of the IBC, by the investment of some
discretionary or equity jurisdiction in the Adjudicating Authority outside Section 30(2) of the Code,
when it comes to a resolution plan being adjudicated upon by the Adjudicating Authority”119.
      Para 68-69, supra note 34
                                                                           PART K
K     Factual Analysis
161 We have held in Section H of this judgement that Resolution Plans are not in a nature of a
traditional contract per se, and the process leading up to their formulation and acceptance by the
CoC is comprehensively regulated by the insolvency framework. In Section J, we have further held
that the IBC framework, does not enable withdrawals or modifications of Resolution Plans, once
they have been submitted by the RP to the Adjudicating Authority after their approval by the CoC. In
any event, and without affecting the legal position formulated above, we will also deal with the
submissions of the parties that the contractual terms of their respective Resolution Plans enabled
withdrawal or re-negotiation of terms. We will be undertaking an analysis on whether the individual
Resolution Applicants before us had specifically negotiated with the respective CoCs for a right of
modification or withdrawal and are contractually entitled to the same in the present case.
K.1 The Ebix Appeal 162 Before we begin our analysis on the factual matrix pertaining to Ebix’s
Appeal, we must deal with the preliminary issue alleged by the respondents during the course of the
Ebix Appeal- whether the Third Withdrawal Application by Ebix was barred by res judicata; whileEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

this will not have a bearing on the final outcome of the appeal, we shall analyze it briefly.
PART K K.1.1 Res Judicata 163 To begin our inquiry, it is important to first consider the contours of
the principle of res judicata. In Indian law, the principle has been recognized in Section 11 of the
Code of Civil Procedure 1908. Section 11, in so far as is relevant, reads as follows:
“11. Res judicata.—No Court shall try any suit or issue in which the matter directly
and substantially in issue has been directly and substantially in issue in a former suit
between the same parties, or between parties under whom they or any of them claim,
litigating under the same title, in a Court competent to try such subsequent suit or
the suit in which such issue has been subsequently raised, and has been heard and
finally decided by such Court.
[…] Explanation IV.—Any matter which might and ought to have been made ground
of defence or attack in such former suit shall be deemed to have been a matter
directly and substantially in issue in such suit.
Explanation V.—Any relief claimed in the plaint, which is not expressly granted by
the decree, shall, for the purposes of this section, be deemed to have been refused.
[…]”
164 In Satyadhyan Ghosal v. Deorajin Debi120, a three judge Bench of this Court, speaking through
Justice KC Das Gupta, explained the doctrine of res judicata in the following terms:
“7. The principle of res judicata is based on the need of giving a finality to judicial
decisions. What it says is that once a res is judicata, it shall not be adjudged again.
Primarily it applies as between past litigation and future litigation. When a matter —
whether on a question of fact or a question of law — has been decided between two
parties in one suit or proceeding (1960) 3 SCR 590 PART K and the decision is final,
either because no appeal was taken to a higher court or because the appeal was
dismissed, or no appeal lies, neither party will be allowed in a future suit or
proceeding between the same parties to canvass the matter again. This principle of
res judicata is embodied in relation to suits in Section 11 of the Code of Civil
Procedure; but even where Section 11 does not apply, the principle of res judicata has
been applied by courts for the purpose of achieving finality in litigation. The result of
this is that the original court as well as any higher court must in any future litigation
proceed on the basis that the previous decision was correct.” From the above extract,
it is clear that while res judicata may have been codified in Section 11, that does not
bar its application to other judicial proceedings, such as the one in the present case.
165 Before proceeding further, it is important to compare the reliefs sought by Ebix in the First,
Second and Third Withdrawal Applications. They have been tabulated below, for an easy
comparison:Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

First Withdrawal Second Withdrawal Third Withdrawal Application Application
Application i. Direct that the Ld. i. Allow the Resolution i. Allow the Resolution
Resolution Professional Applicant to withdraw the Applicant to withdraw the supply
a copy of the Special Resolution Plan dated Resolution Plan dated Investigation Audit
to the 19.02.2018 (along with the 19.02.2018 (along with the Resolution Applicant
Addendum/Financial Addendum/Financial forthwith; Proposal dated 21.02.2019)
Proposal dated 21.02.2019) submitted by it, and as submitted by it, and as ii. Direct
that the Ld. approved by the Committee approved by the Committee Resolution
Professional of Creditors; of Creditors; supply a copy of the Certificates under
Sections ii. Direct the Ld. Resolution ii. Direct the Ld. Resolution 43, 45, SO and 66
of the Professional and/or Educomp Professional and/or Educomp Insolvency and
Bankruptcy Solutions Limited and the Solutions Limited and the Code, 2016 to the
Resolution Committee of Creditors to Committee of Creditors to Professional
forthwith; refund the Earnest Money refund the Earnest Money Deposit of Rs.
2,00,00,000/- Deposit of Rs. 2,00,00,000/- iii. Withhold approval of the furnished
by the Resolution furnished by the Resolution Resolution Plan sanctioned Applicant
in respect of the Applicant in respect of the by the Committee of Resolution Plan;
Resolution Plan; Creditors of the Corporate Debtor, as filed before this iii. Withhold
approval of the iii. Withhold approval of the Hon'ble Tribunal on Resolution Plan
sanctioned Resolution Plan sanctioned 11.04.2018, pending detailed by the
Committee of Creditors by the Committee of Creditors PART K consideration of the
same by of the Corporate Debtor, as of the Corporate Debtor, as the Resolution
Applicant; filed before this Hon'ble filed before this Hon'ble Tribunal on 07.03.2018
and Tribunal on 07.03.2018 and iv. Grant the Resolution recorded vide order dated
recorded vid order dated Applicant sufficient time to re- 1.1.04.2018, pending
detailed 11.04.2018, pending detailed evaluate its proposals consideration of the
same by consideration of the same by contained in the Resolution the Resolution
Applicant; the Resolution Applicant;
Plan, and also to suitably revise/modify and/or withdraw its Resolution Plan;
From the above table, it is clear that the prayers in the Second and Third Withdrawal Applications
were identical. Further, prayer (iii) of both corresponds to prayer (iii) of the First Withdrawal
Application, in almost identical terms, while prayer (ii) was not present in the First Withdrawal
Application at all. At the same time, prayers (i) and (ii) in the First Withdrawal Application have not
been repeated in the Second and Third Withdrawal Applications. However, what is at issue is prayer
(iv) of the First Withdrawal Application and prayer (i) of the Second and Third Withdrawal
Applications. Through the former, Ebix sought permission to re-evaluate its Resolution Plan and to
suitably “revise/modify and/or withdraw” it, while through the latter, Ebix sought permission to
withdraw its Resolution Plan. Now we must analyse whether this would attract the principle of res
judicata.
166 In a judgment of this Court in Sheodan Singh v. Daryao Kunwar121, a four judge Bench of this
Court elaborated on the various conditions which must be satisfied before the doctrine of resEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

judicata can apply in a given case. Justice KN Wanchoo, speaking for the Court, held:
(1966) 3 SCR 300 PART K “9. A plain reading of Section 11 shows that to constitute a
matter res judicata, the following conditions must be satisfied, namely—
(i) The matter directly and substantially in issue in the subsequent suit or issue must
be the same matter which was directly and substantially in issue in the former suit;
(ii) The former suit must have been a suit between the same parties or between
parties under whom they or any of them claim;
(iii) The parties must have litigated under the same title in the former suit;
(iv) The court which decided the former suit must be a court competent to try the
subsequent suit or the suit in which such issue is subsequently raised; and
(v) The matter directly and substantially in issue in the subsequent suit must have
been heard and finally decided by the court in the first suit…” (emphasis supplied)
167 In the present case, conditions (i) is not in dispute since the parties were the same. As regards
(ii), in the First Withdrawal Application, the prayer was to enable Ebix to re-evaluate its proposals
and to revise/modify and also withdraw its Resolution Plan. A prayer for withdrawal of the
Resolution Plan was raised in the Second and Third Withdrawal Applications. Conditions (iii) and
(iv) are also not in issue. What remains to be assessed is compliance with condition (v), i.e., whether
Ebix’s prayer in the First Withdrawal was in fact “heard and decided finally”. While dismissing the
First Withdrawal Application, the NCLT had held:
“This is an application filed by one Ebix Singapore Ptd. Limited seeking re-valuation
of the Resolution Plan submitted by it before the Resolution Professional.
No ground for considering the prayer sought in the application is made out.
The application is dismissed as such.” PART K NCLT dismissed the First Withdrawal
Application in a summary manner. Further, the order does not make mention of the
prayer to “revise/modify and/or withdraw” of the Resolution Plan, but only refers to
its re-evaluation.
168 The meaning of the phrase “heard and finally decided” was considered by a judgment of a two
judge Bench of this Court in Krishan Lal v. State of J&K122, where it was held that the matter must
have been heard on merits to have been “heard and finally decided”. Justice BL Hansaria, speaking
for the Court, held:
“12. Insofar as the second ground given by the High Court — the same being bar of
res judicata — it is clear from what has been noted above, that there was no decisionEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

on merits as regards the grievance of the appellant; and so, the principle of res
judicata had no application. The mere fact that the learned Single Judge while
disposing of the Writ Petition No. 23 of 78 had observed that:
“This syndrome of errors, omissions and oddities, cannot be explained on any
hypothesis other than the one that there is something fishy in the petitioner's
version….” which observations have been relied upon by the High Court in holding
that the suit was barred by res judicata do not at all make out a case of applicability of
the principle of res judicata. The conclusion of the High Court on this score is indeed
baffling to us, because, for res judicata to operate the involved issue must have been
“heard and finally decided”. There was no decision at all on the merit of the grievance
of the petitioner in the aforesaid writ petition and, therefore, to take a view that the
decision in earlier proceeding operated as res judicata was absolutely erroneous, not
to speak of its being uncharitable.” (emphasis supplied) (1994) 4 SCC 422 PART K
169 In Daryao v. State of U.P.123, a Constitution Bench of this Court held that orders dismissing
writ petitions in limine will not constitute res judicata. It was noted that while a summary dismissal
may be considered as a dismissal on merits, it would be difficult to determine what weighed with the
Court without a speaking order. Justice PB Gajendragadkar, speaking for the Court, held:
“26...If the petition is dismissed in limine without passing a speaking order then such
dismissal cannot be treated as creating a bar of res judicata. It is true that, prima
facie, dismissal in limine even without passing a speaking order in that behalf may
strongly suggest that the Court took the view that there was no substance in the
petition at all; but in the absence of a speaking order it would not be easy to decide
what factors weighed in the mind of the Court and that makes it difficult and unsafe
to hold that such a summary dismissal is a dismissal on merits and as such
constitutes a bar of res judicata against a similar petition filed under Article 32…”
170 Another two judge Bench of this Court, in its judgment in Erach Boman Khavar v. Tukaram
Shridhar Bhat124, has held that the doctrine of res judicata can only apply when there has been a
conscious adjudication of the issue on merits. Justice Dipak Misra, speaking for the Court, held:
“39. From the aforesaid authorities it is clear as crystal that to attract the doctrine of
res judicata it must be manifest that there has been a conscious adjudication of an
issue. A plea of res judicata cannot be taken aid of unless there is an expression of an
opinion on the merits. It is well settled in law that principle of res judicata is
applicable between the two stages of the same litigation but the question or issue
involved must have been decided at earlier stage of the same litigation.” (emphasis
supplied) (1962) 1 SCR 574 (2013) 15 SCC 655 PART K
171 Res judicata cannot apply solely because the issue has previously come up before the court. The
doctrine will apply where the issue has been “heard and finally decided” on merits through a
conscious adjudication by the court. In the present case, the NLCT’s order dismissing the FirstEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Withdrawal Application makes it clear that it had only considered only that part of prayer (iv) which
related to re-evaluation of the Resolution Plan, possibly because Ebix had hoped to re-evaluate the
Resolution Plan on the basis of the information received as a consequence of prayers (i) and (ii) and
those prayers were rejected since such information was not available.
172 In the impugned judgment, the NCLAT has relied upon Explanation (V) to Section 11 to state
that since withdrawal was also prayed for as a relief in prayer
(iv) of the First Withdrawal Application, it would have also been assumed to have been rejected.
Mulla’s The Code of Civil Procedure states that Explanation V can only apply upon the fulfilment of
two conditions: (i) the relief claimed must have been substantial, and not merely auxiliary; and (ii)
the relief claimed must have been one which the Court is bound to grant, and not one which it is
discretionary for the Court to grant125.
173 In Jaswant Singh v. Custodian of Evacuee Property126, a two judge Bench of this Court held that
res judicata will only apply if the cause of action the same and that the party also had an earlier
opportunity to apply for the relief it is now seeking. Justice ES Venkataramiah held:
125 th Sir Dinshaw Fardunji Mulla, The Code of Civil Procedure (18 edn, LexisNexis)
(1985) 3 SCC 648 PART K “14…It is well-settled that in order to decide the question
whether a subsequent proceeding is barred by res judicata it is necessary to examine
the question with reference to the (i) forum or the competence of the Court, (ii)
parties and their representatives, (iii) matters in issue, (iv) matters which ought to
have been made ground for defence or attack in the former suit, and (v) the final
decision…A cause of action for a proceeding has no relation whatever to the defence
which may be set up, nor does it depend upon the character of the relief prayed for by
the plaintiff or the applicant. It refers entirely to the grounds set forth in the plaint or
the application as the case may be as the cause of action or in other words to the
media upon which the plaintiff or the applicant asks the court to arrive at a
conclusion in his favour. In order that a defence of res judicata may succeed it is
necessary to show that not only the cause of action was the same but also that the
plaintiff had an opportunity of getting the relief which he is now seeking in the
former proceedings.
The test is whether the claim in the subsequent suit or proceedings is in fact founded upon the same
cause of action which was the foundation of the former suit or proceedings…” (emphasis supplied)
174 The prayer for withdrawal of the Resolution Plan in the First Withdrawal Application was not
substantial and one that the Court was bound to grant, since it was contingent upon a re-evaluation,
which in itself was contingent upon receiving the information sought in prayers (i) and (ii). Since the
latter two contingencies never arose, the NCLT did not apply its mind to the prayer for withdrawal
independently. When it filed the Second Withdrawal Application, it was dismissed on a technical
ground and not on its merits. When a revised Third Withdrawal Application was filed, the NCLT
then adjudicated it on its merits and allowed it. Hence, since the NCLT did not adjudicate Ebix’s
prayer for withdrawal of their Resolution Plan on its merits while dismissing the First WithdrawalEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Application, the opportunity to seek the relief was not available to Ebix in a real sense. Therefore, we
reverse the finding of the NCLAT on this issue and hold that Ebix’s Third Withdrawal Application
was not barred by res judicata. PART K K.1.2 Analysis of the Resolution Plan of Ebix 175 To briefly
recount the relevant facts for determination of the dispute over the terms of the resolution plan –
the CIRP of Educomp commenced on 30 May 2017. After consultation with the E-CoC, the E-RP
invited EOIs on 18 October 2017. The RFRP was issued on 5 December 2017, and was revised on 17
January 2018 and 20 January 2018. Ebix submitted its draft Resolution Plan after the last date of 27
January 2018, and after securing an extension from the Adjudicating Authority, on 29 January
2018. Ebix took the benefit of an extension of time which was granted to it to submit its Resolution
Plan. In the absence of an extension of time, it would not have been permitted to enter the fray.
After multiple rounds of negotiations, on 9 February 2018, Ebix was declared the successful
Resolution Applicant and a LOI was issued by the E-CoC. On 17 February 2018, Ebix’s Resolution
Plan was approved by a 74.16 per cent voting share of the E-CoC, which was subsequently upgraded
to 75.35 per cent by CSEB’s vote being added belatedly on 23 February 2018. While it is true that the
votes of CSEB were received in favour of the Resolution Plan on a later date, all the parties including
Ebix proceeded on the notion that the Resolution Plan has been approved by the requisite majority
of seventy-five per cent of the voting share of the E-CoC as was required then (now the requisite
percentage has been reduced to sixty-six per cent pursuant to an amendment). Thus, the CSEB
Application filed before the NCLT seeking a clearance of its delayed vote was a mere formality and
there was no controversy raised in relation to that application at that stage. In fact, the Approval
Application for the approval of the Resolution Plan was filed before the NCLT on the basis that the
Plan has been duly PART K approved by the requisite majority of the CoC. No objections were raised
against the Approval Application on the ground that the threshold of seventy-five per cent of votes
was not met. The Resolution Plan dated 19 February 2018 and the addendum dated 21 February
2018 for a total bid amount of Rs 400 crores were then submitted by the E-RP to the Adjudicating
Authority for approval on 7 March 2018.
176 Owing to the intervening applications for investigation into the accounts of Educomp
(pertinently, no internal special audit has been conducted till date), Ebix filed the First Withdrawal
Application on 5 July 2019, on account of a delay in approval of seventeen months. Thereafter, it
filed the Second and Third Withdrawal Applications.
177 Ebix has alleged before this Court that it is entitled to withdraw its Resolution Plan by relying
on: (i) the terms of the RFRP, which indicates that the Resolution Plan is binding on the Resolution
Applicant only after approval by the Adjudicating Authority under Section 31; (ii) the terms of the
Resolution Plan which indicate that the Plan was valid for six months; and (iii) the principles of
contract law to urge frustration on account of fraud and an erosion of the commercial substratum.
178 Clause 1.8.3 of the RFRP, produced below, invited Resolution Plans with a validity of not less
than six months:
“1.8.3 A Resolution Plan once made/submitted must be valid for a period not less
than 6 (six) months from the Resolution Plan Submission Date including any
revisions to such Resolution plan Submission Date (“Resolution Plan ValidityEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Period”). In case of extension of the Resolution Plan Submission Date by the
Resolution Professional, the validity PART K period of the Resolution Plan shall also
be deemed to be valid for a period of 6 (six) months from such revised Resolution
Plan Submission date.
If any Resolution Plan as approved by the CoC and submitted to the Adjudicating
Authority is rejected by the Adjudicating Authority, then the Resolution Professional
and the CoC shall act in accordance with the instructions/directions issued by the
Adjudicating Authority.” Ebix urges that in compliance with the above clause of the
RFRP, Clause 7 of its Resolution Plan specified that it shall be valid for a term of six
months from the date of submission:
“7. Term of the Resolution Plan This Resolution Plan proposed by the Resolution
Applicant is valid for a term of six months from the date of submission of this plan”
Ebix urges that these matching terms of the offer (the RFRP) and the acceptance (the
Resolution Plan) are binding on the E-CoC and the Resolution Plan is voidable and
revocable at the instance of Ebix, upon the failure to seek timely approval under
Section 31.
179 This submission of Ebix cannot be accepted since the terms of the RFRP or the Resolution Plan
relate to the validity of the Resolution Plan for the period of negotiation with the E-CoC and not for
a period after the Resolution Plan is submitted for the approval of the Adjudicating Authority. The
time which may be taken before the Adjudicating Authority is an imponderable which none of the
parties can predict. In fact, this is emphasized by Clause 1.3.7 of the RFPF which contains a schedule
of the Resolution Plan submission process. As regards the approval of the Adjudicating Authority, it
provides clearly that there is no time-line:
PART K “1.3.7 Schedule of Resolution Plan Submission Process […]
11. Approval of NCLT regarding the Resolution Plan of Successful Resolution
Applicant – As per NCLT.” Parties cannot indirectly impose a condition on a judicial
authority to accept or reject its Plan within a specified time period, failing which the
CIRP process will inevitably come to an end. In this case, the draft Resolution Plan of
Ebix was submitted on 29 January 2018 and remained valid for the term of the
multiple rounds of negotiations with the E-CoC, until its submission to the
Adjudicating Authority on 7 March 2018, which was within the six-month period
envisaged in the Plan.
180 Even if it were to be assumed, for the sake of argument, that the term in the submitted
Resolution Plan was in the nature of a qualified offer which would expire after six months of its
submission, failing the imprimatur of the Adjudicating Authority under Section 31 which would
make it binding on all parties, the surrounding terms of the RFRP and the subsequent legal
materials including the LOI and the Compliance Certificate (Form H) under CIRP Regulations make
it clear that there was no scope to resile from the implementation of the Resolution Plan, once it hadEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

been submitted to the Adjudicating Authority, except in the event of a rejection. Clause 1.9.3 of the
RFRP required Ebix to replace its EMD with a PBG equivalent to ten per cent of the Resolution Plan
value, if it were to be declared as the ‘successful Resolution Applicant’. This PBG can be invoked
under Clause 1.9.5 of the RFRP if the Resolution Applicant fails to implement the Resolution Plan.
Further, Clause 1.8.4 of the RFRP states that “[a] Resolution PART K Plan submitted by a
Resolution Respondent shall be irrevocable”. Clause 1.10(l) of the RFRP also provides that a
successful Resolution Applicant is not permitted to withdraw an approved Resolution Plan:
“Clause 1.10 of the RFRP “By procuring this RFRP and obtaining access to the Data
room and Information Memorandum, in accordance with the terms of this RFRP, the
Resolution Respondent is deemed to have made the following acknowledgements and
representations:
[...]
(l) The Resolution Respondent upon declaration as Successful Resolution
Respondent shall remain responsible for the implementation and supervision of the
Resolution Plan from the date of approval by the Adjudicating Authority, and will not
be permitted to withdraw the Resolution Plan and the Resolution Professional, PwC
or the CoC assume no responsibility or liability in this respect.” (emphasis supplied)
Ebix’s submission that Clause 1.10(l) is applicable only upon approval of the
Adjudicating Authority is not plausible since the Resolution Plan becomes binding on
all stakeholders as a consequence of the approval under Section 31. The E-
RP’s argument holds much weight when it is argued that Clause 1.10(l) cannot be construed to infer
that the Adjudicating Authority would declare Ebix as the ‘Successful Resolution Applicant’ once
again, which would then impose the obligation of barring withdrawals for the first time. Mr Nakul
Dewan, learned Senior Counsel for the E-RP, has also submitted before us that the validity of the
Resolution Plan being six months was not mentioned as a specific conditionality in Form H that was
submitted by the E-RP along with the Resolution Plan to the PART K Adjudicating Authority, which
evinces that the six-month validity was only vis-à- vis the acceptance by the E-CoC.
181 Ebix has also tried to argue that its position has changed manifestly because of new allegations
which have come up in relation to the financial conduct of Educomp. However, in this regard, it is
pertinent to note Clause 1.3.2 of the RFRP which directs prospective Resolution Applicants to
conduct their own due diligence. In so far as is relevant, it reads:
“1.3.2 The Resolution Applicant(s) shall be provided access to the electronic as well as
physical data room ("Data Room") established and maintained by the Company
acting through the Resolution Professional and coordinated by PwC in order to
conduct a due diligence of the business and operations of the Company” Similarly,
Clause 1.13.6 also requires prospective Resolution Applicants to conduct independent
investigations:Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

“1.13.6 This RFRP does not purport to contain all the information required by the
Resolution Applicant. The Resolution Applicant should conduct independent
investigations and analysis and should check the accuracy, reliability and
completeness of the information in this RFRP and obtain independent advice from
appropriate sources, prior to making an assessment of the Company.” Ebix was
responsible for conducting their own due diligence of Educomp and could not use
that as a reason to revise/modify their approved Resolution Plan. In any event,
Section 32A of the IBC grants immunity to the Corporate Debtor for offences
committed prior to the commencement of CRIP and it cannot be prosecuted for such
offences from the date the Resolution Plan has been approved by the Adjudicating
Authority under Section 31, if the Resolution Plan PART K results in a change of
management or control of the Corporate Debtor subject to certain conditions. Section
32A reads as follows:
“32A. (1) Notwithstanding anything to the contrary contained in this Code or any
other law for the time being in force, the liability of a corporate debtor for an offence
committed prior to the commencement of the corporate insolvency resolution
process shall cease, and the corporate debtor shall not be prosecuted for such an
offence from the date the resolution plan has been approved by the Adjudicating
Authority under section 31, if the resolution plan results in the change in the
management or control of the corporate debtor to a person who was not-
(a) a promoter or in the management or control of the corporate debtor or a related
party of such a person; or
(b) a person with regard to whom the relevant investigating authority has, on the
basis of material in its possession, reason to believe that he had abetted or conspired
for the commission of the offence, and has submitted or filed a report or a complaint
to the relevant statutory authority or Court:
[…] (2) No action shall be taken against the property of the corporate debtor in
relation to an offence committed prior to the commencement of the corporate
insolvency resolution process of the corporate debtor, where such property is covered
under a resolution plan approved by the Adjudicating Authority under section 31,
which results in the change in control of the corporate debtor to a person, or sale of
liquidation assets under the provisions of Chapter III of Part II of this Code to a
person, who was not –
(i) a promoter or in the management or control of the corporate debtor or a related
party of such a person; or
(ii) a person with regard to whom the relevant investigating authority has, on the
basis of material in its possession, reason to believe that he had abetted or conspired
for the commission of the offence, and has submitted or filed a report or a complaintEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

to the relevant statutory authority or Court.
[…] (3) Subject to the provisions contained in sub-sections (1) and (2), and notwithstanding the
immunity given in this section, the corporate debtor and any person, who may be required to
provide assistance under such law as may be applicable to PART K such corporate debtor or person,
shall extend all assistance and co-operation to any authority investigating an offence committed
prior to the commencement of the corporate insolvency resolution process.” Thus, in any case even
if it is found that there was any misconduct in the affairs of Educomp prior the commencement of
the CIRP, Ebix will be immune from any prosecution or punishment in relation to the same. The
submission that Ebix has been placed in a prejudicial position due to the initiation of investigation
into the affairs of Educomp by the CBI and SFIO is nothing but a red herring since such
investigations have no bearing on Ebix.
182 Finally, it is also important to note that no clause of Ebix’s own Resolution Plans provides them
with a right to revise/withdraw their Resolution Plan after its approval by the E-CoC, but before its
confirmation by the Adjudication Authority. Clause 9.1 permits withdrawal in the event the
Resolution Plan is not approved in its entirety by the NCLT, while Clause 9.7 allows for an
amendment for the purposes of implementation of the Resolution Plan but only when the E-CoC
approves it with a seventy-five per cent vote. Hence, Ebix did not have any right under their own
Resolution Plan to revise/withdraw it. 183 It is also pertinent to note that Ebix did not stop pursuing
their Resolution Plan after the expiry of six months, if the true import of the commercial bargain
was a withdrawal of the Resolution Plan after six months of its submission. The First Withdrawal
Application was filed on 10 September 2019, which was after one year of the alleged expiry of the
six-month period. Therefore, even if the submitted Resolution Plan was considered as a conditional
offer the terms did not PART K enable a withdrawal of the Resolution Plan in the event that the
Adjudicating Authority does not approve it under Section 31 within six months of its submission.
184 Before we conclude our analysis on the substantive arguments raised by Ebix, we will be briefly
dealing with its arguments that the RP had failed in its obligation to provide information under
Section 29 of the IBC. K.1.3 Duties of the RP 185 Appearing on behalf of Ebix, Mr KV Vishwanathan
has argued before this Court that the E-RP failed in its duties under Section 29 of the IBC when it
failed to inform Ebix about the ongoing investigations against Educomp. While this argument was
made in order to justify Ebix’s withdrawal of its Resolution Plan, which we have already rejected, we
shall assess it nonetheless. On behalf of the E-RP, Mr Nakul Dewan has appeared and argued that
the obligation on an RP to provide information under Section 29 has to be understood on a “best
effort basis”.
186 Section 29 of the IBC places a duty upon the RP to provide an IM to the Resolution Applicant,
containing such information which may be relevant to the Resolution Applicant to draft its
Resolution Plan. It states:
“29. Preparation of information memorandum.—(1) The resolution professional shall
prepare an information memorandum in such form and manner containing such
relevant information as may be specified by the Board for formulating a resolutionEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

plan.
PART K (2) The resolution professional shall provide to the resolution applicant
access to all relevant information in physical and electronic form, provided such
resolution applicant undertakes—
(a) to comply with provisions of law for the time being in force relating to
confidentiality and insider trading;
(b) to protect any intellectual property of the corporate debtor it may have access to;
and
(c) not to share relevant information with third parties unless clauses (a) and (b) of
this sub-section are complied with.
Explanation.—For the purposes of this section, “relevant information” means the information
required by the resolution applicant to make the resolution plan for the corporate debtor, which
shall include the financial position of the corporate debtor, all information related to disputes by or
against the corporate debtor and any other matter pertaining to the corporate debtor as may be
specified.” 187 The BLRC Report elucidates the duties of the RP:
“1. The RP must provide the most updated information about the entity as accurately
as is reasonably possible to this range of solution providers. In order to do this, the
RP has to be able to verify claims to liabilities as well as the assets disclosed by the
entity. The RP has the power to appoint whatever outside resources that she may
require in order to carry out this task, including accounting and consulting services.
2. The information collected on the entity is used to compile an information
memorandum, which is signed off by the debtor and the creditors committee, based
on which solutions can be offered to resolve the insolvency.
In order for the market to provide solutions to keep the entity as a going concern, the information
memorandum must be made available to potential financiers within a reasonable period of time
from her appointment to the IRP. If the information is not comprehensive, the RP must put out the
information memorandum with a degree of completeness of the information that she is willing to
certify.
For example, as part of the information memorandum, the RP must clearly state the expected
shortfall in the coverage of the liabilities and assets of the entity presented in the PART K
information memorandum. Here, the asset and liabilities include those that the RP can ascertain
and verify from the accounts of the entity, the records in the information system, the liabilities
submitted at the start of the IRP, or any other source as may be specified by the Regulator.Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

3. Once the information memorandum is created, the RP must make sure that it is readily available
to whoever is interested to bid a solution for the IRP. She has to inform the market (a) that she is the
RP in charge of this case, (b) about a transparent mechanism through which interested third parties
can access the information memorandum, (c) about the time frame within which possible solutions
must be presented and (d) with a channel through which solutions can be submitted for evaluation.
The Code does not specify details of the manner or the mechanism in which this should be done, but
rather emphasises that it must be done in a time-bound manner and that it is accessible to all
possible interested parties.” (emphasis supplied) 188 Similarly, the UNCITRAL Guide notes:
“5. Duties and functions of the insolvency representative […]
(e) Obtaining information concerning the debtor, its assets, liabilities and past
transactions (especially those taking place during the suspect period), including
examining the debtor and any third person having had dealings with the debtor…”
189 Under the IBC, there is a duty upon the RP to collect as much information about the Corporate
Debtor as is accurately possible to do. When such information is communicated through an IM to
the Resolution Applicant, the RP must be careful to clarify when its information is not
comprehensive and what factors may cause a change.
PART K 190 In the present case, Ebix has alleged that the E-RP did not inform it of the financial
investigations into the conduct of Educomp in a timely fashion. To assess this claim, it is important
to underline a few dates:
(i) 5 December 2017 – E-RP provided Virtual Data Room access to Ebix and other
prospective Resolution Applicants in relation to Educomp, and the final RFRP was
issued;
(ii) 7 March 2018 – E-RP filed the Approval Application before NCLT in relation to
Ebix’s Resolution Plan, after its approval by the E-CoC;
(iii) 3 April 2018 and 26 April 2018 – two articles are published in The Wire in
relation to financial mismanagement of Educomp;
(iv) 4 May 2018 – the IFC Application came up before NCLT, having been filed by a
financial creditor of Educomp seeking investigation of the affairs/transactions, in
which the E-RP was directed file its reply and IFC was directed to serve a notice on
Ebix;
(v) 12 June 2019 – Educomp made regulatory disclosures to the BSE and NSE in
relation to the ongoing investigations by SFIO and CBI; and
(vi) 5 July 2019 – Ebix filed the First Withdrawal Application.Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

191 Ebix cannot dispute that E-RP had provided it the relevant information required under Section
29 to formulate its Resolution Plan. The issues in relation to financial investigations into the
conduct of Educomp arose when the two articles were published by The Wire, both of which were
after the Approval Application had been filed by the E-RP. Further, Ebix was aware of all the
proceedings before the NCLT since the various applications were often listed along with the
Approval Application, in which it continued to appear. Finally, Ebix PART K has brought nothing on
record to prove that E-RP knew of the SFIO and CBI investigations before a regulatory disclosure
was made by Educomp. Hence, it cannot be stated that the E-RP had faltered in its duty to provide
relevant information to Ebix.
K.2 The Kundan Care Appeal 192 The CIRP of Astonfield commenced on 27 November 2018. On 1
May 2019, GUVNL issued a default notice under Article 9.3.1(e) of the PPA, taking the initiation of
the CIRP as an event of default for the termination of the PPA. The validity of the default notice was
adjudicated upon by the NCLT in a judgment dated 29 August 2019. The NCLT set aside the default
notice on the ground that the termination of the PPA would adversely affect the “going concern”
status of Astonfield. On 15 October 2019, the NCLAT dismissed an appeal filed by GUVNL. On 29
October 2019, Kundan Care submitted a Resolution Plan for being considered by the A-CoC, which
was followed by a final version on 12 November 2019. On 14 November 2019, the Resolution Plan
submitted by Kundan Care was approved by the A-CoC with a vote of 99.28 per cent. On 15
November 2019, a Letter of Award was issued by the A-RP to Kundan Care, and the Resolution Plan
was submitted to the NCLT for approval to under Section 31 of the IBC.
193 On 27 November 2019, GUVNL moved this Court in appeal against the order of the NCLAT
dated 15 October 2019 (this Court eventually dismissed the appeal). During the pendency of the
appeal, the appellant moved an application PART K before the NCLT for withdrawal of its
Resolution Plan and for return of its PBG. In view of the pendency of the appeal before this Court,
NCLT deferred consideration of the Resolution Plan till the disposal of the appeal. On the request of
Kundan Care, their application was listed for hearing and dismissed on 3 July 2020 for want of
jurisdiction to enable withdrawals. This decision of the NCLT was confirmed by the NCLAT on 30
September 2020. While Kundan Care’s appeal against this decision of the NCLAT was pending
before this Court, Gujarat Urja (supra) was decided by this Court on 8 March 2021. 194 Kundan
Care had initially sought to rely on Clause 5.1 of their Resolution Plan to argue that it had reserved
the right to modify or withdraw its submitted Resolution Plan in the event of a ‘material adverse
change’ which affects Astonfield. Clause 5.1 reads as follows:
“5.1 Basis of Preparation The preparation of the Resolution Plan is based on the
Information Memorandum provided to the Resolution Applicant by the Resolution
Professional. If at any time before or after submission of this Resolution Plan, should
the information on the basis of which this Resolution Plan has been prepared,
change, or new information becomes available, or if there is a material adverse
change i.e. shall there have occurred any fact, matter, event, circumstance, condition
or change which materially and adversely affects, or could reasonably be expected to
materially and adversely affect: individually or in aggregate, the business, operations,
assets, liabilities, conditions (whether financial, trading or otherwise), prospects orEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

operating results of the Corporate Debtor, the Resolution Applicant shall have the
right to reconsider, revise and/or withdraw the Resolution Plan on assessment of
such additional information and/or make a fresh submission of resolution plan at its
sole discretion” PART K However, the A-RP has pointed out to the court that the LOI
awarded to Kundan Care clearly stipulated that the submitted Resolution Plan is
irrevocable and there were no conditionalities mentioned in the Form H that was
submitted to the Adjudicating Authority. Clause 9 of Kundan Care’s Resolution Plan
confirms this position, since it states:
“9 Condition Precedent THERE ARE NO CONDITION PRECEDENT FOR
APPROVAL OF THIS RESOLUTION PLAN” This is also reaffirmed by the fact that
Clause 1.6.2 of the RFRP issued by the A- RP, specifically indicated that the A-CoC
may reject a Resolution Plan if it did not agree with any of the conditions precedent
in the nature of “walk away conditions”. Clause 1.6.2 states:
“1.61 The CoC reserves the right to reject the Resolution Plan, if any of the Conditions
Precedent (as defined in Format VA - Resolution Plan), are not acceptable to the CoC.
The Conditions Precedent, if any, in a Resolution Plan would mean the 'walk-away
conditions' and shall be required to be specifically mentioned as such in the said
Plan, with a conspicuous heading and placement of a paragraph in the Plan, and all
such conditions shall be placed in a consolidated manner in the said paragraph.” This
indicates that the condition of a material adverse event could be exercised only until
the A-CoC was considering the Resolution Plan, and not after it had been submitted
to the Adjudicating Authority.
195 During the course of the hearing of the present appeal, the compilation of additional documents
has been filed by Kundan Care. On 5 July 2021, Kundan Care had addressed a communication to
EXIM Bank and PFCL “seeking a PART K revision/renegotiation of the resolution amount/financial
proposal” of Kundan Care for the resolution of Astonfield. Responding to the above communication,
EXIM Bank has addressed a letter dated 12 July 2021 stating that a meeting was held by “the
lenders” (EXIM Bank and PFCL) on 9 July 2021, on a without prejudice basis to deal with the issues
raised by Kundan Care in their letter dated 5 July 2021. Responding to the request of Kundan Care,
it has been stated that:
“4… lenders were prima facie agreeable to deliberate the financial proposal seeking
revision in resolution plan amount in the COC convened by the RP post the directions
of the Hon'ble Supreme Court in accordance with the processes laid down by the
IBC”.
Pursuant to the above exchange of communications, a joint request has been made by
Mr Ramji Srinivasan, learned Senior Counsel appearing on behalf of Kundan Care
and Mr V Giri, learned Senior Counsel appearing on behalf of the A-CoC in the
following terms:Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

“In view of the letter dated 12 July 2021 issued by the lenders who are members of
the CoC, the appellant may be permitted to withdraw Civil Appeal 3560/2020 with
liberty to the RA and the CoC to file the revised plan (in terms of the letter dated 12
July 2021) before the NCLT (through the RP) for approval. The CoC shall convene
and take a call on the revised plan within one week and the NCLT shall dispose of the
matter within two weeks upon receiving IA from RP for approval of revised plan.” 196
This Court had been informed that EXIM Bank and PFCL represent 98 per cent of
the financial creditors of Astonfeld. In view of the above agreement which has been
arrived at, we deem it appropriate to exercise our jurisdiction under Article 142 of the
Constitution of India for a one-time relief and direct that:
PART K
(i) The A-CoC shall convene and take a decision on the proposal submitted by
Kundan Care on 5 July 2021, and the response by EXIM Bank and PFCL dated 12
July 2021;
(ii) In the event, that a revised Resolution Plan is agreed upon by the A-CoC, it shall
be submitted through the A-RP for the approval of the NCLT within a week
thereafter. In the event that a revised Resolution Plan is not agreed upon, the original
Resolution Plan, as submitted before the NCLT on 15 November 2019, shall prevail;
and
(iii) The NCLT shall dispose of the application with the revised Resolution Plan
expeditiously, and preferably within a period of two weeks from the date of receipt of
an application from the A-RP for the approval of the revised Resolution Plan.
197 We clarify that the above directions have been issued in view of the submission which has been
urged as noted, and shall not amount to any finding by this Court on the issues raised with regard to
modification or withdrawal of Resolution Plans at the behest of the Resolution Applicant. K.3 The
Seroco Appeal 198 The CIRP of Arya Filaments, an MSME, was instituted on 17 August 2018. Seroco
submitted a draft Resolution Plan on 13 March 2019 for an amount of Rs 6.79 crores (approx.).
Subsequent to meetings with the Arya-CoC and revisions to the Resolution Plan, Seroco’s plan was
approved by the Arya-CoC on 10 May PART K 2019. On 15 May 2019, the Arya-RP filed the
Resolution Plan for approval before the NCLT. Form H was filed by Arya-RP on 5 June 2020.
199 Seroco addressed a letter to Arya-RP and Arya-CoC on 9 June 2020 seeking a modification of
the Resolution Plan and the resolution amount to Rs 5.29 crores (approx.) on account of the
economic slowdown caused by the COVID-19 pandemic, and subsequently filed applications before
the NCLT and an appeal before the NCLAT seeking a modification of the Resolution Plan on account
of the original being filed over eighteen months ago. 200 Seroco has relied on the terms of its
Resolution Plan which envisage payment to the Arya-CoC by sale of land and building, and
old/unusable/spare plant and machineries to urge that there has been a frustration of the contract
because of the economic slowdown which must have impacted the value of these assets. TheEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

proposed revised solution envisages a further haircut to the Arya- CoC where Rs 1.5 crores less
would be paid, over an extended timeline. There are no terms in the Resolution Plan or the Form H
submitted by Arya-RP that could provide such a benefit to Seroco. To the contrary, Clause 19(vii) of
the Resolution Plan provides that the preliminary approval of the Resolution Plan by the Arya-CoC
is binding on Seroco:
“19. Others:
[…]
(vii) We understand that the preliminary approval of the resolution pian is the
prerogative of the Committee of Creditors and the final approval of the same lies with
the Hon'ble Adjudicating authority i.e. NCLT and we undertake that the decision of
the Committee of Creditors and NCLT will be final and binding on us.” PART L
Therefore, there is no scope to grant reliefs even on the terms of the Resolution Plan.
As held in Section H of this judgement, common law remedies available under the
Contract Act are not available to the parties since a submitted Resolution Plan is not
a contract which can be otherwise voidable on account of frustration, force majeure
or other such instances. Hence, parties can only seek reliefs that are specifically
envisaged in the IBC.
L      Conclusion
201    This Court is cognizant that the extraordinary circumstance of the COVID-
19 pandemic would have had a significant impact on the businesses of Corporate
Debtors and upon successful Resolution Applicants whose Plans may not have been
sanctioned by the Adjudicating Authority in time, for myriad reasons. But the
legislative intent of the statute cannot be overridden by the Court to render outcomes
that can have grave economic implications which will impact the viability of the IBC.
202 The residual powers of the Adjudicating Authority under the IBC cannot be exercised to create
procedural remedies which have substantive outcomes on the process of insolvency. The framework,
as it stands, only enables withdrawals from the CIRP process by following the procedure detailed in
Section 12A of the IBC and Regulation 30A of the CIRP Regulations and in the situations recognized
in those provisions. Enabling withdrawals or modifications of the Resolution Plan at the behest of
the successful Resolution Applicant, once it has been submitted to the Adjudicating Authority after
due compliance with the procedural requirements and timelines, would create another tier of
negotiations which will PART L be wholly unregulated by the statute. Since the 330 days outer limit
of the CIRP under Section 12(3) of the IBC, including judicial proceedings, can be extended only in
exceptional circumstances, this open-ended process for further negotiations or a withdrawal, would
have a deleterious impact on the Corporate Debtor, its creditors, and the economy at large as the
liquidation value depletes with the passage of time. A failed negotiation for modification after
submission, or a withdrawal after approval by the CoC and submission to the AdjudicatingEbix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Authority, irrespective of the content of the terms envisaged by the Resolution Plan, when
unregulated by statutory timelines could occur after a lapse of time, as is the case in the present
three appeals before us. Permitting such a course of action would either result in a down-graded
resolution amount of the Corporate Debtor and/or a delayed liquidation with depreciated assets
which frustrates the core aim of the IBC.
203 If the legislature in its wisdom, were to recognize the concept of withdrawals or modifications to
a Resolution Plan after it has been submitted to the Adjudicating Authority, it must specifically
provide for a tether under the IBC and/or the Regulations. This tether must be coupled with
directions on narrowly defined grounds on which such actions are permissible and procedural
directions, which may include the timelines in which they can be proposed, voting requirements and
threshold for approval by the CoC (as the case may be). They must also contemplate at which stage
the Corporate Debtor may be sent into liquidation by the Adjudicating Authority or otherwise, in the
event of a failed negotiation for modification and/or withdrawal. These are matters for legislative
policy.
PART L 204 In the present framework, even if an impermissible understanding of equity is
imported through the route of residual powers or the terms of the Resolution Plan are interpreted in
a manner that enables the appellants’ desired course of action, it is wholly unclear on whether a
withdrawal of a CoC-approved Resolution Plan at a later stage of the process would result in the
Adjudicating Authority directing mandatory liquidation of the Corporate Debtor. Pertinently, this
direction has been otherwise provided in Section 33(1)(b) of the IBC when an Adjudicating
Authority rejects a Resolution Plan under Section 31. In this context, we hold that the existing
insolvency framework in India provides no scope for effecting further modifications or withdrawals
of CoC-approved Resolution Plans, at the behest of the successful Resolution Applicant, once the
plan has been submitted to the Adjudicating Authority. A Resolution Applicant, after obtaining the
financial information of the Corporate Debtor through the informational utilities and perusing the
IM, is assumed to have analyzed the risks in the business of the Corporate Debtor and submitted a
considered proposal. A submitted Resolution Plan is binding and irrevocable as between the CoC
and the successful Resolution Applicant in terms of the provisions of the IBC and the CIRP
Regulations. In the case of Kundan Care, since both, the Resolution Applicant and the CoC, have
requested for modification of the Resolution Plan because of the uncertainty over the PPA, cleared
by the ruling of this Court in Gujarat Urja (supra), a one-time relief under Article 142 of the
Constitution is provided with the conditions prescribed in Section K.2.
205 It would also be sobering for us to recognize that whilst this Court has declared the position in
law to not enable a withdrawal or modification to a PART L successful Resolution Applicant after its
submission to the Adjudicating Authority, long delays in approving the Resolution Plan by the
Adjudicating Authority affect the subsequent implementation of the plan. These delays, if systemic
and frequent, will have an undeniable impact on the commercial assessment that the parties
undertake during the course of the negotiation. The thirty-second report of the Ministry of
Corporate Affairs’ Standing Committee on Finance (2020-2021) on the ‘Implementation of
Insolvency and Bankruptcy Code- Pitfalls and Solutions’ 127 represented a despondent state of
affairs with regard to pendency of applications before the Adjudicating Authority. It noted128:Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

Standing Committee on Finance, Seventeenth Lok Sabha, Ministry of Corporate
Affairs, ‘Implementation of Insolvency and Bankruptcy Code- Pitfalls and Solutions:
Thirty-second Report’ (August 2021) <available at
https://www.ibbi.gov.in/uploads/whatsnew/fc8fd95f0816acc5b6ab9e64c0a892ac.pdf>
accessed on 20 August Ibid., page 6 PART L In its observations, the Report noted
that a delay in the resolution process with more than seventy-one per cent cases
pending for more than 180 days is in deviation of the original objective and timeline
for CIRP that was envisaged by the IBC129. The delays were attributable to: (i) the
NCLT taking considerable time in admitting CIRPs; (ii) late and unsolicited bids by
Resolution Applicants after the original bidder becomes public upon passage of the
deadline for submission of the Plan; and (iii) multiplicity of litigation and the
appellate process to the NCLAT and the Supreme Court130. Such inordinate delays
cause commercial uncertainty, degradation in the value of the Corporate Debtor and
makes the insolvency process inefficient and expensive. We urge the NCLT and
NCLAT to be sensitive to the effect of such delays on the insolvency resolution
process and be cognizant that adjournments hamper the efficacy of the judicial
process. The NCLT and the NCLAT should endeavor, on a best effort basis, to strictly
adhere to the timelines stipulated under the IBC and clear pending resolution plans
forthwith. Judicial delay was one of the major reasons for the failure of the insolvency
regime that was in effect prior to the IBC. We cannot let the present insolvency
regime meet the same fate.
Ibid., Page 20-21 Ibid., Page 23-25 PART L
206 In light of the above, the appeals preferred by Ebix (Civil Appeal 3224 of 2020) and Seroco
(Civil Appeal 295 of 2021) stand dismissed. The parties to the appeal preferred by Kundan Care
(Civil Appeal 3560 of 2020) shall abide by the directions issued by this Court in exercise of its
Article 142 powers as a one-time relief, as specified in paragraph 196 (Section K.2) of this
judgement. 207 Pending application(s), if any, shall stand disposed of.
…….………….…………………...........................J. [Dr Dhananjaya Y Chandrachud]
…….…………………………...............................J. [M. R. Shah] New Delhi;
September 13, 2021.Ebix Singapore Pte Ltd. vs Committee Of Creditors Of Educomp ... on 13 September, 2021

