Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021
Equivalent citations: AIR 2021 SUPREME COURT 3346, AIRONLINE 2021 SC
325
Author: Sanjay Kishan Kaul
Bench: Hrishikesh Roy, Dinesh Maheshwari, Sanjay Kishan Kaul
                                                                              REPORTABLE
                                       IN THE SUPREME COURT OF INDIA
                                        CIVIL ORIGINAL JURISDICTION
                                        WRIT PETITION (C) NO.1088 OF 2020
                         AJIT MOHAN & ORS.                               … PETITIONERS
                                                       VERSUS
                         LEGISLATIVE ASSEMBLY
                         NATIONAL CAPITAL TERRITORY
                         OF DELHI & ORS.                                 …RESPONDENTS
                                                     INDEX
                         S. No.                    Contents                   Page No.
                           1.      Prolegomenon                                   2
                           2.      The Factual Context                           10
                           3.      The Submissions                               33
                             (a)   The Privilege Issue                           35
                             (b)   Privileges, Free Speech and Privacy           73
                             (c)   Legislative Competence                        89
                           4.      Recent Developments                          129
                           5.      The Opinion                                  135
                             (a)   On the issue of Privilege                    143
                             (b)   On Privileges & Fundamental Rights           160
                             (c)   On Legislative Competence                    164
Signature Not Verified
                           6.      Conclusion                                   185
Digitally signed by
Charanjeet kaur
                           7.      Postscript                                   187
Date: 2021.07.08
16:37:35 IST
Reason:Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

                                                                                         [1]
                          JUDGMENT
SANJAY KISHAN KAUL, J.
Prolegomenon1:
1. The technological age has produced digital platforms – not like the railway
platforms where trains were regulated on arrival and departure.
These digital platforms can be imminently uncontrollable at times and carry their own challenges.
One form of digital platforms are the intermediaries that claim to be providing a platform for
exchange of ideas without any contribution of their own. It is their say that they are not responsible
for all that transpires on their platform; though on complaints being made, they do remove offensive
content based on their internal guidelines. The power and potentiality of these intermediaries is
vast, running across borders. These are multinational corporations with large wealth and influence
at their command. By the very reason of the platform they provide, their influence extends over
populations across borders. Facebook is one such corporation.
2. A testament to the wide-ranging services which Facebook offers is 1 “Preface”; See A. M. Singhvi
et. al., The Law of Emergency Powers – Comparative Common Law Perspectives (Springer, 2020).
the fact that it has about 2.85 billion monthly active users as of March, 2021.2 This is over 1/3rd of
the total population of this planet. In the national context, Facebook is the most popular social
media platform in India with about 270 million registered users. Such vast powers must necessarily
come with responsibility. Entities like Facebook have to remain accountable to those who entrust
them with such power. While Facebook has played a crucial role in enabling free speech by
providing a voice to the voiceless and a means to escape state censorship, we cannot lose sight of the
fact that it has simultaneously become a platform for disruptive messages, voices, and ideologies.
The successful functioning of a liberal democracy can only be ensured when citizens are able to
make informed decisions. Such decisions have to be made keeping in mind a plurality of
perspectives and ideas. The information explosion in the digital age is capable of creating new
challenges that are insidiously modulating the debate on issues where opinions can be vastly
divided. Thus, while social media, on the one hand, is enhancing equal and open dialogue between
citizens and policy makers; on the other hand, it has become a tool in the hands of various interest
groups who have 2 Facebook, Press Release, Facebook reports 1st Quarter 2021 Results, (2021)
accessible at https://www.prnewswire.com/news-releases/facebook-reports-first-
quarter-2021-results-301279518.html.
recognised its disruptive potential. This results in a paradoxical outcome where extremist views are
peddled into the mainstream, thereby spreading misinformation. Established independent
democracies are seeing the effect of such ripples across the globe and are concerned. Election and
voting processes, the very foundation of a democratic government, stand threatened by social mediaAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

manipulation. This has given rise to significant debates about the increasing concentration of power
in platforms like Facebook, more so as they are said to employ business models that are
privacy-intrusive and attention soliciting. 3 The effect on a stable society can be cataclysmic with
citizens being ‘polarized and parlayzed’ by such “debates”, dividing the society vertically. Less
informed individuals might have a tendency to not verify information sourced from friends, or to
treat information received from populist leaders as the gospel truth.
3. It is interesting to note that the Oxford Dictionary in 2016 chose “Post-Truth” as the word of the
year. The adjective has been defined as “relating to or denoting circumstances in which objective
facts are less 3 UNESCO, Concept Note, Media for Democracy, Journalism and Elections in times of
Misinformation, (2019) accessible at:
https://en.unesco.org/sites/default/files/wpfd2019_concept_note_en.pdf.
influential in shaping public opinion than appeals to emotion and personal belief.”4
This expression has a period relevance when it came to be recognised contextually
with divided debates about the 2016 US Presidential Elections and Brexit – two
important events with effects beyond their territorial limits. The obfuscation of facts,
abandonment of evidentiary standards in reasoning, and outright lying in the public
sphere left many aghast. A lot of blame was sought to be placed at the door of social
media, it being a source of this evolving contemporary phenomenon where objective
truth is becoming a commodity with diminishing value. George Orwell, in his 1943
essay titled “Looking Back on the Spanish War” had expressed “…the very concept of
objective truth is fading out of the world. After all, the chances are that those lies, or
at any rate similar lies will pass into history”5 – the words have proved to be
prophetic.
4. In the conspectus of the aforesaid, it is difficult to accept the simplistic approach adopted by
Facebook - that it is merely a platform posting third party information and has no role in generating,
controlling 4 Oxford Dictionary Word of the Year 2016, accessible at:
https://languages.oup.com/word-of-the-year/2016/.
5 See K. Gessen, Introduction, 26, in All Art Is Propaganda: Critical Essays (G. Orwell et. al., 2008).
or modulating that information. The endeavour to hide behind such simplistic models have been
found to be unacceptable by the UK Parliament. The House of Commons Digital, Culture, Media and
Sport Select Committee in its 2018 Report had opined that this would amount to shirking of their
responsibilities with respect to content regulation on their site.6
5. Serious questions have been raised about whether there is a faulty architecture of such
intermediary platforms and whether the kind of free, liberal debate which they sought to encourage
has itself become a casualty, defeating the very objective of providing that platform. It is too late in
the day for companies like Facebook to deny that they use algorithms (which are sequences ofAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

instructions) with some human intervention to personalise content and news to target users. The
algorithms select the content based on several factors including social connections, location, and
past online activity of the user. These algorithms are often far from objective with biases capable of
getting 6 Digital, Culture, Media and Sport Committee, U.K. House of Commons, Disinformation
and 'fake news': Final Report, 20-44 (18/02/2019), accessible at:
https://publications.parliament.uk/pa/cm201719/cmselect/cmcumeds/1791/1791.
pdf.
replicated and reinforced. The role played by Facebook is, thus, more active and not
as innocuous as is often presented when dealing with third party content.
6. In fact, in the proceedings before us, it is their contention that there are times
when they are at the receiving end of both groups alleging bias towards the other but
then this is a sequitur to their ability to decide which content to amplify, suggest, and
elevate. Internationally, Facebook has had to recognise its role in failing to prevent
division and incitement of offline violence in the context of the stated ethnic
cleansing in Myanmar where a crescendo of misinformation and posts, somehow
missed by Facebook employees, helped fuel the violence. 7 The platform similarly
apologised for its lack of serious response to evident signs of abuse of the platform in
Sri Lanka, which again is stated to have stoked widespread violence in 2018 in the
country and had to acknowledge its need to be regulated though the exact method is
still unclear and a prerogative of law making authority.
7 Facebook admits it was used to 'incite offline violence' in Myanmar , BBC
(06/11/2018), accessible at: https://www.bbc.com/news/world-asia-46105934.
Joshua Brustein, Facebook Apologizes for Role in Sri Lankan Violence , Bloomberg (13/05/2020),
accessible at: https://www.bloomberg.com/news/articles/2020-05-
12/facebook-apologizes-for-role-in-sri-lankan-violence.
7. There have been endeavours in light of the aforesaid by countries like Australia, US, the UK, and
the EU for ways to regulate platforms such as Facebook in an efficient manner but their efforts are
still at a nascent stage as studies are undertaken to understand the dynamism of the platform and its
disruptive potential. A recent example has been Australia’s effort to formulate a legislation that
would require Facebook to pay publishers for using their news stories. The law was seen as a tool to
regulate the platform’s unchecked influence over political discourse, society, and democracy. In
response, Facebook blocked all news on its platform across the country with the result that there
was some relaxation but ultimately a via media was found. The US has also seen heated debates
arising from the 2016 Presidential elections with allegations of supposed interference by Russia
allegedly facilitated by platforms like Facebook. Last year, the EU formulated legislative proposals
namely the Digital Services Act and Digital Markets Act, setting out rules for platforms to follow.8 8
News Media and Digital Platforms Mandatory Bargaining Code Bill, 2020 was formulated by
Australia; See Alex Barker, Jamie Smyth et al., Facebook bans Australian news as impact of mediaAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

law is felt globally, Financial Times (18/02/2021), accessible at:
https://www.ft.com/content/cec5d055-c2d1-4d5f- a392-a6343beb0b01. See also European
Parliament, Social media and democracy: we need laws, not platform guidelines (10/02/2021)
accessible at:
https://www.europarl.europa.eu/news/en/headlines/society/20210204STO97129/s
8. We have penned down a detailed introduction to appreciate the gravity of what
was debated before us in the context of Facebook’s hands off approach, who have
urged that they cannot be compelled to participate in proceedings of Sub Committees
formed by the Parliament or the Legislative Assemblies. The immense power that
platforms like Facebook wield has stirred a debate not only in our country but across
the world. The endeavour has been to draw a line between tackling hate speech and
fake news on the one hand and suppressing legitimate speech which may make those
in power uncomfortable, on the other. This delicate balance has thus far only been
maintained by the intermediaries by being value-neutral. The significance of this is
all the more in a democracy which itself rests on certain core values. This
unprecedented degree of influence necessitates safeguards and caution in
consonance with democratic values. Platforms and intermediaries must subserve the
principal objective as a valuable tool for public good upholding democratic values.
ocial-media-and-democracy-we-need-laws-not-platform-guidelines.
9. The sheer population of our country makes it an important destination for Facebook. We are
possibly more diverse than the whole of Europe in local culture, food, clothing, language, religion,
traditions and yet have a history of what has now commonly been called ‘unity in diversity’. This
cannot be disrupted at any cost or under any professed freedom by a giant like Facebook claiming
ignorance or lack of any pivotal role.
The factual context:
10. Delhi, the capital of our country, witnessed an unfortunate eruption of violence between 24th
and 29th February, 2020 with communal riots in different parts of North-East Delhi. This caused
loss of life and property and disrupted the working of civic services in Delhi. It need not be stated
that like any other incident of this nature, it also took a political colour. This produced a divide in
the society with people across political affiliations blaming each other.
11. In the wake of these riots, the Legislative Assembly of the National Capital Territory of Delhi
(“the Assembly”) resolved to constitute a Committee on Peace and Harmony (“the Committee”)
under the chairmanship of Mr. Raghav Chadha, Member, Legislative Assembly on 02.03.2020, to
inter alia “consider the factors and situations which have the potential to disturb communal
harmony in the National Capital Territory of Delhi and suggest measures to eliminate such factors
and deal with such situations so as to establish harmony among different religious or linguistic
communities or social groups.” It is the say of the Assembly and the Committee, that it is theirAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

objective to detect what happened and formulate recommendations to ensure it does not happen
again. It is appropriate to extract the Terms of Reference of the Committee dated 12.03.2020 as
issued by the Assembly Secretariat as under:
“LEGISLATIVE ASSEMBLY SECRETARIAT NATIONAL CAPITAL TERRITORY OF
DELHI BULLETIN PART-II (General information relating to legislative and other
matters) Thursday 12th March, 2020/ 22, Phalgun, 1941 (Shaka) Subject: Terms of
Reference of the Committee on Peace and Harmony.
Hon’ble Members are hereby informed that Hon’ble Speaker has approved the
following Terms of Reference for the Committee on Peace and Harmony constituted
on 02.03.2020:
1. There shall be a Committee on Peace and Harmony inter-alia to consider the
factors and situations which have the potential to disturb communal harmony in the
National Capital Territory of Delhi and suggest measures to eliminate such factors
and deal with such situations so as to establish harmony among different religious or
linguistic communities or social groups.
2. The Committee shall consist of nine members who shall be nominated by the
Speaker.
3. The term of the Committee shall be one year.
4. The functions of the Committee shall be:-
(i) to consider the petitions, complaints or reports from the members of the public,
social organizations, journalists etc. on the situations prevailing in a particular
area/areas which have the potential to disturb communal peace and harmony or
where communal riots have occurred and to examine in detail and identify the factors
responsible for it.
(ii) to recommend suitable measures to defuse the situation and restore harmony
among religious communities, linguistic communities or social groups.
(iii) to recognise, reward and felicitate individuals who played a role in the protection
of fellow citizens during acts of communal violence, or undertook any activity that led
to the restoration of peace in the state.
(iv) to recognize, reward and felicitate individuals whose information resulted in the
registration of First Information Reports (FIRs) in relation to the crimes committed
during the communal riots.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

(v) to undertake scientific study of the religious, linguistic and social composition of
the population of NCR Delhi, with a view to identifying and strengthening the factors
which unite the people despite the diversity in terms of their social, religious,
economic and cultural tradition.
(vi) to recommend measures to be undertaken by the government towards
establishing communal harmony and peace in the state.
(vii) to recommend action against such persons against whom incriminating evidence
is found or prima facie case is made out for incitement to violence.
(viii) to examine such other matters, broadly in conformity with the objectives of the
Committee, as may seem fit to the Committee or are specifically referred to it by the
House or the Speaker.
(ix) The Committee shall submit its report to the House. If the House is not in session
the Committee may submit the report to the Speaker who may forward the same to
the Govt. for necessary action thereon. The Secretary shall lay the report on the Table
of the House on the first day of the next session.
(x) As soon as maybe after the submission of the report to the House by the
Committee, the Govt. shall take appropriate action in the matter dealt with in the
report and a complete statement on the action taken by all the authorities thereon
shall be laid in the House within two weeks after the report is presented in the House.
(xi) In considering/examining the complaints/reports etc., the Committee may
engage the services of experts.
(xii) The Speaker shall reconstitute the Committee on the expiry of its term.
(xiii) Except in respect of matters provided in these rules, other matters in
connection with the Committee shall be dealt with under the general rules relating to
the Committees.
(xiv) The Speaker may issue such directions as he may consider necessary for
regulating the procedure in connection with all matters involving the consideration of
any question that may be brought up before the Committee.
(xv) The Committee shall have all the powers, privileges and immunities as are
available to the Committees of the Legislative Assembly of National Capital Territory
of Delhi.
C. Velmurugan Secretary” (Emphasis supplied)Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

12. It appears that the first public meeting was held on 05.03.2020, which was attended by religious
leaders, social workers and various officials from different walks of life. It is the say of the
Committee that thousands of complaints were received which inter alia suggested that Facebook
had been used as a platform for fomenting hate and jeopardising communal harmony. This was
further fuelled by an article published in the Wall Street Journal on 14.8.2020 titled “Facebook’s
Hate-Speech Rules Collide with Indian Politics” (“the Article”) suggesting that there was a broad
pattern of favouritism towards the ruling party and Hindu hardliners. The Article also made serious
allegations of lapses on the part of Facebook India in addressing hate speech content.
13. The aforesaid resulted in two important developments. The first was that on 20.08.2020 the
Parliamentary Standing Committee on Information Technology (“Parliamentary Committee”)
issued a notice requesting Mr. Ajit Mohan, Petitioner No. 1 herein, Vice President and Managing
Director of Petitioner No. 2 Facebook India Online Services Private Limited, to appear before the
Parliamentary Committee on 02.09.2020. The notice stated that the Committee was seeking
Facebook India’s views inter alia on the subject of “safeguarding citizens’ rights and prevention of
misuse of social/online news media platforms including special emphasis on women security in the
digital space.” The letter reads as under:
“MOST IMMEDIATE LOK SABHA SECRETARIAT (STANDING COMMITTEE ON
INFORMATION TECHNOLOGY BRANCH) FAX: 23010756 PARLIAMENT HOUSE
ANNEXE NEW DELHI-110001 No.18/1(iv)/IT/2020 20th August, 2020 From Y.M.
Kandpal Director To Shri Ajit Mohan Vice President & MD, Facebook India Online
Services Pvt. Ltd., 7th Floor, Parsvnath Capital Towers, Bhai Veer Singh Marg, Gole
Market, New Delhi-110001.
Subject: Examination of the subject ‘Safeguarding citizens’ rights and prevention of
misuse of social/online news media platforms including special emphasis on women
security in the digital space’ xxxxx Sir, I am directed to state that the Standing
Committee on Information Technology are examining the subject ‘Safeguarding
citizens’ rights and prevention of misuse of social/online news media platforms
including special emphasis on women security in the digital space’.
2. Keeping in view the importance of the subject and its wider implications in the
present context, the Committee have decided to hear the views of representatives of
Facebook India on the above subject at their sitting scheduled to be held on
Wednesday, 2 nd September, 2020 from 1600 hrs. onwards in Main Committee
Room, Parliament House Annexe, New Delhi.
3. It is, therefore, requested that senior most representatives of Facebook India may
make it convenient to appear before the Committee on the said date, time and venue.
The names/designations of the representatives from Facebook India who will appear
before the Committee may be intimated to this Secretariat by 27th August, 2020 or
before positively. In view of the COVID-19 pandemic, you are requested to restrict the
number of representatives who will attend the scheduled sitting on 2 nd September,Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

2020 to a maximum of 5 persons.
4. You may like to submit a brief note highlighting your views/comments on the
subject matter to the Committee before sitting. The same can be e-mailed at
comit@sansad.nic.in.
5. Entry passes to the venue of the sitting may be collected from the IT Committee
Branch in advance.
6. A copy of the points of Conduct and Etiquette to be observed by non-official
witnesses appearing before the Committee is enclosed at Annexure-I for your
guidance.
Yours faithfully, Sd/-
Director comit@sansad.nic.in”
14. Along with the aforesaid letter was annexed as Annexure-I the Points of Conduct and Etiquette
for the guidance of witnesses appearing before the Parliamentary Committees or their
sub-committees, which inter alia in para 8, set out as to what would constitute breach of privilege
and contempt of the Parliamentary Committee. The said Annexure reads as under:
“ANNEXURE-I POINTS OF CONDUCT AND ETIQUETTE FOR THE GUIDANCE OF
WITNESSES APPEARING BEFORE THE PARLIAMENTARY COMMITTEES OR
THEIR SUB-
COMMITTEES.
The witnesses should note the following points while appearing before Parliamentary
Committee:
1. Due respects to the Chairman and the Committee/Sub-
Committee should be shown by the witness by bowing while taking his seat.
2. The witness should take the seat earmarked for him opposite to the seat of the Chairman.
3. The witness should take the oath, or make affirmation, if so asked by the Chairman. The oath or
affirmation will be administered by the Secretary. The witness will take the oath or make affirmation
standing in his seat and bow to the Chair just before taking the oath or making the affirmation and
immediately afterwards.
4. The witness should answer specific questions put to him either by the Chairman, or by a Member
of the Committee or by any other person authorized by the Chairman. The witness may be asked toAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

place before the Committee any other points that have not been covered and which a witness thinks
are essential to be placed before the Committee.
5. All submissions to the Chair and the Committee should be couched in courteous and polite
language.
6. When the evidence is completed, and the witness is asked to withdraw, he should, while leaving,
bow to the Chair.
7. The witness should not smoke or chew when he is seated before the Committee.
8. Subject to the provisions of Rule 270 of the Rules of Procedure and Conduct of Business in the
Lok Sabha, the witness should note that following acts shall constitute breaches of privilege and
contempt of Committee:-
(a) Refusal to answer questions.
(b) Prevarication or willfully giving false evidence or suppressing the truth or
misleading the Committee.
(c) Trifling with the Committee; returning insulting answers.
(d) Destroying or damaging a material document relative to the enquiry.
9. The witness should not bring cellular phones inside the Parliament House Complex.
xxxxx”
15. Mr. Ajit Mohan, Petitioner No. 1, duly appeared before the Parliamentary Committee and offered
his views.
16. The second development took place on 31.08.2020 when the Chairman of the Committee held a
press conference (“the press conference”) wherein he summarised the complaints received in the
hearings conducted between 25.08.2020 and 31.08.2020. In this process, he stated that it prima
facie appeared that Facebook had colluded with vested interests during the Delhi riots in February,
2020. Comments were also made by the Chairman to the effect that Facebook ought to be treated as
a co-accused and an independent investigation should be carried out into its role in the riots. It was
stated that if the investigation uncovered strong evidence against Facebook, a supplementary
chargesheet should be filed in this regard (we may note here itself that the stand taken during the
course of arguments was that these were not the Chairman’s own views but were merely the views
expressed by the Committee). Since Facebook had not been heard, it was observed in the press
conference that before any action is taken in writing, Facebook should be given a chance to appear
before the Committee. Consequently, notice for appearance was issued on 10.09.2020 (“First
Impugned Summons”) by the Assembly to Mr. Ajit Mohan in the capacity of Vice President andAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

Managing Director of Facebook India. The First Impugned Summons highlighted the factum of
numerous complaints alleging intentional omission and deliberate inaction on the part of Facebook
in tackling hate speech online. The Article was also referred to and Mr. Ajit Mohan was called upon
to deliver insights to the Committee with respect to Facebook India’s internal functioning and
enforcement of policies in view of the special knowledge that he possessed. It was clearly stated that
he was being called as a witness for testifying on oath before the Committee on 15.09.2020.
Significantly, no consequences in the form of breach of parliamentary privilege were intimated in
case Mr. Ajit Mohan refused to appear. The same reads as under:
“LEGISLATIVE ASSEMBLY NATIONAL CAPITAL TERRITORY OF DELHI OLD
SECRETARIAT, DELHI 110054.
Notice/Summon for Appearance No.24/3/P&H/2020/LAS-VII/Leg./33 Date:
10.09.2020 To, Mr. Ajit Mohan, Vice President & Managing Director,
India-Facebook, Address:-1 Address:-2 Facebook India Online Services Pvt. Ltd. One
BKC Level-17, DLF Horizon Building, Bandra Kurla Complex Two Horizon Centre,
Golf Course Road, Bandra (E) DLF Phase 5, Sector 43, Mumbai, India-400051
Gurugram, Haryana 122022 Subject: Notice for Appearance before the Delhi
Legislative Assembly’s Committee on Peace and Harmony, NCT of Delhi.
The Delhi Legislative Assembly’s committee on ‘Peace and Harmony’, headed by
Hon’ble Member of Legislative Assembly of NCT of Delhi, Mr. Raghav Chadha, as its
Chairman along with other Hon’ble Members of the Legislative Assembly, assisting
and facilitating the state’s endeavour to maintain and promote an irenic atmosphere
in the city as well as establishing a conducive milieu of concordance, peace and
pacification amongst different communities residing in NCT of Delhi.
Pertinently, the committee has received numerous complaints alleging inter alia
intentional omission and deliberate inaction on the part of social media
platform-Facebook to apply hate speech rules and Polices which has allegedly led to
serious repercussions and disruption of peace and harmony across the NCT of Delhi.
A few complainants have also drawn considerable strength from the news report
published by The Wall Street Journal on 14.08.2020, titled as ‘Facebook’s
Hate-Speech Rules Collide With Indian Politics’. The committee had promptly taken
cognizance of serious allegations set out in the vetted complaints and have begun the
proceedings in this regard, pursuant to which numerous witnesses have been
examined.
Significantly, in the wake of serious allegations leveled against Facebook India unit
which you have been spearheading since 2019, you, the addressee, as the
Vice-President and Managing Director of Facebook India and as a representative of
the same, are best suited to deliver insights to the committee with respect to
Facebook India’s internal functioning and enforcement of policies, and thus, your
special knowledge in this regard would be imperative for the committee whileAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

examining the current issue in hand.
In view thereof, the committee, under the Chairmanship of Hon’be (sic) MLA Sh.
Raghav Chadha, calls you, the addressee, as a witness for testifying on oath and for
rendering your assistance by providing the relevant information and explanations in
order to smoothly expedite the determination of the veracity of allegations leveled
against Facebook in the complaints and depositions made before the committee. In
pursuance thereof, we hereby summon you, the addressee, to appear before the
committee on 15 th September, 2020 at 12 Noon at MLA Lounge-1, Delhi Vidhan
Sabha, for the purpose of recording your deposition on oath and participating in the
proceedings carried out by the committee.
(Deputy Secretary) The Committee on Peace and Harmony NCT of Delhi PH-011-23890384 Email
ID dvscommittee@delhi.gov.in”
17. One Mr. Vikram Langeh, Director of Trust and Safety, Facebook sent a reply dated 13.09.2020
emphasising that Facebook’s internal policies seek to protect user safety and security and also
emphasised the different mechanisms it employs to tackle hate speech content. The factum of
Facebook having given testimony before the Parliamentary Committee was also set out. A plea was
raised that the role of regulation of intermediaries like Facebook squarely fell within the exclusive
authority of Union of India; in exercise of which the Parliament had enacted the Information
Technology Act, 2000 (“the IT Act”). Not only that, the subject of law and order in the NCT of Delhi
was stated to fall within the exclusive domain of the Union of India. On these pleas the First
Impugned Summons was objected to and requested to be recalled. The reply reads as under:
“FACEBOOK September 13, 2020 To, The Hon’ble Chairman, The Committee on
Peace and Harmony, Delhi Legislative Assembly, NCT of Delhi.
Subject: Response to Notice for Appearance before the Delhi Legislative Assembly’s
Committee on Peace and Harmony, NCT of Delhi dated September 10, 2020 Hon’ble
Chairman, Facebook India Online Services Private Limited is in receipt of the notice
dated September 10, 2020 (“Notice”) issued by the Delhi Legislative Assembly’s
Committee on Peace and Harmony (“Committee”).
Facebook, Inc. (“Facebook”) operates and manages the Facebook platform, and
provides the Facebook service to users in India. Facebook shares the Committee’s
concerns regarding the dissemination of hate speech online and has implemented
robust measures to curb its spread on Facebook’s platforms. Facebook bans
individuals and groups that proclaim a hateful and violent mission from having a
presence on its platforms. Facebook seeks to apply its comprehensive standards
uniformly and has identified a range of such individual and groups across the globe.
Facebook has also built some of the most advanced systems in the world to protect its
users’ safety and security, investing billions of dollars in technology and hiring tens ofAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

thousands of people to work on safety and security. Based on these efforts, we
removed 22.5 million pieces of hate speech content in the second quarter of 2020 (up
from just 1.6 million pieces of hate speech removed in the last quarter of 2017),
nearly 95 percent of which we removed before it was reported to us. Facebook is
committed to being more transparent about how it combats hate speech and
routinely publishes a Transparency Report, which provides details about steps taken
by Facebook to prevent and action content that violates its policies.
In view of the importance of this subject, the Parliament’s Standing Committee on Information
Technology (“Parliamentary Standing Committee”) is examining the issues raised in your Notice as
a part of its inquiry into “Safeguarding citizens’ rights”. We gave testimony before the Parliamentary
Standing Committee. We are enclosing the notice received from the Parliamentary Standing
Committee for your reference. (Annexure A) As you are well aware, the regulation of intermediaries
like Facebook falls within the exclusive authority of the Union of India and in exercise of this power
to regulate “communications”, Parliament has enacted the Information Technology Act, 2000.
Further, the subject of “law and order” in the National Capital Territory of Delhi also falls within the
exclusive domain of the Union of India.
Given that the issues raised by the Notice involve subject matter within the exclusive domain of the
Union of India, and that the matters are under active consideration by Parliament, we respectfully
object to the Notice and request that you recall it.
Facebook responds to the Notice without prejudice to, and expressly reserving, any and all of its
rights.
Sincerely, For Facebook Vikram Langeh Director, Trust & Safety, Facebook.”
18. The aforesaid was not acceptable to the Committee, which formulated a reply to Facebook’s
response on 18.09.2020, this time addressing it to both Mr. Ajit Mohan and Mr. Vikram Langeh.
The three annexures enclosed with the reply were: (a) Terms of Reference of the Committee (“Terms
of Reference”); (b) Sections 18 and 37 of the Government of National Capital Territory Act, 1991
(“GNCTD Act”); and (c) fresh summons issued to Mr. Ajit Mohan (“Second Impugned Summons”)
under Rule 172 of the Rules of Procedure and Conduct of Business in the Legislative Assembly of
NCT of Delhi (“the Rules”).
19. The Committee’s reply alluded to its Terms of Reference to emphasise that it was in furtherance
of the objective of good governance and to carry out responsibilities of the State under the
Constitution. The purpose, it was stated, was to invite the public to join this exploratory process, the
remit of which included making suggestions to the Union Government beyond using the
mechanisms of the Inter-State Council. This was stated to be in line with the principles of
cooperative federalism, which encompassed a large number of areas. It is at this stage that a
perceived element of threat was held out to Mr. Ajit Mohan stating that his refusal to appear was
inconsistent with the law of privileges of a legislature (which extends to the Committee and its
members). He was asked to appear before the Committee on 23.09.2020 in the “spirit of democraticAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

participation and constitutional mandates.” Importantly, it was clearly stated that non-compliance
would be treated as breach of privilege of the Committee and necessary action would be taken.
20. It is the aforesaid Second Impugned Summons which triggered the filing of the present
proceedings under Article 32 of the Constitution of India by Mr. Ajit Mohan as the first petitioner, in
his capacity as the Vice President and Managing Director of Facebook India Online Services Private
Limited, which is the 2nd petitioner. The third petitioner is the parent company, Facebook Inc., US.
The array of respondents include the Assembly as the first Respondent while Respondent Nos. 2 to 4
are the Union of India, represented through different Ministries, being Ministry of Law and Justice,
Ministry of Home Affairs and Ministry of Electronics and Information Technology. Respondent Nos.
5 & 6 are the Lok Sabha and the Rajya Sabha respectively. Delhi Police was impleaded as the 7 th
respondent. We may note that in the course of the proceedings the Committee sought to be
impleaded as a party and in terms of the consent order dated 20.01.2021 the said entity was
permitted to intervene. The prayers made in the writ petition are as under:
“a. Issue a writ/order or direction in the nature of Mandamus setting aside the
Impugned Summonses dated September 10, 2020 and September 18, 2020;
b. Issue a writ/order or direction in the nature of Prohibition restraining Respondent
No.1 from taking any coercive action against Petitioners in furtherance of the
Impugned Summonses;
c. Issue or pass any writ, direction or order, which this Hon’ble Court may deem fit
and proper under the facts and circumstances of the case.”
21. On 23.09.2020, in the presence of the counsel of the parties, notice was issued. Dr. Singhvi,
learned Senior Advocate appearing for Respondent No.1, on instructions, stated that the meeting
scheduled for the said date had already been deferred and no further meeting would be fixed qua the
petitioners till the next date of hearing. Further, on the Court’s query regarding the role of
Respondent Nos. 5 and 6 (the Lok Sabha and the Rajya Sabha respectively), Mr. Harish Salve,
learned Senior Advocate appearing for Petitioner Nos. 1 and 2 submitted that the only purpose of
serving them was that although no relief was claimed, there was a perception that there may be
some interplay of powers between the Delhi Secretariat and the Secretariat of the Central
Government.
22. The aforesaid interim arrangement continued as pleadings were completed. The matter was set
down for hearing with rule nisi being issued on 21.01.2021. The issue was debated before us on
numerous dates thereafter and the hearing concluded on 24.02.2021. We recorded that the counsels
had argued over a period of 26 hours, leaving the task to us to pen down the judgment - which we
seek to perform now.
23. At this stage, we must note a significant development that arose during the course of the
proceedings, possibly emanating from certain questions posed by the Court qua the press
conference, the summonses issued to Petitioner No.1, and on account of certain submissionsAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

advanced by learned counsel for the Petitioners. An affidavit was placed before us (as recorded in
the proceedings of 04.02.2021) in terms whereof the two impugned summonses issued to Petitioner
No.1 dated 10.09.2020 and 18.09.2020 stood withdrawn. A fresh notice was issued on 03.02.2021
(“The New Summons”) to Petitioner No. 2, i.e. Facebook India alone. The New Summons dated
03.02.2021 reads as under:
“LEGISLATIVE ASSEMBLY NATIONAL CAPITAL TERRITORY OF DELHI OLD
SECRETARIAT, DELHI 1100 54 Committee on Peace and Harmony
No.24/3/P&H/2020/LAS-VII/Leg./1305 Date: 03.02.2021 Notice/Summon for
Appearance To, Facebook India Online Services Pvt Limited Address 1 One BKC,
Bandra Kurla Complex Bandra (E) Mumbai, India-400051 Address 2 Level-17, DLF
Horizon Building, Two Horizon Centre, Golf Course Road, DLF Phase 5, Sector 43,
Gurugram, Haryana 122022 Subject: Notice for Appearance under Rule 172 of Rules
of Procedure and Conduct of Business in the Legislative Assembly of NCT of Delhi.
1. In supersession of earlier notice(s)/summons dated 10.09.2020 and 18.09.2020,
the present notice for appearance is being issued.
2. I am directed to state that the National Capital Territory of Delhi had witnessed
unprecedented communal disharmony and violence in February 2020. The Hon’ble
Speaker of the Legislative Assembly of NCT of Delhi has constituted a Committee on
Peace on (sic.) Harmony under the Chairmanship of Sh. Raghav Chadha along with
other Hon’ble Members of the Legislative Assembly to recommend suitable measures
to defuse the situation and restore harmony among religious communities, linguistic
communities or social groups. The Committee aims to recommend preventive and
remedial measures concerning issues of governance, social cohesion, unity,
brotherhood and peace. The Committee further aims to recommend measures to
strengthen overall social and economic development in the context of establishing
communal harmony and peace in society in the NCT of Delhi.
3. Keeping in view the importance of the above subject and its implication on persons
in the NCT of Delhi, various persons including journalists, former bureaucrats and
community leaders have appeared before the Committee to offer their evidence and
suggestions. The Committee has observed and is of the opinion that social media has
a very important role in curbing the spread of false, provocative and malicious
messages which can fan the violence and disharmony.
4. Since, Facebook has lakhs of users in the NCT of Delhi, in the above-stated context,
the Committee has decided to hear the views of representative(s) of Facebook India
on the above subject at their sitting scheduled to be held on 25th February, 2021 from
11 AM onwards in MLA Lounge-1, Assembly Complex, Old Secretariat, Delhi-110054
as per the Rules of Procedure and Conduct of Business of the House.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

5. It is, therefore, requested that a competent senior representative(s) of Facebook
India well conversant with the issues involved may appear before the Committee on
the said date, time and venue as a witness. The names/designations of the
representatives from Facebook India who will appear before the Committee may be
intimated to this Secretariat by 24 th February, 2021 or before positively. Because of
the COVID-19 pandemic, you are requested to restrict the number of representatives
to a minimum.
6. Please note that failure to send a representative as summoned above, could in
terms of the Rules of Procedure and Conduct of Business in the Legislative Assembly
of NCT of Delhi lead to initiation of proceedings for breach of privilege/contempt of
the Assembly.
7. In light of the abovementioned supersession, previous notice(s)/summons dated
10.09.2020 and 18.09.2020 stand withdrawn Sd/-
(Sadanand Sah) Deputy Secretary PH-011-23890384 E-mail ID: dvscommittee@delhi.gov.in ” Dr.
Singhvi submitted that since the legal position was being debated in the larger context, the New
Summons would not make a difference, except that the specific challenge to the earlier summonses
would not stand as they stood withdrawn and had been substituted with the New Summons. It was
Mr. Salve’s view, that this would not really be a redeeming feature and the matter still had to be
debated.
24. Notably, a discordant note did arise in the stands canvassed on behalf of the Assembly by Dr.
Singhvi and on behalf of the Committee by Dr. Rajeev Dhavan. In the perspective of Dr. Dhavan, the
earlier summons were as good in law as the New Summons and, thus, it made no difference.
Obviously, Dr. Singhvi thought otherwise, as there would have been no occasion to withdraw the
earlier summons and issue a fresh summons. We say so as this is one aspect emphasised in the
course of arguments in rejoinder by Mr. Salve.
25. One aspect to be noticed is that the New Summons dated 03.02.2021 has been issued by the
Deputy Secretary of the Committee. Thus, on the one hand, the Committee deemed it appropriate to
withdraw the earlier summons and issue a fresh one (apparently wiser after some arguments from
Mr. Salve and possibly some remarks of the Court) while on the other hand as an intervening entity,
peculiarly, the stand of Dr. Dhavan was that this was not required to be done! On this, we say no
more.
The Submissions
26. In his opening arguments Mr. Salve punched hard on the issue that niceties aside, one has to
consider the true intent with which the summons was issued. In short, it was his say that the
objective was to file a supplementary chargesheet and rope in Facebook. To substantiate this
contention, he refers to three factors, i.e. (a) Para 4 (vii) read with 4Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

(i) of the terms of reference of the Committee; (b) the Article and (c) the press conference dated
31.08.2020.
27. The aforesaid was in the background of what was a politically polarised issue and Mr. Salve
contended that the Petitioner had no intent to become part of such a debate. The parent company
(Facebook Inc.) being an intermediary based in the US, could hardly be expected to be roped into
this political battle which formed the basis of the summonses that have been issued. It was
emphasised that the Committee’s actions amounted to a clear and present danger of coercive action,
which was in violation of Petitioner No. 1’s fundamental rights. In the process of reading his note of
arguments, which were more detailed with different nuances, broadly four issues were sketched out:
 Does a House have a privilege to summon a person to give evidence who is not
directly or indirectly part of the executive?
 Do powers of privilege extend to summoning an individual and compelling them to
give evidence on matters of fact or seek their opinion on any subject matter?
 If there does indeed exist a privilege, how is the same to be reconciled with an
individual’s right to privacy and free speech?
 Is the House constrained by the subject matter which constitutes a part of the
business of the House relating to its legislative functions?
In light of these four issues canvassed by Mr. Salve, we propose to set out the detailed
arguments and thereafter proceed with our analysis under three broad heads – (a)
the privileges issue, (b) privilege, right to privacy and free speech and (c) legislative
competence. Privilege Issue
28. Mr. Salve took us through the history of the notion of privilege, how it emanated, and how it is to
be understood in the current context. He urged that privilege is a special right enjoyed by the House
as a shield in order to enable it to work without fear or interference. It owes its origination in the
United Kingdom under the rubric of the constitutional role of the House of Commons (functioning
as a court). This role, however, has to be appropriately adapted to the Indian Constitution where
there is a sharp separation of powers. A distinction was, thus, sought to be drawn that while
privileges have arisen by virtue of House of Commons being a Court (with powers such as
summoning persons to its “bar”) it cannot be read into the privileges of a Parliament of a republic. It
was, thus, argued that in the Indian context, parliamentary privileges are strictly restricted to
legislative functions. Privileges serve the distinct purpose of safeguarding the integrity of the
legislative functions against obstructions which could be caused by either members or
non-members. Learned counsel sought to refer to certain judicial pronouncements in this behalf.
(i) In State of Karnataka v. Union of India 9 the proceedings related to a Commission of Inquiry
appointed by the Central 9 (1977) 4 SCC 608.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

Government under the Commission of Inquiry Act, 1952 against the then Chief Minister of
Karnataka. The challenge was laid by the State Government which was repelled by a majority
judgment of six Judges with one dissenting Judge.
The most significant aspect emphasised was that the “powers” meant to be indicated in Article
194(3) are not independent but are such powers which depend upon and are necessary for the
conduct of business of each House. Thus, they could not be expanded into those of the House of
Commons in England for all purposes. The Constitution is sovereign or supreme and thus, the
Parliament as well as each legislature of the State in India enjoys only such legislative powers as the
Constitution confers upon it. A distinction was made in the role performed by the Parliament and
Legislative Assembly while exercising its legislative power as against a court of justice. In taking up
proceedings which are quasi judicial in cases of contempt of its authority and motions concerning its
“privileges” and “immunities”, the House only seeks removal of obstructions to the due performance
of its legislative functions. However, if the question of jurisdiction arises as to whether a matter falls
here or not, it has to be decided by the ordinary courts in appropriate proceedings.10
(ii) The next judgment relied upon is Amarinder Singh v. Special Committee, Punjab Vidhan Sabha
& Ors. 11 In this case, Shri Amarinder Singh, then a Member of the Punjab Vidhan Sabha was
expelled for the remaining part of the 13th Vidhan Sabha on allegations of criminal misconduct
relating back to his tenure as the Chief Minister of Punjab during the 12th term of the Vidhan Sabha
qua alleged responsibility for improper exemption of a vacant plot of land licensed to a private party.
On a challenge being laid, the Supreme Court opined in favour of Shri Amarinder Singh holding that
the proper course of action for the State Government should have been to move the criminal law
machinery with the filing of a complaint followed by investigation as contemplated under the Code
of Criminal Procedure and thus, the Punjab Vidhan Sabha had exceeded its powers by expelling the
appellant on the ground of breach of privilege when there existed 10 Smt. Indira Nehru Gandhi v.
Shri Raj Narain & Anr., (1975) 2 SCC 159. 11 (2010) 6 SCC 113.
none. The alleged improper exemption of land was only an executive act and it did not distort,
obstruct, or threaten the integrity of legislative proceedings in any manner observed the
Constitution Bench of five Judges. In coming to the conclusion, the scope of the powers, privileges
and immunities available under Articles 105(3) and 194(3) have been discussed in paras 33 to 37. It
was noticed that they were not codified by way of statute till date and, thus, the Supreme Court held
that it could consider the principles and precedents relatable to the British House of Commons. This
Court had adopted a similar approach towards the concept of legislative privileges to interpret
Article 194(3) in Re. Special Reference 1 of 1964.12 An aspect emphasised was that there was a
distinction between exercise of legislative privileges and ordinary legislative functions. In that
context it was observed as under:
“45. In U.P. Assembly case (supra.), this Court had also drawn a distinction between
the exercise of legislative privileges and that of ordinary legislative functions in the
following manner:
12 AIR 1965 SC 745.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

"70. ….There is a distinction between privilege and function, though it is not always
apparent. On the whole, however, it is more convenient to reserve the term `privilege'
to certain fundamental rights of each House which are generally accepted as
necessary for the exercise of its constitutional functions. The distinctive mark of a
privilege is its ancillary character. The privileges of Parliament are rights which are
‘absolutely necessary for the due execution of its powers.’ They are enjoyed by
individual Members, because the House cannot perform its functions without
unimpeded use of the services of its Members; and by each House for the protection
of its Members and the vindication of its own authority and dignity."
(iii) The next judgment relied upon is in the case of Justice (Retd.) Markandey Katju v. Lok Sabha &
Anr.13 Facebook, as an intermediary, was used by Justice Markandey Katju, former Judge of this
Court to make a statement that Mahatma Gandhi was a British agent causing harm to India and that
Netaji Subhash Chandra Bose was an agent of Japanese fascism. This naturally invoked the hackles
of the Parliamentarians and a discussion took place in the Rajya Sabha. A resolution was passed
unanimously with the Lok Sabha doing the same on the next day unequivocally condemning the
remarks of Justice (Retd.) Katju. Letters and e- 13 (2017) 2 SCC 384.
mails were written questioning this methodology as he was not given an opportunity of hearing in
compliance with the principles of natural justice. Since it provoked no response, these resolutions
were sought to be assailed by Justice (Retd.) Katju in judicial proceedings before this Court. Since
no aspect of privilege was invoked and it was an expression of the views of the Parliament falling
within the domain of freedom of speech in Parliament, the petition was rejected. It is in that context
that a distinction was made between the exercise of contempt or breach of privilege where action
was sought to be initiated against a citizen,-whether a member or a non-member. The law has
developed that the action of such citizen must have interfered with fundamental functioning of the
House so as to enable the House to initiate any proceedings against the citizen. The earlier
judgments inter alia in the case of MSM Sharma v. Dr. Shree Sri Krishna Sinha14, Raja Ram Pal15,
Special Reference No. 1 of 1964 and Amarinder Singh17 were discussed to conclude that Chapter 20
of the Lok Sabha Rules 14 AIR 1960 SC 1186.
15 (2007) 3 SCC 184.
16 Supra note 12.
17 Supra note 11.
entitled privileges and Rules 222 to 228 thereof deal with matters of privileges. Similarly Rules 187
to 203 of the Rajya Sabha Rules deal with issues concerning privileges. Thus, an inquiry would be
along the lines submitted by the petitioner only if such a privilege action was proposed to be taken
which was not so in that case. In the conspectus of the aforesaid legal principles, it was urged that
the petitioners in the instant case being non-members could only be summoned if they had intruded
upon any functions of the Assembly. Their non-appearance or unwillingness to participate in the
debate in which they were compelled to participate did not in any manner disrupt the functioning ofAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

the Committee so as to face the consequences of breach of privilege. The Committee could always
make its recommendations but the petitioners do not want to be part of it. There were no legislative
functions to be performed and thus, the contention was that this was a case of expanding unbridled
privileges in the garb of an amorphous set of rules to make an exception to the rule of law. As such,
it was argued that the Terms of Reference had to be given a restrictive meaning.
29. Next, Mr. Salve sought to deal with the issue of judicial scrutiny of proceedings of the Assembly
by seeking to canvas that there is no absolute bar on Courts to look into the validity of the
proceedings of the Assembly. In the context of Article 212 of the Constitution read with relevant
sections of the GNCTD Act, if proceedings adopted by the Assembly suffer from lack of jurisdiction
or are illegal or unconstitutional, a challenge can be made before the competent court. Learned
senior counsel relied upon judicial pronouncements in Special Reference No.1 of 196418, Raja Ram
Pal v. Hon’ble Speaker, Lok Sabha & Ors.19 and Kalpana Mehta And Ors. vs Union of India And
Ors.20
30. In Special Reference No.1 of 196421 the dispute arose out of a conflict between the legislature
and the judiciary, if one may say so, as a consequence of the power exercised by the U.P. Assembly
in sentencing one Keshav Singh to be detained in a civil prison for a period of 7 days and the
judiciary (Allahabad High Court) enlarging him on bail thereafter. This was taken as an affront by
the legislature, which passed a 18 Supra note 12.
19 Supra note 15.
20 (2018) 7 SCC 1.
21 Supra note 12.
resolution against the two concerned judges to be brought in custody before the House. A Full Bench
of 28 judges consisting of the strength of the Court thereafter assembled to deal with the petitions
filed by the two judges against this resolution. The bench restrained the Speaker from issuing a
warrant against the judges and the Marshal of the House from executing the warrant. In order to
resolve this confrontation, the President of India decided to exercise the power to make a reference
to this Court under Art. 143(1) of the Constitution. The reference was on the important question of
the exercise of powers, privileges and immunities of the State legislature vis-à-vis the power of the
High Court and the Judges to discharge their duties. Suffice to say that the opinion rendered by the
Court in the reference was that the powers conferred on the High Court under Article 226 of the
Constitution and the authority of the Supreme Court under Article 32 of the Constitution are not
subject to any restrictions. It could not be said that a citizen cannot move the High Court or the
Supreme Court to invoke its jurisdiction, even in cases where fundamental rights have been violated.
Once the judiciary was authorized to consider the validity of the actions of the legislature, it was
opined that the judiciary cannot be prevented from scrutinizing the validity of the actions of the
legislatures trespassing on the fundamental rights conferred on the citizens.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

31. In Raja Ram Pal22 a private channel’s telecast based on a sting operation in the “cash for query
case” where 10 Members of Parliament accepted money through middlemen to raise certain
questions in the House resulted in an inquiry and subsequent expulsion of these members from the
House. The members challenged the said expulsion. The three questions framed by the Supreme
Court were all answered in the affirmative – (i) that the Supreme Court within our constitutional
scheme has the jurisdiction to decide the content and scope of powers, privileges and immunities of
the legislature and its members; (ii) the power and privileges of the legislature in India, in particular
reference to Article 105 of the Constitution, includes the power of expulsion of its members; and (iii)
in case of expulsion, the Supreme Court had jurisdiction to interfere to exercise such power and
privileges. While rejecting the plea on expulsion, the Court expounded on the scope of such judicial
review. Significantly, it was opined that though there would be a presumption that the Parliament
would always perform its functions and exercise its 22 Supra note 15.
powers within a reasonable manner, there could be no scope for a general rule that the exercise of
power by the legislature was not amenable to judicial review. This would neither be in the letter nor
the spirit of the Constitution. The touchstone, however, would not be that of an ordinary
administrative action but the legislature could not be said to have the licence even to commit a
jurisdictional error.
32. In Kalpana Mehta and Ors.23 a vaccination drive conducted by NGOs without the vaccine going
through all the pre-requisite trials caused loss of life, resulting in a parliamentary standing
committee being constituted to inquire into the matter. The report of the standing committee was
sought to be relied on in a Public Interest Litigation dealing with the issue. The question which arose
was whether such a report of a standing committee could be relied upon in the judicial review. The
relevant observations for our purposes are the summary of conclusions which deal with the judicial
review of such legislative action. It was opined that constitutional courts are not prevented from
scrutinising the validity of the actions of the legislature trespassing on the fundamental rights
conferred on the citizens. There could, thus, be no 23 Supra note 20.
immunity to parliamentary proceedings under Article 105(3) of the Constitution though it was
subject to the restriction contained in other constitutional provisions such as Article 122 or Article
212. The prohibition on the jurisdiction of the Court was restricted to the ground of irregularity of
procedure but if the proceedings are tainted on account of substantive or gross illegality or
unconstitutionality, there would be no protection against judicial scrutiny.
33. Finally, on the issue of privileges, Mr. Salve referred to the prevalent position in some other
countries regarding the exercise of privilege powers. It was contended that such privilege powers
could not be used to compel speech, more so when the organisation in question is an American
corporation. We may notice at this stage itself that we really do not appreciate the second limb of
this submission. When these corporations are working within the territory of our country and are
subject to the jurisdiction of this Court, then what kind of special privilege would they have by
reason of being an American corporation or a corporation incorporated in any other country! Now
turning to the two enactments sought to be referred to by learned senior counsel – the first one is
the Scotland Act, 1998, more specifically Section 23 and the Government of Wales Act, 2006, moreAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

specifically Section 37. We reproduce the relevant provisions as under:
“Section 23 of the Scotland Act, 1998:
23. Power to call for witnesses and documents (1)The Parliament may require any
person—
(a)to attend its proceedings for the purpose of giving evidence, or
(b)to produce documents in his custody or under his control, concerning any subject
for which any member of the Scottish Executive has general responsibility.
[…]” “Section 37 of the Government of Wales Act, 2006
37. Power to call (1) Subject as follows, the Assembly may require any person—
(a) to attend Assembly proceedings for the purpose of giving evidence, or
(b) to produce for the purposes of the Assembly (or a committee of the Assembly or a sub-committee
of such a committee) documents in the possession, or under the control, of the person, concerning
any matter relevant to the exercise by the Welsh Ministers of any of their functions.
[…]”
34. In the context of the aforesaid provisions, emphasis was laid on the expression “may” to submit
that there is no element of compulsion. The second aspect emphasised was that, as these legislations
suggest, privilege should relate to matters in connection with functions of the ministers. This in turn
was sought to be linked with the argument that what the Committee was seeking to perform was not
a core function of the Assembly and thus, cannot be said to be their function. Further, if only an
opinion was being sought, as had been urged by the respondents, then it was submitted that oath
could only be on a question of fact and not a matter of opinion.
35. Learned senior counsel also assailed the intent of the New Summons as only a subterfuge.
Compelling experts to give an opinion in a democratic polity, it was argued, would be an “abhorrent
proposition” as it could only be a voluntary act. As such, the act of Assembly it was stated, reeked of
constitutional arrogance. In fact, what senior counsel sought to stress was that his submission was
not challenging the exercise of privilege power but the very existence of the same. In this behalf it
was stressed that the Assembly (the Committee being only a smaller group constituted) would have
to reconcile with where their powers to summon originate from. Entry 39 of List II (Powers,
privileges and immunities of the Legislative Assemblies) could not be a source of power of the
Assembly and the scenario was rather of a statutory source of power emanating from Section 18 of
the GNCTD Act, which was enacted in pursuance of Article 239AA (3)(a) and (3)(b) of the
Constitution. Thus, a distinction was sought to be made between a power directly emanating from
the Constitution and one flowing from a statutory provision. In the given facts, this was a case of theAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

latter, which, it was urged would necessarily have to be tested on the touchstone of Part III of the
Constitution. The relevant provisions are extracted hereinunder to appreciate the controversy:
“Article 239AA (3)(a) and (3)(b) 239AA. Special provisions with respect to Delhi.—
xxxx xxxx xxxx xxxx xxxx (3) (a) Subject to the provisions of this Constitution, the
Legislative Assembly shall have power to make laws for the whole or any part of the
National Capital Territory with respect to any of the matters enumerated in the State
List or in the Concurrent List in so far as any such matter is applicable to Union
territories except matters with respect to Entries 1, 2 and 18 of the State List and
Entries 64, 65 and 66 of that List in so far as they relate to the said Entries 1, 2 and
18.
(b) Nothing in sub-clause (a) shall derogate from the powers of Parliament under this
Constitution to make laws with respect to any matter for a Union territory or any part
thereof.” …. …. …. …. …. ….
“Section 18 of the GNCTD Act
18. Powers, privileges, etc., of members.—(1) Subject to the provisions of this Act and to the rules
and standing orders regulating the procedure of the Legislative Assembly, there shall be freedom of
speech in the Legislative Assembly.
(2) No member of the Legislative Assembly shall be liable to any proceedings in any court in respect
of anything said or any vote given by him in the Assembly or any committee thereof and no person
shall be so liable in respect of the publication by or under the authority of such Assembly of any
report, paper, votes or proceedings.
(3) In other respects, the powers, privileges and immunities of the Legislative Assembly and of the
members and the committees thereof shall be such as are for the time being enjoyed by the House of
the People and its members and committees. (4) The provisions of sub-sections (1), (2) and (3) shall
apply in relation to persons who by virtue of this Act have the right to speak in, and otherwise to
take part in the proceedings of, the Legislative Assembly or any committee thereof as they apply in
relation to members of that Assembly.”
36. We may clarify at this stage that since the submissions were drawn in the context of certain
questions raised, this latter submission really arises in the context of privilege powers vis-à-vis the
constitutional provisions under Part III of the Constitution which are to be considered under a
separate section.
37. It appears that the petitioners wanted to avail of the benefit of another senior counsel, possibly
to further buttress their submissions and thus, Mr. Arvind Datar, learned senior counsel sought to
address us next, on behalf of Petitioner No. 3, Facebook Inc.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

38. Mr. Datar, in an endeavour to trace out the constitutional history, referred to the origin of
powers and privileges by inviting our attention to Section 71 of the Government of India Act, 1935. It
was stressed that the provincial legislatures had no powers but only privileges; they did not have
powers to punish people under that Act. Next, in the context of Erskine May’s seminal commentary
on Parliamentary Practices, it was pointed out that Chapter XI deals with powers and Chapter XII
deals with privileges and immunities which are used interchangeably. 24 Power, however, remains,
distinct. The primary power given to the House was to make laws or legislative powers. It is these
powers from the Act of 1935, which are stated to have been adopted under Article 194(3) of the 24
Erskine May’s Treatise on the law, privileges, proceedings, and usage of Parliament, (Sir David
Natzler, 25th Edition, 2019). Indian Constitution, which applies to the State Government and every
State Assembly.
39. Learned senior counsel submitted that Delhi is different as it is on a special footing being
categorised as a Union Territory in Article 239AA of the Constitution. Reiterating Mr. Salve’s
argument, Mr. Datar stressed that the powers and privileges conferred on the Delhi Assembly are
not derived from the Constitution but by reason of statutory enactments, i.e., Section 18 of the
GNCTD Act. The privilege and powers of the Assembly are, thus, undoubtedly to be tested against
Part III of the Constitution. These being statutory in nature, the aspect of constitutional balancing of
powers with fundamental rights, as arose in In Special Reference No.1 of 1964 and MSM Sharma26
does not arise in the present case. The privilege here is a “derivative” from an Act of Parliament and
not from any Constitutional provision.
40. We now turn to the submissions of the respondents on this issue, which were as vehemently
argued. Dr. Singhvi, learned senior counsel 25 Supra note 12.
26 Supra note 14.
seeking to address submissions on behalf of the Assembly, sketched out the contours of his
submissions as under:
(i) The occasion to argue privilege has not even arisen and was premature as there
was no actual notice of privilege. There was, thus, no factual matrix before the Court
to analyse the exercise of the power and what was being sought by the petitioners qua
the aspect of privilege amounted to seeking an advance ruling on the issue.
(ii) Were the arguments of the petitioners to be accepted, it would have wide
ramifications on the working of the committees across the nation both at the State as
well as the Parliamentary levels. The argument of the petitioners, it was urged, had
the propensity to destroy the system of committees which had been found historically
to do yeoman work, possibly away from the more aggressive stances in the
Parliament.
(iii) The petitioners could not be conferred with the privilege to appear before the
kind of committees they want to appear before. The petitioners admittedly hadAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

appeared on more than one occasion of a similar nature without any qualms.
(iv) In the similar vein, the reference to the IT Act was premature as the Assembly
was not debating any legislation of the issue but only discussing a particular aspect.
(v) Arguments of the petitioners were premised on lack of mutual respect and
difference between the organs of our democracy.
(vi) Committee proceedings are House proceedings and the Supreme Court would
normally never interfere with House proceedings and therefore also not with
committee proceedings.
41. The obvious political divergence between Central Government and the State Government came
out quite openly during the arguments where Dr. Singhvi sought to put forth the argument that the
bold stand of the petitioners stood on a support base from the Central Government. The appearance
before the Parliamentary Committee was sought to be justified by the petitioners as being based on
commercial and operational reasons and not in view of any compulsion (an aspect disputed by
learned Solicitor General on behalf of the Central Government). The petitioners, it was argued, were
actually canvassing a case on absence of any commercial and operational
consequences/compulsions rather than lack of jurisdiction. It was, however, fairly assured and
rightly so, that the Assembly and the Committee were not oblivious to the constitutional exclusion of
entries 1, 2 and 18 of List II and the respondent would never contend to encroach upon this
constitutional demarcation. One aspect which Dr. Singhvi sought to emphasise, in our view not very
convincingly, was that the issue of the press conference was an afterthought, raised by the
petitioners to create prejudice. We say so as the press conference being held is not in doubt nor what
transpired there. The only turn which Dr. Singhvi could seek to give to this is that what the
Chairman of the Committee mentioned in the press conference were views of the persons who had
deposed and not his own view per se. To say the least, we find this submission very difficult to accept
and we will deal with it at the relevant stage.
42. The other aspect which Dr. Singhvi pointed out was the withdrawal of the Second Impugned
Summons and the New Summons being issued, which no longer compelled Petitioner No.1 to
appear before the Committee. However, this aspect has been labeled as a “subterfuge” by Mr. Salve,
on account of the divergent views taken on the aspect of withdrawal by Dr. Singhvi and Dr. Dhavan–
and surprisingly so. Consequently Dr. Singhvi will have to bear the burden of the cross for the same.
43. On the specific plea of privilege Dr. Singhvi commenced by seeking to establish that all
committees of legislatures have the power to summon and compel attendance. Any power, without
subsidiary powers to ensure implementation, it was urged, was akin to having no power at all. The
power to compel attendance by initiating privilege proceedings is therefore, an essential power. The
argument was further supplemented with the contention that the power of privileges was
amorphous in common law and the Parliament has consciously not codified this area of law so that
they can cater to unimagined situations in the future.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

44. Dr. Singhvi, in fact, cautioned that this Court should not embark on the path suggested by Mr.
Salve, who had argued that it was time that these privileges were codified. Dr. Singhvi urged this
Court to not even opine on the necessity of codifying such privileges and that the same should be left
to the Parliament, if they so desire without any nudge by this Court.
45. Dr. Singhvi sought to erase the distinction between the exercise of privilege powers under the
Constitution and under the GNCTD Act by putting them on the same pedestal, urging that the two
together provide for the scheme of operation. Learned senior counsel referred to provisions (7)(a) &
(b) of Article 239AA in the context that the GNCTD Act was not to be deemed to be an amendment
to the Constitution for purposes of Article 368 of the Constitution notwithstanding that it may
contain any provision which amends or has the effect of amending the Constitution. The Assembly
was, thus, submitted to be a privileged body with members enjoying freedom of speech in the House
as well as freedom to vote and had all the privileges (under Section 18 of the GNCTD Act) as are
enjoyed by Members of Parliament. It was thus urged that calling into question the proceedings of
the Committee amounted to calling into question the proceedings of the Assembly in a court of law
for which the powers were not vested. The regulation of the procedure of conduct of business was
not subject to jurisdiction of the courts. In order to establish parity of the privilege powers, Dr.
Singhvi drew the attention of the Court to Article 105 of the Constitution, Section 18 of the GNCTD
Act coupled with Rule 172 of the Rules.
46. On this aspect, parity was sought to be drawn by relying on Parliamentary privileges in Entry 74
of List I and that of the Legislative Assembly in Entry 39 of List II which were stated to be pari
materia. Delhi was no different, it was submitted, and thus the powers of the Assembly are the same
under entry 39 of List II as any other Assembly in the context of Article 239AA of the Constitution.
To further amplify this aspect, learned counsel sought to draw strength from the observations of this
Court in State (NCT of Delhi) v. Union of India and Anr. 27 which comprehensively dealt with the
segregation of powers between the State and the Central Government in view of an ongoing conflict
on various issues in this behalf. It was opined by this Court that all entries in List II will have full
play except three specific entries which were excluded, i.e. entries 1, 2 & 18.
47. In view of Article 239AA(3)(a) the power to summon and compel attendance was stated to be
akin to that of any other legislative assembly. Testimonies before committees were stated to be
mostly under oath and the rationale for the same was that the process was solemn in nature and that
it would improve the quality of debate. There was stated to be no 27 (2018) 8 SCC 501.
competing entry in List I and the question of repugnancy would only arise in terms of any entry in
List III where there are central statutes in a given scenario. The committees of legislatures all over
the country (including Delhi), thus, possess the power to compel attendance of witnesses as a part of
their constitutionally recognized powers and privileges and there could be no distinction based on
the kind of committee or the type of person who is summoned in exercise of these powers.
48. We may note another submission of Dr. Singhvi where he cautioned the court against ruling in a
manner wished for by the petitioners on account of its wider ramifications especially in the context
of observations made in Kalpana Mehta And Ors.28on the importance of committees. AnyAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

hampering of the working of the committee would hamper the working of the Assembly as passing
laws is not the only function of the Assembly. Thus, the practice of passing resolutions by
Assemblies on the sense of the house would be disrupted. On the significance of the working of these
committees, it is not necessary to go into depth as the issue has been well considered in Kalpana
Mehta And 28 Supra note 20.
Ors.29 We, thus, consider it appropriate to only extract some of the relevant paragraphs:
66. Woodrow Wilson, the 28th President of the United States, was quoted as saying
in 1885 that “it is not far from the truth to say that Congress in session is Congress on
public exhibition, whilst Congress in its Committee rooms is Congress at work.” This
is because most of the work of Congress was referred to committees for detailed
review to inform debate on the floor of the House.” …. …. …. …. …. ….
“70. The importance of Committees in today's democracy has further been detailed thus:
“Committees may not be of much service in the more spectacular aspect of these
democratic institutions, and they might not be of much use in shaping fundamental
policy, or laying down basic principles of government. But they are absolutely
indispensable for the detailed work of supervision and control of the administration.
Not infrequently, do they carry out great pieces of constructive legislation of public
economy. Investigation of a complicated social problem, prior to legislation, maybe
and is frequently carried out by such legislative committees, the value of whose
service cannot be exaggerated. They are useful for obtaining expert advice when the
problem is a technical one involving several branches within an organization, or
when experts are required to advise upon a highly technical problem definable within
narrow limits. The provision of advice based on an inquiry involving the examination
of witnesses is also a task suitable for a committee. The employment of small
committees, chosen from the members of the House, for dealing with some of the
items of the business of the House is not only convenience but is also in accordance
with the established convention of Parliament. This procedure is particularly helpful
in dealing with matters which, because of their
29 Supra note 20.
special or technical nature, are better considered in detail by a committee of House. Besides
expediting legislative business, committees serve other useful services. Service on these committees
keeps the members adequately supplied with information, deepens their insight into affairs and
steady their judgment, providing invaluable training to aspirants to office, and the general level of
knowledge and ability in the legislature rises. Committees properly attuned to the spirit and forms
parliamentary government can serve the country well as the eyes and ears and to some extent the
brain of the legislature, the more so since the functions and fields of interest of the government
increase day by day.”Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

49. Dr. Singhvi concluded by emphasising that not a single judicial precedent had been cited from
our country or outside where the Court had intervened at the stage of summoning of a witness by
the legislature (sub-committee). Reliance was placed on the judgment of the Madras High Court in
C. Subramaniam v. The Speaker, Madras Legislative Assembly.30 In this case, on a speech being
made by a former Member of the Madras Assembly a show-cause notice was issued by the Speaker
of the Assembly as to why his conduct should not be treated as a breach of privilege. The endeavour
to assail the notice was rejected by the Full Bench of the High Court, on the short ground that it was
premature at that stage as no action had been taken. It was held to be akin to a writ of 30 AIR 1969
Mad 10.
prohibition restraining the Speaker of the Legislative Assembly from proceeding further, which was
virtually on the ground of absence of an ab initio jurisdiction. It was further opined that the power
vested under Article 194(3) of the Constitution empowered the Speaker with the right to call upon a
third party like the writ petitioner to show cause against an alleged breach of privilege by way of
contempt. In the facts of the present case, it was urged, even a show cause notice had not been
issued as the Petitioner had only been called upon to depose. Thus, there was not even an initiation
of any privilege proceedings.
50. We now turn to the arguments of Dr. Rajeev Dhavan on behalf of the Committee which sought to
intervene in the present proceedings. We may note at the threshold that the Committee is really a
creation of the Assembly, but it appears that like the petitioners, the respondents wanted assistance
of more than one counsel in the belief that it would further advance their case. In the process, as
noticed above, some contradiction of stand came into being regarding the implication of the
issuance of the New Summons and withdrawal of the old one.
51. Dr. Dhavan laid great emphasis on the main functions of the Committee as enunciated, taking a
cue from its very description as a “Peace and Harmony Committee.” The main functions, thus, were
to consider viewpoints across society about prevalence of such a situation which had the potential to
disturb communal peace and harmony or where communal riots had occurred and to examine in
detail and identify the factors responsible for it. This was coupled with the mandate to undertake
scientific study on religious, linguistic, and social compositions of the population of Delhi NCR, with
a view to identify and strengthen the factors which unite people despite their diversity. The
Committee also sought to recommend measures to be undertaken by the government towards
establishing communal harmony and peace in the State. We may note with some trepidation Dr.
Dhavan’s submissions while seeking intervention that even if a writ was issued to the Assembly it
could not be deemed to have been issued to the Committee because the Committee was an
autonomous body which would eventually report to the Assembly and thus, enjoys a separate legal
existence. Suffice for us to say at this stage that if the Committee is the creation of the Assembly and
seeks to derive its powers and strength from the Assembly, it is surprising to note a submission that
the -Committee would not be bound by a direction of this Court if it was not specifically made a
party. Be that as it may, we did permit the Committee to intervene and to that extent there was no
objection from Mr. Salve.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

52. The initial rebuttal to the challenge is based on the anticipatory nature of the proceedings, being
presumptive and pre-emptive. There are several stages of scrutiny before a breach of privilege notice
is even issued; much less any conviction arising from such a breach of privilege.
53. It was further contended that no factual basis had been laid for the concerns regarding the First
and Second Impugned Summons and the press conference. Fundamental rights could not be said to
be violated by a mere issuance of summons. There was stated to be lack of specificity of any claim of
mala fides which could not be general in character but must be specifically pleaded and proved by all
material particulars in relation to the persons concerned.31 This was an aspect absent in the present
case. Dr. Dhavan categorised the writ petition as a SLAPP (Strategic Lawsuit 31 State of Madhya
Pradesh v. Nandlal Jaiswal (1986) 4 SCC 566; K. Nagraj v. State of Andhra Pradesh (1985) 1 SCC
523.
Against Public Participation), engineered to silence the Committee and interfere with the
democratic process.
54. Dr. Dhavan clarified the statements made by Mr. Raghav Chadha during the press conference on
31.08.2020 to contend that it was merely a summary of the complaints received by the Committee.
They were stated not to represent the Chairman’s views, the Committee’s conclusions or the scope of
the Committee’s functions. The Committee had not suo moto decided that the petitioners were
responsible for causing disharmony. It had received complaints from several different people, who
specifically attributed the disharmony caused by the riots in Delhi to Facebook. The statements
made in the press conference were, thus, not made in bad faith and were simply repetitions of the
depositions made to the effect that Facebook may have had a role in the riots.
55. The contention on the Committee’s Terms of Reference recommending criminal action was
stated to be “toothless.” Thus, in a sense what was conceded was that the said part of the
Committee’s Terms of Reference (i.e. in paragraph 4(vii)) was “otiose.” The Committee could, at
best, make recommendations. Whether criminal action was, in fact, initiated was entirely the remit
of the police or the judiciary and in that context no real threat was made to the petitioners either by
the Terms of Reference or by the impromptu statements made by the Chairman in the press
conference.
56. The aforesaid submissions, in our view, may have mollified the petitioners though apparently
not Mr. Salve. As per his submissions, all the aspects would have to be read together to come to a
conclusion whether the petitioners had a real concern to approach the Court or not. We say so in the
context of the Terms of Reference which included recommending criminal action, the utterances of
Mr. Raghav Chadha in the press conference (undoubtedly in the background of the depositions
before the Committee) and the limitation on the legislative domain by carving out of certain entries
from List II as applicable to the Assembly. We will pen down our view on this aspect at a later stage.
57. We now come to arguments of Dr. Dhavan that were in sync with what Dr. Singhvi had argued,
i.e., in view of the judicial observations, these committees are the eyes and ears of the Parliament,
essential for the democratic polity. The functions performed by the committees are part of the coreAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

legislative functions of State Assemblies, which may include
(a) supervising administration, (b) taking evidence on legislation, and (c) dealing with a crisis or
governance generally. In that context, Dr. Dhavan pointed out that the petitioners had not
challenged the constitution of the Committee itself or its Terms of Reference. The petitioners had
also not challenged the summons issued by the Parliament despite Parliament’s threat to initiate
breach of privilege proceedings in case they refused to appear. As such, Facebook could not be said
to have any issues while appearing before the Parliamentary Committee. The role of intermediaries
in governance was relevant and the testimony of the petitioners was important in that context. The
refusal was sought to be labeled down as one relating to “political reasons.”
58. Dr. Dhavan then turned to the aspect of the distinction drawn by Dr. Singhvi between members
and non-members in the context of the legislature’s power to summon witnesses or initiate breach
of privilege proceedings. He canvassed that no rule existed as per which non- members have the
power to refuse a summons issued by a legislative committee. The core function of the legislature is
democracy and not just to legislate, an aspect we agree with. Thus, it was the obligation of every
person to cooperate with the legislature and appear when requested to assist in the realisation of
this core function. There were several ways in which the legislature may seek democratic
participation, one example was appearance before committees.
59. In support of the aforesaid plea, Dr. Dhavan illustrated the proposition by giving instances of
notices issued to non-members which also form a subject matter of a treatise by Dr. Dhavan “Only
the Good News: On the Law of the Press in India” published in 1987.
“- Thaniram (1975), (1975) XX P.D. (No.2) 49 (Kerala Legislative Assembly) – Reprimand to person
who questioned the partiality of Speaker.
- Satyayug (1977), (1977) XXII P.D. (No.1) 18 (West Bengal) – The West Bengal Legislature was
maligned and the feature writer did not apologise but the editor did. (Karnataka) – An unrepentant
editor of a newspaper reprimanded by the Legislature for accusations of harassing educational
institutions.
- Nagrik (1978), (1981) XXVI P.D. (No.1) 19 (Tripura) – An editor, who criticized the alleged leak of
a budget by the Chief Minister, subject to imprisonment for a day.
- Varsha Joshi and K.W. Deson (1982), (1982) XXVII P.D. (No.1) (Gujarat) – The threat to institute
legal proceedings against a speaker for allowing discussion on sub judice matters caused the
Committee to recommend imprisonment of a person.”
60. On the constitutional status of the Assembly, Dr. Dhavan sought to make a distinction between
all Union Territories on the one hand, and Delhi and Puducherry on the other. A second distinction
was made between the Delhi and the Puducherry Legislative Assemblies. The significant distinction
was stated to be that while the Puducherry Legislative Assembly was empowered by Article 239A,
the Delhi Legislative Assembly was created through an exercise of constituent power by the 69thAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

Amendment Act, 1991. Thus, while Article 239AA excluded police power and public order from the
scope of the Assembly’s competence, that did not detract from it being a full-fledged working
Legislative Assembly similar to the Parliament. This aspect was stated to be reinforced by Sections
33 to 37 of the GNCTD Act. In Dr. Dhavan’s view, the powers of privilege of the Assembly could be
traced to Article 239AA(2) & (7) of the Constitution, Section 18(3) of the GNCTD Act and Rules 160
and 172(4) of the Rules. Dr. Dhavan drew strength from Article 212(1) to canvas that the
Constitution grants internal autonomy to each House of the State legislature and the validity of any
proceedings cannot be questioned on an allegation of “irregularity of procedure.”32 There were
conceded to be limitations to Article 212(1) of the Constitution and this Court had held that
interference with the internal functioning of the State Legislative Assemblies can only be limited to
cases of “gross illegality and unconstitutionality.” 33 No such illegality having occurred in this case
and only a summons being issued, no proceedings for breach of privilege had been initiated and no
question had been asked. As such there was no occasion whatsoever to call for interference by this
Court.
61. Akin to Dr. Singhvi’s submission, Dr. Dhavan also emphasised on the sui generis nature of
parliamentary powers and privileges and vehemently opposed the suggestion that these privileges
needed to be codified. The powers and privileges of the legislature do not require a law and learned
senior counsel sought to repel the argument of Mr. Salve that the amorphous nature of privileges
offends the law and due process. It would not amount to claiming privilege as they want, as the
Supreme Court has recognized a “Lakshman Rekha” to confine the extent and 32 Supra note 14.
33 Supra notes 12 and 15.
exercise of their powers.34 There could be many other legal concepts that are similarly amorphous
or in HLA Hart’s language “open textured.” This would not amount to ipso facto undermining the
credibility of these concepts or reducing the importance of the meaning given to them by the
Supreme Court. Thus, at this stage, the only question was whether a simpliciter issuance of
summons from a sub-committee was constitutionally improper to which the answer should be in the
negative.
62. The last set of arguments on this point by Mr. Tushar Mehta, learned Solicitor General of India,
were in a limited contour. He supported learned counsel for the respondents on the power of the
Parliament and Assemblies per se to summon but that would be subject to judicial review. However,
his next submission was in sync with the submission of the petitioners that the Assembly lacks
legislative competence to deal with the subject matter in question. That being his submission, it was
felt that a complete argument on privilege was not required to be considered. In substance, his
contention was that the summonses could not have been issued because of lack of legislative
competence but if the Assembly had the legislative competence, then the 34 Supra note 12.
principles as enunciated by learned counsel for the respondents were the correct principles.
Privileges, Free Speech and PrivacyAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

63. We have dealt with the aspect of rival contentions arising from the privilege of the House to
summon a person, to compel them to give evidence on matters of fact, and seek their opinion –
which are the first two questions framed by Mr. Salve under the head of privileges as aforesaid.
Having done so, we proceed to the third question dealing with the interesting aspect of privileges
vis-à-vis an individual’s right to privacy and free speech.
64. We may at the threshold note that Mr. Salve had to deal with the aspect raised by the
respondents on the petition being premature – both in the context of privilege per se and in the
interaction between privileges and fundamental rights.
65. Mr. Salve strongly refuted the plea of the petition being premature on the basis of the
summonses issued by the Committee where it was threatened that “necessary action” would be
taken against the petitioners for breach of privilege if they do not appear. He submitted that even a
threatened breach of fundamental rights is sufficient to invoke jurisdiction of this Court under
Article 32 of the Constitution.35 Further elucidating on this aspect, Mr. Salve submitted that access
to justice is a human right available where there is even a threat to personal liberties. 36 In that
context, he stated that the Second Impugned Summons left no room for doubt that Respondent No.
2 was determined that the failure to appear would constitute a breach of privilege for which
“necessary action” will be taken, which included the risk of arrest and imprisonment. This argument
arose from the plea of Mr. Salve that the petitioner had a right to not appear and in the alternative a
right to remain silent if he so appears.
66. In view of the aforesaid fact and the plea that the summons itself was without jurisdiction, it was
submitted that the threat of coercive action is itself without jurisdiction and a person need not wait
for injury to occur before seeking the Court’s protection.37 Mr. Salve emphasised the importance of
the observations made in S.M.D. Kiran Pasha v. Government of A.P. and Ors. , where the Court
recognized that “if a 35 K.K. Kochunni v. State of Madras, AIR 1959 SC 725, at 729-730; D.A.V.
College v. State of Punjab (1971) 2 SCC 261, at para 5; Anita Kushwaha v. Pushap Sudan (2016) 8
SCC 509, at para 42.
36 Tashi Dalek Gaming Solutions Ltd. v. State of Karnataka (2006) 1 SCC 442. 37 Chief of Army
Staff v. Major Dharam Pal Kukrety (1985) 2 SCC 412. threatened invasion of a right is removed by
restraining the potential violator from taking any steps towards violation, the rights remain
protected and the compulsion against its violation is enforced.”38 Mr. Salve further relied on Bengal
Immunity Co. Ltd. v. State of Bihar and Ors., wherein the Court observed “It is, therefore, not
reasonable to expect the person served with such an order or notice to ignore it on the ground that it
is illegal, for he can only do so at his own risk and peril.”39 The certainty of a legal proposition qua
the right of a person was, thus, emphasised by this Court observing “a person placed in such a
situation has the right to be told definitely by the proper legal authority exactly where he stands and
what he may or may not do.”40
67. The plea raised by Mr. Salve is on the premise that even if a right of privilege validly accrued, the
same would have to be narrowly construed and reconciled with the petitioner’s right under Part III
of the Constitution . The First and Second Impugned Summons addressed to Petitioner No.1Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

explicitly stated that it was so addressed to him as the one “spearheading Facebook”, and thus, no
option was left to Facebook to 38 (1990) 1 SCC 328, at para 14.
39 (1955) 2 SCR 603 at para 7.
40 Ibid.
decide who would appear before the Committee. Of course, with the recall of the Second Impugned
Summons and the issuance of the New Summons; this aspect urged before the recall of the first
notice would not really survive.
68. Learned counsel, once again, took us to Article 194(3) of the Constitution to contend that it
provided that privilege powers would, from time to time, be defined. The submission was that the
Constitution makers had envisaged a clear ambit to be defined for privilege powers, which has
unfortunately never happened. That is why, the plea has been made to the effect that either this
Court defines the privilege power or direct/request the legislature to at least consider the issue of
defining these privilege powers on the pari materia basis as in Scotland and Wales. In the context of
the language of Article 194(3), it was submitted that only such privileges are available to legislatures
that can be exercised without impinging on fundamental rights.
69. In the conspectus of this general proposition, it was urged that the summons issued to the
petitioner violated his right to remain silent which was not limited to Article 20 (which was
inapplicable by virtue of these not being criminal proceedings); but also implicit in his rights under
Article 19(1)(a) and Article 21 of the Constitution. The right of personal autonomy has been held by
this Court to include aspects of the choice between speaking and remaining silent.41
70. The summons per se, as per the submissions, were violative of the petitioner’s right against
arbitrary State action under Articles 14, 19, and 21 of the Constitution. Learned counsel was
conscious of the judgment of this Court in MSM Sharma42 and the view expressed therein about
powers, privileges, and immunities available in terms of Articles 105(3) and 194(3) of the
Constitution. The Court had taken the view that such powers, privileges, and immunities stood in
the same position as Part III of the Constitution and that the fundamental right to free speech and
expression under Article 19(1)(a) must yield to Article 194. Mr. Salve sought to distinguish this
proposition in view of subsequent judicial developments. The principle propounded was submitted
to have been eroded by subsequent constitutional developments as per which the right to free
speech under Article 19 was to be seen as part of a trilogy of rights 41 Selvi and Ors. v. State of
Karnataka (2010) 7 SCC 263; K.S. Puttaswamy and Anr. v. Union of India and Ors. (2017) 10 SCC 1;
Excel Wear v. Union of India & Ors. (1978) 4 SCC 224.
42 Supra note 14.
along with Articles 14 and 21, and the rights no longer existed in silos. It was thus, his contention,
that the fundamental proposition that privileges can override Article 19 but not Article 21 stood
overruled in view of the judicial pronouncements in Maneka Gandhi v. Union of India43 and R.C.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

Cooper v. Union of India44. It would be relevant to reproduce para 6 of Maneka Gandhi45 as it
traces the constitutional development in this regard through various judicial pronouncements as
under:
“6. We may at this stage consider the interrelation between Article 21 on the one
hand and Articles 14 and 19 on the other. We have already pointed out that the view
taken by the majority in A.K. Gopalan case [AIR 1950 SC 27 : 1950 SCR 88 : 51 Cri LJ
1383] was that so long as a law of preventive detention satisfies the requirements of
Article 22, it would be within the terms of Article 21 and it would not be required to
meet the challenge of Article 19.
This view proceeded on the assumption that “certain articles in the Constitution exclusively deal
with specific matters” and where the requirements of an article dealing with the particular matter in
question are satisfied and there is no infringement of the fundamental right guaranteed by that
article, no recourse can be had to a fundamental right conferred by another article. This doctrine of
exclusivity was seriously questioned in R.C. Cooper case [(1970) 2 SCC 298 : (1971) 1 SCR 512] and it
was over-ruled by a majority of the full Court, only Ray, J., as he then was, dissenting. The majority
Judges held that though a law of preventive detention may pass the test of Article 22, it has yet to
satisfy the requirements of other fundamental rights such as Article 19…” 43 (1978) 1 SCC 248.
44 (1970) 2 SCC 298.
45 Supra note 43.
71. We may note in the end an aspect which was raised in the writ petition, but not really contended
on behalf of the petitioners: a similar question related to the interplay between the State
Legislature’s privilege powers under Article 194(3) and a non-member’s fundamental rights was
pending before a 7-Judge Bench of the Supreme Court in N. Ravi v. Legislative Assembly46 on
account of a perceived conflict between MSM Sharma47 and Special Reference No.1 of 196448. Dr.
Singhvi mentioned this issue only to distinguish and state that N. Ravi49 was a case that related to
the conviction of a non-member which is not so in the facts of the present case.
72. Dr. Singhvi, on behalf of Respondent No.1, once again, at the threshold submitted that akin to
the privileges issue, this issue is also premature as no coercive action has been taken against the
petitioner and none was intended if the authorised representative fairly attended and participated in
the proceedings as a witness. The transparency of the proceedings was sought to be emphasised as
there was a live broadcast 46 (2005) 1 SCC 603.
47 Supra note 14.
48 Supra note 12.
49 Supra note 46.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

and therefore there could be no question of any apprehension in respect of the proceedings.
73. Learned counsel also sought to assail the maintainability of the writ petition because Petitioner
Nos. 2 & 3 are not citizens of India and no shareholder had been impleaded as a petitioner. But then
one must note that the initial summons was sent to Petitioner No.1, who is a citizen of India, albeit
holding an office in Petitioner No.2 organisation. Subsequently, the summons issued to him was
withdrawn and re-worded summons was issued. However, the parties had agreed to proceed on the
basis of existing pleadings and questions raised. We are thus, not inclined at the threshold itself to
look into this contention with any seriousness.
74. Insofar as the submission about the summons issued to Petitioner No.1 is concerned (even
though summons was withdrawn), it was urged that a witness could not claim his right to remain
silent or to be let alone in response to a summon to depose before a lawful committee of an
empowered legislature. Such a right was not a fundamental right under Article 20 of the
Constitution unless a person is an accused; as was the case in Selvi50 which involved rights of an
accused in context of narco 50 Supra note 41.
analysis and other tests. Petitioner No.1, and for that matter anyone who deposes, is not an accused.
There is no conflict between Article 19(1)(a) of the Constitution and Rule 174 of the Rules. The right
to remain silent is relevant only in criminal investigations. The proceedings before the Committee
are not criminal or judicial proceedings. There is no accused before the Committee. All persons who
appear before it are witnesses and subject to examination by the members as per the Rules of the
House. These Rules have been made in exercise of the powers conferred under Section 33 of the
GNCTD Act, which in turn draws its strength from Article 239AA(7) of the Constitution. Thus, it was
submitted that the mere summons to give expert deposition before the Committee on the issues
falling within the remit of the Committee cannot be said to be a violation of any fundamental rights
so as to invoke Article 32 of the Constitution. We may note at this stage that the third issue we will
deal with is the perceived remit of the Committee and whether the remit has the sanction of the
Constitution in the context of division of subject matter under the three Lists of the 7th Schedule.
75. The distinction between members and non-members carved out by Mr. Salve was sought to be
brushed aside by Dr. Singhvi by submitting that there was no such distinction as Article 105(4) uses
the expression “in relation to persons”. The apprehension about self-incrimination was also urged to
be misconceived in view of the constitutional protection envisaged under Article 105(2) of the
Constitution.
76. Dr. Singhvi then engaged with the arguments of the petitioners regarding encroachment of
fundamental rights, the submissions originally addressed by both parties being in the context of
Petitioner No.1. In this regard, it was submitted that not even a prima facie case was established for
the breach of any fundamental right. Petitioner No.1 had not been summoned to speak as a private
individual but to speak on behalf of Petitioner No.2. Only a shareholder could have asserted the
right on behalf of Petitioner Nos. 2 & 3, as they were corporate entities, because individuals’ rights
are not to be subsumed in the company.51Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

77. We may note that surprisingly, Dr. Singhvi sought to urge that Petitioner No.1 has not been
summoned to speak as a private individual but to speak for Petitioner No.2. We are saying this is
surprising because the New Summons also permits any suitable officer to speak on behalf of 51
Supra note 44; Bennett Coleman & Ors. v. Union of India (1972) 2 SCC 788; Divisional Forest
Officer v. Bishwanath Tea Co. Ltd. (1981) 3 SCC 238. Petitioner No. 2 and if a shareholder can urge a
right under Article 32 of the Constitution, we fail to appreciate why an officer of a corporation to the
extent he has been asked to speak cannot urge this aspect. The First and Second Impugned
Summons were specifically addressed to Petitioner No.1 and only during the course of arguments,
facing certain difficulties (which somehow Dr. Dhavan did not consider relevant) the initial
summons was withdrawn and a new summons issued.
78. The more relevant submission is that in the context of Article 21, at this stage, only a summons
to appear was issued and there was no question of restriction of personal liberty. The proceedings
were not for breach of privilege. No coercive action was taken or was intended if Petitioner No.1 (or
any other officer) merely appeared and assisted the Committee as a witness. On the issue of right to
privacy under Article 21, it was urged that Article 21 itself would have to be read as confined to a
person while a corporation has no personhood.52
79. The argument of Mr. Salve, based on the trilogy of rights under Articles 14, 19, and 21, was
submitted by Dr. Singhvi to be out of context 52 Chiranjit Lal Chowdhury v. Union of India 1950
SCR 869; Petronet LNG Ltd. v. Indian Petronet Group and Anr. (2009) 158 DLT 759.
in the present case as the Constitution sets clear parameters for the applicability of certain
fundamental rights. Article 19 is still available only to citizens. Article 21 is available only to humans
who are capable of having personhood and Article 19(1)(a) continues to be unavailable when
legislative privilege is invoked especially if the legislatures are to function effectively. In that context
it was urged that the ratio of the decisions in MSM Sharma53 and In Special Reference 1 of 196454
still hold good. On the right to remain silent, it was urged that this was not a right protected under
Article 19(1)(a) of the Constitution as it was not a general right; and if at all this right had to be
pleaded, it was to be before the legislature which had summoned Petitioner No. 1, and not before the
Supreme Court. If silence is to be pleaded for a good reason in response to a specific question, that
request should be dealt with by the Committee as per applicable rules. Reliance in the petition on
the pending reference in N. Ravi55 would be of no avail to the petitioners as there has been no
punishment for any breach so far, making the present case distinguishable.
53 Supra note 14.
54 Supra note 12.
55 Supra note 46.
80. Dr. Dhavan while advancing his case on behalf of the Committee sought to lift the corporate veil
between Petitioner Nos. 1 & 2, as the true petitioner is Facebook and not Ajit Mohan. The purpose of
the summons was to seek Facebook’s assistance regarding its role as a social mediaAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

platform/intermediary in a situation like the Delhi riot, where persons had deposed before the
Committee and pointed out the aggravation which had taken place because of platforms like
Facebook. The summons had been issued to Facebook’s senior representative who could be of
assistance and the summon itself had made it clear that this notice was issued to Facebook India,
not to a specific individual: inasmuch as the notice was issued to Petitioner No.1 in his capacity as a
representative of Facebook. Thus, it was contended that neither Article 32 nor Article 19(1)(a) of the
Constitution were available to the petitioners as these rights do not extend to corporations. This was
stated to be of significance as the petitioner had claimed the right against compelled speech under
Article 19(1)(a) of the Constitution. As far as corporations are concerned, there are no personal
liberties for corporations though they have certain responsibilities.56 56 Supra notes 44 and 51.
81. Learned counsel took us through Article 194(3) to emphasise that it has two parts. The first part
deals with privileges being enacted statutorily, while the second part states that until such a law is
enacted, legislative privileges are frozen as they stood on 20.06.1979. A trilogy of pre-1979 cases
authoritatively discussed which fundamental rights are attracted in relation to a breach of privilege.
57 MSM Sharma58 declared that the relevant portion of the Ganupati Keshavan Reddy59 was obiter
and therefore not binding. Thus, it was submitted that the correct legal position regarding privileges
and fundamental rights was laid down in MSM Sharma60 and Special Reference No. 1 of 1964 61;
i.e., Article 19 of the Constitution does not apply to exercise of privileges under Article 194(3). The
relevant portion of the judgment in MSM Sharma62 as part of para 27 is extracted as under:
“27. .…Article 19(1)(a) and Art. 194(3) have to be reconciled and the only way of
reconciling the same is to read Art. 19(1)(a) as subject to the latter part of Art. 194(3),
just as Art. 31 has been read as subject to Art. 265 in the cases of Ramjilal v.
Income-tax Officer, Mohindargarh (1) and Laxmanappa Hanumantappa v. 57
Ganupati Keshavan Reddy v. Nafisul Hasan AIR 1954 SC 636 (“the Blitz case”);
Supra note 14 (“the Searchlight case”); Supra note 12 (“the Legislative Assembly case”).
58 Supra note 14.
59 Supra note 57.
60 Supra note 14.
61 Supra note 12.
62 Supra note 14.
Union of India (2), where this Court has held that Art. 31(1) has to be read as referring to
deprivation of property otherwise than by way of taxation. In the light of the foregoing discussion,
the observations in the Madhya Bharat case (3) relied on by the petitioner, cannot, with respect, be
supported as correct. Our decision in Gunupati Keshavram Reddy v. Nafisul Hasan (4), also relied
on by learned advocate for the petitioner, proceeded entirely on a concession of counsel and -cannotAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

be regarded as a considered opinion on the subject. In our judgment the principle of harmonious
construction must be adopted and so construed, the provisions of Art. 19(1)(a), which are general,
must yield to Art. 194(1) and the latter part of its el. (3) which are special.”
82. Dr. Dhavan in sync with the arguments of Dr. Singhvi disputed Mr. Salve’s case that Articles 14,
19, & 21 of the Constitution were integrated by R. C. Cooper63 and Maneka Gandhi64 into one
single right. He submitted that the effect of these cases was only to create India’s due process as far
as constitutional limitations are concerned. Each of these rights have their own independent
existence and correspondingly their own independent limitations. The golden triangle does not
invalidate the cases ruling that Article 194(3) of the Constitution, though subject to Article 21, was
not subject to Article 19 of the Constitution. The argument of Mr. Salve was, thus, pleaded to be
overstated and contradictory.
63 Supra note 44.
64 Supra note 43.
83. In the end it was contended that no fundamental right was violated by issuance of summons to
the petitioner.
84. Suffice to say that so far as learned Solicitor General is concerned no specific arguments were
addressed in this behalf except that he drew attention of this Court to N. Ravi65.
Legislative Competence
85. Elaborate submissions were addressed on the first three aspects by Mr. Salve even though one of
the primary issues was whether it was more speculative in character and premature, as at this stage
of the assailed proceedings only summons had been issued to the petitioners. The bedrock of Mr.
Salve’s submissions was based on the alleged lack of legislative competence of the Assembly and
consequently of the Committee to look into the subject matter qua which the notice had been issued
to the petitioners. The submission, thus, was that in the absence of any such legislative competence,
the petitioners were entitled to approach the Court at this stage itself rather than being compelled to
wait for further progress in the proceedings.
65 Supra note 46.
86. There were three limbs of this submission. The first limb was in respect of the statutory
enactments, i.e., the IT Act, enacted by the Parliament under List I, governs and regulates Facebook.
This could not be an aspect with which the State Government was concerned. In fact, this was stated
to be the reason why the petitioners had willingly cooperated and appeared before the
Parliamentary Committee in the past. The second limb was based on the subject matter which the
Committee wanted to go into, even though it had been specifically denuded of the power as those
subject matters fall within the jurisdiction of the Central Government under Entry 31
(Communications) and under Article 239AA(3)(a) of the Constitution read with Entries 1 and 2 inAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

List II (Public Order and Police). The third limb flowed from these two issues and is based on the
unique status of Delhi. He argued that the constitutional scheme specifically took away certain
subject matters which would normally fall in List II and would ordinarily be dealt with by a State
Assembly. However, in Delhi’s case, these powers were conferred on the Central Government.
87. He then took us through the provisions of the IT Act to contend that it is undisputed that
Facebook was an intermediary within the definition of the IT Act. Section 2(1)(w) of the IT Act
defines intermediaries as under:
“2(1). In this Act, unless the context requires otherwise, xxxx xxxx xxxx xxxx xxxx
[(w) "intermediary", with respect to any particular electronic records, means any
person who on behalf of another person receives, stores or transmits that record or
provides any service with respect to that record and includes telecom service
providers, network service providers, internet service providers, web-hosting service
providers, search engines, online payment sites, online-auction sites, online-market
places and cyber cafes;]”
88. In the context of the controversy sought to be raised as regards the role of intermediaries during
such law and order problems, Mr. Salve contended that this aspect was covered by the power to
issue directions to block public access to any information and was thus, squarely covered by Section
69A of the IT Act.
89. The aforesaid provision and its role was not a grey area in view of the judicial pronouncement of
this Court in Shreya Singhal v. Union of India.66 Thus, a well-developed procedure to deal with
such issues was 66 (2015) 5 SCC 1.
already in place and consequently, the matter was an occupied field by the Central Government.
90. Another issue raised by Mr. Salve was that the legislative domains of “public order” and “police”
both stood explicitly outside the competence of the Assembly. It was contended that
recommendations in matters which fall within List I or which do not fall within List II cannot be
said to be legislative functions. It was stressed that the purpose for which the summons was issued,
and the issue sought to be addressed by the Committee were aspects of public order and therefore
they were not primary functions of the Assembly.
91. The utterances in the press conference were pointed out to contend that it was amply clear that
the purpose behind its exercise was to file a supplementary chargesheet which was alien to the
powers of the Assembly.
92. The endeavour of Respondent No.1 had been confirmed in the reply filed by the respondents to
compel Petitioner No.1 to testify as an expert witness as part of its decision “to delve into the matter
of concern raised in the complaints (about Facebook)”. The complaints, in turn, dealt with content
allegedly posted on Facebook and how they contributed to the Delhi riots. By respondents’ own
pleadings, the endeavour of compelling Petitioner No.1 to appear before it was in furtherance of theAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

following:
a. Examine testimonies relating to Facebook’s alleged role in the Delhi riots;
b. Examine instances of inaction/inability on the part of social media platform
(Facebook) to enforce its policies against hateful content;
c. Seek views of Petitioner No.1 as a representative of Facebook to understand
Facebook India’s internal policies and their implementation.
d. Ascertain (Petitioners’) views on the question whether the said company’s platform
has contributed to the Delhi riots and also how these platforms could be used to
strengthen unity among the citizens of Delhi in the future.
93. Conscious of the line sought to be adopted by the respondents by referring to “Cooperative
Federalism”, Mr. Salve contended that the same was misconceived as it arose in a factual matrix
where the Union and the State exercise overlapping powers. The exercise of power by the Assembly
in question had no connection with any such area of overlap. He argued that cooperative federalism
cannot be converted into an independent head of power in addition to the powers conferred by the
statute. In this regard reference was made to two judicial pronouncements in K. Lakshminarayan v.
Union of India & Anr. 67 and State (NCT of Delhi) v. Union of India68.
94. In order to appreciate what is meant by “cooperative federalism” in the context of what appears
to be a continuous judicial battle between the Central Government and the State Government has
been enunciated in State (NCT of Delhi) (2018), where the Court encouraged walking hand- in-hand
even if there are different political dispensations in power. We do believe and may note at this stage
that such hope has been repeatedly belied! The enunciation of the principle is set out in para 119 as
under:69 “119. Thus, the idea behind the concept of collaborative federalism is negotiation and
coordination so as to iron out the differences which may arise between the Union and the State
Governments in their respective pursuits of development. The Union Government and the State
Governments should endeavour to address the common problems with the intention to 67 (2020) 14
SCC 664.
68 Supra note 27.
69 Supra note 27 at para 119.
arrive at a solution by showing statesmanship, combined action and sincere cooperation. In
collaborative federalism, the Union and the State Governments should express their readiness to
achieve the common objective and work together for achieving it. In a functional Constitution, the
authorities should exhibit sincere concern to avoid any conflict. This concept has to be borne in
mind when both intend to rely on the constitutional provision as the source of authority. We are
absolutely unequivocal that both the Centre and the States must work within their spheres and not
think of any encroachment. But in the context of exercise of authority within their spheres, thereAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

should be perception of mature statesmanship so that the constitutionally bestowed responsibilities
are shared by them. Such an approach requires continuous and seamless interaction between the
Union and the State Governments. We may hasten to add that this idea of collaborative federalism
would be more clear when we understand the very essence of the special status of NCT of Delhi and
the power conferred on the Chief Minister and the Council of Ministers on the one hand and the
Lieutenant Governor on the other by the Constitution.”
95. Thus, Mr. Salve contended that while the Court has touched on the concept of collaborative
federalism, it has also simultaneously observed in “absolutely unequivocal” terms that both the
Centre and the State have to work within their spheres and not think of any encroachment. It was,
thus, contended that what was sought to be done was clearly an encroachment by relying on the
larger principle of cooperative federalism.
96. An important aspect has, once again, been emphasized in K. Lakshminarayan70, that the
Assembly can seek to exercise power as conferred under the GNCTD Act, promulgated by the
Parliament exercising its residuary powers under Entry 74 of List I. In that context it was
emphasised that there is a difference between Articles 239A and 239AA of the Constitution. The
former is with respect to the Union Territory of Puducherry, which simply provided purely enabling
provisions while the latter contained extensive provisions among which sub-clause (7) empowered
the Parliament to legislate and give effect to all the provisions. Mr. Salve assailed the endeavour of
the Assembly to “clutch at a jurisdiction that is not available”.
97. In response to the Court’s queries arising from the earlier summons being superseded by the
New Summons, the respondents’ contention that the aspect of privilege had not arisen, and whether
the petitioners could claim to be an unaccountable platform; Mr. Salve contended that the
petitioners were ready to comply with any Indian law and had been doing so. What they were not
desirous of doing was to be drawn into an aspect of political divide. To emphasise this point he
referred to a letter dated 70 Supra note 67.
01.09.2020 by the Union Communication Minister alleging inter alia that Facebook India was
leading a concerted effort to shrink the space for dialogue for those with a right-of-centre ideology.
It was, thus, submitted that on the one hand the respondents seem to allege that there was a pro-
Government or a pro-right bias of Facebook while the Central Government claimed the opposite –
the common factor being that both positions were for their respective political reasons by alleging
bias against the petitioners albeit from different sides. Mr. Salve’s contention was that an Assembly
must limit itself to its core function of legislation. Even if it were to summon a witness, this must be
in relation to matters that were within its ambit as demarcated by the Court in the judgment of State
(NCT of Delhi) v. Union of India 71. This judgment made it clear that in reference to the Code of
Criminal Procedure, 1973, the powers in relation to the Entry of public order were conferred on the
Parliament and consequently denuded from the powers of the Assembly. In that context, even if the
widest amplitude was given to the Entries, that was with the objective of not restricting the
legislative competence of the Parliament or the Assembly in a field which they in principle were
competent to 71 Supra note 27 and Govt. of NCT of Delhi v. Union of India 2020 12 SCC 259.
legislate. In the present case, one was concerned with the powers of the Central GovernmentAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

vis-à-vis the State Government and therefore the principle of widest meaning of entries could not
result in overlapping powers as that can hardly be conducive to administrative exigencies. That it
was so was obvious from the submission of the learned Solicitor General who contended that the
doctrine of pith and substance would have to be applied to the reading of the entries while dealing
with them to demarcate the ‘Lakshman Rekha’ for the Parliament and the State Assemblies. In the
context of the controversy, it was urged, that allowing such wide reading of entries would lead to a
slippery slope.
98. In the end, Mr. Salve also emphasised the ‘doublespeak’ between the stand of the counsel for the
Assembly and the Committee; which was a telltale sign that the New Summons was only subterfuge
to get over the possibility or anticipation of an adverse judicial consideration. The right to remain
silent was a virtuous right and in today’s noisy times, should not be curbed or abrogated.
99. Mr. Datar, learned senior counsel for Petitioner No.3, once again, supporting the stand of Mr.
Salve sought to urge that any powers or privileges were in turn circumscribed by the legislative
competence of the Assembly. Thus, any powers or privileges have to be exercised within the
assigned legislative fields. He sought to draw strength from May’s Commentary as also the
Commentary of Kaul and Shakdher in this context where it was observed in the former
“Disobedience to the order of a committee made within its authority is a contempt of the House.”
(emphasis supplied).72 In the latter it was observed “Disobedience to the orders of a Committee of
the House is treated as a contempt of the House itself, provided the order disobeyed is within the
scope of the Committee’s authority…” (emphasis supplied).73 Learned counsel thereafter turned to
the judicial precedents in this regard.74
100. He submitted that the powers and privileges are controlled by the basic concepts of the written
Constitution which could be exercised within the legislative fields allotted to their jurisdiction by the
three lists under the 7th Schedule; and the legislatures were not competent to travel beyond the
lists.75
101. It was, thus, contended that if a primary legislation can be struck down for being outside the
legislative domain, then a committee cannot 72 Supra note 24 at para 38.57.
73 M. N. Kaul and S. L. Shakhder, Practice and Procedure of Parliament , 303 (A. Mishra, 7th Edn.
2016).
74 Supra notes 9 and 15.
75 Supra note 20.
be formed to deal with such matters. Thus, it was argued that the respondents could not say that
they had the power to go into a roving and fishing inquiry before the Committee relating to all
perceived fields based on a belief that the State Assembly deals with the core functions in Delhi. Its
legislative competence by various entries should not be read in such an expansive manner as to not
be restricted by specific exclusions, at least for the purposes of discussion.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

102. Mr. Datar then turned to judicial precedents from the United States to analyse the similar
federal structure of governance in both India and USA. The cases dealt with enquires by the
Congress.
103. In Watkins v. United States76 it was observed that “no enquiry is an end in itself, it must be
related to a legitimate task of Congress.” Thus, academic enquiries cannot be undertaken – it is only
what is within the powers of the Congress that can be enquired into. “Broad is the power of inquiry,
but not unlimited.”77 Such power of enquiry of the Congress is limited to its “legitimate tasks”,
which would imply legislative competence in the present case.
76 354 US 178 (1957) at pg. 187.
77 Ibid.
104. We may note at this stage that a plea was advanced by Dr. Dhavan that this judgment stood
overruled in Barenblatt v. United States78 and Eastland v. United States Servicemen’s Fund79. Mr.
Datar clarified that the aspect he was seeking to rely upon the judgment for was not only not
overruled, but there was confirmation on the limits on the power of inquiry of the Congress as laid
down in Watkins80.
105. He next referred to the judgment in Howard Jarvis Taxpayers Association v. Padilla81 for the
observation that the legislature may not use its powers to “defeat or materially impair” the exercise
of its fellow branches’ constitutional functions, nor “intrude upon a core zone” of another branch’s
authority. The investigative powers may not be used to trench upon matters falling outside the
legislative purview and the investigative power permits inquiry only into those subjects in reference
to which the legislature has power to act.
106. In the context of the requirement of reading of entries widely, Mr. Datar contended that the
power to legislate conferred by Article 239AA(3)(a) was in respect of matters in List II except
Entries 1, 2 & 18. 78 360 US 109 (1959) at pg. 111-112.
79 421 US 491 (1975) at pg. 504.
80 Supra note 76.
81 62 Cali 486 (2016) at pg. 499.
If the principle of reading entries widely is to be applied in this context, even the excluded entries
have to be read widely as conferring the power on the Parliament. It could not be said that entries
conferring power on the State Assembly were to be read widely while at the same time a restrictive
meaning was to be given to entries under which powers have been specifically excluded. The
phraseology “with respect to” entails that the entries encompass anything with a nexus to public
order and/or the police. The powers with respect to such activities, thus, squarely lie with the
Parliament. Once again, a judicial view already taken was clear and explicit, i.e., that the AssemblyAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

did not have any power – legislative or executive, over the police and its functions. 82 Thus,
exempted entries would have to be read in substance and not hyper-technically, and Article 239AA
would have to be read contextually as also widely to include all ancillary and subsidiary matters.
This in turn denuded the Assembly and the Committee of the powers to legislate or enquire into that
aspect. As such, what has been specifically denied to the Assembly could not be achieved through
Committees under the garb of “peace and harmony.” The Assembly had no jurisdiction to address
violence and communal 82 Govt. of NCT of Delhi v. Union of India 2020 12 SCC 259. riots, if Entries
1 & 2 of List II are interpreted as submitted. In the end there could be no power even to investigate
these matters.
107. The Committee, it was argued, was a creation of the Assembly and could not have a larger
jurisdiction than the Assembly itself. The Bulletin issued on 02.03.2020 suggested that the
Committee was formed to deal with matters falling in Entries 1 & 2 of List II while stating this to be
“in view of the recent communal riots and violence….”. This made it amply clear that the Committee
was meant to deal with the violence and disturbance caused to public order during the riots. The
expression “public order” has to be interpreted broadly and would encompass communal peace and
harmony. The summons issued by the Committee related to the law and order situation of Delhi for
which the Assembly had no power to investigate or formulate law. If there was no competence with
regard to such matters, the summons in that context would be without jurisdiction and, thus, void
ab initio.
108. Since cooperative federalism was propagated as the basis to justify the constitutionality of the
actions of the respondents, it was submitted that the same would not amount to a license to place
reliance on Entries 1 & 2 of List III to sidestep the explicit exclusion in Article 239AA(3)(a) of the
Constitution. The relevant Entries are as under:
“LIST III – CONCURRENT LIST
1. Criminal law, including all matters included in the Indian Penal Code at the
commencement of this Constitution but excluding offences against laws with respect
to any of the matters specified in List I or List II and excluding the use of naval,
military or air forces or any other armed forces of the Union in aid of the civil power.
2. Criminal procedure, including all matters included in the Code of Criminal
Procedure at the commencement of this Constitution.”
109. The matters relating to criminal law would not include power to legislate on issues pertaining
to public order and communal peace and harmony as the same is traceable to “public order”, if the
latter is to be interpreted broadly.
110. Mr. Datar further argued that Entry 45 of List III, which relates to inquiries, cannot enable the
Assembly to inquire into public order, police functions or communications. The power of inquiry
has to be directly related to the legitimate subjects over which the Assembly has powers to legislate.
To buttress his argument on the concept of collaborative federalism, Mr. Datar relied upon theAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

observations of this Court in State (NCT of Delhi) v. Union of India 83 which held that “both the
Centre and the States must work within their spheres and not think of any encroachment.”
111. Mr. Datar argued that obviously the Central Government and the State Government had
different perceptions as to what transpired in Delhi and it can hardly be disputed that it was a law
and order issue arising from communal riots. This was not an aspect that either the Assembly or any
of its committees could deal with. If the Assembly cannot legislate on a subject, it cannot explore the
same under an executive investigation. The mere reluctance to participate could not be threatened
with a breach of privilege and the subject matter being dealt with by the Committee was outside the
purview and power of the Assembly.
112. Mr. Datar emphasised that the role of Facebook was of an intermediary and, thus, the relevant
regulatory mechanism was under the IT Act. He went as far as to contend that there was no
jurisdiction to examine Facebook, as its operations were covered by Entry 31, List I, under “other
forms of communication”. Since the Parliament has overriding power to legislate with respect to
entries in List I under Article 83 Supra note 27.
246(1) of the Constitution, the Assembly could not intervene in matters relating to
intermediaries/other forms of communication. In addition, it was urged that this special entry of
“communication” overrides the general entries of “inquiries” and “criminal law” (List III), which the
Delhi Assembly had attempted to rely on.84
113. Learned counsel next turned to Section 79 of the IT Act which deals with exemption from
liability of intermediaries in certain cases.
114. Mr. Datar finally urged that an intermediary like Facebook has no control over the content
hosted on it and is in fact, prohibited from knowing the substance of the content on their platform
or exercising any control over the same except as prescribed by law. It was, thus, submitted that an
intermediary cannot be held liable for any third party data/information made available/hosted by
them. Facebook was simply a platform where messages are transferred from one person to the
other. Whatsapp, Signal, Telegram are even end-to-end encrypted. These are intermediaries who are
not liable for third party information hosted on them. The only obligation which Section 79 of the IT
Act imposes is that of due diligence on the part of intermediaries as Facebook did not initiate 84
Kerala State Electricity Board v. The Indian Aluminium Co. Ltd. (1976) 1 SCC
466. the transmissions, nor controlled the same. Hence, they cannot be held liable and any action
taken against intermediary has to be in the manner prescribed by the Act.85 It was stated that the
New Summons did not change the position in any way as the content of the inquiry was the same.
115. Dr. Singhvi, seeking to rebut the arguments canvassed on behalf of the petitioners sought to
emphasise that it is not appropriate to equate the expression “peace and harmony” with “law and
order” as the former was a much broader term. In any case, Legislative Assemblies have wide
inquisitorial powers,86 i.e. areas which are otherwise not available to a legislature for legislative
interference are still available to a committee of the legislature. The relevant para from KalpanaAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

Mehta reads as under:
“335. Various committees of both Rajya Sabha and Lok Sabha are entrusted with
enormous duties and responsibilities in reference to the functions of the Parliament.
Maitland in 'Constitutional History of England' while referring to the committees of
the Houses of British Parliament noticed the functions of the committees in the
following words:
“...Then again by means of committees the Houses now exercise what we may call an
inquisitorial power. If anything is going wrong in public affairs a committee may be
appointed to investigate the matter; witnesses can be summoned to give evidence on
oath, and if they will 85 Supra note 66.
86 Supra note 20.
not testify they can be committed for contempt. All manner of subjects concerning the public have of
late been investigated by parliamentary commissions; thus information is obtained which may be
used as a basis for legislation or for the recommendation of administrative reforms.” (emphasis
supplied)
116. This was stated to be in furtherance of the legislative competence of an Assembly and in
exercise of the Committee’s inquisitorial powers to make the best possible recommendations.
117. Dr. Singhvi contended that selective extracts of the press conference cannot be the basis for
giving a different meaning to the proceedings than the Terms of Reference. He sought to clarify that
the scope of the Committee was purely recommendatory, including making positive
recommendations to ensure peace and harmony in the NCT of Delhi in the future which relates to
various heads of competence of the Assembly in List II and List III of the 7th Schedule. No federal
unit can function in the absence of peace and harmony amongst various groups of people who
reside, live and work in that federal unit. Thus, the domain of peace and harmony in the NCT of
Delhi is something very broad and inherent to the legislature of the federal unit and encompasses
within it many areas of competence of the Assembly both in List II and List III. It was further
contended that “fraternity” is a preambular value which, like equality and liberty, imbues the
functioning of the entire Constitution. He referred to Entry 39 of List II relating to “Powers,
privileges and immunities of Legislative Assembly” to emphasise that enforcement of attendance of
persons for giving evidence or producing documents before committees of the Legislature of the
State was an intrinsic part of its functions. This coupled with Entry 45 of List III dealing with
Inquiries and Statistics for the purposes of any of the matters specified in List II or List III would
completely cover the aspects sought to be gone into by the Committee.
118. Dr. Singhvi, in support of the manner in which such committees can function and their remit,
referred to three judicial pronouncements from the United States: (i) Eastland v. The United States
Servicemen’s Fund87, (ii) Watkins v. United States88 and (iii) Barenblatt v. United States89. The
common thread which permeates these judgments is that the power to investigate is inherent in theAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

power to make law as a legislative body cannot legislate wisely or effectively in the absence of
information with respect to the conditions that the legislation is intended 87 Supra note 79.
88 Supra note 76.
89 Supra note 78.
to affect or change. In that context, the issuance of subpoenas could be exercised by a committee
acting on behalf of the House. It was thus said:
“To conclude that the power of inquiry is other than an integral part of the legislative
process would be a miserly reading of the Speech or Debate Clause is derogation of
the integrity of the legislature.”90
119. Such an inquiry was not in turn circumscribed by what the end result would be:
“Nor is the legitimacy of a congressional inquiry to be defined by what it produces.”
91 Such investigative function was akin to any research with the possibility of
researchers ending up in some “blind alleys” and into non-productive enterprises, as
“to be a valid legislative inquiry there need be no predictable end result.” 92
120. On the duty of a citizen to cooperate with US Congress in an effort to obtain the
facts, it was held to be an “unremitting obligation to respond to subpoenas, to respect
the dignity of the Congress and its committees and to testify full with respect to
matters within the province of proper investigation.”93
90 Supra note 79.
91Supra note 79.
92 Supra note 79.
93 Supra note 76.
121. On an aspect of teaching which is pursued in educational institutions, it was observed that
inquiries cannot be made into a constitutional protection against the freedom to teach. But this
would not preclude the Congress from interrogating a witness merely because he is a teacher. Thus,
“an educational institution is not a constitutional sanctuary from inquiry into matters that may
otherwise be within the constitutional legislative domain merely for the reason that inquiry is made
of someone within its walls.”94
122. Dr. Singhvi submitted that it was inappropriate for the petitioners to link the competence to
discuss the subject matter with the powers to exercise privilege. The Terms of Reference that define
the scope and competence not having been challenged, it was submitted that it was not appropriate
for the petitioners to invite a view of this Court on the competence of the Committee. The argumentAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

about excluded Entries was labeled as a “smokescreen”. In the context of the claim of exclusion
arising from Entries it was submitted that any such exclusion would have to be narrowly
construed.95 94 Supra note 78.
95 Synthetics and Chemicals Ltd. v. State of U.P. (1990) 1 SCC 109.
123. Dr. Dhavan adopted the same line of argument as Dr. Singhvi, referring to the same judicial
pronouncements. He submitted that the holding in Watkins96 was based on Chief Justice Warren’s
exclamatory resentment of McCarthyism in the 1950s and has since been criticized as unnecessarily
limiting the powers of Congress. On the same lines were the subsequent judgments of the Supreme
Court which settled major issues of congressional authorisation and relevance of the first
amendment.97 The view taken thereafter by the US Supreme Court reinforces powers of the
Committee rather than undermines them. 98 The essence of American Law, he contended, is that
when you are summoned, you must appear but can plead the fifth amendment in not answering
questions.
124. Dr. Dhavan proceeded with his arguments on a larger canvas that the Delhi Government was
empowered to cover every aspect of its governance, and peace and harmony could not be equated
solely with police functions and public order. The argument can be said to be on four different
planes: (i) harmonious interpretation of entries; (ii) the ragbag 96 Supra note 76.
97 Wilkinson v. United States 365 US 399 (1961); Braden v. United States 365 US 431 (1961).
98 Supra note 79.
approach; (iii) wide scope of inquiries under Entry 45 of List III; and (iv) executive power must be
interpreted widely. The emphasis of Dr. Dhavan’s argument was that communal harmony is an
important part of Delhi’s governance that goes beyond the limited remit of police functions and
public order. The incident of February, 2020 in Delhi was stated to prove that in addition to
affecting public order, communal disharmony has a harmful effect on trade and commerce,
transportation, education and governance generally. Considering the implication of these domains,
it was contended that it would be deeply harmful if the police were the sole custodians of peace and
harmony. The initial course of action requires people to be educated and that governing authorities
liaise with them in order to calm tensions. To agree to the submissions of the petitioners would be to
permit the argument that there was none in the Delhi Government who could address the issue of
peace and harmony. On a larger canvas, the message that would permeate to non-members would
be that they could get away by not appearing before the Legislative Assemblies, as the latter had no
power to compel their appearance. It was submitted that this would make the entire system of
Committee proceedings farcical. The need for harmonious construction required that legislative
entries must be given the widest amplitude and, thus, he submitted that it was the duty of the Court
to reconcile entries that may appear to overlap or may be in direct conflict.99
125. Dr. Dhavan sought to introduce the concept of ragbag legislation, submitting that this was an
expression used by the Indian Supreme Court in income tax jurisprudence.100 The ragbag approachAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

suggested that legislative and executive powers need not be traced to only one entry, but may
instead be traced to multiple entries in the relevant list in the 7 th Schedule. Thus, this perspective of
multiple entries may empower the Committee to consider peace and harmony – some that were
directly applicable like education, and others that applied indirectly like trade and commerce. Peace
and harmony was a concept much beyond public order and police, and illustrations of the same
were given from List II and List III. The relevant portions of List II and List III as given in the 7 th
Schedule read as under:
“List II—State List
5. Local government, that is to say, the constitution and powers of municipal
corporations, improvement trusts, districts boards, mining settlement authorities
and other 99 Jilubhai Nanbhai v. State of Gujarat (1995) Supp. 1 SCC 596. 100 Ujagar
Prints (II) v. Union of India (1989) 3 SCC 488.
local authorities for the purpose of local self-government or village administration.
6. Public health and sanitation; hospitals and dispensaries.
7. Pilgrimages, other than pilgrimages to places outside India.
10. Burials and burial grounds; cremations and cremation grounds.
12. Libraries, museums and other similar institutions controlled or financed by the State; ancient
and historical monuments and records other than those [declared by or under law made by
Parliament] to be of national importance.
13. Communications, that is to say, roads, bridges, ferries, and other means of communication not
specified in List I; municipal tramways; ropeways; inland waterways and traffic thereon subject to
the provisions of List I and List III with regard to such waterways; vehicles other than mechanically
propelled vehicles.
17. Water, that is to say, water supplies, irrigation and canals, drainage and embankments, water
storage and water power subject to the provisions of entry 56 of List I.
22. Courts of wards subject to the provisions of entry 34 of List I; encumbered and attached estates.
24. Industries subject to the provisions of [entries 7 and 52] of List I.
26. Trade and commerce within the State subject to the provisions of entry 33 of List III.
27. Production, supply and distribution of goods subject to the provisions of entry 33 of List III.
28. Markets and fairs.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

32. Incorporation, regulation and winding up of corporations, other than those specified in List I,
and universities; unincorporated trading, literary, scientific, religious and other societies and
associations; co-operative societies.
35. Works, lands and buildings vested in or in the possession of the State.
37. Elections to the Legislature of the State subject to the provisions of any law made by Parliament.
39. Powers, privileges and immunities of the Legislative Assembly and of the members and the
committees thereof, and, if there is a Legislative Council, of that Council and of the members and
the committees thereof; enforcement of attendance of persons for giving evidence or producing
documents before committees of the Legislature of the State.
65. Jurisdiction and powers of all courts, except the Supreme Court, with respect to any of the
matters in this List.” “List III—Concurrent List
1. Criminal law, including all matters included in the Indian Penal Code at the commencement of
this Constitution but excluding offences against laws with respect to any of the matters specified in
List I or List II and excluding the use of naval, military or air forces or any other armed forces of the
Union in aid of the civil power.
3. Preventive detention for reasons connected with the security of a State, the maintenance of public
order, or the maintenance of supplies and services essential to the community; persons subjected to
such detention.
8. Actionable wrongs.
12. Evidence and oaths; recognition of laws, public acts and records, and judicial proceedings.
15. Vagrancy; nomadic and migratory tribes.
16. Lunacy and mental deficiency, including places for the reception or treatment of lunatics and
mental deficients.
20. Economic and social planning.
23. Social security and social insurance; employment and unemployment.
25. Education, including technical education, medical education and universities, subject to the
provisions of entries 63, 64, 65 and 66 of List I; vocational and technical training of labour.
28. Charities and charitable institutions, charitable and religious endowments and religious
institutions.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

33. Trade and commerce in, and the production, supply and distribution of,—
(a) the products of any industry where the control of such industry by the Union is declared by
Parliament by law to be expedient in the public interest, and imported goods of the same kind as
such products;
(b) foodstuffs, including edible oilseeds and oils;
(c) cattle fodder, including oilcakes and other concentrates;
(d) raw cotton, whether ginned or unginned, and cotton seed; and
(e) raw jute.
38. Electricity.
39. Newspapers, books and printing presses.
40. Archaeological sites and remains other than those [declared by or under law made by
Parliament] to be of national importance.
45. Inquiries and statistics for the purposes of any of the matters specified in List II or List III.”
126. Dr. Dhavan further submitted that the constitutional obligation to take preventive action to
ensure non-discrimination provided for the Government’s duty to examine and recommend action
in respect of peace and harmony as also to protect religion, cultural rights and dignity of individuals
as envisaged in various constitutional provisions, i.e., Articles 14, 15, 16, 17, 21, 25 to 30, 39A, 39(b),
40, 41, 46 and 47. These provisions are really an amalgam of fundamental rights and directive
principles of state policy. Considerable emphasis was placed by Dr. Dhavan on Entry 45 in List III,
which is a self-standing entry that has been given the widest amplitude by this Court. 101 This entry
deals with the executive power to make committees of inquiry. In that context it has been observed
that these inquiries would encompass any matter enumerated in any of the Lists and would not be
confined to those matters as mere heads of legislative topics – extending the inquiries into collateral
matters. Further referring to Entry 39 of List II, Dr. Dhavan 101 Sriram Krishna Dalmia v. Justice
Tendolkar 1959 SCR 279 at pgs. 289, 291. urged that this entry was wide enough from a bare reading
to include the power to summon non-members having used the expression of “enforcement of
attendance of persons”.
127. The thread which permeated Dr. Dhavan’s arguments was that the task of governance is much
wider than merely drafting legislation and executing it. Executive power would collapse if it were to
be reduced to simply executing the laws enacted by the Legislature and, thus, the Supreme Court
had explained that executive power without law had to be construed widely.102Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

128. After having dealt with the four aspects referred to aforesaid, Dr. Dhavan sought to respond to
Mr. Salve’s argument of the legislative domain being occupied by the IT Act. It was Dr. Dhavan’s
submission that the IT Act was an example of “cooperative federalism” as the Act empowered both
the State and the Centre in terms of the definition of “appropriate government” in Section 2(e).
Thus, provisions such as Section 6 and 69 of the IT Act could refer to either the Centre or the State
and the legislative domain could not be said to be exclusively occupied by the Centre. This is more so
in the context of a mere summons that 102 Rai Sahib Ram Jawaya Kapur v. State of Punjab (1955) 2
SCR 225. required the petitioner’s appearance without reaching the stage at which punitive action
may be considered. The Committee was submitted not to be engaged in any inquisitorial exercise
but was only limited to aid in the spirit of cooperative federalism.
129. Cooperative federalism was contended not to be a source of power but rather a part of the
principles that underlie the Constitution. It was a method of communication that makes federalism
more effective requiring both Centre and State to work together to address common problems.
Thus, the State could not exist without collaborative or cooperative federalism.103 This was stated
to be of even greater significance in light of the tug of war between the Centre and the State in
respect of the unique position of the Delhi Legislative Assembly. As such, peace and harmony issues
ought to be resolved by a coordinated effort. He did, of course, concede that the history of two
governments was testament to a tussle which was closer to being competitive rather than
collaborative.
130. Dr. Dhavan, thus, concluded his arguments by submitting on this aspect that:
103 Supra note 27.
(a) it was not his contention that conventions and broad concepts are sources of
power;
(b) underlying principles, however, are fundamental to both interpretation of the
Constitution and powers exercised through the Government or their legislatures;
(c) a recommendatory committee has a duty to inform the Central Government of the
problems it encounters so that organs of Government can act in furtherance of this
principle of cooperative pragmatic federalism;
(d) the Committee by itself did not claim the power to punish the breach though it
does possess the power to summon without penal consequences. It could at best
make a recommendation which would have to be examined by the House through the
process of a privileges committee. This was a routine part of every summon, only
indicative of the power of the Parliament/Assembly.
131. Mr.Tushar Mehta, learned Solicitor General sought to advance submissions substantially on
this aspect as there was a conflict in the stands taken by the State and the Central Government on
this issue. As noticed earlier – while on the one hand he was with the State Government on the issueAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

of the right to summon per se, a difference arose on account of his argument that in the given factual
situation, the power to summon vested solely with the Central Government. Mr. Mehta referred to
Article 212 of the Constitution, which reads as under:
“212. Courts not to inquire into proceedings of the Legislature. – (1) The validity of
any proceedings in the Legislature of a State shall not be called in question on the
ground of any alleged irregularity of procedure.
(2) No officer or member of the Legislature of a State in whom powers are vested by
or under this Constitution for regulating procedure or the conduct of business, or for
maintaining order, in the Legislature shall be subject to the jurisdiction of any court
in respect of the exercise by him of those powers.”
132. It was his submission that proper effect should be given to the above provision and the Court
did not really have the power to deal with the functioning/internal administration of the
Parliament/Assemblies and the committees thereof. There was, however, a narrow scope of judicial
review permitted in the present case as the person involved was not a member of the House. The
enquiry being ultra vires the powers conferred on the Assembly, he contended that the subjects
specifically excluded by the Constitution could not be surreptitiously brought within the purview of
the Assembly by categorising the issue as “peace and harmony.” It was intrinsically a law and order
issue, which was an occupied field and also an excluded field so far as the Assembly was concerned.
133. While accepting that privilege was necessarily connected with legislative power, the same (if the
aspect so arose) would have to be considered in the context of legislative competence. The plenary
powers of the legislature were circumscribed by the written Constitution which set out the legislative
fields allotted to each of their jurisdictions by the three Lists in the 7th Schedule putting an embargo
on the Legislatures to travel beyond the entries in their respective lists.104
134. Learned Solicitor General sought to emphasise on the unique case of Delhi with reference to its
excluded entries. It was not at par with any other State Assembly. Delhi was the national capital and
thus, the law makers had consciously made a provision keeping this larger picture in mind and
reserving to the Parliament three entries which would otherwise be available in List II to the State
Assemblies. In the absence of legislative competence, it would be a colourable exercise of power to
engage in the subject matter. The formation of a “peace and harmony” 104 Supra note 12.
committee was stated to be one such colourable exercise of power. This became apparent from the
summons issued which explicitly provided that, in effect, the Committee was dealing with law and
order and the police. The battle between the Centre and the State qua Delhi which gave rise to the
previous judicial pronouncements, clarified which of the two had powers qua specific excluded
entries. It would be a betrayal of the mandate of these judgments which had upheld the rationale
behind exclusion of entries drawing from the unique position of Delhi.105
135. The pith and substance argument was sought to be advanced to contend that reliance on entries
in List II and List III was not justified if the matter directedly related to excluded entries.106Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

136. Learned Solicitor General, while accepting the proposition that entries have to be read widely,
submitted that where there is a specific entry dealing with a particular subject, that specific entry
would prevail to the exclusion of the general entry.107 The entries relied upon by the respondents
were general in nature, while the entries of “law and order” and “police” were specific and thus,
must prevail. The subsequent 105 Supra notes 27 and 82.
106 A.S. Krishna v. State of Madras AIR 1957 SC 297 at para 8; Kartar Singh v. State of Punjab
(1994) 3 SCC 569 at para 60; Zameer Ahmed Latifur Rehman Sheikh v. State of Maharashtra & Ors.
(2010) 5 SCC 246 at para 40. 107 Supra note 84.
executive action was also not permissible for the Assembly as the Central Government had sole
jurisdiction even over executive matters relatable to those entries in view of Article 73 of the
Constitution. The executive powers were mandated to be co-terminus with legislative competence
and the legislature could not be allowed to intervene through the indirect method of committees and
its privilege, thereby overreaching the Constitution.
137. The principle of cooperative and collaborative federalism was not disputed but then it was
urged that the summons did not say that the Assembly and the Committee wanted to give any
recommendations. This was only a defence and an afterthought. By way of example, Mr. Mehta
averred that on a defence strategy matter, the Assembly could not be permitted to call the Chief of
Defence Staff (CDS). In fact, it was submitted that cooperative/collaborative federalism required the
Assembly to function within the confines of the powers conferred on it and not commit an overreach
– to read it otherwise would be combative or competitive federalism.
138. On the doctrine of occupied field, it was urged that the subjects which the Committee sought to
go into were already occupied by the Parliament. Facebook was an intermediary, and in that regard
would be covered under “communication”, which is Entry 31 of List I. In fact, all three fields of
intermediaries, law and order or police were occupied by the Parliament. There was no perceived
conflict of entries and the specific omission of Entries 1 & 2 of List II and the presence of Entry 31 of
List I, clearly indicated which fields were specifically occupied by the Parliament and what has been
specifically omitted for the Assembly.108
139. It was submitted that the Parliamentary Standing Committee on Information Technology was
already in seisin of the aspect of “Safeguarding citizens’ rights and preservation of misuse of
social/online news media platforms including special emphasis on women security in the digital
space”. It was in pursuance thereto that a notice was issued to Petitioner No.1 on 20.08.2020 to
provide his views and the said petitioner duly appeared before that Committee on 02.09.2020.
There was, thus, no occasion for the Committee to go into this aspect.
140. On the aspect of the IT Act, a field occupied by the Parliament, it was submitted that even rules
have been framed thereunder including the 108 ITC Ltd. v. State of Karnataka 1985 Supp SCC 476 at
paras 17, 32; Hoechst Pharmaceuticals Ltd. v. State of Bihar (1983) 4 SCC 45 at para 51; Offshore
Holdings (P) Ltd. v. Bangalore Development Authority (2011) 3 SCC 139 at paraAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

102. IT (Procedure and Safeguards for Blocking for Access of Information by Public) Rules that
provide an elaborate procedure for blocking of information by an online intermediary and their
criminal liability for failing to do so. The IT Act has been formulated under Entry 31 of List I, which
covers “other forms of communication”. Thus, in that sense the intermediaries were beyond the
competence of the Assembly. Section 69A of the IT Act specifically deals with blocking of content,
including hate speech.
141. It was his submission that the legal issues involving law and order, public order, and the
corresponding responsibility of online intermediaries to address hate speech on their platforms have
already been addressed by the Central Government. The Assembly not having legislative
competence, cannot also have the competence to examine people and prepare a report. There was
no power to give recommendations and the summons did not even clarify that the exercise was for
making recommendations.
142. Finally, the learned Solicitor General referred to the case in N. Ravi109 to contend that the
issue in contention, i.e., the interplay of 109 Supra note 46.
fundamental rights and parliamentary privileges, was already pending before a 7-Judge Bench.
Recent Developments:
A. Role of Intermediaries:
143. In COVID times there have been some fast-paced developments around the
world qua the role and management of intermediaries. In view of there being some
time gap between the date of reserving the judgment and its pronouncement, we
consider it appropriate to pen down these developments over the last four months.
The UK Commons Privileges Committee published a new report on select committee
powers on 03.05.2021, looking to strengthen the ability of select committees to call
for persons, papers, and records. The background to this is the reluctance, or in some
cases even refusal, of individuals to appear before these committees in a number of
high-profile cases. The Privileges Committee has proposed a Parliamentary
Committees (Witnesses) Bill, which would introduce new criminal offences relating
to refusal to attend a summons or failing to provide information or documents
without a reasonable excuse110.
110 Alexander Horne, Should Select Committees Be Able To Compel Attendance?, Prospect
Magazine (07/05/2021), accessible at:
https://www.prospectmagazine.co.uk/politics/should-select-committees-be-able-
Intermediaries and platforms have seen a hot pursuit in the US for regulating the
consequences of their business. The House Energy and Commerce Committee of the
US House of Representatives issued a summons to Facebook CEO Mark Zuckerberg,Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

Google CEO Sundar Pichai, and Twitter CEO Jack Dorsey on 25.03.2021, with which
they duly complied. The House Committee pointed out false claims about COVID-19
vaccines and the supposed election fraud that had proliferated on social media
platforms.111 The background was the incident at the Capitol post the US
Presidential Election results being declared in 2021.
It is of significance to note the comments of the Chairman of the Committee, Frank
Pallone that, “For far too long, big tech has failed to acknowledge the role they have
played in fomenting and elevating blatantly false information to its online audiences.
Industry self-
regulation has failed.”112 The Chairmen of two other sub-committees remarked, “We
must begin the work of changing incentives driving social to-compel-attendance.
111 Lauren Feiner, Facebook, Google And Twitter CEOs Will Make Another Appearance Before
Congress In March, CNBC (18/02/2021), accessible at:
https://www.cnbc.com/2021/02/18/facebook-google-twitter-ceos-to-testify-before-
congress-in-march.html.
112 House Committee on Energy and Commerce , Press Release, , E&C Committee Announces
Hearing with Tech CEOs on the Misinformation and Disinformation Plaguing Online Platforms,
(18/02/2021), accessible at:
https://energycommerce.house.gov/newsroom/press-releases/ec-committee-
announces-hearing-with-tech-ceos-on-the-misinformation-and.
media companies to allow and even promote misinformation and disinformation.”113
The divergence of views between Republicans and Democrats was also evident. While
the former claimed that conservative viewpoints are maligned on social media
platforms, the latter sought action against misinformation and hate speech with
special attention to its impact on minority communities including the LGBTQ+
community, the Black community, Asian Americans, and Latin Americans. These
developments, to our mind, are apposite to be examined in the context of the
argument advanced on behalf of the petitioners that they do not want to appear
before the Committee on account of a divided political milieu.
144. In India, since 2020, a Joint Parliamentary Committee has been examining the
Personal Data Protection Bill, 2019 in relation to the issues of data protection and
security.114 The Committee summoned telecom operators Jio and Airtel as well as
aggregators Ola and Uber in November, 2020. Google, PayTM, Facebook, Twitter
and Amazon have
113 Ibid.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

114 Ministry of Parliamentary Affairs, Press Release, Joint Committee on the Personal Data
Protection Bill, 2019 Seeks Views and Suggestions , (03/02/2020), accessibleat:
https://pib.gov.in/PressReleasePage.aspx?PRID=1601695. earlier deposed before this
Committee115 and the report of the parliamentary committee is stated to be in its final stages.
145. A significant development has been the notification of The Information Technology
(Intermediary Guidelines and Digital Media Ethics Code) Rules, 2021 on 25.02.2021116, a day after
the judgment was reserved. These rules introduce a range of due diligence measures to be
implemented by intermediaries and lay down a code of ethics for digital news platforms in relation
to digital media. These Rules have been assailed before different High Courts across the country
including Kerala, Karnataka, Madras, and Delhi, and are currently pending consideration. B.
Amendment to the GNCTD Act, 1991:
146. Yet another significant development in the context of the controversy before us, in the
legislative domain, has been the amendment 115 India Today Web Desk, Parliamentary Panel
Summons Airtel, Jio, Uber, Ola, Truecaller Over Data Security Concerns, India Today, aaccessible
at:
https://www.indiatoday.in/india/story/parliamentary-panel-summons-airtel-jio-
uber-ola-truecaller-over-data-security-concerns-1736020-2020-10-28.
116 The Information Technology (Intermediary Guidelines and Digital Media Ethics Code) Rules,
2021, Notification of the Ministry of Electronics & Information Technology No. 2021 G.S.R. 139(E)
(25/02/2021), accessible at:
https://www.meity.gov.in/writereaddata/files/Intermediary_Guidelines_and_Digital_
Media_Ethics_Code_Rules-2021.pdf.
of the GNCTD Act which came into force on 27.04.2021117. The amendments are:
a. The term ‘Government’ referred to in any law made by the Delhi Legislative
Assembly will mean the Lieutenant Governor (‘LG’).
b. The LG must reserve for the consideration of the President all bills that
incidentally cover any matters that fall outside the purview of the powers conferred
on the Legislative Assembly. c. Rules made by the Delhi Legislative Assembly to
regulate its own procedure and conduct of business in the Assembly must be
consistent with the Rules of Procedure and Conduct of Business in the Lok Sabha.
d. The Delhi Legislative Assembly will not be entitled to make rules to (i) enable itself
or its Committees to consider matters of day-to-day administration of the NCT of
Delhi, or (ii) conduct any inquiry in relation to administrative decisions; and any
such rules made prior to this amendment will be void.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

117 Ministry of Home Affairs, Press Release, , Amendments to GNCTD Act, 1991 Do not Alter
Constitutional and Legal Responsibilities of Elected Government in Respect of Transferred Subjects
in State & Concurrent Lists (29/04/2021), accessible at:
https://pib.gov.in/PressReleaseIframePage.aspx?PRID=1714828. e. Any executive action taken by
the Delhi Government will be in the name of the LG and the requirement of a prior opinion of the
LG by the Delhi Legislative Assembly before it takes any executive action in respect of certain
matters with such matters being specified by a general or special order issued by the LG.
147. The object of the aforesaid as per the Statement of Objects and Reasons of these amendments is
stated to be to promote “harmonious relations between the legislature and the executive” and to
define the responsibilities of the elected government and the LG in accordance with the two NCT
judgments118. Suffice to state that these amendments have been assailed before the Delhi High
Court and are pending consideration.
148. We say that these amendments are significant as in a way they appear to be an offshoot of the
continuous tussle between the State Assembly and the Central Government. The present
proceedings where such difference of opinion is clearly reflected seem to also be a trigger, possibly
in an attempt to control what the Assembly and the Committee intended. However, we are
concerned with the situation prevalent at the relevant time and the arguments advanced in that
behalf. We have not 118 Supra notes 27 and 82.
been called upon to comment on the consequences of these amendments qua the subject matter of
the present proceedings, more so when the challenge in respect of the same is pending before the
Delhi High Court. The Opinion:
149. We must begin our opinion by noticing at the inception itself, the vast and
influential role of an intermediary like Facebook. In this modern technological age, it
would be too simplistic for the petitioners to contend that they are merely a platform
for exchange of ideas without performing any significant role themselves – especially
given their manner of functioning and business model. Debate in the free world has
shown the concern expressed by Governments across the board and the necessity of
greater accountability by these intermediaries which have become big business
corporations with influence across borders and over millions of people. Facebook
today has influence over 1/3 rd population of this planet! In India, Facebook claims
to be the most popular social media with 270 million registered users. The width of
such access cannot be without responsibility as these platforms have become power
centres themselves, having the ability to influence vast sections of opinions.
Without undermining the role performed by Facebook in giving a voice to various sections of society
across the world, it has to be noted that their platform has also hosted disruptive voices replete with
misinformation. These have had a direct impact on vast areas of subject matter which ultimately
affect the governance of States. It is this role which has been persuading independent democracies
to ensure that these mediums do not become tools of manipulative power structures. These
platforms are by no means altruistic in character but rather employ business models that can beAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

highly privacy intrusive and have the potential to polarize public debates. For them to say that they
can sidestep this criticism is a fallacy as they are right in the centre of these debates.
150. Facebook as a platform is in the nature of a mass circulation media which raises concerns of
editorial responsibility over the content circulated through its medium. The width of the reach of
published material cannot be understated or minimized. Facebook has acknowledged in their reply
that they removed 22.5 million pieces of hate speech content in the second quarter of 2020 itself,
which shows that they exercise a substantial degree of control over the content that is allowed to be
disseminated on its platform. To that extent, a parallel may be drawn with editorial responsibility
cast on other mass circulation media.
151. The business modelof intermediaries like the petitioner being one across countries, they cannot
be permitted to take contradictory stands in different jurisdictions. Thus, for example in the United
States of America, Facebook projected itself in the category of a publisher 119, giving them
protection under the ambit of the First Amendment of its control over the material which are
disseminated in their platform. This identity has allowed it to justify moderation and removal of
content. Conspicuously in India, however, it has chosen to identify itself purely as a social media
platform, despite its similar functions and services in the two countries. Thus, dependent on the
nature of controversy, Facebook having almost identical reach to population of different countries
seeks to modify its stand depending upon its suitability and convenience.
152. We are afraid we are not inclined to accept the simplistic approach sought to be canvassed by
Mr. Salve on the role of Facebook. Forceful as it may be, it does not convince us. Developments
around the world, as 119 Facebook’s Motion to Dismiss Pursuant to Federal Rule Of Civil Procedure
12(B)(6) and Incorporated Memorandum Of Law in Laura Loomer v. Facebook Inc. Case No.9:
19-cv-80893-RS, accessible at https://docs.reclaimthenet.org/Loomer-
v-Facebook-fb-response.pdf.
we have noted above, reflect rising concerns across borders. The concern is whether the liberal
debate which these platforms profess to encourage has itself become a casualty. We have noticed in
the beginning that algorithms, which are sequences of instructions, have human interventions to
personalise content and influence opinions as part of the business model. As such, their primary
objective is to subserve their business interests. It is first a business and then anything else. As per
their own acknowledgement, they would only appear before any committee if it served their
commercial and operational interests, as it did when they appeared before the parliamentary
committee. But if their business interests are not served, they seek a right to stay away. Such a stand
is completely unacceptable to us. Facebook has the power of not simply a hand but a fist, gloved as it
may be.
153. We now turn to the incident at hand, that of an unfortunate violent eruption. The need to go
into this incident both from a legal and social perspective cannot be belittled. The capital of the
country can ill-afford any repetition of the occurrence and thus, the role of Facebook in this context
must be looked into by the powers that be. It is in this background that the Assembly sought to
constitute a peace and harmony committee – whether it has the legislative competence or not is anAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

aspect we will deal with it under the relevant head. The Assembly being a local legislative and
governance body, it cannot be said that their concerns were misconceived or illegitimate. It is not
only their concern but their duty to ensure that “peace and harmony” prevails. However, we may
note that the long and repeated battles between the State and the Centre appear to have cast a
shadow even over the well-meaning intent of the Committee to assess peace and harmony as
reflected in the Terms of Reference.
154. We may record that the Central Government and the State Government have been unable to see
eye to eye on governance issues in Delhi. This has been responsible for a spate of litigation and
despite repeated judicial counsel to work in tandem, this endeavour has not been successful. There
is little doubt that the constitution of the governance model in Delhi is somewhat unique. This itself
flows from Delhi being the capital of the country. Delhi has had a history of having an Assembly
replaced by a model of Union Territory governance by Executive Councilors. There were long years
of tussle to have a Legislative Assembly with commonality of objectives across the primary political
space, but whoever was in governance found it difficult to let go. The model that came into being,
thus, had somewhat of a hybrid character, giving an expanded role to the Central Government as
compared to any other Legislative Assembly. To that extent, there was a diminishing of the federal
structure but there appears to have been a consensus on this aspect.
155. The aforesaid arrangement worked well for many years even with different political
dispensations in power in the Centre and the State. But the last few years have seen an unfortunate
tussle on every aspect with the State Government seeking to exercise powers as any other Assembly
and the Central Government unwilling to let them do so. The bone of contention has not only been
the three subject matters of which the State was denuded of its powers, i.e., Entries 1, 2 & 18 from
List II; but it is almost a daily governance tussle.
156. The political dispensation which is in power in the State has to recognise the constitutional
scheme of division of powers in Delhi which circumscribes their ability to work only within those
powers. When they got elected, they knew what they were getting elected for – not what they
thought should be the division of powers. On the other hand, the Central Government is required to
work in tandem, albeit with a different political dispensation. Maturity is required from both sides
and we have to reluctantly note the absence of such maturity in this important inter- relationship.
157. To work well, the Central Government and the State Government have to walk hand in hand or
at least walk side by side for better governance. The failure to do so is really a breach of their
respective electoral mandate, the seven Lok Sabha seats are all held by the powers that be in the
Central Government but a very different result came in the Assembly Elections. This has seen a
repeat. It is a reflection of the maturity of the electorate which has chosen to put one dispensation in
power in the Centre while seeking to choose another in the State as the roles are divergent. The
concerns are different. The two powers unfortunately do not seek to recognise this aspect, and that
is the bane of this structure requiring collaboration and concurrence. Unfortunately, it has become
an endeavour to score points over the other. Some prior discussion and understanding could easily
solve this problem instead of wasting large amounts of judicial time repeatedly arising from the
failure of the two dispensations to have a broader outlook. In fact, the current round is, in our view,Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

arising from the petitioners seeking to take advantage of this divergence of view and their inability
to see a common path.
158. No governance model requiring such collaboration can work if either of the two sides take a ‘my
way or the high way’ approach –which both seem to have adopted. We have expressed our view on
the contours of the dispute and the facts have already been set out hereinabove. We see no purpose
in repeating those facts. We now turn to the four propositions which form the basis of the writ
petition (dealt with under three heads) to record our views qua them.
On the Issue of Privilege:
159. The privilege issue arises out of the plea advanced by the petitioners that both, the First
Impugned Summons dated 10.09.2020 and the Second Impugned Summons dated 18.09.2020,
were to summon Petitioner No.1 or a duly authorized representative of Petitioner No. 2 respectively
with a threat of “privilege”. This argument was coupled with a plea that such power of privilege
cannot extend to compel an individual, who is not a member of the House, into giving
evidence/opinion that they are not inclined to state.
160. We may note the elaborate arguments addressed by Mr. Salve, based on a premise that
privilege power is really a special right enjoyed as a shield in order to facilitate the working of the
Assembly. It is not a sword for assertion of power. It was argued that the constitutional schemes of
the UK and of India, a republic, are different and thus, the privilege powers in the latter must be
strictly confined to legislative functions. Only if the integrity of the legislative functions is impaired,
either by a member or by non-members, would the occasion arise for exercise of such power.
161. In fact, Mr. Salve sought to contend that it is time that exercise of privilege power is codified,
and to that extent an intent was expressed by the Constitution makers in sub-clause (3) of Article
194. The relevant portion states that such privileges “shall be such as may from time to time be
defined by the Legislature by law.”, and thus, the submission was that this clause operated for a
period “until (privilege powers were) so defined.” Mr. Salve sought to persuade us to either lay down
the guiding principles or at least nudge the Parliament/Legislature to do so. We have already
noticed that this is an aspect seriously disputed by all the counsel for the respondents.
162. We may notice in the aforesaid context that the wordings of Article 194(3) are unambiguous
and clear, and thus do not require us to give our own twist or interpretation to them. These are not
wordings of a statute, but that of the primary document – the Constitution. The powers, privileges
and immunities of a House of the State Legislature as well as its committees have been clearly
defined as those of the House and all members and committees thereof before the coming into force
of Section 26 of the Constitution 44th Amendment Act, 1978. There was no timeline provided for
codification of powers, privileges and immunities of a House. The Constitution has given leeway to
the Legislature to define the same from time to time, but there was no compulsion qua the same. If
the Legislature in its wisdom is of the opinion that it needs to be so done, they will do so. Is it for
this constitutional court to nudge them in that direction? Our answer would be in the negative.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

163. We say so as this is itself a debatable issue. There is a divergence of views even amongst
constitutional experts whether full play must be given to the powers, privileges, and immunities of
legislative bodies, as originally defined in the Constitution, or is it to be restricted. Such opinion
would have to be debated before the Parliament/Legislature of the State to come to a conclusion,
one way or the other. It is not even a subject matter where it could be said that any one opinion must
prevail, or a nudge must be given by this Court, or a recommendation must be made for
consideration by the legislative body. That Scotland and Wales have considered it appropriate to
have their own enactments in this context, is a deliberate legislative exercise by those bodies. There
is no uniformity across the world in this regard.
164. The notion of individual constitutional rights and the right to privacy is sought to be expanded
by the petitioners to encompass the right of refusal even to appear in pursuance of the summons.
The debates across democratic policy including some of the developments recorded by us, would
show that there is a turn towards recognising the importance of an element of compulsion (if so
required) for deposition/opinions relating to the present subject matter. This is more so in the
context of monolithic business models having vast financial and technical powers at their disposal.
As a constitutional court, we are not inclined to step into it.
165. It is not disputed that committee proceedings cannot be equated to proceedings before the
court of law.120 No doubt these powers have to work in the context of the business of each House,
and no House can be a knight in shining armour to correct issues in respect of which it has no
legislative power. Yet, it would be a monumental tragedy to conclude that the legislature is restricted
to the function of enacting laws. The role of the legislature is sought to be diminished by such an
argument. The legislature debates many aspects, and at times records a sense of the House. This is
not unusual or without precedent. The judgment in Amarinder Singh121 is of little assistance to the
petitioner as that was a case of an executive act of exemption of land, and in no way obstructed or
threatened the integrity of the legislative proceedings. The facts of each case are important and
propositions of law must apply in the context of the facts.
166. Once we recognize the wider array of functions performed by an elected Parliament or
Assembly, not confined to only enacting laws, any 120 Lord Denning’s observations as noted in State
of Karnataka v. Union of India on note 9.
121 Supra note 11.
act in furtherance of this wider role and any obstruction to the same will certainly give rise to an
issue of parliamentary privilege.122
167. There is little quibble with the proposition recognized in the Special Reference No.1/1964123
that there is a distinction between exercise of legislative privileges and ordinary legislative functions.
A similar line of reasoning has been expressed in Justice (Retd.) Markandey Katju v. Lok Sabha and
Anr., when the hackles of the Parliamentarians were raised on account of some utterances by Justice
(Retd.) Markandey Katju.124 We, however, fail to appreciate the line of argument that no
non-member could be summoned if they had not intruded on the functioning of the Assembly; orAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

that the non-participation of the petitioner would not have adverse consequences as it did not
disrupt the functioning of the Committee. The petitioners, more so with their expanded role as an
intermediary, can hardly contend that they have some exceptional privilege to abstain from
appearing before a committee duly constituted by the Assembly.
168. We really do not have any quibble with the propositions advanced by Mr. Salve that there can
be judicial scrutiny of an endeavour to 122 Supra note 24.
123 Supra note 12.
124 Supra note 13.
exercise the power of privilege, which inherently suffers from lack of jurisdiction, if illegal or
unconstitutional.125 The issue, however, is whether the situation has at all arisen meriting scrutiny
by this Court- which in turn has to be preceded by initiation of the privilege proceedings, an aspect
emphasised by learned counsel for the Assembly as well as the Committee.
169. In the factual matrix, only a summons has been issued for appearance before the Committee.
The question of any privilege power being exercised is yet far away. It has been rightly pointed out
by the learned counsels for the respondents, that even if there was any breach of privilege recorded
by the Committee, the Committee would in turn have to make a recommendation to the Assembly.
The Assembly then would be entitled to consider whether it is a fit case to exercise the power of
breach of privilege. In many cases, it may well be that the Assembly considers that it is not
worthwhile to do so, even if the Committee was to prima facie opine so. The exercise by the
Assembly is further dependent on the opinion of the Privileges Committee. Thus, there are various
tiers of scrutiny before there is culmination of the exercise of power of 125 Supra notes 12, 15 and
20.
privilege. None of those eventualities have at all arisen in the present case. This case is a preventive
endeavour by the petitioner to preclude the respondents from even considering the aspect of
privilege by seeking this Court’s intervention at a pre-threshold stage, only on the premise of the
absence of legislative power. We will, of course, consider the aspect of absence of legislative power
as the last aspect on the questions framed
- but we cannot accept the fetters Mr. Salve seeks to place on the Assembly and the Committee at the
threshold. We may notice the arguments of the respondents that recording of the consequences of
breach of privilege in a notice to appear is apparently something which is done in a routine manner
in such notices. This is possibly to make the noticee conscious of the consequences. That would not
mean that an action for privilege has been triggered off at the outset.
170. We would like to turn to the aspect of the importance of the working of committees; as, if there
is no power to compel attendance, we have little doubt that the working of these committees would
be badly impaired.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

171. The committees constituted by legislative bodies like the Assemblies for the States and
Parliament for the Union, perform a key role in the functioning and the working of the Houses. In
fact, it is often said that the real work is done in these committees - away from the din of the
Parliament. These committees witness more vociferous reflection of the divergent view, slightly
away from public gaze. It is said that there is a more reasonable and applied discussion in these
committees. This is an aspect recognized all over the world qua the functioning of such committees.
These committees are bodies which have the capability to undertake wide-scale consultative
processes, engage in dialogue, and build consensus through intelligent deliberations. In fact, such an
exercise is intrinsic to the legislative process where public policies would require detailed studies
and concentration. These committees undertake deliberations and provide recommendations as
precursors to legislative activities, and the effective working of committees is a prelude to the core
working of the Assemblies.
172. The committees are an extension of the legislature itself and do informed work. Their
significance has been exhaustively dealt with in Kalpana Mehta126 which we have extracted
hereinabove. US Representative James Shannon’s words were noted with approval in the 126 Supra
note 20.
judgment, recognising that “around the world there is a trend to move toward reliance on
committees to conduct the work of parliament, and the greatest reason for this trend is a concern for
efficiency.”127 It is not possible for us to accept the contention of the petitioners to create an
artificial division between Assembly’s core/essential and non-essential functions, with any
restrictive clauses being placed on the deliberations of the committees. Such water-tight
compartmentalisation is not advisable. Unless the committee embarks on a course completely
devoid of its functional mandate specified by the Assembly, or the Assembly itself lacks jurisdiction
to deal with the subject matter, we are of the view that the widest amplitude must be given to the
functioning of these committees. It is the parliamentary committee system that has been recognised
as a creative way of parliaments to perform their basic functions. The same principle would apply,
even if it is to some extent beyond their legislative domain. This is because they will not be able to
make any valid legislative recommendations in the absence of competence over the subject matter.
However, they may debate aspects 127 Comment of US Representative James Shannon during the
1995 Conference on the Role of Committees in Malawi’s Legislature as noted in Kalpana Mehta at
note 20.
which may be a reflection of their sense and consequently the sense of the House, if so adopted by
the House.
173. Walter Bagehot in his seminal work “The English Constitution” 128 elucidated five significant
functions of the House - elective, expressive, teaching, informing and finally, the legislative. The
legislative function itself is a broad umbrella under which multiple responsibilities and tasks are
carried out in synchronization. The legislature is a “democratic nucleus”, whereby such title entails
the law-making process itself as being multi-functional; involving receipt of informed opinions and
balancing interests of various stakeholders.129 Committees actually are in the nature of specialised
forums as Mallory states:Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

“The flow of public business is now so great, and its nature so complicated, that it can
only be handled by bodies with the technical competence and the rational
organization to master it. As Dr. Bernard Crick has pointed out:
The novels of C. P. Snow, Professor Parkinson’s Law and K. C. Wheare’s Government
by Committee are all, in different ways, testimonies to the truth that the most
important work of central government is conducted not by civil servants or M.P.’s
working as individuals, but by committees (Bernard Crick, Reform of the Commons.
Fabian Tract No.319 (London, 1959), p.13).” 128 Bagehot: The English Constitution,
(P. Smith, 2001).. 129 J.R. Mallory, The Uses of Legislative Committees, 6 Canadian
Public Administration 1, 6 (1963).
174. The inquisitorial role of the committee in the functioning of House is of great significance, and
as recognized, the investigation of a complicated social problem prior to legislation often rests
frequently on such legislative committees.130 This task involves the examination of witnesses and is
helpful in dealing with matters of special and technical nature, wisened by insight into affairs of the
workings of different aspects and the views expressed by different stakeholders. It can hardly be said
that in the context of what has been debated, the petitioners have no role to play or are “outsiders”.
Intelligent legislative action and deliberation thereon rests on the power to investigate into
questions of public importance and, thus, issuance of summons is key to this investigative exercise -
a role clearly recognised in Kalpana Mehta131.
175. We have no hesitation in stating that the endeavour of the petitioners to sidestep their
appearance before the Committee on a perceived notion of not being an official representative - is
not acceptable to us – whether the exercise is for a legislative enactment, or for other 130 Promila
Suri, Growth of Committee System in Central Legislature of India 1920-1947, (1979).
131 Supra note 20.
purposes connected with its legislative domain. After all, “To be a valid legislative inquiry there need
be no predictable end result.”132
176. The Committee is yet to start its work qua the assistance to be rendered by the petitioners. The
petitioners cannot themselves frame and presume possible questions that they might face before the
Committee, and then seek to encompass it under the argument of legislative incompetence. The
work of The Committee could encompass several fields where organisations and individuals are
expected to cooperate.
177. We are also not impressed by the argument that the privilege powers of the Assembly are not
constitutional in character but flow only from the GNCTD Act. The scheme of privilege has to be
seen in the context of provisions of Article 239AA of the Constitution, as well as the GNCTD Act.
They are not divorced from each other. Dr. Singhvi, thus, rightly referred to clauses 7(a) and 7(b) of
Article 239AA to contend that the GNCTD Act was not deemed to be an amendment to the
Constitution for the purposes of Article 368, notwithstanding that it may contain any provisionAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

which amends or has the effect of amending the Constitution. Rights and privileges are the same as
any other House and, thus, the 132 Supra note 79.
calling into question of the proceedings of a sub-committee amounts to calling into question the
proceedings of the Assembly. At the cost of repetition, we say that there has been no exercise of
privilege power. However, we have been called upon to deliberate, if one may say, to some extent
unnecessarily over this issue on account of insistence of the petitioners to advance this argument
prematurely. We do not know whether on participation of the petitioners any question of privilege
would arise, whether the Committee would make a reference to the Assembly, whether the Assembly
would consider it to be referred to the Privileges Committee, what would be the opinion of the
Privileges Committee and finally whether the Assembly itself would embark on a path of a breach of
privilege by the petitioners. This is a completely speculative exercise.
178. The Assembly is no different from any other State assembly, except to the extent that certain
powers in List II of the Seventh Schedule have not been conferred (i.e., Entries 1, 2 & 18). As a
principle of law, we are required to read all entries widely. Neither the included Entries nor the
excluded Entries have to be read restrictively. That is the principle we will have to keep in mind.
179. Dr. Singhvi rightly pointed out that there is no judicial precedent shown before us where
judicial review has been successfully exercised at such a threshold stage. Thus, judicial precedents
would have to be read in their factual matrix. The stage for any possible judicial intervention has not
arisen in the present case. In fact, such a threshold intervention was sought and repelled by the Full
Bench of the Madras High Court in C. Subramaniam133.
180. We have little doubt that a “Peace and Harmony” Committee may have a much wider
amplitude than what is excluded in Entries 1, 2 & 18 of List II. As to the issue of the extent of
legislative power, we will deal with it in the third part of our conclusion.
181. We have already noted with some disquiet the divergence of views taken by Dr. Dhavan and Dr.
Singhvi on the issue of the earlier notice being withdrawn, and a subsequent notice being sent. Dr.
Dhavan expressed that this was really of not much significance. We are of the view that the
Committee is a creation of the Assembly. The notice was withdrawn by the respondents themselves.
In the wisdom of the Committee, they sent a fresh notice- that the same was possibly not under 133
Supra note 30.
the advice of Dr. Dhavan or may have been on the advice of Dr. Singhvi is of little relevance to us.
Such conflict of submissions was best avoided and unnecessarily gave rise to another set of
arguments on behalf of the petitioners to read some intent into the same. Dr. Dhavan was, however,
right in seeking to repel the challenge as based on anticipatory nature of proceedings – being
presumptive and preemptive.
182. The aspect of Dr. Dhavan’s submission that the Committee’s threat to recommend criminal
action was “toothless” and the Committee Chairman’s statements during the press conference in this
regard are both best dealt with under the third aspect. Suffice to say at this stage that, in our view,Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

greater care would be required while framing the Terms of Reference so as to not include something
which would be termed by the counsel as “otiose” before this constitutional court. The utterances of
the Chairman of the Committee, which would give rise to petitioner’s apprehensions are best
avoided. We are noticing these aspects because these two factors can be the only reasons for the
petitioners to have approached this Court at this stage. In our view, there would have been nothing
to argue but for these two aspects – the first effectively withdrawn during the course of argument,
and the second sought to be explained away as views of the people who deposed before the
Committee. We find it very difficult to accept both these aspects, and we can safely say that these
gave the petitioners an ostensible cause for approaching this Court. This is an issue we cannot
ignore - but for these aspects, we would have possibly burdened the petitioners with exemplary costs
to have approached the court at this stage. A number of past illustrations have been rightly given by
Dr. Dhavan to illustrate notices issued to non-members which we have already recorded in para 58
and there is no need to repeat them.
183. We may record, at the end, that there is actually no serious dispute about the per se competence
of the Committee to discuss matters outside the legislative domain of the Assembly but it was with a
caveat that it could not give rise to exercise of power of breach of privilege and the right to summon
a non-member. That being the position, we have already noticed that any plea raised on the exercise
of privilege is a pre- emptive strike in the absence of underlying facts. Where that situation arises in
the given factual context, the petitioners could have and would be entitled to assail the same, but
this Court will not indulge in an advance ruling on this aspect. We have already clarified that we are
not inclined to accept the distinction between a member and non-member in the aforesaid context;
and the power of the Assembly to summon in the format it sought to do is beyond exception and in
accordance with law. So much for the aspect of privilege.
On Privileges & Fundamental Rights
184. Mr. Salve sought to pit the expanded right of free speech and privacy against privilege,
emphasising that the petitioner had a right to remain silent. In the context of the plea of the petition
being premature (which we have found against the petitioners as aforesaid), his submission was that
the mere threat of “necessary action” i.e., the possibility of a breach of privilege, was enough to
infringe both the right to free speech and privacy. Thus, “the threatened invasion of the right” could
be “removed by restraining the potential violator”.134
185. The more restricted plea advanced by Mr. Salve was that even if the right of privilege is
recognised, it must be narrowly construed so as to give maximum play to the fundamental rights to
privacy and free speech, which includes the right to remain silent. We may note that in view of the
original notice being withdrawn, Facebook’s plea of not having the 134 Supra note 38.
option of choosing whom to send stands whittled away. The interesting part is that Petitioner No.1
did appear before the Parliament.
186. We find it rather difficult to countenance the plea that the judgment of this Court in MSM
Sharma135 stands whittled down by subsequent judicial pronouncements or that powers, privilegesAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

and immunities under Articles 105(3) and 194(3) of the Constitution must give way to the more
fundamental right of free speech under Article 19(1)(a) of the Constitution in view of the reference
pending before the larger Bench in N. Ravi136.
187. We have discussed at some length the aspect of privilege and the rights which flow from it.
Though such proceedings are not taking place in Court, where depositions also take place, privileges
of an elected body of the Legislative Assembly and consequently of its committees must be given full
play.
188. We would also not like to delve on this issue in more depth as we are conscious of the fact that
the perceived conflict between MSM 135 Supra note 14.
136 Supra note 46.
Sharma137 and Special Reference No.1 of 1964138 is pending consideration before a larger Bench in
N. Ravi139. Suffice for us to add that this reference has been pending since 2005. It may be stated
that this reference needs to be given some priority to settle the legal principles involved, especially
in the context of the expanding conflict on such subject matters.
189. Be that as it may, we also agree with what Dr. Singhvi contended
-that this is another aspect which is premature. No coercive action has been taken against the
petitioner, and none was intended if the authorised representative of the petitioners simply
participated in the proceedings as a witness. Emphasis was also laid on the transparency of these
proceedings in view of them being broadcasted live. The summons having been lawfully issued by an
empowered committee (subject, of course to the legislative competence discussed hereinafter), the
same must be answered. The proceedings are not criminal or judicial in nature as there is no
accused before the Committee. Naturally, the Rules framed by the House under Section 33 of the
GNCTD Act (which in turn draws 137 Supra note 14.
138 Supra note 12.
139 Supra note 46.
strength from Article 239AA(7) of the Constitution) would be followed. Protection of proceedings
before the Assembly or the Committee under Article 194 would include deposition of members or
non-members.
190. We may add here that the option to not answer a question before the Committee cannot
seriously be disputed qua certain aspects if so pleaded for good reasons, an aspect which would be
examined by the Committee as per Rules.
191. We would not like to say anything more on this subject in view of the reference pending in N.
Ravi,140 and the fact that the complete plea of the petitioners is premature as nothing has reallyAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

happened other than them having been asked to appear before the Committee. On Legislative
Competence:
192. Is the Assembly embarking on a path which is blocked for them? This is the core question of
legislative competence of the Assembly in the context of its powers and privileges not being akin to
other State Assemblies. The endeavour of Mr. Salve was to persuade us that once the Assembly lacks
competence, the petitioners have a right to stay away, as 140 Supra note 46.
all proceedings before the Committee would be devoid of any constitutional mandate.
193. It is undisputed that the Assembly is different from the other State Assemblies to the extent
that certain subject matters of List II have been specifically excluded and conferred on the Central
Government. It is, thus, nobody’s case that aspects covered by Entries 1, 2 & 18 in List II can be dealt
with by the Assembly and consequently, the Committee. In fact, the submission of Mr. Salve can be
summarised as advancing a plea that the Assembly and the Committee cannot be permitted to do
indirectly what they cannot do directly.
194. While there is no dispute about the principle of reading the Entries as widely as possible, that
proposition is in the context of challenging a law for lack of legislative competence. Here we are
concerned with the interplay of Entries. The issue would be whether the Central Government has
the legislative competence or the Assembly. The widest amplitude has to be given even to the three
Entries of which the legislative competence has been denuded from the Assembly and conferred on
the Parliament.
195. It is in the aforesaid context that it was emphasised that apart from the aforesaid three Entries,
what is also to be appreciated is that the business of Facebook is directly covered under a
Parliamentary enactment, i.e., the I.T. Act. In this respect, petitioners have willingly cooperated with
proceedings before the Parliamentary Committee in the past.
196. That Facebook is an intermediary was submitted to be apparent from Section 2(1)(w) of the I.T.
Act. The role of the intermediaries is covered by this enactment including the right of the Central
Government to issue directions to block public access to any information under Section 69A of the
I.T. Act and this is no more res integra in view of the judgment in Shreya Singhal141 where a
procedure for the same has been laid down.
197. The intent of the Committee (and for that matter the Assembly) was argued by Mr. Salve to be
quite clear, i.e., to encroach on the very domain which was prohibited. This was stated to be
apparent from the Terms of Reference. The Terms of Reference contained in paragraph 4 (i) (to
consider the complaints from the members of the public, social 141 Supra note 66.
organisations, journalists, etc. on the situation prevailing in a particular area/areas which have the
potential to disturb communal peace and harmony or where communal riots have occurred) have to
be read in context of para 4(vii) which tasks the Committee with recommending action against such
persons against whom incriminating evidence is found. The respondents could not get away byAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

simply saying that the power of recommending action against such persons against whom
incriminating evidence is found is not capable of being enforced in view of the lack of legislative
competence. These are the aspects which were sought to be given teeth by threatening privilege in
the last paragraph of the Terms of Reference.
198. Mr. Salve also sought to rely on the reply of the respondents to justify that these were not mere
apprehensions. We have set out these aspects as reflected in para 90.
199. It could not be seriously disputed before us that collaborative federalism was an integral part of
the working of the Indian Constitution as emphasised by the Court. However, it was simultaneously
accepted that such functioning had to be within respective spheres of legislative competence. Were
the Assembly to encroach upon matters covered by List I (and similarly, if the Central Government
were to encroach upon the powers of the Assembly in List II), it would lead to a chaotic situation
and a breakdown of the division of powers inter se the Centre and the State.
200. We are, however, not impressed with the argument of Mr. Salve that the petitioners cannot be
drawn into what is perceived to be a political divide. Facebook is a platform where such political
differences are reflected. They cannot wash their hands off the issue as this is their very business. As
noticed earlier, their role is not as innocuous as they are seeking to contend.
201. Similarly, we cannot accept the plea that an Assembly must confine itself to the core function of
legislation. This would be unreasonably restricting the role of an elected body.
202. Mr. Salve’s emphasis was that all that transpired was a subterfuge as the real intent of the
Committee was to look into issues that were beyond their scope, while expanding their powers on
account of a political conflict between the Central and State Governments over the issue of the riots
in question. This was stated to be quite apparent from the nature of depositions recorded before the
Committee and the statements made in the press conference by the Chairman of the Committee.
203. As already stated, we have little doubt over the proposition that the division of powers between
the Centre and the State Assemblies must be mutually respected. The concept of a wide reading of
Entries cannot be allowed to encroach upon a subject matter where there is a specific entry
conferring power on the other body. It is this very principle which was in the minds of the
Constitution makers, considering the wide diversity and the federal nature of the country. Thus,
whether it is the argument of Mr. Salve or Mr. Datar in this context, we find them unexceptionable.
The illustrations given by Mr. Datar for exercise of such powers and their judicial scrutiny in the US
also support the proposition, i.e., that an inquiry could not be an end in itself and has to be related
to a legitimate task of the Congress (legislative body). 142 There could not be exercise of power
which may “defeat or materially impair” the exercise of its fellow 142 Supra note 76.
branches’ constitutional functions, nor “intrude upon a core zone” of another branch’s
authority”.143Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

204. We are also of the view that the recourse to Entries 1 & 2 of List III cannot be said to include
what has been excluded from the powers of List II, i.e., Entries 1, 2 & 18. Similarly, Entry 45 of List
III relating to inquiries would again not permit the Assembly or the Committee to inquire into the
aspects of public order or police functions. That a law and order situation arose is not disputed by
anyone, and that this law and order issue related to communal riots also cannot be seriously
disputed. That the Assembly cannot deal with the issue of law and order and police is also quite
clear. Thus, the moot points would be (a) what is the scope of inquiry of the Committee; (b) whether
it could be said that there is any aspect of the inquiry which falls within the legislative domain of the
Assembly; and (c) whether the attendance of the petitioners could be compelled legitimately.
205. We may say that both Dr. Singhvi and Dr. Dhavan were quite conscious of the limitations
which inherently exist on the powers of the Assembly. It is in that context that their argument was
premised on a 143 Supra note 81.
broader understanding of the expression “peace and harmony”, as opposed to it being restricted to
law and order. However, the difficulty that they face relates to the part of the Terms of Reference
that was clearly outside the purview of the powers vested with the Assembly. This problem was
compounded by what transpired in the press conference held by the Chairman of the Committee.
Speaking on behalf of the members of the Committee, the Chairman made certain statements that
assume greater significance by virtue of being in the public domain.
206. We also do not disagree with the in-principle submission of Dr. Dhavan, drawing strength from
judicial precedents in the US, that the power to investigate is inherent in the power to make laws by
the legislative body.144 But while recognising this, the issue in the present case is whether the
Assembly can at all legislate on the matter. The investigative function of committees carries with it
the possibility of researchers ending up in some “blind alleys”.145 This would have to presuppose
that there is an alley. Thus, while we respect the right of the Committee to the extent that there
exists an obligation on the petitioners to respond to the summons, we cannot permit the
proceedings to go on in 144 Supra notes 76, 78, 79.
145 Supra note 79.
a manner that encroaches upon the prohibited entries. We hasten to add that we are not seeking to
control how the Committee proceeds. In fact, the Committee is yet to proceed. But certain
provisions of the Terms of Reference coupled with the press conference is what has persuaded us to
say something more than simply leaving it to the wisdom of the Committee to proceed in the
manner they deem fit.
207. Once again, we do appreciate the contention of Dr. Dhavan that the police cannot be the sole
custodian of peace and harmony and that the expression itself has various connotations. Despite the
State Government being denuded of certain powers, it has to be noted that governance has many
manifestations, and functions of the Government can be realised in different ways. This is especially
true in the present case where the situation was admittedly created through an intrinsically law and
order issue.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

208. The moot point is whether the expression “peace and harmony” can be read in as expanded a
manner as Dr. Dhavan seeks to do by relying a on a number of Entries in List II and List III. We
have no doubt that peace and harmony, whether in the National Capital or in a State context, is of
great importance. But it would be too much to permit the argument that peace and harmony would
impact practically everything and thus, gives power under different entries across the three lists.
We, do, however, recognise that the inquisitorial and recommendatory powers can be utilised under
the principle of better governance.
209. In the aforesaid conspectus, while keeping in mind Article 212 which restrains courts from
inquiring into the proceedings of a legislature, we must also note that a narrow scope of judicial
review has always been appreciated and understood. We are confronted with a situation where the
two legislative bodies are not on the same page as to what transpired and there is in a sense, a tug of
war on the issue as to who would look into what happened and what ought not to have happened. It
is in this context that the learned Solicitor General emphasised the doctrine of pith and substance to
locate the power within the entries which have been taken out of List II and thus, seeks to block the
inquiry by the Committee on aspects which are already covered under the three excluded entries or
under the I.T. Act.
210. The divergent contentions lead us to conclude that the Committee can trace its legitimacy to
several Entries in List II and List III without encroaching upon the excluded fields of public order or
police toundertake a concerted effort albeit not to the extent as canvassed by Dr. Dhavan. Facebook
cannot excuse themselves from appearing pursuant to the New Summons issued to them on
03.02.2021. Areas which are not otherwise available to the legislature for its legislative exercise may,
however, be legitimately available to a committee for its deliberations. This is so in the context of a
broad area of governmental functions. Ultimately, it is the State Government and the State
Assembly which has to deal with the ground reality even in the dual power structure in Delhi. If we
may say so, it is only the factum of Delhi being the capital and the sensitivities arising therefrom in
respect of public order or police which has possibly persuaded these powers to be retained by the
Central Government. We cannot say that informed deliberation inter alia on the best measures
through which online mass hate and violence in their geographical jurisdiction can be addressed
would not be within the Committee’s area of competence as it would undermine the very purpose of
a vital democratic polity.
211. The unfortunate communal riots between 24th and 29th February, 2020 in various parts of
Delhi, led to the death of 53 persons, caused significant damage to public and private property,
disruptions to schools, transport, water supply, medical and other civic amenities.146 The
complexity of communal tensions and their wide-ranging ramifications is a matter affecting citizens
of Delhi and it cannot be said that the Government of NCT of Delhi cannot look into the causal
factors in order to formulate appropriate remedial measures. Appropriate recommendations made
by the State Government in this regard could be of significance in the collaborative effort between
the Centre and the State to deal with governance issues. It is in that context that this Court had
recognised that certain local interests are best addressed by the elected representatives of the
concerned State:Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

“130. Sawer’s “federal principles” reiterate this concept of federal balance when he
states:
“Power of the centre is limited, in theory at least, to those matters which concern the
nation as a whole. The regions are intended to be as free as possible to pursue their
own local interest.”147 146 Delhi Minorities Commission, Government of NCT of
Delhi, Report of the DMC Fact-Finding Committee on North-East Delhi Riots of
February, 2020, :accessible at:
https://archive.org/details/dmc-delhi-riot-fact-report-2020. 147 Supra note 27.
212. We are of the view that because of the pervasive impact of the riots, the Committee could
legitimately attend to such grievances encompassing varied elements of public life. Thus, it would be
entitled to receive information and deliberate on the same to examine their bearing on peace and
harmony without transgressing into any fields reserved for the Union Government in the Seventh
Schedule.
213. Let us now turn to the Terms of Reference. In the larger context of what the Committee is
supposed to do, reliance was placed on paragraph 4(i), i.e., to consider the factors and situations
which have the potential to disturb communal harmony in the National Capital Territory of Delhi
and suggest measures to eliminate such factors and deal with such situations with the object of
establishing harmony among different religious or linguistic communities or social groups. This is
not purely a law and order or policing aspect and has several connotations. It was not necessary at
that stage for the Terms of Reference to spell out as to what aspects it would legislate upon (having
legislative competence) and on what aspects it would like to consider making recommendations.
That would have been a pre-hearing of the issue.
214. If we turn to para 4(i) of the Terms of Reference, the object was to consider petitions,
complaints or reports from the members of the public, social organisationsand journalists on the
matter in issue where communal riots have occurred. Once again this was intrinsically linked to the
larger issue. However, the real troublesome aspect is para 4(vii), which we reproduce, once again, to
appreciate the context:
“(vii) to recommend action against such persons against whom incriminating
evidence is found or prima facie case is made out for incitement to violence”
215. Clearly it is not within the remit of the Assembly to recommend action against such persons
against whom incriminating evidence is found or prima facie case is made out for incitement of
violence. This is an aspect purely governed by policing. It is the function of the police to locate the
wrong doer by investigation and charge them before a competent court and this is what has really
given a handle to the petitioners to approach this Court.
216. We have noticed the submissions of Dr. Singhvi and Dr. Dhavan, which really amount to saying
that this paragraph is insignificant as no action can be taken. If that be so, then in that sense, this
paragraph does not stand even though the petitioners may not have directly assailed it. In order toAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

justify the legislative competence and the remit of the Committee, the respondents have practically
given up this para 4(vii) and we record the same and make it clear that this cannot be part of the
remit of the Committee.
217. We may say that wiser advice prevailed in issuing the New Summons dated 03.02.2021, which
consciously specified the diluted area of inquiry, conscious of the aforesaid limitation and if we may
say, rightly so. What it takes care of is that it is not addressed to Petitioner No.1 directly but instead
it calls for the views of an authorised representative of Petitioner No. 2, Facebook India. It has
rightly used the expression “requested” and also used the expression “could” in the context of
initiation of proceedings for breach of privilege and has categorically withdrawn the previous notices
and summons. On the lighter side, possibly Dr. Singhvi’s advice was adhered to.
218. The result of the aforesaid is that fallacies in the notices stand removed.
219. We have already noticed that the statements made by the Chairman of the Committee during
the press conference cannot be diluted or brushed aside in a manner as learned counsel for the
respondents seek to do. No doubt some part of the press conference refers to the complaints
received and statements made by persons deposing before the Committee. But, at the same time, it
was stated by the Chairman that the material placed before the Committee had resulted in a
“preliminary conclusion”. Thereafter it was stated that “prima facie it seems that Facebook has
colluded with vested interests during Delhi riots”. It does not rest at this and he further states:
“Facebook should be treated as a co-accused and investigated as a co-accused in
Delhi riots investigation.” and “As the issue of Delhi riots is still going in the court, a
supplementary chargesheet should be filled (sic) considering Facebook as a
co-accused.” The aforesaid statements and conclusions are completely outside the
remit of the Committee and should not have been made. That it may give rise to
apprehension in the minds of the petitioners can also not be doubted.
220. The further utterances also show that the findings have already given out of the proceedings
including 3-4 significant important aspects including posting by Facebook of incriminating material
on the platform in spite of continuous request to remove the same and that Facebook colluded with
such web news channels, which has a sole agenda to confuse content and disturb social harmony.
The Chairman also states that material has come before them which shows that wherever there is
content of harmonious nature, Facebook removes that content while disharmonious content is
promoted. A reference has also been made to the race clashes in the US.
221. Towards the end it is also sought to be conveyed that in view of the “incriminating material”,
the representatives of Facebook would be called upon to satisfy principles of natural justice before
conviction. The prima facie view expressed is that Facebook is a co-accused and hence investigations
regarding their role during the Delhi riots should be carried out and after such investigation, a
supplementary chargesheet should be filed.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

222. If it may be said, it is as if the Committee was convinced that Facebook must be prosecuted,
and as if the Committee itself was the prosecutor with a right to direct the filing of a supplementary
chargesheet. It was meeting as a formality to give a right of hearing before doing so, i.e. “before
taking any action.” What more is to be said!
223. We can only say that such statements are hardly conducive to fair proceedings before the
Committee and should have been desisted from. This is especially so as that was not even the
legislative mandate, and the Assembly or the Committee had no power to do any of these things.
224. In view of the aforesaid, thus, while giving the widest amplitude in respect of inquiry by a
legislative committee, we are constrained to put certain fetters in the given factual scenario
otherwise tomorrow the proceedings itself can be claimed to be vitiated.
225. The importance of Committees cannot be over emphasised. The Kalpana Mehta148 case
discusses this issue in some depth. Committees seek to perform the function of holding the
Government accountable to implement its policies, and its duties under legislation and the
performance of governmental agencies can be the subject matter of 148 Supra note 20.
reports formulated by these Committees. However, in the context of the present case, we are dealing
with a scenario where on a particular subject matter there is no legislative mandate to enact a
legislation even if, in a broader sense, an inquiry is made. Thus, the aspect of holding the State
Government accountable is not really envisaged as per the Terms of Reference. Rather, it seems as if
the Committee seeks to hold certain private players responsible for a law and order scenario, which
is within the domain of the Central Government. Therefore, the general principles applicable to
Committees would apply with a little difference in the given scenario.
226. We are conscious of the rationale emphasised that the wide jurisdictions of the High Court
under Article 226 or of this Court under Article 32 of the Constitution should not normally be
exercised in a manner oblivious to the enormous work carried out by the Parliamentary Committees
“in the field”. An Assembly, more so in the nature of Delhi Assembly with its own peculiarities (i.e.,
the exclusion of certain powers), even if given the widest amplitude and powers which a Committee
should have; cannot step on the toes or rather shoes of an entity having exclusive jurisdiction by
reason of List I.
227. We cannot lose sight of the repeated brushes which have occurred between the current
dispensation in the Central Government and the State Government and the Courts being called
upon to define the contours of their powers. Sagacious advice to act in concert appears to have fallen
on deaf ears. We are, faced with a scenario which is a little different from the normal and, thus,
much as we would not like to, some fetters have to be placed qua the exercise sought to be
undertaken by the Committee in question. One set of fetters is not required because it has already
been conceded that para 4(vii) of the Terms of Reference is otiose and that there will be no
endeavour to prosecute. However, another set of fetters become necessary because of the history
recorded aforesaid and the significance of the press conference given by the Chairman of the
Committee. The subject matter went much further than it ought to have and as a result, we haveAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

analysed the press conference in detail to repel the contention on behalf of the respondents that this
aspect should not be taken seriously or is more preemptory in nature. We are clearly of the view that
it is not so. The Committee cannot have a misconception that it is some kind of a prosecuting agency
which can embark on the path of holding people guilty and direct the filing of supplementary
chargesheet against them. We, thus, opine that this aspect has to be kept in mind by the Committee
so as to not vitiate future proceedings and give rise to another challenge. We are of the view that in
any eventuality, as speculative as it may be, if the Committee seeks to traverse the path relating to
the excluded Entries, i.e. law and order and police, any representative of Facebook who would
appear before the Committee would be well within their right to refuse to answer the query and such
an approach cannot be taken amiss with possibility of inviting privilege proceedings. It is a delicate
balance to follow and we do not seek to give an excuse to the representative of the petitioners to not
answer questions and frustrate the proceedings before the Committee qua the petitioners. However,
at the same time, we give this very limited protection were the Committee to embark on these
prohibited areas. We are quite confident that such an eventuality will not arise, given the important
role that the Committee is performing and that it will accept the sagacious advice. So much and not
further.
Conclusion:
228. We have penned down our views on the issues raised by the petitioners, but in view of the
elaborate arguments and length of the judgment, we consider it appropriate to summarise the
ratio/directions in the following terms:
I. There is no dispute about the right of the Assembly or the Committee to proceed on
grounds of breach of privilege per se.
II. The power to compel attendance by initiating privilege proceedings is an essential
power.
III. Members and non-Members (like the petitioners) can equally be directed to
appear before the Committee and depose on oath.
IV. In the given facts of the case, the issue of privileges is premature. Having said
that, the insertion of para 4(vii) of the Terms of Reference taken along with the press
conference of the Chairman of the Committee could legitimately give rise to
apprehensions in the mind of the petitioners on account of which a caveat has been
made.
V. Canvassing a clash between privilege powers and certain fundamental rights is
also preemptory in the present case.
VI. In any case, the larger issue of privileges vis-a-vis the right of free speech, silence,
and privacy in the context of Part III of the Constitution is still at large in view of the
reference to the larger Bench in N. Ravi.149 149 Supra note 46.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

VII. The Assembly admittedly does not have any power to legislate on aspects of law and order and
police in view of Entries 1 and 2 of List II in the Seventh Schedule inter alia being excluded. Further,
regulation of intermediaries is also subject matter covered by the I.T. Act.
VIII. The Assembly does not only perform the function of legislating; there are many other aspects
of governance which can form part of the essential functions of the Legislative Assembly and
consequently the Committee. In the larger context, the concept of peace and harmony goes much
beyond law and order and police, more so in view of on- the-ground governance being in the hands
of the Delhi Government. IX. Para 4(vii) of the Terms of Reference does not survive for any opinion
of the Committee. It will not be permissible for the Committee to encroach upon any aspects strictly
within the domain of Entries 1 and 2 of List II of the Seventh Schedule. As such, any representative
of the petitioners would have the right to not answer questions directly covered by these two fields.
229. That brings us to the end of this saga. The writ petition is accordingly dismissed, subject to
terms aforesaid.
...……………………………J. [Sanjay Kishan Kaul] ...……………………………J. [Dinesh Maheshwari]
...……………………………J. [Hrishikesh Roy] New Delhi.
July 08, 2021.
Postscript:
1. COVID times have been difficult for everyone. The Judiciary and the Bar are no
exception. It has been a contributing factor in there being a period of four months
between reserving the judgment and pronouncement of the order, but that is not the
only reason.
2. We have noticed the presumptive nature of grievances and the invitation to the
court to opine on the same with undoubtedly a handle being provided by the
respondents. The saga of the hearing lasted 26 hours – which is a lot of judicial time.
Daily time period was recorded. Apart from pleadings, there were written synopses,
additional written synopses, rejoinders and replies filed liberally by both parties. The
convenience compilations themselves were very voluminous, in contradiction to their
very purpose. Our concern is if this is how the proceedings will go on in the future, it
will be very difficult to deal with the post COVID period, which is likely to see a surge
in the number of cases pending adjudication.
3. What is the way forward? We do believe that there needs to be clarity in the
thought process on what is to be addressed before the Court.
Counsels must be clear on the contours of their submissions from the very inception of the
arguments. This should be submitted as a brief synopsis by both sides and then strictly adhered to.
Much as the legal fraternity would not want, restriction of time period for oral submissions is anAjit Mohan vs Legislative Assembly, National ... on 8 July, 2021

aspect which must be brought into force. We really doubt whether any judicial forum anywhere in
the world would allow such time periods to be taken for oral submissions and these be further
supplemented by written synopsis thereafter. Instead of restricting oral arguments it has become a
competing arena of who gets to argue for the longest time.
4. We have looked into this aspect to see if there are any international best practices and would like
to refer to some of them without a very expansive discussion.
5. Article 6 of the European Convention on Human Rights, while recognising the right of fair trial
and public hearing, qualifies it inter alia to be completed “within a reasonable time”. 150 This is
intrinsically linked to administering justice without delays. Delay in judicial proceedings has been
the bane of our country and there cannot be a refusal to part ways from old practices especially
when they have outlived their purpose. It is the litigants who bear the costs of our complex and
prolonged adjudicatory process. We are conscious of the equal responsibility of this side of the
bench – it is the need of the hour to write clear and short judgments which the litigant can
understand. The Wren & Martin principles of precis writing must be adopted. But then how is this to
be achieved if the submissions itself go on for hours on end with vast amounts of material being
placed before the Court; with the expectation that each aspect would be dealt with in detail failing
which review applications will be filed (not that they are not 150 Article 6, European Convention on
Human Rights, 1953. filed otherwise!) We are weighed down by judicial precedent. Often a reference
is made to the judgment of the Privy Council or the earlier years of the Supreme Court, which saw
short and crisp judgments but then, the volume of precedents we face today was not present then. In
a technological age like ours, all that is required is to instruct the junior counsel to take out all
judgments on a particular point of view and submit it to the court in a nice spiral binding. On every
aspect there may be multiple judgments. In our view if the proposition of law is not doubted by the
Court, it does not need a precedent unless asked for. If a question is raised about a legal proposition,
the judgment must be relatable to that proposition – and not multiple judgments. The other
scenario is if the facts of the cited judgments are so apposite to the facts of the case that it could act
as a guiding principle. In R. v. Erskine; R. v. Williams 151 a well-known aphorism of Viscount
Falkland in 1641 was noticed “if it is not necessary to refer to a previous decision of the court, it is
necessary not to refer to it. Similarly, if it is not necessary to include a previous decision in the
bundle of authorities, it is necessary to exclude it. That approach will be rigidly enforced.” This
forms the basis of the criminal practice directions in the UK which apply to all criminal matters
before the Court of Appeals, Crown 151 [2009] EWCA Crim 1425, [2010] 1 WLR 183.
Court, and the Magistrate’s Court. Criminal practice directions (vii) clarifies that if a judgment does
not refer to a cited case, it is not that the court has not referred to it but rather, that the court was
not assisted by it. We adopt the same as we can say no better.
6. The contribution to the development of law can be nurtured by comprehensible precedent. There
may be times when the complexity of matters gives rise to complex opinions. But we find that
judgments are becoming more complex and verbose only on account of large number of precedents
cited and the necessity to deal with them and not merely refer to them as is done in other countries.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

7. We have for long discussed case management but seldom is it followed in its true letter and spirit.
This may possibly be because of the large volumes of cases but then this is all the more reason for
better management.
8. The US Supreme Court is more restrictive in its time frame – not that UK Courts are far behind.
The norms and the traditions take care of the requirement of restrictive time frames to address
submissions; which are preceded by the contours of arguments given in the written synopsis and the
material sought to be relied upon. We do not doubt that lawyers think on their feet but then given
the current milieu, there has to be clarity before the lawyers get on their feet keeping a little leeway
in mind for something which may evolve during the arguments.
9. The Supreme Court of India as on 01.05.2021 had 67,898 pending matters.152 The time spent on
routine matters leaves little time to settle legal principles pending before larger Benches that may
have an impact down the line on the judicial system. We have a straight example of this with a
reference to a larger Bench pending in N. Ravi153.
10. Another matter of concern is prolonged interim proceedings. In criminal matters, even bail
matters are being argued for hours together and at multiple levels. The position is no different in
civil proceedings where considerable time is spent at interim stage when the objective should be
only to safeguard the rights of the parties by a short order, and spend the time on the substantive
proceedings instead which could bring an end to the lis rather than on the interim arrangement. In
fact, interim orders in civil proceedings are of no precedential value. This is the reason it is said that
we have become courts of interim proceedings where final proceedings conclude after ages- only for
another round to start in civil proceedings of execution.
152Statistics, Monthly Pending Cases, Types of matters pending in Supreme Court of India as on
01.05.2021 , Supreme Court India, accessible at:
https://main.sci.gov.in/statistics.
153 Supra note 46.
11. The purpose of our post script is only to start a discussion among the legal fraternity by bringing
to notice the importance of succinctly framed written synopsis in advance, and the same being
adhered to in course of oral arguments to be addressed over a limited time period and more crisp,
clear and precise judgments so that the common man can understand what is the law being laid
down. After all, it is for ‘the common man’ that the judicial system exists.
...……………………………J. [Sanjay Kishan Kaul] ...……………………………J. [Dinesh Maheshwari]
...……………………………J. [Hrishikesh Roy] New Delhi.
July 08, 2021.Ajit Mohan vs Legislative Assembly, National ... on 8 July, 2021

