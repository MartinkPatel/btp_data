American Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006
Equivalent citations: (2006)IIILLJ540DEL
Author: Anil Kumar
Bench: Anil Kumar
JUDGMENT
Anil Kumar, J.
Page 2110
1. This order shall dispose of Plaintiff's application under Order 39 Rules 1 and 2 of the Code of Civil
Procedure and the defendant's application under Order 39 Rule 4 of Code of Civil Procedure to
vacate the interim order dated 15th October, 2005 whereby by the defendant was restrained from
using the information and data regarding the wealth of the customers of the plaintiff bank and
customers' wealth management operations and wealth View program/operations of the plaintiff's
bank.
2. Brief facts to comprehend the controversies between the parties are that the plaintiff filed the suit
for permanent and mandatory injunction against the defendant seeking inter-alia a restrain against
the defendant from using or disclosing any information and trade secrets relating to the business
and operations of the plaintiff and to solicit or induce any of the customers of the plaintiff especially
those who are part of the wealth management operation and/or wealth View programme and from
breaching the confidentiality term as per letter of appointment/code of conduct including customers
privacy principles/policies. The plaintiff also sought mandatory injunction against the defendant to
deliver up all the confidential information, data and trade secrets in particular the customer list of
wealth management operations and/or the wealth View programme/operations of the plaintiff
available with the defendant or under her control.
3. The plaintiff contended that it is a banking company under the laws of State of Connecticut, USA
doing banking business in India and having its branch office at Hamilton House, Connaught Place,
New Delhi. The plaintiff was an employee of defendant as head of wealth management, Northern
Region. The defendant was employed in the management cadre on the terms and conditions
stipulated in the letter dated 12.3.2001. The relevant terms for the purpose of present applications
are as under:
9. After confirmation, if you wish to resign from the Company's service, you will be
required to give one month's notice in writing to the Company or one month's salaryAmerican Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

in lieu thereof. Similarly, the company may terminate your employment by giving you
one month's notice or one month's salary in lieu thereof.
Page 2111
14. You will maintain the confidentiality of all the information that you will be exposed to and will
not divulge any information pertaining to the operations of the Company or any of its affiliates to
any one without the express written permission of your superior.
15. You will not, at any time, while in employment with Company, use other than in reference to the
business of the Company and in the course of your duties any such confidential information OR
after cessation of employment with the Company, use to disclose to anyone else such confidential
information and you will also undertake to indemnify the Company and its affiliates from any loss or
damage arising from any breach of this undertaking.
16. You will be bound by all rules, regulations, policies and other orders issued/amended by the
Company from time to time in relation to working hours, conduct, discipline, leave, medical,
retirement and any other matter as though these rules, regulations, policies and orders were a part
of this contract of this employment.
4. The plaintiff contended that it has various interests in finance and banking service industry in
India including credit cards and wealth management etc and various business activities of wealth
management are named and styled wealth View. The products under the wealth View are demand
products, term deposits and mutual funds.
5. On employment, the defendant initially joined in the credit cards division at a position with
American Express Travel Related services where she continued till 2003 and thereafter she was
moved to Wealth Management division.
6. The plaintiff asserted that it has a code of conduct along with certain company policies which are
applicable to all the employees. The defendant had attended various training sessions on the code of
conduct and she was fully aware of its contents. The relevant part of the code of conduct is as under:
Conflicts of interest and Business opportunities You must be alert to any situation
that could compromise the position of trust you hold as an American Express
employee, and avoid any kind of conflict between your personal interests and those of
American Express. You may engage in outside activities that do not conflict with the
Company's interests, interfere with the responsibilities of its employees, or damage
or misuse its reputation, trademarks, relationships, confidential information or other
property. The Company has adopted guidelines to protect both the Company and
each employee against damaging conflicts of interest, and from situations that create
a perception of impropriety.American Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

You should never use your position with the Company, or information acquired
during your employment, in a manner that may create a conflict-or the appearance of
a conflict-between your personal interests and the interests of the Company or its
customers and clients. You also should be aware that actual or potential conflicts of
interest may arise not just from dealings with external parties, such as customers or
suppliers, but also from relationships or transactions with leaders, direct reports or
other employees (e.g. such as receiving loans that are not on generally available terms
and conditions). If a conflict or potential conflict Page 2112 arises, you must report it
immediately. You may report it to your leader or your business unit's Compliance
Officer, who will review the matter with the Corporate Secretary. You also may report
a conflict or potential conflict directly to the Corporate Secretary. Any such
discussion will be held in confidence to the extent possible and in a spirit of
cooperation. If you prefer, you can speak informally and confidentially with the Office
of the Ombudsperson.
The rules applicable to the most common conflict-of-interest situations follow. If you
are uncertain about the propriety of your conduct or business relationships, or if you
have doubts about a possible conflict, you should candidly discuss the matter with
any of the individuals referred to above. Each situation will be looked at on a
case-by-case basis.
Customer Privacy and Information Security You are responsible for protecting the
privacy, confidentiality and security of customer information entrusted to the
Company.
In each of our businesses, we are entrusted with important information about our
customers-information vital to our ability to provide quality products and services. At
American Express, we have long recognized our responsibility to protect the
customer information entrusted to us.
The American Express Customer Privacy Principles set forth the Company's
commitment to protect the privacy, confidentiality and security of customer
information. These principles require you to ensure that any customer information
collected is necessary, accurate and kept confidential. The American Express Internet
Privacy Statement sets forth how the Company provide on the Company's Web site.
The Customer Privacy Principles and the Customer Internet Privacy Statement
describe how customers can remove their names from lists used for mail, telephone
and online marketing.
Leaders are expected to familiarize themselves and their employees at all levels with
our Customer Privacy Principles, to ensure that the Principles are applied in every
aspect of our business, and to encourage the companies with which we do business to
adopt similar principles. In an open network environment, depending on your job
responsibilities you must also follow the American Express Network ConfidentialityAmerican Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

Operating Principles. In addition, many markets have their own legal requirements
governing the use of customer information. You should contact your local
Compliance Officer or the General Counsel's Office if you are unsure of local
requirements.
Intellectual Property You must protect and, when appropriate, enforce the
Company's intellectual property rights.
The company's intellectual property is among its most valuable assets. Intellectual
property refers to creations of the human mind that are protected by various national
laws and international treaties, in a fashion similar to real property (i.e., land).
Intellectual property includes copyrights, patents, trademarks, trade secrets, design
rights, logos, know-how and other intangible industrial or commercial property.
Confidential information and Trade Secrets Page 2113 You must protect confidential
information and trade secrets, and prevent such information from being improperly
disclosed to others inside or outside the Company.
During the course of your employment, you may learn confidential information about
the Company that is not known to the general public or to competitors. Information
of this sort is considered a trade secret if it provides the Company with a competitive
or economic advantage over its competitors. Confidential information or trade
secrets may not be disclosed outside the Company or used for your own or someone
else's benefit.
These obligations apply both during, and subsequent to, your employment with
American Express. When you leave the Company, you must return any and all copies
of materials containing the Company's confidential information or trade secrets in
your possession.
Some examples of American Express' confidential information or trade secrets
include:
Customer lists;
the terms, discount rates or fees offered to particular customers;
marketing or strategic plans; and software, risk models, tools and other system
developments.
Within the Company, confidential information and trade secrets may be divulged
only to other employees who need the information to carry out their duties. When
discussing confidential information or trade secrets, you must not do so in places
where you can be overheard, such as taxis, elevators, the Company cafeteria orAmerican Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

restaurants. In addition, you should not communicate or transmit confidential
information or trade secrets by non-secure methods (e.g. cell phones, non-secure
email, hotel faxes, etc.).
Trademarks, Copyrights and Patents You must protect the Company's trademarks,
copyrights and patents.
Publications, documentation, training materials, computer codes, and other works of
authorship you develop for the Company are the types of material that can be
protected by copyrights. You may also create, discover or develop software, methods,
systems or other patentable inventions when performing your responsibilities or
utilizing information or resources available to you in connection with your
employment. To the extent permitted by law, as an employee or a contractor, you
agree that all such works of authorship and inventions, whether or not patentable or
protect able by copyright, trade secret or trademark, are assigned to the Company
whether they be improvements, derivatives, designs, technologies, written materials,
programs or any other works.
Our logos and the name 'American Express' are examples of Company trademarks
recognized around the world. You must use Company trademarks properly and
consistently, and must protect the Company's goodwill and brand investments from
being used by others for their own advantage. You also must advise senior
management or the General Counsel's Office if you become aware that others are
improperly using the Company's trademarks.
Page 2114 Certain jurisdictions have their own laws that may supersede elements of
this policy. In those cases, the laws of that jurisdiction prevail. If you think an
invention may be eligible for a patent or are unsure about a proposed use of Company
trademarks, copyrights or patents, you should consult the General Counsel's Office.
7. The services of the defendant were terminated on 10.10.2005 on the ground that during the
course of employment she disclosed confidential information to persons which was not in
connection with the business of the company; compromised the position of trust held by her as an
employee of plaintiff and failed to avoid any conflict of interest between her personal interest and
that of the plaintiff; used confidential information and trade secrets for her own benefit; violated the
American Express customer privacy policy; failed to return customer list and details and used the
same for personal benefit or for a competitor and violated the intellectual property rights of the
plaintiff.
8. It was asserted by the plaintiff that defendant was promoted on 4.4.2005 to the position of head,
Northern India wealth management and as a head she had the co-responsibility of selling wealth
management products in India. The defendant had a team of 13 financial concierges and 3 regional
managers. As a head of wealth management, Northern region the defendant was in a unique
position having access to highly confidential information and trade secrets of the plaintiff such asAmerican Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

customer data and information. The plaintiff contended that it took all reasonable steps to ensure
the protection of confidential information with individual password and authorization to only such
persons who could access the said confidential data.
9. The defendant is stated to have submitted a letter dated 19.9.2005 to Mr. Kaustubh Majumdar,
Director and head, Wealth Management conveying her wishes to resign from the employment of the
plaintiff as per the terms of appointment and gave a 30 days notice.
10. The plaintiff alleged that a significant development occurred on 24.9.2005 when plaintiff
obtained the information of the threat to confidential data and information caused due to the certain
acts of the defendant. This information was received by the plaintiff through Mr. Kaustubh
Majumdar, Director of Head of Wealth Management. It was alleged that Ms. Shikha Sharma had
handed over a file to the Director and head of Wealth Management which had about 40-50 pages
containing detailed information of large number of customers and the data also had an exhaustive
list of all the investment accounts mentioned with the plaintiff branch and customer information of
more than 800 persons. The said data was alleged to have been compiled by Ms. Shikha Sharma
under the instruction of the defendant and one copy of that file is with the defendant. The said data
accounts of other managers also and had an exhaustive list of all investments accounts maintained
with the plaintiff branch.
11. The plaintiff admitted that defendant did not have a password called IWB/MFID which could be
used to access confidential information, however, defendant forced Mr. Vasant Pathuri and Mr.
Saurabh Verma to get the access to the confidential information utilizing her position and gave the
password Page 2115 to Ms. Shikha Sharma to compile the data of the wealth Management
programme. It was alleged that the defendant had taken the information under the guise that AUM
balance had fallen and that the presentation had to be made to the departments head.
12. According to the plaintiff, Ms. Shikha Sharma used the ID of Mr. Vasant Pathuri and compiled
the data of customer list and gave it to the defendant. This was alleged to have been done when all
the regional managers of the plaintiff were outside India for a conference. Ms. Shikha Sharma is
alleged to have realized the gravity of the situation only when she went to meet a customer on
14.9.2005 and it transpired that the defendant is leaving the job and joining a competitor and a
request was made to the customer to shift his account from the plaintiff to the competitor. The
plaintiff contended that the file handed over to the plaintiff and interview with Ms. Shikha Sharma
indicated that the defendant had with her confidential information and data regarding the customer
of the plaintiff. Plaintiff stated that a further interview of Ms. Shikha Sharma was held on 27th
September 2005 where Mr. Majumdar and Mr. Amitabh Sen Gupta, dealer North of the plaintiff
were present. Ms. Shikha Sharma put the entire thing in writing but did not sign the writing and
requested one more day to do the same. Upon further inquiries, it was contended, that the
defendant had been approaching the customers of the plaintiff in order to shift their accounts to
another bank which the defendant desired to join.
13. Defendant is alleged to had made desperate attempts to get herself released from the
employment on 26th, 27th and 28th September,2005. It was stated that on 1st October,2005 theAmerican Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

plaintiff was surprised to receive a letter a letter from the counsel from the defendant intimating
that the defendant had submitted a resignation on 19th September, 2005. An interim reply to said
letter was sent by the plaintiff on 3rd October, 2005. In reply to defendant's letter plaintiff
contended that the defendant had been refusing to co-operate with the bank and had not replied to
the questions of the bank nor had returned the property to the bank. A conference was set up with
the defendant on 4th October, 2005. The defendant responded to the letter of the plaintiff through
her solicitor and stated that apart from laptop, car, corporate card, the identity card in and mobile
phone, she does not have any other material of the bank in her possession. In the meeting on 4th
October, 2005 defendant denied having possession of any confidential material of the plaintiff.
14. Plaintiff alleged that Mr. Vasanth had informed that the defendant did direct him to handover
the password of the system which was written down by him on a piece of paper and handed over to
the defendant. It was also as stated that Mr. Saurabh had further stated that he heard defendant
telling Mr. Vasanth to share the password with Ms. Shikha Sharma. It was also alleged that Mr.
Amitabh Bhargav informed plaintiff that a client Mr. Krishnan Bhargav had intimated that the
defendant had contacted him and sought his help in getting business for the new organization.
According to plaintiff these facts clearly indicates that defendant had not returned the confidential
information and data which had been collected by her while in employment with the plaintiff. The
plaintiff contended that he seeks to recover the confidential information and data which is with the
defendant Page 2116 which she is liable to return in terms of contract of employment and also as per
its rights in law.
15. The employment of the plaintiff was, therefore, terminated through a letter of termination dated
10th October, 2005. On termination of the employment of the plaintiff one month salary was
credited in her account in accordance with the terms of employment. In the letter of termination,
the plaintiff has reiterated that the defendant cannot violate the terms with regard to protection of
the confidential information and trade secrets of the plaintiff and again requested defendant to
return the confidential information and data and to refrain from soliciting any of its customers in
breach of her obligations. The plaintiff contended that he verily believes and has credible
information that the defendant has continued to breach the terms of confidentiality and has been
approaching and soliciting the customers of the plaintiff to persuade them to shift their accounts
with the another bank. It was averred that the customers have inform the plaintiff bank that the
defendant in the course of solicitation expressed of them, the desire of their terminating their
relationship with plaintiff bank and shifting with the defendant. Plaintiff relied on the letter dated
11th October, 2005 of Ms. Reena S. Sethi informing about a client who had intimated about the
defendant making him calls and asking him to shift his account from the plaintiff's bank to that of
another competitor. In these circumstances, the plaintiff filed the present suit for perpetual
injunction against defendant seeking restrain against her from using or disclosing any information,
confidential information and trade secrets relating to the business and operations of the plaintiff
and from endeavoring to solicit or induce away any of the customers of the plaintiff and from doing
any acts which would breach the confidentiality terms as in letter of appointment/code of conduct
including the Customers Privacy Principles/Policies of the plaintiff and for a mandatory injunction
directing the defendant to deliver up all confidential information, data, trade secret including
customer's list in particular the customer's list of Wealth Management Operations and/orAmerican Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

Wealthview program/operations of the plaintiff.
16. The defendant has contested the claim of the plaintiff for perpetual injunction on the ground that
the suit has been filed with the motive to prevent her from having employment with any competitor
of the plaintiff bank and with a view to harass the defendant, as the plaintiff fears that the defendant
joining the competitor bank will be a threat to the plaintiff business. The defendant asserted that she
never had any file containing trade secrets or confidential information. No such file as alleged by the
plaintiff was given either by Ms. Shikha Sharma or by anyone else and the allegation by the plaintiff
that the defendant has retained or misused the alleged confidential information is utterly false to the
plaintiff's knowledge. Defendant averred that the allegation that she had obtained forcibly or
otherwise the ID or password in the plaintiff's Wealth View Management Programme from anyone
has been made only after she resigned from the plaintiff bank. Such an allegation has been made
against her only with a view to coerce her to remain in her job and not to join any competitor bank.
17. The defendant categorically asserted that plaintiff's officials even called up Society General to
whom the defendant wanted to join with a view to ruin her Page 2117 career despite the fact that her
statement was duly recorded on 4.10.2005 which fact has not been disclosed by the plaintiff in the
plaint with malafide intention and with a view to suppress the material information.
18. The defendant had joined the plaintiff bank in March, 2001 in the Card sales division and owing
to her exceptional performance and integrity she was appointed Relationship manager for the bank
in February, 2003 to solicit high net income clients. The defendant asserted that she gave a record
breaking sales in July, 2003 and contributed 60% of the total balance sheet for Northern India
region for the plaintiff bank and she sourced and developed strong relationship from the high net
income segment which brought substantial business to the plaintiff bank. During the year 2004
alone the defendant gave record breaking sales amounting to Rs. 90 crores for the plaintiff which
was over 160% year by year for which she was awarded, The Chairman's Ambassador Award, Star
Performer, Will to Win and Highest Performer award within a short span of two years and due to
this the defendant was promoted to Head, wealth management Northern region in April, 2005
which was an out of turn promotion as the defendant had superseded other persons with 6 years
and 9 years in banking industry. The plaintiff had rated her performance as G1/G2 which is the
highest rating in the scale of G1- G5. She contended that even during the last quarter rating she was
rated as G1 in July, 2005 and at the time of her departure from the plaintiff bank the total volume in
retail book of the bank pertaining to the defendant was to the tune of Rs. 219 crores.
19. The assertion of the defendant is that even on integrity she was given L1 which is the highest
rating in all appraisals and no questions were ever asked about her integrity during the defendant's
employment of four and a half years. In the circumstances the defendant contended that all these
allegations have been made against her as an after thought after she had filed her resignation as the
plaintiff bank had started fearing losing its clients base due to the departure of the defendant from
the plaintiff bank.
20. Regarding the trade secrets and confidential information it was contended that it is in public
domain and it is not such a trade secret or confidential information as has been sought to be madeAmerican Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

by the plaintiff. It was categorically asserted that the names of customers, their phone numbers and
addresses are well known and can easily be ascertained by anybody and everybody and such
information cannot be characterized as trade secrets or confidential information. In any case it was
contended that defendant has built relationship with all her clients and the bank does not have any
proprietary rights on these relationships and the clients are not bound by any arrangement of
exclusivity with the plaintiff bank. In the circumstances it was averred that the relief claimed against
the defendant is nothing but an attempt to injunct the clients shifting their accounts from the
plaintiff and to restrain the defendants from dealing with the clients. Regarding the confidential
information, plaintiff averred that it is general knowledge and experience which the defendant
gained while in service of plaintiff bank and which would have been gained by any other person or
persons who worked or who are working in place of defendant and she cannot be directed not to use
her work experience. The plaintiff does not have, according to the Page 2118 defendant any patent or
propriety rights over the alleged trade secrets or confidential information. Denying the negative
covenant being a part of the agreement it was contended that even such a covenant/term in the
contract of her appointment is restraint of trade specially after her resignation and is prohibitive
under Section 27 of the Contract Act and such restraint or restriction violates and seriously impinge
upon the defendant's fundamental right to carry on her lawful profession and cannot be enforced.
21. On an application of the plaintiff seeking restrain against the defendant from using or disclosing
any information, confidential information and trade secrets relating to business and operation of the
plaintiff's acquired/come across directly or indirectly by her during and in the course of her
employment with the plaintiff, an interim order dated 15.10.2005 was passed whereby the
'defendant was restrained from using the information and data regarding the wealth of the
customers of the plaintiff bank and customers wealth management operations and Wealth View
operation of the plaintiff bank.'
22. The defendant has filed IA No. 8893/2005 under Order 39 Rule 4 of Code of Civil Procedure for
vacating the ex-parte interim order dated 15.102005 and for dismissal of plaintiff's application
under Order 39 Rule 1 and 2 read with Section 151 of the Code of Civil Procedure on the ground that
the plaintiff has knowingly made false statements on oath with a view to mislead the Court. The
defendant has reiterated the grounds taken by her in the written statement contending inter-alia
that all the allegations regarding misuse of the alleged confidential information or retaining the
same have been made only after she resigned from the plaintiff bank with a view to coerce her into
remaining in her job and the intention of the plaintiff to adopt coercive means in an effort to retain
its customer base and prevent competition is bearing fruits as on account of interim order the
defendant is unable to obtain employment anywhere else till date, which is causing grave hardship
and injury to the defendant and interfering with her fundamental right to earn her livelihood. The
defendant very categorically asserted that she did not have any file containing any confidential
information of the plaintiff and in the circumstances question of any injunction restraining use of an
information contained in such file cannot and does not arise. According to the defendant the Wealth
View Programme contains list of customers, their addresses, phone numbers and the defendant
cannot be injuncted from dealing with these customers with their addresses and phone numbers in
the garb of the alleged confidential and trade secrets of the plaintiff bank.American Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

23. I have heard the learned Counsels for the parties at length for days and a number of precedents
have been cited and relied by the parties.
24. Whether the defendant obtained any file containing trade secrets or confidential information
from Ms. Shikha Bhardwaj or from anyone else or the allegations have been made only with a view
to coerce her into remaining in her job and/or on account of fear of the plaintiff bank of losing its
those clients which were brought by defendant, due to her departure' Admittedly the defendant did
not have access to the password to access alleged information called IWB/MFID. What is alleged is
that the defendant forced Mr. Vasanth Pathuri and Mr. Saurabh Verma to provide password to
alleged confidential information and thereafter asked Ms. Shikha Sharma to get the Page 2119
confidential information from the computer to prepare the file and handover the same to the
defendant. The plaintiff has alleged that on 14th September,2005 Ms. Shikha Sharma was told by
the defendant that she would be leaving the job and joining a competitor yet she download the
information from the computer and hands over the file containing 40 to 50 pages to the defendant
on 24th September, 2005. If the defendant had already told Shikha Sharma that she would be
leaving and joining a competitor, why would she ask her again later on to compile the alleged
confidential data for her and why will Shikha Sharma do it without complaining about it. No
complaint by Ms. Shikha Sharma has been filed on the ploy that she declined to sign her statement.
The defendant was working as head North India wealth management group and on getting the
password, could have download the information on her own without involving Shikha Sharma. It is
not the case of the plaintiff that the defendant is computer illiterate. The plaintiff has not produced
anything to show that Shikha Sharma prepared a file containing alleged confidential information of
40 to 50 pages and handed over to defendant. The defendant had been examined extensively by the
plaintiff's officers on 4th October, 2005. In the entire examination she was not suggested that she
forced two officials Mr. Vasanth Pathuri and Mr. Saurabh Verma to provide access to confidential
information. There is nothing to show that force could be used by the defendant to extract the
password from these two officials. Defendant is alleged to have told Ms. Shikha Sharma that
confidential information is required because the AUM balance had fallen and that presentation had
to be made to departments heads. Affidavits of Ms. Reena S. Sethi and Mr. Vasanath Pathuri have
been filed regarding meeting with Mr. Purshottam Bagaria who is alleged to have told them that
defendant had told him that she is joining Societe Generale and asked him to shift his account to the
said competitor. Surprisingly the affidavit is silent about forcing Mr. Vasanath Pathuri about
disclosing the password to the defendant. How the defendant using her position forced these two
officials' The person who was forced to disclose the password, files an affidavit and does not say so.
The plaintiff does not say what force was used by the defendant and could be used by her to extract
the password. The person against whom the force was used does not say while filing an affidavit as
to what force was used against him or how he was pressurized, which forced him to divulge the
password. Had the force been used by her, these officials would have made a complaint. This is not
the case of the plaintiff that these officials were misled in giving her the password. Ms. Reena Singh
and Mr. Vasanth had deposed about Mr. Bagaria disclosing them that defendant had asked him to
change his accounts. This assertion of the two officials of the plaintiff would be hearsay and can not
be relied. The plaintiff should have obtained a letter or an affidavit of Mr. Bagaria before making
such an allegation. Why the plaintiff did not obtain the letter or affidavit from Mr. Bagaria becomes
evident from the letter which is given by Mr. Bagaria categorically denying it, when the defendantAmerican Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

brought this allegation to his notice by sending a communication. In his reply dated 5th
November,2005, he has stated categorically that this allegation is incorrect. He stated in his letter:
I further wish to state that the following statement made by Ms. Reena Sethi Sharma
and Mr. Vasant Pathuri in their letter addressed to head Page 2120 of H.R. American
Express bank. ' The client further mentioned that she had been soliciting him by
asking him to move his accounts which are currently maintained with AEB to Societi
Generale' is incorrect
25. Some of the clients of the plaintiff have asserted categorically that it is their decision to bank
with anyone and they have not signed any exclusivity and it is their prerogative to bank with anyone.
Some of them were rather categorical that they are with plaintiff bank because of the defendant.
26. The defendant was a relationship manager who built the relations and she doesn't need the
names and addresses as was also told by her to C.V.Prabhu, Vineet Dhamija and Priti Narain on 4th
October, 2005. The plaintiff never had any issue with defendant about her integrity and gave her the
highest ratings till she resigned. In her examination on 4th October, 2005 the defendant stated that
she did not ask Vasanth to apply for a IWB/MFID nor ask him to share the IDs and passwords.
From the questions asked from the defendant it appears that IWB/MFID are available after
applying. If that be so when the said official applied for it and when it was given, there is complete
silence on it by the plaintiff. In her examination on 4th October, 2005 by the officials of the plaintiff,
the emphasis was also on her personal purchases made by her on the corporate card. There is not a
single question put to her that she misrepresented Shikha Sharma about AUM balances and
obtained a copy of confidential data and information of the bank. The plaintiff bank after having
such a detailed examination of the defendant on not founding any thing against her or any of her
admission which could be used by the bank, conveniently omitted to mention about it and file it
before the Court along with the suit and the application for interim injunction on which the plaintiff
was able to obtain an interim injunction. This is concealment of material fact by the plaintiff before
getting an equitable relief from the Court.
25. The defendant was examined by the plaintiff in detail on 4th October,2005. The officials of the
bank ask her so many details almost about everything but do not ask her as to why she had taken the
alleged confidential data in the garb of checking AUM balances. Are the customers' names and
addresses required for checking and correcting the AUM balances' Why would Shikha Sharma take
alleged confidential information running into 40 to 50 pages and give to defendant knowing that the
defendant is leaving the plaintiff bank'
26. The defendant was one of the relationship manager and was allowed to meet the clients. She had
been meeting clients even after 24th September, 2005 when she is alleged to have taken away the
alleged confidential information and data. The alleged confidential data and information is the
customers names, phone numbers and their financial details. The plaintiff has not produced any
such customer's list or Wealth view programme even for perusal by the Court.American Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

If the defendant knows the customers, can she be restrained from approaching them and if they are
willing to disclose their financial details to her, can she be restrained from taking it because such
details have already been given by the customers to the Plaintiff bank already. Will this constitute
confidential information and is this such an information which was allegedly obtained by the
defendant by misrepresenting and forcing other officials of the plaintiff bank.' Page 2121
27. The learned Counsels for the plaintiff argued in detail about the confidentiality of the bank's data
which are the names and addresses and perhaps the financial portfolios of some of them who
willingly disclose about it to the defendant. The plea on behalf of the plaintiff bank is that the bank
owes a duty of secrecy to its customer which arises out of the confidential nature of Bank- Customer
relationship and is not limited to contractual and equitable obligations and is well established in
Bank's fiduciary duty towards its customers.
28. Reliance was placed on para 46 of the District Registrar and Collector, Hyderabad and Anr. v.
Canara Bank where the Supreme Court has observed that the bank has an element of confidentiality
towards its customers and stated as under:
It cannot be denied that there is an element of confidentiality between a bank and its
customers in relation to the latter's banking transactions.
The leading English case on the bank's duty of confidentiality to customers Tournier
v. The National Provincial and Union Bank of England (1924) 1 K.B.461 : 1923 All ER
550 was also relied on where Atkin L.J. Defined the banker's duty of confidentiality
as follows:
It (the obligation of secrecy) clearly goes beyond the state of the account, that is
whether there is debit or a credit balance, the amount of the balance. It must extend
at least to all the transactions that go through the account, and to the securities, if
any, given in respect of the account.... I further think that the obligations extends to
information obtained from other sources than the customer's actual account, if the
occasion upon which the information was obtained arose out of the banking relations
of the Bank and its customers-for example, with a view to assisting the Bank in
conducting the customer's business, or when coming to decisions as to its treatment
or its customers.... In this case, however, I should not extend the obligation to
information as to the customer obtained after he had ceased to be a customer. (Page
No. 560-561).
Reliance was also placed on Halsbury's Laws of England, Fourth Edition, Reissue,
2003 to contend that a bank's duty of secrecy towards customers would be rendered
completely meaningless if bank employees are not subject to the same duties and
therefore, a banker (including bank employees) owes an obligation of confidence to
customers. Para 454 of Halsbury's Laws of England reads as follows:American Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

The duty covers information derived not only from the customer's accounts but also
from other sources, as far as they are related to banking, as when advice is given to a
customer on business matter, decisions are taken by the bank as to the treatment of
customers; the duty may continue after the relationship ends.
Relying on Shankarlal Agarwalla v. State Bank of India and Anr. it was contended
that the Banker is under an obligation to secrecy and accordingly, Indian Law
recognizes that the Bank-customer privilege extends Page 2122 in its application to
Bankers i.e. employees of the Bank. Referring to Christofi v. Barclays Bank plc.
(1998) 2 All ER 484 it was contended that the duty extends beyond information
which is secret. In Christofi (supra) it was held with respect to the duty of secrecy
that:
... the duty extends beyond information which is secret. It is clear from the judgment
in Tournier's case that the duty extends to information gained during the currency of
the account and that it goes beyond the state of the account, and extends to
information derived from the account itself.
29. The defendant was the relationship manager got appreciation and awards on account of her
exceptional performance and integrity. The defendant had given record-breaking sales in Delhi and
contributed 60 per cent of the total balance sheet for Northern India region for the plaintiff bank.
Her knowledge of the customers and even their financial portfolios cannot be denied in the facts and
circumstances. During the year 2004 defendant gave sales amounting to 90 crores for the plaintiff.
This is not the case of the plaintiff that the defendant was not concerned with any of the customers
and their portfolios and have stolen the details of the customers and their financial portfolios. If the
defendant gave the business and sales amounting to rupees 90 crores in 2004 and also performed
similarly in earlier years, it cannot be inferred that she did not have the information which is touted
as confidential and sacrosanct. If the defendant had this information, why would she force other
employees to get the password and then give that password to yet another employee to download
the data from the computer and take the file from her running into 40 to 50 pages. If the defendant
had built a substantial customer's base, can she be restrained from approaching those customers
again in the facts and circumstances' If it is presumed that the defendant had taken data of the
customers and their financial portfolios, this itself will not give any advantage to the defendant,
because merely having this data will not convince the customers and make them shift their business
from the plaintiff bank to some other bank. All these factors points to an inevitable probable
inference that the defendant did not obtain any information from the plaintiff bank as has been
alleged. Prima facie, therefore, the defendant did not obtain any such data as has been alleged by the
plaintiff, from Shikha Sharma or from any other person in any other manner in the facts and
circumstances of the present case nor breached any alleged confidentiality of the plaintiff's bank.
30. Regarding alleged confidentiality about the customers' names and addresses and their financial
portfolios, it is being canvassed that since it is confidential, the plaintiff has an exclusive right to
deal with these customers. Reliance has been placed by the plaintiff on Lansing Linde Ltd v. Kerr
(1991) 1 All E.R.418 to contend as to what constitutes trade secrets and confidential information.American Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

Defining what constitutes trade secrets and confidential information Lord Staughton held as
follows:
a trade secret is information which, if disclosed to a competitor, would be liable to
cause real or significant harm to the owner of the secret. I would add first, that it
must be information used in a trade or business, and secondly that the owner must
limit the dissemination of it or at least not encourage or permit widespread
publication.
Page 2123 It (trade secrets) can thus include not only secret formulae for the
manufacture of products but also, in an appropriate case, the names of customers
and the goods which they buy.
In Roger Bullivant Ltd v. Ellis (1987) F.S.R.182 it was held:
... it is obvious that, if it is a breach of the duty of good faith for the employee to make
or copy a list of the employer's customers, the removal of a card index of the
customers is a fortiori case.
... The value of the card index to Mr. Ellis and the other defendants was that it
contained a ready and finite compilation of the names and addresses of those who
had brought or might bring business to the plaintiffs and who might bring business to
them. Most of the cards carried the name or names of particular individuals to be
contacted. While I recognize that it would have been possible for Mr. Ellis to contract
some, perhaps many, of the people concerned without using the card index, I am far
from convinced that he would have been able to contact anywhere near all of those
whom he did contact between February and April 1985. Having made deliberate and
unlawful use of the plaintiff's property, he cannot complain if he finds that the eye of
the law is unable to distinguish between those whom he could, had he chosen, have
contacted lawfully and those whom he could not. In my judgment it is of the highest
important that the principle of Robb v. Green which, let it be said, is one of no more
than fair and honourable dealing, should be steadfast maintained.
In Herbert Morris Ltd v. Saxelby (1916) AC 688 at 701 pursuing the theme of what
the employer can protect, and where this elusive dividing line lies, Lord Shaw in the
Herbert Morris case said:
Trade secrets, the names of customers, all such things which in sound philosophical
language in and the are denominated objective knowledge-these may not be given
away by a servant; they are his master's property, and there is no rule of public
interest which prevents a transfer of them against his master's will being restrained.
Addressing the issue of an employee copying the customer lists of his employee for
his own personal use, Lord Esher held that there was an implied duty of good faithAmerican Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

upon an employee in Robb v. Green (1985) 2 QB 315 it was stated that-
A master would not take a servant into his employment if the servant refused to agree
to act honestly, and a servant must know that his master, who is going to engage him,
relies on the faithful performance by him of the duties arising out of the confidential
relations between them.
In Louis V. Smellie (1985) 73 L.T.220 it was held that good faith exists between the
employer and those in his employment and use of information after termination of
employment makes it illegal. It was held:
Good faith that exists between an employer and those in his employment renders it
improper and illegal for employees to make use after the termination of the
employment of those matters which they learns whilst they were in that confidential
relationship.
Page 2124 According to the learned Counsel for the plaintiff the above position has
been recognized by the Delhi High Court in a judgment in Burlington Home
Shopping Pvt. Ltd v. Rajnish Chibber and Anr. 61(1996) DLT 6. In this judgment, the
Court cited with approval McComas, Davison and Gonski in The Protection of Trade
Secrets-A-General Guide (1981 Ed.) where it is acknowledged that although it is not
possible to provide an exhaustive list of information that may be regarded as
confidential, examples of what constitute confidential information includes inter alia,
customer lists and information concerning the proposed contents of a mail order
catalogue. Lord Denning in Seager v. Copydex Ltd (1967) 1 WLR 923 quoted with
approval the following paragraph, As I understand it, the essence of this branch of
the law, whatever the origin of it may be is that a person who has obtained
information in confidence is not allowed to use it as a spring-board for activities
detrimental to the person who made the confidential communication, and
spring-board it remains even when all the features have been published or can be
ascertained by actual inspection by any member of the public.
32. Referring to springboard of activities reliance was also placed by the plaintiff on
Lord Salmon in Seager v. Copydex Ltd where it was stated, 'The law does not allow
the use of such information even as a springboard for activities detrimental to the
plaintiff.'
33. In the Zee Telefilms case, at para 12, the Hon'ble Division Bench of the Bombay
High Court recognized as settled principles (at para 14) the following, With regard to
the requirement of form and degree of development of information or ideas, learned
Counsel for the plaintiffs placed strong reliance on Seager v. Copydex Ltd. (1967) 2
All ER 415. In this case the plaintiff, in the course of discussion with the defendants
of a carpet grip described as 'the germ of the ideas' for a different form of carpet grip
which the plaintiff had devised. Later the defendants developed and marketed theAmerican Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

carpet grip which was unwittingly based on the plaintiff's alternate type of grip. The
Court of Appeal concluded that the plaintiff's idea was 'the springboard' which
enabled the defendants to devise their own grip and held that the defendants were
liable for breach of confidence.
34. Apparently all these cases relied on by the plaintiff are clearly distinguishable. In
the garb of confidentiality, the plaintiff is trying to contend that once the customer of
plaintiff, always a customer of plaintiff. Can a competitor bank be restrained from
dealing with the customers of the bank on the ground that the bank maintains
written record of its customers and their financial portfolios which has been acquired
by the competitor bank and so the competitor bank should be restrained even to
contact those customers' In case the competitor bank without acquiring any
information as to with whom a particular person or company is banking approach
him and canvass about themselves, in my opinion, even after acquiring information
that a particular person of company is banking with a bank, can approach him and
canvass about themselves. It is for the customers to decide with which bank to bank
and a bank can not arrogate to himself the rights to deal with a customer exclusively
on the ground that he has created a data Page 2125 base of his customers and their
financial portfolios. In my opinion no Bank should be allowed to create monopolies
on the ground that they have developed exhaustive data of their clients/customers.
Mere knowledge of names and addresses and even the financial details of a customer
will not be material, as the consent of the customer and his volition as to with whom
to bank, is of prime importance. The option of the customers/clients to bank with any
one can not be curtailed on the plea of confidentiality of their details with any
particular bank. Creating a data base of the clients/customers and then claiming
confidentiality about it, will not permit such bank to create a monopoly about such
customers that even such customers can not be approached. Those cases will be
different where the processes and products which may be confidential are taken by
another organization or company. If the plaintiff bank does not have a right to insist
that no one should deal with his customers, on the ground of confidentiality of the
information regarding his customers, the bank cannot be allowed to achieve the same
indirectly. Another factor is that the customer who is not a party to the present suit
cannot be prevented indirectly to deal with any other bank. Plaintiff can not be
permitted to create and claim such monopolies, which in my view are not permissible
under any statute in this country.
35. The learned Counsels for the plaintiff Mr Chandhihok and Mr Kaul had laid great
emphasis on the principles laid down by the English Courts on common law and
equity some of which are detailed in earlier paras. According to plaintiff an
ex-employee cannot use information regarding the customers, their names and
phone numbers and their financial portfolios, as such information is confidential
even if it has been memorized by the employees in the course of his employment.
Reliance was placed on Printers and Finishers Ltd v. Holloway (1965) R.P.C.239 at
255 where it was held:American Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

... The mere fact that confidential information is not embodied in a document, but is
carried away by the employee in his head is not, by itself a reason against the granting
of an injunction to prevent its use or disclosure by him.
In Baker v. Gibbons (1972) 2 All E.R.759 at 765 it was held:
... In appropriate circumstances a person may be restrained from using confidential
information only memorized and not written down.
And in Westminster Chemical NZ Ltd v. McKinley (1973) 1 N.Z.L.R.659 at 666 it was
held ... May be sufficient to show that information used even from memory was such
that ex-employee could not have known of it but for his employment and that it was
of a confidential nature.
36. Such an information according to the learned Counsels for the plaintiff is also
confidential and can not be used or disclosed during the subsistence of
agreement/contract but even after termination of the employment. The plaintiff
relied on Clause 14 of the letter of appointment of the defendant and its code of
conduct. Reliance was placed on Herbert Morris Ltd V. Saxelby (1916) AC 688 at 701
where it had been held that:
... Trade secrets, the 'names of customers', all such things which in sound
philosophical language are denominated objective knowledge-may not Page 2126 be
given away by a servant; they are his master's property, and there is no rule of public
interest which prevents a transfer of them against his master's will being restrained.
And it was further held that, ... a man's aptitudes, his skill, his dexterity, his manual
or mental ability- all those things which in sound philosophical language are not
objective, but subjective-they may and they ought not to be relinquished by a servant;
they are not his master's property; they are his own property; they are himself.
According to the plaintiff prohibition in agreement in restrain of trade under Section
27 of the Contract Act, would not preclude enforceability of negative covenant. And
restraining the defendant from using such information in no way will affect her right
to seek employment nor will it drive her to idleness. Reliance was placed for
employees implied obligation on Faccenda Chicken Ltd v. Fowler (1986) 1 All ER 617,
Neill L.J where it was laid down that the position relating to an employee's implied
obligations after employment ends:
1) Where the parties are, or have been, linked by a Contract of Employment, the
obligations of the employee are to be determined by the contract between him and his
employer; Vokes Ltd. v. Heather (1945) 62 R.P.C.131 at 141.American Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

2) In the absence of any express term, the obligations of the employee in respect of
the use and disclosure of information are the subject of implied terms....
3) The implied term which imposes an obligation on the employee as to his conduct
after the determination of the employment is more restricted in its scope than that
which imposes a general duty of good faith. It is clear that the obligation not to use or
disclose information may cover secret processes of manufacture such as Chemical
formulae (Amber size and Chemical Co. v. Menzel (1913) 2 Ch.239), or designs or
special methods of construction (Reid and Sigrist Ltd v. Moss and Mechanism Ltd.
(1932) 49 R.P.C.461), and other information which is of a sufficiently high degree or
confidentiality as to amount to a trade secret.
The obligation does not extend, however, to cover all information which is given to or acquired by
the employee while in his employment, and in particular may not cover information which is only
'confidential' in the sense than an unauthorized disclosure of such information to a third party while
the employment subsisted would be a clear breach of the duty of good faith....
4) In order to determine whether any particular item of information falls within the implied term so
to prevent its use or disclosure by an employee after his employment has ceased, it is necessary to
consider all the circumstances of the case...the following matters are among those to which attention
must be paid:
a) The nature of the employment. Thus employment in a capacity where 'confidential'
material is habitually handled may impose a high obligation of confidentiality....
b) The nature of the information itself... information will only be protected if it can
properly be classed as a trade secret or as material Page 2127 which, while not
properly to be described as a trade secret, is in all the circumstances of such a highly
confidential nature as to require the same protection as a trade secret...
c) Whether the employer impressed on the employee the confidentiality of the
information....
d) Whether the relevant information can be easily isolated from other information
which the employee is free to use or disclose....
In the circumstances it was contended that defendant's contractual obligation to maintain
confidentiality of plaintiff customer data survives termination of employment and are not in restrain
of trade and are enforceable.
37. In India unless the statue is such that it cannot be understood without the aid of other laws,
maybe English or any other country, it may not be permissible to import the principles enunciated
in different environments and laws. The Contract Act,1872 is quite exhaustive even if it may not be a
complete code dealing with all the eventualities pertaining to contracts. For comprehending SectionAmerican Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

27 of the Contract Act,1872 what is to be seen is its language which will determine its scope
uninfluenced by the manner in which the analogous provision comes to be construed narrowly or
otherwise modified, in order to bring the construction within the scope and limitation of the rule
governing the English doctrine of restrained of the trade.
38. The Apex Court has dealt with this exhaustively in Superintendence Co of India v. Krishan
Murgai where it was held that under Section 27 of the contract Act, a service condition or obligation
cannot be extended after termination of the service. The observation of the Supreme Court relevant
for this purpose are as under:
52. Neither the test of reasonableness nor the principle that the restraint being partial
was reasonable are applicable to a case governed by Section 27 of the Contract Act,
unless it falls within Exception I. We, therefore, feel that no useful purpose will be
served in discussing the several English decisions cited at the Bar.
53. Under Section 27 of the Contract Act, a service covenant extended beyond the
termination of the service is void. Not a single Indian decision has been brought to
our notice where an injunction has been granted against an employee after the
termination of his employment.
The plaintiff has not relied on any Indian decision where an injunction has been granted against an
employee after termination of his employment on the ground that the employee has confidential
information and should not be allowed to carry on the trade or business which may involve utilizing
such an information. For the same reasons as held by the Apex Court in Krishan Murgai (supra) a
plethora of English and other decisions cited by the plaintiff be discussed in detail.
39. It is no more res-integra that in India while construing the provisions of Section 27 neither the
test of reasonableness not the principle that restrain to trade being partial or reasonable are
applicable unless the case falls within Page 2128 the exception of Section 27 of the Indian Contract
Act,1872. An inquiry into reasonableness of the restraint is not envisaged by Section 27 of the said
act. In contradistinction to the two questions as in England, the courts in India only have to consider
the question whether the contract is or is not in restraint of trade. In Petrofina (Great Britain) Ltd. v.
Martin Diplock (1996) 1 All E.R 126 the Court of Appeal had considered as to what is a contract in
restrain of trade and it was observed:
...A contract in restraint of trade is one in which a party (the covenantor) agrees with
any other party (the covenantee) to restrict his liberty in future to carry on trade with
other persons not parties to the contract in such manner as he chooses....
It was also held in the same case as under:
... every member of the community is entitled to carry on any trade or business he
chooses and in such manner as it thinks most desirable in his own interest, so long as
he does nothing unlawful; with the consequence that any contract which interferesAmerican Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

with the free exercise of his trade of business, by restricting him in the work he may
do for others, or the arrangements which he may make with others, is a contract in
restraint of trade. It is invalid unless it is reasonable as between the parties and not
injurious to the public interest.
40. A learned single Judge in Sandhya Organic Chemicals P Ltd v. United Phosphorous Ltd had held
that a service covenant extended beyond the termination of the service is void. In the instant case it
was held that an employee could not be restrained for all times to come to use his knowledge and
experience which he gained during the course of his employment either with the employer or with
any other employer. It was further held that the principles laid down by the English Courts on
common law and equity will not be applicable in view of Section 27 of the Indian Contract Act,1882
relying on Krishan Murgai (supra).
41. In Ambiance India P. Ltd. v. Naveen Jain , an agreement between the parties prohibiting an
employer for two years from taking employment with any present, past a prospective customer of
plaintiff was held to be void and contrary to Section 27 of the Indian Contract Act, 1872. It was held
that such a stipulation would prime facie be against public policy of India and arm-twisting tactic
adopted by employer against young man looking for a job. Relying on Section 41(e) of the specific
relief act, it was held that the plaintiff will not be entitled for injunction as an injunction which
cannot be specifically enforced and supervised by the Court should not be granted. According to
learned Single Judge in view of Section 14(c) and (d) of the Specific Relief Act, in case plaintiff felt
that the defendant was in breach of agreement, the plaintiff may sue the defendant for the damages
for breach of agreement in accordance with law and had dismissed the application for interim
injunction. The learned judge held that all contracts in restraint of trade are void which are contrary
to Section 27 of the Contract Act. An employee, particular, after the cessation of his relationship
with his employer Page 2129 is free to pursue his own business or seek employment with someone
else. However, during the subsistence of his employment, the employee may be compelled not to get
engaged in any other work or not to divulge the business/trade secrets of his employer to others
and, especially, the competitors. In such a case, a restraint order may be passed against an employee
because Section 27 of the Indian Contract Act does not get attracted to such situation. It is also to be
added that a trade secret is some protected and confidential information which the employee has
acquired in the course of his employment and which should not reach others in the interest of the
employer. However, routine day-to-day affairs of employer which are in the knowledge of many and
are commonly known to others cannot be called trade secrets. A trade secret can be a formulae,
technical know-how or a peculiar mode or method of business adopted by an employer which is
unknown to others.
42. Enforcement of post employment contract restrain restricting the freedom of an employee to
obtain different job opportunities was held to be unenforceable and void in Pepsi Foods Ltd. and
Ors. v. Bharat Coca Cola Holdings Pvt. Ltd. . In this case the plaintiff had not approached the Court
by disclosing the whole truth. The averments made by the plaintiff were not only discredited by the
defendant but their veracity and untruthfulness were also shown to be doubtful. In the
circumstances it was held that negative covenant in contract restraining employee from engaging or
undertaking employment for twelve months after leaving the services of plaintiff was held to beAmerican Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

contrary and in violation of Section 27 of the Indian Contract Act, 1872 and injunction was declined.
43. The case of Burlington (supra) relied on by the plaintiff is clearly distinguishable as that was the
case of violation of the copyright. In this case an employee of the Burlington which was a mail order
service company, whose nature of duties had nothing to do with the compilation and development of
database, on severing relationship with the company, had established himself as a competitor into
mail order shopping business.
44. The case of plaintiff is not of violation of copyright in its customers' names, addresses and their
financial portfolios and details. The `work' of the plaintiff in which rights have been claimed by the
plaintiff has not even be produced by the plaintiff. The defendant during the course of her
employment seems to had taken help of various directories of various organizations to approach a
number of persons and organizations for bringing business to the plaintiff. A copy of the directory of
members of PHDCCI was also produced, where the details of number of customers of the plaintiff's
bank have been marked by the defendant.
45. The plaintiff is claiming rights in respect of names, addresses and financial details of customers
which are already with the plaintiff. In order to claim right in the derivative work containing the
original material, the plaintiff is to show adaptation, abridgement, arrangement, dramatization or
translation in his work entitling him to have certain rights. In order to qualify for independent right
in derivative of collective work, the additional matter injected in a prior work on the matter of Page
2130 rearranging or otherwise transforming a prior work must constitute more than the minimal
contribution which can be ascertained only if the prior work and the work done by the plaintiff is
produced. In (DB), Eastern Book Company and Ors. v. D.B. Modak and Ors. it was held that the
copyright can be claimed in derivative work only in the following manner:
34. Copyright can be claimed only in derivative work. A derivative work consists of a
contribution of original material to a pre-existing work so as to recast, transform or
adapt the pre-existing work. This would include a new version of a work in the public
domain and abridgement adaptation, arrangement, dramatization or translation. A
collective work will qualify for copyright by reason of the original effort expended in
the process of compilation, even if no new matter is added. In determining whether a
work based upon a prior work is separately copyrightable as a derivative or collective
work, the Courts may not properly consider whether the new work is a qualitative
improvement over the prior work. However, in order to qualify for a separate
copyright as a derivative or collective work, the additional matter injected in a prior
work or the matter of rearranging or otherwise transforming a prior work, must
constitute more than a minimal contribution. Applying this test we will have to
examine as to which aspect of the reported judgment in SCC, the appellant can claim
copyright.
The plaintiff has not produced anything which would show that they have done something with the
material which is available in public domain so as to claim exclusive rights in that.American Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

46. The details of customers are not trade secrets nor they are the property was held in 140
Wash.381, 249 P.782, City Ice and Cold Storage Co. v. Kinnee. In this matter the Supreme Court of
Washington had held that customers are not necessarily trade secrets, nor are they property. In this
matter the customers were fixed and settled in a known district, and the fact of their being patrons
of the appellant was in no way covered up, but capable of ascertainment on behalf of respondent's
new employer or anyone else, by an independent canvass at a small expense and in a very limited
period of time. The Court had held and emphasized that such a thing can hardly be said to be a
secret, in the sense that it should be guarded by a Court of equity, which is susceptible of discovery
by observation and little effort. Similarly in 174 Ark, 104, 294 S.W.393, El. Dorado Laundry Co. v.
Ford the name of patrons learned by a driver employed on laundry route were held not to be trade
secrets. It was held that any person of ordinary intelligence would become familiar with the
customers whom he might serve along a laundry route during a period of five months. The Supreme
Court of Arkansas had held that freedom of employment must not be unreasonably abridged, and a
contract in restraint of employment, without some reasonable limitation, is like a similar contract in
restraint of trade, contrary to public policy and unenforceable.
47. Prima facie, the version of the plaintiff that the defendant had taken alleged confidential
information and data of the plaintiff is not believable in the facts and circumstances. The injunction
as prayed by the plaintiff will have direct impact on curtailing the freedom of the defendant in her
future prospects and service. Rights of an employee to seek and search for better employment are
Page 2131 not to be curbed by an injunction even on the ground that she has confidential data in the
present facts and circumstances. Such an injunction will facilitate the plaintiff to create a situation
such as 'Once a customer of American Express, always a customer of American Express'. In the garb
of confidentiality the plaintiff can not be allowed to perpetuate forced employment with American
Express. Freedom of changing employment for improving service conditions is a vital and important
right of an employee which cannot be restricted or curtailed on the ground that the employee has
employer's data and confidential information of customers which is capable of ascertainment on
behalf of defendant or any one else, by an independent canvass at a small expense and in a very
limited period of time. Such a restriction will be hit by Section 27 of the Contract Act and common
law and equitable doctrine of English Law will not be applicable in the fact and circumstances. An
injunction can be granted for protecting the rights of the plaintiff but at the same time cannot be
granted to limit the legal rights of the defendant especially when the Court has a doubt about the
veracity of plaintiff's version and as it appears that the injunction has been sought for extraneous
reasons and oblique motives and by concealment of material document, statement of defendant
recorded by the plaintiffs' officials on 4th October,2005.
48. What is inevitable to infer in the whole facts and circumstances is that the defendant performed
extremely well and her desire to leave has been interpreted by the plaintiff as losing all the business
which she was able to get for the plaintiff in previous years and therefore, the plea of defendant
getting information about the plaintiff's customers illegally and unlawfully and alleging
confidentiality about the same, was made as an afterthought to pressurize her either not to leave the
Plaintiff or to teach her a lesson and curtail her future prospect for employment. The defendant can
not be restrained from dealing with the persons who are banking with the plaintiff. Such an
injunction will affect even those customers /persons who would like to bank with some other banksAmerican Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

than plaintiff despite banking with the plaintiff. Some of the customers have given letters and
communications which have been produced on record to show that it is their decision to be with any
bank/institution for managing their investment.
49. In totality of circumstances the plaintiff bank has failed to make out a strong prima facie case in
his favor. The inconvenience caused to the defendant shall be much more in case the injunction as
prayed by the plaintiff is granted in his favor and therefore, the balance of convenience is in favor of
defendant. Such an injunction as prayed by the plaintiff would rather lead to multiplicity of
proceedings.
50. For the foregoing reasons the order dated 15th October, 2005 needs to be vacated and injunction
application filed by the plaintiffs merits rejection and therefore, I.A. No. 8224/2005 filed by the
plaintiffs is accordingly dismissed and IA No. 8893/2005 filed by the defendant is hereby allowed.
The interim order dated 15th October, 2005 is vacated.
51. Needless to mention, the views expressed above are tentative and prima facie conclusions which
will not be expression of any final opinion on the final merits of the case.American Express Bank Ltd. vs Ms. Priya Puri on 24 May, 2006

