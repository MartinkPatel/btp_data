Avnish Bajaj vs State on 29 May, 2008
Author: S. Muralidhar
Bench: S. Muralidhar
JUDGMENT
S. Muralidhar, J.
Introduction 1.1 Over three and a half years ago, an internet website carried a listing which offered
for sale a video clip, shot on a mobile phone, of two children of a school in Delhi indulging in an
explicitly sexual act. The petitioner, who was the Managing Director (MD) of the company that
owned the website at the relevant point in time, asks this Court to annul his criminal prosecution for
the offences of making available for sale and causing to be published an obscene product within the
meaning of Section 292 Indian Penal Code (IPC) and Section 67 of the Information Technology Act
2000 (IT Act). This petition under Section 482 of the Code of Criminal Procedure 1973 ('CrPC') also
raises questions concerning the criminal liability of directors for the offences attributable to a
company, both under the IPC as well as the IT Act, particularly when such company is not arraigned
as an accused.
1.2 Before discussing the background and the sequence of events leading to the filing of this petition,
it is necessary to understand the context in which the issues arise for determination. The regulation
of pornography on the internet has posed a serious challenge to governments and legislatures
primarily on account of the nature of the medium. The easy availability, even to children, of
pornographic material in digital form including video clips, its rapid transmission across the world
wide web, and the absence of effective filters to screen out objectionable material from being
accessed are factors that compound the challenge. It is said that "controlling pornography on the
internet is problematic because we may not know from whom or from where the material originates,
how many people are receiving the information, or if the material is crossing international
boundaries." [See Robyn Forman Pollack, "Creating the Standards of a Global Community:
Regulating Pornography on the Internet- an International Concern" 10 Temple International and
Comparative Law Journal, (Fall, 1996) 467].
1.3 It is acknowledged that "the main concern of the legislators and parents in relation to the
internet is child pornography, rather than other forms of sexually explicit content. This has been the
case ever since paedophiles started to use the internet for circulating pornographic materials related
to children." [See Yaman Akdeniz, "Cyber Rights, Protection and Markets: Article Governing
Pornography and Child Pornography on the Internet: The UK Approach" 32 University of West Los
Angeles Law Review 247 (2001)] Akdeniz points out that although in some countries there are
arguments against proscription of pornography based on freedom of speech concerns, "there isAvnish Bajaj vs State on 29 May, 2008

general consensus that the line should be drawn with child pornography." These factors need to be
borne in mind while examining the irreversible harm that can be caused by making available on the
internet sexually explicit material that answers the description of child pornography.
Background facts 2.1 Baazee.com India Private Limited ('BIPL'), a wholly owned subsidiary of Ebay
Inc. USA, and the owner of the website http://www.baazee.com, was during the relevant period in
the process of being acquired by and consequently renamed as Ebay India Private Limited (EIPL).
BIPL had its main office at Mumbai and another office in Delhi. During November to December
2004 the petitioner Avnish Bajaj was the MD of BIPL (which later was renamed as EIPL).
2.2 The website baazee.com provided an online platform or market where a seller and a buyer could
interact. To be either a seller or buyer a person had to first register himself with baazee.com by
filling out an online form giving details including the name, email id, date of birth (the age had to be
18 and above). The person registering had to choose an appropriate 'baazee ID' and a password
which would be used every time the person logged on to the website baazee.com to transact either as
a seller or a buyer. While registering, the applicant had to make a declaration to the following effect:
I have read the User agreement carefully - I am above 18 years of age. I have read and
agreed to abide by the baazee.com user agreement...." The next stage in the
registering process was reached after the person clicked on "Accept Terms & Submit".
Thereafter an email was sent to the person by baazee.com in which a link was
provided for activating the account. A person who registered following the above
online procedure could either sell or buy products on the electronic market that
baazee.com offered by using the baazee.com ID and password.
2.3 To be a seller a two-step process was envisaged. The first step was to get
registered following the procedure described hereinbefore. The second step was to
"create a listing." Again several steps were to be followed. First the seller would select
a category and sub-category that broadly classified the product proposed to be sold.
Then the item details had to be specified. The website advised: "Enter the title that
you would like to give your item in the text box provided. Give a title that describes
your item best. Try to include specifications such as brand name, model number etc.
The idea is to make your title most self explanatory and distinctive. Do not use web
language (HTML)." The website also recommended that the seller should "always
include an image that depicts your item correctly." The price and payment mode
preferences were also to be indicated. Baazee.com also offered a mode of receiving
payment under 'paisapay'. The user could also opt for other methods like cheques,
demand drafts, cash on delivery etc. 2.4 When a user was listing an item for the first
time on the site, a customer support representative had to verify his contact details
(address and phone number) by calling up the user on the contact number given in
the registration details. For an already registered user who wished to list some other
item, there was an automated website filter which checked the item to identify
whether it was a prohibited or restricted item. BIPL had a Safety and Trust Division
which instituted word and text filters so that objectionable listings could be removed.Avnish Bajaj vs State on 29 May, 2008

A Community Watch Programme was also operational. If anyone brought to the
notice of BIPL that any objectionable material was being listed, it would trigger a
process by which the listing would be deactivated. Once the item was automatically
screened by the filter, the listing was placed on the site with a unique computer
generated item ID.
2.5 The buying process was fairly straightforward. The registered buyer had to find
the item by using the Search box. He then had to browse the categories and
sub-categories. After reading the item description, if the person intended to buy, he
would click "buy now", select the payment method, specify the delivery details and
confirm the order. This resulted in a purchase order being generated. Then came the
question of payment through either the credit card or online bank transfer. If the
buyer opted for a "paisapay" option and made an online payment, the normal
banking payment gateway got attracted. Once the payment gateway confirmed the
receipt of the payment then an automated payment confirmation was sent to the
buyer. Thereafter the buyer received the item, depending on the product, through
email, hand delivery, courier or post.
2.6 When buyers opted for the "paisapay" method, the system would once in a week
calculate the amount payable to the listed user and send a file to the HDFC bank to
issue a printed demand draft (DD) in the name of bank account number provided by
the seller on www. baazee.com. The HDFC Bank would then dispatch the DD to the
address provided by the seller. For facilitating this entire transaction BIPL received a
commission which was usually a percentage of the selling price of the product.
The sequence of events 3.1 The sequence of events relevant to the present case unfolded thus. Ravi
Raj, a fourth year student of the Indian Institute of Technology (IIT) Kharagpur, was registered as a
seller with baazee.com since 21st July 2004. He had already been using the site for listing products
for sale. His email ID was psell@sify.com.
3.2 In the evening of Saturday 27th November 2004, Ravi Raj placed on the baazee.com website a
listing offering an MMS video clip for sale at Rs. 125 per piece. He adopted the seller's name as Alice
Electronics and gave his address as 12-A/39, Roshpa Tower, Main Road, Malanche, Kharagpur. In
order to avoid detection by the filters installed by baazee.com, Ravi Raj included the clip under the
category Books and Magazines and sub-category 'e-books'. Although baazee.com did have a filter for
some of the words which appear on the website, the listing nevertheless took place. For instance, the
word "sex" at serial No. 23 of the list and word "sexual" at serial No. 70 of the list were definitely
part of the suspected words.
3.3 The electronic website baazee.com when visited had the following item description on its site:
"Item 27877408 - DPS Girls having fun!!! full video + Baazee points." The price was Rs. 125. Under
the column "seller's details" the name indicated was: "alice elec" and Location: "Kharagpur". The
seller was shown as a Member since 21st July 2004. Upon clicking on the item description, the
listing read as under:Avnish Bajaj vs State on 29 May, 2008

DPS Girls having fun!!! Do you want to see that video clip which has rocked the whole
DELHI and now has become a hot point of discussion in the entire Nation?
YES, Then what are you waiting for!!!! Just order for this product and it will be
delivered to you within few hours.
This video is of a girl of DPS RK PURAM which has been filmed by his boyfriend in
very sexual explicit conditions.
Please note: This video clip of around 2:30 Minutes and will be send to you as an
email attachment.
3.4 The buyer interested in getting a copy had to click on the 'buy now' option, make
a payment through credit card or 'paisa pay' option. The buyer had to pay Rs. 128 per
clip which included a commission of Rs.3 that went to BIPL. This was deducted from
the amount received from the buyer and the balance of Rs. 125 per clip was remitted
to the seller by the HDFC bank. The seller, on receiving confirmation that payment
had been made, would send the video clip by an email attachment by a zip file with
the description 'dps_rkpuram-sex-scandle.zip'. Between around 8.30 pm in the
evening of November 27th 2004 when the listing went on line till around 10 am on
29th November 2004 when the listing was de-activated, eight transactions of sale of
the said video clip took place to buyers located in various parts of the country.
3.5 At around 8.20 pm on Saturday 27th November 2004 information was received
on email from Amit Vohra using emailed threadsincp@sify.com for Community
Watch. The mail titled "fraud report about item ID 27877408" read as under:
User's Message The username of the party is alice-elec. This person is trying to sell a
video which is illegal in India as it was shot on two people who are below the legal age
of 18 & pornography is illegal in India. You need to sort this issue & you should even
report it to the legal authorities as this can get your site in trouble.
3.6. This email was assigned to Namrata of BIPL at around 8.25pm on 27th
November 2004 itself. At around 6:25pm on the next date i.e. 28th November 2004,
which happened to be a Sunday, it was assigned to Swapna Sawant of the BIPL and
the priority was shifted to the 'high alert' category.
3.7 On 29th November 2004 at 10:10am baazee.com wrote to Alice Electronics that it
had noticed "that the listings put up on site by you are either obscene or
pornographic in nature" and that the Baazee User Agreement prohibits trade in such
items. It accordingly informed the seller "we have closed the item as it is against the
User Agreement." Soon thereafter Swapna Sawant of BIPL addressed a letter next
morning i.e. on Monday 29th November at 10:38 am to Amit Vohra thanking him for
"spotting this and reporting to us at Community Watch that the Item ID: 27877408 isAvnish Bajaj vs State on 29 May, 2008

pornographic in nature. We have closed the items and have taken this issue up with
the seller." The video clip was removed on 29th November 2004 Monday at around
10:38 am. Meanwhile eight persons with distinct IDs located in different parts of the
country including Calcutta, Nellore, Pune, Delhi, Banglore and Chennai had
purchased it.
3.8 On 9th December 2004 two events took place. The Crime Branch of Delhi police,
on receiving credible information that the said MMS clip was sold for Rs. 125 by a
website, registered FIR No. 645 of 2004. On the same day a news item appeared in a
Delhi the newspaper "Today" with the headlines "DPS sex video at baazee.com". The
news item by Anupam Thapa had the byline "Outrage Exclusive" and stated "online
website goes ahead with the sale of the infamous clip". The news item stated: "India's
biggest online trading portal baazee.com had listed the said MMS clip under the title
'DPS girls having fun' with the member ID of 27877408. The police upon
investigation learnt that one Alice Electronics of Kharagpur West Bengal had since
27th November 2004 sold 8 copies of the said MMS clip."
3.9 The police sent notices under Section 91 CrPC to the petitioner and Sharat
Digumarti, the Senior Manager, Trust and Safety, BIPL (who is Accused No. 3) and
obtained information on the working of the website. On 10th December 2004 in
response to a query addressed to baazee.com, Sharat Digumarti provided "the details
of the seller (alice_elec) and the buyers who purchased this item." He stated that they
had "already disabled the ability of the seller and the buyers in modifying their
contact details and the attached file contains the contact details of these users which
was taking from our database (File Name 'DPS Data') and also file (File Name: DPS
Listing) which show the item that was listed on the site."
3.10 On 11th December 2004 the police seized the printout of an email containing
two pages regarding email ID vishwa777@yahoo.com dated 27th November 2004
with the time as 17:58:26 which was the placement of the order and an email of the
same date received at that very address from Ravi Raj the seller at with the time as
20:05:13 with the email attachment dps_rkpuram_sex_scandal.zip which is a zip file
sent to the said email ID. The subject of the email was 'DPS Sex Scandal'. The third
item seized was an Amkette floppy which had an email from the seller and
confirmation email from baazee.com. Details of the email placement of the order and
receipt of the product by each of the other buyers was also collected.
3.11 On 12 December 2004 Sharat Digumarti furnished the details of the payments
received from the buyers and confirmed that a sum of Rs. 17,787.87 was disbursed to
the seller 'alice_elec' through the HDFC Payment Services.
3.12 On 14th December 2004, the petitioner wrote to the police about his role and
responsibility. Inter alia he stated that: "I am responsible for the India operations of
the Company and my charges, assigns, includes policy decisions, planning, controlAvnish Bajaj vs State on 29 May, 2008

and overall supervision of day to day functioning of the organization."
3.13 In his letter dated 14th December 2004 Sharat Digumarti explained the
registration, buying and selling process and payment process at baazee.com. He
enclosed a note on how the "list of the suspected and banned words" worked and the
process of detection of leakage. He also gave details of the working of Community
Watch. Thereafter a list of 120 words as on 14th December was attached. Although in
the said list at serial No. 106 the word "dps" and at serial No. 110 the word "RKP"
were included, these were admittedly added after the sale of the objectionable video
clip came to light. The contents of the clip itself were therefore not under screening in
the automated process since the clip itself was not on the baazee. com.
3.14 The Manager, Finance and paisapay of baazee.com wrote a detailed letter to the
police giving information on how the said system works and gave a complete list of
the transactions involving the video clip. This letter confirmed that Rs. 128 was
charged per piece from each of the buyers. Rs.3 rupees were paisapay charges and Rs.
125 went to the seller.
3.15 On 17th December 2004, Ravi Raj was arrested at Kharagpur and certain
recoveries were effected from him including the CPU containing the hard disk of the
computer from where the email attachments of the offending video clip were
despatched. The petitioner Avnish Bajaj was arrested in Mumbai on the same day. He
was later released on bail by this Court on 21st December 2004. At the conclusion of
the investigations, a charge sheet was filed showing Ravi Raj, Avnish Bajaj and Sharat
Digumarti as Accused Nos. 1,2 and 3 respectively.
3.16 The learned Metropolitan Magistrate (MM) by an order dated 14th February
2006 took cognizance of the offences under Sections 292 and 294 IPC and Section 67
IT Act. The three accused were summoned to face trial. Ravi Raj has since been
absconding and his trial has been separated.
3.17 This petition was filed by Avnish Bajaj, the MD of BIPL (EIPL) seeking the
quashing of the criminal proceedings on various grounds which will be discussed
hereafter. During the pendency of this petition there has been a stay of the
proceedings before the trial court.
Submissions of Counsel 4.1 Arguments on behalf of the petitioner were addressed by Mr. Arun
Jaitley and Mr. Sidharth Luthra, Senior Advocates.
4.2 According to the petitioner, the case against BIPL is not, and cannot possibly be, in relation to
the video clip since the clip itself was not made available on baazee. com. The video clip was
transferred directly between the seller and buyer without the intervention of the website. While no
submission was made in regard to the video clip being obscene, the submission of the petitioner was
that at the highest BIPL was concerned only with the listing placed on the website which by itselfAvnish Bajaj vs State on 29 May, 2008

was not obscene and did not attract the offence under Section 292/294 IPC or Section 67 IT Act.
4.3 It was then argued that in any event without BIPL (EIPL) being made an accused, no criminal
liability attached to the petitioner for an IPC offence only because he happened to be the MD of
BIPL (EIPL) at the relevant time. The revenue generated by the website was not profit as
contemplated by Section 292 IPC and in any event such income was not generated by the petitioner
but by BIPL which is not an accused in the case. Reasonable care was taken by the website to
immediately remove the video clip once it was brought to its knowledge that it was objectionable.
Therefore the website acted diligently and did not commit any illegality. The charge sheet when read
as a whole does not make out even a prima facie case against the petitioner in his individual capacity
for the offences under Sections 292/ 294 IPC.
4.4 In relation to Section 67 IT Act, it was argued that in the absence of the company BIPL (EIPL)
itself being made an accused, no liability could attach to the petitioner with the aid of Section 85 IT
Act. A reading of the charge sheet as a whole would show that although the petitioner as MD was in
overall charge of the policy and planning of the business, he had no direct role in the placing of the
listing or its filtering and subsequent removal. This was an automated process and the work of
supervising the placing of listings on the website had been delegated to specific individuals like
Accused No. 3 Sharat Digumarti. Criminal liability cannot be fastened lightly in the absence of a
specific case being made out against the petitioner in his individual capacity, particularly since the
company of which he was MD is not arraigned as an accused.
5.1 Appearing for the State, Ms. Mukta Gupta, learned Senior Standing Counsel submitted that the
sequence of events, the listing, video clip and the role attributed to the petitioner, fully make out a
case against the petitioner for the offences under Section 292 IPC and Section 67 IT Act. The offence
under Section 292 IPC includes not only overt acts but illegal omissions within the meaning of
Sections 32, 35 and 36 IPC. The failure to have adequate filter in a system which is entirely
automated, entails serious consequences and a website cannot escape such legal consequences.
5.2 It is further submitted by the learned Counsel for the State that the fact that website earned
profits through the sale is evident from the bank statements which show that for each video clip it
did earn a commission of Rs.3. The chain of events show that the website had a role to play in
several of the stages before the video clip was sent by the seller to the buyer by an email attachment.
The fact that payment was made to the seller even as on 27th December 2004 shows that no attempt
was made to prevent or stop the commission of the illegality by the website.
5.3 It was submitted by Ms. Gupta that the petitioner was the person in-charge of the affairs of the
company that owned the website and was responsible for its policy and planning. There is adequate
material set out in the charge sheet which shows that the petitioner had a direct role in the matter.
Notwithstanding that the BIPL itself is not arraigned as an accused, the petitioner can nevertheless
be proceeded against for the role played by him in the transaction.
5.4 For the offence under Section 67 IT Act, it is not necessary that the company BIPL itself should
be an accused. As explained in the judgments of the Supreme Court, what is relevant is whether atAvnish Bajaj vs State on 29 May, 2008

the trial a case for convicting the company for the offences had been made out. The present stage
was premature to come to a conclusion either way. Even at a subsequent stage in the proceedings,
the court can summon the company if sufficient material emerges against it.
5.5 Finally it was submitted that the crime is of an extremely grave nature and cannot go
unpunished on technicalities. Even if the charge sheet does not contain specific allegations, the
matter can still proceed to the next stages. At this stage the court is only to examine if a prima facie
case is made out and on that test no interference is called for.
Are the offences under Sections 292 and 294 IPC and Section 67 IT Act attracted? 6.1 The question
that first requires to be addressed is whether in the facts and circumstances of the case, as disclosed
in the charge sheet, a prima facie case for offences under Sections 292 and 294 IPC and Section 67
IT Act is made out. If the answer to this question is in the affirmative, the further question that
arises is whether a prima facie case has been made out against the petitioner for those offences.
6.2 Section 292 IPC concerns the offence of sale of obscene materials and reads thus:
292. Sale, etc., of obscene books, etc. (1) For the purposes of Sub-section (2), a book,
pamphlet, paper, writing, drawing, painting, representation, figure or any other
object, shall be deemed to be obscene if it is lascivious or appeals to the prurient
interest or if its effect, or (where it comprises two or more distinct items) the effect of
any one of its items, is. if taken as a whole, such as to tend to deprave and corrupt
person, who are likely, having regard to all relevant circumstances, to read, see or
hear the matter contained or embodied in it].
(2) Whoever-
(a) sells, lets to hire, distributes, publicly exhibits or in any manner puts into circulation, or for
purposes of sale, hire, distribution, public exhibition or circulation, makes, produces or has in his
possession any obscene book, pamphlet, paper, drawing, painting, representation or figure or any
other obscene object whatsoever, or
(b) imports, exports or conveys any obscene object for any of the purposes aforesaid, or knowing or
having reason to believe that such object will be sold, let to hire, distributed or publicly exhibited or
in any manner put into circulation, or
(c) takes part in or receives profits from any business in the course of which he knows or has reason
to believe that any such obscene objects are for any of the purposes aforesaid, made, produced,
purchased, kept, imported, exported, conveyed, publicly exhibited or in any manner put into
circulation, or
(d) advertises or makes known by any means whatsoever that any person is engaged or is ready to
engage in any act which is an offence under this section, or that any such obscene object can be
procured from or through any person, orAvnish Bajaj vs State on 29 May, 2008

(e) offers or attempts to do any act which is an offence under this section, shall be punished on first
conviction with imprisonment of either description for a term which may extend to two years, and
with fine which may extend to two thousand rupees, and, in the event of a second or subsequent
conviction, with imprisonment of either description for a term which may extend to five years, and
also with fine which may extend to five thousand rupees.
Exception.- ...
6.3 Section 292(1) is a deeming provision. If any "book, pamphlet, paper, writing, drawing, painting,
representation, figure or any other object" is "lascivious or appeals to the prurient interest" or "if
taken as a whole is such as to tend to deprave or corrupt person, who are likely to read, see or hear
the matter contained or embodied in it", then such object "shall be deemed to be obscene." The law
in this regard has been explained by the Supreme Court in Ranjit D. Udeshi v. State of Maharashtra ,
C.T. Prim v. State and Samaresh Bose v. Amal Mitra .
6.4 In the present case, there are two pieces of material that call for scrutiny. One is the video clip
and the other the listing on the website baazee.com. It was not argued by learned Counsel for the
petitioner that the video clip in question did not even prima facie attract the definition of an obscene
object within the meaning of Section 292 (1) IPC. Also, it is a matter of record that a separate case
has been instituted before the Juvenile Justice Board against the child involved in the act. As will be
noticed hereafter, the listing itself suggested that even according to the seller the clip answered the
description of child pornographic material.
6.5 To recall, the petitioner's submission was that BIPL and not the petitioner was, if at all,
concerned with the listing on the website which by itself was not obscene. According to the
petitioner, the video clip was transferred directly from the seller to the buyer without the
intervention of the web site. The question then arises whether the listing even prima facie answers
the definition of obscenity attracting Section 292(1) IPC.
6.6 The entire text of the listing has been set out earlier in para 3.3. Prima facie it appears that the
listing itself answered the definition of obscenity since it contained words or writing that appealed
"to the prurient interest" or if taken as a whole was "such as to tend to deprave or corrupt person,
who are likely to read, see or hear the matter contained or embodied in it." The listing contained
explicit words that left a person in no doubt that what was sought to be sold was lascivious. The
words "This video is of a girl of DPS RK PURAM which has been filmed by his boyfriend in very
sexual explicit conditions" are a prominent feature of the listing which invited a potential buyer to
purchase the obscene object which was the video clip by projecting it as child pornography since the
reference is to school children. Despite the arguments to the contrary of the learned Senior counsel
for the petitioner, this Court is not able to agree with their submissions that the listing itself was not
even prima facie an obscene material or text.
6.7 It was argued that even then, there was no overt act done by BIPL in relation to the video clip or
listing, to even prima facie attract the offence under Section 292 (2) IPC. This Court is unable to
agree. As far as the listing is concerned, its contents were in the knowledge of BIPL the moment theAvnish Bajaj vs State on 29 May, 2008

listing was placed on the website by Ravi Raj. The offence under Section 292 (2) (a) IPC gets
attracted when the prosecution is able to prove that a person has "publicly exhibited or in any
manner put into circulation" or "has in his possession" the obscene object. Even if Ravi Raj, and not
BIPL, may have inserted the listing, the website of BIPL certainly "possessed" it. The website was
easily accessible on the net and therefore the website also "publicly exhibited" the listing. It cannot
be said therefore that in respect of the listing, Section 292 (2) (a) IPC is not even prima facie
attracted as far as BIPL is concerned.
6.8 In relation to the video clip, the wording of Section 292(2) (d) IPC is wide enough to include an
attempt at making known "by any means whatsoever" that "such obscene object can be procured."
The placing of an advertisement on the website informing the viewer that an obscene material or
object is available for sale, one click away, is enough to attract the offence under Section 292(2)(d).
The advertisement might itself have been inserted by the seller but the website facilitated the sale by
carrying the listing which informed the potential buyer that such a video clip that is pornographic
can be procured for a price. For instance, there could be a notice board in the premises of a club or
association, on which is pasted a listing by one of the members offering for sale a pornographic film.
It would not be open to the club/association to say that it in providing space on its notice board it is
not by itself "making known" that an obscene object "can be procured from or through any person."
Section 292(d) would be attracted in such a situation to fasten criminal liability on the club itself. If
it is proved that a particular member was aware of the placing of such listing on the notice board
such member would also be liable. Baazee.com here was using a public space in the form of a
website that could be accessed by any internet user.
6.9 In relation to the essential ingredients of the offence of sale of or offer for sale of obscene
products, reference was made to paras 10 and 11 of the judgment in Ranjit D. Udeshi which read
thus:
10. Before dealing with that problem we wish to dispose of Mr. Garg's third argument
that the prosecution must prove that the person who sells or keeps for sale any
obscene object knows that it is obscene, before he can be adjudged guilty. We do not
accept this argument. The first sub-section of Section 292 (unlike some others which
open with the words "whoever knowingly or negligently etc.") does not make
knowledge of obscenity an ingredient of the offence. The prosecution need not prove
something which the law does not burden it with. If knowledge were made a part of
the guilty act (acts reus), and the law required the prosecution to prove it, it would
place an almost impenetrable defence in the hands of offenders. Something much
less than actual knowledge must therefore suffice. It is argued that the number of
books these days is so large and their contents so varied that the question whether
there is mens era or not must be based on definite knowledge of the existence of
obscenity. We can only interpret the law as we find it and if any exception is to be
made it is for Parliament to enact a law. As we have pointed out, the difficulty of
obtaining legal evidence of the offender's knowledge of the obscenity of the book etc.,
has made the liability strict. Under our law absence of such knowledge, may be taken
in mitigation but it does not take the case out of the sub-section.Avnish Bajaj vs State on 29 May, 2008

11. Next to consider is the second part of the guilty act (actus reus), namely, the
selling or keeping for sale of an object which is found to be obscene. Here, of course,
the ordinary guilty intention (mens rea) will be required before the offence can be
said to be complete. The offender must have actually sold or kept for sale, the
offending article. The circumstances of the case will then determine the criminal
intent and it will be a matter of a proper inference from them. The argument that the
prosecution must give positive evidence to establish a guilty intention involves a
supposition that mens rea must always be established by the prosecution through
positive evidence. In criminal prosecution mens rea must necessarily be proved by
circumstantial evidence alone unless the accused confesses. The sub-section makes
sale and possession for sale one of the elements of the offence. As sale has taken place
and the appellant is a book-seller the necessary inference is readily drawn at least in
this case. Difficulties may, however, arise in cases close to the border. To escape
liability the appellant can prove his lack of knowledge unless the circumstances are
such that he must be held guilty for the acts of another. The court will presume that
he is guilty if the book is sold on his behalf and is later found to be obscene unless he
can establish that the sale was without his knowledge or consent. The law against
obscenity has always imposed a strict responsibility. When Wilkes printed a dozen
copies of his Essay on Woman for private circulation, the printer took an extra copy
for himself. That copy was purchased from the printer and it brought Wilkes to grief
before Lord Mansfield. The gist of the offence was taken to be publication-circulation
and Wilkes was presumed to have circulated it. Of course, Wilkes published
numerous other obscene and libellous writings in different ways and when Madame
Pampadour asked him:
How far does the liberty of the Press extend in England?" he gave the characteristic
answer: "I do not know. I am trying to find out !" (See 52 Harv. L. Rev. 40).
6.10 A reading of the above paragraphs shows that there are two elements to be
satisfied in order to prove the offence under Section 292 IPC. The first is that the
person accused of the offence had the knowledge that what was being offered for sale
or exhibited or possessed was obscene. The second is that such person had the
intention to commit any of the acts mentioned in Section 292 (2) IPC. In Ranjit D.
Udeshi it was held that the prosecution did not have to prove that the accused had
knowledge that the contents of the books being offered for sale were in fact obscene
since the deeming provision in Section 292 (1) IPC stood attracted. However the
prosecution was required to prove that the accused did intend to sell such obscene
object.
6.11 Turning to the case on hand, the listing here was carried by the website
baazee.com. The text of the listing leaves no doubt that the object being offered for
sale was obscene. By not having appropriate filters that could have detected the
words in the listing or the pornographic content of what was being offered for sale,
the website ran a risk of having imputed to it the knowledge that such an object wasAvnish Bajaj vs State on 29 May, 2008

in fact obscene. These are the attendant risks that a website owner attracts when he
exploits cyber space for profits. The proliferation of the internet and the possibility of
a widespread use through instant transmission of pornographic material, calls for a
strict standard having to be insisted upon. Owners or operators of websites that offer
space for listings might have to employ content filters if they want to prove that they
did not knowingly permit the use of their website for sale of pornographic material.
Given the nature of the offence and the 'strict liability' envisaged by Section 292 (1)
IPC, even if for some reason the filters fail, the presumption that the owner of the
website had the knowledge that the product being offered for sale was obscene would
get attracted. This of course would be a rebuttable presumption. It would be open to
the owner of the website to show that it took reasonable precaution to filter the listing
for obscene material, this it was nevertheless placed on the website listed without its
knowledge and that it took prompt corrective once it knew that the listing or the
product offered for sale was obscene. But that would be a matter for evidence at the
trial.
6.12 For the purposes of the present petition it is enough to examine if the offence
under Section 292 IPC is prima facie attracted. This Court finds that it does as far as
BIPL (EIPL) is concerned. It is therefore not necessary at this stage for this Court to
examine if there is a valid defence available to BIPL or, whether, as contended by the
prosecution, the offence would get attracted even on account of the illegal omissions
of BIPL.
7.1 Next, we turn to Section 67 of the IT Act which reads as under:
Section 67-Publishing of information which is obscene in electronic form Whoever
publishes or transmits or causes to be published in the electronic form, any material
which is lascivious or appeals to the prurient interest or if its effect is such as to tend
to deprave and corrupt persons who are likely, having regard to all relevant
circumstances, to read, see or hear the matter contained or embodied in it, shall be
punished on first conviction with imprisonment of either description for a term
which may extend to five years and with fine which may extend to one lakh rupees
and in the event of a second or subsequent conviction with imprisonment of either
description for a term which may extend to ten years and also with fine which may
extend to two lakh rupees.
7.2 The plain words of the above provision unambiguously state that the offence stands attracted
when there is publishing, transmitting or where anyone "causes to be published in the electronic
form" any material that is "lascivious or appeals to the prurient interest" or "if its effect is such as to
tend to deprave and corrupt persons who are likely, having regard to all relevant circumstances, to
read, see or hear the matter contained or embodied in it." The remaining portion of the provision
borrows the language of Section 292(2)(d) IPC. As far as the present case is concerned it has already
been held that what was offered for sale through the listing and the listing itself were prima facie
obscene.Avnish Bajaj vs State on 29 May, 2008

7.4 Therefore, it cannot be said that baazee.com in this case did not even prima facie "cause" the
publication of the obscene material. The ultimate transmission of the video clip might be through
the seller to the buyer but in a fully automated system that limb of the transaction cannot take place
unless all the previous steps of registration with the website and making payment take place. It is a
continuous chain. When five to six links of the chain are under the direct control of the website and
it is only on completion of each step that the final two steps which result in the actual publication of
the obscene material ensue, it cannot be said that the website did not even prima facie cause
publication of the obscene material.
8.1 As far as the offence under Section 294 is concerned, the learned Counsel for the prosecution did
not dispute the contention of the learned Counsel for the petitioner that the said offence was not
attracted in the facts of the case. A reference may nevertheless be made to the Section 294 IPC:
294. Obscene acts and songs Whoever, to the annoyance of others--
(a) does any obscene act in any public place, or
(b) sings, recites or utters any obscene song, ballad or words, in or near any public
place, shall be punished with imprisonment of either description for a term which
may extend to three months, or with fine, or with both.
8.2 It appears that Section 294 IPC deals only with doing obscene acts and singing or reciting or
uttering obscene songs in a public place. It cannot be said that the website itself did an obscene act
or performed any obscene song. The offence under Section 294 is not even attracted prima facie in
the facts and circumstances of the present case.
9. To summarise this part of the discussion, this Court finds that a prima facie case for the offence
under Section 292 IPC and Section 67 IT Act is made out as far as the owner of the website
baazee.com, i.e. the company BIPL (renamed as EIPL) is concerned. The offence under Section 294
IPC is not even prima facie attracted.
Is a prima facie case made out for the offences under Sections 292 IPC and 67 IT Act against the
petitioner?
10. The question that arises next is whether a prima facie case for the offence under Section 292IPC
and Section 67 IT Act is made out against the petitioner. It has been argued by the learned Senior
counsel for the petitioner that nowhere in the charge sheet is there any allegation that the petitioner
himself facilitated the publishing of the obscene material or is in any way directly involved in the
transaction.
11. It has been held that a prima facie case is indeed made out against BIPL. However, for some
reason BIPL has not been arraigned as an accused. No satisfactory explanation has been offered by
the prosecution except suggesting during the course of arguments that the law in regard to corporate
criminal liability was not very clear. This is not an acceptable position in view of the clear position inAvnish Bajaj vs State on 29 May, 2008

the law as explained by the Supreme Court. The word 'person' is defined under Section 11 IPC to
include "any Company or Association or body of persons, whether incorporated or not." Therefore
for an offence under the IPC there is no immunity granted to a company as such from prosecution.
Even if, like in Section 292 IPC, the offence is punishable with imprisonment and fine, a company
can still be arraigned and tried as an accused. Section 305 CrPC deals with the procedure that is to
be followed when the accused is a company. A person will be nominated by such company to
represent it during the trial. It may ultimately be punished only with fine (since most offences are
punishable with fine in addition to imprisonment). This position in law has now been settled by the
Constitution Bench of five judges of the Supreme Court Standard Chartered v. Directorate of
Enforcement . Overruling an earlier decision of a three Judge Bench in Assistant Commissioner v.
Velliappa Textiles , the Constitution Bench by a 3:2 majority held that for an offence under the IPC
or any other penal statute where the provision makes the offence punishable with imprisonment
fine, a company can nevertheless be prosecuted. It was held (AIR, paras 7 and 8):
7. As in the case of torts, the general rule prevails that the corporation may be
criminally liable for the acts of an officer or agent, assumed to be done by him when
exercising authorized powers, and without proof that his act was expressly authorized
or approved by the corporation. In the statutes defining crimes, the prohibition is
frequently directed against any "person" who commits the prohibited act, and in
many statutes the term "person" is defined. Even if the person is not specifically
defined, it necessarily includes a corporation. It is usually construed to include a
corporation so as to bring it within the prohibition of the statute and subject it to
punishment. In most of the statutes, the word "person" is defined to include a
corporation. In Section 11 of the Indian Penal Code, the "person" is defined thus:
The word "person" includes any Company or Association or body of persons, whether
incorporated or not.
8. Therefore, as regards corporate criminal liability, there is no doubt that a
corporation or company could be prosecuted for any offence punishable under law,
whether it is coming under the strict liability or under absolute liability.
12. Therefore, there was no legal bar in arraigning BIPL as an accused in the present case. It was
then submitted by the State, on the strength of the decision of the Supreme Court in SWIL Ltd. v.
State of Delhi , that at a later point in time, even before passing an order on charge, the trial court
can summon the company as an accused. Even if this were to happen, that still does not obviate the
requirement in law for the prosecution to show that a prima facie case has been made out against
the petitioner in his individual capacity for the IPC offence. While, as will be discussed hereafter, the
position is different with regard to the offence under Section 67 IT Act, as far as the offence under
Section 292 IPC is concerned, the law as it presently stands does not envisage an automatic liability
attaching to a Director for the offences committed by a company. Therefore even if at a subsequent
stage of the proceedings BIPL is summoned to face trial for the IPC offence, that would not, in the
absence of a specific case being made out against the petitioner in his individual capacity, result in
his being an accused.Avnish Bajaj vs State on 29 May, 2008

13. It requires to be noted that, unlike some other statutes containing penal provisions, the IPC does
not incorporate the concept of criminal liability of a Director or an employee where the principal
accused is a company. In other words, there is no provision similar to Section 141 of the Negotiable
Instruments Act, 1881 ('NI Act') or Section 140 of the Customs Act, 1962 or Section 85 of the IT Act.
These are provisions that provide for a deemed criminal liability of a person who, at the time of
commission of the offence by the company, was in charge of the affairs of the company or
responsible to it for the conduct of its business. The proviso to such provision makes it possible for
such person to escape liability by proving at the stage of trial that the offence was committed by the
company without his or her knowledge. Therefore once the deemed criminal liability gets attracted
under the substantive provision, the burden shifts to the accused under the proviso to rebut such
presumption. However, there is no such provision in the IPC.
14. In Maksud Saiyed v. State of Gujarat , the Supreme Court explained that (SCALE p. 323):
13. Indian Penal Code does not contain any provision for attaching vicarious liability
on the part of the Managing Director or the Directors of the Company when the
accused is the Company. The learned Magistrate failed to pose unto himself the
correct question viz. as to whether the complaint petition, even if given face value and
taken to be correct in its entirety, would lead to the conclusion that the respondents
herein were personally liable for any offence. The Bank is a body corporate. Vicarious
liability of the Managing Director and Director would arise provided any provision
exists in that behalf in the statute. Statutes indisputably must contain provision fixing
such vicarious liabilities. Even for the said purpose, it is obligatory on the part of the
complainant to make requisite allegations which would attract the provisions
constituting vicarious liability.
15. Recently this position was reiterated in S.K. Alagh v. State of U.P. where the Supreme Court
observed (SCALE p. 527):
16. Indian Penal Code, save and except some provisions specifically providing therefor, does not
contemplate any vicarious liability on the part of a party who is not charged directly for commission
of an offence.
18. As, admittedly, drafts were drawn in the name of the company, even if appellant was its
Managing Director, he cannot be said to have committed an offence under Section 406 of the Indian
Penal Code. If and when a statute contemplates creation of such a legal fiction, it provides
specifically therefore. In absence of any provision laid down under the statute, a Director of a
company or an employee cannot be held to be vicariously liable for any offence committed by the
company itself. (See Sabitha Ramamurthy and Anr. v. R.B.S. Channabasavaradhya ).
15. We may, in this regard, notice that the provisions of the Essential Commodities Act, Negotiable
Instruments Act, Employees' Provident Fund (Miscellaneous Provision) Act, 1952 etc. have created
such vicarious liability. It is interesting to note that Section 14A of the 1952 Act specifically creates
an offence of criminal breach of trust in respect of the amount deducted from the employees by theAvnish Bajaj vs State on 29 May, 2008

company. In terms of the explanations appended to Section 405 of the Indian Penal Code, a legal
fiction has been created to the effect that the employer shall be deemed to have committed an
offence of criminal breach of trust. Whereas a person in charge of the affairs of the company and in
control thereof has been made vicariously liable for the offence committed by the company along
with the company but even in a case falling under Section 406 of the Indian Penal Code vicarious
liability has been held to be not extendable to the Directors or officers of the company. (See Maksud
Saiyed v. State of Gujarat and Ors.).
16.1 Although the Supreme Court has termed the liability of a Director, where the company is the
accused, as being 'vicarious', the classical understanding of the concept of vicarious liability is
invariably in the context of a "master and servant" relationship. For instance, a company can be
made vicariously liable for the criminal acts of its employees or directors. In an article by
V.S.Khanna titled "Corporate Liability Standards: When should Corporations be held Criminally
Liable" 37 Am. Crim. L. Rev. 1239 (2000) the concept is explained thus:
Corporate liability is a form of vicarious liability wherein the corporation is held
liable for the wrongs of its agents. Vicarious liability is imposed on corporations
under the doctrine of respondeat superior when an agent (1) commits a crime (2)
within the scope of employment (3) with the intent to benefit the corporation.
(See also Thomas J. Bernard, "The Historical Development of Corporate Criminal
Liability", 22 Criminology 3 1984) 16.2 Here we have a converse situation where the
director is sought to be made liable for the criminal acts of the company.
Nevertheless, what the above two decisions of the Supreme Court show is that as far
as the IPC is concerned there is no automatic criminal liability of a director where the
company is arraigned as an accused.
17. The absence of such a provision in the IPC could be viewed as a lacuna but is not
to be lightly presumed as there have been numerous statutes enacted by Parliament
thereafter which have incorporated such provisions. For instance, Section 85 IT Act is
similarly worded as Section 141 NI Act and incorporates a deemed criminal liability
of the director. The IT Act amends certain provisions of the IPC as well. But
Parliament has chosen not to make any amendment to incorporate such a provision
in the IPC. The Court has therefore to proceed with the law as it exists, particularly
since it is a penal statute which admits of strict construction.
18. Does this mean that a Director or employee of a company can never be made an
accused? The answer has to be in the negative. What it means is that if the
prosecution seeks to make a Director or an employee of a Company, which is the
principal accused, liable for an IPC offence, then it will have to make out a case
against such person in his or her individual capacity. The precise role of the person
concerned in the actions of the company which led to the offence will have to be
proved.Avnish Bajaj vs State on 29 May, 2008

19.1 Turning to the case on hand, it is urged by the prosecution that there are enough
averments in the charge sheet to establish a prima facie case against the petitioner
even in his individual capacity and not merely in his capacity as MD of BIPL. It is
submitted that the charge sheet may not contain the precise words but when read as
a whole does bring out the prima facie case against the petitioner not only in his
designation a the MD of baazee.com but as an individual as well. In the written
submission filed by the State it is asserted that there are "specific averments explicitly
describing the role of the petitioner in commission of the offence under Section 292 &
294 IPC and Section 67 IT Act by his acts and illegal omissions...." It is further sought
to be argued that the charge sheet cannot be complete or accurate thesis of the
prosecution case. Reliance is placed on the decision of the Supreme Court in R.K.
Dalmia v. Delhi Administration . It is further submitted that "it is wrong to say that
the petitioner was charge sheeted and cognizance was taken simply owing to his
designation. The offence by the petitioner have been committed by him individually
though acting in his capacity as the Managing Director of the company." Elsewhere in
the written submission of the State it is averred as under:
It is wrong to suggest that the company merely facilitated the sale between the parties
to the transaction while in fact the company was an indispensable ally for the
completion of the transaction as is demonstrable from the flow chart.
19.2 The reference here is to a flow chart that the Court had asked the parties to
produce which would show the chain of transactions from the stage of the
registration of a seller to the ultimate delivery of the product to the buyer. Reliance
has been placed by the prosecution on the judgment in Keshub Mahindra v. State of
Madhya Pradesh and Sushil Ansal v. State 2002 Crl LJ 1369 to contend that the
liability for the IPC offences, where the company is the main accused would also be
attached to the directors.
19.3 In order to appreciate these submissions the relevant paragraphs of the charge
sheet may be noticed:
The user agreement, downloaded from the site and details seized from, Sharat
Digumarti, indicates that arrangements arrived at between buyers and sellers are
bipartite agreements with no responsibility of Baazee.com whatsoever. However, in
this case Baazee.com acted as an agent of the seller as it had taken a commission on
the sale. The clip was priced at Rs 125/- each, but billed at Rs. 128/- each with Rs3/-
as commission per sale. This commission was credited to PaisaPay, a division of
Baazee.com. The website Baazee.com had installed a program which runs SQL cron
jobs or checks the written words place by the sellers against a set of banned and
suspect words. The web portal is a public domain and can be accessed and read by
just anyone. The language of the advertisement placed on the website was quite
explicit and left nothing for the reader to imagine. The website was committed to
block off offending words through appropriate filters, as per Clause 1.12.4 ScheduleAvnish Bajaj vs State on 29 May, 2008

'C' Part II: Terms & Conditions of the ISP guidelines, issued by the Government of
India, which clearly states therein that "The Licensee shall ensure that objectionable,
obscene, unauthorized or any other content, messages or communications infringing
copyright, Intellectual Property right and International and domestic Cyber Laws, in
any form or inconsistent with the laws of India, are not carried in his network, the
ISP should take all necessary measures to prevent it." However, in-spite of the filters
having the word 'sexual' in its list, the program of Baazee.com failed to block off the
offending advertisement. Further, in-spite of being categorically informed by one of
the users' thread sincp@sify.com on 27.11.2004 at 8.20 p.m. the company,
Baazee.com a 24 x 7 platform, failed to act to stop the sale, immediately. All through
the day on 28.11.2004 the sale was going on unabated and it was finally closed on
29.11.04.
The language of the advertisement written down and represented by accused Ravi
Raj, on the website clearly conveyed the meaning that school children were involved
in explicit sexual act. Further the portal has charged and received commission on the
sale of the offending clip. The portal knew of the illegality of the fact, as the same was
blocked on 29.11.04 but still chose to profit form it by appropriating the commission,
15 days later. The investigation proves that Avnish Bajaj as the MD of Baazee.com as
well as Sharat Digumarti as Head Fraud and Risk Control, had knowledge of the
contravention, through the Community Watch scheme. In spite of being informed,
the item was not blocked for 38 hours. 75% of all sales took place after the web portal
was informed about it. The filters that were put up by the website were also grossly
inadequate. In spite of the word 'sexual' (at serial number 70) the word 'dps' (at serial
number 106) and word 'RKP' (at serial number 110) existing in the suspect list, their
program was not able to detect and block the advertisement which carried the same
word. Likewise words like Avnish Bajaj was the domain administrator and all policy
decisions were made through him. In spite of the hue and cry made in the media
about the issue, the policy makers for the website did not put the names like DPS,
RKPuram on their watch list till after the case was registered.
After having gathered enough evidences to establish that the porn video film was
listed for sale, that it was actually purchased by at least 8 buyers, that the clipping
was delivered to 8 buyers as email attachment through Baazee.com, that payments
were passed on to the accused Ravi Raj col. No. 4., after deducting due commissions,
that in spite of being categorically informed by one of the users thread
sincp@sify.com on 27.11.04 at 8.20 P.M. Baazee.com failed to act to stop the sale,
immediately, but closed it only after 38 hours, accused Avnish Bajaj, CEO of
Baazee.com mentioned in Col. No. 4 was arrested on 17.12.04.
Avnish Bajaj at the time, when the said porn clip was sold and brought through
Baazee.com. was the Managing Director of the Company, Baazee.com India Ltd. He
was in charge for the Indian operations of the Company and was responsible for
policy decisions, planning, control and overall supervision of day to day functioningAvnish Bajaj vs State on 29 May, 2008

of the organization. The profile on checkdomain.com also listed Avnish Bajaj as the
administrative contact of Baazee.com. The issue of sale of pornographic CDs
involving of two adolescents was widely in the media in the first week of Nov. 2004.
However no operative or policy changes were affected by the Company. Baazee.com
to prevent the listing/display/sale of the same on the portal. Although, the accused
company claimed that filters existed to block such objectionable materials,
investigations revealed that the claims made by the company were a mere eyewash.
The filters were found to be rudimentary, grossly inadequate and perfunctory.
Various other interactive web portals like jeevansaathi.com, naukri.com etc. adopt
various measures like delayed insertion and regular online monitoring. This even the
established industry norms, to prevent offensive content from coming up on websites
were totally ignored. The accused company was even alerted by a customer on
27.11.04 itself, but the site was de-listed as "closed" only after 38 hours. Even after
being closed it remained lodged in the closed item list for the general public to access
and see. The payments received were routed through PaisaPay, another division of
Baazee.com facilitating online money transfer and a commission of Rs.3/- per sale
transaction was charged. Although the site was closed on 29.11.04, payments received
from the buyers were not blocked but sent to the seller on 3.12.04. Investigation
proves that the MD of Baazee.com, who exercised control over the day to day
functioning of the organization did not exercise due diligence to prevent the listing of
the said obscene and lascivious clipping. The investigation reveals that the policies
and conduct of Baazee.com its MD was designed to increase sale and maximize
profits. Safeguard of prevailing moral values and prurient interests of any person in
particular and the society at large was not a pressing agenda. The investigations
found that the policy makers of the company were negligent in dealing with the
matter and failed to exercise due diligence.
19.4 The other relevant portions in the charge sheet are: "Further, subsequent to the
registration and arrest in this case, the domain and the network contact information
for the website Baazee.com had been changed from Baazee.com to ebay.com, the
principal company, who now own the domain name Baazee.com, primarily to
insulate the other Directors of the Company from criminal responsibilities. The
domain servers were also relocated by the company to xxx.EBAYDNS.COM, USA.
Sharat Digumarti was the Senior Manager, Trust and Safety who was responsible for maintaining
the subject and banned key word list and ensuring that no lascivious item is listed for sale on the
website. Sharat Digumarti was responsible for ensuring that no banned and illegal items are traded
on the website. However, he did not take appropriate measures to ensure that the list of the banned
and suspect words are updated keeping in mind the social and moral norms. Although the website
runs a 24 x 7 operations, no person had been deputed by him from his unit to review the listings and
to respond to alerts generated by the system. This allowed the item to remain listed for 38 hours
after an alert was raised by the Community Watch program. The filters that have been claimed by
the accused as a measure to block objectionable materials were found to be grossly inadequate
during the investigations. Sharat Digumarti has been charge-sheeted on recognizance withoutAvnish Bajaj vs State on 29 May, 2008

arrest."
The investigation conducted till date have gathered enough evidences against accused persons
Avnish Bajaj, Ravi Raj and Sharat Digumarti Col. No. 4. It has been clearly established that all the
said three accused persons knowing fully well and having reasons to believe, have sold/transmitted
a pornographic/obscene MMS clip causing lascivious impact on citizens by appealing to their
prurient interest for their undue pecuniary gains. Hence the present charge sheet has been prepared
u/s 292/294 IPC r/w 67 IT Act. It is therefore respectfully prayed that accused Accused Avnish Bajaj
and Ravi Raj col. No. 4 on bail and Sharat Digumarti on recognizance, may kindly be called through
notices and witness through summons for holding their trial in accordance with law. The list of
witnesses, documents and materials exhibits have also been enclosed.
19.5 This Court is unable to agree with the submission of the prosecution that the above contents of
the charge sheet make out a prima facie case against the petitioner for the IPC offence both in his
capacity as MD of BIPL as well as in his individual capacity. When read as a whole, the charge sheet
does not bring out the individual culpability of the petitioner at all. It brings out the culpability of
the company and the reference throughout to the petitioner is in his role as the MD of such
company. A useful contrast can be made with the averments pertaining to Sharat Digumarti which
have been extracted in the earlier paragraph. There the precise role of the person who was Senior
Manager, Trust and Safety, BIPL has been described. As regards the petitioner, the averment is that
he was in charge of policy and planning and was negligent in not putting in place sufficient filtering
mechanisms. In light of the strict liability principle, this by itself cannot satisfy the requirement of
there being sufficient material against the petitioner to attract even prima facie the offence against
him under Section 292 IPC.
19.6 A director does not automatically become criminally liable for the criminal acts of the company.
If one carefully reads the judgment in Keshub Mahindra it would be clear that UCIL, the company
was itself an accused. It is in that context that the Supreme Court made observations about the
individual liability of the directors. There were specific allegations in the charge sheet that each of
the directors was party to the decision taken by the UCIL concerning the safety of the Union Carbide
Plant. There are no such averments here as to the precise direct role of the petitioner. Even in the
case of Sushil Ansal no such argument appears to have been advanced that in the absence of the
company the directors could still be made accused. It is not possible to equate the said two decisions
with the case on hand because here the company has not been made an accused at all. In the
absence of the company being made an accused and in the absence of specific allegations concerning
the MD of the company, it is not possible to accept that the submission that the MD can be
proceeded against for the IPC offence.
19.7 It was then sought to be argued that even illegal omissions i.e. the failure to do an act would
attract Section 292 IPC. Sections 32 and 35 IPC were referred to for this purpose. The law in India
as regards illegal omissions has been explained in Ambika Prasad v. Emperor and Anna v. State of
Hyderabad AIR 1956 Hyd 99. There must be a legal compulsion to do an act and the failure to
perform such an act would result in illegal omission. Not any and every omission to perform an act
would result in a criminal liability. A reference may be made to the decisions in Queen v. AnthonyAvnish Bajaj vs State on 29 May, 2008

Udyan (1883) ILR 6 Mad 280 and Basharat v. Emperor AIR 1934 Lahore 813. These provisions will
have to be strictly construed. Otherwise each and every omission can attract criminal liability. The
charge sheet when read as a whole can at best be said to bring out a prima facie case of omission by
BIPL which owned the website and not by the petitioner in his individual capacity.
19.8 The charge sheet discloses that at various stages, in an automated system, roles were assigned
to individual employees of BIPL. There was a separate Manager for Trust and Safety. When the
Community Watch group alerted the website, the matter was first marked to an employee Namrata
then to another employee Swapna Sawant. Even with reference to the flow chart, the prosecution
was unable to show at what stages the petitioner as MD was himself directly involved in the
screening of the listing or its subsequent removal. In the circumstances, it would be a mere surmise
that the petitioner was himself responsible for the offence. There must be a specific allegation in the
charge sheet that, despite knowing the failure of the filters, he nevertheless did nothing about it.
There is no such averment in the charge sheet. In fact the liability sought to be attached to the
petitioner is only in his capacity as MD of the company and not in his individual capacity. Therefore
it is not possible to accept the argument of the prosecution that the doctrine of illegal omission
results in a criminal liability being attached to the petitioner here.
20.1 Next, we turn to the offence under Section 67 of the IT Act vis-à-vis the petitioner here. For this
it is necessary to reproduce Section 85 of the IT Act which reads as under:
Section 85 - Offences by companies (1) Where a person committing a contravention
of any of the provisions of this Act or of any rule, direction or order made thereunder
is a company, every person who, at the time the contravention was committed, was in
charge of, and was responsible to, the company for the conduct of business of the
company as well as the company, shall be guilty of the contravention and shall be
liable to be proceeded against and punished accordingly:
Provided that nothing contained in this sub-section shall render any such person
liable to punishment if he proves that the contravention took place without his
knowledge or that he exercised all due diligence to prevent such contravention.
(2) Notwithstanding anything contained in Sub-section (1), where a contravention of
any of the provisions of this Act or of any rule, direction or order made thereunder
has been committed by a company and it is proved that the contravention has taken
place with the consent or connivance of, or is attributable to any neglect on the part
of, any director, manager, secretary or other officer of the company, such director,
manager, secretary or other officer shall also be deemed to be guilty of the
contravention and shall be liable to be proceeded against and punished accordingly.
Explanation.-For the purposes of this section,-
(i) "company" means any body corporate and includes a firm or other association of individuals; andAvnish Bajaj vs State on 29 May, 2008

(ii) "director", in relation to a firm, means a partner in the firm.
20.2 There are two parts to Section 85 IT Act. The first part says "where a person committing a
contravention of any of the provision of this Act or of any rule, direction or order made thereunder is
a company." On a plain reading of the provision, therefore, the company has to necessarily be found
to be in contravention of a provision of the IT Act. In such event, the deeming provision in the
second part gets attracted. This attaches a deemed criminal liability on a person who, at the time of
commission of the offence, was in "charge of, and was responsible to, the company". This deemed
liability shifts the burden of proof to the individual who is in charge of the affairs of the company.
20.3 The question whether in the absence of arraigning the company as an accused, such a deemed
criminal liability can attach to the directors was first addressed in the judgment of a Bench of the
three Judges of Supreme Court in State of Madras v. C.V. Parekh . There the Manager and Managing
Director of Microtec Castings (P) Ltd. were made the accused along with two other accused who
were a godown clerk and the representative to another company G.Ranji and Co. The company itself
i.e. the Microtec Castings (P) Ltd. was not made an accused. They were charged with having
committed a contravention of Clause 5 of the Iron and Steel Control Order, 1956 which is framed
under the Essential Commodities Act, 1955. The Supreme Court acquitted the accused and in para 3
of the judgment it was observed as under (SCC, p. 493):
3. Learned Counsel for the appellant, however, sought conviction of the two
respondents on the basis of Section 10 of the Essential Commodities Act under
which, if the person contravening an order made under Section 3 (which covers an
order under the Iron and Steel Control Order, 1956) is a company, every person who,
at the time the contravention was committed, was in charge of, and was responsible
to, the company for the conduct of the business of the Company as well as the
company, shall be deemed to be guilty of the contravention and shall be liable to be
proceeded against and punished accordingly. It was urged that the two respondents
were in charge of, and were responsible to, the company for the conduct of the
business of the company and, consequently, they must be held responsible for the
sale and for thus contravening the provisions of Clause 5 of the Iron and Steel
(Control) Order. This argument cannot be accepted, because it ignores the first
condition for the applicability of Section 10 to the effect that the person contravening
the order must be a company itself. In the present case, there is no finding either by
the Magistrate or by the High Court that the sale in contravention of Clause 5 of the
Iron & Steel (Control) Order was made by the Company. In fact, the Company was
not charged with the offence at all. The liability of the persons in charge of the
Company only arises when the contravention is by the Company itself. Since, in this
case, there is no evidence and no finding that the Company contravened Clause 5 of
the Iron & Steel (Control) Order, the two respondents could not be held responsible.
The actual contravention was by Kamdar and Villabhadas Thacker and any
contravention by them would not fasten responsibility on the respondents. The
acquittal of the respondents is, therefore, fully justified. The appeal fails and is
dismissed.Avnish Bajaj vs State on 29 May, 2008

20.4. Later, a two-Judge Bench of the Supreme Court in Sheo Ratan Agarwal v. State
of Madhya Pradesh while dealing with the same provision held as under (SCC,
p.354):
5. ...The Section appears to our mind to be plain enough. If the contravention of the
order made Under Section 3 is by a Company, the persons who may be held guilty
and punished are (1) the Company itself (2) every person who, at the time the
contravention was committed, was in charge of, and was responsible to, the Company
for the conduct of the business of the Company whom for short we shall describe as
the person-in-charge of the Company, and (3) any director, manager, secretary or
other officer of the Company with whose consent or connivance or because of neglect
attributable to whom the offence has been committed, whom for short we shall
describe as an officer of the Company. Any one or more or all of them may be
prosecuted and punished. The Company alone may be prosecuted. The
person-in-charge only may be prosecuted. The conniving officer may individually be
prosecuted. One, some or all may be prosecuted. There is no statutory compulsion
that the person-in-charge or an officer of the Company may not be prosecuted unless
he be ranged alongside the Company itself. Section 10 indicates the persons who may
be prosecuted where the contravention is made by the Company. It does not lay down
any condition that the person-in-charge or an officer of the Company may not be
separately prosecuted if the Company itself is not prosecuted. Each or any of them
may be separately prosecuted or along with the Company. Section 10 lists the person
who may be held guilty and punished when it is a Company that contravenes an order
made Under Section 3 of the Essential Commodities Act. Naturally, before the
person-in-charge or an officer of the Company is held guilty in that capacity it must
be established that there has been a contravention of the Order by the Company.
20.5 In the same paragraph of Sheo Ratan Agarwal, the above highlighted portions of
the judgment in C.V. Parekh were explained thus (SCC, p.355):
That should be axiomatic and that is all that the Court laid down in State of Madras v.
C.V. Parekh (supra) as a careful reading of that case will show and not that the
person-in-charge or an officer of the Company must be arraigned simultaneously
along with the Company if he is to be found guilty and punished. The following
observations made by the Court clearly bring out the view of the Court:
It was urged that the two respondents were in charge of, and were responsible to, the
company for the conduct of the business of the Company and, consequently, they
must be held responsible for the sale and for thus contravening the provisions of
Clause 5 of the Iron and Steel (Control) Order. This argument cannot be accepted,
because it ignores the first condition for the applicability of Section 10 to the effect
that the person contravening the order must be a company itself. In the present case,
there is no finding either by the Magistrate Or by the High Court that the sale in
convention of Clause 5 of the Iron & Steel (Control) Order was made by the Company.Avnish Bajaj vs State on 29 May, 2008

In fact, the Company was not charged with the offence at all. The liability of the
persons in charge of the Company only arises when the contravention is by the
Company itself. Since, in this case, there is no evidence and no finding that the
Company contravened Clause 5 of the Iron & Steel (Control), Order the two
respondents could not be held responsible. The actual contravention was by Kamdar
and Villabhadas Thacker and any contravention by them would not fasten
responsibility on the respondents.
The sentences underscored by us clearly show that what sought to be emphasised was
that there should be a finding that the contravention was by the Company before the
accused could be convicted and not that the Company itself should have been
prosecuted along with the accused. We are therefore clearly of the view that the
prosecutions are maintainable and that there is nothing in Section 10 of the Essential
Commodities Act which bars such prosecutions.
20.6 Although it was urged by learned Senior Counsel for the petitioner that the
above observations of the two-Judge Bench of the Supreme Court are contrary to
what was held by the larger bench of three judges in C.V. Parekh, on a careful
reflection this Court is of the view that the judgment in Sheo Rattan Agarwal is a
possible view to take of what was in fact held by the Supreme Court in C.V. Parekh.
20.7 The next important decision in this regard is U.P. Pollution Control Board v.
Messers Modi Distillery and Ors. . There the question that arose was whether without
making the company an accused in a case involving the offences under Sections 47 of
the Water (Prevention and Control of Pollution) Act 1974, the directors of that
company could be made liable. The said provision was one that provided for a
deemed criminal liability of the director. The Single Judge of the Allahabad High
Court had discharged the directors on the ground that the company being an accused
was a pre-requisite to proceeding against the directors. Reversing the decision of the
High Court, the Supreme Court held (SCC, p.689-690)
6. The learned Single Judge has focussed his attention only on the technical flaw in
the complaint and has failed to comprehend that the flaw had occurred due to the
recalcitrant attitude of Modi Distillery and furthermore the infirmity is one which
could be easily removed by having the matter remitted to the Chief Judicial
Magistrate with a direction to call upon the appellant to make the formal
amendments to the averments contained in para 2 of the complaint so as to make the
controlling company of the industrial unit figure as the concerned accused in the
complaint. All that has to be done is the making of a formal application for
amendment by the appellant for leave to amend by substituting the name of Modi
Industries Limited, the company owning the industrial unit, in place of Modi
Distillery. Although as a pure proposition of law in the abstract the learned Single
Judge's view that there can be no vicarious liability of the Chairman, Vice-Chairman,
Managing Director and members of the Board of Directors under Sub-section (1) orAvnish Bajaj vs State on 29 May, 2008

(2) of Section 47 of the Act unless there was a prosecution against Modi Industries
Limited, the company owning the industrial unit, can be termed as correct, the
objection raised by the petitioners before the High Court ought to have been viewed
not in isolation but in the conspectus of facts and events and not in vacuum. We have
already pointed out that the technical flaw in the complaint is attributable to the
failure of the industrial unit to furnish the requisite information called for by the
Board. Furthermore, the legal infirmity is of such a nature which could be easily
cured. Another circumstance which brings out the narrow perspective of the learned
Single Judge is his failure to appreciate the fact that the averment in para 2 has to be
construed in the light of the averments contained in paras 17, 18 and 19 which are to
the effect that the Chairman, Vice-Chairman, Managing Director and members of the
Board of Directors were also liable for the alleged offence committed by the
Company.
20.8 The decision in Sheo Ratan Agarwal was reiterated in Anil Hada v. Indian
Acrylic Ltd. where the Supreme Court was interpreting Sections 138 and 141 of the NI
Act. That was a case where the company itself had not been made an accused but its
directors were sought to be made as an accused. The Court noticed C.V. Parekh (but
mistakenly to referred to it as a decision of a two Judge Bench) and proceeded to
hold: "But if a company is not proceeded due to any illegal snag or otherwise, the
other prosecuted persons cannot, on that score alone, escape from the penal liability
through the legal fiction envisaged in Section 141 of the Act." The Court in Anil Hada
also took note of the observations in Modi Distillery and explained that they "were
obiter. That apart, the law on the point was specifically discussed and dealt with in
Sheoratan Aggarwal with which we are in respectful agreement."
20.9 Therefore, in light of the law explained in the decisions of the Supreme Court
after C.V. Parekh, it appears that without the company being made an accused, its
directors can be proceeded against under Section 67 read with Section 85 IT Act.
There is another factor which weighs with this Court. At the present stage, it is too
early to conclude that the company will never be made an accused. It is possible,
following the dictum in SWIL that the trial court may at any stage hereafter summon
the company to face trial for the offence under Section 67 IT Act. In SWIL the
Supreme Court relied on the earlier decision in Raghubans Dubey v. State of Bihar
and held (SCC, p. 689):
6...After taking cognizance of the offence, the Magistrate under Section 204 CrPC is
empowered to issue process to the accused. At the stage of issuing process, it is for
the Magistrate to decide whether process should be issued against particular
person/persons named in the charge-sheet and also not named therein. For that
purpose, he is required to consider the FIR and the statements recorded by the police
officer and other documents tendered along with charge-sheet. Further, upon receipt
of police report under Section 173(2) CrPC, the Magistrate is entitled to take
cognizance of an offence under Section 190(1)(b) even if the police report is to theAvnish Bajaj vs State on 29 May, 2008

effect that no case is made out against the accused by ignoring the conclusion arrived
at by the investigating officer and independently applying his mind to the facts
emerging from the investigation by taking into account the statement of the witnesses
examined by the police. At this stage, there is no question of application of Section
319 CrPC.
20.10 In that event, the difficulty in the petitioner being proceeded against may not
arise at all. Prima facie there appears to be sufficient material to summon the
company. In fact the Supreme Court in Modi Distillery observed that the trial court
could overcome such technical objection by directing the arraigning of the company
as an accused as otherwise it would be "a travesty of justice." For the above reasons it
is not possible to hold that not even a prima facie is made out against the petitioner
for the offence under Section 67 read with Section 85 IT Act.
End Note
21. An end note before summarizing the conclusions. As this case reveals, the law in our country is
not adequate to meet the challenge of regulating the use of the internet to prevent dissemination of
pornographic material. It may be useful to look at the legislative response in other common law
jurisdictions. In the United States, there have been three legislations that have dealt with censorship
of pornographic material on the internet: the Communications Decency Act (CDA), which was
enacted as a part of the Telecommunications Act of 1996, the Child Online Protection Act 1998
(COPA) and the Children Internet Protection Act 2003 (CIPA). The CDA sought to prohibit the use
of an interactive computer service to send or display in any manner to those under the age of 18, any
communication that depicts or displays sexual or excretory activities in a manner that is patently
offensive. This was which was however struck down as unconstitutional by the U.S. Supreme Court
in Reno v. ACLU 521 U.S. 844 (1997). The COPA narrowed the range of the material prohibited but
was also held to be unconstitutional. The CIPA, which casts a duty on public libraries and schools to
install software to block obscene or pornographic images, was upheld as constitutionally valid by the
U.S. Supreme Court in United States v. American Library Association 539 U.S. 194 (2003). There
are nevertheless serious concerns expressed about the effectiveness of such laws and the challenges
that exist in enforcing prohibition of child pornography on the internet. [For instance, see Heidi
Wachs, "Permissive Pornography: the Selective Censorship of the Internet under CIPA", 11 Cardozo
Women's L.J. 441] In the United Kingdom, the Obscene Publications Act, 1959 was amended by the
Criminal Justice and Public Order Act of 1994 (CJPOA) to deal with the specific problem of internet
pornography by extending the Act to cover the transmission of electronically stored data. It makes
service providers liable for material placed on the internet by a third party thus requiring them to
monitor material for obscene matter. Further the Protection of Children Act, 1978 was amended by
CJPOA, 1994 to include photographs in electronic data format. India may want to develop a
different legislative model to regulate the use of the internet with a view to prohibiting its use for
disseminating child pornographic materials. Nevertheless, the task deserves the utmost priority.
Summary of conclusionsAvnish Bajaj vs State on 29 May, 2008

22. This Court accordingly holds as follows:
(a) The charge sheet when read as a whole brings out a prima facie case attracting the
offences under Section 292(1) (a) and 292 (2) (d) IPC and Section 67 IT Act.
However, not even a prima facie case for the offence under Section 294 IPC is made
out.
(b) A prima facie case for the offence under Section 292 (2) (a) and 292 (2) (d) IPC is
made out against BIPL now named as EIPL both in respect of the listing and the
video clip respectively.
(c) However, as far as the petitioner Avnish Bajaj is concerned, since the IPC does not
recognise the concept of an automatic criminal liability attaching to the director
where the company is an accused, not even a prima facie case for the offence under
Section 292 IPC is made out even when the charge sheet is read as a whole; it only
seeks to implicate him in his designation as MD of BIPL and not in his individual
capacity.
(d) Therefore, the petitioner will stand discharged as far as the offences under
Sections 292 and 294 IPC are concerned. This will however not affect the case against
the other accused.
(e) A prima facie case for the offence under Section 67 read with Section 85 IT Act is
made out against the petitioner since the law as explained by the decisions of the
Supreme Court recognises the deemed criminal liability of the directors even where
the company is not arraigned as an accused and particularly since it is possible that
BIPL (EIPL) may be hereafter summoned to face trial.
(f) Consequently, while the case against the petitioner of the offences under Sections
292 and 294 IPC is quashed, the prosecution of the petitioner for the offence under
Section 67 read with Section 85 IT Act will continue.
23. It is clarified that the learned trial court will proceed to the next stage of passing an order on
charge uninfluenced by the observations in regard to the offences in respect of which it has been
held by this Court that a prima facie case has been made out against the petitioner. The petition and
the application are accordingly disposed of. The interim stay is vacated.Avnish Bajaj vs State on 29 May, 2008

