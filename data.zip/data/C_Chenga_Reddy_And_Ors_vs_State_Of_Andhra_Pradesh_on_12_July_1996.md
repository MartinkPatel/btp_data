C. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12
July, 1996
Equivalent citations: AIR 1996 SUPREME COURT 3390, 1996 (10) SCC 193,
1996 AIR SCW 2903, 1997 CRILR(SC MAH GUJ) 258, 1996 SCC (CRI) 1205,
(1996) 6 JT 739 (SC), (1996) 6 JT 397 (SC), 1996 (6) JT 397, 1997
CRILR(SC&MP) 258, (1997) 1 EASTCRIC 814, (1997) MAD LJ(CRI) 396, (1996)
3 RECCRIR 793, (1996) 3 CRIMES 119, (1996) 3 CHANDCRIC 130, (1997) SC
CR R 64
Author: G.N. Ray
Bench: G.N. Ray
           CASE NO.:
Appeal (crl.)  52-105 of 1993
PETITIONER:
C. CHENGA REDDY AND ORS.
RESPONDENT:
STATE OF ANDHRA PRADESH
DATE OF JUDGMENT: 12/07/1996
BENCH:
G.N. RAY & DR. A.S. ANAND
JUDGMENT:
JUDGEMENT 1996 SUPP. (3) SCR 479 The Judgment of the Court was delivered by DR. ANAND, J.
This batch of appeals by special leave arise out of the Judgment and Order of High Court of Andhra
Pradesh dated 27.11.1991. The appellants in these appeals arc Executive Engineers, Deputy
Executive Engineers, Section Officers and contractors of Nellore North Division, Nellore South
Division and Gandipalem Project Division. They alongwith a Superintending Engineer (since dead)
and various con-tractors were tried for offences under Sections 120-B, 420/34, 377A/34 IPC and
Section 5(2) read with Section 5(1)(d) of the Prevention of Corruption Act and on being found guilty
were sentenced to different terms of imprisonment for the said offences. The circumstances under
which the cases arose are :
A Call Attention Motion was moved in the Andhra Pradesh Legislative Assembly in
1981 alleging large scale fraud, irregularities and il- legalities committed in the
execution of jungle clearance work by the engineers and contractors in various
divisions of Nellore District during 1978-1981. Consequent upon the Call AttentionC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

Motion, the Government directed the then Deputy Engineer-in-Chief. Shri L.R.
Kapoor PW. to examine and inquire into the allegations. He visited Nellore and after
conducting a preliminary inquiry submitted his report on 17.4.1981 pointing out
various illegalities and irregularities committed by the Engineers, The Secretary,
Irrigation Department of the Government of Andhra Pradesh also directed the then
Chief Technical Examiner. Mohd, Rahamathullak-han PW, to make an inquiry in to
the allgations made on the floor of the assembly during the Call Attention Motion. It
further transpires that the Government of Andhra Pradesh issued G.O. Ms. No. 313
Irrigation and Power Department dated 20.7.1981. Ex. P1. appointing Shri N.V.M.
Krishna, the then Chief Engineer, for carrying out departmental enquiry into the
works allegedly carried out in three Divisions, namely, Nellore North Division,
Nellore South Division and Gandipalem Project Division and the role of the
concerned engineers.
Chief Engineer Shri Krishna PW 1 submitted his report highlighting the irregularities and illegalities
as noticed by him. The case which had acquired importance on account of the call attention motion
in the legislative Assembly was then entrusted by the Government to the And Corruption Bureau
(for short ACB) for inquiry. The ACB officials conducted an inquiry and on 1.5.1982 submitted a
report. Ex. P.30 to the Director Anti Corruption Bureau with a request to register a case against the
appellants. Consequently, crime case No. 2/ACB/NLR/82 for various offences, as already noticed,
came to be registered against the appellants. The investigation was taken in hand by an Inspector of
Police ACB in May 1984. On the request of the ACB, some members of the engineering Staff of the
department were deputed to assist it for purposes of collecting technical data etc. during the
investigation. Site inspections were also carried out to find out whether any work of jungle clearance
had in fact been done in 1979 in the three divisions and the area in which jungle clearance work
could have been done in the year 1979 and the question of making payments in respect of the work
allegedly done. After completion of investigation, charge sheets were filed by the ACB against the
appellants. The Learned Special Judge, after trial of the case, found the appellants guilty of various
offences and imposed varying terms of imprisonments, including fine on different counts. The
substantive sentences were, however, directed to run concurrently. Against their conviction and
sentence the appellants filed appeals in the High Court of Andhra Pradesh. The High Court by its
judgment dated 27.111991, confirmed the conviction of the appellants on different counts but
reduced the sentence of imprisonment of the engineers to the period "till the rising of the Court".
The sentence of fine and imprisonment in lieu, thereof, as imposed by the trial court, was, however,
maintained. The appellants have since paid the fine and have undergone the sentence till the rising
of the Court. By special leave they have filed these appeals.
For facility of reference, we may mention that against the judgment of the Special Court in CC No,
1-8/87, 35 appeals were filed in the High Court by 43 appellants therein. In this Court, the criminal
appeals arising out of that case are Criminal Appeal Nos. 72 - 74/93 etc. All these cases relate to
Gandipalem Project Division. Conviction and sentence imposed in CC. 1/86 and the connected cases
before the Special Court, led to the filing of 44 appeals in the High Court by 71 appellants therein.
The Criminal appeals filed by them in this Court arc Criminal Appeal 'Nos. 128-130/93 etc. All these
relate to Nellore North Division. In respect of Nellore South Division, 68 appellants preferredC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

criminal appeals in the High Court against their conviction and sentence as recorded by the Special
judge and those cases from the hatch of Criminal Appeal Nos. 99-101/93 etc. in this Court. The
Contractors had filed separate appeals in the High Court and Criminal Appeal No. 153/93 and
170-71/93 etc. in this court arise out of the appeals filed by the contractors.
Learned counsel for the parties submitted before us that since the material facts, nature of evidence
and the questions of law are similar in all set of appeals, for the sake of convenience, four
representative appeals one from each of the three Divisions, besides an appeal by the contractors
may he taken up for consideration by us. Consequently, on their suggestion Criminal Appeal Nos ,
72-74/93. Criminal Appeal Nos. 128-130/93. Criminal Appeals Nos. 99-101/93 and Criminal
Appeal. No. 1.53/93 are taken up for consideration, as representative appeals. There are one or two
other Appeals (Criminal Appeal 170-171/93), involving slightly different factors, and we shall deal
with those also during the course of the judgment. All the appeals are, therefore, being disposed of
by this common judgment.
As a normal rule, this Court does not in exercise of its jurisdiction under Articlel36 of the
Constitution of India, while hearing appeals by special leave, reappreciate the evidence, where two
courts have concurrently appreciated the evidence and arrived at findings of guilt of the accused
persons. However in the light of the submissions made at the bar, with a view to satisfy our judicial
conscience, we have examined some of the evidence led in the cases and in particular that evidence
'which appears to have principally influenced both the trial court and the High Court to convict the
appellants. We may point out here that in all these cases, there is no direct evidence available on the
record connecting any of the appellants with the commission of the crime alleged against them. The
entire case hinges on circumstantial evidence and unfortunately neither the trial court nor the High
Court have catalogued the circumstances relied upon by the prosecution against the appellants,
except for broad generalisations on the basis of the charges framed against them.
From the prosecution case, as emerging out of the evidence of PW 1 to PW 21 and documents Ex. P1
to Ex. P 34 , it transpires that Irrigation Circle, Nellore comprises of four Divisions, namely, (i)
Nellore North Division,
(ii) Nellore South Division (iii) Gandipalem Project Division and (iv) Special Investigation Division.
During 1978-81, Shri Duggi Reddy was posted as the Superintending Engineer of Irrigation Circle,
Nellore. He was having control over all the four Divisions .Different Executive Engineers, Deputy
Executive Engineers, Assistant Executive Engineers, Sec-lion Officers and other staff were posted in
the four divisions to look after the affairs of their respective divisions. In these appeals we are
concerned with the allotment of jungle clearance work in the first three divisions of Nellore
Irrigation Circle only. The work of the clearance of the jungle is normally required to be undertaken
departmentally through Luscars, since it is treated as maintenance work, but it is the case of the
prosecution that in these cases work for clearance of jungles was allegedly allotted to contractors on
nomination basis in 1979-80 but without any such work having actually been done it was
"represented" that jungles had been cleared and payments made to the contractors, which amount
was in fact misappropriated by the departmental officials and the contractors. The total expense
involved was Rs. 1,15,663 for 12 +1 works in the Nellore North Division ; Rs. 1,95,108 for 17 works inC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

the Nellore South Division and Rs. 26,068 for 8 works in the Gandipalem Project Division.
According to the prosecution ease, the Executive Engineers were not authorised to allot work on
nomination basis to the contractors without inviting tenders but with a view to bring each of the
'contracts' within their pecuniary jurisdiction, they 'broke' the contracts into smaller amounts and
without any work of jungle clearance having been actually undertaken payments for the work shown
to have been made which were actually misappropriated by the accused thereby causing loss to the
State Exchequer and wrongful gain to themselves. The prosecution, at the trial also tried to establish
that "less work" was done though payments were made for "excessive work" and the difference in
the payments was misappropriated. There is no dispute that though the jungle clearance work was
supposed to have been done in 1979-80, the matter only came to light, through the call attention
motion in the Legislative Assembly in 1981 and even then it was not till 1984 that any physical
inspection of various sites was undertaken, except some random checks made by PW Shri Krishna
in 1982. The substratum of the prosecu-tion case has emerged out of the inspections carried out in
1984.
With this general background, we shall now take up for consideration each of the representative
appeals, as already observed. Our findings shall apply to all the appeals arising out of the concerned
division.
CRIMINAL APPEAL NOS. 72-74 OF 1993. (Gandipalem Project Division) The substratum of the
charge in these appeals, which relate to Gandipalem Project Division, is that with dishonest
intention of misappropriating Government funds, the appellants floated work for so called clearance
of Prickly Pier Jungle on the reach 15/0 to 15/4 mile on Kanpur Canal but without actual execution
of that work, made payment of Rs, 2869 to the contractor, Dunji Ramaiah. The said amount was
misappropriated and wrongful loss was caused to the Government of Andhra Pradesh. Five Officials,
besides a contractor, were arrayed in the case as accused. While Al and A2, were at the relevant time
serving as Executive Engineers, A3 and A4 were serving as Deputy Executive Engineers (formerly
Assistant Engineers) and A5 was working as the Section Officer. Shri D.B. Duggi Reddy,
Superintending Engineer, who was also arrayed as an accused, died and the case against him abated.
The contractor Dunji Ramaiya died during the pendency of the case in the trial court and the case
against him also abated. As already noticed after the call attention motion in the State Assembly, an
inquiry had been ordered into the allegations and Shri L.R. Kapoor, Deputy Engineer-in-Chief
(Irrigation P.W. was appointed as the Inquiry Officer. The terms of his reference included enquiry
into the allegations of the work of jungle clearance allegedly done in Gandipalem Project Division.
In his report, while dealing with jungle clearance work of the Kanpur Canal he stated :
"While the necessity or otherwise for jungle clearance cannot be established at this
distant date, more so without inspections of the sites of works it appears that there
was no justification for giving the above works on nomination. Even in the report
accompanying the estimates, the urgency for the execution of works has also not been
explained. Jungle clearance for the following works was done by the Executive
Engineer, Gandipalem Project Division :C. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

1, Jungle clearance along the allignment of Thikavatapadu branch channel from 3.8
km to 8.8 km - Divisional Register No. 72 of 1980-81 -Rs. 9800.
2. Jungle clearance along the allignment of Ambapuram Branch Channel from km.
2.7 to 5.6 km Divisional Register No. 347/KC of 1979-80 - Rs, 8100.
The above two estimates are for conducting site surveys of the branch channels of the Kanpur Canal
Scheme, Jungle clearance was done before doing surveys and levelling to enable the preparation of
plans and estimates for taking up the execution of the said works. The estimate indicate the urgency
for execution of the works and hence there appears to be some justification for taking up these
works on nomination. The necessity or otherwise of the jungle clearance cannot be established at
this distant date more so in the absence of site inspection."
While summing up he observed :
"The Executive Engineers, Nellore South Division, Nellore North Division and
Gandipalem Divisions are answerable for having sanctioned estimates without
inspection of the works in utter disregard to the instructions issued by the
superintending Engineer - vide Annexure No. 23 and 24".
Subsequently, Sh. N.V.M.. Krishna Chief Engineer (Investigation) PW conducted an inquiry and in
respect of Gandipalem Project Division, in his report, he pointed out certain irregularities in the
matter of allotting the jungle clearance work to 'chosen contractors' on nomination basis. He
submitted his report to the Government. It appears that the matter was simultaneously entrusted to
the ACB also who after making a preliminary inquiry submitted their report dated 1.5.82 to the
Director Anti Corruption Bureau and sought his permission to register case against the accused and
others on the allegation of making 'excessive payments'. According to the preliminary report of ACB
excessive payments had been made for jungle clearance work and that irregularities had been
committed in allotting the work on nomination basis. At the trial, however, the prosecution sought
to establish that no work of jungle clearance had been carried out at all and that the entire amount
alleged to have been spent for jungle clearance was in fact dishonestly misappropriated by the
appellants, in collusion with the .contractor.
The appellants were put on trial on the following charges :
"(i) That you the abovenamed A-l to A-5 and one D.B. Duggi Reddy formerly
Superintending Engineer of Nellore, during the year 1979-80 conspired to float the
work known as Prickly Pier jungle clearance on the banks of Kanpur Canal from mile
15/0 to 15/4 situated at a distance of 2 miles West of South Mopur, Nellore District in
violation of established rules under P.W.D. Code with intent to cheat the Govt. of A.P.
and that the said act was done in pursuance of the agreement between you all who
thereby committed an offence punishable under section 120 B of the Indian Penal
Code and within my cognizance ;C. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

(ii) Secondly, that you the above0named A-l to A-5 herein being the public servants
employed as formerly Executive Engineers, .Deputy Executive Engineers and Section
Officer of Gandhiupalem project division respectively during the period between
1979-80 at the workspot i.e. on the hanks of Kanpur canal from mile 15/0 to 15/4 as
mentioned in charge No. 1 above by corrupt and illegal means in abuse of your official
position as such public servants obtained for yourselves pecuniary advantage to the
extent of Rs.
2,869 and thereby committed an offence punishable under section 5(2) read with 5(l)(d) of the
Prevention of Corruption Act, 1947 and within my cognizance :
(iii) Thirdly, that you the abovenamed accused Nos. 1 to 5 at about the same time,
place and date as mentioned in charge No. 1 above cheated the Govt. of A.P. with
regard to the work of prickly pier jungle clearance at the banks of Kanpur canal to a
tune of Rs. 2,869 and that you thereby committed an offence punishable u/s. 420 r/w
34 of I.PC. and within my cognizance ;
(iv) And fourthly, that you the abovenamed A-l to A-5 alongwith deceased D.B. Duggi
Reddy at about the same date, time and place as slated in charge No. 1 above being
the public servants of P.W.D. Department of Govt. of A.P. wilfully and with intent to
defraud the govt. of A.P. created false records with regard to the work mentioned in
charge No, 1 above which belonged to the Govt. and you all thereby committed an
offence punishable u/s. 477-A r/w. 34 of the I.P.C. and within my cognizance."
After considering both oral and documentary evidence, the trial court, convicted the appellants for
various offences with which they had been charged. The appeals filed by the appellants, except for
reduction of the sentence was also dismissed by the High Court. In its order dismissing the appeals,
the High Court opined :
(i) during the year 1979-80. A-l to A-5 alongwith one late D.B. Duggi Reddy
conspired to flout the work known as 'prickly pier jungle clearance' on the banks of
Kanpur canal from mile 15/0 to 15/4 situate at a distance of 2 mile west of South
Mopur, Nellore district in violation of the established rules under F.W.D. Code with
intention to cheat the Government of Andhra Pradesh ;
(ii) that A-1 to A-5 being public servants obtained for themselves pecuniary
advantage to the extent of Rs. 2,869 by corrupt and illegal means by abuse of the
official position ;
(iii) that A-l to A-5 cheated the Government to the tune of Rs. 2,869 without doing
the jungle clearance work in flagrant disregard of the Codal rules ; and
(iv) that A-l to A-5 wilfully and with an intention to defraud the Government created
false records with regard to the prickly pier jungle clearance work on Kanpur canalC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

from mile 15/0 to 15/4."
We have heard learned counsel for the parties and examined some of the evidence relied upon by
the courts below, with a view to find out whether prosecution has established that "no work" of
clearance of Prickly Pier jungle was done at all and the amount was misappropriated by preparing
false documents.
From the evidence of PW 1 Shri NVM Krishna Chief Engineer (Investigation) who had conducted
the second inquiry we find that he admitted that he did not inspect any work under Kanpur Canal
and that his observations as reflected in the report Ex, P2 were not applicable to any of the works on
the Kanpur Canal. PW 4 Sheikh Mehboob Sharif, admitted in his cross- examination that during
their inspection of the site in 1984 they had noticed signs of the removal of prickly pier jungle on the
left bank of Kanpur canal. The prosecution has led no evidence to show that after 1979 any work had
been done for removal of prickly pier jungle on the banks of Kanpur canal and therefore from the
evidence of PW 4, it follows that 'some' work of clearance of prickly pier jungle at the banks of
Kanpur canal had been undertaken prior to the inspection of the site by the inspecting team. It was
rather impossible to have found out in 1984 whether any work or the extent of it, had been done in
fact for clearance Of the prickly pier jungle in 1979-80 i.e. 4/5 years ago and PW 7 Shri Raja Rao.
Commissioner of Project, rightly admitted that in case of jungle clearance after the completion of
work, it is not possible to know either the quantum of work or the extent of jungle clearance by site
inspection carried out after some time.
So far as the prosecution case that false and fictitious records relating to the preparation of
estimates, allotment of work on nomination basis, drawing up of the agreements and making
payments is concerned, we find that there are ample admissions available in the prosecution
evidence itself by various witnesses to the effect that all the estimates and agreements including the
data sheets for the estimates had been checked earlier and that no mistakes or irregularities had
been found therein. Reference in this connection may be made to the statement of PW 8 Syed
Ismail, who clearly deposed that he had checked the estimates and agreements etc. and forwarded
the same and had there been any mistake in the same, he would have reported the same to the sub
Divisional Officer for rectification but no such action was taken because no mistakes was observed.
According to Shri BVG Krishna Murthy, PW 11 who had scrutinised the bill relating to jungle
clearance work from miles 15/0 to 15/4 and had put. his initials in the measurement book also he
had not noticed any irregularity in the hill and that the corrections found in the estimates and other
documents Accompanying the estimates stood explained. It appears that while subordinate officers
had proposed clearance of larger areas, the concerned Executive Engineer had corrected the
estimates by reducing the area of jungle clearance and hence the corrections. That the Executive
Engineers had the powers to correct the estimates prepared by the Section Officers has been
categorically admitted by PW 12 K. Ram Mohan Rao in his Statement at the trial. It, therefore,
appears to us that the trial court drew on its imagination to hold that the corrections made in the
estimates and other documents established that the entries had been 'manipulated' to show that
jungle clearance work had been undertaken when it had not been so effected and that the
corrections etc. had been made by the Executive Engineers without actually visiting the site and
without making any actual verification at the spot. There is no material available on the record toC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

support the above observations. None of the prosecution witnesses deposed that the appellants did
not inspect the site before preparation or sanction-ing of the estimates for the clearance work. The
trial court, as well as the High Court, it. appears did not also correctly appreciate the true scope and
ambit of Ex. P 4(a), the statement accompanying the estimates to clear the prickly pier jungle on the
banks from miles 15/0 to 15/5 of Kanpur Canal, The statement accompanying the estimate records
that the estimates provide for clearing of the prickly pier jungle on the banks of the canal, both right
and left, "which is obstructing the jeep track"
Whether or not the clearance of jungle on the right bank was, necessary for removing
obstruction of the jeep track was immaterial and what was relevant was whether the
jungle clearance work had been undertaken or not. Making payment for clearance of
jungle on the right bank, which was not necessary may give rise to an inference that
the departmental officials had been negligent and did not act in the best interest of
the department but from that action of the officials, it is not possible to draw the
conclusion that the official committed the offence alleged against them. The
prosecution evidence reveals that the clearance of prickly pier jungle on the left and
the right bank was also undertaken with a view to properly maintain the canal banks
and to prevent their breaches during the rainy season besides facilitating the removal
of obstruction of the jeep track. The High Court conjecturised while observing that
since clearance of the right bank was not necessary for clearing the view of the jeep
track "its clearance was not done". This is against the weight of evidence on the
record.
There is not an iota of evidence led by the prosecution to prove that no work at all
was done for clearance of prickly pier jungle on the reach 15/0 to 15/4 mile on
Kanpur Canal in 1979-80. As a matter of fact, the prosecution has led evidence to
show that some work had been done but it is alleged that payments had been made
for excessive work. As already noticed during the investigation, the inspecting team
had noticed existence of signs of removal of prickly pier jungle on the banks of the
canal. There :being no evidence to show that after 1979 some work had been
undertaken for removal of prickly pier jungle on any of the banks of the canal, a
reasonable inference to be drawn would be that some work had in fact been done and
therefore the charge against the appellant that no work had been done is belied by the
prosecution evidence itself. In view of the admission of PW 7, Shri Raja Rao.
Commissioner of Projects, that in case :of jungle clearance, after the completion of
work, it is not possible to know the exact quantum of work on inspection of the site
years later, the notes made by the inspecting learn in 1984 lose all their relevance and
significance. The inferences drawn by the courts below that the estimates had been
prepared by A-5 without actually visiting the site ; that A-3 had forwarded the
estimate without actual verification at the spot and that A-1 had made corrections
without any physical verification at the spot are based on no evidence. The courts
below have relied upon surmises rather than any evidence to draw such inferences,
because none of the prosecution witnesses deposed that the appellants did not
inspect the site before preparation and sanctioning of the estimates and preparingC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

bills in respect thereof. Section Officer A-5 had proposed jungle clearance on the right
bank as well as on the left bank because he had found that jungle was obstructing the
jeep track. The courts below relied upon the entries in the log book Ex, P-19 to hold
that the verification purporting to have been done at the site was false. Neither the
driver of the vehicle, nor anyone else from the department was examined at. the trial
to prove the entries in the log book. The correctness of the log book has remained
rather doubtful. Even otherwise the absence of entry in the log book, which
admittedly was not being maintained by the accused, cannot give rise to an
irresistible conclusion that the engineers of the department did not visit the site for
actual verification. The vagueness regarding showing nature of the work or its details
or mentioning that in some places the jungle to be cleared was "light jungle" and not
"prickly pier jungle" in the measurement book also cannot lead to a conclusion, much
less an irresistible one, that the wrong mentioning had been made in the agreement
regarding the nature of the work because A-3 had not visited the site while verifying
the actual clearance of jungle on 7.7.79. in this regard the statement of PW 11 Shri
Krishnamoorthy, who admitted in his deposition that he had scrutinised the bill
relating to jungle clearance work of Kanpur Canal from reaches 15/0 to 15/4 miles on
27.8.79 assume significance particularly because PW 11 had also put his initials in the
measurement book, Ex. P6 at page 32 relating to the relevant bill. There is, therefore,
no acceptable material on the record from which a conclusive inference may be
drawn to the effect that the measurements found recorded in the measurement book
Ex. P6 had not been actually taken at the site of the work but were manipulated by
the concerned officials sitting in the office, though there may be a strong Suspicion
that it was so done. Such a strong suspicion, however, cannot take the place the proof
to fasten criminal liability on the appellants.
A careful perusal of the report Ex. P4(a) shows that the proposal that had been
prepared was for jungle clearance on both the banks of the canal and the mere fact
that subsequently the inspecting team found that no clearance was actually required
on the right bank does not militate against the probability that even though not
required, yet jungle clearance was also done on both the banks i.e., the right and left
bank, as proposed because of error of judgment or carelessness of the departmental
officials. If, the work was done, the question whether it was required to be done or
not. could not be used as an incriminatory circumstance against the appellants to
draw an irresistable inference of their guilt after excluding the hypothesis of their
innocence. We are unable to subscribe to the observation : "that there was no
necessity of clearance of jungle over the said bank as the jungle could not damage any
part of the canal and therefore the proposal for clearance of the jungle had been made
with a dishonest intention of boosting up of the area and to draw more funds from
the Government." The observations are rather conjectural and are against the weight
of evidence on. the record. Again, in vain have we searched through the evidence for
support for the observations of the courts below that the depth of the Kanpur Canal
was only 15 ft, and the length of jeep track only 203.16 sq. mts. There is no evidence
on the record to that effect and on the contrary, the evidence of PW 12 Shri K.C. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

Rammohan Rao is to the effect that the depth of Kanpur Canal at the reach between
15/0 to 15/4 miles ranges from 6.33 ft. to 9.74 ft. The inspecting agency did not take
any measurements, but adopted a method of calculating the area by multiplying the
assumed width of the jeep track with the length of the canal to hold the length of the
jeep track to be only 203.16 sq. mts, According to the case of the appellants, they had
prepared the estimates and sanctioned the work of jungle clearance for the entire
reach taking into account both the banks, inclusive of the area obstructing the jeep
track. In our opinion, the trial court quite unjustifiably found that the appellant had
failed to deduct the area occupied by the rough stone inlet. No evidence was led to
show that the rough inlet, was in existence prior to 1979 on the bank of Kanpur canal.
The mere, fact that the investigating agency in 1984, alter a period of five years,
found that a rough stone inlet was in existence was inconsequential particularly since
PW 12 Shri K. Rammohan Rao admitted during his cross-examination that he could
not say as to when the rough stone inlet found on the left bank had in fact been
constructed. There was, thus, no acceptable material on the record to establish the
existence of the rough stone inlet prior to or in 1979, when jungle clearance work was
done and no adverse inference could have been drawn against the appellants on
account of the existence of rough stone inlet on the left hank of the canal in 1984. ft
was the fact situation existing in 1979-80 which was relevant and not the situation as
existing in 1984.
One other circumstance which has been relied upon by the prosecution against the
appellants is that jungle clearance work is only maintenance work, but, it had been
allegedly allotted on nomination basis to the selected contractor, without recording
any reasons for considering the work to be of an urgent nature. This circumstance,
however, in our opinion, by Itself cannot be construed to be an incriminating
circumstance consistent only with the hypothesis of the guilt of the appellants. The
evidence on the record shows that jungle clearance work was taken up on urgent
:basis as maintenance of the canal, to avoid breaches during the rainy season on
account of the directions issued by the Superintending Engineer and the Chief
Engineer in that behalf besides for clearing the jeep track.
The appellants, according to their learned counsel, made allotment of work to the
contractor on nomination basis by virtue of the powers conferred upon the Executive
Engineer in that behalf under G.O. Ms. 1007 dated 5.11.1976. It was argued that vide
G.O. 69 dated 1.2.1978, it had been decided to allot 15% of the work to the weaker
sections of the society and the allotment of the work to Shri Dunji Ramaiah,
contractor, who admittedly belonged to the weaker section of the society, on
nomination basis, was fully justified. The evidence of PW 5, shows that entrustment
of work on nomination basis was permissible under Para 154. Note I, A.P. P.W.D.
Code also. As per G.O. Ms. No. 1007, TR & B dated 5.11.76, the limit of monetary
value fixed for entrustment of work on nomination basis to an Executive Engineer is
Rs. 20,000. The Superintending Engineer, Nellore in his Memo. 599 dated 14.4.80
had advised the Executive Engineers not to allot works costing more than Rs, 2500C. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

on nomination basis without his prior approval. It was stated that if the cost of work
exceeded Rs. 2500 it was required to be ratified by the Superintending Engineer. A-l
had himself issued a circular, Ex, P 17 to all the Assistant Engineers working under
him and to the draftsmen directing them not to propose nomination for work costing
more than Rs. 2500. A-l in his statement recorded under Section 313 Cr.P.C. stated
he had issued circular Ex, P-17 but took the unacceptable plea that the circular had
not been circulated and communicated to his subordinates and therefore it was not
followed. The finding of the courts below that A-1 to A-4 violated the codal provisions
as well as circulars and instructions issued from time to time are amply supported by
the circumstances and other material on the record. However, the non-furnishing of
reasons for entrusting the work on nomination basis up to the value of Rs. 20,000
cannot be used as a circumstance of an incriminating nature against the appellants to
establish any 'dishonest' intention on their part in view of the directions issued by the
superior officers to take up the work urgently because of the ensuing monsoon
season. Even the splitting up of work into parts, so as to allot it on nomination basis
to bring it within the authorised powers of the executive engineers, which was against
the Codal provisions and the circulars issued on the subject from time to time cannot
be said to have been done with the necessary "dishonest intention". In our opinion,
whereas the appellants are established to have violated codal provisions besides
departmental circulars and instructions regarding nomination of contractors and
allotment of work to them, yet, those circumstances cannot be said to be consistent
only with the hypothesis of the guilt of the appellants or connect them with the crime
alleged against them, in fairness to learned counsel for the appellant we must observe
that he did not challenge the findings regarding administrative lapses and :breach of
codal provisions but emphasised that for those lapses they could not be held guilty of
the criminal offences alleged against them.
The conclusions arrived at by the courts below that the official appellants did not
follow the codal provisions and that they have committed gross financial
irregularities and administrative lapses in the matter of clearance of the prickly pier
jungle under Kudimaramath Rules and other relevant provisions cannot be faulted
with but nonetheless, the same cannot be construed as "incriminating circumstances"
to fasten criminal liability on the appellants.
It appears to us that the trial court and the High Court were greatly influenced by the
technical report Ex. P-11 prepared by FW 12 Shri K. Ram Mohan Rao to hold the
appellants guilty. In this report, PW 12 inter alia pointed out various irregularities
committed by the appellants while preparing the estimate, nomination of the
contractor for the. execution of the work and drawing up of the agreement with the
contractor etc. He also opined that the corrections had been made in the estimate Ex.
P 4 with a view to conceal facts and project a false fact-situation. This report is sheet
anchor of the prosecution case but in our opinion it could not have been relied upon
as it was dearly inadmissible in evidence and the opinion of the High Court to the
contrary is not acceptable. PW 12 Shri K. Ram Mohan Rao was serving in theC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

Irrigation Department when he was entrusted with the task of assisting the
investigating officer of ACB during the investigation in this case. Perusal of Ex. P 32
shows that he had been issued specific orders to report to the ACB and assist the
investigation agency. He prepared his report Ex. P-12, during the course of the
investigation and submitted it to PW 19, the investigating officer on 30th June, 1984
after the FIR in this case, Ex. P-24, was registered by PW 19 on 17.5.1982. PW 12 was
examined by the investigating officer after he had Submitted the report and his
report, forms a part of his statement recorded by ACB under Section 161 Cr.P.C
Under these circumstances the observations contained in report Ex. P 11, which
technically and factually form a part of the statement of PW 12, recorded during the
investigation of the case by PW 19 is, hit by Section 162 Cr.P.C. No statement made
by any person to a police officer during the course of investigation can be used for any
purpose at any enquiry or trial in respect of any offence under investigation at the
time when such statement was made, except for the purpose of contradicting a
witness as provided under Section 145 of the Evidence Act. Admittedly, Ex. P 11 has
not been used for any of the purposes envisaged by Section 145 of the Evidence Act
but as a substantive piece of evidence. The opinion of the courts below that the
statement contained in Ex. P 11 was not hit by Section 162 Cr.P.C. on the ground that
PW 12 was an expert within the meaning of Section 45 of the Evidence Act and his
report Ex. P 11 submitted to the investigating officer was as such not hit by Section
162 Cr.P.C. is clearly erroneous as PW 12 does not qualify as an expert within the
meaning of section 45 of the Evidence Act. Even in his own deposition, he has no
where stated about his technical 'qualifications', "expertise" or "experience" in this
particular field to render "expert opinion". There is no material on the record to show
that PW 12 possessed any particular skill which entitled him to "draw conclusions"
relevant to the matter entrusted to him by the investigating officer. We are, therefore, of the opinion
that PW 12 is not an 'expert' within the meaning of Section 45 Evidence Act and Ext. P 11 was hit by
the bar of Section 162 Cr.P.C. and was inadmissible in evidence and could not have been relied upon
in the criminal trial to fasten criminal liability on the appellants.
in a case based on circumstantial evidence, the settled law is that the circumstances from which the
conclusion of guilt is drawn should be fully proved and such circumstances must be conclusive in
nature. Moreover, all the circumstances should be complete and there should be no gap left in the
chain of evidence. Further, the proved circumstances must be consistent only with the hypothesis of
the guilt of the accused and totally inconsistent with his innocence. In the present case the courts
below have overlooked these settled principles and allowed suspicion to take the place of proof
besides relying upon some inadmissible evidence.
On a careful consideration of the material on the record, we are of the opinion that though the
prosecution has established that the appellants have committed not only codal violations but also
irregularities by ignoring various circulars and departmental orders issued from time to time in the
matter of allotment of work of jungle clearance on nomination basis and have committed
departmental lapse yet. non of the circumstances relied upon by the prosecution are of anyC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

conclusive nature and all the circumstances put together do not lead to the irresistible conclusion
that the said circumstances are compatible only with the hypothesis of the guilt of the appellant and
wholly incompatible with their innocence. In Abdulla Mohammed Pagarkar v. State (Union
Territory of Goa, Daman and Diu), [1980] 3 SCC 110, under somewhat similar circumstances this
Court opined that mere disregard of relevant provisions of the Financial Code as well as ordinary
norms of procedural behaviour of government officials and con-tractors, without conclusively
establishing, beyond a reasonable doubt, the guilt of the concerned officials and contractors, may
give rise to a strong suspicion but that cannot be held to establish the guilt of the accused. The
established circumstances in this case also do not establish criminality of the appellants beyond the
realm of suspicion and, in our opinion, the approach of the trial court and the High Court to the
requirements of proof in relation to a criminal charge was not proper. That because of the actions of
the appellants in breach of codal provisions, instructions and procedural safeguards, the Stale may
have suffered financially, particularly by allot-ment of work on nomination basis without inviting
tenders, but those acts of omission and commission by themselves do not establish the commission
of criminal offences alleged against them. We may reiterate that once the report, Ext, P 11, is ruled
out of consideration as inadmissible, then it is not safe to rely on the mere impressions of the
witnesses to hold the appellants guilty of the offences alleged against them. The prosecution has
failed to establish that in 1979-80, no work of jungle clearance in the Gandhipalem Project Division
was undertaken and that false and fabricated documents were prepared with a view to
misappropriate government funds. The prosecution has not even been able to establish that less
work of jungle clearance was undertaken but payment was shown to have been made for excessive
work and some amount out of the payments made for the work were thus misappropriated by the
appellants in connivance with the con-tractors. The conviction and sentence imposed against the
appellants (which had been reduced by the High Court to a token sentence) under the circumstances
cannot be sustained and we accordingly accept the appeal and set aside their conviction and
sentence. Fine paid by the appellants shall be refunded to them, Criminal Appeal Nos. 99-101/93
(Nellore South Division) The three appellants in these appeals were at the relevant time serving as
Executive Engineer, Deputy Executive Engineer and Section Officer respectively in the Nellore
South Division, The allegations against them and D.B. Duggi Reddy, Superintending Engineer (since
dead) relate to the clearance work undertaken in the year 1979 in respect of Juliflora Jungle at North
Mopur, Large Tank 1800 M to 2000 M in Kovur Taluk, Nellore District, The contract with regard to
the clearance of the jungle work was given by the accused Executive Engineer, to the accused
contractor on nomination basis for which payment was made on alleged completion of the clearance
work though in fact no payment should have been made as 'no work' was done and the entire
amount was misappropriated by the appellants and the contractor. The contractor has filed a
separate appeal. The accused were put to face their trial on the following charges :
"(i) That you, the above named A1 to A4 herein and one D.B. Duggi Reddy (deceased
Superintending Engineer) during the year 1979-80 conspired to float the work known
as Clearing and uproot-
ing the jungle at North Mopur, Large tank from 1800 M to 2000 M in Kovur Taluk, Nellore District
in violation of established rules under PWD Code, with intent to cheat the Govt of A.P. and that the
said act was done in pursuance of the agreement between you all and thereby committed an offenceC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

punishable u/s, 120-B of the Indian Penal Code and within my cognizance.
(ii) Secondly, that you the above named Al to A3 herein being public servants employed as formerly
Executive Engineer. Dy. Executive Engineer and Assistant Executive Engineer of Alluru Section
respectively during the period between 1979-80 at the work spot i.e. North Mopur large lank from
1800 M to 2000 M mentioned in charge No, 1 above by corrupt and illegal means in abuse of your
official position as such public servants obtained for yourselves or for A4 pecuniary advantage to the
extent of Rs. 13,164 and thereby committed the offence punishable u/s. 5(2) r/w. 5(l)(d) of the
Prevention of Corruption Act, 1947 and within my cognizance,
(iii) Thirdly that you the above named Accused Nos. 1 to 4 herein at about the same time, place and
date as mentioned in charge No. 1 above cheated the Govt. of A.P. with regard to the work of clearing
and uprooting the jungle at North Mopur large tank from 1800 M to 2000 M to a tune of Rs. 13,164
and that you thereby committed an offence punishable u/s. 420 r/w. 34 of the IPC and within my
cognizance.
(iv) And, fourthly, that you the abovenamed accused Nos. 1 to 4 herein along with deceased D.B.
Duggi Reddy at about the same date, time and place as stated in charge No. 1 above being the public
servants and contractor respectively of P.W. Department of the Govt. of A.P. wilfully and with intent
to defraud the Govt. of A.P. created false records with regard to the work mentioned in charge No. 1
above which belonged to the Government and you all thereby committed an offence punishable u/s.
477-A r/w. 34 of IPC and within my cognizance."
After trial, the learned Special Judge recorded the finding that no work with respect to the clearance
and uprooting of the stumps of Juliflora jungle was undertaken at North-Mopur large tank and that
the entire contract had been given surreptitiously and payments misappropriated and convicted the
appellants and the contractor for offences under Sections 120-B JPC, 420/34 IPC, 477 A/34 IPC as
well as for offences under Section 5(2) read with 5(l)(d) of the Prevention of Corruption Act. The
accused were sentenced as follows :
"A.I to A.4 to undergo RI for a period of one year each for the offence u/s. 12GB IPC;
RI for a period of two years each and to pay a fine of Rs, 1000 each i/d to undergo RI
for 4 months each for the offence u/s. 420 IPC r/w. 34 1PC; RI for a period of two
years each for the offence u/s. 477-A IPC r/w. 34 IPC and further sentenced Al to A4
to undergo RI for a period of 2 years each and to pay a fine of Rs. 1000 each i/d to
undergo RI for 4 months each for the offence u/s. 5(2) r/w. 5(l)(d) of Prevention of
Cor- ruption Act, The sentences shall run concurrently.
I further direct that the sentence imposed on Al in this case is ordered to run
concurrently with the sentence of imprisonment imposed on him in CC. 9/86 to
21/87 and 23/87 to 25/87. The sentence of imprisonment imposed on A2 in this ease
is order to run concurrently with the sentence of imprisonment imposed on him in
CC. 9/87 to 14/87 and 19/87 to 21/87. The sentence of imprisonment imposed on A3
in this case is ordered to run con- currently with the sentence of imprisonmentC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

imposed on him in CC. 1/86."
The High Court in appeal by the appellants against their conviction arid sentence held :
"On a reappraisal of the entire evidence on record, both oral and documentary, and
on a consideration of the conclusions reached by the trial court, this court feels that
the prosecution has made out the case under Sections 120-B, 420 read with 34 and
477-A read with 34 IPC against Al to A4 and under Section 5(2) read with 5(1) (d) of
the Prevention of Corruption Act against Al to A3, and the convictions thereunder are
confirmed........Hence, AI and A3 are sentenced for the offences under Section 120-B,
420 read with 34 and 477-A read with 34 IPC and Section 5(2) read with 5(l)(d) of the
Prevention of Corruption Act till the rising of the Court and each of them is further
sentenced to pay additional fine of Rs. 1000 (rupees one thousand) under each count
in addition to the one imposed by the Court below under Section 420 read with 34
IPC and Section 5(2) read with 5(l)(d) of the Prevention of Corruption Act. in default
to suffer R.I. for three months under each count.
Time granted for payment of fine is one month from today.
As regard the sentence to be inflicted on the contractor, A4 who has been charged
and tried for the offences along with Al to A3, who are Government employees the
same yardstick cannot be used. With the active connivance and A4 alone, Al to A3
have committed the offences and A4 assisted them by subscribing him-self to the
agreement and other documents. So, A4 must be dealt with severely. Hence, A4 is
sentenced for the offences under Section 120-B, 420 read with 34 and 477-A read
with 34 IPC to suffer rigorous imprisonment for six months under each count and the
sentence of fine imposed by the learned Special Judge under Section 420 read with
34 IPC is confirmed. All the sentences of imprisonment shall run concurrently."
The High Court then arrived at the following conclusions :
"(i) during the year 1979-80, Al to A4 along with one late D.B. Duggi Reddy conspired
to float the work known as clearance and Uprooting of jungle on North Mopur large
tank from 1800 M to 2000 M 1/1 mile to 1/2 mile of Kovur taluk in Nellore district, in
violation of the established rules under PWD Code, with intention to cheat the
Government of Andhra Pradesh;
(ii) Al to A3 being public servants, obtained for themselves and for A4 pecuniary
advantage to the extent of Rs. 13,164 by corrupt and illegal means by abuse of their
official position;
(iii) Al to A4 have cheated the Government to the extent of Rs, 13,164 without doing
the work of clearance and uprooting of jungle on North Mopur large tank, Kovur
taluk, in flagrant disregard of the Codal rules; andC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

(iv) Al to A4 wilfully and with intention to defraud the Govern-ment, created false
records with regard to the work of clearance and uprooting of jungle on North Mopur
large tank."
Prosecution in support of its case examined 24 witnesses while the appellants examined two in their
defence. The prosecution relied upon a number of documents Ex. P1 to Ex. P31.
Like the case of the appellants connected with Gandipalem Project Division, the case against the
appellants herein is also based only on circumstantial evidence. Apart from the oral evidence, the
prosecution relied upon five basic documents viz., estimate (Ex. P3); the contract (Ex.P4); the bill
(Ex. P7); payment order (Ex. P8) and the technical report given by PW 8 (Ex, P10) to connect the
appellants with the crime. According to the prosecution, no work at all had been done for jungle
clearance at North Mopur and Exs. P3, P4, P7 and P8 were fabricated and manipulated with the
dishonest intention of appropriating funds amounting to Rs. 13,164.
The circumstances (as can be culled out from the judgment of the courts below) relied upon by the
prosecution and accepted by the courts below to convict the appellants are :
(i) that the clearing and uprooting of jungle at North Mopur could not be given on
nomination basis and that the tenders which should have invited for allotment of that
work were not floated with a view to misappropriate Government funds;
(it) that no reasons were given for allotting the work on nomination basis in breach of
codal provisions;
(iii) that the work was allegedly started by the contractor before issuance of work
order;
(iv) that incorrect measurements were recorded in the measurement book to cancel
the extent of actual work done;
(v) that A2 and A3 made endorsements on the estimate documents :without
conducting actual verification at the spot;
(vi) that no proper estimate for earth work or for filling of the pits was prepared;
(vii) that the anticipated credit for stumps as shown was wrong.
On the basis of the aforesaid circumstances, the prosecution at-tempted to establish that no work of
jungle clearance was done and that Ex. P3, P4, P7 and P8 were manipulated and fabricated with
dishonest intention of misappropriating funds of the Government. Reliance was placed on the
statement of PWs 1.1, 12 and 13 in support of the circumstances that no jungle clearance work was
done and that the modus operandi adopted by appellants to give the work on nomination basis
ignoring the codal provisions and instructions on the subject was only to cover the fraud committedC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

by the appellants in connivance with the contractor. PW 11 deposed that jungle clearance work is not
of an urgent nature implying thereby that it could not have been alloted without floating tenders on
nomination basis. To the same effect is the evidence of PW 12 who went on to add that normally
Jungle clearance work is taken up under the category of maintenance work which is undertaken
departmentally through laskars. PW B also deposed that out of the funds allotted for maintenance
work, jungle clearance work-is required to be undertaken. The prosecution, however has led no
evidence to show that the jungle clearance work was undertaken departmentally in 1979 or that no
jungle clearance was re-quired to be undertaken in 1979.
From the evidence on the record it transpires that pre- measurement of the work was done on
8.1.1,79; estimate was prepared by A3 on 22.11.79; a proposal to allot work on nomination lo A4 was
made. The proposal was forwarded by A2 to Al on 25.11.79. A1 approved the proposal on 15.12.79 to
allot the work on nomination basis to A4. PW 6 in his statement admitted that he had examined Ex.
P3 and Ex. P4 in 1979-80 and that ex-fade he had not found anything wrong in the procedure
followed for allotment of jungle clearance work on nomination basis and therefore he did not point
out any irregularity at that, time. Even PW 5 who had scrutinised the estimate contained in Ex. P3 in
1979 deposed that he had not found anything wrong therein. The evidence of FW 5 and PW 6, thus,
does not support the prosecution case that the documents were fabricated and entire amount
misappropriated. Thought PW 11, 12 and 13 deposed at the trial that jungle clearance work is not
work of an urgent nature and is only maintenance work but we find that none out of them deposed
that the work being maintenance work, it was actually carried out by laskars of the department. The
assertion of PW 8 in his technical report, Ex. P'10, that there were no signs of jungle clearance when
he visited the site in 1984 cannot lead to the conclusion, must less an irresistible conclusion, that in
1979-80 jungle had not been cleared at the site. There is ample evidence on the record to show that
jungle clearance work had been done in 1979-80. The statement of PW 17 Assistant Engineer, shows
that jungle clearance work was being done in 1979-80. If that be so, it was obligatory on the part of
the prosecution to lead evidence to show as to who carried out the work. No evidence has been led to
show that the work of jungle clearing was done by departmental laskars and the very fact that work
had been done shows that the prosecution allegation that no work was done has remained
unsubstantiated. So far as allotment of work on nomination basis is concerned, the prosecution does
not dispute that urgent works could be allotted on nomination basis. The Chief Engineer admittedly
had issued instructions to have the jungles cleared In view of expected monsoon and therefore the
urgency of the matter, is quite obvious. There is also no reliable evidence available on the record to
show that work done was less than the work paid for as is alleged by the prosecution.
The report Ex, P10 submitted by PW 8 which is the sheet anchor of the prosecution case, for the
reasons which we have already given while dealing with Criminal Appeal of the Gandipalem Project
Division not admissible .in evidence. All the reasons given therein apply to Ex. P10 with equal force
and we need not repeat the same. Even otherwise report Ex. P10, prepared after visiting the site in
1984 to demonstrate the position as was supposed to be existing at the site in 1979-80 is hardly of
any value.
According to the prosecution case, the extent of work shown to have been done by the contractor for
which payment was allegedly made to him was not possible to be done in the short period in which itC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

was shown to have been done and this fact exposed the fabricated nature of the documents. This
plea of the prosecution is again based on the inadmissible-technical report Ex, P10. In our
considered view PW 8 adopted a defective method to work out the details of the work done and on
that basis no reasonable conclusion is possible to be drawn to the effect that no work of jungle
clearance was in fact done in 1979-80.
Ex. P1 and P2, panchnamas, relied upon by the prosecution and accepted by the courts below for
ascertaining the time taken for clearing the jungle on the basis of work done by a labourer in a day
do not help the prosecution. Apart from the fact that it is doubtful whether Ex. P1 and P2, the
panchnamas, prepared during the investigation of the case can be used as substantive piece of
evidence, since none of the labourers who are alleged to have done the clearing work were examined
at the .trial, we find it even otherwise an unsatisfactory manner of determining the time taken for
work of jungle clearance. How much work one labourer can turn out would depend upon a number
of factors like his skill, energy, experience etc. ? Generalisation as has been done by the prosecution
and accepted by the courts below is neither fair nor proper.
The prosecution also sought to establish that the accused had no power to allot work on nomination
basis and that they adopted this mode only as an eye wash to cheat the Government and
misappropriate the funds; The High Court and the trial court failed to properly appreciate the
evidence on the record in this behalf also while drawing an inference of criminality. The courts
below while accepting this plea of the prosecution failed to appreciate that vide GOMS No. 1007
dated 5,11.76 the Executive Engineer had been empowered to entrust work on nomination basis
upto the value of Rs. 20000 and that GOMS No 1007 was in force at the relevant time. Mr. L.R.
Kapoor, Commissioner Command Area Development Government of A.P. PW 10, stated :
"GOMS No. 1007, dt. 5.11.76 relating to the powers of the Executive Engineers in
entrusting the works on nomination is still in force. I have referred to this GO as Ann.
29 in Ex. P.16. This GO is not yet repealed and it is still in force. Under this GO the
Executive Engineer can entrust the work on nomination basis costing Rs. 20000."
That the appellants ignored certain other instructions on. the subject cannot lead to an irresistible
inference that they did so with dishonest intention only.
That the appellants adopted a wrong mode and procedure in making two separate items in the
estimate for clearing the jungle above the ground level and for uprooting the stumps has not been
accepted even by the Board of Chief Engineers vide its proceedings dated 21.7.84, May be, as alleged
by the prosecution clearing of the jungle and up-rooting of stumps may be one operation and
making two separate payments, that is one for clearance of jungle above the ground level and the
other for up- rooting and removing the stumps may be objectionable and against the codal
provisions but in the absence of any evidence to show that two separate payments were in fact not
made to the contractor it is not possible to say that the charge of conspiracy has been established.
The statement of PW 20 Superintending Engineer who admitted that separate payments for
up-rooting the stumps of Juliflora are also permissible under Rule III(2)(f) of Standard Schedule of
Rates lends support to the defence plea rather than to the prosecution version. PW 12 and PW 16C. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

have given a lie to the prosecution case as projected at the trial and none of those witnesses was
declared hostile.
It appears to us, Chat influenced by the inadmissible report Ex. P10, the courts below concluded that
the appellants had committed the offence alleged against them. None of the witnesses except PW 8,
who as already noticed, was not competent to depose in that behalf before he visited the site only in
1984 and not prior thereto have stated that no work of jungle clearance was done at the site and the
allegation with regard to less work having been done is based upon calculations made five years later
by PW 8, which does not afford conclusive evidence against the appellants. It is a .matter of
common sense and even the prosecution witnesses have accepted that it was impossible to know in
1984 whether jungle clearance .work had been carried out and if so to what extent in the year 1979
on the basis of an inspection carried out five years later in the years 1984. The maximum that can be
said against the appellants is that they committed some indiscretion in the matter of allotment of
jungle clearance work on nomination basis and also violated codal provisions in the matter of
preparation of estimates, drawing up of the agreements and making payments. These acts of
omission and commission do give rise to a strong suspicion that the appellants so acted with a view
to misappropriate Government funds but suspicion, however, strong cannot take the place of proof.
The prosecution has in our opinion failed to establish the case against the appellants beyond :a
reasonable doubt. The conviction and sentence imposed upon the appellants under the
circumstances, cannot be sustained and we accordingly accept the appeal and set aside their
conviction and sentence. Fine shall be refunded to the appellants.
CRIMINAL APPEAL NOS. 128-130 OF 1993 (NELLORE NORTH DIVISION) These appeals arise
out of Crime Case No. 1 of 1986 and relate to the clearance of Juliflora jungle on Krakatur small tank
.on the reach 0/0 to 1450 meters.
The prosecution case against the appellants A2 (Executive Engineer), A3 (Deputy Executive
Engineer) and A4 (Assistant Executive Engineer), who were tried along with Al Superintending
Engineer (since dead) and A5 the contractor who has filed a separate appeal, is that with dishonest
intention of misappropriating Government funds, the accused floated work called clearance of
Juliflora jungle and up-rooting slumps having width of 50 cms. to 100 cms. on the reach 0/0 to 1450
metres on Krakatur small tank and without execution of that work misappropriated an amount of Rs
5169 allegedly paid to the contractor A5 by cheque by entering into a criminal conspiracy with him.
The matter like the cases of Gandipalem Project and Nellore South Division came to be entrusted for
investigation, after the Call Attention Motion was moved in the State Assembly in 1.981, alleging
large scale bungling and embezzIement of government funds in various Division of Nellore District
for clearance of jungles etc. !o the ACB. We have already referred to the history of the case in the
beginning of the judgment and need not repeat the same.
PW 7 Sh. L.R.. Kapoor, Commissioner Command Area. Develop-ment, Govt. of Andhra Pradesh who
was appointed to enquire into the allegations made on the floor of the House after holding an
inquiry made the report in which he expressed his opinion thai jungle clearance work ought to have
been given by calling tenders instead of resorting to allotment on nomination basis and that the
procedure adopted by the appellants was against the codal provisions. Subsequently, the ChiefC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

Engineer Irrigation Department (Investigation) Sh, N.V.M, Krishan PW 9 who also made an inquiry
submitted his report pointing out various irregularities committed in the preparation and
sanctioning of the estimates; nomination of the agencies; conclusion of the agreements in violation
of A.P, PWD Code, AP Financial Code and AP Public Works Accounts Code besides departments,
instructions and circulars. Subsequently, the case was entrusted to ACB and the investigating officer
of the ACB took up the investigation in 1984. At the request of the ACB, assistance of engineering
staff was provided and the departmental official assisting ACB submitted his report during the
investigation of the case and the accused were sent up for trial. Following charges were framed by
the learned Special Judge on 17.1.1987:
"That you above named A-2 to A-5 and one D.B. Duggi Reddy (deceased A-l) during
the year 1979-80 conspired to float the work known as juliflora jungle clearance at
Krakatur Small Tank situated at a distance of 1 KM West of Krakatur in violation of
the village rules under P.W..D. code with intent to cheat Government of Andhra
Pradesh and that the said act was done in pursuance of the agreement between you
all and you all thereby committed an offence punishable under Section 120-B of the
Indian Penal Code and within my cognizance: Secondly that you above named
accused A-2 to A-4 being servants employed as former Executive Engineer, Deputy
Executive Engineer and Section Officer of Nellore North Division respectively during
the period between 1979-80 at the work spot i.e., Krakatur small Tank mentioned in
charge No, 1 above by corrupt an illegal means in abuse of your official position as
such public servants obtained for yourselves or for A-5 and yourself pecuniary
advantage to the extent of Rs. 5,169 and thereby com-milted the offence punishable
under Section 5(2) r/w. Section 5(l)(d) of the Prevention of Corruption Act 1947 and
within my cognizance;
Thirdly that you the above named accused A-2 to A-5 at about the same time place
and date cheated the Government of A.P. with regard to the work of Juliflora jungle
clearance at Krakatur small Tank to a tune of Rs. 5,169 and that you thereby
committed an offence punishable under Section 420 (PC r/w. 34 of the Indian Penal
Code and within my cognizance;
Fourthly that you the above named accused A-2 to A-5 along with deceased A- l by
name D.B. Duggi Reddy at about the same date, time and place as stated in charge
No. 1 above being the public servants and contractor of P.W.D. Department of
Government of A.P, willfully and with intent to defraud the Government created false
records with regard to the work mentioned in charge No, 1 above which belonged to
the Government and you thereby committed an offence punishable under section
477-A IPC ,r/w. 34 of the Indian Penal Code and within my cognizance.
And I hereby direct that you all be tried by me on the above said charges."
Prosecution in support of its case examined 28 witnesses besides relying upon a number of
documents. The accused on the other hand examined two witnesses in defence. The trial court at theC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

conclusion of the trial held that no work with respect to clearance of Juliflora jungle up-rooting of
the stumps was undertaken at the site and the amount was misappropriated by the accused and
convicted and sentenced the appellants to various terms of imprisonment and fine.
The appeals of the appellants, except in the matter of sentence, failed in the High Court.
Like the cases of Gandipalem Division and the Nellore South Division, in this case also no evidence
has been led by die prosecution to show that no work of jungle clearance was at all undertaken. PW
8 and PW 9 who deposed that jungle clearance work had been done in 1979-80, were declared
hostile, nonetheless we find that the prosecution has led no other evidence to show that in fact no
work had been done at the site in question. Since, the prosecution witnesses admitted in their
evidence that some work had been done, the charge of conspiracy must necessarily fail. Recourse
has been made to surmises and conjectures by the courts below to hold that no work was found to
have been undertaken at the site when it was inspected in 1984. PW 7 Sh. L.R, Kapoor and PW 19
Shri N.V.M. Krishna who had inquired into the matter before the case was entrusted to the ACB
have categorically admitted at the trial that they had not visited the site in question at the time of
conducting the inquiry. According to Sh. L.R. Kapoor, PW 7 not only he did not visit the site in
question but he did not even examine a single witness at the time of conducting inquiry relating to
the work at the site. The prosecution has alleged and tried to establish that there had been flagrant
violations of the codal provisions in regard to preparation and sanctioning of estimates, nomination
of the agency and allotment of work on nomination basis, preparation of the bills and passing of the
same pursuant to an agreement wrongly drawn up between the parties. According to the courts
below, the commencement of the work by the contractor before drawing up the agreement between
the parties exposed the criminal conspiracy between the accused.
It appears to us that the courts below like in the case arising out of Gandipalem Project Division and
Nellore South Division allowed suspicion to lake the place of proof to convict the appellants. No
evidence has been led by the prosecution to show the reaction of the department to the allegations
made on the Floor of the House in 1981 itself. Till 19S4, after the case was registered no inspection
of the site was undertaken by the ACB, No examination of the site except for some random check by
Mr. Krishna in 1982 was also done and, thus, we find that for a period of almost five years nothing
was done to verity the correctness or otherwise of the allegations relating to jungle clearance work.
Could the sites have depicted the state of jungle and the presence of Juliflora or its extent as it
existed in the year 1979 during the inspection made in 1984 ? The answer to us appears clearly to
be in the negative. Even the Chief Engineer and the Superintending Engineer admitted during their
cross- examination that it was not possible to know in 1984 if Juliflora jungle actually existed at the
site in question in 1979-80 or not. We fail to understand as to why after the case had been entrusted
to the ACB in 1982 itself they took no steps to visit the site and ascertain about the situation of the
site till J984, The prosecution witnesses have admitted that there were jungles of Juliflora on the
bank in 1979. There also does not appear to be any justification for the prosecution to now allege
that the area from which jungle had been cleared in 1979 was less than what was actually entered in
the measurement book on the basis of the site inspection carried out in 1984. The omission on the
part of the department and the ACB to immediately inspect the site is a serious lacuna in the
prosecution case, Prosecution has tried to make much capital out of the fact that the contractorC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

allegedly started work of jungle clearance even before the formal agreement was drawn up. From the
evidence of PW 10, PW13 and PW 20 it emerges that when work is entrusted on nomination basis to
a contractor he may commence the work, on oral instructions, even before the formal agreement is
drawn up. The agreement Ex. P5 itself shows the entrustment of the work to have been done to the
contractor before the conclusion of the agreement and therefore no adverse inference can be drawn
against the contractor or the appellants for commencing the work before drawing up of the formal
agreement. The Deputy Executive Engineer PW 13 admitted in his cross-examination that
entrustment of work before conclusion of the agreement is not irregular and has been resorted to in
other cases also, PW 20 who was at the relevant time Chief Engineer (Irrigation) stated in his
deposition that in cases of urgency, the competent authority could direct commencement of the
work before completion of the formalities of executing the agreement. Even though PW 14 Mr. C.
Janardhana Rao, Chief Engineer (minor Irrigation) was declared hostile by the prosecution, yet, we
find that his categorical admission in the cross-examination to the effect that in his capacity as Chief
Engineer he had addressed a letter, as early as on 26.4.1981, to the Secretary Irrigation and Power
Department stating therein that jungle clearance work in Nellore District, which would include the
Nellore North Division also, had been done properly and the work had been allotted within the
powers of the Executive Engineer, has not been contradicted by any other evidence.
Besides, PW 17 admitted that he did not find any mistake when he audited the bill pertaining to the
work in question while PW 12, the head draftsman of the Irrigation North Division categorically
deposed that while scrutinising the estimate Ex. P4, Cor showing the removal .of stumps of Juliflora
as a separate item he hud not raised any objection in view of the provisions of Rule 2(f) of the 1979
Rules. It appears to us that the exercise undertaken in 1984 alter a lapse of five years was a futile
exercise because once a jungle has been cleared and stumps, up-rooted, nothing would remain as
evidence on the soil to show the extent to which the jungle was cleared 5-6 years :earlier. It would
not even be possible to say whether there was any necessity for jungle clearance at that earlier point
of time. Much capital was sought to be made by learned counsel for the State of including the area
of revetment as a part of the area from where jungle was shown to have been cleared to urge that
since there could be no growth of jungle on the revetment, the measurements were falsely recorded
and the criminality had got exposed. We cannot agree. In this connection we find that the
state-ment of PW 13 is somewhat relevant. He admitted that if the branches of Juliflora spread over
the revetment area than that has also to be cleared and the area over the revetment will also have to
be calculated for deter-mining the total area of jungle clearance. He went on. to say that in a
disturbed revetment there is even otherwise the possibility of the growth of Juliflora. Since, PW 7
Mr, L,R. Kapoor who had visited the site during 4,4,1981 to 6.4.81 for conducting preliminary
inquiry stated in his report that it was not possible to find out during the inquiry held in 1981
whether there in fact existed any necessity for jungle clearance at the site or not, we fail to see how
in 1984 the departmental officials assisting the ACB could categorically report about the
non-existence of the necessity for jungle clearance in 1979. It is a matter of common knowledge
which is not disputed even by the prosecution that Juliflora does not grow in an orderly manner but
is a wild growth. Therefore, the extent of the jungle which was required to be cleared in 1979 on the
basis of "paper calculation" or inspection carried out in 1984 was not possible to be determined.C. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

Indeed, jungle clearance work is a part of maintenance work. But there is nothing on the record to
show that it was so undertaken departmentally in 1979-80. It was under the instructions of the
Superintending Engineer contained in circular memo No. 2Q21-G2 dated 29.12.1978 that the jungle
clearance work was treated as urgent work, to prevent breaches during the rainy season and avoid
damages to the tank bunds and therefore no fault can be found with A2 for not recording reasons for
treating the work as of urgent nature and allotting it on nomination basis. The reasons we have
given while dealing with the appeals from Gandipalem Project and Nellore South Division, to hold
that. the prosecution has failed lo establish its case against the appellants beyond a reasonable
doubt also apply to these appeals with equal force. Whether the measurements were recorded in the
measurement book after actually visiting the site or not would only be violation of the statutory
circulars and instructions. It may even be violative of the codal provisions but in the absence of any
evidence, direct or circumstantial, to establish that without any work having been undertaken at the
site, payments were allegedly made, no offence can be said to have been established. That the
'departmental officials did not go to the site is a possible inference which may be drawn from the
fact that divisional vehicle did not go up to the site but again the same cannot be construed as
sufficient to establish criminal conspiracy between the parties. The argument of learned counsel for
the State that two payments were not permissible for clearing jungle and stumps separately only
show the violation of codal provisions and commission of irregularities but that does not by itself
establish any criminality in so far as the appellants are concerned. In our opinion none of the
circumstances relied upon by the prosecution connect the appellants with the crime alleged against
them. The circumstances have not: been proved beyond a reasonable doubt and the circumstances
taken collectively cannot be said to be compatible only with the hypothesis of the guilt of the
appellants and totally incompatible with their innocence. Under the circumstances we are of the
opinion that the prosecution has not established the case against the appellants beyond a reasonable
doubt. Their appeals therefore succeed and are allowed and their conviction and sentence are set
aside. Fine shall be refunded to the appellants.
CRIMINAL APPEAL NO. 153 OF 1993 (NELLORE SOUTH DIVISION - CONTRACTOR'S APPEAL)
This appeal has been filed by the contractor A4, and arises out of :Crl. Case No. 9/87 (High Court
Appeal No. 184/89). It relates to clearance of Juliflora jungle from 0 to 1 mile including removal of
14800 stumps in Nellore South Division. The jungle clearance work was allotted lo the appellant by
the Executive Engineer on nomination basis. On completion of the work, the appellant submitted
his bill and an amount of Rs. 15643 was paid to him. According to the prosecution case, A1 to A3
entered into a criminal conspiracy with A4 and without actually doing any work of jungle clearance
obtained payment of Rs. 15643 and that amount was shared by all the accused and with a view to
cover up the misappropriation, records were fabricated. It is alleged that the jungle clearance work
could not have been allotted to the appellant on nomination basis without floating tenders and even
the nomination of the appellant as the contractor was made in violation of the codal provisions since
Al did not even assign any reason for giving the work on nomination basis and had not obtained any
sanction from the higher authorities to allot work on nomination basis.
Learned counsel for the appellant Mr. Nambiar submitted that the estimate was sanctioned by Al on
the basis of an estimate prepared by A3 and counter singed by A2. The estimated value of the work
was Rs. 18500 but that amount was, however, slashed and in the agreement concluded with theC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

appellant on 25.1.80, Ex. P5, the amount was shown as Rs. 15643 and these facts were indicative of
the bonafides of the officials of the department in getting the jungle cleared through the agency of
the appellant. Argued, the learned counsel that in any event if the departmental officials committed
any codal violations or ignored circulars and instructions in the matter of allotment of jungle
clearance work, the appellant could not be held responsible more so when the charge of conspiracy
is not only vague but also not proved on the record. Learned counsel further contended that vide
GOMS No. 1007 dt. 5,11,76, the Executive Engineers had been authorised to allot work, on
nomination basis, without calling for tenders where the amount involved was less than Rs. 20000
and, therefore, the allotment of the work in question to him on nomination basis could not be
faulted with. It was further submitted that the case of the prosecution to the effect that 710 work at
all was done and by preparing fictitious documents, the entire payment was misappropriated by Al
to A3 in connivance with the appellant has been belied by the prosecution evidence itself. In this
connection learned counsel referred to the evidence of PW 17 Assistant Engineer, who admitted in
his deposition that he had seen work was being actually done at the site in 1979-80. Learned counsel
also drew our attention to the report of inspection submitted by the Chief Engineer on 29.7.79
according to which jungle clearance work had actually been done at the site and urged that this
evidence completely demolished the prosecution case.
The circumstances relied upon by the prosecution and accepted by the courts below against the
appellant are :
(i) that work of clearance of Juliflora jungle and uprooting of stumps was falsely
alloted and without any work being done a cheque for Rs. 15643 was given to the
contractor which was encashed by him;
(ii) that there has been flagrant violations of provisions of PWD Codes etc. in the
matter of preparation of estimate; accord of sanction; drawing up of the agreement
and allotment of work on nomination basis to the appellant;
(iii) that in the measurement book the area where work had been done was recorded
by the officials in excess to help the appellant, without having actually visited the site;
(iv) that the allotment of work by nomination was irregular and in violation of codal
rules. Major work had been split up so as to bring up the allotment of work within the
pecuniary jurisdiction of the Executive Engineers;
(v) the terms of the agreement Ex. P5 concluded between Al and A4 are ambiguous;
(vi) preparation of bill and making of separate payment for removal of stumps and
clearance of jungle was in breach of codal provisions.
Strictly speaking the above cannot be called 'circumstances' against the appellant as the same are
more in the nature of "allegations" of the prosecution against the accused. Even otherwise, so far as
circumstances 2 to 6 (supra) are concerned, they concern the officials of the department, and may beC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

relevant in the case of the appellant, if the charge of conspiracy can be said to have been established.
The charge of conspiracy against the accused was that without any work being done by him,
payment was made to him and various documents fabricated to justify the payment, which was
misappropriated. Circumstances 1 and 3 derive their colour and content from the aforesaid
circumstances.
Was any jungle clearance work done in 1979 at the site in question?
If the answer to the question is in the affirmative, the charge of conspiracy must fail. While dealing
with the case of departmental officials, we have held that the charge of conspiracy has not been
established. Those reasons apply to the case of the appellant also. Besides, PW 17 is the Assistant
Engineer of the department. Kodavalur Tank Channel was within his jurisdiction when he was
working as Section Officer at Kodavalur, from May 1980 to July 1984, He deposed that being a
native of Kodavalur, he had seen that Kodavalur Tank Supply Channel even before he started
working as Section Officer in Kodavalur section. He admitted during his cross examination :
"During 1979-80 I was working at Darsi. While going to Darsi by bus from Kovur, I
observed jungle clearance work being done on Kodavalur Tank Supply Channel, I saw
the jungle clearance work being done at a road bridge which is across the Kodavalur
Tank Supply Channel and that road bridge is within the drainage from 0/0 to 1/0
mile. This tank supply channel runs in embankment on that chainage i.e. 0/0 to 1/0
mile,"
the above statement of PW 17, when considered in the light of the inspection report of the Chief
Engineer dated 29.7.79, shows jungle clearance work was being done in 1979-80, PW 21 a resident
of Rajapulan who has his tailoring shop situate on the left bank of Kodavalur tank for the last about
12-13 years deposed at the trial that about 8-9 years ago he had seen some officials getting jungle
cleared on the banks of that channel by engaging coolies. The evidence of this witness, thus, also
shows that jungle clearance work was being done at the site in question in 1979-80 and to that
extent PW 21 corroborates the testimony of Assistant Engineer P 17. It is nobody's case that jungle
clearance work was done in 1979-80 through departmental laskars and, therefore, the legitimate
inference to be drawn from the evidence of PW 21 is that jungle clearance work was being done at
the site in 1979-80 through the appellant. PW 18 is a bus conductor, He has a hut on the Northern
bank of the channel since 1977. According to him villagers used to cut and take away Karratumma
plants growing on the channel banks. He denied any knowledge as to whether contractors of the
PWD department had cleared Karratumma plants growing on the banks of Kodavalur tank supply
channel during 1979-80. As against this material, is the evidence of PW 8 who visited the site in
1984 and stated in his report that no work of jungle clearance had been done in 1979 as there was
growth of juliflora at the site when he visited it. Finding the growth of Julifiora in 1984 could not
lead to an irresistible conclusion that the jungle had not been cleared in 1.1979-80. In this
connection, the evidence of PW 11 has significance. This witness admitted during his
cross-examination that juliflora grows rather fast and is a wild growth. It could not have stopped
growing between 1979 and 1984, Since, the prosecution witnesses PW 17 and 21 have admitted that
in 1979-80, work of clearance of juliflora jungle was being done at the site and it is no body's caseC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

that it was being done departmentally, the conclusion is irresistible that the same, had been done
through the agency of the appellant and the charge of conspiracy must fail. There have been some
irregularities committed in the matter of allotment of work to the appellant or breach of codal
provisions, circulars and departmental instructions, for preparation of estimates etc. and those
irregularities give rise to a strong suspicion in regard to the bonafides of the officials of the
department and their link with the appellant, but that suspicion cannot be a substitute of proof. The
courts below appear to have drawn inferences by placing the burden of proving innocence on the
appellant which is an impermissible course. In our opinion none of the circumstances relied upon by
the prosecution against the appellant can be said to have been proved satisfactorily and all those
circumstances, which are not of any clinching nature, even if held to be proved do not complete the
chain of evidence so complete as to lead to an irresistible conclusion consistent only with the
hypothesis of the guilt of the appellant and wholly inconsistent with his innocence. The prosecution
has not established the case against the appellant beyond a reasonable doubt. This appeal,
there-fore, succeeds and is allowed. The conviction and sentence of the appellant is hereby set aside.
Fine, if paid by the appellant shall be refunded to him. The appellant is on bail. His bail bonds shall
stand discharged, CRIMINAL APPEAL NOS. 170-171 OF 1993 (NELLORE NORTH DIVISION -
CONTRACTOR'S APPEAL) These appeals arises out of C.C. No. 4 of 1987 and have been filed by the
contractor (A5) who was alloted work on nomination basis for clearance of jungle in Nellore North
Division on the reach of 0.0 to 1450 metres on Krakatur small tank.
The prosecution case against the contractor is that he is a non-existent person. According to the
prosecution there was no such contractor who had been alloted work on nomination basis and all
the documents purporting to have been signed by the appellant as a contractor had been fabricated
by the engineers because the contractor was an unknown and fictitious person. It is alleged that the
name of the contractor as appearing in the order of nomination, allotment letter and the agreement
is fictitious and not correct. Both the courts appear to have readily accepted the prosecution case
and convicted and sentenced the appellant. We fail to see any justification for such a conviction. If
the appellant had nothing to do with the contract, how could he be convicted for allegedly not
undertaking the work with which he, according to the prosecution case itself had no concern. In the
charge sheet and the charge framed against the appellant, the name of the appellant has been given
as the contractor who was alleged to be a co-conspirator with the Engineers and section officers to
misappropriate government funds by receiving payment for doing no jungle clearance work. That
there was clearance of jungle at the site in question, has been amply established from the
prosecution evidence which has been discussed while dealing with the appeals relating to Nellore
North Division. Since, jungle clearance work has been found by us to have been done in 1979-80 and
it is not the prosecution case that it was done departmentally, the inference that it was done through
the agency of the appellant appears to us to be fair and reasonable. The charge framed against the
appellant was never amended and since the charge contained the name of the appellant as a co-
conspirator, who is supposed to have been alloted the work but who did no work and yet received
payment and shared it with his co-accused, we fail to see how it is open to the prosecution to now
contend that the contractor is a fictitious person. The argument is self defeating. Prosecution has
failed to prove the case against the appellant beyond a reasonable doubt either through direct or
circumstantial evidence. The courts below have apparently taken a superficial view of the matter and
without considering the material on the record, recorded the conviction of the appellant whichC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

cannot be sustained. His appeal succeed and are allowed. His conviction and sentence is set aside.
Fine paid by him shall be refunded to him. His bail bonds are discharged.
As a result of our above discussion of various representative appeal and which discussion equally
applies to all the appeals filed in this court arising out of the judgment of the High Court dated
27,11.91, we find that the prosecution has not been able to establish, beyond a reasonable doubt, its
case against any of the departmental officials, that is, the Engineers and section officers and
consequently their appeals succeed and their conviction and sentence are set aside. The fine paid by
each one of them is directed to be refunded to them. The prosecution has also not established its
case against any of the contractors beyond a reasonable doubt. Their appeals also succeed and their
conviction and sentence are hereby set aside. The fine paid by them is directed to be refunded to
them. Their bail bonds shall stand discharged.
This takes us to one other aspect of the case. Mr. L.R. Kapoor who conducted an inquiry from 4.4.81
to 6.4.81 and submitted his report on :284.81 to the Government found that there had been defiance
of the authority of the Superintending Engineer in the matter of execution of work and spending of
grants besides violation of codal provisions and breach of departmental instructions and circulars.
He recommended departmental action against the accused. However, before the accused could be
proceeded departmentally, the case was entrusted to ACB and the accused were tried by the learned
special judge and were convicted and sentenced. Their appeals, except for reduction of sentence,
failed in the High Court. Both the courts found that grave irregularities were committed by the
officers concerned in the matter of allotment of work and the method followed by them was in
violation of the codal provisions departmental instructions and circulars. The courts below have also
found that the officials had committed serious administrative irregularities and lapses. Reference
has been made both by the trial court and the High Court to the codal provisions i.e. A.P. PWD code,
A.P. Financial Code etc. and the circulars and instructions issued from time to time which were
respected in their breach by the official accused. We have not found it possible to take a view
different than the one taken by the courts below in this regard though in our opinion the breach of
code provisions or violation :of the circulars and instructions and commission of administrative
irregularities cannot be said to have been done by the officials concerned with any corrupt or
dishonest intention. Learned counsel appearing for all the appellants also during the course or their
arguments were unable to point out any error in those findings and according to them in the
established facts and circumstances of the case, the irregularities, administrative lapses and
violation of the codal provisions, could only have resulted in a departmental action against the
officials but criminal prosecution was not justified. Their argument has force and appeals to us.
Since, we have given the benefit of doubt to the accused persons (department officials) and
acquitted them, they may seek reinstatement in service. However, as we have agreed with the
findings recorded by both the courts below with regard to the violation of the codal provisions and
administrative lapses by the departmental officials, it appears to us that a departmental enquiry may
be justified but in this fact situation, it would be an unnecessary exercise. Learned counsel for the
appellants have been heard by us at length and they were unable to assail the findings of the courts
below regarding codal violations and administrative lapse which may have caused some loss to the
exchequer also. What then should be the course of action which should be followed in the facts and
circumstances of the case ? While the officials deserve to be punished, should we remit the matter toC. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

the department for awarding appropriate punishment or should we impose the punishment
ourselves and close the chapter, A court of equity must so act, within the permissible limits so as to
prevent injustice. "Equity is not past the age of child bearing" and an effort to do justice between the
parties is a compulsion of judicial conscience. Courts can and should strive to evolve an appropriate
remedy, in the facts and circumstances of a given case, so as to further the cause of justice, within
the available range and forging new tools for the said purpose, if necessary to chisel hard edges of
the law. In our opinion in the established facts and circumstances, it would be appropriate with a
view to do complete justice between the parties, in exercise of our jurisdiction under Article 142 of
the Constitution of India, to direct that no departmental inquiry shall now be initiated against the
departmental officials for their established administrative breaches and violation of the codal
provisions, in 1979-80. Consequent upon their acquittal, the official respondent shall be reinstated
in service with continuity of service for all purposes but for their established administrative lapses
and breach : of codal provisions etc., they shall not be entitled to any back wages or any other type of
monetary benefit for the period they remained out of service. The suspension allowance, if any,
received by all or anyone of them shall however not be recovered from them. This punishment
appears to us to be commensurate with the gravity of their lapses and shall serve the ends of justice.
Those of the officials who may have reached the age of superannuation in. the meanwhile, will get
their pensionary benefits calculated on the basis of their continuous service but they shall be entitled
to draw pension with effect from the date of this order only.C. Chenga Reddy And Ors vs State Of Andhra Pradesh on 12 July, 1996

