Abinaya vs The State Of Tamil Nadu on 30 October, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                            HCP(MD)No.889 of 2023
                          BEFORE THE MADURAI BENCH OF MADRAS HIGH COURT
                                                 DATED: 30.10.2023
                                                         CORAM:
                                    THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                          and
                                  THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                             H.C.P.(MD)No.889 of 2023
                     Abinaya                                                 : Petitioner
                                                           Vs.
                     1.The State of Tamil Nadu
                       Rep. By the Principal Secretary to the Government,
                       Prohibition & Excise Department,
                       Secretariat, Chennai – 600 009.
                     2.The Commissioner of Police,
                       Tiruchirappalli City,
                       Tiruchirappalli District.
                     3.The Superintendent of Prison,
                       Tiruchirappalli Central Prison,
                       Tiruchirappalli District.
                     4.The Inspector of Police,
                       All Women Police Station,
                       Contonment,
                       Tiruchirappalli District.
                       (Crime No.12 of 2023)                            : Respondents
                     Page 1 of 10
https://www.mhc.tn.gov.in/judis
                                                                                 HCP(MD)No.889 of 2023Abinaya vs The State Of Tamil Nadu on 30 October, 2023

                     PRAYER: Petition filed under Article 226 of the Constitution of India to
                     issue a writ of Habeas Corpus, calling for the records pertaining to the
                     Detention order passed by the 2nd respondent dated 17.05.2023 with
                     reference No.C.No.44/Detention/C.P.O/T.C/2023 and set aside the same and
                     direct the respondents to produce the petitioner's husband Prabin Christal
                     Raj, Son of Packiaraj, aged 41 years, now confined in the Central Prison,
                     Tiruchirappalli before this Hon'ble Court and set him at liberty.
                                             For Petitioner    : Mr.P.Jesus Moris Ravi
                                             For Respondents : Mr.A.Thiruvadi Kumar
                                                                Additional Public Prosecutor
                                                          ORDER
[Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus Petition'
[hereinafter 'HCP' for the sake of brevity] was listed in the Admission Board on 19.07.2023, a
Hon'ble Coordinate Division Bench made the following order in the Admission Board:
https://www.mhc.tn.gov.in/judis
2. It has now become necessary to set out a thumbnail sketch of factual matrix and we do so in the
paragraphs infra.
3. Today, the captioned matter is in the Final Hearing Board. https://www.mhc.tn.gov.in/judis
4. Mr.P.Jesus Moris Ravi, learned counsel on record for HCP petitioner is before us on a Video
Conferencing platform [VC] and Mr.A.Thiruvadi Kumar, learned State Additional Public Prosecutor
for all respondents is before us in the physical Court. To be noted, this is a hybrid hearing.
5. Captioned HCP has been filed by the wife of the detenu assailing a 'preventive detention order
dated 17.05.2023 bearing reference C.No. 44/Detention/C.P.O/T.C/2023' [hereinafter 'impugned
preventive detention order' for the sake of brevity and convenience]. To be noted, fourth respondent
is the sponsoring authority [hereinafter 'Sponsoring Authority' for the sake of convenience and
clarity] and second respondent is the detaining authority as impugned preventive detention order
has been made by second respondent.
6. Impugned preventive detention order has been made under 'The Tamil Nadu Prevention of
Dangerous Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-offenders,
Goondas, Immoral traffic offenders, Sand-offenders, Sexual-offenders, Slum-grabbers and Video
https://www.mhc.tn.gov.in/judis Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' [hereinafter
'Act 14 of 1982' for the sake of convenience and clarity] on the premise that the detenu is a 'Sexual
Offender' within the meaning of Section 2(ggg) of Act 14 of 1982.Abinaya vs The State Of Tamil Nadu on 30 October, 2023

7. There is no adverse case. The ground case which constitutes sole substratum of the impugned
preventive detention order is Crime No.12 of 2023 on the file of All Women Police Station,
Cantonment registered under Section 366A of 'The Indian Penal Code (45 of 1860)' [hereinafter
'IPC' for the sake of convenience and clarity] and Sections 5(l) r/w 6(1), 16 r/w 17 of 'the Protection
of Children from Sexual Offences Act, 2012 (No.32 of 2012)' [hereinafter 'POCSO Act' for the sake of
convenience and clarity] and Section 4(1), 4(2)(a), 5(1)(a) ITP Act, 1956 and Sections 9, 10 and 11 of
Child Marriage Act, 2006. Considering the nature of the challenge to the impugned detention order,
it is not necessary to delve into the factual matrix of the case.
8. In the support affidavit qua captioned HCP several grounds have been raised but learned Counsel
for petitioner predicated his campaign https://www.mhc.tn.gov.in/judis against the impugned
Preventive Detention Order on the point that the detenu was arrested on 12.04.2023 but the
impugned preventive detention order has been made only on 17.05.2023 resulting in live and
proximate link between grounds and purpose of detention getting snapped.
9. Mr.Thiruvadi Kumar, learned State Additional Public Prosecutor, submits to the contrary by
saying that materials had to be collected and time was consumed in this exercise. Considering the
facts / circumstances of the case on hand and nature of ground case, we find that this explanation of
learned Prosecutor is unacceptable.
10. We remind ourselves of Sushanta Kumar Banik's case [Sushanta Kumar Banik Vs. State of
Tripura & others reported in 2022 LiveLaw (SC) 813 : 2022 SCC OnLine SC 1333]. To be noted,
Banik case arose under 'Prevention of Illicit Traffic in Narcotic Drugs and Psychotropic Substances
Act, 1988' [hereinafter 'PIT NDPS Act' for the sake of brevity] in Tirupura, wherein after considering
a proposal by a Sponsoring Authority and after noticing the trajectory the matter took, Hon'ble
Supreme Court held that the 'live and proximate link between grounds of detention and
https://www.mhc.tn.gov.in/judis purpose of detention snapping' point should be examined on a
case to case basis. Hon'ble Supreme Court has held in Banik case law that this point has two facets.
One facet is 'unreasonable delay' and the other facet is 'unexplained delay'. We find that the
captioned matter falls under latter facet i.e., unexplained delay.
11. To be noted, Banik case has been respectfully followed by this Court in Gomathi Vs.The Principal
Secretary to Government and others reported vide Neutral Citation of Madras High Court being
2023/MHC/334, Sadik Basha Yusuf Vs. The State of Tamil Nadu and others reported vide Neutral
Citation of Madras High Court being 2023/MHC/733, Sangeetha Vs. The Secretary to the
Government and others reported vide Neutral Citation of Madras High Court being
2023:MHC:1110, N.Anitha Vs. The Secretary to Government and others reported vide Neutral
Citation of Madras High Court being 2023:MHC:1159 and a series of similar orders in HCP cases.
12. To be noted, the impugned preventive detention order is predicated on a solitary case viz., Crime
No.12 of 2023 on the file of All https://www.mhc.tn.gov.in/judis Women Police Station,
Cantonment registered under Section 366A of IPC and Sections 5(l) r/w 6(1), 16 r/w 17 of POCSO
Act and Section 4(1), 4(2)Abinaya vs The State Of Tamil Nadu on 30 October, 2023

(a), 5(1)(a) ITP Act, 1956 and Sections 9, 10 and 11 of Child Marriage Act, 2006 and therefore this
solitary case is the sole substratum of the impugned preventive detention order.
13. This Bench is informed by the learned Additional Public Prosecutor that in the ground case, final
report has been filed within the prescribed time line and the same is now on the file of Mahila Court,
Trichy in Spl.S.C.No.66 of 2023. We make it clear that if the detenu seeks bail before the trial Court,
the trial Court shall deal with the bail application on its own merits and in accordance with law
untrammelled by this order which has been made for the limited purpose of testing the impugned
preventive detention order in habeas legal drill on hand.
14. Before concluding, we also remind ourselves that preventive detention is not a punishment and
HCP is a high prerogative writ. https://www.mhc.tn.gov.in/judis
15. Ergo, the sequitur is, captioned HCP is allowed. Impugned preventive detention order dated
17.05.2023 bearing reference C.No. 44/Detention/C.P.O/T.C/2023 made by the second respondent
is set aside and the detenu Thiru.Prabin Christal Raj, male, aged 41 years, son of Packiaraj, is
directed to be set at liberty forthwith, if not required in connection with any other case / cases.
There shall be no order as to costs.
                                                                    [M.S.,J.] & [R.S.V.,J.]
                     vsm                                                   30.10.2023
                     Index        : Yes
                     Neutral Citation : Yes
P.S: Registry to forthwith communicate this order to Jail authorities in Central Prison,
Tiruchirappalli.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J.
and R.SAKTHIVEL, J.
vsm To
1.The State of Tamil Nadu Rep. By the Principal Secretary to the Government, Prohibition & Excise
Department, Secretariat, Chennai – 600 009.
2.The Commissioner of Police, Tiruchirappalli City, Tiruchirappalli.
3.The Superintendent of Prison, Tiruchirappalli Central Prison, Tiruchirappalli District.
4.The Inspector of Police, All Women Police Station, Contonment, Tiruchirappalli District.Abinaya vs The State Of Tamil Nadu on 30 October, 2023

5.Joint Secretary to Government, Public (Law and Order) Department, Secretariat, Chennai.
6.The Additional Public Prosecutor, Madurai Bench of Madras High Court, Madurai.
30.10.2023 https://www.mhc.tn.gov.in/judisAbinaya vs The State Of Tamil Nadu on 30 October, 2023

