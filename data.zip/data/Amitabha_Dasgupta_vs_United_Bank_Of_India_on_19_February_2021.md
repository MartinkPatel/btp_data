Amitabha Dasgupta vs United Bank Of India . on 19 February,
2021
Equivalent citations: AIR 2021 SUPREME COURT 1193, AIRONLINE 2021 SC
84
Author: Mohan M. Shantanagoudar
Bench: Vineet Saran, Mohan M. Shantanagoudar
                                                                          REPORTABLE
                                 IN THE SUPREME COURT OF INDIA
                                    CIVIL APPELLATE JURISDICTION
                                    CIVIL APPEAL NO. 3966 OF 2010
           Amitabha Dasgupta                                          ...Appellant
                                                 Versus
           United Bank of India & Ors.                                …Respondents
                                            JUDGMENT
MOHAN M. SHANTANAGOUDAR, J.
1. This appeal, by special leave, arises out of the judgment of the National Consumer Disputes
Redressal Commission (‘National Commission’) delivered on 18.12.2008 dismissing the Revision
Petition filed against the judgment of the State Consumer Disputes Redressal Commission (‘State
Commission’) dated 12.10.2004.
Date: 2021.02.19 15:26:24 IST Reason:
2. The following are the facts out of which this appeal arises:Amitabha Dasgupta vs United Bank Of India . on 19 February, 2021

2.1 In the early 1950’s, the Appellant’s mother (since deceased) took a locker on rent
bearing No. A−222 in the Deshapriya Park, Kolkata Branch of the Respondent No. 1
Bank. In 1970, the Appellant/Complainant was included as a joint holder of the
locker. On 27.05.1995, the Appellant visited the Respondent No.1 Bank to operate the
locker and deposit the locker rent. However, the Appellant was informed that the
Bank had broken open his locker on 22.09.1994 for non−payment of rent dues for the
period of 1993−1994. Further, that the locker had subsequently been reallocated to
another customer.
2.2 On 29.05.1995 and 2.06.1995, the Appellant sent communications to Respondent
No. 1 claiming that such breaking of his locker by the Bank was illegal since he had
cleared dues for 1994−1995 on 30.07.1994, i.e., prior to the breaking of the locker.
The Chief Manager of Respondent 1, who is Respondent No. 3 in the present appeal,
responded to the communication and admitted to having inadvertently broken open
the locker, though there were no outstanding dues to be paid, and apologized for the
same. He stated as an ancillary point that reminders for the payment of dues had
been sent on 25.11.1993 and 23.02.1994. However, that these would have no meaning
since the dues were subsequently paid by the Appellant on 30.06.1994.
2.3 On 17.06.1995, when the Appellant went to collect the contents of the locker, it is
alleged that he found only two (one pair of bangles and one pair of ear pussa) of the
seven ornaments that had been deposited in the locker in a non−sealed envelope.
However, Respondent No.1 Bank contends that only those two ornaments were found in the
Appellant’s locker when it was broken open. That the same is evident from the inventory prepared
by Respondent No. 1 when the locker was broken open in the presence of an independent witness.
2.4 Subsequently, the Appellant filed a consumer complaint before the District Consumer Forum
(‘District Forum’) calling upon Respondent No. 1 to return the seven ornaments that were in the
locker; or alternatively pay Rs. 3,00,000/− towards the cost of jewelry, and compensation for
damages suffered by the Appellant.
2.5 The District Forum allowed the complaint and held Respondent No. 1 liable for deficiency of
service, relying upon Respondent No. 3’s admission that the Bank had inadvertently broken open
the Appellant’s locker though there were no pending rent dues. Further, on the claim for the cost of
seven ornaments, it was held that Respondent No.1 could not prove that there had been only two
ornaments in the locker since there were no independent witnesses in the presence of whom the
locker was opened. Hence, Respondent No. 1 was directed to return the entire contents of the locker,
or alternatively pay the Appellant Rs. 3,00,000/− towards cost of the jewelry and, Rs. 50,000/− as
compensation for mental agony, harassment, and cost of litigation.
2.6 On appeal, the State Commission vide order dated 12.10.2004 accepted the District
Commission’s findings on the question of deficiency of service, though it reduced the compensation
from Rs. 50,000/− to Rs. 30,000/−. However, with respect to recovery of the cost of the ornaments,Amitabha Dasgupta vs United Bank Of India . on 19 February, 2021

the State Commission, relying upon the judgment of the National Commission in UCO Bank v. RG
Srivastava,1 observed that the dispute on the contents of the locker can only be decided upon
provision of elaborate evidence. That the Consumer Forum was not equipped to undertake this
evaluation since it only has jurisdiction to conduct a summary trial. Therefore, the Appellants 1 1996
(1) CPR 97.
were directed to approach the civil court for adjudication on the contents of the locker.
2.7 The Revision Petition against the order of the State Commission was dismissed vide the
impugned order. The National Commission by the impugned judgment, accepted the State
Commission’s holding on the limited jurisdiction of the Consumer Forum to adjudicate on the
recovery of the contents of the locker.
Hence, the present appeal.
3. Learned counsel for the Appellant submitted that even if the case is remitted to the civil court for
adjudication on the issue of the contents of the locker, it would be highly improbable to ascertain the
same since the contents of a locker are exclusively known only to the locker holder. On the question
of damages, he relied on Charan Singh v. Healing Touch Hospital & Ors.2 to argue that
compensation must be awarded to bring a qualitative change in the attitude of the service provider.
3.1 Per contra, learned counsel for the Respondents submitted that the National Commission’s
holding does not warrant interference. He submitted that compensation for the loss of 2(2000) 7
SCC 668.
jewellery can only be awarded after appreciation of evidence by the trial court.
4. Heard Learned Counsel for both parties. Based on a perusal of the record, the following issues
arise for consideration in the present appeal:
4.1 First, Whether the Bank owes a duty of care to the locker holder under the laws of
bailment or any other law with respect to the contents of the locker? Whether the
same can be effectively adjudicated in the course of consumer dispute proceedings?
4.2 Second, irrespective of the answer to the previous issue, whether the Bank owes
an independent duty of care to its customers with respect to diligent management
and operation of the locker, separate from its contents? Whether compensation can
be awarded for non−compliance with such duty?
I. Relief with Respect to the Contents of the Locker
5. Disputes between banks and locker holders, pertaining to loss of articles placed inside the locker,
have been subject to judicial consideration in various jurisdictions for nearly a century. For a
broader understanding of the subject, we find it necessary to briefly refer to certain judgments of
foreign jurisdictions, before clarifying the position under Indian law. 5.1 The dominant view ofAmitabha Dasgupta vs United Bank Of India . on 19 February, 2021

courts around the globe has been that the bank is in the position of a bailee with respect to the goods
placed inside the locker by the locker holder. In Roberts v. Stuyvesant Safe Deposit Co.,3 the
defendant company permitted the police under a search warrant, to confiscate the articles that were
inside the plaintiff’s locker. However, the articles were subsequently stolen from police custody. A
suit was filed by the plaintiff, alleging that the defendant company failed to comply with the duty of
care required under the law by permitting the police to take away articles that were not mentioned
in the search warrant. Affirming the plaintiff’s contentions, the Court of Appeals of New York made
the following observations about the relationship of bailment between the parties:
“The legal relationship which the defendant held to the plaintiff, and out of which this
controversy has arisen, was that of a bailee or depositary for hire. The fundamental
question in the case is whether the defendant, upon the undisputed evidence in the
record, discharged those duties and obligations to the 3(1890) 123 N.Y 57.
plaintiff which the law imposed upon it in regard to the care and custody of her
property.” (emphasis supplied) It is pertinent to note the Court’s observation that
whether or not the defendant had discharged its obligations as a bailee would have to
be discerned from the undisputed evidence on the record.
5.2 The position of law stated in Stuvyesant Safe Deposit Co.
(supra) has been reiterated in subsequent precedents which have governed the law on the field such
as Emma M. Lockwood v. The Manhattan Storage & Warehouse Company,4 Mayer v. Brensigner,5
National Safe Deposit Co. v. Stead.6 In Cussen v. Southern Cal. Savings Bank,7 money kept by the
plaintiff in the bank’s safe deposit vault was lost. The Supreme Court of California held that the bank
was liable under the laws of bailment. However, it observed that the plaintiff would have to make a
prima facie case that they had deposited the money inside the locker, and that it was subsequently
lost. The burden of proof would then shift to the defendant bank to prove that it exercised 4 50
N.Y.S 974 (N.Y. 1898).
5 54 N.E 159 (1899).
6 95 N.E. 973 (1911).
7 65 P. 1099 (1901).
the necessary care required under the laws of bailment for the protection of its contents. Therefore,
before applying the laws of bailment, the court must first find on the facts of the case whether the
plaintiff had transferred possession of the articles to the bank.
6. To identify if the relationship of bailment exists between the bank and the locker holder under
Indian law, it is necessary at the outset to refer to the relevant provisions under the Indian Contract
Act, 1872 (‘Contract Act’):Amitabha Dasgupta vs United Bank Of India . on 19 February, 2021

“148. ‘Bailment’, ‘bailor’ and ‘bailee’ defined.—A ‘bailment’ is the delivery of goods by
one person to another for some purpose, upon a contract that they shall, when the
purpose is accomplished, be returned or otherwise disposed of according to the
directions of the person delivering them. The person delivering the goods is called the
‘bailor’. The person to whom they are delivered is called the ‘bailee’.
149. Delivery to bailee how made.—The delivery to the bailee may be made by doing
anything which has the effect of putting the goods in the possession of the intended
bailee or of any person authorised to hold them on his behalf.” Thus, from the
aforementioned provisions, it can be inferred that three components need to be
fulfilled for the existence of bailment. These are: (i) delivery of goods from one
person to another by transfer of possession, actual or constructive; (ii) an express or
implied contract for delivery; (iii) delivery should be for accomplishment of a
purpose.
7. Unfortunately, there is no substantive domestic legislation or sector−specific regulations which
may throw light upon the issue of whether banks are responsible under the laws of bailment for the
loss of articles placed inside the locker. On 4.12.2006, the Reserve Bank of India (‘RBI’) had issued a
Draft Circular on Safe−Deposit Lockers (‘2006 Circular’). 8 This circular was only in the form of a
proposal issued to the banks and hence does not have any binding value. However, it is useful in
understanding the RBI’s position at that stage. Clause 2.1 of the 2006 Circular states:
“2. Security aspects relating to Safe Deposit Lockers:
2.1 It is clarified that the relationship between the bank and the locker hirer is in the
nature of a 'bailor and bailee' and not 'landlord and tenant' though the bank has no
knowledge of the contents of the locker and the bank is required to exercise due care
and necessary precaution for the protection of the lockers provided to the customer.”
(emphasis supplied) On perusal of the 2006 Circular, it is evident that at that point in
time, the RBI had recommended that the laws of bailment ought to guide the
relationship between the bank and the locker
8https://www.rbi.org.in/Scripts/BS_CircularIndexDisplay.aspx?Id=3196.
holder, even if the bank has no knowledge of the contents of the locker.
7.1 The RBI had also issued guidelines covering inter alia, the subject of safe custody of articles
placed inside the lockers (Circular No. RBI/2006−2007/325) on 17.04.2007 (‘2007 Circular).9
There was no clause on the nature of the legal relationship between the bank and the locker holder
in the 2007 Circular. The only reference to the Contract Act was as follows:
“3.5 Banks are advised to be guided also by the provisions of Sections 45 ZC to 45 ZF
of the Banking Regulation Act, 1949 and the Banking Companies (Nomination)
Rules, 1985 and the relevant provisions of Indian Contract Act and Indian Succession
Act.” (emphasis supplied) However, this observation was made in the specific contextAmitabha Dasgupta vs United Bank Of India . on 19 February, 2021

of return of safe custody of articles to the survivors/legal heirs of deceased locker
holders and hence may not have much bearing in the present case.
7.2 Subsequently, in response to a Right to Information (‘RTI’) enquiry made in 2017,
the RBI, and various public sector banks, stated that as per the agreement entered
into with the customers who are hiring/leasing the lockers, the banks have no liability
for loss or damage of articles placed inside the bank lockers. Hence the position of the
RBI from 2006 to 2017 has undergone a sea− 9
https://www.rbi.org.in/Scripts/BS_CircularIndexDisplay.aspx?Id=3422.
change. The position adopted by the banks was challenged before the Competition Commission of
India (‘CCI’) as being in the nature of an anti−competitive practice. The CCI dismissed the claim,
while making the following observations:10 “7. In the instant case, there is no such material to
suggest any understanding/consensus/arrangement amongst the Opposite Parties to have pursued
any of the aforesaid prohibited activities. Suspicion of a cartel has been raised in the information as
all the Opposite Parties allegedly do not take responsibility for any loss of valuables kept by
customers availing safety deposit locker facility from them. However, the RTI replies of some of the
Opposite Parties suggest that they are not completely absolved for loss of valuables kept in their
locker. For instance, the reply dated 7th October, 2015 of Bank of Baroda inter alia states that in
case of loss suffered by the lessee due to theft or burglary etc. of safe custody locker, the liability of
the bank will depend upon the facts and circumstances surrounding the burglary. Further, the reply
dated 13th October, 2015 of Dena Bank states that the responsibility of the bank shall be governed
by the terms and conditions laid down in the memorandum of hiring of locker and the guidelines
issued by RBI from time to time. Reply dated 19th October, 2015 of Andhra Bank states that the
relationship between the bank and its customer, in case of safe deposit locker, is that of ‘lessor and
lessee’ and the particulars of the articles kept in safe deposit locker will not be disclosed by the
customer to the bank and hence, the bank cannot take responsibility for compensating any loss as
the extent of such loss cannot be assessed. It has been further stated that the bank, however, takes
all necessary measures and precautions to safeguard the lockers provided to the customers.
Similarly, the reply dated 30th October, 2015 of Corporation Bank states that 10 Kush Kalra v.
Reserve Bank of India, 2017 SCC OnLine CCI 41. its liability in case of theft/loss of valuables kept in
its safety lockers depends upon the parameters on which the bank takes insurance on the lockers
and the same parameters will be adopted while settlement of claims in case of theft. Taking into
consideration all these replies and in the absence of any material suggesting collusion amongst the
Opposite Parties, it cannot be said that a uniform practice is followed by all the Opposite Parties to
avoid responsibility/liability for loss of valuables kept by customers availing their safety deposit
locker facility.” (emphasis supplied) Therefore, the CCI took notice of the fact that it is common
industry practice for banks to disclaim liability for loss of articles placed inside the locker, though
there are no uniform parameters or policies guiding the same. Additionally, the banks have stated
that acceptance of responsibility for loss of articles placed in their locker facility will depend upon
the relevant facts and circumstances of each case, such as the terms of the locker hiring agreement,
the circumstances under which the articles were lost or stolen, and so on.Amitabha Dasgupta vs United Bank Of India . on 19 February, 2021

8. There has also not been any authoritative pronouncement from this Court on the issue of whether
banks are responsible as bailees, or in any other capacity, for any loss or damage to the contents of
the lockers. However, there have been various High Court judgments guiding the field. One of the
notable cases in which this issue arose was Jagdish Chandra Trikha v. Punjab National Bank.11 In
this case, the appellants had, before the partition of India, entrusted a sealed box of gold ornaments
to the respondent bank in Peshawar on the payment of a fee for safekeeping. The box was moved to
the Rawalpindi branch, then subsequently to the Lahore branch, and finally to India in November
1961 under the Indo−Pakistan Movable Property Agreement. Upon presentation of the box, the
Appellant refused to take delivery since the appearance and weight of the box was different from
what it had been when it was deposited. A suit was filed seeking delivery of the ornaments or
alternatively recovery of the market value of the ornaments. Referring to the relevant common law
authorities, the Delhi High Court held that the bank would be liable in the capacity of a bailee for the
loss of the ornaments:
“71. The Box was entrusted to the defendant Bank at Peshawar. The same was
accepted by the Bank as a bailee and it was expected that the usual care which is
demanded on such matters would be undertaken...it is established that the defendant
Bank failed to discharge its duties as a bailee and did not take care of the goods of the
parents of the plaintiff as one would under similar circumstances, take of his own
goods of the same bulk, quantity and value as the goods bailed.” 11 AIR 1998 Delhi
266.
(emphasis supplied) It is important to note that in the facts of Jagdish Chandra Trikha (supra), the
High Court found that there was complete entrustment of possession of the appellant’s ornaments.
The articles to be safeguarded were handed over by the customer to the bank in a sealed box, which
was then taken to a safe place to be stored. Though the respondent bank claimed it did not have any
knowledge of the contents of the box, it was proved from evidence that the appellant’s predecessors
had handed over a detailed list of the jewellery which was placed inside the safe deposit box to the
bank. It was further proved that the customer did not have any access to the same after entrustment
to the bank. Hence the High Court considered it a fit case to apply the laws of bailment.
8.1 However, the locker service provided by the banks has evolved since the pre−independence days.
In that era, the bank’s employee was entrusted with the relevant goods for safe keeping. Complete
access to the valuables, if any, remained with the bank till the time the customer claimed return of
the same. However, due to modernization of the locker system, banks now provide customers with
partial access to the lockers. Under the current system, the bank allocates a locker to the customer
on the payment of rent. The customer is then provided with a key to the locker through which he can
gain partial access to the locker. The bank has a master key to the locker and the customer can gain
complete access to the locker only when the bank uses its own key to the locker. Therefore, a
combination of the bank’s key and the locker holder’s key is required for opening a locker, providing
neither with complete access. In more advanced, digitally operated locker systems, such ‘keys’ may
not be physical keys but may consist of passwords or data which is exclusively known to the bank
and the customer. Further, the bank may not have any receipt of the exact particulars of the articles
placed inside the locker, as was the case in Jagdish Chandra Trikha (supra). The question thatAmitabha Dasgupta vs United Bank Of India . on 19 February, 2021

therefore arises for consideration before this Court is whether the modern−day bank locker system
would be guided by the laws of bailment.
8.2 An important decision which has considered the modern−day bank locker system is that in
Natioal Bank of Lahore Ltd. v. Sohan Lal Saigal.12 In that case, the appellant bank had provided
locker service for the safe custody of valuables. The 12AIR 1962 P H 534.
locker could be operated jointly by the locker holder and the bank’s custodian. However, the
respondent locker holder was able to prove before the Civil Court that the Manager/custodian of the
bank had tampered with the locker such that it could be operated even without the locker holder’s
personal key. Hence the Civil Court concluded that the Manager had exclusive control over the
lockers. Consequently, referring to the decisions of the Court of Appeals of Ohio in Blair v. Riley13
and the Supreme Court of Illinois in National Safe Deposit Company v. Stead, Attorney General,14
the Punjab and Haryana High Court held that the bailor−bailee relationship applied. In this regard,
the High Court observed that:(Pg. 578) “It may be that the person who hires a locker retains some
control over it by having one key with himself but if the locker can be operated without any key, as
was possible in the lockers which were rented out to the plaintiffs, then at once any impediment in
the way of control and possession of the Bank to whom the locker belonged and in whose strong
room it was to be found, would be removed and it could well be said that the bank was strictly in the
position of the bailee.” (emphasis supplied) The High Court further observed that the locker holders
had produced specific evidence in the form of lists of the articles of 13175 N.E.R 210.
1495 N.E.R. 973.
jewellery deposited inside the lockers so as to prove the extent of loss they had suffered.
8.3 In Mohinder Singh Nanda v. Bank of Maharashtra,15 forty−four safe keeping lockers in the
Respondent bank were broken open by miscreants and the contents were emptied. The Punjab &
Haryana High Court held that the bank would not be liable for the loss of articles, if any, since the
bank had no knowledge of the contents of the locker:
“4. But there is no evidence on record to show that the defendant−Bank had the
knowledge of the articles in the locker. Unless there is entrustment of the property to
the defendant Bank, the Bank cannot be held responsible for the theft. The plaintiffs
have miserably failed to prove that there was entrustment of the articles with the
defendant Bank and that the Bank authorities were aware of the articles placed in the
locker.” (emphasis supplied) 8.4 Subsequently, the Punjab and Haryana High Court
again undertook a comprehensive look into the present−day locker system in Atul
Mehra v. Bank of Maharashtra,16 which pertained to the same bundle of facts as in
Mohinder Singh Nanda (supra). The appellant locker holders filed a suit alleging that
due to the robbery, jewels worth Rs. 4,26,160/− were stolen from his locker. It was
claimed that the respondent bank had not 151998 ISJ (Banking) 673.
16AIR 2003 P&H 11.Amitabha Dasgupta vs United Bank Of India . on 19 February, 2021

complied with the duty of care owed under the laws of bailment. However, the trial court found that
the knowledge of the weight and value of the articles stored inside the locker was exclusive to the
customer, and the bank did not have notice of the same. Further, the appellants had not produced
any evidence at the stage of trial to establish the contents of the locker. Consequently, the Single
Judge Bench of Nijjar J. opined that the provisions with respect to bailment under the Contract Act
would not apply as follows:
“17…The respondent bank could only be fastened with liability on the contents of the
locker being disclosed to it. In the absence of this information, it would have to be
held that there was no entrustment of the goods to constitute bailment as required
under Section 148 of the Indian Contract Act, 1872. 18…These authorities are of no
assistance to the appellants in the present case. In all these cases, exclusive
possession of the property had been handed over by the bailor to the bailee. I am of
the considered opinion that exclusive possession is a sine qua non for bailment.
Therefore, I have no hesitation in coming to the conclusion that mere hiring of the
locker would not be sufficient to constitute a contract of bailment as provided under
Section 148 of the Indian Contract Act, 1872. In order to constitute bailment, as
provided in Section 148 of the Act, it is further necessary to show that the actual
exclusive possession of the property was given by the hirer of the locker to the bank.
It is only thereafter that the question of reasonable care and quantum of damages
would arise. In the present case, it is impossible to know the quantity, quality or the
value of the jewelry which was allegedly kept in the locker at the time when the
robbery occurred. ……… In the present case, the plaintiffs alone had the knowledge of
contents of lockers, therefore, the plaintiffs had to lead independent evidence to
prove that jewelry was actually in the locker on the date of the robbery. Even if the
plaintiffs had proved this peculiar fact; they would still have to prove the value of the
jewelry.” (emphasis supplied.) Therefore, the High Court concluded that mere leasing
out of the locker ipso facto would not establish a relationship of bailment between the
bank and the locker holder. In order to establish exclusive possession, the claimant
must prove that the bank had knowledge of the contents of the locker. Alternatively,
where the locker holder alone has knowledge of the contents, they must lead
independent evidence to prove that their articles or valuables were actually inside the
locker, and the valuation of the same.
8.5 However, Nijjar J. differentiated the holding in Sohan Lal Saigal (supra) by
observing as follows:
20. “In that case, the learned trial court had held that entrustment and the valuation
of jewelry had been proved…..On the twin grounds of exclusive possession of the
jewelry deposited in the locker and entrustment thereof to the Bank, it has been held
that the Bank would be in the position of bailee.” (emphasis supplied) Therefore, in
Sohan Lal Saigal (supra) entrustment of jewelry was proved on production of
elaborate evidence before the trial court. However, in Mohinder Singh Nanda (supra)
and Atul Mehra (supra) no evidence was led to prove the entrustment of jewelry toAmitabha Dasgupta vs United Bank Of India . on 19 February, 2021

the bank, and hence the claimant locker holders were unable to succeed in obtaining
relief. Nijjar J. further observed that:
“22…Whatever property is deposited in the locker is, undoubtedly in the custody and
possession of the bank. Merely because the locker can be operated only in the
presence of the locker hirer would not amount to joint possession of the locker. The
Banker can always open the locker with a “master key”. The hirer of the locker is not
in a position to open the locker without the assistance of the bank. The hirer has
access to the locker only during specified banking hours. The banker has no such
limitation. It must, however, be noticed that the transaction of bailment would only
be established if the provisions of Section 148 of the Indian Contract Act are
complied with.
With regard to this, it is the submission of Mr. Jagga that the plaintiffs have miserably failed to
prove that the jewellery was kept in the locker as claimed in the plaint. There being no entrustment
or delivery of possession, Section 148 of the Act cannot be invoked by the plaintiffs.” Therefore, the
Court in Atul Mehra was sympathetic to the fact that the principles of bailment may be applicable
even to the contemporary dual−key locker system if the bank is in the possession of a master key or
has substantial degree of access to the locker. However, the plaintiff would first have to prove that
they had indeed handed over possession of certain articles for being deposited in the locker of the
bank. If this requirement is not satisfied, the Court is barred from going into other issues such as
whether the locker holder and the bank were in joint possession, etc. 8.6 Having perused the
aforementioned precedents, we find that what was commonly contested in all these cases is whether
delivery of possession or entrustment of valuables from the locker holder to the bank had taken
place, for the purpose of Section 148 of the Contract Act. Even in the relevant foreign precedents
which we have noted, the application of the principles of bailment was contingent on determining
whether possession was transferred in the facts of the case. This in turn requires factual findings on
whether the bank had knowledge of the contents of the locker; or whether the locker holder had
prepared any receipt or inventory of the articles placed inside the locker or was otherwise able to
prove the particulars of the items deposited in the locker. We are of the considered opinion that
these questions cannot be adjudicated upon in the course of proceedings before the consumer fora.
This aspect must be evaluated by the civil court, upon appreciation of evidence led by the parties, as
was done in all the aforementioned decisions of Jagdish Chandra Trikha (supra), Sohan Lal Saigal
(supra), Mohinder Singh Nanda (supra) and Atul Mehra (supra).
8.7 It is true that the National Commission has, in previous decisions such as Punjab National Bank,
Bombay v. K.B. Shetty,17 and Mahender Singh Siwach v. Punjab and Sind Bank,18 awarded the
value of articles which have been stolen or gone missing from bank lockers. Moreover, in Pune Zilla
Madyawarti Sahakari Bank Limited v. Ashok Bayaji Ghogare,19 the National Commission has gone
to the extent of holding that the affidavit of the locker holder should ordinarily be accepted for
proving the contents of the bank locker, unless the same stands impeached by way of cross
examination. However, it is relevant to note that in the facts of the aforementioned cases, the
complainants had produced detailed and precise documentary proof for corroborating the extent of
jewellery 17 1991 (1) C.P.C. 592.Amitabha Dasgupta vs United Bank Of India . on 19 February, 2021

18(2006) 4 CPJ 231 (NC).
19 2015 SCC OnLine NCDRC 2832.
placed inside the locker, which has not been done in the present case.
8.8 In UCO Bank (supra), similar situation arose as in the present case, wherein the respondent
locker holder claimed that his locker was tampered with and broken open, and valuables were
subsequently lost, due to the negligence of the bank. The bank not only disputed the value of
jewellery kept inside the locker, but also denied any negligence in the breaking open of the locker.
The locker holder had only produced an affidavit in respect of the value of the jewellery claimed by
him. Hence the National Commission held that it is appropriate that both these issues should be
remitted for determination in a civil suit in a competent civil court, after adducing of elaborate
evidence on both sides.
8.9 In the recent case of Mamta Chaudaha v. Branch Manager/Head Manager, State Bank of
India,20 the National Commission again observed that the appellant locker holders had not
produced any evidence apart from a standard affidavit to prove that they had kept a specified
quantity of gold ornaments inside the bank locker. Further, there was no evidence of forcible 20
(2020) 1 CPJ 276 (NC).
entry to the locker. Hence the complaint for recovery of value of the ornaments was dismissed.
8.10 In light of the aforementioned conflicting decisions of the National Commission, we find that
the approach adopted by the National Commission in the impugned judgment is the correct
approach. In the present case, the Respondent bank has not disputed their negligence in breaking
open the locker in spite of clearance of rental dues by the Appellant. However, the number of items
originally deposited by the Appellant inside the locker is a contested fact. Hence, we do not propose
to record any conclusions on whether the Appellant locker holder in the present case is entitled to
claim return or recovery of the value of the ornaments alleged to have been deposited by him. We
are in agreement with the findings in the impugned judgment to the extent that the Appellant must
file a separate suit before the competent civil court for seeking this relief and for proving that the
aforesaid items were actually in the custody of the bank. This is especially inasmuch as the contents
of the locker are disputed by the Respondent bank. Hence it is clarified that all questions of fact and
law are left open before the civil court to decide on the merits of the case, including as to whether
the law of bailment is applicable, or any other law as the case may be. II. Separate Duty of Care of
the Bank with regard to Locker Management
9. As discussed supra, imposition of liability upon the bank with respect to the contents of the locker
is dependent upon provision and appreciation of evidence in a civil suit for such purpose. However,
this does not mean that the Appellant in the present case is left without any remedy. Banks as
service providers under the earlier Consumer Protection Act, 1986, as well as the newly enacted
Consumer Protection Act, 2019, owe a separate duty of care to exercise due diligence in maintaining
and operating their locker or safety deposit systems. This includes ensuring the proper functioningAmitabha Dasgupta vs United Bank Of India . on 19 February, 2021

of the locker system, guarding against unauthorized access to the lockers and providing appropriate
safeguards against theft and robbery. This duty of care is to be exercised irrespective of the
application of the laws of bailment or any other legal liability regime to the contents of the locker.
The banks as custodians of public property cannot leave the customers in the lurch merely by
claiming ignorance of the contents of the lockers.
9.1 In this regard, we may refer to the observations made by the National Commission in the
decisions discussed in Part I of our opinion. In Punjab National Bank (supra), in addition to
directing return of the cost of the ornaments lost, the National Commission also made a separate
finding on the negligence of the bank in maintaining the security and safety of the locker:
“4. The last and the most important question is whether the appellant Bank has been
guilty of negligence in ensuring the security and safety of the locker. The State
Commission has taken adverse notice of the fact that the appellant Bank did not
probe departmentally when the locker had been found open on the 9th June,
1988and treated the matter as closed so far as the Bank is concerned. It was content
with lodging a report with the police. It is a matter of common knowledge, the Master
Key of the locker is with the Bank; the locker can be opened only with the Master Key
and the Key with the locker holder. The mechanism is, however, such that the locker
must get closed, if the locker holder takes out his/her key. Further, a certificate is
recorded by the custodian of the Bank that all the lockers operated during a day have
been checked and found properly locked. Such a certificate was also recorded on the
21stApril, 1988. The State Commission, therefore, come to the conclusion that the
Bank was negligent, in ensuring the security of the locker with the result that it was
found on the 9th June, 1988 to have been opened unauthorized. For this the State
Commission has held that the Bank is squarely responsible and therefore liable to
make good the loss suffered by the respondent complainant. This Commission fully
concurs with the findings of the State Commission.” (emphasis supplied)
Accordingly, the bank was ordered to pay separate costs of Rs 3,500/− by way of
compensation to the locker holder. 9.2 In Mahendar Singh Siwach (supra) the bank
negligently allowed a third party, who was the previous allottee of the locker, to break
open the appellant’s locker and take away the valuables therein. It was found that the
bank had failed to duly record and complete the required formalities with respect to
change of allotment from the third party to the current allottee, i.e., the appellant.
The National Commission arraigned the gross deficiency in service committed by the
bank as follows:
“…We find that the record itself proves gross negligence and deficiency in service on
the part of the opposite party Bank in rendering service. Firstly, O.P.'s argument is
that fraud committed by Mr. Ramendra Singh Grover, the third party in removing the
contents of the locker comes under criminal jurisdiction, has no relevance as regards
enforcement of civil liability against the opposite party Bank under Consumer
Protection Act. There is no other valid argument given on behalf of the bank except to
contend that they did not know the details of the contents of the locker and hence theAmitabha Dasgupta vs United Bank Of India . on 19 February, 2021

Bank cannot be made liable. The Bank officials admitted their mistake and stated
that they are liable to compensate for the same. It is also interesting to see the
evidence produced on record, i.e. an extract from the order of the Learned Sessions
Judge, Meerut dated 22.4.1996 granting bail to Mr. Grover which is reproduced
hereunder:
“It appears that the alleged crime could not have been committed without the
connivance of the bank authorities. If the locker in question was allotted to the
applicant in the year 1978, it is not clear how it could be allotted to Mahendra Singh
Siwach in the year 1979. Further, when Mahendra Singh Siwach has been operating
the locker for all these years having his account No. 284 it is not understandable how
the Bank could without verifying from record, accept the request of the applicant that
the locker be broken open as the key had been lost. It was necessary for the bank
authorities to have referred to the bank record and should have also intimated
Mahendra Singh Siwach about this request of the applicant. Not only this, the bank
authorities in the circumstances mentioned above should have prepared an inventory
of the articles and should have got them valued before handing over the same to the
applicant. It does not appear that the police has taken any action against the
concerned delinquent bank official. The applicant−accused claims that he was the
owner of the property kept in the locker and the locker belonged to him. In these
circumstances, when no action has been taken against the bank authorities, I think it
proper to release the applicant also on bail.
xxx It is very strange that the opposite party has not referred to the duties cast on
them under their own instruction manual which is on the guidelines of the Reserve
Bank of India to support their case. Similar Manual of Instructions of United
Commercial Bank on the guidelines of Reserve Bank of India filed by the
Complainant is reproduced hereunder:
“Maintenance of Record 6.1 Locker Register (Form G −126) This Register should be
maintained lockerwise in serial order so as to facilitate locating the details of the hirer
from the locker number. All the details such as the name(s), their addresses,
operational instructions, rent paid, etc., should be recorded. The name(s) of the
hirer(s) should be indexed in the Register according to alphabetical order.
6.4 Locker Key Register The branch should also maintain a Locker Key Register. This
should be maintained keywise to lockerwise and lockerwise to keywise so as to
facilitate tracing the number of Locker from the Key number and tracing the number
of Key from the Locker number. Moreover, when the locks of the lockers are
interchanged, such changes should be immediately recorded in the Locker Key
Register. It should be marked ‘Strictly Private’ and should be kept in personal
custody of Custodian of locker cabinets. A suggested proforma of Locker Key Register
is given in Annexure 1.Amitabha Dasgupta vs United Bank Of India . on 19 February, 2021

6.5 Daily Register of Access to Hired Lockers (G−
125) Signature of the operator on Locker should be obtained in this Register. Date
and time of operation should also be recorded therein.
6.6 Branch should also maintain a pass book to keep a record of total number of Lockers hired and
number of Lockers surrendered so that it is possible to find out at a particular time the number of
Lockers let out and number of Lockers lying vacant.
At the time of half yearly closing, the stock of keys on hand should be verified in reference to Lockers
lying vacant.
12.3.1 Breaking Open of Locker Due to Loss of Key When intimation has been received from hirer(s)
about loss of key, the following procedure should be adopted for breaking open the Locker:—
(a) An application should be obtained from hirer(s) requesting for breaking open the Locker.
(b) The charges for breaking open the Locker should be realized from the hirer in advance and kept
in Sundry Creditors Account.
(c) An appointment should be made with the agents of the makers of lockers cabinet, to send their
mechanic to drill open the Locker in consultation with the hirer(s). Locker should be broken open in
the presence of the hirer(s), the Manager, Accountant and Custodian of the locker cabinet, and one
respectable witness. A suitable remark about breaking open of Locker should be made in Locker
Register, Renewal Diary and Specimen Signature Card.
xxx The procedure laid down by the Reserve Bank of India guidelines has been completely flouted by
the opposite party by not maintaining the locker register, locker key register, non−payment of rent
dues and lastly the procedure that should be adopted for breaking open a locker etc.” (emphasis
supplied) 9.3 In Mamata Chaudaha (supra), though the National Commission dismissed the
complaint on the facts of that case, it noted that the relationship between the bank and the locker
holders, who are also the account holders of the bank, will be that of a service provider and
consumer.
10. We may also refer to the circulars which the RBI has issued on this subject from time to time.
The 2007 Circular (supra) has, inter alia, provided the following recommendations for facilitating
easy and safe operation of lockers:
“1.4 Banks are also advised to give a copy of the agreement regarding operation of the
locker to the locker−hirer at the time of allotment of the locker. 2.1 Operations of Safe
Deposit Vaults/Lockers Banks should exercise due care and necessary precaution for
the protection of the lockers provided to the customer. Banks should review the
systems in force for operation of safe deposit vaults / locker at their branches on an
on−going basis and take necessary steps. The security procedures should be well−Amitabha Dasgupta vs United Bank Of India . on 19 February, 2021

documented and the concerned staff should be properly trained in the procedure. The
internal auditors should ensure that the procedures are strictly adhered to.
xxx 2.2 (ii) Where the lockers have not been operated for more than three years for medium risk
category or one year for a higher risk category, banks should immediately contact the locker hirer
and advise him to either operate the locker or surrender it. This exercise should be carried out even
if the locker hirer is paying the rent regularly. Further, the bank should ask the locker hirer to give in
writing, the reasons why he/she did not operate the locker. In case the locker hirer has some
genuine reasons as in the case of NRIs or persons who are out of town due to a transferable job etc.,
banks may allow the locker hirer to continue with the locker. Further, banks should ask the locker
hirer to give in writing, the reasons why he/she did not operate the locker. In case the locker−hirer
has some genuine reasons as in the case of NRIs or persons who are out of town due to a
transferable job etc., banks may allow the locker hirer to continue with the locker. In case the
locker−hirer does not respond nor operate the locker, banks should consider opening the lockers
after giving due notice to him…
(iii) Banks should have clear procedure drawn up in consultation with their legal advisers for
breaking open the lockers and taking stock of inventory.” (emphasis supplied) Hence the RBI had
issued clear directions as far back as in 2007 imposing duty of care in respect of protection of the
bank lockers and mandating transparency vis a vis the locker holder in allotment and breaking open
of the lockers. However, it has been left to the discretion of the individual banks to formulate the
exact procedures for fulfilling this duty of care. The banks are likely to draft the locker hiring
agreements in a manner which is favourable to their interests, including clauses to the effect that the
lockers are to be operated at the consumers’ own risk. 10.1. On 1.07.2015, the RBI issued a Master
Circular No. 59/2015−16 on Customer Service in Banks which included updated guidelines on locker
operation. However, these were more or less similar to what has already been stated in the 2007
Circular. Further, neither of the aforementioned Circulars provide any guidance on the degree of
care that needs to be exercised by the bank for safeguarding the lockers or detail the exact steps that
should be taken in this regard.
11. It appears to us that the present state of regulations on the subject of locker management is
inadequate and muddled. Each bank is following its own set of procedures and there is no
uniformity in the rules. Further, going by their stand before the consumer fora, it seems that the
banks are under the mistaken impression that not having knowledge of the contents of the locker
exempts them from liability for failing to secure the lockers in themselves as well. In as much as we
are the highest Court of the country, we cannot allow the litigation between the bank and locker
holders to continue in this vein. This will lead to a state of anarchy wherein the banks will routinely
commit lapses in proper management of the lockers, leaving it to the hapless customers to bear the
costs. Hence, we find it imperative that this Court lays down certain principles which will ensure
that the banks follow due diligence in operating their locker facilities, until the issuance of
comprehensive guidelines in this regard.
12. Thus, we emphasize that irrespective of the value of the articles placed inside the locker, the
bank is under a separate obligation to ensure that proper procedures are followed while allottingAmitabha Dasgupta vs United Bank Of India . on 19 February, 2021

and operating the lockers:
(a) This includes maintenance of a locker register and locker key register.
(b) The locker register shall be consistently updated in case of any change in
allotment.
(c) The bank shall notify the original locker holder prior to any changes in the
allotment of the locker, and give them reasonable opportunity to withdraw the
articles deposited by them if they so wish.
(d) Banks may consider utilizing appropriate technologies, such as blockchain
technology which is meant for creating digital ledger for this purpose.
(e) The custodian of the bank shall additionally maintain a record of access to the
lockers, containing details of all the parties who have accessed the lockers and the
date and time on which they were opened and closed.
(f) The bank employees are also obligated to check whether the lockers are properly
closed on a regular basis. If the same is not done, the locker must be immediately
closed and the locker holder shall be promptly intimated so that they may verify any
resulting discrepancy in the contents of the locker.
(g) The concerned staff shall also check that the keys to the locker are in proper
condition.
(h) In case the lockers are being operated through an electronic system, the bank
shall take reasonable steps to ensure that the system is protected against hacking or
any breach of security.
(i) The customers’ personal data, including their biometric data, cannot be shared
with third parties without their consent. The relevant rules under the Information
Technology Act, 2000 will be applicable in this regard.
(j) The bank has the power to break open the locker only in accordance with the
relevant laws and RBI regulations, if any. Breaking open of the locker in a manner
other than that prescribed under law is an illegal act which amounts to gross
deficiency of service on the part of the bank as a service provider.
(k) Due notice in writing shall be given to the locker holder at a reasonable time prior
to the breaking open of the locker. Moreover, the locker shall be broken open only in
the presence of authorized officials and an independent witness after giving due
notice to the locker holder. The bank must prepare a detailed inventory of any articles
found inside the locker, after the locker is opened, and make a separate entry in theAmitabha Dasgupta vs United Bank Of India . on 19 February, 2021

locker register, before returning them to the locker holder. The locker holder’s
signature should be obtained upon the receipt of such inventory so as to avoid any
dispute in the future.
(l) The bank must undertake proper verification procedures to ensure that no
unauthorized party gains access to the locker. In case the locker remains inoperative
for a long period of time, and the locker holder cannot be located, the banks shall
transfer the contents of the locker to their nominees/legal heirs or dispose of the
articles in a transparent manner, in accordance with the directions issued by the RBI
in this regard.
(m) The banks shall also take necessary steps to ensure that the space in which the
locker facility is located is adequately guarded at all times.
(n) A copy of the locker hiring agreement, containing the relevant terms and
conditions, shall be given to the customer at the time of allotment of the locker so
that they are intimated of their rights and responsibilities.
(o) The bank cannot contract out of the minimum standard of care with respect to
maintaining the safety of the lockers as outlined supra.
13. In the present case, it is undisputed that the Respondent Bank inadvertently broke the
Appellant’s locker, without any just or reasonable cause, even though he had already cleared his
pending dues. Moreover, the Appellant was not given any notice prior to such tampering with the
locker. He remained in the dark for almost a year before he visited the bank for withdrawing his
valuables and enquired about the status of the locker. Irrespective of the valuation of the ornaments
deposited by the Appellant, he had not committed any fault so far as operation of the locker was
concerned. Thus, the breaking open of the locker was in blatant disregard to the responsibilities that
the bank owed to the customer as a service provider. The alleged loss of goods did not result from
any force majeure conditions, or acts of third parties, but from the gross negligence of the bank
itself. It is case of gross deficiency in service on the part of the bank.
14. Thus, looking to the facts and circumstances of the case, we deem it appropriate to impose costs
of Rs. 5,00,000/− on the Bank which should be paid to the Appellant as compensation. The amount
of Rs. 5,00,000/− shall be deducted from the salary of the erring officers, if they are still in service.
If the erring officers have already retired, the amount of costs should be paid by the Bank.
Additionally, the Appellant shall be paid Rs. 1,00,000/− as litigation expense.
15. Before concluding, we would like to make a few observations on the importance of the subject
matter of the present appeal. With the advent of globalization, banking institutions have acquired a
very significant role in the life of the common man. Both domestic and international economic
transactions within the country have increased multiple folds. Given that we are steadily moving
towards a cashless economy, people are hesitant to keep their liquid assets at home as was the case
earlier. Thus, as is evident from the rising demand for such services, lockers have become anAmitabha Dasgupta vs United Bank Of India . on 19 February, 2021

essential service provided by every banking institution. Such services may be availed of by citizens
as well as by foreign nationals. Moreover, due to rapid gains in technology, we are now transitioning
from dual key−operated lockers to electronically operated lockers. In the latter system, though the
customer may have partial access to the locker through passwords or ATM pin, etc., they are
unlikely to possess the technological know−how to control the operation of such lockers. On the
other hand, there is the possibility that miscreants may manipulate the technologies used in these
systems to gain access to the lockers without the customers’ knowledge or consent. Thus the
customer is completely at the mercy of the bank, which is the more resourceful party, for the
protection of their assets.
In such a situation, the banks cannot wash off their hands and claim that they bear no liability
towards their customers for the operation of the locker. The very purpose for which the customer
avails of the locker hiring facility is so that they may rest assured that their assets are being properly
taken care of. Such actions of the banks would not only violate the relevant provisions of the
Consumer Protection Act, but also damage investor confidence and harm our reputation as an
emerging economy.
15.1 Thus it is necessary that the RBI lays down comprehensive directions mandating the steps to be
taken by banks with respect to locker facility/safe deposit facility management. The banks should
not have the liberty to impose unilateral and unfair terms on the consumers. In view of the same, we
direct the RBI to issue suitable rules or regulations as aforesaid within six months from the date of
this judgment. Until such Rules are issued, the principles stated in this judgment, in general and at
para 13 in particular, shall remain binding upon the banks which are providing locker or safe deposit
facilities. It is also left open to the RBI to issue suitable rules with respect to the responsibility owed
by banks for any loss or damage to the contents of the lockers, so that the controversy on this issue
is clarified as well.
16. The Appeal is disposed of accordingly.
................................................J. (MOHAN M. SHANTANAGOUDAR) ...............................................J.
(VINEET SARAN) NEW DELHI FEBRUARY 19, 2021Amitabha Dasgupta vs United Bank Of India . on 19 February, 2021

