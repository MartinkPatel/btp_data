Bakhtawar Singh vs State Of Punjab And Ors. on 6 October,
1970
Equivalent citations: AIR 1971 PUNJAB AND HARYANA 220
JUDGMENT
  H.R. Sodhi, J.  
1. This writ petition is directed against the order of the Governor of Punjab passed on 25th April,
1969, whereby the State Government, in exercise of the powers conferred on it under sub-clause (iv)
of Clause (e) of sub-section (1) of S. 10 of the Electricity (Supply) Act, 1948 (hereinafter referred to
as the Act) removed the petitioner from the office of whole-time Member of the Punjab State
Electricity Board, hereinafter called the Board.
2. The petitioner was appointed on 29th April, 1967, a s a whole-time (non-official) Member of the
Board under sub-section (2) of S. 5 of the Act, for a period of five years with effect from 1st May,
1967. The appointment was notified in the Punjab Government Extraordinary Gazette, the relevant
extract where from is appended as Annexure 'A' with the writ petition. The terms and conditions of
his appointment are not indicated in the order but are to be found in the Punjab State Electricity
Board Rules, 1959, (hereinafter called the Rules) published in the Punjab Government Gazette of
June 21, 1963. The petitioner as a member of the Board was to get gross monthly emoluments of Rs.
1200/-. We are informed that this amount has been raised by an amendment in the said Rules to Rs.
1800/- per month. As provided in Rule 6, it is open to the Chairman or a member to resign his office
by giving three months' notice in writing to the Government though such a condition can be waived.
3. When the appointment of the petitioner was made by the State Government, respondent 2 was
the Chief Minister in Punjab and late Shri Lachhman Singh Gill was Minister Incharge of the
Irrigation and Power Departments who processed the file relating to the appointment. Respondent
NO. 2 resigned on 22nd November, 1967, and Shri Lachhman Singh took oath of office as the Chief
Minister on 25th of the same month. The latter too resigned on 23rd August, 1968, and in the wake
of his resignation there came President's rule in the State followed by mid-term elections to the
State Legislative Assembly. The results of the elections were announced somewhere on 9/10th
February, 1969 and Shri Gurnam Singh respondent 2 again headed the Punjab Cabinet on 16th
February, 1969. It may be stated that respondent 2 was the leader of the Akali party in the
Legislative Assembly and Shri Lachhman Sing was also a member of the same party till the fall of
the former's ministry on 22nd November, 1967. Shri Lachhman Singh had defected and organised
Janta Party before he assumed office of the Chief Minister on 25th November, 1967. All this
information , as supplied in the course of arguments, has been taken by the common consent of the
learned counsel for the parties as correct though no reference thereto is to be found either to the
writ petition or in any other document on the record.Bakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

During President's rule some complaints seem to have been made against the alleged acts of
corruption and nepotism of Shri Lachhman Singh during his term of office as Chief Minister from
25th November, 1967 to 23rd August, 1968, and a memorandum in this regard was submitted by the
leaders of the Akali party, including respondent 2, to the President of India. These charges were
inquired into by Shri Naronha, one of the Advisers to the Governor, Punjab, who was administering
the State on behalf of the President.
4. The case of the petitioner is that in the memorandum he was described a close associate of Shri
Lachhman Singh and that respondents 2 and 3 became his enemies because they believed him to be
so. It is alleged that apart from political rivalry between respondent 2 and Shri Lachhman Singh
who brought about the fall of the ministry headed by this respondent, respondent 3 was also very
antagonistic because he had lost mid-term election to the State Assembly to Shri Lachhman Singh
from Dharamkot Constituency. According to the averments in the writ petition, it was not only Shri
Lachhman Singh but the petitioner too who was being held responsible from the fall of the ministry
and on that score both respondents 2 and 3 are stated to have joined hands for arbitrarily securing
removal of the petitioner from membership of the Board. We find that on 11th February, 1969, a day
after the results of the mid-term elections had been declared, a notice was served on the petitioner
calling upon him to explain within a period of 10 days from the receipt of the notice as to why he
should not be removed from membership of the Board. A statement of allegations was given t him
and it is necessary to reproduce them verbatim hereunder:-
"(i) A few days after the formation of Janta Party's Ministry, you went to village
Poohli, P. S. Nathana, and contacted Shri Hardit Singh, the then M. L. A. (Akali
Party) from Nathana Constituency and persuaded him to join Janta Party where he
would be made a minister. Thereafter also you met him twice or thrice at Chandigarh
and pressed him to join Janta Party.
(ii) After Janta Party's ministry was formed towards the end of the year 1967, you
contacted Shri Gurdev Singh of village Badal, the then M. L. A. (Akali Party) from
Muktsar Constituency twice or thrice at Muktsar and persuaded him to join Janta
Party.
(iii) On 3rd January, 1968, a meeting of the Akali Party was to be held in Gurdwara
Alamgir in Ludhiana district with a view to expelling Shri Lachhman Singh Gill from
Akali Party. On 2nd of January, 1968, i. e. a day before this meeting you,
accompanied by Sant Harchand Singh of Longowal and Shri Raghbir Singh, member
S. G. P. C. of village Chatha Nakta, Tehsil Sunam, in his field in the aforesaid village
and asked him to persuade Sant Fateh Singh not to expel Shri Lachhman Singh Gill
from the Akali Party.
(iv) In the month of January, 1968, you contacted Shri Kundan Singh Pattang of
village Sehjra, the then M. L. A. (Akali Party) from Sherpur Constituency at his village
and perssurized him to join the Janta Party.Bakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

(v) About 11/2 months after the formation of Janta Party ministry in Punjab, you
contacted Shri Harbhagwan Singh of village Jakharwala, P. S. Jaito, the then M. L. A.
(Akali Party) Kotkapura Constituency at his village and persuaded him to join the
Janta Party. After about 11/2 months of this incident, you again visited his village to
pressurize him to leave the Akali Party and join the Janta Party. On his refusal to do
so, you threatened him with dire consequences.
(vi) On 4th of February, 1968, you met Shri Gurbachan Singh of village Lakhmirwala,
P. S. Sunam, the then M. L. A. (Akali Party) from Sunam Constituency at Chandigarh
and took him to Shri Lachhman Singh Gill, the then Chief Minister, Punjab, with the
intention of persuading him to join the Janta Party.
(vii) Immediately before the election of a member from Ferozepur Local authorities
constituency for Punjab Vidhan Parishad, in the month of April, 1968, you
approached Sarvshri Bikkar Singh and Ch. Rawal Ram. Municipal Commissioners of
Moga and Shri Gurjit Singh, member Block Samiti of that place, to support Shri
Jagmohan Singh who belonged to the same village as that of Shri Lachhman Singh
Gill and was being supported by the latter.
(viii) The day Shri Harbhaj, M. L. A. from Banga constituency was to be sworn in as a
Deputy Minister in Janta Party's ministry, you brought him in your AIR 1971
Rajasthan to Chandigarh and even before that you had contacted him more than once
with a view to persuading him to join Janta Party. "
5. On receipt of the notice, the petitioner asked for certain documents and other information vide
letter dated 3rd March, 1969, a copy whereof is Annexure 'D'. These documents included copies of
some T. A. bills of several persons including that of Shri Lachhman Singh Gill, former Chief Minister
Shri Natha Singh, Ex-State Minister for Irrigation and Power, and also the alleged statements of all
individuals of which the show cause notice was founded. This letter of the petitioner was addressed
to the Director. Special Enquiry Agency, Punjab, Chandigarh, who had taken up investigation
against the former and others during President's rule. Simultaneous he wrote another letter to the
Secretary, Public Works Department, enclosing with it a copy of the letter addressed by him to the
Director, Special Enquiry Agency. It was stated by the petitioner that he should not be condemned
of the ex parte statements obtained behind his back and that he should be afforded an opportunity
to cross-examine those persons who deposed against him as they had been asking him for special
favours with regard to which he was in possession of massive documentary evidence, and to lead
defence evidence.
6. A request was made that a High Court Judge be appointed as the commissioner of enquiry. The
petitioner has been recalled from medical leave and in subsequent letter of 7th March, 1969, he
asked the same Secretary for copies of the orders of the Chairman. Punjab State Electricity Board, as
made on his applications for medical leave and also a copy of the instructions issued by the Chief
Minister respondent regarding his leave applications. Another document, a copy whereof was
sought, was the memorandum submitted by respondent 2 and others to the Central GovernmentBakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

against Shri Lachhman Singh Gill. Emphasis was laid by the petitioner on the alleged resignation
submitted by Shri Gian Singh Kahlon in the time of Shri Lachhman Singh as the Chief Minister, the
suggestion being that the latter had written something on that resignation which could help the
petitioner in establishing the connivance of some high-ups in the matter of issue of show cause
notice to him during President's rule. The reference presumably was to Shri Gian Singh Kahlon who
was one of the advisers to the Governor during the said rule. An interim reply was submitted by the
petitioner on the same date, that is, 7th March, 1969. The gravamen of the charge, as it appears from
the statement of allegations, was that the petitioners approached members of the Legislative
Assembly (Akali Party) and others in order to persuade them to defect their party and join Janta
Party where some of them could be given high offices.
7. The petitioner refuted these allegations saying with respect to every one of them that the charge
was vague, false and baseless. He repeated in his reply what he had stated earlier in his applications
addressed to the Director, Special Enquiry Agency, and Secretary, Public Works Department
(Irrigation and Power), that he should be afforded and opportunity to cross-examine the witnesses
who had made statements to the police behind his back and on whom the Government proposed to
rely. The stand of the petitioner was that the was a deep-rooted conspiracy against him by
disgruntled persons who were not successful in getting undue favours from him as a member of the
Board. As a matter of fact it was pleaded by him that the show cause notice was issued at a time
when it was almost sure that Akali Party headed by respondent 2 along with the Jan Sangh support
was going to form the Government in the State. Several legal issues regarding the power of the State
Government to remove him under Section 10 of the Act were raised.
8. After the interim reply had been sent, the petitioner was informed by the Director, Special
Enquiry Agency, vide letter dated 15th March, 1969, that the show cause notice was based on the
statements of the following witnesses:-
1. Shri Hardit Singh, M. L. A. village Puhli, District Bhantinda.
2. Shri Gurdev Singh, M. L. A. , Constituency Muktsar, District Ferozepur.
3. Shri Shivdarshan Singh, Member, S. G. P. C. , village Chatha Nakta, P. S. Sunam,
District Sangrur.
4. Shri Kundan Singh Patang, M. L. A. village Sehjra, P. S. Mehal Kalan, District
Sangrur.
5. Shri Harbhagwan Singh, Ex M. L. A. village Jhakharwala, P. S. Jaito, District
Bhatinda.
6. Shri Gurbachan Singh, M. L. A. , village Lakhmirwala, P. S. Sunam, District
Sangrur.
7. Shri Bikkar Singh, Municipal Commissioner, Moga, District Ferozepur.Bakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

8. Shri Gurjit Singh, Member Block Samiti, Moga District Ferozepur.
9. Ch. Rawal Ram, Municipal Commissioner, Moga, District Ferozepur.
10. Shri Mukhtiar Singh, Driver, Punjab State Electricity Board, Patiala.
11. Shri Ram Sarn, Sub Inspector, Police, District Jullundur.
12. Shri Yash Pal, A. S. I. Police, Jullundur.
13. Shri Ram Sarup, Clerk, Toll Tax Barrier, Bridge Sutlej, Rupar.
The petitioner was further told that he could consult the statements of the above witnesses of any
working day within a stipulated time and he then thought that it was absolutely essential to have
copies of the statements of some particular witnesses, the same could be supplied to him on a
written request. The other record desired by the petitioner was considered to be not relevant and
copies thereof could not, therefore, be supplied to him nor was it deemed expedient to show the
same to him. The petitioner reiterated in his letter of 25th March, 1969, (Annexure 'H') that the
documents relied upon by him were very material for his purposes and that the only way to afford
him an opportunity to defend himself against the charges was to appoint a High Court Judge as
commission of enquiry and give him an opportunity to cross-examine those witnesses and lead his
defence evidence. In other words, he wanted a regular and full -fledged enquiry. Another reply was
sent by him on 28th March, 1969, but nothing new was stated. He denied the allegations and
reiterated his demand for enquiry.
9. There then came letter, Annexure 'J', from the Secretary to Government Punjab, Irrigation and
Power Departments, along with which were supplied attested copies of the statements of 13
witnesses referred to above. It seems that the petitioner did not go to the office to inspect the record
as suggested to him in the letter of 15th March, 1969 (Annexure 'GI') but in spite of his failure to do
so, the copies were supplied. The petitioner continued corresponding with the secretary to
Government, Punjab, Irrigation and Power Departments, and sent a telegram on April 12, 1969,
asking for a copy of the report of the Deputy Superintendent of Police submitted to the Director,
Special Enquiry Agency, and the consequent report of the Director himself as submitted to the
Government, to enable him to give a proper reply.
9-A. The requests of the petitioner for the various documents, relevant or otherwise, having met
with no success, the petitioner submitted his final reply on 16th April, 1969, and a copy thereof is
Annexure 'M' with the writ petition. Again nothing new was said and the same pleas were repeated
asking for a proper enquiry and he denied the charges levelled against him. All this culminated in
the impugned order passed on 25th April, 1969, whereby the petitioner was removed from
membership of the Board.
10. Hence the present writ petition in which in addition to the State of Punjab, Shri Gurnam Singh,
former Chief Minister, Shri Sohan Singh Bassi, the then Irrigation and Power Minister, and theBakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

Punjab State Electricity Board, Patiala, are impleaded as respondents.
11. As affidavit, in reply, on behalf of the State was filed by the Secretary to Government, Punjab,
Irrigation and Power Department. Respondents 2 and 3 file their affidavits in regard to the
averments in the writ petitioner so far as they related to them. The Secretary, Punjab State
Electricity Board, filed an affidavit in reply in which it has been stated that the Chief Minister of
Punjab had ordered the Chairman of the Board not to sanction any further leave of the petitioner
and that the papers might be sent to him for proper orders. It is further stated that the extension of
medical leave applied for by the petitioner was not sanctioned by the Chairman as the work of the
Board was suffering due to absence of the petitioner. The petitioner stated in the writ petition that
he had not handed over the charge because it was not specified in the order as to who was to take
over the charge from him. In regard to this plea, the Secretary of the Board stated that it was not
correct on the part of the petitioner to keep documents in his possession at his residence and that he
was informed by a demi-official letter to hand over the charge to Shri Sudarshan Kumar Sharma,
Confidential Stenographer to the Assistant Secretary (P. )
12. Apart from the preliminary objections to the effect that Art. 311 of the Constitution did not apply
and services of the petitioner had been terminated in accordance with the terms of the statute, it was
pleaded by the State that the charges had been framed against him on 11th February, 1969, when the
State of Punjab was being administered by the President of India. The allegations against the Chief
Minister were denied by the Secretary in his affidavit for want of knowledge and with respect to the
allegation of mala fide against the Chief Minister who directed the Chairman not to sanction further
medical leave, it was stated that the petitioner went on leave from 3rd February to 7th February,
1969, in the first instance. The telegram is said to have been sent by the petitioner from Yamuna
Nagar asking for extension of leave by praying for further extension of leave by 10 days and this
request was supported by a medical certificate from a private practitioner. During his absence on
leave, the show-cause notice was sent to Patiala from Chandigarh by a special messenger on 11th
February, 1969. Several attempts were made to serve the petitioner with the charge-sheet but his
address being not available in the office, the Chief Minister was justified in ordering that any
extension of leave applied for by the petitioner should be sent to him for orders. The demand of the
petitioner for documents and records was pleaded to be unreasonable and it was stated by the
Secretary that no regular enquiry was ordered by the Government nor was the petitioner entitled to
any such enquiry where he should have been given the opportunity to cross-examine the witnesses
and lead his defence evidence. The case of the State is that the terms of the statute were complied
with and his explanation obtained.
13. Respondent 2, in his affidavit, denied that the petitioner was treated as Shri Lachhman Singh
Gill's man and that on that account he was removed from membership of the Board or that there
was any enmity between him and the petitioner. The averments of this respondent is that while
dealing with an employee he was never swayed by any political considerations and that a
memorandum was submitted by him to the President only as one of the members of the Akali Party.
He admitted that he directed the Chairman of the Board not to sanction any further leave to the
petitioner and that papers should be sent to him as he though such an order to be in public interest
because the work of the Board was suffering due to the continued absence of the petitioner. He, asBakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

sated by him, had reason to believe that the petitioner was avoiding service of notice which had been
issued on 11th February, 1969, before the respondent took over as the Chief Minister of the State.
14. In the affidavit filed by the respondent 3 who, as Irrigation and Power Minister, passed th
impugned order, it is admitted that the said respondent unsuccessfully contested election to the
Legislative Assembly against Shri Lachhman Singh Gill but he denied that he was in any way
opposed to the petitioner or that he arbitrarily secured his (petitioner's) removal from membership
of the Board because of any feeling of animosity or bias.
15. Mr. J. N. Kaushal, learned counsel for the petitioner, has raised the following contentions before
us:-
(1) That Section 10(1)(e)(iv) of the Act under which the power given to the State
Government purports to have been exercised is ultra vires the Constitution being
violative of Art. 14 thereof inasmuch as the language employed in it is so wide as to
give naked arbitrary unguided and unchannelised power to the Government and that
it being capable of abuse can be pressed into service for purposes beyond what are
contemplated by Act.
(2) That the principles of natural justice have been violated in the present case since
the petitioner was not afforded an opportunity to cross-examine those witnesses who
had deposed behind his back before he police and whose statements were used
against him. It is urged that the circumstances of the present case were such that
mere obtaining of an explanation, though a technical compliance with the terms of he
statute, was not in consonance with the notions of justice and fair play which form
the basis of the rule of law and a part of our Constitution. In other words, a proper
enquiry should have been held against the petitioner as claimed by him in his
representatives to the State Government. The submission is that rules of natural
justice were offended against because of the impugned order having been passed by
respondents 2 and 3 who were biased and inimically disposed against the petitioner.
The argument further is that the petitioner was entitled to be supplied the copies of
the documents asked for by him and particularly of the reports of the Director
Vigilance and Deputy Superintendent of Police which formed the basis of the
impugned order. The charges, according to the learned counsel, were highly vague
giving no exact particulars in many cases with the result that proper explanation to
them could not be given and the petitioner was consequently denied reasonable
opportunity for even an explanation.
(3) That the State Government acted as a quasi-judicial authority in the matter of
taking a decision in regard to termination of services of the petitioner and in the
capacity respondent 3 was bound to pass a speaking order giving a process of
reasoning so as to indicate how he arrived at the final conclusion.Bakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

(4) That the circumstances of the case and a perusal of the impugned order show that
respondent 3 did not apply his mind nor made a judicial approach and rather seemed
to be already determined to remove the petitioner from membership.
(5) That the charges levelled against the petitioner are unconnected with the
discharge of his duties as a member of the Board and the Act requires that there must
be some nexus between the conduct rendering a person unfit and the nature of duties
to be performed by him. In other words, removal of a person from membership in the
absence of any such link will be for reasons not contemplated by the Act even if
Section 10(1)(e)(iv) is held to be intra vires.
16. The contention regarding the ultra vires of Section 10(1)(e)(iv) is without substance and must be
repelled. The Act, is our democratic set up governed by the rule of law, provides for the
rationalisation of production and distribution of electricity in order to bring about electrical
development in the welfare State. The object is that the benefits of electricity are extended to urban,
rural and suburban areas, though a system of administration controlled by the Board constituted
under Section 5 of the Act. The Board has been made into a body corporate and is to have amongst
its members persons who have experience of commercial enterprises and administration and also
possess technical qualifications. Section 8 provides that the Chairman and members of the Board
are to hold office for such period and on such terms and conditions as may be prescribed by the
Rules. According to the Rules, the term of office of a member shall be for such period not exceeding
five years as may be fixed by the Government which is also to decide about the remuneration.
Section 9 enjoins that a member so long as he holds office shall not have any interest, direct or
indirect, in any firm or company carrying on the business of generation, transmission, distribution,
or use of electricity, or concerned with the manufacture, sale or hire of machinery apparatus, plan or
equipment which could be connected with such generation, transmission, distribution or use. If
prior to his appointment, a member had any such interst, he must inform the Government about it
before taking charge of his office and divest himself of the same. He is required to remain quite aloof
from political life of the country and if he even seeks to become a member of the Parliament, or the
State Legislature or any local body, he renders himself liable to removal from office.
Section 10 lays down the conditions and circumstances under which he can be removed or
suspended from office and the prohibition from entering public life is to be found in Clause (d)
sub-section (1) thereof. It may be useful to reproduce the relevant part of Section 10 for facility of
reference:-
"10. Removal or suspension of members:-
(1) The State Government may suspend from office for such period as it thinks fit or
remove from office any member of the Board who-
(a) is found to be a lunatic or becomes of unsound mind; or
(b) is adjudge insolvent; orBakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

(c) fails to comply with the provisions of Section 9; or
(d) becomes or seeks to become a member of Parliament or any State Legislature or
any local authority; or
(e) in the opinion of the State Government-
(i) has refused to act; or
(ii) has become incapable of acting; or
(iii) has so abused his position as a member as to render his continuance on the
Board detrimental to the interests of the general public; or
(iv) is otherwise unfit to continue as a member, or
(f) is convicted of an offence involving moral turpitude.
(2) The State Government may suspend any member pending an inquiry against him.
(3) No order of removal shall be made under this section unless the member
concerned has been given an opportunity to submit his explanation to the State
Government; and when such order is passed, the seat of the member removed shall
become vacant and another member may be appointed under Section 5 to fill up the
vacancy. (4) *** * (5) *** * It is Clause (iv) of sub-section (1) (e) of the above section
that is sought to be declared ultra vires Art. 14 of the Constitution. The attack is
directed on the ground that the power given to the State Government in the matter of
removal of a member is arbitrary, uncontrolled and unchannelised, admitting of
discriminatory classification of natural justice.
References in this connection has been made by Mr. Kaushal to a Full Bench judgment of this Court
in Shiromani Gurdwaras Parbandhak Committee, Amritsar v. Lachhman Singh Gill, Chief Minister,
Punjab, ILR (1968) 2 Punj and Har 1 = (AIR 1970 Punj 40) (FB) where Section 79 of the Sikh
Gurdwaras Act, 1925, was held to be violative of Article 14 of the Constitution and therefore, invalid
and void on the line of the argument now advanced before us. Two of the members of the Judicial
Commission constituted under the Act had been removed under Clause (iv) of Section 79 by the
State Government on the ground that they had served as members for more than two years. The
argument on the side of the petitioners that this provision of law gave arbitrary, capricious,
unguided and uncontrolled power without any indication on what basis the discretion vesting in the
State Government was to be exercised, and being capable of admitting discrimination and abuse of
authority must be held to be ultra vires Art. 14 of the Constitution was accepted.
The learned Judges constitution the Full Bench considered the scheme of the Act and came to the
conclusion that there was really nothing in the preamble and the main body thereof which could
show how he policy of the Act could be effectuated by the whimsical and capricious exercise ofBakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

power under Clause (iv) of the said section since any one of the members of the Judicial
Commission could be picked up by the Government for removal after two years without there being
anything more. The object or policy of giving this unbridled power to the State Government under
the Sikh Gurdwaras Act and was not found discernible in the said Act and the view taken, therefore,
was that instead of there being security of service commencing after a member had served on the
Judicial Commission for two years, Section 79 (iv) created insecurity by making his further
continuance in office dependant on the whim and caprice of the executive. It was in such a situation
that the learned Judges looked up for some guidance in the Act but the same was not to be found. In
Clause (i) of Section 79 of the said Act, there is given power to the State Government to remove a
member of the Judicial Commission "if he refuses to act or becomes in the opinion of the State
Government incapable of acting or unfit to act as a member. "
With regard to the power exercisable under this Clause (1) of Section 79, it was
observed by the learned Judges that the exercise of such a power is in the wake of the
object and policy of the Act as is to be seen in the preamble and the main body
thereof. No fault could be found with Clause (i) which gave wide discretion to the
Government to remove a member on the ground of his being unfit to continue in
office, though power to remove on the expiry of two years was held to be
unchannelised and arbitrary, with no guidance coming from the Act for the exercise
of such power. No doubt the validity of Clause (i) of Section 79 of the Sikh Gurdwaras
Act, which is substantially in the same terms as Clause (i) of Section 79 of the Sikh
Gurdwaras Act, which is substantially in the same terms as Clause (iv) of Section
10(1)(e) of the Act, was not the subject of direct challenge, but the learned Judges did
observe that such a provision was intra vires, and that exception could be taken to
Clause (iv) of Section 79 of the said Act only to which a reference has already been
made above.
In the case before us, policy of the Act in inserting Clause (iv) of Section 10(1)(e) and
the guiding principles for the exercise of discretion are easily discernible and one can
find a clear clue as to the circumstances in which the discretion should be exercised
by the State Government in regard to the removal of a member of the Board on the
ground of his being unfit for the office. The Board which is a body corporate is, as
already stated, brought into being to rationalise and distribute the benefits of
electricity amongst the public and the legislature has gone to the extent of laying
down that no member of the Board is to go near the prortals of political arena by even
seeking to become a member of Parliament. State Legislature or a local body. He is
also not to have any interst in a commercial undertaking connected even remotely
with the generation, transmission, distribution or use of electric power. All these
prohibitions are laid down to ensure the discharge of duties honestly and with
integrity by members of the Board. It was impossible for the legislature to enumerate
the various types of conduct, special circumstances or reasons, which could make a
person unfit to continue as a member of the Board and in the nature of things,
keeping in view the duties to be performed, it was necessary to have left the
discretion with some high authority to decide whether a particular member was fit toBakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

continue in office or not. The presumption of law is in favour of constitutionality of
the provision and Mr. Kaushal has not been able to show, beyond vehemently
stressing that the discretion was capable of abuse, how any unreasonable
classification was created. The test of unfitness is to be found in each case on an
objective data having some nexus with the object sought to be achieved by the Act.
Moreover, the power is vested in no less an authority than the State Government and
it cannot be assumed that discretion will in every cases be exercised arbitrarily or
capriciously.
17. It is indeed for the State Government to find out, in good faith, the degree of harm likely to be
caused by a particular conduct of a member and then determine whether his continuance in office
would be desirable or not. The mere fact that there is a discretionary power given to the State
Government to decide whether a member of the Board is fit to continue to hold office or not is not
by itself sufficient to strike down the provision contained in the Act. The legislative provision may
not by itself be discriminatory but when an order of removal of a member of the Board is passed
mala fide or discriminates one with reference to others similarly situated, the aggrieved party is not
without a remedy and the order can be struck down as having created a classification without any
reasonable basis or hypothesis. AIR 1957 SC 397. The charge of violation of equal protection will in
such a case be against the State Government which having a discretion vested in it exercised the
same arbitrarily. In such circumstances, it is not the provision of law which can be said to be bad but
the exercise of power thereunder.
In M/s. Pannalal Binjraj's case. AIR 1957 SC 397 the validity of S. 5 (7-A) of the Income-tax Act,
1922, as amended by the Indian Income-tax Amendment Act, 1940. Section 3 whereof inserted the
new Section 5(7-A), was challenged. This newly added section enabled the Commissioner of
Income-tax and the Central Board of Revenue, to transfer any case from of Income-tax officer to
another. Such a transfer could be made at any stage of the proceedings. Several assessees filed their
respective petitions in the Supreme Court impugning the validity of transfer orders passed by the
Central Board of Revenue on the ground that Section 5(7-A) was ultra vires the Constitution. The
argument raised was that the said power of transfer to the Commissioner of Income-tax or the
Central Board of Revenue was not hedged with any conditions and was completely arbitrary,
unguided and uncontrolled enabling the said Commissioner or the Central Board to discriminate the
case of one assessee from those of others in a like situation and transfer the case from one State to
another. This assessees claimed that under Section 64 of the Income-tax Act, they had right to be
assessed by the Income-tax Officer of the place where they resided or carried on their business,
profession or vocation.
Their Lordships, while holding that Section 64 does give a right to the assessee to be assessed by the
Income-tax Officer of a particular area or locality where he resides or carries on a business, have
observed that this right is subject to the exigencies of tax collection and Section 5(7-A) which had
been inserted for administrative convenience controls that right. The argument that it gave wide
unbridled discretion to the Commissioner of Income-tax and Central Board of Revenue was
repelled, it being held that the appropriate authority has to determine what are the proper cases in
which such power is exercisable having regard to the object of the Act and the ends to be achieved.Bakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

There may in the opinion of their Lordships, arise cases which create complications and where in
view of the widespread activities and large ramifications of interrelated transactions it might be
necessary on account of administrative exigencies or for proper assessment of income-tax that a
particular case be transferred from one office to another. The discretionary power vesting in the
Commissioner of Income-tax that a particular case be transferred from one officer to another. The
discretionary power vesting in the Commissioner of Income-tax and the Central Board of Revenue
was, therefore, held not to be arbitrary, unfettered or unguided, which could enable an authority to
pick and choose one assessee out of those similarly circumstances. In other words, the mere vesting
of discretion in a proper authority does not by itself render the provision discriminatory.
18. There is yet another approach to the matter. The Act does not permit the exercise of discretion in
an arbitrary manner inasmuch as it is obligatory on the State the delinquent member to explain the
charges against him before any action by way of suspension or removal from office can be taken
against him. The statutory provision requiring explanation to be obtained is by itself a great check
on the exercise of discretion and an order passed after consideration of the explanation is intended
by law to be based on an objective data. Section 10(1)(e)(iv) of the act is intra vires of the
Constitution and valid. It has to be seen on the facts and circumstances of each case where an
individual order is discriminatory or mala fide passed by an abuse of power vested in the competent
authority.
19. The next contention that the petitioner had a right to claim that a full-fledged regular enquiry
should have been held against him by appointing an enquiry officer is equally devoid of force. It
cannot be urged with any reasonableness that no matter that the statue requires only an explanation
to be obtained, the person proceeded against has still a right to demand that instead of obtaining
explanation from him an elaborate enquiry be instituted. Such an argument based on rules of
natural justice is wholly misconceived. No doubt, as observed by their Lordships of the Supreme
Court, "the doctrine of natural justice cannot be imprisoned within the strait-jacket of a rigid
formula", and, that its horizon is vast expanding in a welfare State, still the policy of the particular
statue has always to be kept in view in order to find out how far some further rules of natural justice
can be invoked when the legislature itself has embodies some of them in that statute. As observed by
their Lordships of the Supreme Court in Union of India v. Col. J. N. Sinha, Civil Appeal No. 381 of
1970 D/-12-8-1970 = (reported in AIR 1971 SC 40) if a statutory provision either specifically or by
necessary implication excludes the application of any or all the principles of natural justice, then the
court cannot ignore the mandate of the legislature or the statutory authority and read into the
concerned provisions principles of natural justice. The mandatory provision under Section 10 of the
Act requiring an explanation to be obtained is an incorporation of an elementary rule of natural
justice and prescribes one of the recognised modes of enquiry. The legislature has in its wisdom
considered that essentials of justice and fair play would be satisfied if the scope of an enquiry is
restricted to an explanation only.
In Ridge v. Baldwin, (1963) 2 All ER 66, to which reference has been made by their Lordships in Dr.
Bool Chand v. The Chancellor, Kurukshetra University, 1968 Ser LR 119 = (AIR 1968 SC 292) the
cases of dismissal of a servant by his master have been classified into three categories, one of which
is where there must be something against a man before he is dismissed, as is the case before us.Bakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

Where a person holds office at a pleasure of the master or there is contractual service, no enquiry is
needed before the services of the employee are terminated except that in case of a breach of
contract, the aggrieved person may in a proper case, be entitled to damages. In case of the third
category when dismissal can be effected only on the existence of some objective data against the
servant, the rule of a case as one of the principles of justice and fair play. The only import of this
principles is that "an officer cannot lawfully be dismissed without first telling him what is alleged
against him hearing his defence or explanation. " An inquiry does not, therefore, necessarily
postulate the appointment of an inquiry with the delinquent official arrayed as an accused and the
prosecution as an accuser; where witnesses must be examined and permitted to be cross-examined
and giving an opportunity to the official to lead evidence in defence. The expression 'inquiry',
according to its ordinary dictionary meaning, includes even seeking information by asking
questions. It is, in other words, a search for truth and the same can be done sometime by getting an
explanation. When the legislature lays down a particular mode by which truth is to be sifted, it
cannot be claimed as of right supposedly founded on the rules of natural justice that in spite of the
requirement of law being only an explanation, a regular inquiry of the type contemplated by Art. 311
of the Constitution must be instituted in every case. The use of the word explanation in Section 10
implies that no member shall be removed until he has been informed of the cause for removal and
allowed an opportunity of explanation which may consist of his oral or written statement without
the process and formality that is required in a case where an inquiry almost equated with a trial is
held. It is a different matter if the competent authority by making a judicial approach honestly feels
that in order to find out truth and do justice to the delinquent explanation alone is not sufficient and
that witnesses should be examined, cross-examined in the presence of the official concerned and he
be given an opportunity to lead defence evidence.
Mr. Kaushal relies in this connection on some observations of their Lordships of the Supreme Court
in Dr. Bool Chand's case, 1968 Ser LR 119 = (AIR 1968 SC 292) (Supra). Dr. Bool Chand was
appointed Vice-Chancellor of Kurukshetra University under Kurukshetra University Act (Act 12 of
1956) for a term of five years. The University, the statutes or the ordinances did not lay down any
conditions in which appointment of the Vice-Chancellor could be determined nor did it contain any
limitation on the exercise of the power of the Chancellor in the matter of terminating the
employment of the Vice-Chancellor, Dr. Bool Chand was a member of the Indian Administrative
Service wherefrom he was compulsorily retired. When this information came to the notice of the
Chancellor, a notice was issued to Dr. Bool Chand to show cause why his services as Vice-Chancellor
be not terminated. He submitted his representation and the Chancellor ultimately terminated his
services before the expiry of five years. A question arose whether a person appointed as
Vice-Chancellor in such circumstances was entitled to continue in office for the full term of his
appointment. When there was no provision in the statute for determining the employment nor was
any procedure contained therein in this regard. It was urged on behalf of Dr. Bool Chand that the
Chancellor was bound hold an inquiry before termination his tenure in accordance with the rules of
natural justice. In this context emphasis has been laid by the learned counsel on the following
observations of their Lordships:-
"But once the appointment is made in pursuance of a Statute, though th appointing
authority is not precluded from determining the employment, the decision of theBakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

appointing authority to terminate the appointment may be based only upon the result
of an enquiry held in a manner consistent with the basic concept of justice and fair
play. "
Again another observation of their Lordships is equally relevant:-
"The power to appoint Vice-Chancellor has its source in the University Act:
................... . The power may not be exercised arbitrarily it can be only exercised for
good cause, i. e. , in the interests of the University and only when it is found after due
enquiry held in a manner consistent with the rules of natural justice, that the holder
of the office is unfit to continue as Vice-Chancellor. "
20. Dr. Bool Chand had raised an issue that the then Chancellor knew about the fact of compulsory
retirement before his appointment as Vice-Chancellor and on this question an enquiry was needed.
An observation has again been made by their Lordships in the following terms:-
"The Chancellor, Sardar Ujjal Singh, was in our judgment, under no obligation,
unless moved by the appellant, to hold such enquiry. "
21. It is on the basis of all these observations that an argument is raised before us that in the instant
case the petitioner could ask for an inquiry and the same was, therefore, necessary. Fact sin Dr. Bool
Chand's case, 1968 Ser LR 119 = (AIR 1968 SC 292) were entirely different. The University Act
under which Dr. Bool Chand was appointed as Vice-Chancellor did not contain any provision
relating to the termination of the services of a Vice-Chancellor nor was there to be found in it a
provision as we have in the present Act of obtaining an explanation. The Act with which we are
concerned provides for suspension and removal of a member of the Board with a rider that no such
action will be taken against him unless he is afforded an opportunity to offer an explanation. The
expression 'inquiry' as appears in the observations of their Lordships is not intended to convey an
idea of a regular trial where witnesses could be examined or cross-examined and defence evidence
produced. All that is said by their Lordships is that some sort of inquiry consistent with rules of
natural justice would have been held in regard to the issue of fact raised by Dr. Book Chand if he had
asked the Chancellor for such an inquiry. It is too much to read in these observations that whatever
be the intention of a particular statute, an inquiry must in every case to be held.
22. An enquiry of the type as desired by the petitioner could not thus be claimed by him by invoking
he aid of the rules of the natural justice. At the same time consideration of his explanation in order
to arrive at the decision, whether the petitioner should be retained as a member of the Board had no
bias. The petitioner was also entitled on the basis of the rules of natural justice that he should have
been apprised of the contents of any report or document that was to be taken into consideration
against him, and it was equally his right to be shown the records if he could reasonably rely on them
in the matter of giving his defence by way of explanation. The Director Vigilance and Deputy
Superintendent of Police, both of whom conducted enquiries against the petitioner, had submitted
their reports to the Government.Bakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

23. It is not possible to find direct evidence of personal bias which has to be inferred like any other
fact from the circumstances of the case. The causes which may lead to personal bias cannot be
enumerated exhaustively and hostility of the authority called upon to exercise quasi-judicial
functions may result from variety of incidents. In the instant case, except for strong suspicions
which cannot take the place of proof, evidence of malice or hostility on the part of respondents 2 and
3 is missing. Ill-will and bad faith against respondent 2 are sought to be proved from the following
circumstances:-
(1) The petitioner was a close associate of late Shri Lachhman Singh Gill and was
considered to be responsible for toppling the ministry of which respondent 2 was the
Chief Minister.
(2) A memorandum was submitted to the President by respondents 2, 3 and others
making a number of allegations against the petitioner and Shri Gill. Specific reference
is made in he writ petition to the fact that the petitioner was described as a close
associate of late Shri Gill.
(3) Respondent 2 interfered with the powers of the Chairman of the Board and
directed him not to grant medical leave to the petitioner and in fact such leave as
prayed for was got cancelled through the Chairman who telegraphically informed the
petitioner about the request for extension of leave having been turned down.
(4) Respondent 3 was a political opponent of late Shri gill having lost to the latter in
the mid-term elections to the State Legislative Assembly, and that since the petitioner
was very intimately associated with Shri Gill, respondent 3 became inimically
disposed to him.
24. Respondent 2 in his affidavit denied that the petitioner was being treated as Shri Lachhman
Singh Gill's man. It is admitted by him that he along with his political associates did submit a
memorandum to the President for appointing a commission of enquiry into certain allegations
against late Shri Gill and that some of the charges were inquired into by Shri Naronha, an Advisor to
Governor, Punjab. This respondent asserted that as Chief Minister while dealing with his employees,
he was never swerved by any political considerations and allegations of the petitioner are
ill-founded, more so when it is to be noticed that show-cause notice was issued to the petitioner on
11th February, 1969, during President's rule.
25. As regards cancellation of medical leave, the averment of respondent 2 is that the work of the
Board was suffering due to continued absence of the petitioner and he though it in public interest
that the Chairman of the Board should not sanction any more leave to the petitioner and that papers
might be sent to him for proper orders. The suggestions of bias and enmity as levelled against this
respondent are stoutly denied.
26. The only allegation against respondent 3 is that there was an election contest during mid-term
elections to the State Legislative Assembly between late Shri Lachhman Singh Gill and the saidBakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

respondent in which the latter lost. The plea is that because of political rivalry and enmity between
Shri Gill and this respondent, the latter became hostile to the petitioner as well, as the petitioner was
considered to be a close associate of Shri Gill.
27. There is no manner of doubt that a memorandum was submitted by the Akali Party, including
respondent 2, and in that reference was made to the petitioner. The reference could not be just
innocent and must obviously be intended to convey some connection of the petitioner with late Shri
Gill and latter's course of conduct which was under criticism. It is difficult, in such circumstances, to
believe that in the thickness of dust and storm of political rivalries, relations between the petitioner
and respondents 2 and 3 could be normal and happy. At the same time, the enquiry against the
petitioner had started during President's rule in which neither of these respondents had any hand.
When the matter came up before them, they could not be expected, with the background of
fratricidal strife to have a soft corner for the petitioner. The conduct of the petitioner in asking for
medical leave when show-cause notice was not being served on him because of his whereabouts not
being known, legitimately gave an impression to respondent 2 that he was trying to avoid service. It
was with this impression that respondent 2 asked the Chairman not to sanction any more leave
without the petitioner appearing before the medical board. No doubt there was no love lost between
the petitioner and respondent 2, it is not correct to assume that all this was done by the said
respondent on account of political differences. This respondent has sworn an affidavit denying any
ill-will against the petitioner and there is no reason to disbelieve the same whatever might have been
the apprehensions of the petitioner.
28. Averments against respondent 3, even if they be treated as true, do not constitute sufficient
evidence for coming to a conclusion that he had any ill-will against the petitioner. In a democratic
from of Government, lawful authority has to be exercised by the Ministers and the mere fact that
before a Minister came to hold office there were election contests in which a particular person was
arrayed against him will not by itself by enough to conclude that every action of the Minister against
such a person is tainted with a bad faith. Each case will have to be considered on its own facts and
we are satisfied that the present is not the one where the authority can be said to have been abused
on that score.
29. The executive file shows that enquiry against the petitioner had been started by the Director
Vigilance under orders of the Chief Secretary, somewhere in September, 1968, during President's
rule, Respondents 2 and 3 might not have any hand in it except for the submission of the
memorandum to the President and their pursuing the same with a demand for an enquiry. The
Director submitted his interim report on 21st January, 1969, much before the mid-term elections
commenced. One of the charges was to the effect that the petitioner being a member of the Board
took part in politics and canvassed support for late Shri Lachhman Singh Gill and others. There
were allegations of corruption and misuse of authority as well, it being alleged amongst other things
that the petitioner had been getting electric connections and extra loads for various parties out to
turn. The petitioner was said to have got attached to his official residence at Patiala a piece of land
belonging to Horticulture Department about which the Deputy Commissioner made an enquiry and
submitted a report to the Government. The Vigilance Department also found that a number of
employees of the Board were suspended by the petitioner and later reinstated within a short periodBakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

without must justification. The Director based his report on the recommendations of the Deputy
Superintendent of Police who had investigated the charges. Investigation could not be completed on
many charges against the petitioner as the Special Enquiry Agency felt that it was not receiving full
co-operation from the Board which had many of the relevant records in its possession.
We thus find that the enquiry as conducted by the Vigilance Department against the petitioner
related to a number of charges one of them only being taking part in politics. The petitioner asked
for several documents whose relevancy it is not possible to assess as the petitioner neither in his
explanation nor elsewhere pointed out the connection between the charges against him and the
documents he wanted to inspect for the purposes of preparing his defence. Refusal to supply copies
of all the documents therefore, cannot be said to have in any way violated the rules of natural justice.
He was, of course, entitled to the copies of the reports of the Deputy Superintendent of Police and
the Director Vigilance who had expressed an opinion on the basis of data produced before them that
the petitioner was prima facie found guilty of having attempted to pursued some Akali M. L. As. And
others to join Janta party headed by late Shri Lachhman Singh Gill. It cannot be said that the
reports were not before the Minister or that he did not take them into consideration. No doubt
copies of the statements made by these witnesses were made available to the petitioner for his
explanation but the opinions of these officers as formed on those statements, other material, if any,
when the same had been conveyed to the Government were equally important and they could not be
used in any manner whatsoever against the petitioner without the latter having been apprised of
them. The order of the Minister respondent 3, of course, does not disclose that he was influenced by
these reports but it is just a grievance of the petitioner that the order being not a speaking one these
reports and other ex parte material collected against him must have been taken into account. No
copy of the order of respondent 3 was appended either with the writ petition or the returns filed by
the respondents but the Advocate-General in the course of arguments took us through the same and
we placed a copy thereof on the record. Original order of the Minister dated 24th April, 1969, is in
Punjabi and translation thereof reads as under:-
"I have carefully considered the whole file, show-cause notice and the explanation
furnished by Shri Bakhtawar Singh. I have also seen the opinions of our Legal
Remembrancer and the Advocate-General. I agree with the Secretary, Irrigation and
Power, that this fact is established that Shri Bakhtawar Singh, while working as
Member of the State Electricity Board, was taking part in politics, as a result whereof
the work of the Board was adversely affected. Besides, he did not discharge his duties
impartially. For these reasons, I agree with the proposal of the Secretary, Irrigation
and Power, that it is not desirable that Shri Bakhtawar Singh should continue as
Member of the State Electricity Board. I, therefore, order that Shri Bakhtawar Singh
should be removed from membership of the Board under Section 10(1)(e)(iv) of the
Act. Before the orders are actually issued, the file should be sent to the Chief Minister
as well.
Sd/-         
Sohan Singh Bassi 24-4-1969"Bakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

A reading of this order leaves no doubt in our mind that the Minister was of the view that the
petitioner did not act with impartiality and the work of the Board had been adversely affected. One
of the charges before the Special Enquiry Agency was of partiality shown by the petitioner in his
official duties and probably this has been incorporated by the Minister from the two reports of the
said Agency, copies whereof were sought by the petitioner and denied to him. In the face of such an
order in which reference is made to charges other than the one on which termination of services is
supposed to have been made, it is not possible to hold that the reports of the Special Enquiry Agency
and other charges against the petitioner were not taken into consideration while passing the
impugned order. This conclusion also finds support from the impugned order itself Respondent 3
has based his order not only on the charge with regard to which show-cause notice was given but
also on matters which the petitioner had no opportunity to explain and which are referred to in the
file particularly the reports of the Special Enquiry Agency. It is difficult to say which of the
allegations constituted the dominant reason that induced this respondent to pass the order of
termination of the services of the petitioner.
Respondent 3 states in his order that the petitioner did not discharge his duty impartially and that
the work of the Board was adversely affected because of the petitioner taking part in politics. Partial
or inefficient discharge of duties is by itself a substantial misdemeanour which could justify removal
of the petitioner but after an opportunity had been afforded to him to explain what he ha to say
regardless of the fact whether his explanation would have been accepted or not. There seem to have
been lurking in the mind of this respondent several other allegations which formed the
subject-matter of enquiry by the Special Enquiry Agency including those of partiality in the
discharge of the duties and the work of the Board having been adversely affected. The order as
passed by him cannot be split up and the petitioner has been punished for all the three charges, two
out of which he had no opportunity to explain.
30. Mr. Sibal relies on a judgment of the Supreme Court in State of Orissa v. Bidyabhushan
Mohapatra, AIR 1963 SC 779, and contends that when punishment could be recorded on one ground
namely that he was participating in politics, the other charges appearing in the order of the Minister
need not be taking into consideration. It has been observed by their Lordships in this case that if the
High Court is satisfied that if some but not all the findings of the Tribunal were not assailable the
order of the Governor on whose powers by the rules no restrictions in determining the appropriate
punishment are placed, was final and the High Court had no jurisdiction to direct the Governor to
review the penalty Bidyabhushan's case, AIR 1963 SC 779 has no bearing on one before us. Charges
of habitually receiving illegal gratification and being possessed of property totally disproportionate
to his income as levelled against Bidyabhushan, were enquired into by the Administrative Tribunal
constituted under the Disciplinary Proceedings (Administrative Tribunal) Rules 1951 framed in
exercise of the powers conferred by Art. 309 of the Constitution of India.
The enquiry was held in the presence of the official and four out of five heads under the charge of
corruption and also the charge relating to possession of disproportionate property, were held to
have been proved. He was called upon to show cause why he should not be dismissed from service as
recommended by the Tribunal. After receiving an explanation from him, the Governor directed his
dismissal. He then moved the High Court by a petition under Arts 226 and 227 of the ConstructionBakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

for quashing the entire proceedings before the Tribunal and also the order of his dismissal. The
High Court held that the findings of the Tribunal on two of the heads under charge number one
which related to habitually receiving illegal gratification were vitiated because it had failed to
observe the rules of natural justice. Findings on the other charges were, however, not considered to
have been vitiated. The High Court still quashed the order of punishment and directed the State
Government to consider afresh whether on the basis of the charges held proved, it would like to
maintain the punishment or whether lesser punishment would suffice. It was thus not a case where
no opportunity had been afforded to the official in respect of any of the charges but the High Court
directed review of the penalty because it held that finds of the Tribunal on some charges were not
unassailable. It was in these circumstances that their Lordships observed that where an order may
be supported on any findings as to substantial misdemeanour for which the punishment would be
lawfully imposed. It is not for the Court to consider whether that ground alone would have weighed
with the authority in dismissing the public servant. The charges there were quite distinct and
separate and each one of them had been enquired into by the competent Tribunal in accordance
with the rules.
In the instant case, the punishment is based on three charges intermixed with one another and no
enquiry has been held with regard to two of them.
31. Our attention has also been invited by Mr. Sibal to Railway Board, New Delhi v. Niranjan Singh,
AIR 1969 SC 966, where one of the questions was as to whether an order of removal based on a
number of grounds, one or more of which are found to be unsustainable, could be struck down.
Niranjan Singh who was serving in the Railway was served with a charge-sheet containing two
charges and called upon to show cause as to why he should not be removed from service. An enquiry
into these charges was conducted by an enquiry committee which reached the conclusion that one
charge was not proved beyond reasonable doubt though he was guilty of the second charge. The
General Manager of the Railway concerned was the disciplinary authority under the Indian Railway
Establishment Code Vol. 1. He did not agree with the findings of the enquiry committee on charge
number one and held the same also to be proved. The High Court having been moved by a writ
petition went into the evidence and agreed with the enquiry committee that one charge was not
proved. It was all a matter of inference to be drawn from established facts and the Supreme Court
took the view that the High Court exceeded its power in interfering with the finding of the General
Manager with regard t that charge. The High Court also quashed the punishment on the ground that
when an order of detention for removal from service is based on a number of grounds and one or
more of those grounds disappear, it become difficult to uphold that order when it is not clear to what
extent it was based on the ground found to be bad. A regular enquiry had been held in this case and
the delinquent official could not make a grievance that he was not afforded an opportunity to show
cause against any charge on which the punishment was based.
32. The facts of both these cases decided by the Supreme Court are distinguishable and, in our
opinion, they do not lay down anything contrary to the well-established rule of natural justice that a
person cannot be condemned without being heard. The impugned order has, therefore, to be
quashed on the short ground that it offended against the rules of natural justice inasmuch as the
material not made available to the petitioner was used against him and he was not afforded anBakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

opportunity to explain two of the allegations. We do not agree with the learned counsel for the
petitioner that the charges were in any way vague and that amounted to denial of reasonable
opportunity for an explanation.
33. A perusal of the statement of allegations as given above, makes it abundantly clear that all
necessary particulars were supplied to the petitioner pinning down even the point of time when the
petitioner was said to have contacted certain M. L. As of the Akali Party to press them to join Janta
Party or he took any other step in this regard. The argument that mere mentioning that a few days
after the formation of the Janta Party's ministry the petitioner went to a certain village and
contacted Shri Hardit Singh is not sufficient and that a date should have been specified is devoid of
force. Formation of Janta Party was on a specified date and it cannot be believed that the petitioner
did not know of it. The expression "a few days" has also a very clear understandable import and no
vagueness appears in this allegation. In the second allegation too, the same criticism was levelled by
Mr. Kaushal and is equally without substance. He could not find fault with other allegations which
give even the dates on which the petitioner was alleged to have committed supposed indiscreet and
ill-advised acts of dabbling in politics as a member of the Board.
34. The third and fourth contentions of the learned counsel can be disposed of together. It is
conceded by Mr. H. L. Sibal, Learned Advocate-General, that the State Government acted as a
quasi-judicial authority while removing the petitioner from his office as member of the Board and
that it had, therefore, to pass a speaking order. He has, however, vehemently contended that the
order in question is a sufficiently speaking one and a Minister could not be expected to write almost
a judgment as is required of a Presiding Officer in a law Court necessitating the formulation of
points in controversy in the form of issues and giving detailed reasons for arriving at a decision one
way or the other. The argument indeed is that it is only the process of reasoning that has to be
indicated and the same is very clearly noticeable in the present case. He has, in this connection,
relied upon a Full Bench judgment of this Court in State of Punjab v. Bhagat Ram Patanga. 71 Pun
LR 625 = (AIR 1970 Punj 9) (FB). It is urged that the Minister respondent 3 agreed to the proposal
of the Secretary, Irrigation and Power as it appears from the executive file, and that the contents of
that proposal according to the learned counsel, have to be taken along with the order is a speaking
one made after a proper judicial approach. We are asked to look into the office noting and report of
the Secretary as similar course was followed by the Full Bench in Bhagat Ram Patanga's case, 71 Pun
LR 625 = (AIR 1970 Punj 9) (FB) where the learned Judges taking an overall picture on the basis of
the office noting and the contact that the Minister maintained throughout with the progress of the
case, came to the conclusion that the order impugned in that case did give reasons. The order there
was of course, a brief one, but the learned Judges in upholding the validity of the order made
reference to the executive file.
In the alternative, Mr. Sibal contends that the present order even if taken in isolation gives enough
reasons as in intended by law. Facts in Bhagat Ram Patanga's case, 71 Pun LR 625 = (AIR 1970 Punj
9 FB) were totally different and cannot render any assistance to the learned counsel. Some incident
had taken place at a meeting of the Municipal Committee, Phagwara, over which the Sub-Divisional
Officer presided. There were two versions of the incident one as given by the Sub-Division Officer
and the other by the petitioner to whom misbehaviour was attributed. He was removed fromBakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

membership of the Municipal Committee under Section 16(1)(e) of the Punjab Municipal Act and
further disqualified for the alleged flagrant abuse of his position as member of the Municipal
Committee. The only question to be determined was which of the versions could be believed namely,
whether the one coming from the Sub-Divisional Officer who presided over th meeting or the other
as it came from those members of the Municipal Committee who were charged with flagrant abuse
of their positions and consequently removed. The learned Judges found the outline of the manner in
which the State government reached its decision by examining the executive file which showed that
the Minister Incharge and the Chief Minister fully applied their minds to the case. The file had been
put up to the Home Minister many a time before the final order was passed and all proceedings were
being taken under the very directions of the Minister concerned. The Chief Minister appended a
note on the file which was considered by the Home Minister and then the final action taken. The
learned Judges constituting the Full Bench considered all the judgments of the Supreme Court as
were placed before them in regard to the necessity for passing a speaking order by an administrative
authority performing quasi-judicial functions and relying mainly on Bhagat Raja v. Union of India,
AIR 1967 SC 1606, observed that "the State Government, while removing a Municipal Commissioner
under Section 16 (1) of the Act, may be expected to give an outline of the process of reasoning by
which they reached their decision. " Bhagat Raja's case, AIR 1967 SC 1606 was under the Mines and
Minerals (Regulations and Development) Act, 1957, which provided for a revision to the Central
Government but the argument that in other cases where an authority is called upon to adjudicate the
rights of the parties but no appeal or revision is provided under the statute, as was the case under
the Mines and Minerals Act, and there is therefore no need to give reasons, was repelled it being
held by the Full Bench that outline of the process of reasoning is necessary no matter whether some
right of appeal or revision exists under the law or not. The broad approach of their Lordships of the
Supreme Court in Bhagat Raja's case, AIR 1967 SC 1606 was held to apply in such cases as well. In
our opinion, it has to be determined on the facts and circumstances of each case as to what is a
necessary process of reasoning required in that case. The desirability of looking for such a process, if
it is not a mere platitude, renders it necessary that the person affected by the order must know what
weighed with the authority passing that order and how the development of thought that led to the
impugned decision took place in the mind of the said authority. If the allegations are repeated or it is
just said that the competent authority is satisfied that the allegations are proved but no chain of
ratiocination by which the decision is reached by the authority itself is manifestly apparent in the
order it cannot possibly be said that the process of reasoning is to be found therein. Mere mention of
the conclusion is not tantamount to giving reasons for the conclusion. For instance, if A makes a
statement against B but the latter denies the same and a penal action hinges on the credibility of A,
it has to be stated why the statement of A is being relied upon. Otherwise, the order may smack of
arbitrariness which the rule of law as enshrined in our Constitution does not permit. The
satisfaction as to the credibility of a witness or in any other matter when that satisfaction is to affect
the rights of a third party though subjective has to be based on objective data. The satisfaction has
also to be of the quasi-judicial authority itself and of none else. In fact, after an explanation is
received the competent authority alone is called upon to apply its judicial mind and then accept or
reject the same without letting any one else influence its judgment intentionally or unwittingly
whether by way of comments or in any other manner. Moreover, application of the judicial mind
must be seen from the order itself and not that reasons are to be guessed or gathered from scrutiny
of the executive files. An attempt on the part of a High Court to build up reasons from anBakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

examination of the executive file was adversely commented upon by their Lordships of the Supreme
Court in Pragdas Umar Vaiahya v. Union of India, Civil Appeal No. 657 of 1967, D/- 17-8-1967 (SC).
In that case, the High Court looked into the file of the Central Government and having found that
the applications for leases filed by two of the respondents in the aforesaid appeal were earlier in
point of time, upheld the order of cancellation of lease in favour of Pragdas as made by the Central
Government. On an appeal by Pragdas by special leave, this procedure followed by the High Court
was considered by their Lordships to be irregular it being observed that "it is not for the High Court
to give reasons which the Government might have, but has not chosen to give, in support of its
conclusion. Since no reasons were given in support of the order passed by the Central Government,
the order was ex facie defective, and the defect could not be remedied by looking into the file
maintained by the Government and constructing the reasons in support of the order. The reasons in
support of the order has to be recorded and disclosed to the parties concerned by the Central
Government, the reasons could not be gathered from the 'notings' made in the files of the Centre
Government". Recording of reasons and disclosure thereof in the words of their Lordships, "is not a
mere formality". These observations apply with equal force in the present case. The petitioner was
entitled to know on what grounds the conclusion was reached by the Minister that the former was
indulging in politics. The argument of Mr. Sibal that the report of the Secretary, Irrigation and
Power, and other office notings give an insight into the reasons for the impugned order cannot,
therefore, be accepted in view of the observations in Pragdas's case. Civil Appeal No. 657 of 1967,
D/-17-8-1967 (SC).
35. Mr. Kaushal contends that the approach of the Full Bench in Bhagat Ram Patanga's case, 71 Pun
LR 625 = (AIR 1970 Punj 9) (FB) where executive file was scrutinised to find out reasons can no
longer be support in view of the observations of their Lordships of the Supreme Court in Pragdas
Umar Vaiahya's case, Civil Appeal No. 657 of 1967, D/-17-8-1967 (SC). It is not necessary for us to
deal with this contention of the learned counsel when we find that the facts of Bhagat Ram Patanga's
case. 71 Pun LR 625 = (AIR 1970 Punj 9) (FB) were quite different.
36. In the light of what has been said above, the order of the Minister cannot be said to be a speaking
one. All that is stated by him is that he has looked into the file which beyond doubt contains a
number of documents including the reports of the Deputy Superintendent of Police, Director
vigilance, Secretary Irrigation and Power and office notings. He claims to have considered the
show-cause notice and also the opinions given by the Legal Remembrance and the
Advocate-General, though he does not refer to what is actually said in the show-cause notice, the
explanation, evidence on which he proposes to rely or the opinions of the Advocate-General or the
Legal Remebrancer. He simply purports to agree with the opinions of the Secretary, Irrigation and
Power, and states that it stood established that the petitioner had taken part in politics. He could not
be expected to write, as rightly urged by the learned Advocate-General, an elaborate judgment but it
is also too much to assert that he should not even say in his order as to how he arrived at the
decision that the charge against the petitioner stood proved. As is to be seen from the statement of
allegations, reference was made to several details and the Vigilance Department in its report too
relied upon the statements of a number of witnesses who had appeared before it and copies of some
statements were supplied to the petitioner. The petitioner had stated in his explanation that they
were not telling the truth and that he had material in his possession to show that the personsBakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

deposing against him had been asking for favours from him and he declined to accommodate them.
Of course, no specific instances were cited by the petitioner as well who was only insisting for an
enquiry in the course of which he wanted to produce the material. Be that as it may, it was not
difficult for the Minister to call upon the petitioner to produce that material before him and then say
without writing a formal judgment, why he believed the witnesses and how their statements were
reliable,. As a matter of fact, what we find is that no reference whatsoever is made to the statements
of those witnesses in the impugned order. The petitioner was demanding an enquiry and the
Government had obtained the opinion of the Legal Remembrancer and the Advocate-General. The
Minister could have said on the basis of those opinions that the demand for enquiry could not be
met but even that much is not stated in the impugned order.
37. The impugned order rather seems to have been passed in a mechanical way lacking in judicial
approach which implies that the authority must act reasonably and with an open mind. It was as
already stated, necessary for the Minister to indicate why he believed the statements of some Akali
M. L. As. And other who had deposed against the petitioner before the police. The petitioner refuted
the allegations against him and the decision depended on the credibility of the witnesses and
existence of certain facts. It should have been stated in the order how the explanation of the
petitioner was not satisfactory and mere saying that the same had been considered was not enough.
The petitioner had, of course, no legal right to claim an elaborate enquiry of the type demanded by
him but there was no bar to respondent 3 in directing such an enquiry to be held or himself holding
an enquiry in which the value of the statements as made against the petitioner could be tested in the
presence of the petitioner or otherwise. The underlying idea of a judicial approach is only to sift
truth and if, in a particular set of circumstances, it is found that the same could be done only by
holding a somewhat detailed enquiry beyond a mere explanation, it becomes incumbent of the
administrative authority performing quasi-judicial functions to do so in compliance with the rules of
natural justice no matter that the requirement of law is that an explanation only is to be obtained.
The statements made behind the back of the petitioner before the Special Enquiry Agency or police
could not be accepted as true at their face value unless their truthfulness was examined by the
authority which was to take a penal action on the basis of those statements. In the instant case, we
are constrained to hold that no attempt appears to have been made on the part of respondent 3 to
find out the truth by a judicial approach, nor can the order passed by him be held to be a speaking
one giving the process of reasoning.
38. The last question that survives for consideration is whether a member of the Board participating
in politics is guilty of such a conduct as to render him unfit to continue in office within the meaning
of Section 10(1)(e)(iv) of the Act. We have not the least doubt in our mind that the Chairman and
members of the Board are prohibited by the Act from taking direct or indirect part in political life of
the country. This prohibition is to be found in the scheme and policy of the Act which provides a
machinery for the distribution of benefits of electricity to the people of a particular State. The Board
which is an independent corporate body is concerned with the electrical development in the Sate
and, as enjoined in Section 5(6) of the Act, a person shall be disqualified from becoming a member
thereof, if he is, or within the twelve months last preceding was, member of Parliament or of any
State Legislature or any local authority. This provision of law prevents the entry into the Board of a
person who is not only connected with party politics at the time when he is made a member but alsoBakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

who was so connected within the preceding one year. There is then Clause (d) of sub-section (1) of S.
10 which permits the State government to suspend or remove from office any member of the Board
who becomes or even seeks to become a member of such bodies. The object of these prohibitions is
to have only those persons on the Board who are not likely to exploit their office by indulging in
nepotism, favouritism and corruption for their political ends. The nature of duties to be performed
by the members is such that they have to deal with public and give benefits of electricity to them
which are most needed at present in our welfare State which is on march to industrial and
agricultural development. A politically minded person can work havoc and use his office so as to
deprive deserving persons of electric connections and other amenities arising from the use of
electricity conferring the same on his own partymen. Conflict between duty and loyalty to party
politics is likely to arise if a politician is taken or allowed to continue as member of the Board. The
participation in politics is, therefore, certainly a conduct which renders a person unfit to continue a
member making him liable to suspensions or removal from office by the State Government under
Section 10(1)(e)(iv) of the Act.
39. In the result, the petition is allowed, removal of the petitioner from membership of the Board
declared illegal and a writ of certiorari directed to issue quashing the impugned order of the
Governor of Punjab as passed on 25th April, 1969. There is no order as to costs.
Bal Raj Tuli, J.
40. I agree.
41. Petition allowed.Bakhtawar Singh vs State Of Punjab And Ors. on 6 October, 1970

