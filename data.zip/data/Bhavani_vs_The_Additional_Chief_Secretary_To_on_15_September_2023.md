Bhavani vs The Additional Chief Secretary To ... on 15
September, 2023
Author: M.Sundar
Bench: M.Sundar
    2023:MHC:4317
                                                                                H.C.P.No.1451 of 2023
                                      IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                    DATED : 15.09.2023
                                                          CORAM
                                        THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                        and
                                       THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                 H.C.P.No.1451 of 2023
                     Bhavani                                                        .. Petitioner
                                                            Vs
                     1.The Additional Chief Secretary to Government,
                       Home, Prohibition and Excise Department,
                       Secretariat, Chennai – 9.
                     2.The Commissioner of Police,
                       Greater Chennai.
                     3.The Superintendent of Prison,
                       Central Prison, Puzhal, Chennai – 66.
                     4.The Inspector of Police (L & O),
                       M-3, Puzhal Police Station, Chennai.                     .. Respondents
                                  Petition filed under Article 226 of the Constitution of India
                     praying for issuance of a writ of habeas corpus to call for the records in
                     connection with the order of detention passed by the second
                     respondent dated 11.04.2023 in Memo No.96/BCDFGISSSV/2023
                     against the petitioner's brother Sarathkumar, male, aged 21 years,
                     S/o.Saravanan, who is confined at Central Prison, Puzhal, Chennai, setBhavani vs The Additional Chief Secretary To ... on 15 September, 2023

                     Page Nos.1/8
https://www.mhc.tn.gov.in/judis
                                                                                        H.C.P.No.1451 of 2023
                     aside the same and direct the respondents to produce the detenu
                     before this Court and set him at liberty.
                                  For Petitioner            :     Ms.S.Rohini
                                  For Respondents           :     Mr.E.Raj Thilak
                                                                  Additional Public Prosecutor
                                                            ORDER
[Order of the Court was made by M.SUNDAR, J.,] This order will now dispose of captioned 'Habeas
Corpus Petition' ['HCP' for the sake of brevity, convenience and clarity].
2. When the captioned HCP was listed for Admission on 03.08.2023, the following
proceedings/order was made:
M.SUNDAR, J.
and R.SAKTHIVEL, J.
(Order of the Court was made by M.SUNDAR, J.,) Captioned Habeas Corpus Petition
has been filed in this Court on 26.07.2023 inter alia assailing a 'detention order dated
11.04.2023 bearing reference 96/BCDFGISSSV/2023' [hereinafter 'impugned
preventive detention order' for the sake of convenience, clarity and brevity] made by
'second respondent' [hereinafter 'Detaining Authority' for the sake of convenience].
To be noted, fourth respondent is the Sponsoring Authority.
2. To be noted, cousin sister of the detenu is the petitioner.
https://www.mhc.tn.gov.in/judis
3. Ms.M.Kokila, learned counsel on record for petitioner is before this Court. Learned counsel for
petitioner submits that ground case qua the detenu is for alleged offences under Sections 341,
294(b), 324, 307, 427, 302 of 'Indian Penal Code, 1860 (Act 45 of 1860)' [hereinafter 'IPC' for the
sake of brevity] subsequently altered into Sections 341, 294(b), 324, 307, 427, 302 of IPC read with
120(B) of IPC in Crime No.158 of 2023 on the file of M-3 Puzhal Police Station.Bhavani vs The Additional Chief Secretary To ... on 15 September, 2023

4. The aforementioned impugned preventive detention order has been made on the premise that the
detenu is a 'Goonda' under Section 2(f) of 'The Tamil Nadu Prevention of Dangerous Activities of
Bootleggers, Cyber law offenders, Drug- offenders, Forest-offenders, Goondas, Immoral traffic
offenders, Sand-offenders, Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982 (Tamil
Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake of convenience and clarity].
5. The impugned preventive detention order has been assailed inter alia on the ground that live and
proximate link between the grounds of detention and purpose of detention has snapped as the
detenu was arrested on 07.03.2023 and the impugned preventive detention order has been passed
on 11.04.2023.
6. Prima facie case made out for admission. Admit. Issue Rule nisi returnable by four weeks.
7. Mr.A.Gokulakrishnan, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice
for all respondents. List the captioned Habeas Corpus Petition accordingly.'
3. The aforementioned proceedings/order dated 03.08.2023 captures all essentials i.e., essential
facts imperative for appreciating this final order and therefore we are not setting out the facts again.
Suffice to say that the aforementioned Admission Board order dated
https://www.mhc.tn.gov.in/judis 03.08.2023 shall now be read as an integral part and parcel of the
instant final order. This also means that the short forms, short references and abbreviations used in
the aforementioned Admission Board order will continue to be used in the instant final order also.
4. As would be evident from paragraph 5 of the 03.08.2023 Admission Board order, at the time of
admission, learned counsel for petitioner posited her challenge against the impugned preventive
detention order on the ground that live and proximate link between the grounds of detention and
purpose of detention has snapped but in the Final Hearing Board today, learned counsel on record
for petitioner changed her line of attack qua her campaign against the impugned preventive
detention order on one point which turns on subjective satisfaction arrived at by the Detaining
Authority qua imminent possibility of the detenu being enlarged on bail. Learned counsel submitted
that such subjective satisfaction has been arrived at by the Detaining Authority by relying on Balaji's
case bail order being bail order dated 26.05.2021 in Crl.M.P.No.10485 of 2021 on the file of Sessions
Court, Chennai. Relevant portion in paragraph No.4 of the grounds of impugned preventive
detention order reads as follows:
https://www.mhc.tn.gov.in/judis '4......Further, it is pertinent to note that in a
similar case registered in R3 Ashok Nagar Police Station Crime No.59/2021 under
Sections 147, 148, 449, 324, 302 IPC, bail was granted to the some other accused by
the Court of Sessions at Chennai in Crl.M.P.No.10485/2021. Hence, I infer that there
is a real possibility of his coming out on bail by filing bail application for M-3 Puzhal
Police Station Crime No.158/2023 before the appropriate court, since, in similarly
placed cases, bail was granted by the courts, after a lapse of time......'Bhavani vs The Additional Chief Secretary To ... on 15 September, 2023

5. A careful perusal of Balaji's case bail order, more particularly paragraph 5 thereat brings to light
that the then prevailing Covid-19 situation had weighed in the minds of the learned Sessions Judge
in granting bail. Paragraph 5 of Balaji's case bail order reads as follows:
'5.The petitioners have been in custody for the past 75 days. No previous case is
reported as against the petitioners. Considering the duration of custody and stage of
the case and existing Covid-19 situation, this Court is inclined to grant bail to the
petitioners subject to condition.' https://www.mhc.tn.gov.in/judis
6. Learned Prosecutor submitted to the contrary by saying that alleged offences in Balaji's case and
case on hand are broadly comparable.
7. We carefully considered the rival submissions.
8. Covid - 19 situation in legal parlance is from 15.03.2020 to 28.02.2022 vide orders of Hon'ble
Supreme Court in Suo Motu Writ Petition (C) No.3 of 2020 wherein limitation across the Board was
extended and therefore, Balaji's case would not apply to the case on hand as the impugned
preventive detention order has been made on 11.04.2023. This Court has repeatedly held that in
cases of this nature, comparison is not restricted to alleged offences but it pertains to determinants /
parameters for grant of bail too as 'imminent possibility' is qua probability. Therefore, subjective
satisfaction as regards imminent possibility of detenu being enlarged on bail arrived at by the
detaining authority by relying on a bail order wherein bail has been granted owing to then prevalent
Covid-19 situation, is impaired leading to the inevitable sequitur that impugned preventive
detention order is vitiated and that it deserves to be dislodged. https://www.mhc.tn.gov.in/judis
9. Ergo, the sequitur is, captioned HCP is allowed. Impugned preventive detention order dated
11.04.2023 bearing reference No.96/BCDFGISSSV/2023 made by the second respondent is set
aside and the detenu Thiru.Sarathkumar, aged 21 years, Son of Thiru.Saravanan, is directed to be
set at liberty forthwith, if not required in connection with any other case / cases. There shall be no
order as to costs.
                                                                      (M.S.,J.)        (R.S.V.,J.)
                                                                             15.09.2023
                     Index : Yes/No
                     Neutral Citation : Yes/No
                     mmi
P.S: Registry to forthwith communicate this order to Jail authorities in Central Prison, Puzhal,
Chennai. To
1.The Additional Chief Secretary to Government, Home, Prohibition and Excise Department,
Secretariat, Chennai – 9.
2.The Commissioner of Police, Greater Chennai.Bhavani vs The Additional Chief Secretary To ... on 15 September, 2023

3.The Superintendent of Prison, Central Prison, Puzhal, Chennai – 66.
4.The Inspector of Police (L & O), M-3, Puzhal Police Station, Chennai.
5.The Public Prosecutor, High Court, Madras.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL, J., mmi 15.09.2023
https://www.mhc.tn.gov.in/judisBhavani vs The Additional Chief Secretary To ... on 15 September, 2023

