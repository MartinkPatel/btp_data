Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on
17 April, 2014
Author: K.S. Radhakrishnan
Bench: Vikramajit Sen, K.S. Radhakrishnan
                                                                             REPORTABLE
                        IN THE SUPREME COURT OF INDIA
                        CIVIL APPELLATE JURISDICTION
                       CIVIL APPEAL NO. 4591  OF 2014
              (@ Special Leave Petition (Civil) No.1804 of 2014)
Association of Unified Tele Services
Providers & Others                               …. Appellants
                             Versus
Union of India                                   …. Respondent
                                    WITH
                        CIVIL APPEAL NO. 4592 OF 2014
             (@ Special Leave Petition (Civil) No.2925 of 2014)
                                    WITH
                        CIVIL APPEAL NO.10748 OF 2011
                                     AND
                        CIVIL APPEAL NO.10749 OF 2011
                               J U D G M E N T
K.S. Radhakrishnan, J.
CIVIL APPEAL NO. 4591 OF 2014 [Arising out of SLP (C) No. 1804 of 2014] AND CIVIL APPEAL
NO. 4592 OF 2014 [Arising out of SLP (C) No. 2925 of 2014]
1. Leave granted.
2. We are in these appeals concerned with the scope and ambit of the powers and duties of the
Comptroller and Auditor General of India (CAG), the Telecom Regulatory Authority of India (TRAI)
and the Department of Telecommunications (DoT) in relation to the proper computation and
quantification of Revenue in determining the licence fee and spectrum charges payable to Union of
India under Unified Access Services (UAS) Licences entered into between DoT and the privateAsso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

service providers.
3. We have to examine the above-mentioned issue in the light of the various constitutional, statutory
and licensing provisions, bearing in mind the fact that we are dealing with “spectrum”, which is
universally treated as a scarce finite and renewable natural resource, the intrinsic utility of that
natural resource has been elaborately considered by this Court in Centre for Public Interest
Litigation and others v. Union of India and others (2012) 3 SCC 1 and in the Presidential Reference,
the opinion of which has been expressed in Natural Resources Allocation, in Re: Special Reference
No.1 of 2012 decided on September 27, 2012, reported in (2012) 10 SCC 1. This Court reiterated that
the spectrum as a natural resource belongs to the people, though State legally owns it on behalf of its
people because State benefits immensely from its value. This Court in Centre for Public Interest
Litigation and others (supra) referring to the intrinsic worth of spectrum stated as follows:
“75. The State is empowered to distribute natural resources. However, as they
constitute public property/national asset, while distributing natural resources the
State is bound to act in consonance with the principles of equality and public trust
and ensure that no action is taken which may be detrimental to public interest. Like
any other State action, constitutionalism must be reflected at every stage of the
distribution of natural resources. In Article 39(b) of the Constitution it has been
provided that the ownership and control of the material resources of the community
should be so distributed so as to best subserve the common good, but no
comprehensive legislation has been enacted to generally define natural resources and
a framework for their protection. Of course, environment laws enacted by Parliament
and State Legislatures deal with specific natural resources i.e. forest, air, water,
coastal zones, etc.
76. …………… The ownership regime relating to natural resources can also be
ascertained from international conventions and customary international law,
common law and national constitutions. In international law, it rests upon the
concept of sovereignty and seeks to respect the principle of permanent sovereignty
(of peoples and nations) over (their) natural resources as asserted in the 17th Session
of the United Nations General Assembly and then affirmed as a customary
international norm by the International Court of Justice in the case of Democratic
Republic of Congo v. Uganda.………..
77. Spectrum has been internationally accepted as a scarce, finite and renewable
natural resource which is susceptible to degradation in case of inefficient utilisation.
It has a high economic value in the light of the demand for it on account of the
tremendous growth in the telecom sector. Although it does not belong to a particular
State, right of use has been granted to the States as per international norms.
78. In India, the courts have given an expansive interpretation to the concept of
natural resources and have from time to time issued directions, by relying upon the
provisions contained in Articles 38, 39, 48, 48-A and 51-A(g) for protection andAsso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

proper allocation/distribution of natural resources and have repeatedly insisted on
compliance with the constitutional principles in the process of distribution, transfer
and alienation to private persons.
85. As natural resources are public goods, the doctrine of equality, which emerges
from the concepts of justice and fairness, must guide the State in determining the
actual mechanism for distribution of natural resources. In this regard, the doctrine of
equality has two aspects: first, it regulates the rights and obligations of the State
vis-à-vis its people and demands that the people be granted equitable access to
natural resources and/or its products and that they are adequately compensated for
the transfer of the resource to the private domain; and second, it regulates the rights
and obligations of the State vis-à-vis private parties seeking to acquire/use the
resource and demands that the procedure adopted for distribution is just, non-
arbitrary and transparent and that it does not discriminate between similarly placed private
parties.”
4. We have indicated, the worth of spectrum to impress upon the fact that the State actions and
actions of its agencies/instrumentalities/licensees must be for the public good to achieve the object
for which it exits, the object being to serve public good by resorting to fair and reasonable methods.
State is also bound to protect the resources for the enjoyment of general public rather than permit
their use for purely commercial purposes. Public trust doctrine, it is well established, puts an
implicit embargo on the right of the State to transfer public properties to private party if such
transfer affects public interest. Further it mandates affirmative State action for effective
management of natural resources and empowers the citizens to question ineffective management.
5. UAS license holders have an obligation to use such resources in a manner as not to impair or
diminish the people’s right and people’s long term interest in that property or resource. In Secretary,
Ministry of Information and Broadcasting, Government of India and others v. Cricket Association of
Bengal and others 1995 (2) SCC 161, this Court held “there is no doubt since air waive frequencies
are public property and are also limited, they have to be used in the best interest of the society and
this can be done either by the Central Authority by establishing its own broadcasting network or
regulating the grant of licenses to other agencies, including the private agencies.” In Reliance
Natural Resources Limited v. Reliance Industries Limited (2010) 7 SCC 1, this Court held that the
constitutional mandate is that the natural resources belong to the people of this country. This Court
in several decisions took the view that the natural resources are vested with the Government as a
matter of trust to the people of India and it is the solemn duty of the State to protect the national
interest and natural resources must always be used in the interest of the country and not in private
interest. In short, State is the legal owner of spectrum as a trustee of the people and even though it is
empowered to distribute the same, the process of distribution must be guided by constitutional
provisions, including the doctrine of equality and larger public good. Bearing in mind the above
constitutional principles, we may proceed further.Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

6. We have the Indian Telegraph Act, 1885 in force, which gives the “exclusive privilege” to the
Central Government of establishing, maintaining and working of telegraph to the Central
Government and the Government is empowered to give licences on such conditions and in
consideration of such payment, as it thinks fit, to any person to establish, maintain or work a
telegraph in any part of India. The Indian Wireless Telegraphy Act, 1933, regulates the possession of
wireless telegraph apparatus. The National Policy of 1994 was the first major step towards
deregularisation, liberalization and private sector participation for providing certain basic telecom
services on affordable and reasonable prices to all people covering all villages and also to achieve
various other objectives. Following the New Telecom Policy of 1999 (NTP), licenses were granted to
various cellular mobile telephone service operators in various cities and circles to make available
affordable and effective communication for citizens, considering the fact that access to
telecommunication was of utmost importance to achieve the country’s social and economic growth.
NTP also attempted to provide universal service to all uncovered areas, including the rural areas and
also provided high level services capable of meeting the needs of the country’s economy by striking a
balance between the two. The NTP of 1999 specifically refers to spectrum management which
highlights the following aspects:
“10. The policy on spectrum management as enumerated in NTP, 1999 was as under:
(i) Proliferation of new technologies and the growing demand for telecommunication
services has led to manifold increase in demand for spectrum and consequently it is
essential that the spectrum is utilised efficiently, economically, rationally and
optimally.
(ii) There is a need for a transparent process of allocation of frequency spectrum for
use by a service provider and making it available to various users under specific
conditions.
(iii) With the proliferation of new technologies it is essential to revise the National
Frequency Allocation Plan (NFAP) in its entirety so that it becomes the basis for
development, manufacturing and spectrum utilisation activities in the country
amongst all users. NFAP was under review and the revised NFAP was to be made
public by the end of 1999 detailing information regarding allocation of frequency
bands for various services, without including security information.
(iv) NFAP would be reviewed no later than every two years and would be in line with
the Radio Regulations of the International Telecommunication Union (ITU).
(v) Adequate spectrum is to be made available to meet the growing need of
telecommunication services. Efforts would be made for relocating frequency bands
assigned earlier to defence and others. Compensation for relocation may be provided
out of spectrum fee and revenue share.Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

(vi) There is a need to review the spectrum allocation in a planned manner so that
required frequency bands are available to the service providers.
(vii) There is a need to have a transparent process of allocation of frequency spectrum
which is effective and efficient and the same would be further examined in the light of
ITU guidelines. In this regard the following course of action shall be adopted viz.:
(a) spectrum usage fee shall be charged;
(b) an Inter-Ministerial Group to be called the Wireless Planning Coordination
Committee, as a part of the Ministry of Communications for periodical review of
spectrum availability and broad allocation policy, should be set up; and
(c) massive computerisation in WPC wing would be started in the next three months
so as to achieve the objective of making all operations completely computerised by
the end of the year 2000.”
7. Parliament, in the year 1997, enacted the Telecom Regulatory Authority of India (TRAI) Act to
provide for the establishment of TRAI and the Authority has been entrusted with various regulatory
functions on unified licensing. The Act and the recommendations made by TRAI emphasized on
efficient utilization of spectrum to all the service providers and indicated that it would make further
recommendations on efficient utilization of spectrum, spectrum pricing, availability and spectrum
allocation procedure, and DoT has to issue spectrum related guidelines, based on its
recommendations.
8. Let us now examine the facts which gave rise to these appeals. On 28.01.2010, the TRAI issued a
communication to one of the service providers for furnishing books of accounts to the Branch Audit
Office of the Director General of Audit, Post and Telecommunication, operative portion of the said
communication reads as follows:
“In terms of Rule 5 of the Telecom Regulatory Authority of India, Service Providers
(Maintenance of Books of Accounts and other Documents) Rule, 2002, every service
provider shall produce all such books of accounts and documents referred to in sub
rule (1) of rule 3 thereof that has a bearing on the verification of the Revenue, to
Telecom Regulatory Authority of India (the authority);
(ii) to furnish to the Comptroller and Auditor General of India the statement or
information, relating thereto, which the Comptroller and Auditor General of India
may require to be produced before him and the Comptroller and Auditor General of
India may audit the same in accordance with the provisions of Section 16 of the
Comptroller and Auditor General’s (Duties, Powers and Conditions of Service) Act,
1971.Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

2. The Comptroller and Auditor General of India (through Director General of Audit, Post &
Telecommunications) has decided to audit the books of accounts of your company for the period of
three years commencing from 2006-2007 onwards to assess the government share out of the
revenues carried by your company in terms of the licence agreement with DoT.
3. Therefore in terms of the rule 5 of the TRAI, Service Providers (Maintenance of Books of Accounts
and other Documents) Rules, 2002, it is requested that all necessary records/books of accounts
circle/area-wise, on the Maintenance of Books of Accounts and other relevant matters during the
last week of January, 2010 in the office of DO Audit, P&T, New Delhi, which would facilitate the
audit work.
4. It is, therefore, requested that all necessary co-operation may be extended to the Branch Audit
Officers and Delhi office of DG Audit P&T for completion of the above audit work besides providing
all necessary records/information/ documents required in connection with this audit work.
This issues with the approval of the Authority.”
9. The DoT later wrote a communication dated 16.03.2010 to one of the service providers, the
subject matter of which reads “Audit and Telecom Service Providers by Comptroller & Auditor
General”, the operative portion of the said communication reads as under:
“In exercise of power conferred on the Licensor under clause 22.3 of Unified Access
Service (UAS) Licence, it is requested to provide the following accounting records, for
three years commencing from 2006-07, consisting of books of accounts and other
documents for all the services offered under the above referred UAs licences issued to
reflect :
i) Total cost and breakup of original and current cost i.e. cost after depreciation
under separate heads for different category of fixed assets;
ii) Cost and breakup of operational expenses;
iii) Service wise revenue;
iv) Income from other sources;
v) Supporting books of accounts other documents
a) Fixed assets register
b) Stores and spares/Inventory register
c) Register showing service-wise particulars of subscribersAsso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

d) Register showing deposits from customers
e) Cash books
f) Journals
g) Ledger
h) Copies of bills and counterfoils of all receipts.
2. The above mentioned information should be sent directly to DDG (Accounts), Department of
Telecommunications, Room No.701, Sanchar Bhavan, 20, Ashoka Road, New Delhi – 110001 within
15 days from date of issue of this letter.
Sd/- (16.3.2010) (Shashi Mohan) Director (AS-IV) Tele:23372063/Fax-23372404”
10. One of the service providers replied to the above-mentioned letter on 15.04.2010, the operative
portion of the same reads as under:
“We appreciate that DoT in terms of Clause 22.3 of UASL can call for Licensee’s
books of accounts or go further and direct for a special audit by independent auditor
in terms of Clause 22.6 and we have been complying and are committed to complying
with direction/s that may be issued by DoT in this regard. However, we should like to
mention here that we are currently undergoing the extensive special audit of our
books of accounts by an independent auditor M/s S.K. Mittal & Co. appointed by DoT
for the same period i.e. FY 2006-07 and 2007-08.
In the light of the above, the recent communication of DoT asking us to provide our
accounting records for period of three years starting from 2006-07 for an audit by the
C&AG is a matter of surprise and concern for us. We submit that a fresh audit so
closely on the heels of the special audit by DoT appointed independent auditor is
unwarranted and will result in duplication of efforts, time and waste of resources.
However, as a good corporate citizen, we have provided to DoT the total cost and
breakup of original and current cost, cost and breakup of operational expenses,
service wise revenue, and income from other sources for the year 2006-07, 2007-08
and 2008-09 vide our letters dated 1st April, 2010 and 12th April 2010 though this
information provided to DoT is very sensitive from competitive point of view.
We would also like to submit that the provisions of the C&AG Act, 1971, which set out
the duties and powers of the C&AG pertain only to the audit of accounts of the Union
or the States or Government Companies or Corporations. The audit of accounts of
private companies such as ours is not a part of duties and powers of the C&AG.Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

It is, therefore, requested that while DoT can call for our books of accounts, the audit
of those does not fall within the purview of the C&AG.
We submit that the information sought through the letter like operational expenses,
total cost and break up of original and current cost etc. is not only sensitive from
competitive point of view but has no direct linkages to the revenues of the company
and thus falls beyond our licence obligations.
We submit once again that we have already provided to DoT the desired information
and are ready and be willing to provide any further specific information or data which
is required by DoT in accordance with the provisions of the UAs licence.
We look forward to your kind consideration and support on the matter.”
11. The Director General of Audit, Post and Telecommunications, later, with specific
reference to “Audit of Telecom Service Providers by C&AG” sent a communication
dated 10.05.2010 to one of the service providers, the operative portion of the same
reads as under:
“OFFICE OF THE DIRECTOR GENERAL OF AUDIT, POST &
TELECOMMUNICATIONS SHAM NATH MARG (NEAR OLD SECRETARIAT),
DELHI R.P. Singh Director General Dated : 10.5.2010 Sub: Audit of Telecom Service
Providers by C&AG-Reg.
Ref : 1) DoT Letter No.842-1086/2010-AS-IV dt. 16.03.2010.
2) Your office letter No.RTL/09-10/4433 Dt. 31.3.2010.
Dear Shri Singh, Kindly refer to your office letter cited on the above subject extending cooperation
in conduct of the audit of revenue share by C&AG. Certain difficulty has been expressed by your
Company in providing the books of accounts in physical form as they are being maintained in
electronic form in SAP R3. Further, it has been stated, the same could be viewed in the concerned IT
Systems which would be made available at your headquarters at DAKC, Navi Mumbai. In this
connection, it is requested that on 20th May, 2010, a presentation may be given covering your
business activities, accounting policies, Accounting, billing and financial systems and all other issues
relating to revenue share, followed by brief interface meeting with my Audit team which would start
the process of audit. The time and venue of the presentation is given in Annexure-I. Shri Subu R.
Director (Report) of my office has been nominated as Nodal Officer who would be overseeing and
coordinating the Audit.
Regards, Yours sincerely, R.P. Singh”
12. The TRAI on 21.05.2010 sent yet another communication to one of the service providers with
specific reference to “Furnishing of Books of Accounts to the Branch Audit Offices of the DirectorAsso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

General of Audit, Post and Telecommunications”, the operative portion of the same reads as under:
“Telecom Regulatory Authority of India Mahanagar Doorsanchar Bhawan, Jawahar
Lal Nehru Marg, Old Minto Road New Delhi – 110 002 F.No.14-21/2009-FA Dated
21st May, 2010 Mr. Anand Dalal Addl. Vice President (Regulatory Affairs) M/s Tata
Group of Companies Indicom Building 2A, Old Ishwar Nagar Main Mathura Road
New Delhi – 110 065 Subject : Furnishing of Books of Accounts to the Branch Audit
Offices of the Director General of Audit, Post & Telecommunication.
Kindly refer to TRAI’s letter No.14-21/2009-FA dated 28th January, 2010, in which
your company has been asked to make available for audit all necessary records/books
of accounts circle/area-wise, to the corresponding Branch Audit Offices (as indicated
in the list) and to submit consolidated accounts to the Delhi office of the DG Audit,
P&T. Your company was also requested to make a presentation on the maintenance
of books of accounts and other relevant matters in the office of DG Audit P&T, New
Delhi.
2. We have been informed by the C&AG that your company has not responded to
these instructions so far.
3. In this connection, TRAI had received representations from the industry associates
indicating that the scope of the C&AG’s audit is similar to the scope of the exercise
that is being done by the special auditor appointed by the DoT and that this exercise
would be a duplication of work. The concerns expressed by the industry associations
were brought to the notice of the C&AG. However, the C&AG (through Director
General Audit (P&T) has informed us that the audit by the C&AG of India under
Section 16 of the C&A (DPC) Act is in exercise of the provisions of TRAI Rules, 2002
and has no relation with the special audit undertaken by the CAs appointed by DoT.
4. In view of the above, you are requested to make available all necessary
records/books of accounts circle/area wise, to the corresponding Branch Audit
Offices (as indicated in the letter dated 28th January, 2010) and to submit
consolidated accounts to the Delhi Office of the DG Audit, P&T within 15 days of the
receipt of this letter. You are also informed that non-compliance of this letter may
attract appropriate action under the TRAI Act.
This issues with the approval of the Authority.
Yours faithfully, Sd/-
(Anuradha Mitra) Pr. Advisor (FA)”
13. The TRAI also apprised the Service Providers that the audit sought to be conducted by CAG was
separate and independent of the audit or special audit conducted by DoT, and therefore, directed theAsso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

Service Providers to make available all the records for audit by CAG or else appropriate action would
be taken against them under the TRAI Act. Service providers, aggrieved by the stand of DoT and
TRAI, filed Civil Writ Petition 3673 of 2010, challenging the legality of the above-mentioned notices
before the Delhi High Court, seeking following reliefs:
“i. Pass a writ, order or direction to hold and declare that Rule 5 of the Telecom
Regulatory Authority of India, Service Providers (Maintenance of Books of Accounts
and other Documents) Rules, 2002 for being ultra vires of Section 16 of the C&AG Act
and Article 149 of the Constitution of India;
ii. Set aside/quash all actions taken/purported to be taken by the Respondent No.1
and/or Respondent No.2;
iii. Set aside/quash Respondent No.2’s letters dated 10.5.2010 and 21.5.2010 and the
directions contained therein;
iv. Set aside/quash Respondent No.3’s letter dated 28.1.2010 and the directions contained therein;
v. pass any order(s) as the Court may deem fit in the interest of justice, equity and good conscience.”
14. The Division Bench of the Delhi High Court examined the legality of the above-mentioned
communications in the light of Rule 5 of the TRAI Rules, 2002, Section 16 of the CAG Act, 1971 and
Article 149 of the Constitution of India read with UAS licence conditions and took the view that the
CAG has the powers to conduct the revenue audit of all accounts drawn by the licensees and
expressed the view that the accounts of the licensee, in relation to the revenue receipts can be said to
be the accounts of the Central Government and, thus, subject to a revenue audit, as per Section 16 of
the CAG (Duties, Powers and Conditions) Act, 1971. Holding so, the writ petitions were dismissed
against which these civil appeals have been preferred by way of special leave.
15. Shri Harish N. Salve, learned senior counsel appearing for the appellants, submitted that the
High Court has not properly appreciated the scope of Article 149 of the Constitution of India,
particularly the phrase “accounts of the Union and States and any other authority or body”. Learned
senior counsel submitted that a composite interpretation would reveal that the term ‘body’ is to be
construed in the light of the continuing term “Union”, “States” and “authority” all of which connote
some form of State control. Learned senior counsel also made reference to the principle of “nocitar a
cociis.” Learned senior counsel made reference to the Judgment of this Court in M.K. Ranganathan
v. Government of Madras (1955) 2 SCR 374, Rohit Pulp and Paper Mills v. Collector of Central
Excise, Baroda (1990) 3 SCC 447, Ahmedabad Pvt. Primary Teachers’ Association v. Administrative
Officer and others (2004) 1 SCC 755. Learned senior counsel also referred to the Constituent
Assembly Debates and Article 149 of the Constitution of India and submitted that the term “any
other authority or body” was only meant to cover the entities that perform State functions/or
entities financed or controlled by the State, as opposed to local bodies and other miscellaneous
corporations and organizations.Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

16. Learned senior counsel submitted that Section 16 of the Act of 1971 does not apply to audit of
private telecom licensees and submitted that the mere fact that licence fee payable under the licence
agreement has to be credited into the Consolidated Fund of India in the form of receipts does not
mean that a proprietary audit in respect of such receipts extends to a statutory audit of private
telecom licensee. Learned senior counsel also submitted that for audit of telecom licensees the
correct legal regime would be clause 22 of the Licence Agreement which specifically provides for
audit and special audit. Shri Salve also pointed out that the DoT, under the agreement, can appoint
an outside auditor of its choice or even the CAG can conduct an audit in terms of clause 22 of UAS.
Learned senior counsel also pointed out that the mere fact that Rule 5 of 2002 Rules states that the
CAG may carry out an audit of the accounts of telecom licensee under Section 16 of the 1971 Act does
not make such audit legally permissible. Rule 5, according to learned senior counsel, ought to be
struck down as ultra vires and in contravention of Section 16 of 1971 Act.
17. Shri Gopal Jain, learned senior counsel also appearing for the appellants, submitted that the
reasoning of the High Court is patently erroneous in law and pointed out that the licence agreement
obliges the licensee to maintain accounts as prescribed in the agreement to produce those accounts
as and when demanded, and if the Government is satisfied that the accounts are not maintained as
per the prescribed manner, a provision for special audit is there, which the service providers are also
subjected to. So far as the audit referred to under Article 149 of the Constitution is concerned,
learned senior counsel pointed out that there must be an element of government control of finance
and the same is completely lacking in the case of the service providers. Learned senior counsel also
referred to the meaning and content of Article 266 of the Constitution and stated that the same deals
with receipts which are payable into the Consolidated Fund of India and the receipts are only that of
the Union and the States, as the case may be, and not the private telecom companies.
18. Shri Paras Kuhad, learned Additional Solicitor General of India, appearing for the
respondent-Union of India, fully supported the reasoning of the High Court and submitted that the
High Court has correctly appreciated and understood the scope of Article 149 of the Constitution
which has clearly defined the powers of the CAG. Learned ASG pointed out that the conferment of
powers upon Parliament under Article 149 is not limited to the accounts of the Union and the States
and other bodies and authorities, but also extends to inclusion therein of the powers to legislate on
all matters concerning or pertaining to the accounts of the Union. Learned ASG placed considerable
emphasis on the expression “in relation to” which takes in the underlying accounts and records
maintained by the service providers. Learned ASG pointed out that the object of Article 149 of the
Constitution and Act of 1971 is to provide for Parliamentary control of executive on public funds,
consequently, ambit of audit by CAG has to cover all issues that are required to be examined by the
Parliament. Referring to the essence of Parliamentary Democracy, learned ASG placed reliance on
the decision of this Court in S.R. Chaudhuri v. State of Punjab and others (2001) 7 SCC 126 and
Kihoto Hollohan v. Zachillhu and others (1992) Suppl. 2 SCC 651.
19. Learned ASG also submitted “receipts payable into the Consolidated Fund of India” under
Article 266 of the Constitution of India take in “all revenue receipts received by the Government of
India” and submitted that a combined reading of Sections 13, 16 and 18 would indicate that it is
obligatory on the part of the CAG to audit all transactions entered into by the Union and the StatesAsso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

pertaining to the Consolidated Fund. Learned ASG referring to Rule 3 submitted that the Rule
prescribes the records required to be maintained enabling TRAI to carry out its obligation under
Section 11 and Rule 5 provides for furnishing the said record to TRAI for the said purpose and for its
audit by CAG. Learned ASG, therefore, submitted that the High Court has correctly interpreted the
various provisions of the Act and the constitutional provisions and hence calls for no interference.
20. We will, before examining the various contentions raised by the learned senior counsel for the
appellant and ASG on the scope of Article 149 of the Constitution, Section 16 of Act of 1971, Rule 5 of
2002 Rules etc., examine the various clauses in the UAS Licence Agreement. As already indicated,
the Licence Agreement specifically refers to Section 4 of the Indian Telegraph Act, 1885, which
highlights the fact that the Central Government enjoys an “exclusive privilege” so far as “spectrum”
is concerned, which is a scarce, finite and renewable natural resource which has got intrinsic utility
to mankind. Spectrum, as already indicated, is a natural resource which belongs to the people, and
the State, its instrumentalities or the licensee, as the case may be, who deal with the same, hold it on
behalf of the people and are accountable to the people.
21. The DoT had entered into various UAS licence agreements and, in certain cases, for few decades.
Agreement confers powers on DoT to suspend the operation of the licence at any time if it is
necessary or expedient to do so in the public interest or in the interest of the security of the State
and also reserves the right to take over the entire service equipments and network of the licensee or
revoke/terminate/suspend the licence in the interest of public or national security or in the interest
of national emergency/war etc. Licensor also reserves the right to keep any area out of the operation
zone of service if implications of security so require. Few of the clauses, which are relevant for our
purposes, need reference and hence are extracted hereunder. Clause 9.1 indicates the requirement of
furnishing of information which reads as under:
“9. Requirement to furnish information:
9.1 The LICENSEE shall furnish to the Licensor/TRAI, on demand in the manner and
as per the time frames such documents, accounts, estimates, returns, reports or other
information in accordance with the rules/ orders as may be prescribed from time to
time. The LICENSEE shall also submit information to TRAI as per any order or
direction or regulation issued from time to time under the provisions of TRAI Act,
1997 or an amended or modified statute.”
22. Clause 16 is general in nature and is extracted hereunder:
“16. General:
16.1 The LICENSEE shall be bound by the terms and conditions of this Licence
Agreement as well as by such orders/directions/ regulations of TRAI as per
provisions of the TRAI Act, 1997 as amended from time to time and instructions as
are issued by the Licensor/TRAI.Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

16.3 The Statutory provisions and the rules made under Indian Telegraph Act 1885 or
Indian Wireless Telegraphy Act, 1933 shall govern this Licence agreement. Any order
passed under these statutes shall be binding on the LICENSEE.”
23. Part 2 of the licence conditions refers to commercial conditions and clause 17 deals with
performance, which reads as under:
“17. Tariffs:
17.1 The LICENSEE will charge the tariffs for the SERVICE as per the Tariff orders/
regulations / directions issued by TRAI from time to time. The LICENSEE shall also
fulfill requirements regarding publication of tariffs, notifications and provision of
information as directed by TRAI through its orders/regulations/directions issued
from time to time as per the provisions of TRAI Act, 1997 as amended from time to
time.”
24. Part 3 of the licence conditions deals with the finance conditions, fee payable, etc. which reads as
under:
“18.1 Entry Fee:
One Time non-refundable Entry Fee of Rs.2 crore has been paid by the Licensee prior
to signing of this Licence Agreement.
18.2 Licence Fees:
In addition to the Entry Fee described above, the Licensee shall also pay Licence Fee
annually @ 6 (six)% of Adjusted Gross Revenue (AGR), excluding spectrum charges.
Annual Licence fee w.e.f. 1.4.2004 shall be @ 6 (six)% of AGR. The Licensor reserves
the right to modify the above mentioned Licence Fee any time during the currency of
this agreement.
18.3 Radio Spectrum Charges:
18.3.1 The LICENSEE shall pay spectrum charges in addition to the Licence Fee on
revenue share basis as notified separately from time to time by the WPC Wing.
However, while calculating ‘AGR’ for limited purpose of levying spectrum charges
based on revenue share, revenue from wireline subscribers shall not be taken into
account.
18.3.2 Further royalty for the use of spectrum for point to point links and other access
links shall be separately payable as per the details and prescription of Wireless
Planning & Coordination Wing. The fee/ royalty for the use of spectrum /possessionAsso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

of wireless telegraphy equipment depends upon various factors such as frequency,
hop and link length, area of operation and other related aspects etc. Authorization of
frequencies for setting up Microwave links by Licensed Operators and issue of
Licenses shall be separately dealt with by WPC Wing as per existing rules.”
25. Clause 19 deals with definition of Adjusted Gross Revenue (AGR) which reads as under:
“19. Definition of ‘Adjusted Gross Revenue’:
19.1 Gross Revenue:
The Gross Revenue shall be inclusive of installation charges, late fees, sale proceeds
of handsets (or any other terminal equipment etc.), revenue on account of interest,
dividend, value added services, supplementary services, access or interconnection
charges, roaming charges, revenue from permissible sharing of infrastructure and
any other miscellaneous revenue, without any set-off for related item of expense, etc.
19.2 For the purpose of arriving at the “Adjusted Gross Revenue (AGR)” the following
shall be excluded from the Gross Revenue to arrive at the AGR:
I. PSTN related call charges (Access Charges) actually paid to other eligible/entitled
telecommunication service providers within India;
II. Roaming revenues actually passed on to other eligible/entitled telecommunication
service providers and;
III. Service Tax on provision of service and Sales Tax actually paid to the Government
if gross revenue had included as component of Sales Tax and Service Tax.”
26. Clause 20 deals with the schedule of payments of annual licence fee and other dues. Relevant
clauses being 20.4, 20.6, 20.7 and 20.11 are extracted hereunder:
“20.4 The quarterly payment shall be made together with a STATEMENT in the
prescribed form as annexure-II, showing the computation of revenue and Licence fee
payable. The aforesaid quarterly STATEMENTS of each year shall be required to be
audited by the Auditors (hereinafter called LICENSEE’S Auditors) of the LICENSEE
appointed under Section 224 of the Companies’ Act, 1956. The report of the Auditor
should be in prescribed form as annexure-II.
20.6 Final adjustment of the Licence fee for the year shall be made based on the gross
revenue figures duly certified by the AUDITORS of the LICENSEE in accordance with
the provision of Companies’ Act, 1956.
20.7 A reconciliation between the figures appearing in the quarterly statements
submitted in terms of the clause 20.4 of the agreement with those appearing inAsso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

annual accounts shall be submitted along with a copy of the published annual
accounts audit report and duly audited quarterly statements, within 7 (seven)
Calendar days of the date of signing of the audit report. The annual financial account
and the statement as prescribed above shall be prepared following the norms as
prescribed in Annexure.
20.11 The LICENSOR, to ensure proper and correct verification of revenue share paid, can, if
deemed necessary, modify, alter, substitute and amend whatever stated in Conditions 20.4, 20.7,
22.5 and 22.6 hereinbefore and hereinafter written.”
27. Clause 22 deals with the preparation of accounts. Relevant clauses are extracted hereunder:
“22. Preparation of Accounts.
22.1 The LICENSEE will draw, keep and furnish independent accounts for the
SERVICE and shall fully comply orders, directions or regulations as may be issued
from time to time by the LICENSOR or TRAI as the case may be.
22.2 The LICENSEE shall be obliged to:
a) Compile and maintain accounting records, sufficient to show and explain its
transactions in respect of each completed quarter of the Licence period or of such
lesser periods as the LICENSOR may specify, fairly presenting the costs (including
capital costs), revenue and financial position of the LICENSEE’s business under the
LICENCE including a reasonable assessment of the assets employed in and the
liabilities attributable to the LICENSEE’s business, as well as, for the quantification
of Revenue or any other purpose.
(b) Procure in respect of each of those accounting statements prepared in respect of a
completed financial year, a report by the LICENSEE’s Auditor in the format
prescribed by the LICENSOR, stating inter-alia whether in his opinion the statement
is adequate for the purpose of this condition and thereafter deliver to the LICENSOR
a copy of each of the accounting statements not later than three months at the end of
the accounting period to which they relate.
c) Send to the LICENSOR a certified statement sworn on an affidavit, by authorized
representative of the company, containing full account of Revenue as defined in
condition 19 for each quarter separately along with the payment for the quarter.
22.3 (a) The LICENSOR or the TRAI, as the case may be, shall have a right to call for and the
LICENSEE shall be obliged to supply and provide for examination any books of accounts that the
LICENSEE may maintain in respect of the business carried on to provide the service(s) under this
Licence at any time without recording any reasons thereof.Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

22.3 (b) LICENSEE shall invariably preserve all billing and all other accounting records (electronic
as well as hard copy) for a period of THREE years from the date of publishing of duly audited &
approved Accounts of the company and any dereliction thereof shall be treated as a material breach
independent of any other breach, sufficient to give a cause for cancellation of the LICENCE.
22.5 The LICENSOR may, on forming an opinion that the statements or accounts submitted are
inaccurate or misleading, order Audit of the accounts of the LICENSEE by appointing auditor at the
cost of the LICENSEE and such auditor(s) shall have the same powers which the statutory auditors
of the company enjoy under Section 227 of the Companies Act, 1956. The remuneration of the
Auditors, as fixed by the LICENSOR, shall be borne by the LICENSEE.
22.6 The LICENSOR may also get conducted a ‘Special Audit’ of the LICENSEE company’s
accounts/records by “Special Auditors”, the payment for which at a rate as fixed by the LICENSOR,
shall be borne by the LICENSEE. This will be in the nature of auditing the audit described in para
22.5 above. The Special Auditors shall also be provided the same facility and have the same powers
as of the companies’ auditors as envisaged in the Companies Act, 1956.
22.7 The LICENSEE shall be liable to prepare and furnish the company’s annual financial accounts
according to the accounting principles prescribed and the directions given by the LICENSOR or the
TRAI, as the case may be, from time to time.”
28. Clause 32 deals with the obligations imposed upon the licensee, which read as under:
“32. Obligations imposed on the LICENSEE.
32.1 The provisions of the Indian Telegraph Act 1885, the Indian Wireless Telegraphy
Act 1933, and the Telecom Regulatory Authority of India Act, 1997 as modified from
time to time or any other statute on their replacement shall govern this LICENCE.
32.2 The LICENSEE shall furnish all necessary means and facilities as required for
the application of provisions of Section 5(2) of the Indian Telegraph Act, 1885,
whenever occasion so demands.
Nothing provided and contained anywhere in this Licence Agreement shall be deemed to affect
adversely anything provided or laid under the provisions of Indian Telegraph Act, 1885 or any other
law on the subject in force.”
29. We have earlier referred to the clauses of the licence agreement, which indicate the pattern of
“revenue sharing” between the Union of India and the licensee. Licence fee envisages, apart from the
one-time non refundable Entry Fee, the licence fee annually be paid @ 6% of AGR excluding
spectrum charges. Right is also reserved on the licensor to modify the licence fee during the
currency of the agreement. Spectrum charges have to be paid in addition to the licence fee on
“Revenue Sharing Basis”. While levying spectrum charges based on AGR, the components which
form the AGR have also been given in clause 19.1, which is wide enough to embrace other source ofAsso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

revenue inflow. Licensee is, therefore, obliged to maintain the accounts relating to licence
agreement and particularly the revenue received by it because it has to share the revenue with the
Union, which has to be calculated with reference to the Gross Revenue Receipts.
30. TRAI Service Providers (Maintenance of Books of Accounts and other Documents) Rules, 2002
have been framed by the Central Government in exercise of the powers conferred under sub-section
(1) read with clause (d) of sub-section (2) of Section 35 of the TRAI Act, 1997. Rule 3 deals with the
maintenance of books of accounts and other documents, which reads as under:
“3. Maintenance of Books of Accounts and other Documents – (1) Every service
provider shall keep and maintain the following books of accounts and other
documents in the manner as specified by the Central Government from time to time,
namely:-
i) books of accounts to reflect the itemized original and current cost service-wise of
fixed assets and separate heads for different category of assets may be maintained;
ii) books of accounts and other documents to reflect service-wise itemised
operational expenses;
iii) books of accounts to reflect service-wise revenue;
iv) books of accounts to reflect income from other sources;
v) supporting books of accounts and other documents as –
a) fixed assets register;
b) stores and spares register
c) register showing particulars, service-wise, of subscribers;
          d)    register showing deposits from customers;
          e)    cash book;
          f)    journal;
          g)    ledger; and
h) copies of bills and copies of counter foils of all receipts.Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

Explanation – For the purpose of this rule –
a) “itemized” means the requirement for both the total cost and also its break-up;
b) “current cost” means cost after depreciation; and
c) “fixed assets” includes sub-heads such as building, plant and machinery, etc. (2) Every service
provider shall intimate to the Authority the place where the books of accounts and other documents
are maintained.”
31. Rule 5 of 2002 Rules, the validity of which is under challenge, reads as under:
“5. Audit Every service provider shall produce all such books of accounts and
documents, referred to in sub-rule (1) of rule 3, that has a bearing on the verification
of the Revenue, to the Authority –
(i) for the purpose of calculating license fee; and
(ii) to furnish to the Comptroller and Auditor General of India the statement or
information, relating thereto, which the Comptroller and Auditor General of India
may require to be produced before him and the Comptroller and Auditor General of
India may audit the same in accordance with the provisions of Section 16 of the
Comptroller and Auditor General’s (Duties, Powers and Conditions of Service) Act,
1971 (56 of 1971).”
32. UAS Licence holders do not dispute the fact that they have to maintain books of accounts and
other documents referred to in Rule 3 of 2002 Rules and they also do not question the right of the
DoT under Clause 22.5 to appoint an auditor, nor do they question the DoT’s power to appoint a
Special Auditor under Clause 22.6 or even the audit being conducted by DoT through CAG. UAS
Licence holders also do not dispute that the transactions between them and the Union of India form
the basis for ascertaining the amounts payable to the Union of India, by way of Revenue Share,
which has to be credited to the Consolidated Fund of India. What they dispute is the competence of
CAG to conduct audit of the accounts of the service providers in accordance with the provisions of
Section 16 of the Act of 1971 read with Rule 5(ii) of 2002 Rules. Power of the CAG under Section 16
of the 1971 Act has been disputed primarily on the ground that Article 149 of the Constitution
confers powers on the CAG to conduct audit of accounts only of the Union and the States or any
other authority or body prescribed by or under any law made by Parliament, not private entities or
their underlying accounts and records maintained by them in the absence of law made by the
Parliament. We may point out that this is the prime question that arises for consideration in these
appeals.
CAGAsso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

33. We may first examine the powers of the CAG under our constitutional scheme. Article 148 of the
Constitution states that there shall be a Comptroller and Auditor General, who shall be appointed by
the President by warrant under his hand and shall only be removed in like manner and on like
grounds as of Judge of the Supreme Court of India. The CAG is, therefore, an important functionary
under the Constitution and, it is often said, he is the guardian of the purse and that he should see
that not farthing of it is spent without the authority of the Parliament. Article 149 deals with the
duties and powers of the CAG which reads as under:
“149. Duties and powers of the Comptroller and Auditor General. The Comptroller
and Auditor General shall perform such duties and exercise such powers in relation
to the accounts of the Union and of the States and of any other authority or body as
may be prescribed by or under any law made by Parliament and, until provision in
that behalf is so made, shall perform such duties and exercise such powers in relation
to the accounts of the Union and of the States as were conferred on or exercisable by
the Auditor General of India immediately before the commencement of this
Constitution in relation to the accounts of the Dominion of India and of the Provinces
respectively.”
34. Article 149 does confer the power on the CAG to discharge duties and powers in relation to the
accounts of the Union and the States or any other authority or body, as may be prescribed under the
law made by the Parliament. CAG, therefore, is exercising constitutional powers and duties in
relation to the accounts, while the High Court under Article 226 of the Constitution, so also the
Supreme Court under Article 32 of the Constitution, is exercising judicial powers. Duties and powers
conferred by the Constitution on the CAG under Article 149 cannot be taken away by the Parliament,
being the basic structure of our Constitution, like Parliamentary democracy, independence of
judiciary, rule of law, judicial review, unity and integrity of the country, secular and federal
character of the Constitution, and so on.
35. The scope of Article 148 vis-à-vis the powers of the CAG came up for consideration before this
Court in S.Subramaniam Balaji v. State of Tamil Nadu and others (2013) 9 SCC 659 and this Court
held that the CAG is the constitutional functionary appointed under Article 148 of the Constitution
and its main role is to audit the income and expenditure of the Government, government bodies and
State run corporations and the extent of its duties is listed in the Comptroller and Auditor General
(Duties, Powers etc.) Act, 1971. It is stated that functioning of the Government is controlled by the
government, laws of the land, legislature and the CAG. CAG has the power to examine the propriety,
legality and validity of all expenses incurred by the government and the office of the CAG exercises
effective control over the government accounts and expenditure incurred on the schemes only after
implementation of the scheme, as a result, the duties of the CAG will arise only after the expenditure
has been incurred.
36. In Arvind Gupta v. Union of India and others (2013) 1 SCC 393 this Court, while examining the
scope of Articles 149, 150 and 151 of the Constitution, vis-à-vis the reports of the CAG, noticed and
pointed out that the CAG’s functions are carried out in the economy’s efficiency and effectiveness
with which the government has used its resources and it was pointed out that performance/auditAsso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

reports prepared under the regulations have to be viewed accordingly. In Arun Kumar Agrawal v.
Union of India and others (2013) 7 SCC 1 this Court while interpreting Section 16 of 1971 Act held
that the CAG has to satisfy himself that the rules and procedures, designed to secure an effective
check on the assessment, collection and proper allocation of revenue are being duly observed and
CAG has to examine the decisions which have financial implications, including the propriety of
decision making. This Court also noticed that the report of the CAG is required to be submitted to
the President, who shall cause them to be laid before each House of Parliament, as provided under
Article 151(1) of the Constitution of India. By placing the reports of the CAG in the Parliament, CAG
regulates the accountability of the Executive to the Parliament in the field of financial
administration, thereby upholding the parliamentary democracy.
37. We are of the considered view that when the executive deals with the natural resources, like
spectrum, which belongs to the people of this country, Parliament should know how the nation’s
wealth has been dealt with by the executive and even by the UAS Licence holders and the quantum
of the Revenue generated out of the use of the spectrum and whether the same has been properly
assessed, collected and accounted for by the Union and the UAS Licence holders. When nation’s
wealth, like spectrum, is being dealt with either by the Union, State or its instrumentalities or even
the private parties, like service providers, they are accountable to the people and to the Parliament.
Parliamentary democracy also envisages, inter alia, the accountability of the Council of Ministers to
the Legislature. In this connection reference may be made to the Judgment of this Court in S.R.
Chaudhuri (supra) and Kihoto Hollohan (supra).
38. Learned senior counsel appearing for the service providers, while interpreting Article 149 of the
Constitution, questioned the CAG’s jurisdiction, stating that so far as the service providers are
concerned, it does not extend to them since they are not government companies, nor do they receive
any funding from the government. Further, it is also pointed out that they do not fall, rather not
covered within the ambit of ‘any other authority or body’ prescribed under any law made by the
Parliament. It was also pointed out that the CAG cannot audit private companies, like the service
providers.
39. While examining the scope of Article 149, read with Section 16 of 1971 Act, let us not forget that
we are dealing with a natural resource which belongs to the peoples of this country, and hence we
have to give a purposive interpretation to Article 149 read with Section 16 of 1971 Act and Rule
5(i)(ii) of 2002 Rules. Much emphasis has been made on the Constituent Assembly Debates in
respect of Article 149 (which was previously Article 145 in the 1940’s Draft Constitution) and it was
submitted that the term “any other authority or body” in Article 149 was only meant to cover entities
that performed State functions and/ or entities financed or controlled by the State, as opposed to
“local bodies and other miscellaneous corporations and organizations”.
40. Constitution, as it is often said “is a living organic thing and must be applied to meet the current
needs and requirements”. Constitution, therefore, is not bound to be understood or accepted to the
original understanding of the constitutional economics. Parliamentary Debates, referred to by
service providers may not be the sole criteria to be adopted by a court while examining the meaning
and content of Article 149, since its content and significance has to vary from age to age.Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

Fundamental Rights enunciated in the Constitution itself, as held by this Court in People’s Union
For Civil Liberties (PUCL) and another v. Union of India and another (2003) 4 SCC 399, have no
fixed content, most of them are empty vessels into which each generation has to pour its content in
the light of its experience.
41. Parliament has an obligation to ascertain whether the entire receipts by way of licence fee,
spectrum charges, have been realized by the Union of India and credited to the Consolidated Fund
of India (CFI). Article 266 says, all the public moneys received by or on behalf of the Government of
India shall be credited to CFI. CAG can carry out examination into the economy, efficacy and
effectiveness with which the Union of India has used its resources, and whether it has realized the
entire licencee fee, spectrum charges and also whether the Union of India has correctly carried out
the audit under Clauses 22.5 and 22.6 of UAS Licence Agreement. CAG’s examination of the
accounts of the Service Providers in a Revenue Sharing Contract is extremely important to ascertain
whether there is an unlawful gain to the Service Provider and an unlawful loss to the Union of India,
because the revenue generated out of that has to be credited to the Consolidated Fund of India. The
subject matter, with which we are concerned, as already indicated, is “spectrum”, a natural resource,
which belongs to the people, therefore, people of this country, through Parliament should know how
its natural resources have been dealt with by the Union, State or its instrumentalities or even by
UAS licence holders. Instances are not rare, where even the Executive, at times, acts hand in glove
with licence holders, who deal with the natural resources, hence, necessity of proper parliamentary
control over the resources. We have to understand the scope of Article 149 of the Constitution,
Section 16 of 1971 Act and Rule 5 of TRAI Rules 2002, in that perspective.
42. Chapter 3 of the Act of 1971 deals with the duties and powers of the CAG. Section 13 of the Act
deals with the general provisions relating to audit and the same is extracted hereinbelow:
“13. It shall be the duty of the Comptroller and Auditor General –
a) to audit all expenditure from the Consolidated Fund of India and of each State and
of each Union Territory having a Legislative Assembly and to ascertain whether the
moneys shown in the accounts as having been disbursed were legally available for
and applicable to the service or purpose to which they have been applied or charged
and whether the expenditure conforms to the authority which governs it;
b) to audit all transactions of the Union and of the State relating to Contingency
Funds and Public Accounts;
c) to audit all trading, manufacturing, profit and loss accounts and balance sheets
and other subsidiary accounts kept in any department of the Union or of a State;
and in each case to report on the expenditure, transactions or accounts so audited by him.”
43. Section 13(b) provides that the CAG would “audit all transactions of the Union and of the States
relating to Contingency Funds and Public Accounts”. The expression “transaction” means anAsso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

incident of buying and selling or action of conducting business, it also means an exchange or
interaction between people. The “transaction” is, therefore, an expression of widest amplitude and
would cover even the lease agreement entered into by the Union with service providers. The
expression “relating to” refers to “Contingency Funds and Public Accounts”. While examining the
scope of Section 13, the test to be applied is, is it a transaction of Union or State or is it, in any way,
“relates to contingency public fund”.
44. Section 16 of the Act of 1971 deals with audit of receipts of Union or States, reads as under:
“16. It shall be the duty of the Comptroller and Auditor-General to audit all receipts
which are payable into the Consolidated Fund of India and of each State and of each
Union Territory having a Legislative Assembly and to satisfy himself that the rules
and procedures in that behalf designed to secure an effective check on the
assessment, collection and proper allocation of revenue and are being duly observed
and to make for this purpose such examination of the accounts as he thinks fit and
report thereon.”
45. The expression “to audit all receipts” does not distinguish the revenue receipts and non-revenue
receipts. For the purpose of audit of receipts, the duty of the CAG extends “to such examination of
the accounts as it thinks fit and report thereon”. Section 13 read along with Section 16 makes it clear
that the expression “to audit all transactions” so also “audit of all receipts”, payable into
Consolidated Fund of India would take in not only the accounts of the Union and of the State and of
any other authority or body as may be prescribed or under any law made by the Parliament but also
to audit all transactions which Union and State have entered into which has a nexus with
Consolidated Fund, especially when the receipts have direct connection with Revenue Sharing.
46. Above reasoning is further re-inforced if we look at Section 18 of the Act, which deals with the
powers of the CAG in connection with the audit of accounts, which reads as follows :-
“18. (1) The Comptroller and Auditor-General shall in connection with the
performance of his duties under this Act, have authority –
a) to inspect any office of accounts under the control of the Union or of a State
including treasuries, and such offices responsible for the keeping of initial or
subsidiary accounts, as submit accounts to him;
b) to require that any accounts, books, papers and other documents which deal with
or form the basis of or an otherwise relevant to the transactions to which his duties in
respect of audit extend, shall be sent to such place as he may appoint for his
inspection;
c) to put such questions or make such observations as he may consider necessary, to
the person in charge of the office and to call for such information as he may require
for the preparation of any account or report which it is his duty to prepare.Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

(2) The person in charge of any office or department, the accounts of which have to
be inspected and audited by the Comptroller and Auditor-General, shall afford all
facilities for such inspection and comply with requests for information in as complete
a form as possible and with all reasonable expedition.” Section 18(1)(b) delineates the
powers of the CAG to call for the books of accounts, papers and other documents
which form the basis of various transactions to which his duties extend.
47. Section 16 of Act 56 of 1971 has to be understood in the light of Article 266 of the Constitution.
Article 266 also uses the expression “all revenue receipts by the Government of India” which
evidently includes income of the nation received by the DoT in parting with the privilege i.e.
‘spectrum” on a revenue sharing basis with service providers. The expression “licence fee” in clause
18.1 and “Radio spectrum charges” in clause 18.3.1 in the licence agreement for UAS have to be
understood in that perspective. The licence fee received by the DoT so also the Radio spectrum
charges while granting the privilege to deal with the spectrum by the licensees is a “revenue received
by the Government” within the meaning of Article 266 i.e. “a receipt payable into the Consolidated
Fund of India” within the meaning of Section 16 of 1971 Act.
48. Revenue share receivable by the Union being a receipt payable into the Consolidated Fund” by
virtue of Section 16 and 18(1)(b) of 1971 Act, in relation to such receipts, the CAG is entitled to seek
the records maintained in terms of Rule 3 of Rules of 2002 and the records maintained under
clauses 22.1 and 22.2 of the licence agreement. We are of the view that unless the underlying records
which are in the exclusive custody of the Service Providers are examined, it would not be possible to
ascertain whether the Union of India, as per the agreement, has received its full and complete share
of Revenue, by way of licence fee and spectrum charges.
49. We may now examine the challenge made to Rule 5 of TRAI Rules 2002, on the basis that the
same is ultra vires to Section 16 of CAG Act, 1971 and Article 149 of the Constitution. Clauses 9.1 as
well as 16.1 of the Licence Agreement categorically states that the licensee shall be bound by the
terms and conditions of the agreement as well as by the order/directions/regulations of TRAI as per
the provisions of TRAI Act, 1997. For effective fulfillment of the above-mentioned statutory
obligations, TRAI framed 2002 Rules under Section 35 of Act of 1971. Rule 3 of TRAI Rules 2002, as
already stated, casts an obligation on the service providers to maintain the Books of Accounts and
other documents so as to make available the same to CAG. Article 149 of the Constitution, as already
indicated, provides for confirmation of powers upon CAG under any law i.e. even by supporting
legislation and Rule 5 falls in that category. Rule 5 obliges every service provider to produce all such
books of accounts or documents referred to in sub-rule (1) of Rule 3 so that the CAG can carry out
audit entrusted to it by virtue of the powers conferred under Article 149 read with Section 16 of Act
of 1971. Rule 5 only manifests conferment of powers upon CAG in relation to the accounts of bodies
in the nature of private service providers which we have already found is consistent with Article 149
of the Constitution.
50. We have to read Section 13, 16 and 18 of the 1971 Act along with Article 149 of the Constitution
and Sections 3 and 5 of the TRAI Act, 1997 and, if so read, in our view, CAG is entitled to seek the
records in terms of Rule 3 of TRAI Rules 2002 read with Clause 22 of the Licence Agreement. CAG,Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

in that process, is not actually auditing the accounts of the UAS Service providers as such, but
examining all the receipts to ascertain whether the Union is getting its due share by way of licence
fee and spectrum charges, which it is legitimately entitled to, by way of Revenue Sharing. By
adopting that process, CAG is not carrying out any statutory audit of the accounts of the service
providers, but for the limited purpose of ascertaining whether the Union is getting its legitimate
share by way of “Revenue Sharing”. Service providers are, therefore, bound to provide all the
records and documents called for by the CAG.
51. CAG has, therefore, a duty to examine and satisfy himself that all the rules and procedures in
that behalf are being met not only by the Union but also the service providers as a whole, since both,
the Union, as well as the service providers, are dealing with the natural resources. CAG’s function is,
therefore, separate and independent, which is not similar to the audit conducted by the DoT under
Clause 22.5 or special audit under Clause 22.6. CAG’s function is only to ascertain whether the
Union of India is getting its due share, while parting with the right to deal with its exclusive privilege
to the Service Providers, who are dealing with a national wealth, to that extent, Rule 5(1)(ii) has to
be read down, but the service providers are bound to make available all the books of accounts and
other documents maintained by them under Rule 3, so as to ascertain whether the Union of India is
getting its full share of revenue.
CIVIL APPEAL NOS.10748 AND 10749 OF 2011
52. We are, in these appeals, concerned with the legality of the communication dated 16.3.2010
issued by the Department of Telecommunications and the communication dated 10.5.2010 issued
by the Director General of Audit, Post and Telecommunication, to the various Telecom service
providers covered by Unified Access Service (UAS) License for making available all the accounting
records for three years commencing from 2006-2007 for the purpose of audit by the Comptroller of
Auditor General of India (CAG).
53. The Telecom Service Providers approached the Telecom Disputes Settlement and Appellate
Tribunal (for short ‘the Tribunal’) and filed two petition Nos. 139 and 141 of 2010 seeking following
reliefs:
“i. Set aside/quash the impugned communications inter alia dated 16th March, 2010
and 10th May, 2010 seeking audit of telecom companies by the C&AG and seeking
information beyond the ambit and scope of the UAS license;
ii. Strike down Rule 5(b) of TRAI Service Providers (Maintenance of Books of
Accounts and other Documents) Rules, 2002 as being ultra vires.
iii. Pass any order(s) as the Tribunal may deem fit in the interest of justice, equality
and good conscience.”
54. The Tribunal considered the question as to whether it could examine the vires of Rule 5 of the
Telecom Regulatory Authority of India, Service Providers (Maintenance of Books of Accounts andAsso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

other Documents) Rules, 2002 as a preliminary issue and, on 19.5.2010, held that rules framed by
the Central Government in exercise of its Rule making power under Sections 35 of the Act could not
be a subject matter of challenge before it and held that no relief could be granted on the challenge of
the vires of Rule 5 of TRAI Rules 2002. The Tribunal, therefore, admitted the petitions only on the
limited ground of examining the legal validity of the communications dated 16.3.2010 and
10.5.2010. The Tribunal also noticed that a writ petition was already pending before the Delhi High
Court challenging the vires of Rule 5 of TRAI Rules 2002 and then went on to examine the legality of
the above mentioned communications.
55. The Tribunal proceeded as if the above mentioned communications were issued by the DoT in
exercise of its jurisdiction conferred under Clauses 22.3 to 22.6 of the Conditions of License
enumerated in the license agreement for UAS. The above mentioned communications, as noted by
the Tribunal, were questioned by the service providers on the following grounds:
“(i) Before directing an audit in regard to the accounts of the licensees, the DOT was
required to form an opinion which in turn would require an application of mind on
its part and assignment of reasons which having not been complied with, the
impugned action cannot be sustained.
(ii) A special audit having been conducted in respect of the financial years 2006-2007
and 2007-2008 by a private Auditor, the impugned action on the part of the
respondent must be held to be wholly illegal.
(iii) Adherence to the principles of natural justice which is a sine-
qua-non for exercise of the power conferred on DOT having not been complied with, the impugned
letters are liable to be quashed.
(iv) The invoices and other documents supporting the books of accounts maintained by the
petitioner would be voluminous keeping in view the fact that Vodafone alone has about 200 million
subscribers.
(v) Exercise of power by DOT in any event was an abuse of process of the Court.
(vi) DOT cannot be permitted to do something indirectly which it cannot do directly.”
56. The Tribunal also considered the contentions raised by the Department, which are as follows:
“(a) DOT has exercised its power in terms of the letter issued by TRAI as also by the
Comptroller of Auditor General of India.
(b) Some of the parties, namely, Vodafone and Airtel having expressly undertaken to
produce the books of accounts and co-operate with the respondent are stopped and
precluded from raising the question of the jurisdiction of the Tribunal.Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

(c) Having regard to clause 22.4 of the Conditions of License, DOT could adopt one of
the three measures, namely: (i) refer the matter to the Comptroller and Auditor
General which has even otherwise the requisite jurisdiction to audit the books of
accounts of the petitioners for the purpose of ascertaining as to whether the revenue
earned by them has correctly been shared with the DOT in terms of the conditions of
license; (ii) conduct an audit within the meaning of provisions of clause 22.5 of the
license and; (iii) conduct a special audit.
(d) The power to conduct an audit through CAG or departmentally or a special audit
are independent powers in respect whereof DOT can exercise its discretion.”
57. The Tribunal noticed that a special audit had already been conducted and hence the question of
having another audit in terms of Clause 22.5 would arise only if the Department “forms an opinion”
which would mean an “honest and bona fide” opinion that the accounts submitted by the service
providers were inaccurate and misleading. The Tribunal also took the view that the recourse to
Clause 22.5 could be taken only after the accounts for the licencees had been audited by the auditor
and that a special audit could be undertaken only for the audited accounts and not for any other
purpose. The Tribunal concluded as follows:
“An audit or a special audit within the meaning of clauses 22.5 and 22.6 envisages
some special actions. For the purpose of taking recourse to clause 22.5 the
respondent was required to form an opinion which would mean an honest and
bonafide one. The respondent as a ‘State’ within the meaning of Article 12 of the
Constitution of India is also required to act reasonably and fairly.”
58. The Tribunal later referred to Clause 22.5 and stated as follows:
“An audit in terms of Clause 22.5 of the license, therefore, can be directed, provided a
misstatement or a mis-declaration is noticed. The opinion can be formed only if the
statement of accounts is found to be inaccurate or misleading. The licensees are also
required to bear the costs of the Auditors. In terms of the aforementioned provisions,
not only the same would require assignment of reasons but also compliance of the
principles of natural justice.”
59. In support of its reasoning, the Tribunal placed reliance on the judgments of this Court in Rajesh
Kumar and Others v. Deputy CIT and Others (2007) 2 SCC 181 as also the reference order passed in
Sahara India (Firm) Lucknow v. Commissioner of Income Tax, Central-I and Another (2008) 14
SCC
151. The Tribunal also examined the principles laid down in Anisminic Ltd. V. Foreign
Compensation Commission 1969 (1) All England Reporter 208 on the question of “jurisdictional
error” and took the view that, after the special audit had been conducted, the question of having
another audit in terms of Clause 22.5 of the Conditions of License would not arise. Holding so, the
Tribunal set aside the communications dated 16.3.2010 and 10.5.2010 and allowed the petitionsAsso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

with costs of Rs.50,000/. Aggrieved by the same, these two appeals have been preferred.
60. Shri Paras Kuhad, learned Additional Solicitor General appearing for the appellants, submitted
that the Tribunal has completely misapplied various clauses of the licence agreement, especially
Clauses 22.3, 22.5 and 22.6 which, according to the learned senior counsel, empower the
Department to call for the books of account of the service providers for its audit. Shri Kuhad
submitted that the communications dated 16.3.2010 and 10.5.2010 are intended to carry out an
audit by the CAG and that the Department has got the legal right to call upon the service providers
to make available all the records so that they could be scrutinized by the CAG. CAG, it was pointed
out, has got the power under Article 149 of the Constitution read with Section 16 of the Comptroller
of Auditor General’s (Duties, Powers and Conditions of Service) Act, 1971 and Rule 5 of TRAI Rules,
2002 and the conditions of license to carry on audit of the accounts of the service providers, since
the Union of India and the service providers are in agreement for revenue sharing. Shri Kuhad also
questioned the finding of the Tribunal that before exercising the powers by the CAG for audit, the
department has to form an opinion that the statements and account already submitted were
inaccurate and misleading. Shri Kuhad further submitted that the Tribunal has completely misread
of the various clauses of UAS License as well as the powers conferred under the 1971 Act.
61. Shri Gopal Jain, learned senior counsel appearing for the respondents service providers,
supported the reasoning of the Tribunal in setting aside the communications dated 16.3.2010 and
10.5.2010 and submitted that an audit by CAG, or for that matter even by the Department, could be
conducted only if the DoT had formed an opinion that the statements or accounts submitted by the
service providers were inaccurate or misleading. In other words, it was pointed out, that for taking
recourse to Clause 22.5, the department was required to form an opinion which would mean “honest
and bona fide opinion” that the accounts made available were misleading or inaccurate and, for that
purpose, the department has to act reasonably and fairly.
62. We are of the view that there has been a complete misreading of the various clauses of the
licensing agreement as well as understanding of law on the point. Let us first examine the
background under which the communications dated 16.3.2010 and 10.5.2010 were issued by DoT
and the Director General of Audit, Post & Telecommunications respectively, to the UAS license
holders. Both the communications would indicate that they were sent for seeking cooperation for
the Audit of Telecom service providers by the CAG, which is neither an audit by the department
within the meaning of Clause 22.5, nor a special audit under Clause 22.6. For easy reference, we
may, once again, refer the relevant portions of the communication dated 16.3.2010:
“Government of India Ministry of Communication Department of
Telecommunication (AS Cell) Sanchar Bhawan, 20, Ashoka Road, New Delhi – 110
001 No. 842-1086/1010-AS-IV Dated 16th March, 2010 To M/s. Bharti Airtel Ltd.
And Bharti Hexacom Ltd., Unitech World Cyber Park Power-A, 4th Floor, Sector 39,
Gurgaon – 122 001 Subject : Audit of Telecom Service Providers by C&AG Reference:
Unified Access Service Licence Agreements as detailed below:
     |Sl. No.       |Service Area   |Licence No.    |Dated          |
|  xxx         |Xxx            |Xxx            |xxx            |Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

In exercise of powers conferred on the Licensor under clause 22.3 of Unified Access
Service (UAS) Licence, it is requested to provide the following accounting records, for
three years commencing from 2006-07, consisting of books of accounts and other
documents for all the services offered under the above referred UAS licences issued,
to reflect:
i) Total cost and break-up of original and current cost i.e. cost after depreciation
under separate head for different category of fixed assets;
ii) Cost and breakup of operation expenses
iii) Service wise revenue
iv) Income from other sources
v) Supporting books of accounts/ other documents as
a) Fixed asset register
b) Stores and spares / inventory register
c) Register showing service – wise particulars of subscribers
d) Register showing deposits from customers
e) Cash books
f) Journals
g) Ledger
h) Copes of bill and counter foils of all receipts.
[Emphasis Supplied]
2. The above mentioned information should be sent directly to DDG (Accounts), Department of
Telecommunications, Room No. 701, Sanchar Bhavan, 20, Ashoka Road, New Delhi 110 001 within
15 days from date of issue of this letter.
Sd/- 16.3.2010 (Shashi Mohan) Director (AS-IV)”Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

63. The communication dated 16.3.2010 was issued by the DoT in exercise of powers conferred
under Clause 22.3 of UAS License calling for the accounting records for three years consisting of
books of accounts and other documents referred to therein. The purpose of issuing such a letter has
been specifically earmarked stating “Audit of telecom service providers by C&AG”. Above mentioned
communications were issued not under Clause 22.5, as noticed by the Tribunal, but under Clause
22.3, which is reflected in the above mentioned communications itself. Clause 22.3 reads as follows:
“22.3 (a) The LICENSOR or the TRAI, as the case may be, shall have a right to call for
and the LICENSEE shall be obliged to supply and provide for examination any books
of accounts that the LICENSEE may maintain in respect of the business carried on to
provide the service(s) under this Licence at any time “without recording any reasons
thereof”.
22.3(b) LICENSEE shall invariably preserve all billing and all other accounting
records (electronic as well as hard copy) for a period of THREE years from the date of
publishing of duly audited & approved Accounts of the company and any dereliction
thereof shall be treated as a material breach independent of any other breach,
sufficient to give a cause for cancellation of the LICENCE.” (Emphasis Supplied)
64. Clause 22.3(a) specifically states that the licensor or TRAI shall have a right to call for and the
licensee shall be obliged to supply and provide for examination any books of accounts that the
licensee may maintain in respect of the business carried on to provide services under this license at
any time “without recording any reasons thereof”. In other words, while issuing the communication
dated 10.5.2010, DoT or TRAI is not expected to record any reasons and that they can summon
books of accounts in respect of the business at any time, from the UAS Licence holders.
65. Let us now examine the communication dated 10.5.2010 issued by the Director General of Audit,
Post & Telecommunications to the UAS service providers, which specifically refers to the
communication dated 16.3.2010, which is extracted below, once again, for an easy reference:
“D.O. No. Report-PSP/F-4/Vol-II/2009-10/4 OFFICE OF THE Director General of
Audit, Post & Telecommunications Sham Nath Marg, (Near Old Secretariat), Delhi –
110002 R. P. Singh Director General Dated 10-5-2010 Sub: Audit of Telecom Service
Providers by C&AG-Reg.
Ref: 1) DoT letter No. 842-1086/2010/AS-IV dt. 16.03.2010
2) Your office letter No. TTSL/DoT/ Audit/2010 dt. 1.04.2010 Dear Sh. Dalal Kindly
refer to your office letter cited on the above subject extending cooperation in conduct
of the audit of revenue share by C&AG. Certain difficulty has been expressed by your
Company in providing the books of accounts in physical form as they are being
maintained in electronic form in SAP ERP System. Further, it has been stated that
the audit could be carried out by access to your systems at Noida Office. In this
connection, it is requested that on 21st May 2010 a presentation may be givenAsso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

covering your business activities, accounting policies, accounting, billing and
financial systems and all other issues relating to revenue shares, followed by brief
interface meeting with my Audit term which would start the process of audit.
The time and venue of the presentation is given in Annexure-I. Shri Subu R. Director (Report) of my
office has been nominated as Nodal Officer who would be overseeing and coordinating the audit.
Regards Yours sincerely, Sd/-
R. P. Singh”
66. Both the communications dated 16.3.2010 and 10.5.2010, referred to above, clearly indicate that
CAG intends to conduct the Audit, since there is “revenue sharing” between the Union of India and
the UAS licence holders and the revenue generated will have to be credited to the Consolidated Fund
of India.
67. The Tribunal, in our view, has committed a fundamental error in taking the view that the above
mentioned communications were issued by the DoT in exercise of the powers conferred under
Clauses 22.3 to 22.6, in fact, the communications specifically refer to only Clause 22.3, and not to
any other clauses. On the other hand, the Tribunal made specific reference to Clause 22.5 which, in
our view, is inapplicable in a case where the audit is sought to be conducted by CAG. The Tribunal
has also not properly appreciated the scope of clauses 20.4, 22.5 and 22.6. There are three stages of
audit. First, audit is to be conducted by the Licencee under Clause 20.4 through an auditor
appointed under Section 224 of the Companies Act. Clause 22.5 empowers the licensor to conduct
an audit, if it is found that statements or accounts submitted are inaccurate and misleading. In our
view, the opinion to be formed is purely subjective, it need not establish to the satisfaction of the
licencee that the statements or accounts are inaccurate and misleading. Further, Clause 22.6 is an
independent Clause which has no relationship with Clause 22.5. This is an additional power
conferred on the Licensor to conduct special audit. In other words, audit conducted by the licensor
or the licencee, has nothing to do with the audit conducted by CAG. If the reasoning of the Tribunal
is accepted, then the DOT can always stall an Audit sought to be conducted not only by CAG in
exercise of powers conferred under Article 149 of the Constitution read with the 1971 Act and TRAI
Rules 2002, but also an audit under clause 22.5 as well as special audit under clause 22.6.
Consequently, an audit to be conducted by CAG would not depend upon the “formation of opinion”
by the DoT that the statements or accounts submitted to it were inaccurate or misleading, which, in
our view, would deprive the statutory and constitutional powers conferred on the CAG to conduct
the audit or enquiry or inspection. Tribunal’s order, in our view, is an encroachment upon the
constitutional and statutory power conferred on CAG under Articles 148, 149 of the Constitution as
well as Section 16 of the 1971 Act read with Rule 5 of the TRAI Rules 2002 and the licensing
provisions.
68. We may, in this connection, refer to Clauses 22.5 and 22.6 for an easy reference:Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

“22.5 The LICENSOR may, on forming an opinion that the statements or accounts
submitted are inaccurate or misleading, order Audit of the accounts of the LICENSEE
by appointing auditor at the cost of the LICENSEE and such auditor(s) shall have the
same powers which the statutory auditors of the company enjoy under Section 227 of
the Companies Act, 1956. The remuneration of the Auditors, as fixed by the
LICENSOR, shall be borne by the LICENSEE.
22.6 The LICENSOR may also get conducted a ‘Special Audit’ of the LICENSEE
company’s accounts/records by “Special Auditors”, the payment for which at a rate as
fixed by the LICENSOR, shall be borne by the LICENSEE. This will be in the nature
of auditing the audit described in para 22.5 above. The Special Auditors shall also be
provided the same facility and have the same powers as of the companies’ auditors as
envisaged in the Companies Act, 1956.”
69. Clauses 22.5 and 22.6 are not meant for an audit to be conducted by CAG or TRAI, but meant for
an audit by the DoT. The Tribunal also committed an error in holding that the “formation of
opinion” under clause 22.5, that the statements or accounts submitted by the Licensee are
inaccurate or misleading, is jurisdictional fact, referring to the jurisdiction of DoT/CAG to conduct
audit under clause 22.5 or a special audit under clause 22.6. ‘Formation of opinion’ under clause
22.5 is a subjective opinion of Licensor or else the power to conduct any form of audit under clause
22.5 and 22.6 would be lost and Licensor has to go on convincing the licensee that the statements or
accounts submitted by the Licensee are inaccurate and misleading.
70. We, therefore, find no merit in the appeals filed by the Service Providers and hence those
appeals are dismissed, as above. The appeals filed by the DoT and others are, however, allowed,
setting aside the judgment of the Tribunal. In the facts and circumstances of the case, there will be
no order as to costs.
……..……………………J. (K.S. Radhakrishnan) ……..……………………J. (Vikramajit Sen) New Delhi, April
17, 2014.Asso.Of Unified Tele.Serv.Prov.& Ors vs Union Of India & Ors on 17 April, 2014

