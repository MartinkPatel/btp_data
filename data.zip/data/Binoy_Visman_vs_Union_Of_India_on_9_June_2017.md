Binoy Visman vs Union Of India on 9 June, 2017
Author: A.K. Sikri
Bench: A.K. Sikri
                                                                                     REPORTABLE
                                               IN THE SUPREME COURT OF INDIA
                                                   CIVIL ORIGINAL JURISDICTION
                                            WRIT PETITION (CIVIL) NO. 247 OF 2017
                         BINOY VISWAM                                              .....PETITIONER(S)
                                                                         VERSUS
                         UNION OF INDIA & ORS.                                    .....RESPONDENT(S)
                                                                        WITH
                                            WRIT PETITION (CIVIL) NO. 277 OF 2017
                                                                        AND
                                            WRIT PETITION (CIVIL) NO. 304 OF 2017
                                                           JUDGMENT
A.K. SIKRI, J.
In these three writ petitions filed by the petitioners, who claim themselves to be pubic spirited
persons, challenge is laid to the constitutional validity of Section 139AA of the Income Tax Act, 1961
(hereinafter referred to as the ‘Act’), which provision has been inserted by the amendment to the
said Act vide Finance Act, 2017. Section 139AA of the Act reads as under:
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 1 “Quoting of Aadhaar number. – (1)
Every person who is eligible to obtain Aadhaar number shall, on or after the 1st day of
July, 2017, quote Aadhaar number–
(i) in the application form for allotment of permanent account number;
(ii) in the return of income:Binoy Visman vs Union Of India on 9 June, 2017

Provided that where the person does not possess the Aadhaar Number, the
Enrolment ID of Aadhaar application form issued to him at the time of enrolment
shall be quoted in the application for permanent account number or, as the case may
be, in the return of income furnished by him.
(2) Every person who has been allotted permanent account number as on the 1st day
of July, 2017, and who is eligible to obtain Aadhaar number, shall intimate his
Aadhaar number to such authority in such form and manner as may be prescribed,
on or before a date to be notified by the Central Government in the Official Gazette:
Provided that in case of failure to intimate the Aadhaar number, the permanent
account number allotted to the person shall be deemed to be invalid and the other
provisions of this Act shall apply, as if the person had not applied for allotment of
permanent account number.
(3) The provisions of this section shall not apply to such person or class or classes of
persons or any State or part of any State, as may be notified by the Central
Government in this behalf, in the Official Gazette.
Explanation. – For the purposes of this section, the expressions –
(i) “Aadhaar number”, “Enrolment” and “resident” shall have the same meanings respectively
assigned to them in clauses (a),
(m) and (v) of section 2 of the Aadhaar (Targeted Delivery of Financial and other Subsidies, Benefits
and Services) Act, 2016 (18 of 2016);
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 2
(ii) “Enrolment ID” means a 28 digit Enrolment Identification Number issued to a resident at the
time of enrolment.”
2) Even a cursory look at the aforesaid provision makes it clear that in the application forms for
allotment of Permanent Account Number (for short, ‘PAN’) as well as in the income-tax returns, the
assessee is obliged to quote Aadhaar number. This is necessitated on any such applications for PAN
or return of income on or after July 01, 2017, which means from that date quoting of Aadhaar
number for the aforesaid purposes becomes essential. Proviso to sub-section (1) gives relaxation
from quoting Aadhaar number to those persons who do not possess Aadhaar number but have
already applied for issuance of Aadhaar card. In their cases, the Enrolment ID of Aadhaar
application form is to be quoted. It would mean that those who would not be possessing Aadhaar
card as on July 01, 2017 may have to necessarily apply for enrolment of Aadhaar before July 01,
2017.Binoy Visman vs Union Of India on 9 June, 2017

3) The effect of this provision, thus, is that every person who desires to obtain PAN card or who is an
assessee has to necessarily enrol for Aadhaar. It makes obtaining of Aadhaar card compulsory for
those persons who are income-tax assessees. Writ Petition (Civil) No. 247 of 2017 & Ors. Page 3
Proviso to sub-section (2) of Section 139AA of the Act stipulates the consequences of failure to
intimate the Aadhaar number. In those cases, PAN allotted to such persons would become invalid
not only from July 01, 2017, but from its inception as the deeming provision in this proviso
mentions that PAN would be invalid as if the person had not applied for allotment of PAN, i.e. from
the very beginning. Sub-section (3), however, gives discretion to the Central Government to exempt
such person or class or classes of persons or any State or part of any State from the requirement of
quoting Aadhaar number in the application form for PAN or in the return of income.
The challenge is to this compulsive nature of provision inasmuch as with the introduction of the
aforesaid provision, no discretion is left with the income-tax assessees insofar as enrolment under
the Aadhaar (Targeting Delivery of Financial and Other Subsidies, Benefits and Services) Act, 2016
(hereinafter referred to as the ‘Aadhaar Act’) is concerned. According to the petitioners, though
Aadhaar Act prescribes that enrolment under the said Act is voluntary and gives choice to a person
to enrol or not to enrol himself and obtain Aadhaar card, this compulsive element thrusted in
Section 139AA of the Act makes the said provision unconstitutional. The basis on which the
petitioners so Writ Petition (Civil) No. 247 of 2017 & Ors. Page 4 contend would be taken note of at
the appropriate stage.
Purpose of these introductory remarks was to highlight the issue involved in these writ petitions at
the threshold.
4) Before we take note of the arguments advanced by the petitioners and the rebuttal thereof by the
respondents, it would be in the fitness of things to take stock of historical facts pertaining to the
Aadhaar scheme and what Aadhaar enrolment amounts to.
Aadhaar Scheme and its administrative and statutory framework
5) Respondent No.1, Union of India, through the Planning Commission, issued Notification dated
January 28, 2009, constituting the Unique Identification Authority of India (for short, ‘UIDAI’) for
the purpose of implementing of Unique Identity (UID) scheme wherein a UID database was to be
collected from the residents of India. Pursuant to the said Notification, the Government of India
appointed Shri Nandan Nilekhani, an entrepreneur, as the Chairman of the UIDAI on July 02,
2009. According to this scheme, every citizen of India is entitled to enrol herself/himself with it and
get a unique, randomnly selected 12 digit number. For such enrolment, every person so intending
would have to provide his/her personal information along with Writ Petition (Civil) No. 247 of 2017
& Ors. Page 5 biometric details such a fingerprints and iris scan for future identification.
Accordingly, it is intended to create a centralized database under the UIDAI with all the above
information. The scheme was launched in September 2010 in the rural areas of Maharashtra and
thereafter extended all over India. One of the objects of the entire project was non-duplication and
elimination of fake identity cards.Binoy Visman vs Union Of India on 9 June, 2017

6) On December 03, 2010, the National Identification Authority of India Bill, 2010 was introduced
in the Rajya Sabha. On December 13, 2011, the Standing Committee Report was submitted to the
Parliament stating that both the Bill and project should be re-considered. The Parliamentary
Standing Committee on Finance rejected the Bill of 2010 as there was opposition to the passing of
the aforesaid Bill by the Parliament. Be that as it may, the said Bill of 2010 did not get through. The
result was that as on that date, Aadhaar Scheme was not having any statutory backing but was
launched and continued to operate in exercise of executive power of the Government. It may also be
mentioned that the Government appointed private enrollers and these private collection/enrolment
centres run by private parties continued to enrol the citizens under the UID scheme.
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 6
7) Writ Petition (Civil) No. 494 of 2012, under Article 32 of the Constitution of India, was preferred
by Justice K.S. Puttuswamy, a former Judge of the Karnataka High Court before this Court,
challenging the UID scheme stating therein that the same does not have any statutory basis and it
violated the ‘Right to Privacy’, which is a facet of Article 21 of the Constitution. This Court decided to
consider the plea raised in the said writ petition and issued notice. Vide order dated September 23,
2013, the Court also passed the following directions:
“In the meanwhile, no person should suffer for not getting the Aadhaar card in spite
of the fact that some authority had issued a circular making it mandatory and when
any person applies to get the Aadhaar Card voluntarily, it may be checked whether
that person is entitled for it under the law and it should not be given to any illegal
immigrant.” In the meanwhile, various writ petitions were filed by public spirited
citizens and organisations challenging the validity of the Aadhaar scheme and this
Court has tagged all those petitions along with Writ Petition (Civil) No. 494 of 2012.
8) In the meantime, in some proceedings before the Bombay High Court, the said
High Court passed orders requiring UIDAI to provide biometric information to CBI
for investigation purposes with respect to a criminal trial. This order was challenged
by Writ Petition (Civil) No. 247 of 2017 & Ors. Page 7 UIDAI by filing Special Leave
Petition (Criminal) No. 2524 of 2014, in which orders dated March 24, 2014 were
passed by this Court restraining the UIDAI from transferring any biometric
information to any agency without the written consent of the concerned individual.
The said order is in the following terms:
“In the meanwhile, the present petitioner is restrained from transferring any
biometric information of any person who has been allotted the Aadhaar number to
any other agency without his consent in writing.
More so, no person shall be deprived of any service for want of Aadhaar number in
case he/she is otherwise eligible/entitled. All the authorities are directed to modify
their forms/circulars/likes so as to not compulsorily require the Aadhaar number in
order to meet the requirement of the interim order passed by this Court forthwith.”Binoy Visman vs Union Of India on 9 June, 2017

9) Thereafter, the aforesaid writ petitions and special leave petitions were taken up
together. Matter was heard at length by a three Judges Bench of this Court and
detailed arguments were advanced by various counsel appearing for the petitioners as
well as the Attorney General for India who appeared on behalf of the Union of India.
As stated above, one of the main grounds of attack on Aadhaar Card scheme was that
the very collection of biometric data is violative of the ‘Right to Privacy’, which, in
turn, violated not only Article 21 of the Constitution of India but other Articles
embodying the fundamental rights guaranteed under Part Writ Petition (Civil) No.
247 of 2017 & Ors. Page 8 III of the Constitution. This argument was sought to be
rebutted by the respondents with the submission that in view of eight Judges’ Bench
judgment of this Court in M.P. Sharma & Ors. v.
Satish Chandra & Ors.1 and that of six Judges’ Bench in Kharak Singh v. State of U.P. & Ors.2, the
legal position regarding the existence of fundamental Right to Privacy is doubtful. At the same time,
it was also accepted that subsequently smaller Benches of two or three Judges of this Court had
given the judgments recognising the Right to Privacy as part of Article 21 of the Constitution. On
that basis, respondents submitted that the matters were required to be heard by a Larger Bench to
debate important questions like:
(i) Whether there is any Right to Privacy guaranteed under the Constitution; and
(ii) If such a Right exists, what is the source and what are the contours of such a Right
as there is no express provision in the Constitution adumbrating the Right to Privacy.
10) Though, this suggestion of the respondents were opposed by the counsel for the
petitioners, the said Bench still deemed it proper to refer the matter to the Larger
Bench and the reasons for taking this course of action are mentioned in paras 12 and
13 of the 1 AIR 1954 SC 300 2 AIR 1963 SC 1295 Writ Petition (Civil) No. 247 of 2017
& Ors. Page 9 order dated August 11, 2015 which reads as under:
“12. We are of the opinion that the cases on hand raise far reaching questions of
importance involving interpretation of the Constitution. What is at stake is the
amplitude of the fundamental rights including that precious and inalienable right
under Article 21. If the observations made in M.P. Sharma (supra) and Kharak Singh
(supra) are to be read literally and accepted as the law of this country, the
fundamental rights guaranteed under the Constitution of India and more particularly
right to liberty under Article 21 would be denuded of vigour and vitality. At the same
time, we are also of the opinion that the institutional integrity and judicial discipline
require that pronouncement made by larger Benches of this Court cannot be ignored
by the smaller Benches without appropriately explaining the reasons for not
following the pronouncements made by such larger Benches. With due respect to all
the learned Judges who rendered the subsequent judgments – where right to privacy
is asserted or referred to their Lordships concern for the liberty of human beings, we
are of the humble opinion that there appears to be certain amount of apparentBinoy Visman vs Union Of India on 9 June, 2017

unresolved contradiction in the law declared by this Court.
13. Therefore, in our opinion to give a quietus to the kind of controversy raised in this
batch of cases once for all, it is better that ratio decidendi of M.P. Sharma (supra) and
Kharak Singh (supra) is scrutinized and the jurisprudential correctness of the
subsequent decisions of this Court where the right to privacy is either asserted or
referred be examined and authoritatively decided by a Bench of appropriate strength.
(emphasis supplied)”
11) While referring the matter as aforesaid, by another order of the even date, the Bench expressed
that it would be desirable that the matter be heard at the earliest. On the same day, yet another
order was passed by the Bench in those petitions giving certain Writ Petition (Civil) No. 247 of 2017
& Ors. Page 10 interim directions which would prevail till the matter is finally decided by the Larger
Bench. We would like to reproduce this order containing the said interim arrangement in toto:
“I N T E R I M O R D E R After the matter was referred for decision by a larger Bench,
the learned counsel for the petitioners prayed for further interim orders. The last
interim order in force is the order of this Court dated 23.9.2013 which reads as
follows:-
“All the matters require to be heard finally. List all matters for final hearing after the
Constitution Bench is over.
In the meanwhile, no person should suffer for not getting the Aadhaar card inspite of
the fact that some authority had issued a circular making it mandatory and when any
person applies to get the Aadhaar card voluntarily, it may be checked whether that
person is entitled for it under the law and it should not be given to any illegal
immigrant.” It was submitted by Shri Shyam Divan, learned counsel for the
petitioners that the petitioners having pointed out a serious breach of privacy in their
submissions, preceding the reference, this Court may grant an injunction restraining
the authorities from proceeding further in the matter of obtaining biometrics etc. for
an Aadhaar card. Shri Shyam Divan submitted that the biometric information of an
individual can be circulated to other authorities or corporate bodies which, in turn
can be used by them for commercial exploitation and, therefore, must be stopped.
The learned Attorney General pointed out, on the other hand, that this Court has at
no point of time, even while making the interim order dated 23.9.2013 granted an
injunction restraining the Unique Identification Authority of India from going ahead
and obtaining biometric or other information from a citizen Writ Petition (Civil) No.
247 of 2017 & Ors. Page 11 for the purpose of a Unique Identification Number, better
known as “Aadhaar card”. It was further submitted that the respondents have gone
ahead with the project and have issued Aadhaar cards to about 90% of the
population. Also that a large amount of money has been spent by the UnionBinoy Visman vs Union Of India on 9 June, 2017

Government on this project for issuing Aadhaar cards and that in the circumstances,
none of the well-known consideration for grant of injunction are in favour of the
petitioners.
The learned Attorney General stated that the respondents do not share any personal
information of an Aadhaar card holder through biometrics or otherwise with any
other person or authority. This statement allays the apprehension for now, that there
is a widespread breach of privacy of those to whom an Aadhaar card has been issued.
It was further contended on behalf of the petitioners that there still is breach of
privacy. This is a matter which need not be gone into further at this stage.
The learned Attorney General has further submitted that the Aadhaar card is of great
benefit since it ensures an effective implementation of several social benefit schemes
of the Government like MGNREGA, the distribution of food, ration and kerosene
through PDS system and grant of subsidies in the distribution of LPG. It was,
therefore, submitted that restraining the respondents from issuing further Aadhaar
cards or fully utilising the existing Aadhaar cards for the social schemes of the
Government should be allowed.
The learned Attorney General further stated that the respondent Union of India
would ensure that Aadhaar cards would only be issued on a consensual basis after
informing the public at large about the fact that the preparation of Aadhaar card
involving the parting of biometric information of the individual, which shall however
not be used for any purpose other than a social benefit schemes.
Having considered the matter, we are of the view that the balance of interest would
be best served, till the matter is finally decided by a larger Bench if the Union of India
or the UIDA proceed in the following manner:-
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 12
1. The Union of India shall give wide publicity in the electronic and print media
including radio and television networks that it is not mandatory for a citizen to obtain
an Aadhaar card;
2. The production of an Aadhaar card will not be condition for obtaining any benefits
otherwise due to a citizen;
3. The Unique Identification Number or the Aadhaar card will not be used by the
respondents for any purpose other than the PDS Scheme and in particular for the
purpose of distribution of foodgrains, etc. and cooking fuel, such as kerosene. The
Aadhaar card may also be used for the purpose of the LPG Distribution Scheme;Binoy Visman vs Union Of India on 9 June, 2017

4. The information about an individual obtained by the Unique Identification
Authority of India while issuing an Aadhaar card shall not be used for any other
purpose, save as above, except as may be directed by a Court for the purpose of
criminal investigation.
Ordered accordingly.”
12) In nutshell, the direction is that obtaining an Aadhaar Card is not mandatory and the benefits
due to a citizen under any scheme are not to be denied in the absence of Aadhaar Card. Further,
unique identification number or the Aadhaar Card was to be used only for the PDS Scheme and, in
particular, for the purpose of distribution of food grains etc. and cooking fuels such as Kerosene and
LPG Distribution Scheme, with clear mandate that it will not be used by the respondents for any
other purpose. Even the information about the individual collected while issuing Writ Petition
(Civil) No. 247 of 2017 & Ors. Page 13 an Aadhaar Card was not to be used for any other purpose,
except when it is directed by the Court for the purpose of criminal investigation. Thus, making of
Aadhaar Card was not to be made mandatory and it was to be used only for PDS Scheme and LPG
Distribution Scheme. Thereafter, certain applications for modification of the aforesaid order dated
August 11, 2015 was filed before this Court by the Union of India and a five Judges Bench of this
Court was pleased to pass the following order:
“3. After hearing the learned Attorney General for India and other learned senior
counsels, we are of the view that in paragraph 3 of the Order dated August 11, 2015, if
we add, apart from the other two Schemes, namely, PDS Scheme and the LPG
Distribution Scheme, the Schemes like The Mahatma Gandhi National Rural
Employment Guarantee Scheme 12 (MGNREGS), National Social Assistance
Programme (Old Age Pensions, Widow Pensions, Disability Pensions) Prime
Minister’s Jan Dhan Yojana (PMJDY) and Employees’ Provident Fund Organisation
(EPFO) for the present, it would not dilute earlier order passed by this Court.
Therefore, we now include the aforesaid Schemes apart from the other two Schemes
that this Court has permitted in its earlier order dated August 11, 2015.
4. We impress upon the Union of India that it shall strictly follow all the earlier
orders passed by this Court commencing from September 23, 2013.
5. We will also make it clear that the Aadhaar card Scheme is purely voluntary and it
cannot be made mandatory till the matter is finally decided by this Court one way or
the other.” Thus, Aadhaar is permitted for some more schemes as well.
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 14
13) The petitioner herein, laying stress on the above orders, plead that from a perusal of the various
interim orders passed by this Court it is amply clear that the Court has reiterated the position that
although there is no interim order against the collection of information from the citizens for the
purpose of enrolment for Aadhaar, the scheme is purely voluntary and the same is not to be madeBinoy Visman vs Union Of India on 9 June, 2017

mandatory by the Government.
14) While matters stood thus, the Government of India brought in a legislation to govern the
Aadhaar Scheme with the enactment of the Aadhaar (Targeted Delivery of Financial and other
subsidies, benefits and services) Act, 2016 (hereinafter referred to as the ‘Aadhaar Act’).
15) Introduction to the said Act gives the reasons for passing that Act and Statement of Objects and
Reasons mention the objectives sought to be achieved with the enactment of Aadhaar Act.
Introduction reads as under:
“The Unique Identification Authority of India was established by a resolution of the
Government of India in 2009. It was meant primarily to lay down policies and to
implement the Unique Identification Scheme, by which residents of India were to be
provided unique identity number. This number would serve as proof of identity and
could be used for identification of beneficiaries for transfer of benefits, subsidies,
services and other purposes.
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 15 Later on, it was felt that the
process of enrolment, authentication, security, confidentiality and use of Aadhaar
related information be made statutory so as to facilitate the use of Aadhaar number
for delivery of various benefits, subsidies and services, the expenditures of which
were incurred from or receipts therefrom formed part of the Consolidated Fund of
India.
The Aadhaar (Targeted Delivery of Financial and Other Subsidies, Benefits and
Services) Bill, 2016 inter alia, provides for establishment of Unique Identification
Authority of India, issuance of Aadhaar number to individuals, maintenance and
updating of information in the Central Identities Data Repository, issues pertaining
to security, privacy and confidentiality of information as well as offences and
penalties for contravention of relevant statutory provisions.”
16) In the Statement of Objects and Reasons, it is inter alia mentioned that though
number of social benefits schemes have been floated by the Government, the failure
to establish identity of an individual has proved to be a major hindrance for
successful implementation of those programmes as it was becoming difficult to
ensure that subsidies, benefits and services reach the unintended beneficiaries in the
absence of a credible system to authenticate identity of beneficiaries. Statement of
Objects and Reasons also discloses that over a period of time, the use of Aadhaar
Number has been increased manifold and, therefore, it is also necessary to take
measures relating to ensuring security of the information provided by the individuals
while enrolling for Aadhaar Card. Having these parameters in mind, para 5 of the
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 16 Statement of Objects and
Reasons enumerates the objectives which Aadhaar Act seeks to achieve. It reads as
under:Binoy Visman vs Union Of India on 9 June, 2017

““5. The Aadhaar (Targeted Delivery of Financial and Other Subsidies, Benefits and
Services) Bill, 2016 inter alia, seeks to provide for –
(a) issue of Aadhaar numbers to individuals on providing his demographic and
biometric information to the Unique Identification Authority of India;
(b) requiring Aadhaar numbers for identifying an individual for delivery of benefits,
subsidies, and services the expenditure is incurred from or the receipt therefrom
forms part of the Consolidated Fund of India;
(c) authentication of the Aadhaar number of an Aadhaar number holder in relation to
his demographic and biometric information;
(d) establishment of the Unique Identification Authority of India consisting of a
Chairperson, two Members and a Member-Secretary to perform functions in
pursuance of the objectives above;
(e) maintenance and updating the information of individuals in the Central Identities
Date Repository in such manner as may be specified by regulations;
(f) measures pertaining to security, privacy and confidentiality of information in
possession or control of the Authority including information stored in the Central
Identities Date Repository;
and
(g) offences and penalties for contravention of relevant statutory provisions.”
17) Some of the provisions of this Act, which have bearing on the Writ Petition (Civil) No. 247 of
2017 & Ors. Page 17 matter that is being dealt with herein, may be taken note of.
Sections 2(a), 2(c), 2(d), 2(e), 2(g), 2(h), 2(k), 2(l), 2(m), 2(n), Section 3, Section 7, Section 28,
Section 29 and Section 30 reads as under:
“2(a) "Aadhaar number" means an identification number issued to an individual
under sub-section (3) of section 3;
xxx xxx xxx 2(c) "authentication" means the process by which the Aadhaar number
alongwith demographic information or biometric information of an individual is
submitted to the Central Identities Data Repository for its verification and such
Repository verifies the correctness, or the lack thereof, on the basis of information
available with it;Binoy Visman vs Union Of India on 9 June, 2017

2(d) "authentication record" means the record of the time of authentication and
identity of the requesting entity and the response provided by the Authority thereto;
2(e) "Authority" means the Unique Identification Authority of India established
under sub-section (1) of section 11;
xxx xxx xxx 2(g) "biometric information" means photograph, finger print, Iris scan,
or such other biological attributes of an individual as may be specified by regulations;
2(h) "Central Identities Data Repository" means a centralised database in one or
more locations containing all Aadhaar numbers issued to Aadhaar number holders
along with the corresponding demographic information and biometric information of
such individuals and other information related thereto;
                                   xxx         xxx         xxx
Writ Petition (Civil) No. 247 of 2017 & Ors.                                  Page 18
2(k) "demographic information" includes information relating to the name, date of
birth, address and other relevant information of an individual, as may be specified by
regulations for the purpose of issuing an Aadhaar number, but shall not include race,
religion, caste, tribe, ethnicity, language, records of entitlement, income or medical
history;
2(l) "enrolling agency" means an agency appointed by the Authority or a Registrar, as
the case may be, for collecting demographic and biometric information of individuals
under this Act;
2(m) "enrolment" means the process, as may be specified by regulations, to collect
demographic and biometric information from individuals by the enrolling agencies
for the purpose of issuing Aadhaar numbers to such individuals under this Act;
2(n) "identity information" in respect of an individual, includes his Aadhaar number,
his biometric information and his demographic information;
3. Aadhaar number. - (1) Every resident shall be entitled to obtain an Aadhaar
number by submitting his demographic information and biometric information by
undergoing the process of enrolment:
Provided that the Central Government may, from time to time, notify such other
category of individuals who may be entitled to obtain an Aadhaar number.Binoy Visman vs Union Of India on 9 June, 2017

(2) The enrolling agency shall, at the time of enrolment, inform the individual
undergoing enrolment of the following details in such manner as may be specified by
regulations, namely:
(a) the manner in which the information shall be used;
(b) the nature of recipients with whom the information is intended to be shared
during authentication; and
(c) the existence of a right to access information, the procedure for making requests
for such Writ Petition (Civil) No. 247 of 2017 & Ors. Page 19 access, and details of the
person or department in-charge to whom such requests can be made.
(3) On receipt of the demographic information and biometric information under
sub-section (1), the Authority shall, after verifying the information, in such manner as
may be specified by regulations, issue an Aadhaar number to such individual.
xxx xxx xxx
7. Proof of Aadhaar number necessary for receipt of certain subseidies, benefits and
services, etc. -
The Central Government or, as the case may be, the State Government may, for the purpose of
establishing identity of an individual as a condition for receipt of a subsidy, benefit or service for
which the expenditure is incurred from, or the receipt therefrom forms part of, the Consolidated
Fund of India, require that such individual undergo authentication, or furnish proof of possession of
Aadhaar number or in the case of an individual to whom no Aadhaar number has been assigned,
such individual makes an application for enrolment:
Provided that if an Aadhaar number is not assigned to an individual, the individual
shall be offered alternate and viable means of identification for delivery of the
subsidy, benefit or service.
xxx xxx xxx
28. Security and confidentiality of information - (1) The Authority shall ensure the
security of identity information and authentication records of individuals.
(2) Subject to the provisions of this Act, the Authority shall ensure confidentiality of identity
information and authentication records of individuals.
(3) The Authority shall take all necessary measures to ensure that the information in the possession
or control of the Authority, including information stored in the Central Identities Data Repository, is
secured and protected against access, use or disclosure not permitted under this Act or regulationsBinoy Visman vs Union Of India on 9 June, 2017

made Writ Petition (Civil) No. 247 of 2017 & Ors. Page 20 thereunder, and against accidental or
intentional destruction, loss or damage.
(4) Without prejudice to sub-sections (1) and (2), the Authority shall—
(a) adopt and implement appropriate technical and organisational security measures;
(b) ensure that the agencies, consultants, advisors or other persons appointed or engaged for
performing any function of the Authority under this Act, have in place appropriate technical and
organisational security measures for the information; and
(c) ensure that the agreements or arrangements entered into with such agencies, consultants,
advisors or other persons, impose obligations equivalent to those imposed on the Authority under
this Act, and require such agencies, consultants, advisors and other persons to act only on
instructions from the Authority.
(5) Notwithstanding anything contained in any other law for the time being in force, and save as
otherwise provided in this Act, the Authority or any of its officers or other employees or any agency
that maintains the Central Identities Data Repository shall not, whether during his service or
thereafter, reveal any information stored in the Central Identities Data Repository or authentication
record to anyone:
Provided that an Aadhaar number holder may request the Authority to provide access
to his identity information excluding his core biometric information in such manner
as may be specified by regulations.
29. Restriction on sharing information. - (1) No core biometric information, collected
or created under this Act, shall be—
(a) shared with anyone for any reason whatsoever; or
(b) used for any purpose other than generation Writ Petition (Civil) No. 247 of 2017 &
Ors. Page 21 of Aadhaar numbers and authentication under this Act.
(2) The identity information, other than core biometric information, collected or created under this
Act may be shared only in accordance with the provisions of this Act and in such manner as may be
specified by regulations.
(3) No identity information available with a requesting entity shall be—
(a) used for any purpose, other than that specified to the individual at the time of submitting any
identity information for authentication; orBinoy Visman vs Union Of India on 9 June, 2017

(b) disclosed further, except with the prior consent of the individual to whom such information
relates. (4) No Aadhaar number or core biometric information collected or created under this Act in
respect of an Aadhaar number holder shall be published, displayed or posted publicly, except for the
purposes as may be specified by regulations.
30. Biometric information deemed to be sensitive personal information.-The biometric information
collected and stored in electronic form, in accordance with this Act and regulations made
thereunder, shall be deemed to be "electronic record" and "sensitive personal data or information",
and the provisions contained in the Information Technology Act, 2000 (21 of 2000) and the rules
made thereunder shall apply to such information, in addition to, and to the extent not in derogation
of the provisions of this Act.
Explanation.-- For the purposes of this section, the expressions—
(a) "electronic form" shall have the same meaning as assigned to it in clause (r) of sub-section (1) of
section 2 of the Information Technology Act, 2000 (21 of 2000);
(b) "electronic record" shall have the same meaning as assigned to it in clause (t) of sub-section (1)
of section 2 of the Information Technology Act, 2000 (21 of 2000);
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 22 "sensitive personal data or information" shall
have the same meaning as assigned to it in clause (iii) of the Explanation to section 43A of the
Information Technology Act, 2000 (21 of 2000).” That apart, Chapter VII which comprises Sections
34 to 47, mentions various offences and prescribes penalties therefor.
18) Even the Constitutional validity of the aforesaid Act is challenged in this Court in Writ Petition
(C) No. 797 of 2016, which has also been tagged along with Writ Petition (C) No. 494 of 2012, the
lead matter in the batch of matters which has been referred to the Constitution Bench.
19) At this juncture, by Finance Act, 2017, Income Tax Act is amended with introduction of Section
139AA which provision has already been reproduced. It would be necessary to mention at this stage
that since challenge to the very concept of Aadhaar i.e. unique identification number is predicated
primarily on Right to Privacy, when instant writ petitions were initially listed before us, we
suggested that these matters be also tagged along with Writ Petition (C) No. 494 of 2012 and other
matters which have been referred to the Constitution Bench. Pertinently, in the counter affidavit
filed on behalf of the Union of India also, plea has been taken that the matters be tagged along with
those pending writ Writ Petition (Civil) No. 247 of 2017 & Ors. Page 23 petitions and be decided by a
larger Bench. On this suggestion, reaction of the learned counsel for the petitioners was that
petitioners would not be pitching their case on the ‘Right to Privacy’ and would be questioning the
validity of Section 139AA of the Act primarily on Articles 14 and 19 of the Constitution. On this basis,
their submission was that this Bench should proceed to adjudicate the matter. Therefore, we make it
clear at the outset that we are not touching upon the privacy issue while determining the question of
validity of the impugned provision of the Act. The ArgumentsBinoy Visman vs Union Of India on 9 June, 2017

20) Mr. Datar, learned senior counsel who opened the attack on behalf of the petitioners, started by
stating the historical fact pertaining to introduction of Aadhaar Scheme, leading to the passing of
Aadhaar Act and thereafter the impugned provision and referring to the various orders passed by
this Court from time to time (which have already been reproduced above). After this narration, his
first submission was that this Court had, time and again, emphasised by various interim orders that
obtaining an Aadhaar Card would be a voluntarily act on behalf of a citizen and it would not be
made mandatory till the pendency of the petitions which stand referred to the Constitution Bench
now. He further Writ Petition (Civil) No. 247 of 2017 & Ors. Page 24 submitted that even Section 3
of the Aadhaar Act spells out that enrollment of Aadhaar is voluntarily and consensual and not
compulsory or by way of executive action. He also drew our attention to the proviso to Section 7 of
the Aadhaar Act as per which a person is not to be deprived of subsidies as per the various schemes
of the Government as the said proviso clearly mentions that if an Aadhaar Number is not assigned to
an individual, he shall be offered alternate and viable means of identification for delivery of subsidy,
benefit or service. According to him, there was a total reversal of the aforesaid approach for
assessees under the Income Tax Act and those who wanted to apply for issuance of PAN Card
inasmuch as not only it was made compulsory for them to get Aadhaar enrollment number, but
serious consequences were also provided for not adhering to this requirement. In their cases, PAN
issued to these assessees had to become invalid, that too from the retrospective effect i.e. from the
date when it is issued. Having regard to the aforesaid, the legal submission of Mr. Datar was that
Section 139AA was unconstitutional and without legislative competence inasmuch as this provision
was enacted contrary to the binding nature of the judgments/directions of this Court which was
categorical that Aadhaar had to remain voluntary. Questioning the legislative Writ Petition (Civil)
No. 247 of 2017 & Ors. Page 25 competence of the legislature to enact this particular law, argument
of Mr. Datar was that there were certain implied limitations of such a legislative competence and
one of these limitations was that legislature was debarred from enacting a law contrary to the
binding nature of decisions of this Court. His submission in this behalf was that though it was within
the competence of the legislature to remove the basis of the Supreme Court decision, at the same
time, legislature could not go against the decision which was law of the land under Article 141 of the
Constitution. He argued that, in the instant case, legislature could not be construed as removing the
basis of the various orders of this Court relating to Aadhaar Scheme itself but the impugned
provision was inserted in the statute book violating the binding nature of those orders.
21) Dilating on the aforesaid submissions, Mr. Datar argued that the earlier orders of this Court
dated August 23, 2015 of the main writ petition specifically permitted Aadhaar to be used only for
LPG and PDS. By an order dated October 15, 2015, at the request of the Union of India, it was
permitted to be extended to three other schemes, namely, MNREGA, Jan Dhan Yojana etc. The
Constitution Bench made it explicitly clear that the Aadhaar Writ Petition (Civil) No. 247 of 2017 &
Ors. Page 26 scheme could not be used for any other purpose. According to him, the Parliament did
not in any manner remove the basis of these decisions. The Aadhaar scheme, as enacted under the
Aadhaar Act, continued to retain its voluntary character (as demonstrated by Section 3 of that Act)
that existed when Aadhaar was operating under executive instructions. Nonetheless, even if it is
argued that the above orders were passed when Aadhaar was based on executive instructions,
decisions of this Court continue to be binding as they are made in exercise of the judicial power.
According to Mr. Datar, any judgment of a court, whether interim or final, whether rendered in theBinoy Visman vs Union Of India on 9 June, 2017

context of a legislation, delegated legislation (rules/notifications) or even executive action will
continue to be binding. In view of the judgment of this Court in Ram Jawaya Kapoor v. State of
Punjab3, which held that executive and legislative powers are co-extensive under the Constitutional
scheme, unless the basis of the judgment is removed by a subsequent enactment, it cannot be
argued that a decision based on executive instruction is less binding than other judgments/orders of
the Supreme Court, or that the judgment/order loses force if the executive instruction is replaced by
law.
3 (1955) 2 SCR 225 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 27
22) He also referred to the decision in the case of Madan Mohan Pathak v. Union of India4, wherein
the direction of the Calcutta High Court to pay bonus to Class-III and Class-IV employees was
sought to be nullified by a statutory amendment. This was held to be impermissible by the seven
Judges’ Bench. He also relied upon Bakhtawar Trust v. M.D. Narayan5, wherein, after citing the
case-laws on this point, the Court reiterated the principle as follows:
““25. The decisions referred to above, manifestly show that it is open to the
legislature to alter the law retrospectively, provided the alteration is made in such a
manner that it would no more be possible for the Court to arrive at the same verdict.
In other words, the very premise of the earlier judgment should be uprooted, thereby
resulting in a fundamental change of the circumstances upon which it was founded.
xxx xxx xxx
27. Here, the question before us is, whether the impugned Act has passed the test of
constitutionality by serving to remove the very basis upon which the decision of the
High Court in the writ petition was based. This question gives rise to further two
questions – first, what was the basis of the earlier decision; and second, what, if any,
may be said to be the removal of that basis?
(emphasis supplied)”
23) Based on the above principles, Mr. Datar’s fervent plea was that:
(i) The basis of the earlier order of the Supreme Court is that Aadhaar will be made a
voluntary scheme, it is a
4 AIR 1978 SC 803 5 (2003) 5 SCC 298 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 28
consensual scheme, and that it is to be expressly limited to six specific purposes; and
(ii) No attempt whatsoever has been made to remove the basis of these earlier orders. This alone
renders Section 139AA unconstitutional.Binoy Visman vs Union Of India on 9 June, 2017

24) Arguing that basis of the orders of this Court was not removed, plea of Mr. Datar was that the
basis of the said orders was that serious constitutional concerns had been raised about the Aadhaar
scheme, and that therefore, pending final decision on its validity by the Supreme Court, it ought to
remain voluntary. Consequently, in order to remove the basis of these orders, the Parliament would
have to pass a law overturning the voluntary character of Aadhaar itself. Notably, although
Parliament did have a chance to do so, it elected not to. The Aadhaar Act came into force on March
25, 2016. This was after the order of this Court. Significantly, however, the Parliament continued to
maintain Aadhaar as a voluntary scheme vide Section 3 of the said Act. Mr. Datar submitted that if
Parliament so desired, it could have removed the basis of this Court’s order by:
(i) Amending Section 3 so that Aadhaar is made compulsory for every resident of
India; or
(ii) Introducing either a proviso or adding a sub-section in Section 3 to the following
effect:
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 29 “Notwithstanding anything
contained in sub-section (1), the Central Government may notify specific purposes for
which obtaining Aadhaar numbers may be made mandatory in public interest.”
25) However, Parliament elected not to do so as there is no non-obstante clause.
Instead of making enrollment for Aadhaar itself mandatory, it made Aadhaar
mandatory for filing income-tax returns, even as enrollment itself remained
voluntary under Section 3 of the Aadhaar Act. He, thus, submitted that far from
taking away the basis of the earlier Supreme Court orders. The Aadhaar Act
strengthened and endorsed those orders, while Section 139AA impermissibly
attempted to overturn them without taking away their basis. Indeed, Parliament did
not even sof ar as include a non-obstante clause in Section 139AA, which would have
made it clear that Section would override contrary laws – clearly indicating once
again that Section 13AA was not taking away the basis of the Court’s orders. The
emphasis of Mr. Datar is that unless suitable/appropriate amendments are made to
the Aadhaar Act, the orders of the Court cannot be overruled by the newly inserted
Section 139AA.
26) On the aforesaid edifice, the argument built and developed by Mr. Datar is that
although the power of Parliament to pass laws with respect to List-I and List-III is
plenary, it is subject to two implied Writ Petition (Civil) No. 247 of 2017 & Ors. Page
30 limitations:
(i) Parliament or any State legislature cannot pass any law that overrules a judgment;
before any law is passed which may result in nullifying a decision, it is mandatory to
remove the basis of the decision. Once the basis on which the earlier
decision/order/judgment is delivered is removed, Parliament can then pass a law
prospectively or retrospectively and with or without a validation clause.Binoy Visman vs Union Of India on 9 June, 2017

(ii) Implied limitation not to pass contrary laws: The doctrine of harmonious
construction applies when there is an accidental collision or conflict between two
enactments and the Supreme Court has repeatedly read down one provision to give
effect to other. Thus, both the provisions have to be given effect to. But if the collision
or conflict is such that one provision cannot co-exist with another, then the latter
provision must be struck down. In the present case, obtaining an Aadhaar number
continues to be voluntary and explicitly declared to be so. Once the Aadhaar Card is
voluntary, it cannot be made mandatory by the impugned Section 139AA of the Act.
As long as the Aadhaar enactment holds the field, there is an implied limitation on
the power of Parliament not to pass a contrary law.
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 31
27) He also advanced two examples of such an implied limitation:
(i) If Parliament, by a statute, makes medical service in rural areas an attractive
option for doctors with incentives like preference for post-graduate admissions,
higher pay/allowances, or even lower tax, such a scheme is voluntary and only those
doctors who want those benefits may opt for it. While such a statute exists, it will not
be permissible for Parliament to simultaneously amend the Medical Council Act,
1956 and state that absence of rural service will be a ground to invalidate the doctor’s
certificate of practice. Thus, what is statutorily voluntary under one Parliamentary
Act cannot be made statutorily compulsory under another Parliamentary Act at the
same time.
(ii) Second example given by Mr. Datar was that making Aadhaar compulsory only
for individuals with severe consequences of cancellation of PAN cards and a deeming
provision that they had never applied for PAN is discriminatory when such a
provision is not made mandatory for other assessees.
28) Mr. Datar’s next plea of violation of Article 14 was based by him on the
application of the twin-test of classification viz. there Writ Petition (Civil) No. 247 of
2017 & Ors. Page 32 should be a reasonable classification and that this classification
should have rational nexus with the objective sought to be achieved as held in R.K.
Dalmia v. Justice S.R. Tendolkar6. Mr. Datar conceded that first test was met as
individual assessees form a separate class and, to this extent, there is a rational
differentiation between individuals and other categories of assessees. The main brunt
of his argument was on the second limb of the twin-test of classification which
according to him is not satisfied because there is no rational nexus with the object
sought to be achieved.
29) Third argument of Mr. Datar was that the affected persons by Section 139AA are
individuals who are professionals like lawyers, doctors, architects etc. and lakhs of
businessmen having small or micro enterprises. By imposing a draconian penalty ofBinoy Visman vs Union Of India on 9 June, 2017

cancelling their PAN cards and deeming that they had never applied for them, there
is a direct infringement to Article 19(1)(g). The consequences of not having a PAN
card results in a virtual “civil death” and it will be impossible to carry out any
business or professional activity under Rule 114B of the Income Tax Rules, 1962
(hereinafter referred to as the ‘Rules’), it will not be possible to operate bank accounts
with transactions above Rs.50,000/-,
6 (1959) SCR 279 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 33 use credit/debit cards,
purchase motor-vehicles, purchase property etc.
30) Elaborating this point, it was submitted by him that once it is shown that the right under Article
19(1)(g) has been infringed, the burden shifts to the State to show that the restriction is reasonable,
and in the interests of the public, under Article 19(6) of the Constitution. He referred to Modern
Dental College and Research Centre & Ors. v. State of Madhya Pradesh7, wherein this Court held
that the correct test to apply in the context of Article 19(6) was the test of proportionality:
“… a limitation of a constitutional right will be constitutionally permissible if : (i) it is
designated for a proper purpose; (ii) the measures undertaken to effectuate such a
limitation are rationally connected to the fulfilment of that purpose; (iii) the
measures undertaken are necessary in that there are no alternative measures that
may similarly achieve that same purpose with a lesser degree of limitation; and
finally (iv) there needs to be a proper relation (‘proportionality strict sensu’ or
‘balancing’) between the importance of achieving the proper purpose and the social
importance of preventing the limitation on the constitutional right.”
31) Mr. Datar also submitted that even if the State succeeds in showing a proper
purpose and a rational connection with the purpose, thereby meeting the test of
Article 14, the impugned law clearly fails on clauses (iii) (narrow tailoring) and (iv)
(balancing)
7 (2016) 7 SCC 353 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 34 of the proportionality test of
the above decision. He submitted that the State has failed entirely to show that the cancellation of
PAN Cards as a consequence of not enrolling for Aadhaar with its accompanying draconian
consequences for the economic life of an individual is narrowly tailored to achieving its goal of tax
compliance. It is also submitted that in accordance with the arguments advanced above, the State’s
own data shows that the problem of duplicate PANs was minuscule, and the gap between the tax
payer base and the PAN Card holding population can be explained by plausible factors other than
duplicates and forgeries. He questioned the wisdom of legislature in compelling 99.6% of the
taxpaying citizenry to enroll for Aadhaar (with the further prospect of seeding) in order to weed out
the 0.4% of duplicate PAN Cards, as it fails the proportionality test entirely.
32) On the principle of proportionality, he submitted that this principle was applied in the R.K.
Dalmia8 case as per the following passage:Binoy Visman vs Union Of India on 9 June, 2017

“11 …
(d) that the Legislature is free to recognize degrees of harm and may confine its
restrictions to those cases where the need is deemed to be the clearest;
(e) that in order to sustain the presumption of constitutionality the court may take
into consideration matters of common knowledge, matters of common
8 Footnote 6 above Writ Petition (Civil) No. 247 of 2017 & Ors. Page 35 report, the history of the
times and may assume every state of facts which can be conceived existing at the time of
legislation;…”
33) Basic premise of the submissions of Mr. Shyam Divan, learned senior advocate, was also the
same as projected by Mr. Datar. He insisted that Section 139AA of the Act, which had made Aadhaar
mandatory for income-tax assessees, is unconstitutional. However, in his endeavour to plead that
the provision be declared unconstitutional, he approached the subject from an altogether different
premise, giving another perception to the whole issue. His basic submission was that every
individual or citizen in this country had complete control over his/her body and State cannot insist
any person from giving his/her finger tips or iris of eyes, as a condition precedent to enjoy certain
rights. He pointed out that all the petitioners in his writ petition were holding PAN Cards and were
income-tax assessees but had not enrolled under Aadhaar Scheme. They were the consentions
persons in the society and did not want to give away their finger tips or iris, being consentions
objectors, that too, to private persons who were engaged as contractors/private enrollers by the
Government for undertaking the job of enrolment under the Aadhaar. It was submitted that the data
given to such persons were not safe and there was huge possibility that the same may Writ Petition
(Civil) No. 247 of 2017 & Ors. Page 36 be leaked. Further, requirement of giving Aadhaar number for
every transaction amounted to surveillance by the State and the entire profile of such persons would
be available to the State. He also pointed out that with today’s technology, there was every
possibility of copying the fingerprint and even the iris images. Various cases of fake Aadhaar Card
had come to light and even as per the Government’s statement, 3.48 lakh bogus Aadhaar Cards were
cancelled. There were instances of Aadhaar leak as well. Even hacking was possible. He conceded
that these were the issues within the realm of ‘Right to Privacy’ which were to be decided by the
Constitution Bench. However, according to him, various orders passed by this Court in those
petitions clearly reflect that the Court had given the directions that Aadhaar Scheme had to be
voluntarily; there would not be any illegal implants; and no one would suffer any consequences if he
does not enroll himself under the Aadhaar Scheme. He also submitted that even the Aadhaar Act
was voluntary in nature which creates rights for citizens and not obligations. According to him,
Aadhaar Act envisages free consent for getting certain benefits under social welfare schemes of the
Government. On the other hand, Section 139AA of the Act is compulsory and coercive. Pointing out
that if Aadhaar number is not mentioned in the income-tax Writ Petition (Civil) No. 247 of 2017 &
Ors. Page 37 returns, the effect provided under Section 139AA of the Act is that the PAN Card held
by such a person would itself become invalid and inoperative which will lead to various adverse
consequences inasmuch as for many other purposes as well, PAN Card is used. He referred to
Sections 206AA, 196J, 271F and 272B of the Act and Rule 114B of the Rules to demonstrate this. HeBinoy Visman vs Union Of India on 9 June, 2017

also referred to the provisions of Identification of Prisoners Act, 1920 which require a prisoner to
give his fingerprints for record and submitted that making Aadhaar compulsory amounted to
treating every person at par with a prisoner.
34) On the aforesaid premise, Mr. Divan articulated his legal submissions as under:
(i) Section 139AA of the Act is contrary to the concept of ‘limited Government’.
(ii) The impugned provision coerces the individuals to part with their private
information which was a part of human dignity and, thus, the said provision was
violative of Article 21 of the Constitution as it offended human dignity.
(iii) The impugned provision creates the involvement which can be used for
surveillance.
(iv) This provision converts right under Aadhaar Act to duty Writ Petition (Civil) No.
247 of 2017 & Ors. Page 38 under the Income Tax Act.
35) Elaborating on the argument predicated on the concept of ‘Limited Government’,
Mr. Divan submitted that the Constitution of India was the basic law or grundnorm
which ensures democratic governance in this country. Though a sovereign country,
its governance is controlled by the provisions of the Constitution which sets
parameters within which three wings of the State, namely, Legislature, Executive and
Judiciary has to function.
Thus, no wing of the State can breach the limitations provided in the Constitution which employs an
array of checks and balances to ensure open, accountable government where each wing of the State
performs its actions for the benefit of the people and within its sphere of responsibility. The checks
and balances are many and amongst them are the respective roles assigned by the Constitution to
the legislature, the executive and the judiciary. Under India’s federal structure, with a distribution of
legislative authority between the Union government and the States, the fields of legislation and
corresponding executive authority are also distributed between the Union and the States. Provisions
in the Constitution such as the fundamental rights chapter (Part III) and the chapter relating to
inter-state trade (Part XIII) also Writ Petition (Civil) No. 247 of 2017 & Ors. Page 39 circumscribe
the authority of the State. These limitations on the power of the State support the notion of ‘limited
government’. In this sense, the expression ‘limited government’ would mean that each wing of the
State is restricted by provisions of the Constitution and other laws and is required to operate within
its legitimate sphere. Exceeding these limits would render the action of the State ultra vires the
Constitution or a particular law.
He further argued that the concept of ‘limited government’ may also be understood in a much
broader and different sense. This notion of a limited government is qua the citizenry as a whole.
There are certain things that the State simply cannot do, because the action fundamentally alters the
relationship between the citizens and the State. The wholesale collection of biometric data includingBinoy Visman vs Union Of India on 9 June, 2017

finger prints and storing it at a central depository per se puts the State in an extremely dominant
position in relation to the individual citizen. Biometric data belongs to the concerned individual and
the State cannot collect or retain it to be used against the individual or to his or her prejudice in the
future. Further the State cannot put itself in a position where it can track an individual and engage
in surveillance. The State cannot deprive or withhold the enjoyment of rights and entitlements by an
individual or makes such entitlements conditional on a citizen Writ Petition (Civil) No. 247 of 2017
& Ors. Page 40 parting with her biometrics. Mr. Divan referred to the judgment of this Court in
State of Madhya Pradesh & Anr. v. Thakur Bharat Singh9 where the concept of limited government
is highlighted in the following manner:
“5. ...All executive action which operates to the prejudice of any person must have the
authority of law to support it, and the terms of Article 358 do not detract from that
rule. Article 358 expressly authorises the State to take legislative or executive action
provided such action was competent for the State to make or take, but for the
provisions contained in Part III of the Constitution. Article 358 does not purport to
invest the State with arbitrary authority to take action to the prejudice of citizens and
others: it merely provides that so long as the proclamation of emergency subsists
laws may be enacted, and exclusive action may be taken in pursuance of lawful
authority, which if the provisions of Article 19 were operative would have been
invalid. Our federal structure is founded on certain fundamental principles:
(1) the sovereignty of the people with limited Government authority i.e. the
Government must be conducted in accordance with the will of the majority of the
people. The people govern themselves through their representatives, whereas the
official agencies of the executive Government possess only such powers as have been
conferred upon them by the people; (2) There is a distribution of powers between the
three organs of the State — legislative, executive and judicial — each organ having
some check direct or indirect on the other; and (3) the rule of law which includes
judicial review of arbitrary executive action.
As pointed out by Dicey in his Introduction to the study of the Law of the Constitution, 10th Edn., at
p. 202, the expression “rule of law” has three meanings, or may be regarded from three different
points of view. “It means, in the first place, the absolute supremacy or predominance of regular law
as opposed to the influence of arbitrary power, and excludes the existence of arbitrariness, of
prerogative, or even of wide discretionary authority on the part of the 9 AIR 1967 SC 1170 : (1967) 2
SCR 454 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 41 Government”. At p. 188 Dicey points
out:
“In almost every continental community the executive exercises far wider
discretionary authority in the matter of arrest, of temporary imprisonment, of
expulsion from its territory, and the like, than is either legally claimed or in fact
exerted by the Government in England: and a study of European politics now and
again reminds English readers that wherever there is discretion there is room for
arbitrariness, and that in a republic no less than under a monarchy discretionaryBinoy Visman vs Union Of India on 9 June, 2017

authority on the part of the Government must mean insecurity for legal freedom on
the part of its subjects.” We have adopted under our Constitution not the continental
system but the British system under which the rule of law prevails. Every Act done by
the Government or by its officers must, if it is to operate to the prejudice of any
person must, be supported by some legislative authority.”
36) Relying on the aforesaid observations, Mr. Divan submitted that the recognition
of the distinction between an individual or person and the State is the single most
important factor that distinguishes a totalitarian State from one that respects
individuals and recognizes their special identity and entitlement to dignity. The
Indian Constitution does not establish a totalitarian State but creates a State that is
respectful of individual liberty and constitutionally guaranteed freedoms. The
Constitution of India is not a charter of servitude.
37) Proceeding further, another submission of Mr. Divan, as noted Writ Petition
(Civil) No. 247 of 2017 & Ors. Page 42 above, was that Section 139AA which coerces
the individuals to part with their personal information was unconstitutional. He
submitted that a citizen is entitled to enjoy all these rights including social and civil
rights such as the right to receive an education, a scholarship, medical assistance,
pensions and benefits under government schemes without having to part with his or
her personal biometrics. An individual’s biometrics such as finger prints and iris scan
are the property and entitlement of that individual and the State cannot coerce an
individual or direct him or her to part with biometrics as a condition for the exercise
of rights or the enjoyment of entitlements. Every citizen has a basic right to
informational self-determination and the state cannot exercise dominion over a
citizen’s proprietary information either in individual cases or collectively so as to
place itself in a position where it can aggregate information and create detailed
profiles of individuals or facilitate this process. The Constitution of India is not a
charter for a Police State which permits the State to maintain cradle to grave records
of the citizenry. No democratic country in the world has devised a system similar to
Aadhaar which operates like an electronic leash to tether every citizen from cradle to
grave. There can be no question of free consent in situations where an individual is
being coerced to part with its Writ Petition (Civil) No. 247 of 2017 & Ors. Page 43
biometric information (a) to be eligible for welfare schemes of the State; and/or (b)
under the threat of penal consequences. In other words, the State cannot compel a
person to part with biometrics as a condition precedent for discharge of the State’s
constitutional and statutory obligations. In support of his submission that there
cannot be coercive measures on the part of the Government to part with such
information and it has to be voluntary and based on informed consent, Mr. Divan
refered to the following judgments:
(i) National Legal Services Authority v. Union of India & Ors.10 “75. Article 21, as
already indicated, guarantees the protection of “personal autonomy” of an individual.Binoy Visman vs Union Of India on 9 June, 2017

In Anuj Garg v. Hotel Assn. of India [(2008) 3 SCC 1] (SCC p. 15, paras 34-35), this Court held that
personal autonomy includes both the negative right of not to be subject to interference by others and
the positive right of individuals to make decisions about their life, to express themselves and to
choose which activities to take part in. Self-determination of gender is an integral part of personal
autonomy and self-expression and falls within the realm of personal liberty guaranteed under
Article 21 of the Constitution of India.”
(ii) Sunil Batra & Anr. v. Delhi Administration & Ors.11 “55. And what is “life” in Article 21? In
Kharak Singh case [AIR 1963 SC 1295 : (1964) 1 SCR 332, 357] Subba Rao, J. quoted Field, J. in
Munn v. Illinois [94 US 113 (1877)] to emphasise the quality of life covered by Article 21:
10 (2014) 5 SCC 438 11 (1978) 4 SCC 494 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 44
“Something more than mere animal existence. The inhibition against its deprivation extends to all
those limbs and faculties by which life is enjoyed. The provision equally prohibits the mutilation of
the body by the amputation of an arm or leg, or the putting out of an eye or the destruction of any
other organ of the body through which the soul communicates with the outer world.” A dynamic
meaning must attach to life and liberty.”
(iii) Aruna Ramachandra Shanbaug v. Union of India & Ors.12 “25. Mr T.R. Andhyarujina, learned
Senior Counsel whom we had appointed as amicus curiae, in his erudite submissions explained to us
the law on the point. He submitted that in general in common law it is the right of every individual
to have the control of his own person free from all restraints or interferences of others. Every human
being of adult years and sound mind has a right to determine what shall be done with his own body.
In the case of medical treatment, for example, a surgeon who performs an operation without the
patient's consent commits assault or battery. It follows as a corollary that the patient possesses the
right not to consent i.e. to refuse treatment. (In the United States this right is reinforced by a
constitutional right of privacy). This is known as the principle of self-determination or informed
consent. Mr Andhyarujina submitted that the principle of self-determination applies when a patient
of sound mind requires that life support should be discontinued. The same principle applies where a
patient's consent has been expressed at an earlier date before he became unconscious or otherwise
incapable of communicating it as by a “living will” or by giving written authority to doctors in
anticipation of his incompetent situation.
                                       xxx       xxx          xxx
12     (2011) 4 SCC 454
Writ Petition (Civil) No. 247 of 2017 & Ors.                                Page 45
93. Rehnquist, C.J. noted that in law even touching of one person by another without consent and
without legal justification was a battery, and hence illegal. The notion of bodily integrity has been
embodied in the requirement that informed consent is generally required for medical treatment. As
observed by Cardozo, J. while on the Court of Appeals of New York:Binoy Visman vs Union Of India on 9 June, 2017

“Every human being of adult years and sound mind has a right to determine what
shall be done with his own body, and a surgeon who performs an operation without
his patient's consent commits an assault, for which he is liable in damages.” “Vide
Schloendorff v. Society of New York Hospital [211 NY 125 : 105 NE 92 (1914)] , NY at
pp. 129-30, NE at p. 93. Thus the informed consent doctrine has become firmly
entrenched in American Tort Law. The logical corollary of the doctrine of informed
consent is that the patient generally possesses the right not to consent, that is, to
refuse treatment.”
38) He, thus, submitted that the right to life covers and extends to a person’s right to
protect his or her body and identity from harm.
The right to life extends to allowing a person to preserve and protect his or her finger prints and iris
scan. The strongest and most secure manner of a person protecting this facet of his or her bodily
integrity and identity is to retain and not part with finger prints/iris scan. He argued that the right
to life under Article 21 permits every person to live life to the fullest and to enjoy freedoms
guaranteed as fundamental rights, constitutional rights, statutory rights and common law rights. He
also argued that the Writ Petition (Civil) No. 247 of 2017 & Ors. Page 46 constitutional validity of a
statutory provision must be judged by assessing the effect the impugned provision has on
fundamental rights. The effect of the impugned provision is to coerce persons into parting with their
finger prints and iris scan and lodging these personal and intimate aspects of an individual’s identity
with the State as part of a programme that is in the petitioner’s view wholly illegitimate and the
validity of which is pending before the Constitution Bench.
39) Expressing his grave fear and misuse of personal information parted with by the citizenry in the
form of biometrics i.e. finger prints and iris scan, Mr. Divan made a passionate plea that
requirement of enrollment for Aadhaar is designed to facilitate and encourage private sector
operators to create applications that depend upon the Aadhaar data base for the purposes of
authentication/verification. This would mean that non-governmental, private sector entities such as
banks, employers, any point of payment, taxi services, airlines, colleges, schools, movie theatres,
clubs, service providers, travel companies, etc. will all utilise the Aadhaar data base and may also
insist upon an Aadhaar number or Aadhaar authentication. This would mean that at every stage in
an individual’s daily activity his or her presence could be traced to a location in real Writ Petition
(Civil) No. 247 of 2017 & Ors. Page 47 time. One of the purposes of Aadhaar as projected by the
respondents is that it will be a single point verification for KYC (Know Your Customer). This is
permissible and indeed contemplated by the impugned Act. Given the very poor quality of scrutiny
of documents by private enrollers and enrollment agencies (without any governmental supervision)
means that the more rigorous KYC process at present being employed by banks and other financial
institutions will yield to a system which depends on a much weaker data base. This would eventually
imperil the integrity of the financial system and also threaten the economic sovereignty of the
nation. According to him, Aadhaar Act does not serve as an identity as incorrectly projected by the
respondents but serves as a method of identification. Every citizen-state and citizen-service provider
interaction requiring identification is sought to be captured and retained by the government at a
central base and a whole ecology developed that would require reference to this central data base onBinoy Visman vs Union Of India on 9 June, 2017

multiple occasions in course of the day. He argued that this exercise of enrollment impermissibly
creates the foundation for real time, continuous and pervasive identification of citizens in breach of
the freedoms guaranteed under the Constitution. Writ Petition (Civil) No. 247 of 2017 & Ors. Page
48
40) Another submission of Mr. Divan was that object behind Section 139AA of the Act was clearly
discriminatory inasmuch as it creates two classes: one class of those persons who volunteer to enrol
themselves under Aadhaar Scheme and provide the particulars in their income-tax returns and
second category of those who refuse to do so. This provision by laying down adverse consequences
for those who do not enrol becomes discriminatory qua that class and, therefore, is violative of
Article 14 of the Constitution. Another limb of his submission was that it also creates an artificial
class of those who object to such a provision of enrollment under Aadhaar. According to him, this
would be violative of equality clause enshrined in Article 14 of the Constitution and in support of
this submission, he relied upon the judgment of this Court in Nagpur Improvement Trust & Anr. v.
Vithal Rao & Ors.13. Paras 21, 22 and 26 reads as under:
“21. The first point which was raised was: whether it is the State which is the
acquiring authority or it is the Improvement Trust which is the acquiring authority,
under the Improvement Act. It seems to us that it is quite clear, especially in view of
Section 17-A as inserted by para 6 of the Schedule, that the acquisition will be by the
Government and it is only on payment of the cost of acquisition to the Government
that the lands vest in the Trust. It is true that the acquisition is for the Trust and may
be at its instance, but nevertheless the acquisition is by the Government.
22. If this is so, then it is quite clear that the 13 (1973) 1 SCC 500 Writ Petition (Civil)
No. 247 of 2017 & Ors. Page 49 Government can acquire for a housing
accommodation scheme either under the Land Acquisition Act or under the
Improvement Act. If this is so, it enables the State Government to discriminate
between one owner equally situated from another owner.
xxx xxx xxx
26. It is now well-settled that the State can make a reasonable classification for the
purpose of legislation.
It is equally well-settled that the classification in order to be reasonable must satisfy two tests: (i)
the classification must be founded on intelligible differentia and (ii) the differentia must have a
rational relation with the object sought to be achieved by the legislation in question. In this
connection it must be borne in mind that the object itself should be lawful. The object itself cannot
be discriminatory, for otherwise, for instance, if the object is to discriminate against one section of
the minority the discrimination cannot be justified on the ground that there is a reasonable
classification because it has rational relation to the object sought to be achieved.Binoy Visman vs Union Of India on 9 June, 2017

41) He also relied upon the judgment in the case of Subramanian Swamy v. Director, Central Bureau
of Investigation & Anr.14. Paras 58 and 59 reads as under:
“58. The Constitution permits the State to determine, by the process of classification,
what should be regarded as a class for purposes of legislation and in relation to law
enacted on a particular subject. There is bound to be some degree of inequality when
there is segregation of one class from the other. However, such segregation must be
rational and not artificial or evasive. In other words, the classification must not only
be based on some qualities or characteristics, which are to be found in all persons
grouped together and not in others who are left out but those qualities or
characteristics must have a reasonable relation to the object of the legislation.
Differentia which is the basis 14 (2014) 8 SCC 682 Writ Petition (Civil) No. 247 of
2017 & Ors. Page 50 of classification must be sound and must have reasonable
relation to the object of the legislation. If the object itself is discriminatory, then
explanation that classification is reasonable having rational relation to the object
sought to be achieved is immaterial.
59. It seems to us that classification which is made in Section 6-A on the basis of
status in government service is not permissible under Article 14 as it defeats the
purpose of finding prima facie truth into the allegations of graft, which amount to an
offence under the PC Act, 1988. Can there be sound differentiation between corrupt
public servants based on their status? Surely not, because irrespective of their status
or position, corrupt public servants are corrupters of public power. The corrupt
public servants, whether high or low, are birds of the same feather and must be
confronted with the process of investigation and inquiry equally. Based on the
position or status in service, no distinction can be made between public servants
against whom there are allegations amounting to an offence under the PC Act, 1988.”
42) In fine, submission of Mr. Divan was that save and except by “reading down”,
section 139AA is unworkable. This is because Aadhaar by its very design and by its
statute is “voluntary” and creates a right in favour of a resident without imposing any
duty.
There is no compulsion under the Aadhaar Act to enroll or obtain a number. If a person chooses not
to enroll, at the highest, in terms of the Aadhaar Act, he or she may be denied access to certain
benefits and services funded through the Consolidated Fund of India. When the Aadhaar enrollment
procedure is supposedly based on informed free consent and is voluntary a person cannot be
compelled by another law to waive free consent Writ Petition (Civil) No. 247 of 2017 & Ors. Page 51
so as to alter the voluntary nature of enrollment that is engrafted in the parent statute. The right of a
resident under the parent Act cannot be converted into a duty so long as the provisions of the
Aadhaar Act cannot be converted into a duty so long as the provisions of the Aadhaar Act remain as
they are. Argument was that Section 139AA be read down to hold that it is only voluntary provision
by taking out the sting of mandatoriness contained therein and there is no compulsion on any
person to give Aadhaar number.Binoy Visman vs Union Of India on 9 June, 2017

43) We may mention at this stage itself that on conclusion of his arguments, Mr. Divan was put a
specific query that most of the arguments presented by him endeavoured to project aesthetics of law
and jurisprudence which had the shades of ‘Right to Privacy’ jurisprudence which could not be gone
into by this Bench as this very aspect was already referred to the Constitution Bench. Mr. Divan was
candid in accepting this fact and his submission was that in these circumstances, the option for this
Bench was to stay the operation of proviso to sub-section (2) of Section 139AA of the Act till the
decision is rendered by the Constitution Bench.
44) Mr. Salman Khurshid, learned senior counsel who appeared in Writ Petition (Civil) No. 247 of
2017, while adopting the Writ Petition (Civil) No. 247 of 2017 & Ors. Page 52 arguments of Mr.
Datar and Mr. Divan, made an additional submission, invoking the principle of right to live with
dignity which, according to him, was somewhat different from the Right to Privacy. He submitted
that although dignity inevitably includes privacy, the former has several other dimensions which
need to be explored as well. In his submissions, the test to identify whether certain data collected
about individuals is intrusive or merely expansive is to consider whether it causes embarrassment,
indignity or invasion of privacy. Thus, the concept of dignity is quite distinct from that of privacy.
Privacy is a conditional concept. One has it only to the extent that one’s circumstances allow for it,
as a matter of fact and law. While it is widely accepted that a situation may occur where a person
may not have any Right to Privacy whatsoever, dignity is an inherent possession of every person,
regardless of circumstance. In that sense, Dignity is an inherent dimension of equality, the basis of
John Rawls ‘Theory of Justice’. The Social Contract theory propounded by Rousseau remains the
ground on which John Rawls developed the model of the Original Position in which the contours of
the compact are conceived. Anything that reduces the personality of the participant, such as diluting
the human element and substituting it with a number or biometric data, Writ Petition (Civil) No.
247 of 2017 & Ors. Page 53 virtually destroys the model. Dignity is an immutable value, held in equal
measure at all times by all people, a quality privacy does not share. No court has ever held that a
person can be stripped entirely of hir/her dignity. The concept of dignity is deeper than that of
privacy and its boundaries do not depend upon the circumstance of any individual and thus the
State cannot legitimately fully infringe upon it. He pointed out that in M. Nagaraj & Ors. v. Union of
India & Ors.15, this Court has, thus, elucidated the concept of Right to Dignity in the following
manner:
“20. ... This Court has in numerous cases deduced fundamental features which are
not specifically mentioned in Part III on the principle that certain unarticulated
rights are implicit in the enumerated guarantees.
xxx xxx xxx
26. It is the duty of the State not only to protect the human dignity but to facilitate it
by taking positive steps in that direction. No exact definition of human dignity exists.
It refers to the intrinsic value of every human being, which is to be respected. It
cannot be taken away. It cannot give (sic be given). It simply is.Binoy Visman vs Union Of India on 9 June, 2017

Every human being has dignity by virtue of his existence. The constitutional courts in Germany,
therefore, see human dignity as a fundamental principle within the system of the basic rights. This is
how the doctrine of basic structure stands evolved under the German Constitution and by
interpretation given to the concept by the constitutional courts.”
45) After explaining the aforesaid distinction between the two concepts, Mr. Khurshid argued that
the impugned provision in the 15 (2006) 8 SCC 212 Writ Petition (Civil) No. 247 of 2017 & Ors. Page
54 Income Tax Act was violative of right to live with dignity guaranteed under Article 21 of the
Constitution. He submitted that Right to Life and Liberty mentioned in Article 21 of the Constitution
encompasses within its right to live with dignity as has been held in catena of cases by this Court. He
explained in detail as to how the concept of dignity was dealt with by different jurists from time to
time including Kant who identified dignity with autonomy and Dworkin who exemplified the
doctrine of dignity on the conception of living well, which itself is based on two principles of dignity,
namely, self respect and authenticity. In this sense, he submitted that living with dignity involves
giving importance to living our life well and acting independently from the personal sense of
character and commitment to standards and ideals we stand for. The mandatory requirement of
Aadhaar card makes an unwarranted intrusion in the importance we give to our bodily integrity in
living our life well and compels human beings to express themselves the way the State wants. He
also submitted that the features relevant for upholding the dignity of a human being will be severely
compromised with when the data are cross-referenced with data relating to other spheres of life and
are disclosed to third parties through different data collected for varied reasons. This would take
place without the knowledge Writ Petition (Civil) No. 247 of 2017 & Ors. Page 55 and consent of the
poor assessees who are apparently required to mandatory obtain the Aadhaar card only for the
purposes of payment of taxes.
46) Mr. Khurshid also raised doubts and fears about the unauthorised disclosure of the information
given by these persons who enroll themselves under Aadhaar and submitted that in the absence of
proper mechanism in place to check unauthorised disclosure, the impugned provision of making
Aadhaar card for filing tax returns cannot be said to be consistent with the democratic ideals. Mr.
Khurshid also submitted that there was no compelling state interests in having such a provision
introducing compulsive element and depriving from erstwhile voluntary nature of Aadhaar scheme.
According to him, the ‘proportionality of means’ concept is an essential one since integrating data
beyond what is really necessary for the stated purpose is clearly unconstitutional. He submitted that
in light of the decision in the case of Gobind v. State of Madhya Pradesh16, which has been the
position of this Court since the past forty-two years and has been cited with approval often, it is
humbly submitted that the State has the onerous burden of justifying the impugned mandatory
provision. The ‘compelling state interest’ justification is only one aspect of 16 (1975) 2 SCC 148 Writ
Petition (Civil) No. 247 of 2017 & Ors. Page 56 the broader ‘strict scrutiny’ test, which was applied
by this Court in Anuj Garg v. Hotel Association of India17. The other essential facet is to
demonstrate ‘narrow tailoring’, i.e., that the State must demonstrate that even if a compelling
interest exists, it has adopted a method that will infringe in the narrowest possible manner upon
individual rights. He submitted that neither is there any compelling State interest warranting such a
harsh mandatory provision, nor has it been narrowly tailored to meet the object, if any.Binoy Visman vs Union Of India on 9 June, 2017

47) In this hue, he also submitted that Section 139AA of the Act violates the Rule of Law.
Elaborating his argument, he submitted that a legal system which in general observes the rule of law
treats its people as persons, in the sense that it attempts to guide their behaviour through affecting
the circumstances of their action. It, thus, presupposes that they are rational autonomous creatures
and attempts to affect their actions and habits by affecting their deliberations. It satisfies men’s
craving for reasonable certainty of form as well as substance, and for dignity of process as well as
dignity of result. On the other hand, when the rule of law is violated, it may be either in the form of
leading to uncertainty or it may lead to frustrated and disappointed 17 (2008) 3 SCC 1 Writ Petition
(Civil) No. 247 of 2017 & Ors. Page 57 expectations. It leads to the first when the law does not enable
people to foresee future developments or to form definite expectations. It leads to frustrated
expectations when the appearance of stability and certainty which encourages people to rely and
plan on the basis of the existing law is shattered by retroactive law-making or by preventing proper
law-enforcement, etc. The evils of frustrated expectations are greater. Quite apart from the concrete
harm they cause they also offend dignity in expressing disrespect for people’s autonomy. The law in
such cases encourages autonomous action only in order to frustrate its purpose. When such
frustration is the result of human action or the result of the activities of social institutions then it
expresses disrespect. Often it is analogous to entrapment: one is encouraged innocently to rely on
the law and then that assurance is withdrawn and one’s very reliance is turned into a cause of harm
to one. Just as in the instant case, the impugned provision came into force when the order of the
Court that Aadhaar card is not mandatory, still continues to operate.
48) In the alternative, another submission of Mr. Khurshid was that Section 139AA was
retrospective in nature as per proviso to sub-section (2) thereof. As per the said proviso, on failure to
give Writ Petition (Civil) No. 247 of 2017 & Ors. Page 58 Aadhaar number, the consequence was not
only to render the PAN Card invalid prospectively but from the initial date of issuance of PAN Card
in view of the expression ‘as if the person had not applied for Permanent Account Number’ which
would meant that PAN Card would be invalidated by rendering the same void ab initio i.e. from
retrospective effect. Such a retrospective effect, according to him, was violative of Article 20(1) of the
Constitution. Further, retrospective operation is not permissible without separate objects for such
operations as held in Dayawati v. Inderjit18. In conclusion, learned senior counsel submitted that
the law regarding mandatory requirement of Aadhaar card is a hasty piece of legislation without
much thought going into it. It is submitted that the Aadhaar card cannot be made mandatory for
filing tax returns with such far-reaching consequences for non-compliance, unless and until suitable
measures are put in place to ensure that the dignity of the assessees is not compromised with. The
generalisation, centralisation and disclosure of biometric information, however, accidental it might
be, has to be effectively controlled and mechanisms have to be put in place to inquire and penalise
those found guilty of disclosing such information. The need to do so is extremely 18 (1966) 3 SCR
275 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 59 crucial in view of the fact that biometric
systems may be bypassed, hacked, or even fail. Unless the same is done, the identity of the citizens
will be reduced to a collection of instrumentalised markers. Further, the organisations and
authorities allowed to conduct it should be strictly defined. There has to be a strict control over any
systematic use of common identifiers. No such re-grouping of data can be allowed as could lead to
the use of biometrics for exclusion of vulnerable groups. Brown considers surveillance as both a
discursive and a material practice that reifies bodies around divisive lines. Surveillance of certainBinoy Visman vs Union Of India on 9 June, 2017

communities has been both social as well as political norm. He further submitted that this Court
cannot lose sight of the fact that the data collected under the impugned provision may be used to
carry out discriminatory research and sort subjects into groups for specific reasons. The fact that the
impugned provision creates an apprehension in the minds of the people, legitimate and reasonable
enough with no preventive mechanism in place, is in itself a violation of the right to life and personal
liberty as enshrined under the Constitution.
49) Mr. Anando Mukherjee, learned counsel, appeared in Writ Petition (Civil) No. 304 of 2017,
while reiterating the submissions of earlier Writ Petition (Civil) No. 247 of 2017 & Ors. Page 60
counsel, argued that Section 139AA was confused, self-destructive and self-defeating provision for
the reason that on the one hand, it had an effect of making enrollment into Aadhaar mandatory, but,
on the other hand, by virtue of the explanation contained in the provision itself, it is kept voluntary
and as a matter of right for the same set of individuals and for the purposes of Section 139AA. He
also submitted that there was a conflict between Section 139AA of the Act and Section 29 of Aadhaar
Act inasmuch as Section 29 puts a blanket embargo on using the core biometric information,
collected or created under the Aadhaar Act for any purpose other than generation of Aadhaar
numbers and authentication under the Aadhaar Act. Mr. Mukherjee went to the extent of describing
the impugned provision as colourable exercise of power primarily on the ground that when Aadhaar
Act is voluntary in nature, there was no question of making this very provision mandatory by virtue
of Section 139AA of the Act.
50) Appearing for Union of India, Mr. Mukul Rohatgi, learned Attorney General for India, put stiff
resistance to the submissions advanced on behalf of the petitioners. In a bid to torpedo and
pulverise the arguments as set forth on the side of the petitioners, Writ Petition (Civil) No. 247 of
2017 & Ors. Page 61 the learned Attorney pyramid his arguments in the following style:
In the first, Mr. Rohatgi made few preliminary remarks. First such submission was
that many contentions advanced by the counsel for the petitioners touch upon the
question of Right to Privacy which had already been referred to the Constitution
Bench and, therefore, those aspects were not required to be dealt with. In this behalf,
he specifically referred to the following observations of this Court in its order dated
August 11, 2015, which were made by the three Judge Bench in Writ Petition (Civil)
No. 494 of 2012:
“At the same time, we are also of the opinion that the institutional integrity and
judicial discipline require that pronouncement made by larger Benches of this Court
cannot be ignored by the smaller Benches without appropriately explaining the
reasons for not following the pronouncements made by such larger Benches. With
due respect to all the learned Judges who rendered the subsequent judgments –
where right to privacy is asserted or referred to their Lordships concern for the
liberty of human beings, we are of the humble opinion that there appears to be
certain amount of apparent unresolved contradiction in the law declared by this
Court.” Notwithstanding these preliminary remarks, he rebutted the said argument
based on Article 21, including Right to Privacy, by raising a plea that Right toBinoy Visman vs Union Of India on 9 June, 2017

Privacy/Personal Autonomy/Bodily Integrity is not absolute. He referred to the
judgment of the United States Supreme Court in Roe v. Wade19 wherein it was
19 410 U.S. 113 (1973) Writ Petition (Civil) No. 247 of 2017 & Ors. Page 62 held:
“The privacy right involved, therefore, cannot be said to be absolute. In fact, it is not
clear to us that the claim asserted by some amici that one has an unlimited right to do
with one’s body as one pleases bears a close relationship to the right of privacy
previously articulated in the Court’s decisions. The Court has refused to recognise an
unlimited right of this kind in the past.” He also relied upon the judgment of this
Court in Sharda v.
Dharmpal20 where the Court held that a matrimonial court has the power to order a
person to undergo medical test. Passing of such an order by the court would not be in
violation of the right to personal liberty under Article 21 of the Indian Constitution.
51) His second preliminary submission was that insofar as challenge to the validity of
Section 139AA on other grounds is concerned, it is to be kept in mind that the
constitutional validity of a statute could be challenged only on two grounds, i.e. the
Legislature enacting the law was not competent to enact that particular law or such a
law is violative of any of the provisions of the Constitution.
In support, he referred to the various judgments of this Court.
52) He, thus, submitted that no third ground was available to any of the petitioners to challenge the
constitutional validity of a legislative enactment. According to him, the principle 20 (2003) 4 SCC
493 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 63 proportionality should not be read into
Article 14 of the Constitution, while taking support from the judgment in K.T. Plantation Private
Limited & Anr. v. State of Karnataka21, wherein it is held that plea of unreasonableness,
arbitrariness, proportionality, etc. always raises an element of subjectivity on which a court cannot
strike down a statute or a statutory provision.
53) Third introductory submission of the learned Attorney General was that the scope of judicial
review in a fiscal statute was very limited and Section 139AA of the Act, being a part of fiscal statute,
following parameters laid down in State of Madhya Pradesh v. Rakesh Kohli & Anr.22 had to be kept
in mind:
“32. While dealing with constitutional validity of a taxation law enacted by
Parliament or State Legislature, the court must have regard to the following
principles:
(i) there is always presumption in favour of constitutionality of a law made by
Parliament or a State Legislature,Binoy Visman vs Union Of India on 9 June, 2017

(ii) no enactment can be struck down by just saying that it is arbitrary or
unreasonable or irrational but some constitutional infirmity has to be found,
(iii) the court is not concerned with the wisdom or unwisdom, the justice or injustice
of the law as Parliament and State Legislatures are supposed to be alive to the needs
of the people whom they represent and they are the best judge of the community by
21 (2011) 4 SCC 414 22 (2012) 6 SCC 312 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 64 whose
suffrage they come into existence,
(iv) hardship is not relevant in pronouncing on the constitutional validity of a fiscal statute or
economic law, and
(v) in the field of taxation, the legislature enjoys greater latitude for classification...”.
54) In this hue, he also argued that the State enjoys the widest latitude where measure of economic
regulations are concerned {See – Secretary to Government of Madras & Anr. v. P.R. Sriramulu &
Anr.23, paragraph 15) and that mala fides cannot be attributed to the Parliament, as held in G.C.
Kanungo v. State of Orissa24, (paragraph 11). Also, the courts approached the issue with the
presumption of constitutionality in mind and that Legislature intends and correctly appreciates the
need of its own people, as held in Mohd. Hanif Quareshi & Ors. v. State of Bihar25 (paragraph 15).
55) On merits, the argument of Mr. Rohatgi was that once the aforesaid basic parameters are kept in
mind, the impugned provision passes the muster of constitutionality. Adverting to the issue of
legislative competence, he referred to Article 246 and 248 of the Constitution as well as Entry 82
and Entry 97 of List-I of Schedule-VII of the Constitution which empowers the 23 (1996) 1 SCC 345
24 (1995) 5 SCC 96 25 AIR 1958 SC 731 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 65
Parliament to legislate on the subject pertaining to income-tax.
Therefore, it could not be said that the impugned provision made was beyond the competence of the
Parliament. He also submitted that in any case residuary power lies with the Parliament and this
power to legislate is plenary, as held in Synthetics and Chemicals Ltd. & Ors. v. State of U.P. &
Ors.26 “56. On behalf of the State both Mr. Trivedi and Mr. Yogeshwar Prasad contended that
regulatory power of the State was there and in order to regulate it was possible to impose certain
disincentives in the form of fees or levies. Imposition of these imposts as part of regulatory process
is permissible, it was submitted. Our attention was drawn to the various decisions where by virtue of
“police power” in respect of alcohol the State has imposed such impositions. Though one would not
be justified in adverting to any police power, it is possible to conceive sovereign power and on that
sovereign power to have the power of regulation to impose such conditions so as to ensure that the
regulations are obeyed and complied with. We would not like, however, to embark upon any theory
of police power because the Indian Constitution does not recognise police power as such. But we
must recognise the exercise of sovereign power which gives the States sufficient authority to enact
any law subject to the limitations of the Constitution to discharge its functions. Hence, the Indian
Constitution as a sovereign State has power to legislate on all branches except to the limitation as toBinoy Visman vs Union Of India on 9 June, 2017

the division of powers between the Centre and the States and also subject to the fundamental rights
guaranteed under the Constitution. The Indian State, between the Centre and the States, has
sovereign power. The sovereign power is plenary and inherent in every sovereign State to do all
things which promote the health, peace, morals, education and good order of the people.
Sovereignty is difficult to define. This power of sovereignty is, however, subject to constitutional
limitations. This power, according to some 26 (1990) 1 SCC 109 Writ Petition (Civil) No. 247 of 2017
& Ors. Page 66 constitutional authorities, is to the public what necessity is to the individual. Right to
tax or levy imposts must be in accordance with the provisions of the Constitution.”
56) Rebutting the argument of Mr. Datar that by making the impugned provision mandatory the
Legislature had acted contrary to the judgments of this Court, Mr. Rohatgi argued that this
argument was devoid of any merit on various counts: First, there was no judgment of this Court and
the orders referred were only interim orders. Secondly, in any case, those orders were passed at a
time when Aadhaar was being implemented as a scheme in administrative/executive domain and
the Court was considering the validity of Aadhaar scheme in that hue/background. Those orders
have not been passed in the context of examining the validity of any legislative measure. Thirdly, no
final view is taken in the form of any judgment that Aadhaar is unconstitutional and, therefore,
there is no basis in existence which was required to be removed. Fourthly, the Parliament was
competent to pass the law and provide statutory framework to give legislative backing to Aadhaar in
the absence of any such law which existed at that time. He, thus, submitted that there was no
question of curing the alleged basis of judgment/interim orders by legislation. He specifically relied
upon the following passage from the judgment Writ Petition (Civil) No. 247 of 2017 & Ors. Page 67
in the case of Goa Foundation & Anr. v. State of Goa & Anr.27:
“24. The principles on which first question would require to be answered are not in
doubt. The power to invalidate a legislative or executive act lies with the Court. A
judicial pronouncement, either declaratory or conferring rights on the citizens cannot
be set at naught by a subsequent legislative act for that would amount to an
encroachment on the judicial powers. However, the legislature would be competent
to pass an amending or a validating act, if deemed fit, with retrospective effect
removing the basis of the decision of the Court. Even in such a situation the courts
may not approve a retrospective deprivation of accrued rights arising from a
judgment by means of a subsequent legislation (Madan Mohan Pathak v. Union of
India). However, where the Court's judgment is purely declaratory, the courts will
lean in support of the legislative power to remove the basis of a court judgment even
retrospectively, paving the way for a restoration of the status quo ante. Though the
consequence may appear to be an exercise to overcome the judicial pronouncement it
is so only at first blush; a closer scrutiny would confer legitimacy on such an exercise
as the same is a normal adjunct of the legislative power. The whole exercise is one of
viewing the different spheres of jurisdiction exercised by the two bodies i.e. the
judiciary and the legislature. The balancing act, delicate as it is, to the constitutional
scheme is guided by the well-defined values which have found succinct manifestation
in the views of this Court in Bakhtawar Trust.”Binoy Visman vs Union Of India on 9 June, 2017

57) Mr. Rohatgi thereafter read extensively from the counter affidavit filed on behalf
of the Union of India detailing the rational and objective behind introduction of
Section 139AA of the Act. He submitted that the provision aims to achieve, inter alia,
the following objectives:
(i) This provision was introduced to tackle the problem of
27 (2016) 6 SCC 602 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 68 multiple PAN cards to
same individuals and PAN cards in the name of fictitious individuals are common medium of money
laundering, tax evasion, creation and channelling of black money. PAN numbers in name of firm or
fictitious persons as directors or shareholders are used to create layers of shell companies through
which the aforesaid activities are done. A de-duplication exercise was done in the year 2006 and a
large number of PAN numbers were found to be duplicate. The problem of some persons
fraudulently obtaining multiple PANs and using them for making illegal transactions still exists.
Over all 11.35 lakh cases of duplicate PAN/fraudulent PAN have been detected and accordingly such
PANs have been deleted/deactivated. Out of this, around 10.52 lakh cases pertain to individual
assessees. Total number of Aadhaar for individuals exceeds 113 crores whereas total number of PAN
for individuals is around 29 crore. Therefore, whereas the Aadhaar Act applies to the entire
population, the Income Tax Act applies to a much smaller sub-set of the population, i.e. the tax
payers. In order to ensure One Pan to One Person, Aadhaar can be the sole criterion for allotment of
PAN to individuals only after all existing PAN are seeded Writ Petition (Civil) No. 247 of 2017 & Ors.
Page 69 with Aadhaar and quoting of Aadhaar is mandated for new PAN applications.
Counter affidavit filed by the Union of India also gives the following instances of misuse of PAN:
(a) In NSDL scame of 2006, about one lakh bogus bank and demat accounts were
opened through use of PANs. The real PAN owners were not aware of these accounts.
(b) As Banks progressively started insisting on PANs for opening of bank accounts,
unscrupulous operators managed multiple PANs for providing entries and operating
undisclosed accounts for making financial transactions.
(c) Entry operators manage a large number of shell companies using duplicate PANs
or PANs issued in the name of dummy directors and name lenders. As the persons
involved as bogus directors are usually the same set of persons, linkage with Aadhaar
would prevent such misuse. Further, it will also be expedient for the Enforcement
agencies to identify and red flag such misuses in future.
(d) Cases have also been found where multiple PANs are Writ Petition (Civil) No. 247
of 2017 & Ors. Page 70 acquired by a single entity by dubious means and used for
raising loans from different banks. In one such case at Ludhiana, multiple PANs were
found acquired by a person in his individual name as well as in the name of his firms
by dubious means. During investigation, he admitted to have acquired multiple PANs
for raising multiple loans from banks and to avoid adverse CIBIL information.Binoy Visman vs Union Of India on 9 June, 2017

Prosecution has been launched by the Income Tax Department in this case u/s 277A,
278, 278B of the Act in addition
(ii) To tackle the problem of black money, Mr. Rohatgi pointed out that the Second
Report of the Special Investigation Team (SIT) on black money, headed by Justice
M.B. Shah (Retd.), after observing the menace of corruption and black money,
recommended as follows:
“At present, for entering into financial/business transactions, persons have option to
quote their PAN or UID or passport number or driving license or any other proof of
identity. However, there is no mechanism/system at present to connect the data
available with each of these independent proofs of ID. It is suggested that these
databases be interconnected. This would assist in identifying multiple transactions by
one person with different IDs.” The SIT in its Third Report has recommended the
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 71 establishment of a Central KYC
Registry. The rational for the SIT recommendations was to prove a verifiable and
authenticable identity for all individuals and Aadhaar provides a mechanism to serve
that purpose in a federated architecture without aggregating all the information at
one place.
The Committee headed by the Chairman, CBDT on ‘Measures to tackle black money
in India and abroad’ reveals that various authorities are dealing with the menace of
money laundering being done to evade taxes under the garb of shell companies by the
persons who hold multiple bogus PAN numbers under different names or variations
of their names, providing accommodation entries to various companies and persons
to evade taxes and introduce undisclosed and unaccounted income of those persons
into their companies as share applications or loans and advances or booking fake
expenses. These are tax frauds and devices which are causing loss to the revenue to
the tune of thousands of crores.
(iii) Another objective is to curb the menace of shell companies.
It is submitted in this regard that PAN is a basis of all the requirements in the process of
incorporation of a company. Writ Petition (Civil) No. 247 of 2017 & Ors. Page 72 Even an artificial
juridical person like a company is granted PAN. It is required as an ID proof for incorporation of a
company, applying for DIN, digital signature etc. PAN is also required for opening a bank account in
the name of a company or individuals. Basic documents required for obtaining a PAN are ID proof
and address proof. It has been observed that these documents which are a basis of issuance of PAN
could easily be forged and, therefore, PAN cards issued on the basis of such forged documents
cannot be genuine and it can be used for various financial frauds/crime. Aadhaar will ensure that
there is no duplication of identity as biometric will not allow that. If at the time of opening of bank
accounts itself, the more robust identity proof like Aadhaar had been used in place of PAN, the
menace of mushrooming of non-descript/shell/jamakharchi/bogus companies would have been
prevented. There is involvement of natural person in the complex web of shell companies only at theBinoy Visman vs Union Of India on 9 June, 2017

initial stage when the shareholders subscribe to the share capital of the shell company. After that
may layers are created because there is company to company transaction and much more complex
structure of shell company Writ Petition (Civil) No. 247 of 2017 & Ors. Page 73 compromising the
financial integration of nation is formed which makes it almost impossible to identify the real
beneficiary (natural person) involved in these shell companies. These shell companies have been
used for purpose of money laundering at a large scale. The fake PAN cards have facilitated the
enormous growth of shell companies which were being used for layering of funds and illegal transfer
of such funds to some other companies/persons or parked abroad in the guise of remittances against
import. The share capital of these shell companies are subscribed by fake shareholders through
numerous bank accounts opened with the use of fake PAN cards at the initial stage.
(iv) According to the respondents, this provision will help in widening of tax base. It was pointed out
that more than 113 crore people have registered themselves under Aadhaar. Adults coverage of
Aadhaar is more than 99%. Aadhaar being a unique identification, the problem of bogus or duplicate
PANs can be dealt with in a more systematic and foolproof manner.
According to the respondent, in fact, it has already shown results as Aadhaar has led to weeding out
duplicate Writ Petition (Civil) No. 247 of 2017 & Ors. Page 74 and fakes in many welfare
programmes such as PDS, MNREGS, LPG Pahal, Old Age pension, scholarships etc. during the last
two years and it has led to savings of approximately Rs.49,000 crores to the exchequer.
58) Mr. Rohatgi also referred to that portions of the counter affidavit which narrates the following
benefits Aadhaar seeding in PAN database:
(a) Permanent Account Number (PAN) – PAN is a ten-digit alpha-numeric number
allotted by the Income Tax Department to any ‘person’ who applies for it or to whom
the department allots the number without an application.
One PAN for one person is the guiding principle for allotment of PAN. PAN acts as the identifier of
taxable entity and aggregator of all financial transactions undertaken by the taxable entity i.e.
‘person’.
(b) Legal provisions relating to PAN – PAN is the key or identifier of all computerized records
relating to the taxpayer. The requirement for obtaining of PAN is mandated through Section 139A of
the Act. The procedure for application for PAN is prescribed in Rule 114 of the Rules. The forms
prescribed for PAN application are 49A Writ Petition (Civil) No. 247 of 2017 & Ors. Page 75 and
49AA for Indian and Foreign Citizens/Entities. Quoting of PAN has been mandated for certain
transactions above specified threshold value in Rule 114B of the Rules.
(c) Uniqueness of PAN – For achieving the objective of one PAN to one assessee, it is required to
maintain uniqueness of PAN. The uniqueness of PAN is achieved by conducting a de-duplication
check on all already existing allotted PAN against the data furnished by new applicant. Under the
existing system of PAN only demographic data is captured. De-duplication process is carried out
using a Phonetic Algorithm whereby a Phonetic PAN (PPAN) is created in respect of each applicantBinoy Visman vs Union Of India on 9 June, 2017

using the data of applicant’s name, father’s name, date of birth, gender and status. By comparison of
newly generated PPAN with existing set of PPANs of all assessees duplicate check is carried out and
it is ensured that same person does not acquire multiple PANs or one PAN is not allotted to multiple
persons. Due to prevalence of common names and large number of PAN holders, the demographic
way of de-duplication is not foolproof. Many instances are found where multiple PANs have been
allotted to one person or one PAN has been allotted to multiple persons despite the application of
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 76 above-mentioned de-duplication process. While
allotment of multiple PAN to one person has the risk of diversion of income of person into several
PANs resulting in evasion of tax, the allotment of same PAN to multiple persons results in wrong
aggregation and assessment of incomes of several persons as one taxable entity represented by
single PAN.
(d) Presently verification of original documents in only 0.2% cases (200 out of 1,00,000 PAN
applications) is done on a random basis which is quite less. In the case of Aadhaar, 100%
verification is possible due to availability of on-line Aadhaar authentication service provided by the
UIDAI. Aadhaar seeding in PAN database will make PAN allotment process more robust.
(e) Seeding of Aadhaar number into PAN database will allow a robust way of de-duplication as
Aadhaar number is de-duplicated using biometric attributes of fingerprints and iris images. The
instance of a duplicate Aadhaar is almost non-existent. Further seeking of Aadhaar will allow the
Income Tax Department to weed out any undetected duplicate PANs. It will also facilitate resolution
of cases of one PAN allotted to multiple persons.
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 77
59) After stating the aforesaid purpose, rational and benefits, the learned Attorney General
submitted that the main provision is not violative of any constitutional rights of the petitioners.
According to him, the provision was not discriminatory at all inasmuch as it was passed on
reasonable classification, the two classes being tax payers and non tax payers. He also submitted
that it was totally misconceived that this provision had no rational nexus with the objective sought
to be achieved in view of the various objectives and benefits which were sought to be achieved by
seeding Aadhaar with PAN. Mr. Rohatgi also referred to various orders and judgments of this Court
whereunder use of Aadhaar was endorsed, encouraged or even directed. Following instances are
cited:
60) The importance and utility of Aadhaar for delivery of public services like PDS,
curbing bogus admissions in schools and verification of mobile number subscribers
has not only been upheld but endorsed and recommended by this Court.
61) This Court in the case of PUCL v. Union of India28 has approved the
recommendations of the High Powered Committee headed by Justice D.P. Wadhwa,
which recommended linking of AadhaarBinoy Visman vs Union Of India on 9 June, 2017

28 (2011) 14 SCC 331 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 78 with PDS and encouraged
State Governments to adopt the same.
62) This Court in State of Kerala & others vs. President, Parents Teachers Association, SNVUP and
Others 29 has directed use of Aadhaar for checking bogus admissions in schools with the following
observations:
“18. We are, however, inclined to give a direction to the Education Department, State
of Kerala to forthwith give effect to a circular dated 12.10.2011 to issue UID Card to
all the school children and follow the guidelines and directions contained in their
circular. Needless to say, the Government can always adopt, in future, better
scientific methods to curb such types of bogus admissions in various aided schools.”
63) While monitoring the PILs relating to night shelters for the homeless and the
right to food through the public distribution system, this Court has lauded and
complimented the efforts of the State Governments for inter alia carrying out
bio-metric identification of the head of family of each household to eliminate
fictitious, bogus and ineligible BPL/AAY household cards.
64) A two Judge Bench of this court in People’s Union for Civil Liberties (PDS
Matter) v. Union of India & Ors.30 has held that computerisation is going to help the
public distribution system in the country in a big way and encouraged and endorsed
the
29 (2013) 2 SCC 705 30 (2013) 14 SCC 368 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 79
digitisation of database including bio-metric identification of the beneficiaries. In fact, this Court
had requested Mr. Nandan Nilekani to suggest ways in which the computerisation process of PDS
can be expedited.
65) In the case of People’s Union for Civil Liberties v. Union of India & Ors.31, this Court has also
endorsed bio-metric identification of homeless persons so that the benefits like supply of food and
kerosene oil available to persons who are below poverty line can be extended to the correct
beneficiaries.
66) In the case of Lokniti Foundation v. Union of India & Ors.32, this Court has disposed of the writ
petition while approving the Aadhaar based verification of existing and new mobile number
subscribers and upon being satisfied that an effective process has been evolved to ensure identity
verification.
67) Mr. Sengupta, learned counsel arguing on behalf of UIDAI, made additional submissions
specifically answering the doctrine of proportionality argument advanced by Mr. Datar as well as on
the aspect of informational self-determination. His submissions in this behalf were that
proportionality should not be read into Article 14 of the Constitution and in any case no
proportionality or other 31 (2010) 5 SCC 318 32 Writ Petition (C) No. 607 of 2016 decided onBinoy Visman vs Union Of India on 9 June, 2017

February 06, 2017 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 80 Article 14 violation had been
made out in the instant case. He also argued that there is no absolute right to informational
self-determination; to the extent such right may exist it is part of the Right to Privacy whose very
existence contours is before the Constitution Bench of this Court.
68) Adverting to the doctrine of proportionality, he referred to the judgments of this Court in
Modern Dental College and Research Centre33 wherein this doctrine is explained and applied and
submitted that the doctrine is applied only in the context of Article 19(1)(g) and not Article 14 of the
Constitution. He pointed out that proportionality is not the governing law even in the United
Kingdom for claims analogous to Article 14 of the Constitution. His passionate submission was that
proportionality supplanting traditional review in European Court of Human Rights cases and not
remaining applicable in traditional judicial review claims has caused immense confusion in British
pubic law. Narrating the structure of Article 19, submission of Mr. Sengupta was that freedoms
which were enlisted under Article 19(1) were not the absolute freedoms and they were subject to
reasonable restrictions, as provided under sub-article (2) to (6) of Article 19 itself. It is because of
this reason, while examining as to whether 33 Footnote 7 above Writ Petition (Civil) No. 247 of 2017
& Ors. Page 81 a particular measure violated any of the freedoms or was a reasonable restriction,
balancing exercise was to be done by the courts and this balancing exercise brings the element of
proportionality. However, this was not envisaged in Article 14 at all.
69) Coming to the impugned provision and referring to the penal consequences provided in proviso
to Section 139AA(2), he argued that the test of whether penalty is proportionate is not the same as
the doctrine of proportionality. Proportionate penalty is an incident of arbitrariness whereas there
cannot be any arbitrariness qua a statute. He also submitted that on facts penalty provided in the
impugned provision is deemed to be the same as that for not filing income tax return with valid
PAN. He also argued that there was no violation of Article 14 inasmuch as classification had a
reasonable nexus with the object enshrined in the impugned provision. It was open to the
Legislature to determine decrease of harm and act accordingly and the Legislature does not have to
tackle problem 100% for it to have a rational nexus. Since individual assessees are prone to the
problem and financial frauds using fake PAN, whether individually or in the guise of legal persons,
Aadhaar aims at tackling problem Writ Petition (Civil) No. 247 of 2017 & Ors. Page 82 which
exhibited a rational nexus with the object. According to Mr. Sengupta, there was no discriminatory
object inasmuch as the object is to weed out duplicate PANs that allow financial and tax fraud.
Therefore, the provision is not discriminatory in nature.
70) Dealing with the argument of right to informational self-determination, the learned counsel
submitted that as a matter of current practice in India, no absolute right to determine what
information about oneself one wants to disclose; several pieces of personal information are required
by law. The perils of comparative law in merely transplanting from German law; the need to develop
an Indian understanding of privacy and self-determination in the Indian context. Even in German
law, the judgment quoted by the petitioner does not demonstrate an untrammelled Right to Privacy
or information self-determination. The world over, information over oneself is the most critical
element of privacy; the contours of which are to be determined by a Constitution Bench.Binoy Visman vs Union Of India on 9 June, 2017

A Caveat
71) Before we enter into the discussion and weigh the merits of arguments addressed on both sides,
one aspect needs to be made absolutely clear, though it has been hinted earlier as well. Writ Petition
(Civil) No. 247 of 2017 & Ors. Page 83 Conscious of the fact that challenge to Aadhaar
scheme/legislation on the ground that it was violative of Article 21 of the Constitution is pending
before the Constitution Bench and, therefore, this Bench could not have decided that issue, counsel
for the petitioners had submitted that they would not be pressing the issue of Right to Privacy.
Notwithstanding the same, it was argued by Mr. Divan, though in the process Mr. Divan emphasised
that he was touching upon other facets of Article 21. Likewise, Mr. Salman Khurshid while arguing
that the impugned provision was violative of Article 21, based his submission on Right to Human
Dignity as a facet of Article 21. He also emphasised that the concept of human dignity was different
from Right to Privacy. We have taken note of these arguments above. However, we feel all these
aspects argued by the petitioners overlap with privacy issues as different aspects of Article 21 of the
Constitution. Right to Let Alone has the shades of Right to Privacy and it is so held by the Court in
R. Rajagopal & Anr. v. State of Tamil Nadu & Ors.34:
“26. We may now summarise the broad principles flowing from the above discussion:
(1) The right to privacy is implicit in the right to life and liberty guaranteed to the
citizens of this country by Article 21. It is a “right to be let alone”. A citizen has a right
to safeguard the privacy of his own, his family,
34 (1994) 6 SCC 632 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 84 marriage, procreation,
motherhood, child-bearing and education among other matters. None can publish anything
concerning the above matters without his consent — whether truthful or otherwise and whether
laudatory or critical. If he does so, he would be violating the right to privacy of the person concerned
and would be liable in an action for damages. Position may, however, be different, if a person
voluntarily thrusts himself into controversy or voluntarily invites or raises a controversy.
(2) The rule aforesaid is subject to the exception, that any publication concerning the aforesaid
aspects becomes unobjectionable if such publication is based upon public records including court
records. This is for the reason that once a matter becomes a matter of public record, the right to
privacy no longer subsists and it becomes a legitimate subject for comment by press and media
among others. We are, however, of the opinion that in the interests of decency [Article 19(2)] an
exception must be carved out to this rule, viz., a female who is the victim of a sexual assault, kidnap,
abduction or a like offence should not further be subjected to the indignity of her name and the
incident being publicised in press/media.
(3) There is yet another exception to the rule in (1) above — indeed, this is not an exception but an
independent rule. In the case of public officials, it is obvious, right to privacy, or for that matter, the
remedy of action for damages is simply not available with respect to their acts and conduct relevant
to the discharge of their official duties. This is so even where the publication is based upon facts and
statements which are not true, unless the official establishes that the publication was made (by theBinoy Visman vs Union Of India on 9 June, 2017

defendant) with reckless disregard for truth. In such a case, it would be enough for the defendant
(member of the press or media) to prove that he acted after a reasonable verification of the facts; it
is not necessary for him to prove that what he has written is true. Of course, where the publication is
proved to be false and actuated by malice or personal animosity, the defendant would have no
defence and would be liable for damages. It is equally obvious that in matters not relevant to the
discharge of his duties, the public official enjoys the same protection as any other citizen, Writ
Petition (Civil) No. 247 of 2017 & Ors. Page 85 as explained in (1) and (2) above. It needs no
reiteration that judiciary, which is protected by the power to punish for contempt of court and
Parliament and legislatures protected as their privileges are by Articles 105 and 104 respectively of
the Constitution of India, represent exceptions to this rule.
(4) So far as the Government, local authority and other organs and institutions exercising
governmental power are concerned, they cannot maintain a suit for damages for defaming them.
(5) Rules 3 and 4 do not, however, mean that Official Secrets Act, 1923, or any similar enactment or
provision having the force of law does not bind the press or media.
(6) There is no law empowering the State or its officials to prohibit, or to impose a prior restraint
upon the press/media.” So is the Right to Informational Self Determination, as specifically spelled
out by US Supreme Court in United States Department of Justice v. Reporters Committee for
Freedom of the Press35. Because of the aforesaid reasons and keeping in mind the principle of
judicial discipline, we have made conscious choice not to deal with these aspects and it would be for
the parties to raise these issues before the Constitution Bench. Accordingly, other arguments based
on Articles 14 and 19 of the Constitution as well as competence of the legislature to enact such law
are being examined.
72) We have deeply deliberated on the arguments advanced by 35 489 U.S. 749 (1989) Writ Petition
(Civil) No. 247 of 2017 & Ors. Page 86 various counsel appearing for different petitioners as well as
counter submissions made by counsel appearing on behalf of the State. Undoubtedly, the issue that
confronts us is of seminal importance. In recent times, issues about the proprietary, significance,
merits and demerits have generated lots of debate among intelligentia. The Government claims that
this provision is introduced in the Statute to achieve laudable objectives and it is in public interest.
It is felt that this technology can solve many development challenges. The petitioners argue that the
move is impermissible as it violates their fundamental rights. It falls in the category of, what Ronald
Dworkin calls, “hard cases”. Nevertheless, the duty of the court is to decide such cases as well and
give better decision. While undertaking this exercise of judicial review, let us first keep in mind the
width and extent of power of judicial review of a legislative action. The Court cannot question the
wisdom of the Legislature in enacting a particular law. It is required to act within the domain
available to it. Scope of Judicial Review of Legislative Act
73) Under the Constitution, Supreme Court as well as High Courts are vested with the power of
judicial review of not only administrative acts of the executive but legislative enactments Writ
Petition (Civil) No. 247 of 2017 & Ors. Page 87 passed by the legislature as well. This power is given
to the High Courts under Article 226 of the Constitution and to the Supreme Court under Article 32Binoy Visman vs Union Of India on 9 June, 2017

as well as Article 136 of the Constitution. At the same time, the parameters on which the power of
judicial review of administrative act is to be undertaken are different from the parameters on which
validity of legislative enactment is to be examined. No doubt, in exercises of its power of judicial
review of legislative action, the Supreme Court, or for that matter, the High Courts can declare law
passed by the Parliament or the State Legislature as invalid. However, the power to strike down
primary legislation enacted by the Union or the State Legislatures is on limited grounds. Courts can
strike down legislation either on the basis that it falls foul of federal distribution of powers or that it
contravenes fundamental rights or other Constitutional rights/provisions of the Constitution of
India. No doubt, since the Supreme Court and the High Courts are treated as the ‘ultimate arbiter in
all matters involving interpretation of the Constitution, it is the Courts which have the final say on
questions relating to rights and whether such a right is violated or not. The basis of the aforesaid
statement lies in Article 13(2) of the Constitution which proscribes the State from making ‘any law
which takes away or abridges the right conferred by Part III’, enshrining Writ Petition (Civil) No.
247 of 2017 & Ors. Page 88 fundamental rights. It categorically states that any law made in
contravention thereof, to the extent of the contravention, be void.
74) We can also take note of Article 372 of the Constitution at this stage which applies to
pre-constitutional laws. Article 372(1) reads as under:
“372. Continuance in force of existing laws and their adaptation.-
(1) Notwithstanding the repeal by this Constitution of the enactments referred to in
article 395 but subject to the other provisions of this Constitution, all the law in force
in the territory of India immediately before the commencement of this Constitution
shall continue in force therein until altered or repealed or amended by a competent
Legislature or other competent authority.” In the context of judicial review of
legislation, this provision gives an indication that all laws enforced prior to the
commencement of the Constitution can be tested for compliance with the provisions
of the Constitution by Courts. Such a power is recognised by this Court in Union of
India & Ors. v. Sicom Limited & Anr.36. In that judgment, it was also held that since
the term ‘laws’, as per Article 372, includes common law the power of judicial review
of legislation, which is a part of common law applicable in India before the
Constitution came into force, would continue to vest in the Indian courts.
36 (2009) 2 SCC 121 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 89
75) With this, we advert to the discussion on the grounds of judicial review that are available to
adjudge the validity of a piece of legislation passed by the Legislature. We have already mentioned
that a particular law or a provision contained in a statute can be invalidated on two grounds,
namely: (i) it is not within the competence of the Legislature which passed the law, and/or (ii) it is in
contravention of any of the fundamental rights stipulated in Part III of the Constitution or any other
right/ provision of the Constitution. These contours of the judicial review are spelled out in the clear
terms in case of Rakesh Kohli37, and particularly the following paragraphs:Binoy Visman vs Union Of India on 9 June, 2017

“16. The statute enacted by Parliament or a State Legislature cannot be declared
unconstitutional lightly. The court must be able to hold beyond any iota of doubt that
the violation of the constitutional provisions was so glaring that the legislative
provision under challenge cannot stand. Sans flagrant violation of the constitutional
provisions, the law made by Parliament or a State Legislature is not declared bad.
17. This Court has repeatedly stated that legislative enactment can be struck down by
court only on two grounds, namely (i) that the appropriate legislature does not have
the competence to make the law, and
(ii) that it does not (sic) take away or abridge any of the fundamental rights
enumerated in Part III of the Constitution or any other constitutional provisions.
In McDowell and Co. while dealing with the challenge to an enactment based on Article 14, this
Court stated in para 43 of the Report as follows: (SCC pp. 737-38) ““43. … A law made by Parliament
or the 37 Footnote 20 above Writ Petition (Civil) No. 247 of 2017 & Ors. Page 90 legislature can be
struck down by courts on two grounds and two grounds alone viz. (1) lack of legislative competence,
and (2) violation of any of the fundamental rights guaranteed in Part III of the Constitution or of any
other constitutional provision. There is no third ground. … if an enactment is challenged as violative
of Article 14, it can be struck down only if it is found that it is violative of the equality clause/equal
protection clause enshrined therein.
Similarly, if an enactment is challenged as violative of any of the fundamental rights guaranteed by
sub-clauses (a) to (g) of Article 19(1), it can be struck down only if it is found not saved by any of the
clauses (2) to (6) of Article 19 and so on. No enactment can be struck down by just saying that it is
arbitrary or unreasonable. Some or the other constitutional infirmity has to be found before
invalidating an Act. An enactment cannot be struck down on the ground that court thinks it
unjustified. Parliament and the legislatures, composed as they are of the representatives of the
people, are supposed to know and be aware of the needs of the people and what is good and bad for
them. The court cannot sit in judgment over their wisdom.” (emphasis supplied)
26. In Mohd. Hanif Quareshi, the Constitution Bench further observed that there was always a
presumption in favour of constitutionality of an enactment and the burden is upon him, who attacks
it, to show that there has been a clear violation of the constitutional principles. It stated in para 15 of
the Report as under:
(AIR pp. 740-41) ““15. … The courts, it is accepted, must presume that the legislature
understands and correctly appreciates the needs of its own people, that its laws are
directed to problems made manifest by experience and that its discriminations are
based on adequate grounds. It must be borne in mind that the legislature is free to
recognise degrees of harm and may confine its restrictions to Writ Petition (Civil) No.
247 of 2017 & Ors. Page 91 those cases where the need is deemed to be the clearest
and finally that in order to sustain the presumption of constitutionality the court may
take into consideration matters of common knowledge, matters of common report,Binoy Visman vs Union Of India on 9 June, 2017

the history of the times and may assume every state of facts which can be conceived
existing at the time of legislation.”
27. The above legal position has been reiterated by a Constitution Bench of this Court in Mahant
Moti Das v. S.P. Sahi.
28. In Hamdard Dawakhana v. Union of India, inter alia, while referring to the earlier two decisions,
namely, Bengal Immunity Co. Ltd. and Mahant Moti Das, it was observed in para 8 of the Report as
follows: (Hamdard Dawakhana case, AIR p. 559):
““8. Therefore, when the constitutionality of an enactment is challenged on the
ground of violation of any of the articles in Part III of the Constitution, the
ascertainment of its true nature and character becomes necessary i.e. its
subject-matter, the area in which it is intended to operate, its purport and intent have
to be determined. In order to do so it is legitimate to take into consideration all the
factors such as history of the legislation, the purpose thereof, the surrounding
circumstances and conditions, the mischief which it intended to suppress, the remedy
for the disease which the legislature resolved to cure and the true reason for the
remedy….” In Hamdard Dawakhana, the Court also followed the statement of law in
Mahant Moti Das and the two earlier decisions, namely, Charanjit Lal Chowdhury v.
Union of India and State of Bombay v. F.N. Balsara and reiterated the principle that
presumption was always in favour of constitutionality of an enactment.
xx xx xx
30. A well-known principle that in the field of taxation, the legislature enjoys a
greater latitude for Writ Petition (Civil) No. 247 of 2017 & Ors. Page 92 classification,
has been noted by this Court in a long line of cases. Some of these decisions are
Steelworth Ltd. v. State of Assam; Gopal Narain v. State of U.P.;
Ganga Sugar Corpn. Ltd. v. State of U.P.; R.K. Garg v. Union of India; and State of W.B. v. E.I.T.A.
India Ltd.”
76) Again in Ashok Kumar Thakur v. Union of India & Ors.38, this Court made the following
pertinent observations:
“219. A legislation passed by Parliament can be challenged only on constitutionally
recognised grounds. Ordinarily, grounds of attack of a legislation is whether the
legislature has legislative competence or whether the legislation is ultra vires the
provisions of the Constitution. If any of the provisions of the legislation violates
fundamental rights or any other provisions of the Constitution, it could certainly be a
valid ground to set aside the legislation by invoking the power of judicial review. A
legislation could also be challenged as unreasonable if it violates the principles of
equality adumbrated in our Constitution or it unreasonably restricts the fundamentalBinoy Visman vs Union Of India on 9 June, 2017

rights under Article 19 of the Constitution. A legislation cannot be challenged simply
on the ground of unreasonableness because that by itself does not constitute a
ground. The validity of a constitutional amendment and the validity of plenary
legislation have to be decided purely as questions of constitutional law. This Court in
State of Rajasthan v. Union of India said: (SCC p. 660, para
149) “149. … if a question brought before the court is purely a political question not
involving determination of any legal or constitutional right or obligation, the court
would not entertain it, since the court is concerned only with adjudication of legal
rights and liabilities.” Therefore, the plea of the petitioner that the legislation itself
was intended to please a section of the community as part of the vote catching
mechanism is 38 (2008) 6 SCC 1 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 93
not a legally acceptable plea and it is only to be rejected.”
77) Furthermore, it also needs to be specifically noted that this Court emphasised
that apart from the aforesaid two grounds no third ground is available to invalidate
any piece of legislation. In this behalf it would be apposite to reproduce the following
observations from State of A.P. & Ors. v. McDowell & Co. & Ors.39, which is a
judgment rendered by a three Judge Bench of this Court:
“43...A law made by Parliament or the legislature can be struck down by courts on
two grounds and two grounds alone, viz., (1) lack of legislative competence and (2)
violation of any of the fundamental rights guaranteed in Part III of the Constitution
or of any other constitutional provision. There is no third ground. We do not wish to
enter into a discussion of the concepts of procedural unreasonableness and
substantive unreasonableness — concepts inspired by the decisions of United States
Supreme Court. Even in U.S.A., these concepts and in particular the concept of
substantive due process have proved to be of unending controversy, the latest
thinking tending towards a severe curtailment of this ground (substantive due
process). The main criticism against the ground of substantive due process being that
it seeks to set up the courts as arbiters of the wisdom of the legislature in enacting the
particular piece of legislation. It is enough for us to say that by whatever name it is
characterised, the ground of invalidation must fall within the four corners of the two
grounds mentioned above. In other words, say, if an enactment is challenged as
violative of Article 14, it can be struck down only if it is found that it is violative of the
equality clause/equal protection clause enshrined therein. Similarly, if an enactment
is challenged as violative of any of the fundamental rights guaranteed by clauses 39
(1996) 3 SCC 709 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 94
(a) to (g) of Article 19(1), it can be struck down only if it is found not saved by any of
the clauses (2) to (6) of Article 19 and so on. No enactment can be struck down by
just saying that it is arbitrary or unreasonable.Binoy Visman vs Union Of India on 9 June, 2017

Some or other constitutional infirmity has to be found before invalidating an Act. An enactment
cannot be struck down on the ground that court thinks it unjustified. Parliament and the
legislatures, composed as they are of the representatives of the people, are supposed to know and be
aware of the needs of the people and what is good and bad for them. The court cannot sit in
judgment over their wisdom. In this connection, it should be remembered that even in the case of
administrative action, the scope of judicial review is limited to three grounds, viz., (i)
unreasonableness, which can more appropriately be called irrationality, (ii) illegality and (iii)
procedural impropriety (see Council of Civil Service Unions v. Minister for Civil Service [1985 AC
374 : (1984) 3 All ER 935 : (1984) 3 WLR 1174] which decision has been accepted by this Court as
well). The applicability of doctrine of proportionality even in administrative law sphere is yet a
debatable issue. (See the opinions of Lords Lowry and Ackner in R. v. Secy. of State for Home
Deptt., ex p Brind [1991 AC 696 : (1991) 1 All ER 720] AC at 766-67 and 762.) It would be rather odd
if an enactment were to be struck down by applying the said principle when its applicability even in
administrative law sphere is not fully and finally settled...”
78) Another aspect in this context, which needs to be emphasized, is that a legislation cannot be
declared unconstitutional on the ground that it is ‘arbitrary’ inasmuch as examining as to whether a
particular Act is arbitrary or not implies a value judgment and the courts do not examine the
wisdom of legislative choices and, therefore, cannot undertake this exercise. This was so recognised
in a recent judgment of this Court Rajbala & Ors. v. Writ Petition (Civil) No. 247 of 2017 & Ors. Page
95 State of Haryana & Ors.40 wherein this Court held as under:
“
64. From the above extract from McDowell & Co.
case it is clear that the courts in this country do not undertake the task of declaring a piece of
legislation unconstitutional on the ground that the legislation is “arbitrary” since such an exercise
implies a value judgment and courts do not examine the wisdom of legislative choices unless the
legislation is otherwise violative of some specific provision of the Constitution. To undertake such an
examination would amount to virtually importing the doctrine of “substantive due process”
employed by the American Supreme Court at an earlier point of time while examining the
constitutionality of Indian legislation. As pointed out in the above extract, even in United States the
doctrine is currently of doubtful legitimacy. This Court long back in A.S. Krishna v. State of Madras
declared that the doctrine of due process has no application under the Indian Constitution As
pointed out by Frankfurter, J., arbitrariness became a mantra.
65. For the above reasons, we are of the opinion that it is not permissible for this Court to declare a
statute unconstitutional on the ground that it is ‘arbitrary’.”
79) Same sentiments were expressed earlier by this Court in K.T. Plantation Private Limited &
Anr.41 in the following words:Binoy Visman vs Union Of India on 9 June, 2017

“205. Plea of unreasonableness, arbitrariness, proportionality, etc. always raises an
element of subjectivity on which a court cannot strike down a statute or a statutory
provision, especially when the right to property is no more a fundamental right.
Otherwise the court will be substituting its wisdom to that of the legislature, which is
impermissible in our constitutional democracy.” A fortiorari, a law cannot be
invalidated on the ground that the Legislature did not apply its mind or it was
prompted by some 40 (2016) 2 SCC 445 41 Footnote 19 above.
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 96 improper motive.
80) It is, thus, clear that in exercise of power of judicial review, Indian Courts are invested with
powers to strike down primary legislation enacted by the Parliament or the State legislatures.
However, while undertaking this exercise of judicial review, the same is to be done at three levels. In
the first stage, the Court would examine as to whether impugned provision in a legislation is
compatible with the fundamental rights or the Constitutional provisions (substantive judicial
review) or it falls foul of the federal distribution of powers (procedural judicial review). If it is not
found to be so, no further exercise is needed as challenge would fail. On the other hand, if it is found
that Legislature lacks competence as the subject legislated was not within the powers assigned in the
list in VII Schedule, no further enquiry is needed and such a law is to be declared as ultravires the
Constitution. However, while undertaking substantive judicial review, if it is found that the
impugned provision appears to be violative of fundamental rights or other Constitutional rights, the
Court reaches the second stage of review. At this second phase of enquiry, the Court is supposed to
undertake the exercise as to whether the impugned provision can still be saved by reading it Writ
Petition (Civil) No. 247 of 2017 & Ors. Page 97 down so as to bring it in conformity with the
Constitutional provisions. If that is not achievable then the enquiry enters the third stage. If the
offending portion of the statute is severable, it is severed and the Court strikes down the impugned
provision declaring the same as unconstitutional.
81) Keeping in view the aforesaid parameters we, at this stage, we want to devote some time
discussing the arguments of the petitioners based on the concept of ‘limited government’. Concent of
‘Limited Government’ and its impact on powers of Judicial Review
82) There cannot be any dispute about the manner in which Mr. Shyam Divan explained the concept
of ‘limited Government’ in his submissions. Undoubtedly, the Constitution of India, as an
instrument of governance of the State, delineates the functions and powers of each wing of the State,
namely, the Legislature, the Judiciary and the Executive. It also enshrines the principle of
separation of powers which mandates that each wing of the State has to function within its own
domain and no wing of the State is entitled to trample over the function assigned to the other wing
of the State. This fundamental document of governance also contains principle of federalism
wherein the Union is assigned Writ Petition (Civil) No. 247 of 2017 & Ors. Page 98 certain powers
and likewise powers of the State are also prescribed. In this context, the Union Legislature, i.e. the
Parliament, as well as the State Legislatures are given specific areas in respect of which they have
power to legislate. That is so stipulated in Schedule VII of the Constitution wherein List I
enumerates the subjects over which Parliament has the dominion, List II spells out those areasBinoy Visman vs Union Of India on 9 June, 2017

where the State Legislatures have the power to make laws while List III is the Concurrent List which
is accessible both to the Union as well as the State Governments. The Scheme pertaining to making
laws by the Parliament as well as by the Legislatures of the State is primarily contained in Articles
245 to 254 of the Constitution. Therefore, it cannot be disputed that each wing of the State to act
within the sphere delineated for it under the Constitution. It is correct that crossing these limits
would render the action of the State ultra vires the Constitution. When it comes to power of
taxation, undoubtedly, power to tax is treated as sovereign power of any State. However, there are
constitutional limitations briefly described above. In a nine Judge Bench decision of this Court in
Jindal Stainless Ltd. & Anr. v. State of Haryana & Ors.42 discussion on these constitutional
limitations are as follows:
42 (2016) 11 Scale 1 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 99 “20. Exercise
of sovereign power is, however, subject to Constitutional limitations especially in a
federal system like ours where the States also to the extent permissible exercise the
power to make laws including laws that levy taxes, duties and fees. That the power to
levy taxes is subject to constitutional limitations is no longer res-integra. A
Constitution Bench of this Court has in Synthetics and Chemicals Ltd. v. State of U.P.
(1990) 1 SCC 109 recognised that in India the Centre and the States both enjoy the
exercise of sovereign power, to the extent the Constitution confers upon them that
power. This Court declared:
“56 … We would not like, however, to embark upon any theory of police power
because the Indian Constitution does not recognise police power as such. But we
must recognise the exercise of Sovereign power which gives the State sufficient
authority to enact any law subject to the limitations of the Constitution to discharge
its functions. Hence, the Indian Constitution as a sovereign State has power to
legislate on all branches except to the limitation as to the division of powers between
the Centre and the States and also subject to the fundamental rights guaranteed
under the Constitution. The Indian States, between the Centre and the States, has
sovereign power. The sovereign power is plenary and inherent in every sovereign
State to do all things which promote the health, peace, morals, education and good
order of the people.
Sovereignty is difficult to define. This power of sovereignty is, however, subject to
constitutional limitations.”This power, according to some constitutional authorities,
is to the public what necessity is to the individual. Right to tax or levy impost must be
in accordance with the provisions of the Constitution.”
21. What then are the Constitutional limitations on the power of the State legislatures
to levy taxes or for that matter enact legislations in the field reserved for them under
the relevant entries of List II and III of the Seventh Schedule. The first and the
foremost of these limitations appears in Article 13 of the Constitution of Writ Petition
(Civil) No. 247 of 2017 & Ors. Page 100 India which declares that all laws in force in
the territory of India immediately before the commencement of the Constitution areBinoy Visman vs Union Of India on 9 June, 2017

void to the extent they are inconsistent with the provisions of Part III dealing with the
fundamental rights guaranteed to the citizens. It forbids the States from making any
law which takes away or abridges, any provision of Part III.
Any law made in contravention of the said rights shall to the extent of contravention be void. There
is no gain saying that the power to enact laws has been conferred upon the Parliament subject to the
above Constitutional limitation. So also in terms of Article 248, the residuary power to impose a tax
not otherwise mentioned in the Concurrent List or the State List has been vested in the Parliament
to the exclusion of the State legislatures, and the States' power to levy taxes limited to what is
specifically reserved in their favour and no more.
22. Article 249 similarly empowers the Parliament to legislate with respect to a matter in the State
List for national interest provided the Council of States has declared by a resolution supported by
not less than two-thirds of the members present and voting that it is necessary or expedient in
national interest to do so. The power is available till such time any resolution remains in force in
terms of Article 249(2) and the proviso thereunder.
23. Article 250 is yet another provision which empowers the Parliament to legislate with respect to
any matter in the State List when there is a proclamation of emergency. In the event of an
inconsistency between laws made by Parliament under Articles 249 and 250, and laws made by
legislature of the States, the law made by Parliament shall, to the extent of the inconsistency, prevail
over the law made by the State in terms of Article 251.
24. The power of Parliament to legislate for two or more States by consent, in regard to matters not
otherwise within the power of the Parliament is regulated by Article 252, while Article 253 starting
with a non-obstante clause empowers Parliament to make any law for the whole country or any part
of the territory of India for implementing any treaty, agreement or convention with any other
country or Writ Petition (Civil) No. 247 of 2017 & Ors. Page 101 countries or any decision made at
any international conference, association or other body.”
83) Mr. Divan, however, made an earnest endeavour to further broaden this concept of ‘limited
Government’ by giving an altogether different slant. He submitted that there are certain things that
the States simply cannot do because the action fundamentally alters the relationship between the
citizens and the State. In this hue, he submitted that it was impermissible for the State to undertake
the exercise of collection of bio-metric data, including fingerprints and storing at a central
depository as it puts the State in an extremely dominant position in relation to the individual
citizens. He also submitted that it will put the State in a position to target an individual and engage
in surveillance thereby depriving or withholding the enjoyment of his rights and entitlements, which
is totally impermissible in a country where governance of the State of founded on the concept of
‘limited Government’. Again, this concept of limited government is woven around Article 21 of the
Constitution.
84) Undoubtedly, we are in the era of liberalised democracy. In a democratic society governed by
the Constitution, there is a strong trend towards the Constitutionalisation of democratic politics,Binoy Visman vs Union Of India on 9 June, 2017

where the actions of democratic elected Government are judged Writ Petition (Civil) No. 247 of 2017
& Ors. Page 102 in the light of the Constitution. In this context, judiciary assumes the role of
protector of the Constitution and democracy, being the ultimate arbiter in all matters involving the
interpretation of the Constitution.
85) Having said so, when it comes to exercising the power of judicial review of a legislation, the
scope of such a power has to be kept in mind and the power is to be exercised within the limited
sphere assigned to the judiciary to undertake the judicial review. This has already been mentioned
above. Therefore, unless the petitioner demonstrates that the Parliament, in enacting the impugned
provision, has exceeded its power prescribed in the Constitution or this provision violates any of the
provision, the argument predicated on ‘limited governance’ will not succeed. One of the aforesaid
ingredients needs to be established by the petitioners in order to succeed.
86) Even in the case of Thakur Bharath Singh43 relied upon by Mr. Divan, wherein executive order
was passed imposing certain restrictions requiring the respondent therein to reside at a particular
place as specified in the order, which was passed in exercise of powers contained under Section
3(1)(b) of the M.P. 43 Footnote 9 above Writ Petition (Civil) No. 247 of 2017 & Ors. Page 103 Public
Security Act, 1959, the Court struck down and quashed the order only after it found that restrictions
contained therein were unreasonable and violative of fundamental freedom guaranteed under
Article 19(1)(d) and (e) of the Constitution of India.
87) With this, we proceed to consider the arguments on which vires of the impugned provisions are
questioned:
Argument of Legislative Competence
88) It is not denied by the petitioners that having regard to the provisions of Article
246 of the Constitution and Entries 82 and 97 of List I, the Parliament has requisite
competence to enact the impugned legislation. However, the submission of the
petitioners was that the impugned legislative provision was made as per which
enrolment under Aadhaar had become mandatory for the income tax assessees,
whereas this Court has passed various orders repeatedly emphasising that enrolment
for Aadhaar card has to be voluntary. On this basis, the argument is that the
Legislature lacked the authority to pass a law contrary to the judgments of this Court,
without removing the basis of those judgments. It was also argued that even Aadhaar
Act was voluntary in nature and the basis of the judgments of this Court could be
taken away only by making enrolment under the Writ Petition (Civil) No. 247 of 2017
& Ors. Page 104 Aadhaar Act compulsory, which was not done.
89) Before proceeding to discuss this argument, one aspect of the matter needs
clarification. There was a debate as to whether Aadhaar Act is voluntary or even that
Act makes enrolment under Aadhaar mandatory.Binoy Visman vs Union Of India on 9 June, 2017

90) First thing that is to be kept in mind is that the Aadhaar Act is enacted to enable
the Government to identify individuals for delivery of benefits, subsidies and services
under various welfare schemes. This is so mentioned in Section 7 of the Aadhaar Act
which states that proof of Aadhaar number is necessary for receipt of such subsidies,
benefits and services. At the same time, it cannot be disputed that once a person
enrols himself and obtains Aadhaar number as mentioned in Section 3 of the
Aadhaar Act, such Aadhaar number can be used for many other purposes. In fact, this
Aadhaar number becomes the Unique Identity (UID) of that person. Having said
that, it is clear that there is no provision in Aadhaar Act which makes enrolment
compulsory. May be for the purpose of obtaining benefits, proof of Aadhaar card is
necessary as per Section 7 of the Act. Proviso to Section 7 stipulates that if an
Aadhaar number is not assigned to enable an individual, he shall be offered alternate
and viable Writ Petition (Civil) No. 247 of 2017 & Ors. Page 105 means of
identification for delivery of the subsidy, benefit or service. According to the
petitioners, this proviso, with acknowledges alternate and viable means of
identification, and therefore makes Aadhaar optional and voluntary and the
enrolment is not necessary even for the purpose of receiving subsidies, benefits and
services under various schemes of the Government. The respondents, however,
interpret the proviso differently and there plea is that the words ‘if an Aadhaar
number is not assigned to an individual’ deal with only that situation where
application for Aadhaar has been made but for certain reasons Aadhaar number has
not been assigned as it may take some time to give Aadhaar card. Therefore, this
proviso is only by way of an interim measure till Aadhaar number is assigned, which
is otherwise compulsory for obtaining certain benefits as stated in Section 7 of the
Aadhaar Act. Fact remains that as per the Government and UIDAI itself, the
requirement of obtaining Aadhaar number is voluntary. It has been so claimed by
UIDAI on its website and clarification to this effect has also been issued by UIDAI.
91) Thus, enrolment under Aadhaar is voluntary. However, it is a moot question as to
whether for obtaining benefits as prescribed Writ Petition (Civil) No. 247 of 2017 &
Ors. Page 106 under Section 7 of the Aadhaar Act, it is mandatory to give Aadhaar
number or not is a debatable issue which we are not addressing as this very issue is
squarely raised which is the subject matter of other writ petition filed and pending in
this Court.
92) On the one hand, enrollment under Aadhaar card is voluntary, however, for the
purposes of Income Tax Act, Section 139AA makes it compulsory for the assessees to
give Aadhaar number which means insofar as income tax assessees are concerned,
they have to necessarily enroll themselves under the Aadhaar Act and obtain Aadhaar
number which will be their identification number as that has become the
requirement under the Income Tax Act. The contention that since enrollment under
Aadhaar Act is voluntary, it cannot be compulsory under the Income Tax Act, cannot
be countenanced. As already mentioned above, purpose for enrollment under the
Aadhaar Act is to avail benefits of various welfare schemes etc. as stipulated inBinoy Visman vs Union Of India on 9 June, 2017

Section 7 of the Aadhaar Act. Purpose behind Income Tax Act, on the other hand, is
entirely different which has already been discussed in detail above. For achieving the
said purpose, viz., to curb blackimongy, money laundering and tax evasion etc., if the
Parliament chooses to make the provision mandatory under the Income Tax Act, the
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 107 competence of the Parliament
cannot be questioned on the ground that it is impermissible only because under
Aadhaar Act, the provision is directory in nature. It is the prerogative of the
Parliament to make a particular provision directory in one statute and
mandatory/compulsory in other. That by itself cannot be a ground to question the
competence of the legislature. After all, Aadhaar Act is not a mother Act. Two laws,
i.e., Aadhaar Act, on the one hand, and law in the form of Section 139AA of the
Income Tax Act, on the other hand, are two different stand alone provisions/laws and
validity of one cannot be examined in the light of provisions of other Acts. In
Municipal Corporation of Delhi v. Shiv Shanker44, if the objects of two statutory
provisions are different and language of each statute is restricted to its own objects or
subject, then they are generally intended to run in parallel lines without meeting and
there would be no real conflict though apparently it may appear to be so on the
surface. We reproduce hereunder the discussion to the aforesaid aspect contained in
the said judgment:
“5. ... It is only when a consistent body of law cannot be maintained without
abrogation of the previous law that the plea of implied repeal should be sustained. To
determine if a later statutory provision repeals by implication an earlier one it is
accordingly necessary to closely scrutinise and consider the true meaning and effect
both of the earlier and the later statute. Until this
44 (1971) 1 SCC 442 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 108 is done it cannot be
satisfactorily ascertained if any fatal inconsistency exists between them. The meaning, scope and
effect of the two statutes, as discovered on scrutiny, determines the legislative intent as to whether
the earlier law shall cease or shall only be supplemented. If the objects of the two statutory
provisions are different and the language of each statute is restricted to its own objects or subject,
then they are generally intended to run in parallel lines without meeting and there would be no real
conflict though apparently it may appear to be so on the surface. Statutes in pari materia although in
apparent conflict, should also, so far as reasonably possible, be construed to be in harmony with
each other and it is only when there is an irreconcilable conflict between the new provision and the
prior statute relating to the same subject-matter, that the former, being the later expression of the
legislature, may be held to prevail, the prior law yielding to the extent of the conflict. The same rule
of irreconcilable repugnancy controls implied repeal of a general by a special statute. The
subsequent provision treating a phase of the same general subject-matter in a more minute way may
be intended to imply repeal protanto of the repugnant general provision with which it cannot
reasonably co-exist. When there is no inconsistency between the general and the special statute the
later may well be construed as supplementary.”Binoy Visman vs Union Of India on 9 June, 2017

93) In view of the above, we are not impressed by the contention of the petitioners that the two
enactments are contradictory with each other. A harmonious reading of the two enactments would
clearly suggests that whereas enrollment of Aadhaaar is voluntary when it comes to taking benefits
of various welfare schemes even if it is presumed that requirement of Section 7 of Aadhaar Act that
it is necessary to provide Aadhaar number to avail the benefits of schemes and services, it is upto a
person to avail those benefits Writ Petition (Civil) No. 247 of 2017 & Ors. Page 109 or not. On the
other hand, purpose behind enacting Section 139AA is to check a menace of black money as well as
money laundering and also to widen the income tax net so as to cover those persons who are
evading the payment of tax.
94) Main emphasis, however, is on the plea that Parliament or any State legislature cannot pass a
law that overrules a judgment thereby nullifying the said decision, that too without removing the
basis of the decision. This argument appears to be attractive inasmuch as few orders are passed by
this Court in pending writ petitions which are to the effect that the enrollment of Aadhaar would be
voluntary. However, it needs to be kept in mind that the orders have been passed in the petitions
where Aadhaar scheme floated as an executive/administrative measure has been challenged. In
those cases, the said orders are not passed in a case where the Court was dealing with a statute
passed by the Parliament. Further, these are interim orders as the Court was of the opinion that till
the matter is decided finally in the context of Right to Privacy issue, the implementation of the said
Aadhaar scheme would remain voluntary. In fact, the main issue as to whether Aadhaar card
scheme whereby biometric data of an individual is collected violates Right to Privacy and, therefore,
is offensive of Article 21 of the Constitution or not is yet to be Writ Petition (Civil) No. 247 of 2017 &
Ors. Page 110 decided. In the process, the Constitution Bench is also called upon to decide as to
whether Right to Privacy is a part of Article 21 of the Constitution at all. Therefore, no final decision
has been taken. In a situation like this, it cannot be said that Parliament is precluded from or it is
rendered incompetent to pass such a law. That apart, the argument of the petitioners is that the
basis on which the aforesaid orders are passed has to be removed, which is not done. According to
the petitioners, it could be done only by making Aadhaar Act compulsory. It is difficult to accept this
contention for two reasons: first, when the orders passed by this Court which are relied upon by the
petitioners were passed when Aadhaar Act was not even enacted. Secondly, as already discussed in
detail above, Aadhaar Act and the law contained in Section 139AA of the Income Tax Act deal with
two different situations and operate in different fields. This argument of legislature incompetence
also, therefore, has fails. Whether Section 139AA of the Act is discriminatory and offends Article 14
of the Constitution of India?
Article 14, which enshrines the principle of equality as a fundamental right mandates that the State
shall not deny to any person equality before the law or the equal protection of the laws within the
territory of India. It, thus, gives the right to equal Writ Petition (Civil) No. 247 of 2017 & Ors. Page
111 treatment in similar circumstances, both in privileges conferred and in the liabilities imposed. In
Sri Srinavasa Theatre & Ors. v. Government of Tamil Nadu & Ors.45, this Court explained that the
two expressions ‘equality before law’ and ‘equal protection of law’ do not mean the same thing even
if there may be much in common between them. “Equality before law” is a dynamic concept having
many facets. One facet is that there shall be no privileged person or class and that one shall be above
law. Another facet is “the obligation upon the State to bring about, through the machinery of law, aBinoy Visman vs Union Of India on 9 June, 2017

more equal society... For, equality before law can be predicated meaningfully only in an equal
society...”. The Court further observed that Article 14 prescribes equality before law. But the fact
remains that all persons are not equal by nature, attainment or circumstances, and, therefore, a
mechanical equality before the law may result in injustice. Thus, the guarantee against the denial of
equal protection of the law does not mean that identically the same rules of law should be made
applicable to all persons in spite of difference in circumstances or conditions {See Chiranjit Lal
Chowdhuri v. Union of India & Ors.46}.
95) The varying needs of different classes or sections of people 45 (1992) 2 SCC 643 46 1950 SCR
869 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 112 require differential and separate
treatment. The Legislature is required to deal with diverse problems arising out of an infinite variety
of human relations. It must, therefore, necessarily have the power of making laws to attain
particular objects and, for that purpose, of distinguishing, selecting and classifying persons and
things upon which its laws are to operate. The principle of equality of law, thus, means not that the
same law should apply to everyone but that a law should deal alike with all in one class; that there
should be an equality of treatment under equal circumstances. It means “that equals should not be
treated unlike and unlikes should not be treated alike. Likes should be treated alike.
96) What follows is that Article 14 forbids class legislation; it does not forbid reasonable
classification of persons, objects and transactions by the Legislature for the purpose of achieving
specific ends. Classification to be reasonable should fulfil the following two tests:
(1) It should not be arbitrary, artificial or evasive. It should be based on an intelligible
differentia, some real and substantial distinction, which distinguishes persons or
things grouped together in the class from others left out of it.
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 113 (2) The differentia adopted as
the basis of classification must have a rational or reasonable nexus with the object
sought to be achieved by the statute in question.
Thus, Article 14 in its ambit and sweep involves two facets, viz., it permits reasonable classification
which is founded on intelligible differentia and accommodates the practical needs of the society and
the differential must have a rational relation to the objects sought to be achieved. Further, it does
not allow any kind of arbitrariness and ensures fairness and equality of treatment. It is the fonjuris
of our Constitution, the fountainhead of justice. Differential treatment does not per se amount to
violation of Article 14 of the Constitution and it violates Article 14 only when there is no reasonable
basis and there are several tests to decide whether a classification is reasonable or not and one of the
tests will be as to whether it is conducive to the functioning of modern society.
97) Insofar as the impugned provision is concerned, Mr. Datar had conceded that first test that of
reasonable classification had been satisfied as he conceded that individual assesses form a separate
class and the impugned provision which targeted only individual assesses would not be
discriminatory on this ground. His whole Writ Petition (Civil) No. 247 of 2017 & Ors. Page 114
emphasis was that Section 139AA did not satisfy the second limb of the twin tests of classification as,Binoy Visman vs Union Of India on 9 June, 2017

according to him, this provision had no rational nexus with the object sought to be achieved.
98) In this behalf, his submission was that if the purpose of the provision was to curb circulation of
black money, such an object was not achievable by seeing PAN with Aadhaar inasmuch as Aadhaar
is only for individuals. His submission was that it is only the individuals who are responsible for
generating black money or money laundering. This was the basis for Mr. Datar’s submission. We
find it somewhat difficult to accept such a submission.
99) Unearthing black money or checking money laundering is to be achieved to whatever extent
possible. Various measures can be taken in this behalf. If one of the measures is introduction of
Aadhaar into the tax regime, it cannot be denounced only because of the reason that the purpose
would not be achieved fully. Such kind of menace, which is deep rooted, needs to be tackled by
taking multiple actions and those actions may be initiated at the same time. It is the combined effect
of these actions which may yield results and each individual action considered in isolation may not
be sufficient. Therefore, Writ Petition (Civil) No. 247 of 2017 & Ors. Page 115 rationality of a
particular measure cannot be challenged on the ground that it has no nexus with the objective to be
achieved. Of course, there is a definite objective. For this purpose alone, individual measure cannot
be ridiculed. We have already taken note of the recommendations of SIT on black money headed by
Justice M.B. Shah. We have also reproduced the measures suggested by the committee headed by
Chairman, CBDT on ‘Measures to tackle black money in India and Abroad’. They have, in no
uncertain terms, suggested that one singular proof of identity of a person for entering into
finance/business transactions etc may go a long way in curbing this foul practice. That apart, even if
solitary purpose of de-duplication of PAN cards is taken into consideration, that may be sufficient to
meet the second test of Article 14. It has come on record that 11.35 lakhs cases of duplicate PAN or
fraudulent PAN cards have already been detected and out of this 10.52 lakh cases pertain to
individual assessees. Seeding of Aadhaar with PAN has certain benefits which have already been
enumerated. Furthermore, even when we address the issue of shell companies, fact remains that
companies are after all floated by individuals and these individuals have to produce documents to
show their identity. It was sought to be argued that persons found with duplicate/bogus Writ
Petition (Civil) No. 247 of 2017 & Ors. Page 116 PAN cards are hardly 0.4% and, therefore, there was
no need to have such a provision. We cannot go by percentage figures. The absolute number of such
cases is 10.52 lakh, which figure, by no means, can be termed as miniscule, to harm the economy
and create adverse effect on the nation. Respondents have argued that Aadhaar will ensure that
there is no duplication of identity as bio-metric will not allow that and, therefore, it may check the
growth of shell companies as well.
100) Having regard to the aforesaid factors, it cannot be said that there is no nexus with the
objective sought to be achieved.
101) Another argument predicated on Article 14 advanced by Mr. Divan was that it was
discriminatory in nature as it created two classes; one class of those who volunteered to enrol
themselves under Aadhaar scheme and other class of those who did not want it to be so. It was
further submitted that in this manner this provision had the effect of creating an artificial class of
those who object to Aadhaar scheme as self conscious persons. This is a fallacious argument.Binoy Visman vs Union Of India on 9 June, 2017

102) Validity of a legislative act cannot be challenged by creating artificial classes by those who are
objecting to the said provision Writ Petition (Civil) No. 247 of 2017 & Ors. Page 117 and predicating
the argument of discrimination on that basis.
When a law is made, all those who are covered by that law are supposed to follow the same. No
doubt, it is the right of a citizen to approach the Court and question the constitutional validity of a
particular law enacted by the Legislature. However, merely because a section of persons opposes the
law, would not mean that it has become a separate class by itself. Two classes, cannot be created on
this basis, namely, one of those who want to be covered by the scheme, and others who do not want
to be covered thereby. If such a proposition is accepted, every legislation would be prone to
challenge on the ground of discrimination. As far as plea of discrimination is concerned, it has to be
raised by showing that the impugned law creates two classes without any reasonable classification
and treats them differently.
103) The principle of equality does not mean that every law must have universal application for all
persons who are not by nature, attainment or circumstances, in the same position, as the varying
needs of different classes of persons often require separate treatment. It is permissible for the State
to classify persons for legitimate purposes. The Legislature is also competent to Writ Petition (Civil)
No. 247 of 2017 & Ors. Page 118 exercise its discretion and make classification. In the present
scenario the impugned legislation has created two classes, i.e. one class of those persons who are
assessees and other class of those persons who are income tax assessees. It is because of the reason
that the impugned provision is applicable only to those who are filing income tax returns. Therefore,
the only question would be as to whether this classification is reasonable or not. There cannot be any
dispute that there is a reasonable basis for differentiation and, therefore, equal protection clause
enshrined in Article 14 is not attracted. What Article 14 prohibits is class legislation and not
reasonable classification for the purpose of legislation. All income tax asessees constitute one class
and they are treated alike by the impugned provision.
104) It may also be pointed out that the counsel for the respondents had argued that doctrine of
proportionality cannot be read into Article 14 of the Constitution and in support reliance has been
placed on the judgment of this Court in E.P. Royappa v. State of Tamil Nadu & Anr.47. This aspect
need not be considered in detail inasmuch as Mr. Datar, learned counsel appearing for the
petitioner, had conceded at the Bar that he had invoked the doctrine of proportionality only in the
context of Article 19(1)(g). 47 (1974) 4 SCC 3 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 119
105) We, therefore, reject the argument founded on Article 14 of the Constitution.
Whether impugned provision is violative of Article 19(1)(g)
106) Invocation of provisions of Article 19(1)(g) of the Constitution by the petitioners was in the
context of proviso to sub-section (2) of Section 139AA of the Act which contains the consequences of
the failure to intimate the Aadhaar number to such authority in such form and manner as may be
prescribed and reads as under:Binoy Visman vs Union Of India on 9 June, 2017

“(2) Every person who has been allotted permanent account number as on the 1st day
of July, 2017, and who is eligible to obtain Aadhaar number, shall intimate his
Aadhaar number to such authority in such form and manner as may be prescribed,
on or before a date to be notified by the Central Government in the Official Gazette:
Provided that in case of failure to intimate the Aadhaar number, the permanent
account number allotted to the person shall be deemed to be invalid and the other
provisions of this Act shall apply, as if the person had not applied for allotment of
permanent account number.”
107) The submission was that the aforesaid penal consequence was draconian in
nature and totally disproportionate to the non-compliance of provisions contained in
Section 139AA. It was pointed out that persons effected by Section 139AA are only
individuals, i.e. natural persons and not legal/artificial Writ Petition (Civil) No. 247
of 2017 & Ors. Page 120 personalities like companies, trusts, partnership firms, etc.
Thus, individuals who are professionals like lawyers, doctors, architects and lakhs of
businessmen having small or micro enterprises are going to suffer such a serious
consequence for failure to intimate Aadhaar number to the designated authority.
According to him, consequence of not having a PAN card results in a virtual ‘civil
death’ as one example given was that under Rule 114B of the Rules, it will not be
possible to operate bank accounts with transaction above Rs.50,000/- or to use
credit/debit cards or purchase motor vehicles or property etc.
108) Section 139A deals with PAN. Sub-section (1) thereof requires four classes of
persons to have the PAN allotted. It reads as under:
“139A. Permanent account number. – (1) Every person, –
(i) if his total income or the total income of any other person in respect of which he is
assessable under this Act during any previous year exceeded the maximum amount
which is not chargeable to income-tax; or
(ii) carrying on any business or profession whose total sales, turnover or gross
receipts are or is likely to exceed five lakh rupees in any previous year; or
(iii) who is required to furnish a return of income under sub-section (4A) of section
139; or
(iv) being an employer, who is required to furnish a Writ Petition (Civil) No. 247 of
2017 & Ors. Page 121 return of fringe benefits under section 115WD.
and who has not been allotted a permanent account number shall, within such time, as may be
prescribed, apply to the Assessing Officer for the allotment of a permanent account number.”Binoy Visman vs Union Of India on 9 June, 2017

109) This PAN number has to be mentioned/quoted in number of eventualities specified under
sub-section (5), (5A), (5B), (5C), 5(D) and sub-section (6) of Section 139A. These provisions read as
under:
“5. Every person shall –
(a) quote such number in all his returns to, or correspondence with, any income-tax
authority;
(b) quote such number in all challans for the payment of any sum due under this Act;
(c) quote such number in all documents pertaining to such transactions as may be
prescribed by the Board in the interests of the revenue, and entered into by him:
Provided that the Board may prescribe different dates for different transactions or
class of transactions or for different class of persons:
Provided further that a person shall quote General Index Register Number till such
time Permanent Account Number is allotted to such person;
(d) intimate the Assessing Officer any change in his address or in the name and
nature of his business on the basis of which the permanent account number was
allotted to him.
(5A) Every person receiving any sum or income or amount from which tax has been
deducted under the provisions of Chapter XVIIB, shall intimate his Writ Petition
(Civil) No. 247 of 2017 & Ors. Page 122 permanent account number to the person
responsible for deducting such tax under that Chapter:
Provided further that a person referred to in this sub-section, shall intimate the
General Index Register Number till such time permanent account number is allotted
to such person.
(5B) Where any sum or income or amount has been paid after deducting tax under
Chapter XVIIB, every person deducting tax under that Chapter shall quote the
permanent account number of the person to whom such sum or income or amount
has been paid by him–
(i) in the statement furnished in accordance with the provisions of sub-section (2C) of
section 192;
(ii) in all certificates furnished in accordance with the provisions of section 203;Binoy Visman vs Union Of India on 9 June, 2017

(iii) in all returns prepared and delivered or caused to be delivered in accordance
with the provisions of section 206 to any income-tax authority;
(iv) in all statements prepared and delivered or caused to be delivered in accordance
with the provisions of sub-section (3) of section 200:
Provided that the Central Government may, by notification in the Official Gazette,
specify different dates from which the provisions of this sub-section shall apply in
respect of any class or classes of persons:
Provided further that nothing contained in sub-sections (5A) and (5B) shall apply in
case of a person whose total income is not chargeable to income-tax or who is not
required to obtain permanent account number under any provision of this Act if such
person furnishes to the person responsible for deducting tax a declaration referred to
in section 197A in the form and manner prescribed thereunder to the effect that the
tax on his estimated total income of the previous year in which such income is to be
included in computing his total income will be nil.
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 123 (5C) Every buyer or licensee or
lessee referred to in section 206C shall intimate his permanent account number to
the person responsible for collecting tax referred to in that section.
(5D) Every person collecting tax in accordance with the provisions of section 206C
shall quote the permanent account number of every buyer or licensee or lessee
referred to in that section –
(i) in all certificates furnished in accordance with the provisions of sub-section (5) of
section 206C;
(ii) in all returns prepared and delivered or caused to be delivered in accordance with
the provisions of sub-section (5A) or sub-section (5B) of section 206C to an
income-tax authority;
(iii) in all statements prepared and delivered or caused to be delivered in accordance
with the provisions of sub-section (3) of section 206C.
(6) Every person receiving any document relating to a transaction prescribed under
clause (c) of sub-section (5) shall ensure that the Permanent Account Number or the
General Index Register Number has been duly quoted in the document.”
110) Sub-section (8) empowers the Board to make Rules, inter alia, prescribing the
categories of transactions in relation to which PAN is to be quoted. Rule 114B of the
Rules lists the nature of transaction in sub-rule (a) to (r) thereof where PAN number
is to be given.Binoy Visman vs Union Of India on 9 June, 2017

111) According to the petitioners, it amounts to violating their fundamental right to
carry on business/profession etc. as Writ Petition (Civil) No. 247 of 2017 & Ors. Page
124 enshrined under Article 19(1)(g) of the Constitution which stands infringed and,
therefore, it was for the State to show that the restriction is reasonable and in the
interest of pubic under Article 19(6) of the Constitution. It is in this context, principle
of proportionality has been invoked by the petitioners with their submission that
restriction is unreasonable as it is utterly disproportionate for committing breach of
Section 139AA of the Act.
112) As noted above, Mr. Datar had relied upon the judgment of this Court in Modern
Dental College & Research Centre 48 and submitted that while applying the test of
proportionality, the respondents were specifically required to demonstrate the that
measures undertaken are necessary in that there are no alternative measures that
may similarly achieve that same purpose with a lesser degree of limitation (narrow
tailoring) and also that there was proper relation between the importance of
achieving the proper purpose and the social importance of preventing the limitation
on the constitutional right, (balancing two competing interests).
113) In order to consider the aforesaid submissions we may bifurcate
48 Footnote 7 above Writ Petition (Civil) No. 247 of 2017 & Ors. Page 125 Section 139AA in two
parts, as follows:
(i) That portion of the provision which requires quoting of Aadhaar number
(sub-section(1)) and requirement of intimating Aadhaar number to the prescribed
authorities by these who are PAN holders (sub-section (2)).
(ii) Consequences of failure to intimate Aadhaar number to the prescribed authority
by specified date.
114) Insofar as first limb of Section 139AA of the Act is concerned, we have already
held that it was within the competence of the Parliament to make a provision of this
nature and further that it is not offensive of Article 14 of the Constitution. This
requirement, per se, does not find foul with Article 19(1)(g) of the Constitution either,
inasmuch as, quoting the Aadhaar number for purposes mentioned in sub-section (1)
or intimating the Aadhaar number to the prescribed authority as per the requirement
of sub-section (2) does not, by itself, impinge upon the right to carry on profession or
trade, etc. Therefore, it is not violative of Article 19(1)(g) of the Constitution either. In
fact, that is not even the argument of the petitioners. Entire emphasis of the
petitioners submissions, while addressing the arguments predicated on Article
19(1)(g) of the Constitution, is on the consequences that ensue in terms of Writ
Petition (Civil) No. 247 of 2017 & Ors. Page 126 proviso to sub-section (2) inasmuch
as it is argued, as recorded above, that the consequences provided will have the effect
of paralysing the right to carry on business/profession. Therefore, thrust is on theBinoy Visman vs Union Of India on 9 June, 2017

second part of Section 139AA of the Act, which we proceed to deal with, now.
115) At the outset, it may be mentioned that though PAN is issued under the
provisions of the Act (Section 139A), its function is not limited to giving this number
in the income-tax returns or for other acts to be performed under the Act, as
mentioned in sub-sections (5), (5A), (5B), 5(C), 5(D) and 6 of Section 139A. Rule 114B
of the Rules mandates quoting of this PAN in various other documents pertaining to
different kinds of transactions listed therein. It is for sale and purchase of immovable
property valued at Rs.5 lakhs or more; sale or purchase of motor vehicle etc., while
opening deposit account with a sum exceeding Rs.50,000/-
with a banking company; while making deposit of more than Rs.50,000/- in any account with Post
Office, savings bank; a contract of a value exceeding Rs.1 lakh for sale or purchase of securities as
defined under the Securities Contract (Regulation) Act, 1956; while opening an account with a
banking company; making an application for installation of a telephone connection; Writ Petition
(Civil) No. 247 of 2017 & Ors. Page 127 making payment to hotels and restaurants when such
payment exceeds Rs.25,000/- at any one time; while purchasing bank drafts or pay orders for an
amount aggregating Rs.50,000/- or more during any one day, when payment in cash; payment in
cash in connection with travel to any foreign country of an amount exceeding Rs.25,000/- at any
one time; while making payment of an amount of Rs.50,000/- or more to a mutual fund for
purchase of its units or for acquiring shares or debentures/bonds in a company or bonds issued by
the Reserve Bank of India; or when the transaction of purchase of bullion or jewellery is made by
making payment in cash to a dealer above a specified amount, etc. This shows that for doing many
activities of day to day nature, including in the course of business, PAN is to be given. Pithily put, in
the absence of PAN, it will not be possible to undertake any of the aforesaid activities though this
requirement is aimed at curbing the tax evasion. Thus, if the PAN of a person is withdrawn or is
nullified, it definitely amounts to placing restrictions on the right to do business as a business under
Article 19(1)(g) of the Act. The question would be as to whether these restrictions are reasonable
and, therefore, meet the requirement of clause (6) of Article 19. In this context, when ‘balancing’ is
to be done, doctrine of proportionality can be applied, which was Writ Petition (Civil) No. 247 of
2017 & Ors. Page 128 explained in the case of Modern Dental College & Research Centre49, in the
following manner:
“Doctrine of proportionality explained and applied
59. Undoubtedly, the right to establish and manage the educational institutions is a
fundamental right recognised under Article 19(1)(g) of the Act. It also cannot be
denied that this right is not “absolute” and is subject to limitations i.e. “reasonable
restrictions” that can be imposed by law on the exercise of the rights that are
conferred under clause (1) of Article 19. Those restrictions, however, have to be
reasonable. Further, such restrictions should be “in the interest of general public”,
which conditions are stipulated in clause (6) of Article 19, as under:Binoy Visman vs Union Of India on 9 June, 2017

“19. (6) Nothing in sub-clause (g) of the said clause shall affect the operation of any
existing law insofar as it imposes, or prevent the State from making any law
imposing, in the interests of the general public, reasonable restrictions on the
exercise of the right conferred by the said sub-clause, and, in particular, nothing in
the said sub-clause shall affect the operation of any existing law insofar as it relates
to, or prevent the State from making any law relating to—
(i) the professional or technical qualifications necessary for practising any profession
or carrying on any occupation, trade or business, or
(ii) the carrying on by the State, or by a corporation owned or controlled by the State,
of any trade, business, industry or service, whether to the exclusion, complete or
partial, of citizens or otherwise.”
60. Another significant feature which can be noticed from the reading of the
aforesaid clause is that the State is empowered to make any law relating to the
professional or technical qualifications necessary for
49 Footnote 7 above Writ Petition (Civil) No. 247 of 2017 & Ors. Page 129 practising any profession
or carrying on any occupation or trade or business. Thus, while examining as to whether the
impugned provisions of the statute and rules amount to reasonable restrictions and are brought out
in the interest of the general public, the exercise that is required to be undertaken is the balancing of
fundamental right to carry on occupation on the one hand and the restrictions imposed on the other
hand. This is what is known as “doctrine of proportionality”. Jurisprudentially, “proportionality” can
be defined as the set of rules determining the necessary and sufficient conditions for limitation of a
constitutionally protected right by a law to be constitutionally permissible. According to Aharon
Barak (former Chief Justice, Supreme Court of Israel), there are four sub-components of
proportionality which need to be satisfied [ Aharon Barak, Proportionality:
Constitutional Rights and Their Limitation(Cambridge University Press 2012).], a
limitation of a constitutional right will be constitutionally permissible if:
(i) it is designated for a proper purpose;
(ii) the measures undertaken to effectuate such a limitation are rationally connected
to the fulfilment of that purpose;
(iii) the measures undertaken are necessary in that there are no alternative measures
that may similarly achieve that same purpose with a lesser degree of limitation; and
finally
(iv) there needs to be a proper relation (“proportionality stricto sensu” or
“balancing”) between the importance of achieving the proper purpose and the social
importance of preventing the limitation on the constitutional right.Binoy Visman vs Union Of India on 9 June, 2017

61. Modern theory of constitutional rights draws a fundamental distinction between the scope of the
constitutional rights, and the extent of its protection. Insofar as the scope of constitutional rights is
concerned, it marks the outer boundaries of the said rights and defines its contents. The extent of its
protection prescribes the limitations on the exercises of the rights within its scope. In that sense, it
defines the justification for limitations that can be imposed on Writ Petition (Civil) No. 247 of 2017
& Ors. Page 130 such a right.
62. It is now almost accepted that there are no absolute constitutional rights and all such rights are
related. As per the analysis of Aharon Barak, two key elements in developing the modern
constitutional theory of recognising positive constitutional rights along with its limitations are the
notions of democracy and the rule of law. Thus, the requirement of proportional limitations of
constitutional rights by a sub-constitutional law i.e. the statute, is derived from an interpretation of
the notion of democracy itself. Insofar as the Indian Constitution is concerned, democracy is treated
as the basic feature of the Constitution and is specifically accorded a constitutional status that is
recognised in the Preamble of the Constitution itself. It is also unerringly accepted that this notion
of democracy includes human rights which is the cornerstone of Indian democracy. Once we accept
the aforesaid theory (and there cannot be any denial thereof), as a fortiori, it has also to be accepted
that democracy is based on a balance between constitutional rights and the public interests. In fact,
such a provision in Article 19 itself on the one hand guarantees some certain freedoms in clause (1)
of Article 19 and at the same time empowers the State to impose reasonable restrictions on those
freedoms in public interest. This notion accepts the modern constitutional theory that the
constitutional rights are related. This relativity means that a constitutional licence to limit those
rights is granted where such a limitation will be justified to protect public interest or the rights of
others. This phenomenon—of both the right and its limitation in the Constitution—exemplifies the
inherent tension between democracy's two fundamental elements. On the one hand is the right's
element, which constitutes a fundamental component of substantive democracy; on the other hand
is the people element, limiting those very rights through their representatives. These two constitute
a fundamental component of the notion of democracy, though this time in its formal aspect. How
can this tension be resolved? The answer is that this tension is not resolved by eliminating the
“losing” facet from the Constitution. Rather, the tension is resolved by way of a proper balancing of
the competing principles. This is one of the expressions of the multi-faceted nature of Writ Petition
(Civil) No. 247 of 2017 & Ors. Page 131 democracy. Indeed, the inherent tension between
democracy's different facets is a “constructive tension”. It enables each facet to develop while
harmoniously coexisting with the others. The best way to achieve this peaceful coexistence is
through balancing between the competing interests. Such balancing enables each facet to develop
alongside the other facets, not in their place. This tension between the two fundamental
aspects—rights on the one hand and its limitation on the other hand—is to be resolved by balancing
the two so that they harmoniously coexist with each other. This balancing is to be done keeping in
mind the relative social values of each competitive aspects when considered in proper context.
63. In this direction, the next question that arises is as to what criteria is to be adopted for a proper
balance between the two facets viz. the rights and limitations imposed upon it by a statute. Here
comes the concept of “proportionality”, which is a proper criterion. To put it pithily, when a law
limits a constitutional right, such a limitation is constitutional if it is proportional. The law imposingBinoy Visman vs Union Of India on 9 June, 2017

restrictions will be treated as proportional if it is meant to achieve a proper purpose, and if the
measures taken to achieve such a purpose are rationally connected to the purpose, and such
measures are necessary. This essence of doctrine of proportionality is beautifully captured by
Dickson, C.J. of Canada in R. v. Oakes, in the following words (at p.
138):
“To establish that a limit is reasonable and demonstrably justified in a free and
democratic society, two central criteria must be satisfied. First, the objective, which
the measures, responsible for a limit on a Charter right or freedom are designed to
serve, must be “of” sufficient importance to warrant overriding a constitutional
protected right or freedom … Second … the party invoking Section 1 must show that
the means chosen are reasonable and demonstrably justified. This involves “a form of
proportionality test…” Although the nature of the proportionality test will vary
depending on the circumstances, in each case courts will be required to balance the
interests of Writ Petition (Civil) No. 247 of 2017 & Ors. Page 132 society with those of
individuals and groups.
There are, in my view, three important components of a proportionality test. First,
the measures adopted must be … rationally connected to the objective. Second, the
means … should impair “as little as possible” the right or freedom in question …
Third, there must be a proportionality between the effects of the measures which are
responsible for limiting the Charter right or freedom, and the objective which has
been identified as of “sufficient importance”. The more severe the deleterious effects
of a measure, the more important the objective must be if the measure is to be
reasonable and demonstrably justified in a free and democratic society.”
64. The exercise which, therefore, is to be taken is to find out as to whether the limitation of
constitutional rights is for a purpose that is reasonable and necessary in a democratic society and
such an exercise involves the weighing up of competitive values, and ultimately an assessment based
on proportionality i.e. balancing of different interests.
65. We may unhesitatingly remark that this doctrine of proportionality, explained hereinabove in
brief, is enshrined in Article 19 itself when we read clause (1) along with clause (6) thereof. While
defining as to what constitutes a reasonable restriction, this Court in a plethora of judgments has
held that the expression “reasonable restriction” seeks to strike a balance between the freedom
guaranteed by any of the sub-clauses of clause (1) of Article 19 and the social control permitted by
any of the clauses (2) to (6). It is held that the expression “reasonable” connotes that the limitation
imposed on a person in the enjoyment of the right should not be arbitrary or of an excessive nature
beyond what is required in the interests of public. Further, in order to be reasonable, the restriction
must have a reasonable relation to the object which the legislation seeks to achieve, and must not go
in excess of that object (see P.P. Enterprises v. Union of India [P.P. Enterprises v. Union of India,
(1982) 2 SCC 33). At the same time, reasonableness of a restriction has to be determined Writ
Petition (Civil) No. 247 of 2017 & Ors. Page 133 in an objective manner and from the standpoint ofBinoy Visman vs Union Of India on 9 June, 2017

the interests of the general public and not from the point of view of the persons upon whom the
restrictions are imposed or upon abstract considerations (see Mohd. Hanif Quareshi v. State of
Bihar AIR 1958 SC 731). In M.R.F. Ltd. v. State of Kerala, (1998) 8 SCC 227, this Court held that in
examining the reasonableness of a statutory provision one has to keep in mind the following factors:
(1) The directive principles of State policy.
(2) Restrictions must not be arbitrary or of an excessive nature so as to go beyond the
requirement of the interest of the general public.
(3) In order to judge the reasonableness of the restrictions, no abstract or general
pattern or a fixed principle can be laid down so as to be of universal application and
the same will vary from case to case as also with regard to changing conditions,
values of human life, social philosophy of the Constitution, prevailing conditions and
the surrounding circumstances.
(4) A just balance has to be struck between the restrictions imposed and the social
control envisaged by Article 19(6).
(5) Prevailing social values as also social needs which are intended to be satisfied by
the restrictions.
(6) There must be a direct and proximate nexus or reasonable connection between
the restrictions imposed and the object sought to be achieved. If there is a direct
nexus between the restrictions, and the object of the Act, then a strong presumption
in favour of the constitutionality of the Act will naturally arise.”
116) Keeping in view the aforesaid parameters and principles in mind, we proceed to
discuss as to whether the ‘restrictions’ which would result in terms of proviso to
sub-section (2) of Section 139AA of Writ Petition (Civil) No. 247 of 2017 & Ors. Page
134 the Act are reasonable or not.
117) Let us revisit the objectives of Aadhaar, and in the process, that of Section 139AA
in particular.
118) By making use of the technology, a method is sought to be devised, in the form of
Aadhaar, whereby identity of a person is ascertained in a flawless manner without
giving any leeway to any individual to resort to dubious practices of showing multiple
identities or fictitious identities. That is why it is given the nomenclature ‘unique
identity’. It is aimed at securing advantages on different levels some of which are
described, in brief, below:
(i) In the first instance, as a welfare and democratic State, it becomes the duty of any
responsible Government to come out with welfare schemes for the upliftment ofBinoy Visman vs Union Of India on 9 June, 2017

poverty stricken and marginalised sections of the society. This is even the ethos of
Indian Constitution which casts a duty on the State, in the form of ‘Directive
Principles of State Policy’, to take adequate and effective steps for betterment of such
underprivileged classes.
State is bound to take adequate measures to provide education, health care, employment and even
cultural opportunities and social standing to these deprived and underprivileged classes. It Writ
Petition (Civil) No. 247 of 2017 & Ors. Page 135 is not that Government has not taken steps in this
direction from time to time. At the same time, however, harsh reality is that benefits of these
schemes have not reached those persons for whom that are actually meant.
India has achieved significant economic growth since independence. In particular, rapid economic
growth has been achieved in the last 25 years, after the country adopted the policy of liberalisation
and entered the era of, what is known as, globalisation. Economic growth in the last decade has been
phenomenal and for many years, the Indian economy grew at highest rate in the world. At the same
time, it is also a fact that in spite of significant political and economic success which has proved to
be sound and sustainable, the benefits thereof have not percolated down to the poor and the
poorest. In fact, such benefits are reaped primarily by rich and upper middle classes, resulting into
widening the gap between the rich and the poor. Jean Dreze & Amartya Sen eithly narrate the
position as under 50:
“Since India’s recent record of fast economic growth is often celebrated, with good
reason, it is extremely important to point to the fact that the societal reach of
economic progress in India has been remarkably limited. It is not only that the
income distribution has been getting more unequal in recent years (a characteristic
that India shares with China), but also that the rapid rise in real wages in China from
which the working classes have benefited greatly is not 50 An Uncertain Glory : India
and its Contradictions Writ Petition (Civil) No. 247 of 2017 & Ors. Page 136 matched
at all by India’s relatively stagnant real wages. No less importantly, the public
revenue generated by rapid economic growth has not been used to expand the social
and physical infrastructure in a determined and well-planned way (in this India is left
far behind by China). There is also a continued lack of essential social services (from
schooling and health care to the provision of safe water and drainage) for a huge part
of the population. As we will presently discuss, while India has been overtaking other
countries in the progress of its real income, it has been overtaken in terms of social
indicators by many of these countries, even within the region of South Asia itself (we
go into this question more fully in Chapter 3, ‘India in Comparative Perspective’).
To point to just one contrast, even though India has significantly caught up with China in terms of
GDP growth, its progress has been very much slower than China’s in indicators such as longevity,
literacy, child undernourishment and maternal mortality. In South Asia itself, the much poorer
economy of Bangladesh has caught up with and overtaken India in terms of many social indicators
(including life expectancy, immunization of children, infant mortality, child undernourishment and
girls’ schooling). Even Nepal has been catching up, to the extent that it now has many socialBinoy Visman vs Union Of India on 9 June, 2017

indicators similar to India’s, in spite of its per capita GDP being just about one third. Whereas
twenty years ago India generally had the second-best social indicators among the six South Asia
countries (India, Pakistan, Bangladesh, Sri Lanka, Nepal and Bhutan), it now looks second worst
(ahead only of problem-ridden Pakistan). India has been climbing up the ladder of per capita
income while slipping down the slope of social indicators.” It is in this context that not only
sustainable development is needed which takes care of integrating growth and development, thereby
ensuring that the benefit of economic growth is reaped by every citizen of this country, it also
becomes the duty of the Government in a welfare State to come out with various welfare Writ
Petition (Civil) No. 247 of 2017 & Ors. Page 137 schemes which not only take care of immediate
needs of the deprived class but also ensure that adequate opportunities are provided to such persons
to enable them to make their lives better, economically as well as socially. As mentioned above,
various welfare schemes are, in fact, devised and floated from time to time by the Government,
keeping aside substantial amount of money earmarked for spending on socially and economically
backward classes. However, for various reasons including corruption, actual benefit does not reach
those who are supposed to receive such benefits. One of the main reasons is failure to identify these
persons for lack of means by which identity could be established of such genuine needy class.
Resultantly, lots of ghosts and duplicate beneficiaries are able to take undue and impermissible
benefits. A former Prime Minister of this country51 has gone to record to say that out of one rupee
spent by the Government for welfare of the downtrodden, only 15 paisa thereof actually reaches
those persons for whom it is meant. It cannot be doubted that with UID/Aadhaar much of the
malaise in this field can be taken care of.
(ii) Menace of corruption and black money has reached alarming proportion in this country. It is
eating into the economic 51 Late Shri Rajiv Gandhi Writ Petition (Civil) No. 247 of 2017 & Ors. Page
138 progress which the country is otherwise achieving. It is not necessary to go into the various
reasons for this menace. However, it would be pertinent to comment that even as per the
observations of the Special Investigation Team (SIT) on black money headed by Justice M.B. Shah,
one of the reasons is that persons have the option to quote their PAN or UID or passport number or
driving licence or any other proof of identity while entering into financial/business transactions.
Because of this multiple methods of giving proofs of identity, there is no mechanism/system at
present to collect the data available with each of the independent proofs of ID. For this reason, even
SIT suggested that these databases be interconnected. To the same effect is the recommendation of
the Committee headed by Chairman, CBDT on measures to tackle black money in India and abroad
which also discusses the problem of money-laundering being done to evade taxes under the garb of
shell companies by the persons who hold multiple bogus PAN numbers under different names or
variations of their names. That can be possible if one uniform proof of identity, namely, UID is
adopted. It may go a long way to check and minimise the said malaise.
(iii) Thirdly, Aadhaar or UID, which has come to be known as Writ Petition (Civil) No. 247 of 2017 &
Ors. Page 139 most advanced and sophisticated infrastructure, may facilitate law enforcement
agencies to take care of problem of terrorism to some extent and may also be helpful in checking the
crime and also help investigating agencies in cracking the crimes. No doubt, going by aforesaid, and
may be some other similarly valid considerations, it is the intention of the Government to give
phillip to Aadhaar movement and encourage the people of this country to enroll themselves underBinoy Visman vs Union Of India on 9 June, 2017

the Aadhaar scheme.
119) Wether such a scheme should remain voluntary or it can be made mandatory imposing
compulsiveness on the people to be covered by Aadhaar is a different question which shall be
addressed at the appropriate stage. At this juncture, it is only emphasised that malafides cannot be
attributed to this scheme. In any case, we are concerned with the vires of Section 139AA of the
Income Tax Act, 1961 which is a statutory provision. This Court is, thus, dealing with the aspect of
judicial review of legislation. Insofar as this provision is concerned, the explanation of the
respondents in the counter affidavit, which has already been reproduced above, is that the primary
purpose of introducing this provision was to take care of the problem of multiple PAN cards
obtained in fictitious names. Such multiple cards in fictitious names are Writ Petition (Civil) No. 247
of 2017 & Ors. Page 140 obtained with the motive of indulging into money laundering, tax evasion,
creation and channelising of black money. It is mentioned that in a de-duplication exercises, 11.35
lakhs cases of duplicate PANs/fraudulent PANs have been detected. Out of these, around 10.52
lakhs pertain to individual assessees. Parliament in its wisdom thought that one PAN to one person
can be ensured by adopting Aadhaar for allottment of PAN to individuals. As of today, that is the
only method available i.e. by seeding of existing PAN with Aadhaar. It is perceived as the best
method, and the only robust method of de-duplication of PAN database. It is claimed by the
respondents that the instance of duplicate Aadhaar is almost non-existent. It is also claimed that
seeding of PAN with Aadhaar may contribute to widening of the tax case as well, by checking the tax
evasions and bringing in to tax hold those persons who are liable to pay tax but deliberately avoid
doing so. It would be apposite to quote the following discussion by the Comptroller and Auditor
General in its report for the year 2011:
“Widening of Tax Base The assessee base grew over the last five years from 297.9
lakh taxpayers in 2005-06 to 340.9 lakh taxpayers in 2009-10 at the rate of 14.4 per
cent.
The Department has different mechanisms available to enhance the assessee base which include
inspection Writ Petition (Civil) No. 247 of 2017 & Ors. Page 141 and survey, information sharing
with other tax departments and third party information available in annual information returns.
Automation also facilitates greater cross linking. Most of these mechanisms are available at the level
of assessing officers. The Department needs to holistically harness these mechanisms at macro level
to analyse the gaps in the assessee base. Permanent Account Numbers (PANs) issued upto March
2009 and March 2010 were 807.9 lakh and 958 lakh respectively. The returns filled in 2008-09 and
2009-10 were 326.5 lakh and 340.9 lakh respectively. The gap between PANs and the number of
returns filed was 617.1 lakh in 2009-10. The Board needs to identify the reasons for the gap and use
this information for appropriately enhancing the assessee base. The gap may be due to issuance of
duplicate PAN cards and death of some PAN card holders. The Department needs to put in place
appropriate controls to weed out the duplicate PANs and also update the position in respect of
deceased assessee. It is significant to note that the number of PAN card holders has increased by
117.7 per cent between 2005-06 to 2009-10 whereas the number of returns filed in the same period
has increased by 14.4 per cent only.Binoy Visman vs Union Of India on 9 June, 2017

(emphasis supplied) The total direct tax collection has increased by 128.8 per cent during the period
2005-06 to 2009-10. The increase in the tax collection was around nine times as compared to
increase in the assessee base. It should be the constant endeavour of the Department to ensure that
the entire assessee base, once correctly identified is duly meeting the entire tax liability. However,
no assurance could be obtained that the tax liability on the assessee is being assessed and collected
properly. This comment is corroborated in para 2.4.1 of Chapter 2 of this report where we have
mentioned about our detection of under charge of tax amouting to Rs. 12,842.7 crore in 19,230 cases
audited during 2008-09. However, given the fact that ours is a test audit, Department needs to take
firm steps towards strengthening the controls available on the existing statutes towards deriving an
assurance on the tax collections.” Writ Petition (Civil) No. 247 of 2017 & Ors. Page 142
120) Likewise, the Finance Minister in his Budget speech in February, 2013 described the extent of
tax evasion and offering lesser income tax than what is actually due thereby labelling India as tax
known compliance, with the following figures:
“India’s tax to GDP ratio is very law, and the proportion of direct tax to indirect tax is
not optional from the view point of social justice. I place before you certain data to
indicate that our direct tax collection is not commensurate with the income and
consumption pattern of Indian economy. As against estimated 4.2 crore persons
engaged in organized sector employment, the number of individuals filing return for
salary income are only 1.74 crore. As against 5.6 crore informal sector individual
enterprises and firms doing small business in India, the number of returns filed by
this category are only 1.81 crore. Out of the 13.94 lakh companies registered in India
up to 31th March, 2014, 5.97 lakh companies have filed their returns for Assessment
Year 2016-17. Of the 5.97 lakh companies which have filed their returns for
Assessment Year 2016-17 so far, as many as 2.76 lakh companies have shown losses
or zero income. 2.85 lakh companies have shown profit before tax of less than Rs. 1
crore. 28,667 companies have shown profit between Rs. 1 crore to Rs. 10 crore, and
only 7781 companies have profit before tax of more than Rs.10 crores. Among the 3.7
crore individuals who filed the tax returns in 2015-16, 99 lakh show income below the
exemption limit of Rs. 2.5 Lakh p.a. 1.95 crore show income between Rs. 2.5 to Rs. 5
lakh, 52 lakh show income between Rs. 5 to Rs. 10 lakhs and only 24 lakh people
show income above Rs. 10 lakhs.
Of the 76 lakhs individual assesses who declare income above Rs. 5 lakhs, 56 lakhs are in the
salaried class. The number of people showing income more than 50 lakhs in the entire country is
only 1.72 lakh. We can contrast this with the fact that in the last five years, more than 1.25 crore cars
have been sold, and number of Indian citizens who flew abroad, either for business or tourism, is 2
crore in the year 2015. From all these figures we can conclude that we are largely a tax
non-compliant society. The predominance of the Writ Petition (Civil) No. 247 of 2017 & Ors. Page
143 cash in the economy makes it possible for the people to evade their taxes. When too many
people evade the taxes, the burden of their share falls on those who are honest and complaint.”Binoy Visman vs Union Of India on 9 June, 2017

121) The respondents have also claimed that linking of Aadhaar with PAN is consistent with India’s
international obligations and goals. In this behalf, it is pointed out that India has signed the
Inter-Governmental Agreement (IGA) with the USA on July 9, 2015, for Improving International
Tax Compliance and implementing the Foreign Account Tax Compliance Act (FATCA). India has
also signed a multilateral agreement on June 3, 2015, to automatically exchange information based
on Article 6 of the Convention on Mutual Administrative Assistance in Tax Matters under the
Common Reporting Scheme (CRS), formally referred to as the Standard for Automatic Exchange of
Financial Account Information (AEoI). As part of India’s commitment under FATCA and CRS,
financial sector entities capture the details about the customers using the PAN. In case the PAN or
submitted details are found to be incorrect or fictitious, it will create major embarrassment for the
country. Under Non-filers Monitoring System (NMS), Income Tax Department identifies non-filers
with potential tax liabilities. Data analysis is carried out to identify non-filers about whom specific
information was available in AIR, Writ Petition (Civil) No. 247 of 2017 & Ors. Page 144 CIB data and
TDS/TCS Returns. Email/SMS and letters are sent to the identified non-filers communicating the
information summary and seeking to know the submission details of Income tax return. In a large
number of cases (more than 10 lac PAN every year) it is seen that the PAN holder neither submits
the response and in many cases the letters are return unserved. Field verification by fields
formations have found that in a large number of cases, the PAN holder is untraceable. In many
cases, the PAN holder mentions that the transaction does not relate to them. There is a need to
strengthen PAN by linking it with Aadhaar/biometric information to prevent use of wrong PAN for
high value transactions.
122) While considering the aforesaid submission of the petitioners, one has to keep in mind the
aforesaid purpose of the impugned provision and what it seeks to achieve. The provision is aimed at
seeding Aadhaar with PAN. We have already held, while considering the submission based on
Article 14 of the Constitution, that the provision is based on reasonable classification and that has
nexus with the objective sought to be achieved. One of the main objectives is to de-duplicate PAN
cards and to bring a situation where one person is not having Writ Petition (Civil) No. 247 of 2017 &
Ors. Page 145 more than one PAN card or a person is not able to get PAN cards in
assumed/fictitious names. In such a scenario, if those persons who violate Section 139AA of the Act
without any consequence, the provision shall be rendered toothless. It is the prerogative of the
Legislature to make penal provisions for violation of any law made by it. In the instant case,
requirement of giving Aadhaar enrolment number to the designated authority or stating this
number in the income tax returns is directly connected with the issue of duplicate/fake PANs.
123) At this juncture, we will also like to quote the following passages from the nine Judge Bench
judgment of this Court in Jindal Stainless Ltd.52, which discussion though is in different context,
will have some relevance to the issue at hand as well:
“109. It was next argued on behalf of the dealers that an unreasonably high rate of tax
could by itself constitute a restriction offensive to Article 301 of the Constitution. This
was according to learned counsel for the dealers acknowledged even in the minority
judgment delivered by Sinha, CJ in Atiabari's case (supra). If that be so, the only way
such a restriction could meet the constitutional requirements would be through theBinoy Visman vs Union Of India on 9 June, 2017

medium of the proviso to Article 304(b) of the Constitution. There is, in our opinion,
no merit in that contention either and we say so for two precise reasons. Firstly,
because taxes whether high or low do not constitute restrictions on the freedom of
trade and commerce. We have held so in the previous paragraphs of the judgment
based on our textual understanding of the provisions of Part XIII which is matched
by the contextual interpretation. That being 52 Footnote 40 above Writ Petition
(Civil) No. 247 of 2017 & Ors. Page 146 so the mere fact that a tax casts a heavy
burden is no reason for holding that it is a restriction on the freedom of trade and
commerce. Any such excessive tax burden may be open to challenge under Part III of
the Constitution but the extent of burden would not by itself justify the levy being
struck down as a restriction contrary to Article 301 of the Constitution.
110. Secondly because, levy of taxes is both an attribute of sovereignty and an
unavoidable necessity.
No responsible government can do without levying and collecting taxes for it is only through taxes
that governments are run and objectives of general public good achieved. The conceptual or juristic
basis underlying the need for taxation has not, therefore, been disputed by learned counsel for the
dealers and, in our opinion, rightly so. That taxation is essential for fulfilling the needs of the
government is even otherwise well-settled. A reference to “A Treatise on the Constitutional
Limitations” (8th Edn. 1927 - Vol. II Page 986) by Thomas M Cooley brings home the point with
commendable clarity. Dealing with power of taxation Cooley says:
“Taxes are defined to be burdens or charges imposed by the legislative power upon
persons or property, to raise money for public purposes. The power to tax rests upon
necessity, and is inherent in every sovereignty. The legislature of every free State will
possess it under the general grant of legislative power, whether particularly specified
in the constitution among the powers to be exercised by it or not. No constitutional
government can exist without it, and no arbitrary government without regular and
steady taxation could be anything but an oppressive and vexatious despotism, since
the only alternative to taxation would be a forced extortion for the needs of
government from such persons or objects as the men in power might select as
victims.”
111. Reference may also be made to the following passage appearing in McCulloch v.
Maryland, 17 US 316 (1819) where Chief Justice Marshall recognized Writ Petition
(Civil) No. 247 of 2017 & Ors. Page 147 the power of taxation and pointed out that the
only security against the abuse of such power lies in the structure of the government
itself. The court said:
“43. ..It is admitted that the power of taxing the people and their property is essential
to the very existence of government, and may be legitimately exercised on the objects
to which it is applicable to the utmost extent to which the government may choose to
carry it. The only security against the abuse of this power is found in the structure ofBinoy Visman vs Union Of India on 9 June, 2017

the government itself. In imposing a tax, the legislature acts upon its constituents.
This is, in general, a sufficient security against erroneous and oppressive taxation.
44. The people of a State, therefore, give to their government a right of taxing
themselves and their property; and as the exigencies of the government cannot be
limited, they prescribe no limits to the exercise of this right, resting confidently on
the interest of the legislator, and on the influence of the constituents over their
representative, to guard them against its abuse.”
112. To the same effect is the decision of this Court in State of Madras v. N.K.
Nataraja Mudaliar (AIR 1969 SC 147) where this Court recognized that political and
economic forces would operate against the levy of an unduly high rate of tax. The
Court said:
“16.… Again, in a democratic constitution political forces would operate against the
levy of an unduly high rate of tax. The rate of tax on sales of a commodity may not
ordinarily be based on arbitrary considerations, but in the light of the facility of trade
in a particular commodity, the market conditions internal and external - and the
likelihood of consumers not being scared away by the price which includes a high rate
of tax. Attention must also be directed sub-Section (5) of Section 8 which authorizes
the State Government, notwithstanding anything contained in Section 8, in the public
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 148 interest to waive tax or impose
tax on sales at a lower rate on inter-State trade or commerce. It is clear that the
legislature has contemplated that elasticity of rates consistent with economic forces is
clearly intended to be maintained.”
124) Therefore, it cannot be denied that there has to be some provision stating the
consequences for not complying with the requirements of Section 139AA of the Act,
more particularly when these requirements are found as not violative of Articles 14
and 19 (of course, eschewing the discussion on Article 21 herein for the reasons
already given). If Aadhar number is not given, the aforesaid exercise may not be
possible.
125) Having said so, it becomes clear from the aforesaid discussion that those who are not PAN
holders, while applying for PAN, they are required to give Aadhaar number. This is the stipulation of
sub-section (1) of Section 139AA, which we have already upheld. At the same time, as far as existing
PAN holders are concerned, since the impugned provisions are yet to be considered on the
touchstone of Article 21 of the Constitution, including on the debate around Right to Privacy and
human dignity, etc. as limbs of Article 21, we are of the opinion that till the aforesaid aspect of
Article 21 is decided by the Constitution Bench a partial stay of the aforesaid proviso is necessary.
Those who have already Writ Petition (Civil) No. 247 of 2017 & Ors. Page 149 enrolled themselves
under Aadhaar scheme would comply with the requirement of sub-section (2) of Section 139AA of
the Act. Those who still want to enrol are free to do so. However, those assessees who are not
Aadhaar card holders and do not comply with the provision of Section 139(2), their PAN cards beBinoy Visman vs Union Of India on 9 June, 2017

not treated as invalid for the time being. It is only to facilitate other transactions which are
mentioned in Rule 114B of the Rules. We are adopting this course of action for more than one
reason. We are saying so because of very severe consequences that entail in not adhering to the
requirement of sub-section (2) of Section 139AA of the Act. A person who is holder of PAN and if his
PAN is invalidated, he is bound to suffer immensely in his day to day dealings, which situation
should be avoided till the Constitution Bench authoritatively determines the argument of Article 21
of the Constitution. Since we are adopting this course of action, in the interregnum, it would be
permissible for the Parliament to consider as to whether there is a need to tone down the effect of
the said proviso by limiting the consequences.
126) However, at the same time, we find that proviso to Section 139AA(2) cannot be read
retrospectively. If failure to intimate the Aadhaar number renders PAN void ab initio with the
deeming provision that the PAN allotted would be invalid as if the person Writ Petition (Civil) No.
247 of 2017 & Ors. Page 150 had not applied for allotment of PAN would have rippling effect of
unsettling settled rights of the parties. It has the effect of undoing all the acts done by a person on
the basis of such a PAN. It may have even the effect of incurring other penal consequences under the
Act for earlier period on the ground that there was no PAN registration by a particular assessee. The
rights which are already accrued to a person in law cannot be taken away. Therefore, this provision
needs to be read down by making it clear that it would operate prospectively.
127) Before we part with, few comments are needed, as we feel that these are absolutely essential:
(i) Validity of Aadhaar, whether it is under the Aadhaar scheme or the Aadhaar Act, is
already under challenge on the touchstone of Article 21 of the Constitution. Various
facets of Article 21 are pressed into service. First and foremost is that it violates Right
to Privacy and Right to Privacy is part of Article 21 of the Constitution. Secondly, it is
also argued that it violates human dignity which is another aspect of Article 21 of the
Constitution.
Since the said matter has already been referred to the Constitution Bench, we have consciously
avoided discussion, though submissions in this behalf have been taken note of. We feel that all the
aspect of Article 21 needs to be dealt with by the Writ Petition (Civil) No. 247 of 2017 & Ors. Page 151
Constitution Bench. That is a reason we have deliberately refrained from entering into the said
arena.
(ii) It was submitted by the counsel for the petitioners themselves that they would be confining their
challenge to the impugned provision on Articles 14 and 19 of the Constitution as well as competence
of the Legislature, while addressing the arguments, other facets of Article 21 of the Constitution
were also touched upon. Since we are holding that Section 139AA of the Income Tax Act is not
violative of Articles 14 and 19(1)(g) of the Constitution and also that there was no impediment in the
way of Parliament to insert such a statutory provision (subject to reading down the proviso to
sub-section (2) of Section 139AA of the Act as given above), we make it clear that the impugned
provision has passed the muster of Articles 14 and 19(1)(g) of the Constitution. However, more
stringent test as to whether this statutory provision violates Article 21 or not is yet to be qualified.Binoy Visman vs Union Of India on 9 June, 2017

Therefore, we make it clear that Constitutional validity of this provision is upheld subject to the
outcome of batch of petitions referred to the Constitution Bench where the said issue is to be
examined.
(iii) It is also necessary to highlight that a large section of citizens feel concerned about possible data
leak, even when Writ Petition (Civil) No. 247 of 2017 & Ors. Page 152 many of those support linkage
of PAN with Aadhaar. This is a concern which needs to be addressed by the Government. It is
important that the aforesaid apprehensions are assuaged by taking proper measures so that
confidence is instilled among the public at large that there is no chance of unauthorised leakage of
data whether it is done by tightening the operations of the contractors who are given the job of
enrollment, they being private persons or by prescribing severe penalties to those who are found
guilty of leaking the details, is the outlook of the Government. However, we emphasise that
measures in this behalf are absolutely essential and it would be in the fitness of things that proper
scheme in this behalf is devised at the earliest.
128) Subject to the aforesaid, these writ petitions are disposed of in the following manner:
(i) We hold that the Parliament was fully competent to enact Section 139AA of the Act
and its authority to make this law was not diluted by the orders of this Court.
(ii) We do not find any conflict between the provisions of Aadhaar Act and Section
139AA of the Income Tax Act inasmuch as when interpreted harmoniously, they
operate in distinct fields.
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 153
(iii) Section 139AA of the Act is not discriminatory nor it offends equality clause
enshrined in Article 14 of the Constitution.
(iv) Section 139AA is also not violative of Article 19(1)(g) of the Constitution insofar
as it mandates giving of Aadhaar enrollment number for applying PAN cards in the
income tax returns or notified Aadhaar enrollment number to the designated
authorities. Further, proviso to sub-section (2) thereof has to be read down to mean
that it would operate only prospective.
(v) The validity of the provision upheld in the aforesaid manner is subject to passing
the muster of Article 21 of the Constitution, which is the issue before the Constitution
Bench in Writ Petition (Civil) No. 494 of 2012 and other connected matters. Till then,
there shall remain a partial stay on the operation of proviso to sub-section (2) of
Section 139AA of the Act, as described above.
No costs.Binoy Visman vs Union Of India on 9 June, 2017

.............................................J. (A.K. SIKRI) .............................................J. (ASHOK BHUSHAN)
NEW DELHI;
JUNE 09, 2017.
Writ Petition (Civil) No. 247 of 2017 & Ors.                                      Page 154
ITEM NO.5                            COURT NO.4             SECTION - X
(For judgment)
                   S U P R E M E C O U R T O F          I N D I A
                           RECORD OF PROCEEDINGS
                              WRIT PETITION(C)247 OF 2017
BINOY VISWAM                                                        Petitioner(s)
                                              VERSUS
UNION OF INDIA & ORS.                                               Respondent(s)
With
Date : 09/06/2017 These petitions were called on for judgment today. For Petitioner(s) Mr.Salman
Khurshid, Sr.Adv.
Mr.Vishnu Shankar Jain, Adv.
Mr.Deepak Joshi, Adv.
Mr.I.K.M.Mairom, Adv.
Mr.Sriram P., Adv.
Mr.Pratap Venugopal, Adv.
Ms.Surekha Raman, Adv.
Mr.Udayaditya Banerjee, Adv.
Mr.Prasanna S., Adv.
Ms.Niharika, Adv.Binoy Visman vs Union Of India on 9 June, 2017

Ms.Sameeksha G., Adv.
Mr.Apaar Gupta, Adv.
For M/s K.J.John & Co., Adv.
Mr.Anando Mukherjee, Adv.
For Respondent(s) Ms.Sadhna Sandhu, Adv.
Ms.Rashmi Malhotra, Adv.
Mr.Zoheb Hossain, Adv.
Mr.Arghya Sengupta, Adv.
Ms.Ranjeeta Rohatgi, Adv.
Mr.Ritesh Kumar, Adv.
Mr.Abhinav Mukherji, Adv.
Mr.Saurabh Kirpal, Adv.
Mr.A.Gulati, Adv.
Ms.Anil Katiyar, Adv.
Writ Petition (Civil) No. 247 of 2017 & Ors. Page 155 Hon'ble Mr.Justice A.K.Sikri pronounced the
judgment of the Bench comprising His Lordship and Hon'ble Mr.Justice Ashok Bhushan.
These writ petitions are disposed of in the following manner:
(i) We hold that the Parliament was fully competent to enact Section 139AA of the Act
and its authority to make this law was not diluted by the orders of this Court.
(ii) We do not find any conflict between the provisions of Aadhaar Act and Section
139AA of the Income Tax Act inasmuch as when interpreted harmoniously, they
operate in distinct fields.
(iii)Section 139AA of the Act is not discriminatory nor it offends equality clause
enshrined in Article 14 of the Constitution.Binoy Visman vs Union Of India on 9 June, 2017

(iv) Section 139AA is also not violative of Article 19(1)(g) of the Constitution insofar
as it mandates giving of Aadhaar enrollment number for applying PAN cards in the
income tax returns or notified Aadhaar enrollment number to the designated
authorities. Further, proviso to sub-section (2) thereof has to be read down to mean
that it would operate only prospective.
(v) The validity of the provision upheld in the aforesaid manner is subject to passing
the muster of Article 21 of the Constitution, which is the issue before the Constitution
Bench in Writ Petition (Civil) No. 494 of 2012 and other connected matters. Till then,
there shall remain a partial stay on the operation of proviso to sub-section (2) of
Section 139AA of the Act, as described above.
No costs.
(SATISH KUMAR YADAV)                             (H.S.PARASHER)
     AR-CUM-PS                                     COURT MASTER
(Signed reportable judgment is placed on the file) Writ Petition (Civil) No. 247 of 2017 & Ors. Page
156 Writ Petition (Civil) No. 247 of 2017 & Ors. Page 157Binoy Visman vs Union Of India on 9 June, 2017

