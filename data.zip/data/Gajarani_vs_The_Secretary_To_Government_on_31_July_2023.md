Gajarani vs The Secretary To Government on 31 July, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                                H.C.P.No.489 of 2023
                                      IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                    DATED : 31.07.2023
                                                          CORAM
                                        THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                       and
                                       THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                  H.C.P.No.489 of 2023
                     Gajarani                                                      .. Petitioner
                                                            Vs
                     1. The Secretary to Government,
                        Home, Prohibition and Excise Department,
                        Secretariat, Fort St. George, Chennai -9.
                     2. The Commissioner of Police,
                        Avadi City, Office of the Commissioner of Police
                        (Goondas Section), Avadi, Chennai – 54.
                     3.The Superintendent of Prison,
                       Central Prison, Puzhal, Chennai.
                     4.State rep. By its
                       The Inspector of Police,
                       T-11 Thiruninravur Police Station,
                       Chennai.                                                 .. Respondents
                                  Petition filed under Article 226 of the Constitution of India
                     praying for issuance of a writ of habeas corpus to call for the entire
                     records relating to the petitioner's son detention under Tamil Nadu
                     Act 14 of 1982 vide detention order dated 15.02.2023 on the file of
                     the           second    respondent    made     in    proceedings       Memo
                     Page Nos.1/9Gajarani vs The Secretary To Government on 31 July, 2023

https://www.mhc.tn.gov.in/judis
                                                                                           H.C.P.No.489 of 2023
                     No.41/BCDFGISSSV/2023 quash the same as illegal and consequently
                     direct the respondents herein to produce the petitioner's son namely
                     Arun Babu @ Aron, S/o.Babu, aged 27 years before this Court and set
                     the petitioner's son at liberty from detention, now the petitioner's son
                     detained at Central Prison, Puzhal, Chennai.
                                  For Petitioner             :      Mr.R.Sasikumar
                                  For Respondents            :      Mr.E.Raj Thilak
                                                                    Additional Public Prosecutor
                                                            ORDER
[Order of the Court was made by M.SUNDAR, J.,] When the captioned 'Habeas Corpus Petition'
(hereinafter 'HCP' for the sake of convenience and clarity) was listed in the Admission Board on
30.03.2023, this Court made the following order:
'Captioned Habeas Corpus Petition has been filed in this Court on 23.03.2023 inter
alia assailing a detention order dated 15.02.2023 bearing reference
No.41/BCDFGISSSV/2023 made by 'second respondent' [hereinafter 'Detaining
Authority' for the sake of convenience and clarity]. To be noted, fourth respondent is
the Sponsoring Authority.
2. To be noted, mother of the detenu is the petitioner.
3. Mr.R.Sasikumar, learned counsel on record for habeas corpus petitioner is before us. Learned
counsel for petitioner submits that ground case qua the detenu is for the alleged offences under
Sections 341, 294(b), 323, 336, 397 and 506(ii) of 'The Indian Penal Code (45 of 1860)' [hereinafter
'IPC' for the sake of convenience and clarity] in Crime No.16 of 2023 on the file of T-11
Thirunindravur Police Station.
https://www.mhc.tn.gov.in/judis
4. The aforementioned detention order has been made on the premise that the detenu is a 'Goonda'
under Section 2(f) of 'The Tamil Nadu Prevention of Dangerous Activities of Bootleggers, Cyber law
offenders, Drug-offenders, Forest- offenders, Goondas, Immoral traffic offenders, Sand-offenders,
Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)'
[hereinafter 'Act 14 of 1982' for the sake of convenience and clarity].
5. The detention order has been assailed inter alia on the ground that some of the pages in the
booklet furnished to the detenu were illegible, which prevented the detenu from making an effective
representation.Gajarani vs The Secretary To Government on 31 July, 2023

6. Prima facie case made out for admission. Admit. Issue Rule nisi returnable by four weeks.
7. Mr.R.Muniyapparaj, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice for
all respondents. List the captioned Habeas Corpus Petition accordingly. '
2. The aforementioned order made in the 30.03.2023 Admission listing shall be read as an integral
part and parcel of this order which means that the short forms, short references and abbreviations
used in the order in the Admission listing shall be used in the instant order also.
3. There are three adverse cases. The ground case which constitutes substantial part of substratum
of the impugned preventive detention order is Crime No.16 of 2023 on the file of T-11
https://www.mhc.tn.gov.in/judis Thirunindravur Police Station for the alleged offences under
Sections 341, 294(b), 323, 336, 397 and 506(ii) of IPC. Owing to the nature of the challenge to the
impugned detention order, it is not necessary to delve into the factual matrix or be detained further
by facts.
4. Mr.R.Sasikumar, learned counsel on record for petitioner and Mr.E.Raj Thilak, learned State
Additional Public Prosecutor for all respondents are before us.
5. As would be evident from the Admission Board order dated 30.03.2023, at the time of admission,
learned counsel for HCP petitioner projected the point that some of the pages in the booklet
furnished to the detenu are not legible, however, in the Final Hearing Board today, learned counsel
for petitioner pivoted his campaign against the impugned preventive detention order on the
incorrect/improper translation point. Learned counsel drew our attention to the similar case bail
order relied on by the detaining authority in Aravind's case vide Crl.M.P.No.1759 of 2018 dated
01.02.2018 on the file of the Principal Sessions Judge, Chennai, at pages 174 and 175 of the grounds
booklet and submitted that the bail https://www.mhc.tn.gov.in/judis order has not been fully
translated. We had the benefit of perusing the grounds booklet served on the detenu and we have no
reason to disagree with the learned counsel for petitioner. English version of bail order dated
01.02.2018 says 'Major portion of investigation might have been completed by this time. The
murder case pending against the petitioner is of the year 2012 and another case of the year 2014...'
whereas the Tamil version says ',th; kPJ Vw;fdnt bfhiy tHf;F kw;Wk; bfhiy Kaw;rp tHf;F cs;sJ and it
also says tprhuiz KGikahf Kot[ bgw;Ws;sjhy;///'
6. We are informed that the literacy level of the detenu is 12th standard and he is a school drop out.
We are also informed that the detenu is conversant only with Tamil.
7. In this view of the matter, we find that flaw in the translation is very serious and it certainly
affects the rights of the detenu to make an effective representation which are rights and
constitutional safeguard enshrined in Article 22(5) of the Constitution of India. We remind
ourselves of Powanammal case which also on facts arose out of the preventive detention case. In
Powanammal case in similar https://www.mhc.tn.gov.in/judis circumstances i.e., similar fact
situation, Honourable Supreme Court addressed to itself the issue of providing a detenu with
translated copies in a language in which the detenu is conversant with and answered the sameGajarani vs The Secretary To Government on 31 July, 2023

interalia by saying that it is imperative and not providing translated copy in a language which the
detenu is conversant with vitiates preventive detention. Powanammal case i.e., Powanammal Vs.
State of Tamil Nadu is reported in (1999) 2 SCC 413 and the relevant paragraphs wherein the
question which the Honourable Supreme Court addressed to itself and the manner in which the
question was answered are paragraphs 6 and 16 which read as follows:
'6. The short question that falls for our consideration is whether failure to supply the
Tamil version of the order of remand passed in English, a language not known to the
detenue, would vitiate her further detention.
16. For the above reasons, in our view, the non-supply of the Tamil version of the
English document, on the facts and in the circumstances, renders her continued
detention illegal. We, therefore, direct that the detenue be set free forthwith unless
she is required to be detained in any other case. The appeal is accordingly allowed. '
8. Applying Powanammal principle, we have no hesitation in
https://www.mhc.tn.gov.in/judis saying that the impugned preventive detention
order in the case on hand deserves to be dislodged.
9. Ergo, the sequitur is, captioned HCP is allowed. Impugned preventive detention
order dated 15.02.2023 bearing reference No.41/BCDFGISSSV/2023 made by the
second respondent is set aside and the detenu Thiru.Arun Babu @ Aron, aged 27
years, Son of Thiru.Babu, is directed to be set at liberty forthwith, if not required in
connection with any other case / cases. There shall be no order as to costs.
                                                                  (M.S.,J.)        (R.S.V.,J.)
                                                                         31.07.2023
                     Index : Yes/No
                     Neutral Citation : Yes/No
                     mmi
P.S: Registry to forthwith communicate this order to Jail authorities in Central
Prison, Puzhal, Chennai.
To
1. The Secretary to Government, Home, Prohibition and Excise Department, Secretariat, Fort St.
George, Chennai -9.
2. The Commissioner of Police, Avadi City, Office of the Commissioner of Police (Goondas Section),
Avadi, Chennai – 54.
https://www.mhc.tn.gov.in/judisGajarani vs The Secretary To Government on 31 July, 2023

3.The Superintendent of Prison, Central Prison, Puzhal, Chennai.
4.The Inspector of Police, T-11 Thiruninravur Police Station, Chennai.
5.The Public Prosecutor High Court, Madras.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL, J., mmi 31.07.2023
https://www.mhc.tn.gov.in/judisGajarani vs The Secretary To Government on 31 July, 2023

