Association Of Victims Of Uphaar ... vs Union Of India And Ors.
on 29 February, 2000
Equivalent citations: 2000IVAD(DELHI)342, 86(2000)DLT246
Author: S.K. Mahajan
Bench: S.K. Mahajan
ORDER
S.N. Variava C.J.
1. This Writ Petition arises out of an unfortunate incident which took place in Uphaar theatre in the
evening of 13th June, 1997. A fire took place in which a number of people were killed and/or injured.
All the Petitioners are those who were injured in the fire or relatives of those who were injured or
killed in the fire. By this Writ Petition the Petitioners seek to highlight, what according to them are a
shocking state of affairs. They claim that there is complete disregard of statutory obligations,
prescribed under the law, for prevention of fire hazards in public places.
2. The grievance of the Petitioners is that each and every public authority, not only failed in the
discharge of its statutory obligations, but in fact acted in a manner which was hostile and foreign to
the discharge of their public duties. The standards set under the statute and the rules framed for the
purpose of preventing public hazards were observed only by their breach. Licence and permits were
issued in complete disregard of the mandatory conditions of inspection and ensuring that the
minimum safeguards were provided on the ground. Scores of cinema halls were and are permitted
to run without any inspection and without any licence. Permits are issued mechanically and perhaps
for a price. The petitioners, therefore, seek adequate compensation for the victims and punitive
damages against the Respondents for showing callous disregard to their statutory obligations and to
the fundamental guaranteed and indefeasible rights under article 21 of the Constitution of India, of
the paying public in failing to provide safe premises, free from hazards that could reasonably be
foreseen.
3. The Respondents have taken a preliminary objection as to the maintainability of this Petition. At
this preliminary stage the question of maintainability is being considered. At this stage, Court is not
deciding merits. The facts referred to hereafter are as stated by the parties and not as and by way of
a decision on merits or findings by the Court. All observations and/or reference to facts in this
Order, will only be preliminary. Court will not be continuously repeating the word preliminary in
this Order.
4. Mr. Desai submitted that at this stage he was not making any submissions on the question of
individual liability of each Respondent Mr. Desai submitted that this Writ Petition raises complex
factual issues and disputed questions of fact. Mr. Desai further submitted that a Writ Petition is notAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

an appropriate proceeding for deciding the causation and responsibility for the unfortunate
incident. Mr. Desai submitted that this Court could not entertain such a Writ Petition. Mr. Desai
submitted that even if the Court could entertain such a Writ Petition, this was not a Writ Petition
which should be entertained by the Court. Mr. Desai submitted that this Petition arises out of a
chain of complex events which culminated in the tragedy which took place at the Uphaar Cinema on
13th June, 1997 in which there were large scale casualties including fatalities. He submitted that the
Petitioner have imp leaded a large number of authorities, including Municipal Corporation of Delhi
(Respondent No. 4), Delhi Vidyut Board (Respondent No. 6), Delhi Police (Respondent No. 3), Delhi
Fire Service (Respondent No. 5) and Medical Services (Respondent No. 8 & 9) and various members
of the Ansal family. He submitted that the tragedy resulted from an intricate chain of events and the
causation and culpability cannot be determined without a fair procedure, including detailed
evidence tested by cross examination. Mr. Desai submitted that some of the complex questions that
arise are as follows:
(1) The precise cause of the incident (2) What is the role of each of the individual
parties mentioned above?
(3) Are they blameworthy?
(4) How is the blame to be apportioned?
(5) Who are the people entitled to claim?
(6) What is the amount of each claim?
Mr. Desai submitted that each of these questions, which relates to causation, the extent of
culpability, people entitled to claim damages and the amount due to them, would involve a complex
trial based on primary evidence.
5. Mr. Desai submitted that by filing a fresh affidavit, verifying the Writ Petition, the Petitioners
have now accepted that the whole Petition is based entirely on the basis of an inquiry made by one
Mr. Naresh Kumar the Deputy Commissioner, South, Govt. of N.C.T. of Delhi. Mr. Desai submitted
that this was a summary inquiry. Mr. Desai submitted that this inquiry was not held under any legal
framework, much less under Commissions of Inquiry Act. He submits that the Deputy
Commissioner himself states that he did not have enough time or material to come to final
conclusions. Mr. Desai points out that this report has already culminated into an F.I.R. (being F.I.R.
No. RC 3(S)/97/CBI/SIC.IV/New Delhi dated 26.07.1997). He points out that the F.I.R. mentions
135 primary documents and 179 witnesses. He points out that the criminal trial is proceeding. He
points out that on 15th November 1997 the charge sheet has been filed by the C.B.I. against 16
persons including Respondent Nos. 18,22, 23, 37 to 40. He points out that the offences invoked are
under Sections 304, 304A, 337, 338 read with Section 36 of the Indian Penal Code and Section 14 of
the Cinematograph Act. He points out that the punishment can be as high as life imprisonment. He
submits that as the criminal case is pending, the liability in this case cannot be determined without
full evidence and proof according to law.Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

6. Mr. Desai submitted that it has been consistently held by the Supreme Court and the High Courts
that disputed questions of fact would not normally be determined in the extraordinary jurisdiction
of High Court under Article 226. In support of this submission Mr. Desai relied upon the case of
DLF Housing Construction Pvt. Ltd. Vs. Delhi Municipal . In this case it has been held that where
the basic facts are disputed and complicated questions of law and facts depending on evidence are
involved the Writ Court is not the proper forum for seeking relief. It has been held that the right
course to follow was to dismiss the Writ Petition on this preliminary ground, without entering upon
the merits of the case. It has been held that in the absence of firm and adequate factual foundation,
it was hazardous to embark upon a determination of the points involved.
7. Mr. Desai also relied upon the case of M/s. Radha Krishna Aggarwal & Co. Vs. State of Bihar &
Ors. , wherein it is held that if facts are disputed and require assessment of evidence the correctness
of which can only be tested satisfactorily by taking detailed evidence, involving examination and
crossexamination of witnesses, the case could not be conveniently or satisfactorily decided in
proceeding under Art. 226 of the Constitution.
8. Mr. Desai relied upon the case of Express Newspaper Pvt. Ltd. Vs. Union of India, , wherein it was
held that questions arising out of a lease, such as, whether there has been breach of the covenants
under the lease whether the lease can be forfeited, whether relief against forfeiture can be granted
etc. are foreign to the scope of Art. 32 of the Constitution. It was held that such questions cannot be
decided just on affidavits. It was held that these are matters which should be tried in a regular civil
proceeding.
9. In support of the above submission Mr. Desai also relied upon the cases of Noorali Abdulla Modi
Vs. Suresh Moti Lal reported in 1995 Supp (4) SCC Pg. 397. Bharat Ram Meena Vs. Rajasthan High
Court at Jodhpur ; State of Madhya Pradesh & Ors Vs. M.V. Vyavsaya & Co. ; Om Prakash Vs. State
Of Haryana, and Jai Singh Vs. Union of India . All these authorities support the proposition
canvassed by Mr. Desai and it is not necessary to set out each authority in detail.
10. Mr. Desai next submitted that even though the writ jurisdiction gives wide discretion to Hon'ble
High Court to give an appropriate relief, it was settled law that if an alternative remedy lay the Writ
Petition would not be entertained. He submitted that the high prerogative writ authority cannot be
invoked to jettison the normal procedure of law. He submitted that in the present case, the principal
relief sought by the Petitioners against Respondents No. 11 to 40 was in the nature of compensation
or damages. He submitted that such a claim should be tried in a properly constituted suit with the
compliance of the rules of Civil Procedure and evidence. He submitted that in a proper suit, pleading
would be filed, issues joined, discovery and inspection of documents would be permitted, evidence
led (and subjected to cross examination) and only then would a decision be rendered. He submitted
that the summary Writ procedure was manifestly inappropriate as a substitute. In support of this
submission he relied on the cases of K.S. Rashid & Sons Vs. IT Commissioner , Shri Sohan Lal Vs.
UOI & Anr. ; C.A. Abraham Vs. ITO reported in AIR 1961 SC Pg. 265; Than Singh Nathmal Vs.
Superintendent of Taxes ; S.K. Kalra & Ors. Vs. UOI & Others ; LIC of India Vs. Kiran Sinha
reported in AIR 1985 SC Pg. 1265 and Mohan Pandey and Anr. Vs. Usha Rani Rajgaria & Ors., .Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

11. Mr. Desai next submitted that the inquiry report of Mr. Naresh Kumar, Deputy Commissioner
(South), was neither admissible in evidence, nor did it have probative value. He submitted that the
report is not made under the authority of a statute and thus it does not have a statutory flavour. He
submitted that even in an enquiry conducted under the Commission of Enquiry Act, 1952, any
statement made by any witness cannot be used to subject the witness to any Civil or Criminal
Proceeding nor it can be used against him in any Civil or Criminal Proceeding. He submitted that a
Commission of Enquiry is not a Court. He submitted that the purpose of Commission of Enquiry is
not a Court. He submitted that the purpose of Commission was to provide information to the
Government and to recommend a course of action to be followed. He submitted that the
Commission was not required to adjudicate upon the rights of the parties and had no adjudicatory
functions. He submitted that the power to administer an oath did not impart to it the status of a
Court. He submitted that these principles, regarding a Commission of Enquiry under the
Commission of Enquiry Act, 1952 would apply with greater force to cases of ordinary inquiries. In
support of this submission he relied upon the cases of Kehar Singh Vs. The State wherein, a it was
held that a report of a Commission is recommendation of the Commission for consideration of the
Government. It was held that it is the opinion of the Commission based on the statements of
witnesses and other materials. It was held that it has no evidentiary value in the trial of the criminal
case.
12. Mr. Desai also relied on the case of Kiran Bedi Vs. Committee of Enquiry wherein it is held that
the report of a Commission of Inquiry, which was only a fact finding body, did not have force
proprio vigore and was only recommendatory in nature.
13. Mr. Desai also relied on the case of Dr. Bali Ram Waman Hirai Vs. Mr. Justice B. Lentin wherein
it is held that a Commission of Inquiry is not a Court properly so called. It was held that a
Commission is obviously appointed by the appropriate Government "for the information of its
mind" in order for it to decide as to the course of action to be followed. It was held that a
Commission was therefore a factfinding body which was not required to adjudicate upon the rights
of the party and had no adjudicatory function. It was held that the Government was not bound to
accept its recommendations or act upon its findings. It was held that the mere fact that the
procedure adopted by it is of a legal character and that it had the power to administer an oath did
not impart to it the status of a Court.
14. Mr. Desai next submitted that a Writ Petition does not lie against private individuals, especially
to enforce private claims. He submitted that the general rule, as enunciated by various
pronouncements of the Supreme Court and the High Courts is that the remedy under Article 32 or
Article 226 lies only against the State and its instrumentalities and not against a private person. He
submitted that Respondents Nos. 11 to 40 are either incorporated bodies or private individual
person and do not have any trappings of a State nor are they discharging any public duty. Mr. Desai
submitted that it was settled law that mandamus could not be issued against a person or a legal
entity, which is not a statutory body, Government Corporation or an industry run by or under the
authority of the Government. Mr. Desai submitted that a writ can not lie against private individuals
in the guise of seeking to enforce some statutory duties. Mr. Desai submitted that Respondents Nos.
11 and 12 were companies incorporated under the Companies Act, 1956 and were non-statutoryAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

bodies. He submitted that the other Respondents i.e. Respondent Nos. 13 to 40 were individuals. He
submitted that none of these Respondents could be said to have trappings of a statutory body or a
public duty imposed on them by a statute in respect of which enforcement could be sought by means
of a mandamus. He submitted that violation of any law or non-compliance with any requirement
under the law ipso facto neither creates a legal duty nor legal right which entitles the Petitioner to
invoke writ of mandamus under Article 226 against these Respondents. He submitted that thus, the
entire Writ Petition was misconceived against Respondents 11 to 40. He submitted that the distinct
division between public law and private law should be maintained and cannot be completely
obliterated, by the device of converting one into the other. He submitted that in the present case the
Petitioners were seeking to use public law remedies to pursue claims arising out of privates law. In
support of these submissions Mr. Desai relied upon the cases of Smt. Vidya Verma Vs. Shiv Naraian
Verma ; Sohan Lal Vs. UOI & Ors., ; Thomas & Ors. Vs. Industrial Tribunal and Ors., ; Praga Tools
Corporation Vs. C. V. Emanual & Ors ; Shri Anadi Mukha Satguru Vs. V.R. Rudani .
15. Mr. Desai next submitted that the present Petition suffered from the vice of misjoinder of
parties, causes of action and multifariousness. He relied upon a chart (which has been set out at
page 293 of the counter affidavit of Respondent No. 12) and submitted that this unequivocally
showed that there was gross misjoinder of parties. He pointed out that some of the Respondents are
only shareholders of the Respondent No. 12 Company; some of the Respondents were erstwhile
Directors; some of the Respondents were neither shareholders, directors nor employees at any point
of time. He submitted that an old lady of 87 years and a minor of 15 years have also been arrayed as
Respondents. He submitted that this clearly showed that the Petitioners have imp leaded several
Respondents belonging to the Ansal family, without inquiring into their legal status or possible
responsibility for an alleged grievance of the Petitioners. Mr. Desai also submitted that some of the
Respondents are already chargesheeted and thus could not be compelled to incriminate themselves
by virtue of constitutional protection available to them.
16. Mr. Desai submitted that the Petition seeks to ventilate a number of different causes of action for
which different modes of adjudication should have been resorted to. He submitted that the clubbing
of several different causes of action makes the entire Writ Petition bad in law. He submitted that
various disparate and unconnected averments have been made against several statutory authorities
and a number of private individuals. He submitted that the Petition ex-facie suffers from the defect
of multifariousness.
17. Mr. Desai next submitted that it was settled law that in a case where a charge sheet was filed in
the Competent Court, it was that Court alone which could deal with the case in accordance with law.
He submitted that each step of the investigation was to be taken only by the police and by no other
authority. He submitted that this being the settled law this Court should not monitor criminal
proceedings once the chargesheet was filed and prayer (a) of the Writ petition was misconceived. In
support of this submission he relied upon the cases Abhinandan Jha Vs. Dinesh Mishra, , Vineet
Narain Vs. Union of India ; Ankul Chandra Pradhan Vs. Union of India and Union of India & Ors.Vs.
Sushil Kumar Modi & Ors. .Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

18. Mr. Desai next submitted that a person accused of an offence is entitled to the protection under
Article 20(3) of the Constitution of India. He submitted that a person against whom an F.I.R. (in
respect of an offence ) is lodged is a person accused of an offence and thus entitled to protection of
Article 20(3). He submitted that such a person cannot be compelled to be a witness against himself.
He submitted that the guarantee against testimonial compulsion is not to be confined to oral
testimony at the witness stand but it also includes statements in writing which incriminate the
maker when figuring as an accused person. He submitted that thus, Respondents 13, 16, 18 ,22, 23,
24, 25, 37, 38, 39 and 40 could not be expected to oppose the Writ Petition and disclose their
possible defenses in the criminal trial, before this Hon'ble Court. He submitted that these
Respondents cannot therefore be made parties to a Writ Petition and had to be removed from the
array of parties. In support of this submission he relied upon the cases M.P. Sharma Vs. Satish
Chandra ; State of Bombay Vs. Kathi Kalu Oghad reported in AIR 1961 SC Pg. 180; Ramanlal
Bhogilal Shah & Anr. Vs. D.K. Guha & Ors. and Smt. Nandini Satpathy Vs. P.L. Dani & Ors. .
19. Mr. Desai lastly submitted that by prayers (c), (d) and (e) the Petitioners seek damages and
punitive damages from Respondents jointly and severally. He submitted that the Petitioners have
not set out the role of each party and/or the appointment of claimed damages. He submitted that
there are 40 parties with largely different stands. He submitted that it is only in a suit where proper
pleadings are made, issues framed and evidence led in consonance with the Evidence Act that a
possible decree for damages/compensation can be passed. He submitted that the issues involved can
be adjudicated only in a Civil Suit with procedural safeguards of Civil Procedure Code and Evidence
Act. He submitted that prayers (c), (d) and (e) cannot be granted in writ proceedings.
20. On the basis of the above mentioned preliminary objections Mr. Desai submitted that the Writ
Petition should be dismissed.
21. Dr. Dhawan stated, at the beginning, that he was adopting all the arguments of Mr. Desai and
would only supplement those argument and/or deal with aspects not touched by Mr. Desai.
22. Dr. Dhawan submitted that his clients were private Respondents who were exfacie neither liable
nor responsible for the tragedy. He submitted that his clients fell into the following categories.
(A) Those that have no nexus, even with the Company that owns the theatre, and are neither nor
were ever Directors, shareholders or employees. He submitted that these were Respondents Nos. 21
and 30 to 36.
(B) Those who were Directors at some distant point in time but not at the time of the tragedy. He
submitted that these were :
Respondents No. 13 (Director from 24.12.94 to 25.3.1996), Respondents No. 15
(Director from 12.9.1980 to 7.10.86), Respondent No. 16 (Director from 25.3.1996 to
28.3.1997), Respondent No. 18 (Director from 26.5.1972 to 17.8.1988), Respondent
No. 27 (Director from 17.10.1988 to 13.5.1992), Respondent No. 28 (Director from
3.5.1992 to 1.12.1993), Respondent No. 29 (Director from 1.12.1993 to 18.3.1995).Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

(C) Those who were or are only shareholders i.e. Respondent Nos. 14, 17, 19 and 20
(D) Those who are Directors now, but not at the time of the fire i.e. Respondent No.
23.
(E) Those who were Directors at the time i.e. Respondent Nos. 24 and 25.
(F) Those who were employees i.e. Respondent Nos. 37, 38,39 and 40.
Dr. Dhawan submitted that this list included a boy of 15 and a lady of 83. He submitted that there
are no allegations in the Petition connecting them with alleged crime. He submitted that in any
event no reliefs could be claimed against those falling in categories A,B,C and D.
23. Dr. Dhawan submitted that the original Writ contained skeletal facts. He submitted that later,
the Petitioners brought on record the Naresh Kumar Committee Report. He submitted that this was
a Report of a rapid ex-statutory inquiry by the Delhi Government. Dr. Dhawan submitted that
disputed questions of fact have been raised which could not conveniently be agitated in Writ
jurisdiction. Dr. Dhawan Submitted that mere infraction of a statute does not give rise to a claim for
damages. In support of this submission he relied upon the cases of M.C. Mehta Vs. Union of India
and Sh. Anadi Mukta Sadguru S.M.V.S.J.M.S. Trust Vs. V.R. Rudani, .
24. Dr. Dhawan submitted that even if his clients owed any responsibility or obligations they could
not be held liable under writ jurisdiction as disputed questions of fact arose.
25. Mr. Rawal submitted that the Report, relied upon by the Petitioners, had not been fully accepted
by the Government. He submitted that it was only a fact finding Commission which enquired in a
summary manner. He submitted that the Government had not even accepted all the
recommendations and had implemented only some of them.
26. Mr. Rawal submitted that all acts of his clients were acts of State and that they enjoyed
immunity for such acts. In support of this submission Mr. Rawal relied upon the case of Kasturi Lal
Ralia Ram Jain Vs. The State of Uttar Pradesh .
27. Mr. Rawal submitted that his clients had suspended the licence, however the High Court stayed
the suspension. He submitted that the High Court also stayed the Order of the Lt. Governor
canceling the licence. He submitted that under these circumstances, in order to exercise some
control, temporary permits were issued. Mr. Rawal submitted that thus his clients could not be
faulted for having granted temporary permits.
28. Mr. Mishra and Mr. Gupta also supported the arguments of Mr. Desai and Mr. Rawal.
29. On the other hand Mr. Tulsi submitted that on the facts alleged in the Petition and admitted in
the counter Affidavit, it was established that every public authority, not only failed in the discharge
of its statutory obligations, but in fact, acted in a manner which was hostile and foreign to the
discharge of their public duties. Mr. Tulsi submitted that the facts disclosed that the standard, setAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

under the statutes and under the rules framed thereunder, were observed in complete breach both
by the public authorities as well as the Cinema owners. Mr. Tulsi submitted that licences and
permits were issued in complete disregard of the mandatory conditions. He submitted that the
cinema owners showed scant regard for the safety of the paying public. He submitted that they acted
in a manner which directly increased the fire hazard and made escape of their patrons, viewing the
cinema from the balcony, almost impossible.
30. Mr. Tulsi points out that in para 2 of the Petition it was alleged that 17 permits were issued
during the last 13 years statutory authorities carring to inspect the premises or to find out whether
the deviations detected, had been removed. Mr. Tulsi points out that Respondent No. 3 i.e. the
Commissioner of Police has in para 5 of his Counter Affidavit, admitted that temporary permits were
issued on two months basis "in order to exercise some control over the management". He submits
that it is nowhere asserted that prior to issuance of these temporary permits, any physical
verification was carried out. He submits that the grant of temporary per mits for 13 years is
defended on the ground that the order of suspension of licence for four days in 1983, having been
stayed by the High Court, the permits were issued under Rule 7(i) of the Delhi Cinematographic
Rules. Mr. Tulsi submits that Respondent No. 3 conveniently overlooks, that the Order of the High
Court in CWP No. 1350/83 only stayed the order dated 27th June 1983, suspending the licence for 4
days. Mr. Tulsi points out that the Order of the High Court did not in any manner, prevent the
statutory authorities from complying with the statutory requirements of inspection in the future, nor
did the High Court direct the authorities to blindly go on issuing temporary permits indefinitely or
for a period of 13 years.
31. Mr. Tulsi submits that the grant of temporary permits for a long period of 13 years in the
purported exercise of power under Rule 7(1) of the Delhi Cinematograph Rules, 1981, is prohibited
under Rule 3(4). Rule 3(4) provides that a temporary license shall not be extended beyond the
aggregate period of 5 years in any case. Mr. Tulsi submits that this proves that the Respondents
failed to comply with the mandatory provision of Rule 3(4) of the Rules.
32. Mr. Tulsi submits that the structural defects/unauthorized deviations in the cinema hall, pointed
out in paras 3 and 9 to 14 of the Petition are admitted in the Counter Affidavit of Respondent No. 3
Mr. Tulsi submits that the existence of the said deviations in respect of the unauthorised increase in
the number of seats in the balcony from 282 to 302; reduction in the size of gangways from 120 cms.
to 90 cms; absence of footlights near the floor; non-illumination of the Exit signs; obstruction of exit
with the provision of box; the doors being bolted from outside ; absence of functional public address
system etc. are thus facts admitted between the parties.
33. Mr. Tulsi submits that the averments with regard to the deviations/violations of the Electricity
Act, and the Rules, by the Delhi Vidyut Board (as alleged in para 7 of the Petition) have been
admitted in the Counter Affidavit of Respondent No. 2. He points out that in para 10 of the said
Counter Affidavit, it has been admitted that the D.V.B. has placed the concerned Superintending
Engineer, Executive Engineer, Assistant Engineer and two Supervisors under Suspension besides
transferring the Additional Chief Engineer. He points out that it has also been admitted that two of
the D.V.B. Officials were also arrested by the Police Department. He submits that this admission isAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

significant in view of the averment in para 5, with regard to the Report received by the Government,
of the Magisterial Inquiry conducted by Shri Naresh Kumar, Dy. Commissioner (South), N.C.T. of
Delhi. He submits that the Government clearly accepted the findings of the Report as correct. He
submits that the Government has claimed that it has taken necessary action against the officials of
different departments. He submits that the findings of the Magisterial Inquiry having been accepted
by Respondent No. 2, the averments in para 7 of the Petition with regard to the factual condition of
the transformer etc. must be deemed to be admitted as the same are in conformity with the finding
of the Inquiry Officer. He submits that the findings of the Inquiry Officer are based on his own, on
the spot observations, at the time of inspection within a couple of days of the tragedy.
34. Mr. Tulsi submits that the denial of the deviations in the Counter Affidavit of Respondent No. 6,
in the light of Counter Affidavit of Respondent No. 2, is of no avail, Mr. Tulsi submits that
Respondent No. 6, claims that the records of the maintenance of the transformer were not
destroyed. He submits that no reason has been given why they were not produced before the Inquiry
Officer. He submits that it is not explained why the same records have not been produced for the
scrutiny of this Court. Mr. Tulsi submits that even the socalled measures to strengthen the safety,
claimed to have been adopted after the tragedy, speak eloquently of the distressing state of affairs, at
the time of the tragedy. He submits that out of 75,000 transformers in Delhi, only 7 are claimed to
have been replaced with dry-type, instead of the existing oil-type transformers. He submits that the
Report of the Committee of the Chief Engineer, has purposefully been withheld from this Court as
the same would reveal that hundreds of other transformers in the city, were found to be in similar
condition as that of Uphaar.
35. Mr. Tulsi submits that the averments in para 15 of the Petition, with regard to the conduct of the
staff of the cinema owners/management have by and large been admitted in the Counter Affidavit of
Respondent No. 6. He points out that according to this Counter Affidavit, the tragedy was the direct
result of the fact that even when the power supply of the transformer tripped, within 0.3 seconds of
the D.V.B. transformer catching fire, the management instead of evacuating their patrons, chose to
continue with the movie, lest they should have to refund the ticket amount. He points out that the
generator was switched on. He submits that the tragedy was further compounded by the careless
and callous attitude of the cinema staff, which wasted precious time in first trying to remove the cars
from the parking area and then in collecting cash instead of evacuating the patrons and informing
the fire service and D.V.B. immediately. He submits that this delay in informing the fire service and
giving timely warning to the patrons for evacuation became the immediate cause for the tragedy.
36. Mr. Tulsi submits that the averments in para 18 of the Petition, regarding the medical facilities,
are admitted by Respondent No. 2, in his Counter Affidavit. He submits that in the Counter affidavit
it has been stated that "13 CATS ambulances alongwith 26 paramedics reached the Uphaar site
within 50-55 minutes. Currently the ambulances have been linked through Motorala Radio
Trunking Wireless Communication Equipment, which has reduced the response time to 10-15
minutes." Mr. Tulsi submits that this admission by Respondent No. 2 establishes the allegations of
the Petitioners in para 18 of the Petition.Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

37. Mr. Tulsi submits that the averments in Paras 18 and 19 of the Petition stand established from
the Counter Affidavit of Respondent No. 7. He submits that it is admitted that the CATS Centre was
conceived before 1986. He submits that on 29.1.1986 land measuring 14.34 acres was taken over by
the All India Institute of Medical Sciences after paying Rs. 99 lakhs in March 1986 as the cost of
land. He submits that for some unexplained reasons the Trauma Centre was handed over to the
Delhi Administration in 1988. He submits that again for unexplained reasons, in 1991-92, it was
handed back to the AIIMS and till today, not a brick has been laid in execution of the Project, for
which Rs. 50 crores have been provided in the 9th Five-Year Plan. He submits that the unexplained
delay in setting up the CATS for 13 years only compounded the magnitude of the tragedy. He
submits that the existence of CATS would certainly have saved many precious lives.
38. Mr. Tulsi submits the Counter Affidavit of Respondent No. 5 establishes total disregard of the
statutory obligations, by public authorities. He points out that the Chief of the Delhi Fire Service
claims (in para 6 of the Counter Affidavit) that "only a fire extinguisher is required to be provided in
cinema halls constructed prior to 1981". Mr. Tulsi submits that this is diametrically opposite to the
provision of Section 3 of the Delhi Fire Prevention and Fire Safety Act, 1986, read with Rule 4 of the
Delhi Fire Prevention and Fire Safety Rules, 1987. Mr. Tulsi submits that the Chief of Delhi Fire
Service is either totally unmindful of the statutory obligations or is merely trying to work out a
defense, with scant regard to facts. He submits that the report of the Deputy Commissioner (South)
clearly brings out the statutory aspects of the Acts and the Rules. Mr. Tulsi submits that it is
shocking that the fire officers could close their eyes to the height of the building, built of concrete
and mortar and work out a feeble defense.
39. Mr. Tulsi submits that issuance of temporary licence under Section 7(1) is subject to Part III of
the Rules, dealing with inspections of the building in respect of which temporary license is to be
granted. He submits that Rules 15 and 16 specifically require the Executive Engineer, the Chief Fire
Officer and the Electrical Inspector to inspect the premises before issuance of temporary license. He
submits that it is the admitted case of the Respondents that no physical inspection was carried out
prior to issuance of temporary license for 13 years. He submits that this entails a breach of the
mandatory provisions of Rules 15 and 16 of the Cinematograph Rules. He submits that the provision
of inspection is necessarily to be read alongwith the Rules contained in the First Schedule, in
particular, Rules 8, 9, 10, 12, 18, 48, 50 and 64.2.2. He submits that the requirement of the fire
extinguisher, as provided in Rule 16 (a) of the Rules, has necessarily to be read alongwith the
requirements prescribed under Rule 18 of the First Schedule. He submits that Rule 16(a) cannot be
read in isolation as is sought to be done by the Respondents. He submits that the Notification by
which the Delhi Cinematograph Rules, 1981, were notified on 31.12.1981 itself states that "The Lt.
Governor is pleased to make the following rules in suppression of those published by the Chief
Commissioner, Delhi's Notification.... dt. 28th August, 1953 ....". He submits that in view of the said
operative clause, the 1981 Rules would apply to all the licenses that are issued subsequent to the said
Rules having come into force.
40. Mr. Tulsi submits that from the reply of Respondent No. 5 it becomes clear that the Respondent
is not even aware of his statutory obligations, and therefore, there is no question of the Respondent
being able to perform the same, or implement statutory standards in respect of the cinema halls. HeAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

submits that it inevitably follows that Respondent No. 5 has mechanically and without enforcing the
standards, which he is mandated to do, been blindly issuing No Objection Certificates, to various
cinema owners, merely on being shown a fire extinguisher. He submits that such callous and wanton
disregard of public duties entrusted upon the Respondent makes the State directly liable for the acts
which directly contributed to the tragedy.
41. Mr. Tulsi submits that in addition to the above, the findings of the Enquiry Committee
conclusively establishes the liability of the Government of Delhi. Mr. Tulsi submits that the
Respondent now cannot shirk their responsibility by raising technical objections, after the findings
of the Enquiry Committee have been accepted by the Government.
42. Mr. Tulsi submits that this Court is competent to deal with such matters in its writ jurisdiction
under Article 226 of the Constitution of India. He submits that it is too late in the day to raise such
technical objections to wriggle out of the liability for the deliberately committed arbitrary and
capricious actions in utter breach of law. Mr. Tulsi relied on the case of Bandhua Mukti Morcha Vs.
UOI & Ors. . In this case the Supreme Court acted on receipt of a letter by a Judge of the Supreme
Court alleging that there were bonded labourers. The Supreme Court appointed two advocates as
Commissioners to visit quarries and interview a cross section of workers. On the Commissioners
confirming the allegations in the letter, the Supreme Court issued notice to the nine lessees and
stone crushers. The Supreme Court appointed one Mr. Patwardhan of IIT to carry out a socioegal
investigation on terms indicated by it. In this case the Supreme Court rejected a contention that the
Court was not empowered to appoint to a commission or an investigation body. The Supreme Court
held as follows:
"The right to live with human dignity, free from exploitation enshrined in Article 21
derives its life breath from the Directive Principles of State Policy an particularly
clauses (e) and (f) of Article 39 and Articles 41 and 42 and at the least, therefore, it
must include protection of the health and strength of workers, men and women, and
the children of tender age against abuse, opportunities and facilities or children to
develop in a healthy manner and in conditions of freedom and dignity, education
facilities just and humane conditions of work and maternity relief. These are the
minimum requirements which must exist in order to enable a person to live with
human dignity and neither the Central nor any State Government has the right to
take any action which will deprive a person of the enjoyment of these basic essentials.
Where legislation is already enacted by the State providing these basic requirements
to the persons, particularly belonging to the weaker session of the community and
thus investing their right to live with basic human dignity, the State can certainly be
obligated to ensure observance of such legislation for inaction on the part of the State
in securing implementation of such legislation would amount to denial of protection
under Article 21 more so in the context of Article 256. The State of Haryana must
therefore ensure that the mine lessees or contractors to whom it is giving its mines
for stone quarrying operations observe various social welfare and labour laws enacted
for the benefit of the workmen. This is a constitutional obligation which can be
enforced against the Central Government and the State of Haryana by a WritAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

Petition....
Litigation particularly in relation to bounded labourers is really not in nature of an
adversary litigation. Whenever there is any allegation of the existence of bounded
labour in any particular State, the State instead of seeking to come out with a case of
denial of such existence on the basis of feeling that the existence of bounded labour in
the State may cast a slur or stigma on its administrative machinery, should cause
effective enquiries to be made in to the matter and if the matter is pending in the
Court, should cooperate with the Court to see that this illegal system is ended at the
earliest......
Even if the Government on its own enquiry is satisfied that the complaint is untrue, it
should not baulk an enquiry by the Court, when the complaint is brought by a citizen,
by raising preliminary objections of hypertechnical or even frivolous nature. The
Supreme Court would be failing discharge of its constitutional duty of enforcing a
fundamental right if it refuses to intervene because the Petitioner belonging to the
under privileged segment of society or a public spirited citizen espousing his cause is
unable to produce the relevant material before the Court. Therefore, the Court has
evolved the practice of appointing responsible persons as Commissioners for the
purpose of gathering facts and data in regard to a complaint of breach of a
fundamental right made on behalf of the weaker sections of the society. The report of
the commissioner would furnish prima facie evidence of the facts and data gathered
by the Commissioner. Once the report of the Commissioner is received, copies of it
would be supplied to the parties so that either party, if it wants to dispute any of the
facts or data stated in the report, may do so by filing an affidavit and the court then
would consider the report of the Commissioner and the affidavits which may have
been filed and proceed to adjudicate upon the issue arising in the Writ Peti tion. It
would be entirely for the Court to consider what weight to attach to the facts and data
stated in the report of the commissioner and to what extent to act upon such facts
and data. But it would not be correct to say that the report of the Commissioner has
no evidentiary value at all, since the Statements made in it are not tested by
crossexamination. Order XLVI of the Supreme Court Rules, 1966 makes the
provisions of Order XXVI of the Code of Civil Procedure, except Rules 13, 14, 19, 20,
21 and 22 applicable to the Supreme Court and lays down the procedure for an
application for issue of a commission, but Order XXVI is not exhaustive. In view of
Rule 6 of Order XLVII of the Supreme Court Rules, Order XLVI of the Rules cannot
detract from the inherent power of the Supreme Court to appoint a commission, if
the appointment of such commission is found necessary for the purpose of securing
enforcement of a fundamental right in exercise of its constitutional jurisdiction under
Article 32. The reports of the Commissioners are clearly documents having
evidentiary value and they furnish prima facie evidence of the facts and data stated in
those reports.Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

What have been stated above in regard to the exercise of jurisdiction by the Supreme
Court under Article 32 must apply equally in relation to the jurisdiction of the High
Courts under Article 226 is much wider, because the High Courts are required to
exercise this jurisdiction not only for enforcement of a fundamental right but also for
enforcement of any legal right and there are many rights conferred on the poor and
the disadvantaged which are the creation of statute and they need to be enforced as
urgently and vigorously as fundamental rights."
43. Mr. Tulsi also relied on the case of Century Spinning & Manufacturing Co. Ltd. Vs. Ulhas Nagar
Municipal Corpn., . In this case the High Court had dismissed the Petition in limine on the basis that
there was disputed question of fact. The Supreme Court held:
"The High Court may, in exercise of its discretion, decline to exercise its
extraordinary jurisdiction under Art. 226 of the Constitution. But the discretion is
judicial; if the Petitioner makes a claim which if frivolous, vexatious, or prima facie
unjust or which may not appropriately be true in a Petition invoking extraordinary
jurisdiction, the Court may decline to entertain the Petition. But a party claiming to
be aggrieved by the Action of a public body or authority on the plea that the action is
unlawful, highhanded, arbitrary or unjust is entitled to a hearing of its Petition on the
merits. Apparently the Petition filed by the Company did not raise any complicated
questions of fact for determination and the claim could not be characterized as
frivolous, vexatious or unjust. The High Court has given no reason for dismissing the
Petition in limine, and on a consid eration of the averments in the Petition and the
materials placed before the Court the Appellants were entitled to have its griev ance
against the action of the Municipality, which was prima facie unjust, tried, Merely
because a question of fact is raised, the High Court will not be justified in requiring
the party to seek relief by the somewhat lengthy, dilatory and expensive process by a
civil Suit against a public body."
44. Mr. Tulsi also relied on the case of Bhola Nath Tripathi Vs. State of UP reported in 1990 (Suppl.)
SCC pg. 151. In this case also the Supreme Court acted on the basis of a letter alleging that a woman
had been forced into prostitution. The Supreme Court appointed a Commissioner to make inquiry
and acted on the Report of the Commissioner. The Supreme Court directed the Commissioner to, if
necessary, recover the woman and keep her in a safe place.
45. Mr. Tulsi submitted that the role of the MCD, as established in the Inquiry Report, brings out the
total disregard of the public duties and responsibility in implementing the Delhi Cinematographic
Act and the building byelaws. He submitted that the Report has established that the completion
certificate was issued in breach of Section 17 in as much as no survey about the fire hazards in the
building was ever conducted. He submitted that the MCD officials, even after having noticed eleven
different violations on 23.5.1996, failed in the performance of their statutory duties in having the
violations removed. He submitted that had the officials performed their responsibility, the tragedy
could have been averted, as the fire hazard in the basement would have been removed and exits and
gangways in the balcony would not have continued to be obstructed.Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

46. Mr. Tulsi submitted that it is on account of the arbitrary and ultra vires actions of the
Respondents, committed in breach of public law, which resulted in loss of 59 lives. He submitted
that the guaranteed and indefeasible right of life has been lost on account of misuse of power and
subversion of general welfare. He submitted that the common good of the public requires that this
Court penalises the public wrongs by fixing liability on the wrongdoers. He submits that this is the
only means of civilising public power and protecting the rights of citizens. In support of this Mr.
Tulsi relies on the case of Lucknow Development Authority Vs. M.K. Gupta, . In this case it was inter
alia held by the Supreme Court as follows:
"8. Having examined the wide reach of the Act and jurisdiction of the Commission to
entertain a complaint not only against business or trading activity but even against
service rendered by statutory and public authorities the stage is now set for
determining if the Commission in exercise of its jurisdiction under the Act could
award compensation and if such compensation could be for harassment and agony to
a consumer. Both these aspects specially the latter are of vital significance in the
present day context. Still more important issue is the liability of payment. That is,
should the society or the tax payer be burdened for oppressive and capricious act of
the public officers or it be paid by those responsible for it. The administrative law of
accountability of public authorities for their arbitrary and even ultra vires actions has
taken many strides. It is now accepted both by this Court and English Courts that the
State is liable to compensate for loss or injury suffered by a citizen due to arbitrary
actions of its employees. In State of Gujarat Vs. Memon Mohammed Haji Hasam the
order of the High Court directing payment of compensation for disposal of seized
vehicles without waiting for the outcome of decision in Appeal was upheld both on
principle of bailee's legal obligation to preserve the property intact and also the
obligation to take reasonable care of it..."to return it in the same condition in which it
was seized' and also because the Government was, 'bound to return the said property
by reason of its statutory obligation or to pay its value if it had disabled itself from
returning it either by its own act or by act of its agents and servants'. It was extended
further even to bona fide action of the authorities if it was contrary to law in Lala
Bishambar Nath Vs. Agra Nagar Mahapalika, Agra. It was held that where the
authorities could not have taken any action against the dealer and their order was
invalid, 'it is immaterial that the Respondents had acted bona fide and in the
interests of preservations of public health. Their motive may be good but their orders
are illegal. They would accordingly be liable for any loss caused to the appellants by
their action.' The theoretical concept that King can do no wrong has been abandoned
in England itself and the State in now held responsible for tortuous act of its servants.
The First Law Commission constituted after coming into force of the Constitution on
liability of the State in tort, observed that the old distinction between sovereign and
nonsovereign functions should no longer be invoked to determine liability of the
State Friedmann observed:
"It is now increasingly necessary to abandon the lingering fiction of a legally
indivisible State, and of a feudal conception of the Crown, and to substitute for it theAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

principle of legal liability where the State, either directly or through incorporated
public authorities, engages in activities of a commercial, industrial or managerial
character. The proper test is not an impracticable distinction between governmental
and non-governmental function, but the nature and form of the activity in question."
Even Kasturi Lal Ralia Ram Jain Vs. State of U.P. did not provide any immunity for tortutous acts of
public servants committed in discharge of statutory function if it was not referable to sovereign
power. Since house construction or for that matter any service hired by a consumer or facility
availed by him is not a sovereign function of the State the ration of Kasturi Lal could not stand in
way of the Commission awarding compensation. We respectfully agree with Mathew, J. in Shyam
Sunder Vs. State of Rajasthan that it is not necessary, "to consider whether there is any rational
dividing line between the socalled sovereign and proprietary or commercial functions for
determining the liability of the State" (SCC p. 695, para 20). In any case the law has always
maintained that the public authorities who are enstrustted with statutory function cannot act
negligently. As far back as 1878 the law was succinctly explained in Geddis Vs. Proprietors of Bann
Reservoir thus;
"I take it, without citing cases, that it is now thoroughly well established that no
action will lie for doing that which the Legislature has authorized, if it be done
without negligence, although it does occasion damage to anyone; but an action does
lie for doing what the Legislature has authorized, if it be done negligently."
Under our Constitution Sovereignty vests in the people. Every limb of the constitutional machinery
is obliged to be people oriented. No functionary in exercise of statutory power can claim immunity,
except to the extent protected by the statute itself. Public authorities acting in violation of
constitutional or statutory provisions opproessively are accountable for their behaviour before
authorities created under the statute like the commission or the courts entrusted with responsibility
of maintaining the rule of law. Each hierachy in the Act is empowered to entertain a complaint by
the consumer for value of the goods or services and compensation. The word "compensation" is
again of very wide connotation. It has not been defined in the Act. According to dictionary it means,
"compensating or being compensated; thing given as recompense" In legal sense it may constitute
actual loss or expected loss and may extend to physical, mental or even emotional suffering, insult
or injury or loss. Therefore, when the Commission has been vested with the jurisdiction to award
value of goods or services and compensation it has to be construed widely enabling the Commission
to determine compensation for any loss or damage suffered by a consumer which in law is otherwise
included in wide meaning of compensation. The provision in our opinion enables a consumer to
claim and empowers the Commission to redress any injustice done to him. Any other construction
would defeat the very purpose of the Act. The Commission or the Forum in the Act is thus entitled to
award not only value of the goods or services but also to compensate a consumer for injustice
suffered by him.
10. Who should pay the amount determined by the Commission for harassment and agony, the
statutory authority or should it be realised from those who were responsible for it ? Compensation
as explained includes both the just equivalent for loss of goods or services and also for sufferance ofAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

injustice. For instance in Civil Appeal No. .... of 1993 arising out of SLP (Civil) No. 659 of 1991 the
Commission directed the Bangalore Development Authority to pay Rs. 2446 to the consumer for the
expenses incurred by him in getting the lease-cum-sale agreement registered as it was additional
expenditure for alternative site allotted to him. No misfeasance was found. The moment the
authority came to know of the mistake committed by it, it took immediate action by allotting
alternative site to the Respondent.It arose in due discharge of duties. For such acts or omissions the
loss suffered has to be made good by the authority itself. But when the sufferance is due to mala fide
or oppressive or capricious acts etc. of a public servant, then the nature of liability changes. The
Commission under the Act could determine such amount if in its opinion the consumer suffered
injury due to what is called misfeasance of the officers by the English Courts. Even in England where
award of exemplary or aggravated damages for insult etc. to a person has now been held to be
punitive, exception has been carved out if the injuryy is due to, 'oppressive, arbitrary or
unconstitutional action by servants of the Government' (Salmond and Heuston on the Law of
Torts).Misfeasance in public office is explained by Wade in his book administrative Law thus :
"Even where there is no ministerial duty as above, and even where no recognised tort
as trespass, nuisance, or negligence is committed, public authorities or officers may
be liable in damages for malicious, deliberate or injurious wrongdoing. There is thus
a tort which has been called misfeasance in public office, and which includes
malicious abuse of power, deliberate maladministration, and perhaps also other
unlawful acts causing injury."
The jurisdiction and power of the courts to indemnify a citizen for injury suffered due to abuse of
power by public authorities is founded as observed by Lord Hailsham in Cassell & Co. Ltd. Vs.
Brome on the principle that, an award of exemplary damages can serve a useful purpose in
vindicating the strength of law. An ordinary citizen or a common man is hardly equipped to match
the might of the State or its instrumentalities. That is provided by the rule of law. It acts as a check
on arbitrary and capricious exercise of power. In Rookes Vs. Barnard it was observed by Lord
Devlin, 'the servants of the government are also the servants of the people and the use of their power
must always be subordinate to their duty of service.' A public functionary if he acts maliciously or
oppressively and the exercise of power results in harassment and agony then it is not an exercise of
power but its abuse. No law provides protection against it. He who is responsible for it must suffer
it. Compensation or damages as explained earlier may arise even when the officer discharges his
duty honestly and bona fide. But when it arises due to arbitrary or capricious behaviour then it loses
its individual character and assumes social significance. Harassment of a common man by public
authorities is socially abhorring and legally impermissible. It may harm him personally but the
injury to society is far more grievous. Crime and corruption thrive and prosper in the society due to
lack of public resistance. Nothing is more damaging than the feeling of helplessness. An ordinary
citizen instead of complaining and fighting succumbs to the pressure of undesirable functioning in
offices instead of standing against it. Therefore, the award of compensantion for harassment by
public authorities not only compensate the individual, satisfies him personally but helps in curing
social evil. It may result in improving the work culture and help in changing the outlook. Wade in
his book Admin istrative Law has observed that it is to the credit of public authorities that there are
simply few reported English decisions on this form of malpractice, namely, misfeasance in publicAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

offices which includes malicious use of power, deliberate maladmin istration and perhaps also other
unlawful acts causing injury. One of the reasons for this appears to be development of law which,
apart, from other factors succeeded in keeping a salutary check on the functioning in the
Government or semi-government offices by holding the officers personally responsible for their
capricious or even ultra vires action resulting in Injury or loss to a citizen by awarding damages
against them. Various decisions rendered from time to time have been referred to by Wade on
Misfeasance by Public Authorities. We shall refer to some of them to demonstrate how necessary it
is for out society. In Ashby Vs. White the House of Lords invoked the principle of ubi jus ibi
remidium in favour of an elector who was wrongfully prevented from voting and decreed the claim
of damages. The ratio of this decision has been applied and extended by English Courts in various
situations. In Roncarelli Vs. Duplessis the Supreme Court of Canada awarded damages against the
Prime Minister of Quebec personally for directing the cancellation of a restaurant-owner's liquor
licence solely because the licensee provided bail on many occasions for fellow members of the sect of
Jehovah's Witnesses, which was then unpopular with the authorities. It was observed that, 'what
could be more malicious then to punish this licensee for having done what he had an absolute right
to do in a matter utterly irrelevant to the Alcoholic Liquor Act ? Malice in the proper sense is simply
acting for a reason and purpose knowingly foreign to the administration, to which ws added here the
element of intentional punishment by what was virtually vocation outla wry. "In Smith Vs. East
Elloe Rural District Council the House of Lords held that an action for damages might proceed
against the clerk of a local authority personally on the ground that he had procured the compulsory
purchase of the Plaintiff's property wrongfully and in bad faith." In Farrington Vs.Thomson the Su
preme Court of Victoria awarded damages for exercising a power the authorities knew they did not
possess. A licensing inspector and a public office ordered the Plaintiff to close his hotel and cease
supplying liquor. He obeyed and filed a Suit for the resultant loss. The Court observed :
"Now I take it to be perfectly clear, that if a public officer abuses his office, either by
an act of omission or commission, and the consequence of that is an injury to an
individual, an action may be maintained against such public officer."
In Wood Vs. Blair a dairy farmer's manager contracted typhoid fever and the local authority served
notices forbidding him to sell milk, except under certain conditions. These notices were void, and
the farmer was awarded damages on the ground that the notices were invalid and that the Plaintiff
was entitled to damages for misfeasance. This was done even though the finding was that the
officers had acted from the best motives'.
47. Mr. Tulsi also relied on the case of Nilabeti Behra Vs. State of Orissa, . In this case the facts were
that the deceased, aged about 22 years, was taken into police custody at about 8 a.m. on December 1,
1987 by ASI, police in connection with investigation of an offence of theft in the village. He was
handcuffed, tied and kept in custody in the police station where the accused police constable and
some other persons were present that night. The dead body of the deceased with a handcuff and
multiple injuries was found by some railway men lying on the railway track on the morning of
December 2, 1987. The police reached the spot to take charge of the dead body much later in the
day. Mother of the deceased sent a letter dated September 14, 1988 to the Supreme Court alleging
custodial death of her son and claiming compensation on ground of violation of Art 21. The SupremeAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

Court treated the letter as a Writ Petition under Art 32. The State of Orissa, the police ASI and the
constable concerned, were imp leaded as Respondents in the Petition. The defense of the
Respondents was that the deceased managed to escape from police custody at about 3 a.m. on the
night between December 1 and 2, 1987 by chewing off the rope with which he was tied; that he could
not be apprehended thereafter in spite of a search; and that the dead body of the deceased was
found on the railway track with multiple injuries which indicated that he was run over by a passing
train. The medical evidence comprising the testimony of the doctor who conducted the postortem,
excluded the possibility of the injuries to the deceased being caused in a train accident while
indicating that all of them could have resulted from merciless beating given to him. However, a
written opinion was rendered by the Professor and head of the Department of Forensic Medicine,
Medical College, Cuttack on a reference made to him wherein he stated on the basis of documents
that the injuries found on the dead body of the deceased could have been caused by rolling on the
railway track in between the rail and by coming into forceful contact with projecting part of the
moving train/engine. While adding that it did not appear to be a case of suicide, he indicated that
there was more likelihood of accidental fall on the railway track followed by the running
engine/train. A joint inquiry was conducted by the Executive Magistrate and the Circle Inspector of
Police. A report, stated to be one under Sec. 176 Cr. P.C., was submitted recording a finding that the
deceased escaped from police custody at about 3 a.m. on December 2, 1987 and died in a train
accident as a result of injuries sustained therein. However, the Regional Forensic Science laboratory
submitted a report in respect of the two cut ends of the pieces of rope which were sent for
examination that the two cut ends did not match with each other in respect of physical appearance
thus negating the Respondent's suggestion regarding the deceased's escaped by chewing off the
rope. In view of the controversy relating to the cause of death of the deceased, the Supreme Court
directed (on March 4, 1991) the District Judge to hold an inquiry into the matter and submit a
Report. Accordingly, the District Judge submitted his Report containing his findings based on
evidence led by the parties that the deceased had died on account of multiple injuries inflicted on
him while he was in police custody. The findings and the Report of the District Judge were disputed
before the Supreme Court by the Respondents. Two questions arose for decisions by the Supreme
Court: (1) Whether it was a case of custodial death and (2) whether the Respondents were liable for
compensation to the deceased's mother, the Petitioner, for the custodial death. Thus highly disputed
questions of fact arose. The Supreme Court interlia held as follows:
"9. We may also refer to the report dated December 19, 1988 containing the findings
in a joint inquiry conducted by the Executive Magistrate and the Circle Inspector of
police. This report is stated to have been made under Section 176 Cr. PC and was
strongly relied on by the learned Additional Solicitor General as a statutory report
relating to the cause of death. In the first place, an inquiry under Section 176 Cr. PC is
contemplated independently by a Magistrate and not jointly with a police officer
when the role of the police officers itself is a matter of inquiry. The joint finding
recorded is that Suman Behera escaped from police custody at about 3 a.m. on
December 2, 1987 and died in a train accident as a result of injuries sustained
therein. There was handcuff on the hands of the deceased when his body was found
on the railway track with rope around it. It is significant that the report dated March
11, 1988 of the Regional Forensic Science Laboratory (Annexure 'R-8' at p. 108 of theAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

paperbook) mentions that the two cut ends of the two pieces of rope which were sent
for examination do not match with each other in respect of physical appearance. This
finding about the rope negatives the Respondents' suggestion that Suman Behera
managed to escape from police custody by chewing off the rope with which he was
tied. It is not necessary for us to refer to the other evidence including the oral
evidence adduced during the inquiry, from which the learned District Judge reached
the conclusion that it is a case of custodial death and Suman Behera died as a result
of the injuries inflicted upon him voluntarily while he was in police custody at the
Police outpost Jeraikela. We have reached the same conclusion on a reappraisal of
the evidence adduced at the inquiry taking into account the circumstances, which
also support that conclusion. This was done in view of the vehemence with which the
learned Additional Solicitor General urged that it is not a case of custodial death but
of death of Suman Behera caused by injuries sustained by him in a train accident,
after he had managed to escape from police custody by chewing off the rope with
which he had been tied for being detained at the Police outpost. On this conclusion,
the question now is of the liability of the Respondents for compensation to Suman
Behera's mother, the Petitioner, for Suman Behera's custodial death.
10. In view of the decisions of this Court in Rudul Sah Vs. State of Bihar, Sebastian M.
Hongray Vs. Union of India, Bhim Singh Vs. State of J & K, Saheli; A Women's
Resources Centre Vs. Commissioner of Police, Delhi Police Headquarters and State of
Maharashtra Vs. Ravikant S. Patil the liability of the State of Orissa in the present
case to pay the compensation cannot be doubted and was rightly not disputed by the
learned Additional Solicitor General, It would, however, be appropriate to spell out
clearly the principle on which the liability of the State arises in such cases for
payment of compensation and the distinction between this liability and the liability in
private law for payment of compensation in an action on tort. It may be mentioned
straightaway that award of compensation in a proceeding under Article 32 by this
Court or by the High Court under Article 226 of the Constitution is a remedy
available in public law, based on strict liability for contravention of fundamental
rights to which the principle of sovereign immunity does not apply, even though it
may be available as a defense in private law in an action based on tort. This is a
distinction between the two remedies to be borne in mind which also indicates the
basis on which compensation is awarded in such proceedings. We shall now refer to
the earlier decisions of this Court as well as some other decisions before further
discussion of this principle.
11. In Rudul Sah it was held that in a Petition under Article 32 of the Constitution,
this Court can grant compensation for deprivation of a fundamental right. That was a
case of violation of the Petitioner's right to personal liberty under Article 21 of the
Constitution. Chandrachud, CJ., dealing with this aspect, stated as under : (SCC pp.
14748 paras 9 and 10 ) :Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

"It is true that Article 32 cannot be used as a substitute for the enforcement of rights
and obligations which can be enforced efficaciously through the ordinary processes of
courts, civil and criminal. A money claim has therefore to be agitated in and
adjudicated upon in a Suit instituted in a Court of lowest grade competent to try it.
But the important question for our consideration is whether in the exercise of its
jurisdiction under Article 32, this Court can pass an order for the payment of money
if such an order is in the nature of compensation consequential upon the deprivation
of a fundamental right. The instant case is illustrative of such cases ....
"..The Petitioner could have been relagated to the ordinary remedy of a Suit if his
claim to compensation was factually controversial. In the sense that a Civil Court may
or may not have upheld his claim. But we have no doubt that if the Petitioner files a
Suit to recover damages for his illegal detention, a decree for damages would have to
be passed in that Suit, though it is not possible to predicate, in the absence of
evidence, the precise amount which would be decreed in order of compensation in
favour of the petitioner will be doing mere lip service of his fundamental right to
liberty which the State Government has so grossly violated Article 21 which
guarantees the right to life and liberty will be denuded of its significant content if the
power of this Court were limited to passing orders of release from illegal detention.
One of the telling ways in which the violation of that right can reasonably be
prevented and due compliance with the mandate of Article 21 secured is to mulct its
violators in the payment of monetary compensation. Administrative sclerosis leading
to flagrant infringements of fundamental rights cannot be corrected by any other
method open to the judiciary to adopt. The right to compensation is some palliative
for the unlawful acts of instrumentalities which act in the name of public interest and
which present for their protection the powers of the State as a shield. If civilization is
not to perish in this country as it has perished in some other too wellknown to suffer
mention, it is necessary to educate ourselves into accepting that respect for the rights
of individuals is the true bastion of democracy. Therefore, the State must repair the
damage done by its officers to the Petitioners rights. It may have recourse against
those officers". (SCR pp. 513-14 ).
12. It does appear from the above extract that even though it was held that
compensation could be awarded under Article 32 for contravention of a fundamental
right, yet it was also stated that "the Petitioner could have been relegated to the
ordinary remedy of a Suit if this claim to compensation was actually controversial
and Article 32 cannot be used as a substitute for the enforcement of rights and
obligations which can be enforced efficaciously through the ordinary processes. This
observation may tend to raise a doubt that the remedy under Article 32 could be
denied if the claim to compensation was factually controversial and therefore
optional not being a distinct remedy available to the Petitioner in addition to the
ordinary processes. The later decisions of this Court proceed on the assumption that
monetary compensation can be awarded for violation of constitutional rights under
Article 32 or Article 226 of the Constitution but this aspect has not been adverted to.Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

It is, therefore, necessary to clear this doubt and to indicate the precise nature of this
remedy which is distinct and in addition to the available ordinary processes, in case
of violation of the fundamental rights.
13. Reference may also be made to the other decisions of this Court after Rudal Sah.
In Sebastian M. Hongray Vs. UOI, , it was indicated that in a Petition for writ of
habeas corpus, the burden was obviously on the Respondents to make good the
positive stand of the Respondents in response to the notice issued by the court by
offering proof of the stand taken, when it is shown that the person detained was last
seen alive under the surveillance, control and command of the detaining authority. In
Sebastian M. Hongray Vs. UOI (II), (1984) 3 SCC 82, in such a writ petition,
exemplary costs were awarded on failure of the detaining authority to produce the
missing persons on the conclusion that they were not alive and had met an unnatural
death. The award was made in Sebastian M. Hongray(II) apparently following Rudal
Shah but without indicating anything more. In Bhim Singh Vs. State of J & K,
detention in police custody of the Petitioner Bhim Singh was held to constitute
violation of his rights under articles 21 and 22(2) and this court exercising its power
to award compensation under Article 32 directed the State to pay monetary
compensation to the petitioner for violation of his constitutional right by way of
exemplary costs or otherwise taking this power to be settled by the decisions in Rudul
Sah and Sebastian M. Hongray. In Saheli, (1990) 2 SCC 422, the State was held liable
to pay compensation payable to the mother of the deceased who died as a result of
beating and assault by the police. However, the principle indicated therein was that
the State is responsible for the tortuous acts of its employees. In State of Maharashtra
Vs. Ravikant S. Patil, the award of compensation by the High Court for violation of
the fundamental right under Article 21 of an undertrial prisoner, who was handcuffed
and taken through the steets in a procession by the police during investigation, was
upheld. However, in none of these cases, except Rudal Sah anything more was said.
In Saheli reference was made to the State's liability for tortuous acts of its servants
without any reference being made to the decision of this Court in Kasturilal Ralia
Ram Jain Vs. State of U.P. , wherein sovereign immunity was upheld in the case of
vicarious liability of the State for the tort of its employees. The decision in Saheli is
therefore, more in accord with the principle indicated in Rudul Sah.
14. In this context, it is sufficient to say that the decision of this Court in Kasturilal
upholding the State's plea of sovereign immunity for tortuous acts of its servants is
confined to the sphere of liability in tort, which is distinct from the State's liability for
contravention of fundamental rights to which the doctrine of sovereign immunity has
no application in the constitutional scheme and is no defense to the constitutional
remedy under Articles 32 and 226 of the Constitution which enables award of
compensation for contravention of fundamental rights when the only practicable
mode of enforcement of the fundamental rights can be the award of compensation.
The decisions of this Court in Rudul Sah and others in that line relate to award of
compensation for contravention of fundamental rights, in the constitutional remedyAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

under Article 32 and 226 of the Constitution. On the other hand, Kasturilal related to
value of goods seized and not returned to the owner due to the fault of Government
servants, the claim being of damages for the tort of conversion under the ordinary
process and not a claim for compensation for violation of fundamental rights.
Kasturilal is, therefore, inapplicable in this context and distinguishable.
15. The decision of Privy Council in Maharaj Vs. AttorneyGeneral of Trinidad and
Tobago (1978 2 All ER 670) is useful in this context. That case related to Section 5 of
the Constitution of Trinidad and Tobago 1962, in the chapter pertaining to human
rights and fundamental freedoms, wherein Section 6 provides for an application to
the High Court for redress. The question was, whether the provision permitted an
order for monetory compensation. The contention of the Attorney General therein,
that an order for payment of compensation did not amount to the enforcement of the
rights that had been contravened was expressly rejected. It was held that an order for
payment of compensation, when a right protected had been contravened, is clearly a
form of redress which a person is entitled to claim under Section 6 and may well be
'the only practicable form of redress' Lord Diplocak who delivered the majority
opinion, at page 679, stated :
"It was argued on behalf of the Attorney General that Section 6(2) does not permit of
an order for monetary compensation despite the fact that this kind of redress was
ordered in Jaundoo Vs. Attorney General of Guyana, (1971) AC 972, Reliance was
placed on the reference in the subsection to enforcing, or securing the enforcement
of, any of the provisions of the said foregoing sections as the purpose for which
orders etc., could be made. An order for payment of compensation, it was submitted,
did not amount to the enforcement of the rights that had been contravened. In their
Lordships" view an order for payment of compensation when a right protected under
Section 1 has been contravened is clearly a form of redress which a person is entitled
to claim under Section 6(1) and may well be the only practicable form of redress, as
by now it is in the instant case. The jurisdiction to make such an order is conferred on
the High Court by para (a) of Section 6(2) viz. jurisdiction to hear and determine any
application made by any person in pursuance of sub section (1) of this Section. The
very wide powers to make orders, issue writs and give directions are ancillary to this."
Lord Diplock further stated at page 680, as under :
"Finally, their Lordships would say something about the measure of monetary,
compensation recoverable under section 6 where the contravention of the claimant's
constitutional rights consists of deprivation of liberty otherwise than by due process
of law. The claim is not a claim in private law for damages for the tort of false
imprisonment, under which the damages recoverable are at large and would include
damages for loss of reputation. It is a claim in public law for compensation for
deprivation of liberty alone."Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

16. Lord Hailsham while dissenting from the majority regarding the liability for compensation in
that case, concurred with the majority opinion on this principle and stated at page 687, thus:
"....I am simply saying that, on the view I take, the expression 'redress' in subection
(1) of Section 6 and the expression 'enforcement' in subection (2), although capable of
embracing damages where damages are available as part of the legal consequences of
contravention, do not confer and are not in the context capable of being construed so
as to confer a right of damages where they have not hitherto been available, in this
case against the State for the judicial errors of a judge".
Thus, on this principle, the view was unanimous, that enforcement of the constitutional right and
grant of redress embraces award of compensation as part of the legal consequences of its
contravention.
17. It follows that a claim in public law for compensation for contravention of human rights and
fundamental freedoms, the protection of which is guaranteed in the Constitution, is an
acknowledged remedy for enforcement and protection of such rights,and such a claim based on
strict liability made by resorting to a constitutional remedy provided for the enforcement of a
fundamental right is distinct from, and in addition to, the remedy in private law for damages for the
tort resulting from the contravention of the fundamental right. The defense of sovereign immunity
being inapplicable, and alien to the concept of guarantee of fundamental rights, there can be no
question of such a defense being available in the constitutional remedy. It is this principle which
justifies award of monetary compensation for contravention of fundamental rights guaranteed by
the Constitution, when that is the only practicable mode of redress available for the contravention
made by the State or its servants in the purported exercise of their powers, and enforcement of the
fundamental right is claimed by resort to the remedy in public law under the Constitution by
recourse to Article 32 and 226 of the Constitution. This is what was indicated in Rudul Sah and is
the basis of the subsequent decisions in which compensation was awarded under Articles 32 and
226 of the Constitution, for contravention of fundamental rights.
18. A useful discussion on this topic which brings out the distinction between the remedy in public
law based on strict liability for violation of a fundamental right enabling award of compensation, to
which the defense of sovereign immunity is inapplicable, and the private law remedy, wherein
vicarious liability of the State in tort may arise, is to be found in Ratanlal & Dhirajlal's Law of Torts
22nd Edition, 1992, by Justice G.P. Singh, at pages 44 to 48.
19. This view finds support from the decisions of this Court in the Bhagalpur Blinding cases : Khatri
(II) Vs. State of Bihar and Khatri (IV) Vs. State of Bihar wherein it was said that the Court is not
helpless to grant relief in a case of violation of the right to life and personal liberty, and it should be
prepared to forge new tools and device new remedies for the purpose of vindicating these precious
fundamental rights. It was also indicated that the procedure suitable in the facts of the case must be
adopted for conducting the inquiry, needed to ascertain the necessary facts, for granting the relief,
as the available mode of redress, for enforcement of the guaranteed fundamental rights. More
recently in Union Carbide Corpn. Vs. Union of India Misra, CJ. Stated that 'we have to develop ourAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

own law and if we find that it is necessary to construct a new principle of liability to deal with an
unusual situation which has arisen and which is likely to arise in future... there is no reason why we
should hesitate to evolve such principle of liability." To the same effect are the observations of
Venkatachaliah, J. (as he then was), who rendered the leading judgment in the Bhopal gas case with
regard to the court's power to grant relief.
20. We respectfully concur with the view that the Court is not helpless and the wide powers given to
this Court by Article 32, which itself is a fundamental right, imposes a constitutional obligation on
this Court to forge such new tools, which may be necessary for doing complete justice and enforcing
the fundamental rights guaranteed in the Constitution, which enable the award of monetary
compensation in appropriate cases, where that is the only mode of redress available. The power
available to this Court under Article 142 is also an enabling provision in this behalf. The contrary
view would not merely render the court powerless and the constitutional guarantee a mirage, but
may, in certain situations, be an incentive to extinguish life, if for the extreme contravention the
Court is powerless to grant any relief against the State, except by punishment of the wrongdoer for
the resulting offence, and recovery of damages under private law, by the ordinary process. If the
guarantee that deprivation of life and personal liberty cannot be made except in accordance with
law, is to be real, the enforcement of the right in case of every contravention must also be possible in
the constitutional scheme, the mode of redress being that which is appropriate in the facts of each
case. This remedy in public law has to be more readily available when invoked by the haveots, who
are not possessed of the wherewithal for enforcement of their rights in private law, even though its
exercise is to be tempered by judicial restraint to avoid circumvention of private law remedies,
where more appropriate.
21. We may also refer to Article 9(5) of the International Covenant on Civil and Political Rights, 1966
which indicates that an enforceable right to compensation is not alien to the concept of enforcement
of a guaranteed right. Article 9(5) reads as under :
"Anyone who has been the victim of unlawful arrest or detention shall have an
enforceable right to compensation."
22. The above discussion indicates the principle on which the courts power under Articles 32 and
226 of the Constitution is exercised to award monetary compensation for contravention of a
fundamental right. This was indicated in Rudul Sah and certain further observations therein
adverted to earlier, which may tend to minimize the effect of the principle indicated therein, do not
really detract from that principle. This is how the decisions of this Court in Rudul Sah and others in
that line have to be understood and Kasturilal distinguished therefrom. We have considered this
question at some length in view of the doubt raised, at times, about the propriety of awarding
compensation in such proceedings, in stead of directing the claimant to resort to the ordinary
process of recovery of damages by recourse to an action in tort. In the present case, on the finding
reached, it is clear case for award of compensation to the Petitioner for the custodial death of her
son.Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

32. Adverting to the grant of relief to the heirs of a victim of custodial death for the infraction or
invasion of his rights guaranteed under Article 21 of the Constitution of India, it is not always
enough to relegate him to the ordinary remedy of a Civil Suit to claim damages for the tortuous act
of the State as that remedy in private law indeed is available to the aggrieved party. The citizen
complaining of the infringment of the indefeasible right under Article 21 of the Constitution cannot
be told that for the established violation of the fundamental right to life, he cannot get any relief
under the public law by the courts exercising writ jurisdiction. The primary source of the public law
proceedings stems from the prerogative writs and the Courts have, therefore, to evolve 'new tools' to
give relief in public law by moulding it according to the situation with a view to preserve and protect
the Rule of Law. While concluding his first Hamlyn Lecture in 1949 under the title 'Freedom under
the Law' Lord Denning in his own style warned:
"Not one can suppose that the executive will never be guilty of the sins that are
common to all of us. You may be sure that they will sometimes do things which they
ought not to do : and will not do things that they ought to do. But if and when wrongs
are thereby suffered by any of us what is the remedy? Our procedure for securing our
personal freedom is efficient, our procedure for preventing the abuse of power is not.
Just as the pick and shovel is no longer suitable for the winning of coal, so also the
procedure of mandamus, certiorari and actions on the case are not suitable for the
winning of freedom in the new age. They must be replaced by new and up to date
machinery, by declarations, injunctions and actions for the negligence...This is not
the task of Parliament... the Courts must do this. Of all the great tasks that lie ahead
this is the greatest. Properly exercised the new powers of the executive lead to the
welfare stale; but abused they lead to a totalitarian state. None such must ever be
allowed in this country."
33. The old doctrine of only relegating the aggrieved to the remedies available in civil law limits the
role of the Courts too much as protector and guarantor of the indefeasible rights of the citizens. The
Court have the obligation to satisfy the social aspirations of the citizens because the Courts and the
law are for the people and expected to respond to their aspirations.
34. The public law proceedings serve a different purpose then the private law proceedings. The relief
of monetary compensation, as exemplary damages, in proceedings under Article 32 by this Court or
under Article 226 by the High Courts, for established infringment of the indefeasible right
guaranteed under Article 21 of the Constitution is a remedy available in public law and is based on
the strict liability for contravention of the guaranteed basic and indefeasible rights of the citizen.
The purpose of public law is not only to civilize public power but also to assure the citizen that they
live under a legal system which aims to protect their interests and preserve their rights. Therefore,
when the Court moulds the relief by granting 'compensation' in proceedings under Articles 32 and
226 of the Constitution seeking enforcement or protection of fundamental rights, it does so under
the public law by way of penalizing the wrongdoer and fixing the liability for the public wrong on the
State which has failed in its public duty to protect the fundamental rights of the citizen. The
payment of compensation in such cases is not to be understood, as it is generally understood in a
civil action for damages under the provate law but in the broader sense of providing relief by anAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

order of making monetary amends under the public law for the wrong done due to breach of public
duty, of not protecting the fundamental rights of the citizen. The compensation is in the nature of
'exemplary damages' awarded against the wrongdoer for the breach of its public law duty and is
independent of the rights available to the aggrieved party to claim compensation under the private
law in an action based on tort, through a Suit instituted in a court of competent jurisdiction or/and
prosecute the offender under the penal law.
35. This Court and the High Courts, being the protectors of the civil liberties of the citizen, have not
only the power and jurisdiction but also an obligation to grant relief in exercise of its jurisdiction
under Articles 32 and 226 of the Constitution to the victim or the heir of the victim whose
fundamental rights under Article 21 of the Constitution of India are established to have been
flagrantly infringed by calling upon the State to repair the damage done by its officers to the
fundamental rights of the citizens, notwithstanding the right of the citizen to the remedy by way of a
Civil Suit or criminal proceedings. The State of course has the right to be indemnified by and take
such action as may be available to it against the wrongdoer in accordance with law through
appropriate proceedings. Of course, relief in exercise of the power under Articles 32 or 226 would be
granted only once it is established that there has been an infringement of the fundamental rights of
the citizen and no other form of appropriate redressal by the Court in the facts and circumstances of
the case, is possible. The decisions of this Court in the line of cases starting with Rudul Sah Vs. State
of Bihar granted monetary relief to the victims for deprivation of their fundamental rights in
proceedings through petitions filed under Article 32 or 226 of the Constitution of India,
notwithstanding the rights available under the civil law to the aggrieved party where the courts
found that grant of such relief was warranted. It is a sound policy to punish the wrongdoer and it is
in that spirit that the courts have moulded the relief by granting compensation to the victims in
exercise of their writ jurisdiction. In doing so the courts take into account not only the interest of the
applicant and the Respondent but also the interests of the public as a whole with a view to ensure
that public bodies or officials do not act unlawfully and do perform their public duties property
particularly where the fundamental right of a citizen under Article 21 is concerned. Law is in the
process of development and the process necessitates developing separate public law procedures as
also public law principles. It may be necessary to identify the situations to which separate
proceedings and principles apply and the courts have to act firmly but with certain amount of
circumspection and selfestrain, lest proceedings under Articles 32 or 226 are misused as a disguised
substitute for civil action in private law. Some of those situations have been identified by this Court
in the cases referred to."
48. Mr. Tulsi also relied on the case of Sebastian M. Hongray Vs. Union of India. In this case a Writ
of Habeas Corpus was sought for production of two missing persons. In spite of Order to that effect
the persons were not produced. It was contended in defense that compliance was beyond their
control as these persons could not be found despite best efforts. It was informed that these two
persons had left in the company of their compatriots. Thus highly disputed questions of fact were
raised. The Supreme Court still directed ".... as a measure of exemplary costs Rs. 1 lac to each of the
Petitioners women with in a period of four weeks from today."Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

49. Mr. Tulsi also relied on the case of M.C. Mehta and Anr. Vs. UOI . In this case it is inter alia held
as follows:
"Mr. Divan learned counsel appearing on behalf of Shriram raised a preliminary
objection that the Court should not proceed to decide these constitutional issues
since there was no claim for compensation originally made in the writ petition and
these issues could not be said to arise on the writ petition. Mr. Divan conceded that
the escape of oleum gas took place subsequent to the filing of the writ petition but his
argument was that the petitioner could have applied for amendment of the writ
petition so as to include a claim for compensation for the victims of oleum gas but no
such application for amendment was made and hence on the writ petition as it stood,
these Constitution issues did not arise for consideration. We do not think this
preliminary objection raised by Mr. Divan is sustainable. It is undoubtedly true that
the Petitioner could have applied for amendment of the Writ Petition so as to include
a claim for compensation but merely because he did not do so, the Applications for
compensation made by the Delhi Legal Aid and Advice Board and the Delhi Bar
Association cannot be thrown out. These Applications for compensation are for
enforcement of the fundamental right to life enshrined in Article 21 of the
Constitution and while dealing with such application, we cannot adopt a hyper
technical approach which would defeat the ends of justice. This Court has on
numerous occasions pointed out that where there is a violation of fundamental or
other legal right of a person or class of persons who by reason of poverty or disability
or socially or economically disadvantaged position cannot approach a court of law for
justice, it would be open to any public spirited individual or social action group to
bring an action for vindication of the fundamental or other legal right of such
individual or class of individuals and this can be done not only by filing a regular writ
petition but also by addressing a letter to the court. If this Court is prepared to accept
a letter complaining of violation of the fundamental right of an individual or a class of
individuals who cannot approach the court for justice, there is no reason why these
Applications for compensation which have been made for enforcement of the
fundamental right of the persons affected by the oleum gas leak under Article 21
should not be entertained. The court while dealing with an Application for
enforcement of a fundamental right must look at the substance and not the form. We
cannot therefore sustain the preliminary objection raised by Mr. Divan.
3. The first question which requires to be considered is as to what is the scope and
ambit of the jurisdiction of this Court under Article 32 since the Applications for
compensation made by the Delhi Legal Aid and Advice Board and the Delhi Bar
Association are Applications sought to be maintained under that Article. We have
already had occasion to consider the ambit and coverage of Article 32 in the Bandhua
Mukti Morcha Vs. UOI , and we wholly endorse what has been stated by one of us
namely, Bhagwati J. as he then was in his judgment in that case in regard to the true
scope and ambit of that article. It may now be taken as well settled that Article 32
does not merely confer power on this Court to issue a direction, order or writ forAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

enforcement of the fundamental rights but it also lays a constitutional obligation on
this Court to protect the fundamental rights of the people and for that purpose this
Court has all incidental and ancillary powers including the power to forge new
remedies and fashion new strategies designed to enforce the fundamental rights. It is
in realization of this constitutional obligation that this Court has in the past
innovatted new methods and strategies for the purpose of securing Enforcement of
the fundamental rights, particularly in the case of the poor and the disadvantaged
who are denied their basic human rights and to whom freedom and liberty have no
meaning.
6. So far as the power of the court under Article 32 to gather relevant material
bearing on the issues in this kind of litigation which we may for the sake of
convenience all social action litigation, and to appoint Commissions for this purpose
is concerned, we endorse what one of us namely Bhagwati J., as he then was has said
in his judgment in Bandhuwa Mukti Morcha case. We need not repeat what has been
stated in that judgment.
7. We are also of the view that this Court under Art 32(1) is free to device any
procedure appropriate for the particular purpose of the proceeding, namely,
enforcement of a fundamental right and under Article 32(2) the Court has the implict
power to issue whatever direction, order or writ is necessary in a given case,
including all incidental or ancillary power necessary to secure enforcement of the
fundamental right. The power of the court is not only injunctive in ambit that is
preventing the infringement of a fundamental right, but it is also remedial in scope
and provides relief against a breach of the fundamental right already committed vide
Bandhua Mukti Morcha case. If the courts were powerless to issue any direction,
order or writ in cases where a fundamental right has already been violated. Article 32
would be robbed of all its efficacy, because then the situation would be that if a
fundamental right is threatened to be violated the Court can injunct such violation
but if the violator is quick enough to take action infringing the fundamental right, he
would escape from the net of Art. 32. That would to a large extent emasculate the
fundamental right guaranteed under Art. 32 and render it impotent and futile. We
must, therefore, hold that Article 32 is not powerless to assist a person when he finds
that his fundamental right has been violated. He can in that even seek remedial
assistance under Art. 32. The power of the Court to grant such remedial relief may
include the power to award compensation in appropriate cases. We are deliberately
using the words 'in appropriate cases' because we must make it clear that it is not in
every case where there is a breach of a fundamental right committed by the violator
that compensation would be awarded by the Court in a petition under Art 32. The
infringement of the fundamental right must be gross and patent that is,
incontrovertible and ex facie glaring and either such infringement should be on a
large scale affecting the fundamental rights of a large number of persons or it should
appear unjust or unduly harsh or oppressive on account of their poverty or disability
or socially economically disadvantaged position to require the person to personsAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

affected by such infringement to intiate and pursue action in the Civil Courts.
Ordinarily of course, a petition under Art. 32 should not be used as a substitute for
enforcement of the right to claim compensation for infringement of a fundamental
right through the ordinary process of civil court. It is only in exceptional cases of the
nature indicated by us above, that compensation may be awarded in a petition under
Art. 32. This is the principle on which this Court awarded compensation in Rudul Sah
Vs. State of Bihar. So also, this Court awarded compensation to Bhim Singh, whose
fundamental right to personal liberty was grossly violated by the State of Jammu and
Kashmir. If we make a fact analysis of the cases where compensation has been
awarded by this Court we will find that in all the cases the fact of infringement was
patent and incontrovertible the violation was gross and its magnitude was such as to
shock the conscience and of the court and it would have been gravely unjust to the
person whose fundamental right was violated to require him to go to the Civil Court
for claiming compensation.
8. The next question which arises for consideration on these applications for
compensation is whether Article 21 is available against Shriram which is owned by
Delhi Cloth Mills Limited, a public company limited by shares and which is engaged
in an industry vital to public interest and with potential to affect the life and health of
the people. The issue of availability of Art. 21 against a private corporation engaged in
an activity which has potential to affect the life and health of the people was
vehemently argued by counsel for the applicants and Shriram. It was emphatically
contended by counsel for the applicants with the analogical aid of the American
doctrine of State Action and the functional and control test ennunciated by this Court
in its earlier decisions, that Article 21 was available as Shriram was carrying on an
industry which, according to the governments own declared industrial policies, was
ultimately intended to be carried out by itself but instead of the Government
immediately embarking on that industry Shriram was permitted to carry it on under
the active control and regulation of the Government. Since the Government intended
to ultimately carry on this industry and the mode of carrying on the industry could
vitally affect public interest the control of the Government was linked to regulating
that aspect of the functioning of the industry which could vital ly affect public
interest. Special emphasis was laid by counsel for the applicants on the regulatory
mechanism provided under the Industries Development and Regulation Act, 1951
where industries are included in the schedule if they vitally affect public interest.
Regulatory measures are also to be found in Bombay Municipal Corporation Act, the
Air and Water Pollution Control Acts and now the recent Environment Protection
Act, 1956. Counsel for the applicants also pointed to us the sizable aid in loans, land
and other facilities granted by the Government to Shriram in carrying on the
industry. Taking aid of the American State Action doctrine it was also argued before
us on behalf of the applicants that private activity if supported, controlled or
regulated by the State may get so entwined with governmental activity as to be
termed State action and it would then be subject to the same constitutional restraints
on the exercise of power as the State.Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

20. In order to assess the functional role allocated to private corporation engaged in
the manufacture of Chemicals and fertilizers, we need to examine the Industrial
policy of the Government and see the public interest importance given by the State to
the activity carried on by such private corporation.
21. Under the Industrial Policy Resolution, 1956 industries were classified into three
categories having regard to the part which the State would play in each of them. The
first category was to be the exclusive responsibility of the State. The second category
comprised those industries which would be progressively State owned and in which
the State would therefore generally take the initiate in establishing new under takings
but in which private enterprise would also be expected to supplement the effort of the
State by promoting and developing undertakings either on its own or with State
participation. The third category would include all the remaining industries and their
future development would generally be left to the intiative and their future
development would generally be left to intiative and enterprise of the private sector.
Schedule B to the Resolution ennumberated the industries.
22. Appendix I to the Industrial Policy Resolution, 1948 dealing with the problem of
state participation in industry and the conditions in which private enterprise should
be allowed to operate state that there can be no doubt that the State must play a
progressively active role in the development of industries. However, under the
present conditions, the mechanism the resources of the State may not permit it to
function forthwith in industry as widely as may be desirable. The policy declared that
for some time to come, the State could contribute more quickly to the increase of
national wealth by expanding its present activities wherever it is already operating
and by concentrating on new units of production in other fields.
23. On these consideration the Government decided that the manufacture of arms
and ammunition the production and Control of atomic energy d the ownership and
management of railway transport would be the exclusive monopoly of the Central
Government. The establishment of a new undertakings in coal, iron and steel, aircraft
manufacture, ship building, manufacture of telephone, telegraph and wireless
appartus and minerals oils were o be the exclusive responsibility of the state except
where in national interest the State itself finds it necessary to secure the cooperation
of private enterprise subject to control of the Central Government.
24. The policy resolution also made mention of certain basic industries of importance
the planning and regulation of which by the Central Government was found
necessary in national interest. Among the eighteen industries so mentioned as
requiring such Central control, heavy Chemicals and fertilizers stood included.
25. In order to carry out the objective of the Policy Resolution the Industries
(Development and Regulation ) Act of 1951 was enacted which according to its objects
and reasons, brought under Central Control the development and regulation of aAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

number of important industries the activities of which affect the country as a whole
and the development of which must be governed by economic factors of all India
import. Section 2 of the act declares that it is expedient in the public interest that the
Union should take under its control the industries specified in the First Schedule.
Chemicals and Fertilizers find a place in the First Schedule as items 19 and 18
respectively.
26. If an analysis of the declarations in the Policy Resolution and the Act is
undertaken, we find that the activity of producing Chemicals and fertilizers is deemed
by the State to be an industry of vital public interest, whose public import
necessitates that the activity should be ultimately carried out by the State itself,
though in the interim period with State support and under State control, private
corporations may also be permitted to supplement the State effort. The argument of
the applicants on the basis of this premise was that in view of this declared industrial
policy of the State, even private corporations manufacturing Chemicals and fertilizers
can be said to be engaged in activities which are so fundamental to the society as to
be necessarily considered government functions.
27. It was pointed out on behalf of the applicants that as Shriram are registered under
the Industries Development and Regulaion Act, 1951 its activities are subject to
extensive and deviled control and supervision by the Government. Under the Act a
licence is necessary for the establishment of a new industrial undertaking or
expansion of capacity or manufacture of new article by an existing industrial
undertaking carrying on any of the scheduled industries included in the First
Schedule of the Act. By refusing licence for a particular unit, the Government can
prevent over concentration in a particular region or over investment in a particular
industry. Moreover, by its power to specify the capacity in the licence it can also
prevent over development of a particular industry, if it has already reached target
capacity. Sec. 18G of the Act empowers the Government to control the supply,
distribution, price etc of the articles manufactured by a schedule industry and under
Section 18-A Government can assume management and control of an industrial
undertaking engaged in a scheduled industry if after investigation it is found that the
affairs of the undertaking are being managed in a manner detrimental to public
interest and under Section 18-AA in certain emergent cases takeover is allowed even
without investigation. Since Shriram is carrying on a schedule industry. It is subject
to this stringent system of registration and licensing. It is also amenable to various
directions that may be issued by the Government from time to time and it is subject
to the exercise of the powers of the government under Section 18-A, 18-AA and 18-G.
28. Shriram is required to obtain a licence under the Factories Act and is subject to
the directions and orders of the authorities under the Act. It is also required to obtain
a licence for its manufacturing activities from the Municipal authorities undue the
Delhi Municipal Act, 1957. It is subject to extensive environment regulation under the
Water (Prevention and Control of Pollution) Act, 1974 and as the factory is situated inAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

an air pollution control area, it is also subject o the regulation of the air (Prevention
and Control of Pollution ) Act 1981. It is true that control is not exercised by the
Government in relation to the internal management policies of the company.
However, the control is exercised on all such activities of Shriram which can
jeopardize public interest. This functional control is of special significance as it is the
potentiality of the fertilizer industry to adversely affect the health and safety of the
community and its being impregnated with public interest which perhaps dictated
the policy decisions of the government to ultimately operate this industry exclusively
and invited function control. Along with this extensive functional control, we find
that Shriram also receives sizable assistance in the shape of loans and overdrafts
running into several crores of rupees from the government through various agencies.
Moreover, Shriram is engaged in the manufacture of caustic soda, chlorine etc. Its
various units are set up in a single complex surrounded by thickly populated colonies.
Chlorine gas is admittedly dangerous to life and health. If the gas escapes either from
the storage tank or from the filled cylinders or from any other point in the course of
production the health and well brig of the people living in the vicinity can be seriusly
affected. Thus Shriram is engaged in an activity which has the potential to invade the
right to life of large sections of people. The question is whether these factors are
cumulative sufficient to bring Shriram within the ambit of Art. 12. Prima facie it is
arguable that when the State's power as economic agent, economic entrepreneur and
allocate of economic benefits is subject to the limitations of fundamental rights (Vide
Eurasian Equipment and Chemicals Ltd Vs. State of West Bengal, , Rashbihari Panda
Vs. State of Orissa , R.D. Shetty Vs. International Airports Authority AND Kasturi Lal
Reddy Vs. State of J & K (1980 SCC 1 ) why should a private corporation under the
functional control of the State engaged in an activity which is hazardous to the health
and safety of the community and is imbued with public interest and which the State
ultimately proposes to exclusively run under its industrial policy, now be subject to
the sameimitations. But we do not propose to decide this question and made any
definite pronouncement upon it for reasons which we shall point out later in the
course of this judgment.
29. We were during the course of arguments, addressed at great length by counsel on
both sides on the American doctrine of State action. The learned counsel elaborately
traced the evolution of this doctrine in its parent country. We are aware that in
America since the Fourteenth Amendment is available only against the State, the
courts in order to thwart racial discrimination by private parties devised the theory of
State action under which it was held that wherever private activity was aided,
facilitated or supported by the State in a significant measure such activity took the
colour of State action and was subject to the constitutional limitations of the
Fourteenth Amendment. This historical context in which the doctrine of State action
evolved in the United States is irrelevant for our purpose especially since we have Art
15(2) in our Constitution. But it is the principle behind the doctrine of State aid,
control and regulation so impregnating a private activity as to give it the colour of
State action that is of interest to us and that also to the limited extent to which it canAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

be Indianized and harmoniously blended with our constitutional jurisprudence. That
we in no way consider ourselves bound by American exposition of constitutional law
is well demonstrated by the fact that in R.D. Shetty this Court preferred the minority
opinion of Douglas, J. in Jackson Vs. Metropolitan Edison Company as against the
majority opinion of Rehnquist J. And again in Air India Vs. Nergesh Meerza this
court whilst preferring the minority view in General Electric Company Vs. Martha V.
Gilbert said that the provisions of the American constitution cannot always be
applied to Indian conditions or to provisions of our Constitution and whilst some of
the principles adumbreated by the American decisions may provide a useful guide.
Close ad hereto those principles while applying them to the provisions of our
Constitution is not to be favoured because the social conditions in our country are
different.
30. Before we part with this topic we may point out that this Court has throughout
the last few years expanded the horizon of Art. 21 primarily to inject respect for
human rights and social conscience in our corporate structure. The purpose of
expansion has not been to destroy the raisin d'etre of creating Corporations but to
advance the human rights jurisprudence. Prima facie we are not inclined to accept
the apprehensions of learned counsel for Shriram as well founded when he says that
our including within the ambit of Article 12 and thus subjecting to the displine of Art.
21, those private corporations whose activities have the potential of affecting the life
and health of the people would deal a death blow to the policy of encouraging and
permitting private entrepreneurial activity. Whenever a new advance is made in the
field of human rights, apprehension is always expressed by the status quoists that it
will create enormous difficulties in the way of smooth functioning of the system and
affect its stability. Similar apprehension was voiced when this Court in R.D. Shetty
case brought public sector corporations within the scope and ambit of Art. 12 and
subjected them to the discipline of fundamental rights. Such apprehension expressed
by those who may be affected any new and innovative expansion of human rights
need not deter the court from widening the scope of human rights and expanding
their reach and ambit, if otherwise it is possible to do so without doing violence to the
language of the constitutional provision. It is through creative interpretation and
bold innovation that the human rights jurisprudence has been developed in our
country to a remarkable extent and this forward march of the human rights
movement cannot be allowed to be halted by unfounded apprehensions expressed by
the status quoists. But we do not propose to decide finally at the present whether a
private corporation like Shriram would fall within the scope and ambit of Art 12
because we have not had sufficient time to consider and reflect on this question in
depth. The hearing of this case before us concluded only on December 15, 1986 and
we are called upon to deliver our judgment within a period of four days, on December
1986. We are therefore of the view that this is not a question on which we must make
any definite pronouncement at this stage. But we would leave it for a proper and
detailed consideration at a later stage if it becomes necessary to do so.Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

31. We must also deal with one other question which was seriously debate d before us
and that question ix as to what is the measure of liability of an enterprise which is
engaged in an hazardous or inherently dangerous industry, if by reason of an accident
occuring in such industry, persons die or are injured. Does the rule in Rylands Vs.
Fletcher, (1868) LR 3 HL 330 apply or is there any other principle on which the
liability can be determined. The rule in Rylands Vs. Fletcher was evolved in the year
1866 and it provides that a person who for his own purposes brings on to his land and
collects and keeps there anything likely to do mischief if it escapes must keep it at his
peril and if he fails to do so, is prima facie liable for the damage which is the natural
consequences of its escape. The liability under this rule is strict and it is no defense
that the thing escaped without that persons wilful act, default or neglect or even that
he had no knowledge of its existence. This rule laid down a principle of liability that if
a person who brings on to his land and collects and keeps there anything likely to do
harm and such thing escapes and does damage to another he is liable to compensate
for the damage cause. Of course, this rule applies only to non natural user of the land
and it does not apply to things naturally on the land or where the escape is due to an
act of Govt. and an act of a stranger or the default of the person injured or where the
thing which escapes is present by the consent of the person injured or in certain cases
where there is statutory authority. Vide Halsbury's Laws of England, vol 45, para
1305. Considerable case law has developed in England as to what is natural and what
is non natural use of land and what are precisely the circumstances in which this rule
may be displaced. But it is not necessary for us to consider these decisions laying
down the parameters of this rule because in a modern industrial society with highly
developed scientific knowledge and technology where hazardous or inherently
dangerous industries are necessary to carry as part of the development programme,
this rule evolved in the 19th century at a time when all these developments of science
and technology had not taken place consistent with the constitutional norms and the
needs of the present day economy and social structure. We need not feel inhibited by
this rule which was evolved in the context of a totally different kind of economy. Law
has to grown in order to satisfy the needs of the fast changing society and keep
abreast with the economic developments taking place in the country. As new
situations are arise the law has to be evolved in order to meet the challenge of such
new situations. Law cannot afford to remain static. We have to evolve new principles
and lay down new norms which would adequately deal with the new problems which
arise in a highly industrialised economy. We cannot allow our judicial thinking to be
constricted by reference to the law as it prevails in England or for the matter of that
in any other foreign country. We no longer need the crutches of a foreign legal order.
We are certainly prepared to receive light from whatever source it comes but we have
to build our own jurisprudence and we cannot countenance an argument that merely
because the law in England does not recognise the rule of strict and absolute liability
in cases of hazardous or inherently dangerous activities of the rule laid down in
Rylands Vs. Fletcher as developed in England recognise certain limitations and
exceptions, we in India must hold back and not venture to evolve a new principle of
liability since English courts have not done so. We have to develop our own law and ifAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

we find that it is necessary to contract a new principle of liability to deal with an
unusual situation which has arisen and which is likely to arise in future on account of
hazardous or inherently dangerous industries which are concomitant to an industrial
economy, there is no reason why we should hesitate to evolve such principle of
liability merely because it has not been so done in England. We are of the view that
an interprise which is engaged in a hazardous or inherently dangerous industry
which poses a potential threat to the health and safety of the persons working in the
factory and residing in the surrounding areas owes an absolute and non elegable duty
to the community to ensure that no harm results to anyone on account of hazardous
or inherently dangerous nature of the activity which it has under taken. The
enterprise must be held to be under an obligation to provide that the hazardous or
inherently dangerous activity in which it is engaged must be conducted with the
highest standards of safety and if any harm results on account of such activity the
enterprise must be absolutely liable to compensate for such harm and it should be no
answer to the enterprise to satisfy that it had taken all reasonable care and that the
harm occurred without any negligence on its part. Since the persons harmed on
account of the hazardous or inherently dangerous activity carried on by the
enterprise would not be a in a position to isolate the process of operation from the
hazardous preparation of substance or any other related element that caused the
harm the enterprise must be held stricly liable for causing such harm as a part of the
social cost of carrying on the hazardous or inherently dangerous activity. If the
enterprise is permitted to carry on an hazardous or inherently dangerous activity for
its profit, the law must presume that such permission is conditional on the enterprise
absorbing the cost of any accident arising on account of such hazardous or inherently
dangerous activity as an appropriate item of its overheads. Such hazardous or
inhrently dangerous activity for private profit can be tolerated only on condition that
the enterprise engaged in such hazardous or inherently dangerous activity
indemnifies all those who suffer on account of the carrying on of such hazardous or
inherently dangerous activity regardless of whether it is carried on carefully or not.
This principle is also sustainable on the ground that the enterprise alone has the
resource to discover and guard against hazards or dangers and to provide warning
against potential hazards. We would therefore hold that where an enterprise is
engaged in a hazardous or inherently dangerous activity and harm results to anyone
on account of an accident in the operation of such hazardous or inherently dangerous
activity resulting, for example, in escape of toxic gas the enterprise is strictly and
absolutely liable to compensate all those who are affected by the accident and such
liability is not subject to any of the exceptions which operate visa-vis the tortuous
principle of strict liability under the rule in Rylands Vs. Fletcher.
50. Mr. Tulsi also relied on the case of Kahtri and Ors. (IV) Vs. State of Bihar and Ors. . In this case
it is inter alia held as follows :
"7. That takes us to the question whether the reports made by Shri L.V. Singh as a
result of the investigation carried by him and his associates are relevant under anyAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

provision of the Indian Evidence Act so as to be liable to be produced and received in
evidence. It is necessary, in order to answer this question, to consider what is the
nature of the proceeding before us and what are the issues which arise in it. The
proceeding is a Writ Petition under Article 32 for enforcing the fundamental rights of
the Petitioners enshrined in Article 21. The petitioners complaint that after arrest,
whilst under police custody, they were blinded by the members of the police force,
acting not in their private capacity but as police officials and their fundamental right
to life guaranteed under Article 21 was therefore violated and for this violation the
State is liable to pay compensation to them. The learned Attorney -General who at
one stage appeared on behalf of the State at the hearing of the Writ Petition
contended that the inquiry upon which the court was embarking the order to find out
whether or not the petitioners were blinded by the police officials whilst in police
custody was irrelevant, since in his submission, even if the petitioners were so
blinded, the State was not liable to pay compensation to the petitioner first, because
the State was not constitutionality or legally responsible for the acts of the police
officers outside the scope of their power or authority and the blindings of the
underrial prisoners effected by the police could not therefore be said to constitute
violation of their fundamental, right under Article 21 by the State and secondly, even
if there was violation of the fundamental right of the petitioners under Article 21 by
reason of the blindings effected by the police officials, there was, on a true
construction of that Article, no liability on the State to pay compensation to the
Petitioners. The attempt of the learned Attorney General in advancing the contention
was obviously to prempt the enquiry which was being made by this Court so that the
Court may not proceed to probe further in the matter. But we do not think we can
accede to this contention of the learned AttorneyGeneral. The two questions raised by
the learned Attorney General are undoubtedly important but the arguments urgent
by him in regard to these two questions are not prima facie so strong and appalling as
to persuade us to decide them as preliminary objections without first inquiring into
the facts. Some serious doubts arise when we consider the argument of the learned
Attorney General. If an officers of the State acting in his official capacity threatens to
deprive a person of his life or personal liberty without the authority of law, can such
person not approach the court for injunction the State from acting through such
officer in violation of his fundamental right under Article 21 ? Can the State urge in
defense in such a case that it is not infringing the fundamental right of the Petitioner
under Article 21 because the officer who is threatening to do so is acting outside the
law and therefore beyond the scope of his authority and hence the State is not
responsible for his action Would this not make a mockery of Article 21 and reduce it
to nullity a mere rope of sand, for, on this view, if the officer is acting according to law
there would ex concession is be no breach of Article 21 and if he is acting without the
authority of law, the State would be able to contend that it is not responsible for his
action and therefore there is no violation of article 21. So also if there is any
threatened invasion by the State of the fundamental right guaranteed under Article
21, the Petitioner who is aggrieved can move the court under Article 32 for a writ
injuncting such threatened invasion and if there is any continuing action of the StateAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

which is violative of the fundamental right under Article 21, the Petitioner can
approach the Court under Article 32 and ask for a writ striking down the continuance
of such action, but where the action taken by the State has already resulted in breach
of the fundamental right under Article 21 by deprivation of some limb of the
Petitioner, would be Petitioner have no remedy under Article 32 for beach of the
fundamental right guarantee to him ? Would the Court permit itself to become
helpless spectator of the violation of the fundamental right of the Petitioner by the
State and tell the Petitioner that though the Constitution has guaranteed the
fundamental right to him and has also given him the fundamental right of moving the
court for enforcement of his fundamental right, the Court cannot give him any relief.
These are some of the doubts which arise in our mind even in a prima facie
consideration of the contention of the leaned Attorney General and we do not
therefore, think it would be right to entertain this contention as a preliminary
objection without inquiring into the facts of the case. If we look at the averments
made in the Writ Petition it is obvious that the Petitioners cannot succeed in claiming
relief under Article 32 unless they establish that their fundamental right under
Article 21 was violated and in order to establish such violation, they must show that
they were blinded by the police officials at the time of arrest or whilst in police
custody. This is the foundational fact which must be established before the Petitioner
can claim relief under Article 32 and logically therefore the first issue to which we
must address ourselves is whether the foundational fact is shown to exist by the
Petitioners. It is only if the Petitioners can establish that they were blinded by the
members of the police force at the time of arrest or whilst in police custody that the
other questions raised by the learned Attorney General would arise for consideration
and it would be wholly academic to consider them if the petitioners fail to establish
this foundational fact. We are, therefore, of the view, as at present advised, that we
should first inquire whether the petitioners were blinded by the police officials at the
time of arrest or after arrest whilst in police custody, and it is in the context of this
inquiry that we must consider whether the reports made by Shri L.V. Singh are
relevant under the Indian Evidence Act so as to be receivable in evidence."
"8. We may at this stage refer to one other contention raised by Mr. K.G. Bhagat on
behalf of the State that if the Court proceeds to hold an inquiry and comes to the
conclusion that the petitioners were blinded by the members of the police force at the
time of arrest or whilst in police custody, it would be tantamount to adjudicating
upon the guilt of the police officers without their being parties to the present Writ
Petition and that would be grossly unfair and hence this inquiry should not be held by
the Court until the investigation is completed and the guilt or innocence of the police
officer is established. We cannot accept this contention of Mr. K.G. Bhagat. When the
court trying the Writ Petition proceeds to inquire into the issue whether the
petitioners were blinded by the police officials at the time of arrest or whilst in police
custody, it does so, not for the purpose of adjudicating upon the guilt of any
particular officer with a view to punishing him but for the purpose of deciding
whether the fundamental right of the petitioners under Article 21 has been violatedAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

and the State is liable to pay compensation to them for such violation. The nature and
object of the inquiry is altogether different from that in a criminal case and any
decision arrived at in the Writ Petition on this issue cannot have any relevant much
less any binding effect, in any criminal proeeding which may be taken against a
particular police officer. A situation of this kind sometimes arises when a claim for
compensation for accident caused by negligent driving of a motor vehicle is made in a
civil court or tribunal and in such a proceeding, it has to be determined by the court
for the purpose of awarding compensation to the claimant, whether the driver of the
motor vehicle was negligent in driving, even through a criminal case for rash and
negligent driving may be pending against the driver. The pendency of a criminal
proceeding cannot be urged as a bar against the court trying a civil proceeding or a
Writ Petition where a similar issue is involved. The two are entirely distinct and
separate proceedings and neither is a bar against the other. It may be that in a given
case, if the investigation is still proceeding, the court may defer the inquiry before it
until the investigation is completed or if the court considers it necessary in the
interest of justice, it may postpone its inquiry even after the prosecution following
upon the investigation is terminated, but that a matter entirely for the exercise of the
discretion of the court and there is no bar precluding the court from proceeding with
the inquiry before it merely because the investigation or prosecution is pending."
51. Mr. Tulsi also relied on the case of Consumer Education Research Centre Vs. UOI, . In this case
the Supreme Court relied on the case of Nilabeti Behra and held that directions could be given to
State or its undertakings/instrumentalities, companies or even private employers to make right to
life meaningful. The Supreme Court directed the State Govt. to ensure that certain standards were
maintained in condition of works in Asbestos industries. The Supreme Court held private parties i.e.
the employers liable to provide protection measures and directed payment of compensation of Rs. 1
lakh to each affected worker.
52. Mr. Tulsi also relied on the case of N. Nagendra Rao & Co. Vs. State of Andhra Pradesh . It was
held by the Supreme Court :
"However, since 1965 when this decision was rendered the law on vicarious liability
has marched ahead. The ever increasing abuse of power by public authorities and
interference with life and liberty of the citizens arbitrarily, coupled with
transformation in social outlook with increasing emphasis on human liberty resulted
in more pragmatic approach to the individuals dignity, his life and liberty and carving
out of an exception by the court where the abuse of public power was violative of the
constitutional guarantee. Such infringements have been held to be wrong in public
law which do not brook any barrier and the State has been held liable to compensate
the victims. (See Rudul Sah, Vs. State of Bihar, Sebastian M. Hongray Vs. Union of
India, Saheli, A Women's Resources Centre Vs. Commissioner of Police, Delhi Police
headquarters, State of Maharashtra Vs. Ravikant S. Patil). In Nilabati Behera Vs.
State of Orissa Hon'ble Mr. Justice J.S. Verma observed as under: (SCC p. 758, para
10).Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

"It may be mentioned straightway that award of compensation in a proceeding under
Article 32 by this Court or by the High Court under Article 226 of the Constitution is
a remedy available in public law, based on strict liability for contravention of
fundamental rights to which the principle of sovereign immunity does not apply, even
though it may be available as a defense in private law in an action based on tort."
In the same decision, it was observed by Hon'ble Dr. Justice A.S. Anand (SCC p. 768, para 34).
"The purpose of public law is not only to civilize power but also to assure the citizen
that they live under a legal system which aims to protect their interests and preserve
their rights."
53. Mr. Tulsi also referred to a case reported 1998 (1) SCC Journal Section Pg. 1. In this case, the
Supreme Court whilst considering grant of compensation as exemplary damages, held as follows:
"Therefore, when the court moulds the relief by granting 'compensation' in
proceedings under Articles 32 or 226 of the Constitution seeking enforcement or
protection of fundamental rights, it does so under the public law by way of penalizing
the wrongdoer and fixing the liability for the public wrong on the State which has
failed in its public duty to protect the fundamental rights of the citizen. The payment
of compensation in such cases is not to be understood as it is generally understood in
a civil action for damages under the private law but in the broader sense of providing
relief by an order of making monetory amends under the public law for the wrong
done due to breach of public duty of not protecting the fundamental rights of the
citizen. The compensation is in the nature of exemplary damages awarded against the
wrongdoer for the breach of its public law duty and is independent of the rights
available to the aggrieved party to claim compensation under the private law in an
action based on tort, through a Suit instituted in a court of competent jurisdiction
or/and prosecute the offender under the penal law."
54. Mr. Tulsi also relied on the case of Punjab & Haryana High Court Bar Association Vs. State of
Punjab, . In this case, it was alleged that an advocate, his wife and child were abducted and
murdered by the Police. Facts were highly disputed. Supreme Court deprecated inaction on the part
of the High Court and directed CBI to in ivestigate and report. CBI submitted its report. The facts set
out in the Report were disputed. Further prosecution had already been launched against seven
police officers and the trial was in progress. Even though there was no proof and even though there
parties had had no opportunity to test evidence by crossxamination, the Supreme Court held that
the report of CBI casts a finger of suspicion at the police officers. On this finger of suspicion and
relying upon Nilabati's case the Supreme Court awarded damages even through facts were highly
disputed and denied.
55. Mr. Tulsi also relied on the case of Common Cause Registered Society Vs. UOI . In this case it
was held that exemplary damage can be awarded by the Court for oppressive, arbitrary and
unconstitutional action of servants of Govt. and Police.Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

56. Mr. Tulsi also relied on the case of Secretary Jaipur Devpt. Authority Vs. Daulat Mal Jain, . In
this case the Supreme Court set aside a policy of allotment of land to private parties.
57. Mr. Tulsi also relied on the case of, Rudul Sah Vs. State of Bihar And Anr. , wherein it was held
as follows :
The Petitioner had been acquitted on 3rd June, 1968. He was however released from
jail only on 16th October, 1982 i.e. after more than 14 years after he was acquitted.
"8. That takes us to the question as to how the grave injustice which has been
perpetrated upon the Petitioner can be rectified, in so far as it lies within our power
to do in the exercise of our writ jurisdiction under Article 32 of the Constitution. That
Article confers power on the Supreme Court to issue directions or orders or writs,
including writs in the nature of habeas corpus, mandamus, prohibition, quo warranto
and certiorari, whichever may be appropriate, for the enforcement of any of the rights
conferred by Part III. The right to move the Supreme Court by appropriate
proceedings for the enforcement of the rights conferred by Part III is 'guaranteed'
that is to say, the right to move the Supreme Court under Article 32 for the
enforcement of any of the rights conferred by Part III of the Constitution is itself a
fundamental right.
9. It is true that Article 32 cannot be used as a substitute for the enforcement of rights
and obligations which can be enforced efficaciously through the ordinary processes of
courts, civil and criminal. A money claim has therefore to be agitated in and
adjudicated upon in a Suit instituted in a court of lowest grade competent to try it.
But the important question for our consideration is whether in the exercise of its
jurisdiction under Article 32, this Court can pass an order for the payment of money
if such an order is in the nature of compensation consequential upon the deprivation
of a fundamental right. The instant case is illustrative of such cases. The Petitioner
was detained illegally in the prison for over 14 years after his acquittal in a fulldressed
trial. He filed a habeas corpus Petition in this Court for his release from illegal
detention. He obtained that relief, our finding being that his detention in the prison
after his acquittal was wholly unjustified. He contends that he is entitled to be
compensated for his illegal detention and that we ought to pass an appropriate order
for the payment of compensation in this habeas corpus Petition itself.
10. We cannot resist this argument. We see no effective answer to it save the stale and
sterile objection that the Petitioner may, if so advised, file a Suit to recover damages
from the State Government. Happily, the States counsel has not raised that objection.
The Petitioner could have been relegated to the ordinary remedy of a Suit if his claim
to compensation was factually controversial, in the sense that a Civil Court may or
may not have upheld his claim. But we have no doubt that if the Petitioner files a Suit
to recover damages for his illegal detention, a decree for damages would have to be
passed that Suit, though it is not possible to predicate, in the absence of evidence, theAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

precise amount which would be decreed in his favour. In these circumstances, the
refusal of this Court to pass an order of compensation in favour of the Petitioner will
be doing mere lip service to his fundamental right to liberty which the State Govt. has
so grossly violated. Article 21 which guarantees the right to life and liberty will be
denuded of its significant content if the power of this Court were limited to passing
orders of release from illegal detention. One of the telling ways in which the violation
of that right can reasonably be prevented and due compliance with the mandate of
Article 21 secured is to mulct its violators in the payment of monetary compensation.
Administrative sclerosis leading to flagrant infringements of fundamental rights
cannot be corrected by any other method open to the judiciary to adopt. The right to
compensation is some palliative for the unlawful acts of instrumentalities which act
in the name of public interest and which present for their protection the powers of
the State as a shield. If civilization is not to perish in this country as it has perished in
some others too wellnown to suffer mention, it is necessary to educate ourselves into
accepting that respect for the rights of individuals is the true bastion of democracy.
Therefore, the State must repair the damage done by its officers to the Petitioner's
rights. It may have recourse against those officers.
11. Taking into consideration the great harm done to the Petitioner by the
Government of Bihar, we are of the opinion that as an interim measure, the State
must pay to the Petitioner as further sum of Rs. 30, 000/ (Rupees thirty thousand) in
addition to the sum of Rs. 5,000/- (Rupees five thousand) already paid by it. The
amount shall be paid within two weeks from today. The Government of Bihar agrees
to make the payment though, we must clarify, our order is not based on their consent.
12. This order will not preclude the Petitioner from bringing a Suit to recover
appropriate damages from the State and its erring officials. The order or
compensation passed by us is, as we said above, in the nature of a palliative. We
cannot leave the Petitioner penniless until the end of his Suit, the many appeals and
the execution proceedings. A fullressed debate on the nice points of fact and law
which takes place leisurely in compensation suits will have to await the filing of such
a Suit by the poor Rudul Sah. The Leviathan will have liberty to raise those points in
that Suit. Until then, we hope, there will be more Rudul Sah in Bihar or elsewhere."
58. Mr. Tulsi also relied on the case of Manju Bhatia Vs. NDMC, . In this case a builder had
constructed a building in breach of municipal regulation and this resulted in demolition of top four
floors. The builder had sold the flats in these top flour floors to various persons. The Supreme Court
confirmed award of damage against the builder which consisted not just return of costs received by
the builder but also the escalated value of flats.
59. Mr. Tulsi also relied on the case of SAHELI, A Women's Resources Centre Vs. Commissioner of
Police and Ors. . This Writ Petition was filed by a Women's and Civil Rights Organisation (SAHELI)
on behalf of two women who were beaten up, allegedly, by the SHO and Police in collusion with
landlord. In this case, the Lt. Governor Ordered an enquiry. The Enquiry Committee, which wasAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

only a fact finding body, gave a Report. The Report inter alia held as follows.
"So far as it seems that there is a high level conspiracy in getting the rooms of tenants
got vacated by the landlord if the accused is bailed out, it will be difficult to find out
the truth. Smt. Shobha and the doctor are already under pressure. As the local police
is involved in all this episode so being out the accused will definitely affect the fate of
the case. The accused should not be bailed out as it is clear case u/s 302/120B IPC.
The details of DD entries mentioned in the bail application itself show the conspiracy
or connivance of the local police with the accused. Therefore, the bail is opposed
strongly."
The Supreme Court held as follows:
"10. It is now apparent from the report dated December 5, 1987 of the Inspector of
the Crime Branch, Delhi as well as the counteraffidavit of the Deputy Commissioner
of Police,Delhi on behalf of the Commissioner of Police Delhi and also from the fact
that the prosecution has been launched in connection with the death of Naresh, son
of Kamlesh Kumar showing that Naresh was done to death on account of the beating
and assault by the agency of the sovereign power acting in violation and excess of the
power vested in such agency. The mother of the child Kamlesh Kumari, in our
considered opinion, is so entitled to get compensation for the death of her son from
Respondent 2, Delhi Administration.
11. An action for damages lies for bodily harm which includes battery, assault, false
imprisonment, physical injuries and death. In case of assault, battery and false
imprisonment the damages are at large and represent a solatium for the mental pain,
distress, indignity, loss of liberty and death. As we have held hereinbefore that the
son of Kamlesh Kumari aged 9 years died due to beating and assault by the SHO, Lal
Singh and as such she is entitled to get the damages for the death of her son. It is well
settled now that the State is responsible for the tortious acts of its employees.
Respondent No. 2, Delhi Administration is liable for payment of compensation to
Smt. Kamlesh Kumari for the death of her son due to beating by the SHO of Anand
Parbat Police Station, Shri Lal Singh.
10. 12. It is convenient to refer in this connection the decision in Joginder Kaur Vs.
Punjab State, 1969 ACJ 28, 32 (P&H) wherein it has been observed that :
"In the matter of liability of the State for the torts committed by its employees, it is
now the settled law that the State is liable for tortious acts committed by its
employees in the course of their employment".
11. 13. In State of Rajasthan Vs. Vidhyawati, 1962 Supp (2) 989, it has been held that: (SCR p. 1007)
"Viewing the case from the point of view of first principles, there should be no difficulty in holding
that the State should be as much liable for tort in respect of tortuous act committed by its servantAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

within the scope of his employment and functioning as such as any other employer. The immunity of
the Crown in the United Kingdom was based on the old feudalistic notions of justice, namely that
the king was incapable of doing a wrong, and therefore, of authorizing or instigating one, and that
he could not be sued in his own courts. In India, ever since the time of the East India Company the
sovereign has been held liable to be sued in tort or in contract, and the Common Law immunity
never operated in India."
12. 14. In Peoples Union for Democratic Rights Vs. Police Commissioner, Delhi Police Headquarters,
, one of the labourers who was taken to the police station for doing some work and on demand for
wages was severely beaten and ultimately succumbed to the injuries. It was held that the State was
liable to pay compensation and accordingly directed that the family of the deceased labourer will be
paid Rs. 75,000/- as compensation.
13. 15. On a conspectus of these decisions we deem it just and proper to direct the Delhi
Administration, Respondent 2 to pay compensation to Kamlesh Kumari, mother of the deceased,
Naresh a sum of Rs. 75,000/- with in a period of four weeks from the date of this judgment. The
Delhi Administration may take appropriate steps for recovery of the amount paid as compensation
or part thereof from the officers who will be found responsible, if they are so advised. As the police
officers are not parties before us, we state that any observation made by us in justification of this
order shall not have any bearing in any proceedings specially criminal prosecution pending against
the police officials in connection with the death of Naresh. The writ petitions are disposed of
accordingly."
60. Mr. Tulsi also relied on the case of Charan Sahu Vs. UOI . In this case the validity of The Bhopal
gas Leak disaster (processing of Claims) Act, 1985 had been challenged interlia on the grounds that
it violated the fundamental rights guaranteed under Articles 14, 19 and 21. The Supreme Court
upheld the validity of the said Act.
61. Mr. Tulsi submitted that wanton, reckless, malicious and oppressive character of the acts of the
respondents is writ large in the facts and circumstances of the case. He submitted that such acts
deserve grant of exemplary damages to punish the Respondents and to deter the others from similar
extreme misconduct in the future. He submitted that exemplary damages deserve to be awarded in
view of the enormity of the misconduct, both of the public authorities, as well as the owners, for the
public duties which they failed to discharge. In this regard Mr. Tulsi relies on certain passage from
22 American Jurisprudence 2 D Pg. 783 and 25 Corpus Juris Secundem Pg. 1107-1113. In these
books it has been stated that exemplary damages are awarded by way of punishment, to the offender
and as a deterrent warning and expression of indignation they have reference to the future rather
than to the past, imposed in order to admonish (the Defendant) not to repeat the wrongful act and
to deter others from the commission of like ills_ a reward for public service to the plaintiff for
bringing the wrongdoer to justice.
62. Mr. Tulsi also relied on Hallsburry's Laws of England, 4th Edition, Volume 12, Pg. 431 Art 113
wherein it has been set out that Courts can have a public or social policy whereby a legal authority is
held to be liable for negligence of its building inspector.Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

63. Mr. Tulsi submitted that the culture of sacrificing public good for personal gains and
subservience of public authority, to the business houses can only be reversed by awarding exemplary
damages against the public authorities as well as the owners. He submits that until and unless the
extent of damages is painful enough to the Respondents, it will fail to set an example to similarly
situated persons, that sacrificing public good is neither safe nor good business. He submits that
keeping in view the size of the business empire, of the owners of Uphaar, Rs. 100 crores may be just
about sufficient to cause them the requisite pain and discomfort, and remind the others that if they
continue to sacrifice the general welfare of their patrons, they would meet the same fate.
64. Mr. Tulsi submitted that the owners/licensee of Uphaar Cinema can not wriggle out of their
liability to compensate the Petitioner for the irreperable loss by taking protection of being a private
party and thereby being not amenable to the writ jurisdiction of this Hon'ble Court. He submitted
that Section (6) of Delhi Cinematograph Rules, 1981 clearly lays down that the licensee shall be
responsible for all acts and omissions of his manager, servants or agents which are committed or
made with his knowledge and consent and arising out or in connection with the cinema to which his
license relates. He submitted that a statutory duty is cast upon the owner/licensee under the rules
for observance of all safety measures pre scribed in the law. He submitted that any violation made
intentionally to subvert the statutory duty cast upon them for the reason of public safety and interest
makes them liable and responsible under the Writ Jurisdictin exercised by this Hon'ble Court. In
support of this Mr. Tulsi relies on the case of Unnikrishnan & Ors Vs. State of Andhra Pradesh, . In
this case the scope and ambit of Article 21 was dis cussed at great length. It was inter alia held that
the State can be directed to ensure observance of ligislation and can be made liable for inaction on
their part in securing implemenatation of legislation as non ensurance of implementation would
amount to denial of the right to live with human dignity as enshrined in Article 21. It was also held
that the term 'Authority' used in Article 226, the context must receive a liberal meaning unlike the
term in Article 12. It was held that Article 12 was relevant only for the purpose of enforcement of
fundamental rights under Article 32. It was held that Article 226 confers power on the High Courts
to issue writs for enforcement of the fundamental rights as well as non fundamental rights. It was
held that the words any person or authority used in Article 226 are not to be confined only to
statutory authorities and instrumentalities of the State but that they may cover any other person or
body performing public duty. It was held that the form of the body concerend was not very much
relevant. It was held that what was relevant was the nature of the duty imposed on the body. It was
held that the duty must be judged in the light of positive obligation owed by the person or authority
to the affected party. It was held that it did not matter by what means the duty was imposed. It was
held that if a positive obligation existed mandamus could not be denied.
65. Mr. Tulsi also relied on the case of Andi Mukti Trust Vs. V.R. Rudani . In this case the question
was whether a private body was amenable to writ jurisdiction of the High Court. It has been inter
alia held that "15. If the rights are purely of a private character no mandamus can issue. If the
management of the college is purely a private body with no public duty mandamus will not lie. These
are two exceptions to mandamus. But once these are absent and when the party has no other equally
convenient remedy, mandamus cannot be denied. It has to be appreciated that the appellant's trust
was managing the affiliated college to which public money is paid as government aid. Public money
paid as government aid plays a major role in the control, maintenance and working of educationalAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

institutions. The aided institutions like government institutions discharge public function by way of
imparting education to students. They are subject to the Rules and regulations of the affiliating
University. The University authorities closely super vise their activities. Employment in such
Iinstitutions, therefore, is not devoid of any public character. So are the service conditions of the
academic staff. When the University takes a decision regarding their scales, it will be binding on the
management. The service conditions of the academic staff are, therefore, not purely of a private
character. It has superdded protection of University decisions creating a legal rightuty relationship
between the staff the management. When there is existence of this relationship, mandamus cannot
be refused to the aggrieved party.
16. The law relating to mandamus has made the most spectacular advance. It may be recalled that
the remedy by prerogative writs in England started with very limited scope and suffered from many
procedural disadvantages. To overcome the difficulties, Lord Gardiner (the Lord Chancellor) in
pursuance of Section 3(1)(e) of the Law Commission Act, 1965, requested the Law Commission 'to
review the existing remedies for the judicial control of administrative acts and omissions with a view
to evolving a simpler and more effective procedure". The Law Commission made their report in
March, 1976 (Law Commission Report No. 73). It was implemented by Rules of Court (Order 53) in
1977 and given statutory force in 1981 by Section 31 of the Supreme Court Act, 1981. It combined all
the former remedies into one proceeding called Judicial Review. Lord Denning explains the scope of
this 'judicial review":
"At one stroke the courts could grant whatever relief was appro priate. Not only
certiorari and mandamus, but also declaration and injunction. Even damages. The
procedure was much more simple and expeditious. Just a summons instead of a writ.
No formal pleadings. The evidence was given by affidavit. As a rule no
cross-examination, no discovery, and so forth. But there were important safeguards.
In particular, in order to qualify, the applicant had to get the leave of a Judge.
The statute is phrased in flexible terms. It gives scope for development. It use the
words 'having regard to'. Those words are very indefinite. The result is that the courts
are not bound hand and foot by the previous law. They are to have regard to it. So the
previous law as to who are and who are not public authorities, is not absolutely
binding. Nor is the previous law as to the matters in respect of which relief may be
granted. This means that the Judges can develop the public law as they think best.
That they have done and are doing."
17. There, however, the prerogative writ of mandamus is confined only to public authorities to
compel performance of public duty. The 'public authorities' for them mean every body which is
created by statute-and whose powers and duties are defined by statute. So Government
departments, local authorities, police authorities and statutory undertakings and corporations, are
all 'public authorities'. But there is no such limitation for our High Courts to issue the writ 'in the
nature of mandamus'. Article 226 coners wide powers on the High Courts to issue writs in the
nature of prerogative writs. This is a striking departure from English law. Under Article 226, writs
can be issued to 'any person or authority'. It can be issued 'for the enforcement of any of theAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

fundamental rights and for any other purpose."
66. Mr. Tulsi submitted that this Hon'ble Court is not helpless and is empowered to direct payment
of exgratia compensation in these proceedings as it is not enough to relegate the Petitioners to the
ordinary remedy of claiming damages in a Civil Courts. Mr. Tulsi submitted that in view of the
expanding horizons of human rights, dignity of persons is recognised under law, and deterrence is
aspired, where lives are lost due to careless disregard of the duties, by public authorities, and those
on whom duties are enjoined by law, to protect and preserve human life. Mr. Tulsi submitted that
Respondents must, therefore, be made to bear the brunt, by doing complete justice to the parties in
this very proceedings. In support of this submission.
67. Mr. Tulsi also relied on the case of Indian Council for Enviro Legal Action Vs. UOI, . In this case
the question was whether a public interest litigation alleging environmental pollution by private
industrial units was maintainable. It was interalia held :
"54.Taking up the objections urged by Shri Bhat first, we find it difficult to agree with
them. This Writ Petition is not really for issuance of appropriate writ, or order or
directions against the Respondents but is directed against the Union of India,
Government of Rajasthan and RPCB to compel them to perform their statutory
duties enjoined by the Acts aforementioned on the ground that their failure to carry
out their statutory duties is seriously undermining the right to life (of the residents of
Bichhri and the affected area) guaranteed by Article 21 of the Constitution. If this
Court finds that the said authorities have not taken the action required of them by
law and that their inaction is jeopardizing the right to life of the citizens of this
country or any section thereof, it is the duty of this Court to intervene. If it is found
that the Respondents are flouting the provisions of law and the directions and orders
issued by the lawful authorities, this Court can certainly make appropriate directions
to ensure compliance with law and lawful directions made there under. This a social
action litigation on behalf of the villages of Bichhri whose right to life, as elucidated
by this Court in several decisions, is invaded and seriously infringed by the
Respondents as it established by the various reports of the experts called and filed
before this Court. If an industry is established without obtaining the requisite
permission and clearances and if the industry is continued to be run in blatant
disregard of law to the detriment of life and liberty of the citizens living in the
vicinity, can it be suggested with any modicum of reasonableness that this Court has
no power to intervene and protect the fundamental right to life and liberty Of the
citizens of this country. The answer in our opinion, is self evident. We are also not
convinced of the plea of Shri Bhat that RPCB has been adopting a hostile attitude
towards his clients throughout and therefore its contentions or the reports prepared
by its officers, should not be relied upon. If the Respondents establish and operate
their plants contrary to law, flouting all safety norms provided by law the RPCB was
bound to act. On that account, it cannot be said to be acting out of animus or
adopting a hostile attitude. Repeated and persistent violations call for repeated
orders. That is no proof of hostility. Moreover the reports of RPCB officials are fullyAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

corroborated and affirmed by the reports of the Central Team of Experts and of
NEERI. We are also not prepared to agree with Shri Bhat that since the report of
NEERI was prepared at the instance of RPCB, it is suspect. This criticism is not only
unfair but is also, uncharitable to the officials of NEERI who have no reason to be
incimical to the Respondents. If, however, the actions of the Respondents of invite
the concern of the experts and, if they depict the correct situations in their reports,
they cannot be accused of any bias. Indeed, it is this Court that asked NEERI to
suggest remedial measures and it is in compliance with those orders that NEERI
submitted its interim report and also the final report. Similarly, the objection of Shri
Bhat that the reports submitted by the NEERI, by the Central team (experts from the
Ministry of Environment and Forests, Government of India) and.RPCB cannot be
acted upon is equally unacceptable. These reports were called by this Court and
several orders passed on the basis of those reports. It was never suggested on behalf
of Respondents 4 to 8 that unless they are permitted to crossexamine the experts or
the persons who made those reports, their reports cannot be acted upon. The
objection, urged at this late stage of proceedingsafter a lapse of several years is wholly
unacceptable. The persons who made the said reports are all experts in their field and
under no obligation either to the RPCB or for all matter to any other person or
industry. it is in view of their independence and competence that their reports were
relied upon and made the basis of passing orders by this Court from time to time.
55. Now, coming to the question of alleged pollution by Hindustan Zinc Limited
(R-9), it may be that Respondent 9 is also responsible for discharging untreated
effluents of one of the other point of time but that is not the issue we are concerned
with in these writ petitions. These writ petitions are confined to the pollution caused
in Bichhri village on account of the activities of the Respondent. No report among the
several reports placed before us in these proceedings says that Hindustan Zinc
Limited is responsible for the pollution at Bichhri village. Shri Bhat brought to our
notice certain reports stating that the discharges from Hindustan Zinc Limited were
causing pollution in certain villages but they are all downstream i.e. to the north of
Bichhri village and we are not concerned with the pollution in those villages in these
proceedings. The bringing in of Hindustan Zinc Limited in these proceedings is
therefore, not relevant. If necessary the pollution, if any, caused by Hindustan Zinc
Limited can be the subject matter of a separate proceeding.
57. So far as the responsibility of the Respondents for causing the pollution in the
wells, soil and the aquifers is concerned, it is clearly established by the analysis report
referred to in the report of the Central Experts Team dated 1.11.1993 (p. 1026 of Vol
II ). Indeed, number of orders passed by this Court, referred to hereinbefore are
premised upon the finding that the respondents are responsible for the said
pollution. It is only because of the said reason that they were asked to defray the cost
of removal and storage of sludge. It is precisely for this reason that, at one stage, the
Respondents had also undertaken the dewatering of polluted wells. Disclaiming the
responsibility for the pollution in and around Bichhri village, at this stage ofAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

proceedings, is clearly an afterthought. We accordingly hold and firm that the
respondents alone are responsible for all the damage to the soil to the underground
water and to village Bich hri in general, damage which is eloquently portrayed in the
several reports of the experts mentioned hereinabove. NEERI has worked out the
cost for repairing the damage at more than Rupees forty crores. Now, the question is
whether and to what extent can the Respondents be made responsible for defraying
the cost of remedial measures in these proceedings under Article 32. Before we advert
to this question, it may perhaps be appropriate to clarify that so far as removal of
remaining sludge and/or the stoppage of discharge of further toxic wastes are
concerned, it is the absolute responsibility of the Respondents to store the sludge in a
proper manner (in the same manner in which 720 MT of sludge has already been
stored ) and to stop the discharge of any other or further toxic wastes from its plants
including Sulphuric acid plant and to ensure that the wastes discharged do not flow
into or through the sludge., Now, turning to the question of liability it would be
appropriate to refer to a few decisions on the subject.
58. In Oeum Gas Leak Case [MC Mehta Vs. UOI ] a Constitution Bench discussed this
question at length and held thus : (SCC pp. 420-21. paras 31-32).
"We are of the view that an enterprise which is engaged in a hazardous or inherently
dangerous industry which poses a potential threat to the health and safety of the
persons working in the factory and residing in the surrounding areas owes an
absolute and nondelegable duty to the community to ensure that no harm results to
anyone on account of hazardous or inherently dangerous nature of the activity which
it has undertaken. The enterprise must be held to be under an obligation to provide
that the hazardous or inherently dangerous activity in which it is engaged must be
conducted with the highest standards of safety and if any harm results on account of
such activity the enter prise must be absolutely liable to compensate for such harm
and it should be no answer to the enterprise to satisfy that it had taken all reasonable
care and that the harm occurred without any negligence on its part. Since the persons
harmed on account of the hazardous or inherently dangerous activity carried on by
the enterprise would not be a in a position to isolate the process of operation from the
hazardous preparation of substance or any other related element that caused the
harm the enterprise must be held strictly liable for causing such harm as a part of the
social cost of carrying on the hazardous or inherently dangerous activity. If the
enterprise is permitted to carry on an hazardous or inherently dangerous activity for
its profit, the law must presume that such permission is conditional on the enterprise
absorbing the cost of any accident arising on account of such hazardous or inherently
dangerous activity as an appropriate item of its overheads. Such hazardous or
inherently dangerous activity for private profit can be tolerated only on condition
that the enterprise engaged in such hazardous or inherently dangerous activity
indemnifies all those who suffer on account of the carrying on of such hazardous or
inherently dangerous activity regardless of whether it is carried on carefully or not.
This principle is also sustainable on the ground that the enterprise alone has theAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

resource to discover and guard against hazards or dangers and to provide warning
against potential hazards. We would therefore hold that where an enterprise is
engaged in a hazardous or inherently dangerous activity and harm results to anyone
on account of an accident in the operation of such hazard ous or inherently
dangerous activity resulting, for example, in escape of toxic gas the enterprise is
strictly and absolutely liable to compensate all those who are affected by the accident
and such liability is not subject to any of the exceptions which operate vis a vis the
tortuous principle of strict liability under the rule in Rylands Vs. Fletcher.
We would also like to point out that the measure of compensation in the kind of cases
referred to in the preceding paragraph must be correlated to the magnitude and
capacity of the enterprise because such compensation must have a deterrent effect.
The larger and more prosperous the enterprise, the greater must be the amount of
compensation payable by it for the harm caused on account of an accident in the
carrying on of the hazardous or inherently dangerous activity by the enterprise."
59. Shri Bhat, however, points out that in the said decision, the question whether the industry
concerned therein was a State within the meaning of Art. 12 and, therefore, subject to the discipline
of Part III of the Constitution including Article 21 was left open and that no compensation as such
was awarded by this Court to the affected persons. He relies upon the observations in the concurring
opinion of Ranganath Misra, CJ, in Union Carbide Corpn. The learned Chief Justice referred in the
first instance, to the propositions enunciated in Oleum gas Leak Case and then made the following
observation in paras 14 and 15 : (SCC pp. 607-08) "14. In M.C. Mehta case, no compensation was
awarded as this Court could not reach the conclusion that Shriram (the delinquent company ) came
within the meaning of State in Article 12 so as to be liable to the discipline of Article 21 and to be
subjected to a proceeding under Article 32 of the constitution. Thus, what was said was essentially
obiter.
15. The extract part of the observations from M.C. Mehta case perhaps is a good guideline for
working out compensation in the cases to which the ratio is intended to apply. The Statement of the
law ex facie makes a departure from the accepted legal position in Rylands Vs. Fletcher. We have not
been shown any binding precedent from the American Supreme Court where the ratio of M.C.
Mehta decision has in terms been applied. In fact Bhagwati, CJ., clearly indicates in the judgment
that his view is a departure from the law applicable to western countries. "
60. The majority judgment delivered by M.N. Venkatachaliah, J. (On behalf of
himself and two other learned Judges ) has not expressed any opinion on this issue.
We on our part find it difficult to say, with great respect to the learned Chief Justice,
that the law declared in Oleum Gas Leak case is obiter. It does not appear to be
unnecessary for the purposes of that case. Having declared the law, the Constitution
Bench directed the parties and other organizations to institute actions on the basis of
the law so declared. Be that as it may, we are of the considered opinion that even if it
is assumed (for the same of argument) that this Court cannot award damages against
the Respondents in these proceedings that does not mean that the Court cannotAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

direct the Central Government to determine and recover the cost of remedial
measures from the Respondents. Section 3 of the Environment (Protection ) Act,
1986 expressly empowers the Central Government ( or its delegate, as the case may
be ) to take all such measures as it deems necessary or expedient for the purpose of
protecting and improving the quality of environment." Section 5 clothes the Central
Government (or its delegate ) with the power to issue directions for achieving the
objects of the Act. Read with the wide definition of 'environment' in Section 2(a),
Section 3 and 5 clothe the Central Government with all such powers as are necessary
or expedient for the purpose of protecting and improving the quality of the
environment. The Central Government is empowered to take all measures and issue
all such directions as are called for the above purpose. In the present case the said
powers will include giving directions for the removal of the sludge, for undertaking
remedial measure and also the power to impose the cost of remedial measures on the
offending industry and utilize the amount so recovered for carrying out remedial
measures. This Court can certainly give directions to the Central Government/its
delegate to take all such measures, if in a given case this Court finds that such
directions are warranted. We find that similar directions have been made in a recent
decision of this Court in Indian Council for Enviroegal Action. That was a Writ
Petition filed under Art 32 of the Constitution. Following is the direction:
"It appears that the Pollution Control Board had identified as many as 22 industries
responsible for the pollution caused by discharge of their effluents into Nakkavagu.
They were responsible to compensate to farmers. It was the duty of the State
Government to ensure that this amount was recovered from the industries and paid
to the farmers."
It is, therefore, idle to contend that this Court cannot make appropriate directions for the purpose of
ensuring remedial action. It is more a matter of form.
61. Shri K.N. Bhat submitted that the rule of absolute liability is not accepted in England or other
Commonwealth countries and that the rule evolved by the Houses of Lords in Rylands Vs. Fletcher
is the correct rule to be applied in such matters. Firstly, in view of the binding decision of this Court
in Oleum Gas Leak case, this contention is untenable, for the said decision expressly refers to the
rule in Rylands but refuses apply it saying that it is not suited to the conditions in India. Even so, for
the sake of completeness, we may discuss the rule in Rylands and indicate why that rule is
inappropriate and unacceptable in this country....
64. The Australian High Court has, however, expressed its disinclination to treat the rule in Rylands
as an independent head for claiming damages or as a rule rooted in the law governing the law of
nuisance in Burnie Port Authority Vs. General Jones Pvt. Ltd. The respondent, General Jones
Limited had stored frozen vegetables in three cold storage rooms in the building owned by the
appellant, Burnie Port Authority (Authority). The remaining building remained under the
occupation of the Authority. The Authority wanted to extend the building. The extension work was
party done by the Authority itself and partly by an independent contractor (Wildridge and SinclairAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

Pvt.. Ltd.).For doing its work, the contracter used a certain insulating material called EPS, a highly
inflammable substance. On account of negligent handling of EPS, there was a fire which inter alia
damaged the rooms in which General jones had stored its vegetables.On an action of general jones,
the Australian High Court held by majority a majority that the rule in Ryland having attracted by
many difficulties, uncertainities, qualifications & exceptions, should now be seen, for purposes of
the of Australian Common Law, as absorbed by the principles of ordinary negligence. The Court
held further that under the rules governing negligence if a person in control of a premises,
introduces a dangerous substance to carry on a dangerous activity, or allows another to do one of
those things, owes a duty of reasonable care to avoid reasonably foreseeable risk of injury or damage
to the person of property of another. In a case, where a person or the property of that other is
lawfully in a place outside the premises, the duty of care varies in degree according to the magnitude
of the risk involved and extends to ensuring that such care is taken. Applying the said principle, the
court held that the authority allowed the independent contractor to introduce or retain a dangerous
substance or to engage in a dangerous activity in its premises which substance and activity caused a
fire that destroyed the goods of General Jones. The evidence, the court held, established that the
independent contractor's work was a dangerous activity in that it involved real and foreseeable risk
of a serious conflagration unless special precautions were taken. In the circumstances, it was held
that the authority owned a non delegable duty of care to General Jones to ensure that its contractor
took reasonable steps to prevent the occurrence of a fire and the breach of that duty attracted
liability pursuant to the ordinary principles of negligence for the damages sustained by the
respondent.
65. On a consideration of the two lines of thought (one adopted by the English Courts and the other
by the Australian High Court), we are of the opinion that any principle evolved in this behalf should
be simple, practical and suited to the conditions obtained in this country. We are convinced that the
law stated by this Court in Oleum Gas Leak case is by far the more appropriate oneapart from the
fact that it is binding upon us. (We have disagreed with the view that the law stated in the said
decision is obiter). According to this rule, once the activity carried on is hazardous or inherently
dangerous, the person carrying on such activity is liable to make good the loss caused to any other
person by his activity irrespective of the fact whether he took reasonable care while carrying on his
activity. The rule is premises upon the very nature of the activity carried on. In the words of the'
Constitution Bench, such an activity : (SCC p. 421, para 31.) ".... can be tolerated only on condition
that the enterprise engaged in such hazardous or inherently dangerous activity indemnifies all those
who suffer on account of the carrying on of such hazardous or inherently dangerous activity
regardless of whether it is carried on carefully or not".
The Constitution Bench has also assigned the reason for stating the law in the said terms. It is that
the enterprise (carrying on the hazardous or inherently dangerous activity) alone has the resources
to discover and guard against hazardous or dangersand not the persona effected and the practical
difficulty ( on the part of the affected person ) in establishing the absence of reasonable care or that
the damage to him was foreseeable by the enterprise.
66. Once the law in Oleum Gas Leak Case is held to be the law applicable, it follows, in the light of
our findings recorded hereinabove, that Respondents 4 to 8 are absolutely liable to compensate forAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

the harn caused by them to the villagers in the affected area, to the soil and to the underground
water and hence, they are bound to take all necessary measures to remove the sludge and other
pollutants lying in the affected area ( by affected area, we mean the area of about 350 hac indicated
in the sketch at p. 178 of NEERI report) and also to defray the cost of the remedial measures
required to restore the soil and the underground water sources. Section 3 and 4 of Environment (
Protection) Act confers upon the Central Government the power to give directions of the above
nature and to the above effect. Levy of costs required for carrying out remedial measures is implict
in Sections 3 and 4 which are couched in very wide and expansive language. Appropriate directions
can be given by this Court to the Central Government to invoke and exercise those powers with such
modulations as are called for in the facts and circumstances of this case.
67. The question of liability of the Respondents to defray the costs of remedial measures can also be
looked into from another angle, which has now come to be accepted universally as a sound principle,
viz, the "Polluter Pays" principle.
"The Polluter Pays principle demands that the financial costs of preventing or
remedying damages caused by pollution should lie with the undertakings which cause
the pollution, or produce the goods which cause the pollution. Under the principle it
is not the role of Government to meet the costs involved in either prevention of such
damage, or in carrying out remedial action because the effect of this would be to shift
the financial burden of the pollution incident to the taxpayer. The Polluter Pays
principle was promoted by the Organisation for Economic Cooperation and
Development (OECD) during the 1970s when there was great public interest in
environment issues. During this time there were demands on Government and other
institutions to introduce policies and mechanisms for the protection of the
environment and the public from the threats posed by pollution in a modern
industrial society. Since then there has been considerable discussion of the nature of
Polluter Pays principle, but the precise scope of the principle and its implications for
those involved in past or potentially polluting activities have never been satisfactorily
agreed.
Despite the difficulties inherent in defining the principle, the European Community
accepted it as a fundamental part of its strategy on environmental matters and it has
been one of the underlying principles of the four Community Action Programmes on
the Environment. The current Fourth Action Programme (1987) OJC 328/1 makes it
clear that the cost of preventing and eliminating nuisance must in principle be borne
by the polluter, and the Polluter Pays principle has now been incorporated into the
European Community Treaty as part of the new articles on the environment which
were introduced by the Single European Act of 1986. Article 130-R(2) of the Treaty
states that environmental considerations are to play a part in all the policies of the
community, and that action is to be based on three principles; the need for preventive
action; the need for environmental damage to be rectified at source; and that the
polluter should pay."Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

"Thus, according to this principle, the responsibility for repairing the damage is that
of the offending industry. Sections 3 and 5 empower the Central Government to give
directions and take measures for giving effect to this principle. In all the
circumstances of the case we think it appropriate that the task of determining the
amount required for carrying out the remedial measures, its recovery/ realization
and the task of undertaking the remedial measures is placed upon the Central
Government in the light of the provisions of the Environment (Protection) Act, 1986.
It is, of course, open to the Central Government to take the help and assistance of
State Government, RPCB or such other agency or authority, as they think fit."
68. Mr. Tulsi also relied on the case of Poonam Verma Vs. Ashwin Patel & Ors. . In this case the
Supreme Court awarded damages against a Doctor who had qualified in homoeopathy but
prescribed allopathic medicine to a patient. The Supreme Court held that the Doctor having
practiced in Allopathy, without being qualified in that system, was guilty of negligence per se and,
therefore, the Appeal against him had to be allowed in consonance with the maximum sic utere tuo
ut alienum non loedas ( a person is held liable at law for the consequences of his negligence).
69. It must be mentioned that Mr. Tulsi had also relied on the cases of Shiv Sagar Tiwari Vs. UOI
reported in 1995 (6) SCC Pg. 499; Mohd. Aslam Vs. UOI ; Bhuwaneshwar Singh Vs. UOI reported in
1993 (4) SCC Pg. 3271; CERC Vs. UOI reported in 1995 (3) SCC Pg. 421 ; Union Carbide Corp. Vs.
UOI ; M.C. Mehta Vs. Kamal Nath ; M.C. Mehta Vs. UOI ; M.C. Mehta Vs. UOI and Jagdish Prasad
Sashtri Vs. State of UP & Ors. . These cases also set out the same principles which have been
extracted hereinabove and it is thus not necessary to set out each case separately.
70. Mr. Tulsi submitted that, on the above mentioned law and under the above mentioned
circumstances, the Petitioners have prayed for grant of Rs. 11.8 crores, as exgratia compensation @
Rs. 20 lakhs per person who lost his/her life, and a compensation @ Rs. 10 lakhs to 103 persons who
received serious injuries during the tragedy. He submitted that this is the least which is payable to
these parties.
71. In rejoinder Mr. Desai submitted that at present, the Court was considering the preliminary
objections of the Respondents. He submitted that in replying to the preliminary objections, the
Petitioners had placed reliance on, about, a thousand of pages of documents which had been handed
over across the Bar. He submitted that reliance on numerous documents, in this manner constituted
a violation of procedural rules, as also of the principles of natural justice, and was unfair to the
Respondents.
72. Mr. Desai submitted that at this preliminary stage the question is not of ascertaining the
individual liability of each Respondent but to decide, inter alia :
1. Whether the matter raises complex factual issues;
2. Whether the causation and responsibility can be decided in a summary manner ;Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

3. Whether facts are disputed ;
4. Whether this can be an appropriate matter for a writ petition.
73. Mr. Desai submitted that at this stage the Respondents are not addressing in detail the factual
allegations made by the Petitioners including in relation to seating plans, smoke and the
photographs handed over to the Courts. He submitted that those matters can only be gone into at
the final hearing if any. He submitted that at a full hearing of the matter, in order to render a
decision in accordance with law and principles of natural justice, the following requirements would
have to be complied with.
(i) There would be proper pleadings, making precise allegations of misconduct against individual
respondents.
(ii) there would be a full discovery giving all the documents and that
(iii) too before the arguments;
(iv) there would be a full opportunity to the Respondents to peruse these documents and meet them
by producing their evidence.
(v) the documents including the reports would be proved in accordance with the rules of evidence.
74. Mr. Desai contends that this procedure cannot be bypassed by a summary hearing in a Writ
Petition as is sought to be done by the Petitioners. He submits that the summary procedure of a Writ
Petition cannot be resorted to by the Petitioner when there are issues of such complexity and
disputes with respect to facts.
75. Mr. Desai submitted that in a recent judgment in the case of Chairman, Grid Corporation of
Orissa Vs. Sukamani Das, reported in (1999) 5 SCALE Pg. 539. In this case a claim was made for
compensation for the death of individuals by electrocution allegedly due to negligence of a
Government company. The Respondents denied liability no the ground that the death had not
occurred as a result of their negligence, but because of an act of God or act of some other person.
The Respondents, therefore, contended that the Writ Petition was not a proper remedy as the facts
stated by the petitioner were disputed and could not be decided without evidence being led by both
the sides. The High Court awarded compensation to the Writ Petitioners on the basis that the deaths
had taken place due to electrocution and negligence was thus proved. The Supreme Court held as
follows :
"In our opinion, the High Court committed an error in entertaining the writ petitions
even though they were not fit cases for exercising power under Article of the
Constitution... The High Court failed to appreciate that all these actions were in tort
and negligence was required to be established firstly by the claimants.. In view of the
specific defenses raised by the appellants in each of these cases they deserved anAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

opportunity to prove that proper care and precautions were taken in maintaining the
transmission lines and yet the wires had snapped because of circumstances beyond
their control or unauthorised intervention of third parties or that the deceased had
not died in the manner stated by the petitioners. These questions could not have been
decided properly on the basis of affidavits only. It is the settled legal position that
where disputed questions of fact are involved a petition under Article 226 of the
Constitution is not the proper remedy."
Mr. Desai submitted that in this case the Supreme Court has laid down that compensation following
an allegation of negligence cannot be granted in a writ proceedings and can only be granted after a
proper inquiry. He submitted that in this judgment it has been held that :
(i) It is a settled position of law that where disputed questions of fact are involved,
Article is not the proper remedy.
(ii) The powers inherent in the Supreme Court under Article 142 of the Constitution
are not available to the High Court.
(iii) Issues of liability and causation in negligence cannot be decided in writ
proceedings.
76. Mr. Desai submitted that in the above mentioned case, the Supreme Court relied upon the
decision in Sanchalak shri Vs. Vijaya kumar , wherein the distinction between the powers of the
High Courts and the Supreme Court had been emphasised. He submitted that the Supreme Court
also distinguished the decision in Shakuntala Devi Vs. DESU [1995 (2) SCC Pg. 369] on this basis.
Mr. Desai submitted that in any event, the decision in Shakuntala Devi clearly states that it is based
on the peculiar facts of that case and shall not be treated as a precedent in future cases. Mr. Desai
submitted that in Munir Alam Vs. Union of India the Supreme Court ordered a full inquiry by a
competent judicial officer after taking evidence, and even then ordered a further CBI inquiry and left
the matter of exemplary damages to be decided by the trial Court.
77. Mr. Desai submitted that their preliminary objections as to the maintainability of the present
Writ Petition have not been answered at all by the Petitioners. He submitted that the Respondents
contention that present proceedings raise complex disputed questions of fact, and are, therefore, not
amenable to writ jurisdiction, has not been answered.
78. Mr. Desai submitted that there is no force in the distinction sought to be drawn between private
law and public law disputes in the context of the above preliminary objections. He submitted that
the judgments of the Supreme Court on adjudication of disputed questions of facts in writ
proceedings arise out of Petitions under Articles 32 or 226 of the Constitution. He submitted that
such proceedings are by their very nature public law remedies. He submitted that the question
whether a particular dispute involves state activity in the public law realm or the private law realm is
irrelevant to the aforesaid preliminary objection.Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

79. Mr. Desai submitted that judgments cited on behalf of the Respondents have neither been
explained nor distinguished. Mr. Desai reiterates that the cases of DLF Housing Construction Vs.
Delhi Municipal Corporation, ; Radhakrishnan Aggarwal Vs. State of Bihar, and Express
Newspapers Pvt. Ltd. Vs. Union of India, , inter alia, clearly lay down that the disputed question of
facts may not be decided in a Writ Petition.
80. Mr. Desai submitted that the judgments cited by the Petitioners do not negate the above
propositions. Mr. Desai submits that the cases relied upon by the Petitioner are of no help to them
for the following reasons :
(a) Consumer Education & Research Centre Vs. UOI.
Mr. Desai submitted that this case arose out of a Writ Petition under Art. 32 in which directions
were sought on behalf of workers who have sustained illnesses and injuries from working in
asbestos factories. He submits that the prayers were not related to compensation. He submits that
the Supreme Court held that it could give directions to make the right to life meaningful. Mr. Desai
submitted that the Supreme Court made specific reference to power under Articles 32 and 142. He
submitted that the Supreme Court awarded compensation to the employees in view of the fact that
the Employees State Insurance Act and the Workmens Compensation Act do not provide for
payment of compensation after cessation of employment. He submitted that in that view of the
matter, the Supreme Court held that it became necessary to protect such persons from the respective
dates of cessation of their employment. He submitted that it is significant that the contentious issue
of quantification of damages did not arise as damages were liquidated.
(b) Rudul Sah Vs. State of Bihar.
Mr. Desai submitted that this Habeas Corpus Petition against the State arose out of illegal
incarceration of an individual. Mr. Desai submitted that the Supreme Court observed that Article 32
cannot be used as a substitute for the enforcement of rights and obligations which can be enforced
efficaciously through the ordinary processes of Court, Civil and Criminal, and that a money claim
has to be agitated in a suit. He submitted that however, in this case, the Court passed an order for
compensation as the State did not raise an objection and the facts were not in dispute. He submitted
that the compensation was awarded against the State.
(c) Sebastian M. Hongray Vs. UOI Mr. Desai submitted that the question in this case was of
enforcing obedience to a writ of habeas corpus. He submitted that there was no question of
compensation. He submitted that in any event, the Respondent was the Union of India and not a
private party.
(d) Saheli Vs. Commissioner of Police Mr. Desai submitted that this was a Writ Petition filed on
behalf of women alleging police violence. He submitted that the report of the Crime Branch itself
mentioned the connivance of the local police with the accused. He submitted that the award of
compensation was made on the specific finding that the death was caused by 'agency of sovereign
power'. Mr. Desai submits that the Court held that the State is responsible for the tortious act of itsAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

employees and on the basis, compensation was awarded against the Delhi Administration.
(e) State of Maharashtra Vs. Ravikant S. Patil Mr. Desai submitted that this Petition arose out of an
allegation of violation of fundamental rights of an under trial by police officer. He submitted that the
police officer had been directed by the High Court to personally pay compensation to the victim. He
submitted that despite upholding the findings of the High Court the Supreme Court held that the
compensation should be paid by the State and not the officer.
(f) Nilabati Behera Vs. State of Orissa Mr. Desai submitted that this Petition involved a claim of a
mother for compensation for the death of her son in police custody. He submits that the only
Respondents were the State and police officers. He submitted that the Supreme Court first resolved
the factual disputes by ordering an inquiry to be conducted by the District Judge. He submitted that
the District Judge's enquiry was conducted by taking evidence. He submitted that the liability of the
State to pay compensation was not disputed. He submitted that the case does not concern payment
of compensation by private parties as is clear from the Court's discussion of State's liability and
sovereign immunity.
(g) Bhuwaneshwar Singh Vs. UOI Mr. Desai submits that in this case, compensation was awarded
against the Union for detention of a sepoy pursuant to court martial proceedings beyond prescribed
period. He submits that in this case there was no question of liability of private party.
(h) Lucknow Development Authority Vs. M.K. Gupta Mr. Desai submits that this case concerns an
appeal from a decision of the National Consumer Disputes Redressal Commission, which considers
civil disputes. He submits that this case does not involve award of compensation in Writ
proceedings. He submitted that the question which arose was of jurisdiction of Consumer
Commission to adjudicate disputes against LDA. He submitted that in any event, the only question
that an be regarded as decided by this decision is of the liability of the State to pay compensation.
(i) N. Nagendra Rao Vs. State of A.P. Mr. Desai submitted that the question which arose in this case
was of vicarious liability of the State for acts of its officers in exercise of powers under Essential
Commodities Act. He submitted that the Supreme Court specifically notes that the facts are not
disputed. He submitted that the proceedings arose out of a Suit and not in Writ jurisdiction. He
submitted that the case involves the scope of sovereign immunity and not any Issues which might be
relevant to a claim for compensation against a private party.
(j) Punjab & Haryana High Court Bar Ass. Vs. State of Punjab Mr. Desai submitted that issue in
these proceedings were the abduction and alleged murder of an Advocate and his family. He
submitted that the Supreme Court first directed a CBI investigation to establish the facts. He
submitted that only thereafter was compensation awarded to the parents of the deceased and to the
person falsely implicated in the abduction and murder. He submitted that the compensation was
directed to be paid by the State and not by any private party.
(k) Sec. Jaipur Dev. Authority Vs. Daulat Mal Jain Mr. Desai submitted that this case involves a
misuse of office by Minister and other public officials in allotments of land. He submitted that fromAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

the Judgment it appears that the facts of allotment of the land by the Minister was not disputed. He
submitted that in any event, facts were established by an enquiry report of the Lok Ayukta of
Rajasthan.
(l). Express Newspapers Vs. UOI Mr. Desai relies upon paras 201, 205 and 206 of this decision. He
submitted that from a reading of para 201 it is clear that the allegations of improper motives were
not denied. He submitted that the thus there were no disputed questions of facts. He submitted that
these paras showed that on aspects where there were disputed questions of facts, it was held that a
Writ Petition was not the proper remedy.
(m) Poonam Verma Vs. Ashwin Patel Mr. Desai submitted that this Judgment arose in an Appeal
under the Consumer Protection Act for practice of allopathy by homoeopath, and not in a writ
proceeding. He submitted that evidence had been recorded by the Consumer Commission. He
submitted that the Judgment lays down that in a case of strict liability, or negligence per se, there is
no need to establish surrounding circumstances. He submitted that the judgment does not say that
causation and quantum also do not need to be proved. He submitted that the quantum of damages
has been fixed taking evidence as to the age and earning capacity of the deceased into account.
(n) Achutrao Khodwa Vs. State of Maharashtra Mr. Desai submitted that in this case, the Supreme
Court recorded a finding of negligence against a medical practitioner applying the doctrine of res
ipsa loquitor. He submitted that the Supreme Court's award of damages was based on an express
finding as to causation. He submitted that the question of causation was dealt with as a distinct and
separate element of proof in order for damages to be awarded.
(o) Andi Mukta Trust Vs. V.R. Rudani Mr. Desai submitted that this case is cited to establish that a
Writ Petition may be filed against a private party. He submitted that in this case the question arose
in the context of private educational institutions which received aid from the Government, and in
any event had a public element to it. He submits that maintainability of a writ petition against a
private trust running a college was upheld on the ground that the college was government aided and
discharged public functions. He submits that the Supreme Court particularly held that if the rights
sought to be protected are purely of a private character, and the management is purely a private
body, with no public duties, mandamus will not lie. He submitted that the words 'any person or
authority' in Article 226 was interpreted to include only those persons or bodies 'performing public
duty'.
(p) M.C. Mehta Vs. Union of India.
Mr. Desai submitted that this case concerns the oleum gas leak. He submitted that the Supreme
Court accepted the doctrine of strict liability. He submits that the reasoning of the Court on
maintainability appears to be based on the interpretation of Article 32. He submitted that this case
does not decide whether a private corporation would fall within the scope of Article 12. He
submitted that the Supreme Court, therefore, did not make any order of compensation against the
private corporation but directed that actions may be filed on behalf of the victims in the appropriate
court.Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

(q) R.S. Saini Vs. State of Punjab Mr. Desai submitted that this judgment was sought to be used to
support the admissibility of the inquiry report. He submitted that the Judgment concerns a Writ
Petition against removal as President of a Municipal Coucil on the basis of an Inquiry Report. He
submitted that in this context, the Supreme Court affirmed the finding of the High Court that the
Inquiry Report was based on materials available and was not perverse. He submitted that in this
case the Supreme Court reiterated the limited scope of judicial review in matters of this nature. Mr.
Desai submitted that this judgment is not applicable to the present case, as in the is case the Writ
Petition does not challenge the Inquiry Report at all. He submitted that the position of a domestic
inquiry in a service matter is not analogous to the position of a Government Inquiry. He submitted
that this Judgment does not confer admissibility upon a commission of inquiry Report, and the
Court's observations in Kehar Singh, Kiran Bedi and Hiray remain applicable.
r) Khatri Vs. State of Bihar Mr. Desai submitted that in this case the question was whether certain
documents could have been called for by the Court in the Bihar blinding case. He submitted that the
Supreme Court confined itself to considering whether the State is liable to pay compensation for
violation of fundamental rights.
(s) Indian Council for Enviroegal Action Vs. UOI Mr. Desai submitted that this case concerns the
loss caused to the people of Bichhri village by Chemical factories. He submitted that whilst the Court
directed private Respondents to provide for improvement and restoration of the environment, the
claim for damages for loss suffered by villagers was explicity left to be agitated in a suit.
(t) Kumari Vs. State of Tamil Nadu Mr. Desai submitted that by this short order, the Supreme Court
awarded compensation to the mother of a child who died as a result of falling in to an open sewerage
tank. Mr. Desai submitted that although the Court has not elaborated on its reasoning, the case is
explicitly stated to be 'in the facts and circumstances of this case'. He submitted that in any case the
direction was only against the State. He submitted that the State was left to other remedies to claim
the amount or part thereof from other Respondents.
(u) Manju Bhatia Vs. NDMC Mr. Desai submitted that this judgment is concerned with the
interelationship between tort, contract and equity. Mr. Desai submitted that the Supreme Court
directed the builder to compensate the purchasers in the context of compensating purchasers of flat
in a building constructed illegally and demolished. He submitted that the case is based upon
admitted facts.
81. Mr. Desai submitted that it is clear from all the above cases that the Supreme Court has awarded
compensation in Writ Proceedings only when the acts complained of have been of the State or their
employees, and the causal link with the damage caused has been proven. He submitted that in some
cases, the facts were not disputed, and in some others, the Supreme Court first directed
investigation by specialised agencies or judicial officers. He submitted that in contrast, in this case
private parties are sought to be made liable for their alleged negligence by award of compensation.
He submitted that the only case, cited by the Petitioners in which compensation was awarded
against a private party was the CERC case. He submitted that in that case, the Supreme Court made
specific reference to its power under Articles 32 and 142. He submitted that the Supreme CourtAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

awarded compensation to the employee in view of the fact that the Employees State Insurance Act
and the Workman Compensation Act do not survive for payment of compensation after cessation of
employment. He submitted that the present case is therefore clearly distinguishable from the CERC
case.
82. Mr. Desai submitted that the stand of the Petitioners seeks to obliterate the distinction between
causation and liability, each of which is required to be established for a claim in negligence. He
submitted that this obfuscates the critical issue in the case. He submitted that even if the Petitioners
succeed on the question of strict liability for breach of a statutory duty, they would still be required
to prove the link between the breach and the damage, and prove the quantum of damages. He
submitted that it is clear from the authorities (including those cited by the Petitioners) that neither
strict liability nor breach of statutory duty absolves the claimant of the burden of proving causation.
83. Mr. Desai submitted that the Petitioners have failed to distinguish or explain the cases cited by
the Respondents regarding the admissibility of Reports of Commissions of Inquiry. He submitted
that the factual foundation for Petitioners, claim is based solely on the Report of the Naresh Kumar
Inquiry. He submitted the said inquiry was not even a statutory or judicial inquiry. He submitted
that its report can, at best, be treated as recommendatory and does not substitute the procedure of a
Civil Suit. In any event. He submitted in the Report is not admissible in evidence as proof of its
contents. He submitted that the Petitioners have not given any evidence on facts apart from the
Naresh Kumar Inquiry Report. He reiterates that the law as laid down by the Supreme Court in the
cases of Kehar Singh Vs. The State; Dr. Baliram Waman Hiray Vs. Justice B. Lentin and Smt. Kiran
Bedi Vs. Committee of Inquiry is clearly that the report not admissible in evidence.
84. In rejoinder Dr. Dhawan adopted and elaborated on arguments of Mr. Desai in respect of the
Petitioners having handed over a mass of material which according to him raised an enormous
number of Issues. Dr. Dhawan submitted that such detailed documents running over hundred pages
should not be permitted to be introduced as they raised serious disputed questions of fact. He
submitted that these documents should not form the basis of any conclusions that the Court might
come to on any evidentiary and factual matters which go to liability . He submitted that these
documents should not be relied upon in these proceedings.
85. Dr. Dhawan submitted that the cases cited by the Petitioner may be classified as follows:
(a) Cases where Issues of fact and liability were determined or to be determined by
way of civil suit or criminal proceedings :
N. Nagendra Achutrao Bhopal Union Carbide
(b) Cases where Issues of fact and liability were determined by leading evidence in
the consumer forum Lucknow Development Authority Poonam Verma
(c) Cases where specific findings of fact were made because facts were not disputed at
the threshold or after further proceedings:Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

Rudul Sah Saheli Ravikant Nilabati Bhawanenshwar Singh 1993 (4) SCC Pg. 377
Punjab High Court .
Secy. Jaipur Development Authority Delhi Case (1992) Cr. L.J. Pg. 128 Khatri and
Khatri .
86. Dr. Dhawan submitted that the cases in which compensation was awarded are cases that dealt
with custodial death, disappearance and admitted detention viz.:
Sebastain Hongray 1984 (3) SCC Pg. 141 Nilabati Bhuwaneshwar Punjab High Court
87. Dr. Dhawan submitted that where facts are disputed, it has been held that the ordinary remedy
would lie viz.
DLF Construction Radhakrishan Express Newspaper .
88. Dr. Dhawan submitted that the case of R.S. Saini cited by Petitioners, on the fact findings of a
disciplinary inquiry, is not relevant for the purposes of this case. He submitted that this is even more
so in complex cases involving fundamental rights. Dr. Dhawan submitted that in CERC case relief
was given, by the Supreme Court, to the private affected parties under Art. 142 under peculiar
circumstances. Dr. Dhawan submitted that disputed questions of fact and liability are to be
determined by way of Civil Suit or in criminal proceedings. He submitted that where there is a
constitutional wrong by police and detention authorities resulting in a direct and in most cases self
evidently admitted infliction of grievous hurt, torture detention, the Court has intervened to award
damages for the constitutional wrong. Dr. Dhawan submitted that the proper procedure in public
interest cases, where there are disputed questions, is that a writ should not be entertained. He
submitted that where there are mass claims for damages these have to be considered in their
individual context.
89. Dr. Dhawan submitted that several arguments were advanced by the Petitioners by which a
distinction was sought to be made between public and private law. He submitted that it was argued
that the Writ jurisdiction was a proper forum to determine liability and award damages. He
submitted that these arguments cannot be supported in law. He submitted that Public law was
concerned with public actions of public officials and authorities performing public functions by or
on behalf of the State which are in excess of jurisdiction or in violation of fundamental rights. He
submitted that the distinction between public and private law remedies remains crucial and valid.
He submitted that private persons are normally not amenable to the Writ jurisdiction. He submitted
that in certain cases where the private persons discharged the functions of State and owed positive
obligations to the person affected a Writ may be maintainable. He submitted that this would be in
areas of education, environment and such cases. He submitted that the mere fact that a person falls
within a regime of permissions and prohibitions cannot bring him within the Writ jurisdiction. Such
an enlargment of public law remedies will greatly enlarge the scope of the Writ jurisdiction to
determine civil and criminal liability without adequate due process. He submitted that where there
are issues of civil liability with claims for damages arising out of such liability which has to beAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

proven by due process the proper course is a suit. He submitted that the purpose of damages in
public law is different from civil cases and is ordered only when violation of fundamental rights is
established. He submitted that damages based on liability are awarded only in civil cases after
appropriate due processes through which facts and liability are determined. He submitted that
damages are not awarded en masse but are awarded individually according to the claim. He
submitted that ultra vires can never be the basis of liability or damages. He submitted that liability
must be determined in civil or criminal proceedings. He submitted that concepts of public and
private law are not interchangeable and must not be cross fertilized.
90. Dr. Dhawan submitted that the concept of res ipsa loquitor is a rule of evidence. He submitted
that the assumptions arising out of res ipsa loquitor are defeasible on the basis of factual evidence
relating to causation.
91. Dr. Dhawan submitted that no case had been made out against Respondnts 11 to 40 and that
Respondents 11 to 40 should be deleted from the list of Respondents.
92. In rejoinder all the other Counsel reiterated what they had argued earlier and/or supported Mr.
Desai and Dr. Dhawan in their submissions that the Petitioners had not been able to show taht the
Petition was maintainable.
93. We have heard parties at length and considered all the submissions. The cases relied upon by
Mr. Desai and Dr. Dhawan undoubtedly show that the law is that, ordinarily, if disputed questions
of fact arise, Courts would not interfere in Writ jurisdiction. Also at one stage State did enjoy an
immunity. However, law has developed with the times. None of the cases, relied upon by Mr. Desai,
Dr. Dhawan, and/or Mr. Rawal have dealt with or considered the law as it has evolved. Now the law
is that in cases where question of life and liberty arise, merely because some disputed questions of
fact are sought to be raised, Court would not be justified in requiring the party to seek relief by way
of lengthy, dilatory and expensive process of a Civil Suit. As seen by the various authorities citted by
Mr. Tulsi Court is not powerless in such cases. As has been set out by the Supreme Court in Century
Spinning & Manufacturing Co. Ltd's case the High Court may, in exercise of its discretion, decline to
exercise its extrardinary jurisdiction under Art. 226 of the Constitution. But the discretion is
judicial. Thus if the Petitioner makes a claim which is frivolous, vixatious, or prima facie unjust or
which may not appropriately be true in a Petition invoking extraordinary jurisdiction, the Court may
decline to entertain the Petition. But a party claiming to be aggrieved by the action of a public body
or authority on the plea that the action is unlawful, highhanded, arbitrary or unjust is entitled to a
hearing of its Petition on the merits. Merely because a question of fact is raised, the High Court will
not be justified in requiring the party to seek relief by the somewhat lengthy, dilatory and expensive
process by a civil Suit against a public body. In Bandhua Mukti's case the Supreme Court held that
Court can appoint responsible persons as commissioner and ascertain facts for itself. The Supreme
Court held that once the Report of the Commissioners is received it would be supplied to the parties
so that if they dispute any fact or data they may do so by filing an Affidavit. The Supreme Court held
that Court could then consider the Report and the Affidavits and that it would then be for the Court
to decide what weight is to be attached to facts and data stated in the Report of the Commissioner.
As set out in Bandhua Mukti's case it would not be correct to say that the report of a CourtAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

appointed Commissioner had no evidentiary value since statements in it were not tested by cross
examination. This case shows taht court have power to appoint Commissioner whose Reports will
furnish prima facie evidence on the basis of which the Writ Court can act. The Supreme Court also
appointed Commissioners and ascertained facts for itself for itself amongst others in Bhola Nath
Tripathi's case and M.C. Mehta's case. In this last mentioned case Supreme Court has gone to the
extent of laying down that Courts are free to devise any procedure appropriate for that particular
purpose.
94. Also in Bandhua Mukati Morcha case it has been held that what the Supreme Court do under
Article 32, the High Court can also do under Art. 226. As stated by the Supreme Court the
jurisdiction of the High Court under Art. 226 is much wider.
95. The cases cited by Mr. Tulsi also show that it is no longer correct to submit that in writ
jurisdiction action cannot be taken against private parties. In Bandhua Mukti's case, Bhola Nath
Tripathi's case, Consumer Education Research Centre's case, Andi Mukti Trust's Tripathi's case,
Indian Council for Environment Legal Actions case and M.C. Mehta's case Court found out facts for
itself. In the last mentioned case Supreme Court has held as follows :
"30. Before we part with this topic we may point out that this Court has throughout
the last few years expanded the horizon of Art. 21 primarily to inject respect for
human rights and social conscience in our corporate structure. The purpose of
expansion has not been to destroy the raisin d'etre of creating corporations but to
advance the human rights jurisprudence. Prima facie we are not inclined to accept
the apprehensions of learned counsel for Shriram as well founded when he says that
our including with in the ambit of Article 12 and thus subjecting to the discipline of
Art 21, those private corporations whose activities have the potential of affecting the
life and health of the people would deal a death blow to the policy of encouraging and
permitting private entrepreneurial activity. Whenever a new advance is made in the
field of human rights, apprehension is always expressed by the status quoists that it
will create enormous difficulties in the way of smooth functioning of the system and
affect its stability. Similar apprehension was voiced when this court in R.D. Shetty
case brought public sector corporations within the scope and ambit of Art. 12 and
subjected them to the discipline of fundamental rights. Such apprehension expressed
by those who may be affected by new and innovative expansion of human rights, need
not deter the court from widening the scope of human rights,and expanding their
reach and ambit, if otherwise it is possible to do so without doing violence to the
language of the constitutional provision. It is through creative interpretation and
bold innovation that the human rights jurisprudence has been developed in our
country to a remarkable extent and this forward march of the human rights
movement cannot be allowed to be halted by unfounded apprehensions expressed by
the statuts quoists..........
31. We must also deal with one other question which was seriously debated before us
and that question is as to what is the measure of liability of an enterprise which isAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

engaged in an hazardous or inherently dangerous industry, if by reason of an accident
occuring in such industry, persons die or are injured. Does the rule in Rylands Vs.
Fletcher, (1868) LR 3 HL 330 apply or is there any other principle on which the
liability can be determined. The rule in Rylands Vs. Fletcher was evolved in the year
1866 and it provides that a person who for his own purposes brings on to his land and
collects and keeps there anything likely to do mischief if it escapes must keep it at his
peril and if he fails to do so, is prima facie liable for the damage which is the natural
consequence of its escape. The liability under this rule is strict and it is no defense
that the thing escaped without that persons's willful act, default or neglect or even
that he had no knowledge of its existence. This rule lais down a principle of liability
that if a person who brings on to his land and collects and keeps there anything likely
to do harm and such thing escapes and does damage to another he is liable to
compensate for the damage caused. Of course, this rule applies only to non natural
user of the land and it does not apply to things naturally on the land or where the
escape is due to an act of Govt. and an act of a stranger or the default of the person
injured or where the thing which escapes is present by the consent of the person
injured or in certain cases where there is statutory authority. Vide Halsbury's Laws of
England, Vol 45, para 1305. Considerable case law has developed in England as to
what is natural and what is non natural use of land and what are precisely the
circumstances in which this rule may be displaced. But it is not necessary for us to
consider these decisions laying down the parameters of this rule because in a modern
industrial society with highly developed scientific knowledge and technology where
hazardous or inherently dangerous industries are necessary to carry as part of the
developmental programme, this rule evolved in the 19th century at a time when all
these developments of science and technology had not taken place consistent with the
constitutional norms and the needs of the present day economy and social structure.
We need not feel inhibited by this rule which was evolved in the context of a totally
different kind of economy. Law has to grown in order to satisfy the needs of the fast
changing society and keep abreast with the economic developments taking place in
the country. As new situations are arise the law has to be evolved in order in order to
meet the challenge of such new situations. Law cannot afford to remain static. We
have to evolve new principles and lay down new nroms which would adequately deal
with the new problems which arise in a highly industrialised economy. We cannot
allow our judicial thinking to be constricted by reference to the law as it prevails in
England or for the matter of that in any other foreign country. We no longer need the
crutches of a foreign legal order. We are certainly prepared to receive light from
whatever source it comes but we have to build our own jurisprudence and we cannot
countenance an argument taht merely because the law in England does not recognise
the rule of strict and absolute liability in cases of hazardous or inherently dangerous
activities of the rule laid down in Rylands Vs. Fletcher as developed in England
recognise certain limitations and exceptions, we in India must hold back and not
venture to evolve a new principle of liability since English courts have not done so.
We have to develop our own law and if we find that it is necessary to contruct a new
principle of liability to deal with an unusual situation which has arisen and which isAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

likely to arise in future on account of hazardous or inherently dangerous industries
which are concomitant to an industrial economy, there is no reason why we should
hesitate to evolve such principle of liability merely because it has not been so done in
England. We are of the view that an enterprise which is engaged in a hazardous or
inherently dangerous industry which poses a potential threat to the health and safety
of the persons working in the factory and residing in the surrounding areas owes an
absolute and non delegable duty to the community to ensure that no harm results to
anyone on account of hazardous or inherently dangerous nature of the activity which
it has undertaken. The enterprise must be held to be under an obligation to provide
that the hazardous or inherently dangerous activity in which it is engaged must be
conducted with the highest standards of safety and if any harm results on account of
such activity the enterprise must be absolutely liable to compensate for such harm
and it should be no answer to the enterprise to satisfy that it had taken all reasonable
care and that the harm occurred without any negligence on its part. Since the persons
harmed on account of the hazardous or inherently dangerous activity carried on by
the enterprise would not be a in a position to isolate the rocess of operation from the
hazardous preparation of substance or any other related element that caused the
harm the enterprise must be held strictly liable for causing such harm as a part of the
social cost of carrying on the hazardous or inherently dangerous activity.If the
enterprise is permitted to carry on an hazardous or inherently dangerous activity for
its profit, the law must presume that such permission is conditional on the enterprise
absorbing the cost of any accident arising on account of such hazardous or inherently
dangerous activity as an appropriate item of its overheads. Such hazardous or
inherently dangerous activity for private profit can be tolerated only on condition
that the enterprise engaged in such hazardous or inherently dangerous activity
indemnifies all those who suffer on account of the carrying on of such hazardous or
inherently dangerous activity regardless of whether it is carried on carefully or not.
This principle is also sustainable on the ground that the enterprise alone has the
resource to discover and guard against hazards or dangers and to provide warning
against potential hazards. We would therefore hold that where an enterprise is
engaged in a hazardous or inherently dangerous activity and harm results to anyone
on account of an accident in the operation of such hazardous or inherently dangerous
activity resulting, for example, in escape of toxic gas the enterprise is strictly and
absolutely liable to compensate all those who are affected by the accident and such
liability is not subject to any of the exceptions which operate vis a vis the tortuous
principle of strict liability under the rule in Rylands Vs. Fletcher.
96. Mr. Rawal's submission that acts of his clients were acts of State and that they thus enjoined
sovereign immunity is no longer true due to the law as laid down by the Supreme Court in various
authorities relied upon by Mr. Tulsi. To recapitulate only a few. In the case of Lucknow
Development Authority, it has been held that under our Constitution sovereignty vests in the people.
Every limb of the constitutional machinery is obliged to be people oriented. No functionary in
exercise of statutory power can claim immunity, except to the extent protected by statute itself.
Public authorities acting in violation of constitutional or statutory provisions oppressively areAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

accountable for their behaviour. The rationale behind this, in the words of Supreme Court, is :
"The jurisdiction and power of the courts to indemnify a citizen for injury suffered
due to abuse of power by public authorities is founded as observed by Lord Hailsham
in Cassell & Co. Ltd. Vs. Broome on the principle that, an award of exemplary
damages can serve a useful purpose in vindicating the strength of law. An ordinary
citizen or a common man is hardly equipped to match the might of the State or its
instrumentalities. That is provided by the rule of law. It acts as a check on arbitrary
and capricious exercise of power. In Rookes Vs. Barnard it was observed by Lord
Devlin, 'the servants of the governments are also the servants of the people and the
use of their power must always be subordinate to their duty of service. A public
functionary if be acts maliciously or oppressively and the exercise of power results in
harassment and agony then it is not an exercise of power but its abuse. No law
provides protection against it. He who is responsible for it must suffer it.
Compensation or damages as explained earlier may arise even when the officer
discharges his duty honestly and bona fide. But when it arises due to arbitrary or
capricious behaviour then it loses its individual character and assumes social
significance. Harassment of a common man by public authorities is socially
abhorring and legally impermissible. It may harm him personally but the injury to
society is far more grievous. Crime and corruption thrive and prosper in the society
due to lack of public resistance. Nothing is more damaging then the feeling of
helplessness. An ordinary citizen instead of complaining and fighting succumbs to
the pressure of undesirable functioning in offices instead of standing against it.
Therefore the award of compensation for harassment by public authorities not only
compensate the individual, satisfies him personally but helps in curing social evil. It
may result in improving the work culture and help in changing the outlook."
97. Also as seen in Nilabeti Behrai's case in spite of highly disputed questions of fact it was held (
relying on cases of Rudul Shah Vs. State of Bihar, Sebastian Hongray Vs. UOI. Bhim Singh Vs. State
of J & K, Saheli Vs. Commissioner of Police and State of Mahrashtra Vs. Ravikant S. Patil) that the
liability of the State to pay compensation cannot now be denied. In this case it was clarified that this
liability to compensate in public law was different and distinct from the liability in private law for
compensation in an action on tort. It was clarified by the Supreme Court, in this case, that award of
compensation in a proceeding under Art. 32 or Art 226 is a remedy available in public law based on
strict liability for contravention of fundamental rights to which the principles of sovereign immunity
did not apply, even though it may have been available as a defense in private law in an action based
on tort. On this point the Supreme Court has observed as follows :
"17. It follows that a claim in public law for compensation for contravention of human
rights and fundamental freedoms, the protection of which is guaranteed in the
Constitution, is an acknowledged remedy for enforcement and protection of such
rights, and such a claim based on strict liability made by resorting to a constitutional
remedy provided for the enforcement of a fundamental right is distinct from, and in
addition to, the remedy in private law for damages for the tort, resulting from theAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

contravention of the fundamental right. The defense of sovereign immunity being
inapplicable, and alien to the concept of guarantee of fundamental rights, there can
be no question of such a defense being available in the constitutional remedy. It is
this principle which justifies award of monetary compensation for contravention of
fundamental rights guaranteed by the Constitution, when that is the only practicable
mode of redress available for the contravention made by the State or its servants in
the purported exercise of their powers, and enforcement of the fundamental right is
claimed by resort to the remedy in public law under the Constitutional by recourse to
Articles 32 and 226 of the Constitution. This is what was indicated in Rudul Sah and
is the basis of the subsequent decisions in which compensation was awarded under
Articles 32 and 226 of the Constitution, for contravention of fundamental rights".
"33. The old doctrine of only relegating the aggrieved to the remedies available in
civil law limits the role of the Courts too much as protector and guarantor of the
indefeasible rights of the citizens. The Court have the obligation to satisfy the social
aspirations of the citizens because the Courts and the law are for the people and
expected to respond to their aspirations.
34. The public law proceedings serve a different purpose than the private law
proceedings. The relief of monetory compensation, as exemplary damages, in
proceedings under Articles 32 by this Court or under Article 226 by the High Courts,
for established infringement of the indefeasible right guaranteed under Article 21 of
the Constitution is a remedy available in public law and is based on the strict liability
for contravention of the guaranteed basic and indefeasible rights of the citizen. The
purpose of public law is not only to civilize public power but also to assure the citizen
that they live under a legal system which aims to protect their interests and preserve
their rights. Therefore, when the court moulds the relief by granting 'compensation '
in proceedings under Article 32 and 226 of the Constitution seeking enforcement or
protection of fundamental rights, it does so under the public law by way of penalizing
the wrongdoer and fixing the liability for the public wrong on the State which has
failed in its public duty to protect the fundamental rights of the citizen. The payment
of compensation in such cases is not to be understood, as it is generally understood in
a civil action for dam ages under the private law but in the broader sense of providing
relief by an order of making "monetary amends" under the public law for the wrong
done due to breach of public duty, of not protecting the fundamental rights of the
citizens. The compensation is in the nature of 'exemplary damages' awarded against
the wrongdoer for the breach of its public law duty and is independent of the rights
available to the aggrieved party to claim compensa tion under the private law in an
action based on tort, through a Suit instituted in a Court of competent jurisdiction
or/and prosecute the offender under the penal law.
35. This Court and the High Courts, being the protectors of the civil liberties of the
citizen, have not only the power and jurisdiction but also an obligation to grant relief
in exercise of its jurisdiction under Article 32 and 226 of the Constitution to theAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

victim or the heir of the victim whose fundamental rights under Article 21 of the
Constitution of India are established to have been flagrantly infringed by calling upon
the State to repair the damage done by its officers to the fundamental rights of the
citizens, notwithstanding the right of the citizen to the remedy by way of a Civil Suit
or criminal proceedings. The State of course has the right to be indemnifies by and
take such action as may be available to it against the wrongdoer in accordance with
law through appropriate proceedings. Of course, relief in exercise of the power under
Article 32 or 226 would be granted only once it is established that there has been an
infringement of the fundamental rights of the citizen and no other form of
appropriate redressal by the court in the facts and circumstances of the case, is
possible. The decisions of this Court in the line of cases starting with Rudul Sah Vs.
State of Bihar granted monetary relief to the victims for deprivation of their
fundamen tal rights in proceedings through petitions filed under Articles 32 or 226 of
the Constitution of India, notwithstanding the rights available under the civil law to
the aggrieved party where the courts found that grant of such relief was warranted. It
is a sound policy to punish the wrongdoer and it is in that sprit that the courts have
moulded the relief by granting compensation to the victims in exercise of their writ
jurisdiction. In doing so the courts take into account not only the interest of the appli
cant and the Respondent but also the interests of the public as a whole with a view to
ensure that public bodies or officials do not act unlawfully and do perform their
public duties property particularly where the fundamental right of a citizen under
Article 21 is concerned. Law is in the process of development and the process
necessitates developing separate public law procedures as also public law principles.
It may be necessary to identify the situations to which separate proceedings and
principles apply and the courts have to act firmly but with certain amount of
circumstances and self restraint, lest proceedings under Articles 32 or 226 are
misused as a disguised substitute for civil action in private law. Some of those
situations have been identified by this Court in the cases referred to Brother Verma,
J."
98. At the stage it would also be convenient to reproduce following observation of the Supreme
Court in Kahtri's case :
"7. That takes us to the question whether the reports made by Shri L.V. Singh as a
result of the investigation carried by him and his associates are relevant under any
provision of the Indian Evidence Act so as to be liable to be produced and received in
evidence. It is necessary, in order to answer this question, to consider what is the
nature of the proceeding before us and what are the issues which arise in it. The
proceeding is a Writ Petition under Article 32 for enforcing the fundamental rights of
the Petitioners enshrined in Article 21. The Petitioners complain that after arrest,
whilst under police custody, they were blinded by the members of the police force,
acting not in their private capacity but as police officials and their fundamental right
to life guaranteed under Article 21 was therefore violated and for this violation the
State is liable to pay compensation to them. The learned Attorneyeneral who at oneAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

stage appeared on behalf of the State at the hearing of the Writ Petition contended
that the inquiry upon which the court was embarking the order to find out whether or
not the Petitioners were blinded by the police officials whilst in police custody was
irrelevant, since in his submission, even if the Petitioners were so blinded, the State
was not liable to pay compensation to the Petitioners first, because the State was not
constitutionally or legally responsible for the acts of the police officers outside the
scope of their power or authority and the blindings of the under trial prisoners
effected by the police could not therefore be said to constitute violation of their
fundamental, right under Article 21 by the State and secondly, even if there was
violation of the fundamental right of the Petitioners under Article 21 by reason of the
blindings effected by the police officials, there was, on a true construction of that
Article, no liability on the State to pay compensation to the Petitioner. The attempt of
the learned Attorney General in advancing the contention was obviously to prempt
the enquiry which was being made by this Court so that the Court may not proceed to
probe further in the matter. But we do not think we can accede to this contention of
the learned Attorney general. The two questions raised by the learned Attorney
General are undoubtedly important but the arguments urged by him in regard to
these two questions are not prima facie so strong and appealling as to persuade us to
decide them as preliminary objections without first inquiring into the facts. Some
serious doubts arise when we consider the argument of the learned Attorney General.
If an officer of the State acting in his official capacity threatens to deprive a person of
his life or personal liberty without the authority of law, can such person not approach
the Court for injuncting the State from acting through such officers in violation of his
fundamental right under Article 21 ? Can the State urge in defense in such a case that
it is not infringing the fundamental right of the Petitioner under Article 21 because
the officer who is threatening to do so is acting outside the law and therefore beyond
the scope of his authority and hence the State is not responsible for his action Would
this not make a mockery of Article 21 and reduce it to nullity, a mere rope of sand, for
on this view, if the officer is acting according to law there would be no breach of
Article 21 and if he is acting without the authority of law, the State would be able to
contend that it is not responsible for his action and therefore there is no violation of
Article 21. So also if there is any threatened invasion by the State of the fundamental
right guaranteed under Article 21, the Petitioner who is aggrieved can move the Court
under Article 32 for a writ injuncting such threatened invasion and if there is any
continuing action of the State which is violative of the fundamental right under
Article 21, the Petitioner can approach the court under Article 32 and ask for a writ
striking down the continuanance of such action, but where the action taken by the
State has already resulted in breach of the fundamental right under Article 21 by
deprivation of sone limb of the Petitioner, would the Petitioner have no remedy
under Article 32 for beach of the fundamental right guaranteed to him ? Would the
Court permit itself to become helpless spectator of the violation of the fundamental
right of the Petitioner by the State and tell the Petitioner that though the Constitution
has guaranteed the fundamental right to him and has also given him the fundamental
right of moving the court for enforcement of his fundamental right, the Court cannotAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

give him and relief. These are some of the doubts which arise in our mind even in a
+32consideration of the contention of the learned Attorney General and we do not
therefore, think it would be right to entertain this contention as a preliminary
objection without inquiring into the facts of the case. If we look at the averments
made in the Writ Petition it is obvious that the Petitioners cannot succeed in claiming
relief under Article 32 unless they establish that their fundamental right under
Article 21 was violated and in order to establish such violation, they must show that
they were blinded by the police officials at the time of arrest or whilst in police
custody. This is the fundamental fact which must be established before the Petitioner
can claim relief under Article 32 and logically therefore the first issue to which we
must address ourselves is whether the foundational fact is shown to exist by the
Petitioners. It is only if the Petitioners can establish that they were blinded by the
members of the police force at the time of arrest or whilst in police custody that the
other questions raised by the learned Attorney General would arise for consideration
and it would be wholly academic to consider them if the Petitioners fail to establish
this foundational fact. We are, therefore, of the view, as at present advised, that we
should first inquire whether the Petitioners were blinded by the police officials at the
time of arrest or after arrest whilst in police custody, and it is in the context of this
inquiry that we must consider whether the reports made by Shri L.V. Singh are
relevant under the Indian Evidence Act so as to be receivable in evidence."
"8. We may at this stage refer to one other contention raised by Mr. K.G. Bhagat on
behalf of the State that if the court proceeds to hold an inquiry and comes to the
conclusion that the Petitioners were blinded by the members of the police force at the
time of arrest or whilst in police custody, it would be tantamount to adjudicating
upon the guilt of the police officers without their being parties to the present Writ
Petition and that would be grossly unfair and hence this inquiry should not be held by
the court until the investigation is completed and the guilt or innocence of the police
officer is established. We cannot accept this contention of Mr. K.G. Bhagat. When the
court trying the Writ Petition proceeds to inquire into the issue whether the
Petitioners were blinded by the police officials at the time of arrest or whilst in police
custody, it does so, not for the purpose of adjudicating upon the guilt of any
particular officer with a view to punishing him but for the purpose of deciding
whether the fundamental right of the Petitioners under Article 21 has been violated
and the State is liable to pay compensation to them for such violation. The nature and
object of the inquiry is altogether different from that in a criminal case and any
decision arrived at in the Writ Petition on this issue cannot have any relevant much
less any binding effect, in any criminal proceeding which may be taken against a
particular police officer. A situation of this kind sometimes arises when a claim for
compensation for accident caused by negligent driving of a motor vehicle is made in a
Civil Court or tribunal and in such a proceeding, it has to be determined by the Court
for the purpose of awarding compensation to the claimant, whether the driver of the
motor vehicle was negligent in driving, even through a criminal case for rash and
negligent driving may be pending against the driver. The pendency of a criminalAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

proceeding cannot be urged as a bar against the court trying a Civil Proceeding or a
Writ Petition where a similar issue is involved. The two are entirely distinct and
separate proceedings and neither is a bar against the other. It may be that in a given
case, if the investigation is still proceeding, the Court may defer the inquiry before it
until the investigation is completed or if the Court considers it necessary in the
interest of justice, it may postpone its inquiry even after the prosecution following
upon the investigation is terminated, but that is matter entirely for the exercise of the
discretion of the court and there is no bar precluding the court from proceeding with
the inquiry before it merely because the investigation or prosecution is pending".
99. This last case and the case of Punjab & Haryana High Court Bar Association show that pending
criminal proceedings are not a bar to Courts exercising powers under Article 32 or Art. 226 and
awarding damages. This is because award of compensation in such cases is on principles of strict
liability and has nothing to do with either criminal proceedings or civil claims arising in tort. Even
otherwise there is no compulsion on any party to disclose his defense. It is for the party to decide
whether he wants to file an affidavits. If the party does not file any affidavit he would not be
compelled to do so. If he files his affidavit he does so willingly.
100. On this law it cannot be said, at this stage, that the Petition is not maintainable. Even otherwise
we find that this is not a matter in which highly disputed question of fact arise. This appears to be a
matter in which facts could be ascertained very easily. The Rules and Regulation are clear and
unambiguous. Everybody knows them or should know them. It cannot seriously be disputed that the
Private Respondents, who were or are owners of Uphaar Cinema were (as are all cinema owners)
bound to strictly comply with them. It cannot be seriously disputed that the Govt. agencies are
entrusted with duty to ensure that the Rules and Regulations were complied with. It cannot be
seriously disputed that a theatre is one place where a large number of people have to sit in an
enclosed area for a fairly long period of time. There is a potential threat to life safety if fire, leakages
of gas etc. take place. This potential threat has to be guarded against. At this stage, therefore, it
cannot be said that the cinema owners/employees (past/present) cannot be held to be under an
obligation to provide and maintain all standards of safety and/or that they are not liable to
compensate for loss of fundamental right guaranteed under Article 21 if harm has arisen by virtue of
their not guarding against such hazard. Prima facie it appears that under the doctrine of strict
liability on Public Law ( as set out above) the liability would be then even if there is no negligence on
their part. The Govt. and its agencies would also be liable for not having ensured strict compliance
with Rules and Regulations which have been created to ensure safety. At this stage it appears to us
that this is the case in which there can hardly be any dispute. The Rules and Regulations are clear
and known. The affidavits of the public authorities support Petitioners and admit that there was non
compliance. In fact, Mr. Rawals arguments have necessarily been that Rules and Regulations were
not complied with. Mr. Rawal sought to justify the lapse of not ensuring compliance by blaming it on
the Orders of the High Court. At this stage, it appears to us that Orders of this Court only stayed the
suspension of licence for four days and/or the Order of the Lt. Governor. It prima facie appears that
Orders of the High Court did not justify grant of temporary permits for such a long period of time.
Admittedly, the fire took place on 13th June, 1997. Admittedly, a number of people have been killed
and/or injured. Admittedly, fire fighting equipments and/or ambulances arrived on scene late.Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

Admittedly at that time and even now the CATS Centre which was to have been created as far back
as 1986 has not yet been established. There also does not appear to be much dispute on fact that
number of seats had been increased, size of gangway reduced, one exit closed by creating a private
viewing box, etc. It can easily be ascertained whether there have been unauthorised deviations. The
building is still standing. These are matters which can easily be verified by the Court by appointment
of commissioners. The commissioners, who would be responsible persons, knowledgeable in the
field would visit the site in presence of all parties and ascertain facts. The Report of the
commissioner would show whether Rules and Regulataions were complied and whether there have
been deviations or not. It is clarified that Court is not giving any findings at this stage and is not
holding that there have been breach of Rules and/or Regulations and/or unauthorised deviations
and/or failure to enforce. All that the Court is saying is that at this stage it cannot conclude that the
petition is not maintainable.
101. In this view of the matter we do not find much substance in contentions that Petitioners could
not have and should not have been permitted to rely upon numerous documents. All the documents
shown to the Court were part of the Naresh Kumar Report. As Mr. Desai and Dr. Dhawan have
repeatedly commented, the Petition is based on that Report. Thus all Respondents have all along
known that material in support of the Petition would come from that Report. The Report was with
Respondent No. 2. it was produced in Court by Respondent No. 2. Petitioners did not have a full
copy of the Report with them. After it was produced by Respondent No. 2, Petitioner relied on it.
Having known all along that the Petition was based on that Report any Respondent could have
asked for and taken inspection of that Report. Not having done so they could hardly complain that
they were taken by surprise. In any event, they can now take full and complete inspection if they so
desire. Any party who wants inspection must so intimate in writing to Respondent No. 2 on or
before__________ Respondent No. 2 to give full complete inspection of the Report and all its
annexures to that party on or before _____. It being clarified that if a party does not take inspection
they will then not be entitled to complain that they are taken by surprise.
102. Whilst it cannot be said at this stage that the Petition is not maintainable, still we see some
substance in the submission that there is no case made out against some of the Respondents.
Respondent Nos. 21 and 30 to 36 have no nexus. They were not and are now or at time of fire
directors or shareholders or employees. Similarly, Respondents 14, 17, 19 and 20 are only
shareholders. As shareholders they have no role to play in the management and thus cannot be
made responsible for the lapses, even if there are any lapses. Thus, in our view the Petition will not
survive against these Respondents who will stand deleted.
103. It is again clarified that Court has not given any final findings. All observations are prima facie
only to show that at this stage it cannot be said that the Petition is not maintainable. The
preliminary objections are thus dismissed. Petition is now fixed on 14th July, 2000 for final hearing.
104. We appoint Mr. Ravinder Sethi, Senior Advocate, Delhi High Court Chambers, Prof. T.K. Dutta,
Head of Civil Engineering Deptt., IIT, New Delhi and Dr. Sanjeev Jain, in Mechanical Engineering
Deptt., IIT, New Delhi as Court Commissioners to visit the site, on as many occasions as required
after notice to all parties, and to submit a Report as to whether or not all Rules, Regulations andAssociation Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

statutory provisions were complied with and if not, to what extent. They are also to ascertain
whether there have been unauthorised deviations and if so to what extant. Such Report to be
submitted by 31.5.2000. Respondent No. 3 is directed to ensure that there are no
changes/alterations made of any item whatsoever or the building till further orders.Association Of Victims Of Uphaar ... vs Union Of India And Ors. on 29 February, 2000

