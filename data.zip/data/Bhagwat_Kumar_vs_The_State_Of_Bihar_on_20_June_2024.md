Bhagwat Kumar vs The State Of Bihar on 20 June, 2024
Bench: Chief Justice, Harish Kumar
         IN THE HIGH COURT OF JUDICATURE AT PATNA
                Civil Writ Jurisdiction Case No.16760 of 2023
     ======================================================
1.   Gaurav Kumar S/o Umesh Prasad Singh, resident of Village-Itahari (West),
     Distt.-Munger (Bihar).
2.   Naman Sherstra, S/o Santosh Singh, resident of Ward No. 04, Khurhan
     Milik, P.S. Alamnagar, District-Madhepura (Bihar).
                                                                 ... ... Petitioner/s
                                        Versus
1.   The State of Bihar through the Chief Secretary, New Secretariat, Patna,
     Bihar.
2.   The Secretary (IC) Law Department, Govt. of Bihar, New Secretariat, Patna,
     Bihar.
                                                             ... ... Respondent/s
     ======================================================
                                         with
                   Civil Writ Jurisdiction Case No. 16882 of 2023
     ======================================================
     Rakesh Sharma son of Devendra Sharma, resident of Village-Narchwar,
     Pachaura, Police Station-Harnaut, District-Nalanda.
                                                                 ... ... Petitioner/s
                                        Versus
1.   Union of India through the Cabinet Secretary, Central Secretariat, New
     Delhi, Delhi 110001.
2.   The State of Bihar through its Chief Secretary, New Secretariat, Patna.
3.   The Principal Secretary, General Administration Department, Government of
     Bihar, Patna.
4.   The Secretary to Government (I/C), Law Department, Government of Bihar,
     Patna.
                                                         ... ... Respondent/s
     ======================================================
                                     withBhagwat Kumar vs The State Of Bihar on 20 June, 2024

               Civil Writ Jurisdiction Case No. 17494 of 2023
     ======================================================
 Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
                                          2/87
       Bhagwat Kumar S/o-Pramod Kumar Resident of Post Noawan, Nehalpur,
       Jehanabad, P.S.-Shakurabad Bihar, Pin-804429, District-Jehanabad.
                                                                   ... ... Petitioner/s
                                             Versus
  1.    The State of Bihar through the Chief Secretary, New Secretariat, Patna
        Bihar.
  2.    The Principal Secretary, Department of General Administration, Government
        of Bihar, Patna.
  3.    The Deputy Secretary, General Administration Department, Government of
        Bihar, Patna.
  4.    The Principal Secretary to the Chief Minister, Government of Bihar, Patna.
                                                              ... ... Respondent/s
       ======================================================
                                         with
                   Civil Writ Jurisdiction Case No. 17770 of 2023
       ======================================================
       Anjani Kumar Tiwari S/o Narvdshwar Tiwari, R/o Village-Near Post Office
       Chandwa, P.O. and P.S.-Chandwa, District-Arrah, Bhojpur.
                                                                   ... ... Petitioner/s
                                             Versus
  1.    The State of Bihar through the Chief Secretary, Govt. of Bihar, New
        Secretariat, Patna, Bihar.
  2.    The Principal Secretary, General Administration, Govt. of Bihar, Patna.
                                                               ... ... Respondent/s
       ======================================================
                                           with
                     Civil Writ Jurisdiction Case No. 17916 of 2023
       ======================================================
       Youth For Equality, P-21, South Extension Part -II, New Delhi -110049
       through its Secretary Shri Subham Kumar aged about 33 years, Male, Son of
       Amrendra Kumar Singh, Rajeev Nagar, P.O, Keshri Nagar, Patna.Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

                                                                   ... ... Petitioner/s
                                             Versus
  1.    The State of Bihar through the Chief Secretary, New Secretariat, Patna,
 Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
                                          3/87
        Bihar.
  2.    The Additional Chief Secretary, Department of General Administration,
        Govt. of Bihar, Patna.
  3.    The Principal Secretary to the Governors Secretariat, Government of Bihar,
        Patna.
  4.    The Principal Secretary to the Chief Minister, Secretariat, Government of
        Bihar, Patna.
                                                               ... ... Respondent/s
       ======================================================
                                           with
                     Civil Writ Jurisdiction Case No. 18007 of 2023
       ======================================================
       Mohan Kumar son of Late Ayodhya Singh, Resident of Village-Motha, P.S.-
       Arwal, District-Arwal.
                                                                  ... ... Petitioner/s
                                             Versus
  1.    The State of Bihar through Chief Secretary, Government of Bihar, Patna.
  2.    The Secretary Law Department, Government of Bihar, Patna.
  3.    The Secretar In-Charge, Law Department, Government of Bihar, Patna.
  4.    The Union of India through Secretary, Ministry of Department of Personnel
        and Training, Government of India, New Delhi.
                                                                ... ... Respondent/s
       ======================================================
                                          with
                    Civil Writ Jurisdiction Case No. 18008 of 2023
       ======================================================
       Shashi Ranjan Singh Son of Sri Binod Prasad Singh Resident of Nagar Nigam
       Ke Pichhe, Senapath, Darbhanga, P.S.- Town, District- Darbhanga.Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

                                                                  ... ... Petitioner/s
                                             Versus
  1.    The State of Bihar through the Chief Secretary, New Secretariat, Patna,
        Bihar.
  2.    The Additional Chief Secretary, Department of General Administration,
        Govt. of Bihar, Patna.
 Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
                                          4/87
  3.    The Principal Secretary to the Governors Secretariat, Government of Bihar,
        Patna.
  4.    The Principal Secretary to the Chief Minister, Secretariat, Government of
        Bihar, Patna.
                                                                 ... ... Respondent/s
       ======================================================
                                             with
                        Civil Writ Jurisdiction Case No. 380 of 2024
       ======================================================
       Dhirendra Kumar Son of Sri Raghubansh Sharma, Resident of Village- Petwa,
       P.S.- Okri, P.O- Bandhiganj, District- Jehanabad.
                                                                   ... ... Petitioner/s
                                             Versus
  1.    The State of Bihar through Chief Secretary, Government of Bihar, Patna.
  2.    The Secretary Law Department, Government of Bihar, Patna.
  3.    The Secretary In-charge, Law Department, Government of Bihar, Patna.
  4.    The Union of India, through Secretary, Ministry of Department of Personnel
        and Training, Government of India, New Delhi.
                                                             ... ... Respondent/s
       ======================================================
                                           with
                    Civil Writ Jurisdiction Case No. 1950 of 2024
       ======================================================
       Vikas Kumar Son of Mukesh Kumar, Resident of Mohalla-New Harni Chak,
       Royal Residency Beur, P.S. Beur, Distt.-Patna.Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

                                                                   ... ... Petitioner/s
                                             Versus
  1.    The State of Bihar through the Chief Secretary Govt. of Bihar, Patna.
  2.    The Chief Secretary Govt. of Bihar, Patna.
  3.    The Principal Chief Secretary General and Administrative Department,
        Govt. of Bihar, Patna.
  4.    The Principal Secretary Law Department, Govt. of Bihar, Patna.
                                                                 ... ... Respondent/s
 Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
                                          5/87
       ======================================================
                                            with
                      Civil Writ Jurisdiction Case No. 4252 of 2024
       ======================================================
       Madhup Kumar Singh @ Munmun Singh son of Shambhunath Singh,
       Resident of Village-Adauri, P.S.-Purhania, District-Sheohar.
                                                                    ... ... Petitioner/s
                                             Versus
  1.    The State of Bihar through the Secretary, Department of Law, Patna.
  2.    The Legal Remembrance, Bihar, Patna.
  3.    The Secretary, Cabinet Department, Bihar, Patna.
                                                                  ... ... Respondent/s
       ======================================================
       Appearance :
       (In Civil Writ Jurisdiction Case No. 16760 of 2023)
       For the Petitioner/s     :      Mr. Gopal Shankaranarayan, Sr. Advocate
                                       Mr. Gaurav Kumar (In Person)
                                       Mr. Abhinav Srivastava, Advocate
                                       Mr. Pawan Reley, Advocate
                                       Mr. Neeraj Gupra, Advocate
                                       Mr. Akshay Lodhi, Advocate
                                       Mr. Alok Abhinav, Advocate
                                       Mr. Nrupal A. Dingankar, Advocate
                                       Mr. Rajat Kumar, Advocate
                                       Mr. Brahmanand Kumar, AdvocateBhagwat Kumar vs The State Of Bihar on 20 June, 2024

                                       Mr. Naman Sherstra, Advocate
                                       Mr. Shyam Kishore, Advocate
                                       Mr. Riwaz Rai, Advocate
                                       Mr. Devesh Kumar, Advocate
                                       Mr. Madhav Gupta, Advocate
                                       Mr. Vishal Sinha, Advocate
                                       Mr. Alok Kumar, Advocate
       For the State            :      Mr. P. K. Shahi, AG
                                       Mr. Vikas Kumar, AC to AG
                                       Mr. Amish Kumar, AC to AG
                                       Mr. Manish Kumar, Advocate
                                       Mr. Sanjiv Kumar, Advocate
                                       Mr. R.Ranjan, Advocate
       For the Intervener       :      Mr. Y.V.Giri, Sr. Advocate
                                       Mr. Pranav Kumar, Advocate
                                       Mr. Shrishti Singh, Advocate
                                       Mr. Devashish Giri, Advocate
       (In Civil Writ Jurisdiction Case No. 16882 of 2023)
 Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
                                          6/87
       For the Petitioner/s     :       Mr. Amit Srivastava, Sr. Advocate
                                        Mr. Nirbhay Prashant, Advocate
       For the Respondent/s :           Dr. K. N. Singh, Additional Solicitor General
       For the UOI          :           Mr. Kumar Priya Ranjan, CGC
                                        Mr. Sandeep Kumar, Advocate
                                        Mr. Vibhuti Kumar, Advocate
       (In Civil Writ Jurisdiction Case No. 17770 of 2023)
       For the Petitioner/s     :      Mr. Mrigank Mauli, Sr. Advocate
                                       Mr. Samir Kumar, Advocate
                                       Mr. Sanket, Advocate
                                       Mrs. Smriti Singh, Advocate
                                       Mr. Sauravh Singh, Advocate
                                       Mr. Navin Kumar Singh, Advocate
       For the Respondent/s :          Mr. P. K. Shahi, Advocate General
       (In Civil Writ Jurisdiction Case No. 17916 of 2023)
       For the Petitioner/s     :      Mr. Dhananjay Kumar Tiwary, Advocate
       For the Respondent/s :          Mr. Rana Vikram Singh, Advocate
                                :      Mr. Janardan Pd. Singh, Sr. Advocate
                                       Mr. Rajiv Ranjan Kr. Pandey, Advocate
       (In Civil Writ Jurisdiction Case No. 18007 of 2023)
       For the Petitioner/s     :      Mr. Dinu Kumar, Advocate
                                       Mrs. Ritika Rani, Advocate
                                       Mr. Vardaan Mangalam, Advocate
       For the Respondent/s :          Mr. P.K.Shahi, Advocate General
       For the UOI              :      Mr. Kumar Priya Ranjan, CGCBhagwat Kumar vs The State Of Bihar on 20 June, 2024

                                       Mr. Sandeep Kumar, Advocate
       (In Civil Writ Jurisdiction Case No. 18008 of 2023)
       For the Petitioner/s     :      Mr. Sanjay Singh, Sr. Advocate
                                       Mr. Rudrank Shivam Singh, Advocate
                                       Mrs. Bandana Singh, Advocate
                                       Mr. Dhananjay Kumar Tiwary, Advocate
       For the Respondent/s :          Mr. Rana Vikram Singh, Advocate
                                :      Mr. Rajiv Ranjan Kr. Pandey, Advocate
       (In Civil Writ Jurisdiction Case No. 380 of 2024)
       For the Petitioner/s     :      Mr. Dinu Kumar, Advocate
                                       Mrs. Ritika Rani, Advocate
                                       Mr. Vardhan Mangalam, Advocate
       For the Respondent/s :          Mr. P.K.Shahi, Advocate General
       (In Civil Writ Jurisdiction Case No. 17494 of 2023)
       For the Petitioner/s     :      Mr. P N Shahi, Sr. Advocate
                                       Mr. Mrigank Mauli, Sr. Advocate
                                       Mr. Amit Anand, Advocate
                                       Ms. Deeksha Singh, Advocate
                                       Mr. Vishal Kumar, Advocate
                                       Mr. Deep Shekhar, Advocate
                                       Mr. Ankur Govind, Advocate
 Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
                                          7/87
                                        Mr. Raghvendra Kumar, Advocate
       For the Respondent/s :           Mr. P.K.Shahi, Advocate General
                                        Mr. Vikas Kumar, AC to AG
                                        Mr. Amish Kumar, AC to AG
                                        Mr. Manish Kumar, Advocate
                                        Mr. Sanjiv Kumar, Advocate
       (In Civil Writ Jurisdiction Case No. 1950 of 2024)
       For the Petitioner/s     :      Mr. Vikas Kumar (In person)
       For the Respondent/s :          Mr. P. K. Shahi, AG
       (In Civil Writ Jurisdiction Case No. 4252 of 2024)
       For the Petitioner/s     :      Mr. Sanjay Kumar, Advocate
       For the Respondent/s :          Mr. P. K. Shahi, AG
       ======================================================
       CORAM: HONOURABLE THE CHIEF JUSTICE
                  and
                  HONOURABLE MR. JUSTICE HARISH KUMAR
       CAV JUDGMENT
(Per: HONOURABLE THE CHIEF JUSTICE) Date : 20-06-2024 Equality of opportunity pitted
against reparations for long years of deprivation of equality, has been the subject of judicialBhagwat Kumar vs The State Of Bihar on 20 June, 2024

discourse while adjudicating affirmative action; introduced both by the Central and State
Governments within this country. One of such affirmative action exceeding the 50% limit; as
prescribed by a 9 Judge Constitution Bench in Indra Sawhney v. Union of India, 1992 Supp (3) SCC
217, enhancing reservation to 65% within the State of Bihar, is challenged in these batch of writ
petitions. The State has brought in such reservation based on the Caste Survey, which found the
majority of the population within the State, belonging to the marginalized and deprived
communities of Backward & Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 Extremely
Backward Classes, Scheduled Castes and Scheduled Tribes. The petitioners cry foul on the perceived
sacrifice of merit, thus, frustrating the fundamental right of equality of opportunity in public
employment & admissions to educational institutions, guaranteed under Part III of the Constitution
of India.
2. Shri Mrigank Mauli, learned Senior Counsel led the arguments for the petitioners which
commenced with the statement that the entire edifice of the Amendment Act and the enhancement
in reservation, is built upon the Caste Survey, the results of which were published just a few days
before the Amendment Bill was introduced in the Legislature. The Caste Survey notified on
06.06.2022 was completed by 05.08.2023 and the report published on 02.10.2023. The caste wise
socio- economic report was brought out on 07.11.2023 and the bill was tabled hastily on 09.11.2023.
There was hence, no analysis carried out despite the Preamble of the Act referring to such an
analysis. The automatic escalation of the percentage for each and every caste referred to in the Bihar
Reservation of Vacancies in Posts and Services (for Scheduled Castes and Scheduled Tribes and
Other Backward Classes) Act, 1991, (hereinafter referred to as 'Reservation Act'), was mechanically
carried out Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 without reference to the real
facts & figures coming out of the Caste Survey. It is specifically argued that though land holding of
every individual was one of the terms of reference in the caste survey, there was no analysis of the
economic status of each community granted reservation, based on the details of the land holdings
collected in the survey or an examination of the productive nature of such holding.
3. The Preamble was read over to us which according to the learned Senior Counsel speaks of a
proportional representation having been attempted, as is the provision of reservation in elections to
local bodies. It is pointed out that such proportional representation, confined to SC and ST, as
coming out from 243D and 243T, based on Article 330(2) cannot be imported automatically into
Article 16. Article 16(4) specifically speaks of adequate representation as the yardstick to determine
the benchmark, for providing reservation in appointments in posts, to any backward class of
citizens. Though the word 'adequate' is not employed in Article 15(4), the Hon'ble Supreme Court
has held it to be a valid basis for understanding the social and educational standards of backward
class of citizens and of the SC and ST. The economic criteria hence, is an important index on which
the percentage of Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 reservation has to be
considered which has been totally ignored while bringing out the present amendment. It is also
pointed out that the rejoinder of the petitioner makes a better analysis of the facts and figures
coming out of the caste survey; which also would belie the contention of the State in support of
enhancement of the percentage of reservation.Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

4. Referring to the Preamble, the learned Senior Counsel also points out the casual manner in which
drafting was carried out, employing words without any meaning, especially in the portion where the
very object of the amendment is proclaimed. The affirmative measure has been wrongly termed a
'major' and for data, the word 'date' has been used. The Legislation proceeds on the basis that the
population of the State is divided into 85%; comprising of SC, ST and Backward Classes and the
balance 15% alone from the unreserved category. The entire substratum of the amendment turns on
the computation of reservation percentage available to the unreserved category; which is an exercise
of determining proportionate representation. It is patently illegal and irregular and there is no
constitutional sanction for making such proportional reservation under Article 15 and 16; akin to
that made under Article 243 D and 243 T. Patna High Court CWJC No.16760 of 2023
dt.20-06-2024
5. Indra Sawhney (supra) was specifically referred to and the history of Article 15 and 16 was traced,
to point out that whenever there was an interference caused by a decision of the Courts, the
Constitution itself was amended for maintaining the affirmative action. In fact, the 50% rule as
brought in by Indra Sawhney (supra) has been accepted by the Union Parliament while introducing
clause (4-A) in Article 16 which has been upheld in K. Krishna Murthy v. Union of India, (2010) 7
SCC
202. Under Article 16(4-A), the backlog vacancies were specifically held to be not violating the 50%
rule and this is the only situation in which the ceiling of 50% would not be applicable. Specific
reference was made to clause (6) of both Articles 15 and 16, wherein the 10% reservation was made
for the Economically Backward Communities of the unreserved category by the 103rd amendment.
This was upheld by the Hon'ble Supreme Court in Janhit Abhiyan v. Union of India (EWS
Reservation), (2023) 5 SCC 1. The decision was relied on to argue that proportionality can never
justify excessive reservation above the 50% limit. Once more emphasis was laid, insofar as the said
measure having been brought in by a Constitutional Amendment, which is lacking in the present
case. The source of the power of the State is Article 15(4) and 16(4) Patna High Court CWJC
No.16760 of 2023 dt.20-06-2024 which has to be regulated by the authoritative pronouncements of
the Hon'ble Supreme Court regarding the breach not being possible of 50% reservation. Otherwise,
it would be in total frustration of merit, which would violate the constitutional guarantee of equal
opportunity.
6. Jaishri Laxmanrao Patil v. State of Maharashtra, (2021) 8 SCC 1 is relied on, which reaffirmed the
maximum of 50% in reservations as laid down in Indra Sawhney (supra); binding under Article 141.
The prayer for reference of Indra Sawhney (supra) to a larger bench was rejected clearly finding that
the thumping majority of five judges out of nine was in favour of the reservations being limited to
50% while three dissenting judges held that reservation can only be lesser than 50%. Only one of the
judges differed from this and found it possible even above 50%. It was found that M. Nagaraj v.
Union of India, (2006) 8 SCC 212 also did not lay down any ratio that ceiling of 50% reservation can
be exceeded by showing contemporary data regarding backwardness. The Commission which
approved the reservation in excess of 50%, impugned in the cited decision, was found to have
completely misconstrued the ratio of a number of Constitution Bench decisions, while taking the
view that ceiling of 50% can be Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 breachedBhagwat Kumar vs The State Of Bihar on 20 June, 2024

merely on the basis of quantifiable data. M. Nagaraj (supra) was also read over to us where tests
were laid down to judge the validity of affirmative action, which the impugned legislation herein
fails to pass. The mere existence of power to implement an affirmative measure cannot justify an
over- breadth, especially when there is a breach of the 50% limit.
7. The Mandal Commission report was referred to from the rejoinder, in which the three factors
considered were social, educational & economic. In the present survey, though there was emphasis
on the economic factors regarding income, land holding etc: the details of land holdings and
whether they are productive and/or unproductive were not at all disclosed in the report, thus
undermining the development which has been achieved by certain of the communities. The
economic aspect, which is crucial in determining the social and educational status of castes or
communities, has been completely ignored while considering the need for enhancement of
reservation. Definitely, there would have been improvement in the status of a community by the
affirmative action which has been in place for the last 75 years which had to be reckoned and at least
certain castes excluded from the category of marginalized and deprived; thus ensuring their exit
from the backward classes. Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
8. Shri Mrigank Mauli, learned Senior Counsel also took us to the rejoinder filed in CWJC No. 17770
0f 2023, in which a detailed analysis is provided regarding the data as discernible from the Caste
Survey, which, according to him, would belie the contention of the State that no proportionate
representation has been provided based on the inclusion in the various services. On the aspect of
judicial review, Jaishri Laxmanrao Patil (supra) is referred to and para-261 specifically pointed out
where the Hon'ble Supreme Court had looked into the data produced. As held in the cited decision,
the present exercise attempted by the State is a fraud on the Constitution. The affirmative action is
intended at providing a level playing field and not a device to provide facilities to certain
communities, who may not be necessarily marginalized or down trodden. The concept of
proportionate representation is alien to Article 15(4) and Article 16(4); which aspect, when
intended, was specifically referred to in the Constitution of India, as disclosed from Articles 243-D,
243-T, 330 and 332.
9. Adequate representation, as held in M. Nagaraj (supra), can only be to ascertain the
backwardness and the affirmative action should be only to such an extent as to not compromise the
efficiency in administration. Reference was Patna High Court CWJC No.16760 of 2023
dt.20-06-2024 made to Chebrolu Leela Prasad Rao v. State of Andhra Pradesh; (2021) 11 SCC 401,
wherein 100% reservation was found to be proportional when the area was comprised fully of
tribals. The words of Dr. B.R.Ambedkar, as extracted in Para- 104, was specifically read out and
reliance was placed on Para- 109 to emphasize that adequate representation does not mean
proportionate representation. Para-810 of Indra Sawhney (supra) was emphatically pointed out as
the only circumstance in which there could be more than 50% reservation; which is not available in
the present case.
10. Union of India v. Rakesh Kumar; (2010) 4 SCC 50 was relied on to contend that more than 50%
is possible only when there is a proportionate representation permitted by the Constitution, as in
Article 243D. With respect to the subjective satisfaction regarding the backwardness of oneBhagwat Kumar vs The State Of Bihar on 20 June, 2024

community or the other and the principles of judicial scrutiny involved, heavy reliance is placed on
Barium Chemicals Ltd. vs. Company Law Board; AIR 1967 SC 295. In conclusion, it is reiterated that
there is absolutely no thought or deliberation, which went into such excessive reservation being
granted and there was not even a reference to the Backward Commission constituted by a statute.
Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
11. Shri Gopal Shankaranarayanan, learned Senior Counsel appearing in CWJC No. 16760 of 2023,
pin pointed the historical evolution of the judicial precedents with respect to affirmative action by
first distinguishing those decisions under Articles 15 and 16 and then co-relating them. In a
challenge made with respect to an affirmative action under Article 16(4), it was upheld in B.
Venkataramana v. State of Madras & Anr.; AIR 1951 SC 229. Later in State of Madras vs.
Champakam Dorairajan; 1951 SCR 525 it was held that there is no provision under Article 15 akin to
Article 16(4); upon which by amendment, clause (4) was brought into Article 15. M.R.Balaji Vs. State
of Mysore; 1962 SCR Supl. (1)439, for the first time, dealt with the 50% limit in reservations, which
was followed in Devadasan vs. Union of India; (1964) 4 SCR 680, under Article 16 and
R.Chitralekha v. State of Mysore; (1964) 6 SCR 368, under Article 15. M.R.Balaji (supra), under
Article 15, though upheld the principle of reservation to educational institutions, found that 50% is
reasonable and adequate. State of Kerala & Ors. v. N.M.Thomas; (1976) 2 SCC 310, while upholding
the two years exemption granted for promotion from test qualification to SCs/STs, all the same held
that the reservation at no point should cross 50%. Indra Sawhney (supra) saw a Patna High Court
CWJC No.16760 of 2023 dt.20-06-2024 confluence of the principles laid down in the decisions
under Articles 15 and 16 and harmonized the seeming distinction in N.M.Thomas (supra) from
M.R.Balaji (supra).
12. The learned Senior Counsel specifically pointed out that the 50% reservation has a history of 120
years, it having been first legitimized by Rajarshi Sahoo Maharaj of Kolhapur who brought in quotas
in the appointments to the government; a full 48 years before Independent India adopted the
Constitution. The learned Senior Counsel emphasized that none of the cited decisions applied
proportionality to Article 15 or Article 16 and the term was glaringly absent in the said provision.
Referring to Indra Sawhney (supra), again on the scope and reach of judicial scrutiny in matters
within the subjective satisfaction of the executive; the principles as stated in Barium Chemicals
(supra), was emphasized. The principle in Indra Sawhney (supra) applies equally in the case of the
constitutional provision at Article 15(4), like Article 16(4), which expressly places the particular fact
of inadequate representation within the subjective judgment of the State/Executive. Referring to
Paragraph-81 of Indra Sawhney (supra), it was emphasized that the special circumstances stated
therein does not arise at all in the present case. Reference was made to the various provisions, Patna
High Court CWJC No.16760 of 2023 dt.20-06-2024 which were already placed before Court to point
out that when proportionate representation was intended, it was spelt out in the Constitution and
there can be no importation of the term where it is absent. Where there is no such mention, the
principle is not applicable and applying it would create excessive reservation, thus frustrating the
cause of equality.Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

13. In Jarnail Singh & Ors. v. Lachhmi NarainGupta & Ors.; (2018) 10 SCC 396, the learned Judges
refused to refer the decision in M. Nagraj (supra) to a larger Bench and it was clarified that there can
be no determination of backwardness for SC/ST, which, however, is the necessary ingredient to
include the communities and classify them as backward communities. The five Judge Bench noticed
the difference in language between Article 16 (4-A) and that in Articles 330 and 332.
14. Under Articles 15 and 16, there can be no distinction insofar as the applicability of the limit of
50% for reservations. The question of adequacy in representation, under Article 16(4), applies only
when backwardness has to be ascertained, which alone could result in affirmative action being
applied for backward communities. In summing up, the learned Senior Counsel would emphasize
that there can be no Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 reservation granted
beyond the 50% limit except in exceptional circumstances, as referred to in Indra Sawhney (supra).
Consistently for the last 70 years, the Hon'ble Supreme Court has fixed the ceiling of 50% in
reservations; to ensure that there is no compromise of merit. Indra Sawhney (supra) achieved a
confluence of the two strands of principles delineated in the decisions on Articles 15 and 16 and
emphasized that adequacy of representation can only be to provide reservation and it cannot be
equated with a proportionate representation enabling the 50% limit to be exceeded. Article 16(4-B)
was introduced to ensure that the carry forward vacancies within the reservation quota of a year was
not included in the quota for a subsequent selection year, which indirectly provided a constitutional
imprimatur to the 50% ceiling in reservations as declared by the decisions of the Hon'ble Supreme
Court. Arguments were also addressed on the National Backward Commission having not been
consulted, which, according to the learned Senior Counsel, is a mandate as per Article 338. Reliance
is also placed on Jaishri Laxmanrao Patil (supra) to further the said argument.
15. Shri Sanjay Singh, learned Senior Counsel who appeared in CWJC No. 18008 of 2023, pointed
out that equality is the foundational argument, both for and against reservation. Patna High Court
CWJC No.16760 of 2023 dt.20-06-2024 Indra Sawhney (supra) was referred, to point out that
equality forms a basic structure of the Constitution and to breach the 50% limit in granting
reservations would cause interference to the basic structure. Referring to the data placed before this
Court, it is argued that it does not suggest lack of adequate representation. The common thread of
challenge that there is no recommendation made to a Backward Commission, either at the national
level or that constituted within the State and the legislature too acted in haste, was adopted fully.
The data as revealed from the Caste Survey would make it imperative that certain castes are
excluded from the backward communities. But rather than considering exclusion, further benefits
have been granted to them, thus depriving other backward communities from such benefits and also
impinging into the merit-based considerations. Paragraph-422 was referred, to point out the test
laid down for adequacy, which has not been fulfilled in the present exercise. The interjection made
by the learned Advocate General regarding the subject petitions, not agitating exclusion or inclusion
of castes in the OBC list; was resisted on the ground that, without such consideration, reservation
would be excessive and impinge upon the equality clause. The data; at least with respect to certain
communities now entitled to enhanced Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
reservation, projects the illegality of protection offered to those not suffering from any lack of
representation in government employment. Even considering proportional representation there is
no reason to continue reservation at least for some of the castes who have made long strides inBhagwat Kumar vs The State Of Bihar on 20 June, 2024

coming to the mainstream. The term backward does not mean that one remains so forever as held in
Paragraph 629 of Indra Sawhney (supra). In the 75 years of independence, the benefits granted to
the various marginalized communities would definitely have resulted in certain communities having
benefited largely and progressed both socially, educationally and economically. This is the
foundation for bringing in the principle of creamy layer and if the exclusion of such progressed
communities, groups, classes and individuals is not being considered, then it would be a fraud on
the power conferred for affirmative action. Not only would merit be compromised but those who
still wallow in backwardness would also stand denied of their right to be uplifted. It is pointed out
that the data from the Caste Survey reveals that four communities have progressed considerably in
the past years and they do not require any more reservation. Dr. Ambedkar's words from Indra
Sawhney (supra), Paragraph 693 was specifically read out.
Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
16. Shri Dinu Kumar, learned Counsel appearing in CWJC No. 18007 of 2023, argued that by the
present enactment, the reservation due to economically weaker sections of 10%, as granted in the
Act of 1991, is completely obliterated. It is pointed out that separate enactments were brought in for
admission to educational institutions and appointment in services, both of which violate the basic
principles of affirmative action.
17. Shri Abhinav Shrivastava, learned Counsel appearing in CWJC No. 17916 of 2023, argues that
the decisions, as referred to by the learned Senior Counsel, speak in the same tone, profess an
identical ideology and declare a like proposition. They eulogize and propound, with a uniform tenor
and spirit, a balance between equality and affirmative action; strikingly the need of the hour. The
State's attempt to overreach and overstep the 50% limit is a clear abuse of the enabling provision
under the Constitution. The fact that the close proximity within which the legislation was brought
out; two days after the caste survey report came, disclose the undue haste and clearly indicates that
there was no deliberation on the new measure adopted. The Preamble of the Act was read over to
again point out that the entire exercise is carried out very Patna High Court CWJC No.16760 of 2023
dt.20-06-2024 casually. Barium Chemicals Ltd.(supra) was reiterated to emphasize the principles
governing the exercise of a power conferred by the Constitution or a Statute, which cannot at all be
on a subjective satisfaction. The present exercise is constitutionally impermissible, especially when
the State argument is anchored on proportional representation. Not every community aspires for a
government job and the proportional representation in any event is beyond the constitutional
framework. Affirmative action has been held to be a recompense for the long deprivation, which
cannot, all the same, compromise merit and efface it totally or even considerably. In a democracy,
the Government propounds the majority will, but a constitutional governance ensures the protection
of minorities. It is pointed out from judicial pronouncements that Judges have often, with some
dismay, spoken of the tendency in this country to clamour for being included in the backward
classes. Disadvantages suffered over the years, is not necessarily the measure employed in
determining backwardness and extraneous considerations, for immediate appeasement, reign
supreme.Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

18. The learned Counsel would also argue on the non- disclosure of the land holding, which is the
basis of an equitable consideration to bring out a more egalitarian society, wherein Patna High
Court CWJC No.16760 of 2023 dt.20-06-2024 the persons who labour on the lands also get a right
over it. Agriculture is one of the major activities and is a very important economic factor, at least,
within the State of Bihar. It is also pointed out that there are many horizontal reservations, like 35%
for females, 2% for grand-children of freedom fighters and 4% for persons with disabilities, which
further reduces the quota for unreserved category.
19. Shri Nirbhay Prashant, learned Counsel appearing in CWJC No. 16882 of 2023, adopted the
arguments of the other counsel. Shri Vikash Kumar, a young lawyer appeared in person and argued
vehemently on the concepts of equality and the attempt to strike a balance by the affirmative action
as provided in Articles 15(4) and 16(4). The right to reservation is not a super fundamental right and
the 50% limit, as imposed by the Hon'ble Supreme Court, arise also from Article 335. Insofar as the
data collection is concerned, the same is argued to be a complete fraud since the Caste Survey shows
only 1.15% of the State population having internet connection whereas 56% of the people in the State
are said to possess smart phones, as revealed in a survey.
20. The learned Advocate General commenced with a profound statement that just as inventions
and research have Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 contributed
significantly to evolution of human society, the unique Caste Survey as carried out by the State of
Bihar is an exercise which would open new vistas and new dimensions redefining the philosophy of
social milieu. It would also tread a new path in achieving the goal of an egalitarian society and in its
wake, of course would be brought forth new challenges which are henceforth unknown. For this very
reason, the learned Advocate General submitted that he would be relying heavily on the decision of
this Court which upheld the exercise of Caste Survey, to substantiate the reservation percentage now
brought in by the State which is exceptional in its own way and cannot be compared to the decisions
of the Hon'ble Supreme Court which dealt with 'Jatt' and 'Maratha' reservations.
21. The significant revelations with respect to the social milieu in this State, discernible from the
details disclosed on the Caste Survey is unparalleled and for that reason alone would be the
foundation of the arguments to substantiate the breach of 50 per cent which even according to the
Hon'ble Supreme Court is not an unimpeachable rule. The ground raised of a hasty decision cannot
be validly put forth against a legislation and the learned counsel for the petitioners have read the
Preamble only to point out certain spelling mistakes. This Patna High Court CWJC No.16760 of
2023 dt.20-06-2024 accusation cannot form the basis of the contention that the present
amendment made to the reservation policy of the State, is motivated on the proportion of the
Backward and Extremely Backward Communities. Constitutional validity of a legislation can be
challenged only on two grounds, one of lack of legislative competence and the other of infraction of
any of the fundamental rights or the provisions of the Constitution. No arguments were addressed
on these two aspects and the petitioners had unnecessarily laboured only on the spelling mistakes in
the Amendment Act and also the concept of proportionality which they believe is solely relied upon,
for the subject enhancement of the reservation percentage. The question of inclusion or exclusion of
a caste is alien to the amendment and also not relevant in the context of the challenge made in the
batch of cases.Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

22. Indra Sawhney (supra) itself holds that 50 per cent is not an inviolable rule. The mere
introduction of Article 16(4B) is not a pointer to the fact that the Constitution has accepted that 50
per cent reservation or that it can never be breached. In fact Article 16(4B) is an instance of breach
and the 50% reservation, as brought in by the Constitution Bench decision, is capable of being
overlooked in exemplary Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 circumstances
as provided in that decision itself. The petitioners challenge to the legislation on grounds of haste, a
Commission not having been constituted or consulted to look into the details of the Caste Survey,
spelling mistakes and the reference to proportionate representation in the Preamble are to be
rejected at the outset as untenable. It is pointed out that in none of the decisions, the Hon'ble
Supreme Court has said that the 50% limit for reservation is an inviolable rule and often it has been
clarified that it is otherwise; capable of being overreached by the State, if there is sufficient cause
shown. Janhit Abhiyan, Jarnail Singh and Dr. Jaishri Laxmanrao Patil (all supra), are in quite
distinct situations from that available in the present case; wherein the details as discernible from the
Caste Survey clearly indicates the requirement for an enhanced reservation.
23. The original Reservation Act has not been challenged and the challenge is only with respect to
the amendment made enhancing the percentage of reservation to each of the marginalized
categories as identified in the enactment. The present litigation is not with respect to inclusion or
exclusion of any caste or community in the reservation net. The reference to the Mandal
Commission and the parameters reckoned are not at all relevant since Mandal Commission was
Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 with respect to identification of backward
communities. The Caste Survey has reckoned the entire population within the State of Bihar and
assessed their social, educational and economic status. In Dr. Jaishri Laxmanrao Patil (supra), the
'Marathas', a new group was included under the backward communities, while under the subject
amendment to the Reservation Act, there is no such inclusion or exclusion and the State continues
with the identified backward classes as has been occasioned in the year 1991. The decision in Dr.
Jaishri Laxmanrao Patil (supra), hence, is not applicable to the facts of the present case. Dr. Jaishri
Laxmanrao Patil (supra) also held; on a reference to the Gaikwad Commission, which was the basis
of the inclusion of 'Marathas', that there was inadequate material to hold that the entire Marathas
were enabled of classification as backward communities under Articles 15(4) and 16(4).
24. Insofar as Janhit Abhiyan (supra) is concerned, there was an economically weaker section
identified who was granted a percentage of reservation; which also makes it inapplicable to the
present case. The learned Advocate General took us through the details of the Caste Survey and
pointed out that it was based on an analysis of the data supplied; which is an empirical objective
data not based on any subjective opinion and Patna High Court CWJC No.16760 of 2023
dt.20-06-2024 collected on a real-time basis, that the present enhancement of percentage in
reservation has been carried out. Despite the reservation granted in the past so many years, the SC,
ST and BC lagged behind by miles. It is pointed out that 98 lakh families, as per the Caste Survey,
still exist at a monthly income of Rs. 6000/- per month. The condition in Bihar is not comparable to
the other States and is below the national average in all parameters of development. There are
schemes launched by the State to uplift the economically weaker sections of society by providing
facilities and also monitory assistance, but all these do not meet the required standard to ensure
upliftment of the marginalized. It is on deep contemplation of the ground realities, immediate stepsBhagwat Kumar vs The State Of Bihar on 20 June, 2024

were taken to make equality a reality and not an abstract concept, by ensuring spread of education
and reasonable distribution of employment opportunities to the marginalized, for which purpose the
impugned exercise has been undertaken. The intention to ensure upliftment of the marginalized
sections is very clear and the analysis of data collected in the Caste Survey justifies the affirmative
action, which is only a revisit of the existing Reservation Act. The interim order in the Maratha case,
as is evident from Dr. Jaishri Laxmanrao Patil v. State of Maharashtra & Anr., (2021) 2 Patna High
Court CWJC No.16760 of 2023 dt.20-06-2024 SCC 785, is pointed out to argue that if the facts were
similar, the State of Bihar would not have any case, but the facts are quite distinct & different;
clearly justifying the enhanced reservation of 65%. The 50% rule, it is reiterated, is not a rule of
uniform and universal application and the numerical bench mark has been breached to achieve the
long-desired need of social capital for the down trodden to empower them and evoke in them an
aspiration to achieve equality. This, according to the learned Advocate General is the surest
immunity against discrimination, especially in the special circumstance existing in the State of
Bihar.
25. The Caste Survey and the report prepared; based on collection of empirical data has not been
challenged whereas in the Maratha case, the reliance on the report of the Gaikwad Commission was
held to be erroneous. While the Maratha case does not support an extraordinary circumstance;
insofar as the State of Bihar is concerned, it is on a totally different set of facts. The Caste Survey
reached almost 12 crore people and the data collected is real time with every family being surveyed
and only a negligible portion of the population not participating. Again, exclusion and inclusion are
not the subject matter of the present case. The confluence of all religions in a federal State; Patna
High Court CWJC No.16760 of 2023 dt.20-06-2024 where the legacy of feudalism continues to
plague ownership of lands conferred by permanent settlements, impedes development.
Backwardness, characterized by mere birth into communities, refuses to die down, despite the
varied and numerous endeavours by the State to bring in social reform. The numerically vast
population and the marginalized majority confronts the State with a grave challenge in its constant
struggle to achieve the goal of an egalitarian society.
26. The State has the plenary sovereign power to legislate, which is not dependent on the
recommendations of a Backward Commission; whether it be at the National or State level. The
enhanced reservation is on the legislative wisdom garnered from the wealth of past experience and
also the immediate & present empirical data collected from the vast population within the State.
There is no reason to bring in standards laid down by other Commissions, including the Mandal
Commission. The objective considerations as would be discernible from the Caste Survey undertook,
marks out the present legislation impugned in the batch of writ petitions, as not only justifiable but
also valid. The learned Advocate General took us through the Caste Survey report and the minute
details of the various communities, as coming out from the said report; Patna High Court CWJC
No.16760 of 2023 dt.20-06-2024 which is stated to be history in the making, though proportionate
representation is not permissible. Understanding proportion will be a relevant measure for
determining adequacy, which has resulted in the increased reservation granted to the backward
communities, who are the majority of the vast population of the State. The parameters of judicial
review as has been laid down by the Hon'ble Supreme Court, was specifically pointed out to urge
that the impugned legislation is not perverse, per se defective or illegal or irrational by any stretch ofBhagwat Kumar vs The State Of Bihar on 20 June, 2024

imagination. It is a sad situation that 15% of the population gets 50% reservation and this alone is
the extraordinary aspect which marks out the situation in the State requiring affirmative action to
take in the extraordinary circumstances. Adequacy does not mean mere numbers and there is more
to it, often invisible and unnoticed, which can only be brought to light by unique measures of social
engineering; as done in the case of the singular Caste Survey. It is on a social test based on the
details collected in the survey, that the legislature formed the opinion, to enhance the percentage of
reservation even beyond the 50% mark to achieve the ultimate aim of totally effacing inequality. The
collective objective opinion formed by the legislature led to the legislation, which is beyond judicial
review. Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
27. The learned Advocate General's arguments were impassioned, inspired with deep introspection
and laced abundantly with rare insights of the social milieu. The Caste Survey and the empirical data
collected therein eloquently cries out for more reservations to the backward including the SCs and
the STs. He summed up that the State has a responsibility to take measures to uplift those who were
deprived for long, left to abject destitution and thus grossly disadvantaged; the landless, the
homeless and the jobless, the undernourished, the downtrodden and the marginalized, which
require drastic steps. Such steps should evoke in them a sense of belonging and enable them to
aspire for better times, better opportunities and better facilities, raising the expectation of adequacy;
in determining which proportionality cannot be wholly and entirely ignored. When 10% reservation
for the unreserved category is considered, it cannot be said that there is breach of the 50% rule by
15%. If at all there is breach, it would only be a mere 5%. Arguing further on the breach being not an
inviolable rule, the learned Advocate General pointed out that the reliance placed by the petitioners
is on the decisions in Indra Sawhney, Janhit Abhiyan, and Dr. Jaishri Laxmanrao Patil (all supra).
All of these, viewed through the constitutional prism and understood in Patna High Court CWJC
No.16760 of 2023 dt.20-06-2024 the ethos of reality; the underlying philosophy of affirmative
action, according to the learned Advocate General, support the present amendment made to the
Reservation Act. It is pointed out that the petitioners have relied only on paragraphs here and there
and a reading of the decisions in its entirety, would clearly show that breach is possible but has to be
substantiated when it is challenged before a Court of law.
28. Shri Y.V.Giri, learned Senior Counsel, in support of the State action, argues that there is no role
for the Preamble if there is no ambiguity in the enactment; as has been held in Maharishi Mahesh
Yogi Vedic Vishwavidyalaya v. State of Madhya Pradesh & Ors.,(2013) 15 SCC 677. Exclusion or
inclusion is not a matter coming within the scope of the subject writ petitions and there is no
mandate that the Backward Commission has to be approached in every circumstance where an
affirmative action is brought out by the State. The Bihar State Backward Commission Act, 1993 and
the functions of the Commission, as delineated therein, were read out along with Paragraph 667 of
Indra Sawhney (supra). Reliance was also placed on the Caste Survey to assert legislative
compulsion and no conflict arising with the constitutional provision. Reliance is placed on Janhit
Abhiyan and Dr. Jaishri Laxmanrao Patil Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
(both supra) to further urge that proportionate representation is one of the relevant factors in
determining reservation.Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

29. In reply, Shri Gopal Sankaranarayanan submits that the entire approach of the State
Government is erroneous; linking adequacy and proportion to breach the 50% limit in reservations.
It is also pointed out that the Caste Survey itself is challenged in the Hon'ble Supreme Court and in
none of the judgments of the Hon'ble Supreme Court, the breach of 50% rule was approved and the
permission was confined to special circumstances as has been read out from Paragraph-810 of Indra
Sawhney (supra), which is not available in the present case. Shri Mrigank Mauli refers to Articles
338 and 338A, to emphasize the significance of a National Commission. It was pointed out from the
details of the Caste Survey that there is adequate representation of the backward communities. Shri
Abhinav Shrivastava points out that adequacy is based on social backwardness and there is no
reference to a far flung or backward area which justifies the breach of 50% limit. In Our Judgment: -
30. The history of reservations in this country is chronicled in the various decisions of the Hon'ble
Supreme Court wherein there was a challenge made to the affirmative Patna High Court CWJC
No.16760 of 2023 dt.20-06-2024 action brought out by the State and the Union Parliament. Before
we refer to the decisions, we have to first notice the provisions in the Constitution, which provides
for such affirmative action. Article 14 speaks of equality before law and Article 15 prohibits
discrimination on grounds of religion, race, caste, sex or place of birth. Article 15 as it originally
stood did not provide for the special provision for advancement of any socially and educationally
backward class of citizens or for the Scheduled Castes and the Scheduled Tribes as was later
introduced by the Constitution (1st Amendment) Act 1951. Article 16 which provided for equality of
opportunity in matters of public employment, at the inception itself, contained clause (4) wherein, it
was provided that nothing in this Article shall prevent the State from making any provision for the
reservation of appointments or posts in favour of any backward class of citizens, which, in the
opinion of the State, is not adequately represented in the services under the State. Article 29
provided for protection of interest of minorities and clause (1) speaks of the right to conserve a
distinct language, script or culture. Clause (2) provides that no citizen shall be denied admission
into any educational institution maintained by the State or receiving aid out of State funds on
grounds only of religion, Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 race, caste,
language or any of them.
31. B. Venkataramana (supra) was a case under Article 16(4) where the reservations in a selection to
the post of District Munsiffs was challenged; brought in by a government order; popularly termed
the 'Communal G.O'. Therein specific number of posts were reserved for various castes, religions
and communities. Looking at clause (4) of Article 16, it was specifically held that there was express
permission to the State to make provisions for reservation of appointments or posts in favour of any
backward class of citizens; which in the opinion of the State is not adequately represented in the
services of the State. Reservation of posts in favour of any backward class, (this term is used in this
judgment alternatively for the entire category of reserved and also as distinguished from SC & ST;
which has to be understood from the context in which the term is used) could not, therefore, be
regarded as unconstitutional. The petitioner was a Brahmin and his ineligibility to be considered for
such reserved posts, it was found, cannot be regarded as one arising on the ground of religion, race
or caste but by reason of the necessity to make reservation for the backward class of citizens.
However, the ineligibility created by the 'Communal G.O' was also by reason of the express
reservation made for Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 categories otherBhagwat Kumar vs The State Of Bihar on 20 June, 2024

than backward class; including Muslims, Christians and non-Brahmin Hindus and Brahmins. The
ineligibility of the petitioner for any of the posts reserved for communities other than Harijans and
Backward Class Hindus could be regarded as founded only on the ground of his being a Brahmin.
This ineligibility created by the 'Communal G.O'; it was held, was not sanctioned by clause (4) of
Article 16 and led to a clear infringement of the fundamental right guaranteed to the petitioner as an
individual citizen under Article 16(1) & (2).
32. Champakam Dorairajan (supra); a case under Article 15, was delivered on the same day and by
the very same Constitution Bench of 5-Judges who decided B. Venkataramana. Therein, the
reservations made to Medical & Engineering Colleges by the State of Madras was under
challenge. The 'Communal G.O' apportioned the seats to students coming from
outside the State; some reserved for discretionary allotment by the State and the
balance apportioned between the four distinct groups of districts. The Government
order brought out after the commencement of the Constitution followed the earlier
'Communal G.O', which apportioned every 14 seats to four distinct groups of districts;
to be filled up from amongst the non-brahmin Hindus, backward Hindus, Brahmins
Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 Harijans, Anglo-Indians &
Indian Christians and Muslims.
33. The learned Judges noticed that while clause (1) of Article-29 of the Constitution of India
protects language, script, culture etc: of a citizen, clause (2) guarantees the fundamental right of an
individual citizen. The right to get admission into an educational institution of the kind mentioned
in clause (2) is a right which an individual citizen has as a citizen and not as a member of any
community or class of citizens. This right could not be denied to a citizen on grounds only of
religion, race, caste, language or any of them. The contention of the State that the provisions of
Article 29 have to be read along with the other Articles in the Constitution and would be superseded
by Article-46; which promotes with special care, the educational and the economic interest of the
weaker sections of the people and in particular of the Scheduled Castes and the Scheduled Tribes
from social injustice and all forms of exploitation, was specifically rejected.
34. It was categorically held that the Directive Principles of State Policy which, by Article 37, are
expressly made unenforceable by a Court, cannot override the provisions found in Part-III. The
provisions under Part-III on the other hand; notwithstanding other provisions, are expressly made
Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 enforceable by appropriate writs, orders
or directions under Article 32. The Chapter of Fundamental Rights was held to be sacrosanct and
not liable to be abridged by any legislative or executive act or order except to the extent provided in
the appropriate Article in Part-III. Directive Principles of State Policy according to the learned
Judges have to conform to and run as subsidiary to the Chapter of Fundamental Rights. Specific
reference was made to clause (4) of Article 16; which, it was observed, was unnecessary, if the
arguments founded on Article- 46 were sound. It was held that clause (4) was inserted in Article 16
which insertion coupled with the omission of a like express provision in Article 29 was very
significant. The distinction in so far as Article 16 dealing with public employment and Article 29 (2)
dealing with admissions to educational institutions maintained or aided by the State wasBhagwat Kumar vs The State Of Bihar on 20 June, 2024

emphasized; juxtaposed with the fact that a provision similar to clause (4) of Article 16 was absent in
Article 29(2). It was held that protection of backward class of citizens would require appointment of
members of backward classes in state-services for which power has been given to the State to
provide for reservation in appointments. Such conferment of power was not obviously considered
necessary in the case of admission into an Patna High Court CWJC No.16760 of 2023
dt.20-06-2024 educational institution and this was held to be the reason for the omission from
Article 29, a clause similar to Clause (4) of Article-16.
35. The First Amendment of the Constitution introduced clause (4) to Article 15 of the Constitution
as a direct consequence of the decision in Champakam Dorairajan (supra). The reservation made of
a total 68% in the Colleges affiliated to the Universities in the State of Mysore was tested against
Article 15(4) in M.R. Balaji (supra) and held to be bad for reason of it being excessive and a fraud on
the Constitution. Many of the arguments made therein, in support and against the challenge, were
addressed before us and we refer to them briefly so as to put in perspective the dicta coming out of
the decision; applicable squarely in the instant case.
36. The contention advanced for the petitioners that the affirmative action was incompetent unless a
Commission was appointed under Article 340 and a copy of its report is placed before the
Parliament; pursuant to which the President alone can make the special provision for reservation
was rejected as misconceived. The Constitution, though contemplated the appointment of a
Commission, it was only for the assistance of the Union and the State Governments, who at Patna
High Court CWJC No.16760 of 2023 dt.20-06-2024 their discretion would implement the
recommendations; which procedure was also held to be not a condition precedent to an action
under Article 15(4). Hence the arguments addressed by the petitioners herein regarding the absence
of a recommendation or report from a Commission as contemplated under the Constitution, cannot
be accepted; to declare bad, the impugned reservation. The argument canvassed, of the mandatory
requirement of a legislation was also negatived on the premise that the State under Article 12
includes the Legislature and the Government; which in the context of the challenge herein is
irrelevant as the impugned action is one by a legislation itself.
37. M.R. Balaji (supra) considering the scope and extent of the expression 'backwardness' under
Article 15 (4), declared that caste cannot be the predominant or sole basis for determination of social
and educational backwardness, since it would be illogical and lead to further perpetuation of an evil
which had to be wiped out. It was also held to be impracticable of application to many groups
existing in the Indian society. Social backwardness primarily would be a result of poverty; which is
also aggravated by caste, making both relevant for determination of this aspect. Along with these,
various factors Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 like occupation, many of
which are perceived as inferior; place of residence, often when the location is rural; makes the
identification of a proper criteria difficult. The intermix of social and economic considerations hence
require elaborate investigation and collection of data, which has to be examined in a rational and
scientific way. The mode adopted of determining educational backwardness, of computing the State
average of student population and classifying those who fall below it as backward and those who are
less than half of average, to be most backward, was held to be flawed, since it eventually included
those groups who were slightly above or below the average, even in the same category.Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

38. Examining the extent of the special provision under Article 15(4), the State's contention that it
could be without limitation was rejected. The Constitution Bench held that Article 15(4) is in the
nature of an exception and if it is capable of completely excluding the rest of the society, then it
would be extremely unreasonable and would be an infringement of the fundamental rights of those
citizens constituting the rest of society. A total exclusion of qualified and competent students from
the Universities, without any consideration of merit, on grounds only of reservation of entire seats,
was held to be Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 against the national
interest. Emphasizing the duty of the State to proceed with affirmative action in an objective and
rational manner; while advocating reasonable and even generous steps in advancement of the
weaker sections, it was cautioned that the State has to keep in mind and not ignore the requirements
of the community at large.
39. The reservation laid down of 68% was struck down and a bench mark of 50% was prescribed;
less than which was held to be reasonable; with a caveat that how much less would depend on the
relevant prevailing circumstances. It was categorically opined that "what is true in regard to Article
15(4) is equally true in regard to Article 16(4)" (sic), thus deprecating any excessive, unreasonable
and extravagant reservation under both provisions since it would create wide-spread dissatisfaction
and materially affect efficiency.
40. Another Constitution Bench by majority in T. Devadasan (supra) approved the ratio in
M.R.Balaji (supra), ' ... that reservation of more than half the vacancies is per se destructive of the
provisions of Art. 15(1) which is to the effect that the State shall not discriminate against any citizen
on grounds of religion, race, caste, sex, place of birth or any of them' (sic). It was found that equal
protection of laws and Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 equality before
law, as provided in Article 14 means 'equality among equals'(sic). It was reiterated that clause (4) of
Article 16 is a proviso or an exception to clause (2). The promotions assailed, which exceeded the
50% rule of reservation; justified on the ground of 'carry forward vacancies', was declared invalid
relying on the 50% rule propounded in M.R.Balaji. The dissenting opinion; to the majority, found
the 50% rule in M.R.Balaji to be a mere general observation intended to be only a workable guide
and not an inflexible rule of law and held that Article 16(4) was not an exception to Article 16(1), but
an emphatic way of stating the principle inherent in the main provision. It was also held that the
doctrine of destruction of fundamental right depends upon the entire cadre strength and the
percentage reserved, out of that strength.
41. The dissenting interpretation of Article 16(4) was accepted by the majority in N.M. Thomas
(supra) and also in Indra Sawhney (supra); larger Benches, respectively of seven and nine Judges. It
was held that Article 16 does permit reasonable classification for ensuring attainment of equality of
opportunity; the assurance of which is possible, only if unequally situated persons are treated
unequally and not equally, in certain situations. Not doing so, according to the majority judgment in
Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 Indra Sawhney (supra), 'would
perpetuate and accentuate inequality'. Article 16(1) being a facet of Article 14; implicitly permits
classification and the minute that is recognized, clause (4) becomes an instance of classification
inherent in clause (1) and the theory of it being an exception becomes untenable. This was the only
deviation from the dicta in M.R. Balaji (supra). In N.M. Thomas two out of the seven judges aloneBhagwat Kumar vs The State Of Bihar on 20 June, 2024

expressed an opinion on the 50% rule in M.R.Balaji; that it is more a rule of caution and not a hard
and fast one to be reduced to a mathematical formula. The majority hence affirmed the 50% limit on
reservations making it the dictum of the seven judge bench.
42. Indra Sawhney (supra) considered the question of the extent to which reservations can be made
and the efficacy of the 50% rule as propounded in M.R. Balaji (supra). M.R.Balaji was found to have
negatived the plea that the reservation as per Article 15(4) is limitless, finding it to be a 'special
provision' requiring it to be applied within reasonable limits. Devadasan (supra) applied it as
declared law in the case arising under Article 16(4) to strike down the carry forward rule. There was
no clear declaration coming out of N.M. Thomas (supra); two learned judges in N.M.Thomas,
having termed it a mere rule of Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 caution
while two others passingly referred to it, without expressing a positive opinion. This led to the
argument that N.M. Thomas overruled M.R Balaji. On whether the 50% rule stood overruled, a
two-judge bench, in K.C Vasanth Kumar v. State of Karnataka 1985 Supp SCC 714, differed. N.M
Thomas, on this point, was argued to be an obiter; especially when one of the two judges who
expressed a contrary opinion; affirmed it in Akhil Bharatiya Soshit Karmchari Sangh v. Union of
India (1981) 1 SCC 246.
43. Indra Sawhney (supra) categorically held that '... clause (4) speaks of adequate representation
and not proportionate representation.' (sic-para 807). One cannot be read as the other, and the
latter was accepted only in Articles 330 & 332. It was held so in para 807 to 809, 811, 813 & 814:
807. We must, however, point out that clause (4) speaks of adequate representation
and not proportionate representation. Adequate representation cannot be read as
proportionate representation. Principle of proportionate representation is accepted
only in Articles 330 and 332 of the Constitution and that too for a limited period.
These articles speak of reservation of seats in Lok Sabha and the State legislatures in
favour of Scheduled Tribes and Scheduled Castes proportionate to their population,
but they are only temporary and special provisions. It is therefore not possible to
accept the theory of proportionate representation though the proportion of
population of backward classes to the total population would certainly be relevant.
Just as every power must be exercised reasonably and fairly, the power conferred by
clause (4) of Article 16 should also be exercised in a fair Patna High Court CWJC
No.16760 of 2023 dt.20-06-2024 manner and within reasonable limits -- and what is
more reasonable than to say that reservation under clause (4) shall not exceed 50% of
the appointments or posts, barring certain extraordinary situations as explained
hereinafter. From this point of view, the 27% reservation provided by the impugned
Memorandums in favour of backward classes is well within the reasonable limits.
Together with reservation in favour of Scheduled Castes and Scheduled Tribes, it comes to a total of
49.5%. In this connection, reference may be had to the Full Bench decision of the Andhra Pradesh
High Court in V. Narayana Rao v. State of A.P. [AIR 1987 AP 53 : 1987 Lab IC 152 : (1986) 2 Andh
LT 258] , striking down the enhancement of reservation from 25% to 44% for OBCs. The said
enhancement had the effect of taking the total reservation under Article 16(4) to 65%.Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

808. It needs no emphasis to say that the principal aim of Articles 14 and 16 is equality and equality
of opportunity and that clause (4) of Article 16 is but a means of achieving the very same objective.
Clause (4) is a special provision -- though not an exception to clause (1). Both the provisions have to
be harmonised keeping in mind the fact that both are but the re-statements of the principle of
equality enshrined in Article 14. The provision under Article 16(4) -- conceived in the interest of
certain sections of society -- should be balanced against the guarantee of equality enshrined in
clause (1) of Article 16 which is a guarantee held out to every citizen and to the entire society. It is
relevant to point out that Dr Ambedkar himself contemplated reservation being "confined to a
minority of seats" (See his speech in Constituent Assembly, set out in para 693). No other member
of the Constituent Assembly suggested otherwise. It is, thus, clear that reservation of a majority of
seats was never envisaged by the Founding Fathers. Nor are we satisfied that the present context
requires us to depart from that concept.
809. From the above discussion, the irresistible conclusion that follows is that the reservations
contemplated in clause (4) of Article 16 should not exceed 50%.
xxx xxx xxx
811. In this connection it is well to remember that the reservations under Article 16(4) do not
operate like a Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 communal reservation. It
may well happen that some members belonging to, say, Scheduled Castes get selected in the open
competition field on the basis of their own merit; they will not be counted against the quota reserved
for Scheduled Castes; they will be treated as open competition candidates.
xxx xxx xxx
813. It is, however, made clear that the rule of 50% shall be applicable only to reservations proper;
they shall not be -- indeed cannot be -- applicable to exemptions, concessions or relaxations, if any,
provided to 'Backward Class of Citizens' under Article 16(4).
814. The next aspect of this question is whether a year should be taken as the unit or the total
strength of the cadre, for the purpose of applying the 50% rule. Balaji [1963 Supp 1 SCR 439 : AIR
1963 SC 649] does not deal with this aspect but Devadasan [T. Devadasan v. Union of India, (1964)
4 SCR 680 : AIR 1964 SC 179 :
(1965) 2 LLJ 560] (majority opinion) does. Mudholkar, J speaking for the majority
says : (SCR pp. 694-95) "We would like to emphasise that the guarantee contained in
Article 16(1) is for ensuring equality of opportunity for all citizens relating to
employment, and to appointments to any office under the State. This means that on
every occasion for recruitment the State should see that all citizens are treated
equally. The guarantee is to each individual citizen and, therefore, every citizen who
is seeking employment or appointment to an office under the State is entitled to be
afforded an opportunity for seeking such employment or appointment whenever it is
intended to be filled. In order to effectuate the guarantee each year of recruitmentBhagwat Kumar vs The State Of Bihar on 20 June, 2024

will have to be considered by itself and the reservation for backward communities
should not be so excessive as to create a monopoly or to disturb unduly the legitimate
claims of other communities."
On the other hand is the approach adopted by Ray, CJ in Thomas [(1976) 2 SCC 310, 380 : 1976 SCC
(L&S) 227 : (1976) 1 SCR 906] . While not disputing the correctness of the 50% rule he seems to
apply it to the entire service as such. In our opinion, the approach adopted by Ray, CJ would not be
consistent with Article
16. True it is that the backward classes, who are victims of historical social injustice, which has not
ceased fully as yet, are not properly represented in the services under Patna High Court CWJC
No.16760 of 2023 dt.20-06-2024 the State but it may not be possible to redress this imbalance in
one go i.e., in a year or two. The position can be better explained by taking an illustration. Take a
unit/service/cadre comprising 1000 posts. The reservation in favour of Scheduled Tribes, Scheduled
Castes and Other Backward Classes is 50% which means that out of the 1000 posts 500 must be
held by the members of these classes i.e., 270 by Other Backward Classes, 150 by Scheduled Castes
and 80 by Scheduled Tribes. At a given point of time, let us say, the number of members of OBCs in
the unit/service/category is only 50, a short fall of 220. Similarly, the number of members of
Scheduled Castes and Scheduled Tribes is only 20 and 5 respectively, shortfall of 130 and 75. If the
entire service/cadre is taken as a unit and the backlog is sought to be made up, then the open
competition channel has to be choked altogether for a number of years until the number of members
of all backward classes reaches 500 i.e., till the quota meant for each of them is filled up. This may
take quite a number of years because the number vacancies arising each year are not many.
Meanwhile, the members of open competition category would become age barred and ineligible.
Equality of opportunity in their case would become a mere mirage. It must be remembered that the
equality of opportunity guaranteed by clause (1) is to each individual citizen of the country while
clause (4) contemplates special provision being made in favour of socially disadvantaged classes.
Both must be balanced against each other. Neither should be allowed to eclipse the other. For the
above reason, we hold that for the purpose of applying the rule of 50% a year should be taken as the
unit and not the entire strength of the cadre, service or the unit, as the case may be.
[underlining by us for emphasis]
44. Indra Sawhney a nine-judge Bench thus gave further judicial imprimatur to the 50% rule. The
nine-judge Bench also held Devadasan to be correctly decided and declared that a carry forward
rule, in whatever manner it is operated, Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
shall also not result in breach of the 50% rule. This alone; the 50% rule in carry forward vacancies,
was rendered inapplicable by the constitutional amendment, incorporating clause (4-B) in Article
16. It dealt with only the carry forward rule, applicable both in direct recruitment and promotions
but left untouched the 50% rule otherwise; as held in R.K Sabharwal v. State of Punjab (1995) 2 SCC
745. Only when there is a carry forward could the reservation exceed 50%; that too the limit being
exceeded only by reason of the carry forward of the unfilled vacancies in the previous years, in which
previous years again the reservation was applied following that rule. This was another facet of
equality; fostering enough opportunities to those categories who would not have had enoughBhagwat Kumar vs The State Of Bihar on 20 June, 2024

qualified candidates amongst themselves for reason only of their backwardness.
45. M. Nagaraj v. Union of India reported in (2006) 8 SCC 212 was concerned with the 77th
Amendment Act, 1995 inserting Article 16(4-A) enabling accelerated seniority to the roster point
promotees and the Constitution (85 th Amendment) Act, 2001, providing accelerated promotion
with consequential seniority. Both these were challenged as unconstitutional and violative of the
basic structure of the Constitution. Relying on the majority opinion in Minerva Mills Patna High
Court CWJC No.16760 of 2023 dt.20-06-2024 v. Union of India reported in 1983 SCC 625; the
observation that Articles 14 and 19 are not fanciful rights and are elementary rights for functioning
of democracy, the principle emerging was found to be that equality is the essence of democracy and
accordingly a basic feature of the Constitution. Reservation, as is used in Article 16(4); which word
was (and still is) absent in Article 15(4) was considered in the context of Article 335 of the
Constitution providing relaxation of the standards of evaluation. Reservation as a subject of Article
16(4) was held to be different from the word 'reservation' as a general concept. The concept of
equality of opportunity in public employment concerns an individual; both belonging to the general
category or the backward classes and the conflicting claims that arise under Article 16(1) has to be
balanced with the preferential treatment given to a backward class under Article 16(4). The
reasonable balance, thus must be struck between claims of backward classes and claims of other
employees as well as the requirement of efficiency of administration.
46. In the matter of application of the basic structure, the twin test, namely the width test and the
test of identity had to be satisfied. In applying the width test, the boundaries were held to be (i) the
ceiling limit of 50% Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 (quantitative
limitation); (ii) principle of creamy layer (qualitative exclusion); (iii) the compelling reasons of
backward class & inadequacy of representation; and (iv) the overall administrative efficiency; which
principles are not to be obliterated or sacrificed completely at the altar of reparations. On applying
the test of identity, it was held that there is no alteration in the existing structure of the equality code
comprising of Articles 14, 15 & 16. The limitations of equity justice and efficiency survive the
impugned amendments; which incorporated clause(4-A) & (4-B) in Article 16. The controversy as to
whether the Article 16(4) was an exception to Article 16(1) was settled in Indra Sawhney which held
that both Article 16(1) and (4) are re-statement of the principles of equality under Article 14; the
former being individual specific and the later enabling and permitting a positive discrimination in
favour of a class which is characterized by its 'backwardness' and 'inadequacy of representation'.
Backwardness had to be based on the objective factors while inadequacy has to factually exist.
47. In fact, M. Nagaraj in paragraph 49 held so: -
49. Reservation is necessary for transcending caste and not for perpetuating it.
Reservation has to be used in a limited sense otherwise it will perpetuate casteism in
the country. Reservation is underwritten by a special justification. Equality in Article
16(1) is individual-specific whereas reservation in Article 16(4) and Article 16(4-A) is
enabling. The discretion of the State is, however, subject to Patna High Court CWJC
No.16760 of 2023 dt.20-06-2024 the existence of "backwardness" and "inadequacy
of representation" in public employment. Backwardness has to be based on objectiveBhagwat Kumar vs The State Of Bihar on 20 June, 2024

factors whereas inadequacy has to factually exist. This is where judicial review comes
in.
However, whether reservation in a given case is desirable or not, as a policy, is not for us to decide as
long as the parameters mentioned in Articles 16(4) and 16(4-A) are maintained. As stated above,
equity, justice and merit (Article
335)/efficiency are variables which can only be identified and measured by the State. Therefore, in
each case, a contextual case has to be made out depending upon different circumstances which may
exist State wise.
48. Referring to M. R. Balaji, N. M. Thomas and Indra Sawhney (all supra), it was held that the 9
Judge Bench in Indra Sawhney held that Article 16(4) speaks of adequate representation and not
proportionate representation, although proportion of population of the backward classes to the total
population would certainly be relevant. Balancing equality of opportunity available under Article
16(1) for each individual citizen, with the special provision under Article 16(4) for the socially
disadvantaged classes, the majority opinion of the 50% rule to be applied to each year in Indra
Sawhney was re- affirmed finding that equality clause and the special provision should be balanced
and neither allowed to eclipse the other.
49. Article 16(4-A) was held to be inspired by the observations in Indra Sawhney that in order to
avoid lumping of OBCs, SCs and STs which would enable the OBCs to take away all the vacancies
leaving STs and SCs high and dry. The State Patna High Court CWJC No.16760 of 2023
dt.20-06-2024 concerned was entitled to categorize and sub-classify SCs/STs on the one hand,
vis-a-vis OBCs on the other. While Indra Sawhney protected equality with a rule of 50%, balancing
the rights of the general category vis-a-vis the rights of backward class enbloc Article 16(4-A)
ensured that not only OBCs but also SCs and STs would be enabled the preferential treatment
available under Article 16(4). The sub-classification in favour of SCs and STs within the egalitarian
equality enabled by that clause was held to be constitutionally valid.
50. On the 50% limit, M. Nagaraj held so in paragraph 122, which is extracted below: -
122. We reiterate that the ceiling limit of 50%, the concept of creamy layer and the
compelling reasons, namely backward class, inadequacy of representation and over
all administrative efficiency are all constitutional requirements without which
structure of equality of opportunity in Article 16 would collapse.
51. Union of India v. Rakesh Kumar & Others reported in (2010) 4 SCC 50 and K Krishna Murthy v.
Union of India reported in (2010) 7 SCC 202 were concerned with the reservations in local
self-government institutions & bodies. Both these decisions held that barriers to political
participation is not of the same character; as barriers that limit access to education and
employment, thus attempting a comparison between the Patna High Court CWJC No.16760 of 2023
dt.20-06-2024 constitutional provisions at Article 243-D and 243-T on the one hand and Article
15(4) and 16(4) on the other. Rakesh Kumar (supra) held Article 243-D to be a distinct andBhagwat Kumar vs The State Of Bihar on 20 June, 2024

independent constitution basis for reservation in Panchayati Raj Institutions, which cannot be
readily compared with affirmative action measures enabled by Article 15(4) and 16(4) of the
Constitution. It was found that Indra Sawhney though declared an upper limit of 50% for
reservations in public employment, all the same the said decision did recognize the need for
exceptional treatment in special circumstances. The said circumstances were laid down in
paragraph 810 of Indra Sawhney, which was emphasized by the State before us too; which we will
refer to a little later.
52. Continuing the narration from Rakesh Kumar; it was held that under Articles 15(4) and 16(4),
the reservation of seats in favour of socially and educationally backward classes (SEBC, being the
all-inclusive deprived classes) is '... ordinarily done on the basis of proportionate representation and
an upper ceiling of 50% allows for considerable flexibility in distributing the benefits of higher
education and public employment among a wide range of intended beneficiaries such as ...'
(sic-para-45) the SC, ST, women and OBC. An upper ceiling limit of 50% allows for considerable
flexibility in Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 distributing the benefits of
higher education and public employment among a wide range of extended beneficiaries only enables
proportionate aspects to be considered within the limit of 50%. This was distinguished from the
reservations in Panchayats, in scheduled areas pointing out the inherent distinction, between, the
nature of benefits that accrue from access to education and employment, on the one hand, and
political participation, on the other. "While access to higher education and public employment
increases the likelihood of gradual socio-economic empowerment of the individual beneficiaries;
involvement in local self-government is intended as a more immediate measure of protection for the
individual as well as the community he or she belongs to." (sic para 45). The reservation provided
for half of the citizens in Panchayats located in scheduled areas, in favour of SCs was held to be a
measure of compensatory discrimination which goes beyond the ordinary standards of adequate
representation; which sanctions proportionate representation and even goes beyond that.
53. The concept of adequate representation comes into play when it is found that a particular
community is under- represented in a certain domain and a specific threshold is provided in order
to ensure that a beneficiary group is enabled to Patna High Court CWJC No.16760 of 2023
dt.20-06-2024 be adequately represented with the passage of time. It was held that in instances
where the Constitution does not specify the quantum of reservations, the idea of proportionate
reservation is the rule of thumb.
54. Immediately, we have to notice that while Article 243-D and 243-T refers to proportionate
representation, Article 16(4) specifically speaks of adequate representation in the services under the
State. We will have to notice that though Article 15(4) does not specify adequacy, the provision is
akin to that in clause (4) of Article 16. K Krishna Murthy (supra) also held that the principles
evolved for conferring reservation benefits under Articles 15(4) and 16(4) cannot be mechanically
applied in the context of reservation enabled by Article 243-D and 243-T.
55. Jarnail Singh & Others v. Lachhmi Narain Gupta reported in (2018) 10 SCC 396 refused to refer
M Nagaraj (supra) to a larger bench. But the conclusion in M. Nagaraj that the State has to collect
quantifiable data showing backwardness of the Scheduled Caste and Scheduled Tribe was held to beBhagwat Kumar vs The State Of Bihar on 20 June, 2024

contrary to the nine-Judge Bench in Indra Sawhney. The five judge Bench in Jarnail Singh while
refusing to refer for reconsideration the decision in M.Nagaraj quoted from the Patna High Court
CWJC No.16760 of 2023 dt.20-06-2024 decision the following paragraphs, with approval:
19. The Court then concluded as follows :
(Nagaraj case [M. Nagaraj v. Union of India, (2006) 8 SCC 212 : (2007) 1 SCC (L&S)
1013] , SCC pp. 278-79, paras 121-24) "121. The impugned constitutional
amendments by which Articles 16(4-A) and 16(4-B) have been inserted flow from
Article 16(4). They do not alter the structure of Article 16(4). They retain the
controlling factors or the compelling reasons, namely, backwardness and inadequacy
of representation which enables the States to provide for reservation keeping in mind
the overall efficiency of the State administration under Article 335. These impugned
amendments are confined only to SCs and STs. They do not obliterate any of the
constitutional requirements, namely, ceiling limit of 50% (quantitative limitation),
the concept of creamy layer (qualitative exclusion), the subclassification between
OBCs on one hand and SCs and STs on the other hand as held in Indra Sawhney
[Indra Sawhney v. Union of India, 1992 Supp (3) SCC 217 :
1992 SCC (L&S) Supp 1] , the concept of post-based roster with inbuilt concept of
replacement as held in R.K. Sabharwal [R.K. Sabharwal v. State of Punjab, (1995) 2
SCC 745 : 1995 SCC (L&S) 548]
122. We reiterate that the ceiling limit of 50%, the concept of creamy layer and the
compelling reasons, namely, backwardness, inadequacy of representation and overall
administrative efficiency are all constitutional requirements without which the
structure of equality of opportunity in Article 16 would collapse.
123. However, in this case, as stated above, the main issue concerns the "extent of
reservation". In this regard the State concerned will have to show in Patna High
Court CWJC No.16760 of 2023 dt.20-06-2024 each case the existence of the
compelling reasons, namely, backwardness, inadequacy of representation and overall
administrative efficiency before making provision for reservation. As stated above,
the impugned provision is an enabling provision. The State is not bound to make
reservation for SCs/STs in matters of promotions.
However, if they wish to exercise their discretion and make such provision, the State has to collect
quantifiable data showing backwardness of the class and inadequacy of representation of that class
in public employment in addition to compliance with Article 335. It is made clear that even if the
State has compelling reasons, as stated above, the State will have to see that its reservation provision
does not lead to excessiveness so as to breach the ceiling limit of 50% or obliterate the creamy layer
or extend the reservation indefinitely.Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

124. Subject to the above, we uphold the constitutional validity of the Constitution (Seventy- seventh
Amendment) Act, 1995; the Constitution (Eighty-first Amendment) Act, 2000; the Constitution
(Eighty-second Amendment) Act, 2000 and the Constitution (Eighty-fifth Amendment) Act, 2001."
[underlining by us for emphasis] [paragraph 122 in the above extract already quoted in para 50
above]
56. Chebrolu Leela Prasad Rao (supra) was concerned with an office memorandum issued by the
State of Andhra Pradesh providing 100% reservation to the Scheduled Tribe candidates for the post
of teachers in the schools of scheduled areas within the State. Inter alia considering the Patna High
Court CWJC No.16760 of 2023 dt.20-06-2024 question whether 100% reservation is permissible
under the Constitution, in paragraph 109, Indra Sawhney (supra) and paragraph 807 was referred,
to hold that reservation under Article 16(4) is not a proportionate representation but an adequate
one. The government order providing for 100% reservation was held to be not permissible under the
Constitution; the outer limit being 50% as specified in Indra Sawhney.
57. Jaishri Laxmanrao Patil (supra) again considering the extent to which reservations are
permissible, reiterated and reaffirmed the maximum upper limit of 50% as laid down in Indra
Sawhney and held it to be binding under Article 141, which had to be implemented. A reference
sought to a larger bench was declined by the five-Judge Bench. The Commission, whose report was
subject matter of the consideration was found to have completely misread the ratio of a number of
Constitution Bench decisions, when it took the view that, the ceiling of 50% can be breached merely
on the basis of quantifiable data. We specifically extract paragraph 10 of the aforesaid decision: -
10. A careful reading of the judgments in Indra Sawhney v. Union of India [Indra
Sawhney v. Union of India, 1992 Supp (3) SCC 217 : 1992 SCC (L&S) Supp 1] ,
clarifies that seven out of nine Judges concurred that Patna High Court CWJC
No.16760 of 2023 dt.20-06-2024 there exists a quantitative limit on
reservation--spelt out at 50%. In the opinion of four Judges, therefore, per the
judgment of B.P. Jeevan Reddy, J., this limit could be exceeded under extraordinary
circumstances and in conditions for which separate justification has to be
forthcoming by the State or the agency concerned.
However, there is unanimity in the conclusion by all seven Judges that an outer limit for reservation
should be 50%. Undoubtedly, the other two Judges, Ratnavel Pandian and P.B. Sawant, JJ.
indicated that there is no general rule of 50% limit on reservation. In these circumstances, given the
general common agreement about the existence of an outer limit i.e. 50%, the petitioner's argument
about the incoherence or uncertainty about the existence of the rule or that there were contrary
observations with respect to absence of any ceiling limit in other judgments (the dissenting
judgments of K. Subba Rao, in T. Devadasan v. Union of India [T. Devadasan v. Union of India,
(1964) 4 SCR 680 : AIR 1964 SC 179] , the judgments of S.M. Fazal Ali and Krishna Iyer, JJ. in State
of Kerala v. N.M. Thomas [State of Kerala v. N.M. Thomas, (1976) 2 SCC 310 : 1976 SCC (L&S) 227]
and the judgment of Chinnappa Reddy, J. in K.C. Vasanth Kumar v. State of Karnataka [K.C.
Vasanth Kumar v. State of Karnataka, 1985 Supp SCC 714 : 1985 Supp (1) SCR 352] ) is not an
argument compelling a review or reconsideration of Indra Sawhney [Indra Sawhney v. Union ofBhagwat Kumar vs The State Of Bihar on 20 June, 2024

India, 1992 Supp (3) SCC 217 : 1992 SCC (L&S) Supp 1] rule.
58. It has been argued by the learned Advocate General, that the issue of whether the Marathas can
be included or not is not relevant to the instant case. Suffice it to notice that the reservation of 12%
and 30% conferred on the Maratha community in addition to the 50% social reservation was held to
Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 be not covered by any exceptional
circumstances, as contemplated by the Constitution Bench in Indra Sawhney's case; which was a
unanimous declaration of the 5 Judge Bench.
59. Jaishri Laxmanrao Patil (supra) also held that Indra Sawhney is equally applicable to Article 15
(4) and we extract hereunder paragraphs 13 & 14:-
13. So far as the argument that Indra Sawhney [Indra Sawhney v. Union of India,
1992 Supp (3) SCC 217 : 1992 SCC (L&S) Supp 1] was concerned only with
reservations under Article 16(4) is concerned, this Court is inclined to accept the
submissions of the petitioner. The painstaking reasoning in various judgments, in
Indra Sawhney [Indra Sawhney v. Union of India, 1992 Supp (3) SCC 217 : 1992 SCC
(L&S) Supp 1] , including the judgments of Pandian and Sawant, JJ. would show that
almost all the previous precedents on both Articles 15(4) and 16(4) were considered
[M.R. Balaji v. State of Mysore, 1963 Supp (1) SCR 439 : AIR 1963 SC 649; P.
Rajendran v. State of Madras, (1968) 2 SCR 786 : AIR 1968 SC 1012 [Article 15(4)]; A.
Peeriakaruppan v. State of T.N., (1971) 1 SCC 38 [Article 15(4)]; State of A.P. v. U.S.V.
Balram, (1972) 1 SCC 660 [Article 15(4)]; T. Devadasan v. Union of India, (1964) 4
SCR 680 : AIR 1964 SC 179; State of U.P. v. Pradip Tandon, (1975) 1 SCC 267; Janki
Prasad Parimoo v. State of J&K, (1973) 1 SCC 420 : 1973 SCC (L&S) 217; State of
Kerala v. N.M. Thomas, (1976) 2 SCC 310 : 1976 SCC (L&S) 227 [Article 16(4)] & K.C.
Vasanth Kumar v. State of Karnataka, 1985 Supp SCC 714 : 1985 Supp (1) SCR 352
[Article 15(4)].] .
14. The tenor of all the judgments shows the anxiety of this Court to decisively rule on the subject of
reservations under the Constitution -- in regard to backward classes and socially and educationally
backward classes. This is also evident from the history of Article 15(4) which was noticed and the
phraseology adopted (socially and educationally backward classes) which was held to be wider than
"backward classes" though the later expression pointed to social backwardness. Such Patna High
Court CWJC No.16760 of 2023 dt.20-06-2024 conclusions cannot be brushed aside by sweeping
submission pointing to the context of the adjudication in Indra Sawhney [Indra Sawhney v. Union of
India, 1992 Supp (3) SCC 217 : 1992 SCC (L&S) Supp 1] .
60. The decisions we have dealt with as referred at the Bar, are consistent in upholding the principle
propounded by M.R. Balaji (supra) that reservations which is a special provision for the
advancement of the weaker sections of society, would require the State, when making such
affirmative action, to approach its task objectively and in a rational manner. The special provision in
Article 15(4) which was found to be akin to that in Article 16(4) should be within reasonable limits
and should be less than 50% was consistently upheld and affirmed. The only departure from theBhagwat Kumar vs The State Of Bihar on 20 June, 2024

principles enunciated in M. R. Balaji has been insofar as finding Article 16(4) to be not an exception;
but one in affirmation of the equality clause under Article 16(1). This does not digress from the rule
that reservation, unless it is with respect to carry-forward vacancies, has to be confined to 50%
which has to be based on adequate representation; proportionate representation being applicable
only insofar as the reservation percentage applicable to the various groups coming within the
backward classes, i.e. OBCs, MBCs, SCs and STs. It is with this principle in mind; especially Patna
High Court CWJC No.16760 of 2023 dt.20-06-2024 the emphasis on the concept of adequate
representation being the relevant consideration, insofar as clause (4) under both Article 15 and 16
are concerned, we look at the facts as pointed out from the caste survey; a copy of which has been
placed before us.
61. The details, as seen from the caste survey pointed out by the learned Advocate General is more
insofar as the proportionate ratio of the backward classes to the total population of the State. The
benefits that have accrued to the backward castes, looking at the figures, in the perspective of
proportionality, we cannot but say, are meager and it is far from the goal of egalitarian society. We
have to emphasize that in the present case, we are not concerned with the various schemes and
benefits which would be conferred on the backward classes so as to achieve the goal of equality, both
socially and economically. We are, in the present case, only concerned with the enhancement of
reservation beyond the 50% limit, invoking the power under clause (4) of both Article 15 and 16; in
admissions to educational institutions and appointments to public employment.
62. Jaishri Laxmanrao Patil (supra) referred to M.R. Balaji in which it was held that "... Courts often
consider Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 the substance of the matter
which has to be examined and not its form, and in ascertaining the substance of the matter, the
appearance or the cloak, or the veil of the executive action is carefully scrutinised ..." (sic-para 502).
Barium Chemicals Ltd was relied on to find that though the formation of opinion is subjective, the
existence of the circumstances relevant to the inference as the sine qua non for action must be
demonstrable. Holding that the opinion formed with respect to grant of reservation is not beyond
judicial scrutiny altogether, one of the parameters of scrutiny of a Commission's report was stated to
be whether on the basis of the data and materials available; the conclusions arrived at are justified.
63. We would now look at the Caste Survey report relied on by the State to project inadequate
representation of the various backward castes and the general category people, for which we extract
the following columns from the Caste Survey: -
S Category Total No. of Persons working in Government No. Persons Sector Figures
Percentage 1 General Category 2,01,09,207 6,41,281 3.19 2 Backward Category
3,54,63,936 6,21,481 1.75 3 Extremely Backward 4,70,80,514 4,61,725 0.98 Class 4
Scheduled Castes 2,56,89,820 2,91,004 1.13 5 Scheduled Tribes 21,99,361 30,164 1.37
6 Other Reported Caste 1,82,472 3,715 2.04 Total 13,07,25,310 20,49,370 1.57 Patna
High Court CWJC No.16760 of 2023 dt.20-06-2024
64. Only 1.57% of the total population is employed under the Government and when we look at the
proportion of the employees in each of the categories, as compared to the total population of eachBhagwat Kumar vs The State Of Bihar on 20 June, 2024

such category, definitely the open category has an edge with 3.19%. However, when we compare the
ratio of representation of the backward classes in government employment, which has to be
computed on the total number of government employees, we find the backward classes to be
adequately represented. The Other Backward Classes have a presence of 6,21,481 out of a total of
20,49,370 government employees; which makes their representation at 30.32%. Insofar as the
extremely backward community, the percentage of representation is 22.53%, the SCs 14.19% and
STs 1.47%. The backward classes together occupy 14,04,374 posts out of a total 20,49,370
government employees which is a whooping 68.52% of the total employees, which leaves the
un-reserved category with 31.48% of the total posts in government employment. We perfectly realize
that the percentage of the backward communities in government employment, is not sourced solely
through appointments by virtue of reservation. There definitely would be appointments made from
meritorious candidates. Be that as it may, the fact remains that backward communities are Patna
High Court CWJC No.16760 of 2023 dt.20-06-2024 adequately represented in public employment,
by virtue of reservation and also merit; which is an indication of one or other caste or community
having reaped the benefits of reservation and the various beneficial welfare schemes implemented
by the State; in achieving an element of social capital. There is no requirement for an enhancement
of reservations, as adequate representation now exists and there is no valid ground for breach of
50% rule; which in any way is not permissible.
65. In fact, the State should introspect on the reservation percentage within the 50% limit as
conceded to the various categories which could be on the basis of proportionate representation
within the reservation categories; which is also to say that the 'creamy layer' should be excluded. We
say that as a mere observation and not a positive direction, but, however, cannot find a way to
uphold the reservation percentage beyond the 50% limit, as has been brought in by the State. In
revisiting the percentage of reservation, the State should look into and objectively analyze as to
which of the castes or communities within the OBC & EBC have more representation and which of
them are more likely to be appointed on merit. This would give an indication of which of the casts or
communities have in the past years reaped the benefits of the affirmative action and the Patna High
Court CWJC No.16760 of 2023 dt.20-06-2024 beneficial schemes implemented for the upliftment
of the poor and the marginalized. This inevitably takes us to the inference that exclusion and
inclusion of castes or communities on the basis of the development or the lack of it, in the past
years, is an inextricably linked relevant consideration while enhancing the reservation percentage.
But still the law is clear that even that would not permit breach or overreach of the 50% limit.
66. The following extract is made from the category wise educational data, also found in the Caste
Survey report specifically pointed out by the learned Advocate General. Patna High Court CWJC
No.16760 of 2023 dt.20-06-2024 The above table only indicates the student population in each of
the categories; general and backward and the percentage of students studying in the various stages
from primary to graduation (professional and otherwise) as also post-graduation, Doctorate/CA and
others. The summary of educational data shows 100% as distributed between the various stages of
education which only indicates the number of students carrying on studies in the various stages. We
cannot find a large disparity among the various categories and we cannot discern either a case of
proportionate representation or an adequate representation from the above details.Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

67. In this context, specific reference is to be made to paragraph 810 from Indra Sawhney which was
emphasized by the learned Advocate General, as extracted hereinbelow: -
Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
810. While 50% shall be the rule, it is necessary not to put out of consideration
certain extraordinary situations inherent in the great diversity of this country and the
people. It might happen that in far flung and remote areas the population inhabiting
those areas might, on account of their being out of the mainstream of national life
and in view of conditions peculiar to and characteristical to them, need to be treated
in a different way, some relaxation in this strict rule may become imperative. In
doing so, extreme caution is to be exercised and a special case made out.
68. K Krishna Murthy (supra) after extracting paragraph 810 held so in paragraph 66 and 67: -
66. Admittedly, reservations in excess of 50% do exist in some exceptional cases,
when it comes to the domain of political representation. For instance, the Legislative
Assemblies of the States of Arunachal Pradesh, Nagaland, Meghalaya, Mizoram and
Sikkim have reservations that are far in excess of the 50% limit. However, such a
position is the outcome of exceptional considerations in relation to these areas.
Similarly, vertical reservations in excess of 50% are permissible in the composition of
local self-government institutions located in the Fifth Schedule Areas.
67. In the recent decision reported as Union of India v. Rakesh Kumar [(2010) 4 SCC
50 : (2010) 1 SCC (L&S) 961 : (2010) 1 Scale 281] this Court has explained why it may
be necessary to provide reservations in favour of the Scheduled Tribes that exceed
50% of the seats in panchayats located in the Scheduled Areas. However, such
exceptional considerations cannot be invoked when we are examining the quantum
of reservations in favour of backward classes for the purpose of local bodies located in
general areas. In such circumstances, the vertical reservations in favour of
SCs/STs/OBCs cannot exceed the upper limit of 50% when taken together. It is
obvious that in order to adhere to this upper ceiling, some of the States may have to
modify their legislations so as to reduce the quantum of the existing quotas in favour
of OBCs.
Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
69. The exception provided under paragraph 810 is with respect to far flung and remote areas. The
inhabitants of such areas, who remain out of the mainstream of national life and the conditions
peculiar and characteristic to them, could lead to different treatment being meted out to them, even
justifying a breach of the 50% rule. We also look at the specific areas; the North-East, where such
breach was permitted, as noticed in K Krishna Murthy which falls under the exception provided in
paragraph 810 of Indra Sawhney. We do not find ourselves persuaded to hold the situation in the
State of Bihar, especially looking at the Caste Survey, to be of such extenuating nature for reason ofBhagwat Kumar vs The State Of Bihar on 20 June, 2024

it being far flung and away from the mainstream of national life. The Caste Survey, on the contrary,
definitely paints a different picture from what was argued, insofar as the adequate representation in
public employment. The State of Bihar is neither a far flung or remote area nor is it out of the
mainstream of national life making an overbreadth of the 50% limit an imperative measure.
70. Examining the Second Backward Classes Commission (Mandal Commission); Indra Sawhney
(supra) specifically referred to the socio-educational field survey and criteria of backwardness, in
paragraph 667. We cannot but Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 express a
reservation to the submission of the learned Advocate General that in the present case we are not
concerned with the inclusion or exclusion of a caste or community and the criteria of backwardness
would not be a relevant consideration. Even in the case of enhancement, we found an objective
analysis should take in, the relevant aspects for a better understanding of the change in social
milieu, aided actively by the long years of measures and schemes for the upliftment of the deprived,
the marginalized and the downtrodden.
71. We refer to paragraph 667 from Indra Sawhney (supra) also to emphasize the manner in which a
methodology was evolved for collection of data and scientific analysis of the same. We extract
paragraph 667: -
667. Chapter IX sets out the evidence tendered by Central and State Governments
while Chapter X deals with the evidence tendered by the Public. Chapter XI is quite
important inasmuch as it deals with the "Socio-Educational Field Survey and Criteria
of Backwardness". In this chapter, the Commission says that it decided to tap a
number of sources for the collection of data, keeping in mind the criticism against the
Kaka Kalelkar Commission as also the several judgments of this Court. It says that
Socio-Educational Field Survey was the most comprehensive inquiry made by the
Commission in this behalf. Right from the beginning, this survey was designed with
the help of top social scientists and specialists in the country. Experts from a number
of disciplines were associated with different phases of its progress. It refers to the
work of Research Planning Team of Sociologists and the work done by a panel of
experts led by Prof. M.N. Srinivas. It refers to the fact that both of them concurred
that "in the Indian context such collectivities can be castes or other hereditary groups
traditionally associated with specific occupations which are considered to be low and
Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 impure and with which
educational backwardness and low income are found to be associated". The
Commission says further that with a view to providing continuous guidance at the
operational level, a Technical Advisory Committee was set up under Dr K.C. Seal,
Director General, Central Statistical Organisation with the Chief Executive, National
Sample Survey Organisation and representatives of Directors of State Bureaux of
Economics and Statistics as members. The Commission sets out the methodology
evolved by the Experts' panel and states that survey operations were entrusted to the
State Statistical Organisations of the concerned States/Union Territories. It refers to
the training imparted to the survey staff and to the fact that the entire data so
collected was fed into a computer for electronic processing of such data. Out of theBhagwat Kumar vs The State Of Bihar on 20 June, 2024

406 districts in the country, the survey covered 405 districts.
In every district, two villages and one urban block was selected and in each of these villages and
urban blocks, every single household was surveyed. The entire data collected was tabulated with the
aid of National Informatic Centre of Electronics Commission of India. The Technical Committee
constituted a Sub-Committee of Experts to help the Commission prepare "Indicators of
Backwardness" for analysing the data contained in the computerised tables. In para 11.23 (page 52)
the Commission sets out the eleven Indicators/Criteria evolved by it for determining social and
educational backwardness. Paras 11.23, 11.24 and 11.25 are relevant and may be set out in full:
"11.23. As a result of the above exercise, the Commission evolved eleven 'Indicators'
or 'criteria' for determining social and educational backwardness. These 11
'Indicators' were grouped under three broad heads, i.e., Social, Educational and
Economic.
72. We find no such analysis having been made of the data collected in the Caste Survey. True, a
massive exercise of a survey was conducted by the Government, of the entire population of the State
and the data collated in a report. It was the contention of the petitioners that there was no analysis
of such data and merely based on the lack of proportionate representation in government
employment and educational Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
institutions, the percentage of reservation was enhanced. There was no scientific analysis conducted
nor was any expert appointed to make analysis of the data collected. An expert's views or a reference
to a legally constituted Commission, we have held, is not essential in every such exercise. What
worries us is the fact of no such exercise or analysis having been done by the Government or the
Legislature in bringing about the Amendment Acts. After the collection of data, there was a frog leap
into the amendment enhancing the reservations beyond 50%, which we found was again on
proportionate representation in the services of the State and educational institutions, clearly not
permissible under Articles 15(4) & 16(4).
73. The different judgments of the learned Judges in Indra Sawhney (supra) specifically emphasized
the words adequate as found in Article 16(4). Paragraph 422 of one judgment which found that
there was no general rule of a 50% limit held so: -
422. Under the Constitution, the reservations in employment in favour of backward
classes are not intended either to be indiscriminate or permanent. Article 16(4) which
provides for reservations, also at the same time prescribes their limits and
conditions. In the first place, the reservations are not to be kept in favour of every
backward class of citizens. It is only that backward class of citizens which, in the
opinion of the State, is "not adequately represented" in the services under the State,
which is entitled to the benefit of the reservations.
Secondly, and this follows from the first, even that Patna High Court CWJC No.16760 of 2023
dt.20-06-2024 backward class of citizens would cease to be the beneficiary of the reservation policy,
the moment the State comes to the conclusion that it is adequately represented in the services.Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

74. We also extract the answer to Question 4 in that very same judgment from paragraph 552:
552. ...
Question 4:
Ordinarily, the reservations kept both under Article 16(1) and 16(4) together should
not exceed 50 per cent of the appointments in a grade, cadre or service in any
particular year. It is only for extraordinary reasons that this percentage may be
exceeded. However, every excess over 50 per cent will have to be justified on valid
grounds which grounds will have to be specifically made out.
The adequacy of representation is not to be determined merely on the basis of the
over all numerical strength of the backward classes in the services. For determining
the adequacy, their representation at different levels of administration and in
different grades has to be taken into consideration. It is the effective voice in the
administration and not the total number which determines the adequacy of
representation.
75. In paragraph 629 of a dissenting opinion in Indra Sawhney (supra) exclusion of creamy layer
was found to be a social purpose. It was also found that income apart, provision should be made that
wards of those backward classes, who have achieved a particular status in the society either political,
social or economic or their parents are in higher services, then, such individuals should be precluded
to avoid Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 monopolization of the services
reserved for the backward classes by a few. This again projects a need for examination of the relative
conditions and status of individuals in each of the castes which have been given reservation under
the Reservation Act, the percentage of which was enhanced; in this case mechanically. The only
consideration that weighed with the legislature was that the backward classes constitute the major
part of the population and that their representation in the various services and educational
institutions are lesser in proportion than the unreserved category of government employees bear
with their total population. Even when enhancement of reservation is considered, it is imperative
that the status of the people at large in a caste and the economic and social status they achieved
based on the reservations & beneficial schemes, should be considered. A particular caste which had
developed considerably or even marginally would not need an enhancement while another caste
which had not developed marginally or not at all, would require a better percentage of reservation.
Otherwise within the backward caste and most backward caste there would be situations in which
one or more of the castes which had developed better than the others would continue to appropriate
the benefits because of the social and financial capital they had Patna High Court CWJC No.16760 of
2023 dt.20-06-2024 achieved over the years.
76. In this context, we refer to paragraph 693 of Indra Sawhney and the words of Dr. B.R. Ambedkar
quoted therein: -Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

"There are three points of view which it is necessary for us to reconcile if we are to
produce a workable proposition which will be accepted by all. Of the three points of
view, the first is that there shall be equality of opportunity for all citizens. It is the
desire of many Members of this House that every individual who is qualified for a
particular post should be free to apply for that post, to sit for examinations and to
have his qualifications tested so as to determine whether he is fit for the post or not
and that there ought to be no limitations, there ought to be no hindrance in the
operation of this principle of equality of opportunity. Another view mostly shared by
a section of the House is that, if this principle is to be operative -- and it ought to be
operative in their judgment to its fullest extent -- there ought to be no reservations of
any sort for any class or community at all, that all citizens, if they are qualified,
should be placed on the same footing of equality so far as the public services are
concerned. That is the second point of view we have. Then we have quite a massive
opinion which insists that, although theoretically it is good to have the principle that
there shall be equality of opportunity, there must at the same time be a provision
made for the entry of certain communities which have so far been outside the
administration. As I said, the Drafting Committee had to produce a formula which
would reconcile these three points of view, firstly, that there shall be equality of
opportunity, secondly that there shall be reservations in favour of certain
communities which have not so far had a 'proper look-in' so to say into the
administration. If Honourable Members will bear these facts in mind -- the three
principles we had to reconcile, -- they will see that no better formula could be
produced than the one that is embodied in sub-clause (3) of Article 10 of the
Constitution; .... It is a generic principle. At the same Patna High Court CWJC
No.16760 of 2023 dt.20-06-2024 time, as I said, we had to reconcile this formula
with the demand made by certain communities that the administration which has
now -- for historical reasons
-- been controlled by one community or a few communities, that situation should
disappear and that the others also must have an opportunity of getting into the public
services. Supposing, for instance, we were to concede in full the demand of those
communities who have not been so far employed in the public service to the fullest
extent, what would really happen is, we shall be completely destroying the first
proposition upon which we are all agreed, namely, that there shall be an equality of
opportunity. Let me give an illustration. Supposing, for instance, reservations were
made for a community or a collection of communities, the total of which came to
something like 70% of the total posts under the State and only 30% are retained as
the unreserved. Could anybody say that the reservation of 30% as open to general
competition would be satisfactory from the point of view of giving effect to the first
principle, namely, that there shall be equality of opportunity? It cannot be in my
judgment. Therefore the seats to be reserved, if the reservation is to be consistent
with sub-clause (1) of Article 10, must be confined to a minority of seats. It is then
only that the first principle could find its place in the Constitution and be effective in
operation. If Honourable Members understand this position that we have toBhagwat Kumar vs The State Of Bihar on 20 June, 2024

safeguard two things, namely, the principle of equality of opportunity and at the same
time satisfy the demand of communities which have not had so far representation in
the State, then, I am sure they will agree that unless you use some such qualifying
phrase as 'backward' the exception made in favour of reservation will ultimately eat
up the rule altogether. Nothing of the rule will remain. That I think if I may say so, is
the justification why the Drafting Committee undertook on its own shoulders the
responsibility of introducing the word 'backward' which, I admit, did not originally
find a place in the fundamental right in the way in which it was passed by this
Assembly."
[underlining by us for emphasis]
77. Reference was made to the formula adopted by Patna High Court CWJC No.16760 of 2023
dt.20-06-2024 the drafting committee to reconcile the different points of view and produce a
formula that that shall ensure equality of opportunity, but enabling reservations in favor of certain
communities who had not so far participated in the administration. Merit, hence, cannot be
sacrificed completely but there should also be participation ensured of groups of people who were
long deprived any role in the administration. The emphasis was on reconciling the need for
efficiency in administration while enabling reparations by way of affirmative action.
78. In explaining the content of the word 'backward', Shri K. M. Munshi's words were extracted in
paragraph 692 of Indra Sawhney (supra) which again emphasized the need to ensure efficiency in
the services of the State while providing the backward communities so far deprived to have a better
status and an opportunity to serve the country. We extract from paragraph 692 of Indra Sawhney
(supra): -
"What we want to secure by this clause are two things. In the fundamental right in
the first clause we want to achieve the highest efficiency in the services of the State --
highest efficiency which would enable the services to function effectively and
promptly. At the same time, in view of the conditions in our country prevailing in
several provinces, we want to see that backward classes, classes who are really
backward, should be given scope in the State services; for it is realised that State
services give a status and an Patna High Court CWJC No.16760 of 2023
dt.20-06-2024 opportunity to serve the country, and this opportunity should be
extended to every community, even among the backward people. That being so, we
have to find out some generic term and the word 'backward class' was the best
possible term.
79. It is to break the stranglehold hold of a few at the expense and to the detriment of the many, that
reservation to backward classes was envisaged. But merit cannot be completely effaced and
sacrificed at the altar of reparations. This was the principle on which the 50% limit was laid down
for reservations. Though, a reference order, we deem it appropriate to refer to paragraph 16 from
Jaishri Laxmanrao Patil v. State of Maharashtra, (2021) 2 SCC 785, which is extracted hereinbelow:
-Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

16. The factors termed as extraordinary and exceptional, justifying reservations in
excess of 50% are those required for the purpose of providing reservations. The
social, educational and economic backwardness of a community, existence of
quantifiable data relating to inadequacy of representation of the community in public
services and deprivation of the benefits flowing from reservations to the community
are not exceptional circumstances for providing reservations in excess of 50%. We are
of the prima facie opinion that the High Court committed an error in treating the
above factors as circumstances which are extraordinary, warranting relaxation of the
strict rule of 50%. Admittedly, reservations provided to the Maratha community were
implemented in educational institutions for one academic year only.
Implementation of the Act for admissions in educational institutions and appointments to public
posts during the pendency of these appeals will cause irreparable loss to the candidates belonging to
the Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 open category. It will be difficult to
cancel the admissions made in the educational institutions and appointments made to the public
posts by implementing the reservations as per the Act.
80. Janhit Abhiaan (supra) found economic disabilities and economic backwardness to be valid
criteria for reservation or compensatory discrimination. The framers of the Constitution, according
to the majority judgment, laid stress on the principle of economic democracy, complimenting the
political democracy and contemplating reservation to deal with the deprivations arising out of
economic disadvantages, which has the sanction of our Constitution and our jurisprudence. On the
issue relevant to the instant case, which is breach of 50% ceiling on reservation, it was held so in
paragraph 156-158, which are extracted hereinbelow:-
156. A long deal of arguments by the learned counsel challenging the amendment in
question had also been against the prescription of ten per cent reservation for EWS
on the ground that it exceeds the ceiling limit of fifty per cent laid down by this Court
in the consistent series of cases. Apart that this argument is not precisely in
conformity with the law declared by this Court, it runs counter to the other argument
that this EWS reservation is invalid because of exclusions. If at all the cap of fifty per
cent is the final and inviolable rule, the classes already standing in the enabled
bracket of fifty per cent cannot justifiably claim their share in the extra ten per cent,
which is meant for a separate class and section i.e. economically weaker section.
157. Moreover, the argument regarding the cap of fifty per cent is based on all those
decisions by this Court which Patna High Court CWJC No.16760 of 2023
dt.20-06-2024 were rendered with reference to the reservations existing before the
advent of the amendment in question. The fifty per cent ceiling proposition would
obviously be applied only to those reservations which were in place before the
amendment in question. No decision of this Court could be read to mean that even if
Parliament finds the necessity of another affirmative action by the State in the form
of reservation for a section or class in need, it could never be provided. As noticed
hereinbelow, the decisions of this Court are rather to the contrary and provide thatBhagwat Kumar vs The State Of Bihar on 20 June, 2024

flexibility within which Parliament has acted for putting in place the amendment in
question.
158. In the above backdrop, the relevant decisions of this Court in regard to this fifty
per cent ceiling limit could be referred but, while reiterating that these decisions are
applicable essentially to the class/classes who are to avail the benefits envisaged by
Articles 15(4), 15(5) and 16(4) of the Constitution of India.
81. The cap of 50% was hence reiterated to be a inviolable rule within the bracket of categories who
are termed backward class. The paragraph extracted from Dr. Jaishri Laxmanrao Patil (supra)
hereinabove was specifically extracted with approval. We also notice paragraph 171-173 which are
extracted hereinbelow:-
171. Thus, having examined the permissible limits of affirmative action in light of the
possible harm of preferential treatment qua other innocent class of competitors i.e.
general merit candidates, this Court has expressed the desirability of fifty per cent as
the ceiling limit for reservation in education and public employment but, as observed
hereinbefore, all such observations are required to be read essentially in the context
of the reservation obtaining under Articles 15(4), 15(5) and 16(4) or other areas of
affirmative action like that in relation to local self-government (the case of K. Krishna
Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 Murthy [K. Krishna
Murthy v. Union of India, (2010) 7 SCC 202 : (2010) 2 SCC (L&S) 385] ) and cannot
be overstretched to the reservation provided for entirely different class, consisting of
the economically weaker sections.
172. Moreover, as noticed, this ceiling limit, though held attached to the
constitutional requirements, has not been held to be inflexible and inviolable for all
times to come. Reasons for this are not far to seek. As mentioned hereinbefore,
reservation by affirmative action is not having trappings of any such essential feature
of the Constitution, collectively enumerated by Kesavananda [Kesavananda Bharati v.
State of Kerala, (1973) 4 SCC 225] and successive decisions, that its modulation with
reference to any particular compelling reason or requirement could damage the basic
structure of the Constitution.
173. In another view of the matter, the prescription of ceiling limit of fifty per cent,
being apparently for the benefit of general merit candidates, does not provide any
justified cause to the candidates standing in the bracket of already available
reservation to raise any grievance about extra ten per cent reservation for the benefit
of another section of society in need of affirmative action. In any case, there is no
question of violation of any such basic feature of the Constitution that the entire
structure of equality of opportunity in Article 16 would collapse by this EWS
reservation.Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

82. The rule of 50% limit in reservation, thus, applies to the Backward Classes, Scheduled Caste and
Scheduled Tribes, which is equally applicable under Article 15(4) and Article 16(4) and in the
present case, we see no extenuating circumstance enabling the State to breach the rule, as found in
paragraph 810 of Indra Sawhney.
Patna High Court CWJC No.16760 of 2023 dt.20-06-2024
83. Having dealt with the various decisions relied on at the Bar, we have to notice that there is no
requirement that a Commission should be appointed or reference made to the already constituted
Commission at the National or State level for the purpose of considering reservations, or its
percentage; as held in M.R Balaji (supra). But it has to be emphasized that even as early as in M.R
Balaji, on ascertaining the backwardness, it spoke of the relevance of various factors and the
intermix of aspects like poverty, caste, occupation, location of residence etc; which reflects the social
and economic situation, requiring an elaborate investigation by collection of data and in-depth
analysis in a rational and scientific manner. We have already found that such an analysis was absent
insofar as the enhancement of the quota for reservations. Article 15(4) and Article 16(4) were
equated in M.R Balaji (supra) and Devadasan (supra) applied 50% limit even to Article 15(4).
Paragraph 814 of Indra Sawhney (supra) approved Devadasan (supra) to the extent of its majority
decision regarding the limit of 50% being applied to Article 15(4). N.M.Thomas (supra) was differed
from and it was held that to apply the 50%, the year has to be taken as a unit and not the service as a
whole. There can be no filling up of the deficiency of service in one single year was Patna High Court
CWJC No.16760 of 2023 dt.20-06-2024 the authoritative pronouncement.
84. That, adequate representation is the core of both Articles 15(4) & 16 (4); was reiterated and the
rule of 50% limit in reservations was reaffirmed by the various decisions. That, the exception
provided, to exceed the 50% limit, was confined and restricted to extenuating circumstances and
characteristically inherent aspects akin to far flung areas thus being kept away from the mainstream
of National life, is undisputed. That, these conditions do not exist and was not demonstrated in the
instant case is abundantly clear. That, the State attempted no in-depth study or analysis before
providing for enhancement of the reservation percentage is established from the records. That, the
State proceeded on the mere proportion of population of different categories as against their
numerical representation in government services and educational institutions is the admitted
position and is the pivotal argument of the State. That, this argument works against the core
principles of Articles 15(4) & 16(4) is a given fact. In our judgment hence, the enhancement of
reservations beyond the 50% limit is bad in law based on the principles of equality emanating from
the Constitution, as laid down by the wealth of precedents discussed in this judgment; binding on us
and the Patna High Court CWJC No.16760 of 2023 dt.20-06-2024 State equally. We, hence, set
aside the Bihar Reservation of Vacancies in Posts and Services (for Scheduled Caste, Scheduled
Tribes and Other Backward Classes) Amendment Act, 2023 and the Bihar Reservation (in
Admission to Educational Institutions) Amendment Act, 2023 as ultra vires the Constitution and
violative of the equality clause under Articles 14, 15 and 16. The Writ Petitions are allowed leaving
the parties to suffer their respective costs.
(K. Vinod Chandran, CJ) Harish Kumar, J:Bhagwat Kumar vs The State Of Bihar on 20 June, 2024

(Harish Kumar, J) Sujit/Anushka/ Sharun AFR/NAFR AFR CAV DATE 11.03.2024
Uploading Date 20.06.2024 Transmission DateBhagwat Kumar vs The State Of Bihar on 20 June, 2024

