Dakshnamurthy vs The State Of Tamil Nadu on 29 March, 2023
Bench: M.Sundar, M.Nirmal Kumar
    2023:MHC:1566
                                                                                        H.C.P.No.1921 of 2022
                                     IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                       DATED : 29.03.2023
                                                             CORAM
                                       THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                      and
                                  THE HONOURABLE MR.JUSTICE M.NIRMAL KUMAR
                                                      H.C.P.No.1921 of 2022
                     Dakshnamurthy
                     S/o.Kalian                                          .. Petitioner /
                                                                            Father of the detenu
                                                                 Vs.
                     1.           The State of Tamil Nadu
                                  Represented by its Secretary
                                  Home, Prohibition and Excise Department
                                  Fort St.George
                                  Chennai – 600 009
                     2.           The District Magistrate and District Collector
                                  Kallakurichi District
                                  Kallakurichi
                     3.           The Superintendent of Police
                                  Kallakurichi District
                                  Kallakurichi
                     4.           The Superintendent of Central Prison
                                  Central Prison, Vellore
                                  Vellore District
                     5.           The Inspector of Police
                     Page Nos.1/10
https://www.mhc.tn.gov.in/judis
                                                                                       H.C.P.No.1921 of 2022
                                  Chinna Salem Police StationDakshnamurthy vs The State Of Tamil Nadu on 29 March, 2023

                                   Kallakurichi
                                  Kallakurichi District
                                  (Crime No.236 of 2022)                     ..      Respondents
                                  Petition filed under Article 226 of the Constitution of India praying
                     for issuance of a writ of habeas corpus to call for the entire records in
                     D.O.No.C2/44/2022 dated 28.08.2022 passed by the District Collector and
                     District Magistrate, Kallakurichi District, the second respondent herein and
                     quash the same as illegal and direct the respondents to produce the detenu
                     Sanjeev, son of Dakshnamurthy, aged 22 years, now confined in Central
                     Prison, Vellore before this Court and set him at liberty.
                                  For Petitioner           :     Mr.R.Sankarasubbu
                                  For Respondents          :     Mr.R.Muniyapparaj
                                                                 Additional Public Prosecutor
                                                                 assisted by
                                                                 Mr.M.Sylvester John, Advocate
                                                            ORDER
[Order of the Court was made by M.SUNDAR, J.,] Captioned 'Habeas Corpus Petition' ['HCP' for the
sake of brevity] has been filed by the father of detenu assailing a 'preventive detention order dated
28.08.2022 bearing reference D.O.No.C2/44/2022' [hereinafter 'impugned detention order' for the
sake of convenience and brevity]. To be noted, fifth respondent is the sponsoring authority and
second respondent is https://www.mhc.tn.gov.in/judis the detaining authority as the impugned
detention order has been made by second respondent.
2. Impugned detention order has been made under 'The Tamil Nadu Prevention of Dangerous
Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-offenders, Goondas, Immoral
traffic offenders, Sand-offenders, Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982
(Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake of convenience and clarity]
on the premise that the detenu is a 'Goonda' within the meaning of Section 2(f) of Act 14 of 1982.
3. There is no adverse case. This solitary case which is the sole substratum of the impugned
detention order is Crime No.236 of 2022 on the file of Chinnasalem Police Station for an alleged
offence under Sections 147, 148, 294(b), 323, 324, 332, 336, 353, 435, 436, 379 and 506(ii) of 'The
Indian Penal Code (45 of 1860)' [hereinafter 'IPC' for the sake of convenience and clarity] read with
Sections 3, 4 and 5 of Tamil Nadu Property (Prevention of Damage and Loss) Act, 1992. Owing to
the nature https://www.mhc.tn.gov.in/judis of the challenge to the impugned detention order, it is
not necessary to delve into the factual matrix or be detained further by facts.
4. Mr.R.Sankarasubbu, learned counsel on record for petitioner and Mr.R.Muniyapparaj, learned
State Additional Public Prosecutor, assisted by Mr.M.Sylvester John, learned counsel for all
respondents are before us.
5.Notwithstanding very many averments and grounds raised in the support affidavit, in the hearing
Mr.R.Sankarasubbu, learned counsel for petitioner predicated his campaign against the impugned
detention order on three points and they are as follows:Dakshnamurthy vs The State Of Tamil Nadu on 29 March, 2023

a) As regards the subjective satisfaction of detaining authority qua imminent
possibility of detenu being enlarged on bail qua paragraph 5 of the impugned
detention order, the detaining authority has said that the Sponsoring Authority
received reliable information that his relatives are taking steps to file bail application
but there is no statement from the relatives.
To put it differently, there is nothing to buttress what has been described as 'reliable information';
https://www.mhc.tn.gov.in/judis
b) As regards the same subjective satisfaction, Sponsoring Authority has relied on an order dated
23.03.2023 made in C.M.P.No.2447 of 2020 on the file of the Sessions Court, Villupuram vide
Crime No.144 of 2020 for alleged offences under Sections 147, 148, 294(b), 448, 323, 324, 506(ii)
IPC read with Section 3 of Tamil Nadu Property (Prevention of Damage and Loss ) Act of
Ulundurpet Police Station but this really is not a similar case as the ground case turns on offences
under Sections 379, 436, 435, 353, 336 and 332 of IPC also;
c) The aforementioned order of the Sessions Court has been given in the grounds booklet as an
annexure. It is at page 76, it is in English but a Tamil translation has not been provided. Learned
counsel submitted that detenu has difficulty in understanding legal language in which the bail order
is couched and therefore it has impaired his constitutional safeguard to make an effective
representation against the impugned preventive detention order;
6. In response to the aforesaid three points, learned Prosecutor submitted to the contrary and
submissions of learned Prosecutor are as https://www.mhc.tn.gov.in/judis follows:
a) As regards reliable information, learned Prosecutor submitted that it is reliable
information received by the Sponsoring Authority;
b) As regards the second point, it was submitted that the two cases are largely
similar;
c) As regards the third point, learned Prosecutor really did not have much of a say as
the obtaining position is no Tamil translation of the bail order has been provided in
the grounds booklet.
7. We carefully considered the three points that have been urged / exhorted before us. We also
considered the rival submissions. The discussion and dispositive reasoning are as follows:
a) As regards the first point of bald averment that 'reliable information' was received
by Sponsoring Authority is not good enough qua subjective satisfaction qua
imminent possibility of detenu being enlarged on bail. Therefore, this point enures to
the benefit of the petitioner;Dakshnamurthy vs The State Of Tamil Nadu on 29 March, 2023

https://www.mhc.tn.gov.in/judis
b) As regards the second point, we find that two cases are dissimilar as the provisions of IPC
referred to by learned counsel for petitioner are not there in the bail order which has been treated as
a similar case and this by itself makes the two cases vastly different. This means that subjective
satisfaction qua imminent possibility of detenu being enlarged on bail is impaired. More
importantly, a careful perusal of the bail order brings to light that the similar case of Thirupathy and
Pasupathi in the Villupuram Sessions Court is vastly different as that was a case where the injured
were admitted in the hospital and discharged. This leaves us with the conclusion that comparison of
these two cases is a case of comparison of Apples and Oranges or Chalk and Cheese. The sequitur is,
second point also enures to the benefit of the petitioner.
c) As regards the third point, we respectfully remind ourselves of Pownammal case law
[Pownammal Vs. State of Tamil Nadu reported in (1999) 2 SCC 413] wherein Hon'ble Supreme
Court addressed itself to the question of furnishing the https://www.mhc.tn.gov.in/judis detenu
with the copies in a language which the detenu is conversant with and answered the same. The
question which the Hon'ble Supreme Court addressed itself to is captured in paragraph 6 and the
answer is set out in paragraph 16. Paragraphs 6 and 16 of Pownammal case law {as in SCC journal}
read as follows:
'6. The short question that falls for our consideration is whether failure to supply the
Tamil version of the order of remand passed in English, a language not known to the
detenue, would vitiate her further detention.
16. For the above reasons, in our view, the non-supply of the Tamil version of the
English document, on the facts and in the circumstances, renders her continued
detention illegal. We, therefore, direct that the detenue be set free forthwith unless
she is required to be detained in any other case. The appeal is accordingly allowed. '
Pownammal case law principle or ratio applies in all fours to the case on hand.
Therefore, the third point also enures to the benefit of the petitioner.
https://www.mhc.tn.gov.in/judis
8. Apropos, the sequitur is, captioned HCP is allowed. Impugned detention order dated 28.08.2022
bearing reference D.O.No.C2/44/2022 made by the second respondent is set aside and the detenu
Thiru.Sanjeev, aged 22 years, son of Thiru. Dakshnamurthy, is directed to be set at liberty forthwith,
if not required in connection with any other case / cases. There shall be no order as to costs.
                                                                        (M.S.,J.)         (M.N.K.,J.)
                                                                               29.03.2023
                     Index : Yes
                     Speaking
                     Neutral Citation : Yes
                     gpaDakshnamurthy vs The State Of Tamil Nadu on 29 March, 2023

P.S: Registry to forthwith communicate this order to Jail authorities in Central Prison, Vellore.
To
1. The Secretary Home, Prohibition and Excise Department Fort St.George Chennai – 600 009
2. The District Magistrate and District Collector Kallakurichi District Kallakurichi
3. The Superintendent of Police Kallakurichi District Kallakurichi https://www.mhc.tn.gov.in/judis
M.SUNDAR, J., and M.NIRMAL KUMAR, J., gpa
4. The Superintendent of Central Prison Central Prison, Vellore Vellore District
5. The Inspector of Police Chinna Salem Police Station Kallakurichi Kallakurichi District
6. The Public Prosecutor High Court, Madras.
29.03.2023 https://www.mhc.tn.gov.in/judisDakshnamurthy vs The State Of Tamil Nadu on 29 March, 2023

