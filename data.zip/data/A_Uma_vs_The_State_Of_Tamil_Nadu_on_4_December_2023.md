A.Uma vs The State Of Tamil Nadu on 4 December, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                          HCP(MD)No.1299 of 2023
                         BEFORE THE MADURAI BENCH OF MADRAS HIGH COURT
                                                DATED: 04.12.2023
                                                    CORAM:
                                    THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                      and
                                  THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                           H.C.P.(MD)No.1299 of 2023
                     A.Uma                                                  : Petitioner
                                                       Vs.
                     1.The State of Tamil Nadu,
                        Rep. by its Principal Secretary to Government,
                        Home, Prohibition and Excise Department,
                        Secretariat,
                        Fort St. George,
                        Chennai – 9.
                     2.The Deputy Inspector General of Police
                        Tirunelveli Range & the Commissioner of Police,
                        Tirunelveli District.
                     3.The Superintendent,
                        Central Prison,
                        Palayamkottai,
                        Tirunelveli District.
                     Page 1 of 11
https://www.mhc.tn.gov.in/judisA.Uma vs The State Of Tamil Nadu on 4 December, 2023

                                                                             HCP(MD)No.1299 of 2023
                     4.The Inspector of Police,
                        Palayamkottai Police Station,
                        Palayamkottai,
                        Tirunelveli District.                                    : Respondents
                     PRAYER: Petition filed under Article 226 of the Constitution of India
                     to issue a writ of Habeas Corpus, calling for the entire records
                     relating to the order of detention passed by the second respondent in
                     his proceedings in Detention Order No.47/BCDFGISSSV/2023 dated
                     27.09.2023 and quash the same and direct the respondents to
                     produce the body or person of the detenue namely Sandru, S/o.Anbu
                     aged about 23 years (now detained at Central Prison, Palayamkottai)
                     before this Court and set him at liberty.
                                             For Petitioner   : Mr.R.Anand
                                             For Respondents : Mr.S.Ravi
                                                               Additional Public Prosecutor
                                                         ORDER
*********** [Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus
Petition' [hereinafter 'HCP' for the sake of brevity] was listed in the Admission Board on
https://www.mhc.tn.gov.in/judis 26.10.2023, a Hon'ble Predecessor Coordinate Division Bench
made the following order and a scanned reproduction of the same is as follows:
2.It has now become necessary to set out a thumbnail sketch of factual matrix and we
do so in the paragraphs infra.
3.Today, captioned matter is in the Final Hearing Board.
4.Mr.R.Anand, learned counsel on record for petitioner and Mr.S.Ravi, learned State
Additional Public Prosecutor for all respondents are before us.
https://www.mhc.tn.gov.in/judisA.Uma vs The State Of Tamil Nadu on 4 December, 2023

5.Captioned HCP has been filed by mother of the detenu assailing a 'preventive detention order
dated 27.09.2023 bearing reference No.47/BCDFGISSSV/2023' [hereinafter 'impugned preventive
detention order' for the sake of brevity and convenience].
To be noted, fourth respondent is the sponsoring authority and second respondent is the detaining
authority as impugned preventive detention order has been made by second respondent.
6.Impugned preventive detention order has been made under 'The Tamil Nadu Prevention of
Dangerous Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-offenders,
Goondas, Immoral traffic offenders, Sand-offenders, Sexual-offenders, Slum-
grabbers and Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982'
for the sake of convenience and clarity] on the premise that the detenu is a 'Goonda' within the
meaning of Section 2(f) of Act 14 of 1982.
7.The ground case which constitutes sole substratum of the impugned preventive detention order is
Crime No.1034 of 2023 on the file of Palayamkottai Police Station for alleged offences under
https://www.mhc.tn.gov.in/judis Sections 147, 148, 302, 506(ii) and 109 of 'The Indian Penal Code
(45 of 1860)' [hereinafter 'IPC' for the sake of convenience and clarity] which was subsequently
altered into Sections 147, 148, 302, 506(ii) and 109 of IPC r/w. 3(1)(r), 3(1)(s), 3(2)(v) of 'The
Schedule Castes and Scheduled Tribes (Prevention of Atrocities Act, 1989' [hereinafter 'SC/ST (PoA)
Act' for the sake of convenience]. Considering the nature of the challenge to the impugned detention
order, it is not necessary to delve into the factual matrix of the case.
8.Though several points have been raised in the support affidavit, Mr.R.Anand, learned Counsel on
record for the HCP petitioner predicated his campaign against the impugned preventive detention
order on one point in the final hearing board and this one point turns on Section 8(1) of Act 14 of
1982.
9.Learned Counsel drew our attention to the impugned preventive detention order dated
27.09.2023 and pointed out that the same has been duly served on the detenu on the next day by
04.30 p.m. ie., on 28.09.2023 at 04.30 p.m. The detention order together with the rubber stamp is
as follows:
https://www.mhc.tn.gov.in/judis https://www.mhc.tn.gov.in/judis
10.Thereafter, learned Counsel placed before us the grounds booklet served on the detenu and
pointed out that the grounds booklet has been served on the detenu only on 12.10.2023 and for an
illustration the last page of the index is as follows:
https://www.mhc.tn.gov.in/judis
11.The aforementioned records would demonstrate that there is a direct and clear breach of Section
8(1) of Act 14 of 1982 is learned Counsel's say.A.Uma vs The State Of Tamil Nadu on 4 December, 2023

12.As the matter turns heavily on records, learned Prosecutor really does not have much of a say.
13.In this view of the matter it will suffice to say that the aforementioned point is directly and
squarely covered in all say by an order made by this Division Bench in Vasanthi's case [Vasanthi Vs.
The Additional Chief Secretary to Government and others] reported in 2023:MHC:4028 [Neutral
Citation of Madras High Court].
14.Following Vasanthi's case principle, we have no hesitation in dislodging the impugned preventive
detention order in the captioned matter in the habeas legal drill on hand.
15.Ergo, the sequitur is, captioned HCP is allowed. Impugned preventive detention order dated
27.09.2023 bearing reference https://www.mhc.tn.gov.in/judis No.47/BCDFGISSSV/2023 made by
the second respondent is set aside and the detenu Thiru.Sandru, male, aged 23 years, son of Anbu, is
directed to be set at liberty forthwith, if not required in connection with any other case / cases.
There shall be no order as to costs.
                                                              [M.S.,J.]     &     [R.S.V.,J.]
                                                                      04.12.2023
                     Index          : Yes/No
                     Internet       : Yes/No
                     Neutral Citation : Yes/No
                     MR
Post Script: Registry to forthwith communicate this order to Jail authorities in Central Prison,
Palayamkottai. All concerned are to act on this order being uploaded in official website of this Court
without insisting on certified copies. To be noted, this order when uploaded in official website of this
Court will be watermarked and will also have a QR code.
https://www.mhc.tn.gov.in/judis To
1.The Principal Secretary to Government, State of Tamil Nadu, Home, Prohibition and Excise
Department, Secretariat, Fort St. George, Chennai – 9.
2.The Deputy Inspector General of Police Tirunelveli Range & the Commissioner of Police,
Tirunelveli District.
3.The Superintendent, Central Prison, Palayamkottai, Tirunelveli District.
4.The Inspector of Police, Palayamkottai Police Station, Palayamkottai, Tirunelveli District.
5.The Additional Public Prosecutor, Madurai Bench of Madras High Court, Madurai.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J.
and R.SAKTHIVEL, J.A.Uma vs The State Of Tamil Nadu on 4 December, 2023

MR ORDER MADE IN 04.12.2023 https://www.mhc.tn.gov.in/judisA.Uma vs The State Of Tamil Nadu on 4 December, 2023

