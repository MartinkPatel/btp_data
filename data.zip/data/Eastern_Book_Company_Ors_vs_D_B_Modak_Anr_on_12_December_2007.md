Eastern Book Company & Ors vs D.B. Modak & Anr on 12
December, 2007
Equivalent citations: AIR 2008 SUPREME COURT 809, 2008 AIR SCW 49, 2008
AIHC NOC 873, 2008 CORLA(BL SUPP) 129 SC, 2008 (1) JKJ 41, 2008 (1) SCC
1, 2007 (2) COPYTR 487, 2007 (14) SCALE 191, (2008) 1 CIVILCOURTC 553,
(2008) 1 MAD LJ 361, (2008) 1 CALLT 69, (2007) 14 SCALE 191, (2008) 2 MAD
LW 278, (2008) 1 RECCRIR 415, (2008) 1 RECCIVR 599, (2008) 36 PTC 1,
(2008) 1 ANDH LT 670, (2008) 2 ANDHLD 1, (2008) 2 ICC 206
Author: P.P. Naolekar
Bench: B.N. Agrawal, P.P. Naolekar
           CASE NO.:
Appeal (civil)  6472 of 2004
PETITIONER:
Eastern Book Company & Ors.
RESPONDENT:
D.B. Modak & Anr.
DATE OF JUDGMENT: 12/12/2007
BENCH:
B.N. AGRAWAL & P.P. NAOLEKAR
JUDGMENT:
J U D G M E N T [with Civil Appeal No. 6905 of 2004 and Contempt Petition (Civil) No. 158 of 2006
in Civil Appeal No. 6472 of 2004] P.P. Naolekar, J.
1. These appeals by special leave have been preferred against the common judgment of a Division
Bench of the High Court of Delhi involving the analogous question and are, therefore, decided
together by this judgment.
2. Appellant No. 1  Eastern Book Company is a registered partnership firm carrying on the business
of publishing law books. Appellant No. 2  EBC Publishing Pvt. Ltd. is a company incorporated and
existing under the Companies Act, 1956. The said appellants are involved in the printing and
publishing of various books relating to the field of law. One of the well-known publications of
appellant No. 1  Eastern Book Company is the law report Supreme Court Cases (hereinafter
called SCC). The appellant publishes all reportable judgments along with non-reportable
judgments of the Supreme Court of India. Yet another category included in SCC is short judgments,Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

orders, practice directions and record of proceedings. The law report SCC was commenced in the
year 1969 and has been in continuous publication ever since. The name Supreme Court Cases has
been coined by the appellants and they have been using the same continuously, exclusively and
extensively in relation to the law reports published by them. For the purpose of publishing the
judgments, orders and proceedings of the Supreme Court, the copies of judgments, orders and
proceedings are procured from the office of the Registrar of the Supreme Court of India. After the
initial procurement of the judgments, orders and proceedings for publication, the appellants make
copy- editing wherein the judgments, orders and record of proceedings procured, which is the raw
source, are copy- edited by a team of assistant staff and various inputs are put in the judgments and
orders to make them user friendly by making an addition of cross-references, standardization or
formatting of the text, paragraph numbering, verification and by putting other inputs. The
appellants also prepare the headnotes comprising of two portions, the short note consisting of
catch/lead words written in bold; and the long note, which is comprised of a brief discussion of the
facts and the relevant extracts from the judgments and orders of the Court. Headnotes are prepared
by appellant No. 3-Surendra Malik. As per the said appellant (plaintiff No. 3 in the suits filed in the
Delhi High Court), the preparation of the headnotes and putting the various inputs in the raw text of
the judgments and orders received from the Supreme Court Registry require considerable amount of
skill, labour and expertise and for the said work a substantial amount of capital expenditure on the
infrastructure, such as office, equipment, computers and for maintaining extensive library, besides
recurring expenditure on both the management of human resources and infrastructural
maintenance, is made by the plaintiff- appellants. As per the appellants, SCC is a law report which
carries case reports comprising of the appellants version or presentation of those judgments and
orders of the Supreme Court after putting various inputs in the raw text and it constitutes an
`original literary work of the appellants in which copyright subsists under Section 13 of the
Copyright Act, 1957 (hereinafter referred to as the Act) and thus the appellants alone have the
exclusive right to make printed as well as electronic copies of the same under Section 14 of the Act.
Any scanning or copying or reproduction done of or from the reports or pages or paragraphs or
portions of any volume of SCC by any other person, is an infringement of the copyright in SCC
within the meaning of Section 51 of the Act.
3. The defendant-respondent No. 2 Spectrum Business Support Ltd. (in Civil Appeal No.
6472/2004) has brought out a software called Grand Jurix published on CD-ROMs and the
defendant-respondent No. 2 Regent Data Tech Pvt. Ltd. (in Civil Appeal No. 6905/2004) has
brought out software package called The Laws published on CD-ROMs. As per the appellants, all
the modules in the defendant- respondents software packages have been lifted verbatim from the
appellants work; the respondents have copied the appellants sequencing, selection and
arrangement of the cases coupled with the entire text of copy-edited judgments as published in the
plaintiff-appellants law report SCC, along with and including the style and formatting, the
copy-editing paragraph numbers, footnote numbers, cross- references, etc.; and such acts of the
defendant- respondents constitute infringement of the plaintiff- appellants exclusive right to the
same.
4. The plaintiff-appellants herein moved the Court for temporary injunction by filing applications in
Suit No.758/2000 against Spectrum Business Support Ltd. and in Suit No. 624/2000 againstEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

Regent Data Tech Pvt. Ltd. before a learned Single Judge of the High Court of Delhi. The interim
orders of injunction were passed in the suits from time to time. However, the
defendant-respondents filed application for vacation of the stay order. By a common judgment
dated 17.1.2001, the Single Judge of the High Court dismissed the appellants applications for
interim injunction and allowed the respondents application for vacation of stay. However, before
the Single Judge, the respondents conceded that the appellants have copyright in the headnotes and
as such they undertook not to copy these headnotes in their CD-ROMs.
5. Aggrieved by the said order dated 17.1.2001 refusing to grant interim injunction, the appellants
preferred appeals before a Division Bench of the Delhi High Court and the applications praying for
interim relief were also filed in both the appeals. The applications praying for the interim relief were
disposed of by the Division Bench on 9.3.2001 directing that during the pendency of the appeals the
respondents will be entitled to sell their CD- ROMs with the text of the judgment of the Supreme
Court along with their own headnotes which should not in any way be a copy of the headnotes and
the text of the plaintiff- appellants.
6. The Division Bench of the Delhi High Court heard the matters finally and has held that the
appellants are not right in submitting that although the respondents have a right to publish the raw
judgments they could do so only after obtaining the same from the original source, i.e. after
obtaining certified copy of the judgment. The Division Bench did not agree with the submission of
the appellants that by making certain corrections in the judgments or putting paragraph numbers or
arranging the said judgments in a particular manner while printing, the appellants can claim that
the copy-edited judgments become their original literary work. If the right of a person like the
appellants who are merely reporting the judgments of the courts is stretched to this extent, then
after a judgment is reported by a particular journal, others would be barred from doing the same
and the very purpose of making these judgments in public domain, therefore, would be frustrated.
The Court has further held that the appellants are not the author of the Supreme Court judgments
and by merely making certain corrections therein or giving paragraph numbers, the character of a
judgment does not change and it does not become materially different from the original judgment.
Once a person has a right to obtain certified copy of the judgment from the Registry of the Court and
to publish it, it cannot be said that he has no right to take text of the judgment from the journal
where it is already reported. The act of reproduction of any judgment or order of the Court, Tribunal
or any other judicial authority under Section 52(1)(q) of the Act, is not an infringement of the
copyright. Any person can, therefore, publish judgments of the Courts. The appellants may have
happened to have first published the judgments, but the same will not mean that they can have a
copyright therein. It is the considered opinion of the Division Bench that no person can claim
copyright in the text of the judgment by merely putting certain inputs to make it user friendly. The
appellants cannot claim copyright in the judgment of the Court. But it has been held by the Court
that reading the judgment and searching the important portions thereof and collecting sentences
from various places for the purposes of making headnotes would involve labour and skill; and that
there is originality and creativity in preparation of the headnotes, but not when they are verbatim
extracts from the judgment and, therefore, there would be copyright in the headnotes to the
judgments prepared by the appellants. So far as footnotes and editorial notes are concerned, it
cannot be denied that these are the publishers own creations and based on publishers ownEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

research and thus will have a copyright of the appellants. The Division Bench modified the judgment
of the Single Judge by directing the respondents that they shall be entitled to sell their CD-ROMs
with the text of the judgments of the Supreme Court along with there own headnotes, editorial
notes, if any, which should not in any way be copy of the headnotes of the appellants. The
respondents shall also not copy the footnotes and editorial notes appearing in the journal of the
appellants. Thus, the Court has not accepted the case of the appellants that they have a copyright in
the copy-edited judgments of the Supreme Court. Aggrieved by the decision of the Division Bench of
Delhi High Court, the appellants have filed these appeals by special leave.
7. The appellants have claimed that the copyright subsists in SCC as a law report as a whole based
cumulatively and compendiously on all the substantial contributions of skill, labour and capital in
the creation of various parts of SCC, i.e., headnotes, editorial notes, footnotes, the version of the
copy-edited text of judgments as published in the appellants law report SCC, the selection of cases
as published in SCC, the sequence and arrangement of cases as published in SCC and the index,
table of cases, etc. which are published in each volume of SCC, that give it the SCC volumes and
thereby complete SCC set, its character as a work as a whole. The appellants claim that the copyright
subsists in the copy-edited version. The appellants do not claim copyright in the raw text of the
judgments, certified copies of which are obtained from the Registry. The appellants do not claim a
monopoly in publishing judgments of the Supreme Court as they are being published by other
publishers also without copying from each other publication. The appellants claim that their
copyright is in the copy-edited version of the text of judgments as published in SCC which is a
creation of the appellants skill, labour and capital and there are contributions/inputs/ additions of
the appellants in creating their version of the text of judgments as published in SCC. The appellants
placed before us the following contributions, inputs and additions made by them to the text in the
certified copies of the judgments received by them from the Registry. The appellants assert that
originality inheres in the following aspects of its editorial process which are selected, coordinated
and arranged in such a way that the resulting work as a whole constitutes an original work of the
appellants.
MATTER ADDED PER SE TO THE RAW TEXT OF THE JUDGMENTS
1. Cross-citations are added to the citations(s) already given in the original text For example, a.
SCC/AIR/LLJ citations added in addition to the SCR citation given in the text and cross- citations
separated by : Raw text obtained from Registry:
SCC Page:
Corresponding citations from SCC Page:
R. Chitralakha and Anr. v. State of Mysore & Ors. 1964 (6) SCR 368 at 388 and
Triloki Nath v. J.& K State 1969 (1) SCR 103 at 105 and K.C. Vasanth Kumar v.
Karnataka 1985 Supp. (1) SCR 352 R. Chitralakha v.Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

State of Mysore and Triloki Nath v. State of J & K (II) and K. C. Vasanth Kumar v.
State of Karnataka.
(1964) 6 SCR 368, 388: AIR 1964 SC 1823 (1969) 1 SCR 103, 105: AIR 1969 SC 1:
(1970) 1 LLJ 1985 Supp SCC 714:
1985 Supp 1 SCR b. FCR, IA, Bom LR citations added in addition to the AIR citation
given in raw text and cross- citations separated by : Raw text obtained from
Registry:
SCC Page:
Corresponding citations from SCC Page:
Dr Hori Ram Singh vs. Emperor (AIR 1938 FC 43), Gokulchand Dwarkadas Morarka
vs. The King (AIR 1948 PC 82), Shreekantiah Ramayya Munipalli vs. State of Bombay
(AIR 1955 SC 287) Hori Ram Singh (Dr) v. Emperor, Gokulchand Dwarkadas
Morarka v. R.,Shreekantiah Ramayya Munipalli v. State of Bombay.
AIR 1939 FC 43:
1939 FCR 159 AIR 1948 PC 82: 75 IA 30 AIR 1955 SC 287:
57 Bom LR 632
2. (a) Names of cases and cross-citations are added where only the citation of the case is given in the
original text.
For example, Citation alone given in text replaced with full case name: M.P. Oil Extraction (P) Ltd.
v. State of M.P. and Jab LJ cross-citation added to AIR citation already in raw text, and separated
by : Raw text obtained from Registry:
SCC Page:
Corresponding citation from SCC Page:
The said decision has been reported in AIR 1982 M.P. 1.
The said decision has been reported in M.P. Oil Extraction (P) Ltd.
v. State of M.P. AIR 1982 MP 1: 1982 Jab LJ 795 2(b). Citations and cross-citations
are added where only name of the case is given in the original text.Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

For example Name of case in text replaced with full case reference and cross-
citations added as per SCC style.
Raw text obtained from Registry:
SCC Page:
Corresponding citation from SCC Page:
Division Bench of this Court in Kishan Lal Sharma (supra).
Division Bench of this Court in Kishan Lal Sharma.
Kishan Lal Sharma v. Prem Kishore, AIR 1983 Raj 100:
1983 Raj LR 164
d) Among the pensioners also, the above anomaly will prevail as pointed out in
Janaki Prasad.
(d) Among the pensioners also, the above anomaly will prevail as pointed out in
Janaki Prasad.
Janaki Prasad Parimoo v. State of J & K, (1973) 1 SCC 420 2(c). Citation inserted in case-history
where only the title and year of the impugned/earlier orders are given.
For example, From the Judgment and Order dated June 17, 1980 of Gujarat High Court in Special
Civil Application No. 2711 of 1999: AIR 1981 Guj 15
3. SCC style of presenting (repeatedly) cited cases For example, Changes have been made in the
name of the cited cases as per SCC style as Rattan Singhs case (supra); Mohammads case
(supra) and Range Forest Officers case in the raw text consecutively changed to Ratan Singh
case; Mohammed case and Range Forest Officer case in SCC.
Raw text obtained from Registry:
SCC Page:
In Rattan Singhs case (supra), the High Court of Madhya Pradesh finding certain
illegalities in the prosecution relating to setting aside In Mohammads case (supra),
the observation of the Kerela High Court that if a clear illegality or injustice comes
to the notice of the High Court In the third case relied on by Justice M.K. Chawla,
namely, Range Forest Officers case, a vehicle belonging to the respondent was
confiscated.Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

140. In Ratan Singh case the High Court of Madhya Pradesh finding certain illegalities in the
prosecution relating to setting aside
141. In Mohammed case, the observations of the Kerela High Court that if a clear illegality or
injustice comes to the notice of the High Court
142. In the third case relied on by Justice M.K. Chawla, namely, Range Forest Officer case a vehicle
belonging to the respondent was confiscated.
* The changes have been underlined.
4. Precise references to quoted matter are provided For example, a. The exact page and paragraph
number as in the original case source is inserted.
Raw text obtained from Registry:
SCC Page:
In Balaji it is stated:
It seems fairly clear that the backward classes of citizens for whom special provision
After referring to the provisions of Articles 338(3), 340 (1), 341 and 342, the Court
proceeded to hold as follows:
It would thus be seen that this provision contemplates that some Backward Classes
may by the Presidential order be included In Balaji it is stated: (SCR p. 458) It
seems fairly clear that the backward classes of citizens for whom special provision
After referring to the provisions of Articles 338(3), 340(1), 341 and 342, the Court
proceeded to hold as follows: (SCR p.458) It would thus be seen that this provision
contemplates that some Backward Classes may by the Presidential order be included
It may be appropriate to quote the relevant holding from the judgment:
When Art. 15(4) refers to the special provision for the advancement of certain
classes or scheduled castes or scheduled tribes, it must not be ignored that the
provision which is authorised to be made It may be appropriate to quote the relevant
holding from the judgment: (SCR pp.467, 470) When Article 15(4) refers to the
special provision for the advancement of certain classes or Scheduled Castes and
Scheduled Tribes, it must not be ignored that the provision which is authorised to be
made The Privy Council observed: It may be well to add that their Lordships
judgment does not imply that every sum paid under mistake is recoverable The Privy
Council observed: (IA p.302, para 17) It may be well to add that their Lordships
judgment does not imply that every sum paid under mistake is recoverable * The
changes have been highlighted b. The exact page and paragraph number as in the
original treatises/reference material is inserted.Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

Raw text obtained from Registry:
SCC Page:
is very instructive, Supposing, for instance, reservations were made for a
community or a collection of communities, the total of which is very instructive:
(CAD, Vol. 7, pp. 701-02) Supposing, for instance, reservations were made for a
community or a collection of communities, the total of which is a community which is
backward in the opinion of the Government.
is a community which is backward in the opinion of the Government. (CAD, Vol. 7,
pp. 702) * The changes have been highlighted.
5. Margin headings are added to quoted extracts from statutes/rules etc. when missing.
For example, Section number and Margin Heading of the Section have been supplied.
Raw text obtained from Registry:
SCC Page:
deals with sovereignty over, and limits of, territorial waters and says:
(1) The sovereignty of India extends and has always extended to the territorial
waters of India (hereinafter referred to as the territorial waters) and to the seabed
and subsoil underlying, and the air space over such waters.
deals with sovereignty over, and limits of, territorial waters and says:
. Sovereignty over, and limits of, territorial waters.-(1) The sovereignty of India
extends and has always extended to the territorial waters of India (hereinafter
referred to as the territorial waters) and to the seabed and subsoil underlying, and the
air space over such waters.
It says:
(1) All lands, minerals and other things of value underlying the ocean within the
territorial waters, or the continental shelf, or the exclusive economic zone, of India
shall vest in the Union and be held for the purpose of the Union.
It says:
97. Things of value within territorial waters or continental shelf and resources of
the exclusive economic zone to vest in the Union.- (1) All lands, minerals and otherEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

things of value underlying the ocean within the territorial waters, or the continental
shelf, or the exclusive economic zone, of India shall vest in the Union and be held for
the purpose of the Union.
That article reads as under:
9(1) All citizens shall have the right That Article reads as under:
9. Protection of certain rights regarding freedom of speech, etc.- (1) All citizens
shall have the right
6. Number of the section/rule/article/paragraph is added to the extract quoted in the original text
For example, The sub-section numbers have been added to the text.
Raw text obtained from Registry:
SCC Page:
The said provision reads as under:
Where a landlord has acquired his interest in the premises by transfer, no suit for
the recovery of possession of the premises on any of the grounds mentioned in clause
(f) or clause (ff) of The said provision reads as under:
3. (3-A) where a landlord has acquired his interest in the premises by transfer, no
suit for the recovery of possession of the premises on any of the grounds mentioned
in clause
(f) or clause (ff) of The said sub-section reads as under:
If, in the course of any trial under this Act of any offence, it is found that the accused
person has committed any other offence under this Act or any rule made thereunder
or under any other law, The said sub-section reads as under:
2. (2) If, in the course of any trial under this Act of any offence, it is found that the
accused person has committed any other offence under this Act or any rule made
thereunder or under any other law, For convenience, we reproduce the sub-section
here:
Any person who is a member of a terrorists gang or a terrorists organization, which
is For convenience, we reproduce the sub-section here:
. (5) Any person who is a member of a terrorists gang or a terrorists
organization, which is Sub-section (4) of Section 3 of TADA reads thus:Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

whoever harbours or conceals, or attempts to harbour or conceal, any terrorist shall
be punishable with imprisonment for a term which shall not be less than five years
but Sub-section (4) of Section 3 of TADA reads thus:
 3. (4) Whoever harbours or conceals, or attempts to harbour or conceal, any
terrorist shall be punishable with imprisonment for a term which shall not be less
than five years but Section 2 (1) (i) of the TADA which reads thus:-
Words and expressions used but not defined in this Act and defined in the code
shall have the meanings respectively assigned to them in the Code Indian Penal
Code by the following words in clause y of Section 2 of the Code:
words and expressions used herein and not defined but defined in the Indian Penal
Code Section 2 (1) (i) of TADA which reads thus:
. (1) (i) words and expressions used but not defined in this Act and defined in the
Code shall have the meanings respectively assigned to them in the Code Indian
Penal Code by the following words in clause y of Section 2 of the Code:
 2. (y) words and expressions used herein and not defined but defined in the Indian
Penal Code
7. Phrases like concurring, partly concurring, partly dissenting, dissenting,
supplementing, majority expressing no opinion etc. are added to the original text.
For example, Words like partly dissenting and partly concurring have been added as per the
application of Editors judgement regarding the opinions expressed by the Judges.
Raw text obtained from Registry:
SCC Page:
D.P. Wadhwa J I agree that the appeal be dismissed. However, I D. P. WADHWA, J.-
(partly concurring) I agree that the appeal be dismissed. However, I S.C. AGRAWAL
J.
Special leave granted. AGRAWAL, J. (partly dissenting)  Special leave granted.
KOSHAL, J.
On a perusal of the judgment prepared by my learned brother, Krishna Iyer, J., I
agree respectfully with findings (2) to (11), (13) and (14) enumerated by him Koshal,
J. (partly dissenting)  On a perusal of the judgment prepared by my learned brother,
Krishna Iyer, J., I agree respectfully with findings (2) to (11), (13) and (14)Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

enumerated by him
8. Judges on whose behalf opinion given: Expression such as for himself and Pathak, C.J., or
Fazal Ali and Rangnath Mishra, JJ. etc. are added to the original text.
For example, A uniform style has been mentioned by SCC to take care of the fact that which judges
have signed the Judgment.
Raw text obtained from Registry:
SCC Page:
RANGANATH MISRA, J.
We have had the benefit of reading the judgment passed The Judgments of the Court
were delivered by RANGANATH MISRA, J. (for himself and Pathak, C.J.)
(concurring) RANGANATHAN, J.
The seeds of the present controversy were sown as early as in 1946. The Judgments of
the Court were delivered by RANGANATHAN, J. (for himself and Ramaswami, J.)
- The seeds of the present controversy were sown as early as in 1946.
9. Existing paragraphs in the original text are broken up and separate paragraph numbers are given.
For example, Existing paragraph broken up into two paragraphs and separate paragraph number
added on application of editorial judgment.
Raw text obtained from Registry:
SCC Page:
but the risk involved in sacrificing efficiency of administration must always be borne
in mind when any State sets about making a provision for reservation of
appointments of posts. We see no justification to multiply the risk, which would
be the consequence of holding that reservation can be provided even in the matter of
promotion. but the risk involved in sacrificing efficiency of administration must
always be borne in mind when any State sets about making a provision for
reservation of appointments or posts. (SCR p.606)
828. We see no justification to multiply the risk, which would be the consequence
of holding that reservation can be provided even in the matter of promotion.Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

weaker segments of We, the people of India. No other understanding can reconcile the claim of a
radical present and hangover of the unjust past. A similar view was expressed in Vasant Kumar by
Chinnappa Reddy, J. The learned Judge said  the mere securing of high marks at an examination
may not necessarily mark out a good administrator.
weaker segments of We, the people of India. No other understanding can reconcile the claim of a
radical present and hangover of the unjust past.
833. A similar view was expressed in Vasanth Kumar by Chinnappa Reddy, J. The learned Judge
said (SCC p.
739, para 36) [T]he mere securing of high marks at an examination may not necessarily mark out a
good administrator.
MATTER ADDED UPON VERIFICATION
10. Internal referenceing: Use of paragaraph numbering for internal referencing within a judgment.
For example, Internal paragraph numbering has been added after uniform paragraph numbering
have been provided to the multiple judgments. Para 86, 85, 89, 90, 91 and 92 have been changed
respectively to Paras 790-793, 794 and 797, 798, 799, 800 and 801 to 803.
Raw text obtained from Registry:
SCC Page:
(d) Creamy layer can be, and must be excluded. (Para
86)
(e) It is not correct to say that the backward class, social, educational and economic
backwardness are closely inter-twined in the Indian context. (Para 85)
(f) The adequacy of representation of a particular class in the services under the State
is a matter within the subjective satisfaction of the appropriate Government.
The judicial scrutiny in that behalf is the same as in other matters within the subjective satisfaction
of an authority. (Para 89) (4) (a) A backward class of citizens cannot be identified only and
exclusively with reference to economic criteria. (Para 90)
(b) It is, of course, permissible for the Government or other authority to identify a backward class of
citizens on the basis of occupation-cum-income, without reference to caste, if it is so advised. (ParaEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

91) (5) There is no constitutional bar to classify the backward classes of citizens into backward and
more backward categories.
(Para 92)
(d) Creamy layer can be, and must be excluded.(Paras 790-793)
(e) It is not necessary for a class to be designated as a backward class that it is situated similarly to
the Scheduled Castes/ Scheduled Tribes. (Paras 794 and 797)
(f) The adequacy of representation of a particular class in the services under the State is a matter
within the subjective satisfaction of the appropriate Government.
The judicial scrutiny in that behalf is the same as in other matters within the subjective satisfaction
of an authority. (Para 798) (4) (a) A backward class of citizens cannot be identified only and
exclusively with reference to economic criteria. (Para
799)
(b) It is, of course, permissible for the Government or other authority to identify a backward class of
citizens on the basis of occupation-
cum-income, without reference to caste, if it is so advised. (Para 800) (5) There is no constitutional
bar to classify the backward classes of citizens into backward and more backward categories. (Para
801 to
803)
11. Verification of first word of quoted extract and emphasis supplied on verification.
For example, Raw text obtained from Registry:
SCC Page:
The Rajasthan High Court in CIT v Rangnath Bangur opined:
.that once a reassessment proceeding is initiated, the original order of assessment
is set aside or ceases to be operative. The finality of such an assessment order is
wiped out and a fresh order of assessment would take the place of and completely
substitute the initial order of assessment. It is, therefore, clear that when The
Rajasthan High Court in CIT v. Rangnath Bangur opined: (p.498) [T]hat once a
reassessment proceeding is initiated, the original order of assessment is set aside or
ceases to be operative. The finality of such an assessment order is wiped out and a
fresh order of assessment would take the place of and completely substitute the initialEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

order of assessment. It is, therefore, clear that when and said:
reassessment proceedings cannot be contained only to such income which has
escaped assessment, but the entire assessment and said: (p. 503) [R]eassessment
proceedings cannot be confined only to such income which has escaped assessment,
but the entire assessment Five Judges:
the Constitution is the fundamental law of the land and it is wholly unnecessary to
provide in any law made by the legislature that anything done in disregard of the
Constitution is prohibited. Such a prohibition is to be read in every enactment.
[T]he Constitution is the fundamental law of the land and it is wholly unnecessary
to provide in any law made by the legislature that anything done in disregard of the
Constitution is prohibited. Such a prohibition is to be read in every enactment.
(emphasis supplied)
12. Ellipsis  is added to indicate breaks in quoted extract.
For example, Raw text obtained from Registry:
SCC Page:
, he has said that the word caste appearing after scheduled is really a
misnomer and has been used only for the purpose of identifying this
165), he has said that the word caste appearing after scheduled is really a
misnomer and has been used only for the purpose of identifying this Gajendragadkar,
J observed:
Though castes in relation to Hindus may be a relevant factor to consider in
determining the social backwardness of groups or classes of citizens, it cannot be the
sole or the dominant test in that behalf. Gajendragadkar, J. observed:
though castes in relation to Hindus may be a relevant factor to consider in
determining the social backwardness of groups or classes of citizens, it cannot be
made the sole or the dominant test in that behalf. manner as may be prescribed
duties of excise on all excisable goods which are produced or manufactured in India
as, and at the rates, set forth in the Schedule to the Central Excise Tariff Act, 1985.
manner as may be prescribed duties of excise on all excisable goods which are
produced or manufactured in  India as, and at the rates, set forth in the Schedule to
the Central Excise Tariff Act, 1985.
13. Matter inadvertently missed in quoted extracts is supplied.Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

For example, Incorporation of matter missing in quotations from cases.
Raw text obtained from Registry:
SCC Page:
Where there is no express exclusion the examination of the remedies and the scheme
of the particular Act to find out the intendment becomes necessary to see if the
statute creates a special right or a liability and provides for the determination of the
right Where there is no express exclusion the examination of the remedies and the
scheme of the particular Act to find out the intendment becomes necessary and the
result of the inquiry may be decisive. In the latter case Mr Justice M.K. Chawla
holding that parties have no locus standi.
Mr Justice M.K. Chawla holding that Mr. H.S. Chowdhary and other intervening
parties have no locus standi.
8. State to secure a social order for the promotion of welfare of the people. (1) The
State shall strive to promote the welfare of the people by securing and protecting as
effectively as it may a social, economic and political, shall inform all the institutions
of the national life.
 38. State to secure a social order for the promotion of welfare of the people.- (1) The
State The State shall strive to promote the welfare of the people by securing and
protecting as effectively as it may a social order in which justice, social, economic and
political, shall inform all the institutions of the national life.
The inputs of efficiency include a sense of belonging and of accountability (not pejoratively used) if
its composition takes in also the weaker segments of we, the people of India.
The inputs of efficiency include a sense of belonging and of accountability which springs in the
bosom of the bureaucracy (not pejoratively used) if its composition takes in also the weaker
segments of We, the people of India.
It is no doubt true that the Act was amended by U.P. Act 26 of 1975 which came into force on
August 18, 1975 taking away the power of the Director to make an appointment under Section 16 F
(4) of the Act in the case of minority institutions. The amending Act did not, however, provide
proceedings under Section 16 F of the Act.
It is no doubt true that the Act was amended by U.P. Act 26 of 1975 which came into force on
August 18, 1975 taking away the power of the Director to make an appointment under Section
16-F(4) of the Act in the case of minority institutions. The amending Act did not, however, provide
expressly that the amendment in question would apply to pending proceedings under Section 16-F
of the Act.Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

* The changes have been underlined.
14. Incomplete/incorrect case names or citations are completed/corrected.
For example, Corrections in the case names.
Raw text obtained from Registry:
SCC Page:
In R v. Greater London Council 1976 (3) ALL ER 184, one Albert Raymond Blackburn
73. In R v. Greater London Council, ex parte Blackburn, one Albert Raymond
Blackburn Ray, C.J. in State of Uttar Pradesh v. Pradeep Tandon and Ors. 1975 (2)
SCR 761 at 766 has gone to the extent of saying that:
47. Ray, CJ in State of U.P. v. Pradip Tandon has gone to the extent of saying that:
(SCC pp. 273-74, para 15) Reference may be made to (1) Hindustan Zinc V. A.P. State
Electricity Board 1991 (3) SCC 299; (2) Sitaram Sugars V. Union of India and Others
1990 (3) SCC 223; (3) D.C.M. v. S. Paramjit Singh 1990 (4) SCC 723; (4) Minerva
Talkies V. State of Karnataka and Others 1988 Suppl SCC 176;
(5) State of Karnataka V. Ranganath Reddy 1978 (1) SCR 641; (6) Kerala State
Electricity Board V. S.N. Govind Prabhu 1986 (4) SCC;
(7) Prag Ice Company V. Union of India and Others 1978 (2) SCC 458; (8)
Sarawaswati Industries Syndicate Ltd. V. Union of India 1975 (1) SCR 956; (9) Murti
Match Works V. Assistant Collector, Central Excise and Others 1974 (3) SCR 121; (10)
T. Govindraja Mudaliar V. State of Tamil Nadu and Others 1973 (3) SCR 222; and
(11) Narender Kumar V. Union of India and Others 1969 (2) SCR 375.
Reference may be made to :
(1) Hindustan Zinc Ltd. v.
A.P. State Electricity Board; (2) Shri Sitaram Sugar Co. Ltd. v. Union of India; (3) Delhi Cloth and
General Mills Ltd. v. S. Paramjit Singh; (4) Minerva Talkies v. State of Karnataka; (5) State of
Karnataka v. Ranganath Reddy; (6) Kerela State Electricity Board v.
S.N.Govinda Prabhu and Bros.; (7) Prag Ice and Oil Mills v. Union of India; (8) Saraswati Industries
Syndicate Ltd. v. Union of India; (9) Murthy Match Works v. Assistant Collector, Central Excise;
(10) T. Govindaraja Mudaliar v. State of T.N. and (11) Narender Kumar v. Union of India.Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

* The changes have been underlined.
15. Other corrections For example, a. Clauses numbered in terms of answers to questions framed by
learned Judge have been renumbered correctly in terms of questions framed, as (3)(e) actually has
been found to be answer to (3) (c) and vice-versa.
a1. Similarly, clause has been changed to sub- clause.
Raw text obtained from Registry:
SCC Page:
(c) It is not necessary for a class to be designated as a backward class that it is
situated similarly to the Schedule Castes/Tribes.
(Paras 87 and 88)
(d) Creamy layer can be, and must be excluded. (Para.
86)
(e) It is not correct to say that the backward class of citizen contemplated in Article 16 (4) is the
same as the socially and educationally backward classes referred to in Article 15(4). It is much wider.
The accent in Article 16(4) is on social backwardness. Of course, social, educational and economic
backwardness are closely inter-twined in the Indian context.
(c) It is not correct to say that the backward class of citizen contemplated in Article 16 (4) is the
same as the socially and educationally backward classes referred to in Article 15(4). It is much wider.
The accent in Article 16(4) is on social backwardness. Of course, social, educational and economic
backwardness are closely inter-twined in the Indian context. (Paras 786-
789)
(d) Creamy Layer can be, and must be excluded. (790-
793)
(e) It is not necessary for a class to be designated as a backward class that it is situated similarly to
the Schedule Castes/ Schedule Tribes. (Paras 794 and 797) that no better formula could be produced
than the one that is embodied in clause (3) of Article 10 of the Constitution; they will find that the
view of those who believe and hold that there shall be that no better formula could be produced than
the one that is embodied in sub-Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

clause (3) of Article 10 of the Constitution; they will find that the view of those who believe and hold
that there shall be
16. Text has been changed as per corrigenda issued, which have been issued upon SCC Editors
request and suggestions.
For example, SUPREME COURT OF INDIA Corrigendum This Courts order dated October 25,
1996 in CA 14553/96 @ SLP ) No. 5570/93 in the matter of Smt. Indira Sohan Lal (Dead) by LRs.
Vs. Union of India
-----------------------------------------------------------
Page No.    Line No.        For                  Read
1    bottom line        and deducted         deducted
2   7-8 from bottom     developed to bring    developed  to
on par with levelled bring them on land and huge levelled land and a huge 3 12-13 from bottom
compelling material, compelling nor the High Court material and refused to advert High Courts to
refusal to advert to it,
----------------------------------------------------------------
OTHER ADDITIONS/INSERTIONS MADE TO THE RAW TEXT
17. Compressing/simplification of information relating to case history.
For example Raw text obtained from Registry:
SCC Page:
CIVIL APPEAL NOS. 999-1005 OF [ARISING OUT OF S.L.P. (C) NOS. 18380- 86 OF
1996] WITH CIVIL APPEAL NOS. 1006-1316 OF 1997 [ARISING OUT OF S.L.P. (C)
NOS.
20293/96, 20662/96, 21726/96, 21824- 26/96, 22224-502/96, 22771/96, 23196- 97/96, 23199/96,
23700-703/96, 23744/96,23747-48/96, 23761/96, 23763/96, 23766/96, 23775-76/96,
24285/96,24315/96,24320-22/96, 24325- 26/96, 24328-29/96 & 24224/96 WITH
INTERLOCUTORY APPLICATION NO.1 IN CIVIL APPEALS [ARISING OUT OF S.L.P.(C)NOS.
24224/96,24285/96,24315/96,24320- 22/96, 24325-26/96 & 24328-29/96.
Civil Appeals Nos.Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

999 to 1316 of 1997 with I.A. No. 1 in C.As. arising out of SLPs. (C) Nos.
24224, 24285, 24315, 24320-22, 24325-26 and 24328-29 of 1996, decided on February 20, 1997.
passed by Madhya Pradesh High Court respectively in Misc. Petitions No. 1371 of 1992 M.P. No.
1980 of 1992 and M.P. No. 2315 of 1992. All the said Misc. Petitions were filed before the Madhya
Pradesh High Court under Article 226 of the Constitution.
passed by Madhya Pradesh High Court respectively in Miscellaneous Petitions Nos. 1371, 1980 and
2315 of 1992. All the said miscellaneous petitions were filed before the Madhya Pradesh High Court
under Article 226 of the Constitution * The changes have been underlined.
(SCC HAS UNIQUE STYLE)
18. There are certain norms followed at SCC for giving case names.
For example, Raw text obtained from Registry:
SCC Page:
Budh Prakash Jai Prakash v. Sales Tax Officer, Kanpur [1952 A.L.J. 332] Budh
Prakash Jai Prakash v. STO Indian Aluminium Cables Limited vs. State of Haryana
Indian Aluminium Cables Ltd. v. State of Haryana Trilok Nath Tiku & Another v.
State of Jammu & Kashmir and Others Triloki Nath Tiku v. State of J & K (I) R.
Chitralekha and Anr. v. State of Mysore & Ors. 1964 (6) SCR 368 at 388 and Triloki
Nath v. J & K State 1969 (1) SCR 103 at 105 and K.C. Vasanth Kumar v.
Karnataka 1985 Supp. (1) SCR R. Chitralekha v. State of Mysore and Triloki Nath v.
State of J & K (II) and K.C. Vasanth Kumar v. State of Karnataka Minor P. Rajendran V. State of
Madras & Ors. 1968 (2) SCR 786 at 790 P. Rajendran v. State of Madras State of Andhra Pradesh V.
P. Sagar 1968 (3) SCR 595 State of A.P. v. P. Sagar K.S. Venkataraman and Bharat Kala Bhandar
Ltd. v. M.C. Dhamangaon K.S. Venkataramanan and Bharat Kala Bhandar Ltd. v.
Municipal Committee
19. Words like Section, Sec., Rule etc. are omitted, and only the number of the Section/Rule is
given at the beginning of the quoted extract.
Raw text obtained from Registry:
SCC Page:Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

Sec 2 (h). terrorist act has the meaning assigned to it in sub-section (1) of Section
3, and the expression terrorist shall be construed accordingly;  (h) terrorist
act has the meaning assigned to it in sub-section (1) of Section 3, and the expression
terrorist shall be construed accordingly; Rule 11. No refund of duties or charges
erroneously paid, unless claimed within three months -- No duties or charges which
have been paid or have been adjusted in an account current maintained with the
Collector 1. No refund of duties or charges erroneously paid, unless claimed within
three months.-- No duties or charges which have been paid or have been adjusted in
an account current maintained with the Collector RULE 233B. Procedure to be
followed to cases where duty is paid under protest.-- (1) Where an assessee desires to
pay duty under protest he shall deliver to the proper officer a letter to this 33-B.
Procedure to be followed in cases where duty is paid under protest. (1) Where an
assessee desires to pay duty under protest he shall deliver to the proper officer a
letter to this
20. Margin heading and the first clause/sub-section or initial matter of section/rule etc. is made to
run-on, instead of being let to start from a fresh line.
Raw text obtained from Registry:
SCC Page:
Liability of person to whom money is paid or thing delivered by mistake or under
coercion-- 72. A person to whom money has been paid, or anything delivered, by
mistake or under coercion, must repay or return it. 2. Liability of person to whom
money is paid or thing delivered, by mistake or under coercion.-- A person to whom
money has been paid, or anything delivered, by mistake or under coercion, must
repay or return it.
Sec 424. Refund of automobile accessories tax.
(a) No refund shall be made of any amount paid by or collected from any manufacturer, producer, or
importer in respect 24. Refund of automobile accessories tax.  (a) No refund shall be made of
any amount paid by or collected from any manufacturer, producer, or importer in respect Section 3,
which is the charging Section, reads:-
. Duties specified in the Schedule to the Central Excise Tariff Act, 1985 to be levied.
(1) There shall be levied and collected in such manner as may be prescribed duties
175. Section 3, which is the charging section, reads:
. Duties specified in the Schedule to the Central Excise Tariff Act, 1985 to be levied.
- (1) There shall be levied and collected in such manner as may be prescribed dutiesEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

21. Compressing of unquoted referends and use of *** for such parts.
Raw text obtained from Registry:
SCC Page:
six months, the words five years were substituted.
Explanation
(ii)relevant date- means,
(a) in the case of excisable goods on which duty of excise has not been levied or paid
or has been short- levied or short-paid
(c) in any other case, the date on which the duty is to be paid under this Act or the
rules made thereunder;
six months, the words five years were substituted.
Explanation.--
(1)-(2) * * * (3) (i) * * *
(ii) relevant date means,
--
(a) in the case of excisable goods on which duty of excise has not been levied or paid or has been
short-levied or short-paid
(c) in any other case, the date on which the duty is to be paid under this Act or the rules made
thereunder,
(i)..
(ii)..
(iii) where the landlord of any building is (1) a serving or retired Indian Soldier as defined in the
Indian Soldiers (Litigation) Act, 1925 (IV of 1925) and such building was let out at any time before
his retirement, or (2)  and such landlord needs such building for occupation by himself
or the members of his family for residential purposes,
(i)-(ii) * * *Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

(iii) where the landlord of any building is-
(1) a serving or retired Indian Soldier as defined in the Indian Soldiers (Litigation) Act, 1925 (IV of
1925), and such building was let out at any time before his retirement, or (2) * * * and such landlord
needs such building for occupation by himself or the members of his family for residential purposes,
22. Series of dots in the raw texts (i.e., ..) are replaced with ellipsis (i.e., ).
Raw text obtained from Registry:
SCC Page:
so to say into the administration.that no better formula could be produced
than the one that is embodied in clause (3) of Article 10 of the Constitution; they will
find that the view of those who believe and hold that there shall be equality of
opportunity has been embodied in sub-clause (1) of Article
10. It is a generic principle  Supposing for instance, we are to concede in full
the demand of those communities who have not been so far employed in the public
services to the fullest extent, what would really happen is, we shall be completely
destroying the first proposition upon which we are all agreed, namely, that there shall
be in an equality of opportunity.I am sure they will agree that unless you use some
such qualifying so to say into the administration that no better formula could be
produced than the one that is embodied in sub-clause (3) of Article 10 of the
Constitution; they will find that the view of those who believe and hold that there
shall be equality of opportunity, has been embodied in sub-clause (1) of Article 10. It
is a generic principle.
Supposing for instance, we are to concede in full the demand of those communities who have not
been so far employed in the public services to the fullest extent, what would really happen is, we
shall be completely destroying the first proposition upon which we are all agreed, namely, that there
shall be in an equality of opportunity. I am sure they will agree that unless you use some such
qualifying
23. Removal of abbreviations: sec., R. and cl. are substituted respectively with Section, Rule or
clause.
Raw text obtained from Registry:
SCC Page:
Having regard to the object and language of s. 34 of the I.T. Act, 1922, s. 147 of the
I.T. Act, 1961, and s. 8 of the Surtax Act, 1964, the reopening of an assessment can
only be for the benefit of the Revenue subject to one exception, Having regard to theEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

object and language of Section 34 of the I.T. Act, 1922, Section 147 of the I.T. Act,
1961, and Section 8 of the Surtax Act, 1964, the reopening of an assessment can only
be for the benefit of the Revenue subject to one exception,  it would not be in
accordance either with cl. (1) of Art. 15 or cl. (2) of Art. 29 to require the
consideration of the castes of persons to be borne in mind for determining what are
socially and educationally backward classes. It is true that cl. (4) of Art. 15 contains a
non-obstante clause with the result  it would not be in accordance either with
clause (1) of Article 15 or clause (2) of Article 29 to require the consideration of the
castes of persons to be borne in mind for determining what are socially and
educationally backward classes. It is true that clause (4) of Article 15 contains a
non-obstante clause with the result * The changes have been underlined.
24. Hyphenation has been added after the section/rule numbers, which have alphabets, suffixed to
them.
Raw text obtained from Registry:
SCC Page:
SCOPE OF SECTIONS 11B, 11D, 12A, 12B, 12C AND 12D OF THE CENTRAL EXCISE
ACT, 1944 Sections 11B and 11D in Chapter II and Sections 12A, 12B, 12C and 12D in
Chapter II-A are now to be considered:-
1B. Claim for refund of duty (1) Any person claiming refund of any duty of excise
may make an application for refund of such duty to the Assistant Commissioner of
Central Excise before the Scope of Sections 11-B, 11-
D, 12-A, 12-B, 12-C and 12-D of The Central Excises and Salt Act, 1944 Sections 11-B and 11-D in
Chapter II and Sections 12-A, 12-B, 12-C and 12-D in Chapter II-A are now to be considered:
1B. Claim for refund of duty.- (1) Any person claiming refund of any duty of excise
may make an application for refund of such duty to the Assistant Collector of Central
Excise before the * The changes have been underlined.
25. Indentation For example SCC style of presentation of quoted extracts in separate indented
paragraphs applied to raw text.
Raw text obtained from Registry SCC Page As Chinnappa Reddy, J. in Vasanth Kumar has rightly
observed, Always one hears the word efficiency as if it is sacrosanct and the sanctorum has to be
fiercely guarded. Efficiency is not a mantra which is whispered by the Guru in the Sishyas ear.
57. As Chinnappa Reddy, J.
in Vasanth Kumar has rightly observed: (SCC p.739, paraEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

36) Always one hears the word efficiency as if it is sacrosanct and the sanctorum has to be
fiercely guarded.
Efficiency is not a mantra which is whispered by the Guru in the Sishyas ear.
26. Removal of full stops or removal of word No..
Raw text obtained from Registry:
SCC Page:
The appellant says that each of these R.S.Os. maintains an office, a stock yard and
other necessary paraphernalia for receiving, stocking, repairing and delivering motor
vehicles to their customers. The appellant says that almost seventy percent of its sales
are to parties other than State Transport Undertakings S.T.Us. The sales to S.T.Us.,
are in the region of thirty percent of its production. The R.S.Os., the appellant says,
contact the local purchasers and the S.T.Us., book the order and also deliver the
vehicles to them pursuant to sales effected by them. The appellant always keeps the
R.S.Os. well stocked having regard to their requirements. By way of illustration, it is
stated, the R.S.O. at Hyderabad The appellant says that each of these RSOs maintains
an office, a stock yard and other necessary paraphernalia for receiving, stocking,
repairing and delivering motor vehicles to their customers. The appellant says almost
seventy per cent of its sales are parties other than State Transport Undertakings
(STUs). The sales to STUs are in the region of thirty per cent of its production.
The RSOs, the appellant says, contact the local purchasers and the STUs book the orders and also
deliver the vehicles to them pursuant to sales effected by them. The appellant always keeps the RSOs
well stocked having regard to their requirements. By way of illustration, it is stated, the RSO at
Hyderabad All the three special leave petitions namely S.L.P. (Civil) No. 19279 of 1995, S.L.P. (Civil )
No. 20137 of 1995 and S.L.P. (Civil ) No. 19796 of 1995 are directed against common judgment dated
9.5.1995
2. All the three special leave petititions namely SLP (Civil) No. 19729 of 1995, SLP (Civil ) No. 20137
of 1995 and SLP (Civil ) No. 19796 of 1995 are directed against common judgment dated 9-5-1995 *
The changes have been underlined.
27. Giving full forms of abbreviations to enhance readability and clarity.
Raw text obtained from Registry:
SCC Page:
from legal consequences and therefore, they are also guilty of the offence u/s 201 IPC.Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

from legal consequences and therefore, they are also guilty of the offence under
Section 201 IPC. * The changes have been underlined.
In addition to the above, capitalization and italicization is made wherever necessary
in the raw text; and punctuation, articles, spellings and compound words are also
checked and corrected, if required, in the original text.
8. The copyright protection finds its justification in fair play. When a person
produces something with his skill and labour, it normally belongs to him and the
other person would not be permitted to make a profit out of the skill and labour of
the original author and it is for this reason the Copyright Act, 1957 gives to the
authors certain exclusive rights in relation to the certain work referred in the Act. The
object of the Act is to protect the author of the copyright work from an unlawful
reproduction or exploitation of his work by others. Copyright is a right to stop others
from exploiting the work without the consent or assent of the owner of the copyright.
A copyright law presents a balance between the interests and rights of the author and
that of the public in protecting the public domain, or to claim the copyright and
protect it under the copyright statute. One of the key requirements is that of
originality which contributes, and has a direct nexus, in maintaining the interests of
the author as well as that of public in protecting the matters in public domain. It is a
well-accepted principle of copyright law that there is no copyright in the facts per se,
as the facts are not created nor have they originated with the author of any work
which embodies these facts. The issue of copyright is closely connected to that of
commercial viability, and commercial consequences and implications.
9. The development of copyright law in India is closely associated with the British
copyright law. Statute of Anne, the first Copyright Act in England, was passed in 17th
century which provided that the author of any book already printed will have the sole
right of printing such book for a term mentioned therein. Thereafter, came the Act of
1814, and then the Act of 1842 which repealed the two earlier Acts of 1709 and 1814.
The Copyright Act of 1911 in England had codified and consolidated the various
earlier Copyright Acts on different works. Then came the Copyright Act of 1956. In
India, the first Copyright Act was passed in 1914. This was nothing but a copy of the
Copyright Act of 1911 of United Kingdom with suitable modifications to make it
applicable to the then British India. The Copyright Act of 1957, which is the current
statute, has followed and adopted the principles and provisions contained in the U.K.
Act of 1956 along with introduction of many new provisions. Then came the
Copyright (Amendment) Act, 1983 which made a number of amendments to the Act
of 1957 and the Copyright (Amendment) Act, 1984 which was mainly introduced with
the object to discourage and prevent the widespread piracy prevailing in video films
and records. Thereafter, the Copyright (Amendment) Act, 1994 has effected many
major amendments in the Copyright Act of 1957.Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

10. In the present case, the questions which require determination by the Court are :
(1) What shall be the standard of originality in the copy-edited judgments of the
Supreme Court which is a derivative work and what would be required in a derivative
work to treat it the original work of an author and thereby giving a protected right
under the Copyright Act, 1957 to the author of the derivative work ? and (2) Whether
the entire version of the copy-edited text of the judgments published in the
appellants law report SCC would be entitled for a copyright as an original literary
work, the copy-edited judgments having been claimed as a result of inextricable and
inseparable admixture of the copy-editing inputs and the raw text, taken together, as
a result of insertion of all SCC copy-editing inputs into the raw text, or whether the
appellants would be entitled to the copyright in some of the inputs which have been
put in the raw text ?
11. Copyright is purely a creation of the statute under the 1957 Act. What rights the
author has in his work by virtue of his creation, are defined in Sections 14 and 17 of
the Act. These are exclusive rights, but subject to the other provisions of the Act. In
the first place, the work should qualify under the provisions of Section 13, for the
subsistence of copyright. Although the rights have been referred to as exclusive
rights, there are various exceptions to them which are listed in Section 52.
12. We are mainly concerned for the purpose of these appeals with Sections 2 [clauses
(k), (o), (y)], 13(1), 14(1)(a), 17, proviso (d) and 52(1)(q)(iv) of the Copyright Act,
1957. The relevant provisions of these Sections are as under:
. Interpretation.- In this Act, unless the context otherwise requires, -
xxx xxx xxx
(k) "Government work" means a work which is made or published by or under the
direction or control of -
(i) the Government or any department of the Government;
(ii) any Legislature in India;
(iii) any Court, Tribunal or other judicial authority in India; xxx xxx xxx (o) "literary work"
includes computer programmes, tables and compilations including computer databases; xxx xxx
xxx (y) "work" means any of the following works, namely:-
(i) a literary, dramatic, musical or artistic work;
(ii) a cinematograph film;Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

(iii) a sound recording; 3. Works in which copyright subsists. - (1) Subject to the
provisions of this section and the other provisions of this Act, copyright shall subsist
throughout India in the following classes of works, that is to say, -
(a) original literary, dramatic, musical and artistic works;
(b) cinematograph films; and
(c) sound recording, (2) Copyright shall not subsist in any work specified in sub-section (1), other
than a work to which the provisions of section 40 or section 41, apply, unless -
(i) in the case of a published work, the work is first published in India, or where the work is first
published outside India, the author is at the date of such publication, or in a case where the author
was dead at that date, was at the time of his death, a citizen of India;
(ii) in the case of an unpublished work other than a work of architecture, the author is at the date of
the making of the work a citizen of India or domiciled in India; and
(iii) in the case of a work of architecture, the work is located in India.
Explanation.- In the case of a work of joint authorship, the conditions conferring copyright specified
in this sub-section shall be satisfied by all the authors of the work.
(3) Copyright shall not subsist -
(a) in any cinematograph film if a substantial part of the film is an infringement of the copyright in
any other work;
(b) in any sound recording made in respect of a literary, dramatic or musical work, if in making the
sound recording, copyright in such work has been infringed.
xxx xxx xxx 4. Meaning of copyright.  (1) For the purposes of this Act, "copyright" means the
exclusive right, subject to the provisions of this Act, to do or authorise the doing of any of the
following acts in respect of a work or any substantial part thereof, namely:-
(a) in the case of a literary, dramatic or musical work, not being a computer
programme, -
(i) to reproduce the work in any material form including the storing of it in any
medium by electronic means;
(ii) to issue copies of the work to the public not being copies already in circulation;
(iii) to perform the work in public, or communicate it to the public;Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

(iv) to make any cinematograph film or sound recording in respect of the work;
(v) to make any translation of the work;
(vi) to make any adaptation of the work;
(vii) to do, in relation to a translation or an adaptation of the work, any of the acts
specified in relation to the work in sub-clauses (i) to (vi);
xxx xxx xxx 7. First owner of copyright.- Subject to the provisions of this Act, the
author of a work shall be the first owner of the copyright therein:
Provided that -
xxx xxx xxx
(d) in the case of a Government work, Government shall, in the absence of any
agreement to the contrary, be the first owner of the copyright therein;
xxx xxx xxx 2. Certain acts not to be infringement of copyright.- (1) The following
acts shall not constitute an infringement of copyright, namely:
-
(a) .
xxx xxx xxx
(q) the reproduction or publication of -
(i)      
xxx                        xxx               xxx
(iv)    any judgment or order of a 
Court, Tribunal or other judicial authority, unless the reproduction or publication of
such judgment or order is prohibited by the Court, the Tribunal or other judicial
authority, as the case may be;
xxx xxx xxx
13. Subject to the provisions of Section 13 and the other provisions of the Act, there
shall be a copyright throughout India in original literary work, dramatic, musical and
artistic works, cinematograph films and sound recording, subject to the exceptions
provided in sub-Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

sections (2) and (3) of Section 13. For copyright protection, all literary works have to be original as
per Section 13 of the Act. Broadly speaking, there would be two classes of literary works : (a)
primary or prior works:
These are the literary works not based on existing subject- matter and, therefore,
would be called primary or prior works; and (b) secondary or derivative works: These
are literary works based on existing subject-matter. Since such works are based on
existing subject-matter, they are called derivative work or secondary work. Work is
defined in Section 2(y) which would be a literary, dramatic, musical or artistic work;
a cinematograph film; and a sound recording. Under Section 2(o), literary work
would include computer programmes, tables and compilations including computer
databases. For the purposes of the Act, Section 14(1) enumerates what shall be a
copyright which is an exclusive right, subject to the provisions of the Act, to do or
authorize the doing of the acts provided in clauses
(i) to (vii) in respect of a work or any substantial part thereof in the case of a literary,
dramatic or musical work, not being a computer programme. Section 2(k) defines the
`government work which would be a work which is made or published by or under
the direction or control of, amongst others, any Court, Tribunal or other judicial
authority in India. By virtue of this definition, the judgments delivered by the
Supreme Court would be a government work. Under Section 17(d), the Government
shall, in the absence of any agreement to the contrary, be the first owner of the
copyright in a government work. In the absence of any agreement to the contrary, the
government shall be the first owner of the copyright in the judgments of the Supreme
Court, the same being a government work under Section 2(k). Section 52(1) expressly
provides that certain acts enumerated therein shall not constitute an infringement of
copyright and sub-clause (iv) of clause
(q) excludes the reproduction or publication of any judgment or order of a Court,
Tribunal or other judicial authority, unless the reproduction or publication of such
judgment or order is prohibited by the Court, the Tribunal or other judicial authority
from copyright. The judicial pronouncements of the Apex Court would be in the
public domain and its reproduction or publication would not infringe the copyright.
The reproduction or publication of the judgments delivered by the Supreme Court by
any number of persons would not be infringement of a copyright of the first owner
thereof, namely, the Government, unless it is prohibited. The question, therefore, is
whether by introducing certain inputs in a judgment delivered by a court it becomes
original copy-edited judgment and the person or authority or company who did so
could claim to have embodied the originality in the said judgment and the judgment
takes the colour of original judgment having a copyright therein of its publisher.
14. In many cases, a work is derived from an existing work. Whether in such a derivative work, a
new copyright work is created, will depend on various factors, and would one of them be only skill,
capital and labour expended upon it to qualify for copyright protection in a derivative literary workEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

created from the pre-existing material in the public domain, and the required exercise of
independent skill, labour and capital in its creation by the author would qualify him for the
copyright protection in the derivative work. Or would it be the creativity in a derivative work in
which the final position will depend upon the amount and value of the corrections and
improvements, the independent skill & labour, and the creativity in the end-product is such as to
create a new copyright work to make the creator of the derivative work the author of it; and if not,
there will be no new copyright work and then the original author will remain the author of the
original work and the creator of the derivative work will have been the author of the alterations or
the inputs put therein, for their nature will not have been such as to attract the protection under the
law of copyright.
15. It is submitted by Shri Raju Ramachandran, learned senior counsel for the appellants that
Section 52(1)(q)(iv) of the Act does not bar the recognization of copyright in the copy-edited version
of the text of judgments of the courts as published in law reports. The Government is the first owner
of copyright in the judgments of the courts as per Section 2(k) read with Section 17 and Section
52(1)(q)(iv) of the Act provides that any person wanting to reproduce or publish judgments would
not infringe the copyright of the Government, but Section 52(1)(q)(iv) does not imply that in case a
person has expended independent skill, labour and capital on the judgments of the courts to create
and publish his version of the judgments, any other person is free to copy that persons version of
the judgments, substantially or in its entirely. Copyright subsists in the copy-edited version of the
text of judgments of the courts as published in law reports, which have been created by the
application of skill, labour and capital which is not trivial or negligible. The inputs put in the
copy-edited judgments in SCC, is a derivative literary work created from pre- existing material of the
judgments of the court which is in public domain. The exercise of independent skill, labour and
capital in its creation by the author of such work, and the derivative literary work created by the
expenditure of the independent skill, labour and capital of the appellants gives them copyright in
such creations. It is not necessary that work created should have a literary merit. The courts can
only evaluate whether the skill, labour and capital actually employed, required in creating the work,
is not trivial or negligible. It is further urged by the learned senior counsel that in deciding whether
a derivative work qualifies for copyright protection, it must be considered as a whole, and it is not
correct to dissect the work into fragments and consider the copyrightability of each such fragment
piecemeal and individually apart from the whole. He submits that the respondents if wish to
reproduce or publish a work already in public domain is obliged to go to the public domain/common
source of such work rather than misappropriating the effort and investment of the appellants by
copying the version of such work which was created by them by independent expenditure of skill,
labour and capital. To buttress his submissions, the learned senior counsel placed reliance on
various foreign judgments and judgments of the Indian High Courts which are considered
hereinafter.
16. Ladbroke (Football) Ltd. v. Willim Hill (Football) Ltd., [1964] 1 WLR 273 (HL), is a case where
the concept of originality was considered on the basis of skill, judgment and/or labour in the context
of compilation. Since 1951 the respondents, who were well- known bookmakers, had sent their
customers each week fixed odds football betting coupons arranged in a certain general form. In 1959
the appellants, who were also bookmakers, started sending out coupons closely resembling theEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

respondents coupons. A coupon was a sheet of paper on which were printed several lists of
forthcoming matches. Beside each list were columns of squares on which the punter could indicate
his forecast of the result of each match. Some of the lists included all the matches to be played;
others included only a selection of them. The bets varied in character. A great variety of bets was
offered and the odds offered differed widely from 5-2 to 20,000-1. The respondents coupon
contained 16 lists, each with an appropriate name. The appellants coupon, which contained 15 lists,
closely resembled the respondents. The lists offered by the appellants were almost identical with
those offered by the respondents in their corresponding lists. The respondents brought action
claiming copyright in the coupons. The House of Lords was called upon to determine whether or to
what extent copyright attached to these coupons. The respondents said that a coupon must be
regarded as a single work and that as such it was protected by copyright. The appellants sought to
dissect the coupon. It was contended by the respondents that there had been a breach of copyright
by the appellants, since the respondents compilation, which must be regarded as a single work, was
original and protected by copyright and the part taken by the appellants from the respondents
work was substantial. It did not follow that because the fragments of the compilation, taken
separately, would not be copyright, the whole could not be copyright. It was submitted by the
appellants that the derivative work of the respondents not being original, no copyright can be
claimed and the inputs put, if considered separately, are of insignificant value and thus the
respondents could not claim copyright.
The word `original does not mean that the work must be the expression of original or inventive
thought. Copyright Acts are not concerned with the originality of ideas, but with the expression of
thought, and in the case of literary work, with the expression of thought in print or writing. The
originality which is required relates to the expression of the thought. But the Act does not require
that the expression must be in an original or novel form, but that the work must not be copied from
another work - that it should originate from the author; and as regards compilation, originality is a
matter of degree depending on the amount of skill, judgment or labour that has been involved in
making the compilation. The words literary work cover work which is expressed in print or
writing irrespective of the question whether the quality or style is high. The commonplace matter
put together or arranged without the exercise of more than negligible work, labour and skill in
making the selection will not be entitled to copyright. The word original does not demand original
or inventive thought, but only that the work should not be copied but should originate from the
author. In deciding, therefore, whether a work in the nature of a compilation is original, it is wrong
to consider individual parts of it apart from the whole. For many compilations have nothing original
in their parts, yet the sum total of the compilation may be original. In such cases the courts have
looked to see whether the compilation of the unoriginal material called for work or skill or expense.
If it did, it is entitled to be considered original and to be protected against those who wish to steal
the fruits of the work or skill or expense by copying it without taking the trouble to compile it
themselves. In each case, it is a question of degree whether the labour or skill or ingenuity or
expense involved in the compilation is sufficient to warrant a claim to originality in a compilation.
17. While considering the question whether the copyright protection is available to the work created
as a whole or the fragment of the work would be considered piecemeal and individually apart from
the whole, the House of Lords said as under:Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

. One test may be whether the part which he has taken is novel or striking, or is
merely a commonplace arrangement of ordinary words or well-known data. So it may
sometimes be a convenient short cut to ask whether the part taken could by itself be
the subject of copyright. But, in my view, that is only a short cut, and the more correct
approach is first to determine whether the plaintiffs work as a whole is `original
and protected by copyright, and then to inquire whether the part taken by the
defendant is substantial.
A wrong result can easily be reached if one begins by dissecting the plaintiffs work
and asking, could section A be the subject of copyright if it stood by itself, could
section B be protected if it stood by itself, and so on. To my mind, it does not follow
that, because the fragments taken separately would not be copyright, therefore, the
whole cannot be. 
18. In the case of Walter and Another v. Lane, [1900] AC 539 (HL), the Earl of Rosebery on five
occasions in 1896 and 1898 delivered to the public audience speeches on subjects of public interest.
The Reporter of `The Times took down the speeches in shorthand, wrote out their notes, corrected,
revised and punctuated them and the reports were published in `The Times, the speeches being
given verbatim as delivered by Lord Rosebery. The reporters were employed under the terms that
the copyright in all reports and articles composed by `The Time magazine should belong to the
proprietors. In the year 1899, the respondent published a book called  Appreciations and
Addresses:
Lord Rosebery, which contained the reports of the above speeches of Lord Rosebery
and it was admitted that these reports were taken from the reports in `The Times.
Lord Rosebery made no claim. The appellants brought an action against the
respondent claiming a declaration that a copyright of the articles and reports was
vested in the proprietors of `The Times. The issue involved in the case was whether
a person who makes notes of a speech delivered in public, transcribes them and
publishes in the newspaper a verbatim report of the speech, is the author of the
report within the meaning of the Copyright Act, 1842, and is entitled to the copyright
in the report. The House of Lords held that each reporter is entitled to report and
each undoubtedly would have a copyright in his own published report. It was of
course open to any other reporter to compose his own report of Lord Roseberys
speech, and to any other newspaper and book to publish that report; but it is a sound
principle that a man shall not avail himself of anothers skill, labour and expense by
copying the written product thereof; and copyright has nothing to do with the
originality or the literary merits of the author or composer. It may exist in the
information given by a street dictionary. If a person chooses to compose and write a
volume devoid of the faintest spark of literary or any other merit, there is no legal
reason why he should not, if he desires, become the first publisher of it and register
his copyright, worthless and insignificant as it would be.Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

19. In the case of Designers Guild Ltd. v. Russell Williams (Textiles) Ltd., [2000] 1 WLR 2416 (HL),
the plaintiff brought proceedings claiming that the defendant had infringed the plaintiffs copyright
by copying one of its fabric designs, i.e. for the fabric design Ixia. The infringement of which the
plaintiff complained was that for the purpose of creating its own design Marguerite by the
defendant. The defendant had copied a substantial part of Ixia. There were mainly two main issues
at the trial. First, what, if anything had the designer of Marguerite copied from Ixia. Secondly, did
what had been copied amount to the whole or a substantial part of Ixia? It was said by the House
of Lords that the law of copyright rests on a very clear principle that anyone who by his or her own
skill and labour creates an original work of whatever character shall enjoy an exclusive right to copy
that work. No one else may for a season reap what the copyright owner had sown.
20. University of London Press Limited v. University Tutorial Press Limited, [1916] 2 Ch 601, is
perhaps the most cited judgment regarding originality. Originality was held to be not required to be
noval form but the work should not be copied from other work, that is, it should be original. The
judgment was based on the following facts:
Certain persons were appointed as examiners for matriculation examination of the
University of London on a condition that any copyright in the examination papers
should belong to the University. The University assigned the copyright to the plaintiff
company. After the examination, the defendant company brought out a publication
containing a number of the examination papers, including three which had been set
by two examiners appointed by the University. The plaintiff company brought a case
of copyright infringement against the defendant company. It was argued that since
the setting of the papers entailed the exercise of brainwork, memory, and trained
judgment, and even the selection of passages from other authors work involved
careful consideration, discretion and choice they constituted original literary work.
On the other and, the defendants claimed that what they had done was fair dealing
for the purposes of private study which was permissible under the law. The court
agreed that the material under consideration was a literary work. The words literary
work cover work which is expressed in print or writing, irrespective of the question
whether the quality or style is high. The word `literary seems to be used in a sense
somewhat similar to the use of the word literature in political or electioneering
literature and refers to written or printed matter. With respect to the originality
issue, the Court held that the term original under the Act does not imply original
or novel form of ideas or inventive thought, but the work must not be copied from
another work - that it should originate from the author.
21. In Kelly v. Morris, (1866) LR 1 Eq. 697, School of thought propounded is that, at least in respect
of compilations, only time and expenses are necessary which is industrious collection.
The plaintiff was the owner and publisher of the first directory. The defendant came out with
another directory. The plaintiff sought an injunction against the defendant to restrain the
publication of the defendants directory on the allegations that the defendant was guilty of
appropriating the information contained in the plaintiffs directory and obtained the benefit ofEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

many years of incessant labour and expense. The defendant, on the other hand, contended that
there had been no unfair or improper use of the plaintiffs work. Information which was given in
the plaintiffs directory was entitled to be used and adopted as long as he did not servilely copy it.
The defendant had bestowed his independent time, labour and expense on the matter and thus had
in no way infringed the copyright of the plaintiff. Granting injunction, the Court held that in the case
of a directory when there are certain common objects of information which must, if described
correctly, be described in the same words, a subsequent compiler is bound to set about doing for
himself that which the first compiler has done. In case of a road- book, he must count the milestones
for himself. In the case of a map of a newly discovered island he must go through the whole process
of triangulation just as if he had never seen any former map, and, generally he is not entitled to take
one word of the information previously published without independently working out the matter for
himself, so as to arrive at the same result from the same common sources of information, and the
only use that he can legitimately make of a previous publication is to verify his own calculations and
results when obtained. The compiler of a directory or guidebook, containing information derived
from sources common to all, which must of necessity be identical in all cases if correctly given, is not
entitled to spare himself the labour and expense of original inquiry by adopting and re-publishing
the information contained in previous works on the same subject.
22. In the case of Parry v. Moring and Gollancz, Cop Cas (1901-1904) 49, the plaintiff, after
obtaining permission from the representatives of the owner of certain letters, updated,
chronologically arranged and translated them into modern English for their inclusion in his book.
Later, the defendant published, as one of the series, an edition of the letters prepared by the
plaintiff. The plaintiff, therefore, brought an action against the defendant alleging infringement of
his copyright. The plaintiff maintained his copyright in his version of the text apart from the
copyright in the text. It was held that there is copyright in the work of editing the text of a
non-copyright work. The editor of a non-copyright work is not entitled to take the text from the
edition of a rival editor and use it as a copy for the purpose of his own work.
23. In Gopal Das v. Jagannath Prasad and Another, AIR 1938 All. 266, the plaintiffs were the
printers and publishers of the books. The book titled Sachitra Bara Kok Shastra was printed for
the first time in 1928 and had run into four editions since. The defendants printed and published
another book titled Asli Sachitra Kok Shastra in 1930. The plaintiffs case was that the book
published by the defendants was a colorable imitation of their book and an infringement of
plaintiffs copyright. It was held by the Court that the plaintiffs compiled their book with
considerable labour from various sources and digested and arranged the matter taken by them from
other authors. The defendant instead of taking the pains of searching into all the common sources
and obtaining his subject matter from them, obtained the subject matter from the plaintiffs book
and availed himself of the labour of the plaintiffs and adopted their arrangement and subject matter
and, thus, such a use of plaintiffs book could not be regarded as legitimate. It was held that a
person whose work is protected by copyright, if he has collected the material with considerable
labour, compiled from various sources of work in itself not original, but which he has digested and
arranged, the defendant could not be permitted to compile his work of like description, instead of
taking the pains of searching into all the common sources and obtaining the subject-matter from
them and to adopt his arrangement with a slight degree of colourable variation thereby saving painsEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

and labour which the plaintiff has employed. The act of the defendant would be illegitimate use. The
Court held that no one is entitled to avail himself of the previous labour of another for the purpose
of conveying to the public the same information, although he may append additional information to
that already published.
24. In V. Govindan v. E.M. Gopalakrishna Kone and Another, AIR 1955 Madras 391, the
respondents had published an English-English Tamil Dictionary in 1932. The appellants were the
publishers of similar Dictionary in 1947. An action was brought regarding the publication and sale of
the dictionary by the appellants which was alleged to be constituting an infringement of the
respondents copyright. The lower court went through both the books minutely and found, page
after page, word after word, slavishly copied, including the errors, and found the sequence, the
meanings, the arrangement and everything else practically the same, except for some deliberate
differences introduced here and there to cover up the piracy. The High Court referred to Copinger
and James on Law of Copyright wherein the law has been neatly summarized that : In the case of
compilations such as dictionaries, gazetteers, grammars, maps, arithmetics, almanacs,
encyclopaedias and guide books, new publications dealing with similar subject-matter must of
necessity resemble existing publications, and the defence of common source is frequently made
where the new publication is alleged to constitute an infringement of an earlier one. The Court held
that in law books and in books as mentioned above there is very little amount of originality but the
same is protected by law and no man is entitled to steal or appropriate for himself the result of
anothers brain, skill or labour even in such works. The Court further clarified that where there is
a common source, the person relying on it must prove that he actually went to the common
source from where he borrowed, employing his own skill, labour and brains and that he did not
merely copy.
25. In C. Cunniah & Co. v Balraj & Co., AIR 1961 Madras 111, the appellant firm was carrying on the
business in pictures, picture frames, etc. One Sri T.M. Subramaniam drew a picture of Lord
Balasubramanya and gave it the title of Mayurapriya and a copyright was assigned to the appellant.
It came to the knowledge of the appellant firm that the respondent firm was printing and selling
copies of a close and colourable imitation of the appellants picture under the style of Bala
Murugan. The case of the defence was that their picture was an independent production and that the
appellant had not acquired copyright in the picture and the subject dealt with in that picture was a
common subject, in which no copyright could be acquired by anyone. The Court held that in order to
obtain copyright production for literary, domestic, musical and artistic works, the subject dealt with
need not to be original, nor the ideas expressed be something novel. What is required is the
expenditure of original skill or labour in execution and not originality of thought.
26. In Agarwala Publishing House v. Board of High School and Intermediate Education and
Another, AIR 1967 All. 91, a writ petition was filed by a publisher firm challenging an amendment of
the Regulations of the Board declaring that copyright of the question papers set at all examinations
conducted by the Board shall vest in the Board and forbidding the publication of such question
papers without the Boards permission. The question involved in the case was whether the question
papers are `original literary work and come within the purview of Section 13 of the Copyright Act,
1957. It was urged that no copyright can exist in examination papers because they are not originalEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

literary work. It was held that the original literary works referred to in Section 13 of the
Copyright Act, 1957, are not confined to the works of literature as commonly understood. It would
include all works expressed in writing, whether they have any literary merits or not. This is clear
from the definition given in Section 2(o) of the Act which states that literary work includes tables
and compilations. The Court further held that the word original used in Section 13 does not imply
any originality of ideas but merely means that the work in question should not be copied from some
other work but should originate in the author, being the product of his labour and skill.
27. In the case of Gangavishnu Shrikisondas v. Moreshvar Bapuji Hegishte and Others, ILR 13 Bom
358, the plaintiff, a book seller, in 1984 brought out a new and annotated edition of a certain
well-known Sanskrit work on religious observances entitled Vrtraj, having for that purpose
obtained the assistance of the pandits, who re-cast and re-arranged the work, introduced various
passages from other old Sanskrit books on the same subject and added footnotes. Later on, the
defendant printed and published an edition of the same work, the text of which is identical with that
of the plaintiffs work, which moreover contained the same additional pages and the same
footnotes, at the same places, with many slight differences. The foundation of both plaintiffs and
defendants books is an old Sanskrit work on Hindu ceremonial, which could have been published
by anyone. The copyright claimed by the plaintiff was on the additions and alterations to the original
text, which the parties admit to be material and valuable, and in which the copyright is claimed of its
prior publication. The defendants argued that there was nothing really original in the plaintiffs
book and, therefore, he was not entitled to copyright in the book. It was held by the Court that a new
arrangement of old matters will give a right to the protection afforded by the law of copyright. If
anyone by pains and labour collects and reduces it as a systematic compilation in the form of a book
it is original in the sense that that entitles the plaintiff to the copyright. The plaintiff worked for such
a new arrangement of old matters as to be an original work and was entitled to the protection; and
that as the defendants had not gone to independent sources of the material but had pirated the
plaintiffs work, they were restrained by injunction.
28. In Rai Toys Industries and Others v. Munir Printing Press, 1982 PTC 85, the plaintiff had
published a Tambola ticket book containing 1500 different tickets in 1929. The plaintiffs alleged that
the defendants had brought out another ticket book which the plaintiffs claimed to have written in
1929 and registered as copyright. The ticket book brought out by the defendants was alleged to
contain 600 different tickets and the same had been copied identically from the books of the
plaintiff. On this basis, a suit for injunction and rendition of account was filed by the plaintiff. The
question before the court was whether the ticket-books in the form of tables constitute literary work;
and whether copyright has been violated or not? It was held by the High Court that preparation of
tickets and placing them in tables required a good deal of skill and labour and would thus satisfy the
test of being original literary work. It was recognized that the arrangement of numbers is individual
work of a person who prepares it; it bears his individuality and long hours of labour. It is not
information which could be picked up by all and sundry. The preparation of tickets is an
individualized contribution and the compilation eminently satisfies the test of being an original
literary work. Hence it was held to be a clear case of copyright violation when the defendant decided
to pick and choose 600 tables on the sly and publish them as his individual work.Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

29. In Macmillan and Another v. Suresh Chandra Deb, ILR 17 Cal 952, the plaintiffs were
proprietors of the copyright of a selection of songs and poems composed by various authors, which
was published in 1861. In 1889, the defendants published a book containing same selection of
poems and songs as was contained in plaintiffs book, the arrangement, however, being different.
The plaintiffs claimed copyright in the selection made by them. The defendants, on the other hand,
contended that there could be no copyright in such selection. The Court held that in the case of
works not original in the proper sense of the term, but composed of, or compiled or prepared from
material which are open to all, the fact that one man has produced such a work does not take away
from any one else the right to produce another work of the same kind, and in doing so to use all the
materials open to him. But, as the law is concisely stated by Hall, V.C., in Hogg v Scott, L.R. 18 Eq.
444, , the true principle in all these cases is, that the defendant is not at liberty to use or avail
himself of the labour which the plaintiff has been at for the purpose of producing his work, that is, in
fact, merely to take away the result of another mans labour, or, in other words, his property. It is
enough to say that this principle has been applied to maps, to road books, to guide books, to
compilations on scientific and other subjects. This principle seems to be clearly applicable to the
case of a selection of a poem. It was held that for such a selection as the plaintiff had made obviously
required extensive reading, careful studying and comparison and the exercise of taste and judgment
to make a selection for himself. But, if one spares himself this trouble and adopts some other
persons selection, he offends against the principle. The Court was of the opinion that the selection
of poems made by the plaintiff and embodied in the Golden Treasury was the subject of copyright
and that the defendants book had infringed that right.
30. These decisions are the authority on the proposition that the work that has been originated from
an author and is more than a mere copy of the original work, would be sufficient to generate
copyright. This approach is consistent with the sweat of the brow standards of originality. The
creation of the work which has resulted from little bit of skill, labour and capital are sufficient for a
copyright in derivative work of an author. Decisions propounded a theory that an author deserves to
have his or her efforts in producing a work, rewarded. The work of an author need not be in an
original form or novel form, but it should not be copied from anothers work, that is, it should
originate from the author. The originality requirement in derivative work is that it should originate
from the author by application of substantial degree of skill, industry or experience. Precondition to
copyright is that work must be produced independently and not copied from another person. Where
a compilation is produced from the original work, the compilation is more than simply a
re-arranged copyright of original, which is often referred to as skill, judgment and or labour or
capital. The copyright has nothing to do with originality or literary merit. Copyrighted material is
that what is created by the author by his skill, labour and investment of capital, maybe it is
derivative work. The courts have only to evaluate whether derivative work is not the end-product of
skill, labour and capital which is trivial or negligible but substantial. The courts need not go into
evaluation of literary merit of derivative work or creativity aspect of the same.
31. Mr. P N Lekhi, learned senior counsel appearing for the respondents in C.A. No. 6472/2004 has
submitted that the judgment of the court is a government work as defined under Section 2(k)(iii)
and on account of Section 17 (d), the Government in the absence of any agreement to the contrary be
the first owner of the copyright therein. Section 52(1)(q)(iv) provides that the publication of anyEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

judgment or order of a court, tribunal or other judicial authority, unless the reproduction of
publication of such judgment or order is prohibited, would not constitute an infringement of the
copyright. Therefore, publication of the judgments of the apex court by the respondents would not
tantamount to infringement of the copyright of the appellants. It is further urged that the judgments
published in the Supreme Court Cases is nothing but merely a derivative work based upon the
judgments of the court, which lacks originality as it does not depict independent creation even a
modicum of creativity. The inputs put by the appellants is nothing but expressing an idea which can
be expressed in a limited way and as such there cannot be a copyright. Filling the blanks or gaps by
providing names of the parties or citations of the judgments, both of which are well known and
unchangeable parts of that idea, are not original work. These are not creative at all to warrant
copyright protection, either singly or in combination. The additions made in the reported judgment
by the editors of the Supreme Court Cases are only the well known extensions of the reported
decision. These extensions lack even the minimal degree of authors creativity or originality or
intellectual labour. These additions do not create additional knowledge, the protection of which is
the very basis of the copyright protection.
32. It is submitted by Ms. Pratibha M. Singh, learned counsel for the respondents in C.A. No.
6905/2004, that in the present case, the journals of the appellants, including SCC, are printed and
published on the basis of pre- existing judgments. Journals are, therefore, a derivative work. There
is a distinction between a `law report as understood in England and a `law journal as printed in
India. The appellants journal `SCC is not a law report in the strict sense, inasmuch as the
appellants journal reproduces the judgments of the court verbatim along with inputs. However, a
law report known in the traditional English sense is when a law reporter present in the court would
record in his own words and language the arguments of the counsel on both sides, give a summary
of the facts and incorporate into the said report his transcript of the speech of the Judge. Thus, the
appellants work could only be a law journal and not a law report. The judgments were specifically
made a part of the exception to copyright infringement and thus find place in Section 52(1)(q) of the
Act. The underlying purpose is that it is in public interest to place judgments in public domain. The
work for which the copyright protection is claimed is a derivative work. For claiming protection of
copyright in a derivative work, under the Indian law originality is a pre-condition and originality
means only that the work was independently created by the author as opposed to copied from other
works, and that it possesses at least some minimal degree of creativity. There is a distinction
between creation and discovery. The first person to find a particular fact has not created the fact, he
or she has merely discovered its existence. Reporting of the judgments of the Supreme Court with
certain inputs could only be said to be a discovery of facts already in existence. Though for the
purposes of creativity neither novelty nor invention is requisite for copyright protection, but at least
some minimal creativity is a must. To create a copyright by alterations of the text, these must be
extensive and substantial practically making a new version. The English decisions relied upon by the
appellants would not apply to the facts of the present case as all the said authorities are under the
old 1842 Act in U.K. wherein the word `original was conspicuously missing in the statute. It is
further urged that the copy-editing inputs of the appellants are only discoveries/facts and there are
limited ways/unique of expressing the various copy-editing inputs and thus no copyright can subsist
in such limited/unique expressions. The facts which are discovered could be expressed in limited
ways and as such ways adopted cannot give copyright protection to the inputs or the judgments as aEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

whole. It is urged that recognizing the copyright in the copy-edited version of the law reports would
amount to giving the appellants a monopoly in the judgments of the courts which is against the
intendment of Section 52(1)(q)(iv) and would defeat the purpose of putting judgments in the public
domain. It is submitted by the learned counsel for the respondents that for a derivative work, the
originality test as applied in United States Supreme Court should be made applicable whereby the
author of a derivative work would satisfy that the work has been produced from his exercise of skill
and judgment. The exercise of skill and judgment required to produce the work must not be so
trivial that it could be characterized a purely mechanical exercise. The work should be
independently created by the author as opposed to copied from the other works and that it possesses
at least some minimal degree of creativity. The case law relied upon by the learned counsel for the
respondents is considered hereinafter.
33. In Feist Publications Inc. v. Rural Telephone Service Co. Inc., 18 USPQ 2d. 1275, Rural
Telephone Service Co. publishes a typical telephone directory consisting of white pages and yellow
pages. The white pages list in alphabetical order the names of rural subscribers together with their
towns and telephone numbers. The yellow pages list Rurals business subscribers alphabetically by
category and feature classified advertisements of various sizes. To obtain white pages listings for its
area-wide directory, Feist Publications Inc. approached different telephone companies operating in
North West Kansas and offered to pay for the right to use their white pages listings. Of them, only
Rural refused. Unable to license Rurals white pages listings, Feist used them without Rurals
consent. Rural sued for copyright infringement in the District Court taking the position that Feist, in
compiling its own directory, could not use the information contained in Rurals white pages. Rural
asserted that Feists employees were obliged to travel door to door or conduct a telephone survey to
discover the same information for themselves. Feist responded that such efforts were economically
impractical and, in any event, unnecessary because the information copied was beyond the scope of
copyright protection. The United States Supreme Court held that the sine qua non of copyright is
originality. To qualify for copyright protection, a work must be original to the author. Original, as
the term is used in copyright, means only that the work was independently created by the author (as
opposed to copied from other works), and that it possesses at least some minimal degree of
creativity. The requisite level of creativity is extremely low; even a slight amount will suffice. The
vast majority of works make the grade quite easily, as they possess some creative spark, no matter
how crude, humble or obvious it might be. Originality does not signify novelty; a work may be
original even though it closely resembles other works so long as the similarity is fortuitous, not the
result of copying. The Court further held that no one claim originality as to the facts. This is because
facts do not owe their origin to an act of authorship. The distinction is one between creation and
discovery: the first person to find and report a particular fact has not created the fact; he or she has
merely discovered its existence. Factual compilations, on the other hand, may possess the requisite
originality. The compilation author typically chooses which facts to include, in what order to place
them, and how to arrange the collected data so that they may be used effectively by readers. These
choices as to selection and arrangement, so long as they are made independently by the compiler
and entail a minimal degree of creativity, are sufficiently original. Thus, if the compilation author
clothes facts with an original collocation of words, he or she may be able to claim a copyright in this
written expression. The Court goes on to hold that the primary objective of copyright is not to
reward the labour of authors, but to promote the progress of science and useful arts. To this end,Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

copyright assures authors the right to their original expression but encourages others to build freely
upon the ideas and information conveyed by a work. Only the compilers selection and arrangement
may be protected; however, the raw facts may be copied at will. The Court rejected the doctrine of
the sweat of the brow as this doctrine had numerous flaws, the most glaring being that it
extended copyright protection in a compilation beyond selection and arrangement  the compilers
original contributions  to the facts themselves. A subsequent compiler was not entitled to take one
word of information previously published, but rather had to independently work out the matter for
himself, so as to arrive at the same result from the same common sources of information. Sweat of
the brow courts thereby eschewed the most fundamental axiom of copyright law that no one may
copyright facts or ideas. The sweat of the brow doctrine flouted basic copyright principles and it
creates a monopoly in public domain materials without the necessary justification of protecting and
encouraging the creation of writings by authors.
34. The judgment in Matthew Bender & Co., Inc. v. West Publishing Co., 158 F.3d 674 (2nd Cir.
1998), is of United States Court of Appeals, Second Circuit, which directly covers the reports of the
judgments of the courts. The facts involved in the case are that the West Publishing Co. and West
Publishing Corp. (West) obtain the text of judicial opinions directly from courts. It alters these
texts into (i) independently composed features, such as syllabus, headnotes which summarize the
specific points of law recited in each opinion and key numbers which categorize points of law into
different legal topics and sub-topics and (ii) additions of certain factual information to the text of
the opinions, including parallel or alternative citations to cases, attorney information, and data on
subsequent procedural history. West publishes the case reports in different series of case reporters
collectively known as National Reporter System. Two series of case reporters at issue in that case
were the Supreme Court Reporter and the Federal Reporter. HyperLaw publishes and markets
CD-ROMs which are compilations of the Supreme Court and the United States Court of Appeals that
cover approximately the same ground. HyperLaw intends to expand its CD-ROM product taking the
material from the West publications. HyperLaw intervened and sought a judgment declaring that
the individual West case reports that are left after redaction of the first category of alterations do not
contain copyrightable material. It was held by the Court that for copyright protection, the material
does not require novelty or invention, but minimal creativity is required. All of Wests alterations to
judicial opinions involve the addition and arrangement of facts, or the rearrangement of data
already included in the opinions, and, therefore, any creativity in these elements of Wests case
reports lies in Wests selection and arrangement of this information. Wests choices on selection
and arrangement can reasonably be viewed as obvious, typical and lacking even minimal creativity.
Copyright protection is unavailable for both derivative works and compilations alike unless, when
analysed as a whole, they display sufficient originality so as to amount to an original work of
authorship. Originality requires only that the author makes the selection or arrangement
independently and that it displays some material with minimal level of creativity. While a copy of
something in the public domain will not, if it be merely a copy, support a copyright, a
distinguishable variation will. To support a copyright there must be at least some substantial
variation, not merely a trivial variation such as might occur in the translation to a different medium.
Creativity in selection and arrangement, therefore, is a function of (i) the total number of options
available, (ii) external factors that limit the viability of certain options and render others
non-creative, andEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

(iii) prior uses that render certain selections `garden variety.
35. In the case of Key Publications, Inc. v. Chinatown Today Publishing Enterprises, Inc., 945
F.2d.509, Key Publication published an Annual Classified Business Directory for New York Citys
Chinese-American community. In 1990, Galore Publication published the Galore Directory, a
classified directory for the New York Chinese American community. Key brought a suit against
Galore Directory charging that Galore Directory infringed Keys copyright in the 1989-90 Key
Directory. The United States Court of Appeal held that individual components of compilation are
generally within the public domain and thus available for public. There are three requirements for a
compilation to qualify for copyright protection : (1) the collection and assembly of pre-existing data;
(2) selection, co- ordination or arrangement of the data; and (3) the resulting work that comes into
being is original, by virtue of the selection, coordination or arrangement of the data contained in the
work. For originality, the work is not required to contain novelty. The doctrine of sweat of the
brow, rewarded compilers for their efforts in collecting facts with a de facto copyright to those facts
and this doctrine would prevent, preclude the author absolutely from saving time and effort by
referring to and relying upon prior published material. It extended copyright protection in
compilation beyond selection and arrangement - the compilers original contribution  to the facts
themselves drawn on sweat of the brow is a copyright protection to the facts discovered by the
compiler. The court discarded sweat of the brow notion of copyright law.
36. In Macmillan and Company v. K. and J. Cooper, 1924 Privy Council 75, action was brought by
McMillan and Company to restrain the respondent-firm who was carrying on the trade and business
of publishers of educational books, from printing, distributing or otherwise disposing of copies of
the book published by the appellants. The ground on which the relief was claimed was that the
appellants had a copyright in the book entitled Plutarchs Life of Alexander, Sir Thomas Norths
Translation and that the respondent published subsequently a book entitled Plutarchs Life of
Alexander the Great, Norths Translation, as it had infringed the copyright to which the appellants
were entitled in the earlier compilation. The Court noted the contents of the book of the appellants
as also that of the respondent. As per the Court, the text of the appellants book consisted of a
number of detached passages, selected from Sir Thomas Norths translation, words being in some
instances introduced to knit the passages together so that the text should as far as possible, present
the form of an unbroken narrative. The passages so selected were, in the original translation, by no
means contiguous. Considerable printed matter in many instances separated the one from the other.
The opinion of the Privy Council was that for the work done by the appellants, great knowledge,
sound judgment, literary skill or taste in the inputs brought to bear upon the translation was not
required, as the passages of the translation which had been selected are reprinted in their original
form, not condensed, expanded, modified or reshaped to any extent whatever. The Court observed
that the Norths translation of Plutarchs Life of Alexander does not and never did, as the law
stands, never can enjoy the protection of copyright; and the questions which arise for decision must
be dealt with upon that assumption. The Court said that in all cases where the reprint with the text
of it consisted merely of a reprint of passages selected from the work of any author, would never
have a copyright. There may be cases where selecting and reprinting the passages would require the
appreciation upon what has been laid down or established in the book and labour, accurate scientific
knowledge, sound judgment, touching the purpose for which the selection is made, and literary skillEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

would all be needed to effect the object in view. In such a case, the copyright might well be acquired
for the print of the selected passages. The Court said that it is the product of the labour, skill and
capital of one man which must not be appropriated by another, not the elements, the raw material,
upon which the labour and skill and capital of the first have been expended. To secure copyright for
this product, it is necessary that the labour, skill and capital expended should be sufficient to impart
to the product some quality or character which the raw material did not possess and which
differentiates the product from the raw material. The Court approved the principles enunciated in
the case of University of London Press, Ltd. v. University Tutorial Press, Ltd., [1916] 2 Ch. 601,
dealing with the meaning of the words `original literary work that the original does not mean
expression of original or inventive thought. The Copyright Act is not concerned with the original
ideas, but with the expression of thought. The originality which is required relates to expression of
thought and the Act does not require that the expression must be in original or novel form. The work
must not be copied from another work  that it should originate from the author.
37. The Supreme Court of Canada in the matter of CCH Canadian Ltd. v. Law Society of Upper
Canada, 2004 (1) SCR 339 (Canada) has noticed the competing views on the meaning of `original
in copyright law wherein some courts have held that a work which has originated from an author
and is more than a mere copy of a work, is sufficient to give copyright. This approach is held to be
consistent with the `sweat of the brow or `industriousness standard of originality on the premise
that an author deserves to have his or her efforts in producing a work rewarded. Whereas the other
courts have held that a work must be creative to be original and thus protected by the copyright Act,
which approach is consistent with a natural rights theory of property law; however, it is less absolute
in that only those works that are the product of creativity will be rewarded with copyright protection
and it was suggested in those decisions that the creativity approach to originality helps ensure that
copyright protection is extended to the expression of ideas as opposed to the underlying ideas or
facts. The Court has also noticed that those cases which had adopted the sweat of the brow approach
to originality should not be interpreted as concluding that labour, in and of itself, would be a ground
for finding of originality. The question for consideration of the copyright has arisen on the following
fact foundation. The appellant, Law Society of Upper Canada, has maintained and operated the
Great Library at Osgoode Hall in Toranto, a reference and research library. The Great Library
provides a request- based photocopy service for Law Society members, the judiciary and other
authorized researchers. Under the custom photocopy service, legal materials are reproduced and
delivered to the requesters. The Law Society also maintains self-service photocopiers in the Great
Library for use by its patrons. The respondents, CCH Canadian Ltd., Thomson Canada Ltd. and
Canada Law Book Inc. publish law reports and other legal materials. The law book publishers
commenced copyright infringement action against the Law Society claiming ownership of copyright
in 11 specific works on the ground that the Law Society had infringed copyright when the Great
Library reproduced a copy of each of the works. The publishers further sought permanent injunction
prohibiting the Law Society from reproducing these 11 works as well as any other works that they
published. The Law Society denied liability and submitted that the copyright is not infringed when a
single copy of a reported decision, case summary, statute, regulation or a limited selection of text
from a treatise is made by the Great Library staff or one of its patrons on a self-service photocopier
for the purpose of research. The Court was called upon to decide the question as to what shall be the
originality in the work of compilation. On consideration of various cases, it was held that to beEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

original under the Copyright Act the work must originate from an author, not be copied from
another work, and must be the product of an authors exercise of skill and judgment. The exercise
of skill and judgment required to produce the work must not be so trivial that it could be
characterized as a purely mechanical exercise. Creative works by definition are original and are
protected by copyright, but creativity is not required in order to render a work original. The original
work should be the product of an exercise of skill and judgment and it is a workable yet fair
standard. The sweat of the brow approach to originality is too low a standard which shifts the
balance of copyright protection too far in favour of the owners right, and fails to allow copyright to
protect the publics interest in maximizing the production and dissemination of intellectual works.
On the other hand, the creativity standard of originality is too high. A creative standard implies that
something must be novel or non-obvious - concepts more properly associated with patent law than
copyright law. By way of contrast, a standard requiring the exercise of skill and judgment in the
production of a work avoids these difficulties and provides a workable and appropriate standard for
copyright protection that is consistent with the policy of the objectives of the Copyright Act. Thus,
the Canadian Supreme Court is of the view that to claim copyright in a compilation, the author must
produce a material with exercise of his skill and judgment which may not be creativity in the sense
that it is not novel or non- obvious, but at the same time it is not the product of merely labour and
capital.
38. It is the admitted position that the reports in the Supreme Court Cases (SCC) of the judgments
of the Supreme Court is a derivative work in public domain. By virtue of Section 52(1) of the Act, it is
expressly provided that certain acts enumerated therein shall not constitute an infringement of
copyright. Sub-clause (iv) of clause (q) of Section 52(1) excludes the reproduction or publication of
any judgment or order of a Court, Tribunal or other judicial authority, unless the reproduction or
publication of such judgment or order is prohibited by the Court, the Tribunal or other judicial
authority from copyright. The judicial pronouncements of the Apex Court would be in the public
domain and its reproduction or publication would not infringe the copyright. That being the
position, the copy-edited judgments would not satisfy the copyright merely by establishing amount
of skill, labour and capital put in the inputs of the copy-edited judgments and the original or
innovative thoughts for the creativity are completely excluded. Accordingly, original or innovative
thoughts are necessary to establish copyright in the authors work. The principle where there is
common source the person relying on it must prove that he actually went to the common source
from where he borrowed the material, employing his own skill, labour and brain and he did not
copy, would not apply to the judgments of the courts because there is no copyright in the judgments
of the court, unless so made by the court itself. To secure a copyright for the judgments delivered by
the court, it is necessary that the labour, skill and capital invested should be sufficient to
communicate or impart to the judgment printed in SCC some quality or character which the original
judgment does not possess and which differentiates the original judgment from the printed one. The
Copyright Act is not concerned with the original idea but with the expression of thought. Copyright
has nothing to do with originality or literary merit. Copyrighted material is that what is created by
the author by his own skill, labour and investment of capital, maybe it is a derivative work which
gives a flavour of creativity. The copyright work which comes into being should be original in the
sense that by virtue of selection, co-ordination or arrangement of pre-existing data contained in the
work, a work somewhat different in character is produced by the author. On the face of theEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

provisions of the Indian Copyright Act, 1957, we think that the principle laid down by the Canadian
Court would be applicable in copyright of the judgments of the Apex Court. We make it clear that the
decision of ours would be confined to the judgments of the courts which are in the public domain as
by virtue of Section 52 of the Act there is no copyright in the original text of the judgments. To claim
copyright in a compilation, the author must produce the material with exercise of his skill and
judgment which may not be creativity in the sense that it is novel or non- obvious, but at the same
time it is not a product of merely labour and capital. The derivative work produced by the author
must have some distinguishable features and flavour to raw text of the judgments delivered by the
court. The trivial variation or inputs put in the judgment would not satisfy the test of copyright of an
author.
39. On this touchstone, we shall take into consideration the inputs put by the appellants in their
journal `SCC. The appellants have added in the copy- edited version the cross-citations to the
citation(s) already given in the original text; added names of cases and cross-citations where only
the citation of the case is given; added citation and cross-citations where only name of the case is
given; inserted citation in case history where only the title and year of the impugned/earlier order is
given; presented in their own style the cases when they are cited repeated in the judgment; provided
precise references to the quoted matter in the judgment by giving exact page and paragraph number
as in the original case source/treatise/reference material; added margin headings to quoted extracts
from statutes/rules, etc., when they are missing from the original text of the judgment; added the
number of the Section/Rule/Article/paragraph to the extract quoted in the original text; added the
names of Judges on whose behalf opinion given by giving expressions such as for himself and
Pathak, C.J. etc.; done verification of first word of the quoted extract and supplied emphasis on
such verification; added ellipsis  to indicate breaks in quoted extract; provided and supplied the
matter inadvertently missed in quoted extracts in the original text of the judgment;
completed/corrected the incomplete/incorrect case names or citations; renumbered correctly the
clauses/sub-clauses in terms of the questions framed which were numbered in terms of answers to
questions framed by learned Judge; changed the text as per corrigenda issued, which has been
issued upon SCC Editors request and suggestions; done compressing/simplification of information
relating to the case history; followed certain norms at SCC for giving case names; omitted the words
like Section, Sec., Rule, etc. and given only the number of the Section/rule at the beginning
of the quoted extract; made margin heading and the first clause/sub-section or initial matter of
section/rule etc. to run-on instead of being let to start from a fresh line; done compressing of
unquoted referends and use of *** for parts; replaced the series of dots in the raw text with ellipsis;
removed abbreviations such as sec., R., cl. and substituted them with full word, i.e. Section, Rule,
clause; added hyphenation after the section/rule numbers which have alphabets suffixed to them;
applied indentation of quoted extracts; removed full stops or word No. ; and given full forms of
abbreviations to enhance readability and clarity. In addition to the above, capitalization and
italicization is also made wherever necessary in the raw text; and punctuation, articles, spellings and
compound words are also checked and corrected, if required, in the original text.
40. The aforesaid inputs put by the appellants in the judgments would have had a copyright had we
accepted the principle that any one who by his or her own skill and labour creates an original work
of whatever character, shall enjoy an exclusive right to copy that work and no one else would beEastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

permitted to reap the crop what the copyright owner had sown. No doubt the appellants have
collected the material and improved the readability of the judgment by putting inputs in the original
text of the judgment by considerable labour and arranged it in their own style, but that does not give
the flavour of minimum requirement of creativity. The exercise of the skill and judgment required to
produce the work is trivial and is on account of the labour and the capital invested and could be
characterized as purely a work which has been brought about by putting some amount of labour by
the appellants. Although for establishing a copyright, the creativity standard applies is not that
something must be novel or non-obvious, but some amount of creativity in the work to claim a
copyright is required. It does require a minimal degree of creativity. Arrangement of the facts or
data or the case law is already included in the judgment of the court. Therefore, creativity of SCC
would only be addition of certain facts or material already published, case law published in another
law report and its own arrangement and presentation of the judgment of the court in its own style to
make it more user- friendly. The selection and arrangement can be viewed as typical and at best
result of the labour, skill and investment of capital lacking even minimal creativity. It does not as a
whole display sufficient originality so as to amount to an original work of the author. To support
copyright, there must be some substantive variation and not merely a trivial variation, not the
variation of the type where limited ways/unique of expression available and an author selects one of
them which can be said to be a garden variety. Novelty or invention or innovative idea is not the
requirement for protection of copyright but it does require minimal degree of creativity. In our view,
the aforesaid inputs put by the appellants in the copy-edited judgments do not touch the standard of
creativity required for the copyright.
41. However, the inputs put in the original text by the appellants in (i) segregating the existing
paragraphs in the original text by breaking them into separate paragraphs; (ii) adding internal
paragraph numbering within a judgment after providing uniform paragraph numbering to the
multiple judgments; and (iii) indicating in the judgment the Judges who have dissented or
concurred by introducing the phrases like concurring, `partly concurring, `partly dissenting,
`dissenting, `supplementing, `majority expressing no opinion, etc., have to be viewed in a
different light. The task of paragraph numbering and internal referencing requires skill and
judgment in great measure. The editor who inserts para numbering must know how legal
argumentation and legal discourse is conducted and how a judgment of a court of law must read.
Often legal arguments or conclusions are either clubbed into one paragraph in the original judgment
or parts of the same argument are given in separate paragraphs. It requires judgment and the
capacity for discernment for determining whether to carve out a separate paragraph from an
existing paragraph in the original judgment or to club together separate paragraphs in the original
judgment of the court. Setting of paragraphs by the appellants of their own in the judgment entailed
the exercise of the brain work, reading and understanding of subject of disputes, different issues
involved, statutory provisions applicable and interpretation of the same and then dividing them in
different paragraphs so that chain of thoughts and process of statement of facts and the application
of law relevant to the topic discussed is not disturbed, would require full understanding of the entire
subject of the judgment. Making paragraphs in a judgment could not be called a mechanical process.
It requires careful consideration, discernment and choice and thus it can be called as a work of an
author. Creation of paragraphs would obviously require extensive reading, careful study of subject
and the exercise of judgment to make paragraph which has dealt with particular aspect of the case,Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

and separating intermixing of a different subject. Creation of paragraphs by separating them from
the passage would require knowledge, sound judgment and legal skill. In our opinion, this exercise
and creation thereof has a flavour of minimum amount of creativity. The said principle would also
apply when the editor has put an input whereby different Judges opinion has been shown to have
been dissenting or partly dissenting or concurring, etc. It also requires reading of the whole
judgment and understanding the questions involved and thereafter finding out whether the Judges
have disagreed or have the dissenting opinion or they are partially disagreeing and partially agreeing
to the view on a particular law point or even on facts. In these inputs put in by the appellants in the
judgments reported in SCC, the appellants have a copyright and nobody is permitted to utilize the
same.
42. For the reasons stated in the aforesaid discussion, the appeals are partly allowed. The High
Court has already granted interim relief to the plaintiff- appellants by directing that though the
respondent- defendants shall be entitled to sell their CD-ROMS with the text of the judgments of the
Supreme Court along with their own head notes, editorial notes, if any, they should not in any way
copy the head notes of the plaintiff-appellants; and that the defendant-respondents shall also not
copy the footnotes and editorial notes appearing in the journal of the plaintiff-appellants. It is
further directed by us that the defendant-respondents shall not use the paragraphs made by the
appellants in their copy-edited version for internal references and their editors judgment regarding
the opinions expressed by the Judges by using phrases like `concurring, `partly dissenting, etc.
on the basis of reported judgments in SCC. The judgment of the High Court is modified to the extent
that in addition to the interim relief already granted by the High Court, we have granted the
above-mentioned additional relief to the appellants.
43. In view of the decision rendered by us in the civil appeals, we do not think it necessary to pass
any order on the contempt petition. The contempt petition stands disposed of accordingly.
44. There shall be no order as to costs.Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007

