Brawn Laboratories Ltd. vs Rhone Poulenc Rorer S.A. & Anr. on
1 May, 1999
Equivalent citations: 1999IIIAD(DELHI)849, 79(1999)DLT507, 1999(49)DRJ630
Author: S.K. Mahajan
Bench: S.K. Mahajan
ORDER
S.K. MAHAJAN,J.
1. The petitioner seeking to enforce the negative covenant contained in the agreement dated
September 23, 1991 filed this petition under sections 8 & 11 of the Arbitration and Conciliation Act,
1996 (for short the Act) for reference of disputes to arbitrator to be appointed by the International
Chambers of Commerce, Paris, France. Alongwith the petition an application was filed under section
9 of the Act to restrain the respondents from manufacturing, marketing, and/or selling the products
mentioned in Schedule 'A' of the agreement pending adjudication of disputes in arbitration. By this
order I propose to dispose of this application of the petitioner under section 9 of the Act.
2. The case set up in the petition is that under the Agreement the respondent had granted an
exclusive licence to the petitioner for the respondent's know how and patents to manufacture, use
and sell under its trade mark the products in the territory using substances supplied by the
respondent and/or a third party appointed by the respondent or selected by the licencee. The
products for which the exclusive licence to manufacture, use and sell was granted to the petitioner
were, besides others, a medicine being marketed under the trade mark "CLEXANE" with
formulations "ENOXAPA-
RINE". The petitioner is alleged to have obtained the approval of foreign collaboration proposals
from the Reserve Bank of India and no objection Certificate from the Drug Controller(India) and
Director General of Health Services for conducting the clinical trials of Pipotiazine and oral drops,
Licence for import of Pipotiazine, bulk drugs tablets and injection for the purpose of examination,
test and analysis, licence for import of 'ZOPICLONE' tablets from France and is stated to have
installed various manufacturing facilities to the satisfaction of respondent No.1 for manufacture of
the said drugs. The petitioner is also alleged to have conducted extensive promotional campaigns for
marketing "CLEXANE" imported for the petitioner by respondent No.1 and as a result of such
campaign the product is alleged to have attained popularity in the Indian Market. It is also the case
of the petitioner that respondent No.1 with a view to encash upon the success of the said product
marketed by the petitioner from the said respondents insisted that the petitioner should co-market
the product `CLEXANE' in India with the respondent No.1 and with that end in view formed itsBrawn Laboratories Ltd. vs Rhone Poulenc Rorer S.A. & Anr. on 1 May, 1999

subsidiary namely respondent No.2 which was incorporated on January 31, 1995.
3. Respondent No.1 is alleged to have terminated the agreement on several occasions. By a notice
dated June 12, 1995 the agreement was allegedly terminated on the ground that there was a
substantial change in the share capital structure of the petitioner and the same having been done
without the approval of respondent No.1, the petitioner had allegedly violated the terms of the
agreement. On the petitioner informing the respondent No.1 that there was no change in the capital
structure, respondent No.1 vide letter dated August 23, 1995 assured the petitioner that they would
let the petitioner know of their comments in respect of the petitioner's letter in the next few weeks.
However, no comments, as assured came from respondent No.1 and by letter dated August 29, 1995
the respondent informed the petitioner that a new out pack of "Clexane" containing 20 mg. and 40
mg. of solid "Enoxaparine", would be available in blue and red colours respectively. By this letter the
notice dated 12th June, 1995 was allegedly withdrawn.
4. Another attempt was made by respondent No. 1 to terminate the agreement by notice dated
October 2, 1995 on the ground of the petitioner having transferred their exclusive rights to market
the contracted product to Brawn Pharmaceuticals Ltd. without prior approval in writing from
respondent No.1. The petitioner is stated to have informed respondent No.1 by its letter dated
November 29, 1995 that there was no authorisation in favour of Brawn Pharmaceuticals Ltd. to
market the product of respondent No. 1 and clearly there was no violation of the terms of the
agreement.
5. It is alleged that the termination of the agreement, therefore, by the respondent was not in
accordance with the terms of the agreement in asmuch as under Article 16 of the agreement in the
event of any infringement of any term of the agreement by either party, a notice to remedy the
infringement within 90 days was required to be given to the defaulting party and it was only on the
defaulting party not having remedied the infringement the aggrieved party could terminate the
agreement. It is contended that even assuming there was an infringement of the agreement an
opportunity ought to have been given to the petitioner to remedy the infringement within 90 days
and it was only after the expiry of the period of 90 days that the aggrieved party could terminate the
agreement if such infringement remained unremedied. Petitioner also stated that a reply to notice of
termination dated October 2, 1995 was given by the petitioner to which respondent No.1 vide its
letter dated January 24, 1996 while confirming the contents of its notice of termination for the first
time stated that the inspection report of the factory of the petitioner showed that the petitioner was
not in a position to manufacture the contracted products.
6. It is further stated in the petition that no reply to various letters of the petitioner was given by
respondent No.1 obviously for the reasons it was distributing their products through respondent
No.2 in breach of the agreement dated 23.9.1991. The action of respondent No.1 in manufacturing
and/or marketing the products in India through its own subsidiary was stated to be contrary to the
terms of the agreement. The termination of the agreement was also alleged to be wrong, illegal and
not maintainable as the same was based on extraneous considerations and with ulterior motives to
deprive the petitioner of its exclusive right to sell and distribute the contracted products in India for
a period of 10 years and for further renewed period.Brawn Laboratories Ltd. vs Rhone Poulenc Rorer S.A. & Anr. on 1 May, 1999

7. The petitioner having allegedly invested considerable amount of Rs.67 Lacs in creating and
further improving infrastructure facilities as per the suggestion of respondent No.1 and for
procuring of licence, permissions, and approvals from different regulatory authorities in India,
besides spending huge amount or expensive promotional activities in respect of the contracted
products pursuant to the agreement, sought to claim a sum of Rs.7 Crores from respondent No.1 for
which a dispute was raised and the petition was filed for initiating arbitration proceedings for
deciding the claim by the arbitrators and thereafter recovery of the above amount from respondent
No.1. Details of the disputes have been mentioned in the petition and it is stated that cause of action
arose in favour of the petitioner on 12th June, 1995, 2nd October, 1995 and 24th January, 1996
when termination letters were given on wrong and fictitious ground with ulterior motives in breach
of Article 16 of the Agreement. It is stated that this Court has jurisdiction to try the petition as the
cause of action has accrued in Delhi because the licence was granted within the jurisdiction of this
Court.
8. By way of interim relief, the petitioner filed an application under Section 9 of the Act and stated
that as the petitioner had the exclusive right to manufacture and market the contracted products as
per article 3 of the agreement the petitioner by virtue of Section 42 of the Specific Relief Act was
entitled to the grant of injunction restraining the respondent from manufacturing, marketing or
selling the products in India pending adjudication of disputes by arbitration.
9. Composite reply was filed by respondents to the main petition as well as to the application under
Section 9 of the Act. In spite of opportunity having been granted to the petitioner to file rejoinder, it
chose not to file the same.
10. The respondents in their reply stated that this Court does not have jurisdiction to entertain and
try and dispose of the petition inasmuch as part I of the Act was applicable to only those arbitrations
where the place of arbitration was in India and as parties had expressly agreed to refer disputes to
the International Chamber of Commerce, Paris, France, Part I of the Act would not apply to the
present proceedings and consequently this Court will have no jurisdiction to try the petition.
11. On merits of the case, it was stated by the respondents that as per own admission of the
petitioner the licence agreement was terminated as far back as in January, 1996 pursuant to the
notice of termination served upon the petitioner, the applicant has become totally disentitled to the
discretionary relief from this Court in law or equity for reasons of enormous and inordinate delay
and laches on the part of the petitioner. It is also stated that after the termination of the agreement
in January, 1996 respondent No.1 had been continuously, openly and uninterruptedly selling the
products contracted in India through respondent No.2 to the full knowledge of the medical
profession and the pharmaceutical industry including the petitioner who did not raise any objection
to the marketing of the said drug in India through respondent No.2. It was, therefore, alleged that
the petitioner by its conduct has authorised the sale and marketing of the drug in India by
respondent No.2 and it was, therefore, estopped from raising any claim or demand by filing the
petition for seeking any order or relief on the ground that respondent No.1 was marketing and
selling the drugs in India through respondent No.2 in violation of the alleged agreement. It is also
alleged that as a result of tremendous and constant representation and efforts made andBrawn Laboratories Ltd. vs Rhone Poulenc Rorer S.A. & Anr. on 1 May, 1999

expenditure incurred and investments made by respondents to market the contracted drug under
the trade name "CLEXANE" it achieved wide existence in India and had become the infrastructure
of the medical profession. The petition and interim application was, therefore, stated to be vitiated
by malafide, inordinate and unjustifiable delay and laches which would disentitle the petitioner to
any relief in law and or equity.
12. Besides the disentitlement of the petitioner to any relief due to inordinate delay and laches it is
also stated in the reply of the respondents that respondent No.1 had entered into an agreement with
the petitioner and not with Brawn Pharmaceuticals Limited which was entirely different and distinct
entity, and till date the petitioner had not been able to obtain requisite licence and permissions in its
name. It is also stated that in Article 6 of the agreement the petitioner had expressly undertaken to
observe confidentiality and secrecy in respect of the valuable secrets and proprietary know-how
information and data disclosed to it by respondent No.1 under the terms of the agreement and the
petitioner having committed breach of the covenant of secrecy and confidentiality by divulging and
passing on the know-how, information and data to Brawn Pharmaceuticals Ltd., which information
was used by Brawn Pharmaceuticals Ltd. to make an application to Government of India for
manufacturing the product, respondent No.1 had rightly cancelled and terminated the agreement.
The petitioner was stated to have no production capacity and capability to manufacture the
contracted product and it was only Brawn Pharmaceuticals Ltd. which had certain production
facilities on which no reliance could be placed by the petitioner for enforcement of the agreement.
13. It is also the case of the respondents that the petitioner has committed grave default and
breaches of the terms and conditions of the agreement inasmuch as while it had given an express
commitment and undertaking to purchase the substances or ingredients of the drugs of the value of
US $ 1,05,000 during the year 1994 from respondent No.1, the value of the drugs actually purchased
by it from respondent No.1 came to only US $ 13,000, payment of which was also inordinately
delayed and was received only after numerous requests and reminders. It is stated that there had
been complete and total failure and negligence on the part of the petitioner in fulfillment of its
duties and obligations under the agreement leading to its termination in October, 1995 and
reiterated in January, 1996.
14. As already stated, rejoinder to the counter statement of the respondents was not filed by the
petitioner in spite of opportunity having been granted by this Court.
15. Lengthy arguments were advanced by learned counsel for the parties on the question as to
whether this Court has the jurisdiction to try this petition in view of Section 2 of the Arbitration and
Conciliation Act according to which Part I of the Act will apply where the place of arbitration was in
India. While the petitioner places reliance upon the judgment of this Court in Dominant Offset
Private Limited Vs. Adamoske Strojiney A.S., , in support of his contention that even in cases where
place of arbitration was not in India, part I of the Act will apply, Mr.Ganesh, learned counsel for the
respondent, has placed reliance upon an unreported judgment of the Division Bench of Calcutta
High Court in Cavender Agro Limited Vs. Seagram Company Limited in A.P.O.No.498 and 499/97
in C.S.No.592/97 decided on January 27, 1998 wherein it was held that part I was made applicable
to domestic arbitrations only and there was no corresponding provision in Part II of the Act.Brawn Laboratories Ltd. vs Rhone Poulenc Rorer S.A. & Anr. on 1 May, 1999

15A. I have given my thoughtful consideration to the arguments advanced by the parties on the
question as to whether part I of the Act applies to the facts of the present case and whether this
Court has the jurisdiction to grant relief under Section 9 of the Act and I am of the opinion that this
Court need not decide this question at this stage as the application of the petitioner for grant of
interim relief can be decided de-hors the applicability of Part I of the Act to the present case. I have,
therefore, refrained myself from making any observation on the question as to whether part I of the
Act applies to the arbitration where the place of arbitration was not in India.
16. It is the case of the petitioner itself that the licence agreement was terminated by the respondent
by notice dated 2nd October, 1995 on the ground of the petitioner having transferred its exclusive
rights to market the contracted products to Brown Pharmaceuticals Limited without prior approval
in writing from respondent No.1. Respondent No.1 by letter dated 24th January, 1996 confirmed the
contents of its notice dated 2nd October, 1995 by which the agreement was terminated. It is
admitted case of the parties that since June, 1995 the agreement has not been acted upon by the
parties. Respondent No.2, even according to the petitioner's own showing, was incorporated in
January 1995 and is admittedly marketing the products of respondent No.1. The products of
respondent No.1 are being marketed without the assistance of the petitioner for the last more than
three years. In these circumstances, even assuming the petitioner has a case on merits, in my view, it
will not be entitled to the grant of injunction on the ground of delay alone. The petitioner by its long
silence and conduct has encouraged, acquiesed or in any case assented to the marketing of the
product either by respondent No.1 itself or through the agency of respondent No.2. Though, in view
of the delay in filing of the present application, the Court is not making any observations on the
merits of the case, however, assuming that the petitioner has a case on merits, it is not entitled to the
interim injunction because of the delay in making the application and because of its conduct, as
mentioned above.
17. There is another reason as to why the petitioner is not entitled to the grant of interim injunction
till the decision of the suit. The products which were agreed to be marketed through the agency of
the petitioner are life saving drugs. One of the products, namely, "Enoxaparine" being marketed
under the trade mark "Clexane" is prescribed for and used to prevent "Pulmonary Embolism" which
leads to heart attacks. As per averments made in the reply, which is not refuted by way of rejoinder,
the said drug or medicine is manufactured and marketed by respondent No.1 in the form of prefilled
syringes containing Enoxaparin 20 mg/0.2 ml. and 40 mg/0.4 ml. and 60 mg/0.6 ml. in a carton or
box containing two such syringes for subcutaneous or intravascular injection. The said drug or
medicine is very widely and efficaciously used all over the world for treatment of certain diseases
such as "Hamoestatis" which is a process by which the human body takes steps to prevent bleeding
in case of injury, trauma, and the like. The said drug is stated to be a highly sophisticated and
therapeutically effective drug for the prevention of heart attacks. Grant of injunction, therefore,
would not be in larger public interest as the same may result in denial of life saving drug "Clexane"
to heart patients all over India resulting in grave and irreparable loss, injury and consequences to
patients. In case, the petitioner ultimately succeeds in proving that the termination of the agreement
was illegal, prima facie, it appears to the Court that the petitioner can be compensated with damages
for such illegal termination of the contract and it will not suffer any injury much less irreparable
injury if the injunction is not granted in its favour.Brawn Laboratories Ltd. vs Rhone Poulenc Rorer S.A. & Anr. on 1 May, 1999

18. For the reasons stated above, in my opinion, the petitioner is not entitled to the discretionary
relief of injunction in this case. The application is accordingly dismissed with no order as to costs.
19. Any observation made in this order is only a prima-facie view of the court and it will not have
any effect on the merits of the case.Brawn Laboratories Ltd. vs Rhone Poulenc Rorer S.A. & Anr. on 1 May, 1999

