Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26
August, 2016
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
    IN THE COURT OF SPECIAL JUDGE−03 (P. C. ACT) (CBI),
            PATIALA HOUSE COURTS, NEW DELHI
CC No. 19/13
RC No. AC−1/2012/A0001/CBI/AC−1/ND
Central Bureau of Investigation
Versus
(1)         Anup Kumar Srivastava
            S/o Sh. V. S. Srivastava
            R/o D−2/137, Kaka Nagar,
            New Delhi
(The   proceedings   against   this   accused   were   quashed   by   Hon'ble   High 
Court of Delhi vide order dated 21.11.2013 in CRL. M.C. 4360/2012 )
(2)         Lallan Ojha
            S/o Late Sh. Babu Nandan Ojha
            R/o 21, Savita Vihar, 
            Near Anand Vihar, New Delhi−92
(3)         Hemant Gandhi
            S/o Sh. Mool Shankar Gandhi
            R/o H. No. 11, New Sainik Vihar,
            Pitampura, New Delhi.
(He is declared Proclaimed Offender vide order−sheet dated 14.03.2016)
(4)         Dilip Aggarwal
            S/o Late Sh. Dwarka Prasad Aggarwal
            R/o. BM−160, Shalimar Bagh (West),
            Delhi−110088.
(5)         Anand Aggarwal
            S/o Late Sh. Mohan Lal Aggarwal,
CC No. 19/13                                                                                                Page No. 1 of 140
 CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
            R/o. 13/41, Punjabi Bagh (West),
            New Delhi−110026.
Date of filing of charge−sheet         :        29.02.2012
Date of conclusion of final arguments  :        25.07.2016
Date of announcement of judgement      :        26.08.2016
JUDGEMENTCbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

1. This   case   was   registered   on   the   basis   of   source  information   on   02.01.2012   under  
section   120−B   IPC   r/w  7,8,10,12   and   13   (2)   r/w   13   (1)   (d)   of   Prevention   of 
Corruption Act ,1988.
2. As  per prosecution, Hemant  Gandhi (A−3) resident  of  House   No.   38,   Ground   Floor,   Road
  No.   52,   Punjabi   Bagh  West,   New   Delhi     is   having   close   contacts   with   Dr.   Anup 
Kumar Srivastava (A−1), Commissioner, Central Excise Delhi−1 
Commissionerate, Central Revenue Building, I P Estate, ITO,  New Delhi R/o D−
II, 137, Kaka Nagar, New Delhi, Lallan Ojha  (A−2),   Superintendent,   Central   Excise,   Central  
Revenue  Building,   New  Delhi   R/o  21,  Savita   Vihar,  Delhi   and   other 
officials of Central Excise Deptt., Delhi and Hemant Gandhi  (A−
3) is acting as a middleman for these officials of Central 
Excise, Delhi for obtaining illegal gratification by corrupt and 
illegal means from the businessmen for the aforesaid public 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
servants and delivering the same to these officials. 
3. On   28.12.2011,   a   team   of   officials   of   Central   Excise,  Delhi−I, led by Lallan Ojha (A−
2), Superintendent conducted  an illegal raid at the godown/premises of Dilip Aggarwal (A−
4) and Anand Aggarwal (A−5) at 71/7, A−4 First Floor Rama  Road,   Najafgarh   Road  Industrial
 Area,  New Delhi−  110015.  Lallan   Ojha   (A−2),   in   conspiracy   with   Dr.   Anup   Kumar 
Srivastava (A−1), Hemant Gandhi (A−3) and others negotiated 
with the owners of godown for an illegal gratification in lieu 
of not taking any action against them and finalised the bribe 
amount of Rs. 60 lacs to be paid by these private persons. 
This was telephonically conveyed by Lallan Ojha (A−2) to Dr.  Anup Kumar Srivastava (A−
1) through Hemant Gandhi (A−3).  It is further learnt that Hemant Gandhi (A−3) was in regular 
touch with Dilip Aggarwal (A−4) and Anand Aggarwal (A−5)  and   received   from   them   on  
30.12.2011   a   huge   amount   of  money as part of the illegal gratification alongwith a cheque 
of Rs. 20 Lakhs issued by Anand Aggarwal (A−5) as security  for   the   remaining   amount.  
Further,   on   request   of   Dilip  Aggarwal (A−4), Hemant Gandhi (A−3) spoke to Lallan Ojha  (A−
2)   and   Dr.   Anup   Kumar   Srivastava   (A−1)   for   some 
concession in the amount of illegal gratification. 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
4. As   per   prosecution,   both   the   public   servants   asked  Hemant Gandhi (A−
3) to meet them in their office located at  ITO, New Delhi on 02.01.2012. Lallan Ojha (A−
2) also asked  Hemant Gandhi (A−3) to bring Rs. 3 lacs, as his part of share  from   the   amount   of  
illegal   gratification   obtained   as   above  from Dilip Aggarwal (A−
4). It was reliably learnt that Hemant  Gandhi (A−
3) would send Rs. 3 lakhs to be delivered to Lallan  Ojha (A−2) at his ITO office on 02/01/2012. Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

5. Dr.   Anup   Kumar   Srivastava   (A−1)  was   posted   as  Commissioner,   Central   Excise   Delhi−I
  since   March   2010.  Hemant   Gandhi   (A−3)   is   a   Private   person   and   as   per  intercepted  
conversations   received   from   Special   Unit,   CBI, 
Delhi and as stated by PS to Commissioner, Central Excise,  Delhi−I,   he   was   in   regular   contact  
with   Dr.   Anup   Kumar  Srivastava   (A−1)   telephonically   and   also   through   personal 
meetings for the last 5−7 months and Hemant Gandhi (A−3) 
got organized illegal Excise searches under the directions and 
protection of Dr Anup Kumar Srivastava (A−1), through the 
subordinate officials of Dr. Anup Kumar Srivastava (A−1) for 
collecting illegal gratification from the parties so raided.  The 
same is also corroborated by their mobile phone CDRs. 
6. As per prosecution, Lallan Ojha (A−2), was transferred 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 to  
Office   of   Commissioner,   Central   Excise   Delhi−I   in   Audit 
Branch in July 2010 and thereafter he was posted in Anti−
Evasion Branch in November 2010 as Supdt (Anti Evasion). 
As per intercepted telephonic conversation between Hemant  Gandhi (A−
3) and Dr. Anup Kumar Srivastava (A−1), he was 
chosen for an illegal raid to be conducted on 28.12.2011. The 
entire conversation shows that the search was conducted by  A−
2 with the sole motive of obtaining illegal gratification for  himself,   Dr.   Anup   Kumar   Srivastava  
(A−1)   and   Hemant  Gandhi (A−3). These conversations also show that the owner 
of the premises Anand Aggarwal (A−5) and his associate Dilip  Aggrawal (A−
4) were pressurized to obtain illegal gratification  and   finally   a   settlement   was   reached   for   an
  illegal  gratification of Rs 60 lacs. 
7. Sh.   Manoj   Shukla,   Ld.   Senior   Public   Prosecutor  submitted  that   Hemant   Gandhi   (A−3)  
was   acting   as  middleman of Dr. Anup Kumar Srivastava (A−1) for collection 
of illegal gratification by scouting for his known businessmen 
who could be raided and illegal gratification extracted from  them for himself and A−
1 Dr.  Anup Kumar Srivastava. It has  also been revealed that he the name of A−2  Lallan Ojha was 
pre−decided   by   Dr.   Anup   Kumar   Srivastava   (A−1)   for   the 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
planned   operation   and   accordingly,   Lallan   Ojha   (A−2)   was 
deputed for carrying out  the said illegal raid. 
8. Ld. Senior Public Prosecutor has further submitted that  Anand   Aggarwal   (A−5)   is   the   owner
  of   the   godown   of   the  imported   mobile   phones   located   at   71/7,   A−4   First   Floor  Rama  
Road,   Najafgarh   Road   Industrial   Area,   New   Delhi− 
110015 Industrial Area and Dilip Aggarwal (A−4) is a client  and associate of Anand Aggarwal (A−
5) and is having good  business relations with him. Dilip Aggarwal (A−4) is a known  person   of  
Hemant   Gandhi   (A−3)   for   the   last   ten   years. 
Therefore, on receipt of the information about a raid on the  godown of Anand Aggarwal (A−Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

5), not knowing that the said  raid   was   got   done   by   Hemant   Gandhi   (A−3)   himself,   A−5 
contacted Hemant Gandhi (A−3) for help. Hemant Gandhi (A−
3) in turn communicated the vulnerability of Dilip Aggrawal  (A−4) and Anand Aggarwal (A−
5) to Lallan Ojha (A−2), asking  him to demand huge amount of illegal gratification.  Hemant 
Gandhi (A−3) also collected Rs 20 lacs in cash and a cheque of  Rs 20 lacs from Anand Aggarwal (A−
5) directly for himself,  Dr. Anup Kumar Srivastava (A−1) and Lallan Ojha (A−2). 
9. Ld. Senior Public Prosecutor has further submitted that  on   23.12.11,   Hemant   Gandhi   (A−3)  
contacted   Dr.   Anup 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 Kumar
  Srivastava   (A−1)   indicating   to   do   "some   work"   and  asked him to depute Lallan Ojha (A−
2) or somebody else as  chosen by Dr. Anup Kumar Srivastava (A−1) for the said work, 
however, Dr. Anup Kumar Srivastava (A−1) was busy on that  day and directed Hemant Gandhi (A−
3) to meet him the next  day. On 27.12.2011, Hemant Gandhi (A−3) sought permission 
of Dr. Anup Kumar Srivastava (A−1) to meet him in his (i.e. 
Dr. Srivastava's) office and Dr. Anup Kumar Srivastava (A−1) 
agreed to meet him. On that day, Dr. Anup Kumar Srivastava  (A−1) introduced Hemant Gandhi (A−
3) to Lallan Ojha (A−2)  and in the meeting between these three, Lallan Ojha (A−2) 
was deputed for conducting an illegal raid at the premises of  Anand   Aggarwal's   (A−5)   godown  
at   Rama   Road   Industrial  area, Near DHL Office, Delhi. The fraudulent nature of the  search  as 
well   as  the   entire   motive  for  collection  of  illegal  gratification   is   established   through   the  
intercepted  conversations of  Hemant Gandhi (A−3) with Lallan Ojha (A−
2) and Dr. Anup Kumar Srivastava (A−1). A−3 Hemant Gandhi  kept   Dr.   Anup   Kumar  
Srivastava   (A−1)   informed  telephonically about the  recoveries during the search, success 
of the mission (i.e. the illegal search) and the settlement for 
an illegal gratification of Rs 60 lacs in a cryptic language by 
saying "Mission successful" and "Six zero". These inputs were 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
acknowledged by Dr. Anup Kumar Srivastava (A−1) by saying 
"OK". The conversations held between Hemant Gandhi (A−3)  and by Lallan Ojha (A−
2) and those between Hemant Gandhi  (A−3)   and   Dr.   Anup   Kumar   Srivastava   (A−1)   when  
read   in  totality unambiguously establish the motive as well as modus  operandi   of   these   three  
persons   for   receiving   illegal  gratification from Anand Aggarwal (A−5) and Dilip Aggrawal  (A−
4). 
10. Ld. Senior Public Prosecutor has further submitted  that 
96 incriminating conversations, for the period 23.12.2011 to 
02.01.2012, were received during investigation from Special 
Unit (SU) CBI, New Delhi. It is submitted that legal technical 
surveillance was being conducted by SU of telephone/mobile 
calls of the mobile number 9818517000 and landline no 011− 25225641 of Hemant Gandhi (A−
3), mobile no 9560806997  of   Dilip   Aggarwal   (A−4)   and   mobile   numbers   8130000444 Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

and 9811602221 of Lallan Ojha (A−2). These conversations 
show that an amount of Rs. 60 lacs was settled as an illegal  gratification   to   be   received   from  
Anand   Aggarwal   (A−5).  Accordingly, Anand Aggarwal (A−5) paid Rs 20 lacs in cash as  per  
instruction   of   Lallan   Ojha   (A−2)   to   SK   Singh,   Supdt.  Central Excise, Delhi−
I and the remaining amount of Rs 20 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 lacs  
and   a   self−cheque   of   Rs.   20   lacs   as   security   for   the  balance   amount,   to   Hemant  
Gandhi   (A−3).   These  conversations  also  revealed that Hemant Gandhi (A−3) was  the    
middleman   acting   on   behalf   of   Dr.   Anup   Kumar  Srivastava (A−1). 
11. Ld. Senior Public Prosecutor has further submitted that 
on 23.12.2011 (Call No.1) Hemant Gandhi (A−3) contacted  Dr.   Anup   Kumar   Srivastava   (A−1)  
and   asked   to   introduce  Lallan Ojha (A−2) as chosen by Dr. Anup Kumar Srivastava (A−
1) for doing some work on next day. Since Dr. Anup Kumar  Srivastava (A−
1) was busy, therefore, he intimated to Hemant  Gandhi   (A−3)   to   see   him   next   day.   As   per  
call   no.2   dated  27.12.2011, Hemant Gandhi (A−3) confirmed from Dr. Anup  Kumar   Srivastava  
(A−1)   about   his   availability   in   the   Office  and desired to meet in the office. A−
3 was asked by Dr. Anup  Kumar   Srivastava   (A−1)   to   come   to   his   office.   During   this 
meeting, Lallan Ojha (A−2) was also called and deputed for 
conducting the illegal raid. As per call no.3 dated 27.12.2011, 
after the meeting with Dr. Anup Kumar Srivastava (A−1) and  Lallan Ojha (A−
2), Hemant Gandhi (A−3) contacted his source  namely   one   Ashok   Aggarwal   to   provide   the
 address   of   the  party,   which   was   to   be   raided,   which   as   the   later   calls 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
revealed, would establish that Ashok Aggarwal has given the  information   about   the   premises   of
  Anand   Aggarwal   (A−5)  located Rama Road Industrial Area, New Delhi owing to some 
personal enmity. 
12. As per prosecution, in pursuance of aforesaid criminal  conspiracy,   Hemant   Gandhi   (A−3)  
showed   the   business  premises   of   Anand   Aggarwal   (A−5)   located   at   Rama   Road 
Industrial   Area,   New   Delhi   to   Lallan   Ojha   (A−2)   in   the 
evening of 27.12.2011 ( as per call No. 4 and 6).  
13. Ld. Senior Public Prosecutor has further submitted that 
Call Nos.12, 13, 14, 15 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 
26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 38, 39, 40,  41,  42,  43,  44,  45    
 dated 28/12/2011 from 07:20:25   to  13:09:39   prove   that   on   28.12.2011,   in   furtherance   of 
aforesaid conspiracy, Lallan Ojha (A−2), took along with him 
S.K. Singh Supdt., K.N. Srivastava Inspector and Sunil Kumar,  Inspector   of   Central   Excise,  
Delhi   and   illegally   raided   the  above−mentioned  business premises of Anand Aggarwal  (A−
5). Being an illegal raid, no documentation was done during 
or after the raid. Further, in lieu of not taking any legal action Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

for the goods discovered in the business premises, Lallan Ojha  (A−
2), negotiated for an illegal gratification of Rs. 60 Lakhs 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
with Anand Aggarwal (A−5).   In between, Lallan Ojha (A−2) 
informed each and every development to Hemant Gandhi (A−
3) and Hemant Gandhi (A−3) further communicated the same  developments   to   Dr.   Anup  
Kumar   Srivastava   (A−1)   such   as  availability of the stock to the tune of Rs. 3 ½  to 4 crores and 
success of the illegal raid and the settlement of negotiation 
for an illegal gratification of Rs. 60 lakhs. 
14. Ld. Senior Public Prosecutor has further submitted that  as   per   call   no.   46   on   28.12.2011,  
at   in   furtherance   of  aforesaid conspiracy,  furtherance of the aforesaid conspiracy, 
Lallan Ojha (A−2)  informed Hemant Gandhi (A−3) to convey 
the message to the Commissioner Dr. Anup Kumar Srivastava  (A−1)   in   brief   about   the   success
  of   the   illegal   raid   by  communicating, "Mission successful". Lallan Ojha (A−2) asked 
Hemant Gandhi (A−3) to be cautious in communicating the 
message, as telephones may be under surveillance.   On this  Hemant Gandhi (A−
3) assured Lallan Ojha (A−2) not to worry  as he has spoken to Dr. Anup Kumar Srivastava (A−
1) in the  morning   also   and   they   [i.e.   Hemant   Gandhi   (A−3)   and   Dr  Srivastava A−
1)] are used to talking in code words only. It is  also told by Lallan Ojha (A−
2) to Hemant Gandhi (A−3) that it  may be conveyed that he will come at about 2.30−3.00 PM 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
and will then give a further detail. As per call no 47 dated 
28/12/2011 at 13:26:01 hrs., Hemant Gandhi (A−3) tried to  contact   Dr.   Anup  Kumar
 Srivastava (A−1) but  the  PS to Dr  Srivastava (A−1) informed that the Commissioner had gone in 
the meeting and as and when he comes back, she will call  back. This 
call immediately follows the directions of Lallan  Ojha (A−
2), and thus clearly establishes the involvement of  Dr. Anup Kumar Srivastava (A−
1) in the criminal conspiracy to  conduct an illegal search for obtaining illegal gratification. 
15. Ld. Senior Public Prosecutor has further submitted that  as   per   Call   No.   48   dated  
28/12.2011   at   13:33:08   hrs.,  Hemant Gandhi (A−3) informed Mahender Kapoor, one Supdt, 
Central   Excise,   about   the   success   of   the   "Misson"   and 
discussed that the matter is settled for Rs 60 lakhs, which the  Party   will   pay  tomorrow. He  asks
 Mahender Kapoor  not  to  disclose this figure, as he has not informed even "Muchhad"  [i.e.   Anup  
Kumar   Srivastava   (A−1)].   Mahender   Kapoor  already   knew   through   Lallan   Ojha   (A−2)  
about   the   said  fraudulent   raid   and   the   involvement   of   Dr.   Anup   Kumar  Srivastava (A−
1). He has also given statement u/s 164 Cr. PC  to   establish   the   facts   in   his   knowledge   about  
the   said  incidence and also about having received Rs 7.50 Lakhs from 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Hemant Gandhi (A−3) on 30.12.2011, which Hemant Gandhi  (A−3) owed him. Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

16. Ld. Senior Public Prosecutor has further submitted that 
as per Call No. 51 dated 28/12/2011 at 16:12:06 hrs., Dr.  Anup   Kumar   Srivastava   (A−1)   called  
Hemant   Gandhi   (A−3)  through his PS, as he was busy in a meeting when Hemant  Gandhi   (A−3)
  had   tried   to   contact   him   earlier.   As   per   this  conversation,   it   is   informed   by   Hemant  
Gandhi   (A−3)   that,  "mission   successful",   settlement   for   "six   zero"   (Rs   Sixty 
Lakhs), as per the direction of Lallan Ojha (A−2) vide call No 
46. 
17. Ld. Senior Public Prosecutor has further submitted that  Hemant Gandhi (A−
3) informed one Amit that Dilip Aggrwal  was   the   person   whose   premises   got   raided   and  
Dilip  Aggarwal (A−4) has been following the party since morning.  Hemant   Gandhi   (A−3)   also  
informed   that   he   is   in   direct  contact   with   the   Excise   officer   and   that   the   deal   has  
been  finalized and that the payment will made tomorrow. He also 
informed that it was the team of the "Mucchad" [i.e. Dr A.K.  Srivastava(A−
1)]. The above discussion is in call no 52, dated  28/12/2011   at   17:53:09   hrs.   As   per   call   no.  
54,   Hemant  Gandhi (A−3) discussed with Ashok Aggarwal in the evening 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
on 28/12/2011 that they should not reveal that the illegal  raid   was   got   done   by   them   as   it  
will   hurt   their   market  reputation. It is specifically asked by Ashok Aggarwal whether  the   party  
of   Central   Excise   Deptt.   was   deputed   by   Dr  Srivastava on which, Hemant Gandhi (A−
3) confirmed that it  was indeed a party of Dr. Anup Kumar Srivastava (A−1). 
18. As per prosecution, Call No. 55 dated 29/12/2011 at 
13:19:50 hrs. reflects that it is informed by Hemant Gandhi  (A−3) to Lallan Ojha (A−
2) that he is in the office of Central  Excise and requests Lallan Ojha (A−2) to meet him outside the 
main gate where he was waiting. As   per   Call   No.56   dated  30/12/2011   at   08:54:31   hrs.,  
Lallan   Ojha   (A−2)   informed  Hemant   Gandhi   (A−3)   from   his   mobile   no.   8130000444 
stating that it was his new no. and it has not been shared 
with anyone else. On 28.12.2011 also, Lallan Ojha had used  the   mobile   of  K   N   Srivastava, one  
of the  Inspectors  in   the  raiding team, and not his own mobile. As per this call, it is 
discussed that there was a 99% chance that Anand Aggarwal  (A−
5) will deliver the money today itself and if there is any 
delay then directions will be given to Hemant Gandhi (A−3) to 
remain in his contact. This again shows a conspiracy between 
them.  As per Call No.57 dated 30/12/2011 at 10:17:37 hrs., 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
there is a discussion between Lallan Ojha (A−2) and Hemant  Gandhi (A−
3) in a coded language that the bribe amount was 
decided to the tune of Rs 60 lacs but today he has delivered  only Rs 20 lacs. 
19. Ld. Senior Public Prosecutor has further submitted that  as   per   direction   of   Lallan   Ojha  
(A−2),   S.K.   Singh,   Supdt.,  Central Excise collected Rs. 20 lakhs from Anand Aggarwal  (A−
5) at NOIDA.   Further, as per directions of Lallan Ojha (A−Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

2), S.K. Singh contacted Hemant Gandhi (A−3) and delivered 
to him the said amount of Rs. 20 lakhs. S.K. Singh has also 
given statement U/s. 164 Cr.P.C. in which he has stated the  above facts. 
20. Ld. Senior Public Prosecutor has further submitted that 
in the evening of 30.12.2011, Hemant Gandhi (A−3) collected  a cash of Rs. 20 Lakhs as 2 nd 
Installment and a self−cheque  issued by Anand Aggarwal (A−5) of Rs. 20 Lakhs as security 
for balance amount of Rs. 20 lakhs. The details of discussion 
about collection of cheque and the way the amount of Rs. 20  lakhs   collected   from   Anand  
Aggarwal   (A−5)   and   Dilip  Aggarwal (A−4) are available in call No. 60, 62, 63, 64, 69, 
70, 72, 75, 76, 77, 78, 79 all dated 30.12.2011. As per these  calls, Dilip Aggarwal (A−
4) has acted as a mediator on behalf 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 of  
Anand   Aggarwal   (A−5).   Further,   A−4   and   A−5   requested  Hemant Gandhi (A−
3) for some concession in the amount of  illegal gratification, on which Hemant Gandhi (A−
3) agreed to  talk to Dr. Anup Kumar Srivastava (A−1). 
21. Ld. Senior Public Prosecutor has further submitted that  as   per  Call   No.67   dated   30/12/2011
  at   17:28:57   hrs.,  Hemant   Gandhi   (A−3)   tried   to   contact   Dr.   Anup   Kumar  Srivastava  
(A−1)   on   the   office   landline   number   of   the  Commissioner 
 but the PS to Commissioner told that he has 
reportedly gone for some meeting. As per Call No.68 dated 
30/12/2011 at 17:31:31 hrs., Hemant Gandhi (A−3) informed  Dr. Anup Kumar Srivastava (A−
1), that the Party is sitting with  him in another room and requested for some concession to 
the party. Reacting positively, Dr. Anup Kumar Srivastava (A−
1) replied that this can be discussed in the office on Monday,  as he was out of station. 
22. As   per   prosecution,   Lallan   Ojha   (A−2)   asked   Hemant  Gandhi (A−
3) to deliver his share of Rs. 3 lakhs out of the ill− gotten money.   On this, Hemant Gandhi (A−
3) promised to  deliver   the   same   on   31.12.2011   but   due   to   his   prior 
engagement, Hemant Gandhi (A−3) promised to deliver the  same   the   next   day.     There   is   also
  discussion   between   two 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 about  
the   settled   illegal   gratification   of   Rs.   60   lakhs   and  request   of   the   Party   for   some  
concession.   The   above  discussions are in call No. 80, 81, 82, 83 and 84. 
23. Ld. Senior Public Prosecutor has further submitted that  on   02.01.2012   Hemant  Gandhi (A−
3) delivered  Rs. 3 lakhs  through his driver Sh. Rajesh Verma.   Further, Rajesh Verma  contacted  
Lallan   Ojha   (A−2)   after   reaching   outside   the   CR  Building but Lallan Ojha (A−
2) deputed his driver Dilip Kumar  Yadav for collection of the same from Rajesh Verma.  Finally, 
the amount of Rs. 3 lakhs was collected by Dilip Kumar Yadav  at the instance of Lallan Ojha (A−
2) and he kept the same in  boot of the car.  The above discussions are in call Nos. 88 to Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

96. Dilip Kumar Yadav and Sh. Rajesh Verma have also given 
statements U/s. 164 Cr.P.C. about delivery/collection of Rs. 3  lakhs. 
24. Ld. Senior Public Prosecutor has further submitted that 
after registration of the case, a trap was laid at the backside 
parking of C.R. Buildings, where an amount of Rs. three lakhs 
had been kept by Dilip Kumar Yadav, driver of Lallan Ojha (A−
2) in vehicle No.  DL 4C AD 4421 AVEO CHEVROLET (Black  colour).  In the presence of 
 two independent witnesses, an  amount of Rs. 2,96,500/− was recovered by CBI from the boot 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 of   the
  car   No.  DL   4C   AD   4421   AVEO   CHEVROLET   (Black  colour) of Lallan Ojha (A−
2). The car is registered in the name  of Smt Shashi Ojha W/o Lallan Ojha (A−2). 
25. Investigation   revealed  that   voices   available   in   the   96 
recovered conversations are of Hemant Gandhi (A−3), Lallan  Ojha   (A−2),   Dr.   Anup   Kumar  
Srivastava   (A−1),   A−5   Anand  Aggrwal and A−4 Dilip Aggrwal including other prosecution 
witnesses   such   as   S.K.   Singh,   Supdt.,   Mahender   Kapoor,  Supdt.,   Dilip   Kumar   Yadav  
(driver   of   Lallan   Ojha),   Rajesh  Verma   (driver   of   Hemant   Gandhi).     The   voices   have  
been  identified   by   the   independent   witnesses   during   the 
investigation.  The voice of Dr. Anup Kumar Srivastava (A−1) 
has been identified by Smt. Rekha Rani, PS to Commissioner,  Pradeep   Kumar,   Addl.  
Commissioner   and   B.   Mohan,   Dy.  Commissioner.     The   voice   of   Lallan   Ojha   (A−2)   has  
been  identified   by   B.   Mohan,   Dy.   Commissioner   and   S.K.   Singh,  Supdt.     The   voice   of  
Hemant   Gandhi   (A−3)   has   been  identified by Mahender Kapoor, Supdt. 
26. During investigation, the voice samples of Lallan Ojha  (A−2),   Hemant   Gandhi   (A−3),  
Anand   Aggarwal   (A−5)   and  Dilip   Aggarwal   (A−4),   wife   of   Hemant   Gandhi   (A−3),   Dilip 
Kumar Yadav (driver), Rajesh Verma (driver) and Dr. Anup 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 Kumar
  Srivastava   (A−1)   had   been   taken   in   front   of  independent   witness   and   forwarded   to  
Central   Forensic  Science   Laboratory   for   expert   opinion   on   the   questioned 
voices recorded by Special Unit, CBI, New Delhi. A positive  opinion   has   been   received  
regarding   all   samples.   During  investigation,   all   the   mobile   numbers   figuring   in   the 
intercepted communications have been conclusively linked to  the   speaker   of   the   relevant  
content,   either   directly   as   a  subscriber, or as a user. 
27. Ld. Senior Public Prosecutor has further submitted that  investigation   revealed   that   out   of  
the   aforesaid   illegal  gratification amount of Rs. 20 lakhs, an amount of Rs. 7.50 
lakhs was given to Mahender Kapoor by Hemant Gandhi as  repayment   of   his   outstanding   loan  
and   subsequently   an  amount of Rs.6 lakhs was recovered during investigation at  the   instance  
of   Mahender   Kapoor.   The   said   fact   is   also 
covered by Mahender Kapoor in his statement recorded u/s 
164 Cr.P.C. It is also established that an amount of Rs.3 lakhs  was sent by Hemant Gandhi (A−Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

3) to Lallan Ojha (A−2) as a  part   of   his   share   out   of   Rs.   20   lakhs   collected   directly   by 
Hemant   Gandhi   (A−3).     The   said   fact   has   been   proved   by  recovery of Rs. 2,96,500/−
 from the vehicle of Lallan Ojha (A−
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
2) on 02.01.2012 in the presence of independent witnesses.  The   shortfall   is   due   to   lesser  
number   of   currency   notes   in  some bundles. There is also evidence of Rajesh Verma, driver  of  
Hemant   Gandhi   (A−3)   and   Dilip   Yadav,   driver   of   Lallan  Ojha (A−
2) that Rajesh handed over Rs. 3 lakhs in a polythene 
bag to Dilip Kumar Yadav.  The said facts also established by 
both the drivers in the statement given u/s 164 Cr.P.C. Of the 
remaining amount out of Rs. 20 lakhs [20−7.5 (refer above)− 3.0=   Rs.   9.5   lakhs],   Rs.   8.6  
lakhs   was   recovered   from  possession   of   Hemant   Gandhi   (A−3)   and   Rs.   1   lakh   was 
claimed to have been spent on New Year party. Apart from  above,   a   self−cheque   of   Rs.   20  
lakhs   issued   by   Anand  Aggarwal   (A−5)   was   also   recovered   from   the   possession   of 
Hemant Gandhi (A−3). 
28. Ld. Senior Public Prosecutor has further submitted that 
the fraudulent raid was carried out by Lallan Ojha (A−2) in 
criminal conspiracy with Hemant Gandhi (A−3) and Dr. Anup  Kumar   Srivastava   (A−1),   which  
is   established   by   the   other  team members of the raiding party consisting of S.K. Singh, 
Supdt., Central Excise, Sunil Kumar, Inspector, Central Excise 
and K.N. Srivastava, Inspector Central Excise that Lallan Ojha  (A−
2) has conveyed to them that the said raid was carried out 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
as per instruction of Dr. Anup Kumar Srivastava (A−1).   All  these   three   team  members have  
given  statement   UI/s.  164  Cr.P.C. in this regard.  
CHARGE 
29. In   view   of   the   aforesaid   allegations,   a   charge 
under Section 120B IPC r/w 7, 12 & 13 (2) r/w 13(1)(d) of 
Prevention of Corruption Act 1988 was framed against all the  accused persons.
30. A   separate   charge  under   Section   7,  12  &  13(2) 
r/w Sec. 13(1)(d) of Prevention of Corruption Act 1988 was 
framed against accused Anup Kumar Srivastava (A−1).
31. A separate charge under Section 7, 13(2) r/w Sec. 
13(1)(d) of Prevention of Corruption Act 1988 was framed  against accused Lallan Ojha (A−2).
32. A separate charge under Section 12 r/w Section 7  of   Prevention   of   Corruption   Act   1988  
was   framed   against  accused Hemant Gandhi (A−3).Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

33. A separate charge under Section 12 r/w Section 7  of   Prevention   of   Corruption   Act   1988  
was   framed   against  accused Anand Aggarwal (A−5) and Dilip Aggarwal (A−4).
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
PROSECUTION EVIDENCE
34. The   witnesses   examined   by   prosecution   are  enlisted as under :
   S.        PWs                                Name of Witnesses                                               Paging
  No.
   1.       PW−1 Rajesh Verma S/o Sh. Badri Prasad                                                              95−227
   2.       PW−2 Dilip Kumar Yadav S/o Sh. Krishan Kumar Yadav                                                 229−357
   3.       PW−3 Pawan Singh, Nodal Officer, Idea Celluar                                                      359−375
   4.       PW−4 Anuj Bhatia, Nodal Officer, Vodafone Ltd.                                                     377−399
   5.       PW−5 Akhtarul Haneef, Director(Vig), NDMC                                                          401−421
   6.       PW−6 Rekha Rani W/o Chander Prakash                                                                423−487
   7.       PW−7 Mahesh Kumar S/o Sh. Om Prakash                                                               489−529
   8.       PW−8 Dr. John Joseph, The then Commissioner,                                                       531−551
                 Custom & Central Excise, Delhi−01
   9.       PW−9 Pradeep Kumar, Commissioner, Central Excise                                                   553−575
Building, Tikrapara, Raipur, Chattisgarh
10. PW−10 Virendra Kumar, Hawaldar, Central Excise,  577−587 Nehru Place, New Delhi
11. PW−11 B. Mohan, Dy. Commissioner, Central Excise,  589−617 Large Tax Unit (LTU), Delhi
12. PW−12 S. K. Singh, Superintendent, Service Tax Head  619−659
Quarters, Near WHO Building, New Delhi
13. PW−13 A. D. Tiwari, SSO, Grade−I, CFSL 661−697
14. PW−14 Sunil Verma, LDC, Dept of Central Zone, MCD,  699−731 Lajpat Nagar, New Delhi
15. PW−15 M. C. Kashyup, Dy. SP, CBI, Spl. Unit, ND 733−763
16. PW−16 Dr. Rajirder Singh, Director, CFSL, New Delhi 765−789
17. PW−17 Tarun Khurana, Ex. Nodal Officer, Bharti Airtel  791−803 Ltd.
18. PW−18 Punit Mehta S/o Sh. Shyam Sundar Mehta 805−823
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
19. PW−19 Ms. Surbhi Sharma Vats, Ld. MM, PHC, NDD 825−833
20. PW−20 Vinod Kumar Sharma, Clerk, O/o Commercial  835−839 Record Section/Branch, MTNLCbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

21. PW−21 Sunil Kumar, Superintendent, Central Excise,  841−855
Ambala Division, Panchkula, Commissionerate,  Haryana, Delhi Zone
22. PW−22 Mahendra Kapoor S/o Lt. Sh. K. L. Kapoor 857−885
23. PW−23 R. C. Kataria, Retd. DGM, MTNL 887−891
24. PW−24 Ms. Meenakshi Sahney D/o Sh. K. K. Aneja 893−895
25. PW−25 Vishwadeep Bhist, S/o Sh. Gajpaal Bisht 897
26. PW−26 Gurwinder Singh, Commercial Officer, Eastern  899−901
Court, MTNL, Janpat, New Delhi
27. PW−27 Prem Lal Kukreti S/o Lt. Sh. Bishumber Dutt 903−927
28. PW−28 Sh. Sudesh Kumar, Ld. MM, PHC 929−935
29. PW−29 K. N. Srivastava S/o Sh. S. B. L. Srivastava 937−949
30. PW−30 J. P. Singh S/o Lt. Sh. Ganga Prasad 951−961
31. PW−31 K. Ramesh, Section Officer, Pawan Hans  963−969 Helicopter
32. PW−32 Arvind Bansal, LD. MM., PHC, NDD 971−975
33. PW−33 Saurabh Gandhi S/o Vijay Ghandi 977−979
34. PW−34 P. K. Gottam, SSO−I, CFSL, CBI 981−991
35. PW−35 N. P. Mishra, DSP, CBI, SC−III 993−999
36. PW−36 Inderpal S/o Sh. Bheem Raj 1001
37. PW−37 Ram Singh, Dy. SP, CBI, ACB 1003−1051
35. I   would   like   to   discuss   the   testimonies   of   the  aforesaid witnesses at appropriate places.
Statements under Section 313 Cr.PC
36. All the accused persons denied all the allegations 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
put to them.Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

Defence Evidence of Lallan Ojha (A−2)
37. A−2 examined following witnesses in defence :
1. A−2/ DW−1 Smt. Shashi Ojha, who testified as under :
"I am a Director in SJIT Services Pvt. Ltd.  The said firm is  engaged   in  
manufacturing   of   plastic   cutlery   and   cloth  hanger. 
 We are manufacturing cutlery for domino pizza 
and hanger for Wardrobe.  Both my sons are also Director  and they help me. 
On   2nd  January   2012,   my   husband   Lallan 
Ojha left the house at 7:30 AM and I was to accompany my 
niece and her husband to AIIMS for treatment of their son.  My   niece   had   given  
me   Rs.50,000/−   to   be   deposited   in  AIIMS. 
 I had kept that money in a white envelope and  kept  in a  shopping  bag
 colour white & red.    I  had kept  Rs.3,00,000/−
 in the same bag.  The cash was kept to make 
the payment to the workers and to buy raw material for 
the factory and some money was to be deposited in AIIMS,  out   of   the   cash.     The
  cash   was   of   company   and   it   is 
reflected in the account book of the company as cash in 
hand on that day.  Out of that money, I paid 3,500/− to my 
nephew to be spent in the factory as he was leaving for 
factory at 8:00 AM.  I kept this entire money in the above 
mentioned shopping bag in the dickey of my car no. DL− 4C−
4421.  My niece had taken sometime to be get ready as  I   was   taken   to   AIIMS,  
when   I   came   down   and   when   I 
reached down, I found our driver Dilip had left the house 
with the lunch of Mr. Ojha and he was also to pick up Mr.  Ojha  to AIIMS.   I  kept
 waiting  till  12:00/12:30 am  and  tried to call Dilip and my husband. 
 I had also dialed the  number of office but I could not contact my husband and 
the driver. Thereafter I received the call of my son stating 
that why I have not reached in the factory with cash. I told 
him to come back home as the car had not come back from 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
the office and driver and my husband had not contacted 
me. CBI came to search our house but they did not disclose  anything   to   me.   At  
about   07:55   p.m.,   my   elder   son 
received a message that my husband had been arrested by 
CBI. I immediately checked the reason of his arrest and I 
was informed that some money had been recovered from  the  car  and  I   informed  
the  officers   that   the  money   was 
kept by me in the car. The total amount kept by me in the  car   was   Rs.3,46,500/−.  Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

The   CBI   officers   present   in   my 
house, did not record my statement and when I wanted to 
leave my house to the CBI office, I was not permitted to 
leave my house and I was informed that in case I made any 
issue out of it, me and my son would be arrested. After 2 - 
3 days, I met CBI officer Ram Singh, IO of this case and 
informed him about this money on which he told me if I  made   an   issue   out   of   it,
  me   and   my   son   would   be  arrested."
2. A−2/DW−2   Ajay   Kumar   Sahu,   Inspector   Vigilance,  Central Excise, Delhi−
1, who testified as under :
"I  have  brought   the  summoned   record  pertaining  to  the  complaint   against  
Dr.   A.   K.   Srivastava;   the   copy   of   the 
letter to CVC dated 16.12.2011; copy of the letter dated 
07.09.2011 from the office of Commissioner to Additional 
Director General; copy of letter dated 23.12.2010 by Anup  Kumar   Srivastava   to  
Sh.   Ram   Jethmalani,   Advocate, 
President, Supreme Court Bar Association; copy of letter  dated   22.11.2011   from  
the   Commissioner   of   Central  Excise−I,   by   Additional   Commissioner   to  
Additional  Commissioner   (Vigilance),   DGOV.   The   same   are  collectively
 Ex.DW2/A (Colly.) (A−2) (18 pages). Copies 
of the same are placed on record and OS&R."
Defence Evidence of Dilip Aggarwal (A−4) He   examined  Man   Mohan   Goel   (A−4/DW−1),   a 
Chartered Accountant, who proved the Income Tax Returns of 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
five years i.e. 2011−2012 to 2015−2016 filed by accused Dilip  Aggarwal through him.
Defence Evidence of Anand Aggarwal (A−5)
38. A−5   examined  Sushil   Kumar   (A−5/DW−1),   who  testified as under :
"I   am   12th   passed  and   I   am   working   as   an   Accountant 
with accused Anand Aggarwal (A−5) for last about 8 years. 
As an Accountant, I see accounts of his business.   I look 
after the Income Tax return of Anand Aggarwal (A−5) and 
get it audited from Chartered Accountant.  I have brought  the   copies   of   the  
income   tax   returns   filed   by   New   Sky  International,   which   is   under   the  
sole   proprietorship   of  Anand   Aggarwal   (A−5).     These   returns   are   from   the 
assessment year 2010−2011 to the assessment year 2014−
2015 I.e of five years, which are collectively exhibited as  Ex.A−5/DW−1−
A (colly).  I identify the signature of Anand  Aggarwal (A−5) on these returns.  Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

Sh.   Anand   Aggawal   (A−5)   carries   on   the 
business of mobile trading and sanitary goods through the 
aforesaid proprietorship concern.
XXXXX by Sh. S. C. Sharma, Ld. Sr. P. P. for CBI.
The office of M/s New Sky International is  situated on 63−B,
 Second Floor, Rama Road,  Kirti  Nagar 
since 2008.  I do not know the place where the godown of  M/s New Sky 
International is situated.   I do not know if  the  godown   of  M/s   New   Sky 
International   is  located  at  71/7,   A−4,   First   Floor,   Rama   Road,   Najafgarh  
Road,  Industrial   Area,   New   Delhi.     I   have   no   idea   about   the  distance  of 
63−B,   Second   Floor,   Rama   Road,   Kirti   Nagar  and 71/7,  A−4,  First
 Floor, Rama Road,  Najafgarh Road, 
Industrial Area, New Delhi as I am sitting only on 63−B.  I 
do not know about the raid conducted by the officials of  Central   Excise,   Delhi   on  
28.12.2011   at   the  godown/premises i.e. 71/7, A−4, First Floor, Rama Road, 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Najafgarh Road, Industrial Area, New Delhi.
It is correct that as per the return for the  assessment   year   2012−2013   the   gross  
turn   over   of   M/s  New Sky International is Rs.2,77,20,416/−.
It is incorrect to suggest that I am deposing 
falsely/showing ignorance in respect of raid conducted by  Central   Excise   on  
28.12.2011   to   save   my   employer  accused Anand Aggarwal.  
I know Dilip Aggarwal as I have seen him 2 
to 4 times in the office of M/s New Sky International.  He 
used to visits the aforesaid office in respect of the trading  of mobile phones.  
XXXXX by Lalan Ojha (A−2).
Nil.  Opportunity given.
XXXXX by Sh. Satya Prakash, adv. for Dilip Aggarwal  (A−4).
Question: I   put   it   to   you   that   there   is   no   business 
relationship between Dilip Aggarwal and Anand Aggarwal.  What you have to say?
(question is strongly opposed by Ld. Senior Public  Prosecutor   on   the   ground  
that   the   counsel   who   had  examined the witness in chief on behalf of A−
5 is asking a  leading question on behalf of A−4 and thereby prejudicing  the 
prosecution.     I  have   considered   this  submission  and  although   I   find  Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

substance   in   the   arguments   of   Ld.   Se. 
Public Prosecutor, I am of the opinion that the right of an  accused   to   cross  
examine   a   witness   produced   by   a   co−
accused should not be curtailed.  However, I am further of 
the opinion that propriety demanded that A−4 should have  engaged   a   separate  
lawyer   and   should   have   sought 
permission to cross examine the witness prior to the cross 
examination by Ld. Senior Public Prosecutor.  Nonetheless, 
I permit Ld. Counsel for A−4 to cross examine the witness.) Answer: It is correct."
Mobile phones, its users/ owners 
39. Prosecution has placed reliance on the call details 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
as well as the intercepted calls. In order to understand as to 
who is the owner/ user of the mobile phones in question and  the   relevant   CDRs   of   the   said  
phones   and   the   Customer  Application Form (CAF), I have culled the testimonies of the 
prosecution witnesses and I am putting the same in tabular  form as under :
 Sl.          Phone                                                                                     Document/
                                  Name of Subscriber                    Proved by PW
 No.         number                                                                                      Exhibit
1.       8750017000 Hemant Gandhi                                     PW3 Pawan                     D−66 [PW3/B 
                                                                      Singh,                        (CAP) (CDR−
                                                                      Nodal Officer,                PW3/E & F)]
                                                                      Idea Cellular
2.       9811697334 Inder                                             PW4 Anuj                      D−54 [(PW4/B 
                                                                      Bhatia                        (CAF
                                                                      Nodal Officer                 D−61 PW4/J & 
                                                                      Vodafone                      K−CDR, CDR 
                                                                                                    with 65B 
                                                                                                    certificate
3.       9999919999 Joginder Khurana                                  PW4 Anuj                      D−55 [PW4/C 
                                                                      Bhatia                        CAF
                                                                      Nodal Officer                 D−61 PW4/J & K 
                                                                      Vodafone                      CDR
4.       9899016666 Hemant Gandhi                                     PW4 Anuj                      D−56 [PW4D - 
                                                                      Bhatia                        CAF
                                                                      Nodal Officer                 D−61− CDR with 
                                                                      Vodafone                      65B certificate
5.       9582000505 Nitin Gandhi                                      PW4 Anuj                      D−57 [PW4/E−
                                                                      Bhatia                        (CAF)
                                                                      Nodal Officer                 D−61 - PW4/J & 
                                                                      Vodafone                      K - CDR
6.       9953248659 Swatantra Paul                                    PW4 Anuj                      D058 [PW4/F - 
         called from  used by Lallan Ojha                             Bhatia                        (CDF]
         spot made by  (in Cell No.4, 6,                              Nodal Officer 
         this phone                                                   VodafoneCbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

 CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
 Sl.          Phone                                                                                     Document/
                                  Name of Subscriber                    Proved by PW
 No.         number                                                                                      Exhibit
7.       9811602221 Ms Sashi Jha                                      PW4 Anuj                      D−59[PW4/G - 
         (D−25      used by Lallan Ljha                               Bhatia                        CAF
         PW15/F)    (proved by A/M - D−                               Nodal Officer                 D−61 CDR with 
                    3/Ex.PW37/B by                                    Vodafone                      65B certificate
                    which seized from 
                    his possession at the 
                    time of arrest)
8.       9899426957 Dr. A. K. Srivatava                               PW4 Anuj                      D−60[PW4/H - 
                                                                      Bhatia                        CAF
                                                                      Nodal Officer                 D−61 CDR with 
                                                                      Vodafone                      65B certificate
9.       9899623528 Ram Sanei                                         PW4 Anuj                      D−64[PW4/M−1 
                                                                      Bhatia                        - CAF]
                                                                      Nodal Officer                 PW4/R - 
                                                                      Vodafone                      original CAF
                                                                                                    {PW4/N & P - 
                                                                                                    CDR]
10. 9818517000                   Hemant Gandhi                        PW17 Tarun                    D−41 
    on                           used by Hemant                       Khurana                       [Ex.PW17/B 
    surveillance                 Gandhi (proved by                    Nodal Officer                 −CAF]
    (D−21                        arrest memo                          Bharti Airtel
    PW15/B                       Ex.PW27/A
11. 8130000444                   Lallan Ojha                          PW17 Tarun                    D−42 
    On                           used by Lallan Ojha                  Khurana                       [Ex.PW17/C - 
    surveillance                 (proved by arrest                    Nodal Officer                 CAF]
    (D−24                        memo D−3/PW37/B)                     Bharti Airtel
    PW15/e)
12. 9650192981 Usha Rani                                              PW17 Tarun                    D−43 
                                                                      Khurana                       [Ex.PW17/D - 
                                                                      Nodal Officer                 CAF]
                                                                      Bharti Airtel
13. 9910973878 Jitedner Kumar                                         PW17 Tarun                    D−44 [PW17/E - 
                                                                      Khurana                       CAF]
                                                                      Nodal Officer 
                                                                      Bharti Airtel
14. 9650111775 Punit Mehta                                            PW17 Tarun                    D−45 
 CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
 Sl.          Phone                                                                                     Document/
                                  Name of Subscriber                    Proved by PW
 No.         number                                                                                      Exhibit
                                                                      Khurana                       [Ex.PW17/F - Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

                                                                      Nodal Officer                 CAF]
                                                                      Bharti Airtel                 D−49 [Ex.PW17J 
                                                                                                    - CDR]
15. 9810406660 Saurabh Gandhi                                         PW17 Tarun                    D−46 [PW17/G 
               used by Mahender                                       Khurana                       - CAF]
               Kapoor (proved by                                      Nodal Officer                 D−50 PW17/K - 
               PW33 Saurabh                                           Bharti Airtel                 CDR
               Gandhi)
16. 9560806997                   Used by Dilip                        PW17 Tarun                    D−52 PW17/M & 
    on                           Aggarwal (seized                     Khurana                       N - CDR
    surveillance                 from him vide                        Nodal Officer 
    (D033                        seizure memo D−                      Bharti Airtel
    PW15/D)                      8/PW37/D)
17. 25223000                     Hemant Gandhi                        PW20 Vinod                    D−37 PW20/B -
                                 (himself admitted in                 Kumar                         CAF
                                 transcript call no.11.               PW23 R. C.                    D−36 PW23/B - 
                                 Also proved by the                   Kataria - MTNL                CDR
                                 CAF                                  Rajouri Garden
18. 25227000                     Hemant Gandhi                        PW20 Vinod                    D−38 PW20/C
                                 (himself admitted in                 Kumar                         D−36 PW23/C - 
                                 transit call no.11.                  PW23 R. C.                    CDR
                                 Also proved by the                   Kataria
                                 CAF
19. 25225641                     Used by Hemant                       PW20 Vinod                    D−39, PW20/D
    on                           Gandhi                               Kumar
    surveillance                 His self landline 
    (D−22                        number proved by 
    PW15/C)                      CAF D−39.
20. 23378637                     Used by Dr. A. K.    PW26 Gurvinder  D−62 
                                 Srivastava           Singh, MTNL,    [Ex.PW26/B]
                                 in the name  of      Janpath
                                 collector central 
                                 excise (proved by 
                                 PW6 Rekha Rani, his 
                                 PA)
21. 8800338184 Used by Anand 
 CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
 Sl.          Phone                                                                                     Document/
                                  Name of Subscriber                    Proved by PW
 No.         number                                                                                      Exhibit
                                 Aggarwal seized 
                                 from him vide 
                                 seizure memo D−
                                 7/Ex.PW37/C. 
22. 9910973978 Used by Rajesh 
               Verma (PW1)
               (seized vide seizure Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

               memo D−10) PW1 
               Rajesh Verma 
               (admitted)
23. 9899623528 Used by Dilip 
               Kumar Yadav 
               (Driver) (PW2)
               proved by Dilip Kr. 
               Yadav PW2 himself 
               (seized from PW2 
               himself vide seizure 
               memo D−32)
Relevant phone numbers by which calls were made
1. Dilip Aggarwal (A−4) - 9560806997 (Sl. No. 16 above)
2. Lallan Ojha (A−2) - 9953248659, 9811602221,  8130000444 (Sl. No. 6, 7 & 11 above)
3. Hemant Gandhi (A−3) - 9818517000, 25225641 (Sl.  No. 10 & 19 above)
4. Anand Aggarwal (A−5) - 8800338184 (Sl. No. 21  above)
5. Mahender Kapoor (PW22) 9810406660 (Sl.No. 15 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 above)
6. Ashok Aggarwal (proved by PW36) 9811420824 (Sl.  No.2)
7. Dilip Kumar Yadav (PW−2) - 9899623528
8. Rajesh Verma (PW−1) - 9910973978 I may point out that nothing has been brought out 
on record by the defence to disprove the aforesaid particulars. 
Whether   prosecution   has   been   able   to   rule   out   the  possibility   of   tampering   the  
electronic   evidence   i.e.  intercepted calls
40. Prosecution   has   examined   PW−15   namely   M.   C.  Kashyap,   DSP,   CBI,   who   intercepted
  the   calls.   Since   Ld.  Defence counsels have led frontal attack upon the procedure 
adopted by PW−15 in intercepting the calls, segregating them 
and preparing a copy of the same and have argued that due  to   human   intervention   the  
possibility   of   tampering   the  electronic   calls   has   not   been   ruled   out   beyond   reasonable 
doubt. Sh. Rakesh Kumar Sharma, Advocate for A−4 and A−5, 
has submitted that M. C. Kashyap should have issued three  certificates   under   Section   65B   of  
Indian   Evidence   Act,   on  each stage of intercepting the calls, segregating the calls and 
giving copy of the segregated calls. This court is aware that Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
interception of telephonic calls is a very serious issue because  it   not   only 
infringes the right of privacy of individuals but  also due  to  its  being electronic evidence, it
 is very easy to  manipulate   the   same.   Before   discussing   the   aforesaid  arguments   and   in  
view   of   the   seriousness   of  the   questions 
involved, I would like to reproduce the entire evidence of PW−
15 Sh. M. C. Kashyap, DSP, CBI as under :
"I   was   posted  in   Special  Unit     in  1997   and   till  6.2.2014   I 
remained posted there. In Special unit, we collect intelligence  and   for   that  
purpose,   we   do   telephonic   interceptions.   In 
December 2011, certain telephones being used by  Sh. Lalan  Ohja, A−
2,   Sh. Hemant Gandhi, A−3, Sh. Dilip Aggarwal, A−
4 , were intercepted. In January 2012, it was learnt that a 
case was registered against Sh. Lalan Ohja, A−2,   Sh. Hemant  Gandhi, A−
3, Sh. Dilip Aggarwal, A−4, on the request of the 
Branch, 96 relevant calls were provided to the IO Insp. Sh.  Deepak   Purohit   on  
06.01.2012   vide   seizure   memo   in   a 
compact disc along with recorded call information report in a 
sealed packet.  Copy of the said CD along with the recorded 
call information report was also provided for the purpose of 
day to day investigation. The original order   of Union Home  Secretary,     in   respect
  of     5   telephone   numbers,   were   also  provided   through   the  aforesaid  
seizure  memo.   A   certificate  U/S   65   B   of   Indian   Evidence   Act,   in   regard 
to  intercepted  calls   was   also   provided   to   IO   Insp.   Deepak   Purohit   on 
06.01.2012. 
Today   I   have   been   shown   the   seizure   memo 
dated 06.01.2012, vide which  the  abovesaid documents, as  mentioned   therein,  
same   is   now  Ex.PW15/A  (D−20)  and  bears my signatures at Point A.  
The order  of Home Secretary, UOI, dated 22.12.2011, 
is  for interception of phone no. 98185−17000, is Ex.PW15/B  (D−21). 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
The order  of Home Secretary, UOI, dated 22.12.2011, 
is  for interception of phone no. 11−25225641, is Ex.PW15/C  (D−22). 
The order  of Home Secretary, UOI, dated 30.12.2011, 
is  for interception of phone no. 95608−06997, is Ex.PW15/D  (D−23).
The order  of Home Secretary, UOI, dated 30.12.2011, 
is  for interception of phone no. 81300−00444, is Ex.PW15/E  (D−24),
The order  of Home Secretary, UOI, dated 30.12.2011, 
is  for interception of phone no. 98116−02221, is Ex.PW15/F  (D−25).Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

The aforesaid orders were received by me and on the  basis   of   the   said   orders,  
the   interception   of   the   aforesaid  mobile   phone   calls   was   carried   out
 (Objected   to   by   Ld.  Counsel for A−2, A−3, A−4 and A−5 regarding the mode of 
proof submitting that the witness is not the author of the  aforesaid orders).
I am now shown the certificate under Section 
65B Indian Evidence Act (2 pages) and its  Annexure  A (3 
pages), the same was issued by me and it is now Ex.PW15/G  (D−
26) and it bears my signatures at Point A on each page. 
At   this   stage   a   dark   brown   colour   envelope 
with the seal of court (PAB) is opened and is found containing  three brown colour 
 empty envelopes in unsealed condition  and   one   CD   make   Sony   alongwith   inlay   card   in  
protective  cover. This is the same CD, in which aforesaid 96 intercepted 
calls  were burnt. The said CD bears my signatures at Point X  and is already Ex. P−1.  
XXXXX   by   Sh.   Rakesh   Kumar   Sharma,   Counsel   for   A−4 
Dilip Aggarwal & Anand Aggarwal (A−5).
The   mobile number of Dilip Aggarwal (A−4),  calls of which were intercepted, was 95608−
06997.  The calls  of the said mobile number were intercepted and   recorded 
for the period from the day, the order by Home Secretary was 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
taken and i.e., 30.12.2011 onwards. I do not remember till 
what date the said calls were intercepted and recorded. I do 
not remember the total number of calls on this number, which  were intercepted and recorded.  
I   do  not   remember  the total number  of  calls  which   were   intercepted   and   recorded   even  
on   remaining  aforesaid four mobile numbers.
I   was     looking   after   the   interception   and 
recording of such calls, in Special Unit.  The make of the CD 
in which the intercepted and recorded calls were burnt, is not  mentioned   in   certificate   U/S    
65B   Indian   Evidence   Act,  Ex.PW15/G (D−26).   It is correct that make of the CD is not 
mentioned even in seizure memo Ex.PW15/A (D−20).  
I do not remember the total number of calls on 
the aforesaid 5 mobile numbers, which were intercepted and  recorded.   Myself,   my   team   and  
my   seniors   selected  the   96  intercepted and recorded phone calls.  My team consisted of  my  
DIG   Sh.   Anurag,   SP   Sh.   Dinendra   Kashyap,   Insp.   Sh. 
Mukesh Kumar and  Insp. Kumar Abhishek.  The selection of 
calls was made before burning the same onto CD and it was 
done in my office/Special Unit. I do not remember the exact  date     when   such   calls   were  
segregated.     I   do   not   even  remember, the  number of days, between  the segregation of Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

calls and the same being burnt onto CD.  I do not remember 
the number of days spent on selection of 96 calls.  I had heard  all the  intercepted calls.
Ques: Can you tell the number of days spent on hearing the  calls before segregating 96 calls?
Ans.  The calls were heard from the day they were  intercepted   and   recorded   in   our   system  
and   till   they   were  burnt, it is a daily process.
I   again   state   that   as   and   when   the   call   is 
intercepted and recorded, it is attended by us.  After coming 
to know about the facts of the case, after registration of case,  the   calls   relevant   to   the   same  
were   segregated   and   were  given. The calls were reheard before segregation.   I do not  remember
  the   date   when   I   came   to   know   about   the  registration/facts of the case. 
 A written communication was 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
received in respect of the registration/facts of the case.  I do 
not remember the date of written communication.  
The entire team picked up the 96 calls.   It is  correct   that   the   information   about  
registration/facts   of   the  case   was   shared   with   the   entire   team.   The     written 
communication was received by my senior and he briefed the  team.   I   do  not   remember  the 
date  when   this  briefing   took  place.  
At this stage, Ld. Defence Counsel requests that  CD  Ex.P−1,  be  played,   as he  wants  to  confront  
the witness  with calls no. 90 and 91, as per Annexure A of Ex. PW 15/G, 
because transcript of call no. 91 has not been provided to the  accused.     This   fact   is   recorded   in
  order   of   Ld.   Predecessor  Court dated 17.05.2012. Request of Ld. Defence Counsel is  allowed. 
CD Ex.P−1 is played on the laptop produced by  CBI,   make   Sony   Vaio.   Now   the   audio   file  
number   10   -  181521−0−01−20120102−114721.wav (call no. 90) is played.  
Court Observation: Call   No.   90   is   of   441   KB.   The   audio  recording   conforms   to   the  
transcript,   already  PW2/PX−22.  The voices of the speakers are clearly audible.  
On opening the properties of this audio file, it 
shows - "created : Monday, January 2, 2012, 12:18:26 pm       
     modified: Monday, January 2, 2012, 12:18:26 pm      accessed: "
Duration (length) - 56 seconds.
Now the audio file number 10- 181521−0−02− 20120102−
114726.wav (call no. 91) is played.  Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

Court Observation: Call No. 91 is of 403 KB. The contents  of   conversation   in   this  
file   are   the   same  as  in   call  no.   90,  played   earlier   (vide   transcript   already  
MarkPW2/PX−22).  The voices of the speakers are clearly audible.  
On opening the properties of this audio file, it  shows - 
     "created : Monday, January 2, 2012, 12:18:26 pm
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
            modified: Monday, January 2, 2012, 12:18:26 pm      accessed: "
Duration (length) - 51 seconds.
At   this   stage,   the   witness   clarifies   that   the 
duration of the audio file would be same or may defer by one  second,   if   the   same   would   be  
played   in   different   media  players.
Question: Why did you pick up call no. 91,which is same 
as call no. 90.  Was it to replace some other call? Answer: No.     both   the   calls   were   recorded  
on   two  different telephone numbers.  Call no. 90 was intercepted on  mobile   no.   81300−00444  
and   while   the   call   no.   91   was  intercepted on mobile no. 9818517000.
Generally,   only   one   call   (pertaining   to 
conversation between two phone numbers) is picked up.  But 
sometimes, for certain reasons, when both the parties/ phone  numbers   are   on   interception,   the 
conversation   on   both   the  sides/   phone   numbers,   is   picked   up,   as   was   done   in   the 
instant case.  
Question: I put it to you that same was the situation with  respect   to   call  no.   84.     then   why  
did   you   not   pick   up   the  conversation on both the ends?
Answer: I have already stated that generally, we pick up  the conversation only of one side. 
 Because, the contents of  the conversation are the same.
It   is   wrong   to   suggest   that   call   no.   91   was  replaced   and   that   is   why,   the   call   no.   90
  was   copied   and  pasted in call no. 91.   It is wrong to suggest that I did not 
comply requirements of Section 65 B Evidence Act.
It is wrong to suggest that I did not intercept or 
record the calls.  It is wrong to suggest that I did not burn the  said   calls   on   any   CD.     It   is  
wrong   to   suggest   that   I   have  deposed falsely.
XXXXX by Lallan Ojha (A−2) and Hemant Gandhi (A−3).Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

Deferred   at   the   request   of   Lallan   Ojha   (A−2) 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
and Sh. Pankaj Verma, proxy counsel for Hemant Gandhi (A−
3)   on   the   ground   that   main   counsel   were   present   in   the 
morning, but had to leave for a conference/ some matter in  the hon'ble High Court.
Examination dated 11.04.2014 XXXXX by Sh. V.K. Ohri, Advocate for Lallan Ojha (A−2).
The   recording   of   intercepted   calls   of   a 
particular phone number, is carried out only as per the order  of   competent   authority   and   not  
randomly.   The   competent  authority is approached by Director, CBI. I do not know when  did  
Director,   CBI   write   to   competent   authority   for 
interception/ recording of calls in the instant case. I had no  occasion   to   see   the   Director,   CBI's
  letter   in   this   regard.  Volunteered : I only saw the order of the competent authority. 
The recording of the phones in the instant case started on or 
after the date of issuance of order by the competent authority. 
But, I do not remember the date. I do not remember when did 
the interception/ recording of said phones end. I do not sit in  the   office   of   Director,   CBI.   My  
office   was   in   Special   Unit,  Jamnagar House, Akbar Road, New Delhi. The interception / 
recordings were done in the aforesaid office of Special Unit, 
in  this particular case. There is no Telephone Exchange set up  in   the   said   office.   The  
interception   is   being   done   by   using  Voice   Logger   Systems.   The   service   provider   is  
requested   to  intercept     and   forward   each   and   every   communication   in 
respect of the telephone numbers which were ordered by the 
competent authority to intercept for the period mentioned in 
the said order. Such request is made in writing. In the instant  case,   the   requests   for  
interception   and   forwarding   of   calls, 
were made by the Superintendent of Police, Special Unit, CBI, 
New Delhi to the respective Nodal Officers of the telephone 
companies/ service providers. I do not know as to when were 
these letters of request were sent. I do not remember whether 
these letters are on record. I do not wish to refer the record to 
respond, as such letters are matter of record. 
There  is  a   diary  and  dispatch  register  in  our 
office. It is correct that Dak sent and received is diarized. I 
have now seen the orders already Ex.PW15/B to Ex.PW15/F.  Further   cross−examination   is  
deferred   for 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
02:00 p.m. as it is already 01:30 p.m.  RO & AC                 (Poonam A. Bamba)
                  Special Judge (PC Act)/ CBI−03/ND            11.04.2014   Further   cross−examination   of  
the   witness  (PW−15) is resumed at 02:15 p.m..Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

On S.A. XXXXX by Sh. V.K. Ohri, Advocate for Lallan Ojha (A−2).
I   do  not   remember  how   the  aforesaid  orders  Ex.PW15/B  to  Ex.PW15/F 
were received in my office, but,  these orders were shown to me before starting interception/ 
recording of the telephone numbers mentioned therein. I do 
not remember the time of the day, when these orders were 
shown to me. I also do not remember whether these orders 
were shown to me in the early morning, afternoon or in the  evening. 
Question : I   put   it   to   you   that   when   a   document   is  received from
 the Director's office in your office, it bears a 
dispatch number and on receipt, a diary number is given in  your office. What do you have to say?
Answer : I do not know.
I   have   now   seen  Ex.PW15/B  to  Ex.PW15/F. 
There is no diary/ dispatch or any marking on these orders. It  is   correct   that   these   orders  
authorize   Director,   CBI.   It   is  correct   that   these  orders   mention   that   telephonic  
messages  shall be intercepted and disclosed to Director, CBI. 
Question : I put it to you that there is no authorization by 
the Director, CBI, for interception, in your/ your Unit's favour.  What do you have to say?
Answer : The   Special   Unit,   CBI   at   Delhi,   Mumbai, 
Chennai and Kolkota are authorized to intercept the phone 
messages on behalf of Director, CBI, vide general order.
I do not know whether the said general order  is on  record  of this  case  or not.  I
 have already stated  that  Superintendent of Police had written to the service providers 
conveying the orders of the competent authority and that I  had   not   personally   sent   any   such  
request.   Whatever   was  handed over by me vide seizure memo  Ex.PW15/A, is duly 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
mentioned   in   the   same.   It   is   correct   that   vide   this   seizure  memo  Ex.PW15/A, 
the aforesaid letter written by SP to the  service providers, were not handed over. 
I   have   already   stated   that   the   recording   of 
intercepted messages was done by me and my team, under  the supervision of my senior officers. 
Question :   Can   you   tell   as   to   who   in   your   team 
intercepted the messages on different telephone numbers at  different times?
Answer :   As I have already stated that each and every  communication   of   the   respective  
telephone   numbers   were  recorded   in   said   Voice   Logger   automatically,   which   were 
heard by me and my team members from time to time during  the period of interception.Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

Question : Please tell whether the intercepted calls were 
heard at the time of interception or later on? Answer : Intercepted   calls   were   attended   on   real  
time  basis when a person was on duty access and the same were 
again  heard and attended by other team members including  me or my supervising officers.
All   the   calls   of   the   five   phone   numbers   in 
question in this case, were recorded by Voice Logger. I do not 
know whether the record of all the calls is presently available 
with CBI or not. It is correct that the Voice Logger System is  password   protected.   That   password
  was   available   with   me  only being a System Administrator of that Voice Logger. As I  have  
already   told   that   the   Voice   Logger   was   accessed   by 
different team members by using their password for limited 
rights at their client system. The client system a computerized 
system which is attached through LAN system with the said 
Voice Logger. The description of the client system is not the 
part of Certificate under Section 65B of Indian Evidence Act, 
which is Ex.PW15/G. Each and every communication, which 
got recorded, is protected and its integrity is maintained by  the said Voice Logger itself.
There is no system of calculating hash value in 
the Voice Logger used for intercepting of calls. Hence, no such 
hash value was calculated at the time of making copies. I do 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
not remember the number of computer systems working in  the Special Unit. 
It   is   wrong   to   suggest   that   the   record   was 
tampered on the asking of the IO. It is wrong to suggest that 
false and fabricated copies of the recorded conversation were 
prepared by me. It is wrong to suggest that I had given a false 
Certificate under Section 65B of Indian Evidence Act at the  behest   of   CBI.   It   is   wrong   to  
suggest   that   I   have   deposed  falsely.
XXXXX by Sh. Kunal Sharma, proxy counsel for Sh. Jagjit,  Advocate for Hemant Gandhi (A−3).
Ld. proxy counsel submits that the A−3 as well 
as main counsel Sh. Jagjit had to appear before the court of 
Ld. Special Judge, at Rohini Sh. R. P. Pandey in another case 
CBI Vs. Bibianus Topo & Ors., in which Hemant Gandhi (A−3) 
is accused. Request for adjournment is made.
For  the aforesaid  reasons,  cross−examination  of the witness is deferred.
RO & AC             (Poonam A. Bamba)       Special Judge (PC Act)/ CBI−03/ND            11.04.2014  
Examination dated 02.06.2014 XXXXX by Sh. Jagjit, Advocate for Hemant Gandhi (A−3).Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

My duty hours usually were 09:30 am to 06:00  pm.   I   do   not   remember   till   what   time   I  
was   in   office   on  30.12.2011. It is wrong to suggest that I am deliberately not 
disclosing the timings, in order to conceal the truth.
Director,   CBI   approaches   the   competent  authority   for   obtaining   permission   for  
interception   of  telephone calls. I do not remember at what time, the order 
dated 30.12.2011 for interception of phone number 95608− 06997, already Ex.PW15/D (D−
23), was received by me. My  senior   had   shown   the   said   order   to   me.   Now   I   do   not 
remember   as   to   who   was   the   said   senior   officer.   I   do   not 
remember whether I was on duty on 30.12.2011, same is a 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
matter of record. 
Question: I put it to you that you are are not able to tell  the   details,   because   you   were   not   on  
duty   on   30.12.2011.  What do you have to say?
Answer: I have already stated that I do not remember  whether I was on duty on 30.12.2011. 
 I am not concealing  any information.
I   do   not   remember   between   22.12.2011   till 
02.01.2012, on which dates I was on duty or on leave. No  addition/   alteration/   modification   was
  carried   out   in   the  orders, Ex.PW15/B to Ex.PW15/F, which were shown to me. 
The   witness   is   now   shown  Ex.PW15/B  to 
Ex.PW15/F. It is correct that the date on these documents is 
mentioned in ink whereas, the month and the year is typed. It 
is wrong to suggest that these orders are stereotype and are 
available with CBI and that the date is filled in by CBI, as per  their requirement, to suit their case.
Ld.   counsel   adopts   the   cross−examination  carried out on behalf of other accused persons." 
41. Perusal   of   this   testimony   shows   that   PW−15   has  explained  the   complete  procedure  of 
intercepting  the   calls.  He   testified   that   after   registration   of   the   case   the   relevant 
calls were segregated and were reheard before segregation.  PW−15   also   issued   a   Certificate  
(Ex.PW15/G,   D−26)   under  Section   65B   of   Indian  Evidence  Act, which  I  would like  to 
reproduce as under :
"Certificate u/s 65 (b) of Indian Evidence Act with regard to 
telephone calls mentioned in the endclosed Annexure.
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
I M. C. Kashyap, Dy. Supdt. Of Police, posted in the Special Unit, 
Central Bureau of Investigation, 6/10, Jamnagar House, Akbar Road, 
New Delhi, am posted in a responsible official position in relation to the Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

operation and management of the computer system which is used for  monitoring   of
  telephones.   The   computer   system   is   a   Call   Recording  Server   with   Special  
Voice   Logging   Software   supplied   by   M/s  Kommlabas Dezign Pvt. Ltd., A−
46, Sector 4, Noida, UP being used for 
recording of intercepted telephonic communications of different cases 
simultaneously, as per law.
That I was having lawful control over the use of this computer  system,   which   was  
used   regularly   to   record   intercepted   telephonic 
communications, during the period of interception.
That   during   the   said   period,   intercepted   telephonic 
communications were recorded regularly in this computer system in the 
ordinary course of the said activities.
That   during   the   period   in   question   the   above   said   computer  system   was  
operating   properly   and   there   have   been   no   operational  problem   so   as   to  
affect   the   intercepted   electronic   records   and   the 
accuracy of their contents at out end.
          That the computer hardware and software used in the above said 
computer system has in built security mechanisms for the integrity of  recorded data.
That 96 calls as per annexure− 'A' were intercepted and recorded  on   the   above  
mentioned   computer   system   during   23.12.2011   to 
02.01.2012. These calls were reproduced on a Compact Disc and two  sets     of   the  
same   were   prepared.       These   compact   discs   have   been 
signed by the undersigned for the purpose of identification. One set of 
Compact Disc  was  sealed under  my  signatures.  Both sets of Compact  Discs   were  
handed   over   to   the   Investigating   Officer,     Sh.   Deepak  Purohit,  Inspector  of 
Police,  AC−I,  CBI,   8th  Floor,  CBI  Head  Quarter,  Lodhi Road, New Delhi of RC−
 ACI 2012 A 0001, CBI, New Delhi on  06.01.2012 vide a seizure memo.
That these Compact Discs contain reproduction of the recorded  call   files  
mentioned   in   the   Annexure−   'A'   and   that   during   the   entire 
process of reproduction, there has been no change in these recorded  call files.
That   the   matter   stated   above   is   correct   to   the   best   of   my 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
knowledge and belief.
(M. C. Kashyap) Dy. Supdt. of Police, Special unit, CBI, N. Delhi."Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

42. This certificate refers to Annexure 'A'. Details of 
the intercepted calls are mentioned in this annexure, which 
should be read as part and parcel of this certificate. The same  would be reproduced by me later.
43. In the aforesaid certificate, PW−15 has explained 
as to in what manner the intercepted calls were recorded in 
the computer system and how the same were reproduced on  a   Compact   Disc   and   how   the  
copies   of   the   same   were  prepared. The certificate is a detailed one and I am of the  opinion  
that   PW−15   is   not   required   to   give   any   separate 
certificates at separate stages. The security of the intercepted  calls has been ensured by PW−
15 because as per his testimony  in cross−examination (dated 11.04.2014), he has stated that  Voice  
Logger   System   is   password   protected,   which   was 
available with him only being a System Administrator of that 
Voice Logger. He has also explained that the Voice Logger was  accessed  by 
different members by using their password for  limited   rights   at   their   client   system,   which   is
  attached 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
through LAN system with the Voice Logger. He also testified 
that each and every communication, which was recorded, is  protected   and   its   integrity   is  
maintained   by   the   said   Voice  Logger itself.
44. Ld.   Defence   counsels   have   pointed   out   that  human   intervention   should   have   been  
totally   ruled   out   by  prosecution.   I   may   mention   here   that   in   the   entire   cross−
examination of PW−15, the defence counsels could point out 
to Call No. 90 & 91 only. Ld. Defence counsels suggested that 
Call No. 91 was replaced and Call No.90 is pasted at its place.  PW−
15 has denied and has also explained that Call No. 90 
was intercepted on mobile phone no. 8130000444 and call  no.   91   was   intercepted   on   mobile  
phone   no.   9818517000.  This is a proper explanation, which is further proved by the 
particulars mentioned in Annexure 'A' to the certificate under 
Section 65B of Indian Evidence Act in respect of Call No. 90, 
which shows number of intercepted mobile as 8130000444, 
whereas, the intercepted mobile at call no. 91 is 9818517000. 
Of course, the contents of Calls no. 90 and 91 are same and 
therefore, Call No. 91 has not been specifically proved. There 
may be a question that as to whether there was a different  call   no.   91   and   was   there   any  
possibility   of   its   being 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
exculpatory in nature? I would say that I have no reason to  disbelieve   the   testimony   of   PW−15  
in   this   regard   because  there is no reason as to why he would remove actual Call No. 
91 and put Call no. 90 again in place of it. The conversation  of   the   intercepted   calls   other   than
  Call   No.   91   is   so  overwhelmingly   opens   up  the   entire   scenario   that   it   is   not 
reasonable   to   believe   that   Call   No.   91   could   have   been 
exculpatory in nature in any manner. Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

45. Ld. Defence counsels did not point out as to which  calls   were   tampered.   I   will   further  
point   out   that   human  intervention in this case is only in segregation of the calls and  loading   it  
in   CD.   It   does   not   mean   that   PW−15   and 
Investigating Officer were tampering the contents of the calls.
46. Accordingly,   I   am   convinced   that   the   electronic  data   has   been   intercepted,   segregated
  and   copied   in   CDs  without   any   tampering   in   the   same.   In   view   of   the   above 
discussed evidence, coupled with the certificate under Section 
65B of Indian Evidence Act, 1872, I hold that prosecution has  ruled   out   any   tampering   in   the  
electronic   evidence   of  intercepted calls. PW−15 has also proved that the calls were 
intercepted in view of the orders of Home Ministry, which are  Ex.PW15/B to Ex.PW15/F (D−
21 to D−25). 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Whether the Orders Ex.PW15/B to Ex.PW15/F, issued by 
Secretary to the Government of India, Ministry of Home 
Affairs are violative of Section 5(2) of Indian Telegraph 
Act, 1885 read with Rule 419(A) of the Indian Telegraph  Rules 1951, notified on 01.03.2007
47. It   is   argued   by   Sh.   Rakesh   Kumar   Sharma,   Ld.  Defence counsel for A−4 and A−
5 that telephonic interceptions  can be done only when it is required in interest of sovereignty 
of India and security of State and that it should be done in  exceptional   cases.   I   agree   that  
intercepting   the   telephonic  calls is a very responsible act and has to be done only in the 
circumstances  as  mentioned in  Section   5  (2)  of  the   Indian  Telegraph   Act,   1885.   Perusal   of
  this   provision   shows   that  Central   Government   can   do   so   if   sovereignty,   integrity   of 
India, security of State, public order is involved as well as for 
preventing incitement of commission of an offence.  In the 
present case the interceptions have been done with the orders 
of Home Ministry with a view to prevent the offences, which 
are now under consideration before this court. Therefore, I do  not   find   any   violation   of   any  
law   in   the   aforesaid  interceptions.
The   arrangement   between   service   provider   and   Special  Unit (i.e. SU) of CBI
48. PW4   Anuj   Bhatia,   a   Nodal   Officer,   Vodafone 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 Mobile
  Services   Ltd.   has   answered   this   issue   in   cross  examination   by   A−2.   PW4   testified   (in  
cross−examination  dated 10.2.2014) that there is an arrangement of CBI with  their   office   for  
monitoring   of   calls   of   specified   mobile 
numbers, which are sanctioned for surveillance and that the 
same is under proper custody of CBI. PW4 further testified 
that the service provider does not have any access to such 
monitored calls and it only provides such facility to CBI.Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

49. I have already reproduced the complete evidence  of PW−
15 M. C. Kashyap. However, at the cost of repetition, I  would   again   refer   to   his   testimony   (i.e.
  Cross−examination  dated   11.04.2014   by   Sh.   V.   K.   Ohri,   Advocate   for   A−2),   in 
which PW−15 has stated  that the Special Unit, CBI at Delhi, 
Mumbai, Chennai and Kolkata are authorized to intercept the 
phone messages on behalf of Director, CBI, vide general order  and   that   the   Superintendent   of  
Police   had   written   to   the  service   providers   conveying   the   orders   of   the   competent 
authority. 
Whether CBI was empowered to take voice samples
50. Now,   I   will   take   up   the   question   of   powers   of 
Investigating Officer in respect of taking of voice sample of 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 the  
accused   persons.     In  Ritesh   Sinha   Vs.   State   of   U.   P. 
(2013) Crl. L. J. 1301, Hon'ble Supreme Court of India was  faced   with   the   question   as   to  
whether  a   Magistrate   can  direct  taking   of   voice   sample   of   accused.     The   Division 
Bench of Hon'ble Supreme Court agreed on the point that if 
accused tenders his voice sample voluntarily, the same is not  hit   by   Article   20(3)   of  
Constitution   of   India.     However,  Hon'ble Mr. Justice Aftab Alam was of the opinion that the 
Magistrate   cannot   order   an   accused   to   give   his   voice  sample. 
51. Perusal   of   this   judgement   shows   that   both   the 
judges of Hon'ble Supreme Court agreed that if the accused 
gives his voice sample voluntarily during investigation, there 
is no violation of right under Article 20 of the Constitution. 
Both the judges agreed that voice sample is like finger print  impression,   signatures   or   specimen  
hand   writing   of   an  accused.     Justice   Ranjana   Prakash   Desai   observed   that  identification  
of   voice   involves   measurement   of   frequency  and   intensity   of   sound   waves   which   fell   in
  the   ambit   of  inclusive   definition   of   "measurement"   appearing   in 
Identification of Prisoners Act, 1920.   However, Hon'ble Mr.  Justice   Aftab   Alam   differed   and  
held   that   it   is   not   a 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
measurement.   Therefore, the entire issue was referred to a  Bench of three Judges.  
52. I have perused this judgement carefully and I am 
of the opinion that fundamentally both the judges of Hon'ble 
Supreme Court agree that if given voluntarily, voice sample of 
accused can be taken by police during investigation and the 
same is not violative of Constitution of India. Hon'ble Justice 
Ranjana Prakash Desai has specifically mentioned that  voice  prints   are   like   finger   prints   in  
that   each   person   has   a  distinct   voice,   with   characteristic   features   dictated   by 
vocal cavities and articulators. Justice Aftab Alam has not 
given a dissenting note on this observation. But he differed  on   the   powers   of   Magistrate.  Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

Question   before   Hon'ble  Supreme Court was  as to whether a magistrate can direct 
an accused to give his voice samples.
53. Thus, the dissent is on the question of "powers of 
Magistrate" and not on powers of police to take voice sample  during investigation.
54. I   am   of   the   considered   opinion   that   if   a   fact   is  relevant,   Investigating   Officer   is  
entitled   to   investigate   and 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
collect the same in his investigation. Further, the investigation  is the  exclusive  
domain of the Investigating Officer and he 
can take the handwritings, blood samples, hair samples and  voice   samples,   etc.   without   any  
permission   from   the  magistrate.   Section   2   (h)   of   Criminal   Procedure   Code  mentions  
that   "investigation"  includes   all   proceedings 
under this Code or the collection of evidence conducted 
by a police officer. Therefore, the scope of investigation is  very   wide   and   it   includes   taking  
assistance   of   scientific  experts. Section 9 of Indian Evidence Act makes all the facts 
relevant, which establish the identity of a person, he may be  an accused or may be a witness.
55. Therefore,   even   if   it   is   held   by   larger   Bench   of 
Supreme Court of India, on the reference by Division Bench  in  Ritesh Sinha, that
 the Magistrate does not have power  to direct the accused to give his voice sample, the powers 
of Investigating Officer to do so remain untrammeled.
56. In view of above discussion, I am of the opinion 
that taking of voice samples is akin to taking of handwriting  specimen   by   the   Investigating  
Officer   during   investigation  and therefore, judgement of Hon'ble Supreme Court of India 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
in State of Bombay versus Kathi Kalu Oghad, AIR 1961 SC  1808  case   would   be   squarely  
applicable,   where   Hon'ble  Supreme Court of India held that police during investigation 
can take handwriting samples of accused, though Magistrate  cannot   direct   an   accused   to   give  
his   handwriting   sample.  Accirdingly,   taking   of   voice   samples   during   investigation 
without the orders of Magistrate would be admissible if given  voluntarily. 
Whether   the   accused   persons   had   given   their   voice  samples voluntarily?
57. PW−34 P. K. Gottam, Senior Scientific Officer, CFSL 
testified that Sh. Ram Singh, DSP had brought one requisition 
for taking voice sample of Dr. Anup Kumar Srivastava (A−1). 
He testified that specimen voice was given voluntarily by Dr.  Anup  Kumar  Srivastava (A−1), but
 later i.e. after recording  the   specimen   voice,   Dr.   Anup   Kumar   Srivastava   (A−1)   was 
refusing   to   give   the   same   and   made   a   note   on   the 
Memorandum for Voice Sample, prepared by DSP Ram Singh.  This   Memorandum   has   been  
proved   as   Ex.PW34/A   (D−33,  pages 113 & 115). Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

58. I have perused the noting dated 23.01.2012 of A−
1 on the same, which is in Hindi. If translated in English, it 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
states that, "Initially I had stated that I am not inclined to give  
voice sample. But, on the asking of Investigating Office, I have   given   the   voice   sample.  The  
above  written   ..........   is  wrong."  This itself shows that the accused were free enough to raise  any  
type   of   objection   before   the   sample   taking   scientific  officer at any stage. 
59. Prosecution   has   examined   PW−13   A.   D.   Tiwari, 
Senior Scientific Officer, who took the voice samples of other  accused persons and witnesses.
60. The   Memorandum   of   Sample   Voice   Recording  Ex.PW13/1 (D−
11) dated 04.01.2012 pertains to Lallan Ojha  (A−2).
61. Memorandum   of   Sample   Voice   Recording  Ex.PW13/10   (D−15)   dated   04.01.2012  
pertains   to   accused  Dilip Kumar Aggarwal (A−4).
62. Memorandum   of   Sample   Voice   Recording  Ex.PW13/13   (D−19)   dated   04.01.2012  
pertains   to   Anand  Kumar Aggarwal (A−5).
63. Memorandum   of   Sample   Voice   Recording  Ex.PW13/4   (D−12)   dated   04.01.2012  
pertains   to   accused 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Hemant Gandhi (A−3).
64. Perusal of the memorandums shows that none of  the   accused   raised   any   objection   while  
giving   their   voice  samples.  Hence, I hold that the accused persons had given 
voice samples voluntarily. 
Whether the voice expert (PW−16) has no legal authority 
to compare the voice samples with the questioned voices
65. Ld. Defence counsel has referred to Section 79(A)  of   The   Information   Technology   Act,  
2000,   which   is  reproduced as under :
"CHAPTER XIIA EXAMINER OF ELECTRONIC EVIDENCE 79A.   Central  
Government   to   notify   Examiner   of  Electronic   Evidence.-   The   Central  
Government  may,   for   the 
purposes of providing expert opinion on electronic form evidence 
before any court or other authority specify, by   notification in the  Official   Gazette,  
any   Department,   body   or   agency   of   the   Central 
Government or a State Government as an Examiner of Electronic  Evidence.Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

Explanation.--For the purposes of this  section,  "electronic  form 
evidence" means any  information  of  probative value that is  either   stored   or  
transmitted   in   electronic   form   and   includes 
computer evidence, digital audio, digital video, cell phones, digital  fax machines.]"
66. Ld. Defence counsel has submitted that A−2 had  sought   information   under   RTI   Act   as   to  
whether   any   such 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 expert
  has   been   notified   or   not.   It   is   submitted   that   A−2  received following reply :
"No.14 (31)/2014−ESD Ministry of Communication & Information Technology
Department of Electronics & Information Technology
Electronics Niketan,6, CGO Complex New Delhi−110003 Dated: 19.03.2014
Subject: RTI application received from Shri Lallan Ojha, Delhi.
With   reference   to   your   RTI   application   which   was   received   in   this 
department requesting for the following information.
Please   inform   whether   the   Central   Govt.   has   Issued   any   notification 
declaring CFSL/CBI to be examiner of "Electronic Evidence" as required 
under Sec 79A of IT Act 2000 and also The Act(amendment) Act,2008.
The   information   as   received   from   the   custodian   of   the   information   is 
placed below:
"Government has not issued any notification under sec 79(A) of the IT Act 
for notifying CFSL/CBI New Delhi to be examiner of Electronics Evidence  Act".
(A.K.Kaushik) Additional Director & CPIO (E−Security & Cyber Laws) Shri Lallan Ojha
21, Savita Vihar Delhi−110092 M−9811602221'
67. Ld.   Defence   counsel   argues   that   the   aforesaid  reply   received   under   RTI   was  
confronted   to   PW−16   Dr.  Rajender Singh, Director, CFSL, Government of India and he 
admitted that no notification in his name has been issued by 
Government of India under 79(A) of Information Technology 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Act, 2000. 
68. I have considered this submission. Section 79 (A)  of   Information   Technology   Act,   2000  
has   already   been  reproduced   by   me.   It   simply   says   that   Government  may  appoint   such 
an   expert.  Therefore,  if no  notification  under 
Section 79 (A) has been issued in name of any expert, it does 
not mean that expert becomes ineligible to give opinion. The 
opinion of an expert is relevant under Section 45 of Indian Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

Evidence Act. As per Section 45, expert is a person, who is  especially  skilled  in foreign law,
 science  or art. PW−16 has  testified that he has more than 25 years of experience in the 
field of forensic voice identification. He also testified that he 
has examined more than 1000 cases of such nature, which  involves   more   than   3000   persons'  
voices.   His   academic  qualification   is   M.Sc.,   B.Ed.,   M.Phil   and   Ph.D   (Phy.).  Therefore,   I  
hold   that   even   though   no   notification   under 
Section 79 (A) of The Information Technology Act, 2000 is 
issued by Government in his name, still he is an expert, who 
is specialized in the science of voice identification. 
What is the evidentiary value of opinion of voice expert  (PW−16)
69. Dr.   Rajender   Singh,   Director,   CFSL   has   testified 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 that  
he   compared   the   questioned   recorded   conversation   of  Smt.   Reena   Gandhi,   Rajesh  
Verma,   Hemant   Gandhi,   Lallan  Ojha, Dilip Aggarwal, Anand Kumar Aggarwal, Dilip Kumar 
Yadav and Anup Kumar Srivastava with their specimen voices  and  he  found  the  same
 matching. He  proved his report  as  Ex.PW16/A and Ex.PW16/B. 
70. A question has been raised about the possibility of  error   in   identification/   comparison   by  
the   expert.   This  witness was thoroughly cross−examined and I would like to 
reproduce relevant portion of cross−examination by Sh. V.  K.  Ohri, Ld. Defence counsel for A−
2 as under :
"Question : Is it correct that there is an error in the range of 0 
to 80% in auditory examination of voice for comparison?
Answer : Depending upon the quality of the voice, that is, 
if a person mimics or disguises his voice while giving sample, the 
percentage of error may be more, that is, upto 80%. But, if the 
sample quality is good, that is, given in the manner a person 
speaks, the error would be very less and could be even 0 error.  The   error   in  
auditory   examination   is   further   verified   by  objective   method,   that   is,   voice  
spectrography,   which   has  accuracy   and   reliability   of   voice   comparison   to  
the   extent   of  more   than   99%   even   if   a   person   mimics   or   disguises   in  
his  sample voice.
Depending   upon   the   quality   of   voice,   the 
recorded speech is enhanced or reduced if the recorded voice is 
feeble or loud. It is wrong to suggest that frequency of the voice  is   also   increased.
 Volunteered:  Frequency   of   speech   of   a   particular   person   in   a   particular  
instance,   remains   the   same.  There   is   no   need   to   mention   in   the   report  
or   in   the   internal  worksheet     about   enhancing   or   reducing   the   volume   of  
the Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
voice.   During   examination,   refurbishing   is   done   if   there   is 
external noise. If refurbishing is done in any case,  we do not 
mention the same in the report/ internal worksheet."
71. Opinion   of   PW−16   has   been   assailed   by   Ld. 
Defence counsels on the ground that a preliminary enquiry 
was instituted against him by CBI and therefore, being under 
pressure of CBI, he prepared his reports as per the dictats of  CBI. In cross−
examination (dated 03.04.2014) by Sh. Rakesh  Kumar Sharma, Advocate for A−4 and A−5, PW−
16 admitted  that preliminary enquiry was initiated against him in the year  2011−
2012. He explained that nothing was found against him  in   the   said   preliminary   enquiry  
because   it   was   basis   on   a  fabricated and anonymous complaint. He also stated that the 
preliminary enquiry was registered against him in June 2012,  whereas   the   report   Ex.PW16/A  
was   given   by   him   in   the  present case on 11.02.2012 and report Ex.PW16/B was given  by   him
  on   17.02.2012   i.e.   much   before   initiation   of  preliminary   enquiry.   Hence,   I   find   no  
substance   in   the  submissions   of   Ld.   Defence   counsel   that   PW−16   gave   his 
opinion under the pressure of CBI. Rather, in his report he has 
given detail reasons and has also mentioned that question of  specimen   voices  were  subject  to 
spectrographic  analysis  on  Computer Voice Spectrograph for their Voice Grams and that 
the acoustic features namely formant frequency distribution, 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
intonation   pattern,   frequent   time   coordination   distribution,  etc.   corresponded   with   their  
respective   features   in   the  specimen advances.
72. I   may   mention   here   that   the   report   Ex.PW16/A  (D−
68) is in respect of the voices of Anup Kumar Srivastava 
and Hemant Gandhi, whereas, the report Ex.PW16/B (D−69)  is  in  respect   of  the  voices of Lallan
 Ojha, Hemant Gandhi,  Smt.   Reena   Gandhi,   Dilip   Kumar   Yadav,   Dilip   Aggarwal, 
Anand Kumar Aggarwal. The perusal of the report shows that 
on many questioned voices, the expert has not given opinion 
due to lack of insufficient common clearly audible sentences/  words.   The   report   is   reasoned,  
scientific   in   nature   and  defence counsels have not brought any material to show as to 
why the same should not be believed.
73. Ld.  Defence  counsel has assailed his opinion  on  the   ground   that   there   could   be   error  
upto   80%   in   such  opinions.   Ld.   Defence   counsel   has   referred   to   following  portion   of  
the   cross−examination,   which   is   reproduced   as  under :
"Question : Is it correct that there is an error in the range of 0 to 
80% in auditory examination of voice for comparison? Answer :
Depending upon the quality of the voice, that is, if a  person   mimics   or   disguises  
his   voice   while   giving   sample,   the  percentage   of   error   may   be   more,   that  
is,   upto   80%.   But,   if   the Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
sample quality is good, that is, given in the manner a person speaks, 
the error would be very less and could be even 0 error. The error in 
auditory examination is further verified by objective method, that is,  voice  
spectrography,   which   has   accuracy   and   reliability   of   voice 
comparison to the extent of more than 99% even if a person mimics 
or disguises in his sample voice."
74. From   this  answer,   two   facts   can   be   understood. 
First, there are chances of error. Second, with the help of a 
scientific instrument i.e. voice spectrograph, more than 99% 
accuracy is achieved in identification of voice. In the present  case   PW−16   has   used   voice  
spectrography   and   has   given   a  very reasoned report, wherein he has not given opinion on 
certain portions of the questioned voices.
75. In   view  of this discussion, I hold that the voice  identification report of PW−
16 is scientific in nature and has  to be accepted.
76. In view of various common issues as adjudged 
above, I take up the evidence against each accused as well 
as the legal issues separately raised by each accused.
ANUP KUMAR SRIVASTAVA (A−1)
77. The   proceedings   against   this   accused   were  quashed   by   Hon'ble   High   Court   of   Delhi  
vide   order   dated  21.11.2013 in CRL. M.C. 4360/2012.  I may point out that 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
till that date 13 prosecution witnesses had already been  examined.
HEMANT GANDHI (A−3)
78. This   accused   went   abroad   after   seeking  permission   of   this   court,   but   never   returned
  back.  Consequently,   he   was   declared   Proclaimed   Offender   vide  order−
sheet dated 14.03.2016.
79. It   is   necessary   to   mention   here   that   before  14.03.2016,   the   prosecution   evidence   had
  already   been  closed   and   when   he  was   declared   Proclaimed   Offender, 
the case was already at the stage of recording statements 
of the accused persons under Section 313 Cr.PC. Since he 
had absconded, his statement under Section 313 Cr.PC could  not be recorded. 
LALLAN OJHA (A−2)Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

80. Sh. V. K. Ohri, Advocate for accused Lallan Ojha  (A−
2) has strongly assailed the prosecution case and has also 
filed written submissions. I take up his submissions as under :
1.  Whether   PW−8   was   competent   to   accord   sanction 
under Section 19 of Prevention of Corruption Act, 1988 in  respect of A−2.
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
81. It   is   argued   by   Ld.   Defence   counsel   that   the  sanction to prosecute Lallan Ojha (A−
2) was accorded by the  Commissioner   Central   Excise   Delhi   I,   whereas   the   Chief 
Commissioner erstwhile Principal Collector is the Appointing  authority   of   Superintendent  
Central   Excise   as   per   "the  Superintendent   Central  Excise  Recruitment  Rule   1986".  Ld. 
Defence   counsel   submits   that   this   is   also   substantiated   by  another   document,   "F.  
no.A.32012/2004−Ad.IIA",   issued   by  Government   of   India,   Ministry   of   Finance  
Department   of  Revenue   Central   Board   of   Excise   and   Customs   dated   23rd 
December 2008, which was obtained by A−2 through RTI. Ld. 
Defence counsel has referred to a judgement in a case Amar 
Nath Verma vs. The Union of India and Anrs. decided on  21st   January   2011   by   Hon'ble   Patna  
High   Court.   It   is  accordingly argued by Sh. V. K. Ohri, Ld. Defence counsel that 
the said sanction is bad in law and that as there is no valid 
sanction, the prosecution has to fail against Lallan Ojha (A2).
82. I   have   considered   the   rival   submissions.   It   is   a  settled   law   that   sanction   accorded  
by   an   incompetent  authority   would   go   to   the   root   of   the   case   and   would 
invalidate even the cognizance of the offence against a public  servant.   Therefore,   it   is   to   be  
seen   as   to   whether   the 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
sanctioning   authority   was   competent   to   accord   sanction  under Section  19 
of Prevention of Corruption Act, 1988 to  prosecute accused Lallan Ojha (A−2). 
83. Sh.   Manoj   Shukla,   Ld.   Senior   Public   Prosecutor 
has drawn my attention to the CCS (CCA) Rules, 1965 and 
has submitted that sanctioning authority i.e. PW−8 Dr. John  Joseph, the then 
 Commissioner, Customs & Excise, Delhi−1,  was competent to accord the sanction. 
84. In order to understand the submissions of A−2, I 
would like to reproduce the relevant portion of the schedule  annexed   with   the   Recruitment  
Rules   for   the   post   of  Superintendent   of   Central   Excise,   which   have   been 
collectively marked as Annexure A by A−2, which he procured 
from Ministry of Finance under RTI. The relevant portion is  reproduced as under :
"T H E   S C H E D U L E ........Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

........
−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
−−−−−−−−−−−−−−− In case of recruitment by promotion/
If appointmental promotion Circumstances in which the
deputation/ transfer/grade from which Committee exists, what is its
Public Service Commission is promotion/deputation/transfer to composition.
To be consulted in making  be made appointment −−−−−−−−−−−−−−−−−−−−−−−−−−
−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
                       12.                                                    13.                                               14.
−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
−−−−−−−−−−−−−−−
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
                PROMOTION
           Group 'B' Departmental Promotion     Consultation with Union
Inspector of Central Excise (Ordinary                       Committee
       Public Service Commission
Grade) with 8 years regular service in    (1) Jurisdictional Principal Colle−
       is necessary while making the grade, if any, rendered in the 
     ctor of Customs and Central         direct recruitment.
grade of Inspectors (Senior Grade).              Excise or in his absence Dire−
      ctor General of Inspection (Customs)       and Central Excise) - Chairman.
.............."
85. Perusal   of   above   reproduced   portion   of   'The  Schedule', taken by A−
2 under RTI Act, clearly shows that the  Rule does not show as to who is the appointing or removal 
authority. 
86. Ld. Defence counsel has referred to a judgement 
dated 21.01.2011 of Patna High Court in the matter of Amar  Nath   Verma   vs.   Union   of   India. It
  is argued  that   Hon'ble  Patna High Court has held that Principal Commissioner is the  appointing
  authority   of   Superintendent   of   Central   Excise  Department   as   per   Central   Excise  
Recruitment   Rules   1986,  published on 17.12.1986. 
87. I   have   considered   this   submission   and   have 
perused the aforesaid case law. I have already mentioned that  A−
2 has filed the copy of Recruitment Rules for the post of  Superintendent   of   Central   Excise   in  Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

Central   Excise  Collectorate, but in the Rules it is nowhere written as to who  is   the   appointing  
or   dismissing   authority.   One   copy   of 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Schedule to it has also been filed, relevant portion of which  has   already   been   reproduced   by  
me.   However,   as   already  discussed,   this   Schedule   does   not   specify   appointing/  removing  
authority.   Perusal   of   the   judgement   cited   by   Ld. 
Defence counsel shows that a plea was raised before Hon'ble 
Patna High Court, however, no finding was given on this issue  by the said court.
88. A−2 has also placed on record Annexure−B, which  is   "Information   under   RTI   Act".  
Relevant   portion   of   the  document is reproduced as under :
"F.No.A.32012/1/2004−Ad.IIA Government of India Ministry of Finance
Department of Revenue Central Board of Excise & Customs *****
New Delhi, the 23rd December, 2008.
To All the Cadre Controlling Authorities (CCAs) under CBEC (by name).
Subject: Grant of financial upgradation under the ACP Scheme to Group−B
  Officers under the CBEC - instructions regarding.
Sir, I  am  directed   to  refer   to  the   Deptt.   of Personnel  &  Training's  O.   M. 
No.35034/1/1997−Estt.(D)   dated   09.08.1999,   regarding   grant   of   financial 
upgradation to the eligible officers under the Assured Career Progression (ACP) 
Scheme. Under the Scheme, Groups−B, C and D officers are entitled to 1st and 
2nd financial upgradation on completion of 12 and 24 years of service, ........
2.  However, on careful consideration, it was felt that the above practice is 
not consistent with the position of various Rules and Instructions, mainly for 
the reason that the Group−B officers continue to remain in Group−B even after 
grant of ACP and hence, approval of the Hon'ble FM, who is the appointing 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
authority   for   Group−A,   should   not   be   necessary   for   this   purpose.  The 
appointing   authorities   for   Group−B,   namely,   the   cadre   controlling   Chief 
Commissioners/   Directors   General,   should   be   able   to   approve   such 
proposals. .........
...........
............
4. ...............  The   Cadre   Controlling   Chief   Commissioners/   Directors  General
 are   competent   to   grant   ACP   to   Group−B   officers,   being   their 
Appointing Authorities. As a natural corollary, the composition of Screening Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

Committee for Group−B officers shall be the same as that of the DPC for Group−
B officers. It is ascertained that in CBDT, the work of grant of ACP to Group− B  
officers   has   already   been   assigned   to   Cadre   Controlling   Chief 
Commissioners.
5. In view of the above, it has been decided that henceforth, the work of 
grant of ACP benefit to Group−B officers shall be undertaken by the concerned  Cadre
 Controlling   Chief   Commissioner/   Directors   General,   being   the 
Appointing Authorities for Group−B officers. The composition of Screening 
Committee for Group−B officers shall be the same as that of the DPC for Group−
B officers. The concerned Cadre Controlling Chief Commissioner/ Directors  General,
  being   the   Appointing   Authorities   for   Group−B   officers,   shall   be 
competent to accept the recommendations of the Screening Committee and to 
sanction the ACP benefit to Group−B officers. This procedure shall be applicable 
not only to the future cases, but also to the past pending cases for grant of  
financial upgradation under the ACP Scheme which could not be processed by  
the Board for want of availability of complete documents from the concerned 
field formations.
6. This issues with the approval of the Competent Authority.
Yours faithfully, (L. R. Aggarwal) Deputy Secretary to the Govt. of India"
89. Based   on   the   aforesaid   letter   dated   23.12.2008  obtained by A−
2 under RTI Act, it is argued by Sh. V. K. Ohri,  Ld.   Defence   counsel   that   PW−8   Dr.   John  
Joseph,   the   then  Commissioner,   Customs   &   Central   Excise,   Delhi   was   not 
competent to accord sanction to prosecute A−2 and that Chief  Commissioner   was   the   appointing
  authority   of   the 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Superintendent. Ld. Defence counsel has drawn my attention  to   cross−examination   of   PW−8  
when   the   attention   of   the  witness   was   drawn   to   the   aforesaid   letter.   On   seeing   this 
letter, PW−8 stated that he does not dispute the order of the 
Ministry, but in practice it is the Commissioner, who appoints  the Superintendent of Group−
B officers and has also power to  remove   them  from   the   services.   PW−8  further   testified   that 
there is some office order under which the aforesaid practice 
is being continued contrary to the order of Ministry. 
90. Ld. Defence counsel submits that the appointing  authority   of   Superintendent   is   Chief  
Commissioner   as  mentioned in the above reproduced letter dated 23.12.2008 
and that department is continuing with a wrong practice of  the   Commissioner   according   the  
sanction,   despite   his   not  having any authority to remove or appoint a Superintendent. 
91. I   have   carefully   considered   the   letter   dated 
23.12.2008 and I would like to mention that appointing or  removing  authority  is determined byCbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

 the  Service  Rules. No  office order of any Ministry can change the scheme provided  by   the  
Service   Rules.   I   would   like   to   refer   to   Rule   11   of  Central   Civil   Services   (Classification,  
Control   &   Appeal)  Rules, 1965, which provides following penalties, which can 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
be imposed upon a public servant :
Minor Penalties
(i). Censure
(ii). Withholding promotion
(iii). Recovery of pecuniary loss
(iii)(a). Reduction to a lower stage in time scale of pay by one  stage
(iv). Withholding the increment Major Penalties
(v). Reduction to a lower stage in time scale for a specified   period
(vi). Reduction in lower time scale of pay, grade, post or    service
(vii). Compulsory retirement
(viii). Removal from service
(ix). Dismissal from service
92. Rule   12   is   in   respect   of   disciplinary   authorities  and   refers   to   the  THE  
SCHEDULE,   which   specifies   the 
appointing authorities and the removal authorities.
93. Now, I would like to reproduce relevant portion of 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
THE   SCHEDULE,   which   mentions  appointing   authority   and 
removal authorities of various services :
PART II - Central Civil Services, Group 'B' - (Contd.)
(Except for Civilians in Defence Services)
Authority competent to impose penalties and penalties which it may  Serial 
Appointing impose (with reference to item numbers in Rule 11) Number
Description of service Authority Authority Penalties (1) (4) (5) (2) (3) ... ..... .... ......
.....Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

(i) to (iv)
12. Central Excise Service, Group  Collector   of  Collector of Central Excise/ Land 'B'−
−Superintendents   Group  Central  Customs; All 'B'   (including   Deputy 
Excise/Land  Headquarters Assistant to the  Customs;Nar− ..............
Collector)and District Opium  cotics   Com−  ..............
           Officers, Group 'B'.                  missioner.
.....        ........                                ........             .............                                                                   ......
94. The above quoted portion of THE SCHEDULE in 
reference to Rule 12 of CCS (CCA) Rules, 1965 make is clear  that   the   Superintendents   are  
Group   'B'   officials   in   Central  Excise Department and their appointing authority is Collector. 
It further shows that Collector is also empowered to impose  all  penalties  upon  the
 Superintendents including  the  major  penalties of dismissal and removal. 
95. Hence, I am convinced that PW−8 Dr. John Joseph,  Commissioner, 
Customs & Central Excise was competent to  accord sanction to prosecute A−2. 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
96. I would like to touch a minor issue here. As per  The Schedule  to the CCS (CCA) Rules, 1965,
 the Collector  of the Central Excise is the disciplinary authority of Group 'B' 
Superintendents. The designation of PW−8, who is sanctioning  authority in this case, is
 Commissioner, Customs & Central  Excise.     It   has   not   been   disputed   that   the   designation  
of  Collector  has been changed to  Commissioner. Still with a  view   to   satisfy   this  court,  Ld. 
Senior   Public  Prosecutor   has  filed copy of following notification, which is reproduced as  under :
"Notification No. 26/95−C.E. (N.T.), dated 6−6−1995.
Notification under Section 37 - In exercise of the powers conferred by section 37  of 
the Central  Excises and  Salt  Act,  1944 (1 of 1944)  and  of  all  other powers  
enabling it in this behalf the Central Government hereby directs that references to 
any   authority   specified   in   column   2   of   the   Table   below   in   the   rules  
made   or  deemed   to   have   been   made   under   that   section   or   in   any   other  
notification, 
decisions or orders, issued or made under such rules or under any other section of 
the said Act shall, unless the context otherwise requires, be construed as references 
to the authorities specified in column 3 of the Table below :− TABLE Sl.Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

        No.     Existing Designation                                Substituted Designation
        (1)                (2)                                                     (3)
        1.      Principal Collector of Central             Chief Commissioner of Central Excise
                Excise
        2.      Collector of Central Excise                Commissioner of Central Excise
        3.      Collector of Central Excise                Commissioner of Central Excise 
(Appeals)/Collector(Appeals) (Appeals)/Collector (Appeals)/
Commissioner(Appeals)
4. Deputy Collector of Central Joint Commissioner of Central Excise Excise
5. Assistant Collector of Central Assistant Commissioner of Central Ex− Excise
Excise or Deputy Commissioner of Central Excise"
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
97. Copy   of   this   notification   was   supplied   to   the 
accused and he has not disputed the correctness of the same.
98. In order to further clarify the issue, prosecution 
has also filed a copy of notification dated 13.07.2010. It was 
supplied to the accused and correctness of the same has not 
been disputed. I reproduce the same as under :
"F.No. C−11016/2/2007−Ad.V Government of India Ministry of Finance
Department of Revenue Central Board of Excise & Customs
New Delhi, Date 13th July, 2010.
ORDER Consequent upon  reclassification  of posts  of Inspector  (C.Ex.),  Inspector  
(PO)   and   Inspector   (Examiner)   under   CBEC   as   Gr   'B'   non− gazetted,  
based   on   the   norms   of   the   Department   of   Personnel   and  Training,   vide  
Board's   Order   C   18013/100/2003−Ad.III(B)   date   11th 
December, 2003 read with letter of even number dated 24th October, 
2007 addressed to all Chief Commissioners and Director Generals and 
designation of 'Commissioner' as the appointing authority for the said  reclassified  
posts   of   Inspector   (C.Ex),   Inspector   (PO)   and   Inspector 
(Examiner) vide  Board's Order C 18013/100/2003−Ad.III(B) date 22nd 
December, 2009, as also keeping in view the reclassification of Gr. 'D' 
posts as Gr 'C' on the recommendations of the Sixth Pay Commission, the 
question of specifying authorities to discharge functions as Disciplinary  Authority,  
Appellate   Authority   and   Revisionary   Authority   under   CCS 
(CCA) Rules, 1965 for various Gr 'B', 'C' and erstwhile Gr 'D' category of 
posts has been engaging the attention of the Board.Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

2 The   matter   has   been   examined   in   consultation   with   the 
Department of Personnel and Training. Considering that in terms of Rule 
12 (4) (a) of CCS(CCA) Rules, 1965, the level of disciplinary authority 
for major penalty can not be lower than the Appointing Authority and 
that under Rule 4 to 6 of CCS(CCA) Rules, 1965 regarding classification 
of posts as also other rules such as Rule 24 and 29/29−A,  there is no 
distinction between Gr. 'B' gazetted and Gr 'B' non−gazetted, it has 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
been decided with the approval of the President to specify the following 
authorities as Disciplinary Authority, Appellate Authority and Revisionary 
Authority for Gr. 'B' and 'C' (including erstwhile Gr. 'D') posts in CBEC Classification 
Disciplinary Authority Appellate Authority Revisionary  of posts Authority Gr. 'B' Commissioner
Chief Commissioner President Gr. 'C' Jt. Commissioner/Addl. Commissioner Chief  (including 
Commissioner Commissioner erstwhile   Gr. 
'D') Gr. 'C' Where   Commissioner   has  Chief Commissioner Chairman,   CBEC  (including 
passed an order in a common  or Member (P&V) erstwhile   Gr.  disciplinary proceeding 'D') 3
The above Order takes effect from the date of issue. Necessary 
amendment to the Schedule to CCS(CCA) Rules, 1965 is being carried  out separately.
4 The pending Appeals/Revision Applications shall be decided by 
the competent authorities as per extant provisions.
5 In respect of persons serving in various Directorates, officers in 
rank equal to the above specified authorities shall be the corresponding 
Disciplinary Authority, Appellate Authority and Revisionary Authority.
6 Hindi version will follow [ By Order and in the name of the President ] (Akhatarul Hanif)
Under Secretary to the Government of India To
All the Chief Commissioners/ Directors General in CBEC
All Commissioners/ All Addl. Directors General in CBEC"
99. This   order   dated   13.07.2010   leaves   me   in   no 
doubt about the competency of PW−8 in according sanction  under  Section  19
 of Prevention  of Corruption  Act, 1988 in  respect of A−2. 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
100. Therefore,   I   am   convinced   the   Commissioner   of 
Central Excise (which is new designation of the Collector vide 
above reproduced notification) is competent to remove A−2 
from the service and has rightfully issued the sanction under 
Section 19 of Prevention of Corruption Act, 1988 to prosecute  A−2.Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

2. Whether   holding   of   an  additional   charge  would 
affect the competence of sanction according authority?
101. Ld. Defence counsel has drawn my attention to an 
order Ex.PW8/B, which I am reproducing as under :
"F.No.A−22011/−2/2011−Ad.II Government of India Ministry of Finance
Department of Revenue (Central Board of Excise and Customs) *********
North Block, New Delhi Dated, the 2nd January, 2012
It has been decided that Shri John Joseph, Commissioner, LTU,  Delhi   will   hold  
the   additional   charge   of   the   post   of   Commissioner,  Central Excise, Delhi−
I with immediate effect and until further orders.
(R. Sanehwal) Director Telfax : 2309 2401 ........
........."
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
102. It is argued by Ld. Defence counsel that PW−8 was  not   the   proper   authority   to   issue  
sanction.   The   above  reproduced office order no. 02/2012 shows that he was only 
given an additional charge of post of Commissioner, Central  Excise,   Delhi−1.   On   perusal   of  
this   order,   I   find   that   full  fledged charge of the post of Commissioner was given to PW−
8. Therefore, it cannot be said that the status of PW−8 at the  time   of   according   sanction   was  
that   of   Additional  Commissioner, who is lower in rank than the Commissioner. 
Additional charge of Commissioner should not be  confused 
with the post of Additional Commissioner. PW−8 has testified 
that from 02.01.2012 to 14.01.2013, he was Commissioner,  Customs   &   Excise,   Delhi−1   and  
had   succeeded   Dr.   Anup  Kumar Srivastava (A−1). 
3.  Whether   the   sanction   order   suffers   from   non− application of mind?
103. It is argued by Sh. V. K. Ohri, Advocate that the  sanction   order   Ex.PW8/C   suffers   from  
non−application   of  mind. He has drawn my attention to the cross−examination of  PW−
8 wherein he stated that he did not remember as to what 
documents were received alongwith the letter of CBI. He did 
not remember as to in which language the transcripts were 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
provided to him. Further, paras no. 1 to 14 of the sanction 
order Ex.PW8/C pertaining to accused Lallan Ojha (A−2) are 
exact copy of paras no. 1 to 14 of sanction order Ex.PW5/B 
pertaining to Anup Kumar Srivastava (A−1). Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

104. I have considered this submission. If paras no. 1 
to 14 are similarly worded in both the sanction orders, it is  because   of   the   reason  that   there
 were  common  allegations  against A−1 and A−2. PW−8 had stated that he had got draft of 
sanction order from CBI and that he had gone through the  same   and   had   corrected   where−ever
  it   was   required   and  thereafter,   he   prepared   fresh   sanction   order   himself   and  signed   it.
  This   process   itself   shows   that   PW−8   had   given 
thoughtful consideration to all the facts presented before him.  In   cross−examination   he   had  
also   stated   that   he   had   gone  through all the documents furnished alongwith the letter of 
CBI. I am convinced of this testimony and I am of the opinion 
that the sanction order does not suffer from non−application  of mind.
4. Whether it was  merely  a vexatious  search  covered  under Section 22 of Central Excise Act 1944
105. I   would   like   to   reproduce   Section   22   of   the  Central Excise Act as under :
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Section   22.   Vexatious   search,   seizure,   etc.,   by  Central Excise Officer. − 
Any Central Excise or other officer exercising powers under this 
Act or under the rules made thereunder who −
a) without reasonable ground of suspicion searches or causes to be 
searched any house, boat or place;
b)   vexatiously and unnecessarily detains, searches or arrests any  person;
c)   vexatiously and unnecessarily seizes the movable property of 
any person, on pretence of seizing or searching for any article 
liable to confiscation under this Act;
d)   commits, as such officer, any other act to the injury of any 
person, without having reason to believe that such act is required 
for the execution of his duty;
shall, for every such offence, be punishable with fine which may  extend to two thousand rupees.
Any person wilfully and maliciously giving false information and 
so causing an arrest or a search to be made under this Act shall be 
punishable with fine which may extend to two thousand rupees or 
with imprisonment for a term which may extend to two years or  with both.
106. Ld.   Defence   counsel   has   referred   to   the  statements   of   PW−9   Pradeep   Kumar,   the  
Commissioner   of  Central   Excise,   PW−21   Sunil   Kumar,   the   Superintendent, 
Central Excise and PW−29 K. N. Srivastava, Inspector, Central  Excise.   Ld.   Defence   counsel  
submits   that   verification   of  intelligence   can   be   done   by   Superintendents.   Ld.   Defence Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

counsel submits that PW−11 B. Mohan, Deputy Commissioner  has   testified   that   unauthorized  
raids   are   punishable   under  Section 22 of Central Excise Act, 1944. Ld. Defence counsel  has  
referred   to   the   statement   of   PW−12   S.   K.   Singh, 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Superintendent,   who   testified   that   on   27.12.2011,   Sh.   B. 
Mohan, the Deputy Commissioner, informed him (i.e. PW−12)  that   there   is   a   verification  
search   operation   going   to   be  conducted   on   28.12.2011   and   A−2   also   asked   PW−12   over 
intercom to join verification. It is argued that this shows that 
the search was conducted with the knowledge and permission  of the higher officers. 
107. Ld.   Defence   counsel   has   referred   to  Central  Excise   Law   Manual   2001−02   Chapter  
17   Part−I   para   2.3  and para 2.4. I would like to reproduce the same as under :
"CHAPTER 17 SEARCH, SEIZURE ARREST AND PROSECUTION PART 1
SEARCH AND SEIZURE ........
.......
.......
2.3 In terms of the said rules, an officer not below the rank of the 
Inspector of Central Excise, duly authorized by Commissioner by special  or   general  
order,   can   search   at   any   time,   any   premises   or   conveyance 
where he has reason to believe that excisable goods are manufactured, 
stored or carried in contravention of the provisions of the Act or rules. For 
a registered premises or for stopping and searching any conveyance  in   transit   no  
search   warrant   is   required.   However,   in   other   cases,  normally   search  
warrants  are   issued   by   the   Deputy/   Assistant 
Commissioner authorizing the search. The Central Excise Officer is also 
authorized to stop and search any conveyance as well. The search is to be 
carried out in the presence of two independent witnesses.
2.4 Section   22   deals   with   vexatious   searches,   seizure   etc.   by 
Central Excise Officers. In such case the Central Excise office will be 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
liable   to   punishment   under   the   law.   Similar   provision   is   made  applicable  
to   any   person   wilfully   and   malaciously   giving   false 
information leading to vexatious search."
108. Referring to the aforesaid provisions, it is argued  by   Ld.   Defence   counsel   that   at   the  
most,   A−2   conducted   a  search, which at the most could be termed as "vexatious". It is 
argued that although it was conducted in a bona fide manner 
but if there was any inconvenience to anyone, it would have 
been punishable under Section 22 of the Central Excise Act,  1944.   It   is   argued   by   Ld.   DefenceCbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

  counsel   that   in   view   of  paras 2.3 and 2.4, as quoted above, no search warrant was 
required for conducting the search in question. 
109. I have considered the submissions of Ld. Defence 
counsel. It would require appreciation of evidence to reach to 
a conclusion as to whether it is simply a case of a vexatious 
search. If it simply turns out to be a case of vexatious search, 
I would agree with Ld. Defence counsel that accused would 
be required to be acquitted. Hence, presently this question is  kept   open   and   would   be   decided  
in   later   part   of   the  judgement.
5. Whether there is  any defect in  proving certificates 
under Section 65B of Indian Evidence Act by PW−4
110. PW−4   Anuj   Bhatia,   the   Nodal   Officer,   Vodafone 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Mobile Services, testified that as a Nodal Officer he is heading 
the department dealing with the matters where requests are 
received from various investigating agencies for obtaining call  records   and   Customer  
Application   Form.   He   proved   the  Production−cum−
Seizure Memo dated 18.01.2012 vide which  various   original   Customer   Application   Forms   in  
respect   of  various   persons   including   A−1   and   A−3   regarding   mobile 
phone no. 9899426957 and 9899016666, respectively, were 
handed over to the Investigating Officer. Since these are the  original   documents   with   annexures,
  which   are   photocopies  available in record, no certificate under Section 65B of Indian 
Evidence Act is required to prove the same. 
111. It   appears   that   the   objection   of   Ld.   Defence  counsel is non−
exhibition of the certificates under Section 65B  of Indian Evidence Act. I disagree with the same. D−
61 is a  certificate   under   Section   65B   of   Indian   Evidence   Act   in  respect   of   the   call  
details   of   mobile   phone   numbers  9899016666,   9582000505,   9811602221,   9899426957, 
9811697334   and   9999919999   and   the   same   is   Ex.PW4/J. 
This is sufficient compliance of the provisions under Section  65B of Indian Evidence Act.
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Details of Intercepted Calls and Transcriptions
112. The   CD   containing   all   the   intercepted   calls   has  been proved by PW−15 as Ex.P−
1. I would like to tabulate the  relevant intercepted calls as under :
 Call           Exhibit                                              Call No. Detail
 No.
   01          PW9/PB               Call no. 1, dated 23.12.2011, time at 12:13:05, Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

Duration 42 sec. conversation held between Hemant 
Gandhi (9818517000) and Anup Kumar Srivastava  (9899426957) 02 PW9/PB−1
Call no. 2, dt. 27.12.2011, time at 12:55:28,  duration 32 sec. conversation held between Hemant 
Gandhi (9818517000) and Anup Kumar Srivastava  (1123378637) 03 -
Call no. 3, dated 27.12.11, time at 13:42:42,  duration 29 sec, Conversation held between Hemant 
Gandhi (9818517000) and Ashok Aggarwal  (9811697334) 04  PW 2/PX4
Call no. 4, dt. 27.12.11, time at 14:32:49, duration  101 Sec, conversation held between Lallan Ojha 
(9953248659) and Hemant Gandhi  (9818517000) 05 -
Call no. 5, dated 27.12.11, time16:17:35, duration  101 sec, Conversation held between His Wife (11−
25227000) and Hemant Gandhi (9818517000) 06  PW 2/PX5
Call no. 6, dt. 27.12.11, time at 18:06:28, duration  47 Sec, conversation held between Lallan Ojha 
(9953248659) and Hemant Gandhi (9818517000)  07  PW 2/PX6
Call no. 7, dt. 27.12.11, time at 18:23:36, duration 
29 Sec, conversation held between Hemant Gandhi  (9818517000) and Lallan Ojha (995324P8659)
08 Not proved Call no. 8, dated 27.12.11, time 18:24:16, duration 
48 sec, Conversation held between Hemant Gandhi  (9818517000) and His Wife (11−25223000)
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 09
Not proved Call no. 9, dated 27.12.11, time 18:31:06, duration 
31 sec, Conversation held between His Wife (11− 25223000) and Hemant Gandhi (9818517000) 10
Not proved Call no. 10, dated 27.12.11, time 19:02:49, duration 
61 sec, Conversation held between Hemant Gandhi  (9818517000) and His Wife (11−25223000) 11
Not proved Call no. 11, dated 27.12.11, time 19:09:03, duration 
32 sec, Conversation held between Khurana  (9999919999) and Hemant Gandhi (9818517000)  12
 PW 2/PX7 Call no. 12, dt. 28.12.11, time at 07:20:25, duration  
72 Sec, conversation held  between Hemant Gandhi  (9818517000) and Lallan Ojha (9953248659) 
13  PW 2/PX8 Call no.13  dt. 28.12.11, time at 07:56:00, duration 
70 Sec, conversation held between Lallan Ojha  (9953248659) and Hemant Gandhi (9818517000)
14  PW 2/PX8 Call no.14, dt. 28.12.11, time at 08:19:07, duration  222   Sec,   conversation   held    
between   Lallan   Ojha  (9953248659) and Hemant Gandhi (9818517000) 15  PW 2/PX10 Call   no.  
15,   dt.   28.12.2011,   time   at   08:28:21,  duration   207   Sec.   conversation   held   between  
Lallan  Ojha   (9953248659)   and   Hemant   Gandhi  (9818517000) on 28.12.11 16  PW 2/PX11 Call  
no.   16,   dt.   28.12.2011,   time   at   09:03:28,  duration   289   Sec.   conversation   held   between  
Lallan  Ojha   (9953248659)   and   Hemant   Gandhi  (9818517000) on 28.12.11 17  PW 2/PX12
 Call no. 17, dt. 28.12.2011, time 09:48:33, duration  133   sec.   conversation   held   between  
Hemant   Gandhi  (9818517000)and   Lallan   Ojha   (9953248659)   on  28.12.11 18  PW 2/PX13
 Call no. 18, dt. 28.12.2011, time 09:58:24, duration  113   sec.   conversation   held   between   Lallan
  Ojha  (9953248659)  and Hemant Gandhi  (9818517000) on  28.12.11 19  PW 2/PX14
 Call no. 19, dt. 28.12.2011, time 10:59:29, duration  43   sec.   conversation   held   between   Lallan  
Ojha  (9953248659)  and Hemant Gandhi  (9818517000) on  28.12.11
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 20
 PW 2/PX15   Call   no.   20,   dt.   28.12.2011   ,   time   11:00:27,  duration 69 sec. conversation held 
between between  Lallan   Ojha   (9953248659)   and   Hemant   Gandhi  (9818517000) on 28.12.11
21 Not proved Call No. 21, dt. 28.12.2011, time 11:14:05, duration  64   sec.   Conversation   between  
Hemant   Gandhi  (9818517000) and Ashok Aggarwal (9811697334) 22 Not provedCbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

Call no.22, dt. 28.12.2011, time 11:16:18, duration  27   sec.   Conversation   between   Ashok  
Aggarwal  (9811697334) and Hemant Gandhi (9818517000) 23  PW 1/X
 Call no. 23, dt. 28.12.2011, time 11:16:42, duration  133   sec.   conversation   held   between   Amit 
(9899016666) and Hemant Gandhi (9818517000)  24  PW 1/X1   Call   no.   24,   dt.   28.12.2011   ,  
time   11:21:34,  duration   87   sec.   conversation   held   between   Hemant 
Gandhi(9818517000) and Lallan Ojha (9953248659)  25  PW 1/X2   Call   no.   25,   dt.   28.12.2011  
,   time   11:23:22,  duration   37   sec.   conversation   held   between   Hemant 
Gandhi(9818517000) and Amit (9899016666) 26  PW 1/X3
 Call no. 26, dt. 28.12.2011, time 11:37:09, duration  60   sec.   conversation   held   between   Lallan  
Ojha  (9953248659) and Hemant Gandhi (9818517000) 27  PW 1/X4   Call   no.   27,   dt.  
28.12.2011   ,   time   11:38:26,  duration 102 sec. conversation held between Hemant 
Gandhi (9818517000) and Dileep (9650192981)  28  PW 1/X5
 Call no. 28, dt. 28.12.2011, time 11:42:13, duration  48   sec.   conversation   held   between   Hemant
  Gandhi  (9818517000)   and   Anup   Kumar   Srivastava  (1123378637) 29  PW 1/X6
 Call no. 29, dt. 28.12.2011, time 11:52:19, duration  51   sec.   conversation   held   between   Lallan  
Ojha  (9953248659) and Hemant Gandhi (9818517000) 30  PW 1/X7
 Call no. 30, dt. 28.12.2011, time 11:53:20, duration  55   sec.   conversation   held   between   Lallan  
Ojha  (9953248659) and Hemant Gandhi (9818517000) 31  PW 1/X8
 Call no. 31, dt. 28.12.2011, time 12:02:54, duration  109   sec.   conversation   held   between  
Hemant   Gandhi  (9818517000) and Dileep (9650192981)
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 32
 PW 1/X9   Call   no.   32,   dt.   28.12.2011   ,   time   12:03:54,  duration   100   sec.   conversation  
held   between   Lallan  Ojha   (9953248659)   and   Hemant   Gandhi  (9818517000)  33  PW 1/X10
 Call no. 33, dt. 28.12.2011, time 12:05:52, duration  180   sec.   conversation   held   between  
Hemant   Gandhi  (9818517000) and Dileep (9650192981)  34  PW 1/X11   Call   no.   34,   dt.  
28.12.2011   ,   time   12:11:23,  duration   82   sec.   conversation   held   between   Lallan  Ojha  
(9953248659)   and   Hemant   Gandhi  (9818517000) 35  PW 1/X12
 Call no. 35, dt. 28.12.2011, time 12:15:36, duration  54   sec.   conversation   held   between   Lallan  
Ojha  (9953248659) and Hemant Gandhi (9818517000) 36  PW 1/X13   Call   no.   36,   dt.  
28.12.2011   ,   time   12:18:53,  duration   88   sec.   conversation   held   between   Dileep 
(9650192981) and Hemant Gandhi (9818517000)   37  PW 1/X14   Call   no.   37,   dt.   28.12.2011   ,  
time   12:20:16,  duration   39   sec.   conversation   held   between   Lallan  Ojha   (9953248659)  
and   Hemant   Gandhi  (9818517000)  38  PW 1/X15   Call   no.   38,   dt.   28.12.2011   ,   time  
12:23:42,  duration   36   sec.   conversation   held   between   Lallan  Ojha   (9953248659)   and  
Hemant   Gandhi  (9818517000) 39  PW 1/X16   Call   no.   39,   dt.   28.12.2011   ,   time   12:24:46, 
duration   47   sec.   conversation   held   between   Lallan  Ojha   (9953248659)   and   Hemant  
Gandhi  (9818517000) 40  PW 1/X17   Call   no.   40,   dt.   28.12.2011   ,   time   12:31:49,  duration  
43   sec.   conversation   held   between   Lallan  Ojha   (9953248659)   and   Hemant   Gandhi 
(9818517000)  41  PW 1/X18  Call no. 41, dt. 28.12.2011, time 12:45:19, duration  69   sec.  
conversation   held   between   Hemant   Gandhi  (9818517000) and Dileep (9650192981)  42
 PW 1/X19   Call   no.   42,   dt.   28.12.2011   ,   time   12:47:52,  duration   29   sec.   conversation  
held   between   Lallan 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 Ojha  
(9953248659)   and   Hemant   Gandhi  (9818517000) 43  PW 1/X20   Call   no.   43,   dt.   28.12.2011Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

  ,   time   12:57:42,  duration   40   sec.   conversation   held   between   Lallan  Ojha   (9953248659)  
and   Hemant   Gandhi  (9818517000)  44  PW 1/X21   Call   no.   44,   dt.   28.12.2011   ,   time  
13:00:44,  duration   93   sec.   conversation   held   between   Hemant 
Gandhi (9818517000) and Lallan Ojha (9953248659)   45  PW 1/X22   Call   no.   45,     dt.  
28.12.2011   ,   time   13:09:39,  duration   83   sec.   conversation   held   between   Lallan  Ojha  
(9953248659)   and   Hemant   Gandhi  (9818517000) on 28.12.11 46  PW 1/X23   Call   no.   46,   dt.
  28.12.2011   ,   time   13:22:29,  duration   99   sec.   conversation   held   between   Lallan  Ojha  
(9953248659)   and   Hemant   Gandhi  (9818517000) 47  PW 1/X24   Call   no.   47,   dt.   28.12.2011
  ,   time   13:26:01,  duration   60   sec.   conversation   held   between   Hemant  Gandhi  
(9818517000)   and   PA   of   Commissioner  (1123378637)  48  PW 1/X25   Call   no.   48,   dt.  
28.12.2011   ,   time   13:33:08,  duration   206   sec.   conversation   held   between 
Mehaendra Kapoor (1123379010) and Hemant Gandhi  (11−25225641)  49  PW 1/X26   Call   no.  
49,   dt.   28.12.2011   ,   time   13:43:35,  duration   89   sec.   conversation   held   between   Ashok 
Aggarwal   (9811697334)   and   Hemant   Gandhi  (9818517000)  50  PW 1/X27   Call   no.   50,   dt.  
28.12.2011   ,   time   14:19:47,  duration   58   sec.   conversation   held   between   Dileep 
(9560806997) and Hemant Gandhi (9818517000)  51  PW 1/X28   Call   no.   51,   dt.   28.12.2011   ,  
time   16:12:06,  duration 68 sec. conversation held between Anoop Kr 
Srivastava, his PA (1123378637) and   Hemant Gandhi  (9818517000) 52  PW 1/X29/1   Call   no.  
52,   dt.   28.12.2011   ,   time   17:53:09, 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
duration 166 sec. conversation held between Hemant  Gandhi (11−
25225641) and Amit (9899016666) 52  PW 1/X29/2   Call   no.   52,   dt.   28.12.2011   ,   time  
17:53:09,  duration 166 sec. conversation held between Hemant  Gandhi (11−
25225641) and Amit (9899016666) 53  PW−1/X−30   Call   no.   53,   dt.   28.12.2011   ,   time  
18:05:24,  duration   33   sec.   conversation   held   between   Amit 
(9899016666) and Hemant Gandhi (11−25225641)   54  PW−1/X−    Call   no.   54,   dt.   28.12.2011  
,   time   20:18:40,  31/1 duration   201   sec.   conversation   held   between   Ashok  Aggarwal  
(9811697334)   and   Hemant   Gandhi  (9818517000) on 28.12.11 55  PW−1/X−32   Call   no.   55,  
dt.   29.12.2011   ,   time   13:19:50,  duration   46   sec.   conversation   held   between   Hemant 
Gandhi (9818517000) and Lallan Ojha (9953248659) 56  PW−1/X−33   Call   no.   56,   dt.  
30.12.2011   ,   time   08:54:31,  duration 138 sec. conversation held between Hemant 
Gandhi (9818517000) and  Lallan Ojha (8130000444) 57  PW−1/X−34
 Call no. 57, dt. 30.12.2011 , time 10:17:37,  duration 41 sec. conversation held between  Lallan 
Ojha (8130000444) and Hemant Gandhi  (9818517000)  58  PW−1/X−35   Call   no.   58,   dt.  
30.12.2011   ,   time   10:28:10,  duration   109   sec.   conversation   held   between   Lallan  Ojha  
(8130000444)   and   Hemant   Gandhi  (9818517000)  59  PW−1/X−36   Call   no.   59,   dt.  
30.12.2011   ,   time   10:30:24,  duration   39   sec.   conversation   held   between   Lallan  Ojha  
(8130000444)   and   Hemant   Gandhi  (9818517000)  60  PW−1/X−37   Call   no.   60,   dt.  
30.12.2011   ,   time   12:38:06,  duration   40   sec.   conversation   held   between   Lallan  Ojha  
(8130000444)   and   Hemant   Gandhi  (9818517000) 61  PW−1/X−38   Call   no.   61,   dt.  
30.12.2011   ,   time   13:08:15,  duration 59 sec. conversation held between   Hemant 
Gandhi (9818517000) and Dileep (9560806997)  62  PW 18/A   Call   no.   62,   dt.   30.12.2011   ,  
time   13:59:28, 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

duration   103   sec.   conversation   held   between   Dileep  (9560806997) and Puneet (9650111775) 
63 - Call no. 63, dt. 30.12.2011 , time 14:21:15, duration  357  sec. Covnersation held between Dileep
 Aggarwal  (9560806997) and Pathak (9540050046) 64  PW−1/X 
Call no. 64, dt. 30.12.2011 , time 14:30:30, duration  39/1 153   sec.   conversation   held   between  
Hemant   Gandhi  (9818517000) and Kapoor (9810406660) 64  PW−1/X 
Call no. 64, dt. 30.12.2011 , time 14:30:30, duration  39/2 153   sec.   conversation   held   between  
Hemant   Gandhi  (9818517000) and Kapoor (9810406660) on 30.12.11 65  PW−1/X 40
Call no. 65, dt. 30.12.2011 , time15:12:55, duration  108   sec.   conversation   held   between   Lallan  
Ojha  (8130000444) and Hemant Gandhi (9818517000)  66  PW−1/X 41
Call no. 66, dt. 30.12.2011 , time 15:59:38, duration  36   sec.   conversation   held   between   Dilip  
Aggarwal  (9560806997) and Hemant Gandhi (1145769974) 67  PW−1/X 42
Call no. 67, dt. 30.12.2011 , time 17:28:57, duration 
27 sec. conversation held between Hemant Gandhi (11− 25225641)   and   Person   O/o  
Commissioner   (11− 23378637)  68  PW−1/X 43 Call no. 68, dt. 30.12.2011 , time 17:31:31, duration 
47 sec. conversation held between Hemant Gandhi (11−
25225641) and Anup Kumar Srivastava (9899426957)  on 30.12.11 69  PW−1/X 44   Call   no.   69,  
dt.   30.12.2011   ,   time   17:48:50,  duration 115 sec. conversation held between  Hemant 
Gandhi (11−25225641) and Lallan Ojha (8130000444)  on 30.12.11 70  PW−1/X 45
Call no. 70, dt. 30.12.2011 , time 18:24:38, duration  47   sec.   conversation   held   between  
Hemant   Gandhi  (9818517000) and Dileep (9560806997) 71 -
Call no. 71, dt. 30.12.2011 , time 18:54:32, duration  118 sec. Coversation between Dileep Aggarwal 
(9560806997) and Himanshu (9136311838) on  30.12.11.
72  PW− 18/B Call no. 72, dated 30.12.2011, time 19:06:44, 
duration 98 sec, Conversation held between  Dilip 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Aggarwal (9560806997) and Punit (9650111775) 73  PW2/PX/16
Call no. 73, dated 30.12.2011, time 19:23:21,  duration 148 sec, Transcription of conversation held 
between  Lallan Ojha (9811602221) and S.K.Singh  (9818145883)  74
Call no. 74, dated 30.12.2011, time 19:24:02,  duration 29 sec, Conversation held between Dilip 
Aggarwal (9560806997) and Anand Aggarwal  (9711420824)  PW− 1/X/46
Call no. 75, dated 30.12.2011, time 19:34:08,  75
duration 29 sec, Conversation held between Hemant 
Gandhi (9818517000) and Dileep (9560806997) 76 - Call no. 76, dated 30.12.2011, time 19:34:42, 
duration 23 sec, Transcription of conversation held 
between Anand Aggarwal (9818517000) and Dilip  Aggarwal (9560806997) 77  PW−1/X/47
Call no. 77, dated 30.12.2011, time 19:39:23,  duration 30 sec, Transcription of conversation held 
between  Lallan Ojha(8130000444) and Hemant  Gandhi (9818517000) 78  PW−1/X/48
Call no. 78, dated 30.12.11 , time 19:46:16,  duration 200 sec, Transcription of conversation held 
between   Lallan Ojha (8130000444) and Hemant  Gandhi (9818517000) 79 -
Call no. 79, dated 30.12.11, time at 20:43:03,  duration 228 sec, conversation between Dileep 
Aggarwal (9560806997) and Anand Aggarwal  (9711420824) 80  PW−2/X/17
Call no. 80, dated 31.12.11, time at 10:37:58,  duration 78 sec, Conversation held between  Lallan 
Ojha (8130000444) and Hemant Gandhi  (9818517000) 81  PW−1/X/49Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

Call no. 81, dated 31.12.11, time 10:40:06, duration 
55 sec, Transcription of conversation held between  
Lallan Ojha (8130000444) and Hemant Gandhi  (9818517000) 82 -
Call no. 82, dated 31.12.11, time at 10:45:19,  duration 356 sec, conversation between  Dileep 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Aggarwal (9560806997) and Anand Aggarwal  (8860752486) 83  PW2/PX−18
Call no. 83, dated 31.12.11, time at 21:12:37,  duration 237 sec and conversation held between 
Balwan (8295738558) and  Lallan Ojha (9811602221) 84  PW−1/X/50
Call no. 84, dated 01.01.12, time at 15:19:47,  duration 87 sec, Conversation held between Hemant 
Gandhi (9818517000) and Lallan Ojha (8130000444) 85  PW2/PX−19
Call no. 85, dated 01.01.12, time at 18:23:42,  duration 74 sec, Conversation held between Lallan 
Ojha (8130000444) and K. N. Srivastava (9953248659) 86  PW2/PX20
Call no. 86 dated 01.01.12, time at 19:44:08,  duration 89 sec, Transcription of conversation held 
between Lallan Ojha (8130000444) and K. N.  Srivastava (9953248659) 87  PW2/PX21
Call no. 87, dated 01.01.12, time at 23:01:07,  duration 178 sec, Conversation held between Lallan 
Ojha (8130000444) and K. N. Srivastava (9953248659) 88 PW 1/A
Call no. 88, dated 02.01.12, time at 11:45:06,  duration 48 sec, Conversation held between Hemant 
Gandhi (9910973978) and Lallan Ojha (8130000444)  89  PW 2/PX
Call no. 89, dated 02.01.12, time at 11:46:29, 
duration 23 sec and conversation held between  Lallan 
Ojha (8130000444) and Dileep(Driver)(9599623528) 90  PW 2/PX22
Call no. 90, dated 02.01.12, time at 11:47:21,  duration 57 sec, Conversation held between Lallan 
Ojha (8130000444) and Hemant Gandhi  (9818517000) 92 PW 1/B
Call no. 92, dated 02.1.12, time at 11:48:42,  duration 37sec, Conversation held between Lallan 
Ojha (8130000444)) and Driver of Hemant Gandhi  (9910973978) 93  PW 2/PX1
Call no. 93, dated 02.01.12, time at 11;49:37,  duration 22 sec, Conversation held between  Lallan 
Ojha (8130000444) and Dileep(Driver) (9899623528) 94  PW 2/PX2
Call no. 94, dated 02.01.12, time at 11:50:16,  durartion 100 sec,Conversation held between  Lallan 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Ojha (8130000444) and Dileep(Driver)(9899623528) 95 PW 1/C
Call no. 95, dated 02.01.12, time at 11:52:17,  duration 54 sec, Conversation held between Lallan 
Ojha (8130000444) and Driver of Hemant Gandhi  (9910973978) 96  PW2/PX3
Call no. 96, dated 02.01.12, time at 12:10:58,  duration 25 sec, Conversation held between  Lallan 
Ojha (8130000444)) and Dileep(Driver)(9899623528)
113. It   is   necessary   to   mention   here   that   all   the  intercepted calls have been proved by PW−
15 as contained in  the   CD   Ex.P−1.   However,   specific   exhibit   number   has   been  given   to 
various  calls, during  recording of evidence  with a  view   to   identify   as   to   which   witness   has  
identified   the  relevant  voice  in  the  intercepted calls. Therefore, even  if a 
specific exhibit number is not given to a specific call in the 
above chart, still the same stands proved collectively as Ex.P1 
and where exhibits numbers have been given, it means that 
particular witness has also identified the voice of the speaker. Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

114. The   CDRs   are   contained   in   the   CD   Ex.PW4/K,  were   seen   by   me   on   the   laptop  
and   compared   it   with   the  particulars   mentioned   above   the   transcripts   (D−67),   which 
were found to be correct except that the time mentioned in 
the CDRs is a bit different in terms of "seconds" as compared  to   the   intercepted   calls   details  
mentioned   in   the   transcript  and appearing in Annexure 'A', proved by PW−15. It is natural 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
because the calls were intercepted on a different computer / 
voice logger, whereas, the  timing of the calls were recorded  in the CDRs on a different system.
115. All   the   intercepted   calls   (except   which   are  mentioned in  bold and underlined 
serial numbers) are not  found in the CDR Ex.PW4/K.
116. Calls No. 62, 72 (CDR Ex.PW17/J, D−49), Call No.  64 (CDR Ex.PW17/K, D−
50) and Calls No. 89, 93, 94 & 96  (CDR Ex.PW4/N, D−63) are clearly reflected in these CDRs. 
117. The   CDRs   have   been   proved   alongwith   their 
certificates under Section 65B of Indian Evidence Act by PW− 17 and PW−4, respectively.
118. I may  further mention that PW−1 Rajesh Verma,  driver   of   Hemant   Gandhi   and   PW−2  
Dilip,   driver   of   Lallan  Ojha have testified of having conversation with Lallan Ojha 
and Hemant Gandhi on their mobile phones and have thus, 
proved not only the intercepted calls no. 88 to 96, but have  also  identified  their  own  voices as well
 as voices  of Lallan  Ojha   and   Hemant   Gandhi   in   all   the   intercepted   calls 
contained in Ex.P−1.
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
119. Though the CDR's of Calls No. 2, 27, 28, 31, 33, 
36, 41, 47, 48, 50, 51, 56, 57, 58, 59, 60, 61, 65, 66, 67, 70,  75,  77,  78,  80  and 81 were
 not proved and were  filed by  prosecution   just   a   few   days   before   announcement   of   this 
judgement, but even without these CDRs, I am of the opinion  that   prosecution   has   proved   the  
same   beyond   reasonable  doubt by proving intercepted calls through PW−15, who also  proved   all
  the   details   of   intercepted   calls.   The   respective  voices   in   these   calls   are   further   proved  
to   be   those   of   the  accused persons and witnesses. Moreover, when most of the 
calls are supported by CDRs, this court can safely presume 
the correctness of all the particulars of the calls mentioned in  Annexure   'A'   as   well   as   the  
contents   of   intercepted   calls  (Ex.P1), proved by PW−15.
6. Whether   the   integrity   of   the   intercepted   calls   has  been maintained
120. PW−15   M.   C.   Kashyap   has   testified   that   he  provided 96 intercepted calls in a CD (Ex.P−
1, which is also  marked   as   Q−1)   to   Insp.   Deepak   Purohit,   the   Investigating 
Officer on 06.01.2012, vide Seizure Memo, Ex.PW15/A, (D−Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

20)   alongwith  recorded  call   information  report  in   a  sealed 
packet. Perusal of this Seizure Memo also shows that   M. C. 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Kashyap   handed   over   one   sealed   packet   containing   96 
recorded calls, two system files and Words RC−AC1−2012−A− 0001−
CBI, which is duly signed by M. C. Kashyap, DSP. The 
CD shows the signatures of M. C. Kashyap, which PW−15 M. 
C. Kashyap had identified at point 'X'. I would like to refer to  the   Seizure     Memo   Ex.PW15/A,  
in   which   it   is   specifically  mentioned that the CD was sealed in an envelope and on the 
Seizure Memo specimen of the seal affixed was also given .  The Seizure
 Memo Ex.PW15/A shows the specimen of seal  available on it.
121. As per the testimony of PW−37 Ram Singh, DSP, 
the CD was sent to CFSL by Investigating Officer to Director,  CFSL for obtaining expert opinion. 
122. Now,   I   refer   to   the   testimony   of   Dr.   Rajender 
Singh, the Director, CFSL, Government of India, New Delhi,  who testified as under :
"On   12.01.2012,   Physics   Division   of   CFSL   received   8   sealed 
parcels from SP, CBI, ACU−I, New Delhi, vide letter no. RC.AC−I−2012−A−
0001/CBI/ACU−I/New Delhi, dated 12.01.2012. Further, on 30.01.2012, 
another sealed parcel was received from SP/CBI, ACU−I, New Delhi vide 
letter no. 211/RC−AC−I−2012−A−0001, dated 30.01.2012. The parcel was 
sealed with the seal of CBI and I found them in intact condition after  comparing  
with   the   specimen   seal   forwarded   by   the   Investigating 
Officer. These parcels were marked by me as Exhibit as Q−1, S−1 to S−8. 
The Exhibit Q−1 found to be contained a CD stated to have questioned  recorded  
conversation   of   Smt.   Reena   Gandhi,   Sh.   Rajesh   Verms,   Sh. 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Hemant Gandhi, Sh. Lallan Ojha, Sh. Dilip Aggarwal, Sh. Anand Kumar 
Aggarwal, Sh. Delip Kumar Yadav and Sh. Anup Kumar Srivastava. The  Exhibits   S−
1   to   S−8   found   to   be   containing   a   CD   stated   to   be   have 
specimen voice recordings of Smt. Reena Gandhi, Sh. Rajesh Verma, Sh. 
Hemant Gandhi, Sh. Lallan Ojha, Sh. Dilip Aggarwal, Sh. Anand Kumar 
Aggarwal, Sh. Delip Kumar Yadav and Sh. Anup Kumar Srivastava."
123. This   testimony   proves   that   the   CD   duly   sealed 
with the seal of Special Unit of CBI was received by CFSL. 
124. Now,   I   would   like   to   reproduce   the   relevant  portion   of   the   report   Ex.PW16/A   (D−
68),   in   which   the  description   of   the   parcels   received   by   CFSL   have   been 
mentioned, as under  :Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

"5. Details of parcels and seals ..........
Received   another   forwarding   memo   on   12.01.2012   from   the  Supdt.   Of  
Police,   CBI,   ACU−I,   New   Delhi   vide   No.   85/RC   AC1   2012  A0001 Dated 11−
01−2012 along with eight sealed parcels including 'Q−1'  & 'S−
3', specimen seal impressions of "CBI SU NEW DELHI" in wax and 
ink affixed on a white paper sheet and "CBI RS" in ink affixed on a 
another white paper sheet. The seals on the parcels were tallied with 
specimen seal impression and found intact.
The   parcel   marked   'Q−1'  is   a   yellow   colored   sealed   paper  envelope 
bearing four seals of "CBI SU NEW DELHI". It contained a compact disc 
marked exhibit Q−1."
125. The above referred evidence proves beyond doubt  that   the   CD,   which   was   sealed   with  
the   seal   of   SU   CBI 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
reached intact to CFSL. Now, let us see as to with what seal  CFSL sealed the CD Ex.P−1 (Q−
1). I refer to the concluding  portion of the CFSL report Ex.PW16/B (D−69) as under :
"NOTE :
              (a)         ......
              (b)      The compact discs marked exhibits 'Q−1', 'S−1', 'S−2', 'S−3', 'S−4', 
'S−5', 'S−6' & 'S−7' were re−checked for continuity of original sound and 
found in order and these were returned to the forwarding authority 
along with their original packing and sealed with the seals of "AD PHY 
CFSL CBI NEW DELHI".
126. Now, I would see as to in what condition the CD  reached the court.
127. The   envelope   containing   CD   was   first   of   all  opened   at   the   time   of   examination   of  
PW−1   and   my   Ld.  Predecessor observed as under :
"At   this   stage   a   sealed   envelope   sealed   with   the   seal   of   CFSL   Ex.Q−1 
containing  the marking  CFSL−2012/P−39, RC  AC1 2012 A0001/CBI/ACU  −
I/N.D has been produced. The said envelope is ordered to be opened. It  contains   an
  envelope   in   open   condition   bearing   marking   RC   AC1   2012 
A0001/CBI/N.D( MR−134/12) and one CD bearing the same RC number  and  
CFSL−2012/P−0039   Ex.   Q−1   alongwith   its   cover.   There   are   two  signatures  
on   this   CD   one   is   dated   6.1.2012   and   second   is   dated  17.02.2012.   It   is  
also   mentioned   on   the   CD   "96   Calls".   Ld.   Sr.PP   has 
requested permission to play call numbers 88, 92 and 95. The transcription Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
of the same is given in document no. D−67."
128. Thus,   when   the   envelope   containing   CD   Ex.P−1  was  opened  in   the   court  during 
testimony  of  PW−1, it   was  sealed with the seal of CFSL. 
129. Therefore, prosecution has proved to the hilt the  integrity   of   the   electronic   evidence   in  
form   of   intercepted  calls contained in CD Ex.P−1 (Q−1).
130. Ld. Defence counsels have pointed out that there 
is possibility of tampering the electronic evidence when PW− 15 segregated  the 
96 calls. It is submitted that it is at the 
stage that the CBI could have manipulated the contents of the  intercepted   calls   and   therefore,  
the   contents   of   the   CD  containing 96   calls should be rejected. I disagree  with this 
submission. The provision of Section 65B of Indian Evidence  Act   is   meant   to   rule   out   the  
possibility   of   such   tampering  electronic evidence. I do not find any reason as to why CBI  would  
deliberately   try   to   create   false   evidence   against   the 
accused persons. Perusal of testimony of PW−15 shows that 
the witness has explained the entire process of intercepting  and   segregating   the   calls   in   a   CD,
  which   is   worthy   of  credence. He has also furnished the certificate under Section 
65B of Indian Evidence Act and a report of the mobile phones 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
calling and called, their duration, time and date. Therefore, I 
am of the opinion that the integrity of the electronic evidence  in question has been vouche safed. 
7.  Intercepted mobile phones/ landlines
131. PW−15   has   proved   his   certificate   under   Section 
65B of Indian Evidence Act as Ex.PW15/G (D−26) and he has 
annexed as Annexure 'A' all the details of named recorded call 
file, date of recording on computer system, time of recording  on   computer   system   and   the  
intercepted   phone   number.   I  would like to reproduce the same as under :
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
8. Crux of the above discussion
132. The result of above discussion can be summed up  as under :
(i)   Prosecution   has   successfully   proved   any 
possibility of tampering of the intercepted calls 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

contained in CD Ex.P−1.
(ii)   The   calls   were   intercepted   after   due  authorization.
(iii)   Particulars of the intercepted calls of the mobile 
phones have been proved by PW−15 by way of  proving Annexure 'A'.
(iv)   Most   of   these   intercepted   calls,   as   already 
discussed, are supported with CDRs. Although, 
some of the CDRs were not proved but CBI has  filed   the   same   just   a   few   days  
before   the  judgement,   which   I   have   not   taken   into 
consideration, but atleast it proves the intention 
of CBI that it was not deliberately withholding  of the evidence.
(v)   The speakers in the intercepted calls have been  proved   by   prosecution   by  
examining   voice  expert. His report remains un−impeached.
(vi)   PW−1   and   PW−2   have   identified   the   voice   of  Lallan   Ojha.   PW−1   has  
identified   the   voice   of  Hemant   Gandhi   and   PW−2   has   identified   the 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
voice   of   Lallan   Ojha   in   all   the   calls.   PW−18  Puneet   Mittal   has   identified  
his   own   voice   in  Calls   No.   62  and   72.  He  did   not   identify   the 
voice of Dilip Aggarwal for the obvious reason  of   his   employee/salesman.  
However,   it   is  already   proved  that   he   was   talking   to   mobile 
phone no. 9560806997, which belongs to Dilip 
Aggarwal. Moreover, voice of Dilip Aggarwal is  proved by the expert.
(vii)   As per the report of voice expert, the respective  voices   in   the   intercepted  
calls   matched   with  Dilip Aggarwal and Anand Aggarwal. 
(viii)   Prosecution has also proved (as indicated in the 
charge in earlier part of judgement) as to who  was the owner / user of which phone. 
133. All this evidence is so overwhelming that it is not  possible   to   reject   the   calls,   of   which  
CDRs   have   not   been  proved by prosecution. 
9. Whether the money belongs to the wife of A−2
134. A−2   has   examined   his   wife   Smt.   Shashi   Ojha 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
(A2/DW1)   in   his   defence.   I   have   already   reproduced   her 
entire evidence in earlier part of the judgement. It is argued 
by Sh. V. K. Ohri, Ld. Defence counsel that the recovery of  Rs.3,46,500/−
 was not from Lallan Ojha (A−2) and it was from  car   of   his   wife,   which   has   come   to   hand  Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

over   lunch   to  accused. It is further argued that CBI itself says so in charge− sheet.   It   is   further  
submitted   that   the   explanation   of  Rs.3,46,500/−   given   by   defence   witness   i.e.   wife   of  
Lallan  Ojha (A−2) has gone unchallenged, which clearly establishes 
that the amount so recovered belongs to the company of the  wife of accused Lallan Ojha (A−
2) and her niece. It is further  argued that amount of Rs.3 lacs as alleged by CBI was not 
found from the car of the accused's wife which CBI has failed 
to explain. It is further argued that the CBI intentionally did 
not take the finger prints from the packet recovered from the  car containing Rs.3,46,500/−
 kept by accused's wife and also  no   finger   prints   from   currency   notes   were   taken   and   the 
currency notes so recovered were neither shown to both the  drivers PW−1 and PW−
2 nor they were confronted with each  other during investigation by CBI to prove its case.
135. On the other hand, Ld. Senior Public Prosecutor  has   drawn   my   attention   to   the  
testimony   of   PW−1   Rajesh 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Verma, who is the driver of Hemant Gandhi (A−3) as well as  testimony   of   PW−2   Dilip   Kumar  
Yadav,   the   driver   of   Lallan  Ojha (A−2). 
136. I would like to refer to the evidence of PW−1 and  PW−2. 
137. PW−1 Rajesh Verma testified that on 02.01.2012,  Hemant Gandhi (A−
3) had handed over to him a sum of Rs.3  lacs to deliver the same to Mr. Lallan Ojha (A−
2) at his ITO  office. He testified that Hemant Gandhi (A−3) had also given 
him the phone number of Lallan Ojha (A−2). At around 09:00 
a.m. - 09:30 a.m., he left Punjabi Bagh residence of Hemant  Gandhi (A−
3) for ITO. He further testified that after arriving  at   ITO,   he   called   from   him   mobile   phone  
number  9910973878   to   Mr.   Lallan   Ojha   on   his   phone   number.  However, Lallan Ojha (A−
2) informed him that he was not in  the office and directed PW−1 to hand over the money to his 
driver. PW−1 further testified that he had carried Rs.3 lacs in a  polythene bag. Lallan Ojha (A−
2) gave mobile phone number  of PW−1 to his driver. PW−1 further testified that he received a 
call from the said driver and then came in car Chevrolet Beat 
of white colour bearing no. 7101. Driver of Lallan Ojha (A−2)  parked the car behind the car of PW−
1 and called his name 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
"Rajesh". PW−1 testifies that therefore, he recognized him and 
handed over polythene bag containing Rs.3 lacs to driver of  Lallan Ojha. PW−
1 also identified his voice as well as the voice  of Lallan Ojha (A−2) in the intercepted calls. 
138. Sh. V. K. Ohri, Ld. Defence counsel has drawn my  attention   to   the   cross−examination   of  
PW−1   by   accused  Hemant Gandhi (A−3). In this cross−examination, it is stated  by   PW−1   that  
he   was   not   aware   of   the   contents   of   the 
polythene packet because he never used to open the packets. 
It is, therefore, argued that there is no evidence to show as to  what   was   delivered   by   PW−1  to  
PW−2.   I   disagree   with   this  submission,   of   Ld.   Defence   counsel.   The   aforesaid   reply   of Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

PW−1 is in respect of the gifts, which used to be delivered by  him   on   behalf   of   Hemant   Gandhi
  (A−3)   to   his   friends   and  officers at the time of festivals Dussera, Diwali and New Year. 
This testimony is not in respect of the money carried by him  in polythene bag for Lallan Ojha (A−2).
139. Now, I take up the evidence of PW−2 Dilip Kumar 
Yadav. He testified that at the relevant time he was working  as a driver of Lallan Ojha (A−
2) and was possessing a mobile  phone number of 9899623528, which was given to him by 
accused Lallan Ojha and it belonged to his previous driver. He 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
stated that he did not remember the complete mobile phone  number   of   Lallan   Ojha   but   last  
digits   were   0000444.   He  testified  that   on   28.12.2011,  he   brought  Lallan  Ojha   (A−2) 
from his house to CR Building. From CR Building, one person  joined   him   in   the   car   and   then
  they   went   to   Rama   Road.  Lallan   Ojha   got   down   from   the   car   and   went   somewhere. 
After two hours, Lallan Ojha came back alongwith the same 
person and then went to CR Building. Thereafter, he drove  Lallan Ojha to his house.
140. PW−1 further testified that on 02.01.2012, he took  meals for Lallan 
Ojha to CR Building, one laptop was also  taken   by   him   alongwith   meals.   He   parked   the   car
  in   the  parking at about 11:00 a.m. He received a call from Lallan  Ojha  (A−2)  and  PW−
2 told him his location in  the parking.  PW−2 received further calls from Lallan Ojha (A−
2), who gave  him a mobile phone number. On instructions by Lallan Ojha  (A−2), PW−
2 reached at a juice shop on the main road. Lallan  Ojha (A−
2) had told him that one person would be handing  over   a   packet   and   that   PW−2   should   keep
  it   in   the   car.  Accordingly, PW−2 drove the car outside main road near juice 
shop and waited there. 
141. PW−2 further testified that one person came from 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
opposite direction and gave three packets and asked him to  count the same. PW−
2 further testified that the said person  told  him  that   these   packets  contained  Rs.3 lacs.  PW−
1 told  him (PW−2) to keep the packets in the car of which PW−2 was  driver. PW−
2 further testifies that these packets were put by 
that person on the front seat adjoining the driver seat. These 
three packets were in red colour thaila of some saree shop. 
142. PW−2 further testified that thereafter he drove to 
the parking of CR Building and sat alongwith other drivers in  the parking. When PW−
2 was in parking, Lallan Ojha (A−2)  called   him   and   asked   him   if   he   had   met   the   person 
concerned. Thereafter, the CBI officials came to him and on  their asking, PW−
2 told him that the car belonged to Lallan  Ojha (A−2). PW−
2 also told them that three packets were lying  in   the   car.   In   the   meantime,   accused  Lallan  
Ojha   was  also  brought near the car. The red colour thaila was opened and it  was   found   to  
contain   currency   notes   of   Rs.1,000/−   and  Rs.500/−   denominations.   He   testified   that   the
  said   amount  was counted and found to be Rs.3500/− less than Rs.3 lacs.Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

143. The entire testimony of PW−2 makes it clear that  Hemant Gandhi (A−
3) had sent the money (i.e. around Rs.3 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
lacs) through PW−1, which was handed over to PW−2 at the  instructions   of   Lallan   Ojha   (A−2).  
PW−2   has   specifically  denied  the   suggestion   of   Ld.   Defence   counsel   that   Lallan  Ojha (A−
2) informed the CBI officials that the money was sent  by his wife. 
144. PW−2   has   survived   a   long   cross−examination   by  Ld.   Defence   counsels,   but   his  
testimony   remained  unimpeached.   Although   a   few   contradictions   have   been 
pointed out by Ld. Defence counsels in examination−in−chief, 
statement under Section 161 Cr.PC and his statement under 
Section 164 Cr.PC. However, the same are extremely minor in 
nature and do not cast any shadow on the overall veracity of  the testimony of PW−2.
145. Smt. Shashi Ojha (A2/DW−1) has testified that she 
had kept a sum of Rs.3 lacs in a bag alongwith Rs.50,000/−.  She   testified   that   an   amount   of  
Rs.50,000/−   was   to   be  deposited in AIIMS for treatment of her niece, whereas, she 
had kept Rs.3 lacs to make the payments to the worker and to  buy raw material for the factory.
146. I am of the opinion that she is simply trying to 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 save
 her husband.  Testimony of PW−2 that it was a money  given to him by PW−
1, is fully supported by the testimony of  PW−
1. There is no reason as to why these two drivers would  testify   falsely.   It   must   be   kept   in  
mind   that   PW−2   was   the  driver   of   Lallan   Ojha   (A−2)   himself   and   his   loyalty   more 
towards   his   employer  than   CBI.  He   would  not  support   the  prosecution   case   unless   it   is  
true.   Further,   the   intercepted  telephonic conversation by PW−1 with Lallan Ojha (A−2) and 
conversation   by   PW−2   with   Lallan   Ojha   (A−2)   during   this  event   have   been   identified  
by   them.   Hence,   additional  corroboration   is   brought   on   record   by   prosecution,   which 
proves that PW−1 brought an amount of approximately Rs.3  lacs from Hemant Gandhi (A−
3) and as per the instructions on  mobile phone, PW−1 handed over the said amount to PW−2. 
Testimony of PW−2 and his conversation with Lallan Ojha (A−
2) on mobile, which is duly identified by him, further proves  that   PW−2   had   received   the  
amount   of   approximately   Rs.3  lacs from PW−1 at the instructions of Lallan Ojha (A−2).
147. Thus, the testimony of PW−1 and PW−2 is worthy 
of credence and is fully corroborated by the intercepted calls. 
In view of such authentic evidence, this court has no option 
but reject the testimony of Smt. Shashi Ojha (A2/DW−1).
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
10.  Whether   there   is   no   demand   of   money   by  Lallan Ojha (A−2)Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

148. Sh.   V.   K.   Ohri,  Ld.   Defence   counsel  for   A−2   has 
argued that there is no demand on part of Lallan Ojha (A−2). 
149. I   disagree   with   his   submissions.   All   the  intercepted  calls proved that A−
2 alongwith his team−mates  with active assistance of Hemant Gandhi (A−3) entered the  premises  
of   Anand   Aggarwal   (A−5)   and   cornered   and 
compelled him to pay money. As per Call No. 80, Ex.PW2/PX− 17,   Lallan   Ojha   (A−2)   is   asking
  Hemant   Gandhi   (A−3)   on  31.12.2011 to bring 2 or 3. It can be inferred that it is an 
amount of Rs.2 lacs or Rs. 3 lacs. 
150. As   per   Call   No.   90,   dated   02.01.2012,  Ex.PW2/PX−22,   Lallan   Ojha   is   asking   as   to
  how   much   has  been brought by the driver. Hemant Gandhi (A−3) replies that 
the same 3. It can be inferred to be an amount of Rs.3 lacs, 
which is proved by the recovery of the said amount on that  very day i.e. 02.01.2012. 
151. Ld. Senior Public Prosecutor further submits that 
the Call No. 94, dated 02.01.2012 at 11:50 a.m. Ex.PW2/PX2 
[also reflected in CDRs Ex.PW4/N (Colly.)], Lallan Ojha (A−2) 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 is  
asking   Dilip   (PW−2),   the   driver   of   Lallan   Ojha   (A−2),   in  which   Lallan   Ojha  is
 informing the  car number of Hemant  Gandhi being driven by PW−1 and also telling him that the 
said person will give him three packets.  I am left in no doubt  that  Lallan  Ojha (A−
2) is informing his driver Dilip (PW−2)  that   the   driver   of   Hemant   Gandhi   will   deliver  Rs.3  
lacs  to  him. 
152. This should be seen in the background that in the 
intercepted call no. 62 (Ex.PW18/A), accused Dilip Aggarwal  (mobile   phone   no.   9560806997)  
is   talking   to   one   Puneet  (PW−18)   (mobile   phone   no.   9650111775)   that  somehow 
Rs.3 lacs should be arranged within one hour. He also tells  Puneet (PW−
18) that he had put 20 in the plastic bag. PW− 18   had   turned   hostile   but   in   his   cross−
examination   by   Ld.  Senior Public Prosecutor, he had admitted his mobile phone  number   and  
his   own   voice   in   the   conversation   of   the 
intercepted calls. Although, he could not identify the voice of 
accused Dilip Aggarwal, however, since the CDR [Ex.PW17/J  (Colly.)](at page no. 138 of D−
49) proved that there was a  call between two phone numbers i.e. mobile phone number 
9650111775 (i.e. of Puneet) and 9560806997 (i.e. of Dilip 
Aggarwal), it stands proved that the conversation is between 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
these two persons. The intercepted call was played and Ld.  Prosecutor   specifically   put   a  
question   that   in   this  conversation,   he   was   being   asked   to   make   arrangement   of  bribe  
amount.   To   this  question,  he   replied   that   he   did   not  remember   and   that   it   is   possible  
that   he   might   have   been  asked   to   collect   the   payment   of   sales.   I   disagree   with   this 
reply of PW−18, who is testifying simply to save his employer. 
If the aforesaid conversation is considered in backdrop of the  entire   scenario,   which   is   reflectedCbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

  from   the   cumulative  reading/ hearing of all the intercepted calls, it is clear that  Dilip   Aggarwal
  is   desperate   to   arrange   Rs.3   lacs.   Dilip  Aggarwal   also   stated   in   this   call   that   Rs.20  
lacs   has   been  delivered.
153. These   conversations   are   dated   30.12.2011   and 
can be easily connected with the search in question.
154. Call   No.   72   (Ex.PW18/B)   dated   30.12.2011   is 
also between the said two persons, namely PW−18 and A−4, in  which   A−4   is   asking   as   to  
whether   Hemant   has   come   and  thereafter, telling him to give Hemant immediately  some 20 
after packing it. Thereafter, at point 'A' Dilip asks to collect  remaining   25.   Although,   PW−18  
was   confronted   with   Call  No. 72, and PW18 stated that he did not recollect and that he 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
might be asked to collect the payment of sales.  I may point  out   that   particulars   of   this   call  
also   match   with   the   CDR  Ex.PW17/J (Colly.) (at page 139 of D−49). Thus, it is clear 
that money is being demanded by Lallan Ojha (A−2) from A−5 
directly as well as through Hemant Gandhi (A−3).
11. Cheque of Rs.20 lacs
155. Cheque No. 263085, dated 05.01.2012 for a sum  of Rs.20 lacs, Ex.PW27/C (D−
6) drawn in the name of "Self"  on ING Vysya Bank Ltd., Kirti Nagar Branch, New Delhi, was  seized
  by   Insp.   Surender   Pahari,   vide   Memo   Ex.PW27/B  (Annexure   to   Arrest   Memo),   from  
the   personal   search   of  accused  Hemant Gandhi (A−3).
156. PW−27, Prem Lal Kukreti, the LDC in the office of  Executive   Engineer   (Building),   Central  
Zone,   Lajpat   Nagar  has proved the recovery of this cheque  in his presence. 
157. Accused   Anand  Aggarwal  (A−5)  has  admitted  in 
his statement under Section 313 Cr.PC that he was called by 
CBI officers on 02.01.2012 and his cheque book was taken  after   getting   the   cheque   book   filled
  and   counter−foil   being  written by him. This plea is patently false and after−thought 
because when PW−27 was examined, A−5 did not put to him 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 that  
the   cheque   was   an   unsigned   cheque   at   the   time   of  recovery   or   that   the   cheque   was  
never   recovered   from  Hemant   Gandhi   (A−3).   It   is   pertinent   to   note   that   in   the 
memo Ex.PW27/B it is specifically written that it was signed  by Sh. Anand Kumar Aggarwal i.e. A−
5. 
158. In this regard, it is necessary to mention that DSP  Ram  Singh,  the 
Investigating Officer of this case  recovered  vide recovery memo Ex.PW37/J (D−
78), one cheque book of  account no. 588010019800, in the name of Anand Aggarwal.  Perusal   of  
this   cheque   book   shows   that   on   the   transaction 
sheet in the cheque book, last entry dated 05.01.2012 shows Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

the cheque no. (2630)85 amounting to Rs.20,00,000/− issued  in   the   name   of   "Self"   and
 given   to   Hemant   Gandhi   as  security for Excise Officers. As per the statement of A−5 CBI 
got this entry from him under pressure during investigation. I  disagree   with   this   submission.  
The   memo   shows   that   the  various   documents   including   the   present   cheque   book   was 
handed over by A−5 to the Investigating Officer. Furthermore,  the   Investigating   Officer   had   not
  arrested   this   accused,  therefore, it can be safely presumed that A−5 could not have 
been forcibly compelled to write this entry in the transaction 
sheet of the cheque book. The fact that the actual cheque of 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Rs.20 lacs was found in the possession of Hemand   Gandhi, 
who was in constant touch with Excise Officers further proves 
the correctness of the entry in the transaction sheet.
12.  The intercepted calls in respect of the cheque
159.   In Call No. 60 (no CDR) (Ex.PW1/X−37), Lallan  Ojha (A−
2) (mobile phone no. 8130000444) is asking Hemant 
Gandhi (mobile phone no. 9818517000) to take the cheque 
and tell that "do taarikh tak mil lena chahiye otherwise paanch  
percent ke roz se hisaab lenge hum" (i.e. must get it by second 
of the month, otherwise five percent interest per day would  be charged). 
160. Call   No.   64,   dated   30.12.2011,   Ex.PW1/X−39/1, 
at time 14:30:30, is a conversation between Hemant Gandhi  (mobile   phone   no.   9818517000)  
and   Mahender   Kapoor  (mobile   phone   no.   9810406660).   In   this   conversation, 
Mahender Kapoor asks about Lallan Ojha (A−2) by referring  him   as   "Lallu   Ram".   Hemant  
Gandhi   (A−3)   tells   him   that  cheque will be given. Ld. Senior Public Prosecutor had drawn  my  
attention   to   the   cheque   of   Rs.20   lacs   issued   by   Anand  Aggarwal (A−
5), which was recovered from Hemant Gandhi  (A−
3). Further, the transaction slip also mentions that this is 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
issued for Excise officers. 
161. Call   No.   69,   dated   30.12.2011,   Ex.PW1/X−44  between   landline   011−25225641   and  
Lallan   Ojha   (mobile  phone   no.   8130000444),   Hemant   Gandhi   (A−3)   informed 
Lallan Ojha (A−2) that the said cheque has come.
162. The fact of recovery of the cheque of Rs.20 lacs  (issued by A−
5) from the possession of Hemant Gandhi (A−3),  should   be   seen   in   the   backdrop   of   the  
above−mentioned  conversations specifically as well as  in the background of the 
entire conversations. I am of the opinion that his is enough to 
believe that the aforesaid cheque was given by A−5 to Hemant 
Gandhi as a security to the promise that this amount would  be given to Lallan Ojha later on by A−5. Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

13.  Was it a rogue raid?
163. Prosecution has argued that the search operation 
was totally illegal because no permission of superiors were 
taken nor they were informed nor they acted pursuant to any  search   warrant.   In   order   to  
proved   this   allegation,  prosecution has examined Pradeep Kumar (PW−9), the then 
Additional Commissioner, Anti Evasion, Central Excise, New  Delhi−01.   He   testified   that  
whenever   intelligence   regarding 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
the evasion of Central Excise duty is received and developed, 
same is put up for authorization of search before competent 
authority i.e. Joint Commissioner/ Additional Commissioner 
for scrutiny of intelligence and if there is reasonable belief 
that some documents or things are secreted at the premises,  then   the   search   warrants   are  
issued.   He   testified   that  intelligence is developed by Inspectors and Superintendent of 
Central Excise and it is verified by them and then the secret  verification   of   premises   is   carried  
out   by   Inspectors   and  Superintendents  of   Central   Excise.   He   further   testified   that 
the search warrants are issued for the premises which are  not   registered   with   Central   Excise   or
  where   there   is   a  possibility   of   secretion   of   private   documents   even   in 
registered premises. He further testified that authorization 
of visit is only for registered premises. He further testified  that   in   both   cases   written
 permission  is  required.   In  cross− examination  he   stated that specific search was planned for 
28.12.2011 in case of M/s Ankita Electrodes and the officers  were   called   at   10:00   a.m.   on   that
  day   by   Deputy  Commissioner, Anti Evasion.
164. PW−11,   B.   Mohan   Reddy,   the   then   Deputy 
Commissioner, Anti Evasion, Central Excise, Delhi−1, testified 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 that  
as   per   the   intelligence   developed   by   Inspectors   and  Superintendents, a 
secret verification of premises is carried  out by them. Thereafter, the  search warrants 
are issued for  the   premises,   which   are   not   registered   with   Central   Excise  and
 authorization   of   visit  is   issued   for   the   registered  premises.  In   both   the   cases,   written  
permission   is  required. In cross−examination, he testified that the godown  of Anand Agarwal (A−
5) is not registered with Central Excise  and that if it is not registered with Central Excise, it will not 
come   within   the   jurisdiction   of   Central   Excise.   In   cross− examination   by   Sh.   S.   K.  
Rungta,   Ld.   Senior   Advocate,   he  stated that in case of premises / godown of Anand Aggarwal 
(A−5), no proposal was put to Commissioner for carrying out 
the raid/ search on 28.12.2011, nor any approval was given  by him. In cross−
examination, he admitted that as per Clause  9 (iv) of Chapter−2 of the
 Central Excise, Intelligence and  Investigation   Manual  issued   by   Directorate   General   of 
Central   Excise,   Intelligence,   officers   of   all   the   ranks   are 
encouraged to have their own sources of information. PW−11 
denied the suggestion on behalf of Lallan Ojha (A−2) that K.  N.   Srivastava,   who   was   posted   in  
Anti   Evasion   Branch   as  Inspector   on   28.12.2011,   had   informed   him   (i.e.   PW−11) Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

about the visit to the godown of Anand Aggarwal (A−2). It is 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
relevant to note here that in cross−examination by Sh. Rakesh  Kumar   Sharma,   Advocate   for   A−
4   and   A−5,   PW−11   testified  that on 28.12.2011,  an office order was issued for all the  officers  
of   Anti   Evasion   Branch   to   remain   present   on  28.12.2011   and   that   the   search   was  
conducted   at  premises   of   M/s   Ankita   Electrodes   on   28.12.2011.   He 
further testified that no other search warrant or authorization  other   than   on   M/s   Ankita  
Electrodes   was   issued   for  28.12.2011.   PW−11   further   testified   that   a   team   was 
constituted in the morning of 28.12.2011, but Lallan Ojha (A−
2), S. K. Singh and K. N. Srivastava were not present at the 
scheduled time i.e. 10:00 a.m. on 28.12.2011.
165. The testimony of PW−9 & PW−11 proved beyond  doubt   that   Lallan   Ojha   (A−2),   S.   K.  
Singh,   Superintendent  (PW−12), Inspector and K. N. Srivastava (PW−29) had been  called  for  the 
purpose of a search to be  conducted at  M/s 
Ankita Electrodes, but instead of joining the said search team, 
all the three absented themselves. The testimony of PW−12 S.  K. Singh, PW−
21 Sunil Kumar and PW29 K. N. Singh shows  that Lallan Ojha (A−
2) misled them by asking these officials to  join   him   instead   of   joining   the   actual   team,  
which   was  required to search the premises of M/s Ankita Electrodes.  
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
166. PW−12   S.   K.   Singh,   the   then   Superintendent,  Central Excise, Anti Evasion, Delhi−
1 testified that Lallan Ojha  (A−2) was posted as Superintendent in December 2011. On 
27.12.2011, Deputy Commissioner, B. Mohan informed him  that   there   is   a   verification/   search
  operation   going   to   be  conducted on 28.12.2011 and he (i.e. PW−12) was required to 
report on duty at 10:00 am in the office on 28.12.2011.  On 
27.12.2011 at about 6:30 pm, Lallan Ojha (A−2) asked him 
on the intercom to join the verification.  PW12 testified that  he   thought   that   A−2   was   talking  
in   connection   with   the  verification to be conducted on 28.12.2011.   Thereafter, he  (i.e.   PW12)  
along   with   A−2   and   Inspector   K.  N.   Srivastava 
accompanied in his vehicle and reached Kirti Nagar at about  7:00   pm.     He   testified   that   while
  he   himself   and   K.   N.  Srivastava remained sitting inside the vehicle, A−2 came out 
of the car and proceeded forward.  After 5 minutes, A−2 came  back   after   making   some  
inquiries.     Thereafter,   they   all  returned  to   their   office.     After   10  minutes,  he   (i.e.  PW12) 
received a call from A−2 on intercom and asked him to remain  present  in  the 
office the next day i.e. 28.12.2011 at about  7:30   am   for   proceeding   for   verification  in   regard  
to   the  same operation for which they were called at 10:00 am. 
PW12 further testified that on 28.12.2011, Lallan Ojha, Sunil 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 Kumar
  Inspector,   K.   N.   Srivastava   Inspector   and   he   (i.e. 
PW12) himself assembled at the gate of the office at about  7:30 am. Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

 He (i.e. PW12) along with Inspector Sunil Kumar 
proceeded in the car of Sunil Kumar, whereas Lallan Ojha and 
K. N. Srivastava reached Kirti Nagar separately at about 7:55  am/8:00   am.     All   of   them  
proceeded   towards   Rama   Road  premises.     PW12  testified that when  they reached the  said 
premises,   there   was   a   small   room   and   a   big   room.     Two  persons were sitting there.   A−
2 asked them as to what was  being carried out from there. Those persons informed that the 
mobile phones were imported from China.   Then an inquiry 
was made as to whether any excise related work is carried 
out by them like value addition, packing, repacking or not. 
They responded that mobiles are imported from China and  sold  in  the  same condition.   
 PW12 testified that he along  with Inspector Sunil Kumar left the premises and proceeded 
to the office.  Deputy Commissioner was informed about the 
visit.  This witness thereafter turned hostile and he was duly 
cross examined by Ld. Public Prosecutor.  He was confronted 
with his own statement under Section 161 CrPC at length. 
He admitted that he had made a statement under Section 164  CrPC on oath, which is Ex.PW12/PB. 
 He admitted in cross  examination that he had not seen any search warrant.   He 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
was confronted with his statement under Section 164 CrPC,  wherein   he   had   stated   that   since  
no   search   warrant   was  shown to any person, therefore, he (i.e. PW12) suspected that 
the search was fake.  He admitted that he had stated before 
Magistrate that they i.e. PW11 himself, Inspector Sunil Kumar 
and Inspector K. N. Srivastava, all observed and thought that 
this search operation was fake because in a genuine search  operation,   search   warrant   or  
authorization   slip   is   always  shown   to   the   party.     PW12   denied   that   on   29.12.2011   at 
about   10:00   pm,   A−2 called   him  over   phone  and  informed 
that a relative of Anand Aggarwal was hospitalized and that 
he would meet him next day i.e. 30.12.2011.   He however  admitted   that   he   had   stated   so  
before   Ld.   Metropolitan  Magistrate.     PW12   admitted   that   he   had   stated   before   Ld. 
Metropolitan Magistrate that Anand Aggarwal had contacted 
him on the phone on 30.12.2011 at 8:45 am and that he told  Anand   Aggarwal   that   he   would  
meet   him   outside   Fortune  Hospital at 9:30 am and he handed over to him a bag and  told   him  
that   there   are   20   lacs   in   the   same,   which   are  required to be handed over to Lallan Ojha.
167. PW12   further   admitted   in   cross   examination   by  Ld.   Senior   Public   Prosecutor   that  
he   had   stated  before   Ld. 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Metropolitan Magistrate that he had called up Lallan Ojha on  30.12.2011   and   informed   him   i.e  
he   (i.e.   PW12)   had  collected packet of Rs.20 lacs from Anand Aggarwal.
168. He was also confronted with his statement under  Section   161   CrPC,   which   he   denied  
altogether   on   being  confronted.Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

169. PW−21   Sunil  Kumar, Superintendent  was also  in  the team of Lallan Ojha (A−
2) and also testified in the same  way as PW−12. 
170. PW−29 K. N. Srivastava was posted as Inspector in  Central Excise (Anti Evasion), Delhi−
1, at the relevant time  and he was also a member of team of Lallan Ojha (A−2). He 
also testified in the same manner as PW−12. 
171. All   these   witnesses,   namely   PW−12,   PW−21   and  PW−29   have   testified that  they  were
 not  shown  any  search  warrants/ authorization letters by Lallan Ojha (A−2). All of 
them have testified that no case of excise was found there.  PW−11   B.   Mohan   has   testified   that  
actually   a   search   was  planned   to   be   conducted   on   M/s   Ankita   Electrodes   on 
28.12.2011 and a team for that purpose was constituted, who 
were directed to remain present at 10:00 a.m. on 28.12.2011. 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
However,   Lallan   Ojha   (A−2),   S.   K.   Singh   and   Insp.   K.   N.  Srivastava   were   not   present  
at   the   scheduled   time   i.e.   at  10:00 a.m. on 28.12.2011. PW−11 has further testified that no 
search   warrant   or   authorization   other   than   on   M/s   Ankita 
Electrodes was issued for 28.12.2011. PW−12, PW−21 and PW− 29,   who   were   joined   in   his  
team   by   Lallan   Ojha   (A−2)   to  conduct the search at the premises of A−5, have testified that 
they had been called by Lallan Ojha (A−2) at 07:30 a.m. itself  on 28.12.2011.
172. The entire chain of evidence clearly proves that a 
search was planned to be conducted at the premises of M/s 
Ankita Electrodes and no search warrant/ authorization was  issued  to   conduct   the   search  at
 the   godown  of  A−5. Lallan  Ojha  (A−2)  and  his team−mates namely, PW−12, PW−21 and  PW−
29 should have joined the search team formed by PW−11,  but   A−2   and   his   team−mates  
intentionally   skipped   the   said  search   team   and   rather   proceeded   to   conduct   their   own 
search at the godown of A−5. 
173. Ld. Defence counsels have drawn my attention to  the   Central   Excise   Manual   and   submit  
that   the  Superintendents and Inspectors are required to gather their  own   intelligence.   Ld.  
Defence   counsel   has   referred   to   the 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
testimony   of   PW−12,   who   has   testified   that   they   had   done  verification   in   the   godown  
of   A−5   and   when   nothing   was  found, the matter was laid to rest.
174. It is true that the Superintendents and Inspectors 
are required to gather their own intelligence, but this process  is   different   from   "verification".  
PW−11   B.   Mohan,   the   then  Deputy Commissioner, Anti Evasion, Central Excise, Delhi−1, 
has testified that an intelligence is developed by Inspectors  and   Superintendents   and   then  
secret   verification   of   the  premises   is   carried   out   by   them.   Thereafter,   the   search 
warrants are issued. He admitted in cross−examination by Ld. 
Senior Public Prosecutor that in case of premises/ godown of  Anand Aggarwal (A−5) at 71/7, A−Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

4, First Floor, Rama Road,  Najafgarh   Road,   Industrial   Area,   New   Delhi,   neither   any 
proposal was put to Commissioner for carrying out the raid/ 
search on 28.12.2011, nor any approval was given by him. In  cross−
examination by Sh. Rakesh Kumar Sharma, Ld. Defence  counsel for A−4 and A−5, PW−
11 made it clear that no officer  of   Anti   Evasion   Branch   can   visit   any   premises   without 
proper   authorization/   search   warrants.   However,   the 
officers are at liberty to gather intelligence and develop  the   same.   He   further   testified   that,  
"gathering   of 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
intelligence has to be discreet and does not involve visit  to   a   premises,   otherwise   the  
intelligence   would   get  leaked".
175. This evidence clearly shows that the visit to the  godown of A−
5 at Rama Road, was not intended to gather any 
intelligence, rather it was a raid without any authorization/ 
search warrants. The guilty intention of A−2 is visible from the  fact   that   he   and   his   team−
mates   were   required   to   join   an  authorized   search   at   M/s   Ankita   Electrodes,   but   they 
intentionally   skipped   their   duties   and   instead   reached   the  godown/   premises   no.   71/7,  
A−4,   First   Floor,   Rama   Road,  Najafgarh Road Industrial Area, New Delhi, belonging to A−5. 
176. I have perused the statements under Section 164  Cr.PC of PW−12, PW−21 and PW−
29, which they made before  Ld. Metropolitan Magistrates. PW−12 in his statement under 
Section 164 Cr.PC has stated that it was a fake raid and on  the   instructions   of   Lallan   Ojha,   he  
received   from   Anand  Aggarwal a sum of Rs.20 lacs, which handed over the same to  Hemant  
Gandhi.   PW−12   resiled   from   this   portion   of   his 
statement under Section 164 Cr.PC and he was clever enough  to   admit   that   he   made   such   a  
statement   before   Ld.  Metropolitan Magistrate but it was done under pressure from 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
CBI. It is clear that this accused is lying blatantly before this 
court and I have no hesitation in holding that actually he was  an accomplice in the crime with A−
2. Since PW−12 has resiled  from his statement under Section 164 Cr.PC (Ex.PW19/A) to 
the extent as mentioned by me above, however, PW−12 has 
supported the prosecution version so far as the raid without  search warrant is concerned. 
177. In   nutshell,   the   evidence   discussed   above   that  there   was   no   authorization   for  
conducting   search   or  verification.   Rather,   Lallan   Ojha   (A−2)   and   his   team−mates 
deliberately skipped the actual raiding team which was to be 
conducted at some other place. The intercepted conversations  reveal   that   this   was   not   simply  
a   vexatious   search,   but  actually it was a rogue raid.
14.  What intercepted calls prove?
178. I would directly come to the intercepted calls of  28.12.2011.   Call   No.   13   is   between   Lallan
  Ojha   (mobile  phone no. 9953248659) and Hemant Gandhi (mobile phone Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

no. 9818517000). Lallan Ojha is telling that  as soon as we 
will tighten, everything is to be concluded within half an 
hour. This conversation is 07:56 a.m. Call No. 14 is again 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
between   these   two   persons   and   the   aforesaid   mobile  numbers,   in   which   Hemant  Gandhi
 is  guiding  Lallan  Ojha,  who   has  reached  near  the   premises of  A−5. Call  No.  15 at 
about 08:25 a.m. between these two persons clearly reveals  that   Hemant   Gandhi   is   informing  
Lallan   Ojha   that   two  shipments  of  40000  pieces each has been received.   I may 
point out that Lallan Ojha in his statement under Section 313  Cr.PC   has   not   denied   having  
reached   alongwith   his   team− mates  at   the   godown  of   A−5.  PW−12  has  also  testified  that 
they assembled at the gate of office at about 07:30 a.m. on  28.12.2011 
and reached Kirti Nagar at about  07:55 a.m. / 
08:00 a.m. He also testified that about about 08:45 a.m., the 
premises in question was opened and they entered the said  premises   where   two   persons   were  
sitting.   On   being  questioned by Lallan Ojha, those two persons informed that 
mobile phones were imported from China and are sold as  it   is.   PW−12,   PW−21   and   PW−29  
are   concealing   as   to   what  actually   transpired   at   the   godown   of   A−5.   However,   the 
intercepted calls reveal the true nature of the raid. Since PW−
12 has testified that they entered the premises at about 08:45 
a.m., I would like to refer to the calls which were made after  08:45 a.m. on 28.12.2011.  
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
179. Call no. 16 between A−2 and A−3 is at 9:3:28 am 
on 28.11.2012 in which Lallan Ojha is telling Hemant Gandhi 
that matter should be resolved within 20−25 minutes.  Now, I 
will directly come to call no.20 at 11:00:27 am between A−2  and   A−3,   Lallan   Ojha   (A−2)   is  
telling   Hemant   Gandhi   that  there are 3 or 4 boys.
180. I may mention here that prosecution has proved 
Call No. 73 dated 30.12.2011, at 19:23:21, which took place  between   Lallan   Ojha   (Mobile   no.  
9811602221)   and   S.   K.  Singh (Mobile no. 9818145883), transcript of which has been 
proved as Ex.PW2/PX−16.
between   Mahender   Kapoor   (01123379010)   and   Hemant  Gandhi (011−
25225641), which took place on 28.12.2011 at  13:33:08. Mahender Kapoor has been cited as PW−
22 and has  turned hostile. He has not even identified his own voice and  voice   of   Hemant  
Gandhi.   However,   the   voice   of   Hemant  Gandhi has been identified by PW−
1 Rajesh Verma, who is the  driver   of   Hemant   Gandhi,   when   the   intercepted   call   was  played
  in   the   court.   The   transcript   of   the   same   has   been  proved as Ex.PW1/X−
25. In this call, Hemant Gandhi is telling  that   matter   was   settled   at   "sixty".   Ld.   Senior  
Public  CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Prosecutor submitted that the amount is Rs.60 lacs. Hemant 
Gandhi further states that deal was done right at the spot.Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

182. The   call   nos.   12   to   20,   which   are   started   from  07:20:25   to   11:00:27   on  
28.12.2011,   clearly   prove   that  Lallan Ojha is proceeding to Hemant Gandhi and is discussing 
about the location  of the premises. The Call No. 20 shows 
that Lallan Ojha had reached the premises and had found 4  or   5   boys,   but   the   owner   was   not
  there.   However,   he   is  informing to Hemant Gandhi that owner has not come and  that   he   had
  stated   that   he   would   come   within   10   to   15 
minutes. Call No. 20 reflects that Lallan Ojha was speaking 
from the premises in question, at 11:00:27.
183. In   Call   No.   24,   at   11:21:34,   Hemant   Gandhi   is 
telling Lallan Ojha to keept it tight and that he will set the 
things. Hemant Gandhi also informed Lallan Ojha that Dilip 
Aggarwal is coming and Anand Aggarwal is the owner. Lallan 
Ojha tells Hemant Gandhi that he (i.e. Anand Aggarwal) was  sitting in front of him. 
184. In   Call   No.   26,   at   11:37:09,   Lallan   Ojha   tells 
Hemant Gandhi that one beat import is about 24 - 25 crores.
185. Call No. 27 is between Hemant Gandhi and Dilip 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Aggarwal.   Dilip   Aggarwal   tells   Hemant   Gandhi  that   Anand 
Aggarwal had already reached at the premises, whereas, he  (i.e.   Dilip   Aggarwal)   will   reach  
within   five   minutes.   Dilip  Aggarwal   also   informs   that   Anand   Aggarwal   had   been 
confined after closing the room. Dilip Aggarwal tells Hemant 
Gandhi to talk to them i.e. Excise officials.
186. In Call No. 30 at 11:53:20, Lallan Ojha is telling 
Hemant Gandhi that "ye kaam jhatke me hota hai. Hum to ye   karte   rahe   hain.   Tum   jhatke   me
  kaam   karo,   der   karne   ki   jarurat nahi" (this work is done in a flash and therefore, do it 
quickly).
187. Call  No. 33 (trancript  Ex.PW1/X−10) is between 
Hemant Gandhi and Dilip Aggarwal, at about 12:05:52. Call 
No. 34 is between Lallan Ojha and Hemant Gandhi. Lallan 
Ojha is telling that "30 (tees)" has been offered, but Lallan  Ojha   did   not   agree   to   it   and  
stated   that   it   will   be   settled  above "one".
188. Ld. Senior Public Prosecutor submitted that Call 
No. 34 shows that Rs.30 lacs were offered to Lallan Ojha but 
Lallan Ojha made a demand for more than "one crore".
189. Call No. 37, transcript of which is Ex.PW1/XD−14, 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
shows that Hemant Gandhi is suggesting to Lallan Ojha to tell  them that even DRI is also involved. Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

190. Call No. 39 (transcript Ex.PW1/X−16) shows that 
Hemant Gandhi is telling Lallan Ojha to give them time to  think and to arrange money.
191. Call No. 44 shows that Hemant Gandhi is telling  that   the   person   sitting   inside   (i.e.  
Hemant   Gandhi)   is   the  main owner and that he will take the decision. Lallan Ojha 
tells Hemant Gandhi that he has been tightened and that he  is   stuck   up   at   "aath   aane".   Ld.  
Senior   Public   Prosecutor  submitted that it means Rs.50 lacs.
192. Call   No.   45   at   13:09:39   is   important,   in   which  Lallan   Ojha   tells   Hemant   Gandhi  
that   matter   is   settled   at  "60". As per prosecution, the amount is Rs.60 lacs. Hemant 
Gandhi tells Lallan Ojha to take this amount today itself and 
finish the issue. Lallan Ojha tells Hemant Gandhi that he will 
give it tomorrow. Hemant Gandhi tells that he will send the  driver or someone else who will bring. 
193. In   Call   No.   46,   Lallan   Ojha   is   telling   Hemant 
Gandhi that he is going home and he will having bath and  thereafter   he   will   come   to   the  
office   and   told   'mission 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
successful".   All   these   conversations   proved   that   the   entire 
proceedings were continued till 01:30 p.m.
194. The Call No. 48 is between Hemant Gandhi and 
Hemant Kapoor. As already discussed, Hemant Gandhi calls 
Hemant Kapoor that the deal has been done directly at the  spot.
196. I   have   already   discussed   that   it   was   an 
unauthorized raid intended to threaten the businessmen and 
extort money from them under the colour of official duties. 
Lallan Ojha is not only the tracing the Anand Aggarwal but  has   also   made   a   demand   for   more
  than   Rs.One   crore,  but  finally settled at Rs.60 lacs.
197. Call   No.   62   is   between   Dilip   Aggarwal   and  Puneet,   in   which   Dilip   Aggarwal   is  
asking   to   Puneet   to  arrange Rs.3 lacs from somewhere. Dilip also tells him that 
20 were delivered in a plastic bag.
198. Call   No.   62   is   conversation   between   Hemant  Gandhi   and   Hemant   Kapoor   on  
30.12.2011   and   here   is   a  reference   of   Lallan   Ojha.   Hemant   Gandhi   tells   Hemant 
Kapoor that they will give the cheque.
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
199. In   call  No. 65 Hemant  Gandhi tells Lallan  Ojha  that he will bring the cheque.Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

200. Call No. 69 is again between Hemant Gandhi and 
Lallan Ojha. Hemant Gandhi is telling Lallan Ojha that he has 
received the cheque. Lallan Ojha asks whether "saaman bhi   aa   gaya   na"   (i.e.   whether   the  
thing   has   reached   or   not).  Hemand Gandhi tells him that "saaman" would come in the 
evening aty 07:30 p.m.
201. Call No. 77, dated 30.12.2011 made at 11:39:23  shows   that   Lallan   Ojha   is   asking   whether
  the   job   is   done.  Hemant Gandhi says that he will come within 15 minutes.
202. Call No. 78 is between Hemant Gandhi and Lallan  Ojha   and   its   transcript   is   Ex.PW1/X−
48.   Lallan   Ojha   is  instructing   Hemant   Gandhi   to   "koi   riyayat   nahi"   (have   no 
concession).   Hemant   Gandhi   tells   that   neither   money   nor  things have been delivered.
203. Call No. 80 dated 31.12.2011 is between Hemant 
Gandhi and Lallan Ojha, in which Lallan Ojha tells Hemant 
Gandhi to bring "two or three out of them" (Unme se do teen   leke aaiyega).
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
204. There   is   a   call   No.   88,   Ex.PW1/A,   which   is   a  conversation between driver (PW−
1) of Hemand Gandhi and  Lallan Ojha. Rajesh, the driver of Hemant Gandhi tells Lallan 
Ojha on phone that he has come from Hemant Gandhi and 
has brought something to deliver to him i.e. to Lallan Ojha, 
"main sir Hemant Gandhi Ji ke yahan se aaya hun. Wo appka  
kucch saaman mere paas hai. We dena tha appko". 
205. Further, calls upto Call No. 96 clearly show that in 
this illegal raid, Lallan Ojha cornered Anand Aggarwal and 
with the help of Hemant Gandhi settled for a sum of Rs.60 
lacs. As a security, Anand Aggarwal had to deliver a cheque of 
Rs.20 lacs to Hemant Gandhi and some amount was delivered 
in cash. A sum of Rs.3 lacs was delivered by Hemant Gandhi 
to Lallan Ojha, through his driver. This amount approximately  Rs.3 lacs was received by Dilip (PW−
2), the driver of Lallan  Ojha   a   the   telephonic   instructions   of   Lallan  Ojha.  The   CBI 
team recovered the aforesaid amount of approximately Rs.3  lacs from the car of Dilip (PW−
2). The entire chain makes out  a clear case that Lallan Ojha organized a rogue raid, cornered 
Anand Aggarwal and compelled him to such an extent that 
Anand Aggarwal agreed to pay an amount of Rs.60 lacs as a 
security to his commitment. Anand Aggarwal has also issued 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
a cheque in the sum of Rs.20 lacs, which was recovered from  the possession of Hemant Gandhi (A−
3). The chain of events  leave me in no doubt that the said bribe amount of Rs.3 lacs 
were delivered to Lallan Ojha.Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

DILIP AGGARWAL (A−4) AND ANAND AGGARWAL (A−5)
206. I have already discussed that Anand Aggarwal (A−
5) had paid the money to Lallan Ojha (A−2) through Hemant  Gandhi (A−3). Dilip Aggarwal (A−
4) assisted Anand Aggarwal  in   this   deal.   But,   it   has   to   be   seen   as   under   what 
circumstances they did so. A−2 alongwith other Central Excise 
officials raided the godown of Anand Aggarwal (A−5) without  any   authorization.   I   have   already
  held   that   it   was   totally  illegal raid. Now, it is to be seen that as to for what purpose,  A−
4 and A−5 agreed to pay the said money. Testimony of PW− 12, PW−21 and PW−
29 show that no illegality on part of A−5  was   found.   Intercepted   calls   also   do   not   reflect  
that   any  illegality on part of A−5 was found. That is why, a threat of 
involvement of DRI (i.e. Directorate of Revenue Intelligence) 
(See Calls No. 33, 36 and 48) is being extended. In Call No.  27,   Dilip   Aggarwal   is   perplexed   as  
to   what   is   the   role   of  Excise officials. Call No. 48 is a conversation between Hemant 
Gandhi and Mahender Kapoor, in which Hemant Gandhi tells 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
Mahender   Kapoor   "inka   banta   bhi   nahi   tha,   magar   60   par  
baat hui hai" (there was no liability, but matter was settled 
for 60). In order to be more careful, I have called for the case 
diaries and perused the same and I find that A−4 and A−5 are 
victims of the fear created by Lallan Ojha (A−2) and his team− mates alongwith Hemant Gandhi (A−
3). The intercepted calls  show   that   such   a   terrible   fear   was   generated   during   this 
illegal raid that without committing any offence, A−4 and A−5 
ended up shelling out enormous money. Thus, there are two  factors,   which   prove   that   A−4   and
  A−5   were   not   only   the  victims but were actually innocent. These two factors are (1) 
the raid itself was illegal, (2) no illegality in the business of  A−4 and A−
5 was found. Thus, they paid money for no offence  on   their   part.   This   is   a   sordid   story  
where   victimized  businessmen   were   triply  suffered.  First,  due  to  illegal  raid; 
second, due to having paid money to public servants without 
doing any illegality in the business and, third, having been  prosecuted.   In   these   circumstances,  
A−4   and   A−5   deserve  honourable acquittal.
Conclusion 
207. In view of above discussion, I convict Lallan Ojha  (A−
2) under Section 120B IPC read with Section 7, 12, 13(2) 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
read with Section 13(1)(d) of the Prevention of Corruption  Act, 1988, for having conspired with A−
3 and others.
208. I further convict Lallan Ojha (A−2) under Section  7   and   Section   13   (2)   read   with  
Section   13(1)(d)   of   the  Prevention of Corruption Act, 1988.Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

209. Accused   Dilip   Aggarwal   (A−4)   and   Anand  Aggarwal (A−5) are hereby acquitted.  
210.  Bail−bonds   and   surety   bonds   of   all   the   accused  persons are discharged.
Announced in the open court on this 26th day of August, 2016            (Vinod Kumar)
                  Special Judge−03 (PC Act)/              CBI/ PHC / ND
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
IN THE COURT OF SPECIAL JUDGE−03 (P. C. ACT) (CBI),
PATIALA HOUSE COURTS, NEW DELHI RC No. AC−1/2012/A0001/CBI/AC−1/ND
Central Bureau of Investigation Versus Lallan Ojha S/o Late Sh. Babu Nandan Ojha
R/o 21, Savita Vihar,  Near Anand Vihar, New Delhi−92 ORDER ON SENTENCE 26.08.2016
Present: Sh. V. K. Ojha, Ld. Public Prosecutor for CBI.
Convict Lallan Ojha on bail with Sh. V. K. Ohri,   Advocate.
  Arguments on sentence heard.  
It is argued by Sh. V. K. Ohri, Advocate for convict that  the  convict   had  acted under the
 command of his boss and  that now the boss has been discharged. Therefore, a lenient  view   may  
be   taken   against   the   subordinate.   It   is   further  argued   that   convict   has   already   retired  
and   has   suffered   a  long drawn trial. Further, the new amendment prescribing the 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016 four  
years   of   sentence   under   Section   13(1)(d)   of   the 
Prevention of Corruption Act, 1988 is not applicable to the 
present case. Therefore, the convict should be given less than  three   years   of   sentence,   keeping  
in   view   the   fact   that   the  main   offender   i.e.   the   superior   officer   i.e.   A−1   has   already 
been discharged. 
On   the   other   hand,   Ld.   Public   Prosecutor   has  prayed for maximum sentence.
I have considered the facts and circumstances of 
the case. Keeping in view the grim nature of the offence, I  sentence   the   convict   to  rigorous  
imprisonment   for   five  years and a fine in the sum of Rs.10,000/−, under Section 
120B IPC read with Section 7, 12, 13(2) read with Section  13(1)(d)   of   the   Prevention   of  
Corruption   Act,   1988,   in  default of payment of fine, he shall further undergo simple 
imprisonment for six months. 
I   further   sentence   the   convict   to  rigorous  imprisonment   for   five   years   and   a   fine   in  
the   sum   of  Rs.10,000/−, under Section 7 of the Prevention of Corruption  Act,   1988,   in   default
  of   payment   of   fine,   he   shall   further 
CBI Vs. Anup Kumar Srivastava etc.                       Judgement                         Dated : 26.08.2016
undergo simple imprisonment for six months. Cbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

I   further   sentence   the   convict   to  rigorous  imprisonment   for   five   years   and   a   fine   in  
the   sum   of  Rs.10,000/−, under Section 13(2) read with Section 13(1)(d)  of   the   Prevention   of  
Corruption   Act,   1988,   in   default   of  payment   of   fine,   he   shall   further   undergo   simple 
imprisonment for six months. 
All the sentences shall run concurrently.   Copy of judgement be supplied free of cost to the  convict.
File be consigned to Record Room.
Announced in the open court on this 26th day of August, 2016        (Vinod Kumar)
                Special Judge−03 (PC Act)/       CBI/ PHC / NDCbi vs . Anup Kumar Srivastava Etc. Judgement ... on 26 August, 2016

