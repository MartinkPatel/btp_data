Express Newspapers (Private) Ltd. And ... vs The Union Of India
(Uoi) And Ors. on 19 March, 1958
Equivalent citations: AIR1958SC578, (1961)ILLJ339SC, (1964)ILLJ9SC,
[1959]1SCR12, AIR 1958 SUPREME COURT 578, 1961 (1) LABLJ 339, 1958-59
14 FJR 211, 1958 SCJ 1113, 1959 SCR 12
Bench: B.P. Sinha, J.L. Kapur
JUDGMENT
Bhagwati, J.
1. These petitions under Art. 32 of the Constitution raise the question as to the vires of the Working
Journalists (Conditions of Service) and Miscellaneous Provisions Act, 1955 (45 of 1955), hereinafter
referred to as "the Act" and the decision of the Wage Board constituted thereunder. As they raise
common questions of law and fact they can be dealt with under one common judgment.
2. In order to appreciate the rival contentions of the parties it will be helpful to trace the history of
the events which led to the enactment of the impugned Act.
3. The newspaper industry in India did not originally start as an industry, but started as individual
newspapers founded by leaders in the national, political, social and economic fields. During the last
half a century, however, it developed characteristics of a profit making industry in which big
industrialists invested money and combines controlling several newspapers all over the country also
became the special feature of this development. The working journalists except for the
comparatively large number that were found concentrated in the big metropolitan cities, were
scattered all over the country and for the last ten years and more agitated that some means should
be found by which those working in the newspaper industry were enabled to have their wages and
salaries, their dearness allowance and other allowances, their retirement benefits, their rules of
leave and conditions of service, enquired into by some impartial agency or authority, who would be
empowered to fix just and reasonable terms and conditions of service for working journalists as a
whole.
4. Isolated attempts were made by the Uttar Pradesh and Madhya Pradesh Governments in this
behalf. On June 18, 1947, the Government of Uttar Pradesh appointed a committee to enquire into
the conditions of work of the employees of the newspaper industry in the Uttar Pradesh.
5. On March 27, 1948, the Government of Central Provinces & Berar also appointed an Inquiry
Committee to examine and report on certain questions relating to the general working of theExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

newspaper industry in the province, including the general conditions of work affecting the editorial
and other staff of newspapers, their emoluments including dearness allowance, leave, provident
fund, pensionary benefits, etc.
6. The Committees aforesaid made their reports on the respective dated March 31, 1949, and March
27, 1948, making certain recommendations. The All-India problem, however, remained to be
tackled and during the debate in Parliament on the Constitution (First Amendment) Bill, 1951, the
Prime Minister said that he was prepared to appoint a committee or a commission, including
representatives of the Press, to examine the state of the Press and its content. He elaborated the idea
further on June 1, 1951, when he indicated that an enquiry covering the larger issue of the Press,
such as had been carried out in the United Kingdom by the royal Commission, might be productive
of good for the Press and the development of this very important aspect of public affairs. The idea
was further discussed during the debate in Parliament on the Press (Incitement to Crimes) Bill, later
named the Press (Objectionable Matter) Act, 1952. At its session held in April, 1952, at Calcutta, the
Indian Federation of Working Journalists adopted a resolution for the appointment of a
Commission to enquire into the conditions of the Press in India with a view to improving its place,
status and functioning in the new democratic set up. The appointment of the Press commission was
thereafter announced in a Communique issued by the Govt. of India, Ministry of Information and
Broadcasting, on September 23, 1952, under the Chairmanship of Shri Justice G. S. Rajadhyaksha.
7. The terms of reference inter alia were :-
"2. The Press Commission shall enquire into the state of the Press in India, its
present and future lines of development and shall in particular examine :-
.....................................
(iv) the method of recruitment, training, scales of remuneration, benefits and other
conditions of employment of working journalists settlement of disputes affecting
them and factors which influence the establishment and maintenance of high
professional standards....."
8. The Commission completed its enquiry and submitted its report on July 14, 1954. Amongst other
things it found that out of 137 concerns about whom information was available only 59 were
returning profits and 68 showed losses. The industry taken as a whole had returned a profit of about
6 lakhs of rupees on a capital investment of about 7 crores, or less than 1 per cent. per annum. It
found that proof-readers as a class could not be regarded as working journalists, for there were
proof-readers even in presses doing job work. It came to the conclusion that if a person had been
employed as a proof-reader only for the purpose of making him a more efficient sub-editor, then it
was obvious that even while he was a proof-reader, he should be regarded as a working journalist
but in all other instances, he would not be counted as a journalist but as a member of the press staff
coming within the purview of the Factories Act.Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

9. The question of the emoluments payable to working journalists, was discussed by it in paragraphs
538 and 539 of its report :
538 :- "SCALES TO BE SETTLED BY COLLECTIVE BARGAINING OR
ADJUDICATION :- It has not been possible for us to examine in detail the adequacy
of the scales of pay and the emoluments received by the working journalist having
regard to the cost of living in the various centers where these papers are published
and to the capacity of the paper to make adequate payment.... In this connection it
may be stated that the Federation of Working Journalists also agreed, when it was
put to them, that apart from suggesting a minimum wage it would not be possible for
the Commission to undertake standardisation of designations or to fix scales of pay
or other conditions of service for the different categories of employees for different
papers in different regions. They have stated that these details must be left to be
settled by collective bargaining or where an agreement is not possible the dispute
could be settled by reference to an industrial court or an adjudicator with the
assistance of a Wage Board, if necessary. The All India Newspaper Editors'
Conference and Indian Language Newspapers' Association have also stated that it
would not be possible to standardise designations and that any uniformity of salaries
as between one newspaper and another would be impossible. The resources of
different newspapers vary and the conditions of service are not the same. We agree in
principle that there should be uniformity as far as possible, in the conditions of
service in respect of working journalists serving in the same area or locality. But this
can be achieved only by a settlement or an adjudication to which the employers and
the employees collectively are parties."
539 :- DEARNESS ALLOWANCE :- ".... This again, is a matter which would require
very detailed study of the rise in the index numbers of the cost of living for various
places where the newspapers are published. We do not know of any case where a
uniform rate has been prescribed for dearness allowance applicable all over the
country irrespective of the economic conditions at different centers and the paying
capacity of the various units. This must be a matter for mutual adjustment between
the employers and the employees and if there is no agreement, some machinery must
be provided by which disputes between the parties could be resolved."
10. The position of a journalist was thus characterised by the Commission :
"A journalist occupies a responsible position in life and has powers which he can
wield for good or evil. It is he who reflects and moulds public opinion. He has to
possess a certain amount of intellectual equipment and should have attained a
certain educational standard without which it would be impossible for him to
perform his duties efficiently. His wage and his conditions of service should therefore
be such as to attract talent. He has to keep himself abreast of the development in
different fields of human activity-even in such technical subjects as law, and
medicine. This must involve constant study, contact with personalities and a generalExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

acquaintance with world's problems."
11. It considered therefore that there should be a certain minimum wage paid to a journalist. The
possible impact of such a minimum wage was also considered by it and it was considered not
unlikely that the fixation of such a minimum wage may make it impossible for small papers to
continue to exist as such but it thought that if a newspaper could not afford to pay the minimum
wage to the employee which would enable him to live decently and with dignity, that newspaper had
no business to exist. It recommended division of localities for taking into account the differential
cost of living in different parts of India, and determining what should be the reasonable minimum
wage in respect of each area. It endorsed the concept of a minimum wage which has been adopted
by the Bank Award :-
"Though the living wage is the target, it has to be tempered, even in advanced
countries, by other considerations, particularly the general level of wages in other
industries and the capacity of the industry to pay.... In India, however, the level of the
national income is so law at present that it is generally accepted that the country
cannot afford to prescribe a minimum wage corresponding to the concept of a living
wage. However, a minimum wage even here must provide not merely for the bare
subsistence of living, but for the efficiency of the worker. For this purpose, it must
also provide for some measure of education, medical requirements and amenities."
12. and suggested that the basic minimum wage all over India for a working journalist should be Rs.
125 with Rs. 25 as dearness allowance making a total of Rs. 150. It also suggested certain dearness
allowance and City allowance in accordance with the location of the areas in which the working
journalists were employed. I compared the minimum wage recommended by it with the
recommendations of the Uttar Pradesh and Madhya Pradesh Committees and stated that its
recommendations were fairly in line with the recommendations of those Committees particularly
having regard to the rise in the cost of living which had taken place since those reports were made.
13. It then considered the applicability of the Industrial Disputes Act to the working journalists and
after referring to the award of the Industrial Tribunal at Bombay in connection with the dispute
between "Jam-e-Jamshed" and their workmen and the decision of the Patna High Court in the case
of V. N. N. Sinha v. Bihar Journals Limited ([1953] I.L.R. 32 Pat. 688), it came to the conclusion that
the working journalists did not come within the definition of workman as it stood at that time in the
Industrial Disputes Act nor could a question with regard to them be raised by others who were
admittedly governed by the Act. It thereafter considered the questions as to the tenure of
appointment and the minimum period of notice for termination of the employment of the working
journalists, hours of work. provision for leave, retirement benefits and gratuity, made certain
recommendations and suggested legislation for the regulation of the newspaper industry which
should embody its recommendations with regard to (i) notice period; (ii) bonus; (iii) minimum
wages; (iv) Sunday rest; (v) leave, and (vi) provident fund and gratuity.
14. Almost immediately after the Report of the Press Commission, Parliament passed the Working
Journalists (Industrial Disputes) Act, 1955 (I of 1955) which received the assent of the President onExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

March 12, 1955. It was an Act to apply the Industrial Disputes Act, 1947, to working journalists.
"Working Journalist" was defined in s. 2(b) of the Act to mean "a person whose principal avocation
is that of a journalist and who is employed as such in, or in relation to, any establishment for the
production or publication of a newspaper or in, or in relation to, any news agency or syndicate
supplying material for publication in any newspaper, and includes an editor, a leader-writer,
news-editor, sub-editor, feature writer, copy-taster, reporter, correspondent, cartoonist,
news-photographer and proof reader but does not include any such person who :
(i) is employed mainly in a managerial or administrative capacity, or
(ii) being employed in a supervisory capacity, exercises, either by the nature of the
duties attached to the office or by reason of the powers vested in him, functions
mainly of a managerial nature. Section 3 of that Act provided that the provisions of
the Industrial Disputes Act, 1947, shall apply to, or in relation to, working journalists
as they apply to or in relation to workmen within the meaning of that Act.
15. The application of the Industrial Disputes Act, 1947, to the working journalists was not, however,
deemed sufficient to meet the requirements of the situation. There was considerable agitation in
Parliament for the implementation of the recommendations of the Press Commission, and On
November 30, 1955, the Union Government introduced a Bill in the Rajya Sabha, being Bill No. 13 of
1955. It was a Bill to regulate conditions of service of working journalists and other persons
employed in newspaper establishments. The recommendations of the Press Commission in regard
to minimum period of notice, bonus, Sunday rest, leave, and provident fund and gratuity, etc., were
all incorporated in the Bill; the fixation of the minimum rates of wages however was left to a
minimum wage Board to be constituted for the purpose by the Central Government. The provisions
of the Industrial Employment (Standing Orders) Act, 1946 (20 of 1946) and the Employees'
Provident Funds Act, 1952 (19 of 1952) were also sought to be applied in respect of establishments
exceeding certain minimum size as recommended by the Commission.
16. It appears that during the course of discussion in the Rajya Sabha, the word "minimum" was
dropped from the Bill wherever it occurred, the Minister for Labour having been responsible for the
suggested amendment. The reason for dropping the same was stated by him as under :
"Let the word "minimum" be dropped and let it be a proper wage board which will
look into this question in all its aspects. Now, if that is done, I believe, from my own
experience of the industrial disputes with regard to wages, in a way it will solve the
question of wages to the working journalists for all time to come."
17. The Act as finally passed was entitled "The Working Journalists (Conditions of Service) and
Miscellaneous Provisions Act, 1955 (45 of 1955) and received the assent of the President on
December 20, 1955.
18. The relevant provisions of the Act may now be referred to. It was an Act to regulate certain
conditions of service of working journalists and other persons employed in newspaperExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

establishments. "Newspaper establishment" was defined in s. 2(d) to mean "an establishment under
the control of any person or body of persons, whether incorporated or not, for the production or
publication of one or more newspapers or for conducting any news agency or syndicate". The
definition of "working journalist" was almost in the same terms as that in the Working Journalists
(Industrial Disputes) Act, 1955, and included a proof reader. All words and expressions used but not
defined in this Act and defined in the Industrial Disputes Act, 1947, were under s. 2(g) to have the
meanings respectively assigned to them in that Act. Section 3 applied the provisions of the
Industrial Disputes Act, 1947, as it was in force for the time being, to working journalists as they
applied to, or in relation to workmen within the meaning of that Act subject to the modification that
s. 25(F) of that Act in its application to working journalists in regard to the period of notice in
relation to the retrenchment of a workman was to be construed as substituting six months in the
case of the retrenchment of an editor and three months, in the case of any other working journalist.
The period which lapsed between the publication of the report and the enactment of the Working
Journalists (Industrial Disputes) Act, 1955, viz., from July 14, 1954, to March 12, 1955, was sought to
be bridged over by s. 4 enacting special provisions in respect of certain cases of retrenchment during
that period. Section 5 provided for the payment of gratuity, inter alia, to a working journalist who
had been in continuous service, whether before or after the commencement of the Act, for not less
than three years in any newspaper establishment even when he voluntarily resigned from service of
that newspaper establishment. Section 6 laid down that no working journalist shall be required or
allowed to work in any newspaper establishment for more than one hundred and forty-four hours
during any period of four consecutive weeks, exclusive of the time for meals. Every working
journalist was under s. 7 entitled to earned leave and leave on medical certificate on the terms
therein specified without prejudice to such holidays, casual leave or other kinds of leave as might be
prescribed. After thus providing for retrenchment compensation, payment of gratuity, hours of
work, and leave, ss. 8 to 11 of the Act provided for fixation of the rates of wages in respect of working
journalists. Section 8 authorised the Central Government by notification in the Official Gazette to
constitute a Wage Board for fixing rates of wages in respect of the working journalists in accordance
with the provisions of the Act, which Board was to consist of an equal number of persons nominated
by the Central Government to represent employers in relation to the newspaper establishments and
working journalists, and an independent person appointed by the Central Government as the
Chairman thereof. Section 9 laid down the circumstances which the Wage Board was to have regard
to in fixing rates of wages and these circumstances were the cost of living, the prevalent rates of
wages for comparable employments, the circumstances relating to the newspaper industry in
different regions of the country and to any other circumstance which to the Board may seem
relevant. The decision of the Board fixing rates of wages was to be communicated as soon as
practicable to the Central Government and this decision was under s. 10 to be published by the
Central Government in such manner as it thought fit within a period of one month from the date of
its receipt by the Central Government and the decision so published was to come into operation with
effect from such date as may be specified, and where no date was so specified on the date of its
publication. Section 11 prescribed the powers and procedure of the Board and stated that subject to
any rules of procedure which might be prescribed the Board may, for the purpose of fixing rates of
wages, exercise the same powers and follow the same procedure as an Industrial Tribunal
constituted under the Industrial disputes Act, 1947, exercised or followed for the purpose of
adjudicating an industrial dispute referred to it. The decision of the Board under s. 12 was declaredExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

to be binding on all employers in relation to newspaper establishments and every working journalist
was entitled to be paid wages at a rate which was to be in no case less than the rate of wages fixed by
the Board. Sections 14 and 15 applied the provisions of the Industrial Employment (Standing
Orders) Act, 1946, as it was in force for the time being and also the provisions of the Employees'
Provident Funds Act, 1952, as it was in force for the time being, to every newspaper establishment in
which twenty or more persons were employed. Section 17 provided for the recovery of money due
from an employer and enacted that where any money was due to a newspaper employee from an
employer under any of the provisions of the Act, whether by way of compensation, gratuity or wages,
the newspaper employee might, without prejudice to any other mode of recovery, make an
application to the State Government for the recovery of the money due to him, and if the State
Government or such authority as the State Government might specify in this behalf was satisfied
that any money was so due, it shall issue a certificate for that amount to the collector and the
collector shall proceed to recover that amount in the same manner as an arrear of land revenue.
Section 20 empowered the Central Government by notification in the Official Gazette to make rules
to carry out the purposes of the Act and in particular and without prejudice to the generality of the
foregoing power, such rules were to provide inter alia for the procedure to be followed by the Board
in fixing rates of wages. All rules made under this section, as soon as practicable after they were
made were to be laid before both Houses of Parliament. The Working Journalists (Industrial
Disputes) Act, 1955, was repealed by s. 21 of the Act.
19. In pursuance of the power given under s. 20 of the Act the Central Government published by a
notification in the Gazette of India - Part II - Section 3, dated July 30, 1956, "The Working
Journalists Wage Board Rules, 1956". Rule 8 provided that every question considered at a meeting
of the Board was to be decided by a majority of the votes of the members present and voting. In the
event of equality of votes the Chairman was to have a casting vote. Rule 13 provided for the
resignation of the Chairman or any member from his office or membership, as the case may be. The
seat held by them was to be deemed to have fallen vacant with effect from the date the resignation of
the Chairman or the member was accepted by the Central Government. When a vacancy thus arose
in the office of the Chairman or in the membership of the Board, the Central Government was to
take immediate steps to fill the vacancy in accordance with the Act and the proceedings might be
continued before the Board so reconstituted from the stage at which the vacancy was so filled.
20. By a notification dated May 2, 1956, the Central Government constituted a Wage Board under s.
8 of the Act for fixing rates of wages in respect of working journalists in accordance with the
provisions of the Act, consisting of equal representatives of employers in relation to newspaper
establishments and working journalists and appointed Shri H. V. Divatia, Retired Judge of the High
Court of Judicature, Bombay, as the Chairman of the Board. The three members of the Board who
were nominated to represent employers in relation to newspaper establishments were (1) Shri G.
Narasimhan, Manager, The Hindu, Madras and President, Indian and Eastern Newspaper Society;
(2) Shri A. R. Bhat, M.L.C., who had been a member of the Press Commission and was the President
of the Indian Language Newspapers Association, as also the Chairman of the Minimum Wages
Inquiry Committee for the Printing Industry in Bombay and, (3) Shri K. P. Kesava Menon, Editor,
Mathrubhumi, Calicut. The other three members of the Board who were nominated to represent
working journalists were : (1) Shri G. Venkataraman, M.P., (2) Shri C. Raghavan, Secretary-General,Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

Indian Federation of Working Journalists, and (3) Shri G. N. Acharya, Assistant Editor, Bombay
Chronicle.
21. Shri H. V. Divatia, the Chairman of the Board, had wide and considerable experience as
chairman of the Textile Labour Enquiry Committee, Bombay, had been the President of the First
Industrial Court to be set up in India in 1938, and had worked as an Industrial Tribunal dealing with
several disputes as between several banks and employees, as well as between several insurance
companies and their employees.
22. The first meeting of the Board was held on May 26, 1956, in the Bharatiya Vidya Bhavan at
Bombay. Sri Kesava Menon and Shri G. Narasimhan were not present at this meeting. It was a
preliminary meeting at which the Board set up a sub-committee consisting of Shri A. R. Bhat and
Shri G. N. Acharya to draft a questionnaire for issue to the various journals and organisations
concerned, with a view to eliciting factual data and other relevant information required for the
fixation of wages for the working journalists. The sub-committee was requested to bear in mind,
while framing the questionnaire the need for : (1) obtaining detailed accounts of newspaper
establishments; (2) proper evaluation of the nature of and the work of various categories of working
journalists; and (3) proper classification of the country into different areas on the basis of certain
criteria like population, cost of living, etc. The questionnaire drafted by the sub-committee was to be
finalised by the chairman and circulated to all concerned by the end of June, 1956.
23. The questionnaire was accordingly drawn up and was sent to Universities and Governments,
etc., and several other organisations and individuals interested in the inquiry of the Board, and to all
newspapers individually. It was divided into three parts. Part "A" was intended to be answered by
newspapers, news agencies, organisations of employers and of working journalists and any
individuals who might wish to do so. Part "B" was meant to be answered by all newspapers and Part
"C" by all news agencies.
24. At the outset the Board pointed out that except where the question itself indicated a different
period or point of time, the reporting period for purposes of parts "B" and "C" of the questionnaire
was the financial years (April 1 to March 31) 1952-53, 1953-54, and 1954-55, or in any
establishments which followed a different accounting year, a period of three years as near thereto as
possible. It further pointed out that under s. 11 of the Act the Board had the powers of an Industrial
Tribunal constituted under the Industrial Disputes Act. In Part "A" of the questionnaire under the
heading "Cost of Living", cost of living index for the respective centers were called for and a special
question was addressed whether the basic minimum wage, dearness allowance and metropolitan
allowance in the table attached to paragraph 546 of the Press commission was acceptable to the
party questioned and, if not, what variations would the party suggest and why. Comparable
employment suggested included (a) Higher secondary school teachers; (b) College and university
teachers; (c) Journalists employed as publicity and public relations officers in the information
departments of the Central and State Governments; (d) Journalistic employees of the news service
division of All India Radio and (e) Research personnel of the economic and social research
departments of Central Government ministries like finance, labour and commerce. Under the
heading "Special Circumstances", the only question addressed was question No. 7 : "Are there inExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

your region any special conditions in respect of the newspaper industry which affect the fixing of
rates of wages of working journalists ? If so, specify the conditions and indicate how they affect the
question of wages." As regards the principles of wage fixation the party questioned was to categories
the different newspaper establishments and in doing so consider the following factors, among others
: (a) Invested capital; (b) Gross revenue; (c) Advertisement revenue; (d) circulation; (e) Periodicity
of publication; (f) The existence of chains, multiple units and combines; and (g) Location.
25. In part "B" which was to be answered by newspapers were included under the heading
"Accounts" :-
(1) Balance sheets and (2) Trading and profit and loss accounts of the newspapers as
in the specimen forms attached thereto for the reporting period. Questions were also
addressed in regard to the revenue of the newspapers inter alia from the press, a
process studio, outside work, foundry, etc., and subscriptions as also the expenditure
incurred on postage, distribution/sale, commission and rebate to advertisers, etc. and
other items.
26. All information which was considered necessary by the Wage Board for purposes of fixation of
the rates of wages was thus sought to be elicited by the questionnaire.
27. It appears that Shri K. P. Kesava Menon sent in his resignation on or about June 21, 1956, and by
a notification dated July 14, 1956, the Central Government accepted the said resignation and
appointed in his place Shri K. M. Cherian, member of the executive committee of the Indian and
Eastern Newspapers Association, one of the directors of the Press Trust of India and the Chief
Editor, Malayala Manorama, Kottayam, as a member of the Board.
28. Out of 5,465 newspapers, journals, etc., to whom the questionnaire was sent only 381 answered
the same; and out of 502 dailies only 138 answered it. The Board had an analysis made of those who
had replied to the questionnaire and also of their replies thereto in regard to each of the questions
contained in the questionnaire. It also got statements prepared according to the gross revenue of the
newspapers, the population of the centers, circulation of the papers, the cost of living index, scales of
dearness allowance in certain States, figures of comparable employments, pay scales of important
categories of journalists, etc., the total income, break up of expenditure in relation to total income
and total expenses, total income in relation to net profits, and net losses and net profits in relation
to circulation of the several newspapers which had sent in the replies to the questionnaire.
29. Further meetings of the Board were held on August 17, and August 20, 1956, in Bombay. The
Chairman informed the members that response from journals, organisations, etc., to whom
questionnaire was sent was unsatisfactory and it was decided to issue a Press Note requesting the
papers and journals to send their replies, particularly to Part "B" of the questionnaire as soon as
possible inviting their attention to the fact that the Board had powers of an Industrial Tribunal
under the Act, and if newspapers failed to send their replies, the Board would be compelled to take
further steps in the matter. It was decided that for purposes of taking oral evidence, the country be
divided into 5 zones, namely, Trivandrum, Madras, Delhi, Calcutta and Bombay and the SecretaryExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

was asked to summon witnesses to the nearest and convenient center. It was further decided that
one hour should normally be allotted to each newspaper, 3 hours for regional units and 2 hours for
smaller units for oral evidence. The Board also discussed the question as to the number of persons
who might ordinarily be called for oral evidence from each newspaper or organisation. It thought
that one of the important factors governing the findings of the Board would be the circulation of
each newspaper, and as such it was decided that the figures with the Audit Bureau of Circulation
Ltd., might be obtained at once. The Board also decided to ask witnesses, if necessary, to produce
books of accounts, income-tax assessment orders or any other document which in its opinion was
essential.
30. Meetings of the Board were held at Trivandrum from September 7, to September 10, 1956, in
Madras from September 15, to September 20, 1956, in New Delhi from October 19, to October 26,
1956, in Calcutta from November 25, to December 4, 1956, and in Bombay from January 4, to
January 10, 1957, from January 20, to February 6, 1957, from March 25 to March 31, 1957 and
finally from April 22 to April 24, 1957.
31. Evidence of several journalists and persons connected with the newspaper industry was recorded
at the respective places and at its meeting in Bombay from March 25, to March 31, 1957, the Board
entered upon its final deliberations. At this meeting the chairman impressed upon the members the
desirability of arriving at unanimous decisions with regard to the fixation of wages, etc. He further
stated that he would be extremely happy if representatives of newspaper industry and of working
journalists could come to mutual agreement by direct discussions and he assured his utmost
co-operation and help in arriving at decisions on points on which they could not agree. Members
welcomed this suggestion and decided to discuss various issues among themselves in the afternoon
and on the following days.
32. After considerable discussion on March 25, 1957, and March 26, 1957, in which the
representatives of the newspapers and of working journalists had joint sittings, unanimous
decisions were arrived at on (i) classification of newspapers, (ii) classification of centers and (iii)
classification of employees, except on one point, namely, classification of group, multiple units and
chains on the basis of their total gross revenue. This was agreed to by a majority decision. The
chairman and the representatives of the working journalists voted in favour while the
representatives of the employers voted against. Regarding scales of pay, the chairman suggested at
the meeting of March 27, 1957, that pending final settlement of the issue the parties should submit
figures of scales based on both assumptions, namely, consolidated wages and basic scales with
separate dearness allowance. Both sides agreed to submit concrete suggestions on the following day.
At the Board's meeting on March 28, 1957, the representatives of the employers stated that the term
"rates of pay" did not include scales of pay; therefore, the Board was not competent to fix scales of
working journalists and they submitted a written statement signed by all of them to the chairman in
support of their contention. The representatives of the working journalists argued that the Board
was competent to fix scales of pay. The chairman adjourned the sitting of the Board to study this
issue. A copy of the written statement submitted by the representatives of the employers was given
to the representatives of the working journalists and they submitted a written reply the same
afternoon contending that the Board was competent to fix scales of pay of various categories ofExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

working journalists. At its meeting on March 29, 1957, the Board discussed its own competency to
fix scales of pay. The chairman expressed his opinion in writing, whereby he held that the Board was
competent to fix scales of pay. On a vote being taken according to r. 8 of the Working Journalists
Wage Board Rules, 1956, the chairman and the representatives of the working journalists voted in
favour of the competence of the Board to fix scales of pay, while the representatives of the employers
voted against it. Thereafter, several suggestions were made on this question, but since there was no
possibility of any agreement on this issue, the chairman suggested that members should submit
their specific scales to him for his study to which the members agreed. It was also decided that the
chairman would have separate discussions wish representatives of working journalists in the
morning and with representatives of employers in the afternoon of March 30, 1957. It was also
decided that the Board should meet again on March 31, 1957, for further discussions. No final
decision was however arrived at in the meeting of the Board held on March 31, 1957, on scales of
pay, allowances, date of operation of the decision, etc. It was decided that the Board should meet
again on April 22, 1957, to take final decisions.
33. A meeting of the Board was accordingly held from April 22 to 24, 1957, in the office of the Wage
Board at Bombay. It was unanimously agreed that the word "decision" should be used wherever the
word "report" occurred. The question of the nature of the decisions which should be submitted to
the Government was then considered. It was agreed that reasons need not be given for each of the
decisions, and that it would be sufficient only to record the decisions. The members then requested
the chairman to study the proposals regarding scales of pay, etc., submitted by both the parties and
to give his own proposals so that they may take a final decision. Accordingly, the chairman
circulated to all the members his proposals regarding pay scales, dearness allowance, location
allowance and retainer allowance.
34. The following were the decisions arrived at by the Board on the various points under
consideration and they were unanimous except where otherwise stated. The same may be set out
here so far as they are relevant for the purposes of the inquiry before us.
1. For the purpose of fixation of wages of working journalists, newspaper establishments should be
grouped under different classes.
2. Except in the case of weeklies and other periodicals expressly provided for hereinafter, newspaper
establishments should be classified on the basis of their gross revenue.
3. For purposes of classification, revenue from all sources of a newspaper establishment, should be
taken for ascertaining gross revenue.
4. Classification of Newspaper Establishments :
Dailies - Newspaper Establishments should be classified under the following five
classes :-
  Class           Gross Revenue
"A"              over Rs. 25 lakhsExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

"B"              over Rs. 12 1/2 to 25 lakhs
"C"              over Rs. 5 to 12 1/2 lakhs
"D"              over Rs. 2 1/2 to 5 lakhs
"E"              Rs. 2 1/2 lakhs and below
5. Classification of newspaper establishments should be based on the average gross
revenue of the three-year period, 1952, 1953 and 1954.
6. It shall be open to the parties to seek re-classification of the newspaper
establishments on the basis of the average of every three years commencing from the
year 1955.
11. Groups, multiple units and chains should be classified on the basis of the total
gross revenue of all the constituent units. (This was a majority decision, the chairman
and the representatives of the working journalists voting for and the representatives
of the employers voting against).
12. A newspaper establishment will be classified as :-
(i) A group, if it publishes more than one newspaper from one center;
(ii) A multiple unit, if it publishes the same newspaper from more than one center;
(iii) A chain, if it publishes more than one newspaper from more than one center.
20. Working journalists employed in newspaper establishments should be grouped as follows :
(a) Full time employees :
Group I : Editor Group II : Assistant Editor, Leader Writer, News Editor, Commercial
Editor, Sports Editor, Film or Art Editor, Feature Editor, Literary Editor, Special
Correspondent, Chief Reporter, Chief Sub-Editor and Cartoonist.
Group III : Sub-Editors and Reporters of all kind and full time correspondents not
included in Group (II); news photographers and other journalists not covered in the
groups.
Group IV : Proof Readers.
(b) Part time employees :
Correspondents who are part time employees of a newspaper establishment and
whose principal avocation is that of journalism.Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

An employee should be deemed to be a full time employee if under the conditions of
service such employee is not allowed to work for any other newspaper
establishments.
23. The wage scales and grades recommended by the chairman were agreed to by a
majority decision. The chairman and the representatives of the working journalists
voted for and the representatives of the employers voted against. Shri Bhat suggested
that wage scales should be conditional on a newspaper establishment making profits
in any particular year and also that time should be given to the newspaper
establishments for bringing the scales into operation. These suggestions, however,
were not acceptable to the majority.
35. Wages, scales and grades : (as agreed to by the majority) were as under : Working
journalists of different groups employed in different classes of newspaper
establishments should be paid the following basic wages per mensem.
1. Dailies.
Class of       Group of Employees    Starting              Scale
Newspapers                              Pay
  E                IV                 90                  No Scale
                   III
                     II                 150                  No Scale
                     I
    D                IV                 100   100-5-165 (13 Yrs.)
                                                 EB-7-200 - (5 Yrs.)
                     III                115   115-7 1/2-205 - (12 Yrs.)
                                                  EB-15-295 (6 Yrs.)
                     II                 200   200-20-400 (10 Yrs.)
                     I
    C                IV                 100   100-5-165 (13 Yrs.)
                                                  EB-7-200-(5 Yrs.)
                     III                125   125-10-245 (12 Yrs.)
                                               EB-12 1/2-320 (6 Yrs.)
                     I                  225   225-20-385 (8 Yrs.)
                                               EB-30-445 (2 Yrs.)
                     I                  350   350-25-550 (8 Yrs.)
                                                  -40-630 (2 Yrs.)
    B                IV                 100   100-5-165 (13 Yrs.)
                                                 EB-7-200 (5 Yrs.)
                     III                150   150-12 1/2-300 (12 Yrs.)
                                                 EB-20-420 (6 Yrs.)
                     II                 350    350-20-510 (8 Yrs.)
                                                 EB-30-570 (2 Yrs.)
                     I                  500    500-30-740 (8 Yrs.)
                                                   -40-820 (2 Yrs.)
    A                IV                 125    125-7 1/2-215 (12 Yrs.)
                                                 EB-10-275 (6 Yrs.)
                     III                175    175-20-415 (12 Yrs.) 
                                                EB-25-515 (4 Yrs.)Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

                     II                 500    500-40-820 (8 Yrs.) 
                                                 EB-50-920 (2 Yrs.)
                     I                 1000   1000-50-1300 (6 Yrs.)
                                                   -75-1600 (4 Yrs.)
36. Dearness allowance, location allowance and part time employees remuneration
were also majority decisions. - The chairman and the representatives of the working
journalists voting for and the representatives of the employers voting against.
28. Other allowances :- In view of the paucity of evidence on the subject, the Board
decided that the fixation of conveyance and other allowances should be left to
collective bargaining between the working journalists and the newspaper
establishments concerned.
29. Fitment of employees :- For fitment of the present employees into the new scales,
service in a particular grade and category and in the particular newspaper
establishment alone should be taken into account.
30. In no case should the present emoluments of the employees be reduced as a
result of the operation of this decision.
35. When a newspaper establishment is re-classified as per para. 6 supra, the existing
pay of the staff should be protected. But future increments and scales should be those
applicable to the class of paper into which it falls.
38. Date of operation :- The Board's decision should be operative from the date of
constitution of the Board (i.e., 2-5-1956) in respect of newspaper establishments
coming under Class "A", "B" and "C" and from a date six months from the date of
appointment of the Board (i.e. 1-11-1956) in the case of newspaper establishments
under class "D" & "E". (This was also a majority decision. The chairman and the
representatives of the working journalists voted for and the representatives of the
employers voted against).
41. The Government of India should constitute a Wage Board under the Act, to review
the effect of the decisions of the Board on the newspaper establishments and the
working journalists, after the expiry of 3 years but not later than 5 years from the
date of the publication of the decisions of the Board.
37. These decisions were recorded on April 30, 1957, but the representatives of the
employers thought fit to append a minute of dissent and the chairman also put on
record a note on the same day explaining the reasons for the decisions thus recorded.
These documents are of vital importance in the determination of the issues before us.Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

38. In the minute of dissent recorded by the representatives of the employers they
started with an expression of regret that the conditions in the newspaper industry did
not permit them to accept the majority view. They expressed their opinion that the
fixation of rates of wages should be governed by the following criteria :
(i) normal needs of a worker;
(ii) capacity of the industry to pay;
(iii) nature of the industry; and
(iv) effect on the development of the industry and on employment. They pointed out
that :
(a) The newspaper industry was a class by itself. The selling price of its product was
ordinarily below its cost of production. Further, the cost of production specially that
of newsprint, went on varying and the frequent rises in newsprint price made it
difficult to plan and undertake any long term commitment of an increasing
expenditure.
(b) The income of the newspaper industry was principally derived from two main
sources : sales of copies and advertisement. While sales depended on public
acceptance, income from advertisement depended upon circulation, prestige and
purchasing power of readers. All those factors made publishing of newspapers a
hazardous undertaking and the hazard continued throughout its existence with the
result that it was obligatory that the rates of wages or scales should be fixed at the
minimum level, leaving it to the employees to share the prosperity of the units
through bonuses.
(c) It was not ordinarily easy for newspapers to increase the selling price and it had
been the experience of some established newspapers that such a course, when
adopted, had invariably brought about a reduction in circulation. The fall in
circulation had in turn an adverse effect on the advertisement revenue. The sales or
advertisement income of a newspaper was not responsive to a progressive increase in
expenditure.
(d) In any fixation of wages of a section of employees, its effect on other sections had
to be taken into consideration. Editorial employees were one section of a newspaper
establishment and any increase in their emoluments would have its inevitable
repercussions on the wages of other sections. The salaries of working journalists
would roughly be one-fifth of the total wage bill. The factory staff had a great
bargaining power and as such any increase in the salaries and introduction of scales
in the editorial department would have to be followed by an increase in the wages and
introduction of time scales in the factory side.Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

(e) It was the advertisement revenue that principally decided the capacity to pay of a
newspaper industry. It was not enough to take into consideration the gross revenue
of a newspaper alone but also the proportion of advertisement revenue in it. This
meant that minimum salaries and scales to be fixed on an All-India basis would
perforce have to be low if the newspapers in language of regions with a low
purchasing power such as Kerala and Orissa were not to be handicapped. It would
therefore be fair both to the industry and employees if wages were fixed region-wise.
(f) The proposals, which the majority had made, clearly showed that, according to it
the dominating principle of wage fixation was the need of the worker as conceived by
them, irrespective of its effect on the industry. The Board had not before it sufficient
data needed for the proper assessment of the paying capacity of the industry. The
profit and loss statements of the daily newspaper establishments for the year 1954-55
as submitted to the Board revealed that while 43 of them had shown profits 40 had
incurred losses. The condition of the newspaper industry in the country as a whole
could not be considered satisfactory. The proposals embodied in the decision made
by the majority were therefore unduly high. They would immediately throw a huge
burden on many papers, a burden which would progressively grow for some years,
and would be still bigger when its impact takes place on the wages of employees of its
other sections. All this will in its turn add to the burden of provident fund, gratuity,
etc., when the full impact of the burden took place and the wages of the entire
newspaper establishments went up, it would throw out of gear the economy of most
of the newspapers. It might be that there may not be many closures immediately,
because many of the newspapers would not be in a position to meet the liability of
retrenchment compensation, gratuity, etc., resulting from such a step, newspapers
would try to meet the liability by borrowing to the extent possible and when their
credit was exhausted, they must close down. So far as new newspaper promotions
were concerned, they would be few and far between, with the result that after a few
years it would be found that the number of daily newspapers in the country had not
increased but had gone down. Such an eventuality was not in the interests of the
country both from the point of view of employment as well as of freedom of
expression.
(g) As regards chains and groups the criterion for classification adopted by the
majority was unfair and unnatural. The total gross revenue of all the units in a chain
or a group gave an unreal picture of its capacity to pay.
(h) Giving of retrospective effect, would help only to aggravate the troubles of the
newspaper industry which had been already called upon to devise ways and means of
meeting the burden of retrospective gratuity.
(i) As regards the prevalent rates of wages for comparable employments the nature of
work of the working journalists in newspaper establishments could not be compared
with other avocations or professions and the rates of wages of working journalistsExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

should be fixed only in the context of the financial condition of the newspaper
industry. Comparison, could, however, be made within limits, namely with respect to
alternative employments available to persons with similar educational qualifications
in particular regions or localities. From that point of view the salaries paid to
secondary school teachers, college and university teachers and employees in
commercial firms and banks should be taken into consideration, but the majority had
rejected this view.
39. The note of the chairman was meant to explain the reasons of the decisions which he stated he at
least had in view and some of which were accepted unanimously and others were accepted by some
members and thereby became majority decisions. At the outset the chairman explained that most of
the recommendations of the Press commission were intended for the betterment of the economic
condition of small and medium newspapers, such as price page schedule, telescopic rates for
Government advertisements and their fair distribution among newspapers, statutory restrictions on
malpractices so as to eliminate cutthroat competition and fixation of news agency tariffs which still
remained to be implemented and there had been no stability in the prices of newsprint which
constituted a considerable proportion of the expenditure of a newspaper. These circumstances had
necessitated the fixing of a minimum wage lower than that recommended by the Press Commission.
40. As regards fixation of the rates of wages, the chairman observed :
"In fixing the rates of wages, we have based them on the condition of the newspaper
industry as a whole and not on the effect which they will produce on a particular
newspaper. We can only proceed on the average gross income of a newspaper falling
under the same class and not on the lowest unit in that class. Otherwise, there will be
no improvement in any unit of the same class, and the status quo might remain. With
the extremely divergent conditions obtaining in both English as well as Indian
language newspapers, it is impossible to try to avoid any small or medium newspaper
being adversely affected. When the tone and condition of journalism in India has to
be brought on a higher level it is inevitable that in doing so, more or less burden will
fall on several newspapers; I realise that in cases where wages are very low and
dearness allowance is also low or even non-existent and there are no scales at all, the
reaction to our wage schedule will be one of resentment by the proprietors. Some
anomalies may also be pointed out; but it must be remembered that we had no data
of all the newspapers before us and where we had, it was in many cases not
satisfactory. Under these circumstances, we cannot satisfy all newspapers as well as
journalists. However, we have tried to proceed on the basis of accepted principles
also keeping in view the recommendations of the Press Commission and not on the
editorial expenditure of each newspaper. I am also of the opinion that by rational
management there is great scope for increasing the income of newspapers and we
have evidence before us that the future of the Indian language newspapers is bright,
having regard to increasing literacy and the growth of political consciousness of the
reading public. When there are wide disparities, there cannot be any adjustment
which might satisfy all persons interested. We hope no newspaper is forced to closeExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

down as a result of our decision. But if there is a good paper and it deserves to exist,
we hope the Government and the public will help it to continue."
41. The chairman then proceeded to observe :
"We do not consider it a matter of regret if our decisions discourage the entry into
this industry of persons without the necessary resources required for the payment of
a reasonable minimum wage. While we are anxious to promote and encourage the
growth of small newspapers, we also feel strongly that it should not be at the expense
of the working journalists. The same applies, in our view, to newspapers started for
political, religious or any other propaganda."
42. The reason for grouping all the constituent units of the same group of chain in the same class in
which they would fall on the basis of the total gross income of the entire establishment was given by
the chairman as under :-
"One of the difficult tasks before us was to fix the wages of journalists working in
newspapers which have recently come to exist in our country. All the accounts of the
constituent units in the same group or chain are merged together with the result that
the losses of the weaker units are borne from the high income of prosperous units.
There is considerable disparity in the wages of journalists doing the same kind of
work in the various constituent units situated in different centers. The Press
Commission has strongly criticised the methods of such chains and groups and their
adverse effects on the employees. We have decided to group all the constituent units
of the same group or chain in the same class in which they would fall on the basis of
the total gross income of the entire establishment. We are conscious that as a result
of this decision, some of the journalists in the weak units of the same group or chain
may get much more than those working in its highest income units. If however, our
principle is good and scientific, the inevitable result of its application should be
judged from the stand-point of Indian Journalism as a whole and not on the burden
it casts on a particular establishment. It may be added that in our view, the principle
on which we have proceeded is one of the main steps to give effect to the views
expressed by the Press Commission."
43. The chairman then referred to the points which the representatives of the newspaper employers
had urged as to the burden which might be cast as a result of the decisions and expressed himself as
under :
"I Sympathies with their view point and in my opinion, looking to all the
circumstances, especially the fact that this is the first attempt to fix rates of wages for
journalists, it is probable that some anomalies may result from the implementation of
our decisions. We are, therefore, averse to imposing a wage schedule of all classes of
newspapers on a permanent basis. It is, thus important that the wage rates fixed by
us should be open to review and revision in the light of experience gained within aExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

period of 3 to 5 years. This becomes necessary especially in view of the fact that the
data available to us have not been as complete as we would have wished them to be,
and also because it is difficult for us at this stage to work out with any degree of
precision, the economic and other effects of our decisions on the newspaper industry
as a whole."
44. The chairman suggested as a palliative the creation by the Government of India immediately of a
standing administrative machinery "which could also combine in itself the functions of
implementing and administering our decisions and that of preparing the ground for the review and
revision envisaged after 3 to 5 years. This machinery should collect from all newspaper
establishments in the country on systematic basis detailed information and data such as those on
employment, wage rates, and earnings, financial condition of papers, figures of circulation, etc.,
which may be required for the assessment of the effects of our decisions at the time of the review."
45. The above decision of the Wage Board was published by the Central Government in the Gazette
of India Extraordinary dated May 11, 1957. The Commissioner of Labour, Madras, issued a circular
on May 30, 1957, calling upon the managements of all newspaper establishments in the State to
send to him the report of the gross revenue for the three years, i.e., 1952, 1953 and 1954, within a
period of one month from the date of the publication of the Board's decision, i.e., not later than June
10, 1957. Writ Petition No. 91 of 1957 was thereupon filed on June 13, 1957, by the Express
Newspapers (Private) Ltd., against the Union of India & others and this petition was followed up by
similar petitions field on August 9, 1957, by the Press Trust of India Ltd., the Indian National Press
(Bombay) Private Ltd., and the Saurashtra Trust, being Petitions Nos. 99, 100, and 101 of 1957
respectively. The Hindustan Times Ltd., New Delhi filed on August 23, 1957, a similar petition,
being Petition No. 103 of 1957, and three more petitions, being Petitions Nos. 116, 117 and 118 of
1957, were filed by the Loksatta Karyalaya, Baroda, Sandesh Ltd., Ahmedabad and Jan Satta
Karyalaya, Ahmedabad, respectively, on September 18, 1957.
46. The Express Newspapers (Private) Ltd., the petitioners in Petition No. 91 of 1957, otherwise
termed the "Express Group", are the biggest chain in the newspaper world in India. They publish (i)
Indian Express, an English Daily, from Madras, Bombay, Delhi and Madurai, (ii) Sunday Standard,
an English Weekly, from three centers - Madras, Bombay and Delhi, (iii) Dinmani, a Tamil Daily
from Madras and Madurai, (iv) Dinmani Kadir, a Tamil Weekly from Madras, (v) Loksatta, a
Maratha Daily, and Sunday Loksatta, a Maratha Weekly, from Bombay, (vi) Screen, and English
Weekly from Bombay and (vii) Andhra Prabha, a Telugu Daily and weekly. The total number of
working journalists employed by them are 331, out of whom there are 123 proof readers, as against
1570 who form the other members of the staff. The present emoluments of the working journalists
in their employ amount to Rs. 9,77,892, whereas if the decision of the Wage Board were given effect
to they would go up to Rs. 15,21,282.12 thus increasing the wage bill of the working journalists
annually by Rs. 5,43,390.12. They would also have to pay remuneration to the part-time
correspondents on the basis of retainer as well as payment or news items on column basis. That
would involve an additional burden of about Rs. 1 lakh a year. The retrospective operation of the
Wage Board's decision with effect from May 2, 1956, in their case would further involve a payment
of Rs. 5,16,337.20. This would be the extra burden not taking account the liability for past gratuityExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

and the recurring gratuity as awarded under the provisions of the Act and also the increased burden
which would have to be borne by reason of the impact of the provisions in regard to reduced hours
of working, increase in leave, etc., provided therein. If, moreover, the members of the staff who are
not included in the definition of working journalists made similar demands for increasing their
emoluments and bettering their conditions of service then there would be an additional burden
which is estimated at Rs. 9,92,443.68.
47. The Press Trust of India Ltd., the petitioners in Petition No. 99 of 1957, are a non-profit making
co-operative organization of newspaper proprietors. They employ 820 employees in all, out of whom
170 are working journalists and 650 do not come within that definition. Their total wage bill is Rs.
21,00,000 per year (approximately) out of which the annual salary of the working journalists is Rs.
9,00,000. The increase in their wage bill due to increase in the salary of the working journalists as
per the decision of the Wage Board would come to Rs. 4,05,600 and they would have to pay be way
of arrears by reason of the retrospective operation of the decision another sum of Rs. 4,05,600 to
the working journalists. There would also be an additional financial burden of Rs. 60,000 every year
by reason of the recurring increments in the monthly salaries of the working journalists employed
by them. If the benefits of the Wage Board decision were extended to the other members of the staff
who are not working journalists within the definition of that term but who have also made similar
demands on them, a further annual burden would be imposed on the petitioners which is estimated
at Rs. 3,90,000. If perchance the petitioners not being able to run their concerned except at a loss
intended to close down the same, the amount which they would have to pay to the working
journalists under the provisions of the Act and the decision of the Wage Board would be Rs.
23,68,500 as against the old scale liability of Rs. 11,62,500 and the other members of the staff who
do not fall within the category of working journalists would have to be paid a further sum of Rs.
15,50,000. The total liability of the petitioners in such an event would amount to Rs. 39,18,000 as
against the old liability of Rs. 27,12,500.
48. The Indian National Press (Bombay) Private Ltd., otherwise known as the Free Press Group, are
petitioners in Petition No. 100 of 1957. They publish (i) Free Press Journal, a morning English Daily
(ii) Free Press Bulletin, an evening English Daily (iii) Bharat Jyoti, an English Weekly (iv)
Janashakti, a morning Gujarati Daily and (v) Navashakthi, a Marathi Daily - all from Bombay. They
employ 442 employees including part-time correspondents out of whom 65 are working journalists
and 21 are proof readers and the rest from members of the other staff not falling within the category
working journalists. The effect of the decision of the Wage Board would be that there would have to
be an immediate payment of Rs. 1,73,811 by reason of the retrospective operation of the decision and
there will also be an annual increase in the wage bill to the same extent, i.e., Rs. 1,73,811. There will
also be a yearly recurring increase to the extent of Rs. 22,470 and also corresponding increase for
contribution to the provident fund on account of increase in salary. Under the provisions of the Act
in regard to reduced hours of work, and increase in leave, moreover, there will be an increase in
liability to pay Rs. 90,669 and Rs. 29,806 respectively, in the case of working journalists, besides the
liability for past gratuity in another sum of Rs. 1,08,534 and recurring annual liability for gratuity in
a sum of Rs. 17,995. If similar benefits would have to be given to the other members of the staff who
do not fall within the definition of working journalists the annual burden would be increased by a
sum of Rs. 1,80,000. This would be the position by reason of the petitioners being classified andExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

treated as a chain of newspapers and having been classified as "A" class newspaper establishment on
a total computation of the gross revenue of all their units. If they were not so treated and the
component units were classified on their individual gross revenue the result would be that the Free
Press Journal, the Free Press Bulletin and the Bharat Jyoti would fall within class "A", and
Navashakthi would fall within class "C" and Janashakti would fall within class "D" thus minimising
the burden imposed upon them by the impact of the Wage Board decision.
49. The Saurashtra Trust, the petitioners in Petition No. 101 of 1957, are another chain of
newspapers and they publish (i) Janmabhoomi, a Gujarati Daily from Bombay, (ii) Janmabhoomi
and Pravasi, a Gujrati Weekly from Bombay, (iii) Lokmanya, a Marathi Daily from Bombay, (iv)
Vyapar, a Gujrati Weekly commercial paper from Bombay, (v) Fulchhab, a Gujrati Daily from
Rajkot, (vi) Pratap, a Gujrati Daily from Surat, (vii) Cuttccha Mitra, a Gujrati Daily from Bhuj
(Cutch) and, (vii) Nav Bharat, a Gujrati Daily from Baroda. They employ 445 employees out of
whom 60 are working journalists and 12, proof readers and the rest belong to the other members of
the staff. The effect of the Wage Board decision on them would be to impose on them a burden of Rs.
1,59,528 by reason of the retrospective operation of the decision and an annual increase in the wage
bill of Rs. 1,59,528 for the first year and an annual recurring increase of Rs. 22,000. The operation
of sections 6 and 7 of the Act in regard to reduced hours of work and provision for increased leave
would impose an additional burden of Rs. 42,000 per year. The liability for past gratuity would be
Rs. 93,376 and the recurring annual increase in gratuity would be Rs. 11,000. If similar benefits
were also given to the other members of the staff who were not working journalists the annual
burden will increase by Rs. 5,18,964, by reason of their classification as "A" class newspaper
establishment on a chain basis, all the component units have got to be treated as "A" class
newspapers, whereas if they were classified on a computation of the gross revenue of their
component units Vyapar would fall within Class "B" the Janmabhoomi and Lokmanya would fall
within Class "C" and the Cuttccha Mitra, Fulchhab and Pratap would fall within class "E". The
inequity of this measure is, moreover, sought to be augmented by their pointing out that whereas
the Janmabhoomi from Bombay is placed in the "A" Class, Bombay Samachar (Bombay), a morning
Gujrati Daily from Bombay, which has a larger gross revenue than Janmabhoomi taken as a single
unit is placed in Class B. Similarly, the Pratap from Surat is placed in Class A, whereas the Gujarat
Mitra from Surat which has a larger gross revenue than the Pratap is placed in Class "B" because of
its being treated as a unit by itself; and the Fulchhab from Rajkot is also placed in Class "A", whereas
the Jaihind from Rajkot, which has a larger gross revenue than the Fulchhab, is placed in Class "C"
for an identical reason. The total cost of closing down the concern, if perchance the petitioners have
to so close down owing to their inability to carry on the business except at a loss, is worked out at Rs.
6,13,921 for the working journalists as against the old basis of Rs. 1,00,890. The figure for the rest of
the staff who are not working journalists is computed at Rs. 3,08,112 with the result that the total
cost of closing down on the new basis under the provisions of the Act and the decision of the Wage
Board would be Rs. 9,22,033 as against what otherwise would have been a sum of Rs. 4,09,002.
50. The Hindustan Times Ltd., New Delhi, the petitioners in petition No. 103 of 1957, otherwise
called "the Hindustan Times Group", publish (i) Hindustan Times, an English (Morning) Daily, (ii)
Hindustan Times (Evening News) an English (evening) Daily, (iii) Overseas Hindustan Times, an
English Weekly, (iv) Hindustan, a Hindi Daily, and (v) Saptahik Hindustan, a Hindi Weekly - allExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

from Delhi. They employ a total number of 695 employees out of whom 79 are working journalists,
14 are proof readers and the rest, viz., 602 are other members of the staff. The wages paid to the
working journalists absorb about one-third of the total wage bill as against 602 other members of
the staff whose wage bill constitutes the remaining two-thirds. If the decision of the Wage Board is
given effect to the petitioners would be subjected to the following additional liabilities in respect of
working journalists alone : (i) Increase in the annual wage bill Rs. 2,16,000 (Approx.) (ii) Arrears of
payments from May 2, 1956, to April 30, 1957, Rs. 1,89,000 (iii) Past liability in respect of gratuity
as on March 31, 1957, Rs. 2,65,000 (iv) Recurring annual liability of gratuity Rs. 28,000. The total
liability thus comes to Rs. 6,98,000. The above figures do not include increased liability on account
of the petitioners' contribution towards provident fund, leave rules and payment to part-time
correspondents. There would also be a further recurring increase in the wage bill by reason of the
increments which would have to be given to the various categories of working journalists on the
scales of wages prescribed by the Wage Board. If other members of the staff (who are not "working
journalists") were to be considered for increase in their emoluments, etc., there will be a further
burden on the petitioners computed as under :
(a) Increase in the annual wage bill, Rs. 5,02,000 (Approx.), (b) arrears of payments
from May 2, 1956, to April 30, 1957, Rs. 4,51,000 (Approx.), (c) Past liability in
respect of gratuity as on March 31, 1957, Rs. 5,50,000 (Approx.), (d) Recurring
annual liability for gratuity Rs. 60,000 (Approx.). The total comes to Rs. 15,63,000.
51. The petitioners in petition No. 116 of 1957 are the Loksatta Karyalaya, Baroda, which publish the
Loksatta, a Gujarati Daily from Baroda. They employ 15 working journalists. The annual wage bill of
working journalists would have to be increased by reason of the decision of the Wage Board by Rs.
10,800; the burden of payment of retrospective liability being Rs. 9,600. Moreover, there will be a
recurring annual burden of Rs. 6,340 inclusive of the expenditure involved by reason of the
provisions as to (i) Notice pay, (ii) Gratuity, (iii) Retrenchment compensation and (iv) Extra burden
of reduced hours of work and increased leave.
52. The Sandesh Ltd., the petitioners in Petition No. 117 of 1957, otherwise styled, the Sandesh
Group, Ahmedabad, Publish (i) Sandesh, a morning Gujrati Daily, (ii) Sevak, an evening Gujrati
Daily, (iii) Bal Sandesh, a Gujarati Weekly, and (iv) Aram, and (v) Sat Sandesh, Gujarati Monthlies -
all from Ahmedabad. They employ a total staff of 205 employees out of whom there are 11 working
journalists, 7 proof readers and the rest 187 constitute the other members of the staff. The increase
in the wage bill of the working journalists under the provisions of the Act would be Rs. 24,807 per
year besides a similar liability for Rs. 24,807 by reason of the retrospective operation of the decision.
There will be an increase in expenditure to the tune of Rs. 30,900 by reason of the reduced working
hours and increase in leave and holidays, a liability of Rs. 31,597 for past gratuity and Rs. 24,807
every year for recurring gratuity as also Rs. 1,530 for recurring increase in wages of the working
journalists. The financial burden in the case of proof-readers who are included in the definition of
working journalists under the terms of the Act would be Rs. 5,724 per year. If similar benefits were
to be given to the other members of the staff who are not working journalists the annual increase in
the burden will be Rs. 1,89,816. The total costs of closing down if such an eventuality were
contemplated would be Rs. 1,08,997 for the working journalists only as against a liability of Rs.Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

22,755 on the old basis. The other members of the staff would have to be paid Rs. 1,46,351 and the
total cost of closing down the whole concern would thus come to Rs. 2,55,349 under the new
dispensation as against Rs. 1,69,106 as of old.
53. The Jansatta Karyalaya, Ahmedabad, petitioners in Petition No. 118 of 1957 bring out (i)
Jansatta, a Gujarati Daily and (ii) Chandni a Gujarati Monthly from Ahmedabad. They employ 15
working journalists, 6 proof-readers and 87 other members of the staff thus making a total number
of 108 employees. The increase in the wage-bill of the working journalists would come to Rs.
29,808. The liability for past gratuity would be Rs. 6,624 and the recurring annual gratuity would be
Rs. 2,303 and the annual recurring increase in wages would come to Rs. 2,280. The financial burden
in case of proof-readers would be Rs. 6,480 per year as per the decision of the Wage Board. If
similar benefits had to be given to the other members of the staff who are non-working journalists
the annual burden will increase by Rs. 48,720. The total cost of closing down, if such a contingency
ever arose, would come to Rs. 1,00,798 under the provisions of the Act and the Wage Board decision
as against Rs. 45,206 on the old basis.
54. All these petitions filed by the several petitioners as above followed a common pattern. After
succinctly reciting the history of the events narrated above which led to the enactment of the
impugned Act and the decision of the Wage Board, they challenged the vires of the Act and the
decision of the Wage Board. The vires of the Act was challenged on the ground that the provisions
thereof were violative of the fundamental rights guaranteed by the Constitution under Art. 19(1)(a),
Art. 19(1)(g), and Art. 14; but in the course of the arguments before us another Article, viz., Art. 32
was also added as having been infringed by the Act. The decision of the Wage Board was challenged
on various grounds which were in pari materia with the objections that had been urged by the
representatives of the employers in the Wage Board in their minute of dissent above referred to. It
was also contended that the implementation of the decision would be beyond the capacity of the
petitioners and would result in their utter collapse. The reply made by the respondents was that
none of the fundamental rights guaranteed under Art. 19(1)(a), Art. 19(1)(g), Art. 14 and/or Art. 32
were infringed by the impugned Act, that the functions of the Wage Board were not judicial or
quasi-judicial in character, that the fixation of the rates of wages was a legislative act and not a
judicial one, that the decision of the Wage Board had been arrived at after taking into consideration
all the criteria for fixation of wages under s. 9(i) of the Act and the material as well as the evidence
led before it, that a considerable portion of the decisions recorded by the Wage Board were
unanimous, that the Wage Board had the power and authority also to fix the scales of wages and to
give retrospective operation to its decision, and that the financial position of the petitioners was not
such as to lead to their collapse as a result of the impact of the provisions of the impugned Act and
the decision of the Wage Board.
55. The petitioners in Petitions Nos. 91 of 1957, 99 of 1957, 100 of 1957, 101 of 1957 and 103 of 1957
also field petitions for special leave to appeal against the decision of the Wage Board being Petitions
Nos. 323, 346, 347, 348 and 359 of 1957 respectively and this Court granted the special leave in all
these petitions under Art. 136 of the Constitution subject to the question of the maintainability of
the appeals being open to be urged at the hearing. Civil Appeals arising out of these special leave
petitions were ordered to be placed along with the Writ Petitions aforesaid for hearing and finalExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

disposal and Civil Appeals Nos. 699 of 1957, 700 of 1957, 701 of 1957, 702 of 1957 and 703 of 1957
arising therefrom thus came up for hearing and final disposal before us along with the Writ Petitions
under Art. 32 mentioned above. We took up the hearing of the Writ Petitions first as they were more
comprehensive in scope than the Civil Appeals filed by the respective parties and heard counsel at
considerable length on the questions arising for our determination therein.
56. Before we discuss the vires of the impugned Act and the decision of the Wage Board, it will be
appropriate at this juncture to clear the ground by considering the principles of wage fixation and
the machinery employed for the purpose in various countries. Broadly speaking wages have been
classified into three categories, viz., (1) the living wage, (2) the fair wage and (3) the minimum wage.
57.The concept of the living wage :
"The concept of the living wage which has influenced the fixation of wages, statutorily
or otherwise, in all economically advanced countries is an old and well-established
one, but most of the current definitions are of recent origin. The most expressive
definition of the living wage is that of Justice Higgins of the Australian
Commonwealth Court of Conciliation in the Harvester case. He defined the living
wage as one appropriate for "the normal needs of the average employee, regarded as
a human being living in a civilized community". Justice Higgins has, at other places,
explained what he meant by this cryptic pronouncement. The living wage must
provide not merely for absolute essentials such as food, shelter and clothing but for "a
condition of frugal comfort estimated by current human standards." He explained
himself further by saying that it was a wage "sufficient to insure the workmen food,
shelter, clothing frugal comfort, provision for evil days, etc., as well as regard for the
special skill of an artisan if he is one". In a subsequent case he observed that "treating
marriage as the usual fate of adult men, a wage which does not allow of the
matrimonial condition and the maintenance of about five persons in a home would
not be treated as a living wage". According to the South Australian Act of 1912, the
living wage means "a sum sufficient for the normal and reasonable needs of the
average employee living in a locality where work under consideration is done or is to
be done." The Queensland Industrial conciliation and Arbitration Act provides that
the basic wage paid to an adult male employee shall not be less than is "sufficient to
maintain a well-conducted employee of average health, strength and competence and
his wife and a family of three children in a fair and average standard of comfort,
having regard to the conditions of living prevailing among employees in the calling in
respect of which such basic wage is fixed, and provided that in fixing such basic wage
the earnings of the children or wife of such employee shall not be taken into account".
In a Tentative Budget Inquiry conducted in the United States of America in 1919 the
Commissioner of the Bureau of Labour Statistics analysed the budgets with reference
to three concepts, viz.,
58. (i) the pauper and poverty level, (ii) the minimum of subsistence level, and, (iii) the minimum of
health and comfort level, and adopted the last for the determination of the living wage. The RoyalExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

Commission on the Basic Wage for the Commonwealth of Australia approved of this course and
proceeded through norms and budget enquiries to ascertain what the minimum of health and
comfort level should be. The commission quoted with approval the description of the minimum of
health and comfort level in the following terms :
"This represents a slightly higher level than that of subsistence, providing not only for
the material needs of food, shelter, and body covering, but also for certain comforts,
such as clothing sufficient for bodily comfort, and to maintain the wearer's instinct of
self-respect and decency, some insurance against the more important
misfortunes-death, disability and fire-good education for the children, some
amusement, and some expenditure for self-development."
60. Writing practically in the same language, the United Provinces Labour Enquiry Committee
classified levels of living standard in four categories, viz.,
61. (i) the poverty level, (ii) the minimum subsistence level, (iii) the subsistence plus level and (iv)
the comfort level, and chose the subsistence plus level as the basis of what it called the "minimum
living wage". The Bombay Textile labour Inquiry Committee, 1937 considered the living wage
standard at considerable length and, while accepting the concept of the living wage as described
above, observed as follows :
".... what we have to attempt is not an exact measurement of a well-defined concept.
Any definition of a standard of living is necessarily descriptive rather than logical.
Any minimum, after all, is arbitrary and relative. No completely objective and
absolute meaning can be attached to a term like the "living wage standard" and it has
necessarily to be judged in the light of the circumstances of the particular time and
country."
The Committee then proceeded through the use of norms and standard budgets to lay down what
the basic wage should be, so that it might approximate to the living wage standard "in the light of
the circumstances of the particular time and country."
62. The Minimum Wage-Fixing Machinery published by the I.L.O. has summarised these views as
follows :
"In different countries estimates have been made of the amount of a living wage, but
the estimates vary according to the point of view of the investigator.
63. Estimates may be classified into at least three groups :
(1) the amount necessary for mere subsistence, (2) the amount necessary for health
and decency, and (3) the amount necessary to provide a standard of comfort."Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

64. It will be seen from this summary of the concepts of the living wage held in various parts of the
world that there is general agreement that the living wage should enable the male earner to provide
for himself and his family not merely the bare essentials of food, clothing and shelter but a measure
of frugal comfort including education for the children, protection against ill-health, requirements of
essential social needs, and a measure of insurance against the more important misfortunes
including old age." (Report of the Committee on Fair Wages (1947 to 1949), pp. 5-7, paras 6 & 7).
65. Article 43 of our Constitution has also adopted as one of the Directive principles of State Policy
that :
"The State shall endeavour to secure, by suitable legislation or economic organisation
or in any other way, to all workers, agricultural, industrial or other wise, work, as
living wage, conditions of work ensuring a decent standard of life and full enjoyment
of leisure and social and cultural opportunities....."
66. This is the ideal to which our social welfare State has to approximate in an attempt to ameliorate
the living conditions of the workers.
67. The concept of the minimum wage :
"The International Convention of 1928 prescribes the setting up of minimum
wage-fixing machinery in industries in which "no arrangements exist for the effective
regulation of wages by collective agreement or otherwise and wages are exceptionally
low"....
"As a rule, though the living wage is the target, it has to be tempered, even in
advanced countries, by other considerations, particularly the general level of wages in
other industries and the capacity of industry to pay. This view has been accepted by
the Bombay Textile Labour Inquiry Committee which says that "the living wage basis
affords an absolute external standard for the determination of the minimum" and
that "where a living wage criterion has been used in the giving of an award or the
fixing of a wage, the decision has always been tempered by other considerations of a
practical character."
"In India, however, the level of the national income is so low at present that it is
generally accepted that the country cannot afford to prescribe by law a minimum
wage which would correspond to the concept of the living wage as described in the
preceeding paragraphs. What then should be the level of minimum wage which can
be sustained by the present stage of the country's economy ? Most employers and
some Provincial Governments consider that the minimum wage can at present be
only a bare subsistence wage. In tact, even one important All-India organisation of
employees has suggested that "a minimum wage is that wage which is sufficient to
cover the bare physical needs of a worker and his family." Many others, however,....
consider that a minimum wage should also provide for some other essentialExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

requirements such as a minimum of education, medical facilities and other
amenities. We consider that a minimum wage must provide not merely for the bare
sustenance of life but for the preservation of the efficiency of the worker. For this
purpose, the minimum wage must also provide for some measure of education,
medical requirements, and amenities." (Report of the Committee on Fair Wages, pp.
7-9, paras, 8-10).
68. This is the concept of the "minimum wage" adopted by the Committee on Fair Wages. There are
however variations of that concept and a distinction had been drawn, for instance, in Australian
industrial terminology between the basic wage and the minimum wage, -
"The basic wage there approximates to a bare minimum subsistence wage and no
normal adult male covered by an award is permitted to work a full standard hours
week at less than the assessed basic wage rate. The basic wage is expressed as the
minimum at which normal adult male unskilled workers may legally be employed,
differing from the amounts fixed as legal minima for skilled and semiskilled workers,
piece workers and casual workers respectively..... The minimum wage is the lowest
rate at which members of a specified grade of workers may legally be employed."
(O.D.R. Feenander Industrial Regulation in Australia (1947), Ch. XVII, P. 155).
69. There is also a distinction between a bare subsistence or minimum wage and a statutory
minimum wage. The former is a wage which would be sufficient to cover the bare physical needs of a
worker and his family, that is, a rate which has got to be paid to the worker irrespective of the
capacity of the industry to pay. If an industry is unable to pay to its workmen at least a bare
minimum wage it has no right to exist. As was observed by us in Messrs.
Crown Aluminium Works v. Their Workmen ([1958] S.C.R. 651) :
"It is quite likely that in under-developed countries, where unemployment prevails on
a very large scale, unorganised labour may be available on starvation wages, but the
employment of labour on starvation wages cannot be encouraged or favoured in a
modern democratic welfare state. If an employer cannot maintain his enterprise
without cutting down the wages of his employees below even a bare subsistence or
minimum wage, he would have no right to conduct his enterprise on such terms."
70. The statutory minimum wage however is the minimum which is prescribed by the statute and it
may be higher than the bare subsistence or minimum wage, providing for some measure of
education, medical requirements and amenities, as contemplated above. (Cf. also the connotation of
"minimum rate of wages" in s. 4 of the Minimum Wages Act, 1948 (XI of 1948)).
71. The concept of the fair wage :
"The payment of fair wages to labour is one of the cardinal recommendations of the
Industrial Truce Resolution...... Marshall would consider the rate of wages prevailingExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

in an occupation as "fair" if it is "about on level with the average payment for tasks in
other trades which are of equal difficulty and disagreeableness, which require equally
rare natural abilities and an equally expensive training." Prof. Pigou would apply two
degrees of fairness in judging a wage rate, viz., "fair in the narrower sense" and "fair
in the wider sense". A wage rate, in his opinion, is "fair in the narrower sense" when it
is equal to the rate current for similar workmen in the same trade and neighbourhood
and "fair in the wider sense" when it is equal to the predominant rate for similar work
throughout the country and in the generality of trades."
..............................................
72. "The Indian National Trade Union Congress.... is of the opinion that the wage fixed by collective
agreements, arbitrators, and adjudicators could at best be treated, like the minimum wage, as the
starting point and that wherever the capacity of an industry to pay a higher wage is established, such
a higher wage should be deemed to be the fair wage. The minimum wage should have no regard to
the capacity of an industry to pay and should be based solely on the requirements of the worker and
his family. "A fair wages" is, in the opinion of the Indian National Trade Union Congress, "a step
towards the progressive realisation of a living wage". Several employers while they are inclined to
the view that fair wages would, in the initial stages, be closely related to current wages, are prepared
to agree that the prevailing rates could suitably be enhanced according to the capacity of an industry
to pay and that the fair wage would in time progressively approach the living wage. It is necessary to
quote one other opinion, viz., that of the Government of Bombay, which has had considerable
experience in the matter of wage regulation. The opinion of that Government is as follows :
"Nothing short of a living wage can be a fair wage if under competitive conditions an
industry can be shown to be capable of paying a full living wage. The minimum wage
standards set up the irreducible level, the lowest limit or the floor below which no
workers shall be paid... A fair wage is settled above the minimum wage and goes
through the process of approximating towards a living wage."
73. While the lower limit of the fair wage must obviously be the minimum wage, the upper limit is
equally set by what may broadly be called the capacity of industry to pay. This will depend not only
on the present economic position of the industry but on its future prospects. Between these two
limits the actual wages will depend on a consideration of the following factors and in the light of the
comments given below :
(i) the productivity of labour; (ii) the prevailing rates of wages in the same or similar
occupations in the same or neighbouring localities; (iii) the level of the national
income and its distribution; and (iv) the place of the industry in the economy of the
country.".............(Report of the Committee on Fair Wages pp. 4, 9-11, paras, II-15).
74. It will be noticed that the "fair wage" is thus a mean between the living wage and the minimum
wage and even the minimum wage contemplated above is something more than the bare minimum
or subsistence wage which would be sufficient to cover the bare physical needs of the worker and hisExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

family, a wage which would provide also for the preservation of the efficiency of the worker and for
some measure of education, medical requirements and amenities.
75. This concept of minimum wage is in harmony with the advance of thought in all civilised
countries and approximates to the statutory minimum wage which the State should strive to achieve
having regard to the Directive Principle of State Policy mentioned above.
76. The enactment of the Minimum Wages Act, 1948, affords an illustration of an attempt to provide
a statutory minimum wage. It was an Act to provide for fixing minimum rates of wages in certain
employments and the appropriate Government was thereby empowered to fix different minimum
rates of wages for (i) different scheduled employments; (ii) different classes of work in the same
scheduled employment; (iii) adults, adolescents, children and apprentices; and (iv) different
localities; and (v) such minimum rates of wages could be fixed by the hour, by the day or by any
larger period as may be prescribed.
77. It will also be noticed that the content of the expressions "minimum wage" "fair wage" and
"living wage" is not fixed and static. It varies and is bound to vary from time to time. With the
growth and development of national economy, living standards would improve and so would our
notions about the respective categories of wages expand and be more progressive.
78. It must however be remembered that whereas the bare minimum or subsistence wage would
have to be fixed irrespective of the capacity of the industry to pay, the minimum wage thus
contemplated postulates the capacity of the industry to pay and no fixation of wages which ignores
this essential factor of the capacity of the industry to pay could ever be supported.
79. Fixation of Scales of Wages :-
80. A question arises as to whether the fixation of rates of wages would also include the fixation of
scales of wages. The rates of wages and scales of wages are two different expressions with two
different connotations. "Wages" have been defined in the Industrial Disputes Act, 1947, to mean "all
remuneration capable of being expressed in terms of money, which would, if the terms of
employment, express or implied, were fulfilled, be payable to a workman in respect of his
employment or of work done in such employment."
81. Similar definition of "wages" is to be found in the Minimum Wages Act, 1948, also. They would
therefore include all payments made from time to time to a workman during the course of his
employment as such and not merely the starting amount of wages at the beginning of his
employment. The dictionary meaning of the term in the Concise Oxford Dictionary is also the same,
viz., "Amount paid periodically, especially by the day or week or month, for time during which
workman or servant is at employer's disposal".
82. The use of the word "rate" in the expression "rates of wages" has not the effect of limiting the
connotation of the term. "Rate" is described in the Concise Oxford Dictionary as "a statement of
numeral proportion prevailing or to prevail between two sets of things either or both of which mayExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

be unspecified, amount, etc., mentioned in one case for application to all similar ones, standard or
way of reckoning (measure of) value, etc." In chambers' Twentieth Century Dictionary its meaning is
given as : estimated amount or value (Shakespeare), and also "amount determined according to a
rule or basis; a standard; a class or rank; manner or mode".
83. "Rates of wages" therefore mean the manner, mode or standard of the payments of
remuneration for work done whether at the start or in the subsequent stages. Rates of wages would
thus include the scales of wages, and there is no antithesis between the two expressions, the
expression being applicable both to the initial as well as subsequent amounts of wages. It is true that
in references made to Industrial Tribunals fixing of scales of pay has been specifically mentioned,
e.g., in the Industrial dispute between certain banking companies and their workers. But that is not
sufficient to exclude the "scales of wages" from being comprised within the larger connotation of the
expression "rates of wages" which is capable of including the scales of wages also within its ambit.
Even without the specific mention of the scales of wages it would be open to fix the same in an
inquiry directed towards the fixation of the rates of wages.
84. It is also true that Industrial Tribunals have laid down that the increments of wages or scales of
remuneration could only be fixed having due regard to the capacity of the industry to pay. In the
case of the Britannia Building & Iron Co. Ltd. ([1954] 1 L.L.J. 651, 654) :
"As time scales increase the wage bill year after year which is reflected in the cost of
production, such scales should not, in our opinion, be forced upon the employer of
industrial labour unless it is established that the employer has the present capacity to
pay and its financial capacity can be counted upon in future. Thus, both financial
ability and stability are requisite conditions."
85. Similar observations were made in the case of the Union Drug Co. Ltd. ([1954] 1 L.L.J. 766, 767)
:
"For before incremental scales can be imposed by adjudication, it is essential to see
whether employer would be able to bear its burden. The financial condition of the
Company must be such as to lead to the conclusion that it would be able to pay the
increments year by year for an appreciable number of years, for wage scales when
settled are intended to be long term schemes."
86. This consideration however of the capacity of the industry to pay does not militate against the
construction adopted above that rates of wages do comprise within their scope the scales of wages
also and it therefore follows that the fixation of rates of wages would also include the fixation of
scales of wages. As a matter of fact, the provisions in regard to the statutory minimum wages in
Queensland, Western Australia, and Tasmania prescribe scales of wages which are graduated
according to age and experience.
87. The capacity of the industry to pay being thus one of the essential ingredients in the fixation of
wages, it is relevant to consider the different methods of measuring such capacity.Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

88. The capacity of the industry to pay :
89. The capacity of industry to pay can mean one of three things, viz. :
(i) the capacity of a particular unit (marginal, representative or average) to pay, (ii)
the capacity of a particular industry as a whole to pay or (iii) the capacity of all
industries in the country to pay.
90. "Ideas on this subject have varied from country to country. In New Zealand and Australia the
capacity to pay is calculated with reference to all industries in the country and no special
concessions are shown to depressed industries. In Australia the Arbitration Court considered that
"in view of the absence of clear means of measuring the general wage-paying capacity of total
industry, the actual wage upon which well-situated labourers were at the time maintaining the
average family unit could justifiably be taken as the criterion of what industry could probably pay to
all labourers". This is at best a secondary definition of capacity, for it could only serve to show that
certain industries or units could afford to pay as much as certain others."
91. "The Bombay Textile Labour Inquiry Committee came to conclusion that it was not possible to
define the term "capacity to pay" in a precise manner and observed as follows :
"The capacity to pay a wage cannot obviously be determined merely by the value of
production. There is the important question of determining the charges that have to
be deducted before arriving at the amount that can be paid in wages. The
determination of each of a large number of charges involves difficulties, both
theoretical and practical. Interest charges, remuneration to salaried staffs and
managing agents, sales commissions, profits, all these cannot for any large organised
industry be taken as pre-determined in a fixed manner. Neither is it to be expected
that representatives of Labour would accept without challenge the current levels of
expenditure on these items-apart from the consideration whether the industry has
been reasonably well managed or not."
92. "That Committee was, however, of the opinion that capacity should not be measured in terms of
the individual establishment and that "the main criterion should be the profit making capacity of the
industry in the whole province....."
93. "In determining the capacity of an industry to pay it would be wrong to take the capacity of a
particular unit or the capacity of all industries in the country. The relevant criterion should be the
capacity of a particular industry in a specified region and, as far as possible, the same wages should
be prescribed for all units of that industry in that region. It will obviously not be possible for the
wage fixing board to measure the capacity of each of the units of an industry in a region and the only
practicable method is to take a fair cross-section of that industry." (Report of the Committee on Fair
Wages, pp. 13-15, paras, 21 & 23).Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

94. It is clear therefore that the capacity of an industry to pay should be gauged on an
industry-cum-region basis after taking a fair cross-section of that industry. In a given case it may be
even permissible to divide the industry into appropriate classes and then deal with the capacity of
the industry to pay class-wise.
95.As regards the measure of the capacity again there are two points of view in regard to the same :
96. "One view is that the wage-fixing machinery should, in determining the capacity of industry to
pay, have regard to
(i) a fair return on capital and remuneration to management; and
(ii) a fair allocation to reserves and depreciation so as to keep the industry in a healthy condition.
97. The other view is that the fair wage must be paid at any cost and that industry must go on paying
such wage as long as it does not encroach on capital to pay that wage...................
................................................................
98. The objective is not merely to determine wages which are fair in the abstract, but to see that
employment at existing levels is not only maintained but, if possible, increased. From this point of
view, it will be clear that the level of wages should enable the industry to maintain production with
efficiency. The capacity of industry to pay should, therefore, be assessed in the light of this very
important consideration. The wages board should also be charged with the duty of seeing that fair
wages so fixed for any particular industry are not very much out of lien with wages in other
industries in that region. Wide disparities would inevitably lead to movement of labour, and
consequent industrial unrest not only in the industry concerned but in other industries." (Report of
the Committee on Fair Wages, p. 14, para. 24).
99. The main consideration which is to be borne in mind therefore is that the industry should be
able to maintain production with efficiency and the fixation of rates of wages should be such that
there are no movements from one industry to another owing to wide disparities and employment at
existing levels is not only maintained, but if possible, increased.
100. Different tests have been suggested for measuring the capacity of the industry to pay : viz :
(1) The selling price of the product;
(2) The volume of the output;
(3) the profit and loss in the business;
(4) the rates which have been agreed to by a large majority of the employers;Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

(5) the amount of unemployment brought about or likely to be brought about by the
imposition of the increased wage, etc.
101. They are however not quite satisfactory. The real measure of the capacity of the industry to pay
has been thus laid down in "Wages & the State" by E.M. Burns at p. 387 :
"It would be necessary to inquire inter alia into the elasticity of demand for the
product, for on this depends the extent to which employers could transfer the burden
of the increased wage to consumers. It would also be necessary to inquire how far the
enforced payment of a higher wage would lead employers to tighten up organisation
and so pay the higher wage without difficulty.
........................................................
102. Similarly it frequently happens that an enhanced wage increased the efficiency of the lowest
paid workers; the resulting increase in production should be considered in conjunction with the
elasticity of demand for the commodity before the ability of a trade to pay can fairly be judged.
........................................................
103. Again unless what the trade can bear be held to imply that in no circumstances should the
existing rate of profit be reduced, there is no reason why attempts should not be made to discover
how far it is possible to force employers to bear the burden of an increased rate without driving
them out of business. This would involve an investigation into the elasticity of supply of capital and
organising ability in that particular trade, and thus an inquiry into the rate of profits in other
industries, the ease with which transferences might be made, the possibility of similar wage
regulation extending to other trades, and the probability of the export of capital and organising
ability etc."
104. The principles which emerge from the above discussion are :
(1) that in the fixation of rates of wages which include within its compass the fixation
of scales of wages also, the capacity of the industry to pay is one of the essential
circumstances to be taken into consideration except in cases of bare subsistence or
minimum wage where the employer is bound to pay the same irrespective of such
capacity;
(2) that the capacity of the industry to pay is to be considered on an
industry-cum-region basis after taking a fair cross section of the industry; and (3)
that the proper measure for gauging the capacity of the industry to pay should take
into account the elasticity of demand for the product, the possibility of tightening up
the organisation so that the industry could pay higher wages without difficulty and
the possibility of increase in the efficiency of the lowest paid workers resulting in
increase in production considered in conjunction with the elasticity of demand forExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

the product - no doubt against the ultimate background that the burden of the
increased rate should not be such as to drive the employer out of business.
105. These are the principles of fixation of rates of wages and it falls now to be considered what is
the machinery employed for such fixation.
106. The machinery for fixations of wages :
The fixation of wages may form the subject matter of reference to industrial tribunals
or similar machinery under the Labour Relations Law. But this machinery is
designed for the prevention and settlement of industrial disputes which have either
arisen or are apprehended, disputes relating to wages being one of such disputes. The
ensuring of an adequate wage is however a distinctive objective and it requires the
setting up of some kind of wage fixing board, whether they be trade boards or general
boards. It is seldom that legislative enactments themselves fix the rates of wages,
though a few such instances are known. This method of regulation of wages has now
become obsolete in view of its inflexibility." (The Report of the Committee on Fair
Wages, p. 26, para 49).
108. "The Constitution of Boards falls naturally into two main groups. On the one
hand, there are those not representatives of one but of all trades, workers in general
and employers in general being represented. This group includes among others the
Industrial Welfare Commission of Texas, consisting of the Commissioner of labour,
the representative of employers of labour on the Industrial Accidents, Board and the
State Superintendent of Public Instruction; the Minimum Wage Board of Manitoba,
composed of two representatives of employers, and two of workers (one of each to be
a woman) and one disinterested person; and the South Australian board of Industry,
consisting of a President and four Commissioners, two of whom are to be nominated
by the South Australian Employers' Federation and two by the United Trades and
Labour Council of the State. On the other hand are those Boards representative of
one trade only or of a part of a trade, or of a group of allied trades. An attempt is
made to obtain a body of specialists and the membership of the Board reflects this
intention. It will contain an equal number of representatives of employers and
workers, together with an impartial chairman, and in some cases members of the
public as well. Of this type are the British Trade Boards; the South Australian,
Victorian and Tasmanian Wages Boards; and the Advisory or Wages Boards set up by
many of the Central Commissioners in the United States and Canada." ("Wages &
The State" by E.M. Burns at p. 187).
109. The following is a brief description of the composition and working of wages
boards in the United Kingdom :
"In the United Kingdom where trade boards, and not general boards, have been set
up, the Minister of Labour appoints a board if he is satisfied that no adequateExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

machinery exists in a particular trade or industry for effectively regulation the wages
and that it is necessary to provide such machinery. The trade board is a fairly large
body consisting of an equal number of representatives of employers and workers with
a few independent members including the chairman. Although appointments are
made by the Minister, the representatives of employers and workers are appointed on
the recommendation of the associations concerned. The trade board publishes a
notice announcing its tentative proposals for the fixation or revision of a wage rate
and invites objections or comments. After a two months' notice the board takes a
final decision and submits a report to the Minister who must confirm the rate unless,
for any special reasons, he returns the recommendations to the board for further
consideration." (The Report of the Committee on Fair Wages, pp. 25-26, para 50).
110. The Wage Council Act, 1945 (8 & 9 Geo. VI, ch. 17) provides for the
establishment of Wage Councils. The Minister of Labour and National Service has the
power to make a wages council order after considering objections made with respect
to the draft order on behalf of any person appearing to him to be affected. The Wage
Council makes such investigation as it thinks fit and publishes notice of the wage
regulation proposals and parties affected are entitled to make written representations
with respect to these proposals which representations the Wage Council considers.
The Wage Council can make such further enquiries as it considers necessary and
thereafter submit the proposals to the Minister either without amendment or with
such amendments as it thinks fit in regard to the same. The Minister considers these
wage regulations proposals and makes an order giving effect to the proposals from
such date as may be specified in the order. Remuneration fixed by the wage
regulation orders is called statutory minimum remuneration.
111. There are also similar provisions under the Agricultural Wage Regulation Act,
1924 (14 & 15 Geo. V, ch. 37) in regard to the regulation of wages by Agricultural
Wages Committees and the Agricultural Wages Board.
112. In Canada and Syria a board consists of generally 5 members, but in china the
size of the board varies from 9 to 15. In all these countries employers and workers
obtain equal representation. In Canada the boards are required to enquiry into the
conditions of work and wages. In some provinces the boards are authorised to issue
orders or decrees while in others the recommendations have to be submitted to the
Lieutenant Governor who issues orders.
113. "In the United States of America some state laws prescribe that the
representatives of employers and workers should be elected, but in the majority of
States the administrative authorities are authorised to make direct appointments.
The boards so set up are empowered to make enquiries, to call for records, to
summon witnesses and to make recommendations regarding minimum wages. Some
of the American laws lay down a time-limit for the submission of proposals. The
administrative authority may accept or reject a report and refer it back forExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

reconsideration, or form a new board for considering the matter afresh. Some of the
laws provide that if the report is not accepted, the matter must be submitted again to
the same wages board or a new wages board." (Report of the Committee on Fair
Wages, p. 26, para. 50).
114. The whole procedure for the determination of wages in the United States of
America is described in two decisions of the Supreme Court : (i) Interstate Commerce
Com. v. Louisville & M.R. ([1912] 227 U.S. 88; 57 L.Ed. 431) and (ii) Opp. Cotton
Mills Inc. v. Administration. ([1940] 312 U.S. 126; 85 L.Ed. 624)
115. The Fair Labour Standards Act of 1938 in the U.S.A. provides for convening by
the Administrator of industry committees for each such industry which from time to
time recommend the minimum rate or rates of wages to be paid by the employers.
The committee recommends to the administrator the highest minimum wage rates
for the industry which it determines, having due regard to economic and competitive
conditions, will not substantially curtail employment in the industry. Wage orders
can thereupon be issued by the administrator after due notice to all interested
persons and giving them an opportunity to be heard.
116. In Australia also there are provisions in various states for the appointment of
wage boards the details of which we need not go into. We may only refer to the wage
board system in Victoria which was established in 1896 as a means of directly
regulating wages and working conditions in industries subject to "sweating", and was
not intended to control industrial relations as such.
117. "Under the Factories and Shops Act, 1924, wage boards are set up for the various
industries with a court of Industrial Appeals to decide appeals from a determination
of a wage board. Industries for which there is no special wage board are regulated by
the General Wages Board, which consists of two employers' representatives
nominated by the Victorian Chamber of Manufacturers, two employees'
representatives nominated by the Melbourne Trade Hall Council, and a chairman,
agreed upon by these four members or nominated by the minister for labour."
(Kenneth F. Walker, "Industrial Relations in Australia").
118. It may be noted that in the majority of cases these wage boards are constituted of
equal number of representatives of employers and employees and one or more
independent persons, one of whom is appointed the chairman.
119. The position in India has been thus summarised :
"The history of wage-fixation in India is a very recent one. There was practically no
effective machinery until the last war for the settlement of industrial disputes or the
fixation of wages. The first important enactment for the settlement of disputes was
the Bombay Industrial Disputes Act, 1938 which created an Industrial Court. The ActExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

had limited application and the Court was not charged with the responsibilities of
fixing and regulating wages. During the war State intervention in the settlement of
industrial disputes became necessary, and numerous adjudicators were appointed to
adjudicate on trade disputes under the Defence of India Rules. The Industrial
Disputes Act, 1947, is the first effective measure of All-India applicability for the
settlement of industrial disputes. Under this Act various Tribunals have passed
awards regulating wages in a number of important industries.
"The first enactment specifically to regulate wages in this country is the Minimum
Wages Act, 1948. This Act is limited in its operation to the so-called sweated
industries in which labour is practically unorganised and working conditions are far
worse than in organised industry. Under that Act the appropriate Government has
either to appoint a Committee to hold enquiries and to advise it in regard to the
fixation of minimum rates of wages, or, if it thinks that it has enough material on
hand, to publish its proposals for the fixation of wages in the official gazette and to
invite objections. The appropriate Government finally fixes the minimum rates of
wages on receipt of the recommendations of the Committee or of objections from the
public. There is no provision for any appeal. There is an advisory board in each
province to co-ordinate the work of the various committees. There is also a Central
Advisory Board to co-ordinate the work of provincial boards. Complaints of
non-payment of the minimum rates of wages fixed by Government may be taken to
claims authorities. Breaches of the Act are punishable by criminal courts." (Report of
the Committee on Fair Wages, pp. 26-27, para. 51, 52).
120. It is worthy of note that these committee, sub-committees, advisory board and
central advisory board are to consist of persons to be nominated by the Central
Government representing employers and employees in the scheduled employments,
who shall be equal in number, and independent persons not exceeding one-third of
its total number of members; one of such independent persons shall be appointed the
chairman by the appropriate Government.
121. "Under a recent amendment to the Bombay Industrial Relations Act, 1946, wage
boards can be set up in the Province of Bombay either separately for each industry or
for a group of industries. The wage board is to consist of an equal number of
representatives of employers and employees and some independent persons
including the Chairman, all of whom are nominated by the Government. The board
decides disputes relating to reduction in the number of persons employed,
rationalisation or other efficiency systems of work, wages and the period and mode of
payment, hours of work and leave with or without pay. When a matter has been
referred to a wages board, no proceedings may be commenced or continued before a
conciliator, conciliation board, labour court or industrial court. The wages boards are
authorised to from committees for local areas for the purpose of making enquiries. It
is obligatory on Government to declare the decisions of the wages boards binding, but
where Government feel that it will be inexpedient on public grounds to give effect toExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

the whole or any part of the decision, the matter has to be placed before the
Provincial Legislature, the decision of which will be binding. There is provision for
the filing of appeals from the decisions of the wages boards to the Industrial Court."
(Report of the Committee on Fair Wages, p. 27, para. 52).
122. Those wage boards moreover are under the superintendence of the Industrial
Court.
123. We may also notice here Recommendation 30, being the recommendation
concerning the application of Minimum Wage-Fixing Machinery made by the
International Labour Office, 1949 (Extracts from Conventions & Recommendations,
1919-49, published by International Labour Office (1949) :
"(1) The minimum wage-fixing machinery whatever form it may take (for instance,
trade board for individual trades, tribunals), should operate by way of investigation
into the relevant conditions in the trade or part of trade concerned and consultation
with the interests primarily and principally affected, that is to say, the employers and
workers in the trade or part of trade, whose views on all matters relating to the fixing
of the minimum rate of wages should in any case be solicited and be given full and
equal consideration.
"(2)(a) To secure greater authority for the rates that may be fixed, it should be the
general policy that the employers and workers concerned through representatives
equal in number or having equal voting strength, should jointly take a direct part in
the deliberations and decisions of the wage-fixing body; in any case, where
representation is accorded to one side, the other side should be represented on the
same footing. The wage-fixing body should also include one or more independent
persons whose votes can ensure effective decisions being reached in the event of the
votes of the employers' and workers' representatives being equally divided. Such
independent persons should, as far as possible, be selected in agreement with or after
consultation with the employers' and workers' representatives on the wage fixing
body.
"(b) In order to ensure that the employers' and workers' representatives shall be
persons having the confidence of those whose interests they respectively represent,
the employers and workers concerned should be given a voice as far as is practicable
in the circumstances in the selection of their representatives, and if any organisations
of the employers and workers exist these should in any case be invited to submit
names of persons recommended by them for appointment on the wage-fixing body.
(c) The independent person or persons mentioned in paragraph (a) should be
selected from among men or women recognized as possessing the necessary
qualifications for their duties and as being dissociated from any interest in the trade
or part of trade concerned which might be calculated to put their impartiality inExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

question."
................................................
124. The following appraisement of the system of establishing trader boards by the committee on
fair wages may be noted in this context :
"A trade board has the advantage of expert knowledge of the special problems of the
trade for which it has been set up and is, therefore, in apposition to evolve a scheme
of wages suited to the conditions obtaining in the trade. The system, however, suffers
from the limitation that there is no one authority to co-ordinate the activities of the
various boards with the result that wide disparities may arise between the scales
sanctioned for similar industries. A general board ensures due co-ordination but is
far less competent than a trade board to appreciate the special problems of each
trade. The Bombay Textile Labour Inquiry Committee have stated in their report that
the trade board system is the best suited to Indian conditions, particularly because
the very manner of functioning of trade boards is such that wages are arrived at
largely by discussion and conciliation and that it is only in exceptional cases that the
deciding votes of the Chairman and of the independent members have to be given."
(Report of Committee on Fair Wages, p. 27, para. 53).
125. It is clear therefore that a wage board relating to a particular trade or industry constituted of
equal number of representatives of employers and employees, with an independent member or
members one of whom is appointed a chairman, is best calculated to arrive at the proper fixation of
wages in that industry.
126. Principles for guidance.
127. If a wage board is thus appointed it is necessary that the principles for its guidance in wage
fixation should also be laid down by the appointing authority. The following passage from
"Minimum Wage - An International Survey - I.L.O. Geneva, 1939, summarises the position as it
obtains in various countries :
"As will be clear from the analysis of legislation given earlier in this monograph, the
fundamental principle of the Australian system, both in the Commonwealth and in
the State sphere, is that of the living wage. Even in those cases where the law contains
no reference to this principle its importance is in practice great... As a criterion of
wage regulation the principle of the living wage is however no more than a vague and
general indication of the purpose of the legislation. It leaves the broadest possible
discretion in practice to the wage fixing tribunals. In the case of the Commonwealth
laws indeed the Court is left completely free to determine the principles on which the
basic or living wage is to be assessed. Under certain of the State laws specific, though
limited, directions are given. Thus in Queensland there is a statutory definition of the
family unit on whose requirements the basic wage is to be calculated. In certain casesExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

the general emphasis on the criterion of the workers' needs is supplemented by
directions to fix wage rates that will be "fair and reasonable" and in doing so to take
into account the average standard of comfort being enjoyed by workers in the same
locality or in similar occupations. Such references, it may be noted, involve at least an
indirect allusion to general economic conditions and the capacity of industry to pay,
since the standards currently enjoyed are closely related to these factors. In at least
one case (in Queensland) the Court is specifically directed to examine the probable
effects of its decisions upon industry and the community in general."
128. In the United States of America the Fair Labour Standards Act of 1938 enunciates certain
principles for the guidance of the industry committees which are convened by the Administrator
under the Act :
"The committee shall recommend to the Administrator the highest minimum wage
rates for the industry which it determines, having due regard to economic and
competitive conditions, will not substantially curtail employment in the industry"
and further "in determining whether such classifications should be made in any
industry in making such classification, and in determining the minimum wage rates
for such classification, no classification shall be made, and no minimum wage rate
shall be fixed, solely on a regional basis, but the industry committee and the
Administrator shall consider among other relevant factors the following.
(1) competitive conditions as affected by transportation, living, and production cost;
(2) the wages established for work of like or comparable character by collective
labour agreements negotiated between employers and employees by representatives
of their own choosing; and (3) the wages paid for work of like or comparable
character by employers who voluntarily maintain minimum wage standards in the
industry.
No classification shall be made under this section on the basis of age or sex."
129. The normal rule however is to leave a wide discretion to the tribunals responsible for the
fixation of wages inasmuch as they being constituted of equal numbers of representatives of the
employers and the employees are best calculated to appreciate the whole position and arrive at
correct results.
130. Procedure to be followed :
131. The procedure to be followed by the wage boards is equally fluid. The wage councils and the
central co-ordinating committees appointed under the Wages Council Act, 1945, as also the
agricultural wages committees and the agricultural boards appointed under the Agricultural Wages
Regulation Act, 1924, in the United Kingdom each of them subject, of course, to the regulations
which might be made by the minister as to the meetings and procedure of these bodies includingExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

quorum, etc., is entitled to regulate its procedure in such manner as it thinks fit.
132. The wage boards in Australia "are called together informally by the chairman upon request of
either party. No legal formalities or procedure need be complied with. Meetings of wage boards are
held in the offices of the Department of Labour an officer of the department acting as secretary."
(Kenneth F. Walker "Industrial Relations Australia", p. 24).
133. The wage boards thus constituted are left to regulate their procedure in such manner as they
think fit and it is not necessary that any regulation should be made in regard to the procedure to be
adopted by them in the conduct of the enquiry before them.
134. There are, however, a number of safeguards which have been provided in order to protect the
interests of the parties concerned. The wages councils established by the Minister of Labour and
National Services in the United Kingdom are so established after considering objections from
persons appearing to be affected thereby and wage regulation orders are also recommended by these
councils after considering the written representations in regard to their proposals which are duly
published in the manner prescribed. These recommendations are again in their turn considered by
the minister and it is only after the minister is satisfied that these wage regulation orders are
promulgated, the minister having the power in proper cases to send the same back for
reconsideration by the wage councils. When these proposals are again submitted by the wage
council the same procedure is followed as in the case of original proposals made by them.
135. The reports of the industry committees convened by the administrator in the United States of
America are subject to scrutiny by the administrator who gives notice to all interested persons and
gives them an opportunity of being heard in regard to the same. It is only after this is done that he
approves and carries into effect the recommendations in these reports on his being fully satisfied
that they are proper and if he disapproves of these recommendations he again refers the matter to
such committees for further considerations and recommendations. The orders of the administrator
are again subject to review in the Circuit Court of Appeals in the United States and further revision
in the U.S. Supreme Court upon certiorari or certification.
136. As regards the determinations of the special boards in some of the States of the Commonwealth
of Australia appeals lie against the same to the court of industrial appeals and they are also
challengeable before the High Court.
137. Such safeguards are also provided in our Minimum Wages Act, 1948. Here the work of the
committees, sub-committees and advisory committees is co-ordinated by advisory boards and the
work of the advisory boards is co-ordinated by the central advisory board which advises the Central
Government in the matter of the fixing of the minimum rates of wages and other matters under the
Act and it is after the receipt of such advice from the Central advisory board by the appropriate
Government that the latter takes action in the matter of fixation or revision of minimum rates of
wages. Where, however, the appropriate Government proposes to fix the minimum rates of wages
without reference to the various committees, or sub-committees, it publishes its proposals by
notification in the Official Gazette for the information of persons likely to be affected thereby andExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

fixes the minimum rates of wages only after considering the representations received by it from the
interested parties.
138. The wage boards appointed by the amended Bombay Industrial Relations Act, 1946, are subject
to the appellate jurisdiction as well as supervisory jurisdiction of the industrial courts in the State
and parties affected by their decisions are entitled to file appeals against the same in the industrial
courts.
139. If these safeguards are provided against the determinations of the wage boards, it will be really
immaterial what procedure they adopt in the course of the proceedings before them. They would
normally be expected to adopt all procedure necessary to gather sufficient data and collect sufficient
materials to enable them to come to a proper conclusion in regard to the matters submitted to them
for their determination. If however at any time they flouted the regulations prescribed in regard to
the procedure to be followed by them or in the absence of any such regulations adopted a procedure
which was contrary to the principles of natural justice their decision would be vitiated and liable to
be set aside by the appropriate authority.
140. Character of the functions performed :
141. There is considerable divergence of opinion in regard to the character of the functions
performed by these wage boards and a controversy has arisen as to whether the functions performed
by them are administrative, judicial or quasi-judicial or legislative in character. The question
assumes importance on two grounds; viz., (i) whether the decisions of the wage boards are open to
judicial review and (ii) whether the principle of audi alteram partem applies to the proceedings
before the wage boards. If the functions performed by them were administrative or legislative in
character they would not be subject to judicial review and not only would they not be amenable to
the writs of certiorari or prohibition, under Arts. 32 and 226 of the Constitution, they would also not
be amenable to the exercise of special leave jurisdiction under Art. 136. Their decisions moreover
would not be vulnerable on the ground that the principle of audi alteram partem, i.e., no man shall
be condemned unheard, was not followed in the course of the proceedings before them and the
procedure adopted by them was contrary to the principles of natural justice.
142. It is well settled that writs of certiorari and prohibition will lie only in respect of judicial or
quasi-judicial acts :
"the orders of certiorari and prohibition will lie to bodies and persons other than
courts stricto sensu. Any body of persons having legal authority to determine
questions affecting the rights of subjects, and having the duty to act judicially, is
subject to the controlling jurisdiction of the High Court of justice, exercised by means
of these orders." (Halsbury's Laws of England, 3rd Edn., Vol. II. at p. 55, para, 114).
143. The principle of audi alteram partem also applies only to judicial or quasi-judicial proceedings :
As was observed by the Judicial Committee of the Privy Council in Patterson v. District
Commissioner of Accra ([1948] A.C. 341, 350) :-Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

"On this part of the case, counsel suggested that the provisions of s. 9 were in the
nature of a "mass punishment" of the inhabitants of the proclaimed district and he
relied on the well-known passage from the judgment of the court in Banaker v.
Evans, (16 Q.B. 162, 171) "no proposition can be more clearly established than that a
man cannot incur the loss of liberty or property for an offence by a judicial
proceeding until he has had a fair opportunity of answering the charge against him,
unless indeed the legislature has expressly or impliedly given an authority to act,
without that necessary preliminary. This is laid down in [here a number of cases are
mentioned] and many other cases, concluding with that of Capel v. Child ([1832] 2 C.
& J. 558) in which Bayley B. says he knows of no case in which you are to have a
judicial proceeding, by which a man is to be deprived of any part of his property,
without his having an opportunity of being heard."... Their Lordships have already
indicated that, in their view, the section does not contemplate any judicial
proceeding, and thus a decision against the appellant does not infringe the principles
stated in Bonaker v. Evans." (16 Q.B. 162, 171).
144. The distinction between a legislative and a judicial function is thus brought out in Cooley's
Constitutional Limitations, 8th Edn., Vol. I, ch. V under the caption of "the powers which the
legislative department may exercise", at p. 185 :-
"On general principles, therefore, those inquires, deliberations, orders, and decrees,
which are peculiar to such a department, must in their nature be judicial acts. Nor
can they be both judicial and legislative; because a marked difference exists between
the employment of judicial and legislative tribunals. The former decide upon the
legality of claims and conduct, and the latter make rules upon which, in connection
with the constitution, those decisions should be founded. It is the province of judges
to determine what is the law upon existing cases. In fine, the law is applied by one,
and made by the other. To do the first, therefore, is to compare, the claims of parties
with the law of the land before established - is in its nature judicial act. But to do the
last - to pass new rules for the regulation of new controversies - is in its nature a
legislative act; and if these rules interfere with the past, or the present, and do not
look wholly to the future, they violate the definition of a law as "a rule of civil
conduct", because no rule of conduct can with consistency operate upon what
occurred before the rule itself was promulgated.
"It is the province of judicial power, also to decide private disputes between or
concerning persons; but of legislative power to regulate public concerns, and to make
laws for the benefit and welfare of the State. Nor does the passage of private statutes,
when lawful, are enacted on petition, or by the consent of all concerned; or else they
forbear to interfere with past transactions and vested rights."
145. The following classic passage from the opinion of Holmes, J., in Prentis v. Atlantic Coast Line
Co. Ltd., ([1908] 211 U.S. 210, 226-227; 53 L.Ed. 150, 158, 159) is very apposite in this context :Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

"A judicial inquiry investigates, declares, and enforces liabilities as they stand on
present or past facts and under laws supposed already to exist. That is its purpose
and end. Legislation, on the other hand looks to the future and changes existing
conditions by making a new rule, to be applied thereafter to all or some part of those
subject to its power. The establishment of a rate is the making of a rule for the future,
and therefore, is an act legislative not judicial in kind,......."
..................................................
146. That question depends not upon the character of the body, but upon the character of the
proceedings.
...............................................
147. The nature of the final act determines the nature of the previous enquiry."
148. (See also Mitchell Coal & Coke Co. v. Pennsylvania R. Co. ([1913] 230 U.S. 247; 57 L.Ed. 1472,
1482) and Louisville & Nashville Railroad Company v. Green Garrett ([1913] 231 U.S. 198; 58 L.Ed.
229, 239)).
149. A practical difficulty however arises in thus characterizing the functions as legislative or judicial
because the functions performed by administrative agencies do not fall within water-tight
compartments. Stason and Cooper in their treatises on "Cases and other materials on
Administrative Tribunals" point out :
"One of the great difficulties of properly classifying a particular function of an
administrative agency is that frequently - and, indeed; typically - a single function has
three aspects. It is partly legislative, partly judicial and partly administrative.
Consider, for example, the function of rate-making. It has sometimes been
characterised as legislative, sometimes as judicial. In some aspects, actually, it
involves merely executive or administrative powers. For example, where the
Interstate Commerce Commission fixes a tariff of charges for any railroad, its
function is viewed as legislative. But where the question for decision is whether a
shipment of a mixture of coffee and chicory should be charged the rate established for
coffee or the lower rate established for chicory, the question is more nearly judicial.
On the other hand, where the problem is merely the calculation of the total freight
charges due for a particular shipment, the determination can fairly be described as an
administrative act."
150. This difficulty is solved by the Court considering in a proper case whether the administrative
agency performs a predominantly legislative or judicial or administrative function and determining
its character accordingly. (Vide : Village of Saratoga Springs v. Saratoga Gas, Electric Light & Power
Co., ([1908] 191 New York 123) and People ex rel. Central Park, North & East River R. Co. v. Willcox.
([1909] 194 New York 383).Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

151. The function of the wage board in the United Kingdom had been characterised as legislative in
character by various text-book writers.
152. Robson's Justice and Administrative Law, 3rd Edn., states at p. 608 (foot-note) :
"An example of a subordinate body of this type is a Wage Council, which is not an
administrative tribunal but a subordinate legislative authority."
153. Griffith's Principles of Administrative Law contains the following passage at p. 39 :
"The subordinate legislation which occupies more space than any other subject
relates to Wages Councils. By the Wages Councils Act, 1945, the Minister of Labour
and National Service was empowered to establish by order Wages Councils to operate
in industries and trades. Six such orders were made in 1947. Wages Councils, under
the Act, may submit to the Minister detailed "wages regulations proposals" for fixing
remuneration and making provisions for holidays. The Minister then makes orders
embodying and giving effect to these proposals. In 1947, fifty-five such orders were
made, covering thirty-one different trades."
154. Barbare Wootton in "Social Foundations of Wage Policy; Modern Methods of Wage
Determination" makes the following observations at p. 88 :
"Both arbitration tribunals and courts of inquiry share with - one important
difference - the tripartite structure of statutory wage councils; they are composed of
equal numbers of representatives of employers and of workers under an independent
chairman together with (in some cases) additional independent members. The
essential difference between their structure and that of statutory wage authorities is
that the representative members of the latter are chosen from within the industry
concerned, whereas employers and workers on arbitration tribunal come from
outside the industry whose disputes they have to resolve; if in any case technical
knowledge of a particular industry is required, this is normally supplied by the help of
assessors who take no part in the final award. This difference between the
constitution of wage boards and that to arbitration tribunals clearly implies a
corresponding distinction between the legislative function of the former and the
judicial function of the latter. The wages board drafts laws for its own industry,
whereas the arbitration court gives judgment on matters submitted by others. The
choice of industrial arbitrators unconnected with the industries the merits of whose
claims they must pledge, is evidently intended as a guarantee that they, like other
judges, will be free from bias arising from personal interest."
155. The High Court of the Commonwealth of Australia has taken a similar view in Australian Boot
Trade Employees Federation v. Whybrow & Co. ([1910] 10 C.L.R. 266, 318), in discussing an award
made by the wages board empowered by a State statute to fix minimum rates of wages. The test
applied for determining the character of that function may be stated in the words of Issacs J. at p.Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

318 :
"If the dispute is as to the relative rights of parties as they rest on past or present
circumstances, the award is in the nature of a judgment, which might have been the
decree of an ordinary judicial tribunal acting under the ordinary judicial power.
There the law applicable to the case must be observed. If, however, the dispute is as
to what shall in the future be the mutual rights and responsibilities of the parties - in
other words, if no present rights are asserted or denied, but a future rule of conduct is
to be prescribed, thus creating new rights and obligations, with sanctions for
non-conformity - then the determination that so prescribes, call it an award, or
arbitration, determination, or decision or what you will, is essentially of a legislative
character, and limited only by the law which authorises it. If, again, there are neither
present rights asserted, nor a future rule of conduct prescribed, but merely a fact
ascertained necessary for the practical effectuation of admitted rights, the
proceeding, though called an arbitration, is rather in the nature of an appraisement
or ministerial act."
.................................
156. As against this trend of opinion it has been urged that the decisions of the Wage Councils in the
shape of wage regulation proposals submitted to the minister in Great Britain under the Wage
Councils Act derive their sanction from the orders made by the minister giving effect to these
proposals; but for such orders of the minister they would merely remain the determinations of the
Wage Councils and would not acquire any legislative character. In regard to the determinations of
the wage boards empowered by the statutes to fix the minimum rates of wages in the
Commonwealth of Australia also it is pointed out that under the provisions of the Factories and
Shops Act, 1905, of Victoria "Every determination of any Special Board shall unless and until so
quashed... have the like force, validity and effect as if such determination had been enacted in this
Act..." thus investing the determination of the boards with the characteristics of a legislative act.
157. Reference is made to the provisions of the Fair Labour Standards Act of 1938 in the United
States of America, where the wages orders ultimately approved by the Administrator are subject to
judicial review in the Circuit courts of Appeals or in the United States courts of appeals of the
particular District and also subject to further review by the Supreme Court of the United States of
America on certification.
158. The Minimum Wages Act, 1948, in our country also provides for the committees,
sub-committees, advisory sub-committees, advisory boards and central advisory boards for fixing
minimum rates of wages and the recommendations of these committees are forwarded to the
appropriate Government who by notification in the official gazette fix minimum rates of wages in
respect of each scheduled employment. The notification is a token of the approval by the
appropriate Government of these recommendations of the Committees and invests them with legal
sanction.Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

159.The recent amendment of the Bombay Industrial Relations Act, 1946, empowers the State
Government by notification in the official Gazette to constitute for one or more industries a wage
board for the State and enjoins these wage boards to follow the same procedure as the Industrial
Court in respect of arbitration proceedings before it and appeals from the decisions of these wage
boards lie to the Industrial Courts which has powers of superintendence and control over these wage
boards and it cannot, under the circumstances, be urged that these wage boards perform any
legislative functions.
160. These are the two opposite points of view which have been pressed before us and it is
impossible to state that the functions performed by the wage boards are necessarily of a legislative
character. It is no doubt true that their determinations bind not only the employers and the
employees in the present, but they also operate when accepted by the appropriate government or
authorities and notified in accordance with law, to bind the future employers and employees in the
industry. If that were the only consideration the dictum of Justice Holmes cited above would apply
and the functions performed by these wage boards would be invested with a legislative character.
This is however not all, and regard must be had to the provisions of the statutes constituting the
wage boards. If on a scrutiny of the provisions in regard thereto one can come to the conclusion that
they are appointed only with a view to determine the relations between the employers and the
employees in the future in regard to the wages payable to the employees there would be justification
for holding that they were performing legislative functions. If, however, on a consideration of all the
relevant provisions of the statutes bringing the wage boards into existence, it appears that the
powers and procedure exercised by them are assimilated to those of Industrial Tribunals or their
adjudications are subject to judicial review at the hands of higher Tribunals exercising judicial or
quasi-judicial functions, it cannot be predicated that these wage boards are exercising legislative
functions. Whether they exercise these functions or not is thus to be determined by the relevant
provisions of the statutes incorporating them and it would be impossible to lay down any universal
rule which would help in the determination of this question.
161. Even if on the construction of the relevant provisions of the statute we come to the conclusion
that the functions performed by a particular wage board are not of a legislative character, the
question still remains whether the functions exercised by them are administrative in character or
judicial or quasi-judicial in character, because only in the latter event would their decision be
amenable to the writ jurisdiction or to the special leave jurisdiction above referred to.
162. There is no doubt that these wage boards are not exercising purely judicial functions. They are
not courts in the strict sense of the term and the functions which they perform may at best be
quasi-judicial in character. The fact that they are administrative agencies set up for the purpose of
fixation of wages do not necessarily invest their functions with an administrative character and in
spite of their being administrative bodies they can nevertheless be exercising quasi-judicial
functions if certain conditions are fulfilled.
163. The position in law has been thus summarised in Halsbury's Laws of England, 3rd Ed., Vol. 11,
at pp. 55-56 :-Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

"The orders of certiorari and prohibition will lie to bodies and persons other than
courts stricto sensu. Any body of persons having legal authority to determine
questions affecting the rights of subjects, and having the duty to act judicially, is
subject to the controlling jurisdiction of the High Court of Justice, exercised by
means of these orders. It is not necessary that it should be a court; an administrative
body in ascertaining facts or law may be under a duty to act judicially
notwithstanding that its proceedings have none of the formalities of, and are not in
accordance with the practice of, a court of law. It is enough if it is exercising, after
hearing evidence, judicial functions in the sense that it has to decide on evidence
between a proposal and an opposition. A body may be under a duty, however, to act
judicially (and subject to control by means of these orders) although there is no form
of lis inter partes before it; it is enough that it should have to determine a question
solely on the facts of the particular case, solely on the evidence before it, apart from
questions of policy or any other extraneous considerations."
"Moreover an administrative body, whose decision is actuated in whole or in part by
questions of policy, may be under a duty to act judicially in the course of arriving at
that decision. Thus, if in order to arrive at the decision, the body concerned had to
consider proposals and objections and consider evidence, if at some stage of the
proceedings leading up to the decision there was something in the nature of a lis
before it, then in the course of such consideration and at that stage the body would be
under a duty to act judicially. If, on the other hand, an administrative body in
arriving at its decision has before it at no stage any form of lis and throughout has to
consider the question from the point of view of policy and expediency, it cannot be
said that it is under a duty at any time to act judicially."
164. (See also the decision of this Court in Nagendra Nath Bora v. Commissioner of Hills Division
and Appeals, Assam. ([1958] S.C.R. 1240)
165. In order therefore to determine whether an administrative body is exercising a quasi-judicial
function, it would be necessary to examine in the first instance, whether it has to decide on evidence
between a proposal and an opposition and secondly, whether it is under a duty to act judicially in
the matter of arriving at its decision.
"The duty to act judicially may arise in widely differing circumstances which it would
be impossible to attempt to define exhaustively. The question whether or not there is
a duty to act judicially must be decided in each case in the light of the circumstances
of the particular case and the construction of the particular statute, with the
assistance of the general principles already set out." (Ibid, para. 115).
166. The decision in R. v. Manchester Legal Aid Committee Ex parte R. A. Brand & Co. Ltd. ([1952] 2
Q.B. 413, 428, 429, 430), lays down when an administrative body can be said to have a duty to act
judicially :Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

"The true view, as it seems to us, is that the duty to act judicially may arise in widely
different circumstances which it would be impossible, and, indeed, inadvisable, to
attempt to define exhaustively. Where the decision is that of a court, then, unless, as
in the case, for instance, of justices granting excise licences, it is acting in a purely
ministerial capacity, it is clearly under a duty to act judicially. When, on the other
hand, the decision is that of an administrative body and is actuated in whole or in
part by questions of policy, the duty to act judicially may arise in the course of
arriving at that decision. Thus, if, in order to arrive at the decision, the body
concerned had to consider proposals, and objections and consider evidence, then
there is the duty to act judicially in the course of that inquiry. That, as it seems to us,
is the true basis of the decision in Errington v. Minister of Health....." ([1935] 1 K.B.
249).
167. (See also Rex v. The London Country Council : Ex parte Entertainments Protection Association
Ltd. .....([1931] 2 K.B. 215, 233-4).
"Further, an administrative body in ascertaining facts or law may be under a duty to
act judicially notwithstanding that its proceedings have none of the formalities of and
are not in accordance with the practice of a court of law."
168. Vide Board of Education v. Rice : ([1911] A.C. 179, 182).
.............................................
169. "More recently it has been held by this Court on many occasions that certiorari will lie to quash
the decision of rent control tribunals, and this notwithstanding that such a tribunal is entitled to act
on its own knowledge and information, without evidence unless submitted, and without a hearing
except on notice from a party; see Rex v. Brighton and Area Rent Tribunal. ([1950] 2 K.B. 410).
170. "If, on the other hand, an administrative body in arriving at its decision at no stage has before it
any form of lis and throughout has to consider the question from the point of view of policy and
expediency, it cannot be said that it is under a duty at any stage to act judicially : Compare Franklin
v. Minister of Town and Country Planning." ([1948] A.C. 87, 102).
171. It is strenuously urged before us by learned counsel for the petitioners that if the functions
which the wage boards perform in the matter of fixation of the rates of wages are considered in the
light of the principles cited above, it would appear that as between the employers, on the one hand,
and the employees, on the other, there is a proposition and opposition. The employees demand that
a particular statutory minimum wage should be fixed and the scales of wages should also be
determined in a particular manner. The employers on their part would maintain that the status quo
should continue or that, in any event, much less than the statutory minimum wage demanded by the
employees should be fixed and also that the scales of wages should be fixed on a gradation which is
much less than or in any event, different from that suggested by the employees. The employees may
say that certain factors which are material in the fixation of wages and which affect the employeesExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

should be considered as determinative of the rates of wages while the importance of these factors
may be sought to be minimized by the employers who might put forward certain other factors
affecting them, in their turn, as determinative of those rates, the importance of which may be sought
to be minimized by the employees on the other hand. All these would create proposition and
opposition on both sides with the result that a lis would arise between them. The determination of
these points at issue would have to be arrived at by the wage boards and the wage boards could only
do so after collecting proper data and materials and hearing evidence in that behalf. If the functions
performed by the wage board would thus consist of the determination of the issues as between a
proposition and an opposition on data and materials gathered by the board in answers to the
questionnaire issued to all parties interested and the evidence led before it, there is no doubt that
there would be imported in the proceedings of the wage board a duty to act judicially and the
functions performed by the wage board would be quasi judicial in character. It has been on the other
hand urged before us by the learned counsel for the respondents that the very constitution of the
wage boards is against the fundamental principle of jurisprudence which postulates that no man
should be a judge in his own cause. It was laid down by the House of Lords in Franklin v. Minister of
Town and Country Planning ([1948] A.C. 87. 102) at p. 103 :
172. "My Lords, I could wish that the use of the word "bias" should be confined to its proper sphere.
Its proper significance, in my opinion, is to denote a departure from the standard of even-handed
justice which the law requires from those who occupy judicial office, or those who are commonly
regarded as holding a quasi-judicial office, such as an arbitrator. The reason for this clearly is, that
having to adjudicate as between two or more parties, he must come to his adjudication with an
independent mind, without any inclination or bias towards one side or other in the dispute."
173. The representatives of the employers and the representatives of the employees who are
appointed on the wage board along with an independent chairman and some other members, it is
submitted, would necessarily have a bias in favour of those whom they represent and therefore
would not be competent to be judges and the wage board thus constituted could hardly be called a
judicial body.
174. There is considerable force in these contentions, but we do not fell called upon to express our
final opinion on this question in view of the conclusion which we have hereafter reached in regard to
the ultra vires character of the decision of the Wage Board itself. We are however bound to observe
that whatever be the character of the functions performed by the wage boards whether they be
legislative or quasi-judicial, if proper safeguards are adopted of the nature discussed earlier, e.g.,
provision for judicial review or the adopting of the procedure as in the case of the recommendations
of the wage councils in the United Kingdom, or the reports of the advisory committees which come
to be considered by the administrator under the Fair Labour Standards Act of 1938 in the United
States of America, no objection could ever be urged against the determinations of the wage boards
thus arrived at one the score of the principles of natural justice having been violated.
175. We now proceed to consider how far the impugned Act violates the fundamental rights of the
petitioners.Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

176. Re : Article 19(1)(a).
177. Art. 19(1)(a) guarantees to all citizens the right to freedom of speech and expression. It has,
however, got to be read along with Art. 19(2) which lays down certain constitutionally permissible
limitations on the exercise of that right. Art. 19(2) as substituted by the Constitution (First
Amendment) Act, 1951, with retrospective effect reads as under :
"Nothing in sub-clause (a) of clause (1) shall effect the operation of any existing law,
or prevent the State from making any law, in so far as such law imposes reasonable
restrictions on the exercise of the right conferred by the said sub-clause in the
interests of the security of the State, friendly relations with foreign States, public
order, decency or morality, or in relation to contempt of court, defamation or
incitement to an offence."
178. If any limitation on the exercise of the fundamental right under Art. 19(1)(a) does not fall within
the four corners of Art. 19(2) it cannot be upheld.
179. Freedom of speech and expression includes within its scope the freedom of the press and it
would be apposite here to refer to the following passages from "Freedom of the Press - A Framework
of Principles" (Report of the Commission on Freedom of Press in the United States of America).
180. The General Meaning of Freedom :
To be free is to have the use of one's powers of action (i) without restraint or control
from outside and (ii) with whatever means or equipment the action requires.
181. "The primary suggestion of the term "freedom" is the negative one, the absence of external
interference whether to suppress or to constrain. To be free is essentially to be free from something -
some arbitrary impediment to action, some dominating power or authority. And so long as it can be
taken for granted that the unhindered person has all he needs to act with - which is usually the case
the negative meaning remains the chief element of the conception.
182. "But since freedom is for action, and action is for an end, the positive kernel of freedom lies in
the ability to achieve the end; to be free means to be free for some accomplishment. And this implies
command of the means to achieve the end. Unless the equipment necessary for effective action is at
hand, may be a mockery of freedom...... Unrestraint without equipment is not liberty for any end
which demands equipment." (pp. 54-55).
.............................................
183. Resulting Conception of Freedom of the Press :
184. "The emerging conception of freedom of the press may be summarised as follows :Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

As with all freedoms, press freedom means freedom from and freedom for. A free
press is free from compulsions from whatever source, governmental or social,
external or internal. From compulsions, not from pressures; for no press can be free
from pressures except in a moribund society empty of contending forces and beliefs.
These pressures, however, if they are persistent and distorting - as financial, clerical,
popular, institutional pressures may become - approach compulsion; and something
is then lost from effective freedom which the press and its public must unite to
restore.
"A free press is free for the expression of opinion in all its phases. It is free for the
achievement of those goals of press service on which its own ideals and the
requirements of the community combine and which existing techniques make
possible. For these ends it must have full command on technical resources, financial
strength, reasonable access to sources of information at home and abroad, and the
necessary facilities for bringing information to the national market. The press must
grow to the measure of this market." (p. 228).
....................................................
185. There is paucity of authority in India on the nature, scope and extent of this fundamental right
to freedom of speech and expression enshrined in Art. 19(1)(a) of the Constitution. The first case
which came up for decision before this court was that of Ramesh Thaper v. The State of Madras
([1950] S.C.R. 594, 597). It was a case of a ban on the entry and circulation of the appellant's journal
in the State of Madras under the provisions of section 9(1-A) of the Madras Maintenance of Public
Order Act, 1949, and it was observed by Patanjali Sastri J. (as he then was) at p. 597 :
186. "There can be no doubt that freedom of speech and expression includes freedom of propagation
of ideas, and that freedom is ensured by the freedom of circulation. "Liberty of circulation is as
essential to that freedom as the liberty of publication. Indeed, without circulation the publication
would be of little value." : Ex parte Jackson ([1877] 96 U.S. 727; 24 L.Ed. 877). See also Lovell v. City
of Griffin. ([1937] 303 U.S. 444; 82 L.Ed. 949).
187. Brij Bhushan & Anr. v. The State of Delhi ([1950] S.C.R. 605, 608) was the next case which
came up for decision before this Court and it concerned the constitutionality of section 7(i)(c) of the
East Punjab Public Safety Act, 1949. It was a provision for the imposition of pre-censorship on a
journal. Patanjali Sastri J. (as he then was) who delivered the majority judgment observed at p. 608
:-
"There can be little doubt that the imposition of pre-censorship on a journal is a
restriction on the liberty of the press which is an essential part of the right to freedom
of speech and expression declared by Art. 19(1)(a). As pointed out by Blackstone in
his Commentaries "the liberty of the Press consists in laying no previous restraint
upon publications, and not in freedom from censure for criminal matter when
published. Every freeman has an undoubted right to lay what sentiments he pleasesExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

before the public; to forbid this, is to destroy the freedom of the press. (Blackstone's
Commentaries, Vol. IV, pp. 151, 152)."
188. These are the only two decisions of this Court which involve the interpretation of Art. 19(1)(a)
and they only lay down that the freedom of speech and expression includes freedom of propagation
of ideas which freedom is ensured by the freedom of circulation and that the liberty of the press is an
essential part of the right to freedom of speech and expression and that liberty of the press consists
in allowing no previous restraint upon publication.
189. There is however, a considerable body of authority to be found in the decisions of the Supreme
Court of the United States of America bearing on this concept of the freedom of speech and
expression. Amendment I of that Constitution lays down :
"Congress shall make no law.... abridging the freedom of speech or of the press......"
190. It is trite to observe that the fundamental right to the freedom of speech and expression
enshrined in Art. 19(1)(a) of our Constitution is based on these provisions in Amendment I of the
Constitution of the United States of America and it would be therefore legitimate and proper to refer
to those decisions of the Supreme Court of the United States of America in order to appreciate the
true nature, scope and extent of this right in spite of the warning administered by this Court against
the use of American and other cases, (Vide State of Travancore-Cochin & Ors. v. Bombay Co. Ltd.
([1952] S.C.R. 1112, 1120) and State of Bombay v. R. M. D. Chamarbaugwala. ([1957] S.C.R. 874,
918).
191. Grosjean v. American Press Co. ([1935] 297 U.S. 233, 249; 80 L.Ed. 660, 668), was a case where
a statute imposed a license tax on the business of publishing advertisements and it was observed at
p. 668 :
"The evils to be prevented were not the censorship of the press merely, but any action
of the Government by means of which it might prevent such free and general
discussion of public matters as seems absolutely essential to prepare the people for
an intelligent exercise of their rights as citizens." (Vide Cooley's Constitutional
Limitations, 8th Edn., Vol. II, p. 886).
192. The statute was there struck down as unconstitutional because in the light of its history and of
its present setting it was seen to be a deliberate and calculated device in the guise of a tax to limit the
circulation of information to which the public was entitled in virtue of the constitutional guarantees.
193. The following passage from the dissenting opinion in The Associated Press v. The National
Labour Relations Board ([1936] 301 U.S. 103, 136; 81 L.Ed. 953, 963) is also instructive :
"If the freedom of the press does not include the right to adopt and pursue a policy
without governmental restriction, it is a misnomer to call it freedom. And we may as
well deny at once the right to the press freely to adopt a policy and pursue it, as toExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

concede that right and deny the liberty to exercise an uncensored judgment in respect
of the employment and discharge of the agents through whom the policy is to be
effectuated."
194. It was also observed there at p. 965 :
"Due regard for the constitutional guarantee requires that the publisher or agency of
the publisher of news shall be free from restraint in respect of employment in the
editorial force."
195.Schneider v. Irvingtor ([1939] 308 U.S. 147; 84 L.Ed. 155, 164) was concerned with the effect of
the Municipal Regulations against littering of streets. In the course of its decision the Court made
the following observations at p. 164 :
"This court has characterized the freedom of speech and that of the press as
fundamental personal rights and liberties. The phrase is not an empty one and was
not lightly used. It reflects the belief of the framers of the Constitution that exercise of
the rights lies at the foundation of free government by free press. It stresses, as do
many opinions of this court, the importance of preventing the restriction of
enjoyment of these liberties."
196. Non-interference by the State with this right was emphasized in Thomas v. Collins ([1944] 323
U.S. 516, 545; 89 L.Ed. 430, 448) at p. 448 :-
"But it cannot be the duty, because it is not the right, of the State to protect the public
against false doctrine. The very purpose of the First Amendment is to foreclose public
authority from assuming a guardianship of the public mind through regulating the
press, speech, and religion. In this field every person must be his own watchman for
truth, because the forefathers did not trust any Government to separate the true from
the false for us".....
197. In 93 L.Ed. at p. 1151 is given a summary of the decisions of the Supreme Court of the United
States of America on this subject under the heading "The Supreme Court and the right of Free
Speech and Press" and it contains at p. 1153 the following passage under the captain "Right in
General : Freedom from Censorship and Punishment" :
"The freedom of speech and of press are fundamental personal rights & liberties, the
exercise of which lies at the foundation of free Government by free men...... The very
purpose of the first Amendment is to foreclose public authority from assuming a
guardianship of the public mind through regulating the press, speech, and religion; it
rests on the assumption that the widest possible dissemination of information from
diverse and antagonistic sources is essential to the welfare of the public."Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

198. The dissenting opinion of Douglas J. in Beauharnais v. Illinois ([1951] 343 U.S. 250, 285; 96
L.Ed. 919, 943) contains the following at p. 943 :
"There is room for regulation of the ways and means of invading privacy. No such
leeway is granted the invasion of the right of free speech guaranteed by the First
Amendment. Until recent years that had been the course and direction of
constitutional law. Yet recently the Court in this and other cases has engrafted the
right of regulation onto the First Amendment by placing in the hands of the
legislative branch the right to regulate "within reasonable limits" the right of free
speech. This to me is an ominous and alarming trend. The free trade in ideas which
the framers of the Constitution visualised disappears. In its place there is substituted
a new orthodoxy - an orthodoxy that changes with the whims of the age or the day, an
orthodoxy which the majority by solemn judgment proclaims to be essential to the
safety, welfare, security, morality, or health of Society. Free speech in the
constitutional sense disappears. Limits are drawn - limits dictated by expediency,
political opinion, prejudices or some other desideratum of legislative action."
199. It is clear from the above that in the United States of America :
(a) the freedom of speech comprehends the freedom of press and the freedom of
speech and press are fundamental personal rights of the citizens;
(b) the freedom of the press rests on the assumption that the widest possible
dissemination of information from diverse and antagonistic source is essential to the
welfare of the public;
(c) Such freedom is the foundation of free Government of a free people;
(d) the purpose of such a guarantee is to prevent public authorities from assuming
the guardianship of the public mind and
(e) freedom of press involves freedom of employment or non-employment of the
necessary means of exercising this right or in other words, freedom from restriction
in respect of employment in the editorial force.
199. This is the concept of the freedom of speech and expression as it obtains in the United States of
America and the necessary corollary thereof is that no measure can be enacted which would have the
effect of imposing a pre-censorship, curtailing the circulation or restricting the choice of
employment or unemployment in the editorial force. Such a measure would certainly tend to
infringe the freedom of speech and expression and would therefore be liable to be struck down as
unconstitutional.
200. The press is however, not immune from the ordinary forms of taxation for support of the
Government nor from the application of the general laws relating to industrial relations. It wasExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

observed in Grosjean v. American Press Co. ([1935] 297 U.S. 233, 249; 80 L.Ed. 660, 668) :
"It is not intended by anything we have said to suggest that the owners of newspapers
are immune from any of the ordinary forms of taxation for support of the
Government; But this is not an ordinary form of tax but one single in kind with a long
history of hostile misuse against the freedom of the press.
"The predominant purpose of the grant of immunity here invoked was to preserve an
untrammelled press as a vocal source of public information. The newspapers,
magazines, and other journals of the country, it is safe to say, have shed and continue
to shed, more light on the public and business affairs of the nation than any other
instrumentality of publicity; and since informed public opinion is the most patent of
all restraints upon mis-government, the suppression or abridgment of the publicity
afforded by a free press cannot be regarded otherwise than with gave concern. The
tax here involved is bad not because it takes money from the pockets of the appellees.
If that were all, a wholly different question would be presented. It is bad : Because, in
the light of its history and of its present setting, it is seen to be a deliberate and
calculated device in the guise of a tax to limit the circulation of information to which
the public is entitled in virtue of the constitutional guarantees. A free press stands as
one of the great interpreters between the Government and the people. To allow it to
be fettered is to fetter ourselves."
201. In The Associated Press v. National Labour Relations Board ([1936] 301 U.S. 103, 136; 81 L.Ed.
953, 963), it was held that the freedom of the press safeguarded by the First Amendment was not
abridged by the application in the case of an editor employed by the Associated Press to determine
the news value of the items received and to rewrite them for transmission to members of the
association throughout the United States who must function without bias and prejudice, of the
provisions of the National Labour Relations Act which inhibited an employer from discharging an
employee because of union activities. It was further observed at p. 960 :
"So it is said that any regulation protective of union activities, or the right collectively
to bargain on the part of such employees, is necessarily an invalid invasion of the
freedom of the press. We think that the contention not only has no relevance to the
circumstances of the instant case but is an unsound generalization."
202. Murdock v. Pennsylvania, ([1942] 319 U.S. 105, 136; 87 L.Ed. 1292, 1311), was a case of a
license fee for the sale of religious books and Mr. Justice Frankfurter in his dissenting opinion at p.
1311 observed :
"A tax upon newspaper publishing is not invalid simply because it falls upon the
exercise of a constitutional right. Such a tax might be invalid if it invidiously singled
out newspaper publishing for bearing the burden or taxation or imposed upon them
in such ways as to encroach on the essential scope of a free press. If the Court could
justifiably hold that the tax measures in these cases were vulnerable on that ground, IExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

would unreservedly agree. But the Court has not done so, and indeed could not."
203. In Oklahoma Press Publishing Co. v. Walling ([1945] 327 U.S. 186, 194; 90 L.Ed. 614, 621), and
in Mabee v. White Planis Publishing Co. (1945) 327 U.S. 178; 90 L.Ed. 607 the Federal Fair Labour
Standards Act was held applicable to the press and it was observed in the former case at p. 621 :
"Here there was no singling out of the press for treatment different from that
accorded other business in general. Rather the Act's purpose was to place publishers
of newspapers upon the same plane with other businesses and the exemption for
small newspapers had the same object. Nothing in the Grosjean case ([1935] 297 U.S.
233, 249; 89 L.Ed. 660, 668), forbids congress to exempt some publishers because of
size from either a tax or a regulation which would be valid if applied to all."
204. The Constitution of the United States of America - Analysis and Interpretation - Prepared by
the Legislative Reference Service, Library of Congress, summarises the position thus at p. 792 :
"The Supreme Court, citing the fact that the American Revolution "really began
when......... that Government (of England) sent stamps for newspaper duties to the
American colonies" has been alert to the possible uses of taxation as a method of
suppressing objectionable publications. Persons engaged in the dissemination of
ideas are, to be sure, subject to ordinary forms of taxation in like manner as other
persons. With respect to license or privilege taxes, however, they stand on a different
footing. Their privilege is granted by the Constitution and cannot be withheld by
either State or Federal Government.
..................................
205. "The application to newspapers of the Anti-Trust Laws, the National Labour Relations Act, or
the Fair Labour Standards Act, does not abridge the freedom of the press."
206. The Laws regulating payment of wages have similarly been held as not abridging the freedom
of speech and expression and the following observations in the same publication (at p. 988) in
regard to the Minimum Wage Laws are apposite :
"MINIMUM WAGE LAWS : The theory that a law prescribing minimum wages for
women and children violates due process by impairing freedom of contract was
finally discarded in 1937 (West Coast Hotel Co. v. Parish, 300 U.S. 379). The current
theory of the Court, particularly when labour is the beneficiary of legislation, was
recently stated by Justice Douglas for a majority of the Court, in the following terms :
"Our recent decisions make plain that we do not sit as a super-legislature to weigh the
wisdom of legislation nor to decide whether the policy which it expresses offends the
public welfare..... But the state legislatures have constitutional authority to
experiment with new techniques; they are entitled to their own standard of the public
welfare; they may within extremely broad limits control practices in theExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

business-labor field, so long as specific constitutional prohibitions are not violated
and so long as conflicts with valid and controlling federal laws are avoided (Day-Brite
Lighting, Inc. v. Missouri, 342 U.S. 421, 423 (1952))."
207. While therefore no such immunity from the general law can be claimed by the press it would
certainly not be legitimate to subject the press to laws which take away or abridge the freedom of
speech and expression or which would curtail circulation and thereby narrow the scope of
dissemination of information, or fetter its freedom to choose its means of exercising the right or
would undermine its independence by driving it to seek Government aid. Laws which single out the
press for laying upon it excessive and prohibitive burdens which would restrict the circulation,
impose a penalty on its right to choose the instruments for its exercise or to seek an alternative
media, prevent newspapers from being started and ultimately drive the press to seek Government
aid in order to service, would therefore be struck down as unconstitutional.
208. Such laws would not be saved by Art. 19(2) of the Constitution. This Court had occasion to
consider the scope of Art. 19(2) in Brij Bhushan & Anr. v. The State of Delhi ([1950] S.C.R. 605,
608), where Fazl Ali J. in his dissenting judgment observed at p. 619 :
"It must be recognized that freedom of speech and expression is one of the most
valuable rights guaranteed to a citizen by the Constitution and should be jealously
guarded by the Court. It must also be recognised that free political discussion is
essential for the proper functioning of a democratic government, and the tendency of
the modern jurists is to deprecate censorship though they all agree that "liberty of the
press" is not to be confused with its "licentiousness". But the Constitution itself has
prescribed certain limits and this Court is only called upon to see whether a
particular case comes within those limits."
209. Unless, therefore, a law enacted by the Legislature comes squarely within the provisions of Art.
19(2) it would not be saved and would be struck down as unconstitutional on the score of its
violating the fundamental right of the petitioners under Art. 19(1)(a).
210. In the present case it is obvious that the only justification for the enactment of the impugned
Act is that it imposes reasonable restrictions in the interests of a section of the general public, viz.,
the working journalists and other persons employed in the newspaper establishments. It does not
fall within any of the categories specified in Art. 19(2), viz., "In the interests of the security of the
State, friendly relations with foreign States, public order, decency or morality, or in relation to
contempt of court, defamation or incitement to an offence."
211. Article 19(2) being thus out of the question the only point that falls to be determined by us is
whether the provisions of the impugned Act in any way take away or abridge the petitioners'
fundamental right of freedom of speech and expression.
212. It was contended before us by the learned Attorney-General that it was only legislation directly
dealing with the right mentioned in Art. 19(1)(a) that was protected by it. If the legislation was not aExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

direct legislation on the subject, Art. 19(1)(a) would have no application, the test being not the effect
or result of legislation but its subject-matter. In support of his contention he relied upon the
following observations of Kania C.J. in A. K. Gopalan v. The State of Madras ([1950] S.C.R. 88, 100).
"As the preventive detention order results in the detention of the applicant in a cell it
was contended on his behalf that the rights specified in article 19(1), (a), (b), (c), (d),
(e) and (g) have been infringed. It was argued that because of his detention he cannot
have a free right to speech as and where he desired and the same argument was urged
in respect of the rest of the rights mentioned in sub-clauses (b), (c), (d), (e), and (g).
Although this argument is advanced in a case which deals with preventive detention,
in correct, it should be applicable in the case of punitive detention also to any one
sentenced to a term of imprisonment under the relevant section of the Indian Penal
Code. So considered, the argument must clearly be rejected. In spite of the saving
clauses (2) to (5), permitting abridgment of the rights connected with each of them,
punitive detention under several sections of the Penal Code, e.g., for theft, cheating,
forgery and even ordinary assault, will be illegal. Unless such conclusion necessarily
follows from the article, it is obvious that such construction should be avoided. In my
opinion, such result is clearly not the outcome of the Constitution. The article has to
be read without any pre-conceived notions. So read, it clearly means that the
legislation to be examined must be directly in respect of one of the rights mentioned
in the sub-clauses. If there is a legislation directly attempting the control a citizen's
freedom of speech or expression, or his right to assemble peaceably and without
arms, etc., the question whether that legislation is saved by the relevant saving clause
of article 19 will arise. If, however, the legislation is not directly in respect of any of
these subjects, but as a result of the operation of other legislation, for instance, for
punitive or preventive detention, his right under any of these sub-clauses is abridged,
the question of the application of article 19 does not arise. The true approach is only
to consider the directness of the legislation and not what will be the result of the
detention otherwise valid, on the mode of the detenu's life. On that short ground, in
my opinion, this argument about the infringement of the rights mentioned in article
19(1) generally must fail. Any other construction put on the article, it seems to me,
will be unreasonable."
213. This opinion was expressed by Kania C.J. alone, the other learned judges forming the Bench not
expressing themselves on this question. This passage was, however, cited, with approval by a Bench
of this Court in Ram Singh & Ors. v. The State of Delhi ([1951] S.C.R. 451, 455). It was held by the
Full Court in that case that though personal liberty is sufficiently comprehensive to include the
freedoms enumerated in Art. 19(1) and its deprivation would result in the extinction of these
freedoms, the Constitution has treated these constitutional liberties as distinct fundamental rights
and made separate provisions in Arts. 19, 21 and 22 as to the limitations and conditions subject to
which alone they could be taken away or abridged. Consequently, even though a law which restricts
the freedom of speech and expression is not directed solely against the undermining of security of
the State or its over throw but is concerned generally in the interests of public order may not fall
within the reservation of clause (2) of Art. 19 and may therefore be void, an order of preventiveExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

detention cannot be held to be invalid merely because :
"the detention is made with a view to prevent the making of speeches prejudicial to
the maintenance of public order......
214. This was also a case of detention under the Preventive Detention Act and the detention of the
detenu had been ordered with a view to prevent him from making speeches prejudicial to the
maintenance of public order. Public order was not one of the categories mentioned in Art. 19(2) as it
then stood, and any restriction imposed upon the freedom of speech and expression could not be
justified on that ground, the only relevant ground in that connection then being undermining of the
security of the State or its overthrow. A restriction on the freedom of speech and expression in the
maintenance of public order would therefore not have been justified under Art. 19(2) and if the
Court had come to the conclusion that there was an infringement of the right of freedom of speech
and expression the order could not have been saved under Art. 19(2). The Court, however, took the
view that the direct object of the order was preventive detention and not the infringement of the
right of freedom of speech and expression, which was merely consequential upon the detention of
the detenu and therefore upheld the validity of the order. It was, therefore, urged by the learned
Attorney-General that the object of the impugned Act was only to regulate certain conditions of
service of working journalists and other persons employed in the newspaper establishments and not
to take away or abridge the right of freedom of speech and expression enjoyed by the petitioners and
that therefore the impugned Act could not come within the prohibition of Art. 19(1)(a) read with Art.
13(2) of the Constitution.
215. It was contended, on the other hand, on behalf of the petitioners that the Court has got to look
at the true nature and character of the legislation and judge its substance and not its form, or in
other words, its effect and operation. It was pointed out that the impugned Act viewed as a whole
was one to regulate the employment of the necessary organs of newspaper publications and
therefore related to the freedom of the press and as such came within the prohibition. Reliance was
place in this behalf on the following passage in Minnesota Ex Rel. Olson : ([1930] 283 U.S. 697, 708;
75 L.Ed. 1357, 1363).
"With respect to these contentions it is enough to say that in passing upon
constitutional questions the Court has regard to substance and not to mere matters of
form, and that, in accordance with familiar, principles, the statute must be tested by
its operation and effect."
216. The following observations of Mahajan J. (as he then was) in Dwarkadas Shrinivas of Bombay
v. The Sholapur Spinning and Weaving Co., Ltd. ([1954] S.C.R. 674, 683) were also relied upon :
"In order to decide these issues it is necessary to examine with some strictness the
substance of the legislation for the purpose of determining what it is that the
legislature has really done; the Court, when such questions arise, is not over
persuaded by the mere appearance of the legislation. In relation to Constitutional
prohibitions binding a legislature it is clear that the legislature cannot disobey theExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

prohibitions merely by employing indirect method of achieving exactly the same
result. Therefore, in all such cases the court has to look behind the names, forms and
appearances to discover the true character and nature of the legislation."
217. The impugned Act is as its long title shows an act to regulate certain conditions of service of
working journalists and other persons employed in newspaper establishments and in the very
forefront of the Act, the Industrial Disputes Act, 1947, is by s. 3 made applicable to working
journalists with certain modification in connection with the application of s. 25F of that Act. The
rest of the provisions contained in ch. II concerned themselves with the payment of gratuity, hours
of work and leave and fixation of wages of the working journalists. The regulation of the conditions
of service is thus the main object which is sought to be achieved by the impugned Act. Chapter III of
the Act applies the provisions of the Industrial Employment (Standing Orders) Act, 1946, and the
Employees' provident Funds Act, 1952, to all the employees of the newspaper establishments
wherein twenty or more newspaper employees are employed and covers working journalists as well
as other employees in the employ of the newspaper establishments. The miscellaneous provisions
contained in ch. IV are designed merely to implement or to carry out the provisions of the main part
of the Act and they do not make any difference so far as the effect and operation of the Act is
concerned. If this is the true nature of the Act, it is impossible to say that the Act was designed to
affect the freedom of speech and expression enjoyed by the petitioners or that, that was its necessary
effect and operation. It was conceded in the course of the arguments that if a general law in regard
to the industrial or labour relations had been applied to the press industry as a whole no exception
could have been taken to it. If the matter had rested with the application of the Industrial Disputes
Act. 1947, to the working journalists or with the application of the Industrial Employment (Standing
Orders) Act, 1946, or the Employees' Provident Funds Act, 1952, to them no exception could have
been taken to this measure. It was, however, urged that apart from the application of these general
laws to the working journalists, there are provisions enacted in the impugned Act in relation to
payment of gratuity, hours of work, leave and fixation of the rates of wages which are absolutely
special to the press industry qua the working journalists and they have the effect of singling out the
press industry by creating a class of privileged workers with benefits and rights which have not be
conferred upon other employees and the provisions contained therein have the effect of laying a
direct and preferential burden on the press, have a tendency to curtail the circulation and thereby
narrow the scope of dissemination of information, fetter the petitioners; freedom to choose the
means of exercising their right and are likely to undermine the independence of the press by having
to seek Government aid.
218. It is obvious that the enactment of this measure is for the amelioration of the conditions of the
workmen in the newspaper industry. It would not be possible for the State to take up all the
industries together and even as a matter of policy it would be expedient to take the industries one by
one. Even in regard to the workmen employed it would be equally expedient to take a class of
employees who stand in a separate category by themselves for the purpose of benefiting them in the
manner contemplated. This circumstance by itself would therefore not be indicative of any undue
preference or a prejudicial treatment being meted out to that particular industry, the main object
being the amelioration of the conditions of those workmen. It could not also be said that there was
any ulterior motive behind the enactment of such a measure because the employers may have toExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

share a greater financial burden than before or that the working of the industry may be rendered
more difficult than before. These are all incidental disadvantages which may manifest themselves in
the future working of the industry, but it could not be said that the Legislature in enacting that
measure was aiming at these disadvantages when it was trying to ameliorate the conditions of the
workmen. Those employers who are favourably situated, may not feel the strain at all while those of
them who are marginally situated may not be able to bear the strain and may in conceivable cases
have to disappear after closing down their establishments. That, however, would be a consequence
which would be extraneous and not within the contemplation of the Legislature. It could therefore
hardly be urged that the possible effect of the impact of these measures in conceivable cases would
vitiate the legislation as such. All the consequences which have been visualized in this behalf by the
petitioners, viz., the tendency to curtail circulation and thereby narrow the scope of dissemination of
information, fetters on the petitioners' freedom to choose the means of exercising the right,
likelihood of the independence of the press being undermined by having to seek government aid; the
imposition of penalty on the petitioners' right to choose the instruments for exercising the freedom
or compelling them to seek alternative media, etc., would be remote and depend upon various
factors which may or may not come into pay. Unless these were the direct or inevitable
consequences of the measures enacted in the impugned Act, it would not be possible to strike down
the legislation as having that effect and operation. A possible eventuality of this type would not
necessarily be the consequence which could be in the contemplation of the legislature while enacting
a measure of this type for the benefit of the workmen concerned.
219. Even though the impugned Act enacts measures for the benefit of the working journalists who
are employed in newspaper establishments, the working journalists are but the vocal organs and the
necessary agencies for the exercise of the right of free speech and expression, and any legislation
directed towards the amelioration of their conditions of service must necessarily affect the
newspaper establishments and have its repercussions on the freedom of Press. The impugned Act
can therefore be legitimately characterized as a measure which affects the press, and if the intention
or the proximate effect and operation of the Act was such as to bring it within the mischief of Art.
19(1)(a) it would certainly be liable to be struck down. The real difficulty, however, in the way of the
petitioners is that whatever be the measures enacted for the benefit of the working journalists
neither the intention nor the effect and operation of the impugned Act is to take away or abridge the
right of freedom of speech and expression enjoyed by the petitioners.
220. The gravamen of the complaint of the petitioners against the impugned Act, however, has been
the appointment of the Wage Board for fixation of rates of wages for the working journalists and it is
contended that apart from creating a class of privileged workers with benefits and rights which were
not conferred upon other employees of industrial establishments, the Act has left the fixation of
rates of wages to an agency invested with arbitrary and uncanalised powers to impose an
indeterminate burden on the wage structure of the press, to impose such employer-employee
relations as in its discretion it thinks fit and to impose such burden and relations for such time as it
thinks proper. This contention will be more appropriately dealt with while considering the alleged
infringement of the fundamental right enshrined in Art. 19(1)(g). Suffice it to say that so far as Art.
19(1)(a) is concerned this contention also has a remote bearing on the same and need not be
discussed here at any particular length.Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

221. Re : Article 19(1)(g).
222. The fundamental right of the petitioners herein is the right to carry on any occupation, trade or
business.
223. This freedom also is hemmed in by limitations which are to be found in Art. 19(6), which in so
far as it is relevant for our purposes enacts :
"Nothing in sub-clause (g) of the said clause shall affect the operation of any existing
law in so far as it imposes, or prevent the State from making any law imposing, in the
interests of the general public, reasonable restrictions on the exercise of the right,
conferred by the said sub-clause."
224. The contention under this head is thus elaborated on behalf of the petitioners :
1. The impugned Act imposes unreasonable restrictions on the freedom to carry on
business :
(a) in empowering the fixation of rates of wages on criteria relevant only for fixation
of minimum wages;
(b) in empowering fixation of wages, grant of gratuity and compensation without
making it incumbent on the Board to consider the major factor of the capacity of the
industry to pay;
(c) in authorizing the Board to have regard to not what is relevant for such fixation
but to what the Board deems relevant for the purpose; and
(d) in providing for a procedure which does not compel the Board to conform to the
rules under the Industrial Disputes Act, 1947, thus permitting the Board to follow any
arbitrary procedure violating the principle of audi alteram partem.
2. The restrictions enumerated above in so far as they affect the destruction of the petitioners'
business exceed the bounds of permissible legislation under Art. 19(1)(g).
225. The unreasonableness of the restriction is further sought to be emphasized by pointing out that
under s. 12 of the impugned Act, the decision of the Board is declared binding on all employers,
though the working journalists are not bound by the same and are entitled, if they are dissatisfied
with it, to agitate for further revision by raising industrial disputes between themselves and their
employers and having them adjudicated under the Industrial Disputes Act, 1947.
226. The test of reasonable restrictions which can be imposed on the fundamental right enshrined in
Art. 19(1)(g) has been laid down by this Court in two decisions :Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

In Chintaman Rao v. The State of Madhya Pradesh ([1950] S.C.R. 759, 763) Mahajan
J. (as he then was) observed at p. 763 :-
"The phrase "reasonable restriction" connotes that the limitation imposed on a
person in enjoyment of the right should not be arbitrary or of an excessive nature,
beyond what is required in the interests of the public. The word "reasonable" implies
intelligent care and deliberation, that is, the choice of a course which reason dictates.
Legislation which arbitrarily or excessively invades the right cannot be said to contain
the quality of reasonableness and unless it strikes a proper balance between the
freedom guaranteed in article 19(1)(g), and the social control permitted by clause (6)
of article 19, it must be held to be wanting in that quality." [cited with approval in
Dwarka Prasad Laxmi Narain v. The State of Uttar Pradesh & Ors. ([1954] S.C.R.
803, 811) and in Ch. Tika Ramji v. State of Uttar Pradesh & Ors. ([1956] S.C.R. 393,
446)].
227. The State of Madras v. V. G. Rao ([1952] S.C.R. 597, 606, 607) was the next case in which this
phrase came to be considered by this Court and Patanjali Sastri C.J. observed at p. 606 :-
"This Court had occasion in Dr. Khare's case ([1950] S.C.R. 519) to define the scope of
the judicial review under clause of (5) of Art. 19 where the phrase "imposing
reasonable restriction on the exercise of the right" also occurs and four of the five
judges participating in the decision expressed the view (the other judge leaving the
question open) that both the substantive and the procedural aspects of the impugned
restrictive law should be examined from the point of view of reasonableness : that is
to say, the Court should consider not only factors such as the duration and the extent
of the restrictions but also the circumstances under which and the manner in which
their imposition has been authorised. It is important in this context to bear in mind
that the test of reasonableness, where-ever prescribed, should be applied to each
individual statute impugned, and no abstract standard, or general pattern, of
reasonableness can be laid down as applicable to all cases. The nature of the right
alleged to have been infringed, the underlying purpose of the restrictions imposed,
the extent and urgency of the evil sought to be remedied thereby, the disproportion of
the imposition, the prevailing conditions at the time, should all enter into the judicial
verdict."
228. This criterion was approved of in State of West Bengal v. Subodh Gopal Bose & Others ([1954]
S.C.R. 587, 626) where the present Chief Justice further expressed his opinion that the fact of the
statute being given retrospective operation may also be properly taken into consideration in
determining the reasonableness of the restriction imposed in the interest of the general public [see
also a recent decision of this Court in Virendra v. State of Punjab ([1958] S.C.R. 308)].
229. The appointment of a wage board for the purposes of fixing rates of wages could not be and was
not challenged as such because the constitution of such wages boards has been considered one of the
appropriate modes for the fixation of rates of wages. The Industrial Disputes Act, 1947, can onlyExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

apply when an industrial dispute actually arises or is apprehended to arise between the employers
and the employees in a particular industrial establishment. Though under the amendment of that
Act by the Industrial Disputes (Amendment and Miscellaneous Provisions) Act, 1956, (36 of 1956),
there is a provision for the appointment of a National Tribunal by the Central Government for the
adjudication of industrial disputes which in the opinion of the Central Government involve
questions of national importance or are of such a nature that industrial establishments situated in
more than one State are likely to be interested in, or affected by, such dispute (Vide s. 7-B) the
condition precedent, however, is the existence of an industrial dispute or the apprehension of one. If
the wages for the employees of a particular industry have got to be fixed without such an industrial
dispute having arisen or being apprehended to arise, the only proper mode of such fixation would be
the appointment of wage boards for the purpose. They take the place of Industrial Tribunals or
National Industrial Tribunals and are generally constituted of equal number of representatives of
the employers and the employees in that particular industry along with a quota if independent
member or members one of whom is appointed the chairman of the Board.
230. The main grievance of the petitioners, however, has been that the relevant criteria for the
fixation of rates of wages were not laid down in s. 9 of the Act. Section 8 empowered the Central
Government to constitute a wage board for fixing rates of wages in respect of working journalists in
accordance with the provisions of the Act and s. 9 directed that in fixing such rates of wages the
Board shall have regard to the cost of living, the prevalent rates of wages for comparable
employments, the circumstances relating to the newspaper industry in different regions of the
country and to any other circumstances which to the Board may seem relevant. These criteria, it was
contended, were only relevant for fixing minimum rates of wages, though the word "minimum"
which had been used in the Bill No. 13 of 1955 as introduced in the Rajya Sabha was deleted when
the Act actually came to be passed and it was further contended that the capacity of the Industry to
pay which was an essential circumstance to be taken into consideration in the fixation of wages was
not set out as one of the circumstances to be taken into consideration by the Board in fixing rates of
wages. It was also contended that the other circumstances which the Board was directed to consider
in addition to those specifically enumerated in s. 9(1) were such as to the Board may seem relevant
thus relegating these circumstances to the subjective determination of the Board with the necessary
consequence that no Court or other authority could scrutinize the same objectively.
231. We do not propose to enter into any elaborate discussion on the question whether it would be
competent to us in arriving at a proper construction of the expression "fixing rates of wages" to look
into the Statement of Objects and Reasons attached to the Bill No. 13 of 1955 as introduced in the
Rajya Sabha or the circumstances under which the word "minimum" came to be deleted from the
provisions of the Bill relating to rates of wages and the Wage Board and the fact of such deletion
when the Act came to be passed in its present form. There is a consensus of opinion that these are
not aids to the construction of the terms of the Statute which have of course to be given their plain
and grammatical meaning [See : Ashvini Kumar Ghosh & Anr. v. Arabinda Bose & Anr. ([1953]
S.C.R. 1) and Provat Kumar Kar and others v. William Trevelyan Curtiez Parkar . It is only when the
terms of the statute are ambiguous or vague that resort may be had to them for the purpose of
arriving at the true intention of the legislature. No such reference is, however, necessary in the case
before us, even though perchance, the expression "fixing rates of wages" be considered ambiguous inExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

so far as it does not specify whether the "wages" there are meant to be "living wages", "fair wages",
or "minimum wages". We have already stated in the earlier part of this judgment that the Act was
passed with a view to implement the recommendations of the Press Commission's Report and we
have already seen that the concept of minimum wage, as adopted by the Press commission was to
that of a bare subsistence or minimum wage but what it termed a minimum wage was meant to
provide for not merely the bare subsistence of living, but for the efficiency of the worker, making
provision also for some measure of education, medical requirements and amenities. If this was the
concept of a minimum wage which the Legislature set about to implement, that minimum was
certainly higher than the bare subsistence or minimum wage, and, in any event, required a
consideration by the Wages Board of the capacity of the industry to pay, even though the Press
Commission itself did not think it necessary, to do so, it having expressed the opinion that if a
newspaper industry could not afford to pay to its employees a minimum wage which would enable
them to live decently and with dignity, that newspaper had no right to exist.
232. This was the concept of a minimum wage which was sought to be implemented by the
legislature and for that purpose the capacity of the industry to pay was an essential circumstance to
be taken into consideration and the deletion of the word "minimum", if at all, had the effect of
widening the scope of the enquiry before the Wage Board. If the word "minimum" had been used in
relation to the rates of wages and the Wage Board in the impugned Act, the Wage Board in its
deliberations would have been necessarily confined to a consideration of that aspect alone. But, by
the deletion of that word from the context the Wage Board was invested with a power to determine
the question of the fixation of rates of wages unfettered by any such limitations and to fix the rates of
wages in any proper manner having regard to the circumstances of the case, whether the resultant
wages would be a statutory minimum wage or would approximate to a standard of wage, though
having regard to the economic conditions of our country at present they could not find it within
their power to fix living wages for the working journalists. The criteria which were specified in s.
9(1); of the Act comprised also the prevalent rates of wages for comparable employments. This
criterion had no relation whatever to minimum wages. Reference may be made in this connection to
a decision of the Industrial Court in the case of Nellimarla Jute Mills ([1953] 1 L.L.J. 666), where it
was held that the comparison with rates of wages in other concerns, could be undertaken for
determining fair wage and the upper limit of wages but not for determining the minimum or floor
level of wages which should depend on the minimum requirements of the workers' family consisting
of three consumption units. This criterion was no doubt taken into consideration by the members of
the Committee on Fair Wages as also by the Press Commission and even though the Press
Commission considered that to be an essential ingredient of the minimum wage as contemplated by
it, we are not inclined to stress that circumstance so much and come to the conclusion that what was
contemplated in s. 9(1) was merely a minimum wage and no other.
233. If, therefore, the criterion of the prevalent rates of wages for comparable employments can on a
true construction of s. 9(1) be considered consistent only with the fixation of rates of wages which
are higher than the bare subsistence or minimum wage whether they be statutory minimum wage or
fair wage or even living wage, it could not be urged that the criteria, specified in s. 9(1) of the Act
were relevant only for fixation of minimum wages. The capacity of the industry to pay was therefore
one of the essential circumstances to be taken into consideration by the Wage Board whether it beExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

for the fixation of rates of wages or the scales of wages which, as we have observed before, were
included within the expression "rates of wages". This was by no means an unimportant
circumstance which could be assigned a minor role. It was as important as the cost of living, and the
prevalent rates of wages for comparable employments and ought to have been specifically
mentioned in s. 9(1). The Legislature however, was either influenced in not maintaining it as such by
reason of the view taken by the Press Commission in that behalf or thought that the third criterion
which was specified in s. 9(1), viz., the circumstances relating to the newspaper industry in different
regions of the country was capable of including the same. Even here, there is considerable difficulty
in reconciling oneself to this mode of construction. The capacity of the industry to pay, can only be
considered on an industry-cum-region basis and this circumstance from that point of view would be
capable of being included in this criterion, viz., the circumstances relating to the newspaper industry
in different regions of the country. Even if it were thus capable of being included, the minor role
assigned to it along with literacy of the population, the popularity of the newspapers, predilections
of the population in the matter of language and other circumstances of the like nature prevailing in
the different regions of the country would make it difficult to imagine that this circumstance of the
capacity of the industry to pay was really in the mind of the Legislature, particularly when it is
remembered that the Press Commission attached no significance to the same. From that point of
view, the criticism of the petitioners would appear to be justified, viz., :- that it was not made
incumbent on the Board to consider the major factor of the capacity of the industry to pay as an
essential circumstance in fixing the rates of wages. It is, however, well-recognized that the Courts
would lean towards the constitutionality of an enactment and if it is possible to read this
circumstance as comprised within the category of circumstances relating to the newspaper industry
in different regions of the country, the court should not strike down the provisions as in any manner
whatever unreasonable and violative of the fundamental right of the petitioners.
234. We are therefore of opinion that s. 9(1) did not eschew the consideration of this essential
circumstance, viz., the capacity of the industry to pay and it was not only open but incumbent upon
the Wage Board to consider that essential circumstance in order to arrive at the fixation of the rates
of wages of the working journalists.
235. The last criterion enumerated in s. 9(1) of the Act was "any other circumstance which to the
Board may seem relevant" and it was urged that this was left merely to the subjective determination
of the Board and the Board was at liberty to consider the circumstances, if any, falling within this
category in its own absolute discretion which could not be controlled by any higher authority. If the
matters were left to be objectively determined then it would certainly be enquired into and the
existence or otherwise of such circumstances would be properly scrutinized in appropriate
proceedings. The manner in which, however, this criterion was left to be determined by the Board
on its subjective satisfaction was calculated to enable the Board to exercise arbitrary powers in
regard to the same and that was quite unreasonable in itself. The case of Thakur Reghubir Singh v.
Court of Wards, Ajmer & Ors. ([1953] S.C.R. 1049, 1052), was pointed out as an illustration of such
an arbitrary power having been vested in the Court of Wards which could in its own discretion and
on its subjective determination assume the superintendence of the property of a landed proprietor
who habitually infringed the rights of his tenants. The provision was there struck down because such
subjective determination which resulted in the superintendence of the property of a citizen beingExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

assumed could not be scrutinized and the propriety thereof investigated by higher authorities.
236. This argument, however, does not help the petitioners because this criterion is on a par with or
ejusdem generis with the other criteria which have been specifically enumerated in the earlier part
of the section. The major and important criteria have been specifically enumerated and it would be
impossible for the Legislature exhaustively to enumerate the other circumstances which would be
relevant to be considered by the Board in arriving at the fixation of the rates of wages. In the course
of the enquiry the Board might come across other relevant circumstances which would weigh with it
in the determination of the rates of wages and it would not be possible for the Legislature to think of
them or to enumerate the same as relevant considerations and it was therefore, and rightly in our
opinion, left to the Board to determine the relevancy of those circumstances and take them into
consideration while fixing the rates of wages. If the principles which should guide the Board in fixing
the rates of wages were laid down with sufficient clarity and particularity and the criteria so far as
they were of major importance were specifically enumerated there was nothing wrong in leaving
other relevant considerations arising in the course of the enquiry to the subjective satisfaction of the
Board. The Board was, after all, constituted of equal numbers of representative of employers and the
employees and they were best calculated to take into account all the relevant circumstances apart
from those which were specifically enumerated in the section.
237. It was, however, contended that the procedure to be followed by the Board for fixing the rates
of wages was not laid down and it was open to the Board to follow any arbitrary procedure violating
the principle of audi alteram partem and as such this also was unreasonable. Section 20(2)(d) of the
impugned Act gave power to the Central Government to make rules inter alia in regard to the
procedure to be followed by the Board in fixing rates of wages and s. 11 provided that subject to any
rules which might be prescribed the Board may, for the purpose of fixing rates of wages, exercise the
same powers and follow the same procedure as an Industrial Tribunal constituted under the
Industrial Disputes Act, 1947, exercises or follows for the purpose of adjudicating an industrial
dispute referred to it. This was, however, an enabling provision which vested in the Board the
discretion whether to exercise the same powers and follow the same procedure as an Industrial
Tribunal. The Board was at liberty not to do so and follow its own procedure which may be arbitrary
or violative of the principle of audi alteram partem.
238. It has to be remembered, however, that in the United Kingdom the Wage Councils and the
Central Co-ordinating Committees under the Wages Councils Act, 1945, and the Agricultural Wages
Board under the Agricultural Wages Regulations Act, 1924, also are empowered to regulate their
proceeding in such manner as they think fit. The Wage Boards in Australia have also no formal
procedure prescribed for them, though the Wage Boards which are established under the amended
Bombay Industrial Relations Act, 1946, are enjoined to fallow the same procedure as an industrial
court in respect of industrial proceedings before it. It would not therefore be legitimate to hold that
the procedure to be followed by the wage board for fixing rates of wages must necessarily be
prescribed by the statute constituting the same. It is no doubt contemplated in each of these statutes
that rules of procedure may be prescribed; but even though they may be so prescribed, it is left to
the discretion of the wage boards to regulate their procedure in such manner as they think fit,
subject of course to the rules thus prescribed. A wide discretion is thus left with the wage boards toExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

prescribe their own rules of procedure, but it does not therefore follow that they are entitled to
follow any arbitrary rules of procedure. The wage boards are responsible bodies entrusted with the
tax of gathering data and materials relevant for the determination of the issues arising before them
and even though they are not judicial tribunals but administrative agencies they would elicit all
relevant information and invite answers to the questionnaire or representations from the parties
concerned, hear evidence and arrive at their determination after conforming to the principles of
natural justice. Even though they may perform, quasi-judicial functions, the exercise of arbitrary
powers by them would not be countenanced by any court or higher authority.
239. In the present case, however, we have in the forefront of the impugned Act a provision as to the
application of the Industrial Disputes Act, 1947, to working journalists. No doubt certain specific
provisions as to payment of gratuity, hours of work and leave are specifically enacted, but when we
come to the fixation of rates of wages we find that a wage board has been constituted for the
purpose. The principles to be followed by the Wage Board for fixing rates of wages are also laid
down and the decision of the Board is to be published in the same manner as awards of industrial
courts under the Industrial Disputes Act. Then follows s. 11 which talks of the powers and procedure
of the Board and there also, subject to any rules of procedure which may be prescribed by the
Central Government, the Board is empowered to exercise the same powers and follow the same
procedure as an Industrial Tribunal constituted under the Industrial Disputes Act. If regard be had
to this provision it is abundantly clear that the intention of the legislature was to assimilate the
Wage Board thus constituted as much as possible to an Industrial Tribunal constituted under the
Industrial Disputes Act, 1947, and it was contemplated that the Board may for fixing rates of wages
exercise the same powers and follow the same procedure. The Decision of the Board was to be
binding on all the employers, though the working journalists were at liberty to further agitate the
question under the Industrial Disputes Act if they were not satisfied with the decision of the Wage
Board and wanted a further increase in their rates of wages, thus determined. All these
circumstances point to the conclusion that even though the Board was not bound to exercise the
same powers and follow the same procedure as an industrial tribunal constituted under the
Industrial Disputes Act, the Board was, in any event, not entitled to adopt any arbitrary procedure
violating the principles of natural justice.
240. If on the construction of the relevant sections of the statute the functions which the Wage
Board was performing would be tantamount to laying down a law or rule of conduct for the future so
that all the employers and the employees in the industry not only those who were participating in it
in the present but also those who would enter therein in the future would be bound by it, the dictum
of Justice Holmes would apply and the functions performed by the wage board could be
characterised as legislative in character. Where, however, as in the present case, the constitution of
the Wage Board is considered in the background of the application of the provisions of the
Industrial Disputes Act to the working journalists and the provisions for the exercise of the same
powers and following the same procedure as an industrial tribunal constituted under the Industrial
Disputes Act, it would be possible to argue that the Wage Board was not exercising legislative
functions but was exercising functions which were quasi-judicial in character.Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

241. In this connection, it was also pointed out that the Legislature itself while enacting the
impugned Act did not consider these functions as legislative at all. The Rules of Procedure and
Conduct of Business in Lok Sabha (1957) provide in Rule No. 70 for a Bill involving proposals for the
delegation of legislative power shall further be accompanied by a memorandum explaining such
proposals and drawing attention to their scope and stating also whether they are of normal or
exceptional character. There is also a committee on subordinate legislation which is established for
scrutinizing and reporting to the House whether the powers to made regulations, rules, sub-rules,
by-laws, etc., conferred by the Constitution or delegated by Parliament are being properly exercised
within such delegation (vide Rule 317 ibid). The constitution by the Legislature of the Wages Board
in the matter of the fixation of rates of wages was not considered as a piece of delegated legislation
in the memorandum regarding delegated legislation appended to the draft Bill No. 13 of 1955
introduced in the Rajya Sabha on September 28, 1955, and the only reference that was made there
was to Clause 19 of the Bill which empowered the Central Government to make rules in respect of
certain matters specified therein and it was stated that these were purely procedural matters of a
routine character an related inter alia to prescribing hours of work, payment of gratuity, holidays,
earned leave or other kinds of leave and the procedure to be followed by the Minimum Wages Board
in fixing minimum wages and the manner in which its decisions may be published. Clause 19(3) of
the Bill further provided that all rules made under this section shall as soon as practicable after they
are made, be laid before both Houses of Parliament. These clauses were ultimately passed as s. 20 of
the Impugned Act but they were the only piece of delegated legislation contemplated by the
Legislature and were covered by the memorandum regarding the same which was appended to the
Bill. The decision of the Wage Board was not to be laid before both the Houses of Parliament which
would have been the case if the fixation of rates of wages was a piece of delegated legislation. It was
only to be published by the Central Government after it was communicated to it by the Wage Board
in such manner as the Central Government thought fit, a provision which was akin to the
publication of awards of the industrial Tribunals by the appropriate Government under the
provisions of the Industrial Disputes Act, 1947. This circumstance also was pointed out as indicative
of the intention of the Legislature not to constitute the Wage Board a sub-legislative authority.
While recognising the force of these contentions we may observe that it is not necessary for our
purposes to determine the nature and character of the functions performed by the Wage Board here.
It is sufficient to say that the Wage Board was not empowered or authorized to adopt any arbitrary
procedure and flout the principles of natural justice.
242. It was next contended that the restrictions imposed on newspaper establishments under the
terms of the impugned Act were unreasonable in so far as they would have the effect of destroying
the business of the petitioners and would therefore exceed the bounds of permissible legislation
under Art. 19(6). It was urged that the right to impose reasonable restrictions on the petitioners'
right to carry on business did not empower the legislature to destroy the business itself and reliance
was placed in support of this proposition on Stone v. Farmers Loan and Trust Co. ([1885] 116 U.S.
307, 331; 29 L.Ed. 636, 644), where it was observed :-
"From what has thus been said it is not to be inferred that this power of limitation or
regulation is itself without limit. This power to regulate is not a power to destroy, and
limitation is not the equivalent of confiscation."Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

243. Similar observations of Judicial Committee of the Privy Council in the Municipal Corporation
of the City of Toronto v. Virgo ([1896] A.C. 88, 93 (J.C.)) and the Attorney General for Ontario v.
Attorney General for the Dominion ([1896] A.C. 348, 363) were also relied upon and particularly the
following observations in the former case :-
"But their Lordships think there is a marked distinction to be drawn between the
prohibition or prevention of a trade and the regulation or governance of it and indeed
a power to regulate and govern seems to imply the continued existence of that which
is sought to be regulated or governed."
244. These observations were considered by this Court in Saghir Ahmed v. State of U.P. & Ors. and
after considering the various cases which were cited by both sides, this Court observed :
"Be that as it may, although in our opinion the normal use of the word "restriction"
seems to be in the sense of "limitation" and not "extinction", we would on this
occasion prefer not to express any final opinion on this matter" and the Court
ultimately wound up by saying that "whether the restrictions are reasonable or not
would depend to a large extent on the nature of the trade and the conditions
prevalent in it."
245. Even if the provisions of the impugned Act would not necessarily have the effect of destroying
the business of the petitioners but of crippling it and making it impossible for the petitioners to
continue the same except under onerous conditions, they would have the effect of curtailing their
circulation and drive them to seek government aid and thereby impose an unreasonable burden on
their right to carry on business and would come within the ban of Art. 19(1)(g) read with Art. 13(2)
of the Constitution.
246. Several provisions of the impugned Act were referred to in this context. Section 2(f) of the Act
which defines "working journalist" so as to include "proofreader" was pointed out in this connection
and it was urged that even though the Press Commission Report recommended the exclusion of
certain class of proof-readers from the definition of working journalists the Legislature went a step
further and included all proof-readers within that definition thereby imposing upon the newspaper
establishments an unreasonable burden far in excess of what they were expected to bear. The
provision as to the notice in relation to the retrenchment of working journalist was also extended
beyond the limitations specified in s. 25F of the Industrial Disputes Act, 1947, and was extended to
six months in the case of an Editor and three months in the case of any other working journalist.
The provision with regard to retrenchment was also made applicable retrospectively to all cases of
retrenchment which had occurred between July 14, 1954, and March 12, 1955; so also the payment
of gratuity was ordered not only in the cases usually provided for but also in cases where a working
journalist who had been in continuous service for not less than three years voluntarily resigned from
service from a newspaper establishment. The hours of work prescribed were 144 hours only during
any period of four consecutive weeks and they were far less in number than the hours of work
recommended by the Press Commission Report. The fixation of rates of wages was entrusted to the
Wage Board which could fix any wages which it thought proper irrespective of the capacity of theExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

industry to pay and might be such as the industry could not bear. These provisions taken each one
by itself may not have the effect of destroying the petitioners' business altogether or even crippling it
in the manner indicated but taken cumulatively along with the provisions contained in ss. 14 and 15
of the impugned Act which applied the provisions of the Industrial Employment (Standing Orders)
Act, 1946, and the Employees' Provident Funds Act, 1952, to newspaper establishments would
certainly bring about that result and would therefore constitute an unreasonable restriction on the
petitioners' right to carry on business.
247. We shall deal with these contentions one by one.
248. There is no doubt that "proof-readers" were not all recommended by the Press Commission to
be included in the definition of working journalists, but it has to be remembered that proof-readers
occupy a very important position in the editorial staff of a newspaper establishment. B. Sen Gupta in
his "Journalism as a Career" (1955) talks of the position of the proof-reader as follows :
"The proof-reader is another important link in the production of a newspaper. On
him depends, not to a small extent, the reputation of a paper. He has to be very
careful in correcting mistakes and pointing out any error of fact or grammar that has
crept into any news item or article through oversight or hurry on the part of the
sub-editor. He has not only to correct mistakes but also to see that corrections are
carried out", and the Kemsley Manual of Journalism has the following passage at p.
337 :
"Having thus seen the proof-reader in action, let us consider in detail what
proof-reading denotes. It is primarily the art and practice of finding mistakes in
printed matter before publication and of indicating the needed corrections. It
includes the detection of variations between the type and the copy from which it was
set, mis-statements of facts, figures or dates, errors in grammar, inaccuracies in
quotations, and other defects. Often, too, it happens that, though the proof-reader
does not feel justified in himself making a correction, he takes other action. If he
thinks there is a mistake but is not sure, he must query the proof so that the editorial
staff may decide. He may spot a libel, or think he has. In either case it is important
that the matter shall be queried and passed back to editorial authority.
"It is obvious from this that proof-readers should be men of exceptional knowledge
and sound-judgment. They should be conversant with current affairs, familiar with
names of public men and quite sure how they should be spelled. Some specialize in
different branches of sport, others in theatre, the cinema, music and so on. This saves
much time in looking up books of reference, though, of course, the books are there."
249. As a matter of fact, the Wage Board in the Schedule to its decision defines "proof reader" as "a
person who checks up printed matter or "Proof" with edited copy to ensure strict conformity of the
former with the latter. Factual discrepancies, slips of spelling, grammar and syntax may also be
discovered by him and either corrected or get them corrected."Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

250. If this is the important role played by the proofreaders then no wonder that the Legislature in
spite of the recommendations of the Press Commission included them also in the definition of
working journalist. No doubt they would be entitled to higher wages by reason of the fixation of
rates of wages by the Wage Board but that would by itself be no ground for holding the inclusion of
proof-readers within the definition of working journalist an unreasonable burden on newspaper
establishments.
251. The provisions in regard to notice cannot be said to be per se unreasonable. Apart from the
recommendations of the Press Commission in that behalf, Halsbury's Laws of England, Vol. 22, 2nd
Edn., p. 150, para. 249, foot note (e), contains the following statement in regard to the periods of
reasonable notice to which persons of various employments have been found entitled :-
252. Newspaper editor, from six months (Fox-Bourne v. Vernon & Co. Ltd., (1894) 10 T.L.R. 647); to
twelve months (Grundy v. Sun Printing and Publishing Association, (1916) 33 T.L.R. 77, C.A.).
253. Sub-editor of a newspaper, six months (Chamberlain v. Bennett, (1892) 8 T.L.R. 234).
254. Foreign correspondent to The Times, six months period (Lowe v. Walter, (1892) 8 T.L.R. 358).
255. The Press Commission also recommended that the period of notice for the termination of
services should be based on the length of the service rendered and the nature of the appointment.
There could be no hard and fast rule as to what the notice period should be. The practice upheld by
law or by collective bargaining varies from country to country. In England the practice established
by some judicial decisions is that the editor is entitled to a year's notice and an assistant editor to six
months' notice. After examining the provisions in regard to notice which are in vogue in England,
the Commission also noticed a decision in Bombay (Suit No. 735 of 1951 in the City Civil Court)
where the judge concerned held that in the circumstances of the particular case the plaintiff, an
assistant editor was entitled to a notice of four months although in normal times, he said, the rule
adopted in England of six months should be the correct rule to adopt in India and a longer period of
notice was suggested for editors because it was comparatively much more difficult to secure another
assignment for a journalist of that seniority and standing in the profession.
256. The period of six months, in the case of an editor, and three months, in the case of any other
working journalists prescribed under s. 3(2) of the impugned Act was therefore not open to any
serious objection.
257. The retrospective operation of this provision in regard to the period between July 14, 1954, and
March 12, 1955, was designed to meet the few cases of those employees in the editorial staff of the
newspaper establishments who had been retrenched by the managements anticipating the
implementation of the recommendations of the Press Commission. There was nothing untoward in
that provision also.
258. When we come however to the provision in regard to the payment of gratuity to working
journalists who voluntarily resigned from service from newspaper establishments, we find that thisExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

was a provision which was not at all reasonable. A gratuity is a scheme of retirement benefit and the
conditions for its being awarded have been thus laid down in the Labour Court decisions in this
country.
259. In the case of Ahmedabad Municipal Corporation ([1955] L.A.C. 55, 58) it was observed at p.
158 :-
"The fundamental principle in allowing gratuity is that it is a retirement benefit for
long services, a provision for old age and the trend of the recent authorities as borne
out from various awards as well as the decisions of this Tribunal is in favour of
double benefit.... We are, therefore, of the considered opinion that Provident Fund
provides a certain measure of relief only and a portion of that consists of the
employees' wages, that he or his family would ultimately receive, and that this
provision in the present day conditions in wholly insufficient relief and two
retirement benefits when the finances of the concern permit ought to be allowed."
(See also Nundydroog Mines Ltd. ([1956] L.A.C. 265, 267)).
260. These were cases however of gratuity to be allowed to employees on their retirement. The
Labour Court decisions have however awarded gratuity benefits on the resignation of an employee
also. In the case of Cipla Ltd. ([1955] 2 L.L.J. 355, 358), the Court took into consideration the
capacity of the concern and other factors therein referred to and directed gratuity on full scale...
which included... (2) on voluntary retirement or resignation of an employee after 15 years
continuous service.
261. Similar considerations were imported in the case of the Indian Oxygen & Acetylene Co., Ltd.
([1956] 1 L.L.J. 435), where it was observed :
"It is now well-settled by a series of decisions of the Appellate Tribunal that where an
employer company has the financial capacity the workmen would be entitled to the
benefit of gratuity in addition to be benefits of the Provident Fund. In considering the
financial capacity of the concern what has to be seen is the general financial stability
of the concern. The factors to be considered before granting a scheme of gratuity are
the broad aspects of the financial condition of the concern, its profit earning capacity,
the profit earned in the past, its reserves and the possibility of replenishing the
reserves, the claim of capital put having regard to the risk involved, in short the
financial stability of the concern.
262. There also the court awarded gratuity under ground No. 2, viz., on retirement or resignation of
an employee after 15 years of continuous service and 15 months' salary or wage.
263. It will be noticed from the above that even in those cases where gratuity was awarded on the
employee's resignation from service, it was granted only after the completion of 15 years continuous
service and not merely on a minimum of 3 years service as in the present case. Gratuity being a
reward for good, efficient and faithful service rendered for a considerable period (Vide IndianExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

Railway Establishment Code, Vol. I at p. 614 - Ch. XV, para. 1503), there would be no justification
for awarding the same when an employee voluntarily resigns and brings about a termination of his
service, except in exceptional circumstances.
264. One such exception is the operation of what is termed "The conscience clause". In Fernand
Terrou and Lucion Solal's Legislation for Press, Film and Radio in the World to-day (a series of
studies published by UNESCO in 1951) the following passage occurs in relation to "Journalists'
Working Conditions and their Moral Rights", at p. 404 :
265. "Among the benefits which the status of professional journalist may confer (whether it stems
from the law or from an agreement) is one of particular importance, since it goes to the very core of
the profession. It concerns freedom of information. It is intended to safeguard the journalist's
independence, his freedom of thought and his moral rights. It constitutes what has been called in
France the "conscience clause". The essence of this clause is that when a journalist's integrity is
seriously threatened, he may break the contract binding him to the newspaper concern, and at the
same time receive all the indemnities which are normally payable only if it is the employer who
breaks the contract. In France, accordingly, under the law of 1935, the indemnity for dismissal
which, as we have seen, may be quite substantial, is payable even when the contract is broken by a
professional journalist, in cases where his action is inspired by "a marked change in the character or
policy of the newspaper or periodical, if such change creates for the person employed a situation
prejudicial to his honour, his reputation, or in a general way his moral interests.
"This moral right of a journalist is comparable to the moral right of an author or
artist, which the law of 1935 was the first to recognize, has since been acknowledged
in a number of countries. It was stated in the collective contract of January 31, 1938,
in Poland in this form : "The following are good and sufficient reasons for a journalist
to cancel his contract without warning; (a) the exertion of pressure by an employer
upon a journalist to induce him to perform an immoral action; (b) a fundamental
change in the political outlook of the journal, proclaimed by public declaration or
otherwise made manifest, if the journalist's employment would thereafter be contrary
to his political opinions or the dictates of his conscience."
266. A similar clause is to be found in Switzerland, in the collective agreement signed on April 1,
1948, between the Geneva Press Association and the Geneva Union of Newspaper Publishers :
"If a marked change takes place in the character or fundamental policy of the
newspaper, if the concern no longer has the same moral, political or religious
character that it had at the moment when an editorial employee was engaged and if
this change is such as to prejudice his honour, his reputation or, in a general way, his
moral interests, he may demand his instant release. In these circumstances he shall
be entitled to an indemnity.... This indemnity is payable in the same manner as was
the salary."Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

267. The other exception is where the employee has been in continuous service of the employer for a
period of more than 15 years.
268. Where however an employee voluntarily resigns from service of the employer after a period of
only three years, there will be no justification whatever for awarding him a gratuity and any such
provision of the type which has been made in s. 5(1)(a)(iii) of the Act would certainly be
unreasonable. We hold therefore that this provision imposes an unreasonable restriction on the
petitioners' right to carry on business and is liable to be struck down as unconstitutional.
269. The provision in regard to the hours of work also cannot be considered unreasonable having
regard to the nature and quality of the work to be done by working journalists.
270. That leaves the considerations of fixation of rates of wages by the Wage Board. As we have
already observed, the Wage Board is constituted of equal numbers of representatives of the
newspaper establishments and the working journalists with an independent chairman at its head
and principles for the guidance of the Wage Board in the fixation of such rates of wages directing the
Wage Board to take into consideration amongst other circumstances the capacity of the industry to
pay have also been laid down and it is impossible to say that the provisions in that behalf are in any
manner unreasonable. It may be that the decision of the Wage Board may be arrived at ignoring
some of these essential criteria which have been laid down in s. 9(1) of the Act or that the procedure
followed by the Wage Board may be contrary to the principles of natural justice. But that would
affect the validity of the decision itself and not the constitution of the Wage Board which as we have
seen cannot be objected to on this ground.
271. The further provision contained in s. 17 of the Act in regard to the recovery of money due from
an employer empowering the State Government or any such authority appointed in that behalf to
issue a certificate for that amount to the collector in the same manner as an arrear of land revenue
was also impeached by the petitioners on this ground. That provision, however, relates only to the
mode of recovery and not to the imposition of any financial burden as such on the employer. We
shall have occasion to deal with this provision in connection with the alleged infringement of the
fundamental right under Art. 14 hereafter. We do not subscribe to the view that such a provision
infringes the fundamental right of the petitioners to carry on business under Art. 19(1)(g).
272. This attack of the petitioners on the constitutionality of the impugned Act under Art. 19(1)(g),
viz., that it violates the petitioners' fundamental right to carry on business, therefore, fails except in
regard to s. 5(1)(a)(iii) thereof which being clearly severable from the rest of the provisions, can be
struck down as unconstitutional without invalidating the other parts of the impugned Act.
273. Re. Article 14.
274. The question as formulated is that the impugned Act selected the working journalists for
favoured treatment by giving them a statutory guarantee of gratuity, hours of work and leave which
other persons in similar or comparable employment had not got and in providing for the fixation of
their salaries without following the normal procedure envisaged in the Industrial Disputes Act, 1947.Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

The following propositions are advanced :-
1. In selecting the Press industry employers from all industrial employers governed
by the ordinary law regulating industrial relations under the Industrial Disputes Act,
1947, and Act I of 1955, the impugned Act subjects the Press industry employers to
discriminatory treatment.
2. Such discrimination lies in
(a) singling out newspaper employees for differential treatment;
(b) saddling them with a new burden in regard to a section of their workers in matters of gratuities,
compensation, hours of work and wages;
(c) devising a machinery in the form of a Pay Commission for fixing the wages of working
journalists;
(d) not prescribing the major criterion of capacity to pay to be taken into consideration;
(e) allowing the Board in fixing the wages to adopt any arbitrary procedure even violating the
principle of audi alteram partem;
(f) permitting the Board the discretion to operate the procedure of the Industrial Disputes Act for
some newspapers and any arbitrary procedure for others;
(g) making the decision binding only on the employers and not on the employees, and
(h) providing for the recovery of money due from the employers in the same manner as an arrear of
land revenue.
3. The classification made by the impugned Act is arbitrary and unreasonable, in so far as it removes
the newspaper employers vis-a-vis working journalists from the general operation of the Industrial
Disputes Act, 1947, and Act I of 1955.
275. The principle underlying the enactment of Art. 14 has been the subject-matter of various
decisions of this Court and it is only necessary to set out the summary thereof given by Das J. (as he
then was) in Budhan Choudhry & Others v. The State of Bihar :-
"The provisions of article 14 of the Constitution have come up for discussion before
this Court in a number of cases, namely, Chiranjit Lal Chowdhuri v. The Union of
India ([1950] S.C.R. 869)M, The State of Bombay v. F. N. Balsara ([1951] S.C.R. 682),
The State of West Bengal v. Anwar Ali Sarkar ([1952] S.C.R. 284), Kathi Raning
Rawat v. The State of Saurashtra ([1952] S.C.R. 435), Lachmandas Kewalaram Ahuja
v. The State of Bombay ([1952] S.C.R. 710), Quasim Razvi v. The State of HyderabadExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

([1953] S.C.R. 581), and Habeeb Mohamad v. The State of Hyderabad ([1953] S.C.R.
661). It is, therefore, not necessary to enter upon any lengthy discussion as to the
meaning, scope and effect of the article in question. It is now well-established that
while article 14 forbids class legislation, it does not forbid reasonable classification
for the purposes of legislation. In order, however, to pass the test of permissible
classification two conditions must be fulfilled, namely, (i) that the classification must
be founded on an intelligible differentia which distinguishes persons or things that
are grouped together from others left out of the group and (ii) that that differentia
must have a rational relation to the object sought to be achieved by the statute in
question. The classification may be founded on different bases; namely, geographical,
or according to objects or occupations or the like. What is necessary is that there
must be a nexus between the basis of classification and the object of the Act under
consideration. It is also well-established by the decisions of this Court that article 14
condemns discrimination not only by a substantive law but also by a law of
procedure."
276. It is the light of these observations that we shall now proceed to consider whether the
impugned Act violates the fundamental right of the petitioners guaranteed under Art. 14 of the
Constitution.
277. We have already set out what the Press Commission had to say in regard to the position of the
working journalists in our country. A further passage from the Report may also be quoted in this
context :
"It is essential to realise in this connection that the work of a journalist demands a
high degree of general education and some kind of specialised training. Newspapers
are a vital instrument for the education of the masses and it is their business to
protect the rights of the people, to reflect and guide public opinion and to criticize the
wrong done by any individual or organization however high placed. They thus form
an essential adjunct to democracy. The profession must, therefore, be manned by
men of high intellectual and moral qualities. The journalists are in a sense creative
artists and the public rightly or wrongly, expect from them a general omniscience and
a capacity to express opinion on any topic that may arise under the sun. Apart from
the nature of their work the conditions under which that work is to be performed, are
peculiar to this profession. Journalists have to work at very high pressure and as
most of the papers come out in the morning, the journalists are required to work late
in the night and round the clock. The edition must go to press by a particular time
and all the news that breaks before that hour has got to find its place in that edition.
Journalism thus becomes a highly specialized job and to handle it adequately a
person should be well-read, have the ability to size up a situation and to arrive
quickly at the correct conclusion, and have the capacity to stand the stress and strain
of the work involved. His work cannot be measured, as in other industries, by the
quantity of the output, for the quality of work is an essential element in measuring
the capacity of the journalists. Moreover insecurity of tenure is a peculiar feature ofExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

this profession. This is not to say that no insecurity exists in other professions but
circumstances may arise in connection with profession of journalism which may lead
to unemployment in this profession, which would not necessarily have that result in
other professions. Their security depends to some extent on the whims and caprices
of the proprietors. We have come across cases where a change in the ownership of the
paper or a change in the editorial policy of the paper has resulted in a considerable
change in the editorial staff. In the case of other industries a change in the
proprietorship does not normally entail a change in the staff. But as the essential
purpose of a newspaper is not only to give news but to educate and guide public
opinion, a change in the proprietorship or in the editorial policy of the paper may
result and in some cases has resulted in a wholesale change of the staff on the
editorial side. These circumstances, which are peculiar to journalism must be borne
in mind in framing any scheme for improvement of the conditions of working
journalists." (para. 512).
278. These were the considerations which weighed with the Press Commission in recommending the
working journalists for special treatment as compared with the other employees of newspaper
establishments in the matter of amelioration of their conditions of service.
279. We may also in this connection refer to the following passage from the Legislation for Press,
Film and Radio in the world to-day (a series of studies published by UNESCO in 1951) (supra) at p.
403 :-
"Under certain systems, special advantages more extensive than those enjoyed by
ordinary employees are conferred upon journalists. These may be sanctioned by the
law itself. For instance, certain Latin American countries have enacted legislation in
favour of journalists which is in some cases very detailed and far-reaching and offers
special benefits, more particularly in the form of protection against the risk of
sickness or disability, dismissal or retirement. In Brazil, professional journalists, who
must be of Brazilian birth and nationality, enjoy very considerable tax exemptions.
"In France, the law of 29 March, 1935, conferred on journalists substantial
advantages which at the time were far in advance of general social legislation. Thus,
for example, this law gives all professional journalists the right to an annual holiday
with pay. One month's holiday is granted to journalists who have been working for a
newspaper or periodical for at least one year, and five weeks to journalists whose
contract has been in force for 10 years at least. Should a contract of indefinite
duration be terminated, the journalist is entitled to one or two month's notice and
also to an indemnity for dismissal which may not be less than one month's salary per
year or part of a year of service, at the most recent rate of pay. However, if the period
of service exceeds 15 years, the amount of the indemnity is fixed, as we have seen, by
an arbitral committee."Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

280. The working journalists are thus a group by themselves and could be classified as such apart
from the other employees of newspaper establishments and if the Legislature embarked upon a
legislation for the purpose of ameliorating their conditions of service there was nothing
discriminatory about it. They could be singled out thus for preferential treatment against the other
employees of newspaper establishments. A classification of this type could not come within the ban
of Art. 14. The only thing which is prohibited under this article is that persons belonging to a
particular group or class should not be treated differently as amongst themselves and no such
charge could be leveled against this piece of legislation. If this group of working journalists was
specially treated in this manner there is no scope for the objection that that group had a special
legislation enacted for its benefit or that a special machinery was created, for fixing the rates of its
wages different from the machinery employed for other workmen under the Industrial Disputes Act,
1947. The payment of retrenchment compensation and gratuities, the regulation of their hours of
work and the fixation of the rates of their wages as compared with those of other workmen in the
newspaper establishments could also be enacted without any such disability and the machinery for
fixing their rates of wages by way of constituting a wage board for the purpose could be similarly
devised. There was no industrial dispute as such which had arisen or was apprehended to arise as
between the employers and the working journalists in general, though it could have possibly arisen
as between the employers in a particular newspaper establishment and its own working journalists.
What was contemplated by the provisions of the impugned Act however, was a general fixation of
rates of wages of working journalists which would ameliorate the conditions of their service and the
constitution of a wage board for this purpose was one of the established modes of achieving that
object. If, therefore, such a machinery was devised for their benefit, there was nothing objectionable
in it and there was no discrimination as between the working journalists and the other employees of
newspaper establishments in that behalf. The capacity of the industry to pay was certainly to be
taken into consideration by the Wage Board, as we have already seen before, and the procedure of
the Board also was assimilated to that adopted by an industrial tribunal under the Industrial
Disputes Act, 1947, or was, in any event, to be such as would not be against the principle of audi
alteram partem or the principles of natural justice. There was no occasion, if the Wage Board chose
to exercise the same powers and follow the same procedure as the Industrial Tribunal under the
Industrial Disputes Act, 1947, for it to discriminate between one set of newspaper establishments
and others. If it in fact assumed unto itself the powers of the Industrial Tribunal it would be bound
to follow the procedure prescribed under the Industrial Disputes Act, 1947, and if it were thus to
follow the same, no discrimination could ever be made in the manner suggested. The decision of the
Wage Board was no doubt made binding only on the employers and the working journalists were at
liberty to agitate the question of increase in their wages by raising an industrial dispute in regard
thereto. Once the rates of wages were fixed by the Wage Board, it would normally follow that they
would govern the relationship between the employers and the working journalists, but if liberty was
reserved to the working journalists for further increase in their wages under the provisions of the
Industrial Disputes Act there was nothing untoward in that provision and that did not by itself
militate against the position that what was done for the benefit of the working journalists was a
measure for the amelioration of their conditions of service as a group by themselves. There could not
be any question of discrimination between the employers on the one hand and the working
journalists on the other. They were two contesting parties ranged on opposite sides and the fact that
one of them was treated in a different manner from the other in the matter of the amelioration of theExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

conditions of service of the weaker party would not necessarily vitiate the decision of the Wage
Board. The weaker of the two parties could certainly be treated as a class by itself and the
conferment of special benefits in the matter of trying to ameliorate their conditions of service could
certainly not be discriminatory.
281. The provisions contained in s. 17 of the Act in regard to the recovery of money due from the
employers in the same manner as an arrear of land revenue also was not discriminatory. In the
conflict between the employers and the employees it very often came about that the employers did
not implement the measures which had been enacted for the benefit of the employees and the
employees were thus hard put to realise and cash those benefits. Even the Industrial Disputes Act,
1947, contained a like provision in s. 33C thereof (vide the amendment incorporated therein by Act
36 of 1956) which in its turn was a reproduction of the old s. 25-I which had been inserted therein by
Act 43 of 1953. It may be remembered that if the provisions of the Industrial Disputes Act, 1947,
which was a general Act, had been made applicable to the working journalists there would have been
no quarrel with the same. Much less there could be any quarrel with the introduction of s. 17 into the
impugned Act when the aim and object of such provision was to provide the working journalists who
were a group by themselves from amongst employees employed in the newspaper establishments
with a remedy for the recovery of the monies due to them in the same manner as the workmen
under the Industrial Disputes Act, 1947. We do not see anything discriminatory in making such a
provision for the recovery of monies due by the employers to these working journalists.
282. Similar is the position in regard to the alleged discrimination between Press industry
employers on the one hand and the other industrial employers on the other. The latter would
certainly be governed by the ordinary law regulating industrial relations under the Industrial
Disputes Act, 1947. Employers qua the working journalists again would be a class by themselves and
if a law was enacted to operate as between them in the manner contemplated by the Act that could
not be treated as discriminatory. If measures have got to be devised for the amelioration of the
conditions of working journalists who are employed in the newspaper establishments, the only way
in which it could be done was by directing this piece of legislation against the Press Industry
employers in general. Even considering the Act as a measure of social welfare legislation the State
could only make a beginning somewhere without embarking on similar legislations in relation to all
other industries and if that was done in this case no charge could be leveled against the State that it
was discriminating against one industry as compared with the others. The classification could well
be founded on geographical basis or be according to objects or occupations or the like. The only
question for consideration would be whether there was a nexus between the basis of classification
and the object of the Act sought to be challenged. In our opinion, both the conditions of permissible
classification were fulfilled in the present case. The classification was based on an intelligible
differentia which distinguished the working journalists from other employees of newspaper
establishments and that differentia had a rational relation to the object sought to be achieved, viz.,
the amelioration of the conditions of service of working journalists.
283. This attack on the constitutionality of the Act also therefore fails.
284. Re. Article 32 :-Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

In regard to the infringement of Art. 32, the only ground of attack has been that the
impugned Act did not provide for the giving of the reasons for its decision by the
Wage Board and thus rendered the petitioners' right to approach the Supreme Court
for enforcement of their fundamental right nugatory. It is contended that the right to
apply to the Supreme Court for a writ of certiorari required an order infringing a
fundamental right, that such a right was itself a fundamental right and any legislation
which attempted to restrict or defeat this right was an infraction of Art. 32 and was as
such void. It is further contended that a writ of certiorari could effectively be directed
only against a speaking order, i.e., an order disclosing reasons, and if a statute
enabled the passing of an order that need give no reasons such statute attempted to
sterilize the powers of this Court from investigating the validity of the order and was
therefore violative of Art. 32.
285. Learned Counsel for the petitioners has relied upon a decision of the English Court in Rex v.
Northumberland Compensation Appeal Tribunal, Ex parte Shaw ([1951] 1 K.B. 711, 718) where Lord
Goddard C.J. observed at p. 718 :-
"Similarly anything that is stated in the order which an inferior court has made and
which has been brought up into this court can be examined by the court, if it be a
speaking order, that is to say, an order which sets out the grounds of the decision. If
the order is merely a statement of conviction that there shall be a fine of 40s., or an
order of removal or quashing a poor rate, there is an end of it, this court cannot
examine further. If the inferior court tells this court why it had done what it has and
makes it part of its order, this court can examine it."
286. This decision was affirmed by the Court of Appeal (and the decision of the Court of Appeal is
reported in Rex v. Northumberland Compensation Appeal Tribunal, Ex parte Shaw ([1952] 1 K.B.
338) and while doing so Denning L.J. (as he then was) discussed at p. 352, what was it that
constituted the record :-
"What, then, is the record ? ..... Following these cases I think the record must contain
at least the document which initiates the proceedings; the pleadings if any; and the
adjudication; but not the evidence, nor the reasons, unless the tribunal chooses to
incorporate them. If the tribunal does state its reasons, and these reasons are wrong
in law, certiorari lies to quash the decision."
287. This decision only affirmed that certiorari could lie only if an order made by the inferior
tribunal was a speaking order. It did not lay down any duty on the inferior tribunal to set out the
reasons for its order but only pointed out that if no reasons were given it would be impossible for the
High Court to interfere by exercising its prerogative jurisdiction in the matter of certiorari.
288. A more relevant decision on this point is that of this Court in A. K. Gopalan v. The State of
madras and Anr. ([1950] S.C.R. 88, 100). In that case the provision of law which was impugned
amongst others was one which prevented the detenu on pain of prosecution from disclosing to theExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

Court the grounds of his detention communicated to him by the detaining authority. This provision
was struck down as ultra vires and void. The reason given by Mahajan J. (as he then was) is stated at
p. 243 :
"This Court would be disabled from exercising its functions under article 32 and
adjudicating on the point that the grounds given satisfy the requirements of the
sub-clause if it is not open to it to see the grounds that have been furnished. It is a
guaranteed right of the person detained to have the very grounds which are the basis
of the order of detention. This Court would be entitled to examine the matter and to
see whether the grounds furnished are the grounds on the basis of which he has been
detained or they contain some other vague or irrelevant material. The whole purpose
of furnishing a detained person with the grounds is to enable him to make a
representation refuting these grounds and of proving his innocence. In order that this
Court may be able to safeguard this fundamental right and to grant him relief it is
absolutely essential that the detenu is not prohibited under penalty of punishment to
disclose the grounds to the Court and no injunction by law can be issued to this Court
disabling it from having a look at the grounds. Section 14 creates a substantive
offence if the grounds are disclosed and it also lays a duty on the Court not to permit
the disclosure of such grounds. It virtually amounts to a suspension of a guaranteed
right provided by the Constitution inasmuch as it indirectly by a stringent provision
makes administration of the law by this Court impossible and at the same time it
deprives a detained person from obtaining justice from this Court. In my opinion,
therefore, this section when it prohibits the disclosure of the grounds contravenes or
abridges the rights given by Part III to a citizen and is ultra vires the powers of
Parliament to that extent."
289. It is no doubt true that if there was any provision to be found in the impugned Act which
prevented the Wage Board from giving reasons for its decision, it might be construed to mean that
the order which was thus made by the Wage Board could not be a speaking order and no writ of
certiorari could ever be available to the petitioners in that behalf. It is also true that in that event this
Court would be powerless to redress the grievances of the petitioners by issuing a writ in the nature
of certiorari and the fundamental right which a citizen has of approaching this Court under Art. 32
of the Constitution would be rendered nugatory.
290. The position, however, as it obtains in the present case is that there is no such provision to be
found in the impugned Act. The impugned Act does not say that the Wage Board shall not give any
reason for its decision. It is left to the discretion of the Wage Board whether it should give the
reasons for its decision or not. In the absence of any such prohibition it is impossible for us to hold
that the fundamental right conferred upon the petitioners under Art. 32 was in any manner
whatever sought to be infringed. It may be noted that this point was not at all urged in the petitions
which the petitioners had filed in this Court but was taken up only in the course of the arguments by
the learned Counsel for the petitioners. It appears to have been a clear after-thought; but we have
dealt with the same as it was somewhat strenuously urged before us in the course of the arguments.
We are of the opinion that the Act cannot be challenged as violative of the fundamental rightExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

enshrined in Art. 32 of the Constitution.
291. In regard to the constitutionality of the Act therefore we have come to the conclusion that none
of the provisions thereof is violative of the fundamental rights enshrined in Arts. 19(1)(a), 19(1)(g),
14 and/or 32 save the provision contained in s. 5(1)(a)(iii) of the Act which is violative of the
fundamental right guaranteed under Art. 19(1)(g) of the Constitution and is therefore
unconstitutional and should be struck down.
292. Apart from challenging the vires of the Act dealt with above, the petitioners contend that the
decision of the Wage Board itself is illegal and void because :
(1) Re-constitution of the Board was ultra vires and unauthorised by the Act as it
stood at the time, the rules having been published only on July 30, 1956.
(2) The decision by a majority was unwarranted by the Act and since there was no
provision in the Act, the Rules providing for the same went beyond the Act and were
therefore ultra vires.
(3) The procedure followed by the Board offended the principles of natural justice
and was therefore invalid;
(4) The decision was invalid, because
(a) no reasons were given, (b) nor did it disclose what considerations prevailed with
the Board in arriving at its decision;
(5) Classification on the basis of gross revenue was illegal and unauthorised by the
Act.
(6) Grouping into chains or multiple units was unauthorised by the Act.
(7) The Board was not authorised by the Act to fix the salaries of journalists except in
relation to a particular industrial establishment and not on an All-India basis of all
newspapers taken together;
(8) The decision was bad as it did not disclose that the capacity to pay of any
particular establishment was ever taken into consideration.
(9) The Board had no authority to render a decision which was retrospective in
operation.
(10) The Board had no authority to fix scales of pay for a period of 3 years (subject to
review by the Govt. by appointing another Wage Board at the end of these 3 years)
and (11) The Board was handicapped for want of Cost of Living Index.Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

292. The position in law is that the decision would be illegal on any of the following three grounds,
viz., (A) Because the Act under which it was made was ultra vires;
[See Mohammad Yasin v. Town Area Committee, Jalalabad & Anr ([1952] S.C.R. 572, 578). and
Himmatlal Harilal Mehta v. State of Madhya Pradesh ([1954] S.C.R. 1122, 1127)].
(B) Because the decision itself infringed the fundamental rights of the petitioners.
[See Bidi Supply Co. v. Union of India & Ors. ([1956] S.C.R. 267)].
(C) Because the decision was ultra vires the Act.
[See Pandit Ram Narain v. State of Uttar Pradesh & Ors. ([1956] S.C.R. 664)].
293. The decision of the Wage Board before us cannot be challenged on the grounds that the
impugned Act under which the decision is made is ultra vires or that the decision itself infringes the
fundamental rights of the petitioners. In the circumstances, the challenge must be confined only to
the third ground, viz., that the decision is ultra vires the Act itself.
294. Re. (1).
295. The first ground attack is based on the circumstance that Shri K. P. Kesava Menon who was
originally appointed a member of the Wage Board resigned on or about June 21, 1956, which
resignation was accepted by the Central Government by a notification dated July 14, 1956, and by
the same notification the Central Government appointed in his place Shri K. M. Cherian and thus
reconstituted the Wage Board. There was no provision in the Act for the resignation of any member
from his membership or for the filling in of the vacancy which thus arose in the membership of the
Board. A provision in this behalf was incorporated only in the Working Journalists Wage Board
Rules, 1956, which were published by a notification in the Gazette of India Part II-Section 3 on date
July 31, 1956. It was, therefore, contended that such re-constitution of the Board by the
appointment of Shri K. M. Cherian in place of Shri K. P. Kesava Menon was unauthorised by the Act
as it then stood and the Board which actually published the decision in question was therefore not
properly constituted.
296. It is necessary to remember in this connection that s. 8 of the Act empowered the Central
Government by notification in the Official Gazette to constitute a Wage Board. This power of
constituting the Wage Board must be construed having regard to s. 14 of the General clauses Act,
1897, which says that where by any Central Act or Regulation made after the commencement of the
Act, any power is conferred then, unless a different intention appears that power may be exercised
from time to time as occasion arises. If this is the true position there was nothing objectionable in
the Central Government re-constituting the Board on the resignation of Shri K. P. Kesava Menon
being accepted by it. The Wage Board can in any event be deemed to have been constituted as on
that date, viz., July 14, 1956, when all the 5 members within the contemplation of s. 8(2) of the Act
were in a position to function. Shri K. P. Kesava Menon had not attended the preliminary meeting ofExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

the Board which had been held on May 26, 1956, and the real work of the Wage Board was done
after the appointment of Shri K. M. Cherian in his place and stead and it was only after July 14,
1956, that the Wage Board as a whole constituted as it was on that date really functioned as such.
The objection urged by the petitioners in this behalf is too technical to make any substantial
difference in regard to the constitution of the Wage Board and its functioning.
297. Re. 2.
298. This ground ignores the fact that the Working Journalists Wage Board Rules, 1956, which were
published on July 31, 1956, were made by the Central Government in exercise of the power
conferred upon it by s. 20 of the Act. That section empowered the Central Government to make rules
to carry out the purposes of the Act, in particular to provide for the procedure to be followed by the
Board in fixing rates of wages. Rule 8 provided that every question considered at a meeting of the
Board was to be decided by a majority of the votes of the members present and voting. In the event
of equality of votes the Chairman was to have a casting vote... This Rule therefore prescribed that
the decision of the Board could be reached by a majority and this was the rule which was followed by
the Board in arriving at its decision. The rule was framed by the Central Government by virtue of the
authority vested in it under s. 20 of the Act and was a piece of delegated legislation which if the rules
were laid before both the Houses of Parliament in accordance with s. 20(3) of the Act acquired the
force of law. After the publication of these rules, they became a part of the Act itself and any decision
thereafter reached by the Wage Board by a majority as prescribed therein was therefore lawful and
could not be impeached in the manner suggested.
299. Re. (3).
300. This ground has reference to the alleged violation by the Wage Board of the principles of
natural justice. It is urged that the procedure established under the Industrial Disputes Act was not
in terms prescribed for the Wage Board, the Board having been given under s. 11 of the Act the
discretion for the purpose of fixing rates of wages to exercise the same powers and follow the same
procedure as an Industrial Tribunal constituted under the Industrial Disputes Act, 1947, while
adjudicating upon an industrial dispute referred to it. On two distinct occasions, however, the Wage
Board definitely expressed itself that it had the powers of an Industrial Tribunal constituted under
the Industrial Disputes Act. The first occasion was when the questionnaire was issued by the Wage
Board and in the questionnaire it mentioned that it had such powers under s. 11 of the Act. The
second occasion arose when a number of newspapers and journals to whom the questionnaire was
addressed failed to send their replies to the same and the Wage Board at its meeting held on August
17, 1956, reiterated the position and decided to issue a Press Note requesting the newspapers and
journals to send their replies as soon as possible, inviting their attention to the fact that the Board
had powers of an Industrial Tribunal under the Act and if newspapers failed to send their replies,
the Board would be compelled to take further steps in the matter. This is clearly indicative of the fact
that the Wage Board did seek to exercise the powers under the terms of s. 11 of the Act. Even though,
the exercise of such powers was discretionary with the Board, the Board itself assumed these powers
and assimilated its position to that of an Industrial Tribunal constituted under the Industrial
Disputes Act, 1947. If, then, it assumed those powers, it only followed that it was also bound toExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

follow the procedure which an Industrial Tribunal so constituted was bound to follow.
301. It is further urged that in the whole of the questionnaire which was addressed by the Wage
Board to the newspaper establishments, there was no concrete proposal which was submitted by the
Wage Board to them for their consideration. The only question which was addressed in this behalf
was Question No. 4 in Part "A" which asked the newspaper establishments whether the basic
minimum wage, dearness allowance and metropolitan allowance suggested by the Press
Commission were acceptable to them and if not, what variations would they suggest and why. The
question as framed would not necessarily focus the attention of the newspaper establishments to
any proposal except the one which was the subject-matter of that question, viz., the proposal of the
Press Commission in that behalf and the newspaper establishments to whom the questionnaire was
addressed would certainly not have before them any indication at all as to what was the wage
structure which was going to be adopted by the Wage Board. Even though the Wage Board came to
the conclusion, as a result of its having collected the requisite data and gathered sufficient materials,
after receiving the answers to the questionnaire and examining the witnesses, that certain wage
structure was a proper one in its opinion, it was necessary for the Wage Board to communicate the
proposals in that regard to the various newspaper establishments concerned and invite them to
make their representations, if any, within a specified period. It was only after such representations
were received from the interested parties that the Wage Board should have finalized its proposals
and published its decision. If this procedure had been adopted the decision of the Wage Board could
not have been challenged on the score of its being contrary to the principles of natural justice.
302. It would have been no doubt more prudent for the Wage Board to have followed the procedure
outlined above. The ground No. 8 is, in our opinion, sufficiently determinative of the question as to
the ultra vires character of the Wage Board decision and in view of the conclusion reached by us in
regard to the same, we refrain from expressing any opinion on this ground of attack urged by the
Petitioners.
303. Re. 4.
304. This ground is urged because no reasons were given by the Wage Board for its decision. As a
matter of fact, the Wage Board at its meeting dated April 22, 1957, agreed that reasons need not be
given for each of the decisions and it was only sufficient to record the same and accordingly it did
not give any reasons for the decision which it published. In the absence of any such reasons,
however, it was difficult to divine what considerations, if any, prevailed with the Wage Board in
arriving at its decision on the various points involved therein. It was no doubt not incumbent on the
Wage Board to give any reasons for its decision. The Act made no provision in this behalf and the
Board was perfectly within its rights if it chose not to give any reasons for its decision. Prudence
should, however, have dictated that it gave reasons for the decision which it ultimately reached
because if it had done so, we would have been spared the necessity of trying to probe into its mind
and find out whether any particular circumstance received due consideration at its hands in arriving
at its decision. The fact that no reasons are thus given, however, would not vitiate the decision in any
manner and we may at once say that even though no reasons are given in the form of a regular
judgment, we have sufficient indication of the Chairman's mind in the note which he made on AprilExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

30, 1956, which is a contemporaneous record explaining the reasons for the decision of the majority.
This note of the chairman is very revealing and throws considerable light on the question whether
particular circumstances were at all taken into consideration by the Wage Board before it arrived at
its decision.
305. Re. 5.
306. This ground concerns the classification of newspaper establishments on the basis of gross
revenue. Such classification was challenged as illegal and unauthorised by the Act. The Act certainly
says nothing about classification and could not be expected to do so. What the Act authorised it to
do was to fix the rates of wages for working journalists having regard to the principles laid down in
s. 9(1) of the Act. In fixing the wage structure the Wage Board constituted under the Act was
perfectly at liberty if it thought necessary to classify the newspaper establishments in any manner it
thought proper provided of course that such classification was not irrational. If the newspaper
establishments all over the country had got to be considered in regard to fixing of rates of wages of
working journalists employed therein it was inevitable that some sort of classification should be
made having regard to the size and capacity of newspaper establishments. Various criteria could be
adopted for the purpose of such classification, viz., circulation of the newspaper, advertisement
revenue, gross revenue, capital invested in the business, etc., etc. Even though the proportion of
advertisement revenue to the gross revenue of newspaper establishments may be a relevant
consideration for the purpose of classification, we are not, prepared to say that the Wage Board was
not justified in adopting this mode of classification on the basis of gross revenue. It was perfectly
within its competence to do so and if it adopted that as the proper basis for classification it cannot
be said that the basis which it adopted was radically wrong or was such as to vitiate its decision. If
the need for classification is accepted, as it should be, having regard to the various sizes and
capacities of newspaper establishments all over the country it was certainly necessary to adopt a
workable test for such classification and if the Wage Board had adopted classification on the basis of
the gross revenue, we do not see any reason why that decision of its was in any manner whatever
unwarranted.
307. It may be remembered in this connection that the newspaper Industry Inquiry Committee in
U.P. had suggested in its report dated March 31, 1949, classification of newspapers in the manner
following :-
"A" Class - Papers with (1) a circulation of 10,000 copies or above or (2) an invested
capital of rupees 3 lakhs or more or (3) an annual income of rupees 3 lakhs or more;
"B" Class - Papers with (1) a circulation below 10,000 but above 5,000 copies or (2)
an invested capital between rupees one lakh and 3 lakhs or (3) an annual income
between rupees one lakh and 3 lakhs;
"C" Class - Papers with (1) a circulation below 5000 copies or (2) an invested capital
below rupees one lakh or (3) an annual income below rupees one lakh.Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

308. The classification on the basis of gross revenue was attacked by the petitioners on the ground
that in the gross revenue which is earned by the newspaper establishments, advertisement revenue
ordinarily forms a large bulk of such revenue and the revenue earned by circulation of newspapers
forms more often than not a small part of the same, though in regard to language newspapers the
position may be somewhat different. Unless, therefore, the proportion of advertisement revenue in
the gross revenue of newspaper establishments were taken into consideration, it would not be
possible to form a correct estimate of the financial status of that newspaper establishment with a
view to its classification. The petitioners on the other hand suggested that the profit and loss of the
newspaper establishments should be adopted as the proper test and if that were adopted a different
picture altogether would be drawn. The balance-sheets and the profit and loss accounts of the
several newspaper establishments would require to be considered and it was contended that even if
the gross revenue of a particular newspaper establishment were so large as to justify its inclusion on
the basis of gross revenue in Class "A" or Class "B" it might be working at a loss and its classification
as such would not be justified.
309. We have already referred in the earlier part of this judgment to the unsatisfactory nature of the
profit and loss test. Even though the profit and loss accounts and the balance-sheets of the several
limited companies may have been audited by their auditors and may also have been accepted by the
Income-tax authorities, they would not afford a satisfactory basis for classification of these
newspaper establishments for the reasons already set out above.
310. As a matter of fact, even before us attempts were made by the respondent, the Indian
Federation of Working Journalists to demonstrate that the profit and loss accounts and the
balance-sheets of several petitioners were manipulated and unreliable. We are not called upon to
decide whether the profit and loss test is one which should be accepted; it is sufficient for our
purpose to say that if such a test was not accepted by the Wage Board, the Wage Board was certainly
far from wrong in doing so.
311. Re. 6.
312. This ground relates to grouping into chains or multiple units and the ground of attack is that
such grouping is unauthorised by the Act.
313. The short answer to this contention is that if such grouping into chains or multiple units was
justified having regard to the conditions of the newspaper industry in the country, there was nothing
in the Act which militated against such grouping. The Wage Board was authorised to fix the wage
structure for working journalists who were employed in various newspaper establishments all over
the country. If the chains or multiple units existed in the country the newspaper establishments
which formed such chains or multiple units were well within the purview of the inquiry before the
Wage Board and if the Wage Board thus chose to group them together in that manner such grouping
by itself could not be open to attack. The Act could not have expressly authorized the Wage Board to
adopt such grouping. It was up to the Wage Board to consider whether such grouping was justified
under the circumstances or not and unless we find something in the Act which prohibits the Wage
Board from doing so, we would not deem any such grouping as unauthorised. The real difficulty,Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

however, in the matter of grouping into chains or multiple units arises in connection with the
capacity of the industry to pay, a topic which we shall discuss hereafter while discussing the ground
in connection therewith.
314. Re. 7.
315. This ground is based on the definition of "newspaper establishment" found in Section 2(d) of
the Act. "Newspaper establishment" is there defined as "an establishment under the control of any
person or body of persons, whether incorporated or not, for the production or publication of one or
more newspapers or for conducting any news agency or syndicate." So, the contention put forward is
that "an establishment" can only mean "an establishment" and not a group of them, even though
such an individual establishment may produce or publish one or more newspapers. The definition
may comprise within its scope chains or multiple units, but even so, the establishment should be one
individual establishment producing or publishing a chain of newspapers or multiple units of
newspapers. If such chains or multiple units were, though belonging to some person or body of
persons whether incorporated or not, produced or published by separate newspaper establishments,
common control would not render the constitution of several newspaper establishments as one
establishment for the purpose of this definition, they would none the less be separate newspaper
establishments though under common control.
316. Reliance was placed in support of this contention on a decision of the Calcutta High Court in
Pravat Kumar v. W. T. C. Parker , where the expression which came up for construction before the
Court was "employed in an industrial establishment" and it was observed that :-
"Employed in an industrial establishment "must mean employed in some particular
place, that place being the place used for manufacture or an activity amounting to
industry, as that term is used in the Act."
317. A similar interpretation was put on the expression "industrial establishment" by the Madras
High Court in S.R.V. Service Ltd. v. State of Madras (A.I.R. 1956 Mad. 115, 122), where it was
observed at p. 12 :-
"They referred only to a dispute between the workers and the management of one
industrial establishment, the Kumbakonam branch of the S.R.V.S. Ltd. I find it a little
difficult to accept the contention of the learned counsel for the Madras Union, that
the Kumbakonam branch of the S.R.V.S. Ltd., is not an industrial establishment as
that expression has been used in the several sections of the Act................. I need refer
only to section 3 of the Act to negative the contention of the learned counsel for the
Madras Union, the S.R.V.S. Ltd., with all its branches should be taken as one
industrial establishment."
318. These decisions lend support to the contention that a newspaper establishment like an
industrial establishment should be located in one place, even though it may be carrying on its
activities of production or publication of more newspapers than one. If these activities are carried onExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

in different places, e.g., in different towns or cities of different States, the newspaper establishments
producing or publishing such newspapers cannot be treated as one individual establishment but
should be treated as separate newspaper establishments for the purpose of working out the relations
between themselves and their employees. There would be no justification for including these
different newspaper establishments into one chain or multiple unit and treating them, as if they
were one newspaper establishment. Here again, the petitioners are faced with this difficulty that
there is nothing in the Act to prohibit such a grouping. If a classification on the basis of gross
revenue could be legitimately adopted by the Wage Board then the grouping into chains or multiple
units could also be made by it. There is nothing in the Act to prohibit the treating of several
newspaper establishments producing or publishing one or more newspapers though in different
parts of the country as one newspaper establishment for the purpose of fixing the rates of wages. It
would not be illegitimate to expect the same standard of employment and conditions of service in
several newspaper establishments under the control of any person or body of persons, whether
incorporated or not; for an employer to think of employing one set of persons on higher scales of
wages and another set of workers on lower scales of wages would by itself be inequitous, though it
would be quite legitimate to expect the difference in scales having regard to the quality of the work
required to be done, the conditions of labour in different regions of the country, the standard of
living in those regions and other cognate factors.
319. All these considerations would necessarily have to be borne in mind by the Wage Board in
arriving at its decision in regard to the wage structure though the relative importance to be attached
to one circumstance or the other may vary in accordance with the conditions in different areas or
regions where the newspaper establishments are located.
320. Re. 8.
321. We now come to the most important ground, viz., that the decision of the Wage Board has not
taken into consideration the capacity to pay of any particular newspaper establishment. As we have
already seen, the fixing of rates of wages by the Wage Board did not prescribe whether the wages
which were to be fixed were minimum wages, fair wages, or living wages and it was left to the
discretion of the Wage Board to determine the same. The principles for its guidance were, however,
laid down and they prescribed the circumstances which were to be taken into consideration before
such determination was made by the Wage Board. One of the essential considerations was the
capacity of the industry to pay and that was comprised within the category "the circumstances
relating to newspaper industry in different regions of the country". It remains to consider, however,
whether the Wage Board really understood this category in that sense and in fact applied its mind to
it. At its preliminary meeting held on May 26, 1956, the Board set up a Sub-committee to draft a
questionnaire to be issued to the various journals and organisations concerned, with a view to
eliciting factual data and other relevant information required for the fixation of wages. The
Sub-committee was requested to bear in mind the need inter alia for proper classification of the
country into different areas on the basis of certain criteria like population, cost of living, etc. This
was the only reference to this requirement of s. 9(1) and there was no reference herein to the
capacity of the industry to pay which we have held was comprised therein. The only question in the
questionnaire as finally framed which had any reference to this criterion was Question No. 7 in PartExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

"A" under the heading "Special circumstances" and that question was : "Are there in your regions
any special conditions in respect of the newspaper industry which affect the fixing of rates of wages
of working journalists ? If so, specify the conditions and indicate how they affect the question of
wages." But here also it is difficult to find that the capacity of the industry to pay was really sought to
be included in these special conditions. The Wage Board no doubt asked for detailed accounts of
newspaper establishments and also required information which would help it in the proper
evaluation of the nature and quality of work of various categories of working journalists, but the
capacity of the industry to pay which was one of the essential considerations was nowhere
prominently brought in issue and information on that point was sought from the various newspaper
establishments to whom the questionnaire was going to be addressed. The answers to Question No.
7 as summarized by the Wage Board no doubt referred in some cases to the capacity of the industry
to pay but that was brought in by the newspaper establishments themselves who answered the
question in an incidental manner and could not be said to be prominent in the minds of the parties
concerned.
322. It is pertinent to observe that even before the Press Commission the figures had disclosed that
out of 127 newspapers 68 had been running into loss and 59 with profits and there was an overall
profit of about 1% on a capital investment of seven crores. The profit and loss accounts and the
balance sheets of the various companies owning or controlling newspaper establishments were also
submitted before the Wage Board but they had so far as they went a very sorry tale to tell. The profit
and loss statements for the year 1954-55 revealed that while 43 of them showed profits 40 had
incurred losses. Though no scientific conclusion could be drawn from this statement it showed
beyond doubt that the condition of the newspaper industry as a whole could not be considered
satisfactory. Under these circumstances, it was all the more incumbent upon the Wage Board even
though it discounted these profit and loss statements as not necessarily reflecting the true financial
position of these newspaper establishments, to consider the question of the capacity of the industry
to pay with greater vigilance.
323. There was again another difficulty which faced the Wage Board in that behalf and it was that
out of 5,705 newspapers to whom the questionnaire was addressed only 312 or at best 325 had
responded and the Wage Board was in the dark as to what was the position in regard to other
newspaper establishments. As a matter of fact, the chairman in his note dated April 30, 1957,
himself pointed out that the Wage Board had no data before it of all the newspapers and where it
had, that was in many cases not satisfactory. This aspect was again emphasised by him in his note
when he reiterated that the data available to the Wage Board had not been as complete as it would
have wished them to be and therefore recommended in the end the establishment of a standing
administrative machinery which would collect from all newspaper establishments in the country on
a systematic basis detailed information and data such as those on employment, wage rates and
earnings, financial condition of papers, figures of circulation, etc., which may be required for the
assessment of the effects of the decision of the Wage Board at the time of the review. The Wage
Board, in fact, groped in the dark in the absence of sufficient data and information which would
enable it to come to a proper conclusion in regard to the wage structure which it was to determine.
In the absence of such data and materials the Board was not in a position to work out what would be
the impact of its proposals on the capacity of the industry to pay as a whole or even region-wise andExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

the chairman in his note stated that it was difficult for the Board at that stage to work out with any
degree of precision, the economic and other effects of its decision on the newspaper industry as a
whole. Even with regard to the impact of these proposals on individual newspaper establishments
the chairman stated that the future of the Indian language newspapers was bright, having regard to
increasing literacy and the growth of political consciousness of the reading public, and by rational
management there was great scope for increasing the income of newspapers and even though there
was no possibility of any adjustment which might satisfy all persons interested, it was hoped that no
newspaper would be forced to close down as a result of its decision; but that if there was a good
paper and it deserved to exist, the Government and the public would help it to continue. This was
again a note of optimism which does not appear to have been justified by any evidence on the
record.
324. Even though, the Wage Board classified the newspaper establishments into 5 classes from "A"
to "E" on the basis of their gross revenue the proportion of the advertisement revenue to the gross
revenue does not appear to have been taken into consideration nor was the essential difference
which subsisted between the circulation and the paying capacity of the language newspapers as
compared with newspapers in the English language taken into account. If this had been done, the
basis of gross revenue which the Wage Board adopted would have been modified in several respects.
325. The grouping of the newspapers into chains or multiple units implied that the weaker units in
those groups were to be treated as on a par with the stronger units and it was stated that the loss in
the weaker units would be more than compensated by the profits in the more prosperous units. The
impact of these proposals on groups of newspapers was only defended on principle without taking
into consideration the result which they would have on the working of the weaker units. Here also
the chairman expressed the opinion that the Board was conscious that as a result of its decision,
some of the journalists in the weaker units of the same group or chain may get much more than
those working in its highest income units. He however stated that if the principle was good and
scientific, the inevitable result of its application should be judged from the stand-point of Indian
Journalism as a whole and not the burden in casts on a particular establishment. It is clear
therefore, that this principle which found favour with the Wage Board was sought to be worked out
without taking into consideration the burden which it would impose upon the weaker units of a
particular newspaper establishment.
326. The representatives of the employers objected to the fixation of scales of wages on the plea that
fixation of rates of wages did not include the fixation of scales of wages. This contention was
negatived by the representatives of the employees as also by the Chairman and the Wage Board by
its majority decision accepted the position that it could, while fixing the rates of wages also fix the
scales of wages. The Press Commission itself had merely suggested a basic minimum wage for the
consideration of the parties concerned but had suggested that so far as the scales of wages were
concerned they were to be settled by collective bargaining or by adjudication. Even though the Wage
Board took upon itself the burden of fixing scales of wages as really comprised within the terms of
their reference, it was incumbent upon it to consider what the impact of the scales of wages fixed by
it would be on the capacity of the industry to pay. There is nothing on the record to suggest that both
as regards the rates of wages and the scales of wages which it determined the Wage Board ever tookExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

into account as to what the impact of its decision would be on the capacity of the industry to pay
either as a whole or region-wise.
327. There is, however, a further difficulty in upholding the decision of the Wage Board in this
behalf and it is this that even as regards the fixation of the rates of wages of working journalists the
Wage Board does not seem to have taken into account the other provisions of the Act which
conferred upon the working journalists the benefits of retrenchment compensation, payment of
gratuity, hours of work and leave. These provisions were bound to have their impact on the paying
capacity of the newspaper establishments and if these had been borne in mind by the Wage Board it
is highly likely that the rates of wages including the scales of wages as finally determined might have
been on a lesser scale than what one finds in its decision.
328. This difficulty becomes all the more formidable when one considers that the working
journalists only constituted at best one-fifth of the total staff employed in the various
establishments. The rest of the 80% comprised persons who may otherwise be described as factory
workers who would be able to ameliorate their conditions of service by having resort to the
machinery under the Industrial Disputes Act. If the conditions of service of the working journalists
were to be improved by the Wage Board the other employees of newspaper establishments were
bound to be restive and they would certainly, at the very earliest opportunity raise industrial
disputes with a view to the betterment of their conditions of service. Even though the Industrial
Courts established under the Industrial Disputes Act, 1947, might not give them relief
commensurate with the relief which the Wage Board gave to the working journalists, there was
bound to be an improvement in their conditions of service which the Industrial Court would
certainly determine having regard to the benefits which the working journalists enjoyed and this
would indeed impose an additional financial burden on the newspaper establishments which would
substantially affect their capacity to pay. This consideration also was necessarily to be borne in mind
by the Wage Board in arriving at its final decision and one does not find anything on the record
which shows that it was actually taken into consideration by the Wage Board.
329. The retrospective operation of the decision of the Wage Board was also calculated to impose a
financial burden on the newspaper establishments. Even though this may be a minor consideration
as compared with the other considerations above referred to, it was none the less a circumstance
which the Wage Board ought to have considered in arriving at its decision in regard to the fixing of
rates of wages.
330. The financial burden which was imposed by the decision of the Wage Board was very vividly
depicted in the statements furnished to us on behalf of the petitioners in the course of the hearing
before us. These statements showed that the wage bill of these newspaper establishments was going
to be considerably increased, that the retrospective operation of the decision was going to knock off
a considerable sum from their reserves and that the burden imposed upon the newspaper
establishments by the joint impact of the provisions of the Act in regard to retrenchment
compensation, payment of gratuity, hours of work and leave as well as the decision of the Wage
Board in regard to the fixing of rates of wages and the scales of wages would be such a could
principle the resources of the newspaper establishments, if not necessarily lead to their completeExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

extinction. The statements also showed what extra burden was imposed upon the newspaper
establishments, if they wanted to discharge the working journalists from their employ which burden
was all the grater, if per chance, the newspaper establishments, even though reluctantly came to a
decision that it was worth their while to close down their business rather than continue the same
with all these financial burdens imposed upon them.
331. These figures have been given by us in the earlier part of our judgment and we need not repeat
the same. The conclusion, however, is inescapable that the decision of the Wage Board imposed a
very heavy financial burden on the newspaper establishments, which burden was augmented by the
classification on the basis of gross-revenue, fixation of scales of wages, provisions as regards the
hours of work and leave, grouping of newspapers into chains or multiple units and retrospective
operation given to the decision of the Wage Board as therein mentioned.
332. If these proposals had been circulated, before being finalized, by the Wage Board to the various
newspaper establishments so that these newspaper establishments could, if they so desired, submit
their opinions thereupon and their representations, if any, in regard to the same to the Wage Board
for its consideration and if the Wage Board had after receiving such opinions and representations
from the newspaper establishments concerned finalised it decision, this attack on the ground of the
Wage Board not having taken into consideration the capacity of the industry to pay as a whole or
region-wise would have lost much of its force. The Wage Board, however, did nothing of the type.
Proposals were exchanged between the representatives of the employers and the representatives of
the employees. The discussion that the chairman had with each set of representatives did not bear
any fruit and the chairman himself by way of mediation, as it were, submitted to them his own
proposals presumably having regard to the different points of view which had been expressed by
both these parties. The decision in regard to the scales of wages, was, as we have seen before, a
majority decision which was not endorsed by the representatives of the employers. The proposals of
the chairman also were not acceptable to the representatives of the employers but the
representatives of the employees accepted them and they thus became the majority decision of the
Wage Board. The ultimate decision of the chairman on those points does not appear to have been
the result of any consideration of the capacity of the industry to pay as a whole or region-wise but
reflects a compromise which he brought about between the diverse views but which also was
generally accepted only by the representatives of the employees and not the representatives of the
employers. Nowhere can we find in the instant case any genuine consideration of the capacity of the
industry to pay either as a whole or region-wise. We are supported in this conclusion by the
observations of the chairman himself in the note which he made simultaneously with the
publication of the decision on April 30, 1957, that it was difficult for the Wage Board at that stage to
work out with any degree of precision, the economic and other effects of the decision on the
newspaper industry as a whole.
333. An attempt was made on behalf of the respondents in the course of the hearing before us to
shew that by the conversion of the currency into naye pyse and the newspapers chargeing to the
public higher price by reason of such conversion, the income of several newspapers had appreciably
increased. These figures were, however, controverted on behalf of the petitioners and it was pointed
out that whatever increase in the revenue was brought about by reason of this conversion of priceExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

into naye pyse was more than offset by the fall in circulation, ever rising price of newsprint and the
higher commission, etc., which was payable by the newspaper establishments to their commission
agents. The figure as worked out need not be described here in detail; but we are satisfied that the
conversion of the price into naye pyse had certainly not the effect which was urged and did not add
to the paying capacity of the newspaper establishments.
334. The very fact that the Wage Board thought it necessary to express a pious hope that if there is a
good paper and it deserves to exist, the Government and the public will help it to continue, and also
desired the interests which it felt had been hit hard by its decision not to pass judgment in haste, but
to watch the effects of its decision in actual working with patience for a period of 3 to 5 years, shows
that the Wage Board was not sure of its own ground and was publishing its decision merely by way
of an experiment. The chairman urged upon the Government of India the desirability of creating
immediately a standing administrative machinery which could also combine in itself the functions of
implementing and administering its decision and that of preparing the ground for the review and
revision envisaged after 3 to 5 years. This was again a pious hope indulged in by the Wage Board. It
was not incumbent on the Government to fulfil that expectation and there was no knowing whether
the Government would ever review or revise the decision of the Wage Board at the expiration of
such period.
335. We have carefully examined all the proceedings of the Wage Board and the different tables and
statements prepared by them. Neither in the proceedings nor in any of the tables do we see
satisfactory evidence to show that the capacity of the industry to pay was examined by the Board in
fixing the wage structure. As we have already observed, it was no doubt open to the Board not to
attach undue importance to the statements of profit and loss accounts submitted by various
newspaper establishments, but, since these statements prima facie show that the trade was not
making profit it was all the more necessary for the Board to satisfy itself that the different classes of
the newspaper establishments would be able to bear the burden imposed by the wage structure
which the Board had decided to fix. Industrial adjudication is familiar with the method which is
usually adopted to determine the capacity of the employer to pay the burden sought to be imposed
on him. If the industry is divided into different classes it may not be necessary to consider the
capacity of each individual unit to pay but it would certainly be necessary to consider the capacity of
the respective classes to bear the burden imposed on them. A cross-section of these respective
classes may have to be taken for careful examination and all relevant factors may have to be borne in
mind in deciding what burden the class considered as a whole can bear. If possible, an attempt can
also be made, and is often made, to project the burden of the wage structure into two or three
succeeding years and determine how it affects the financial position of the employer. The whole of
the record before the Board including the chairman's note gives no indication at all that an attempt
was made by the Board to consider the capacity of the industry to pay in this manner. Indeed, the
proceedings show that the demand made by the representatives of the employees and the
concessions made by the employers' representatives were taken as rival contentions and the
Chairman did his best to arrive at his final decision on the usual basis of give and take. In adopting
this course, all the members of the Board seem to have lost sight of the fact that the essential
pre-requisite of deciding the wage structure was to consider the capacity of the industry to pay and
this, in our opinion, introduces a fatal infirmity in the decision of the Board. If we had been satisfiedExpress Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

that the Board had considered this aspect of the matter, we would naturally have been reluctant to
accept any challenge to the validity of the decision on the ground that the capacity to pay had not
been properly considered. After all, in cases of this kind where special Boards are set up to frame
wage structures, this Court would normally refuse to constitute itself into a court of appeal on
questions of fact; but, in the present case, an essential condition for the fixation of wage structure
has been completely ignored and so there is no escape from the conclusion that the Board has
contravened the mandatory requirement of s. 9 and in consequence its decision is ultra vires the Act
itself.
336. Re. 9.
337. This ground, viz., that the Board had no authority to render a decision which was retrospective
in operation in also untenable. The Wage Board certainly had the jurisdiction and authority to
pronounce a decision which could be retrospective in effect from the date of its appointment and
there was no legal flaw in the Wage Board prescribing that its decision should be retrospective in
operation in the manner indicated by it. The retrospectivity may have its repercussions on the
capacity of the industry to pay and we need not say anything more in regard to the same. We have
already dealt with it above.
338. Re. 10.
339. Ground No. 10 talks of the authority of the Wage Board to fix scales of pay for a period of 3
years, subject to review by the Government by appointing another Wage Board at the end of that
period. We are not concerned with such fixation of the period for the simple reason that the Board
has not in terms done so. The only authority which it had was to fix the rates of wages and submit its
decision in respect thereof the Government. Any pious hope expressed that the decision should be
subject to review or revision by the Government by appointment of another Wage Board after lapse
of 3 or 5 years was not a part of its decision and we need not pause to consider the effect of such
fixation of the period, if any, because it has in fact not been done.
340. Re. 11.
341. The last ground talks of the Wage Board being handicapped for want of Cost of Living Index.
This ground also cannot avail the petitioners for the simple reason that the decision of the Wage
Board itself referred in Clause 24 thereof to the all India cost of living index number published by
the Labour Bureau of the Government of India O Base 1944 : 100 and fixed the dearness allowance
in relation to the same. These statistics were available to the Wage Board and it cannot be said that
the Wage Board was in any manner whatever handicapped in that respect.
342. On a consideration of all the grounds of attack thus leveled against the validity and the binding
nature of the decision of the Wage Board, we have, therefore, come to the conclusion that the said
decision cannot be sustained and must be set aside.Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

343. The petitions will, therefore, be allowed and the petitioners will be entitled to an order
declaring that s. 5(1)(a)(iii) of the Working Journalists (Conditions of Service) and Miscellaneous
Provisions Act, 1955, is ultra vires the Constitution of India and that the decision of the Wage Board
dated April 30, 1957, is illegal and void.
344. As regards the costs, in view of the fact that the petitioners have failed in most of their
contentions in regard to the constitutionality of the Act, the fairest order would be that each party
should bear and pay its own costs of these petitions.
345. Civil Appeals Nos. 699-703 of 1957.
346. These Civil Appeals are directed against the decision of the Wage Board and seek to set aside
the same as destroying the very existence of the newspaper establishments concerned and infringing
their fundamental rights. Special leave under Art. 136 of the Constitution was granted by this Court
in respect of each of them, subject to the question of maintainability of the appeals being open to be
urged.
347. These appeals are also covered by the judgment just delivered by us in Petition No. 91 of 1957 &
Ors., and the appellants would be entitled to a declaration in each one of them that the decision of
the Wage Board ins ultra vires the Working Journalists (Conditions of Service) and Miscellaneous
Provisions Act, 1955, and therefore void and inoperative.
348. In view of the conclusion thus reached, we feel it unnecessary to consider whether the appeals
would be maintainable under Art. 136 of the Constitution. The appellants having substantially
succeeded in their respective petitions under Art. 32 of the Constitution, the question has now
become purely academic and we need not spend any time over the same.
349. The result therefore is that there will be no orders save that all the parties thereto shall bear
and pay their own costs thereof.
350. Petitions allowed.
351. Appeals disposed of accordingly.Express Newspapers (Private) Ltd. And ... vs The Union Of India (Uoi) And Ors. on 19 March, 1958

