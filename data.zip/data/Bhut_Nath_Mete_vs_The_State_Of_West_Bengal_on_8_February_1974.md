Bhut Nath Mete vs The State Of West Bengal on 8 February,
1974
Equivalent citations: 1974 AIR 806, 1974 SCR (3) 315, AIR 1974 SUPREME
COURT 806, 1974 (1) SCC 645, 1974 3 SCR 315, 1974 SCC(CRI) 300
Author: V.R. Krishnaiyer
Bench: V.R. Krishnaiyer, Ranjit Singh Sarkaria
           PETITIONER:
BHUT NATH METE
        Vs.
RESPONDENT:
THE STATE OF WEST BENGAL
DATE OF JUDGMENT08/02/1974
BENCH:
KRISHNAIYER, V.R.
BENCH:
KRISHNAIYER, V.R.
SARKARIA, RANJIT SINGH
CITATION:
 1974 AIR  806            1974 SCR  (3) 315
 1974 SCC  (1) 645
 CITATOR INFO :
 R          1974 SC 816  (3)
 R          1974 SC 832  (3)
 F          1974 SC 895  (3)
 F          1974 SC1739  (4)
 F          1974 SC2120  (5)
 RF         1974 SC2240  (1)
 D          1974 SC2337  (15)
 F          1975 SC 255  (1)
 E          1975 SC 550  (8)
 RF         1975 SC 602  (7)
 R          1975 SC 638  (11)
 E          1975 SC 775  (4)
 R          1975 SC 919  (4)
 R          1976 SC1207  (207)
 RF         1976 SC1508  (13)
 E          1979 SC1945  (3,8)
 RF         1980 SC 326  (21)
 RF         1980 SC1789  (106)
 RF         1989 SC1933  (28)Bhut Nath Mete vs The State Of West Bengal on 8 February, 1974

 F          1990 SC1361  (13)
ACT:
Maintenance    of    Internal   Security    Act,    1971--s.
3--Continuance  of emergency not a justiciable  issue--Order
of detention if bad because criminal prosecutions failed--If
Government  should pass a speaking  order--Communication  of
facts  cornerstone of right of  representation--Poverty  and
illiteracy if relevant to S. 3.
HEADNOTE:
The petitioner was detained under s.3 of the Maintenance  of
Internal Security Act, 1971 on the ground that he broke open
wagons and looted wheat and tea.  The report which was  sent
by  the Police to the District Magistrate was  forwarded  to
the Government and the Board.  It contained information that
the  petitioner was poor and illiterate, had  associates  in
notorious  wagon-breakers  and  anti-social  elements,   had
developed  the spirit of lawlessness and aptitude for  anti-
social  activities  and  that  many  of  the  reported   and
unreported  cases of recent and criminal activities  existed
to  his  credit besides the instances  communicated  to  the
detenu.
It  was contended that (1) there was no real  emergency  and
yet the proclamation of emergency remained unretracted  with
consequential peril to fundamental rights; (2) that sections
3(3)  and  10 of the Maintenance of  Internal  Security  Act
violated art. 22(5) of the Constitution; (3) that the  order
was  male fide because it was made after and on  account  of
the  discharge  of the petitioner in the  relative  criminal
cases;  (4)  that a speaking order should be passed  by  the
government  or  by  the Advisory Board  while  approving  or
advising   continuance  of  detention  and  (5)  that   some
irrelevant  and  uncommunicated charges had  influenced  the
authority, vitiating the order of detention.
Allowing the petition,
HELD:(1) Academic exercise in constitutional law are not for
courts  but jurists and it is not possible to hold that  the
continuance  of emergency was void. it is outside the  orbit
of  judicial control and wandering into  the  para-political
sector.  The argument is political, not a justiciable  issue
and the appeal should be to the polls and not to the courts.
[321 H]
Rex  v. Governor of Wormwood Scrubbs Prison, [1920]  2  K.B.
305, The King v. Halliday, [1917] A.C. 260, 270 and  Ringkan
v.  Government  of  Malaysia, [1970]  A.C.  379;  390;  391;
referred to.
(2)  There  is  no  inconsistency with  or  erosion  of  the
opportunity of making a representation against the order The
soul  of  art.  22  is the fair chance to  be  heard  on  allBhut Nath Mete vs The State Of West Bengal on 8 February, 1974

particulars  relied on to condemn the detenu  to  preventive
confinement.   But sec. 3(3) does not and  cannot  transcend
this  trammel and never states that particulars conveyed  to
government  and  eventually to the Board may be  behind  the
back of the detenu.  Reading the provisions liberally and as
owing allegiance to Art. 22(5), it is right to say that  all
particulars  transmitted under s.3(3) beyond the grounds  of
detention  must in no way detract from the effectiveness  of
the  detenu's  right  of  representation  about  them.   The
guarantee  of Art. 22(5) colours the construction of  s.  3.
[324 A-C]
(3)  It  is not correct to say that the order  of  detention
was bad because the criminal prosecutions have failed. it is
well-settled  that  even  unsuccessful  judicial  trial   or
proceeding  would not operate as a bar to a detention  order
or render it mala fide. [324 E-G]
Subrati v. State of West Bengal, [1973] 3 S.C.C. 250, M.  S.
Khan  v. C. C. Roze, A.I.R. 1972 S.C. 1670 and Rameswar  Lal
v. State of Bihar, [1968] 2 S.C.R. 505;511, followed.
316
(4)  There  is no substance in the argument that a  speaking
order  should  be passed by government or  by  the  Advisory
Board  while approving or advising continuance of  detention
although  a  brief expression of the  principal  reasons  is
desirable.  The communication of grounds, the right to  make
representation and the consideration thereof by the Advisory
Board  made up of men with judicial experience, the  subject
matter  being the deprivation of freedom, clearly implies  a
quasi-judicial approach.  The bare bones of natural  Justice
in this context need not be clothed with the ample flesh  of
detailed hearing and elaborate reasoning. A speaking  order,
like  a regular judicial performance, is  neither  necessary
nor  feasible.   A  harmonious  reconciliation  between  the
claims  of  security of the nation and the  liberty  of  the
citizen  through   the process of  effective  representation
before  deprivation and fair consideration by the  executive
and  the  Advisory  Board are the  necessary  components  of
natural justice, no more. [326 F]
(5)  The detention was illegal for denial of opportunity  to
make  effective  representation.  Sec. 3(3) read  with  Art.
22(5) stands contravened and the right to represent rendered
barren.   Particulars prejudicial to the detenu played  over
the  judgment  of the authorities but the  petitioner  never
knew  of  such injurious information, and could  not  answer
back.   Communication  of facts is the  cornerstone  of  the
right of representation and orders passed on  uncommunicated
materials  are unfair and illegal.  Poverty  and  illiteracy
arc  irrelevant  to  S. 3. The  spirit  of  lawlessness  and
aptitude  for  antisocial activities are  neither  here  nor
there   vis-a-vis   s.3.  Other  reported   and   unreported
instances,   though  relevant,  are  kept  back   from   the
petitioner. [328 B]Bhut Nath Mete vs The State Of West Bengal on 8 February, 1974

JUDGMENT:
ORIGINAL JURISDICTION : Writ Petition No. 1456 of 1973. Under Article 32 of the Constitution
for issue of a writ in the nature of habeas corpus.
S. J. S. Fernandez, for the petitioner.
P. K. Chakravarty, for the respondent.
The Judgment of the Court was delivered by KRISHNA IYER, J.-The petitioner, undergoing
inhibitive in- carceration in West Bengal, seeks this Court's writ to be liberated on grounds of
substantive innocence and processor injustice. Judicial vigilance is the price of liberty and freedom
of the person is a founding faith of our Republic. So it behaves us to examine the legal circumstances
of the detention in the light of the constitutional constraints under art. 22 and the procedural
safeguards of the Act (the Maintenance of Internal Security Act, 1971). A brief calendar bearing on
the landmark events, giving the core facts relevant to the legality of the detention, is necessary right
at the beginning. The order of the District Magistrate, Burdwan, which cast the petitioner into jail
recited that he was 'satisfied' that with a view to preventing the petitioner 'from acting in any
manner prejudicial to the maintenance of supplies and services essential to the community' the
direction for detention under S. 3 of the Act was being made, impeccably adhering to the mantra of
the law. The, grounds which induced the authority's satisfaction were concomitantly furnished as
required by S. 6(1), read with s. 3(2), of the Act. "You are being detained" runs the communication
.... on the grounds that you have been acting in a manner prejudicial to the supplies and services
essential to the community as evidenced by the particulars given below :--" Three specific instances
were set out of November 21, 1971, November 24, 1971 and January 13, 1972-all over seven months
prior to the detention order alleging that the petitioner and his associates (not named) broke open
wagons and 'looted' wheat and tea. There is also a statement that 'the said activity of yours thus
attracts Sec. 3 (1) (a) (iii) of the ... Act." It is a trifle mystifying that the detention order is passed
many months after the three criminal break-ins, and equally strange it is that the prisoner is
arrested only on February 22, 1973, many months after the order of detention was passed, there
being no justification of absconders. Long before the grounds of detention were served on the
detenu (February 22, 1973) the State Government had approved the District Magistrate's order
which it did on September 2, 1972. Shortly thereafter, the State Government placed the case of the
detenu before the Advisory Board under s. 10 of the Act, although the actual detention was effected
only in 1973. The affidavit-in-opposition by the Deputy Secretary to Government does not explain
these time lags between the prejudicial acts and the preventive detention order, and between the
order and the detention. The petitioner's averment in this context becomes disturbingly meaningful,
for, according to him, the instances were false and when he was prosecuted in Court, the cases
ended in his favour. He has stated in his representation to the Advisory, Board that "over the
grounds No. 1, 2 and 3 Burdwan P. S. Case No. G.R.P.S. No. 10(1)71, 9(11)71, and 6(1)72 was started.
The petitioner was arrested in connection with aforesaid case. But as the charges are false, so no
prima facie case was established against the petitioner was discharged by the learned S.D.J.M.,
Burdwan. But soon as the petitioner was discharged from the case, the petitioner again arrested andBhut Nath Mete vs The State Of West Bengal on 8 February, 1974

arbitrarily detained under MIS Act."
We will consider these aspects in a little detail later. Suffice it to say that the Advisory Board
considered the representation of the detenu and the material placed before it by the State, and
concluded on April 28, 1973 that there was sufficient cause for the detention of tile petitioner.
Thereafter, by order dated May 7, 1973, the State Government continued the detention "until the
expiration of twelve months from the date of his detention or until the expiry of D.I. Act, 1971,
whichever is later."
Both the State Government and the Advisory Board had before them, while deciding on the
propriety of the detention, the criminal biography of the petitioner, and, indeed, counsel for the
State fairly stated that the opinion and the advice were based upon the specific instances furnished
to the petitioner in the grounds of detention as well as on the dossier furnished by the
Superintendent of Police, a copy of which has been produced in Court. It looks as if this is a routine
procedure and there is a proforma for the history sheet. Column 7 thereof, apart from setting out the
three instances communicated to the detenu also mentions certain relevant and injurious
circumstances relating to the petitioner, which may be extracted here :
"The subject Bhut Nath Mete s/o L. Sambhu Nath Mete of Belari, P.S. Ausgram, Dist.
Burdwan, was born in a poor 8-L954SupCI/74 family. He got no education in his
childhood. He worked is a day labour. He used to mix up with the notorious wagon
breakers and anti- social elements. This inspired in him the criminal propensities
which shaped his future career. But to his association with the railway criminals and
antisocial elements he developed the spirit of lawlessness and acquired special
aptitude for anti-social activities and acts prejudicial to the maintenance of supplies
and services essential to +the community. For fear of assault and manhandling one of
the local people dare to say anything against him and his associates to the Police or to
any authority as a result of many cases remain unreported to the Police. Besides
many of the reported and unreported cases some of the instances of his recent
anti-social and criminal act wish were prejudicial to the maintenance of the supplies
and services essential to the community are mentioned below. . . . "
It is apparent,-and indeed it is not denied,-that the total impact of these materials on the District
Magistrate, the State Government and the Advisory Board, resulted in the initial detention and
subsequent continuation in incarceration.
We have now to see what the grounds of challenge are and the sustainability thereof in the eye of the
law and the Constitution.
Before getting to grips with the contentions we may indicate the constitutional dimensions of the
freedom of which the judges are, in part, sentinels on the qui vive. Civil liberty, a constitutional
guarantee, is a strange bed-fellow with detention without trial, a British bequest. Begun from the
days of the East India Company, our freedom fighters, including the Father of the Nation, have
endured its repressive impact and so when the somber, colonial story came to a close, our foundingBhut Nath Mete vs The State Of West Bengal on 8 February, 1974

fathers enshrined freedom of the person as a fundamental right. But as realists they know that we
became free amidst blood bath and chaos and the environs oil belligerency. The, delicate balance
between security and liberty had to be kept, conscious that, in the contemporary world, war is to
peace near allied and 'this partition do their bounds divide' and the defenses of a nation can be
destroyed and the morale of its people broken not only by external aggression but also by internal
disruption. The sensitive underside of the nation can be wounded by those who break up public
order, breach State security, blow up essential supplies and services; and so, as an unhappy
necessity, preventive detention, apart from punitive prison term, was recognised and provided for.
Being committed to the rule of law, primary article of faith, the framers of the Constitution
mistrusted uncanalised power in the Executive and wrote into the paramount law provisions
regulating preventive detention and proclamations of emergencies. After all, Lord Anton's dictum
that absolute power corrupts absolutely was for them no new knowledge, and Lord Atkin's great
words in Liversidge V. Anderson(1) that amid the clash of arms the laws are not silent, that (1)
[1942] A. C. 205 they may be changed, but they speak same language in war and peace, reverberated
in their ears. Therefore, where freedom is in peril and justice is threatened the citizen shall receive
the fullest protection from the Court within the four corners of art. 22, benignantly stretched, and
the safeguards of the Act liberally interpreted-within legitimate limits. The worth of the human
person is a cherished value carefully watched over by the Court. Such is the judicial perspective in
the application of art. 22 to the MISA, which it contains, controls and animates. Indeed, this Court.
by a series of creative pronouncements has built into vast powers vested in the Administration by
the MISA and its predecessors legal bulwarks, breakraters and blinkers which have largely
humanised the harsh authority over individual liberty otherwise exercisable arbitrarily by executive
fiat. In this case, we, are concerned with a limited canvass, for, in a sense, the court's control
through review is peripheral,. processor and yet crucial. The area of judicial `embudsmania' which
obtrudes into our attention in the present case relates to the observance- of natural justice to the
partial but compulsory extent the law of the Constitution and the law under the Constitution,
obligate. There is a limited 'judicialisation' of administrative acts that art. 22 insists on, which is
express, explicit and mandatory and admits of no exceptions.
Article 22(5) is principled and pragmatic, flexible but firm and enforces the right to be heard
without overloading the administrative process with judicial trappings. It reads "(5) When any
person is detained in pursuance of an order made under any law providing for preventive detention,
the authority making the order shall, as soon as may be, communicate to such person the grounds
on which the order has been made and shall afford him the earliest opportunity of making a
representation against the order."
The fundamental constitutional mandates are that the authority (a) shall communicate to the
detainee 'the grounds on which the order has been made-nothing less than all the material grounds
which operate to create that subjective satisfaction in the authority which spells suspension of the
citizen's liberty-and (b) shall afford him the earliest opportunity of making a representation against
the order-no avoidable delay, no shortfall in the material communicated shall disable the prisoner
making an early, yet comprehensive say on every particular or fact which has influenced the detainer
or other body to order, approve or advice the deprivation of an individual's freedom. Such is the
fairness and justice 'untouchably' entrenched in art. 22(5) when administrative action preventivelyBhut Nath Mete vs The State Of West Bengal on 8 February, 1974

drowns a sacred human right in the name of public good and organised society. The power and its
limits co-exist in constitutional amity and the MISA has effectuated this great policy in S. 3(1) and
(3) read with ss. 5(1) 10 and 11(i) and (ii). The humanist restraint so woven into the law against
executive extravagance or indifference must be strictly applied since casual and careless and
uninformed disposal of other's freedom is to break faith with the constitutional tryst. The
admonition of Patanjali Sastri, C.J., is inspirational :
" Preventive detention is a serious invasion of personal liberty and such meager
safeguards as the Constitution has provided aga inst the improper exercise of the
power must be jealously watched and enforced by the Court. In this cast;, the
petitioner has the right, under article 12(5), as interpreted by this Court by a
majority, to be furnished with particulars of the grounds of his detention "sufficient
to enable him to make a representation which on being considered may give relief to
him. We are of opinion that this constitutional requirement must be satisfied with
respect to each of the grounds communicated to the person detained, subject of
course to a claim of privilege under clause (6) of article 22."(1).
The strict construction of the statute setting the court's face sternly against encroachment on
individual liberty, keeping the delicate balance between social security and citizens' freedom, is
perfectly warranted by this Court's observation in Kishori Mohan Bera v. State of West Bengal(2)
"The Act confers extraordinary power on the executive to detain a person without recourse to the
ordinary laws of the land and to trial by courts. Obviously, such a power places the personal liberty
of such a person in extreme peril against which he is provided with a limited right of challenge only.
There can, therefore, be no doubt that such a law has to be strictly construed. Equally, also, the
power conferred by such a law has to be exercised with extreme care and scrupulously within the
bounds laid down in such a law."
In a sense this approach is only an application of the insistence of fairness when power is exercised
to effect other's rights, particularly the most sensitive of all rights- personal freedom. Natural justice
is the index of fairness, although as Sachs, L.J., indicated in In re-Pargemon Press Ltd.(3) :
"In the application of the concept of fair play there must be real flexibility so that very
different situations may be met without producing procedures unsuitable to the
object in hand". In A. K, Krapak v. Union of India(4) this Court qualified :
"The concept of rule of law would lose its validity if the instrumentalities of the State
are not charged with the duty of discharging their functions in a fair and just manner.
The requirement of acting judicially in essence is nothing but a requirement to act
justly and fairly and not arbitrarily or capriciously."
After all, one could never be too just or too fair when dealing with civil liberty.
(1) Dr. Ram Krishan Bhardwaj v State of Delhi [1953] S. C. R. 708.Bhut Nath Mete vs The State Of West Bengal on 8 February, 1974

(2) A. 1. R. 1972 S. C. 1749.
(3) [1971] 1 Ch. D. 368.
(4) A. 1. R. 1970 SC 150, With these background observations, the statutory 'musts' of the MISA may
now be delineated.
We are concerned, as earlier stated, only with some aspects of the preventive detention
jurisprudence, in the present case, and we confine ourselves to them. The District Magistrate should
be bona fide satisfied about the prejudicial activities of the detainee. Absence of bona fides in this
context does not mean proof of malice, for an order can be malafide although the officer is innocent.
The important point is that the satisfaction of the public functionary, though subjective, must be real
and rational, not colourable, fanciful, mechanical or unrelated to the objects enumerated in s. 3(1) of
the Act.
Viscount Haldane, L.C., in Shearer v.
Shields(1) drew the, line neatly thus :
"Between malice in fact and malice, in law there is a broad distinction which is not
peculiar to, any particular system of jurisprudence. A person who inflicts an injury
upon another person in contravention of the law is not allowed to say that he did so
with an innocent mind; he is taken to know the law, and he must act within the law.
He may, therefore, be guilty of malice in law, although, so far as the state of his mind
is concerned, he acts ignorantly, and in that sense innocently."
The attack on the order of detention has been delivered on the following grounds : (1) that the
grounds are ambivalent, vague and void; (2) that the particulars suffer from insufficient
communication thus crippling the constitutional right of representation; (3) that the detention is
mala fide having been made with ulterior and extraneous purpose of making up for the discharge of
the petitioner in the, criminal cases; (4) that a few acts of theft, not proximate in time to the
detention order after judicial proceedings had failed, have no rational relation to potential
prejudicial activities to stanch which it professes to have been made; (5) that the materials impelling
the detention order and supplied to the Government and the, Board add substantially to the facts
disclosed to the detenu thus hitting him below the belt and denying him the plenary opportunity to
answer the uncommunicated but damaging charges with a futuristic import; (6) that the MISA
violates art. 22(5) and is unconstitutional; and (7) that the detention has been arbitrary and may
continue indefinitely if the Proclamation of Emergency becomes a constant fact of constitutional life
and must therefore be regarded as unconstitutional. The last two were urged in another habeas
corpus application heard shortly before this one and are dealt with in a way here also.
We have to reject summarily the last Submission as falling outside the orbit of judicial control and
wandering into the para-political sector. It was argued that there was no real emergency and yet the
Proclamation remained unretracted with consequential peril to fundamental rights. In our view, thisBhut Nath Mete vs The State Of West Bengal on 8 February, 1974

is a political, not justiciable issue and the appeal should be to the polls and not to the courts. The
traditional (1) [1914] A. C. 808.
view, sanctified largely by some American decisions, that political questions fall outside the area of
judicial review, is not a constitutional. taboo but a pragmatic response of the court to the reality of
its inadequacy to decide such issues and to the scheme of the constitution which has assigned to
each branch of government in the larger sense a certain jurisdiction. of course, when a
problem-which is essentially and basically constitutional- although dressed up as a political
question, is appropriately raised before court, it is within the power of the judges to adjudicate. The
rule is one of self-restraint and of subject-matter, practical sense and respect for other branches of
government like the Legislature and the Executive. Even so, we see no force in the plea. True, an
emergency puts a broad, blanket blindfolding of the seven liberties of art. 19 and its baseless
prolongation may devalue democracy. That is a political matter do hours our ken, for the validity of
the proclamation turns on the subjective satisfaction of the President that a grave emergency, of the
kind mentioned in Part XVIII, or its imminent danger, exists. In Rex v. Governor of Wormwood
Scrubbs Prison(1) the Earl of Reading observed, on a similar contention ". . even if it is material to
consider whether the military emergency has come to an end, it is not a matter which this Court can
consider; whether the emergency continues to exist or not it is for the executive alone to determine..
. . . "
The argument of abuse of power was urged in England but repelled. In The King v.
Halliday(2) Lord Dunnedin met it thus :
"That is true. But the fault, if fault there be, lies in the fact that the British
Constitution has entrusted to the two Houses of Parliament, subject to the assent of
the King, an absolute power untrammeled by any written instrument obedience to
which may be compelled by some judicial body. The danger of abuse in theoretically
present : practically, as things exist, it is in my opinion absent."
And Lord Wright in Liversidge v. Anderson(3) added effect to the point in these words :
"The safeguard of British liberty is in the good sense of the people and in the system
of representative and responsible government which has evolved. If extraordinary
powers are here given, they are given because the emergency is extraordinary and are
limited to the period of the emergency."
of course, the British have no written constitution but the argument remains.
In the recent ruling of the Privy Council in Hinakan v. Government of Malaysia(4), the vires of a
proclamation of emergency was put in issue as unconstitutional and a fraud on power. The Judicial
Committee made short shrift of the submission in these words :
(1) [1920] 2 K. B. 305.Bhut Nath Mete vs The State Of West Bengal on 8 February, 1974

(2) [1917] A. C. 260, 270.
(3) [1942] A. C. 206.
(4) [1970] A. C. 379; 390; 391.
"Although an "emergency" to be within the article must be not only grave but such as
to threaten the security or economic life of the Federation or any part of it, the
natural meaning of the word itself is capable of covering a very wide range of
situations and occurrences, epidemics and the collapse of civil government."
"It is not for their Lordships to criticise or comment upon the wisdom or expediency
of the steps taken by the Government of Malaysia in dealing with the constitutional
situation which had occurred in Sarawak, or to inquire whether that situation could
itself have been avoided by a different approach."
"These were essentially matters to- be determined according to the judgment of the
responsible Ministers in the lights of their knowledge and experience. And although
the Indonesian Confrontation had then ceased, it was open to the Federal
Government, and indeed its duty, to consider the possible consequences of a period
of unstable government in a State that, not so long before, had been facing the
tensions of Confrontation and the subversive activities associated with it. That the
appellant regarded the, Federal Government's actions as aimed at himself is obvious
and perhaps natural; but he has failed to satisfy the Board that the steps taken by the
Government, including the proclamation and the impugned Act, were in fraudum
legis or otherwise unauthorised by the relevant legislation."
Justifiability was left open is that case, but the limits of judicial propriety were clearly drawn. The
U.S. Supreme Court has frowned on forensic examination of subjects of politics and policy which
belong to the other branches of government although in Baker v. Carr(1) a landmark ruling and Gray
v. Senders(2), constitutional questions with considerable political consequences were boldly
handled. Even the Viet Nam war came for judicial consideration. But this large and sensitive debate
about the court's power hardly arises here because basically it is a matter least fit for adjudication by
judicial methods and materials, and clearly the onus of establishing the effective end of emergency
and absence of any grounds whatever for the subjective satisfaction of the President, heavy as it is,
has hardly been discharged. Academic exercises in constitutional law are not for courts but jurists
and we decline to hold the continuance of emergency void. Nor are we impressed with the argument
that S. 3 (3) and S. 10 violate art. 22(5) of the Constitution. The vice, according to counsel, is that the
detaining authority forwards to Government not merely the grounds of detention but "such other
particulars as in his opinion have (1) 369 U. S. 186 (1962) (2) 372 U. S. 363 (1963) a bearing on the
matter"--which matter may be beyond what is communicated to the detenu. If so, the effective
opportunity to make representations against such extra material is absent and the right under art.
22 (5) is stultified. No doubt, the soul of art. 22 is the fair chance to be heard on all particulars relied
on to condemn the detenu to preventive confinement. But s. 3(3) does not- cannot-transcend thisBhut Nath Mete vs The State Of West Bengal on 8 February, 1974

trammel and never states that particulars conveyed to Government and eventually to the Board may
be behind the back of the detenu. Reading the provisions literally and as owing allegiance to art.
22(5), it is right to say that all particulars transmitted under s. 3(3) beyond the grounds of detention
must, if they have a bearing on the determination to detain, in no way detract from the effectiveness
of the detenu's right of representation about them. The guarantee of art. 22(5) colours the
construction of s. 3. So viewed, there is no inconsistency with or erosion of the 'opportunity of
making a representation against the order. Whether, in this case, any unconstitutional deficiency in
communication of such material has occurred: will be tested later. Is there any substance in the
grievance that order is mala fide, made after and on account of the discharge of the relative criminal
cases ? The detention is not punitive but preventive and the District Magistrate's order recites to
that effect. In this case, the petitioner's representation mentions the cases challenge and the
discharge of the accused by the court in regard to the very incidents pressed into service to found the
detention order. The long interval between the incidents and the orders lends probability to the
petitioner's plea that there were cases which ended in his favour, particularly because no denial nor
explanation is forthcoming on these aspects in the return. The question is whether for the reason
that criminal prosecutions have failed the detention order is bad. We think not, and there is
authority for it. in Subrace v. State of, West Bengal(1) this Court rejected an identical argument, the,
purposes of preventive detention being different from conviction and punishment and subjective
satisfaction being enough in the former while proof beyond reasonable doubt being necessary in the
latter.
"The Act creates in the authorities concerned a new jurisdiction to make orders for
preventive detention on their subjective satisfaction on grounds of suspicion of
commission in future of acts prejudicial to the community in general. This
jurisdiction is different from that of judicial trial in courts for offences and of judicial
orders for prevention of offences. Even unsuccessful judicial trial or proceeding
would, therefore, not operate as a bar to a detention order, or render it male fide. The
matter is also not res integra." In M. S. Khan V. C. C. Bose(2) a similar view was
expressed and now a host of decisions had made the legal position unchallengeable. A
note of caution, however, needs to be struck since absolute scrupulousness is
expected of authorities exercising this exceptional power. This is not a power to put
behind bars anyone you regard as dangerous or rowdyish or irrepressible or difficult
of being got rid of by proof of guilt in court. This is an instrument for protecting the
community against specially (1) (1973) 3 SCC 250. (2) A. I. R. 1972 S. C. 1670.
injurious types of anti-social activity statutorily enunciated. If extraneous motives adulterate the use
of power, the court must nullify it. Observations in Rameshwar Lal v. State of Bihar(1) serve as a
warning :
"The appellant was tried for the offence and acquitted as far back as February 1967.
This ground discloses carelessness which is extremely disturbing. That the detaining
authority does not know that the appellant was tried and acquitted months before,
and considers the pendency of the case against him as one of the grounds of
detention shows that due care and attention is not being paid to such serious mattersBhut Nath Mete vs The State Of West Bengal on 8 February, 1974

as detention without trial. If the appellant was tried and acquitted, Government was
required to study the judgment of acquittal to discover whether all these allegations
had any basis in fact or not. One can understand the use of the case if the acquittal
was technical but not when the case was held to be false."
After all, however well-meaning Government may be, detention power cannot be quietly used to
subvert, supplant or to substitute the punitive law of the Penal Code. The immune expedient of
throwing into a prison cell one whom the ordinary law would take of, merely because it is irksome to
undertake the inconvenience of proving guilt in court is unfair abuse. To detain a person after a
court has held the charge false is to expose oneself to the criticism of absence of due care and of
rational material for subjective satisfaction. After all, the responsible officer, aware of the value of
civil liberty even for undesirable persons, must make a credible prediction of the species of
prejudicial activity in s. 3(1) before shutting up a person. It may perilously hover around illegality, if
a single act of theft or threat, for which a prosecution was launched but failed, is seized upon after,
say, a year or so, for detaining the accused out of pique, The potential executive tendency to shy at
courts for prosecution of ordinary offences and to rely generously on the easier strategy of subjective
satisfaction is a danger to the democratic way of life. The large number of habeas corpus petitions
and the more or less stereotyped grounds of detention and inaction by way of prosecution, induce us
to voice this deeper concern. Moreover, a criminal should not get away with it as an unconvicted
detenu if the rule of law is a live force. The ritualistic recital of one or two thefts followed by
incantatory statutory phrases in the order, unsupported even by the affidavit of the detaining
authority may in some circumstances lead to an inference that the order is in fraudum legis. In the
present case such an argument has been made but we are not satisfied that there was foul exercise of
power merely because the courts have discharged the accused or a competent affidavit has not been
filed. True, we should have expected an affidavit from the detaining authority but even that is felt
too inconvenient and a Deputy Secretary who merely peruses the records and swears an affidavit in
every case is the poor proxy. Why is (1) [1968] 2 S. C. R. 505; 511.
an affidavit than needed at all? The fact of subjective satisfaction, solemnly reached considering
relevant and excluding irrelevant facts, sufficient in degree of danger and certainty to warrant
preemptive casting into prison, is best made out by the detaining District Magistrate, not one who
professionally reads records and makes out a precise in the form of an affidavit. The purpose is
missed, going by the seriousness of the matter, the proof is, deficient, going by ordinary rules of
evidence, and the Court is denied the benefit of the word of one who takes responsibility for the
action, if action has to be taken against the detainer later for misuse. We are aware that in the
exigencies of administration, an officer may be held up far away, engrossed in other important work,
thus being unavailable to swear an affidavit. The next bust would then be the oath of one in the
Secretariat Who officially is cognisant of or has participated in the process of approval by
Government--not one who, long later, reads old files and gives its gist to the court. Mechanical
means are easy but not legitimate. We emphasize this infirmity because routine summaries of files,
marked as affidavits, appear in the returns to rules nisi, showing scant courtesy to the constitutional
gravity of deprivation of civil liberty. In some cases where a valid reason for the District Magistrate's
inability to swear affidavits directly has been furnished, this Court has accepted the concerned
Deputy Secretary's affidavit. This should, however, be the exception, not the rule. We may refer inBhut Nath Mete vs The State Of West Bengal on 8 February, 1974

this context to the rulings in Ranjit Dam v. State of West Bengal, (1), J. N. Roy v. State of West
Bengal, (2) and Shaik Hanif and others v. State of West Bengal.(3) We need not proceed further with
this aspects, in the ultimate view we take on this writ petition. We are not persuaded that a speaking
order should be passed by Government or- by the Advisory Board while approving or advising
continuance of detention although a brief expression of the principal reasons is desirable. The
communication of grounds, the right to make representation and the consideration thereof by the
Advisory body made up of men with judicial experience the subject-matter being the deprivation of
freedom, clearly implies a quasi-judicial approach. Indeed. where citizen's rights are affected by an
authority, the question is not so much the mould into which the nature of the act should be fitted
but the nature of the consequence which obligates impartiality, judicial evaluation and reasoned
conclusion on facts. as distinguished from policy formulation and zealous imple- mentation
regardless of two sides and weighing of evidence. Thebare bones of natural justice in this context
need not be clothed with the ample flesh of detailed hearing and elaborate reasoning. It must be
self-evident from the order that the substance of the charge and the essential answer in the
representation have been impartially considered. We do not think that a speaking order like a
regular Judicial performance is either necessary or feasible. Article 22(5) (1) A. I. R. (1972) SC 1753.
(2) A. I. R. (1972) SC 2143. (3) Writ Petitions Nos. 1679 etc; judgment on February 1, 1974.
also does not compel us to reach a different conclusion. After all,. we must remember that a
harmonious reconciliation between the claims of security of the nation and the liberty of the citizen
through the process of effective representation before deprivation and fair consideration by the
Executive and the Advisory Board are the necessary components of natural justice. Not more. In
times of emergency, security of the State and essential supplies and services of the community
assume great importance and demand quicker action. At the same time, we cannot underrate the
right of the citizen and cannot forget the words of Justice Jackson in Knaff v. Shaughnassy : (1)
"Security is like liberty in that many are the crimes committed in its name. The menace to the
security of this country be it great as it may, from this girl's admission is as nothing compared to the
menace to free institutions inherent in procedures on this pattern.... The plan that evidence of guilt
must be secret is abhorrent to free men, because it provides a cloak for the ma levolent, the
misinformed, the meddlesome and the corrupt to play the role of informer undetected and
uncorrected."
What has to be underscored is the obligation to make a fair communication of the grounds and the
particulars sufficient to enable the detainee to explain his innocence. Faceless informers flourish
where confrontation by cross- examination is absent, and orders with the inscrutable face of a
sphinx are not uncommon where subjective satisfaction is sufficient. All the more reason why there
should be a meaningfull comprehensive furnishing of essential particulars so that the executive
agencies may be rigorously held to the standards implied by the courts in art. 22(5). Otherwise, in
the language of Justice Frank further, "he that takes the procedural sword shall perish with that
sword." Administrative absolution is incongruous with our constitutional scheme. If control of
liberty in an emergency-Barbed-wire entanglements of freedom by the executive--is necessary.
control of control is in some measure healthy because power in the minions of government can be
'of an encroaching nature'. Reference was made at the bar in this context to Allen's "Law and
Orders", and Markose's "Judicial Control of Administrative Action"- In the petitioner's case theBhut Nath Mete vs The State Of West Bengal on 8 February, 1974

gravamen of his 'grievance is that some irrelevant and uncommunicated charges have influenced the
authority, vitiating the order. We would not view with unconcern violation on this score, if made
out. It is common ground that the police have sent to the District Magistrate (who in turn has
forwarded to the Government and the Board) a blistering bio-data. It states that (a) he is poor and
illiterate, (b) has associates in notorious wagon breakers and anti-social element, (c) has developed
spirit of lawlessness and aptitude for anti-social activities, (d) many of the (1) 338 U. S. 537.
reported and unreported cases of recent anti-social and criminal activities exist to his credit besides
the instances communicated to the detenu. Fairly considered, this report has been present to the
minds of the authorities but withheld from the affected party, Poverty and illiteracy are outrageously
irrelevant to S. 3. The spirit of law- lessness and aptitude for anti-social activities are neither here
nor there vis-a-vis s. 3. Other reported and unreported' instances though relevant are kept back
from the petitioner. If such be the case. s. 3(3)., read with art. 22(5), stands contravened and the
right to represent rendered barren. And yet particulars prejudicial to the detenu played over the
judgment of the authorities but the petitioner never knew of such injurious information, and could
not answer back. This Court in many weighty pronouncements over two decades has stressed that
art. 22(5) vests a real, not illusory right, that communication of facts is the cornerstone of the right
of representation and orders based on uncommunicated materials are unfair and illegal.
Before parting with this case,( we wish to express our disquiet that more theft even of copper wire,
unless in association with other facts may not give rise to an inference of proclivities of the type
mentioned in s.3(1). Some proximity in time between the acts and the order. sonic indications of
activities disrupting supplies and services to the community and more 'trendy' behaviour warranting
pre- ventive measures. must be available before the extreme step of detention without trial is
clamped down. A sober prognosis by the District Magistrate of the detainee's dangerous behaviour
must be wellgrounded, even if impervious to judicial probe. We cannot dismiss as accidental that in
this area of the law, in two leading cases, two judges, Bose. J., and Bhagwathy. J., have referred to
the, Bestille not that we express our approbation of its use. Executive care and Advisory Board's
vigilance are the hopeful sentinels checking on the misapplication of the MISA. unwittingly to rob
the people of the Republic of civil liberties.
We may emphasise that to minimise processor justice to mere communication and consequent
representation is not to reduce that prescription to a rove of sand, and to make subjective
satisfaction a sufficient prerequisite to detention is not to reduce judicial review to a brutum fulmen.
We hold that the detention in this case is illegal for denial of opportunity to make effective
representation and direct that the petitioner be set free.
P. B. R.Bhut Nath Mete vs The State Of West Bengal on 8 February, 1974

