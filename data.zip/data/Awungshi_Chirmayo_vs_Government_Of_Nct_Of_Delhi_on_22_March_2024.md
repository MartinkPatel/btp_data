Awungshi Chirmayo vs Government Of Nct Of Delhi on 22
March, 2024
Author: J.K. Maheshwari
Bench: Sudhanshu Dhulia, J.K. Maheshwari
                                                                                      1
2024 INSC 249                                                      NON−REPORTABLE
                                    IN THE SUPREME COURT OF INDIA
                                   CRIMINAL APPELLATE JURISDICTION
                                 CRIMINAL APPEAL NO.__________ OF 2024
 (ARISING OUT OF SPECIAL LEAVE PETITION (CRIMINAL) NO.8034 OF 2018)
            AWUNGSHI CHIRMAYO AND ANR.                                 ...APPELLANTS
                                                  VERSUS
            GOVERNMENT OF NCT OF DELHI
            AND OTHERS                                              …RESPONDENTS
                                              JUDGMENT
Leave granted.
2. The appellants before this Court are the two cousins of the deceased who was found dead in her
rented accommodation in House No.424−B, Ground Floor, Chirag Delhi on 29.05.2013. The
deceased was a 25 years old young girl who was a permanent resident of Manipur and at the
relevant time was working in a call centre at Delhi. The post mortem was conducted next day on
30.05.2013 which recorded following observations:
“a) Part of nose is missing over right side and piece of it is attached on the left side.
b) Nibbling marks present over both the upper eye lids
c) wound size of 5 cm is present over dorsum of right foot; margins are irregular and
show nibbling marksAwungshi Chirmayo vs Government Of Nct Of Delhi on 22 March, 2024

d) all wounds are post mortem in origin” The cause of death could not be ascertained
in the post mortem report.
3. Some puzzling facts of this case leading to this appeal are that the First Information Report (for
short ‘FIR’) was only registered by the police on 31.05.2013, initially under Section 306 of Indian
Penal Code (for short ‘IPC’), against unknown persons, when there was blood spattered all over the
room and the face of the deceased was smashed, as we are given to understand. It was only later
converted to a case under Section 302 of IPC. Initially, investigation was conducted by the Crime
Branch and a second post mortem report was submitted again with no clear cause of death
determined.
4. The body of the deceased was discovered on 29.05.2013 by the landlord of the tenanted premises
who alerted PCR at 11am on the same day and this was recorded as DD No. 20A. The post− mortem
of the deceased was conducted on 30.05.2013 by a Senior Resident of the All India Institute of
Medical Sciences (AIIMS) who recorded injuries on the body of deceased, while opinion about the
cause of death was not given and the viscera analysis report and other reports from Central Forensic
Science Laboratory (CFSL), were yet to come.
5. The FIR No. 253 of 2013 was registered on 31.05.2013 at Police Station, Malviya Nagar against
unknown accused persons under Section 306 of the Indian Penal Code, 1860 (hereafter “IPC”). The
investigation was transferred to the Crime Branch, Malviya Nagar the next day, i.e., 01.06.2013 and
pursuant to representations by the appellants, offence under Section 302 of IPC was added. On
04.06.2013 a second post−mortem was conducted by a Medical Board of three doctors from
Maulana Azad Medical College & Lok Nayak Hospital, and noted eleven injuries on the person of
deceased−victim, however, the opinion regarding the cause of death was not given due to the
pendency of viscera chemical analysis and histopathology reports.
6. Meanwhile, the appellants herein had filed Writ Petition (Criminal) No. 1364 of 2013 before the
Delhi High Court praying for direction for the investigation to be given to the Central Bureau of
Investigation (for short ‘CBI’), who is also respondent No. 3 in the present matter. During the
pendency of this Writ Petition, an order dated 11.04.2017 was passed recording the submission
made by the counsel for Government of NCT that the final report which was submitted on
24.02.2015 under Section 173 of CrPC before the Chief Metropolitan Magistrate (South), has been
agreed to be withdrawn and matter will be subjected to further investigation.
7. The High Court ultimately dismissed this Writ Petition for reasons which are four−fold. Firstly, it
was noted that polygraph test had been conducted on the suspects Raj Kumar and Amit Sharma on
26.12.2013, however, no opinion could be formed about their involvement. Secondly, the DNA of the
semen samples recovered from the undergarment of the deceased did not match with the DNA
samples of the accused. Thirdly, the boyfriend of the deceased had not joined investigation, he was
absconding and could not be traced. Fourthly, despite the post mortem conducted on the deceased,
there was no conclusive cause of death which could be ascertained.Awungshi Chirmayo vs Government Of Nct Of Delhi on 22 March, 2024

8. While considering all these factors, the High Court was of the opinion that simply because the
premises of the landlord had an access to the room of the deceased it could not be said that they
were guilty of committing the crime, the relevant observations of the High Court are as follows:
“19. The investigation has been carried out by the investigating agency seemingly
without any bias. Nothing has emerged on record if the landlord Raj Kumar and his
brother− in−law Amit Sharma were having strong connection with any politician to
influence the investigation. The petitioners have not furnished clinching evidence to,
prima facie, infer the involvement of Raj Kumar and Amit Sharma in the crime. Their
suspicion is based upon ‘no evidence’.
Merely because, the landlord and his brother− in−law had access to the victim’s room
by scaling the 7 feet grill, it cannot be inferred at this stage that it was they who had
committed the crime.
20. Since all efforts have been made by the Crime Branch to solve the case, handing
over the investigation to CBI, at this stage, would serve no purpose. Investigation to
CBI can be ordered only in exceptional situation and such an order is not to be passed
as a routine merely because, a party has levelled vague allegations. [‘State of West
Bengal & Ors. vs. Committee for Protection of Democratic Rights’, 2010 (3) SCC
571].”
9. This order of the High Court is presently under challenge before this Court, where the appellants
pray that a thorough investigation be done by CBI. Vide Order dated 05.02.2019, this Court had
constituted Special Investigation Team (SIT) to monitor the investigation. The SIT so constituted
submitted two status reports on 25.07.2019 and 21.10.2019. All the same, the investigation which
has been conducted by the police and later by the SIT yielded no conclusive result. The SIT in its
report has reached the following conclusion:
“From the investigation conducted so far, circumstantial evidences suggest that Ms.
A.S. Reingamphi @ A.S. Solam D/o Sh. A.S. Chihanpam r/o Village−Choithar,
Ukhrul−District, Manipur had committed suicide by consuming some
poison/medicine, though the viscera reports did not reveal presence of any common
posion/medicine in the exhibits. Till now there is no evidence on record to support
the allegation of murder or abetment of suicide or foul play or commission of any
other offence in this case.
−Sd− Dy. Commissioner of Police Crime (Cyber & FICN), Delhi
10. The present appellants, who are close relatives of the deceased and are residents of the State of
Manipur, have always claimed that it is a case of rape and murder, and the police is trying to shield
the accused. The deceased comes from a “Ukhrul” District in the State of Manipur, which is far away
from Delhi. The kith and kin of the deceased, who are before this Court are only praying for an
effective investigation so that the culprits can be apprehended and brought to justice.Awungshi Chirmayo vs Government Of Nct Of Delhi on 22 March, 2024

11. Apparently there seems to be no reason for a young girl of 25 years of age to commit suicide.
Prima facie it does not seem to be a case of suicide. The crime scene shows that blood was spattered
on the floor and the bed sheet was completely drenched in blood. It appears to be a homicidal death
and therefore the culprits must be apprehended.
12. Mr. K.M. Nataraj, learned Additional Solicitor General of this Court, in his usual fairness
submits that he has no objection, if the investigation in the present case is handed over to the CBI.
13. In a seminal judgment reported as State of West Bengal and Others vs Committee for Protection
of Democratic Rights, West Bengal and others (2010) 3 SCC 571, this Court has discussed in detail
inter alia the circumstances under which the Constitutional Courts would be empowered to issue
directions for CBI enquiry to be made. This Court noted that the power to transfer investigation
should be used sparingly, however, it could be used for doing complete justice and ensuring there is
no violation of fundamental rights. This is what the Court said in Para 70:
“70…Insofar as the question of issuing a direction to CBI to conduct investigation in a
case is concerned, although no inflexible guidelines can be laid down to decide
whether or not such power should be exercised but time and again it has been
reiterated that such an order is not to be passed as a matter of routine or merely
because a party has levelled some allegations against the local police. This
extraordinary power must be exercised sparingly, cautiously and in exceptional
situations where it becomes necessary to provide credibility and instil confidence in
investigations or where the incident may have national and international
ramifications or where such an order may be necessary for doing complete justice
and enforcing the fundamental rights… emphasis supplied
14. The powers of this Court for directing further investigation regardless of the stage of
investigation are extremely wide. This can be done even if the chargesheet has been submitted by
the prosecuting agency. In the case of Bharati Tamang v. Union of India and Others (2013) 15 SCC
578, this Court allowed the Writ Petition filed by the widow of late Madan Tamang who was killed
during a political clash and directed investigation by the CBI which would be monitored by the Joint
Director, CBI. The following observations were made in Para 44:
“44…Whether it be due to political rivalry or personal vengeance or for that matter
for any other motive a murder takes place, it is the responsibility of the police to
come up to the expectation of the public at large and display that no stone will remain
unturned to book the culprits and bring them for trial for being dealt with under the
provisions of the criminal law of prosecution. Any slackness displayed in that process
will not be in the interest of public at large and therefore as has been pointed out by
this Court in the various decisions, which we have referred to in the earlier
paragraphs, we find that it is our responsibility to ensure that the prosecution agency
is reminded of its responsibility and duties in the discharge of its functions effectively
and efficiently and ensure that the criminal prosecution is carried on effectively and
the perpetrators of crime are duly punished by the appropriate court of law.”Awungshi Chirmayo vs Government Of Nct Of Delhi on 22 March, 2024

15. This Court has expressed its strong views about the need of Courts to be alive to genuine
grievances brought before it by ordinary citizens as has been held in Zahira Habibulla H. Sheikh v.
State of Gujarat (2004) 4 SCC 158.
16. It is to observe that unresolved crimes tend to erode public trust in institutions which have been
established for maintaining law and order. Criminal investigation must be both fair and effective.
We say nothing on the fairness of the investigation appears to us, but the fact that it has been
ineffective is self evident. The kith and kin of the deceased who live far away in Manipur have a real
logistical problem while approaching authorities in Delhi, yet they have their hope alive, and have
shown trust and confidence in this system. We are therefore of the considered view that this case
needs to be handed over to CBI, for a proper investigation and also to remove any doubts in the
minds of the appellants, and to bring the real culprits to justice.
17. In view of the discussion made above, the order of the Delhi High Court dated 18.05.2018,
dismissing the prayer of the present appellants to transfer the investigation to CBI is hereby set
aside. The appeal is hereby allowed and we direct that CBI to hold enquiry in the matter. The case
shall be transferred from SIT to the CBI. The SIT, which has so far conducted the investigation in
the matter, will hand over all the relevant papers and documents to CBI for investigation. After a
thorough investigation, CBI will submit its complete investigation report or charge sheet before the
concerned court as expeditiously as possible.
Pending application(s), if any, shall stand disposed of.
…….....………………………….J. [J.K. MAHESHWARI] ………...……….………………….J. [SUDHANSHU
DHULIA] NEW DELHI;
MARCH 22, 2024.Awungshi Chirmayo vs Government Of Nct Of Delhi on 22 March, 2024

