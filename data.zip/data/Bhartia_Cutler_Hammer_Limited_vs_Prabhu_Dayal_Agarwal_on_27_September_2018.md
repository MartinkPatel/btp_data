Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27
September, 2018
            In the Court of Ms. Vineeta Goyal: Additional District Judge 
                       (South District) Saket Court Complex, New Delhi.
Suit no. 5597/2016
CNR no. : DLST01−000001−1988
1.
 Bhartia Cutler Hammer Limited.
Having its registered office at 1/E,  216 Acharya Jagdish Chandra Bose Road, Calcutta
Principal office at 1101 New Delhi House, 27, Barakhamba Road, New Delhi.
2. O.P. Bhartia Chairman & Managing Director Bhartia Cutler Hammer Limited 1101 New Delhi
 House 27 Barakhamba Road, New Delhi− 110001               ...Plaintiffs Versus
1. Prabhu Dayal Agarwal S/o Shri S.N. Agarwal
2. Smt. Sulochana Agarwal W/o Prabhu Dayal Agarwal Suit no. 5597/16 Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 1 of 161
3. Govind Agarwal S/o Sh. S.N. Agarwal All Residence of A−62, Mayfair Gardens, New Delhi.
4. Mrs. C.A. Hiranandani W/o Sh. A.D. Hiranandani R/o 3, Sunditta Apartment, 10−
A, Mount Pleasant Road Malabar Hills, Mumbai                                   .....Defendants
Suit  presented on  : 16.08.1988 Arguments concluded on  : 06.08.2018 Judgment pronounced on 
: 27.09.2018 Appearance : Sh. Peeyoosh Kalra with Ms. Sona  Babbar,      Counsels for the plaintiff.
    Sh.Harish Malhotra−Senior Advocate, Sh. N.K.      Kantawala, Counsels for the defendants.
J U D G M E N T
1.  The plaintiffs have filed a suit for declaration, possession,
injunction, rendition of accounts etc. against the defendants.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 2 of 161
2. Facts as averred in the plaint are that Shri Prabhu Dayal Agarwal,   defendant   no.   1   was  
working   as   General   Manager   with   the plaintiff no. 1 during the period 1973 −
 1984 and thereafter functioned as
Executive Director and being a confidant and close friend of the plaintiffBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

no. 2 was entrusted with and functioned as in−charge of the day−to−day dealings,   management  
and   business   affairs   of   the   plaintiff   no.   1.   The
defendant no. 1 was also involved in the formulation and implementation
of the overall policies and conduct of the business and financial affairs of plaintiff   no.   1.   During  
the   period   he   was   functioning   as   General
Manager/Executive Director, defendant no. 1 was in overall charge of the factory   and  
establishments   of  plaintiff  no.   1   and  was   instrumental   in
guiding and supervising the maintenance of books of accounts and other statutory  records.  It   is
 averred  that   defendant   no.  1   was  also dealing
with suppliers and customers of plaintiff no. 1 and representing plaintiff
no. 1 in its dealings with them and negotiating and finalizing contracts as   also   their   execution  
and   implementation.   While   functioning   as
General Manager, defendant no. 1 was dealing with and supervising the work   of   other   employees,
  negotiating,   finalizing   and   entering   into contracts   and   business   transactions   involving  
plaintiff   no.   1,   various financial and accounting matters including supervision and maintenance
of accounts and records and dealing with the Auditors. At the relevant time,   accounts   of   the  
plaintiff   no.   1   were   being   maintained   under
directions of the defendant no. 1 who had authority to operate thereon. The   defendant   no.   1   also
  used   to   authorize   expenditure   in   respect   of transactions involving the plaintiff no. 1.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 3 of 161 2.1. It   is   averred   that  
during   the   year   1981,   defendant   no.   1 represented   to   the   plaintiffs   that   there   was   a  
need   for   providing   a Company House in Delhi which could be used by him and other Senior
Executives   of   the   Company   and   further   that   he   was   in   contact   with
certain estate agents/property brokers for the purpose of acquiring some
plot which could be built upon by the plaintiff no. 1 for the aforesaid purpose.   In   early   June,  
1981,   the   defendant   no.   1   represented   the
plaintiff no. 2, Chairman & Managing Director of plaintiff no. 1 that free hold  plots  for  direct
 purchase  on reasonable prices  were  not  available
and that he had offered a proposal in respect of a plot of leasehold land in Mayfair   Gardens,   New  
Delhi   which   could   be   constructed   upon   and
ultimately acquired and that the estate agent had offered to arrange for
the transaction according to the prevalent market practices in respect of
such plots. The defendant no. 1 represented that as per information with
him, one Mr. Malhotra had already entered into a transaction with the
allottee of the said plot but the estate agent had represented to him that the   transaction   could   be  
switched   over   if   Mr.   Malhotra   was   paid   the
amount invested by him. The defendant no. 1 had represented to and
assured the plaintiff no. 2 that he would assume personal responsibility
for the transaction and ensure that the investment of the plaintiff no. 1
was properly made and secured and there would be no difficulty in the
property being available to the Company. Since the defendant no. 1 was
holding a very senior and confidential position with the plaintiff no. 1,
the negotiations, modalities and finalization of the transaction regardingBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

the plot and the raising of constructions thereon was left to his charge.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 4 of 161 2.2.
It is averred that Plot no. A−62, Mayfair Gardens, New Delhi was
held by one Mrs. C.A. Hiranandani on the basis of perpetual sub−lease.
The said Mrs. C.A. Hiranandani had entered into a transaction for its sale   with   one,   Mr.   J.K.  
Malhotra   with   whom   presumably   M/s.   Vijay Dhawan   &   Co.,   Estate   Agents,   H/179/A  
Panchsheel   Park,   New   Delhi
were in contact. The defendant no. 1 on the basis of negotiations carried
on by him with the estate agents decided upon procuring the assignment of   the   arrangements  
entered   into   by   Mr.   Malhotra   with   Mrs.
Hiranandani. The defendant no. 1 had then represented to the plaintiffs that   the   transactions  
would   have   to   be   in   the   name   of   some individual/individuals   and   that   initially   he  
would   enter   into   the agreement for acquiring the lease−hold rights of the plot and for raising
constructions thereon in his name as a trustee and for and on account and   on   behalf   of   the  
plaintiff   which   could   be   at   any   later   stage   be
substituted and as per decision that the plaintiffs may make and require him   to act   upon  and 
implement.  The  plaintiffs   had  implicit   faith  and
confidence in the defendant no. 1 and trusted his words and assurances.
As per defendant no. 1's representations, desire and decision concerning
the intended transaction regarding Plot no. A−62, Mayfair Gardens, New
Delhi, the plaintiffs at defendant no. 1's behest forwarded to M/s Vijay
Dhawan & Co. Estate Agents through defendant no. 1, their cheque no.
975348 dated 08.06.1981 for Rs.1,00,000/− in favour of Mr. J.K. Malhotra and   Mr.   Malhotra,  
the   original   intending   purchaser   of   plot   aforesaid
opted out of the transaction in respect of the said plot and thereupon
defendant no. 1 negotiated the transaction in respect of the said plot and Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 5 of 161
the constructions to be raised thereon on plaintiff no. 1's account.   The
defendant no. 1, acting for and on behalf of the plaintiffs, sent a letter to
the plaintiff's Bankers, Canara Bank, Janpath, New Delhi for issue of a
Demand Draft for a sum of Rs.8 Lakhs in favour of Oriental Bank of
Commerce to the Credit of the account of Mrs. C.A. Hiranandani. The
said letter was sent by defendant no. 1 to the said Canara Bank on or about   November   24,   1981.  
The   amount   was   under   directions   of   the defendant   no.   1   debited   to   the   capital   account
  in   the   books   of   the company. Mrs. C.A. Hiranandani had obtained sanction of building plans
but   had   not   raised   any   construction   and   agreed   to   the   constructions
being raised by the ultimate purchaser and also agreed to assign and
convey her rights after obtaining requisite permissions as and when the same   were   granted.   It  
seems   that   the   defendant   no.   1   entered   into
certain agreements with and got certain documents executed from the
said Mrs. C.A. Hiranandani and kept the same with himself and never
made over the same to the plaintiffs. It also seems that permissions were obtained for additions
 and alterations to the building plans  that  wereBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

initially got sanctioned by the said Mrs. Hiranandani and the work of
constructions on the said plot was commenced under the overall charge and   supervision   of  
defendant   no.   1   and   by   utilizing   the   funds   and
connections of plaintiff no. 1. The defendant no. 1 utilized the funds of the   plaintiff   no.   1   and  
authorized   incurring   of   various   expenditure   in
relation to the work of constructions that were undertaken on the said
plot for, on behalf and on account of plaintiff no. 1. In addition to the
payment of Rs.8 Lakhs that had been made from out of the funds of the Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 6 of 161
plaintiff no. 1 to Mrs. C.A. Hiranandani, various amounts were spent on the   constructions   that  
were   raised   on   the   said   plot.   Considerable
amounts of material and services belonging to and/or paid for by plaintiff
no. 1 were under the directions of defendant no. 1 diverted/utilized for the   said  work   of
 constructions   on   A−62,  Mayfair   Gardens,   New  Delhi. Enormous   funds   and   resources   of  
the   plaintiff   were   utilized   for   the purpose   of   raising   the   constructions.   During   the  
period   1982−83,   the defendant no. 1 and various other officials of plaintiff no. 1 acting under
instructions   of   the   defendant   no.   1   expended   varying   amounts   on
procurement of constructional materials which were under the directions
of the defendant no. 1 entered in the books of plaintiff no. 1's New Delhi
office as advance for acquisition of Capital Assets. Subsequently, during
the financial year ending June 30, 1983 the cost of acquisition of various
constructional materials aggregating to Rs. 3,72,645.72 were debited to the  Capital  Account   and 
correspondingly   credited to  the  other   related
accounts. Further more, though considerable other expenses relating to
various aspects of construction on the said property were incurred from
time to time from out of the funds of plaintiff no. 1 and materials/services
procured and/or paid for by the Company were utilized in relation to the
said constructions, yet the same appear not to have been appropriately reflected   in   the   books   of
  accounts/records   of   the   plaintiff   no.   1   which books   of   accounts   and   records   were   being
  kept   under   the   directions,
control and supervision of defendant no. 1. The defendant no. 1 has not
furnished to the plaintiffs any account of the various expenses incurred in   connection   with   the  
work   of   constructions   on   the   said   plot   A−62, Bhartia Cutler Hammer Ltd. & anr v. P.D.
Agarwal & ors Page no. 7 of 161 Mayfair Gardens,  New  Delhi  despite  requests. However, so  far as 
the plaintiffs have been able to ascertain during the period 1983−84, 1984−85
materials/services of the aggregate value of Rs.7,60,972.68 have, under
instructions of and/or at the behest of defendant no. 1 been utilized/spent in   relation   to   the  
constructions   of   the   house   of   plaintiff   no.   1   at   A−2, Mayfair Gardens, New Delhi.
2.3.  The plaintiffs  further  averred that it  may be pertinent  to
mention that various constructional materials including wood, furniture, electrical   and   sanitary  
materials/fittings&   fixtures,   geysers,   air conditioners,   pumps,   motors,   paints,   hardware   and
  services   of   labour skilled   land   unskilled,   carpenters,   painters   and   construction   labour
procured in the name and/or at the expenses of the plaintiff no. 1 wereBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

utilized in connection with the work of constructions that were carried out  on the said plot  at  A−
62, Mayfair Gardens, New Delhi  during the period 1983−84 to 1985−
86. The complete details of all such expenses are
within the special knowledge of defendant no. 1 and the value of some of
the aforesaid items as could be ascertained with reference to the items involved   has   been  
mentioned   in   the   preceding   paragraphs.   The
defendant no. 1 started residing in the portion of the said premises and
got installed therein at the expense of plaintiff no. 1 various equipments,
machinery and fixtures belonging to and/or acquired by land/or in the name of the company.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 8 of 161 2.4.
It is further averred that in the later half of 1986, certain
acts of omission and commission on the part of the defendant no. 1 in
relation to the business and transactions of plaintiff no. 1 that had been
entrusted to and were being handled by defendant no. 1 came to light.
The plaintiff no. 2 then inquired from defendant no. 1 about the details of
the amounts spent in relation to the company's house at A−62, Mayfair
Gardens, New Delhi as the position concerning the same was not clear from   the   books   of  
accounts   and   records   that   were   being   maintained
under the supervision and charge of defendant no. 1. The defendant no. 1 promised   to   make  
available   the   requisite   information   as   also   all documents   concerning   the   said   transaction  
pertaining   to   the   capital assets   of  the  Company   but   since   then   he  has   been   avoiding   to  
do   so. Repeated   approaches   and   requests   made   for   information   have   been
ignored and neglected and no details and explanation with regard to the extent   and   the   manner  
of   expenditure   made   in   relation   to   the   said property   and   utilization   of   the   funds   of  
plaintiff   no.   1   have   been
furnished. However, the defendant no. 1 merely forwarded to plaintiff no.
2 copies of the documents as follows:−
(i)   Letter   dated   June   8,   1981   from   plaintiff   no.   1   to   M/s.   Vijay Dhawan   &   Co.,   Estate
  Agents,   Dhawan   House,   H−179/A,   Panch Sheela Park, N. Delhi enclosing the Cheque.
(ii)   Construction   Agreement   dated   9.11.82   between   Mr.   C.A.
Hiranandani and defendants 1 & 2 in respect of constructions to be raised on Plot I no. A−
62, Mayfair Gardens,New Delhi.
(iii) Agreement to sell dt. 9.11.1982 between Mr. C.A. Hiranandani Bhartia Cutler Hammer Ltd. &
anr v. P.D. Agarwal & ors Page no. 9 of 161 and defendant nos. 1 & 2 in respect of Property no. A−
62, Mayfair Gardens, New Delhi and constructions thereon.
2.5. The   plaintiffs   further   averred   that   the   defendant   no.   1
failed/omitted/avoided to furnish true, correct and complete documents, deeds,   declarations,  
affidavits   obtained   by   him   in   relation   to   the
transaction from Mrs. C.A. Hiranandani and also avoided and neglected to   disclose   true   and   fullBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

  details,   data   and   particulars   regarding
utilization of funds, data and particulars regarding utilization of funds of
the plaintiff. Being a Senior Executive entrusted with the responsibilities of   overall   management  
and   supervision   of   business   and   affairs   of   the
company and having been entrusted with the responsibilities of putting
up a company house after acquiring for and on account of the Company and   as   a   trustee   of   a  
plot   of  land,   the  defendant   no.   1   was   bound   to
render all accounts and make over the documents/properties of plaintiff
no. 1 to it. Complete papers in relation to the transactions had, however, not   been   disclosed   or  
furnished   by   defendant   no.   1   to   the   plaintiffs. Copies   sent   by the defendant   no.  1  to 
the plaintiffs  revealed  that  the
agreements with Mrs. Hiranandani that had been initially entered in the year   1981   had   been  
substituted   in   November,   1982   and   further   in
addition to defendant no. 1, his wife (defendant no. 2) was also shown as a   co−party   with   the  
defendant   no.   1.   In   the   above   circumstances,   in
respect of the documents that had been got executed by defendant no. 1
from Mrs. Hiranandani, in favour of the defendant in November, 1982, the   total   consideration  
mentioned   therein   had   proceeded   from   the Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal
& ors Page no. 10 of 161 plaintiff no. 1. Neither the defendant no. 1 nor his wife, defendant no. 2
had paid or contributed any amount, towards the consideration for the
said sale agreement. The said sum of Rs.8 Lakhs was also mentioned as a  security  deposit  in 
the construction  agreement  which  had also  been ostensibly   got   executed   by   the   defendants  
in   their   favour   from   Mrs.
Hiranandani. All the documents had not been furnished or disclosed by the   defendant   no.   1   to  
the   plaintiffs   presumably   for   motivated   and
malafide reasons. It may also be pertinent to mention that neither of the defendant   no(s).   1   and  
2   had   any   knowledge   or   experience   in   the construction business
 and the burden and benefits of the construction
contract was to be that of the plaintiffs. As defendant no. 1 was avoiding
to furnish details, data and information concerning his various activities
in relation to the period during which he was enjoying the confidence of the plaintiffs, the plaintiffs
 sought to re−check of the accounts. It was during the course of such re−
checking that it could be ascertained that materials/services   procured   and/or   paid   for   by   the  
Company   of   the aggregate value exceeding Rs.7,60,972.68 had been diverted and/or used
under the instructions and directions of defendant no. 1 in connection
with the work of constructions at A−62, Mayfair Gardens, New Delhi. The
amount had been split under various heads of expenses of the company
obviously under directions of the defendant no. 1 and integrated into the accounts   of   the  
company   under   his   instructions,   rendering   a
discovery/identification of such maneuvers difficult.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 11 of 161 2.6. It   is   further  
averred   that   during   the   relevant   period,   the
defendant no. 1 as General Manager, Chief Supervisor of the AccountsBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

was responsible for the various entries made therein. The defendant no. 1  also  provided  to  the  
Auditors  the   overall   certificates   concerning   the correctness   of   the   accounts   and   on   the  
basis   of   such   certificates,   the auditors   checked   the   accounts.   The   entries   appearing  
under   various heads   pertaining   to   the   utilization   of   materials   and   services   of   the
company having been utilized in connection with the constructions were,
it seems, under instructions of defendant no. 1 not debited to the capital
account but under other heads of expenses.
2.7. It   is   further   averred   that   the   defendant   no.   1   stopped− attending   to   his   duties   on  
or   about  August,   1985.   The  plaintiffs  have
recently discovered that defendant no. 1 has been contemplating setting
up of an Industrial Unit for manufacture of low tension electrical devices.
The defendant no. 1 has with that objects set up "North West Switchgear
Private Limited" and has started using the said property of plaintiff no. 1 at A−
62, Mayfair Gardens, New Delhi as the office and place of business
for his said Company.  The plaintiffs submitted that the defendants have
no right to use the said plot of the plaintiffs or to continue to occupy the same   or   any   portion  
thereof   either   for   themselves   or   for   any   of   their
Concerns or Companies nor have they any right to make use thereof at all   land   the   action   of   the
  defendants   in   using   the   property   for   non− residential   purpose   is   patently   illegal   and  
contrary   to   law   and   public
policy. The plaintiffs averred that they are entitled to claim and recover Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 12 of 161 possession of the property A−
62, Mayfair Gardens, New Delhi and seek
an order for delivery of possession. It may also be pertinent to mention
that the contemplated business of manufacturing and marketing of Low Tension   Electrical  
Devices   being   set   up   by   defendant   no.   1   is   based
presumably upon utilization of the knowledge and the contacts gained
during the period of defendant no. 1's employment with plaintiff no. 1
and in disregard of the understandings as to the secrecy and/or in breach
of the trust and confidence reposed by the plaintiff in defendant no. 1 by
entrusting him with the overall responsibility of business and financial
management of plaintiff no. 1 and its products. It may also be pertinent to   mention   that  
defendant   no.   1   has   wrongfully   and   in   breach   of   his
agreement/understanding/trust as aforesaid induced some of the Senior
Technical and other Executives/ staff of the plaintiff to leave the services
of the plaintiff no. 1 and thereby procured a breach of contract of their
employment. The defendant no. 1 is contemplating to make use of the special   and technical  
information  unauthorizedly  obtained from   out  of the   records   of   the   Company.   While  
working   as   General   Manager   of plaintiff  no.  1  defendant  no.  1  during  middle of November,
 1985,  was deputed abroad on a study tour for exploring/investigating possibilities of obtaining  
foreign   collaboration   for   indigenous   manufacture   of   Earth
Leakage Circuit Breakers and Miniature Circuit Breakers which items
could be taken up for manufacture by plaintiff no. 1 as complementary toBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

its then existing manufacturing activity by way of expansion.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 13 of 161 2.8.
It is further averred that subsequently, one Shri M.A. Joshi who   was   working   as   the   Works  
Manager   of   plaintiff   no.   1   was   also
deputed during April, 1986 to visit U.S.A. to study and investigate the
possibilities of indigenous manufacture of the aforesaid items. Mr. Joshi, the   then   Works  
Manager   had   by   virtue   of   his   association   with   the
manufacturing activities of plaintiff no. 1 became aware of the various technological   aspects   of  
the   products   being   manufactured   by   the
plaintiffs and contemplated to be manufactured and acquired knowledge with   regard   to   the  
manufacturing   and   trading   proprietory   and
confidential technological and other data and information.
2.9. It is further averred that both defendant no. 1 and the said
Sh. M.A. Joshi had access to all secret technical marketing and financial information   and   data   of  
plaintiff   no.   1   including   its   research   and development   facilities   with   respect   to   its  
present   and   future   product
plans. After defendant no. 1 adopted an evasive attitude land purported
to dissociate by avoiding to report in office, it seems as a part of a scheme
of wrongfully utilizing the aforesaid secret and technical information and
data as also the experience and knowledge gained during deputation to
USA regarding certain complementary items of manufacture, defendant
no. 1 wrongfully induced Shri M.A. Joshi, then Works Manager to give
up employment with the plaintiff no. 1 by resigning his job. It has now
been discovered that defendant no. 1 and the said Shri M.A. Joshi joined
hands in forming a Company called north"West Switchgears Pvt. Ltd. unauthorizedly,   wrongfully,  
in   breach   of   trust   and   without   the Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors
Page no. 14 of 161 knowledge of the plaintiffs and the defendant and Shri M.A.Joshi have
used the Company house at A−62, Mayfair Gardens, New Delhi as a place of   the   said   Company.  
Apart   from   being   wrongful,   illegal   and
unauthorized use of the Company's properties the said act of defendant
no. 1 and Shri M.A. Joshi is violative of the laws, rules, regulations and bye−
laws governing the said property since user of residential property for   business   or   commercial  
purposes   is   prohibited   by   the   mandatory provisions   of   the   Delhi   Development   Act   and  
terms   and   conditions governing   the   Indenture   of   Perpetual   Sub−Lease   in   relation   to   the
property. The said act of defendant no. 1 in the circumstances has caused
and is likely to cause  land penalties to the plaintiffs and involve them in
breaches of the law of land.  The defendant no. 1 and  Shri M.A.  Joshi
has no right to make use of the said property of the plaintiff. Besides
defendant no. 1 attempts and efforts at continuing to make use of the
said property belonging to the Company are wrongful and are adversely
affecting the rights and interests of the plaintiffs.   The defendant no. 1 by   misuse   of   the  
technical   and   financial   knowledge   and   informationBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

obtained/ gained by  him  whilst having virtually complete control  of  the day−to−
day manufacturing and trading activities of plaintiff no. 1 and by wrongfully inducing  the Works    
Manager  to  give  up his     employment with plaintiff   no. 1 and joined hands with defendant 
 no. 1 for making use of secret technical information data and  manufacturing process has acted   in  
breach   of   trust   and/or   express   and/or   implied   obligations
existing in favour of the plaintiffs.   Furthermore,  defendant no. 1 acted in    breach  of   the  trust 
 and  confidence  that  had   been  reposed in Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal &
ors Page no. 15 of 161 him   by   wrongfully   using   the   opportunity   and   funds   that   had   been
afforded   to   him   while   functioning   as   General   Manager/Executive
Director of plaintiff no. 1. Furthermore, defendant no. 1 has wrongfully
exploited for his personal gain the opportunity and contacts that were established   during   the  
visit   to   the   U.S.   for   exploring   possibilities   of
diversification of plaintiff no. 1 Company's activities and sought to use the   information   thus  
gained   at   Company's   expense   for   personal
advantages and for causing loss land detriment to the plaintiff no. 1. It has   also   come   to   the  
knowledge   of   the   plaintiff   that   another   Senior Executive   in   the   employment   of   the  
plaintiff   no.   1   in   the   Materials
Department has also been induced to give up his employment with the
plaintiff no. 1 and has since been employed/retained by defendant no. 1 in   furtherance   of   his  
wrongful   and   illegal   designs   at   utilizing   the information,   data   and   the   expertise   and  
secret   process   through   the
instrumentality of the Company being set up by the said defendant no. 1
with Shri M.A. Joshi. Further more, defendant no. 1 has been wrongfully
inducing some persons in employment of the plaintiff no. 1 to procure a breach   of   their   service  
contracts   with   the   plaintiff   no.   1   and   this
presumably is being done to cause wrongful and illegal gains for himself
land subject plaintiff no. 1 to losses and damages. The defendant no. 1
thus has been indulging in diverse acts, manifesting breach of trust and
confidence that was reposed in him during the course of his employment.
The defendant no. 1 is misusing the property, credits and connections of the   Company   as   also  
knowledge   confidential   information,   secret   and special   process/technical   information.   He  
is   obliged   not   to   use   the Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 16 of
161 property   of   the   Company   and   not   to   misuse   the   knowledge   and
information gained by him and the acts being indulged in by him apart
from being wrongful, illegal and tortuous are exposing the plaintiffs to
losses land penalties. A few months before dissociating himself from the
plaintiff Company and during the period defendant no. 1 was working as
General Manager with plaintiff no. 1, plaintiff no. 1 had divided upon
undertaking a major expansion Project involving about Rs. 20 Crores and
caused work to be done on preparation of feasibility report for the same. The   defendant   no.   1,   it
  appears   with   ulterior   motives,   introduced
unrealistic basis in making certain projections about the project viability
and profitability which is transpired upon in depth study of the report
were totally inviable and intentionally introduced to involve the company to   financial   difficulties  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

and   cause   disruption   in   its   production   and
marketing plans. The plaintiffs averred that defendant no. 1 submitted
his resignation from the post of Executive Director of plaintiff no. 1 on or about   September   11,  
1986   without   handing   over   report   charge   and without   submitting/furnishing   records,  
details,   information   concerning
the various matters that had been entrusted to him during the course of
his employment with the plaintiff. The plaintiffs called defendant no. 1
on numerous occasions for obtaining from him the aforesaid charge/other information/particulars  
but   defendant   no.   1   avoided   doing   so   and repeated approaches have been ignored.
2.10. It   is   further   averred   that   the   defendant   no.   1   has   been
wrongfully and despite requests of the plaintiffs continuing to use land/ Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 17 of 161 occupy   the   properties   of   the   company   and  
has   not   accounted   for   and
made over the same to the company. The defendant no. 2 has no right, to
or interest of any kind in constructions that had been raised over the said plot at A−
62, Mayfair Gardens, New Delhi with the utilization of the fund,  materials  and  services   belonging
 to plaintiff  no.  1. The  use and occupation   by   the   two   defendants   of   the   various   properties  
of   the Company   including   the   said   constructions   on   A−62,   Mayfair   Gardens, New   Delhi  
the   fixtures,   fittings,   installations,   furnishings,   furniture
installed and lying therein are unauthorized and wrongful nor have the
defendants any right to make use of the car belonging to the plaintiff no. 1   which   had   been   made
  available   to   the   defendant   no.   1   during   the course   of   his   employment   with   the  
Company.   North   West   Switchgear
Pvt. Ltd. has no right to make use of the premises and the constructions
comprised in the property A−62, Mayfair Gardens, New Delhi or utilize it
for having its office or commercial activities or correspondence and any use   or   occupation  
thereof   by   the   said   company   is   unauthorized   and negligent.   The   plaintiffs   averred   that  
defendant   no.   1   has   committed
numerous breaches of the trust and the confidence that were reposed in
him and has wrongfully and illegally failed to account  for the various activities  and   functions  and  
accounts   that   were   entrusted  to  him   and
further wrongfully and illegally continued to make use of the property
and assets of plaintiff no. 1. The plaintiffs averred that the defendants are   under   an   obligation   to
  discontinue   the   use   of   the   assets   and properties   of   plaintiff   no.   1   including   the  
constructions   and   other facilities   comprised   in   and   existing   on   A−62,   Mayfair   Gardens,  
New Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 18 of 161
Delhi. The plaintiffs submitted that plaintiff no. 1 is exclusively entitled
to the constructions and the various fixtures, fittings and installations
lying in and installed at the premises at A−62, Mayfair Gardens, New Delhi.   The   defendant   no(s).
  1   and   2   have   no   interest   of   any   kind whatsoever in the property at A−
62, Mayfair Gardens, New Delhi and
have no right to continue to use and occupy the constructions and the
various facilities provided therein for and on account of and in trust forBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

plaintiff no. 1. The defendant no. 3 has in any event no right to make use of   land   reside   in   the  
said   constructions   or   make   use   of   the   facilities provided   therein.   The   defendants   are  
obliged   to   stop   using   of   the
constructions and the premises belonging to plaintiff no. 1 and forming part   of   its   assets.   The  
arrangements   regarding   the   constructions   and intended   transfers   of   the   lease   hold   rights
  that   were   entered   into   by defendant no. 1 are in fact for and on account  of the plaintiffs and/or
their nominees and the plaintiffs averred that defendant no(s). 1 and 2
have no right to obtain any further documents in their names and are
obliged to nominate and assign rights under the Agreement to Sell dated
9.11.82  and the Construction Contract dated 9.11.1982 in favour of the plaintiff or its nominee.
2.11. The   plaintiffs   further   averred   that   though   ostensibly defendants   1   and   2   were  
parties   to   the   agreement   of   construction,   in
reality the benefits and burdens thereof belonged to land vested in the
plaintiffs. The consideration thereof, the security deposit of Rs.8 lakhs and   the   materials   land  
services   utilized   and   rendered   in   connection Bhartia Cutler Hammer Ltd. & anr v. P.D.
Agarwal & ors Page no. 19 of 161 therewith,   all   belonged   to   land/or   were   procured   for   at  
the   cost   and expense   and/or   on   account   of   the   plaintiffs.   The   defendants   had   no
personal interest therein and defendant no. 1 merely acted for and on
behalf of and on account of land/or as a trustee for the plaintiffs. The
plaintiffs as such were in fact and in law all along seized and possessed
absolutely of the constructions and own the licence and permissions and authorities   in   relation  
to   the   constructions   and   their   occupation,
utilization and disposal. The plaintiffs averred that defendant no. 1 is
wrongfully withholding and retaining to himself car belonging to plaintiff no.   1   of   Maruti   Make,
  bearing   Registration   no.   DBA   5831   which   was
purchased by the plaintiff no. 1 for Rs.87,985.00 since September, 1986.
The plaintiffs further submitted that the defendant no. 1 is liable to pay
damages for use and wrongful retention of the car at the rate of Rs.5000/−
per month being the normal prevalent charges for hire of such car in the
open market and return the car to plaintiff no. 1. The defendant no. 1 is
thus liable to pay for the period from October 1, 1986 to December 31,
1987 (15 months) the sum of Rs. 75,000/− on account of charges by way of damages   for   use   and  
return   the   vehicle   and   in   the   alternative.   The defendant   no.   1   is   liable   to   pay   to   the  
plaintiff   no.   1   the   amount   of Rs.87,985/−
 being the cost of replacement of the vehicle plus the damages
as above.  The cause of action in respect of the suit accrued in favour of
the plaintiff and against the defendants on various dates commencing from   June   1981   and   lastly
  when   despite   requests   and   notice,   the
defendants failed to render accounts, hand over records and documents
and/or desist from use of the properties and the constructions at A−62, Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 20 of 161
Mayfair Gardens, New Delhi and the other assets of the plaintiffs.  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

2.12.   It is further averred that the cause of action in favour of the plaintiffs   against   the  defendant
  accrued  at  Delhi,  within  the  limits   of
jurisdiction of this Court and the defendants reside and work for gain at
Delhi and as such this Court has jurisdiction to entertain and try the said   suit.   In   view   of  
aforesaid,   the   plaintiffs   have   prayed   to   grant   a
decree that defendant nos. 1and 2 have no interest in and right to occupy
any portion of the property or use any of the facilities at A−62, Mayfair Gardens,   New   Delhi   and  
further   restrain   by   a   permanent   injunction
defendant no. 1 from representing or claiming House no. A−62, Mayfair
Gardens, New Delhi as being the place of business or registered office of
M/s. North West Switchgear Private Limited from maintaining there at
any office or connected facilities, further to grant a decree of declaration that   the   benefits   and  
the   burdens   of   the   agreement   of   construction entered   into   by   the   defendant   no(s)   1  
and   2   as   builders   with   Mrs. Chandra   A.   Hiranandani   belonged   to   the   plaintiffs   and   the
  said defendants have no person right or interest or entitlement to any of the
rights of the Building therein and/or are obliged to hold it in Trust for
and on account of the plaintiffs and assign and/or deal with it and the
benefits thereof as per plaintiffs directions, to grant an order, decree or directing  the defendants 
to execute  requisite document  of  assignment/
transfer of the Lease hold and other rights in respect of the property A−
62, Mayfair Gardens, New Delhi  in favour of the plaintiffs, further to
grant a decree for delivery of possession of property no. A−62, Mayfair Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 21 of 161
Gardens, New Delhi in favour of the plaintiffs, further to grant a decree for   injunction   restraining  
defendant   no.   3   from   entering   upon   and
making any use of the property of plaintiff no. 1 at Mayfair Gardens, new Delhi,   further   to   grant  
injunction   restraining   defendant   nos.   1   and   2
from entering upon or making use of the existing constructions, fixtures,
fittings, installations and facilities on property known as A−62, Mayfair Gardens,   New   Delhi   and
  directing   the   said   defendants   to   remove
therefrom any of their belongings, further to grant an order or decree directing   defendant   no.   1  
assign   the   burden   and   the   benefits   of   the
contracts pertaining to the constructions and the other rights in relation to   A−62,   Mayfair  
Gardens,   New   Delhi   (hereinafter   referred   to   as   suit
property) in favour of nominee/nominees of the plaintiff no. 1, further to
direct that an inquiry be made into the damages/mesne  profits payable
by defendants in respect of the unauthorized use and occupation of the existing   constructions,  
facilities,   installations,   fixtures,   fittings   and
furniture and pass a decree for payment of the same as may be found due
and payable, further to grant a decree of declaration that defendants 1
and 2 have no right to use and occupy the constructions raised on Plot no. A−
62, Mayfair Gardens, New Delhi and facilities provided therein nor have   the   defendants   1   and  
2   any   right,   title   or   interest   of   any   kind whatsoever   in   any   of   the   fixtures,   fittings,  
electrical   and   sanitary fittings,   geysers,   air−conditioners,   machinery   and   equipments   lying  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

in and installed at the suit property and that the same belonged to plaintiff no.   1,     further   to  
grant   in   favour   of   the   plaintiff   and   against   the
defendant no. 1, a decree for rendition of accounts and upon the  accounts Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 22 of 161
being rendered, a decree for recovery of the amount that may be found due,   further   to   direct  
defendant   no.   1   to   hand   over   the   car   bearing
Registration no. DBA 5831 belonging to plaintiff no. 1 and pay damages
for use and occupation thereof for the period commencing from October 1,
1986 to the day of handing over of the same to the plaintiff no. 1 at the rate of Rs.5000/−
 per month and alternatively to pay to the plaintiff no. 1 by   way   of   compensation   the   sum   of  
Rs.   87,985.00   being   the   amount
required for replacement of the vehicle together with damages for use
and occupation at the rate of Rs. 5000/− p.m. Award interest at the rate of
21% or whatever amounts may be found due and payable.
3. The   written   statement   and   the   counter   claim   have   been preferred   on   behalf   of  
Defendant   No.1   to   3.   Defendant   No.4   despite service has not appeared and was proceeded ex−
parte on 29.08.2005.
3.1. Pursuant to summons issued, defendants filed joint written statement  inter   alia  raising  
preliminary   objections   including   that   the plaint   is   undervalued;   that   the   suit   is   bad   for  
misjoinder   of   cause   of action   and   that   the   suit   as   framed   is   not   maintainable   because,  
the reliefs if granted would come in conflict with the provisions of the terms
of the purported lease deed executed between the President of India and
the Cosmopolitan Housing Society Limited (Lessee) and the Sub−Lessee
executed under the powers conferred by the Governments Grant Act. In
terms of the provisions of the said purported lease as also under the bye−
laws of the said lessee, the plaintiff no. 1 being a corporate body cannot Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 23 of 161
be a member and no person who is not a member can claim any right,
title or interest in regard to the suit property which is on purported lease
from the President of India. It is further submitted that assuming but
not admitting the allegations made in the plaint to be correct, the subject matter   of  the  suit   and
 the   reliefs   prayed   for   relate   to   a   claim   by   the
plaintiffs over or in respect of the property in question held in the name
of defendant no(s) 1 and 2, in other words, held benami for the plaintiffs.
In that event that the suit itself is barred and hit by Section 4 of the
Benami Transaction (Prohibition of the Right to Recover Property) Act, 1988.
3.2. It   is   further   averred   that   the  present   suit   for  declaration
and consequential relief and injunction are barred by limitation since the
defendant no(s) 1and 2 under the document executed in their favour way back in the year 1981−
82 and since the year 1981, the said defendants
having been in continuous possession of the suit property exercising all rights   as   owner   in  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

respect   of   the   said   property,   to   the   notice   and
knowledge of the plaintiffs and even otherwise publicly. Therefore, the
plaintiffs ought to have approached this Court for claiming any relief in
respect of the suit property within 3 years i.e. by the end of the year
1985. Even otherwise, the period of 3 years prescribed under Article 113
of the Limitation Act would run from the date of the documents, initially
executed on 21.11.1981 and again executed on 5.11.1982. The suit filed in
the year 1988 is hopelessly barred by time qua the relief of declaration and   injunction.   The   suit  
is   also   barred   qua   relief   of   possession   as   12 Bhartia Cutler Hammer Ltd. & anr v. P.D.
Agarwal & ors Page no. 24 of 161
years had expired and the defendant even otherwise is entitled to suit property   in   the   alternative,
  by   way   of   adverse   possession,   without prejudice to rights and contentions.
3.3. It is further averred that the suit is barred by the principles
of estoppel by conduct and/or otherwise by the plaintiff acquiescence in
the execution of various documents relating to property in favour of the defendants.   The  
defendants   were   spending   money   out   of   the   funds arranged   by   them   to   the   extent   of  
over   Rs.7   Lacs   for   carrying   out construction   on   the   plot   of   land,   regularly   paying   the  
property   taxes, water charges and electricity dues (from 1986), annual lease rent and incurred  
substantial   expenses   exceeding   Rs.12   Lakhs   towards
constructional improvements carried out on the said property and since
1981 the defendants are in continuous possession of the said property
exercising all rights as owner thereof publicly and in particular including
before various Municipal and other authorities to the knowledge of the
plaintiffs. In fact, amongst others the plaintiff has also sent a written
invitation to attend the house warming ceremony and the plaintiff no.2 with   his   family   members
  attended   the   house   warming   ceremony   on
07.07.1983. The defendant no(s). l & 2 are in possession and enjoyment of the   suit   property  
continuously   and   without   any   interruption   and
otherwise causing substantial improvements over the said property from
time to time at a considerable expense on the part of the defendants and
the plaintiff was and still is fully aware of the exercise by the defendants
of their rights as owners of the said property publicly including before Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 25 of 161 various   municipal   and   other   authorities.   The  
facts   given   in   the paragraph   hereinafter   in   regard   to   the   understanding/   agreement
between  the  parties   be also read  as  part   of  this   written  statement   in support   of   the   plea  
of   bar   of   estoppel   by   conduct   on   the   part   of   the plaintiffs.
3.4. It   is   further   submitted   that   the   plaintiffs   are   guilty   of
latches and delay in approaching this Court even otherwise they have
not come with clean hands. Therefore, the discretionary relief by way of
declarations and injunctions ought not to be granted and the suit as such is liable to be dismissed.Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

3.5. On merits, the defendants have averred that the true and correct  facts  are  that
 some time in the month  of  August,  1973  at  the
instance of plaintiff no.2, who invited defendant no. 2 through a common friend   Dr.   P.C.  
Kejariwal,   a   meeting   was   arranged   in   the   house   of plaintiff   no.   2   in   Calcutta,  
particularly   to   discuss   about   setting   the
affairs of plaintiff no. 1 in good order as at that time the plaintiff no. 1
was undergoing heavy losses. Earlier during 1970−1972 at the instance of
Dr. P.C. Kejariwal, the defendant no.1 had worked for the plaintiff as Materials   Manager.   Inspite  
of   five   years   of   operations   under   plaintiff
no.2, the plaintiff no. l continued to suffer heavy losses. The plaintiff no. l
had negative net worth, the losses were Rs.54.87 lakhs as against equity
of Rs.44 lakhs. The loss in 1973 alone was Rs.16.70 lakhs. The plaintiff
no. l had turned sick and the revival was bleak. The Principal Bankers of Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 26 of 161
the company, First National City Bank had recalled its entire funding of over   Rs.80   lakhs.   At  
enormous   cost   and   expense,   a   full   time   Chief Executive   from   the   collaborators   of  
plaintiff   no.   l   in   USA   Mr.   David
Harst was deputed to put the affairs of plaintiff no.1 in order but he had
also failed. The Government of India was not even prepared to extend
the Collaboration Agreement because of the extremely poor performance
of the plaintiff no. l. The company had very heavy returns of goods and
reputation of the company was bad and getting worse. The relationship of   management   and  
employees   was   at   low   ebb   and   strained.   Besides after   the   death   of   the   elder   brother  
of   plaintiff   in   1973,   there   were serious family disputes.
3.6. It is further averred that the joint venture participant M/s. Cutler−
Hammer Inc. U.S.A. completely disgusted with the performance
of plaintiff no. l had virtually written off and wanted to withdraw their
entire shareholding of 49% which they sold off to the plaintiff no. l at a
total token value of Rs.1 lac only as against face value of Rs.19.6 lacs.
They even let forego their royalty dues of all the 4 years amounting to Rs.   22   lacs.   Differences  
and   disputes   had   started   with   other   Indian partner  and  the  process  of  acquisition  by 
plaintiff  no.   2  of  his   Indian Partner's   shares   had   started.   The   plaintiff   no.   2   thus   was  
to   become absolute owner with 100% shareholding and total control of plaintiff no.
1. In 1974, the plaintiff no. 1 became Chairman and Managing Director
with complete and total control. In this background the plaintiff no. 2 wanted   someone   competent
  and   trustworthy   who   could   set   right   the Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal &
ors Page no. 27 of 161 company and make it profitable.
3.7. It   is   further   submitted   that   accordingly,   in   or   around
August 1973 the plaintiff no.2 who had acted on behalf of plaintiff no. l either   expressly   or   by  
necessary   implication   from   the   position   the
plaintiff no.2 held at that time as Deputy Managing Director with the plaintiff   no.   l   (subsequentlyBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

  4   to   6   months   later   Chairman−cum− Managing   Director)   and   the   defendant   no.1   who  
believed   that   the plaintiff no. 2 with whom he had dealings had actual authority to enter into  
transaction   on   behalf   of   the   company,   mutually   arrived   at   an
agreement in Calcutta on the following terms:−
(a) The defendant no.1 would join and work for plaintiff no.1 and also
look after affairs and other sister concerns managed by plaintiff no.2
and his family members under the overall supervision, control and direction of plaintiff no.2.
(b) In consideration for the services to be rendered by the defendant
no. l to the plaintiff no. l, besides salary and other usual perquisites
the plaintiffs agreed to pay defendant no.1 by way of profit sharing
5% of the profits (before tax) of the plaintiff no. 1 computed on year to
year basis. The debt due by the plaintiff no.1 to the defendant no. l as
the amount equivalent to the aforesaid percentage computed on the said   basis   and   enforceable  
against   plaintiff   no.   l   would   stand
released/adjusted for consideration other than cash, modalities to be
worked out by them later on mutual basis.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 28 of 161 3.8.
The defendants have further averred that knowing that the
plaintiff no. 1 itself would stand to gain due to the rich background and experience   and   potential  
of   the   defendant   no.l   besides   the   salary   and
other perquisites, the plaintiff agreed to provide to defendant no. 1 the
equivalent value on the aforesaid percentage by way of profit sharing as
an inducement to increase efforts on the part of the defendant no. 1to
bring the plaintiff no. 1 as a profit making unit. The plaintiff no.2 who was   initially   Dy.   Managing
  Director   became   the   Chairman   and Managing   Director   in   1974   and   still   has   the  
complete   control   and supervision over the affairs of plaintiff no. l. Subsequently, in the year 1981−
82 the wife of plaintiff no. 2, R. Bhartia also was brought in as the Director   of   plaintiff   no.   1  
entrusted   with   looking   after   the   finance   of
plaintiff no. l under the overall supervision and control of plaintiff no.2.
The defendant no. l who joined work under the overall supervision and control   of   plaintiff   no.2  
in   the   year   1974,   was   promoted   as   General Manager in 1978−
79 and some time in the year 1986, the defendant no. l
was promoted as Executive Director and subsequently in Sept. 1986 the
defendant no. l resigned from the services of the plaintiff.
3.9. It is further averred that during the tenure, the defendant
no. 1 worked for plaintiff no. 1 steps were taken to ensure quality of the
products so that customers' complaints declined and rejection of goods
diminished, new products were introduced to suit market needs, product costs   controlled,  
marketing   techniques   were   improved   to   enable   the
plaintiff no.1 to compete with giant companies such as Larsen and Turbo Bhartia Cutler HammerBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

Ltd. & anr v. P.D. Agarwal & ors Page no. 29 of 161 and   Siemens,   the   government   authorities  
impressed   with   the performance of plaintiff no. l extended the collaboration agreement due to  
the   efforts   of   defendant   no.   l   and   even   the   foreign   collaborators
continued to give support to the plaintiff no. 1 having seen the improved performance   from   the  
previous   loss   position   of   the   company,   for   the entire  period 1975  till   1986  because of a  
very  consistent   and humane
personal policy the labour relations with the management was excellent
without there being any strike. Steps were taken to programme imports
substitution, saving the company costs of over Rs.50 lakhs per year since 1984−85   and   not   less  
than   Rs.120   lakhs   per   year   now   besides   huge savings of  foreign exchange.
3.10. The defendants further averred that the plaintiff no. 1 has
been making substantial profits, which progressively increased as will be
evident from the published annual accounts of plaintiff no.1 which are as follows :− Year  
Gross Profit Rs. Lakhs J 1977  28.29 1978  56.45 1979  95.48 1980  160.97 1981  230.24 (15 months)
1982  289.59 1983  143.78 1984  136.50 1985  146.56 1986  280.67 Bhartia Cutler Hammer Ltd. &
anr v. P.D. Agarwal & ors Page no. 30 of 161 3.11.
It is further averred that during this period the net worth of the plaintiff no. 1 improved from (−
)14.78 lakhs to Rs.502.78 lakhs in the
year 1986. It is also significant to point out that when there was serious recession   in   electrical  
industry   during   1983−85   while   the   plaintiff continued  to show high profits,  other  companies 
in  a similar business experienced their profits nose dive. The plaintiff no. 1 gained from the
sustained efforts on the part of defendant no. 1 and huge profits on a
stable and continued basis as a result, the Management Consultant of the   plaintiff   no.   1   M/s.  
Price   Water   House   who   had   carried   out   an extensive study recommended in 1985−
86 that defendant no. 1 be made
the Chief Executive of plaintiff no. 1. The plaintiff no.2 satisfied with the
performance of defendant no. 1 inducted the defendant no. 1 to various
other business activities of the family members of plaintiff no.2 as well
as other trusts and societies of the family members of plaintiff no.2.
3.12. It is further averred that the plaintiff no.2 was and still is incharge   and   control   of   the  
management   of   plaintiff   no.   1   and   at   all
material times the defendant no. l was working under the supervision
and control of plaintiff no.2. The defendant no. l functioned under the director   supervision   and  
control   of   plaintiff   no.2,   the   latter   being   in
charge of over all policies and conduct of the business including financial affairs   of   plaintiff   no.1  
as   Chairman   and   Managing   Director.   In   this
connection, the relevant part of the management circular dated June 23, 1986 reads as under:−
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 31 of 161
"Shri P.D. Aggarwal is re−designated as Executive Director and
will continue to assist the Managing Director in formulation and
implementation of the overall company policies and conduct of the business affairs."Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

3.13. It is further submitted that the defendant no.1 was working under   the   supervision   and  
control   of   plaintiff   no.2.   As   regards   the supervision   and   maintenance   of   the   books   of  
accounts   and   other statutory   records,   these   were   functions   being   discharged   by   the  
Chief Accountant and/or Company Secretary respectively. The defendant no. 1 merely   ensured  
proper   coordination   and   smooth   working.   However, dealings   as   regards   purchase   of  
materials   or   sales   to   customers   were being   negotiated   and   contracts   finalized   and   signed
  by   the   respective Departmental Heads, assisted by their staff officers. The defendant no. 1 was  
not   directly   dealing   with   suppliers   or   customers.   The   finance   or
accounting matters including dealing with auditors were conducted by the   Chief   Accountant  
and/or   the   Company   Secretary.   All   expenditure
relating to the Head Office at Delhi was incurred only after the approval
of the plaintiff no.2 being Managing Director of plaintiff no. 1 and stated
that  it is therefore wrong to allege the defendant no. l used to authorize
expenditure in respect of transactions involving the plaintiff no. 1.
3.14. The defendants further submitted that in para above, the defendants   have   already   referred  
to   the   terms   of   mutual   verbal
agreement arrived at and binding on the plaintiffs as well as defendant Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 32 of 161
no.1. By the year 1981 as already mentioned above and as will be evident
from the published accounts of plaintiff no.1, as the plaintiff no.1 had
gained substantial profits by running of the business as and in terms of the   agreement   the  
plaintiff   no.   1   was   liable   to   the   defendant   no.   1 therefore   in   or   around   June   1981   at  
Delhi   in   pursuance   to   the   said
agreement it was mutually agreed between the plaintiff no. 2 who acted
for plaintiff no. l and the def no. l towards part release/adjustment of the
defendant no. l's entitlement/claim by way of profit sharing, that a plot of
land at A.62, Mayfair Garden, New Delhi together with all rights, title or interest   thereon   will   be  
got   transferred   in   favour   of   defendant   no.   l and/or   his   nominee   and   the   plaintiffs  
would   also   pay   the   unearned
increase to the Delhi Development Authority. The consideration for the
sale of the land and the building costs to the extent advanced by the
plaintiff no. 1 to the account of defendant no. l would be treated as part
adjusted/discharged of the debts of the plaintiff no. 1 in pursuance to the
said agreement by way of profit sharing. Consequently, a deal in respect of   the   aforesaid   plot  
was   authorized   through   brokers   in   favour   of defendant   no.l   and/or   his   nominees;   initial
  advance   of   Rs.1   lakh   was
made on 8th June, 1981 and the balance price agreed to be paid against
transfer of all right, title or interest in the said plot of land to be effected
in favour of defendant no. l and/or his nominees.
3.15. The   defendants   further   denied   the   allegations   by   stating
that in early June, 1981 or any other date, the defendant no. 1 made any
representation to plaintiff no. 2 regarding the purchase of lease−hold land Bhartia Cutler HammerBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

Ltd. & anr v. P.D. Agarwal & ors Page no. 33 of 161
in Mayfair Garden and further denied by stating that the estate agent
represented to defendant no. 1 that transaction could be switched over if Mr.   Malhotra   was   paid  
the   amount   invested   by   him.   The   defendants
have submitted that in this connection, they crave leave to refer to the
agreements and documents executed directly between the owner of the
said property and the defendant no(s). 1 and 2 for ascertaining their true
import and effect at the time of hearing and save and except what will appear   therefrom   any  
allegation   contrary   thereto   and/or   inconsistent thereof is disputed and denied.
3.16.   The   defendants   further   averred   that   allegation   of   the
property being made available to the company is totally wrong, incorrect
and denied. The payment made by the plaintiff no. 1 was to the account of   defendant   no.   1  
towards   part   adjustment/discharge   of   the   debt   of
plaintiff no. 1 to defendant no. l and not that the payment by the plaintiff
no. 1 was to be treated as the investment of plaintiff no.1 in the suit property.   The   allegation   that  
the   transaction   regarding   the   plot   or
raising of construction thereon was left with the charge of defendant no.1 is  not  admitted. In
 fact, all  rights,  title and interest  for  the said plot
belonged to defendant no(s). l and 2, the latter as nominee jointly holding
with defendant no. 1. Construction work on the said plot of land was got
done, costs borne by the defendant no(s). 1 to 3 as per agreement interse
for residence of defendant no(s). 1 and 2. The defendants further denied that   defendant   no.1  
represented   to   plaintiffs   that   the   defendant   no.1 would   have   the   agreements   for  
acquiring   the   said   plot   of   land   or   for Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal &
ors Page no. 34 of 161 raising construction thereon as a trustee for plaintiffs. The question of
defendant no.1 having represented to the plaintiff that the transactions
would have to be in the name of some individual did not arise. Both the
terms of the perpetual lease deed and the bye laws of the said society
only admit membership by individuals. There was no declaration at any
stage by the plaintiffs either expressly or impliedly of the intention that
the said suit property was to be held in trust or that the defendant no. 1
ever agreed either expressly or impliedly to receive the suit property as a
trust. The said suit property, right, title or interest in respect thereof got
transferred in favour of the defendant no. 1/defendant no.2 directly from
the owner Mrs. Hiranandani/defendant no.4. The payment made by the
plaintiff no. 1 was towards part adjustment discharge of the debt of the
defendant no. l against agreed percentage of profit sharing in accordance
with the mutual understanding/agreement.
3.17. The   defendants   further   averred   that   the   contents   of   the letter   dated   8th  June,   1981
  be   referred   to   for   ascertaining   its   true
meaning and effect as these documents would show that the defendant no(s).   1   and   2   and   Mrs.
  Hiranandani/   defendant   no.4   entered   into   a transaction   directly.  It   is  denied  that  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

the plot   and/or  the  construction
were on plaintiff s account. The defendants further submitted that the concerned   bank   account,  
except   for   plaintiff   no.2   who   could   operate
solely, the account was required to be operated jointly by any two of the three   persons   including  
defendant   no.1   the  other   two  being   the  Chief Accountant/Company   Secretary.   Accordingly,  
the   said   demand   draft Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 35 of 161
must have also been got issued as per the above procedure.   The said
payment, as stated above, was by way of part adjustment/discharge or
debt of plaintiff no. l out of profit sharing due to defendant no. l. It is
wrong to allege that payment was for and on behalf of the plaintiffs. The
allegation that the amount was debited to the capital account under the
directions of defendant no.1 is neither correct nor borne out from any material on record.
3.18. The defendants further submitted that the allegations that
the defendant no. l entered into certain agreements with the said Mrs.
C.A. Hiranandani/defendant no.4 or kept the same with himself or not
handed over the same to the plaintiffs is totally misconceived, incorrect
and denied. Such documents having been entered into between Mrs. C.A.
Hiranandani/ defendant no.4 on the one hand and the defendant no. 1
and his wife on the other hand are dealings directly between the said
parties and the plaintiffs therefore had no right to my claim over the said
documents. Accordingly, the said documents rightly were retained by the defendant nos. 1 and 2. 
 The defendants further submitted that except for   certain   minor   changes   the   construction   of  
the   building   was   in accordance   with   the   plans   as   sanctioned.   The   allegation   that   the
construction on the said plot was commenced under the overall charge
and supervision of defendant no. l is incorrect and denied. As already mentioned   above   the   right,
  title   or   interest   in   the   said   land   stood
transferred in favour of the defendant no. l and the defendant no.2 and
therefore the construction which was got done on the said plot of land Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 36 of 161 was   out   of   expenses   incurred   by   defendant  
nos.   1   to   3   as   per arrangement interse for use as residence of defendant nos. 1 and 2. The
allegation   that   the   construction   on   the   said   plot   was   commenced   by
utilizing the funds for collections of plaintiff no. 1 is not wholly correct.
In pursuance of the aforesaid agreement and understanding towards the part  
adjustment/discharge   of   the   debt   due   to   defendant   no.   1   against profit   sharing,   the  
plaintiff   no.   1   advanced   certain   amounts   and substantial   payments   were   also   arranged  
by   the   defendants   for   the aforesaid purpose.
3.19. It  is  further  submitted  that   the allegation  that  defendant
no.l utilized the funds of the plaintiff no. 1 is totally misconceived and
incorrect. The allegation that the various expenditure in relation to the work   of   construction  
undertaken   on   the   said   plot   was   on   behalf   of
plaintiff no.1 is also wrong, incorrect and denied. As already mentioned
above, the amount advanced by the plaintiff no. 1 was by way of part adjustment/discharge   of   the  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

debt   of   defendant   no.   l   out   of   the   profit
sharing due to the defendant no. l in accordance with the agreement and understanding   referred  
to.   Further,   substantial   payments   towards construction   were   also   arranged   by   the  
defendants.   It   is   further submitted that in pursuance of the agreement understanding as arrived
at  between the  plaintiff and  the defendant  no.  l,  towards   adjustment/
discharge of the debt due to defendant no. 1, against the transfer of all rights,   title   or   interest   in  
the   said   plot   of   land   by   the   owner   Mrs. Hiranandani   in   favour   of   defendant   no.   l/his  
wife   under   the   various Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 37 of
161 documents   executed   by   the   said   Mrs   Hiranandani/   defendant   no.4   in
favour of defendant no. 1 and defendant no.2 the sum of Rs.8 lakhs was
advanced by the plaintiff no. l. The allegation that various amounts were
spent on the construction or material or services belonging to and paid by
the plaintiff no.1 is totally vague, misleading and as such denied. The allegation   that   enormous  
funds   or   resources   for   the   plaintiff   were utilized   for   the   purpose   of   raising   the  
construction   is   also   wrong, misleading   and   as   such   denied.   Besides   the   amount  
advanced   by   the plaintiff   no.   l   pursuant   to   the   aforesaid   agreement/understanding
towards   part   adjustment/discharge   of   the   dues   of   defendant   no.1,
considerable amount was spent towards the construction out of the funds
arranged by the answering defendants.
3.20. The   defendants   further   denied   that   the   allegation   that
under the directions of defendant no. l during the period 82−83 various
amounts that were expended on procurement of construction materials
were duly entered in the books of plaintiff no. l as advance for acquisition for   capital   assets   and  
stated   that   in   pursuance   to   the   agreement/ understanding   between   the   plaintiff   and  
defendant   no.1,   that   the defendant   no.1   was   entitled   to   specific   percentage   of   profits   as  
profit sharing. The modalities of adjustment of such amounts were left to be
decided mutually at a later stage. It has further been mentioned that in
pursuance to the said understanding/agreement in or about June, 1981
out of the profit sharing by way of part adjustment/discharge of the debt
of the plaintiff no. 1 advances amounting to Rs.8 lakhs were made by Bhartia Cutler Hammer Ltd. &
anr v. P.D. Agarwal & ors Page no. 38 of 161
plaintiff no. 1 towards payment for the said land and further advanced certain   amount   towards  
construction   cost.   Besides   this   answering defendants   themselves   had   arranged   funds   of  
over   Rs.7   Lakhs   spent towards the construction besides over Rs.12 Lakhs towards construction
improvements   as   well   as   towards   outgoings   on   the   said   plot   of   land.
However, the final adjustment towards the dues of defendant no. 1 out of
the profit sharing had to take place at a convenient date so as to be in
conformity with the provisions of law. Sometime in or around the year 1982−
83 in the course of finalization of accounts of plaintiff no. 1 it may
however, be that the entry "Advance for Acquisition of Capital Assets"
must   have   been   entered   into   the   books   of   plaintiff   no.1   to   avoid   any
incidence of tax on the plaintiff no. 1. The defendant no.1 was in no wayBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

concerned nor gave any instructions regarding accounting entries, which
were carried out entirely under the supervision of plaintiff no.2 without
in any manner effecting or creating any change in regard to the rights,
title or interest of defendant no.1 or defendant no.2 over the said plot and building.  
As   regards   the   allegation   that   Rs.3,72,645.72   on   account   of construction  
materials   were   debited   to   the   Capital   Account   and correspondingly   credited  
to   the   other   related   accounts,   the   answering
defendants reiterate that whatever accounting entries were done, if at all,   was   to  
lend   a   true   colour   to   that   transaction   so   as   to   avoid   any incidence  of   tax
  of  the   plaintiff  no.   l.   But,   however,   it   did   not   in   any
manner alter or change the true nature of the transaction pursuant to
the agreement understanding arrived at as explained above and which is
binding on the parties. These entries are sham and neither in law or in Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 39 of 161
fact can alter or change the true nature of the transaction as between the
plaintiff and defendants 1 and 2 as explained above. The plaintiffs were
and still are in possession of all books and other records.
3.21. It   is   further   averred   that   the   defendant   no.l   is   not   an
accounting party. It is denied that during the period 1983−84, 1985−86
materials/services of the aggregate value of Rs. 7,60,972.68 have been spent  
towards   construction   on   the   said   plot   of   land   at   the   behest   of
defendant no. l as alleged. Without prejudice to the aforesaid statement the  
necessity   of  asking   the   defendant   no.l   to  give   accounts   would   not
arise when admittedly the books and records are lying with the plaintiff no.   l.   Even
  otherwise   the   allegations   are   after   thought   because   the
plaintiff no. l for the periods in question and even thereafter have got
their books regularly audited and accounts approved by the Board duly
signed, inter alia, by plaintiff no.2 and the same were published.
3.22. The defendants further submitted that the payments  made to   labour   and/or  
towards   materials   for   carrying   out   the   construction partly were made 
out of the funds  arranged  by  answering defendants and   partly   from   the  
advances   made   by   plaintiff   no.1   pursuant   to   the agreement   referred   to  
above.   The   construction   work   was   got   entirely done   by   the   defendants   and
  other   family   members   under   their supervision   and   care.   The   actual  
physical   possession   of   the   property
pursuant to the various agreements on record was and still is with the
defendant nos. 1 and 2. At no stage ever any part of the said premises Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 40 of 161 was   with   the  
plaintiffs.   The   original   documents   pertaining   to   the
transfer of right, title and interest over the said property also are lying
with the defendants. The whole of the premises was and still is being
continued to be used as the residence of the defendants 1, 2 and theirBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

family members.
3.23. It   is   further   submitted   that   the   defendant   no.   l   resigned
from the post of Executive Director in September, 1986. There are no
obligations legal or otherwise on the part of the defendant no. l to give
any information or document relating to the property in question to the plaintiff   no.
  1.   It   may   be   that   due   to   the   friendly   relations   between
defendant no. l and the plaintiff no.2 during the tenure of service, copies
of documents left in the office premises could have come in the hands of
the plaintiff no.2. The defendants further denied that the defendant no. l
was a trustee of the plot of land and that the defendant no. 1 was bound
to render the accounts as alleged or at all. It is further alleged that on
25.11.1981 various agreements such as Agreement to Sell, Construction
Agreement and other documents such as declaration and affidavit were executed   in  
respect   of   the   suit   property.   However,   the   parties   to   the Agreements  were
 the owner  Mrs. C.A.  Hiranandani  and  defendants  1 and   2.   However,   to  
facilitate   the   approval   of   extension   of   time   for
construction, on legal advice, fresh documents were entered into between the  
original   owner   Mrs.   Hiranandani   and   defendants   1   and   2   on
09.11.1982. It is denied that defendant no.2 was made a party at this stage   defendant
  no.   2   was   a   party   in   the   agreements   executed   on Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 41 of 161
25.11.1981 also. The General Power of Attorney was executed by Mrs.
Hiranandani/defendant no.4 again in the name of Ved Prakash Sargoi and   Sham  
Lai   Jalan   while   the   earlier   Power   of   Attorney   was   in   the
names of Ram Gopal Agarwal and Shri Goving Agarwal.
3.24. The   defendants   further   stated   that   the   agreement/ understanding,   part  
of   the   moneys   towards   the   purchase   of   the   said property   were   advanced  
by   the   plaintiff   no.1   towards   adjustment/
discharge of debt of plaintiff no.1 due to defendant no.1 and remaining part   of   the  
funds   towards   construction   on   the   said   plot   of   land   were arranged   by   the
  answering   defendants.   The   transfer   of   right,   title   or interest   in   respect   of  
the   plot   of   land   under   the   various   documents executed   by   Mrs.  
Hiranandani   in   favour   of   defendants   1   and   2   was
absolute and unqualified. Thus, the defendants 1 and 2 were and still are
the true owner in possession of the said plot of land together with the
construction made thereon. The plaintiff no.2 was and still is in overall
charge of all the affairs of plaintiff no.1 including the accounts of plaintiff no.1.   In  
particular,   the   defendants   denied   that   the   defendant   no.   l provided   to   the  
Auditors   the   over−all   certificates   concerning   the correctness   of the accounts
 or  the defendant  no.  l  was  responsible  for
various entries as alleged and submitted that the Chief Accountant and
Company Secretary were responsible for the preparation of the accountsBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

within the overall purview of plaintiff no.2 and the certificates required
from defendant no.1 under directions of plaintiff no.2 of routine nature were  
furnished.   It   is   wrong   to   allege   that   expenses   pertaining   to Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 42 of 161
utilization of materials or services of the Company in connection with the
construction under instructions of defendant no. 1 were debited to other
heads of expenses instead of capital account as alleged.
3.25. The   defendants   further   submitted   that   no   letter   or
communication from the plaintiff no.1 has been placed on record in this
connection that the defendant no. 1 stopped attending his duties. On the
other hand, the defendant herein filed with the written statement a copy
of resignation submitted by defendant no. l which was duly accepted and acted   upon
  by   the   plaintiffs.   The   defendants   denied   that   the   said property   is   being  
used   for   carrying   out   the   business   of   'North   West
Switchgear Private Limited' as alleged and averred that in any event,
the said property belong exclusively to defendant nos. 1 and 2 and the
plaintiffs have no concern in respect of the said property and, therefore,
the plaintiffs are not entitled to raise any objections in regard to the use
of the said property, though the allegation is not admitted.
3.26. The   defendants   further   submitted   that   it   was   within   the
knowledge of the plaintiff when the suit was filed that the suit property
is in possession of the defendants herein, yet the plaintiff chose not to seek  
possession   but   for   declaration   injunction   etc.   The   claim   for
possession is time barred. That the defendant no. l and 2 are titleholder
in possession of the suit property and the plaintiff have no right title or
interest therein. In the alternative and without prejudice the defendant
nos. 1 and 2 are in adverse possession of the suit property publicly and as Bhartia
Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 43 of 161 such   the  
plaintiff   have   no   right   or   interest   in   the   suit   property whatsoever.   It   is  
further   averred   that   the   plaintiffs   have   no   right   or claim   in   the   said  
property.   In   any   event,   no   business   of   North   West
Switchgear Private Limited is being carried out from the said premises.
It may, however, be mentioned that Shri M.A. Joshi had left the services of  
defendant   no.   l   some   time   in   August,   1986.   It   is   denied   that   the
defendant   no.   l   had  made   use  of  secret  technical   information,   data   of
manufacturing process as alleged or at all. It is denied that defendant no.
1 has acted in breach of trust as against the plaintiffs as alleged or at all.
It is denied that defendant no.1 wrongfully used the funds of plaintiff
no.1 while functioning as General Manager/Executive Director as alleged or   at   all.  
It   is   significant   to   point   out   that   at   no   time   there   is   any communication  
of   the   plaintiffs   as   regards   the   alleged   misuse   of   the
knowledge and information on the part of defendant no.1 or causing any disruption  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

in   the   production   of   marketing   plans   of   defendant   no.1   or causing  
financial   difficulties   to   plaintiff   no.1,   these   allegations   are
merely an afterthought and concocted. The defendants further averred
that as mentioned in the resignation letter dated September 11, 1986 to the  
knowledge   of   the   plaintiffs   the   records   which   were   with   the defendant   no.  
l   were   duly   handed   over   to   the   concerned   persons   of
plaintiff no. l. It is significant to mention that after leaving the services
of plaintiff no.1, the brother of plaintiff no.2, Mr. P. Bharatia had given a
good character certificate to defendant no. l as having known defendant no.   l   over  
13   years   and   defendant   no.   l   being   a   man   of   integrity, trustworthy   and  
reliable   person   and,   therefore,   the   Risk   Capital Bhartia Cutler Hammer Ltd. &
anr v. P.D. Agarwal & ors Page no. 44 of 161
Foundation sponsored by the Industrial Financial Corporation of India may  
consider   the   application   of   defendant   no.   l   for   Seed   capital assistance from
 the Foundation. The  creditability of defendant  no.1  is
further evidenced by the fact that after leaving the service of plaintiff no.l   at   the  
instance   of   defendant   no.l   the   Canara   Bank   granted   to
defendant no.1 credit facilities to the limit of Rs. 90 lakhs as per copy of
the letter issued to Canara Bank dated 20.12.1986. The allegation that defendant  
no.1   did   not   submit   charge   of   records   is,   therefore,   wholly
wrong, incorrect and denied.
3.27. The defendants further denying the averments of the plaint
on merits, submitted that as per the practice of the Company, cars were
transferred on book value to senior employees/ex−employees and adjusted
against the dues including leave salary dues. In the case of the defendant
no.1 also it was agreed between the plaintiff and defendant no.1 that the
said car would vest in defendant no.1 and the value thereof got adjusted
against the dues of defendant no.l including the leave salary which are
far in excess of the value of the car. The plaint does not disclose any
cause of action against the defendants. In any event there is no liability
on the part of the defendants to render any account, as the defendants
are not the accounting parties.
3.28. The defendants filed counter claim  inter−alia  praying that Agreement   which  
form   the   foundation   between   the   plaintiff   and defendant  no.1  accepted and 
acted upon  between the parties  provided Bhartia Cutler Hammer Ltd. & anr v. P.D.
Agarwal & ors Page no. 45 of 161
that besides salary and other usual perquisites in consideration for the
services to be rendered by the defendant no. 1 for which the plaintiff no.1 would  
stand   to   gain   substantially   which   in   fact   did   happen   and   the plaintiff   no.  
l   made   substantial   profits   year   after   years,   the   plaintiffs
agreed to provide equal value of specified percentage i.e. 5% of the profits
(before tax) by way of profit sharing. The defendant no.1 by his unstilted efforts  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

made   the   plaintiff   no.   1   a   profit   making   units   and   the   profits increased  
substantially   year   after   year.     On   the   basis   of   the   said
Agreement and the rights flowing therefrom in favour of the defendant
no.1, calculated on 5% of profits (before tax) computed on year to year
basis, the total amount for the entire period 1977 to till 1986 comes to
Rs. 44.06 lakhs, as a debt owing by the plaintiff no. 1 to the defendant no.   1.   It   will
  be     significant   to   point   out   that   in   the   year   1981,   the
accounting period being 1979−80, already there was due and owing from
plaintiff no. 1 to defendant no. l by way of sharing the profit of  Rs. 11.13
lakhs. The sum of Rs. 8lakhs advanced towards the plot of land by the plaintiff   no.  
l,   as   such   was   an   adjustment/discharge   of   part   of   the
aforesaid debt of Rs. 11.13 lakhs. It is further alleged that thereafter the
construction and improvements on the said property was going on until
1986 and besides the sum of over Rs. 7 lakhs spent by the defendant no. l including  
on   outgoings,   the   amount   advanced   by   the   plaintiff   no.   l towards  
construction   was   by   way   of   part   adjustment/discharge   of   the
aforesaid debt owing by plaintiff no. 1 to defendant no. 1. It is further
submitted that in their estimate over 44 lakhs became due from plaintiff no.   l   to  
defendant   no.   l,   however,   the   exact   amount   can   only   be Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 46 of 161
ascertained after proper accounts are rendered by the plaintiff no. l in whose  
custody   books   of   accounts   and   records   relating   to   business   are
available. Despite various dues of the defendant no. l the plaintiffs have
not accounted for the exact amount that would fall to the share of the defendant   no.1
  in   terms   of   the   aforesaid   Agreement   by   way   of   profit
sharing. The defendant no. l has in consequence been unable to ascertain how   much
  the   amount   of  profit   that   will   fall   due   to  the  share   of   the
defendant no. l and it is, therefore, unable to sue for a sum certain. It is the   plaintiffs
  who   have   control   over   the   business   and   accounts   and,
therefore in a position to account what is due to defendant no. l from the
plaintiffs and make payment of the sum so found to be due upon taking
such account, though in the estimate of defendant no. l the amount could
far exceed Rs. 44 lakhs. The plaintiffs despite demands have failed to pay
to defendant no. 1 his share out of the profits as agreed except, however,
as mentioned above, certain advances were made towards plot of land and  
constructions   towards   part   adjustment/discharge   out   of   the
defendant's share of profit.
3.29. It   is   further   submitted   that   without   prejudice,   by   way   of
alternative pleading, the defendants submit that if this Court comes to a
conclusion that the Agreement as pleaded by defendant no. l is legally or otherwise  
not   tenable   and   the   pleas   formed   thereon   also   not   tenable,
then it is stated that the advances made by the defendant no. l towards
plot of land amounting to Rs. 8 lakhs, towards construction alleged to beBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

Rs. 11.33 lakhs the whole of the said advances aggregating to Rs. 19.33 Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 47 of 161
lakhs constitute a loan as advanced by the plaintiff no. l to defendant no. l.  The
 defendant   has   also  spent   over   Rs.  7   lakhs   on  the  construction, besides  
constructional   improvements   and   outgoings   exceeding   Rs.   12
lakhs on the said property. The defendants are in continuous possession
of the whole of the property since the year 1981 when the right, title or
interest of the said property was transferred in favour of defendant no. 1 by   the  
owner   Mrs.   Hiranandani.   The   plaintiffs   by   their   various   acts,
declarations and assurances and by their conduct have acquiesced in the possession 
use and enjoyment  of  the  said property  by  the  defendants.
The defendants having publicly exercising −rights and ownership of the
said property and the plaintiffs are fully aware and on due notice thereof The  
defendants   have   sought   merely   relief   of   declaration,   which   is
entirely at the discretion of the Court. In the facts and circumstances stated   above,  
equity   fully   applies   and   in   which   event   the   defendants
ought not to be dispossessed especially when the plaintiff have chosen to approach  
this   Court   seven   years   after   the   transaction.   Consequently, this   Court   in  
equity   and   in   justice   be  graciously   pleased   to  allow   the
defendants to discharge the said loans in suitable installments towards
full settlement/satisfaction of the plaintiffs alleged rights/claims in the present  
proceedings.   This   is   without   prejudice   to   the   rights   and contentions   of   the
  defendants   here−in−above.     On   the   strength   of aforesaid ground a  prayer was 
made that  the suit  of the plaintiffs  be
dismissed with cost and order be passed for full   and true account in respect   of   the
  conduct   of   the   business   of   plaintiff   no.1   during   the
period.1974 until 1986 and ascertain the defendant no.l's share of the Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 48 of 161 profits   derived   from  
the   running   of   the   business   in   terms   of   the agreement   between   the  
parties   and   payment   of   such   sum   as   may   be
found due from the plaintiff no. l to defendant no. l upon taking of the
accounts alongwith interest@ 18% on the decreetal sum from the date of
suit until payment in favour of defendant no. 1 against the plaintiff no. 1.
It is also prayed that  in the alternative an inqujry be ordered as to the
moneys alleged to have been advanced and the amount so found due to
declared as payable by defendant no.1 to plaintiff no.1 in installments
and on terms as directed towards full satisfaction of the plaintiffs alleged
claim in the present suit.
4. Replication  to  the  written  statement   was   filed  by  the  plaintiffs. The  
plaintiffs   while   denying   the   averments   made   in   the   written
statement reiterated and re−asserted the averments made in the plaint
and submitted that Shri P.O. Kejriwal cousin and friend of the plaintiff
no. 2 was known to defendant no. I's family.   The defendant no. 1 whoBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

was looking for some appointment/opportunity had approached plaintiff
no. 2 through the said Sh. P.O. Kejriwal and on latter's recommendations the  
defendant   no,   1   was   appointed   in   the   Purchase   Department   of plaintiff   no,
  1   under   one   Shri   H.K.   Lohia   sometime   in   August,   1970.
plaintiff no. 1 then was a joint venture, Plaintiff No, 2 was Dy, Managing
Director of plaintiff no. 1 and Mr. Devid Hirst an appointee of the U.S.
Collaborators was the Managing Director. In 1971, on account of certain differences,  
the   plaintiff   no.   2   disassociated   himself   from   active
management of plaintiff no. l. Plaintiff No, 2 has then established two Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 49 of 161
other companies. Defendant No, 1 had resigned from plaintiff no. 1. He
approached plaintiff no. 2 for employment some time, in 1972 in some Companies  
established   by   the   Defendant   No.2.   Some   time   in   August, 1973,   the  
plaintiff   no.   2's   elder   brother   and   Head   of   family   expired necessitating  
shifting   of   Plaintiff   No.   2   from   Delhi   to   Calcutta.   The defendant   no.   1  
was   employed   by   Plaintiff   No.   2   with   East   India Commercial   Co.   Pvt.   Ltd,
  of   which   he   was   then   the   Chairman   and Managing   Director.   Since  
plaintiff   No.   2   was   not   involved   in
Management of plaintiff No. 1 in 1973 there was no occasion and could not   be   any  
occasion   for   the   alleged   happenings   of   August,   1973,   as
pleaded by Defendant No.l.
4.1 It   is   further   submitted   that   the   Plaintiff   No.   2   came   to
acquired control of Plaintiff No. l in the later half of 1974 as a sequel to the U.S. Corpn. dis−
investing its interests in favour of Sh. Lohia and the
said Sh. Lohia  transferring all his interests in favour of Plaintiff No. 2. Defendant  no.  l   who  was  
in  employment   as   aforesaid  with  one  of  the plaintiff   no.   2's   companies   assisted   plaintiff  
no,   2   after   he   acquired management and control of plaintiff no. 1. The defendant no1 1 was later
appointed   as   a   Dy.   General   Manager   under   one   Mr.   Nahoria   and
sometime after latter's resignation in 1978, the defendant no. l was made
General Manager of Plaintiff No.l. The role claimed to have been played
by defendant no. 1 during 1973 and his assertions concerning plaintiff no.   1   made   by   the  
defendants   are   incorrect   and   untenable.   It   is
submitted that Mr. Hirst came to be appointed pursuant to a decision of Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 50 of 161
the Board of Directors of plaintiff no. 1 to employ a Technically qualified and   experienced  
executive   for   ensuring   quality   standards   and   for
imparting trainings to local management and satisfactorily establishing business   operations.   After
  disinvestment   by   the   Collaborators   in   the plaintiff   no.   1,   Mr.   D.R.   Hirst   was   recalled  
by   them.   The   plaintiffs further denied that in 1973, plaintiff no. 2 arrived at any agreement as
alleged or at all.  The plaintiffs re−asserts the facts stated in plaint and controverts   allegations  
made   in   the   written   statement   and   submitted
that while functioning as a General Manager, the Defendant No. 1 was
providing the Certificates to the Auditors on the basis of which the latterBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

signed and audited the accounts. Certain principal members of the staff
namely the Chief Accountant and the Secretary were working under the
directions, supervision and guidance of the defendant No. l. Virtually all
important correspondence with financial institutions, banks, important
customers, Govt. Departments were being looked after by the Defendant
No. 1. It is further submitted that the defendant no. 1 enjoyed virtually
unrestricted authority which was to some extent curtailed and checked and   whilst   efforts   in   that
  regard   were   being   made,   designation   of defendant   no.,   1   upon   his   pleadings   and  
request   was   changed   but   he suddenly   stopped   attending   office.   It   is   submitted   that  
there   was   no agreement or understanding about any part adjustment or discharge of
any alleged debt nor was there any debt owing by the plaintiff no. 1 to defendant   no.   1.  No   money
  was   advanced   by   the   plaintiff   no.1   to  the
defendant no. 1 as alleged or at all but moneys of Plaintiff No. 1 were
used for constructions belonging to it by defendant no. 1 who was acting Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 51 of 161 pursuant   to   the   trust   reposed   in   him.   The
  claim   for   the   alleged substantial payments arranged by the defendants is vague and incorrect
and   is   traversed.   The   allegations   concerning   alleged   transfer   to
defendant no. 1 are also incorrect and dishonest. The defendant no. 1 has not   disclosed all  
the documents  obtained  from  Mrs.  Hiranandani. The
amount paid by plaintiff no. l to Mrs. Hiranandani for acquiring the plot
that was to be held in trust by the defendant no. 1 was never provided for
the purpose alleged by the defendant No. 1, as now being falsely claimed by   him.   It   is   further  
submitted   that   in   fact   it   is   unclear   as   to   when
defendant No. 1 turned totally dishonest and conceived the plan to usurp
the property entrusted to him but the defence manifests and reveals that
scheme appears to have been conceived by way of an after thought. In
view of the role that was being played by the defendant no. 1 in relation to   the   functioning,  
business   and   affairs   of   the   plaintiff   no.   l,   it   is
submitted that it is impermissible for the said defendants to resile from
the records of his own creation.
5. The plaintiff in reply to the counter−claim / written statement of the   defendants   while   denying
  the   averments   of   the   counter−claim
submitted that the alleged claim with regard to alleged profits as a result
of alleged efforts part of the defendant no. 1 during the year is baseless
and misconceived. Neither the defendant no. 1 or any other defendants
have any right or claim to any share of profits and  further prayed that the counter−
claim deserves dismissal.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 52 of 161
6. From pleading of parties, following issues have been framed on 04.05.2006 :−Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

1. Whether the agreement entered into by defendant no. 1 in respect
of the suit property was as a trustee for an on behalf of plaintiff no. 1? OPP.
2. Whether   the   defendant   no.   1   acted   in   breach   of   trust   and
confidences in relation to the affairs of plaintiff no. 1? If so, its effect?OPP
3. Whether the defendant no. 1 utilised the funds and resources of
plaintiff no. 1 for raising construction on suit property?If so, its effect?OPP 
4. Whether the defendant no. 1 is liable to render accounts in respect
of utilization of the funds and assets of plaintiff no. 1?OPP
5. Whether the suit is barred by time?OPD
6. Whether the suit is barred by the provisions of Section 4 of the Benami   Transactions  
(Prohibition   of   Right   to   Recover   Property) Act, 1988 ?OPD 
7. Whether   the   suit   is   barred   by   principles   of   estoppel   and acquiescence?OPD 
8. Whether the plaintiffs are entitled to maintain the suit not being members   of   the  
Cosmopolitan   Housing   Society   Ltd.,   perpetual lessee of the plot?OPP 
9. Whether plaintiff no. 1 is entitled to recover any amount from the
defendant? If so, the extent thereof? OPP  Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors
Page no. 53 of 161
10.  Whether plaintiff no. 1 is entitled to recover possession of the car from the defendant no. 1?OPP 
11. Whether the plaintiff no. 1 is entitled to any interest?If so, at what
rate, on what amount and for which period?OPP 
12. Whether there was any agreement between the defendant no. 1 and   plaintiff   no.   1   as   alleged
  in   paras   1   to   7   of   the   written statement?OPD 
13. Whether the defendant no. 1 is liable to recover any amount from
the plaintiff no. 1?If so, the extent thereof?OPD 
14. Whether the defendant no. 1 is entitled to any interest?If so, at
what rate, on what amount and for which period?OPD
15. Relief.
6.1. In order to prove their case, the plaintiffs  have examined
two witnesses. Sh. Sanjay Sharma, Executive (Accounts) with plaintiffBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

no. 1 was examined as PW1. He tendered his evidence by way of affidavit
Ex.PW1/A and produced documents as follows:− •
Management communication dated 23.09.1974 Ex.PW1/1. •
Management communication dated 23.06.1986 Ex.PW1/2. • Copy   of   account   of   plaintiff   no.   1
  with   Canara   Bank   dated 24.11.1981 showing a debit of Rs.8,00,160/− on account of DD
issued to Mrs. CA Hiranandwani Ex.PW1/3.
           •      Bills /invoices Ex.PW1/4.
           •      Invoice dated 11.06.1985 of Maruti Car bearing no. DBA 5831
                  Ex.PW1/5.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors                                  Page no. 54 of 161
6.2. The plaintiff no. 2 appeared as PW2 and tendered evidence
by way of affidavit as Ex.PW2/A and produced documents as follows:− 
Management communication dated 23.07.1974 Ex.PW2/1. 
Management communication dated 23.06.1986 Ex.PW2/2.  Letter   dated   4.9.1978   addressed  
by   defendant   No.   1   to   Jt.
Controller   Exchange   Control   Department   seeking   grant   of
additional foreign exchange for his travel Ex.PW−2/3.  Letter   dated   25.11.1978   addressed   by  
Defendant   No.   1   to Development   Officer,   Directorate   of   Technical   Development   Ex. PW−
2/4.
 Letter dated 20.4.1979 addressed by Defendant No. 1 to Mr. D.R.
King Vice President Cutler Hammer Inc. U.S.A. Ex.PW−2/5. 
Purchase Order dated 11.06.1979 placed!by the Defendant No. 1
on Cutler Hammer Europa Ltd. Ex.PW−2/6.
 Purchase Order dated 15.06.1979 placed by the Defendant No. 1
on Cutler Hammer Europa Ltd. Ex. PW−2/7.
 Letter   dated   11.9.1979   addressed   by   Defendant   No.   1   to   Jt.
Controller   Exchange   Control   Department   seeking   permission   to
make payment to foreign collaborators Ex.PW−2/8.
 Letter   dated   15.9.1979   addressed   by   Defendant   No.   1   to   Jt.
Controller Exchange Control Department seeking; grant of foreign
exchange for foreign travel of M.A. Joshi Plant Manager Ex. PW− 2/9.
 Letter dated 11.8.1981 addressed by Defendant No. 1 to Mr. W.J. Rose, Eaton Corporation Ex.PW−Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

2/10.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 55 of 161 
Letter dated 7.9.1983 addressed by Defendant No. 1 to Technology Resources Pvt. Ltd. Ex.PW−2/11.
 Letter dated 8.12.1983 addressed by Defendant No. 1 to Canara Bank, New Delhi Ex.PW−2/12.
 Purchase Order dated 17.08.1984 placed by the Defendant No. 1
on M/s Hinditron Equipments Ex.PW−2/l3.
 Letter dated 19.7.1984 addressed by Defendant No. 1 to Canara Bank, New Delhi as Ex.PW−2/14.
 Letter dated 24.11.1984 addressed by Defendant No. 1 to Canara Bank, New Delhi Ex. PW−2/15.
 Letter dated 27.12.1984 addressed by Defendant No. 1 to Canara Bank, New Delhi Ex.PW−2/16.
 Letter   dated   11.9.1986   addressed   by   Defendant   No.   1   to   Jt.
Controller   Exchange   Control   Department   seeking   permission   to
make payment to foreign collaborators as Ex.PW−2/17.
           Technology Resources Pvt. Ltd. As Ex.PW−2/18.
           Office   copy   of   the   letter   dated   June   1981   signed   by   me   and
            addressed to M/s Vijay Dhawan & Co. as Ex. PW−2/19.
           A  copy  of  account  of  Plaintiff No.l   Company  with Canara  Bank
dated 24.11.1981 showing a debit of Rs. 8,00,160/− on account of
the D.D. issued to Mrs. C.A. Hiranandani as Ex.PW−2/20. (Ex.PW− 1/3)  Certificate  dated 
26.8.1981   issued  by  the  Defendant   No.l   to  the auditors Price Waterhouse Ex.PW−2/21.
 Certificate dated 25.11.1982 issued by the Defendant No.l to the Bhartia Cutler Hammer Ltd. & anr
v. P.D. Agarwal & ors Page no. 56 of 161 auditors Price Waterhouse as Ex. PW−2/22.
 The original invoice dated 11.6.1985 for Maruti car DBA 5831 as Exhibit PW−2/23 (Ex. PW−1/5).
6.3. On the other hand, the defendant no. 1 Shri  Prabhu Dayal
Agarwal appeared as DW1, who tendered his evidence by way of affidavit
Ex. DW1/A and relied upon documents as follows :− 
Letter dated 17.02.1986 with annexure from Price water house to 
plaintiffs recommending defendant no. 1 to the post of Chief  Executive Ex. DW1/1.
 Letter dated 28.02.1979 from Cutler Hammer, USA to defendant 
no. 1 congratulating him on excellent job Ex. DW1/2. 
Character certificate dt. 07.12.1987 from Sh. Pratyush Bhartia to 
Risk Capital Foundation Ex.DW1/3.Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

 Receipt of payment of Rs. 15,000/− made by defendant no. 1 to the 
broker Mr. Gyan Bhatnagar Ex.DW1/4.
 Original   receipt   from   the   seller   Mrs.   C.   A.   Hiranandani   in   the
name of defendant no. 1 and 2 for the sale consideration of Rs. 8.0 lakhs  Ex.DW1/5.
 Notarized   copy   of   share   certificate   dated   29.04.1958   issued   by
Cosmopolitan Cooperative Housing Society Limited Ex.DW1/6.  Notarized   copy   of   letter   dated
  16.09.1958   issued   by   the Cosmopolitan Cooperative Housing Society Limited confirming the
shareholding of Mrs. C. A. Hiranandani Ex.DW1/7. 
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 57 of 161 
Notarized copy of Perpetual Sub−Lease dated 31.03.1971 in favour
of Mrs. C. A. Hiranandani Ex.DW1/8. 
 Original   Construction   Agreement   executed   in   duplicate   dated
25.11.1981 between Mrs. C. A. Hiranandani and Defendant no. 1 and 2, Ex.DW1/9. 
 Notarized   copy   of   Agreement   to   Sell   dated   25.11.1981   between
Mrs. C. A. Hiranandani and defendant no. 1 and 2 Ex.DW1/10.   Notarized   copy   of   Special  
Power   of   Attorney   dated   25.11.1981
given by Mrs. C. A. Hiranandani in favour of Mr. Govind Agarwal
for construction of the house Ex.DW1/11 to DW1/13. 
 Notary   attested   receipt   dated   25.11.1981   issued   by   Mrs.   C.   A. Hiranandani Ex.DW1/14. 
 Affidavit   of   Mr.   A.   D.   Hiranandani   (husband   of   Mrs.   C.   A.
Hiranandani) dated 25.11.1981 duly notarized Ex.DW1/15.  
Original affidavit of Mrs. C. A. Hiranandani dated 25.11.1981 duly notarized Ex.DW1/16. 
 Original declaration dated 25.11.1981 of Ms. Kavita Vijay Mehta
(daughter of Mrs. C. A. Hiranandani) Ex.DW1/17. 
 Original declaration dated 25.11.1981 of Mr. Ranjit Hira (son of
Mrs. C. A. Hiranandani) Ex.DW1/18. 
 Original   Will   dated   25.11.1981   of   Mrs.   C.   A.   Hiranandani
bequeathing all rights in the said property to defendant no. 1 and 2 Ex.DW1/19. 
 Notarized   copy   of   General   Power   of   Attorney   dated   25.11.1981
executed by Mrs. C. A. Hiranandani in favour of Mr. Ram Gopal Bhartia Cutler Hammer Ltd. & anr
v. P.D. Agarwal & ors Page no. 58 of 161
Agarwal and Mr. Govind Agarwal  in respect of the said property Ex.DW1/20. Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

 Original   letter   dated   25.11.1981   from   Mrs.   C.   A.   Hiranandani addressed   to  
Cosmopolitan   Cooperative   Housing   Society
nominating defendant no. 1 and 2 as nominees and requesting the
society to make the necessary mutation Ex.DW1/21. 
 Original   letter   dated   25.11.1981   from   Mrs.   C.   A.   Hiranandani addressed   to  
Cosmopolitan   Cooperative   Housing   Society Ex.DW1/22. 
 Original General Power of Attorney dated 26.02.1982 executed by Mrs.   C.   A.   Hiranandani   in  
favour   of   Mr.   Govind   Agarwal, nominating   him   to   do   all   acts   before   Municipal  
Corporation   of Delhi,   Delhi   Development   Authority,   Delhi   Electric   Supply Undertaking,  
Delhi   Administration   etc.   in   order   to   get   plans
sanctioned and do construction on the said property Ex.DW1/23.  
Notarized copy of Agreement to Sell dated 09.11.1982 executed by
Mrs. C. A. Hiranandani in favour of defendant no. 1 and   2 for
transfer of the said property Ex.DW1/24. 
 Notarized   copy   of   Construction   Agreement   dated   09.11.1982
executed between Mrs. C. A. Hiranandani and defendant no. 1 and 2 Ex.DW1/25. 
 Notarized   copy   of   General   Power   of   Attorney   dated   09.11.1982
executed by Mrs. C. A. Hiranandani in favour of Mr. Ved Prakash
Saraogi and Mr. Shyam Lal Jalan  for transfer of the said property Ex.DW1/26. 
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 59 of 161 
Notarized copy of affidavit dated 09.11.1982 executed by Mrs. C.
A. Hiranandani for transfer of said property in favour of defendant no. 1 and 2, Ex.DW1/27. 
 Original   affidavit   dated   09.11.1982   executed   by   Mr.   A.   D.
Hiranandani (husband of Mrs. C. A. Hiranandani) stating that he
has no objection in Mrs. C. A. Hiranandani transferring all rights in the said property Ex.DW1/28. 
 Original Special Power of Attorney dated 09.11.1982 executed by Mrs.   C.  A.   Hiranandani   in  
favour   of  Mr.   Ved  Prakash   Saraogi, Ex.DW1/29. 
 Letter   dt.   18.04.1984   from   Architect   to   defendant   no.   1   Ex.
DW1/30.
 Letter   dt.   19.01.1985   from   Architect   to   defendant   no.   1   Ex.
DW1/31.
 Letter dt. 16.12.1981 from DDA giving sanction to construct Ex.Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

DW1/32.
 Letter dt. 19.09.1981 from DDA granting exemption under Urban
Land (Ceiling and Regulation Act) Ex. DW1/33.
 Receipts   for   processing   fees   paid   by   defendants   to   DDA   Ex.
DW1/34 to Ex. DW1/36.
 Receipts   for   payment   of   composition   charges   paid   to   DDA   EX.
DW1/37 to Ex. DW1/38.
 Receipt for payment of NOC charges paid to DDA Ex. DW1/39. 
Bills / Delivery challans/ cash receipts for materials and services
used in the construction and paid by defendant no(s) 1 and 2, Ex.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 60 of 161
DW1/40 to Ex. DW1/306.
           Valuation report Ex. DW1/307 to DW1/308.
           Form C & D i.e. letter of inspection and approval of drainage work
            issued by DDA Ex. DW1/309 & DW1/310.  
           Receipt dated 27.04.1983 Ex. DW1/311.
           Form of notice of completion of building to DDA Ex. DW1/312.
           Correspondence   with   DDA   regarding   occupancy   certificate   Ex.
            DW1/313 to Ex. DW1/315.
           Occupancy certificate issued by DDA Ex. DW1/316.
           Letter   dt.   14.03.1983   from   DDA   for   sanction   of   power   load   Ex.
            DW1/317.
           Letter dt. 30.03.1983 from DESU for sanction of power load Ex.
            DW1/318.
           Letter   dt.   29.11.1983   from   DDA   regarding   regularization   by
            paying compounding fee Ex. DW1/319.
           Receipt dt. 13.12.1983 from DDA Ex. DW1/320.
           Invitation   card   for   house−warming   and   CD   Ex.   DW1/321   &   Ex.
            DW1/322.
           Letter dated 08.08.1983 wrote by Mrs. C. A. Hiranandani to MCD
informing them that she has sold the property to defendant no.1 and 2 as Ex.DW1/323.  
 Letter dated 02.09.1983, from defendant no. 1 and 2 to Municipal
Corporation of Delhi informing them that they have purchased the
property from Mrs. C. A. Hiranandani Ex.DW1/324.  
 Notice  dated  16.01.1984  issued by the Municipal Corporation of Bhartia Cutler Hammer Ltd. &
anr v. P.D. Agarwal & ors Page no. 61 of 161 Delhi  to the defendant no. 1 and 2 Ex.DW1/325. Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

           Letter to MCD dated 07.02.1984 as Ex. DW1/326.
           A notice for hearing in the matter was issued to the defendant no.
            1 and 2 by MCD on 04.08.1986 Ex.DW1/327. 
           A receipt dated 11.07.1981 for payment of fees in respect of the
            said   property   in   my   name   paid   by   the   defendant   no.   1
            Ex.DW1/328.
           Receipts showing property tax paid by the defendant no. 1 and 2
            Ex.DW1/329 to DW1/371.
           Copies   of   Self   Assessment   Property   Tax   Forms   for   2   years   as
            samples Ex.DW1/372 and DW1/373.
           Receipts/   bills/   notice   for   payment   of   Ground   Rent   from
Cosmopolitan   Cooperative   Housing   Society   Limited   showing
Ground Rent paid by the defendant no. 1 and his wife Ex.DW1/374 to DW1/402.
 Letter   dt.   21.12.1983   from   Indian   Posts   and   Telegraphs
Department to defendant noting change of address in their records Ex.DW1/403.
 Letter from Hiranandani to Delhi Electric Supply Undertaking to
change the name of owner in their records Ex. DW1/404.  
Electricity bill dated February 1998 Ex.DW1/405.  
Letter dated 09.09.1986 for sanctioning of telephone connection at the said house Ex.DW1/406. 
 Notice   received   from   P&T   office   addressed   to   defendant   no.   1
regarding shifting of telephone connection Ex.DW1/407.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 62 of 161 
Original letter dt. 01.06.1982 addressed to defendant no. 1 issued by plaintiff no. 1 Ex. PW2/A. 
Memorandum   and   Articles   of   association   of   plaintiff   no.   1   Ex.
PW2/DX2.  
7. Ld. Counsel for the plaintiff argued that the defendant no. 1 was working   as   General   Manager  
of   the   plaintiff   no.   1   till   1984   and functioned   as   Executive   Director   thereafter.   He   was  
close   friend   of plaintiff  no.   2  and  was   entrusted  with  and  functioned  as   in−charge   of day−
to−day dealings, management and business affairs of the plaintiff no.
1. During the year 1981, the defendant no. 1 represented to the plaintiff
that there was in need for providing a company house in Delhi which
could be used by him and other senior executives of the company. He
further represented that freehold plots for direct purchase on reasonable price   were   not   available
  and   that   he   had   been   offered   a   proposal   in
respect of leasehold plot in Mayfair garden, New Delhi which could be constructed   upon   and  
ultimately   acquired.   The   defendant   no.   1   also represented   that   one   Sh.   J.K.   Malhotra,  
had   already   entered   into   a transaction   with   the   original   allotee   of   said   property   but  
the   Estate agent had represented to him that transaction could be switched over ifBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

Mr. Malhotra was paid an amount invested by him. The defendant no. 1
represented to the plaintiffs and assured that he would assume personal responsibility   for   the  
transaction   and   ensured   that   investment   of   the
plaintiff no. 1 was properly made and secured that there would be no Bhartia Cutler Hammer Ltd. &
anr v. P.D. Agarwal & ors Page no. 63 of 161 difficulty   in   the   property   being   available   to   the  
plaintiffs.   Since   the defendant   no.   1   was   holding   very   senior   and   confidential   position
therefore,   the   modalities   and   finalization   of   the   transaction   regarding
the plot and raising construction thereof were left to his charge. It was
also argued that the defendant no. 1 further represented that initially,
he would enter into an agreement for acquiring the leasehold plot and for raising   construction  
thereon   in   his   name   as   trustee   and   for   and   on
account on behalf of the plaintiffs which could be at any later stage be
substituted as per the decisions of the plaintiffs which the plaintiffs may
make and required him act upon and implemented. The plaintiffs had
implicit faith and confidence in defendant no. 1 and trusted his words and assurances.
7.1. It is further argued that the property in question was held
by the defendant no. 4 on the basis of perpetual sub−lease and it was
represented that the defendant no. 4 has entered into transaction for sale with
 Mr. Malhotra with whom M/s. Vijay Dhawan & Co. Estate agents
were in contact. Defendant No.1 on the basis of negotiations carried on by   him   with   the   said  
estate   agent   had   decided   on   procuring   the
assignment of the arrangements entered into by Mr. J.K. Malhotra with defendant   No.4.   As   per  
defendant   No.1's   representations,   desire   and decision concerning the intended transactions
 regarding plot no. A−62, Mayfair Gardens, New Delhi, the  plaintiffs at defendant No. 1's behest
forwarded to M/s Vijay Dhawan & Co. Estate Agents through defendant
No. 1, their cheque No. 975348 dated June 8, 1981 for Rs. 1,00,000/− in Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 64 of 161 favor   of   Mr.   J.   K.   Malhotra   and   Mr.  
Malhotra   the   original   intending
purchaser of plot aforesaid opted out of the transaction in respect of the
said plot and thereupon defendant No. 1 negotiated the transaction in respect  of  the said plot
 and the  constructions  to be raised thereon  on Plaintiff   No.   1's   account.   The   said   cheque  
was   forwarded   vide   letter dated   08.06.1981  Ex.PW2/19.    The   said   letter   was   signed   by  
plaintiff No.2 which clearly states that the plaintiffs are interested in buying the
said plot admeasuring 800 sq. yards and it authorizes the estate agent to
negotiate the deal and purchase the said plot on behalf of the plaintiffs.
The third paragraph of the letter also recorded that Mr. J.K. Malhotra
would nominate defendant No.1/or his nominee for transferring all his
rights in favour of Mr. P.D. Agarwal and his nominee. The said  letter clearly   indicates   the   nature
  of   the   transaction   that  was   sought   to   be executed.
7.2. It is further argued that the defendant No. 1 acting for and
on behalf of the plaintiffs sent a letter to the Plaintiff's Bankers, Canara
Bank, Janpath, New Delhi for issue of a demand draft for a sum of Rs.8 Lakhs   in   favor   of  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

Oriental   Bank   of   Commerce   to   the   Credit   of   the
account of Mrs. C.A. Hiranandani. The said letter was sent by defendant
no.1 to the said Canara Bank on or about November 24, 1981. The said letter is Ex.DW1/B. 
The amount was under directions of the defendant
no. 1 debited to the capital account in the books of the Company.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 65 of 161 7.3. It   is   further  
argued   that   defendant   No.   1   entered   into
certain agreements with and got certain documents executed from the
said Mrs. C.A. Hiranandani and kept the same with himself and never
made over the same to the plaintiffs. Further the work of constructions on   the   said   plot   was  
commenced   under   the   overall   charge   and
supervision of defendant No. 1 and by utilizing the funds of plaintiff No.1
and authorized incurring of various expenditure in relation to the work
of constructions that were undertaken on the said plot for, on behalf and
on account of plaintiff No.1.
7.4. It is further argued that considerable amounts of material
and services belonging to and/ or paid for by plaintiff No.1 were under
the directions of the defendant No.1 diverted/ utilized for the said work of constructions on A−
62, Mayfair Gardens, New Delhi, thus, enormous funds   and   resources   of   the   plaintiffs   were  
utilized   for   the   purpose   of raising  the constructions.  During  the period 1982−83, defendant  
No.  1 and various other officials of plaintiff No. 1 acting under instructions of
defendant no.1 spent varying amounts on procurement of constructional materials  which were
 under the  directions   of the defendant   no.1  duly
entered in the books of plaintiff no. 1's New Delhi office as Advance for Acquisition   of   Capital  
Assets.   Subsequently,   during   the   financial   year ending  June   30,  1983   the  cost   of 
acquisition   of  various   constructional materials   aggregating   to   Rs.3,72,645.72   were   debited  
to   the   Capital Account   and   correspondingly   credited   to   other   related   accounts.
Furthermore,   though   considerable   other   expenses   relating   to   various Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 66 of 161
aspects of construction on the said property were incurred from time to
time out of the funds of plaintiff no. 1 and materials/ services procured
and/ or paid for by the plaintiff no. 1 were utilized in relation to the said constructions,   yet   the  
same   appear   not   to   have   been   appropriately
reflected in the books of accounts/ records of Plaintiff No.1 which books of
accounts and records were being kept under the directions, control and
supervision of defendant No. 1.
7.5. It   is   further   argued   that   the   defendant   No.   1   has   not
furnished to the plaintiffs any account of the various expenses incurred
in connection with the work of constructions on the suit property despite
requests. However, so far as the Plaintiffs have been able to ascertain
the fact that during the period 1983−84, 1984−85 materials/ services ofBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

the aggregate value of Rs. 7,60,972.68 have, under instructions of and/ or
at the behest of defendant No. 1 been utilized/ spent in relation to the
construction of the suit property.
7.6. It is further argued that in addition to above various other materials   including   wood,  
furniture,   electrical   and   sanitary   materials/ fittings   &   fixtures,   Geysers,   Air   conditioners,  
Pumps,   Motors,   paints, hardware   and   services   of   labour   skilled   and   unskilled,   carpenters,
painters and construction labour procured in the name and/ or at  the
expenses of the plaintiff no. 1 were utilized in connection with the work of   construction   of   the  
suit   property.   The   complete   details   of   all   such expenses   are   within   the   special  
knowledge   of   defendant   no.   1.   It   is Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors
Page no. 67 of 161 further argued that defendant no. 1 started residing in the portion of the
said premises and got  installed therein various equipment, machinery
and fixtures belonging to and/ or acquired by and/ or in the name and at
the expense of plaintiff no. 1.
7.7. It is argued that in the latter half of 1986, certain acts of
omission and commission on the part of the defendant no.1 pertaining to
the business and transactions of plaintiff no. 1 that had been entrusted
to and were being handled by defendant no. 1 came to light. Plaintiff No.
2 then inquired from defendant no. 1 about the details of the amount
spent in relation to the suit property as the position concerning the same
was not clear from the books of accounts and records that were being maintained   under   the  
supervision   and   charge   of   defendant   no.1.   The defendant   no.   1   was   bound   to   render   all
  accounts   and   hand   over   the
documents/ properties of plaintiff no. 1 but the defendant no. 1 merely
forwarded to plaintiff no. 2 copies of:− i.  Letter   dated   June   8,   1981   from   Plaintiff   No.   1   to  
M/s.   Vijay   Dhawan   &   Co.,   Estate   Agents,   Dhawan   House,   H−179/A,  
Panchsheela Park, New Delhi enclosing the cheque ii. Construction   Agreement   dated   9.11.82  
between   Mr.   C.A.   Hiranandani and Defendants 1 & 2 in respect of constructions to 
be raised on Plot No. A−62, Mayfair Gardens, New Delhi.
iii.  Agreement to sell dated 9.11.1982 between Mr. C.A. Hiranandani Bhartia Cutler Hammer Ltd. &
anr v. P.D. Agarwal & ors Page no. 68 of 161 and   Defendants   Nos.   1   &   2   in   respect   of  
Property   No.   A−62,   Mayfair Gardens, New Delhi and construction thereon.
7.8. Ld. Counsel for plaintiffs further argued that the defendant no.  1  avoided  to  furnish 
true, correct  and  complete documents,  deeds, declarations,   affidavits   obtained   by   him   in  
relation   to   the   transaction
from Mrs. C.A. Hiranandani and also neglected to disclose true and full details,   data   and  
particulars   regarding   utilization   of   funds   of   the
plaintiff.  It is argued that from the Copies sent by defendant no. 1 to the
plaintiffs revealed that the Agreements with Mrs. Hiranandani that had been   initially   entered   in  
the   year   1981   had   been   substituted   in November,   1982   and   further   in   addition   to  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

defendant   No.   1,   his   wife defendant no.  2 was also shown as a co−party with defendant no. 1. As
defendant no.1 was avoiding to furnish details, the plaintiffs sought to
recheck of the accounts and during the course of such recheck, it could be ascertained   that  
materials/   services   procured   and/   or   paid   for   by   the Company   of   the   aggregate   value  
exceeding   Rs.7,60,972.68   had   been
diverted and/ or used under the instructions and directions of defendant
no. 1 in connection with the suit property. The amount had been split
under various heads of expenses of the Company under his instructions,
rendering a discovery/ identification of such manoeuvers difficult. It is
argued that since during the relevant period, defendant no. 1 as General Manager,   Chief  
Supervisor   of   the   Accounts   was   responsible   for   the
various entries made therein and provided to the Auditors the overall
certificates concerning the correctness of the accounts and on the basis of Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 69 of 161
such certificates, the entries appearing under various heads pertaining to   the   utilization   of  
materials   and   services   of   the   Company   were   not
debited to the capital account but under other heads of expenses.
7.9. Ld.   Counsel   for   the   plaintiff   argued   that   the   defendants
have made various admissions as under:
(a) That  in   response   to   the   contents   of   paragraph   1   of   the   plaint,
defendant no.1 in paragraph 1 (iv) of the written statement admits that
he was taken in the company since he was a trustworthy person. The
relevant portion of the written statement is reproduced herein below:
"...In   this   background   the   Plaintiff   No.2   wanted   someone
competent and trustworthy who could set right the company
and make it profitable. ..."
(b) In   response   to   the   contents   of   paragraph   7   of   the   plaint,
Defendants admit in their written statement in reply on merits that a
deal in respect of the aforesaid plot was authorized through brokers in
favour of Defendant No.1/ or his nominees and an initial advance of Rs. 1
Lakhs was made on 08.06.1981. The said portion of Para 7 of the written
statement is reproduced herein below:
"...Consequently, a deal in respect of the aforesaid plot was authorized   through  
brokers   in   favour   of   Defendant   No.1 and/  or   his  nominees;  initial   advance  
of Rs.1.0   lakh  was made on 8th June, 1981 and the balance price agreed to be
paid against transfer of all right, title or interest in the said
plot of land to be effected in favour of defendant No. 1 and/ or his nominees..."
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 70 of 161Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

(c) The   said   admission   gains   importance   in   view   of   the   fact   that
Rs.1.0 lakh was forwarded by plaintiff no.1 to M/s Vijay Dhawan & Co. to
be paid to Mr. J.K. Malhotra, under the cover of letter dated 08.06.1981,
which communication recorded the actual nature of transaction.
(d) In response to the  averments   in paragraph  9  of the  plaint  that
defendant no.1 was holding a very senior and confidential position with plaintiff no.1, the 
defendants  in their written statement  did  not reply thus the said fact is deemed to be admitted.
(e)  The defendants no. 1 to 3 have not replied to the averments in paragraph 10
 of the plaint regarding the transaction of sale with Mr.
J.K. Malhotra in their written statement. The said averments, therefore, are deemed to be admitted. 
 Further, in response to the averments in paragraph   10   of   the   plaint   that   defendant   no.1  
represented   to   the plaintiffs   that   the   transaction   would   have   to   be   in   the   name   of  
some individual/   individuals.   The   contesting   defendants   in   their   written
statement have admitted that the society only admitted membership by
individuals as per the terms of the perpetual lease deed and bye−laws. The   said   portion   of   Para  
10   of   the   written   statement   is   reproduced hereinbelow:
".....Both   the   terms   of   the   perpetual   lease   deed   and   the byelaws   of   the  
said   society   only   admit   membership   by Bhartia Cutler Hammer Ltd. & anr v.
P.D. Agarwal & ors Page no. 71 of 161 individuals   and   the   answering   defendants  
crave   leave   to refer to the provisions of the lease deed and the byelaws in
this connection at the time of hearing, if necessary...."
(f) In response to the averments made in paragraph 11 of the plaint
regarding the letters dated 08.06.1981  (Ex. PW2/19)  enclosing a cheque
of Rs. 1 Lakh in favour of Mr. Malhotra, the contesting defendants in the
written statement have stated that the contents of the letter be referred to   at   the   time   of  
hearing   to   ascertain   its   true   meaning   and   effect.
Meaning thereby that the letter dated 08.06.1981 per−se is not disputed.
However, the defendants wish to give an interpretation to the averments
in the letter which may suit his case. The relevant portion of Para 11 of
written statement is reproduced herein below:
"...The contents of the letter dated 8th June 1981 be referred
to for ascertaining its true meaning and effect at the time of
hearing the documents executed would go to show that the
Defendant Nos. 1 and 2 and Mrs. Hiranandani/ Defendant
No.4 entered into a transaction directly..."
(g) In response to the averments in paragraph 12 of the plaint, the
defendants admit that defendant no.1 could operate the bank accounts of plaintiff   no.1   jointly  
with   one   more   person   i.e.   either   the   ChiefBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

Accountant or the Company Secretary. This admission gains relevance
for the fact that the letter bearing instructions addressed to the bankers
of plaintiff no.1 regarding making of a Demand Draft of Rs.8.0 Lakhs in Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 72 of 161 favour  of  defendant  no.4   was   signed  by 
defendant   no.1   and  the  Chief Accountant   (Mark−DW1/   B).   The   defendants   do   not   dispute
  the   said payment of Rs.8.0 Lakhs made by plaintiff no.1 in favour of defendant
no.4. The relevant portion of the written statement is reproduced herein below:
"12. With reference to para 12 the concerned bank, account,
except for Plaintiff No.2 who could operate solely, the account was  required to be 
operated  jointly by  any  two of the  three persons   including   Defendant   No.1   the  
other   two   being   the Chief Accountant/ Company Secretary..."
(h) In response to the contents of paragraph 14 of the plaint regarding
utilization of funds of plaintiff no.1 for the construction of the said plot,
the defendants have not disputed the said fact. The relevant portion of
Para 14 of the written statement is reproduced herein below:
"...The allegation that the construction on the said plot was
commenced by utilising the funds for collections of Plaintiff No.  1
 is not wholly correct.  In pursuance  of  the  aforesaid agreement   and  
understanding   towards   the   part
adjustment/ discharge of the debt due to Defendant No. 1
against profit sharing, the plaintiff No. 1 advanced certain
amounts and substantial payment were also arranged by the
answering defendants for the aforesaid purpose..."
(i) In   response   to   the   averments   in   paragraph   15   of   the   plaint Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 73 of 161
regarding utilization of funds of plaintiff no.1 and authorizing incurring
of expenditure in relation to the work of construction on the said plot, the
defendants in the written statement do not dispute the expenditure from
the account of the plaintiffs.
(j) In response to the contents of paragraph 16 of the plaint regarding
payment of Rs. 8.0 Lakhs from the funds of plaintiff no. 1 to defendant
no. 4, the said fact is admitted in paragraph 16 of the written statement. Further,   the   amounts  
advanced   by   plaintiff   no.   1   towards   the
construction on the said plot are also admitted by defendant no. 1. The
relevant portion of Para 16 of the written statement is reproduced herein below:
      "...the sum of Rs. 8 lakhs was advanced by the plaintiff No. 1..."Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

(k) In response to the contents of paragraph 17 of the plaint stating
that the amount spent on construction material and the said expenses
has been shown in the books of accounts of plaintiff no.1 as "Advance for
Acquisition of Capital Assets",  the defendants in the written statement admit   both   the   facts.  
The   relevant   portion   of   Para   17   of   the   written statement is reproduced herein below:
"...and   further   advanced   certain   amounts   towards
construction cost..........sometime in or around the year 1982−
83 in the course of finalisation of accounts of Plaintiff No.1
it may however, be that the entry "Advance for Acquisition of Capital   Assets"   must  
have   been   entered   into   the   books   of Bhartia Cutler Hammer Ltd. & anr v. P.D.
Agarwal & ors Page no. 74 of 161
Plaintiff No.1 to avoid any incidence of tax on the plaintiff No.1..."
(l) Further, the figure mentioned in paragraph 17 of the plaint of Rs.
3,72,645.72 towards cost of acquisition of construction material has not been   disputed   in   terms  
of   the   actual   cost   incurred   and   therefore,   is deemed to be admitted.
(m) In response to the averments made in paragraph 19 of the plaint,
the defendants admit that the books of accounts of plaintiff no.1 were regularly   audited  and  
approved  by   the  board.  The   relevant   portion   of
Para 19 of the written statement is reproduced herein below:
"...Even otherwise the allegations are after thought because the   Plaintiff   No.   1   for
  the   periods   in   question   and   even thereafter   have   got   their   books   regularly
  audited   and accounts approved by the Board duly signed, inter−alia, by
Plaintiff No. 2 and the same were published..."
(n) In  response to  the  contents  of paragraph 19A  of the plaint, the
defendants in the written statement admit that the payments were made
for construction on the said plot from the funds/ advances received from plaintiff no.1.
(o) In   response   to   the   contents   of   paragraph   23   of   the   plaint,   the defendants   in   their  
written   statement   have   pleaded   friendly   relations Bhartia Cutler Hammer Ltd. & anr v. P.D.
Agarwal & ors Page no. 75 of 161
between defendant no.1 and plaintiff no.2. The relevant portion of Para
23 of the written statement is reproduced herein below:
"......It   may   be   that   due   to   the   friendly   relations   between
Defendant No. 1 and the Plaintiff No. 2 during the tenure of
service, copies of documents left in the office premises could
have come in the hands of the Plaintiff No.2......"Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

(p) The contents of paragraph 26 of the written statement once again acknowledges   payment   of  
Rs.8.0   Lakhs   by   plaintiff   no.1   towards purchase of the plot.
(q) In  response  to  the   contents   of  paragraph   30   of  the  plaint,  with regard   to   issuance   of  
certificates   by   defendant   no.1,   defendant   no.1 admits issuance of certificates. The relevant
 portion of Para 30 of the written statement is reproduced herein below:
"...The   certificates   required   from   Defendant   No.   1   under directions   of  
Plaintiff   No.   2   of   routine   nature   were furnished..."
(r) The defendants in written statement have pleaded in paragraph
44 of the written statement that defendant no.1 was known to the family
of Plaintiff no.2 as a man of integrity, trustworthy and reliable person.
The relevant portion of Para 44 of the written statement is reproduced herein below:
" ...defendant No.1 being a man of integrity, trustworthy and Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 76 of 161 reliable person ..."
(s) Further, in the counter claim in paragraph v), the defendants admit that   the   total   advances  
made   by   the   plaintiff   no.1   to   defendant   no.1
amounted to Rs. 19.33 Lakhs towards acquisition and construction of the
said plot. The relevant portion of paragraph v) of the counter claim is reproduced herein below:
"...then it is stated that the advances made by the Defendant No.1   towards   plot   of  
land   amounting   to   Rs.8.0   lakhs,
towards construction alleged to be Rs.11.33 lakhs the whole of   the   said   advances  
aggregating   to   Rs.19.33   lakhs
constitute a loan as advanced by Plaintiff No.1 to Defendant No. 1..."
The   Ld.   Counsel   for   the   plaintiff   referring   to   the   aforesaid admissions   argued   that
 though   the  plaintiffs   have   to  prove   their  own
case and they should make their case stand on their own legs but the
plaintiffs are not required to prove the facts which stand admitted in the
written statement or pleadings. The admissions made by the defendants
in their written statement or in the counter claim are not required to be proved   independently   by  
the   plaintiffs   as   it   is   equally   a   settled
proposition in law that admissions by a party in its pleadings need no further   proof.   Therefore,  
the   facts   which   stand   admitted   by   the defendants,   as   pointed   out   hereinabove,   have   the
  tendency   to   narrow down   the   controversy   between   the   parties   and   the   same   cannot   be
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 77 of 161 ignored by this  Court. 
7.10.  It   is   further   argued   that   the   defendants   in   the   written statement   do   not   dispute  
the   amounts   paid   by   plaintiff   no.1   towards
acquisition of plot and construction of plot and admit the amounts statedBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

in the plaint expended towards the transaction i.e. Rs.8.0 Lakhs towards acquisition,   and   a   sum  
of   Rs.3,72,645.72   and   Rs.7,60,972.68   towards construction   totaling   to   Rs.   19,33,618.4.  
Besides   the   aforesaid,   the defendants also admit payment of Rs.1.0 Lakh by plaintiff no.1 to Mr.
J.K.   Malhotra   for   acquiring   rights   in   the   plot.   The   only   defense   put
forward by the contesting defendants is that the plaintiffs had verbally agreed   to   pay   to  
defendant   no.1,   besides   "salary   and   other   usual perquisites"−
 5% of the profits (before tax) by way of profit sharing to be
computed on year to year basis which was to be paid for consideration
other than cash. Therefore, the defence sought to be raised is that the
monies forwarded by plaintiff no.1 towards acquisition of the plot as also towards   construction  
thereon   were   in   terms   of   the   aforesaid
understanding of 5% profit sharing and therefore, the plaintiffs have no
right in the said property which is without any substance.
7.11. It   is   further   argued   that   the   present   plaint   was   filed   on 08.01.1988   but   the  
Benami   Transactions   (Prohibition)   Act,   1988
(herinafter referred to as Act, 1988) for the purposes of Sections 3, 5 and
8 came into force on 05.09.1988 and the remaining sections were deemed
to have come into force on 19.05.1988. Prior to coming into force of the Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 78 of 161
said Act, 1988 the litigations on the issues involved as are involved in the
present case, were governed by the then existing law under the Indian
Trusts Act, 1882. Section 7 of the Benami Transactions (Prohibition) Act,
1988 specifically repealed sections 81, 82 and 94 of the Indian Trusts Act,
1988, Section 66 of the Code of Civil Procedure, 1908 and Section 281A of
the Income Tax Act. Further, Section 4(1) of the Benami Transactions (Prohibition)   Act,   1988  
prohibited   the   right   to   recover   property   held
Benami and therefore, all suits would have been liable to be dismissed
which were pending on the date when the Act came into force. The said
issue as to the status of the suit filed prior to the coming into force of the
Benami Transactions (Prohibition) Act, 1988 and the impact of coming
into force of the said Act was considered by Hon'ble Supreme Court in the   matter   of  R.  
Rajagopal   Reddy   v.   Padmini   Chandrashekharan reported in
 AIR 1996 SC 238. The Hon'ble Court was considering the
question as to whether Section 4(1) of the Act, 1988 can be applied to a
suit, claim or action to enforce any right in property held Benami against
such persons in the name of whom the property is held if such proceeding
has been instituted by the real owner prior to coming into force of Section 4(1)   of   the   Act,   which
  proceedings   might   be   at   various   stages   in   the hierarchy.   The   Hon'ble   Court   answered  
the   question   in   negative   and held   that   such   proceedings   would   not   be   affected   by   the  
Benami Transactions (Prohibition) Act, 1988 and that the proceedings will have
to be continued or enforced as if the repealing Act had not been passed.
Therefore, the suit of the plaintiffs having been filed on 08.01.1988 that is   much   prior   to   the  
date   of   enforcement   of   the   Benami   Transactions Bhartia Cutler Hammer Ltd. & anr v. P.D.Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

Agarwal & ors Page no. 79 of 161
(Prohibition) Act, 1988 has to be dealt with in terms of the earlier law
applicable i.e. the Indian Trusts Act, 1882.
7.12. Ld. Counsel for the plaintiffs further argued that Section 26
of Code of Civil Procedure, 1908 (hereinafter referred to as the CPC) and
corresponding order to said Section Order IV of CPC contemplates that suit   shall   be   instituted  
by   presentation   of   plaint.   Section   27   CPC
stipulates that where a suit has been duly instituted, summons may be
issued to the defendants and a perusal of these two sections would show that   Section   26   does  
not   use   the   terminology   'duly   instituted'   which
terminology has been used in Section 27 CPC, therefore, the institution
of suit is complied with the moment when the plaint is presented before
a Court of law. The date of presentation of the plaint is to be treated as
date of institution of suit in terms with Section 26 read with Order IV
Rule 1 CPC.  Ld. Counsel for plaintiff further argued that Section 149 of
the Code of Civil Procedure 1908 is applicable when the matter comes up
before the Court and the Court exercises its discretion to grant time. The
said provision further stipulates that in the event such a discretion is
exercised by the Court and the court fee is paid, it shall have the same
force and effect as if such fee had been paid in the first instance. The provision does
 not anywhere stipulate that  in the absence of deficient court   fee,   the   plaint   instituted   shall   be
  deemed   to   be   not   instituted. Further,   a   perusal   of   the   provisions   of   Order   VII   Rule  
11   sub−rule(c) stipulates   that   the   plaint   can   be   rejected   where   it   is   written   on   an
insufficient stamp paper and when the Court calls upon a party to supply Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 80 of 161 the requisite stamp−
paper within a time to be fixed and party fails to do
so. In that event also, the plaint which is before the Court is considered to   be   a   plaint   filed   on  
the   date   of   its   presentation.   In   view   of   the
aforesaid, the provisions of Section 149 of the Code of Civil Procedure, 1908   in   order   to   show  
that   the   plaint   in   the   present   suit   would   be deemed   to   be   presented   on   23.07.1988  
are   not   at   all   applicable.   The
plaint in the present suit was duly presented on 08.01.1988 that is much
prior to the coming into force of the Benami Transactions (Prohibitions) Act,   1988   and   in   terms
  of   the   settled   law   laid   down   by   the   Hon'ble
Supreme Court in R. Rajagopal Reddy (supra), the provisions of Benami Transactions   (Prohibition)
  Act,   1988   are  not   applicable   to  the  present
case and the suit would be governed by the provisions of the Trusts Act, 1882.   Ld.   Counsel   for  
plaintiff   placed   reliance   upon   judgments   as follows:− 
Vidyawati Gupta & ors v. Bhakti Hari Nayak & ors, JT2006 (2) SC, 278 
Alka Kasana v. Indian Institute of Technology,222 (2015) DLT 473 
D.C. Sankhla v. Ashok Kumar Parmar  ors 1995 1AD (Delhi), 753,  
Raj Navinder Pal v. State 2007, Law suit Deli (Del) 687  Eastern   Steamship   Private   Ltd.   v.  
Pucto   Private   Ltd.   &   Anr.Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

(1970) 72 Bom LR 697  H   H   Maharaja   or   Cooch   Behar;   Abdul   Masid   Basunia   v.   Raja
Mahendra Ranjan Rai Chaudhuri 1921 AIR (Cal) 277 Bhartia Cutler Hammer Ltd. & anr v. P.D.
Agarwal & ors Page no. 81 of 161 7.13. Ld.   Counsel   for   the   plaintiffs   further   argued   that   the
contentions   of   the   defendants   that   the   suit   of   the   plaintiffs   is   not maintainable   because
  the   plaintiffs   have   failed   to   file   or   produce   any
accounting entry/ records to substantiate their claim that the property in
question was purchased by plaintiff no. 1 and further that no resolution was   passed   in   terms   of  
Articles   of   Association   of   plaintiff   no.   1
authorizing purchase of the property in excess of Rs. 1,00,000/− and in view of non−
compliance of Section 281A of the Income Tax,   is without
any substance. The defendants in the written statement do not dispute the   amounts   paid   by  
plaintiff   no.1   towards   acquisition   of   plot   and
construction of plot and admit the amounts stated in the plaint expended
towards the transaction i.e. Rs.8.0 Lakhs towards acquisition, and a sum of   Rs.3,72,645.72   and  
Rs.7,60,972.68   towards   construction   totalling   to Rs.   19,33,618.40.   Besides   the   aforesaid,  
the   defendants   also   admit payment   of   Rs.1.0   Lakh   by   plaintiff   no.1   to   Mr.   J.K.  
Malhotra   for acquiring rights in the plot. It is also argued that meeting of the Board of
Directors of plaintiff no. 1 was held on 22 nd  day of November, 1983 for
approval of draft annual accounts of the Company for the financial year
ended 30th June, 1983.  In the said meeting it was resolved as follows:
"RESOLVED   that   the   expenditure   incurred   during   the   year   on construction  
of   new   R&D   building,   other   building   and   other capital   jobs   shown   as  
building   under   construction   (R   &   D)
Building under Construction (others) and others Rs. 4,61,687/−, Rs. 11,74,846/−  
and   Rs.   2,11,064/−   respectively,   be   and   are   hereby approved".
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 82 of 161 It   is   argued   that   the
  copies   of   General   Ledger   titled
"Building under Construction A/c" shows that as on June 30, 1983 a total sum   of   Rs.  
11,74,845.72   was   being   shown   in   the   books   of   account   of plaintiff   no.   1   on   account   of  
Rs.   8,02,200/−   being   paid   to   Ms.   C.A. Hiranandani   for   acquisition   of   property   and  
Rs.3,72,645.72   being   the expenses incurred in construction of said property.  It is submitted that
the   figure   of   Rs.11,74,845.72   corresponds   with   the   figure   of Rs.11,74,846/−   approved   by  
Board   of   Directors   of   plaintiff   no.   1   in meeting held on November 22, 1983. 
 Ld. counsel for plaintiffs further
argued that on conjoint reading of Section 90 of the Evidence Act along with   Section   193   to   196  
of   Indian   Companies   Act,   the   plaintiffs   are
entitled to a presumption in its favour that the amount of Rs.11,74,846/−
approved by its Board of Directors in the meeting held on 22 nd November 1983 co−
relates with the entries made under the head "Building under
Construction" in relation to property in question.  It also lays to rest the submissions   of  
defendants   that   no   Board   Resolution   was   passed   for
approving the accounts for the relevant year as did not show the suitBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

property as a fixed asset of the Company.  As, the documents being filed
by the plaintiffs, after a lapse of 30 years, so no more require any proof.
It is further argued that argument that articles debarred acquisition of a
property exceeding Rs.1,00,000/− without getting approval of the same, in general   body   meeting  
is   without   any   substance   as   the   defendants   in written   statement   have   stated   about   the  
fact   that   plaintiff   no.   2   was having   100%   shareholding   and   total   control   of   plaintiff   no.
  1.   Even assuming that a resolution under clause 115 of Articles of Association Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 83 of 161
ought to have been passed in a general meeting of the Company, then also the issue of non−
passing of special resolution is of no relevance as
the same would have been required to be passed, if the shareholding of
the plaintiff no. 1 was divided into/ allotted to various shareholders.  But it   is   defendant's   own  
case   that   plaintiff   no.   2   was   having   100%
shareholding and continues to have total control of plaintiff no. 1.  It is
submitted that the said argument is also unsustainable in view of the resolution   passed   by   the  
Board   of   Directors   of   the   Company   in   the
meeting held on November 22, 1983 approving the expenditure incurred
and shown as "Building under Construction" in the books of accounts of
plaintiff no. 1. It is further argued that the said argument advanced is
also erroneous as the same is contrary to the provisions of Section 291 and 292
 of the Companies Act. The said provisions  have been subject
matter of interpretation before the Courts and the courts have concluded
that the compliance of such conditions of the articles of association is an
internal requirement, however, the same cannot be used by a third party to   his   advantage   which  
prejudices   the   right   of   the   company.   The
obligations of third parties qua the company do not change or cease to exist.   This   rule   is  
commonly   called   as   the   'Doctrine   of   Indoor
Management' or 'Turquand Rule' after Royal British Bank v. Turquand case   which   holds   that  
qua   third   parties,   there   is   a   presumption   of compliance   of   rules.   In   this   regard,   the  
plaintiffs   relied   upon   the judgment  of the Hon'ble High Court of Delhi  in the matter of  Jasdev
Singh & Ors. v. Unit Trust of India - LPA No. 10/2005 on 02.05.2011.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 84 of 161 7.14.
It is further argued that the another contention that suit is barred due to non−
filing of copy of notice given to the Commissioner for
acquisition of property as required under the provisions of Section 281A of   the   Income   Tax   Act,
  1961   is   concerned,   the   said   provisions   stands
repealed in terms of Section 7 of the Benami Transactions (Prohibition)
Act, 1988. The said provision is not applicable to the facts of the present
case as no objection as to the maintainability of the suit in view of the
bar of Section 281A of the Income Tax Act, 1961 has been taken in the
written statement filed by the defendants. It is a settled proposition of
law that an objection as to maintainability of suit should be taken at the
first instance. If the objection is not taken at the first instance, especiallyBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

the one of the nature as contemplated under Section 281A of the Income
Tax Act, the same is deemed to have been waived and the defendants at this   stage   cannot   agitate  
the   said   issue.   By   way   of   illustration,   it   is
submitted that a provision similar to Section 281A of the Income Tax Act
exists in Section 80 of the Code of Civil Procedure, 1908 which bars the institution   of   a   suit  
against   the   Govt.   or   a   public   officer   until   a   two
months' notice has been issued. In those cases also, when the defendants
fail to take an objection as to the maintainability of the suit at the initial
stage itself, the objection is deemed to have been waived.   It is further argued   that   provisions   of  
Order   VIII   Rule   2   of   the   Code   of   Civil Procedure,1908   which   stipulate   that   the  
defendant   must   raise   in   his
pleadings all matters which show the suit not to be maintainable and all
such grounds of defence if not raised would be likely to take the opposite party   by   surprise.   The  
plaintiffs   placed   reliance   upon   judgments   as Bhartia Cutler Hammer Ltd. & anr v. P.D.
Agarwal & ors Page no. 85 of 161 follows:− 
1. Ramesh Chand Sharma v. R.S. Aggarwal & Ors. 22 (1982) DLT 356
2.   Bijoy Kant Dey v. Radha kant Dey 1983 (31) BLJR
3.   Dhian Singh Sobha Singh & Anr. v. Union of India AIR 1958 Supreme Court 274 7.15.
Ld. Counsel for the plaintiffs further argued that in support of   its   case,   only   defendant   no.1  
has   entered   the   witness   box   and   the
defence set up by the defendants is to the effect that there was an oral agreement   between   him  
and   the   plaintiffs   with   regard   to   5%   profit sharing   as   alleged   by   him   and   defendant  
no.1   admits   in   his   cross−
examination that there is no document showing profit sharing agreement
between him and plaintiff no.1. It is further argued that the defendant
No.1 admits the fact in his cross−examination that not only the alleged profit   sharing   arrangement
  was   verbal   but   also   at   no   point   in   time starting   from   1974   to   1986   or   even   after  
filing   of   the   suit,   he   ever addressed   any   communication   in   writing   regarding   the  
demand, adjustment or release of the sums due in terms of alleged profit sharing.
Further, defendant no.1 admits in his cross examination that the cheque
of Rs.1.0 Lakh referred to in letter dated 08.06.1981  issued by plaintiff
no.2 is the same as stated in undated letter Ex. DW1/PX1. The letter Ex.
DW1/PX1  was   filed  by  the  defendants   along   with   a   list   of   documents
dated 28.10.2005, however, surprisingly the same was not relied upon by
the defendants in their evidence and also the said letter does not bear Bhartia Cutler Hammer Ltd. &
anr v. P.D. Agarwal & ors Page no. 86 of 161
any date and makes mention of  refund of money paid by plaintiff no.2 'in cash'.   Further,  
defendant   no.1   has   admitted   in   his   cross−examination
that he has not referred to this letter in his written statement and denies
the suggestion of it being a sham document. Even otherwise, the letter at least   gives   details   of  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

the   cheque   dated  08.06.1981   which   are   same  as
those found in Ex. PW2/19, therefore, the said letter proves the fact that a   sum   of  Rs.1.0  Lakh
 was   forwarded  on  08.06.1981.  It   is   a  matter  of
record that in response to the averments made in paragraph 11 of the
plaint, defendants in their written statement have not termed the letter dated   08.06.1981   as   a  
sham   document.   In   order   to   wriggle   out   of contradiction   as   to   the   written   statement  
and   the   statement   made   in evidence,   defendant   no.   1   stated   that   he   was   referring   to  
some   other letter, however, which letter is not part of the record. Clearly, defendant
no.1 has deposed falsely in this regard. Besides, this the letter also bears a   no   objection   at   the  
bottom   signed   by   Mr.   J.K.   Malhotra.   The   said
communication identifies the cheque issued by plaintiff no.1, the estate agent   and   Mr.   J.K.  
Malhotra   and   the   fact   that   a   cheque   had   been
received from plaintiff no.2. At the same time, these facts can also be
verified in Ex.PW2/19 which also carries all the four names. Ex. PW2/19 also  categorically states
 that   the sub−lessee of the  plot  was  defendant no.4   and   therefore,   relates   to   the   suit  
property   No.   A−62,   Mayfair Gardens,   New   Delhi   which   has   been   inadvertently   referred  
as   A−162, Mayfair Gardens.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 87 of 161 7.16.
The Ld. Counsel for the plaintiffs further argued that the defendant   no.1   admits   his   signature  
on  Ex.−P35   (PW2/21)  which   is   a
communication addressed by him to Price Waterhouse & Co. confirming to  the  auditors  the  facts 
in  the  balance sheet.  Similarly,  Ex.−P36  (Ex.
PW2/22) which is a communication by him to M/s. Price Waterhouse &
Co. enclosing accounts and balance sheet for 15 months. This proves his involvement   in   the  
financial   and   accounting   affairs   of   plaintiff   no.1,
which fact is sought to be outrightly disputed.
7.17. It   is   further   argued   that   in   support   of   his   case,   the   only document   that   defendant
  no.1   has   sought   to   produce   is   a   letter   dt. 01.06.1982
 Ex. PW2/A addressed to defendant no. 1 by plaintiff no. 1.
The letter bears signature of the Chief Accountant Mr. A.N. Chandna. A
careful perusal of the letter would reveal that the same is on a letter
head carrying phone numbers and telex numbers which are printed on
other letter heads of the company used in the year 1978. Defendant no.1 was cross−
examined by showing him other letter heads of Ex. P16 (letter dt.   30.04.1982   to   RBI   for  
technical   training   regarding   foreign
collaboration), Ex. P26 (letter dt. 24.08.1978 to RBI for foreign exchange for   visit   to  
collaborators   for   technical   appraisal),   Ex.   P15   (letter   dt.
17.08.1983 to RBI for foreign exchange regarding foreign collaboration)
and Ex.P11 (PW2/17) (letter dt. 11.09.1986 to RBI regarding technical foreign   collaboration).   After
  comparing   all   the   letter   heads,   it   can   be concluded that  during  the year  1982, plaintiff no.1
  was   not  using  the letter head on which Exhibit PW2/A has been made. The same is clearlyBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 88 of 161 a  forged document 
for the reason that once the phone numbers of the company   change,   old   letter   heads   are  
discarded.   Even   the   written
statement filed by the defendants on 23.07.1989 and thereafter, amended
written statement on 18.03.2003 does not talk about the said certificate. Further,   Mr.   A.N.  
Chandna,   the   signatory   to   the   said   letter   left   the
employment of plaintiff no.1 in the year 1988 and since then has been on
the board of the company of defendant no.1.   In any event and without
prejudice to the aforesaid, Ex.−PW2/A does not in any manner talk about any   profit   sharing  
arrangement   between   plaintiff   no.1   and   defendant
no.1. It rather used the words "...we have advanced to you..." "...will be
deducted from salary compensation...". The aforesaid wordings show that
firstly the amount paid was to be deducted from the salary compensation
and not from any other source and the same was to be deducted on a future date.
7.18. It is further argued that the defendant no.1 has placed on
record his Income Tax Returns for the Assessment Year 1982−83 and the
same has been exhibited as Ex. DW1/PX2. A perusal of the said Income
Tax Return shows that the return has been filed only with regard to the
salary compensation received by defendant no.1. The same does not show
the amount paid by plaintiff no.1 towards purchase of the plot and the
alleged plea of having received the said amount as part of his income.
Further, on being asked as to whether the said amount was shown by defendant   no.1   in   his  
Income   Tax   Return,   though   he   stated   that   the same   was   shown,   however,   he   stated  
that   he   could   not   produce   any Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page
no. 89 of 161 records showing the said amount as his income.
7.19. It is further argued by Ld. Counsel for the plaintiffs that for proving   any   profit   sharing  
arrangement   that   if   defendant   no.1   was
introduced to plaintiff no.2 by Mr. P.C. Kejriwal then the alleged profit sharing  agreement  
could have  been within  the knowledge  of Mr.  P.C. Kejriwal   since   he   was   the   person   who  
introduced   defendant   no.1   to plaintiff   no.2   but   the   defendant   no.1   in   his   cross−
examination   admits that Mr. P.C. Kejriwal holds shares in his company and is on the board of
the company since 1988, meaning thereby that the defendant no. 1 was
in touch with Mr. P.C. Kejriwal. Moreover, defendant no.1 has failed to
produce him as a witness to the said verbal profit sharing arrangement
and it is submitted that it was Mr. P.C. Kejriwal who could have been
the best witness to support the verbal profit sharing arrangement but for reasons   best  known   to 
defendant   no.1,   he   has   not   produced   any   such
witness in support of his case. It is further argued that Mr. O.P Bhartia
does not admit the document per se.   A perusal of the evidence would
show that Mr. O.P. Bhartia recognized the letter head and signatures on the   documents   in   terms  
of   which   the   document   was   exhibited   and   in
response to further query, he used the words regarding issuance of letterBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

as "must have been issued". The said words clearly show that he had no personal   knowledge   about
  issuance   of   the   said   letter   and   his
acknowledgement of the letter was only on account of the letter head and
the signatures followed by a presumption of issuance. In any event, it was   only   on   a   closer  
scrutiny   later   and   after   analysing   the Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors
Page no. 90 of 161 circumstances, it was concluded that the letter head had been forged. In
fact, it was the case of defendant no.1 himself that Plaintiff No.1 never
had any practice of issuing any certificates, then how such a certificate was issued.
7.20. Ld. Counsel for the plaintiffs further argued that the law as
stands settled is that in order to ascertain whether a particular sale is
Benami and the apparent purchaser is not the real owner, the burden
lies on the person ascertaining to prove so. The courts have held that
there is no absolute formula which has been evolved but the courts in the
facts of a particular case are guided by probabilities and inference. The Courts   have   laid   down  
six   guidelines,   and   after   applying   the   said
guidelines to the facts of the case, it is argued as follows:− •
The source from which the purchase money came:  In the present
case, it is an admitted position between the parties that the funds
for acquisition of plot and the construction thereon were forwarded
by plaintiff no.1. The defendants, while admitting the factum of funds   forwarded,   have   tried   to  
allege   a   verbal   profit   sharing arrangement, which they have miserably failed to prove. Neither
any   witness   has   been   brought   to   prove   the   alleged   verbal
arrangement despite admission of the fact that the best possible
witness, if at all, is in touch with defendant no.1  and is on the
board of company of defendant no.1, therefore, the source of money
flowing from plaintiff no.1 is undisputed.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 91 of 161 • The   nature   and  
possession   of   property   after   purchase:   it   is   the case   of   the   plaintiffs   that   after   the  
purchase   of   the   plot,   the construction was also carried out with funds of Plaintiff No.1. It is
the case of the plaintiffs that the purpose of buying the property was   to   make   a   company   house
  for   accommodation   for   senior officials   of   plaintiff   no.1.   The   plaint   categorically   states  
that defendant no.1 was inducted in a portion of the plot. All expenses towards   maintenance   of  
the   property   were   being   incurred   by plaintiff   no.1   and   plaintiff   no.1   as   per   the  
arrangement   was holding the property in trust for plaintiff no.1. The possession of
defendant no.1 as an employee of plaintiff no.1 was a permissive possession.   In   fact,   the  
defendants   in   paragraph   F   of   their
preliminary objections and 32A of reply on merits of their written
statement have specifically pleaded as one of his defences to hold the   property   as   he   is   holding
  the   property   by   way   of   adverse
possession, meaning thereby, adverse to the interest of the actual
owner. Therefore, the possession of defendant no.1 as an employee of   the   plaintiff   was   for   and  
on   behalf   of   plaintiff   no.1   and   he cannot claim an independent right qua the same. Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

• Motive, if any, for giving the transaction a Benami colour: It is the
case of the plaintiffs that for the purposes of acquiring a company house   in   Delhi,   it   was  
represented  by   defendant   No.1   that   free hold   plots   for   direct   purchase   on   reasonable  
prices   were   not available and a lease hold plot of land in Mayfair Gardens was
available. He further represented that the transaction would have Bhartia Cutler Hammer Ltd. & anr
v. P.D. Agarwal & ors Page no. 92 of 161
to be in the name of some individual and that initially he would
enter into the agreement for acquiring the leasehold plot and for
raising construction thereon in his name as a trustee, for and on behalf   of   the   Plaintiffs   which  
could,   at   any   later   stage,   be substituted   as   per   the   decision   of   the   Plaintiffs   which   the
Plaintiffs may make and require him to act upon and implement.
It is submitted that the said motive for giving the transaction a
Benami colour is admitted by the Defendants in paragraph 10 of
reply on merits of their written statement. 
• Position of the parties and the relationship, if any, between the Claimant   and   the   alleged  
Benamidar:   It   is   the   case   of   the
plaintiffs that defendant no.1 was its General Manager and later Executive   Director   and   a  
confidante   and   close   friend.   He   was
holding a very senior and confidential position with plaintiff no.1
and the relationship between the parties was fiduciary in nature
having entrusted defendant no.1 with the complete functioning of
the company. The element of trust on the senior most employee of the   company   automatically  
creeps   in   on   account   of   him   being entrusted with  such  a  senior  position,  unless, he  proves
 lack  of trust with his conduct.
• Custody of title deeds after sale: It is the case of the plaintiffs that
it called upon defendant no.1 after termination of his services to
provide the details with regard to acquisition of the property and
he forwarded just a few copies of the documents. The contention of
the defendants that it is the plaintiffs who should have retained Bhartia Cutler Hammer Ltd. & anr
v. P.D. Agarwal & ors Page no. 93 of 161 the custody of title documents and non−
possession of the same by the plaintiffs  is  on account  of the fact  that  the  transaction was
made for and on behalf of the defendants is without any substance as defendant  no.1  was
 entrusted  with  the task of acquiring  the
plot and carrying out construction on the same. He was to get the
property in his own name and hold it in trust on behalf of plaintiff No.1.   If   after   acquisition   of  
property   and   before   leaving   the company, defendant no.1 has taken away the originals with him,
the   same   cannot   be   construed   in   his   favour.   The   plaintiff   no.1 company,  like any  other
 entity, functioned through  its   directors and   employees   and   the   company   cannot   hold  
documents   on   its own. The same are to be kept with the company in custody of some
official. If the said official has mischievously taken with him the
original documents then the said fact cannot be construed against
the company as in the present case. It is further submitted thatBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

plaintiff no.2, though he is a Managing Director, is not required to hold   and   maintain   with  
himself   personally   each   and   every
document of the company and going by a fair level of trust as his co−
workers he also believes that the original important documents
of the company would not be misappropriated by any employee. •
Conduct of the parties concerned in dealing with the property after
sale: The property was acquired and thereafter construction was
carried out from the funds of the company. The said fact is not
disputed. The said property was acquired and constructed for the
purposes of the company house. Defendant No.1 was permitted to Bhartia Cutler Hammer Ltd. &
anr v. P.D. Agarwal & ors Page no. 94 of 161
stay in the said property and his occupation in a portion of the
property was by way of a permissive user. Much reliance has been placed   on   the   alleged  
Grahapravesh/   Havan   Ceremony   by
defendants in the said house. The said aspect has to be evaluated
in terms of the timing and the purpose. The timing being while defendant   no.1   was   working   for  
the   company   and   the accommodation was being provided for him and the purpose being
that anybody moving into a new accommodation going by his/her faith,  conducts  religious  
ceremonies  to ensure  that  the  property
which the person is going to occupy should be good and prosperous
for him. The same has nothing to do with the ownership of the property.
7.21. Ld.   Counsel   for   plaintiffs   further   placed   reliance   upon judgments as follows:− •
Jaydayal Poddar (Deceased) vs Mst. Bibi Hazra And Ors AIR 1974 SC 171  •
Valliammal (D) by Lrs. V. Subramanium & Ors. (2004) 7 Supreme Court Cases 233 •
Mohinder Singh v. Kartar Singh & Ors. 156 (2009) DLT 526  •
Ponnusamy vs Narayanan  AIR 1977 Madras 19
8. Per  contra,   Ld.  Senior   Counsel   for  the  defendants   argued
that no such representation was ever made by defendant no. 1 as alleged
by the plaintiff and no proof has been placed on record to show that any
such representation was made.  It is argued that even the witness of the Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 95 of 161 plaintiffs,   Sh.   Sanjay   Sharma   (PW   1)   in   this  
regard,   though   in   his affidavit stated several times that he has deposed from records available
with the Company but later on in the cross−examination admitted that
the entire contents of para 4 of his affidavit (about the transaction of the
property) was told to him orally by someone whose name he could not
recall and thus the falsity of the allegations is absolutely clear.
Cross−examination of PW1 Sanjay Sharma on 06.04.2011 "The   entire   contents   of   para   4   of  
my   affidavit   are   based   on   oral
information received by me from certain officials of the plaintiff company
I do not recollect their names."Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

8.1. It   is   further   argued   on   behalf   of   the   defendants   that   no
representation such freehold plot, dealing with estate agent, dealing with
Sh. J. K. Malhotra, assuming personal liability, switching of transaction
in favour of the plaintiff as alleged by the plaintiffs was never made by defendant   no.   1.   The  
contentions   are   baseless   without   any   proof   or   a single   document   whatsoever.   It   is  
further   argued   that   the   alleged
amount of Rs.8.0 lacs was paid by defendant no. 1 from his account in the
company and was debited to him in the books of the company. This was
confirmed by the letter Ex. PW2/A issued by the company which fact has
been admitted by PW 2 i.e. Sh. O. P. Bhartia. It is argued that in respect
of this payment no account books / auditors report / vouchers have been
produced by the plaintiffs and in the cross− examination of PW2 twice it
was stated that he does not know if it was debited to defendant no. 1 or Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 96 of 161 not.
Cross of PW 2 on 09.10.2013 "I cannot say if  the  draft of Rs. 8.0 lacs was debited to the account of
defendant no. 1 in the books of plaintiff no. 1."
Cross of PW 2 on 20.05.2014
"I do not know that the said payment of Rs.8 lacs issued in the name of
CA Sh. Hira Nanadani was debited to the account of defendant no .1 in
the books of account of the company."
Based on the above, it was argued that if it was not debited to the
account of defendant no. 1 then this witness would have said so but by
saying that he does not know shows that it was debited and was debited correctly   to  defendant   no.
  1,  which   fact   the   witness   does   not   want   to admit.
8.2. The   ld.   Senior   Counsel   for   the   defendants   repelling   the
contention of not handing over the documents of the suit property argued
that there was no reason to handover the documents to the plaintiffs as they   had   no   connection  
with   the   suit   property   and   as   the   property
belonged to the defendant no(s). 1 & 2. In repelling the contention of the plaintiff   about   utilization
  of   the   funds   of   the   company   and   being
authorized to incur expenditure on construction of the suit property for plaintiffs,   it   was   argued  
that   the   construction   was   raised   by   the Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal &
ors Page no. 97 of 161 defendants   as   owners   of   the   suit   property.   In   support   hundreds   of
documents   (Ex.   DW1/40   to   306)   have   been   placed   on   record   by   the
defendants to prove the same which go un−assailed. It is argued that on
the contrary, the plaintiffs have not proven a single document to show
that the construction was raised by and/or paid by the plaintiffs. It is
argued that in fact, PW1 Sh. Sanjay Sharma confessed during his cross−
examination on 11.01.2012 that the bills for construction alleged to be
paid by plaintiff no. 1 actually do not pertain to the suit property.  It is argued   that   no   account  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

books   /   auditors   report   /   vouchers   have   been produced   by   the   plaintiffs.   It   is   argued  
that   on   one   hand,   plaintiffs
alleged that funds belonging to the plaintiffs were 'DIVERTED' to raise
construction on the suit property while on the other hand, they alleged
that the plaintiffs themselves wanted to raise construction on the suit
property. The two stands are contradictory. It is argued that not a single document   has   been  
placed   on   record   in   support   of   the   alleged
expenditure of Rs.3,72,645.72 and no accounts have been produced. It is
pointed out that the plaintiffs have admitted in their cross−examination
that there was a separate accounts department in the company with as
many as 18 accountants working in the department and having the Chief Accountant   as   the   head
  of   the   department.   The   argument   was   given
referring to the following relevant portions of the cross−examination of
PW1 Sanjay Sharma and PW2 Sh. O.P. Bhartia.
Cross−examination of PW2 on 11.01.2013
"It is correct that there is a separate account department in the plaintiff company.   The   Head   of  
the   Accounts   Department   was   the   Chief Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal &
ors Page no. 98 of 161 Accounts   Officer   at   the   relevant   time.   It   is   correct   that   Mr.   A.   N.
Chandna was the Chief Accounts Officer at the relevant time. There were   other   Accounts   Officer  
as   well.   It   is   also   correct   that   other Accounts   Officers   were   working   under   the  
supervision   of   Mr.   A.   N. Chandna.   I   do   not   recall   if   Mr.   A.   N.   Chandna   was   a   full  
fledged Chartered Accountant."
Cross−examination of PW1 witness Sanjay Sharma on 05.04.2011
"At the relevant time in 1987, there had been as many as 18 employees
posted in the accounts department ...... It is correct that in 1987, Mr.
A.N. Chandna was the Chief Account Officer of the plaintiff company. It   is   also   correct   that   in  
1987,   Mr.   Chandna   was   a   Chartered Accountant."
8.3. The ld. Sr. counsel refuted the plaintiffs' claim that accounts
of the company were manipulated under the directions of defendant no. 1 by   arguing   that   they  
have   not   even   mentioned   the   names   of   the accountants   who   were   directed   by  
defendant   no.   1   to   do   the manipulations.  They  have  not  even  mentioned what   action  was  
taken against those accountants. 
8.4. It   is   further   argued   that   the   cross−examination   of   the
witnesses examined by the plaintiffs clearly show that defendant no. 1 & 2   alongwith   their   family
  were   exclusively   living   in   the   entire   suit Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal &
ors Page no. 99 of 161 property   since   beginning   without   any   interference   of   anyone.   The
following cross−examination was referred:
Cross of PW1 Sanjay Sharma on 16.08.2011
"It is correct that the plans were got sanctioned in the name of Mr. P. D.Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

Aggarwal and his wife. It is correct that the building work was completed
in the year 1983 and Mr. P.D. Aggarwal and his family started residing
therein from 1983 onwards. It is correct that when I joined the plaintiff
company in the year 1987 the building work in plot no. A−62, Mayfair
Garden, N.D. was already completed and Mr. P.D. Aggarwal along with
his family members was already residing in the said building."
Cross of PW2 on 20.05.2014
"It is correct that when defendant no. 1 left the services of the company in
1986 he was living in the suit property. I did not ask for possession from
defendant no.1 of the suit property when I fired him.  It is correct that
right from the beginning the property in question i.e. the suit property it is the  
defendant   no.   1   and   his   family   who   has   been   living   in   the   said property."
Cross of PW2 on 09.10.2013 "It is correct that ever−since the construction in A−
62, Mayfair Garden was
completed defendant nos. 1 and 2 alongwith their family are residing in
the said house.  I do not recall if any notice was sent to any defendant to
vacate the property before filing the present"
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 100 of 161 8.5.
It was argued that all Property Taxes, Ground Rent, Dues of
Cooperative Society since the beginning were paid by the defendants. In
support, the relevant bills and correspondence with DDA, MCD, DESU,
Cooperative Housing Society etc. has also been placed on record (DW1/
307 to 406) by the defendants as evidence of the same.
8.6. It   was   further   argued   by   Ld.   Senior   Counsel   that   the
plaintiff no. 2 neither enquired from the defendant no. 1 as alleged nor
was he required to do as the suit property belongs to the defendants. The books   of  
accounts   were   and   are   in   possession   of   the   plaintiffs.   The
argument that defendant no. 1 promised to make available documents
pertaining to the suit property is without any substance because plaintiff no. 
2 had categorically admitted  during his  cross−examination that he
never asked for the title documents:
 Cross−examination of PW2 on 09.10.2013
"I have never issued any notice in writing to defendant no. 1 ever since he
left the services in 1986 to return the original documents of A−62 Mayfair Garden."
Cross−examination of PW2 on 20.05.2014 "It   is   correct   that   all   the   original   documents   of  
the   suit   property   had always been in possession and custody of defendant no. 1. It is correct
that from year 1981 to 1986  I never asked defendant no. 1 to hand over
the original documents of the suit property to the company or to me."Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 101 of 161 8.7.
It is argued that the last line quoted above establishes that
the documents were in the possession of defendant no. 1 and his wife
(defendant no. 2) in their own individual capacities as the owners of the
suit property without any concern of the plaintiffs.
8.8. It   is   also   argued   that   no   request,   whatsoever,   was   ever
made by the plaintiffs as alleged, nor was there any reason to make any
such request. It is argued that in any case, if defendant no. 1 had done
any fraud as alleged by the plaintiffs, then there was no reason for the
defendant no. 1 to give photocopies of the documents to the plaintiffs.
This was also admitted by the plaintiff no. 2 in cross−examination. It is
argued that the plaintiffs have claimed that the name of defendant no. 2 was   added  fraudulently  
by   defendant   no.   1   in  1982,   but   in   the  cross−
examinations of PW1 Sanjay Sharma and PW2 himself have admitted that   the   original  
documents   are   in   the   name   of   defendant   no.   1   and
defendant no. 2 since beginning. It is further argued that apart from the admission   of   the  
plaintiffs,   the   defendants   have   also   produced   the
documents executed in year 1981 including Will and Power of Attorney,
which are registered documents which clearly show that the buyers in
the agreement duly executed in year 1981 were both defendant no(s). 1 and 2.
8.9. Ld. Senior Counsel further argued that the defendants have
categorically stated that the amount of Rs.8.0 lacs was paid by defendant
No. 1 from his account in the Company and was debited to him in the Bhartia Cutler Hammer Ltd. &
anr v. P.D. Agarwal & ors Page no. 102 of 161 books   of   the   Company.   This   was   confirmed   by  
the   letter   Ex.   PW2/A issued by the Company which fact has been admitted by PW−2 i.e. O. P.
Bhartia on 20.05.2014.
Cross of PW2 on 20.05.2014 "I recognize the signature of Chief Account Officer Mr. Chandna on the
letter dated 1.06.1982 and the same has been issued on the letter head of
my company which is exhibited as Ex. PW2/A. It is correct that this letter
was issued by our company but it must have been issued at the instance of the defendant no. 1."
8.10. It has been stressed that no accounts have been produced by
the plaintiffs to prove their allegations. On the contrary, when PW1 Sh.
Sanjay Sharma was asked in his cross−examination, he categorically said
that there was a voucher which was prepared for the amount of Rs. 8.0
lacs and that he had definitely seen the voucher.
Cross of Sanjay Sharma on 16.08.2011
"It is correct that in the year 1981 I was neither employed by the plaintiff
company nor I had any connection with the same. I can say that I had seen  the  records  as I have 
seen  the  voucher  of the  company. I  am  notBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

stating so on the basis of Ex. PW 1/3 (mentioned as Ex. PW1/20 in my
affidavit) but on the basis of the voucher which is there in the company's account.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 103 of 161 It   is   correct   that   in  
Ex.   PW   1/3   (mentioned   as   Ex.   PW   1/20   in   my
affidavit) which is the statement of Canara Bank there is no mention of Mrs. C.A. Hiranandani.
It is incorrect to suggest that I have not seen any such voucher in the
records of the company. It is incorrect to suggest that no such voucher has
been placed on record. (At this stage after going through the court records,
the witness has stated that there is no such voucher on the court record.)"
Based on the above, it was argued that the plaintiffs have
intentionally withheld this vital voucher, which obviously goes to prove
that the payment was made on behalf of defendant no. 1 out of salary
compensation due to him. 
8.11. Ld. Senior counsel further argued that defendant no. 1 has
categorically denied his involvement in accounts. None of the documents
placed on record by the plaintiffs show any involvement of defendant no.
1 in accounting matters. Two certificates issued to auditors and signed
by defendant no. 1 being a senior employee is being used by the plaintiffs to  
somehow   show   some   involvement   of   defendant   no.   1   in   financial
matters. The defendants had filed an IA no. 8743 of 1991 requesting for
disclosure of all certificates issued to the auditors commencing from the year   1973.  
Inspite   of   the   application   filed   by   the   defendants,   the
plaintiffs did not file the records which were obviously in possession of the   plaintiffs.
 There   are   other   letters   produced   by   the   plaintiffs   and Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 104 of 161
almost all of them are addressed to RBI and Bank for release of foreign
exchange for the purpose of technical foreign collaboration which was his
area of work. If defendant no. 1 was actually looking after accounts of the company,  
the   plaintiffs   would   have   hundreds   if   not   thousands   of documents  
written/signed   by   defendant   no.   1   in   the   course   of   his
employment of more than 12 years to show that he was actually looking
after accounts. And yet, the plaintiffs could not produce any document to
prove involvement of defendant no. 1 in accounts. It is further argued
that plaintiffs were also requested for disclosure of all annual returns/
annual reports from the year 1973 to 1986 and all the certificates issued
to the auditors commencing from year 1973 but defendants did not file
the records and the only reason for not producing was that they show that   payment  
was   made   on   behalf   of   defendant   no.   1   out   of   salary
compensation due to the defendant no. 1. Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

8.12. Ld.   Senior   Counsel   further   argued   that    there   was   no admission  as  
alleged   and   the   point−wise   rebuttal   in   this   regard   is   as under:
(a) Para   7   of   written   statement   (hereinafter   referred   to   as   WS)
denies the contents of para 7 of the plaint and states at the outset that,  "The  
contents   of   para   7   as   stated   are   wrong,   incorrect   and denied."  The  
defendants   have   nowhere   admitted   that   the   initial
advance was made by the Company account or that any transaction
was for the benefit of the Company. The plaintiff merely presumed the
story of J. K. Malhotra and Vijay Dhawan as stated in para 10 of the Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 105 of 161 plaint   itself,   and  
para   11   of   affidavit   of   P2.   No   basis   for   this presumption   has   been   stated  
anywhere   in   the   pleadings.   Even   the
address mentioned in the letter is not that of the suit property.  In any
case, para 8 of the Written Statement clearly says "The allegation in
para 8 that in early June, 1981 or on any other date the defendant No.
1 made any representation to plaintiff No. 2 regarding the purchase of
the lease hold land in May Fair Garden is totally denied. The correct
facts have already been given in para 7 above. Again the allegation
that defendant No. 1 represented that one Mr. Malhotra entered into a
transaction in respect of the said plot is also wrong and denied. The
allegation that the Estate Agent had represented to Defendant No. 1
that the transaction could be switched over if Mr. Malhotra was paid
the amount invested by him is not correct as stated."    
(b) There was no admission about the fact that the defendant was
holding senior and confidential position. It was argued that Defendant
1 was a senior employee of the Company as other senior employees.
There is no question of 'confidential' in this.
(c)     There was no admission and the denial of para 10 of Plaint is
clear in para 10 of the WS which states that  The allegations in para 10   are   not   correct   and  
denied...   In   particular   it   is   denied   that
defendant No.1 represented to plaintiffs that the defendant No.1 would
have the agreements for acquiring the said plot of land or for raising construction   thereon   as   a  
trustee   for   plaintiffs   is   wholly   wrong   and Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal &
ors Page no. 106 of 161 denied.   The   question   of   defendant   No.1   having   represented   to   the
plaintiff that the transactions would have to be in the name of some
individual did not arise .... There was no declaration at any stage by
the Plaintiffs either expressly or impliedly of the intention that the said
suit property was to be held in trust or that the defendant No. 1 ever
agreed either expressly or impliedly to receive the suit property as a trust."Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

As regards membership of the cosmopolitan Society could be
given only to individuals, WS para 10 clearly states that, "the answering
defendants crave leave to refer to the provisions of the lease deed and the
bye laws in this connection at the time of hearing, if necessary."  In any
case, it is a matter of law and there cannot be any estoppel against law.
Reply   to   para   10   in   WS   is   clear   and   states   that,  "The
Plaintiff is put to strict proof in respect of the allegations made in para under  reply. As 
already mentioned  above  the said  suit property, right, title   or   interest   in   respect   thereof   got  
transferred   in   favour   of   the defendant   no.   1/defendant   no.2   directly   from   the   owner  
Mrs. Hiranandani / defendant no.4."
(d) It has been argued that there was denial to the story of J.K.
Malhotra and even plaintiff have made presumptions in paragraph 10
and 11 of the plaint. The purported letter is merely a photocopy and
Defendant 1 has already said that it is a sham document and he was
not even a signatory to the document. If it were a genuine letter, then
the plaintiffs would surely have called Dhawan and so−called Malhotra Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 107 of 161
to the witness box to prove the document. Even the address mentioned
in the letter is not that of the suit property. In fact, the said photocopy
of letter was never on court record when the written statement was
filed so the question of denial of the letter at that time does not arise.
In any case, para 8 of the Written Statement clearly says "Again the allegation   that   defendant   No.
  1   represented   that   one   Mr.   Malhotra
entered into a transaction in respect of the said plot is also wrong and denied."
(e) Para 12 of the written statement states that Defendant 1 could not   operate  the  bank   account  
solely.   He  could   do  so  only   jointly   in conjunction   with   another   person   i.e.   Chief  
Accountant   /   Company Secretary. This fact does not support the plea of the plaintiffs at all, on the
  contrary,   it   shows   that   there   was   no   'utmost   trust'   placed   on
defendant no. 1 as regards money matters. If there was 'utmost trust' on defendant   no.  1, then 
he would not   need signatures  of  company
secretary or chief accountant to operate the bank account. As regards payment of Rs. 8,00,000/−
, the defendants have clearly stated in the
Written Statement para 12 that, "It is wrong to allege that payment
was for and on behalf of the plaintiffs. The allegation that the amount
was debited to the capital account under the directions of defendant
no.1 is neither correct nor borne out from any material on record."
(f) It has been argued that defendant no. 1 has nowhere admitted that the   construction   on   the  
plot   was   commenced   by   utilizing   funds   of Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal
& ors Page no. 108 of 161 plaintiff 1. The defendant no. 1 has specifically stated that the money
spent on construction was spent by defendant no. 1 & defendant no. 2Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

for their own residence in paragraphs as follows:−  Para 14 of Written Statement "As already 
mentioned  above  the right, title or  interest in the said land   stood   transferred   in   favour   of   the
  defendant   no.   1   and   the defendant no. 2 and therefore the construction which was got done on
the said plot of land was out of expenses incurred by defendant nos. 1
to 3 as per arrangement interse for use as residence of defendant nos. 1 and 2."
Para 9 of the Written Statement
"Construction work on the said plot of land was got done, costs borne
by the defendant nos. 1 to 3 as per agreement interse for residence of defendant Nos. 1 and 2."
Para 15 of the Written Statement
"With reference to para 15 the allegation that defendant no. 1 utilized
the funds of the plaintiff no.1 is totally misconceived and incorrect.
The allegation that the various expenditure in relation to the work of
construction undertaken on the said plot was on behalf of plaintiff
no.1 is also wrong, incorrect and denied."
Para 16 of the Written Statement "The   allegation   that   enormous   funds   or   resources   for   the  
plaintiff were utilized for the purpose of raising the construction is also wrong, Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 109 of 161 misleading and as such denied."
It  has  been  argued  by Ld.  Senior  Counsel  for  the defendants
that in the second part of para 14, it was stated that defendant no. 1
had taken some advance from plaintiff no. 1 which had been used for
the purpose of construction but nowhere it was admitted that amounts were  spent  by   the   plaintiff
  no.   1.   Taking   some   advance   from   the
company to be used for construction of his own house is a very normal
thing for an employee. In any case, it was for the company to show
their accounts to prove what amounts have been allegedly spent by them.   If  this   was   admission  
by  the   defendants,   then   what   was   the need   for   the   plaintiffs   to   dispute   the   said  
statement   in   their replication   para   16   by   saying,  "Plaintiff   no.   1  did   not   advance  to
defendant no. 1 amount spent on constructions pursuant to any alleged
agreement or understanding as alleged but rather incurred/caused to
be incurred and/or involved in incurring such expenses".  It is for the plaintiff   to   show   their  
accounts   to   prove   what   amounts   have   been allegedly spent by them.
 (g) It is further argued that para 16 of the WS clearly states that
the payment of Rs.8.0 lacs was from his account in the Company and
therefore it was obviously defendant no. 1's money. Further, para 17 of WS   relates   to   the  
allegation   regarding   amounts   allegedly   spent   on construction.   Defendant   no.   1   has   stated
  that   the   allegation   that various   amounts   were   spent   by   the   company   on   construction  
and Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 110 of 161
entered in to the Company's books as 'advance for capital assets' is not
admitted. Defendant no. 1 has not admitted anywhere the existence orBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

validity of entries in the books  of accounts  of plaintiff n. 1. On the
contrary, he has stated that the alleged entries are sham. 
Para 17 of Written Statement "The   defendant   no.1   was   in   no   way   concerned   nor   gave   any
instructions   regarding   accounting   entries,   which   were   carried   out
entirely under the supervision of plaintiff no.2 without in any manner effecting   or   creating   any  
change   in   regard   to   the   rights,   title   or
interest of defendant no.1 or defendant no.2 over the said plot and building."
Further, in the same para it is stated as follows:
Para 17 of Written Statement
"These entries are sham and neither in law or in fact can alter or
change the true nature of the transaction as between the Plaintiff and
Defendants 1 and 2 as explained above. The Plaintiffs were and still
are in possession of all books and other records and the answering Defendants   put  
the   Plaintiffs   to   strict   proof   in   respect   of   the
allegations made in the paragraph under reply."
(k) In several para no. 14, 9, 15 and 16 of the Written Statement it
has been specifically stated that the money spent on construction was
spent by defendant no(s). 1 & 2 for their own residence. In para 19A, defendant   no.  
1   has   stated   that   defendant   no.   1   had   taken   some Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 111 of 161 advance  from   plaintiff   no.   1  
which   had   he   used   for   the   purpose   of
construction. The defendant no. 1 has nowhere admitted that amounts were   spent  
by   plaintiff   no.   1.   If   this   was   an   admission   by   the
defendants, then what was the need for the plaintiffs to dispute the said   statement  
in   their   replication   as   also   in   para   16   by   saying, "Plaintiff no. 1
 did not advance  to defendant no. 1 amount  spent  on
constructions pursuant to any alleged agreement or understanding as
alleged but rather incurred/caused to be incurred and/or involved in
incurring such expenses".   It is argued that it is for the company to
show their accounts to prove what amounts have been allegedly spent by them.
 (l) It is further argued that there was no acknowledgement and the denial   in   para  
26   of   the   written   statement   is   absolutely   clear.     By
referring to the following, it was argued that to term it as any kind of
admission is absurd.
Para 26 of the WS "Contents   of   para   26   as   stated   are   wrong   and   denied.   As   already
mentioned above, pursuant to the agreement/understanding, part of
the moneys towards the purchase of the said property were advanced by   the   plaintiff   No.1  
towards   adjustment   /discharge   of   debt   ofBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

plaintiff No.1 due to defendant No.1 and remaining part of the funds
towards construction on the said plot of land were arranged by the answering defendants."
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 112 of 161
(m) Refuting the admission of issue of certificates by the defendant
it was stated that denial in para 30 was absolutely clear.
Para 30 of Written Statement "In particular, it is denied that the defendant No. 1 provided to the
Auditors   the   over−all   certificates   concerning   the   correctness   of   the
accounts or the defendant No. 1 was responsible for various entries as   alleged.   The   Chief  
Accountant   and   Company   Secretary   were responsible   for   the   preparation   of   the   accounts
  within   the   overall purview of plaintiff no.2 and the certificates required from Defendant No.1  
under   directions   of   plaintiff   Nno.2   of   routine   nature   were furnished."
(n) Para 44 of the written statement states that after leaving the services   of   the   company,   a  
certificate   regarding   the   integrity   of
defendant no. 1 was issued by the brother of plaintiff no. 2, thereby
showing that there was obviously no wrongdoing by defendant no. 1 as
alleged during his employment with plaintiff no. 1.
(o) It   is   further   argued   that   defendants   have   nowhere   admitted payment   of   Rs.   19.33  
lakhs   by   the   plaintiffs   to   him.   It   has   been
clarified that what is stated in said para is as per legal advice and that
too only by way of alternate pleading without prejudice to the fact that defendant   no(s).   1   &   2  
are   rightful   owners   of   the   property   and attention   is   drawn   to   the   said   paragraph   which
  is   reproduced   as Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 113 of 161
under:− "Without   prejudice   to   the   aforesaid   statements   of   the   answering defendants   and  
by   way   of   alternative   pleading,   the   answering
Defendants state that if this Hon'ble Court comes to a conclusion that
the Agreement as pleaded by defendant no.1 is legally or otherwise
not tenable and the pleas formed thereon also not tenable, then ...."
It   is   further   argued   that   as   regards   the   amount   of   19.33
lakhs mentioned in this para, it refers to the amounts as alleged to have
been spent by the plaintiffs which reads as :− "....it   is   stated   that   the   advances   made   by   the  
Defendant   No.   1 towards plot of land amounting to Rs. 8 lakhs, towards construction alleged  to  
be   Rs.   11.33   lakhs   the   whole   of   the   said   advances aggregating to Rs. 19.33 lakhs ....".
8.13. Ld.   Senior   Counsel   for   the   defendants   by   referring   to aforesaid   paragraph   of  
written   statement   argued   that   the   defendants
have denied the allegations that amounts were spent by the plaintiffs on
construction at various places in the written statement, in the affidavit of   defendant   no.   1   and  
in   the   cross−   examination   of   defendant   no.   1.Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

Denials in the written statement are absolutely clear and categorical and
further argued that it is settled law that admissions have to be clear and
unequivocal in order to relieve the other party of burden of proof and
relied upon judgments as follows:− Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page
no. 114 of 161  Joshna   Gouda   Vs.   Brundaban   Gouda   &   ANR.   -
MANU/SC/0083/2012     Rachakonda Venkat Rao & Ors. Vs. R. Satya Bai (D0 By Lrs. &
Anr. - MANU/SC/0702/2003 8.14. It is further argued by Ld. Senior Counsel for defendants that  
on   one   hand,   the   plaintiffs'   case   is   that   the   property   belongs   to
them, on the other hand, the plaintiffs have submitted no document at
all to prove the ownership of the suit property. Not a single document
has been produced in support of their claim by documentary evidence or
by oral evidence. They have simply stated in their arguments that their
allegations have been admitted by the defendants. These statements by the plaintiffs  are  without 
any substance. There  is  heavy  burden upon
them to prove the same. If the defence put forth in the written statement
is disputed / challenged by the plaintiffs vide their replication, then it is
for the plaintiffs to prove the same.
8.15.   Ld. Senior Counsel for the defendants further argued that the defendants  have clearly  stated 
that the broker for the transaction was Mr. Gyan Bhatnagar and a payment of Rs.15,000/−
 was made to him for his services by defendant no(s). 1 & 2 and receipt is Ex. DW1/4 which the  
plaintiffs   have   not   been   able   to   disprove.   The   plaintiffs   have   not
made any payment to any broker for the suit property as the plaintiffs have  nothing to do  with 
the property. The plaintiffs  have  concocted  a
false story involving one estate agent M/s Vijay Dhawan & Company and
one Mr. J. K. Malhotra. No credible proof in the form of any document or Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 115 of 161
witness has been placed on record by the plaintiffs to support this plea.
The fact is that Vijay Dhawan & Company was not connected with the
suit property. Neither J. K. Malhotra nor Vijay Dhawan & Company was
called as witness for evidence. No proof has been given by the plaintiffs
for payment of Rs.1.0 lacs as alleged to have been made by them to one
Mr. J. K. Malhotra. No account books have been produced in respect of
the alleged payment of Rs. 1.0 lacs. On the other hand, defendant no. 1 has 
made it clear that neither Vijay Dhawan & Co. nor J. K. Malhotra
had anything to do with the transaction which was exclusively between
defendant no. 1 & 2 on one hand and the seller Mrs. C. A. Hiranandani
on the other hand. No reliance can be placed upon document Ex. PW2/19 (photocopy)   because  
the   plaintiffs   themselves   state   that   it   is   their presumption 
that this J. K. Malhotra was in touch with Vijay Dhawan
and that Vijay Dhawan was in touch with the seller of the property. The
letter is a photocopy which cannot be read in evidence. Existence of the
original of this letter has also not been stated anywhere in the pleadings.Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

This letter does not bear the signature of defendant no. 1 and has been
denied by defendant no. 1. The letter does not mention the address of the
property. Furthermore, neither J. K. Malhotra nor Vijay Dhawan was
called as witness to vouch for the letter. 
8.16. Ld.   Senior   Counsel   for   defendants   further   argued   that
plaintiff no. 1 being a corporate entity, the conduct of affairs of plaintiff
no. 1 was done in writing, yet, not a single document has been produced
by the plaintiffs in regard to the suit property; no Board Resolution to Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 116 of 161
buy the property; no Board Resolution to buy in name of defendant no. 1 &   2;   no   Special  
Resolution   as   was   mandatory   vide   the   Articles   of
Association of the Company; no Power of Attorney to defendant no. 1 & 2
to buy the property; no Correspondence with the seller of the property; no  agreement  with  respect
 to the alleged trust; no  document   showing license   to   defendant   no.   1   to   stay;   no   books   of
  accounts;     no   annual reports; no appointment letter of defendant no. 1; no notice to defendants
asking for possession of property or for title documents and no auditors
remarks regarding the suit property has been filed by the plaintiffs. It is further   argued   that  
plaintiffs   have   filed   extract   of   Board   Resolutions approving   the   accounts   of   company  
duly   signed   by   plaintiff   no.   2   but
these resolutions have no relevance because the plaintiff has withheld
the board resolutions for the year in which the propery was purchased. This   was   obviously  
withheld   by   plaintiff   no.   1   because   the   board resolution   approving   the   accounts   for   the  
relevant   year   (year   ending 1982) did not show the suit property as a fixed asset of the company.
There is no avernment made by the plaintiffs that the suit property was
declared in the Income Tax return of plaintiff no. 1.  It is further argued
that defendant no. 1 has clearly stated that there was an oral agreement arrived   at   in  1973  
between   defendant   no.   1  and  plaintiff  no.   1  before
joining the company for the second time according to which defendant no.
1 was to get 5% of profits in addition to normal salary and statement of
the plaintiffs have been extremely vague and even though the plaintiffs
claimed that all employees were issued appointment letters but did not
produce any appointment letter of defendant no. 1. It is further argued Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 117 of 161
that the defendnat no. 1 and 2 have been paying property taxes, ground rent,   electricity   charges  
and  MTNL  charges   since  the  purchase  of  the property till today. 
8.17. It is further argued that the fact  that defendant no. 2 is a co−
owner of the suit property, that itself demolishes the benami claim of
the plaintiffs ab initio. If, according to the plaintiffs there was any fraud
done by defendant no. 1, even then no police complaint or any complaint under   section   630   of  
the   Companies   Act,   1956   was   ever   lodged   by
plaintiff against the defendants. The plaintiffs have not examined vendor
M/s Hiranandani and the broker and the Auditors and the Registrar andBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

the Society and any other person as witness in order to prove the fraud. 
8.18. It is further argued that in the present case the plaint was filed   on   08.01.1988,   the   deficit  
court−fees   was   paid   on   23.07.1988 whereafter   after   removing   other   objections   on  
05.08.1988,   the   matter was listed in the Court on 16.08.1988 and summons were issued to the
defendants.   Since   the   deficit   court−fee   has   been   paid   on   23.07.1988, therefore   the   plaint
  has   to   be   deemed   to   be   instituted   on   23.07.1988
which is subsequent to the coming into force of Act, 1988 and therefore, the   governing   law   for  
the   matter   in   issue   would   be   of   Act,   1988.   Ld. Senior   Counsel   for   defendants   argued  
that   there   cannot   be   deemed automatic condonation of delay in payment of court−
fee and no deemed relate back of the date of payment and the date on which proper court−fee
was paid will be the date of institution of the suit in the absence of any Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 118 of 161 order   of   condonation   of   delay.   Ld.   Counsel  
for  the   defendant   placed reliance upon judgments:
     D. Mohan Vs. Mr. N. Kuppan (MANU/TN/8169/2007 ) ,
           K.T.   Holidays   Pvt   Ltd.   Vs.   Japan   International    Co−operation
            Agency (MANU/DE /3258/2014), 
           K. Dhanavelu Vs. K. S. M. Venugopal (MANU/TN/1655/2016 ), 
           Mohd.   Yunus   &   Anr.   Vs.   Sugra   Begum   &   Ors.   (MANU/
            AP/0108/1954) ,
           Natarajan Vs. Jacob Manohar (MANU/TN/1520/2014),
           Gopalasamy P. M. Vs. C. Senpagam  (2007 (5) CTC 283), 
           S. A. Khadeer Vs. G. V. R. Anjaneyulu  (2003 SCC Online AP 587),
           Buta   Singh   (Dead)   By   L.Rs   Vs.   Union   Of   India    (AIR   1995   SC
            1945),
           Tayal Paper Traders & Ors. Vs. Subhash Chand (RSA  38/2008
            decided on July 1, 2010),
           J. L. Gugnani Vs. M/s Krishna Estate & Ors. (184 (2011) DLT
            410), 
           Patcha   Mahendra   Vs.   Koduru   Penchalaiah   (MANU/AP/
            0248/2005)
8.19. Ld. Senior Counsel for the defendants further argued that
plaintiffs in the present case are claiming title of suit property only on
the basis of their claim that payment consideration for purchase of suit property   was   sent   from  
their   bank   account   whereas   it   has   been
established on record that the said payment was made out of defendant's
account with the company.  As per Benami Transaction (Prohibition Act,
1988), Benami transaction means any transaction in which the property is   transferred   to   one  
person   for   a   consideration   paid  and   provided   by another person. 
 Whether a particular sale is benami or not, is largely
one of the facts and for determining this question no absolute formula or Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 119 of 161
acid test, uniformly applicable in all situations can be laid down yet inBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

weighing the probabilities and for gathering relevant indicia, the Courts
are usually guided by six golden principles i.e. the source from where the purchase   money   came,  
the   nature   and   possession   of   property   after
purchase; motive, in any, for giving the transaction a benami color; the
position of parties and the relationship, if any, between the claimant and another  benamidaar;  
the custody  of  title  deeds  after  the  sale  and  the
conduct of parties concerned in dealing with the property after the sale.
Ld. Senior Counsel for defendants argued that the facts of the present case   can   be   tested   on  
these   principles.   In   the   present   case   puchase consideration  was   paid   by   defendant   no.   1
  out   of   his   account   from
plaintiff no. 1. Plaintiffs have also not produced any books of accounts /
vouchers / documents whatsoever to show the accounting entry of Rs.8.0
lacs. Inspite of the fact that the defendants asked for the Annual Reports
/ Returns vide an IA No. 8743 of 1991 filed in Court, plaintiffs chose not
to disclose the accounts. Payment for purchase of land in a Company will definitely be 
recorded in many books  of accounts  of the  Company viz. Bank   Book,   Ledger,   Fixed   Assets  
Register,   Minute   Book   of   Board Meetings, Auditors
 Reports, Annual Reports, Income Tax Returns. All
these books are in the possession of the plaintiffs, yet, not a single book
has been placed on record of the Court. It proves that the books do not
show the property belonging to the Company.  Plaintiff No. 2 was asked
in his cross if the suit property purchased in the name of defendant no. 1
and 2 was ever disclosed in the books of the Company, to which he says 'I am   not   aware'.  
Therefore,   it   is   clear   that   the   books   do   not   show   the Bhartia Cutler Hammer Ltd. & anr v.
P.D. Agarwal & ors Page no. 120 of 161
property belonging to plaintiff no. 1 whereas the defendants have placed
on record the original letter Ex. PW2/A issued by the plaintiff company
which has been admitted by PW2 in his cross examination.  Ex.  PW2/A
only states that the amount of Rs.8.0 lacs will be debited to defendant no.
1. When PW2 was asked in his cross examination, he says two times that
he does not know if it was debited to defendant no. 1 or not. Further PW1 Sanjay   Sharma  
categorically   stated   that   there   is   a   voucher   for   the
payment of Rs. 8.0 lacs in the accounts of the Company and that he had
seen the voucher. Yet, no such voucher was ever produced in the Court by   the  plaintiffs.     No 
board  resolution  for   passing   of  accounts  for   the
relevant year has been placed on record even though similar resolutions for   future   years   have  
been   placed   on   record   by   the   plaintiffs.   These
resolutions show purchase of individual fixed assets separately. Purchase of   land   costing   over  
Rs.   1.0   lacs   was   prohibited   by   the   Articles   of
Association of the Company without a special resolution approving the
same. No such resolution was ever taken by the Company and nothing
has been placed on record. In fact, the plaintiffs tried to hide the fact that
there was a bar in the Articles of the Company by avoiding to submit theBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

articles as they existed in 1981 inspite of Court order to do so.  No board resolution   or   power   of  
attorney   or   any   document   has   been   placed   on
Court record to show that defendants were authorized by the Company to   purchase   the   suit  
property   on   their   behalf.   There   is   not   even   an
averment with regard to creation of any such document. Defendants did
an elaborate Griha Pravesh ceremony, video of which has been placed on
record. The Griha Pravesh ceremony was undertaken by the defendant Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 121 of 161
no. 1 and his wife which was attended by plaintiffs as guests - a fact has
been admitted by plaintiff no. 2 in his cross examination. It is further argued   that   possession  of  
the   property   was   never   asked   for   by   the
plaintiffs. Even though the plaintiffs claim that defendant no. 1 was fired
from his job in 1986, yet possession of the property was never asked for. In   fact,   possession   of  
the   property   was   asked   for   only   by   way   of   an
amendment in the suit in 1993 i.e. 7 years after defendant no. 1 resigned.
The documents relating to the property are in the favour of defendant no. 1   and   2   and   also   in  
the   favour   of   brothers   and   brother−in−law   of defendant   no.   1.   Plaintiffs   have   neither  
pleaded   nor   produced   any evidence of paying property taxes, ground rent, electricity charges and
telephone bills with regard to the suit property.
8.20. It is next argued that plaintiff  no. 2 was well aware of the
said letter Ex. PW2/A. The said letter was filed in the Court in the year 2005,   however   the  
plaintiffs   did   not   challenge   the   said   letter   in   any manner   whatsoever   in  the  last   12  
years   of   the   proceedings.  Plaintiffs
have not raised any question about the authenticity of the letter at any
point of time, not even in his cross−examination in the year 2014. It is not
the case of the plaintiffs that the letterhead of Ex. PW2/A is not of the
Company. It is also not the case of the plaintiffs that the communication numbers   are   not   of   the
  Company.   They   are   now   merely   building   a baseless   ground   that   the   letterhead,   though  
of   the   company,   was discontinued in the year 1980. No proof in this regard had been given by
the plaintiffs. Although the plaintiffs say that it is a matter of record, Bhartia Cutler Hammer Ltd. &
anr v. P.D. Agarwal & ors Page no. 122 of 161
yet, there is nothing on record which evidences that the said letterhead
was discontinued and scrapped in the year 1980 as alleged. There is no record   or   evidence   to  
show   that   the   old   stationary   was   scrapped   as
alleged or at all. There was no such practice of scrapping stationary as alleged   in   the   Company.  
No   such   practice   is   ever   heard   of   in   any
Company, rather existing stocks of stationary are always used. In fact, plaintiff   No.   1   used   to  
have   different   letterheads   for   head   office, registered   office,   branch   office,   factory,  
departments   etc.   at   the   same time. Such a practice is also generally prevalent in all Companies.
8.21. It is next argued by Ld. Senior Counsel for defendants that plaintiffs  have   neve   pleaded   the
  motive   categorically   in   the   plaint
because this was never a transaction for or by the plaintiffs. During theBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

final arguments, the plaintiffs have argued that the property was bought
benami because the Cooperative Society did not allow the property to be
bought in the name of the Company but  there was no bar on Companies
to buy the suit property. Co−operative Society Rules allowed Companies
to buy leasehold properties. So there could be no motive. Even otherwise,
the company could have bought some other freehold property. It could
have bought the property in the name of plaintiff no. 2 i.e. O. P. Bhartia
or in the name of his wife or in the name of any other Director of the
Company. There was no need to buy the property in the name of the wife of  defendant   no.  1   and 
Powers   of  Attorney  to  be  in  the names   of the brothers   and  brothers−in−law   of  defendant  
no.   1.  If   the   motive   was   to circumvent the Co−
operative Societies Act, then in any case an action to Bhartia Cutler Hammer Ltd. & anr v. P.D.
Agarwal & ors Page no. 123 of 161 circumvent   any   law   would   by   itself   be   void   and   the  
property   cannot belong   to   the   Company   in   that   case.   If   the   motive   was   to   have   a
temporary arrangement of benami which would later be made over to the Company,   then   the  
question   is   −   how   could   it   be   made   over   to   the
Company at a later stage if it was not allowed as per law? It is further argued   that  Company's  Act,  
1956   did   not   allow   investment   of   the
Company to be made in the name of another person. It is not a normal
transaction. This transaction was also not allowed as per the Articles of
Association of the Company without approval by the shareholders in a shareholders meeting.
8.22. Ld. Senior counsel for defendants further argued that why
would a Company buy a property in the name of an employee and his wife?Defendant   no.  2   is  
the   wife   of   defendant   no.   1   who   had   no
connection whatsoever with plaintiff no. 1.  It is further argued that all
documents for transfer of all rights, title and interest in the said plot are
exclusively in favour of defendant no. 1 and his wife defendant no. 2 and
custody is with defendant no. 1 & 2 since beginning and  there are no
documents in the name of the plaintiffs that have been admitted by the plaintiffs   in   their   cross  
examinations   on   06.04.2011,   16.08.2011, 02.05.2013   and   20.05.2013.   It   is   further   argued  
that   no   demand   for handing over possession of the title documents  was  ever made by the
plaintiffs. This makes it clear that the custody of title documents was with   defendant   no.   1   &   2  
in   their   personal   capacity   as   owners.   It   is
further argued that defendant no. 1 & 2 have been exercising all rights Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 124 of 161
as owners over the property since the beginning including constructing
the house and exclusively living in it. Construction of a house on the suit
property was done exclusively by the Defendants using their own funds. More   than   250   bills   /  
challans   etc.   in   support   of  the   same   have   been
placed on record. All Property Taxes, Ground Rent, Dues of Cooperative Society   since   the  
beginning   were   paid   by   the   Defendants.   Bills   and correspondence   with   DDA,   MCD,  
DESU,   Cooperative   Housing   Society
etc. has also been placed on record by the defendants as evidence of the same.Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

8.23. Ld. Senior Counsel for defendants further argued that the suit   is   barred   by   Section   281A  
of   Income   Tax   Act   in   the   alternative.
There can be only one date of institution of suit. In case that  date is
taken to be 08.1.1988, then the suit is hit was Section 281 A of Income
Tax Act and in case that date is taken to be 23.07.1988, then the suit is hit   by   Benami   Act.  At  
the   time   of   filing   of   the   written   statement,
defendants could not have assumed both dates as the date of institution
of suit. Taking the date of institution as July 23, 1988 (under bonafide
belief, the defendants raised the objection of Benami Act in para (E) of the   written   statement.
 Had   the   Plaintiffs   disputed   the   preliminary
objection of para (E) in the replication filed by them, defendants would
have raised the objection of 281A at that stage itself,  therefore, plaintiffs argument   that   no  
specific   objection   was   raised   by   the   defendants   as regards   281A  is  totally misconceived.
 The present   suit  is  governed  by
281A as it existed in 1988, that is, after its amendment in 1984. After the Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 125 of 161
amendment, 281A allowed only a window of one year ending on March 1, 1985   for   all   past  
benami   transactions   to   be   disclosed   in   a   prescribed
format, after which the right to sue in respect of benami properties would
stand forfeited. Therefore, in 1988 when the present suit was filed, the
time limit of one year was already over and there is no way the plaintiffs
could comply with the provisions of 281A unless notice to the Income Tax
had been given before March 1, 1985.   As regards the factum whether
any notice was given under 281A to Income Tax, plaintiff no. 2 was asked the   same   in   his   cross  
examination   and   he   said   he   doesn't   know. Therefore,   since   no   notice   was   given   by   the
  plaintiffs   to   Income   Tax before March 1, 1985, there was no way the plaintiffs could ever comply
with the requirements as laid down in 281A in the year 1988 or on any
date in future. Explanatory Note to the  Finance Act,  1984  makes  the intent   of   the   Legislature  
very   clear.   Ld.   Senior   Counsel   for   the defendants relied upon judgments as follows:
 Jaya   Karmakar   Alais   Jabida   Hossain   Vs.   Ajmal   Hossain
(MANU/WB/0397/2004) 
Vijoy Kumar Sanan Vs. Gurdayal Chand Sunda (1989) 177 ITR 8.24.
Further, Ld. Sr. Counsel for defendant argued that it was
mandatory vide the Articles of Association to pass a Special Resolution to purchase  
the   suit   property.   Nevertheless,   defendants   have   not challenged   the  
maintainability   of   the   suit   on   this   ground   but   if   the
property belonged to the plaintiffs as alleged, then the company would have   taken   a
  Board   Resolution   in   compliance   of   the   Articles   of Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 126 of 161
Association and filed the same with the Registrar of Companies as was
compulsory for a corporate entity. In support of the above, Plaintiffs have
quoted a purported Board Resolution which has not been submitted in
Court at any time. The purported Board Resolution is dated 22.11.1983Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

approving accounts of the Company for the Financial Year 1982−83 and
has been quoted by the plaintiffs in their arguments. This alleged entry
of Rs.11,74,846.72 is not relatable to the suit property at all. By the time
the suit was filed, balance sheets of the relevant years were already filed
with the Registrar of Companies. It seems that they found an entry of Rs.11,74,846.72
  in   FY1982−83   under   the   head   "Building   under construction   (others)"   which
  was   the   amount   spent   on   construction   of various   other   buildings   of   the  
Company   during   the   year.   In   order   to complete   their   case,   plaintiffs   used  
the   difference   amount   i.e. 11,74,846.72   -   8,02,200   =   3,72,645.72,   claiming  
it   to   be   spent   on
construction of the suit property. That is the reason why no document
whatsoever has been produced in respect of the amount of Rs.3,72,645.72
claimed to have been spent on construction and no details regarding the
same has been given or pleaded by the plaintiffs till date.
8.25. Ld. Senior counsel for defendants further argued that the suit    is   barred   by  
limitation.   As   per   Article   59   of   Limitation   Act, limitation   period   in   the  
present   case   will   be   3   years.   Plaintiffs   have
claimed that the name of defendant no. 2 as owner in the title documents
is on account of fraud. In such a case, plaintiffs should have prayed for
voiding of the title documents which stand in its way and that should Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 127 of 161 have   been   done  
within   a   period   of   3   years   of   their   knowledge   as   per
Article 59 of the Limitation Act. Date of knowledge of the alleged fraud
will be the date when the documents were executed i.e. Nov 25, 1981. If the  
plaintiffs'   claim   is   said   to   be   true,   then   it   is   not   possible   that   a
Company would not have knowledge of the ownership of the property for
5 years, because plaintiff no. 2   himself says in his cross−examination
stated that the title documents are also in the name of defendant no. 2
since beginning. Plaintiff no. 2 himself would have seen the documents.
Plaintiff no. 2 and his wife attended the house warming ceremony, so they   would   definitely   know
  about   the   ownership   of   the   property. Auditors   would   have   checked   the   title   deeds   as  
per   the   auditing standards.   Accountants   would   have   checked   the   receipts   &   other
documents.   Accountants,   other   managers   and   auditors   would   have
checked the receipt & other documents pertaining to construction and
various sanctions and approvals. Since the Power of Attorney and Will
are registered documents, they will in any case be taken to be in the deemed   knowledge   of   the  
Plaintiffs.   Ld.   Senior   counsel   for   the defendants relied upon judgment in
 Smt. Dilboo (Dead) by Lrs. & Ors.
Vs. Smt. Dhanraji (Dead) and Ors. (MANU/SC/0564/2000) and further referred to the judgments:
 Becharbhai   Zaverbhai   Patel   and   Anr.   Vs.   Jashbhai   Shivabhai
Patel and Ors. (MANU/GJ/0933/2012) Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

Lydia Agnes Rodriques Nee D'Cunha and Ors. Vs. Joseph Anthony
D'Cunha and Ors. (MANU/MH/1695/2013) 
Masrur Fatema Jafarali Saiyed and Ors. Vs. Vishnubhai Ambalal
Patel and Ors. (MANU/GJ/2748/2016) Bhartia Cutler Hammer Ltd. & anr v. P.D.
Agarwal & ors Page no. 128 of 161  Uma   Vithal   Jhaveri   and   Ors.   Vs.   Nikhil  
Vithal   Jhaveri (MANU/MH/2638/2014)   Mukhinder   Singh   (Deceased)  
Through   L.Rs.   &   Ors.   Vs.   Sh.
Gurbux Singh & Ors. (MANU/DE/0550/2012)
           Md.   Noorul   Hoda   Vs.   Bibi   Raifunnisa   and   Ors.
            (MANU/SC/1414/1996)
8.26. Ld. Senior counsel further argued that the suit as instituted
in 1988 for injunction was converted into a suit for declaration of title
and possession vide order of the Hon'ble Court on 09.04.2001.  However,
when the amendment in suit to include relief of possession was allowed
on 09.04.2001, they were directed to file the amended plaint within 2
weeks. Amended plaint filed on 23.04.2002 i.e. more than 52 weeks after
the court order. Four years later i.e. on 04.05.2006, the Court directed the  Plaintiffs  
to  pay  the  court  fee  within 4  weeks.  The  court   fee was
finally paid on 01.07.2006, which was again 4 weeks after the expiry of
the period allowed by the Court and that too without any application for
condonation of delay. Thus, the date of filing of the amended plaint will
be 01.07.2006 i.e. the date on which the court fee was paid. Since there is
no order for condonation of delay for late payment of Court Fee (there is not   even  
an   application   for   the   same),   it   cannot   relate   back   in   time.
Therefor, the  amendment to include prayer for declaration of title and possession   is   barred   by  
limitation   and   the   suit   without   prayer   for
declaration of title and possession is not maintainable and relied upon judgments:−  
 A. Nawab John & Ors Vs V. N. Subramaniyam (2012) 7 SCC 738  
J. L. Gugnani Vs. M/s Krishna Estate & Ors. (184 (2011) DLT 410) Bhartia Cutler Hammer Ltd. &
anr v. P.D. Agarwal & ors Page no. 129 of 161  K.T.   Holidays   Pvt   Ltd.   Vs.   Japan   International
  Co−operation Agency (MANU/DE /3258/2014)   Mohd.   Yunus   &   Anr.   Vs.   Sugra   Begum   &
  Ors.
(MANU/AP/0108/1954)   Maryadit vs Rameshchandra And Ors. (2007(4)MPHT105)
9. I have heard arguments  advanced by Ld. Counsel  for the
plaintiffs and Ld. Senior Counsel for the defendants and gone through
their written notes of submissions and material available on record and my issue−
wise findings are as under:Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

Issue no. 1, 2, 3, 4, 6, 9 and 12  9.1.
The above issues pertain to transaction of purchase of suit
property and thus are being taken up together. The demised property A−
62, May Fair Gardens New Delhi is the bone of contention between the
parties to the suit. This property admeasuring about 800 sq. yards.  was
originally given on perpetual sublease to Ms. C.A. Hiranandan (herein
after referred to as original owner)  at that time resident of 3, Sundatta Apartments,  
Mt.   Pleasant   Road,   Bombay   vide   document   executed   on
31.03.1971 by and on behalf of President of India. It  is stated in this perpetual  
sublease   that   the   lessee   was   the   Cosmopolitan   cooperative Housing   Society  
Limited   (a   society   registered   under   the   Bombay Cooperative   Society   Act  
1925).   Ms.   C.A.   Hiranandan   was   registered member   of  the   aforesaid  society  
holding   one   share   by   virtue  of   Share
certificate dated 29.04.1958 (Ex. DW1/6) and this made her eligible to Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 130 of 161
one plot admeasuring 800 Sq. yards as above.
9.2. At the outset it is to be noted that the said plot was to be constructed   within  
two   years   of   allotment   i.e   by   1st  April   1973   but
extension was granted by the DDA till 31.12.1981. In this background
the original owner on  25.11.1981  entered into number of agreements /
documents with the Defendants in respect of the demised property which
are listed as under:
1. Construction   agreement   executed   by   the   original   owner   in   the
favour of Defendant no. 1 and 2 as expressing them as builders (Ex. DW1/9);
2. Agreement to sell dt. 25.11.1981 (Ex. DW1/10);
3. SPA given by owner in favour of Sh. Govind Aggarwal, brother of
Defendant no. 1 for construction of house (Ex. DW1/11)
4. Receipt dt. 25.11.1981 issued by C.A. Hiranandani (Ex. DW1/14)
5. Affidavit of Sh. A.D. Hiranandani (Ex. DW1/15)
6. Affidavit of the Mrs. C.A. Hiranandani (Ex. DW1/16)
7. Declaration of Ms. Kavita Vijay Mehta (Ex. DW1/17)
8. Declaration of Sh. Ranjit Hiranandani (Ex. DW1/18)
9. Will   of   the   original   owner   in   favour   of   Defendant   no.   1   and
Defendant no. 2 devolving share in equal proportion. In this willBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

Sh. O P Bhartia Plaintiff no. 2 has been appointed as sole executor
of the will. (Ex. DW1/19)
10. GPA   in   favour   of   Sh.   Govind   Aggarwal   and   Sh.   Ram   Gopal Aggarwal,  
brothers   of   Defendant   no.   1,   (Ex.   DW1/20).   This
document makes mention of agreement entered into by her with
defendant no. 1 and 2. (Ex. DW1/20)
11. Letter to the society for change of nominees name (Ex. DW1/21) Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 131 of 161
12. Letter to the society for transfer of share certificate in the name of
defendant no. 1 and 2. (Ex. DW1/22)  
In documents at Sr. no. (i) and (iv) it is mentioned that a sum   of   Rs.8.00   Lacs  
has   been   given   to   Ms.   C.A.   Hiranandan   vide
Demand Draft no. 16355 DCP 648368 dated 24.11.1981 issued by Canara
Bank New Delhi.
9.3. The defendants have also placed on record more documents in   their  favour   as
  under   which   are  allegedly   executed  by   the  original owner:
• Power   of   Attorney   dated   26.02.1982   in   favour   of   Sh.   Govind Aggarwal,  
brother   of   Defendant   no.   1   authorising   him   also   for presenting   for  
registration   and   admit   execution   on   her   behalf before Sub−
Registrar....  (Ex. DW1/23);
• Receipt dated 09.11.1982 issued by the owner confirming receipt of payment  
through   Demand   Draft   no.   16355   DCP   648368   dated
24.11.1981 issued by Canara Bank New Delhi. (Ex. DW1/5);
• Agreement to sell dated 09.11.1982 in favour of Defendant no. 1 and  Defendant  no.  2  which 
mentions   the consideration  of Rs. 8 lakhs(Ex. DW1/24);
• Construction agreement dated 09.11.1982 executed by the original
owner in the favour of defendant no(s). 1 and 2 as expressing them
as builders. This agreement makes mention of Demand Draft no.
16355 DCP 648368 dated 24.11.1981 issued by Canara Bank New Bhartia Cutler Hammer Ltd. & anr
v. P.D. Agarwal & ors Page no. 132 of 161 Delhi. (Ex. DW1/25);
• GPA   dated   09.11.1982   in   favour   of   Sh.   Ved   Prakash   and   Sh.
Shyam   Lal   Jalan   brother   in   laws   of   Defendant   no.   1,   (Ex. DW1/20).   This   document  
makes   mention   of   agreement   entered into by her with defendant no. 1 and 2. (Ex. DW1/26) •
Affidavit   of   owner   dated   09.11.1982   confirming   the   documentsBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

executed by her in favour of Sh. Ved Prakash and Sh. Shyam Lal.
Also nominating the defendant no. 1 and 2 (Ex. DW1/27) •
Affidavit of the husband of the original owner dated 09.11.1982.
(Ex. DW1/28);
• SPA in favour of in favour of Sh. Ved Prakash brother in law of Defendant no. 1. (Ex. DW1/29) 9.4.
The above−mentioned payment of Rs. 8.00 lakhs made to the
original owner for the purchase of suit property is a matter of fact but
the controversy in this suit is as:
1. Whether the agreement entered into by defendant no. 1 in respect
of the suit property was as a trustee for an on behalf of plaintiff
no. 1 (issue no. 1) and Whether the defendant no. 1 acted in breach
of trust and confidence in relation to the affairs of plaintiff no.1 (issue no. 2) or
2. Whether there was any agreement between the defendant no. 1 and   plaintiff   no.  
1   as   alleged   in   paras   1   to   7   of   the   written Bhartia Cutler Hammer Ltd. &
anr v. P.D. Agarwal & ors Page no. 133 of 161 statement   (issue   no.   12)   so   that  
the   payment   made   towards
purchase of the property was from the amounts due towards the defendant no. 1.
9.5. The issue no. 1 and 2 formulated in the suit pertain to the
trust and confidence having been breached by the defendant no. 1 while
entering into the aforesaid transaction. The plaintiff has argued that the
defendant no. 1 enjoyed the position of trust and confidence in the course
of employment with the plaintiff no.  1 and the transaction which has
been entered by the defendant no. 1 with regard to the suit property was
in fact for plaintiff no. 1 and defendant no. 1 was a trustee for and on
behalf of plaintiff no. 1. In order to prove this issue the plaintiffs have relied   upon  
series   of   documents   such   as   Management   communication dated   23.07.1974  
(Ex.   PW1/1   and   PW2/1)   and   dated   23.06.1986   (Ex.
PW1/2 and PW2/2) mentioning that defendant no. 1 held senior position
in the company plaintiff no. 1. The plaintiff buttressed this argument by
producing number of correspondences by the defendant no. 1 on behalf of
the plaintiff company such as Letter to RBI (Ex. PW2/3, 8, 917), DGTD
(Ex. PW2/4), Culter Hammer USA (Ex. PW2/5, 6, 7), Canara Bank (Ex.
PW 2/ 14 and 15) and many other entities of importance. The plaintiffs also   placed   on   record  
letter   to   PWC   the   auditor   of   the   plaintiff   no.1 written   on   26.08.1981   (Ex.   PW2/21)   to  
claim   the   contention   that   the accounts were being finalised at the behest of the defendant no. 1.
9.6. Per contra, it is relevant to mention that the defendants, in written   statement   there   is   no  
denial   rather   on   the   contrary,   the Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & orsBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

Page no. 134 of 161 Defendant   no.   1   has   given   facts   and   circumstances   by   which   he   has
contributed in the progress of the company Plaintiff no. 1.
9.7. I   have  considered   the   material   evidence   on   record   and   it
transpires that the defendant no. 1 was exercising position of authority
in to the affairs of the plaintiff company because dealing with RBI for
foreign exchange, seeking land from govt., managing the buyers and the
bank would demonstrate that the position of the defendant no. 1 in the plaintiff   company   was  
that   of   Senior   Executive   and   of   trust   and
confidence. The letter to the Auditor PWC sent by the defendant no. 1 demonstrates that
 the accounts  were being finalised at  least  after his approval   who   was   also   sending  
communication   on   behalf   of   the management of the company.
9.8. At   this   stage,   the   issue   no.   12   is   the   next   relevant   issue
which needs to be adjudicated is that since the consideration of Rs. 8.0 lakhs   as   mentioned   above
  has   flown   from   the   Bank   account   of   the
plaintiff no. 1 so whether the defendant no. 1 was entitled to this amount as   his   money   being   5%
  of   the   profit   sharing.   The   defendants   have
claimed that the amount was payable to defemdant no. 1 as part of an
agreement as he was entitled to share of profits earned by the plaintiff no.   1.   The   onus   to   prove
  this   issue   was   upon   defendants   and   the
following evidence has been adduced and contentions raised in support thereof:
• The defendants have argued that the plaintiffs have despite
repeated requests failed to produce books of accounts and Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 135 of 161
vouchers where the payment of Rs. 8.0 lakhs was recorded
in the account of the defendant no. 1. The defendants have also   relied   upon   cross  
examination   of   PW2   on   09.10.2013 and   20.05.2014   as   discussed   in  
preceeding   paragraphs states that he does not know if it was debited to defendant
no. 1 or not;
• The   payment   made   for   purchase   of   suit   property   if   was
made on behalf of the plaintiff no. 1, then it should have been   recorded   in   the  
assets   which   the   plaintiffs   have admitted not recorded;
• The only document produced is certificate dated 01.06.1982
(Ex. PW2/A) allegedly issued by the plaintiff no. 1 company
signed by the Chief Accountant. This letter has been issued
to the defendant no. 1 stating that this is to confirm that we
have advanced to you a sum of Rs. 8.0 lakhs (Rupees Eight lakhs   only)   vide  
Demand   Draft   no.   DCP   648368/   16355 dated   24.11.1981   drawn   in   favour  
of   Mrs.   C.   A. Hiranandani,   Bombay   on   your   behalf.   The   aforesaid   sum
will be deducted from salary compensation amount due to you.Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

• It   is   argued   that   Sh.   Sanjay   Sharma,   PW1,   in   cross
examination admitted that there was voucher in respect of
the said payment but the same was not produced.
• There   was   no   Board   resolution   regarding   purchase   of Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 136 of 161
property for the company, therefore, the said payment was
made on behalf of the defendant no. 1. 
• The defendants argued that the case of the plaintiffs that
the accounts show revenue expenditure of Rs.11,74,846.72 which also include 
payment  of Rs.8,02,200/− besides other
expense of Rs. 3,72,164.72 cannot be believed. The plaintiffs
have attempted to prove with the help of Board resolution
dated 22.11.1983 approving expenditure on construction.
9.9. The   plaintiffs   in   rebuttal   have   put   forth   following arguments mainly that:
• It is argued that the defendants have failed to put on record that   there   was   any  
documentary   agreement   between   the plaintiffs   and   the   defendant   no.   1   to  
give   5%   share   in   the profits   besides   the   salary.   The   contention   of   the  
defendants that this oral agreement was known to one Sh. P. C. Kejriwal gets  
impeached   from   the   facts   that   this   person   was   never
examined and secondly, he was holding shares in the company
of the defendant no. 1 and thus was interested witness.
• The Income Tax Returns (ITR) of the defendant no. 1 do not
show any income on account of accrued 5% share in addition to
the actual salary received from plaintiff no. 1. The ITR also do
not make mention of suit property being purchased out of such
compensation (5% share).
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 137 of 161 • In  
respect   of   certificate   dated   01.06.1982   (Ex.   PW2/A),   it   is
argued on behalf of the plaintiffs that this document is forged
and fabricated because the certificate is issued on letter head
which was not in use. This has been put in cross−examination
to the defendant no. 1. Further, Sh. A. N. Chandra who has
issued this certificate was in the employment of the plaintiff company  but   left
 services   in  the  year  1988.  This   person  has
joined the defendants and thus interested person.
• The plaintiffs have contested the claim of the defendants that Sh.   O.P.   Bhartia  
while   appearing   as   witness   admitted certificate   dated   01.06.1982   (Ex.  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

PW2/A),   the   argument   that there   was   never   any   admission   but   mere  
statement   that   it must have been issued.
9.10. I   have   given   careful   consideration   to   the   rival contentions   and   find  
that   the   payment   of   Rs.8.00   lakhs   was   given through   Demand   Draft   no.  
16355   DCP   648368   dated   24.11.1981
issued by Canara Bank New Delhi (Ex. DW1/5) and handed over to the   owner   of  
suit   property   Mrs.   C.A.   Hiranandani.   The   point   of determination   of   the  
entitlement   of   the   defendant   no.   1   would   be
adjudged as on 24.11.1981. There is no written document to show that
there was any such agreement between the plaintiff no. 1 and the defendant   no.   1.  
This   is   important   from   the   view   point   that   the
plaintiff no. 1 is a company which has distinct corporate entity. Even though   the 
functions   of  the  corporate   entity   are  discharged   by  the Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 138 of 161
persons managing the affairs of the company but the binding effect of the   decisions  
get   culminated   only   based   on   the   documents.   The
receivable from the company account get legalised only if issued in
the forms of writing. Any oral commitment by the persons managing affairs   cannot  
be   pressed   into   service   against   the   corporate   entity.
The defendants cannot take a shield behind the fact that the plaintiff
no. 1 has not produced accounts where the entry of Rs. 8.00 lakhs has
been shown towards him but at the outset it was incumbent upon the
defendants to demonstrate that defendant no. 1 was entitled for the
said amount as his own. There is no evidence which could show that
the defendant no. 1 was legally entitled to the said sum.
9.11. The plaintiffs have put forth argument that in the month of   June   1981   when   the   plaintiff  
no.1   was   looking   for   suitable
accommodation for company house, in this regard, the suit property
was identified and it became known that the original owner has by
that time already dealt with this property through estate agent (Vijay Chauhan   &   Co.)   to   Sh.   J.  
K.   Malhotra.   In   this   background,   the plaintiff   no.   1   wrote   communication   to   this   estate  
agent   (Vijay Chauhan & Co.) expressing interest in the suit property and asked
the switch over of the transaction in lieu of Rs. 1 lakh paid through
Cheque no. 975348 dated 08.06.1981. This letter is exhibited as (Ex.
PW2/19) and its contents are important piece of evidence as a part of
the transaction. The plaintiff no. 2 has written the following letter to
the estate agent (Vijay Chauhan & Co.) which is as under:
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 139 of 161
" O.P. BHARTIA New Delhi House, 11th Floor 27, Barakhamba Road, New Delhi−
110001 June 8, 1981 Messrs, Vijay Dhawan & Co., Estate Agents Dhawan House H−Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

179/A Panch Sheela Park New Delhi
This has reference to our discussions with your Mr. P.L. Dhawan and we confirm that
  we   are   interested   to   buy   the   lease−hold   Plot   no.   A−162,   situated   at  
Mayfair Garden, New Delhi,
 and authorise you to negotiate the deal and purchase of the
above plot on our behalf admeasuring about 800 aq. Yards.
Should   this   transaction   ot   materialise   within   fifteen   days   from   this   date,  
it   is
mutually understood that the earnest money of Rs. 1 Lakh (Rupees one lakh only)
paid   by   cheque   no.   975348   dated   June   8,   1981   in   favour   of   Mr.   J.K.  
Malhotra, payable on Canara Bank, Janpath, New Delhi is returnable to us in full.
We   understand   that   Mr.   Malhotra   will   nominate   Mr.   P.D.   Agarwal   and/or
  his
nominees, on receipt of the balance price, which is to be negotiated through you, for
transferring all his rights accruing to hi, vide receipt in his favour dated May, 19,
1981 (copy attahced) from the sub−lessee of the said plot, Mrs. C.A. Hiranandani, to
Mr. P.D. Agarwal and/or his nominess, Thanking you Yours faithfully (O.P. Bhartia)
Attachment : Cheque Received original letter and cheque P.L. Dhawan"
 
The contents of the letter clearly show that the plaintiff
no. 1 was facilitating buying of the suit property and for this purpose
nominated the defendant no. 1. If the transaction was executed by the Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 140 of 161
defendant no. 1exclusively for his own then it is not explainable as to
what was the need of the above said letter from plaintiff no. 2. At this
stage, it is relevant to refer to another letter marked as DW1/B which
is dated 24.11.1981 written by the defendant no. 1 to Canara Bank
Delhi on behalf of the company to debit the account of the company
for issue of demand draft for Rs. 8.00 lakhs in favour of Oriental Bank of   Commerce
  a/c   Mrs.   C.   A.   Hiranandani   payable   at   Bombay.   The statement   of   Bank  
account   of   the   plaintiff   no.   1   maintained   with
Canara Bank (Ex. PW 1/3 and Ex. PW2/20) shows that an amount of Rs.8,00,160/−
 has been debited. The entire series of the transaction at the  relevant  point  of 
time though  leaves  no  doubt  that  these  were
being carried with the aid and assistance of the plaintiff no. 1 but at
the same time, it is also a fact that if the transaction was to be carried for   the  
plaintiff   no.   1   then   there   would   be   a   Board   resolution   to
purchase the property. The plaintiffs have failed to produce any such
resolution authorising purchase of the suit property for itself either in
its name (plaintiff no.1) or in the names of the defendants as trusteesBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

which is material as to show the intention of the plaintiff no.1. The reliance   of   the  
plaintiffs   to   the   Board   resolution   dated   22.11.1983
adopting the Accounts for the financial year ending 30.06.1983 cannot
be taken as authorisation to buy the suit property in the name of the
defendants. The alleged purchase of the suit property was undertaken
in the November 1981 and the financial year was ending 30 th  June 1982. 
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 141 of 161 9.12.
But at the same time, the defendant no. 1 has also failed
to establish the existence of any agreement of sharing of profit and
the analysis of the circumstances show that the amount paid from the
company account to Mrs. C. A. Hiranandani was an advance towards
the defendant no. 1 which was adjustable from the future salary. In
this regard letter/ certificate dated 01.06.1982 (Ex. PW2/A) allegedly
issued by the Chief Accountant of plaintiff no. 1 company assumes
significance which stated as under:
 This is to confirm that we have advanced to you a 
sum of Rs. 8.0 lakhs (Rupees Eight lakhs only) vide 
Demand Draft no. DCP 648368/ 16355 dated 
24.11.1981 drawn in favour of Mrs. C. A. 
Hiranandani, Bombay on your behalf. The aforesaid 
sum will be deducted from salary compensation  amount due to you.
9.13. The plaintiffs have disputed the above letter being credible based   on   the   fact
  that   the   letter   pads   used   to   issue   this   letter   are
different than those being used at relevant point of time. This objection is   not  
sustainable   because   the   plaintiffs     have   failed   to   produce   the
records showing the correct entry passed in respect of this amount. There
are only averments in the plaint that this amount has been posted in the Capital  
Account.   Another   set   of   contentions   of   the   plaintiffs   are   that while  
adopting   the   accounts   for   the   financial   year   ending   30.06.1983, there   was  
a   Board   resolution   dated   22.11.1983   indicating   that   suit property   was  
shown   as   Building   under   construction   (others)   value   at Rs.11,74,846/−  
included   the   cost   of   plot   and   expense   of   construction Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 142 of 161 cannot   be   accepted 
for  the  precise   details.   In   such   circumstances,   the
amount paid by the plaintiff no. 1 towards purchase of the suit property
partakes the character of advance/ loan which was deductible from the
salary of the defendant no. 1. This amount remains outstanding and has
not been adjusted.
9.14. In so far  as cost of construction is concerned, it would be appropriate   to   refer
  to   certain   dates   such   as   date   of   transaction 25.11.1981,   date   of   completionBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

  of   construction   06.04.1983   and   date   of
House warming (Greh pravesh) 07.07.1983. The claim of the defendants
is discernible from paragraphs 14, 15, 16, 17, 18, 19, and 19A primarily
stating that the major cost has been borne by all three of them (D−1, D−2 & D−
3) as per their arrangement and it has been admitted that some part has   been  
advanced   by   the   plaintiff   no.1.   In   the   same   breath,   the defendants   argued  
that   whatever   the   amount   plaintiff   company   has
incurred towards the cost of construction the same was to be adjusted in
the account of the defendant no. 1 for alleged agreement of sharing of 5%
of the profit. The defendants in counterclaim admit the amount  being
19.33 lakhs which is constituted of two amounts one Rs.8.00 lakhs for
cost of land and other Rs.11.33 lakhs towards cost of construction.   In support   of  
the   claim   that   substantial   amounts   were   spent   by   the
defendants themselves, the bills and vouchers have been submitted.
9.15. Per contra, the plaintiffs alleged that the defendant no. 1
was holding the senior and confidant position in the company, therefore Bhartia
Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 143 of 161
the funds of various projects and items have been diverted for raising
construction etc. In support of this contention submitted evidence in the
form of bills and vouchers (Ex. PW1/5 which is PW1/5A to Z and another
set of evidence PW1/6 to PW1/15). These bills are mostly of the month of
June 1986 and some of the bills and vouchers are of other years.
9.16. I   have   carefully   analysed   the   rival   evidence   adduced   and find   that   the
  defendants   admit   that   some   of   the   funds/   materials   for construction of A−
62 Mayfair Garden has come from the plaintiff no. 1 . There   is   an   admission   to  
the   extent   of   Rs.11.33   lakhs,   whereas,   the
plaintiffs claim that the construction has been raised from the funds of the   plaintiff  
no.   1.   The   plaintiffs   have   not   been   able   to   prove   the
expenditure more than the amount of Rs.11.33 lakhs as admitted by the
defendants. At the same time, the defendants have also failed to produce
evidence of funds and its source to show the construction from its own
account. By mere submitting incoherent bills and valuation, it does not prove   that  
matching   funds   were   available   with   the   defendants   which have   been  
utilised.   In   these   circumstances,   the   admitted   amount   of Rs.11.33   lakhs   is  
treated   as   the   amount   spent/   contributed   by   the
plaintiff company on the cost of construction of the suit property. The existence   of  
any   profit   sharing   arrangement   of   5%   has   already   been
discarded above, therefore, even this amount is treated as loan/ advance
towards the defendants.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 144 of 161 9.17.
It has been argued by the plaintiffs that the defendants in written   statement   have  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

admitted   the   claim   of   the   plaintiffs   and   in
support of this contention referred to the fact that the defendants have
admitted payment of Rs. 8 lakhs by the company and also did not dispute
the contention of the plaintiffs that construction has been made from the
funds of the company. The defendants refuted the claim of admission by
referring to paragraphs 12 and 9 of WS where it has categorically been refuted   that  
the   payment   of   Rs.8   lakhs   was   made   on   behalf   of   the
company but it was asserted that the payment was made out the amount due  
towards   defendant   no.   1.   Further,   it   was   also   contended   that   in
paragraphs 9, 14,15 and 16 there has been specific pleadings about the
fact of expense of construction having been borne by the defendant no. 1 to 3.
9.18. I have gone through the contents of WS and find that there
is no admission of the case of the plaintiffs because the entire WS has to be read 
together  which  has   set  up  the case of the  defendants.  In nut
shell, the defendants have set up pleadings that the amount even though
paid by the company but it was out of the amount due towards defendant
no. 1 as result of agreement of sharing of profit. The construction was got
done by the defendants. The pleadings of WS do not suggest that there
has been any admission on behalf of the defendants.
 
9.19. Now,   coming   to   the   application   of   Benami   Prohibition
Provisions, it has been strongly argued on behalf of the defendants that in   case   the  
consideration   for   the   transaction   has   been   paid   by   the Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 145 of 161 plaintiff   company  
and   property   has   been   bought   in   the   names   of   the
defendant no. 1 and defendant no. 2, then the transaction is a Benami
Transaction which is prohibited either by section 281A of Income Tax Act
or by the provisions of the Act 1988.
9.20. The provisions of section 281A of Income Tax Act remained
on statute book from 15.11.1972 to 19.05.1988. However, on passing  of
Benami Transaction  (Prohibition) Act, 1988 (45 of 1988) its provisions
were made effective from 19.05.1988 and on that date section 281A stood repealed.
9.21. For the purpose of the present suit the relevant legislation would   be   decided  
based   on   the   date   of   filing   of   suit.  The   suit   was
presented in the Registry of Hon'ble High Court on 08.01.1988 which was
put into objections due to deficiency of court fee and other objections. The deficit  
court   fee   was   paid   on   23.07.1988   and   after   removing   other objections   on  
05.08.1988,   the   matter   was   listed   for   16.08.1988.   It   is settled   law   that   the
  date   of   filing   of   the   petition   relates   back   to   theBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

original date after removal of defects. The Hon'ble High Court in Ramiah
v. R. Palaniappan in Crp (PD) no.s 1690 to 1692 of 2005, had an occasion to   deal  
with   this   issue   and   referred   to   judgments   and   observed   as follows:−
"In 1970 (1 SCC) 769, Mannan Lal v. Mst. Chhotaka Bib, the Hon'ble
Supreme Court held that :
"When   the   deficit   stamp   paid   on   an   insufficiently   stamped
memorandum of appeal, the appeal must be treated as pending from Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 146 of 161
the date of presentation both for the purpose of limitation and for the
purpose of sufficiency as to court−fees."
In AIR 1938 Madras 542, Venkanna v. Atchutaramanna, it was held as follows:− "Where   a   plaint  
is   written   upon   paper   insufficiently   stamped,   the
Court is bound to give the plaintiff time to make up the deficit; only
when he fails to comply with the order, the Court can reject the plaint;
that the plaint is presented on the last day of the period of limitation makes   no   difference,   that  
is   the   effect   of   O.   7   Rule   11,   Civil   P.C.
Again, whether the payment of insufficient fee was by design or due to
inadvertence, the Court is bound by the mandatory terms of it, to give
effect to this provision,  this being the law, the Court's action in giving
the plaintiff time originally cannot be questioned.   But once time is
fixed, it is no longer open to the plaintiff to demand as a matter of
right that the time should be extended. The power to grant extension vests   in   the   Court   either  
under   S.   148   or   S.149,   Civil   P.C.   Under
either of those sections, the question is one of the Court's discretion
and not the plaintiff's right. It is obvious that the Court must exercise
its discretion not capriciously but judicially and reasonably."
In 51 M.L.J. 90, Kolisetti Basavayya v. Mittapalli Venkatappayaa, it was held as follows:
"The Court has discretion to extend to any limit the time within which
the deficient court−fee on a plaint may be paid; and if the fee is paid
within the time fixed, the plaint will stand good as on the date of its presentation.
When the plaintiff pays the deficient Court−fees beyond the time fixed,
two courses are open to the Court. It may either reject the plaint or
accept it. Both courses are within its discretion with which a superior
court will not as a rule interfere.
When the plaintiff pays the deficient Court−fee beyond the time fixed Bhartia Cutler
Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 147 of 161
and has not asked the Court to extend the time for payment, but the
Court nevertheless excuses the delay and receives the fee, the naturalBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

inference is that it intended to extend the time and in effect did so."
In AIR 1938 Madras 560, Durairangam Pillai v. Govindarajulu Naidu, it was held:
"Where a plaint insufficiently stamped is filed on the last day of the period   of  
limitation   and   is   returned   by  the   Court   allowing   certain
time for payment of the deficient court−fee, the suit is not barred if the proper  
court−fee   is   paid   within   the   time   allowed   by   the   Court   but
beyond the period of limitation for the suit, because reading O.7 R. 11
together with S. 149, the payment of the deficient court−fee within the
time allowed by the Court has the same effect as if the court−fee had
been paid in the first instance, that is on the date when the plaint was
first presented."
In 1977(2) Andhra Weekly Reporter 117, Kishwari Begum v. Quadiri Begum, it was held:
"Section   148   CPC,   does   not   contain   any   words   of   limitation   to
indicate that the power granted to the Court to extend the time can be
exercised only during the pendency of the proceedings before it, or that
an application for extension should be filed before the expiry of the
period fixed by its order. It merely empowers the Court to enlarge the
period prescribed by it for doing of any act, from time to time, in its
discretion, even though the period originally fixed has expired. It is a
procedural provision and it should be interpreted so as to allow the
Court to meet the several eventualities, arising from time to time to do
justice between the parties and not in such a narrow manner as to
stifle its powers which may result in defeating the ends of justice."
In   AIR   1940   Madras   934,   Venugopal   Pillai   v.   Thirugnanavalli Amman, it has been held:
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 148 of 161
"Even where the Court improperly and without sufficient cause grants
time for payment of court−fee after the plaint has been presented, the
effect of the grant of such time that the plaint takes effect as if it has been   presented  
alongwith   the   full   court−fee   on   the   date   of   its   first
presentation and no question of limitation can arise where the plaint
as originally presented is within time."
In AIR 1944 Kerala 405, V.O. Devassy v. Periyar Credits, it was held:
"  Where   the   suit   was   filed   on   the   last   day   of   limitation,   and   the
deficiency of Court−fee was made good subsequently as required by the
Court, the plaint was not liable to be rejected under O.7 R.11 (C) as
the discretion contemplated in S.149 was exercised by the Court inBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

favour of the plaintiff. The direction having been complied with, the
payment of the deficit court−fee shall be deemed to have been made on
the date of presentation of the plaint."
In AIR 1953 SC 431, Ganesh Prasad v. Narendra Nath, it has been held:−
"The question of payment of Court−fees is primarily a matter between
the Government and the person concerned and therefore, where the High Court  in the  exercise of 
its discretion  allows the  appellant to
amend his memorandum of appeal and grants time for payment of deficient   court−fee   under  
S.149,   the   other   party   cannot   attack   the
order on the ground that it takes away his valuable right to plead the bar of limitation."
In view of the observation made in judgments (supra), thus, the   present   suit   is   taken   to   be  
filed   on   08.01.1988   therefore   relevant
provision would be section 281A of Income Tax Act which is extracted as under:
 281A. Effect of failure to furnish information in respect of  Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 149 of 161 properties held benami.−    (1)  
No   suit   to   enforce   any   right   in   respect   of   any   property  held benami, 
whether against the person in whose name the property is
held or against any other person, shall be instituted in any court by or on   behalf   of  
a   person   (hereafter   in   this   section   referred   to   as   the
claimant claiming to be the real owner of such property unless notice in  the  
prescribed   form   and  containing  the   prescribed   particulars   in
respect of the property has been given by the claimant within a period
of one year from the date of acquisition of the property, to the  Chief
Commissioner or Commissioner. 
(1 A) Where any such property is acquired by the claimant before the 1st   day   of   March,   1984,  
the   provisions   of   sub−section   (1)   shall   be deemed   to   have   been   fulfilled   if   notice   in  
the   prescribed   form   and containing   the   prescribed   particulars   in   respect   of   the   property
  is given by the claimant, within a period of one year from the said date,
to the Chief Commissioner or Commissioner.
(1B)   Notwithstanding   anything   contained   in   sub−section   (1)   or   sub−
section (1A), in relation to any suit relating to any immovable property
of a value not exceeding fifty thousand rupees, the provisions of sub−
section (1) or, as the case may be, sub−section (1A), shall be deemed to have   been   fulfilled   if,   at  
any   time   before   the   suit,   notice   in   the
prescribed form and containing the prescribed particulars in respect of the   property   has   been  
given   by   the   claimant   to   the  Chief Commissioner or Commissioner.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 150 of 161
(2) The Chief Commissioner or Commissioner shall, on an applicationBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

made in the prescribed manner, by the claimant or any person acting
on his behalf or claiming under him, and on payment of the prescribed
fees, issue, for the purposes of a suit referred to in sub−section (1), a
certified copy of any notice given by the claimant under sub−section (1) or sub−section (1A) or sub−
section (IB), within fourteen days from the date of receipt of the application.
(3) This section shall not apply to any suit of a value not exceeding two
thousand rupees which is tried by, --
(a) a Court of Small Causes constituted under the Presidency Small
Cause Courts Act, 1882 (15 of 1882), or the Provincial Small Cause Courts Act, 1887 (9 of 1887); or
(b) a court invested with the jurisdiction of a Court of Small Causes,
by or under any enactment for the time being in force, in the exercise of such jurisdiction.
9.22. The   Income   Tax   Act   does   not   define   Benami   transaction, therefore   it   has   to  be 
understood  in   the  backdrop   general  meaning   is attached to it. In 57th 
Report of Law Commission the aspect has been
discussed in length. But for the purposes of this case it would simply
mean that benami transaction means any transaction in which property is   transferred   to   one  
person   for   a   consideration   paid   or   provided   by another person.
9.23. In the present case, the suit property has been ostensibly Bhartia Cutler Hammer Ltd. & anr v.
P.D. Agarwal & ors Page no. 151 of 161
transferred in the name of defendant no. 1 and defendant no. 2 by the
original owner while the consideration has been paid by the plaintiff no.
1 company. The question whether a particular sale is benami or not is
largely one of fact. Though there is  no formula  or acid test uniformly applicable   it   is   well   neigh
  settled   that   the   question   depends
predominantly upon the intention of the person who paid the purchase
money. For this, the burden of proof is on the person who asserts that it is   a   benami   transaction.  
However,   if   it   is   proved   that   the   purchase money   came  from   a  person  other  than  the 
recorded   owner  (ostensible owner)   there   can   be   a   factual   presumption   at   least   in   certain
  cases, depending on facts, that the purchase was for the benefit of the person who   supplied  
purchase   money.   This   is,   of   course,   a   rebuttable
presumption (Bhim Singh (D) by Lrs. and another vs. Ken singh, AIR
1980 SC 787; Controller of Estate Duties, Lucknow vs. Aloke Mitra (AIR 1981
 SC 102; His Highness Maharaja Pratap Singh vs. Her Highness
Maharani Sarojini Devi, 1994 Supple.(1) SCC 734).
9.24. Hon'ble   Supreme   Court   in   the   case   of  Jaydayal   Poddar through  LRs.and  Anr.  V.  Bibi
  Hazra  and  Ors.:  AIR  1974   SC  171  laid down   circumstances   to   go   through   while  
determining   whether   a particular sale is benami or not.Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

i) The source from which the purchase money came.
ii) The nature and possession of the property after the purchase.
iii) Motive, if any, for giving the transaction a benami colour.
iv) The position of the parties and the relationship, if any, between
the claimant and the alleged benamidar.
v) The custody of the title deed after the sale.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 152 of 161
vi) The conduct of the parties concerned in dealing with the  property after the sale.
9.25. In   the   present   case,   the   evidence   adduced   does   not   show
that the intention of the plaintiffs was to purchase the said property in
Benami. This is exhibited from the fact that the defendant no. 2 Mrs.
Sulochana Agarwal was never mentioned in any of the communications from   the   plaintiff   for  
transaction   in   the   suit   property.   It   was   the defendant   no.   1   who   was   enjoying   position  
in   the   plaintiff   company, steered   the   transaction   according   to   his   wishes.   The   control   of
  the defendant no. 1 over the transaction is further exhibited from the fact
that the demand draft was issued by the Canara Bank at the strength of
his letter  dated 24.11.1981 (DW1/B)  which shows that the defendant no. 1   was   in   the   driving  
seat.   Therefore,   the   transaction   cannot   be   held Benami   Transaction   because   the   element  
of   intention   of   the   person/
company paying consideration is missing and the ingredient of motive is
also missing. The facts suggest that the defendant no. 1 exercising his position   in   the   plaintiff  
no.   1   executed   the   transaction   in   his   favour.
However, it is equally a fact that the plaintiff no. 2 was also aware of the
fact that the transaction was being carried by the defendant no. 1 in his name.   This   conclusion   of
  knowledge   of   the  plaintiff  no.   2   is   exhibited
from the letter written by him to this estate agent, M/s Vijay Chauhan &
Co. (EX. PW2/19) wherein the name of defendant no. 1 has specifically
been authorised. The acquiescence of the plaintiff no. 2 to the transaction is   further   exhibited  
from   the   fact   that   he   participated   in   the   House
warming ceremony and there is document/ letter / notice ever issued to Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 153 of 161
the defendant no. 1 for return of either title deeds or retransfer of the suit property.
9.26. The   careful   analysis   of   the   entirety   of   proven   facts   show
that the negotiations for purchase of suit property was started by the
plaintiffs and defendant no. 1, consideration was paid from the plaintiff
no. 1 accounts, documents were got executed in the name of defendant no.   1,2   and   3;   there  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

were   number   of   other   documents   in   favour   of
brothers of the defendant no. 1, the cost of construction has been from
mix funds and there was no demand of title documents.   Moreover, as
discussed above, that no Board Resolution of the plaintiff company has
been filed authorising to buy the property in the name of the defendants.
Based on these facts, it cannot be conclusively held that the transaction was   a   Benami   in  
particular   because   there   was   no   intention   of   the plaintiff   company   to   hold   the   property
  in   benami.   The   funds   of   the
plaintiff no. 1 invested on the suit property are being treated as loans/
advances towards the defendant no. 1 and thus once the transaction is
not benami, neither the provisions of section 281A of income tax nor the provisions   of   the   Act  
1988   would   apply   as   a   disability   to   bring   the present suit.
9.27. The claim of the defendant no. 1 that this amount was his
entitlement of 5% of the profits has been examined above and has been decided   against   him.  
Another   contention   raised   that   in   that   event   it
becomes an advance towards the defendant no. 1 which was adjustable Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 154 of 161
from the future salary. In this regard letter/ certificate dated 01.06.1982
(Ex. PW2/A) allegedly issued by the Chief Accountant of plaintiff no. 1
company assumes significance which stated as under:
 This is to confirm that we have advanced to you a sum 
of Rs. 8.0 lakhs (Rupees Eight lakhs only) vide Demand
Draft no. DCP 648368/ 16355 dated 24.11.1981 drawn 
in favour of Mrs. C. A. Hiranandani, Bombay on your 
behalf. The aforesaid sum will be deducted from salary 
compensation amount due to you.
The amount paid by the plaintiffs partakes the character of
advance/ loan which was deductible from the salary of the defendant no.
1. This amount remains outstanding and has not been adjusted.
9.28. In consideration of totality of circumstances and discussion above, it  has
 held that suit  property has been bought  in  the name of
defendant no. 1 and 2 and they areentitled to the same, however, the defendant   no.  
1  has   notpaid  the  outstanding  loan  amount   of  Rs.19.33 Lakhs   incurred   by   the
  plaintiff   no.   1,   therefore,   the   plaintiff   no.   1   is entitled   for   recovery   of  
Rs.19,33,618.40   alongwith   interest   @18%   per
annum from the date of institution of this suit till its realization for the reason   that  
defendants   have   utilized   the   amount   of   plaintiff   no.   1
without any authority and the transactions therefore being commercial in   nature  
and   the   value   of   the   suit   property   has   been   increasedBhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

manifolds, since the time of investment, therefore, the rate of interest
has to be compensatory in nature.   In view of above observation, issue
no(s) 1, 2, 3, 4, 6, 9 and 12 are decided accordingly.
Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 155 of 161 Issue no. 5  9.29. The 
present   suit   has   been   treated   to   have   been   filed   on
08.01.1988 and it is contended by the defendants that the suit is barred
by limitation because the transaction happened on 21.11.1981 and also
on 05.11.1982, therefore by virtue of Article 59 of the Limitation Act, the
period of 3 years expires by the end of the year 1985. The suit filed in the
year 1988 is time barred. It is further argued that amendment to include
prayer for declaration of title and possession is also barred by limitation. The   suit   has   been  
instituted   in   year   1988   for   injunction   which   was
converted into a suit for possession by amendment  which was allowed on 09.04.2001.   The  court−
fees   was   finally   paid   on  01.07.2006  and   date  of
filing of amended plaint should be treated as on 01.07.2006 i.e. the date on which court−
fees was paid.  
9.30. The   bone   of   contention   between   the   parties   has   emerged
from the title documents which have conferred rights in the suit property
in the defendants. The plaintiffs alleged that these documents came to the   knowledge   of   the  
plaintiffs   only   when   the   defendant   no.   1   was leaving   the   employment   of   the   plaintiff  
no.   1   in   the   year   1986.   It   is claimed   by   the   plaintiffs   that   certain   copies   of   documents
  depicting dealings between the original owner and the defendant no(s). 1 and 2
were provided which acted as knowledge as provided.
9.31. I have given careful consideration to the facts and find that the   plaintiffs   initially   filed   suit  
for   rendition   of   accounts,   declaration, Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors
Page no. 156 of 161 injunction   on   08.01.1988,   thereafter,   it   was   converted   into   suit   for
declaration   of   title   and   possession   vide   order   dated   09.04.2001   and
amended plaint was filed on 23.04.2002 though the defendant has taken a   plea   that   the   court  
fee   was   paid   on   01.07.2006   so   the   suit   is   time
barred, the date of filing of amended plaint will be 01.07.2006. However,
as discussed above earlier, the date of filing of suit should be treated as
date of presentation and it was observed   in preceding paragraph that
defendant no. 1 was enjoying position of trust and confidence in plaintif no.   1,   there   is   no  
probability   of   documents   having   been   seen   by   the plaintiff   no.   2   on   the   date   of  
execution.   It   is   an   admitted   fact   that defendant   no.   1   left   the   company   in   year   1986  
and   photocopies   of documents were given by the defendant no. 1 to the plaintiff no. 2 at that
time, in these circumstances  the facts  speaks of the knowledge to the
plaintiffs about the documents in year 1986 itself.  The present suit was
filed in January, 1988 which is well within period of limitation.  There is
no reason which could show that plaintiffs will sleep over their valuable
rights for five years. Further, in para no. 9.21 above, it has already been observed   that   a   conjoint  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

reading   of   Order   VII   Rule   11   together   with Section   149   CPC,   the   payment   of   deficit  
court−fee   within   the   time allowed by the Court has the same effect as if the court−
fee has been paid in the first instance i.e. on the date when the plaint was first presented.
The suit filed by the plaintiffs cannot be said to be barred by limitation.
Accordingly, this issue is decided in favour of plaintiffs.
Issue no. 7  Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors Page no. 157 of 161 9.32.
The only instance of the estoppel quoted by the defendants
was that the plaintiff no. 2 attended the house warming ceremony and did   not   ask   for   the   title  
documents   till   the   filing   of   the   present   suit. Attending   house−warming   ceremony   is   not  
sufficient   to   discharge   the onus placed upon the defendants, moreso, in the scenario of trust and
confidence   between   the   plaintiffs   and   defendant   no.   1.     This   issue   is
accordingly decided in favour of the plaintiffs.
Issue no. 8  9.33. This   issue   has   emerged   owing   to   the   contention   of   the
defendants that the sub−lease executed in favour of the defendants and
the society was based on the lease granted to the society. The plaintiff
no. 1 being a corporate body cannot become member and hence the relief
sought if granted would come in conflict of bye−laws. None of the parties
have brought on record any material/ documentation which could show that   the   Co−operative  
Society   Rules   did   not   allow   company   to   buy
leasehold properties, this issue is accordingly adjudicated.
Issue no. 10 and 11  9.34. The   onus   to   prove   these   issues   was   upon   the   plaintiffs   .
These issues pertain to car bearing no. DBA 5831 which the plaintiffs alleged   to   have   been  
retained   by   the   defendant   no.1   unlawfully,
therefore, the defendant no. 1 was liable to pay either the user charges of Rs.75,000/−
 and return the car or the entire amount of Rs.87,985/− was
recoverable from the defendants. Per contra, the defendants contended Bhartia Cutler Hammer Ltd.
& anr v. P.D. Agarwal & ors Page no. 158 of 161
that as per the policy of the plaintiff no. 1 the vehicles were given to the
senior executives at the book value and adjusted towards the amounts
due. The defendants have not been able to produce any agreement in this
regard and it is normal practice that the vehicle given to the employees
during the employment is returned back when the services are left. The
defendant no. 1 could not show that he was entitled to retain the car
beyond the period of entitlement. It transpires from the plaint that the
car was purchased in September, 1986 and it has been retained by the
defendant no. 1, therefore the plaintiff company is entitled to recover the cost of car Rs.87,985/−
 from the defendant along with interest @ 12% p.a.
from the date of institution of suit till the date of its realization.  
Issue no(s). 13 and 14 9.35.   These   issues   emerge   from   the   counterclaim   filed   by   the
defendants but precisely defendant no. 1 who was in the employment of plaintiff   no.1.   The   claim  Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

filed   by   the   defendants   is   based   on   the contention   that   he   was   entitled   to   share   of  
profit   @5%.   In   the counterclaim the defendants appended a schedule as under:
Accounting Pre−text profit Profit showing year as per printed amount @5% ending
balance−sheet Estimate Figures in lakhs 1977 12.24 .61 1978 37.80 1.89 1979 70.55
3.53 1980 102.09 5.10 sub total 11.13 Bhartia Cutler Hammer Ltd. & anr v. P.D.
Agarwal & ors Page no. 159 of 161 1981 150.29 7.51 1982 103.12 5.16 1983 59.25 2.96
1984 74.15 3.70 1985 77.99 3.90 1986 193.93 9.70  TOTAL 44.06 Lakhs 9.36.
It has been contended that based on the calculations above,
the defendant no.1 was entitled to an amount of Rs.44.06 lakhs over the
years. It is further contended that by the end of the year 1979−80 the
outstanding were Rs.11.03 lakhs out of which Rs.8.00 lakhs were paid for
the purchase of the suit property and thereafter amounts were spent on
construction. In the counterclaim, it has been contended that in case the
contentions are not accepted that the defendant no. 1 may be allowed to
treat the total sum of Rs.19.33 lakhs as a loan and be asked to repay in the   agreed 
installments.   The   issue  of   agreement   of  sharing   profits   on oral
 basis has been discussed above and in absence of any convincing evidence   this  
contention   has   been   rejected.   In   consideration   of   the discussion   above,   the  
issue   no.   13   and   14   are   decided   against   the defendants.
Relief
10. In view of discussion made in issue no. 1,2, 3, 4, 6, 9 and 12,
the suit of plaintiffs is partly decreed to the extent that the plaintiff no. 1 Bhartia Cutler Hammer
Ltd. & anr v. P.D. Agarwal & ors Page no. 160 of 161 is entitled for a sum of Rs.19,33,618.40/−
 towards loan amount alongwith interest   @   18%   from   the   date   of   institution   of   suit   till  
realization   of amount from the defendant no. 1. The plaintiff no. 1 is further entitled to
sum of Rs.87,985/− towards cost of car from the defendant no. 1 along
with interest @ 12% p.a. from the date of institution of suit till the date
of its realization. Further, in view of observations made in issue no. 13 and 14, counter−
claim of defendants stand dismissed. Cost of suit is also awarded in favour of plaintiffs. Decree−
sheet be prepared accordingly.
File be consigned to record room. 
                                                                       VINEETA     VINEETA GOYAL
Pronounced in open Court                                               GOYAL       Date: 2018.10.03
                                                                                   17:24:50 +0530
on 27.09.2018
                                                                                     (Vineeta Goyal)
                                                                    Additional District Judge−03,
                                                                         South/Saket/New Delhi Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

Bhartia Cutler Hammer Ltd. & anr v. P.D. Agarwal & ors                                             Page no. 161 of 161Bhartia Cutler Hammer Limited vs Prabhu Dayal Agarwal on 27 September, 2018

