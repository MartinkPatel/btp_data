Gandhimathi vs The State Of Tamil Nadu Rep. By on 31 July,
2023
Author: M.Sundar
Bench: M.Sundar
    2023:MHC:3539
                                                                                 H.C.P.No.500 of 2023
                                     IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                   DATED: 31.07.2023
                                                          Coram
                                       THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                       and
                                      THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                  H.C.P.No.500 of 2023
                     Gandhimathi                                                    .. Petitioner
                                                            vs
                     1.The State of Tamil Nadu rep. By
                        Secretary to Government,
                       Home, Prohibition and Excise Department,
                       Fort St.George, Chennai – 600 009.
                     2.The District Collector and District Magistrate,
                        Mayiladuthurai District, Mayiladuthurai.
                     3.The Superintendent of Police,
                        Mayiladuthurai District, Mayiladuthurai.
                     4.The Superintendent of Prison,
                       Central Prison, Tiruchirappalli.
                     5.The Inspector of Police,
                       Sirkazhi Police Station,
                       Mayiladuthurai District.                             ..   Respondents
                                  Petition filed under Article 226 of the Constitution of IndiaGandhimathi vs The State Of Tamil Nadu Rep. By on 31 July, 2023

                     praying for issuance of a writ of habeas corpus to call for the
                     records relating to the detention order dated 27.02.2023 passed by
                     the second respondent in his proceedings in C.O.C.No.07/2023 and
                     quash the same and direct the respondents herein to produce the
https://www.mhc.tn.gov.in/judis
                     1/9
                                                                                  H.C.P.No.500 of 2023
                     petitioner's son namely Mendal Mani @ Manikandan, son of
                     Velmurugan, aged about 25 years, who is presently undergoing
                     detention in the Central Prison, Tiruchirappalli as Goonda before
                     this Court and set him at liberty forthwith.
                                  For Petitioner          :     Mr.M.Vinoth
                                  For Respondents         :     Mr.E.Raj Thilak,
                                                                Additional Public Prosecutor
                                                          ORDER
[Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus Petition'
(hereinafter 'HCP' for the sake of convenience and clarity) was listed in the Admission Board on
31.03.2023, this Court made the following order:
'Captioned Habeas Corpus Petition has been filed in this Court on 23.03.2023 inter
alia assailing a detention order dated 27.02.2023 bearing Reference C.O.C.
No.07/2023 made by 'second respondent' [hereinafter 'Detaining Authority' for the
sake of convenience and clarity]. To be noted, fifth respondent is the Sponsoring
Authority.
2. Mother of the detenu is the petitioner.
3. Mr.M.Vinoth, learned counsel on record for habeas corpus petitioner is before us. Learned
counsel for petitioner submits that ground case qua the detenu is for alleged offences under Sections
147, 148, 341, 302 read with 149 of 'The Indian Penal Code (45 of 1860)' [hereinafter 'IPC' for the
sake of convenience and clarity] subsequently altered into one under Sections 147, 148, 302, 149,
120B, 342, 427, 294(b), 506(ii) IPC in Crime No.542 of 2022 on the file of Sirkazhi Police Station.
4. The aforementioned detention order has https://www.mhc.tn.gov.in/judis been made on the
premise that the detenu is a 'Goonda' under Section 2(f) of 'The Tamil Nadu Prevention of
Dangerous Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-offenders,
Goondas, Immoral traffic offenders, Sand-offenders, Sexual- offenders, Slum-grabbers and Video
Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake of
convenience and clarity].Gandhimathi vs The State Of Tamil Nadu Rep. By on 31 July, 2023

5. The detention order has been assailed inter alia on the ground that there is an inordinate delay in
passing the detention order.
6. Prima facie case made out for admission. Admit. Issue Rule nisi returnable by four weeks.
7. Mr.R.Muniyapparaj, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice for
all respondents. List the captioned Habeas Corpus Petition accordingly. '
2. The aforementioned order made in the 31.03.2023 Admission listing shall be read as an integral
part and parcel of this order which means that the short forms, short references and abbreviations
used in the order in the Admission listing shall be used in the instant order also.
3. There are two adverse cases. The ground case which constitutes substantial part of substratum of
the impugned preventive detention order is Crime No.542 of 2022 on the file of Sirkazhi Police
Station for the alleged offences under Sections 147, 148, 341, 302 read with 149 of IPC subsequently
altered into one under Sections 147, 148, 302, 149, 120B, 342, 427, 294(b) and 506(ii) IPC. Owing to
the nature of the challenge to the impugned https://www.mhc.tn.gov.in/judis preventive detention
order, it is not necessary to delve into the factual matrix or be detained further by facts.
4. Mr.M.Vinoth, learned counsel on record for petitioner and Mr.E.Raj Thilak, learned State
Additional Public Prosecutor for all respondents are before us.
5. As would be evident from paragraph 5 of the Admission Board order dated 31.03.2023, at the
time of admission, learned counsel for petitioner posited his argument on the point that there is
inordinate delay in passing the detention order, however, in the final hearing today, learned counsel
predicated his campaign against the impugned preventive detention order on the ground that
similar case relied on by the detaining authority to arrive at subjective satisfaction qua imminent
possibility of detenu being enlarged on bail is not really similar.
6. Elaborating on the above submission, learned counsel drew our attention to a portion of
paragraph 4 of the grounds of impugned preventive detention order and the same reads as follows:
https://www.mhc.tn.gov.in/judis '4...... In similar case (i.e)(1)Crime Number
358/2021 u/s 147, 148, 294(b), 452, 323, 324, 302 IPC of Mayiladuthurai Police
Station, bail was granted by the court of Hon'ble High Court, Chennai in
Crl.O.P.No.9350/2021 dated 23.08.2021 to an accused by name Thiru.Ranjith,
S/o.Neelamegam and (2) in Crime Number 692/2022 u/s 341, 294(b), 352, 506(ii),
302 IPC of Mayiladuthurai Police Station, bail was granted by the Court of Principal
District and Sessions Judge, Nagapattinam in Cr.M.P.No.03/2023 dated 12.01.2023
to an accused by name Thiru.Arul, S/o.Rayappan...'
7. It is clear from the aforementioned portion of paragraph 4 of the grounds of impugned preventive
detention order that the detaining authority has relied on two bail orders for arriving at
aforementioned subjective satisfaction. As regards the first of the bail orders, it is a bail order of aGandhimathi vs The State Of Tamil Nadu Rep. By on 31 July, 2023

Hon'ble Single Judge of this Court dated 23.08.2021 in Crl.O.P.No.9350 of 2021 (hereinafter
'Ranjith's case' for convenience as Ranjith is the petitioner in this case) but what has been furnished
to the detenu at pages 196 and 197 of the grounds booklet (Tamil translation at pages 198 and 199) is
not the bail order but an order relaxing condition/s of bail. To be noted, copy of bail order has not
been furnished to the detenu. Therefore, this clearly impairs the rights of the detenu to make an
https://www.mhc.tn.gov.in/judis effective representation against the impugned preventive
detention order and this further means that constitutional safeguard ingrained in Article 22(5) of
the Constitution of India and recognised in Section 8(1) of Act 14 of 1982 has been subjected to
infraction. This apart, there is yet another aspect of the matter. The relaxation (of bail conditions)
order has been made in Crl.M.P.No.8148 of 2021 in Crl.O.P.No.9350 of 2021 is dated 23.08.2021. A
careful perusal of the relaxation order brings to light that bail has been granted by a Hon'ble Single
Judge of this Court much earlier as one other condition had been relaxed on 19.05.2021 itself. This
means that detaining authority has got the bail order date also wrong in Ranjith's case. In other
words, the date of the bail order in Ranjith's case has been wrongly given as 23.08.2021 in the
grounds of impugned preventive detention order. This shows non-application of mind qua detaining
authority and it also baffles the detenu multiplying the infraction of Article 22(5) constitutional
principle which is statutorily recognised vide Section 8(1) of Act 14 of 1982.
8. In response to the above argument, learned Prosecutor submitted to the contrary saying that the
offence in Ranjith's case and the case on hand are comparable and what has happened is
https://www.mhc.tn.gov.in/judis only a secretarial error.
9. We carefully considered the submissions made on both sides. On a demurrer, even if the
argument that it is a secretarial error is accepted, the Prosecutor's endeavour to sustain the
impugned preventive detention order still does not cut ice as the bail order has not been furnished
to the detenu impairing the constitutional right (to make an effective representation against a
preventive detention order) which has been statutorily recognised as alluded to supra. This means
that the impugned preventive detention order is vitiated and the same deserves to be dislodged.
10. We are also informed without any disputation by both sides that co-accused in the ground case
were also clamped with identical preventive detention orders, co-accused assailed the same vide
H.C.P.Nos.428, 486 and 493 of 2023 and these HCPs were allowed in and by an order dated
31.07.2023 by this Bench on the same point.
11. Ergo, the sequitur is, captioned HCP is allowed. Apropos, impugned preventive detention order
dated 27.02.2023 bearing reference C.O.C.No.07/2023 made by the second respondent is set
https://www.mhc.tn.gov.in/judis aside and the detenu Thiru.Mendal Mani @ Manikandan, aged 25
years, son of Thiru.Velmurugan, is directed to be set at liberty forthwith, if not required in
connection with any other case / cases. There shall be no order as to costs.
(M.S.,J.) (R.S.V.,J.) 31.07.2023 Index : Yes Neutral Citation : Yes mmi P.S: Registry to forthwith
communicate this order to Jail authorities in Central Prison, Tiruchirappalli. ToGandhimathi vs The State Of Tamil Nadu Rep. By on 31 July, 2023

1.The Secretary to Government, Home, Prohibition and Excise Department, Fort St.George, Chennai
– 600 009.
2.The District Collector and District Magistrate, Mayiladuthurai District, Mayiladuthurai.
3.The Superintendent of Police, Mayiladuthurai District, Mayiladuthurai.
4.The Superintendent of Prison, Central Prison, Tiruchirappalli.
5.The Inspector of Police, Sirkazhi Police Station, Mayiladuthurai District.
6.The Public Prosecutor, High Court, Madras.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL , J., mmi 31.07.2023
https://www.mhc.tn.gov.in/judisGandhimathi vs The State Of Tamil Nadu Rep. By on 31 July, 2023

