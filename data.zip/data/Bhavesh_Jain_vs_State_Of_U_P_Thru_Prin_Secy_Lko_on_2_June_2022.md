Bhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June,
2022
Author: Vikas Kunvar Srivastav
Bench: Vikas Kunvar Srivastav
HIGH COURT OF JUDICATURE AT ALLAHABAD, LUCKNOW BENCH
Reserved
A.F.R.
Court No. - 31
Case :- APPLICATION U/S 482 No. - 2235 of 2022
Applicant :- Bhavesh Jain
Opposite Party :- State Of U.P. Thru. Prin. Secy. Lko.
Counsel for Applicant :- Satish Chandra Mishra, Neha Rashmi and Gantavya.
Counsel for opposite party :- Santosh Kumar Mishra (A.G.A.) 
Hon'ble Vikas Kunvar Srivastav,J.
1. The instant application moved under Section 482 Cr.P.C. is directed against the summoning order
dated 9.9.2021 issued in Session Case No.752 of 2021 titled "C.B.I. Vs. Md. Azam Khan etc" under
Sections 201, 204, 420, 467, 468, 471, 120-B I.P.C. and Section 66 of the I.T Act, 2000 and all orders
passed in furtherance whereof qua the applicant, "Bhavesh Jain" one of the accused charge sheeted
in Case Crime No.2 of 2018 in Session Case No.752 of 2021 pending before the Special Court,
Anti-Corruption, C.B.I. (Central), Lucknow.
2. It is stated in the application that the F.I.R. No.2 of 2018 was filed on 25.4.2018, alleging certain
irregularities in recruitment of candidates to 1300 posts of the R.G.C.'s, J.E.'s, A.E.'s advertised by
the U.P. Jal Nigam in the year 2016-2017. The said F.I.R. was filed against (i) Mr. Md. Azam Khan,Bhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

the then Chairman, U.P. Jal Nigam; (ii) Mr. Syed Aafaak Ahmad, the then O.S.D; (iii) Mr. Prakash
Singh, the then Secretary, Urban Development; (iv) Mr. P.K. Assudani, the then Managing Director,
U.P. Jal Nigam Ltd; (v) Mr. Anil Kumar Khare, the then Chief Engineer, U.P. Jal Nigam; (vi) other
officers of the U.P. Jal Nigam involved in the recruitment process. The allegation is, that the
aforesaid accused persons conducted the selection without taking prior approval of the Board of Jal
Nigam or the State Government causing a loss of Rs.37.5 Lacs to the State Exchequer and violate of
rules and regulations of the Jal Nigam including the U.P. Water Supply and Sewerage Act, 1975.
None of the allegations are attributable to the applicant nor he is alleged to be a beneficiary anyhow.
3. The company titled "Aptech" who was hired by the U.P. Jal Nigam under contract to organize and
develop the infrastructure for conducting the Computer Based Test (C.B.T.) for short listing of the
candidates, is also arraigned as accused in the F.I.R.
4. The said F.I.R. No.2 of 2018 was lodged by one Sri Ram Sevak Shukla, retired, approximately
eight years back, from the post of Executive Engineer, Jal Nigam, with some ulterior motive on
account of strong political rivalry and enmity between him and certain officers of U.P. Jal Nigam,
who were at the helm of affairs when the selections were conducted. Pursuant to the lodging of the
F.I.R. No.2 of 2018, the Special Investigation Team (S.I.T) was constituted, which investigated the
case for more than one and a half years, allegedly and apparently under the influence and control of
the persons on whose behest the F.I.R. was filed.
5. The applicant who is a mid-level employee of the Aptech group which was hired by U.P. Jal Nigam
for the limited purpose of organizing the infrastructure for conducting the Computer Based Test
(C.B.T) for the recruitment under the contract executed between U.P. Jal Nigam and Aptech.
Aptech's role was limited to facilitate the qualifying examination (C.B.T) and providing the
necessary I.T. infrastructure and software solution for the same. It had no role in the actual selection
of the candidates. The contracts effected the purpose of recruitment dated 17.6.2016, 28.10.2016
and 15.12.2016 respectively and the work order dated 19.5.2016 was issued theirfor.
6. The present applicant, as a matter of fact, is a Software Engineer. In the course of examination in
question (C.B.T.), he was serving as Deputy Manager, Software Development. His role was confined
to programming, Software and website development, which are purely technical in nature. He had
no role in setting the question papers, tabulation of scores, preparation of merit list, etc. Moreover,
the applicant did not have access either to the questions papers, or the result of the examination or
marks of the candidates, which were confidential documents/information stored in the password
protected files with strict access control. It is alleged by the applicant and stands un-rebutted in the
counter affidavit that the applicant was posted at Mumbai since 2003 and he had never visited the
State of U.P., much less Lucknow, when the examination was conducted on behalf of the U.P. Jal
Nigam. He had no interaction with the officials of the U.P. Jal Nigam or any candidate appearing in
the examination.
7. It is stated in the affidavit filed in support of the instant application under Section 482 Cr.P.C.
that the applicant was never served with the notice in the course of investigation by the S.I.T. and
merely on the telephonic request of the Investigating Officer made to Aptech, he gave his statementBhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

to the investigating officer on 12.9.2019, copy whereof is made Annexure No.4 to the affidavit.
Thereafter he has never summoned to participate in the Investigation or to provide any document or
information. Ultimately, the investigation was concluded sometimes in January, 2020 and the
charge sheet was submitted by the S.I.T. on 24.5.2021 which did not include the name of the
applicant as an accused. The court concerned took cognizance of the offences against the charge
sheeted accused namely Md. Azam Khan, Girish Chandra Srivastava under Sections 201, 204, 420,
467, 468, 471 I.P.C. read with Section 120-B I.P.C. and Section 13 of the Anti Corruption Act and
against the accused Neeraj Malik, Vishwajeet Singh, Ajay Kumar Yadav, Santosh Kumar Rastogi,
Roshan Fernandeez and Kuldeep Singh Negi under Sections 201, 204, 420, 467, 468, 471, 120-B
I.P.C. and Section 66 of the I.T. Act, 2000 on the basis of evidences collected by the Investigating
Officer and submitted before the court with the charge sheet. The court which took the cognizance of
the offence over the charge sheet dated 24.5.2021 without conducting any further investigation or
collecting any new material or evidence, when a supplementary charge sheet dated 12.8.2021 was
illegally filed by the Investigating Officer arraying the applicant as accused No.2, took cognizance of
the offences without evidences against him. The applicant has objected that in any event a prima
facie evaluation of the material and documents on record and the facts emerging therefrom, if taken
at their face value, do not disclose the existence of ingredients constituting the alleged offence or
even give rise to suspicion against the applicant and there did not exist sufficient grounds for
proceeding against him. In the absence of any specific allegations against the applicant disclosing
his active involvement in the alleged offences, the learned court below ought to have refused to take
cognizance of the offences against the applicant.
8. The applicant has submitted in the instant application that the recruitments in issue were entirely
an internal affair of the Jal Nigam conducted under the aegis of an internal examination committee
which oversaw the entire recruitment process and took all the decisions regarding the same. Under
the contracts executed between the Jal Nigam and Aptech, Aptech's role too was limited to facilitate
the conduct of the qualifying examination (C.B.T.) and providing the necessary I.T. infrastructure or
software solutions for the same, and it had no role in the actual selection of the candidates. The
applicant being employee of Aptech, had no role, whatsoever, in the conduct of the examination on
behalf of the U.P. Jal Nigam as a Software Engineer, his role was confined to programming
applications, software and website development, he is a technical professional and have no role in
setting the question papers, tabulation of scores, preparation of merit list, etc. Even he did not have
access the question paper or the result of the examination or marks of the candidates. The online
examination was conducted in accordance with the instructions of the U.P. Jal Nigam issued time to
time. The examinations were held on 5.8.2016 to 7.8.2016 (R.G.C.), 6.12.2016 to 7.12.2016 (J.E.)
and 16.12.2016 (A.E.). The Jal Nigam issued completion certificates for successful completion of the
exams which is also made Annexure No.9 to the affidavit.
9. It is alleged by the applicant that the impugned supplementary charge sheet was filed against him
containing vague allegations which are entirely false and baseless. In the charge sheet, it is alleged
that under the contract company was required to publish the answer key upon the conclusion of the
online examinations which it failed to do. As such, it is alleged that Aptech breached the contract
and connived with the officers of the U.P. Jal Nigam as a consequence whereof the candidates did
not get an opportunity to submit their objections on the question paper. Secondly, it been allegedBhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

the terms of the contract were breached by the Aptech and primary data of the examination was
deleted from the cloud server and valuable evidence was destroyed under a criminal conspiracy with
the Jal Nigam for unfair gain. It has also been alleged that the marks of 169 candidates have been
increased as a consequence whereof ineligible candidates were selected and eligible candidates were
deprived and being selected. He has further stated that no specific role in this regard has been
attributed to the applicant and there is not an iota of evidence linking the applicant with the
allegations. He had no concern with the conduct of the examination, publication of answer key,
inviting of objections, etc. There being no specific material or allegations against him, there is no
reason and justification to proceed against the applicant. To verify his position with regard to the
allegation of conspiracy the applicant has further stated in the affidavit that there is no whisper or
any prior meeting of minds between the applicant and officers of Jal Nigam and no "quid pro quo"
has been established. The applicant has never interacted with any officer of Jal Nigam or candidates
appearing in the examination either directly or indirectly. As such, the S.I.T. has conducted a sham
investigation and the entire impugned proceeding are purely based on conjectures and surmises,
and no offence under Section 120-B I.P.C. is made out. The applicant in the affidavit in support of
the application has further states that in February, 2017 after completion of the examination the
complete set of answer keys and response sheets of the examinations were handed over by the
Aptech to the M.D., Jal Nigam upon being so requested in a C.D. ROM together with cover letters
dated 18.3.2017 (R.G.C.), 27.2.2016 (J.E.) and 27.2.2017 (A.E.). The revised result was handed over
to the Managing Director, Jal Nigam vide letters dated 8.8.2017, 31.8.2017, 19.8.2017 and 8.8.2017.
However, for the reason best known to it the Jal Nigam never published the revised result, even with
regard to the allegations that the original/primary result data of the examination was removed by
the Aptech from the cloud server in connivance with the officers of the Jal Nigam. No role of the
applicant has been attributed in the charge sheet. The allegation is neither concerned with the
storage of data nor does he access to control of the computer system or computer network where the
data of the examination is stored. Moreover, as a matter of fact, the original data has not been
deleted and continues to be stored in the archives of the company in hard disks in its original format
under strict access control, as mandated by the internal data retention policy of the company. The
S.I.T. has been informed repeatedly and severally that original data of the examination is not deleted
and is available through various letters dated 7.11.2017 and e-mail dated 7.9.2018, 3.3.2020,
5.3.2020, 21.9.2020 and 3.11.2020. Yet for the reasons best known to it, S.I.T. has never collected
the original data, instead acting with apt premeditation and planned, it filed a false charge sheet
against the applicant on 12.8.2020 in submission to earlier one which is made Annexure No.14 and
15 to the affidavit in support of the application.
10. Counter affidavit on behalf of the State of U.P. filed in the matter has not factually any
differences with regard to the contract between the U.P. Jal Nigam and Aptech India Ltd. for
conducting C.B.T. for recruitment of post of R.G.C., J.E., A.E. in a selection for appointment of 1300
advertised posts. For ready reference, para-8 of the counter affidavit is thus reads as under:-
8& ;g fd mijksDRk p;u izfdz;k esa v/;{k] fo'ks"k dk;kZf/kdkjh] izcU/k funs'kd ty fuxe
,oa ty fuxe ds vU; vf/kdkfj;ksa }kjk fu;ekoyh dk mYya?ku dj euekus rjhds ls
vgZrk@;ksX;rk esa foKkiu ds ckn NsM+&NkM+ dh x;h rFkk vk'kqfyfid ijh{kk esa
fu/kkZfjr inksa ds lkis{k de ijh{kkFkhZ lQy gksus ij euekus 11. In para-9 of theBhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

counter affidavit without specifying any particular evidence with regard to the offence
alleged to have been committed by the applicant "Bhavesh Jain", it is alleged that he
has committed the following offences, (i) a conspiracy between U.P. Jal Nigam and
M/S Aptech Ltd., a collusion is evident from the fact of breach of contract between
them with regard to the recruitment on all the 1300 posts and not publishing the
answer key just after the completion of the exam and even then under a criminal
conspiracy to continue with the process of recruitment. (ii) in breach of conditions of
contract working against the rules for undue gain under a criminal conspiracy in
collusion with the U.P. Jal Nigam deleted the primary data from the cloud server and
thus destroyed a valuable evidence. (iii) that for an undue benefit committed the
criminal conspiracy during the course of recruitment process. (iv) the present
accused applicant whose name came into light in the course of investigation is
arrayed on the basis of evidences collected by the Investigating Officer under Section
201, 204, 420, 467, 468, 47/120-B I.P.C. and Section 66 of the I.T. Act and a
supplementary charge sheet was submitted on 12.4.2021 against him. Denying the
pleading of the accused applicant in his affidavit that S.I.T. has never bothered to
access the original data following due course of procedure, therefore, the allegation as
to the deletion of primary data and arraigning the charges under Section 201, 204,
120-B I.P.C. and Section 66 of the I.T. Act maliciously has stated that Aptech
company had deleted the primary data from the cloud server and in the course of
investigation whenever the company was asked to provide primary data, the officers
and employees of the company did not make available the same, therefore, the
accused is arraigned with Section 201, 204, 420, 467, 468 and 120-B I.P.C. and
Section 66 of the I.T. Act prima facie and further the primary data was recovered with
the help of the Forensic Science Laboratory.
12. In para 51 and 52 aforesaid the Aptech company as a whole is charged with
deletion of primary data, not providing the primary data despite repeated request by
the S.I.T., it is alleged without specifying with particular and visible role of the
present accused applicant.
13. Annexure No.3 to the counter affidavit has an importance for ascertaining the
admitted role and responsibility of each and every employee of Aptech associates
engaged for the examination in issue. Annexure No.3 is a document supplied by the
Aptech company on the requisition of S.I.T. For easy reference table in Annexure
No.3 is quoted as under:-
Role & Responsibilities of Associates w.r.t. U.P. Jal Nigam Project S. No. Resource
Name Designation Role & Responsibility Period of Deployment Present Address
Mobile No.
1.Bhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

Neeraj Malik Executive Vice President Head - Enterprise Business Group May 2016 to Nov 2017
Tata Primanti, Tower 7, House No.203, Sector-72, Gurugram-122101 9810814058
2. Vishwajeet Singh Vice-President (Head Delivery & Chief Information Officer) Responsible for
Operations and Delivery of UP Jal Nigam Project Aug 2016 to Nov 2017 Flat No.02012 ATS
Advantage Indirapuram Ghaziabad 201014 9810280264
3. Ajay Yadav Senior General Manger (Zonal Business Head) Responsible for Sales & Operations of
UP Jal Nigam Project May 2016 to Nov 2017 3/228, Viram Khand, Gomti Nagar, Lucknow 226010
9235501182
4. Santosh Kumar Rastogi Assistant General Manager (Regional Business Head) Responsible for
Sales & Account Management for UP Jal Nigam Project May 2016 to Nov 2017 3/74, Viram Khand,
Gomti Nagar, Lucknow 226010 9044211333
5. Amit Saini Senior General Manger - Technical Responsible for Technical Delivery for UP Jal
Nigam Project Dec 2016 to Nov 2017 C-205, Elite Homes, Indira College Road, near Akshara
International School, Tathawade, Pune-411033 7506513885
6. Roman Fernandes General Manager - Technical Responsible for Technical Delivery for UP Jal
Nigam Project May 2016 to Nov 2017 Mardes, Post-Nirmal, Tal-Vasai, Dist. Palghar, Pin 401304
8898845528
7. Bhavesh Jain Manager - Software Development Responsible for Development Support for UP Jal
Nigam Project May 2016 to Nov 2016 104 Janta Apartment, Dindayal Nagar, Vasai West.
7400427537
8. Jitendra Dixit Senior Executive - Software Development Responsible for Application
Management and Candidate scheduling for UP Jal Nigam Project May 2016 to Nov 2017 Room
No.503, Sai Pooja, Plot No.36, Sector 34, Kamothe Navi Mumbai 410209 9594353825/9323887819
9. Jagdish Sahu System Administrator Responsible for Infrastructure Support for UP Jal Nigam
Project May 2016 to Nov 2017 B-404, Sentosa Park, Ekta Parksville, Global City, Virar West, 401303
9920835967
10. Aftab Khan Deputy General Manager - Project & Operations Responsible for Project
Management (coordination between different departments within Aptech & Customer) & Zonal
Operations management for RGC for UP Jal Nigam Project May 2016 to Feb 2017 Rustomjee
Athena, D-201 Majiwada Thane (W) 400601 9820959711
11. Hemant Kandpal Assistant Manager - Projects Responsible for Project Management for AE & JE
(coordination between different departments within Aptech & Customer) for UP Jal Nigam Project
June 2016 to Nov 2017 67-Raipur, IIM road off Sitapur road, MVM School, Lucknow - 226020Bhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

7054199777
12. Pitam Singh Head - Content (Advisor) Responsible for Content Development for UP Jal Nigam
Project July 2016 to Mar 2017 3/36 Sector - 5 Rajinder Nagar Sahibabad Ghaziabad - 201005
9968275220/9540142522
13. Ratnarupa Ray General Manager - Content Authoring Responsible for Content Authoring for UP
Jal Nigam Project May 2016 to Mar 2017 402 A Poonam Darshan, Poonam Nagar, Andheri (E)
Mumbai - 400093 7400427524
14. Palak Maharishi Manager - Content Development Responsible for Content Development for UP
Jal Nigam Project May 2016 till Nov 2017 B-501, Himalaya Apartment, Sector - 5, Vasundhra,
Ghaziabad, UP 201012 9990743450
15. Dharmendra Singh Manager - Zonal Operations Responsible for Operations Management (JE &
AE) for UP Jal Nigam Project Sep 2016 to Nov 2017 136 Narain Nagar, Ravindrapalli, Lucknow,
U.P., 226016 8960003331
16. Kuldeep Negi Approved Vendor - Result Processing Responsible for Merit List Preparation for
RGC for UP Jal Nigam Project Jun 2016 to Nov 2016 C/O Sarvatra IT Services Pvt. Ltd. Head
Officer: SCO 86, Second Floor, Sector 22, Gurgaon-122016 0124-4239250
17. Ashok Upreti Approved Vendor Result Processing Responsible for Merit List Preparation for AE
& JE for UP Jal Nigam Project Dec 2016 to June 2017 C/O SARTHAK DATA SOLUTIONS PVT LTD
G-247 FIRST FLOOR, GAZIPUR, DELHI 110096 022 65286808
14. It is argued by learned Senior designated on behalf of the accused applicant "Bhavesh Jain" in
the instant application under Section 482 Cr.P.C. that the complaint itself has no allegation
individually or jointly with the other co-accused against the role of the applicant in making or
deleting the entries with regard to marks obtained by the candidates in C.B.T. The role of the
accused is very much specified in the Annexure No.3 annexed with the counter affidavit by the State
opposite party which is detailed against the name of "Bhavesh Jain, Manager- Software
Development, responsible for development support for U.P. Jal Nigam Project from May 2016 to
November 2016" at Sr. No.7.
15. On telephonic request the applicant presented himself before the S.I.T. and his statement was
recorded by the Investigating Officer where he stated about the work assigned to him which is made
Annexure No.4, the works assigned to him was (i) production and development of website (ii)
planning and explaining the work on the website to the colleagues in accordance with the approved
plan conduct of the work, etc. On the query of Investigating Officer of the S.I.T., his reply was
recorded on 12.9.2019 which may be seen at Annexure No.4 of the affidavit filed in support of the
application that the development work of the website with regard to the online form, admit card and
call letter in the recruitment process was done by him. It is also work that after the development of
the website the prescribed fields were to be filled up by the employee arrayed at Sr. No.8 inBhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

Annexure No.3 to the counter affidavit namely Jitendra Dixit, Kuldeep Negi at Sr. No.16 and Ashok
Upreti at Sr. No.17 as they were given responsibility for application management and candidate
scheduling, merit list preparation, etc. There is no iota of evidence against those collected by the
Investigating Officer which prima facie show the role or capacity to access the primary data filled in
the website even evidence of any conspiracy is also not given. As such, the learned court of
Magistrate did not apply his mind in taking cognizance over the charge sheet and issuance of
summon for trial. He relied on the case laws propounded by the Apex Court on the argument in
support of his argument that an employee of a company cannot be made accused without any
specific allegation or specific role attributed to them relying on Ravindranatha Bajpe Vs. Mangalore
Special Economic Zone Ltd. and Ors.1, State of Karnataka Vs. L. Muniswamy and Ors.2 in support
of the argument that where no material on record is available to show prima facie the complicity of
the accused or to suspect him for committing the offence. In this regard, Harishchandra Prasad
Mani and Ors. Vs. State of Jharkhand and Ors.3, Neelu Chopra Vs. Bharti4 and Mirza Iqbal Vs.
State of Uttar Pradesh5 placed before the court in support of his argument that particulars of
offences committed by each and every accused and role of accused must be demonstrated in the
charge sheet and where only vague and bald allegations are made no specific allegations against the
accused and there is no specific role against the accused, the candidates of relevant offences cannot
be taken by the Magistrate. Lastly, learned counsel submitted that a criminal proceeding cannot be
continued if there is no specific allegations against the accused, he relied on a judgment of Rekha
Jain Vs. State of Karnataka dated 10.5.2022 passed in Criminal Appeal No.749 of 2022 by the Apex
Court.
16. On the other hand, learned A.G.A. Sri Santosh Kumar Mishra, Advocate argued that police has
the statutory right and duty to investigate into a cognizable offence on complaint having been made
the result of investigation done by the S.I.T. brought into light the name of the accused as employee
of the company engaged by the Aptech company as Software Developer to fulfill its obligation under
the contract with the U.P. Jal Nigam to conduct C.B.T. for the recruitment of R.G.C., J.E. and A.E on
1300 posts advertised by the U.P. Jal Nigam. The allegations was that illegalities and irregularities
were committed in connivance with the officers of U.P. Jal Nigam by the Aptech company under a
conspiracy of which the present accused applicant was a participant, therefore, prima facie case
against the accused was made out and the charge sheet was submitted against him by the S.I.T.
whereupon cognizance was taken by the Magistrate and summons were issued.
17. Learned A.G.A. relying on the case law propounded by the Apex Court dated 20.4.2022 in
Ramveer Upadhyay and Ors. Vs. State of U.P. and Ors.6 submitted that the criminal proceedings
cannot be nipped in the bud by exercise of jurisdiction under Section 482 of the Cr.P.C. only because
the complaint has been lodged by a political rival, there would have been possibility of a false
complaint at the behest of a political opponent but the same would not be justified interference
under Section 482 of the Code of Criminal Procedure, 1973.
18. Learned A.G.A. has also relied on the judgments of Apex Court in Satish Kumar Jatav Vs. State
of U.P. and Ors.7 decided on 17.5.2022 and M/S Neeharika Infrastrucure Pvt. Ltd. Vs. State of
Maharashtra and Ors.8. He emphasized the argument that while examining the F.I.R./complaint
the court cannot embark upon an enquiry as to the reliability or genuineness or otherwise of theBhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

allegations made therein. Criminal proceeding ought not to be scuttled at the initial. Quashing of
complaint/FIR should be an exception rather than an ordinary rule.
19. Heard learned counsels, perused the materials available on record, gone through the cases cited
in support of their contentions.
20. In The State of Haryana Vs. Bhajanlal9 the scope of High Court power under Section 482 Cr.P.C.
and Article 226 of the Constitution of India was widely considered to quash the FIR and refer to
several judicial precedents and held that High Court should not embark upon an enquiry into the
merits and demerits of the allegations and quash the proceeding without allowing the investigating
agency to complete its task. At the same time, the Apex Court identified the following cases in which
FIR/complaint can be quashed. Para-102 of the aforesaid case is quoted below:-
"102. In the backdrop of the interpretation of the various relevant provisions of the
Code under Chapter XIV and of the principles of law enunciated by this Court in a
series of decisions relating to the exercise of the extraordinary power under Article
226 or the inherent powers under Section 482 of the Code which we have extracted
and reproduced above, we give the following categories of cases by way of illustration
wherein such power could be exercised either to prevent abuse of the process of any
court or otherwise to secure the ends of justice, though it may not be possible to lay
down any precise, clearly defined and sufficiently channelised and inflexible
guidelines or rigid formulae and to give an exhaustive list of myriad kinds of cases
wherein such power should be exercised.
(1) Where the allegations made in the first information report or the complaint, even
if they are taken at their face value and accepted in their entirety do not prima facie
constitute any offence or make out a case against the accused.
(2) Where the allegations in the first information report and other materials, if any,
accompanying the FIR do not disclose a cognizable offence, justifying an
investigation by police officers under Section 156(1) of the Code except under an
order of a Magistrate within the purview of Section 155(2) of the Code.
(3) Where the uncontroverted allegations made in the FIR or complaint and the
evidence collected in support of the same do not disclose the commission of any
offence and make out a case against the accused.
(4) Where, the allegations in the FIR do not constitute a cognizable offence but
constitute only a non-cognizable offence, no investigation is permitted by a police
officer without an order of a Magistrate as contemplated under Section 155(2) of the
Code.
(5) Where the allegations made in the FIR or complaint are so absurd and inherently
improbable on the basis of which no prudent person can ever reach a just conclusionBhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

that there is sufficient ground for proceeding against the accused.
(6) Where there is an express legal bar engrafted in any of the provisions of the Code
or the concerned Act (under which a criminal proceeding is instituted) to the
institution and continuance of the proceedings and/or where there is a specific
provision in the Code or the concerned Act, providing efficacious redress for the
grievance of the aggrieved party.
(7) Where a criminal proceeding is manifestly attended with mala fide and/or where
the proceeding is maliciously instituted with an ulterior motive for wreaking
vengeance on the accused and with a view to spite him due to private and personal
grudge."
21. In Inder Mohan Goswami Vs. State of Uttarakhand10 Apex court in para-27 has observed as
under:-
27. The powers possessed by the High Court under Section 482 of the Code are very
wide and the very plenitude of the power requires great caution in its exercise. The
Court must be careful to see that its decision in exercise of this power is based on
sound principles. The inherent power should not be exercised to stifle a legitimate
prosecution. The High Court should normally refrain from giving a prima facie
decision in a case where all the facts are incomplete and hazy, more so, when the
evidence has not been collected and produced before the Court and the issues
involved, whether factual or legal, are of such magnitude that they cannot be seen in
their true perspective without sufficient material. Of course, no hard-and-fast rule
can be laid down in regard to cases in which the High Court will exercise its
extraordinary jurisdiction of quashing the proceedings at any stage.
22. In Indian Oil Corporation Vs. NEPC India Ltd. and Ors.11 formulated guiding principles for
exercise of power under Section 482 Cr.P.C. in following terms:-
"12. ... (i) A complaint can be quashed where the allegations made in the complaint,
even if they are taken at their face value and accepted in their entirety, do not prima
facie constitute any offence or make out the case alleged against the accused. For this
purpose, the complaint has to be examined as a whole, but without examining the
merits of the allegations. Neither a detailed inquiry nor a meticulous analysis of the
material nor an assessment of the reliability or genuineness of the allegations in the
complaint, is warranted while examining prayer for quashing of a complaint.
(ii) A complaint may also be quashed where it is a clear abuse of the process of the
court, as when the criminal proceeding is found to have been initiated with
malafides/malice for wreaking vengeance or to cause harm, or where the allegations
are absurd and inherently improbable.Bhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

(iii) The power to quash shall not, however, be used to stifle or scuttle a legitimate
prosecution. The power should be used sparingly and with abundant caution.
(iv) The complaint is not required to verbatim reproduce the legal ingredients of the
offence alleged. If the necessary factual foundation is laid in the complaint, merely on
the ground that a few ingredients have not been stated in detail, the proceedings
should not be quashed. Quashing of the complaint is warranted only where the
complaint is so bereft of even the basic facts which are absolutely necessary for
making out the offence.
(v) .."
23. In the State of M.P. Vs. Awadh Krishna Gupta and Ors.12, in para-11 it is held:-
"11. The powers possessed by the High Court under Section 482 of the Code are very
wide and the very plenitude of the power requires great caution in its exercise. Court
must be careful to see that its decision in exercise of this power is based on sound
principles. The inherent power should not be exercised to stifle a legitimate
prosecution. High Court being the highest Court of a State should normally refrain
from giving a prima facie decision in a case where the entire facts are incomplete and
hazy, more so when the evidence has not been collected and produced before the
Court and the issues involved, whether factual or legal, are of magnitude and cannot
be seen in their true perspective without sufficient material. Of course, no hard and
fast rule can be laid down in regard to cases in which the High Court will exercise its
extraordinary jurisdiction of quashing the proceeding at any stage.
In proceeding instituted on complaint, exercise of the inherent powers to quash the
proceedings is called for only in a case where the complaint does not disclose any
offence or is frivolous, vexatious or oppressive. If the allegations set out in the
complaint do not constitute the offence of which cognizance has been taken by the
Magistrate, it is open to the High Court to quash the same in exercise of the inherent
powers under Section 482 of the Code.
24. Further in G. Sagar Suri & Anr. Vs. State of U.P. & Ors.13 it is observed that it is the duty and
obligation of the criminal court to exercise a great deal of caution in issuing the process, particularly
when matters are essentially of civil nature.
25. At the very outset the present accused applicant in the complaint he is alleged individually or
jointly with the other co-accused responsible for the offence punishable under Sections 201, 204,
420, 467, 468, 471, 120-B I.P.C. and Section 66 of the I.T Act, 2000, therefore, it is also imperative
to examine the ingredients of the said offences and whether the allegations made in the complaint,
read on their face, attract those offences under the penal code. Out of the aforesaid offences with
which the present accused applicant "Bhavesh Jain" is arraigned if Section 420, 467, 468, 471 and
120-B I.P.C. are taken at first for the purpose of consideration.Bhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

26. Before proceeding with the discussion Section 415 of the I.P.C. which defines cheating needs to
be quoted here below:-
"415. Cheating.--Whoever, by deceiving any person, fraudulently or dishonestly
induces the person so deceived to deliver any proper−ty to any person, or to consent
that any person shall retain any property, or intentionally induces the person so
deceived to do or omit to do anything which he would not do or omit if he were not so
deceived, and which act or omission causes or is likely to cause damage or harm to
that person in body, mind, reputation or property, is said to "cheat"."
27. The Apex Court in Vijay Kumar Ghai and Ors. Vs. State of West Bengal & Ors. in Criminal
Appeal No. 463 of 2022 decided on 22.3.2022 in para 27, 28, 29, 30, 31, 32, 33 and 35 observed as
under:-
"27. Section 415 of IPC define cheating which reads as under: -
"415. Cheating. --Whoever, by deceiving any person, fraudulently or dishonestly
induces the person so deceived to deliver any property to any person, or to consent
that any person shall retain any property, or intentionally induces the person so
deceived to do or omit to do anything which he would not do or omit if he were not so
deceived, and which act or omission causes or is likely to cause damage or harm to
that person in body, mind, reputation or property, is said to "cheat"." The essential
ingredients of the offense of cheating are:
1. Deception of any person
2. (a) Fraudulently or dishonestly inducing that person-
       (i)      to deliver any property to any person: or
       (ii)     to consent that any person shall retain any property; or
(b) intentionally inducing that person to do or omit to do anything which he would
not do or omit if he were no so deceived, and which act or omission causes or is likely
to cause damage or harm to that person in body,mind,reputation or property.
28. A fraudulent or dishonest inducement is an essential ingredient of the offence. A person who
dishonestly induces another person to deliver any property is liable for the offence of cheating.
29. Section 420 IPC defines cheating and dishonestly inducing delivery of property which reads as
under: -
"420. Cheating and dishonestly inducing delivery of property. --Whoever cheats and
thereby dishonestly induces the person deceived to deliver any property to anyBhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

person, or to make, alter or destroy the whole or any part of a valuable security, or
anything which is signed or sealed, and which is capable of being converted into a
valuable security, shall be punished with imprisonment of either description for a
term which may extend to seven years, and shall also be liable to fine."
30. Section 420 IPC is a serious form of cheating that includes inducement (to lead or move
someone to happen) in terms of delivery of property as well as valuable securities. This section is
also applicable to matters where the destruction of the property is caused by the way of cheating or
inducement. Punishment for cheating is provided under this section which may extend to 7 years
and also makes the person liable to fine.
31. To establish the offence of Cheating in inducing the delivery of property, the following
ingredients need to be proved:-
1. The representation made by the person was false
2. The accused had prior knowledge that the representation he made was false.
3. The accused made false representation with dishonest intention in order to deceive
the person to whom it was made.
4. The act where the accused induced the person to deliver the property or to perform
or to abstain from any act which the person would have not done or had otherwise
committed.
32. As observed and held by this Court in the case of Prof. R.K. Vijayasarathy & Anr. Vs. Sudha
Seetharam & Anr. 24 , the ingredients to constitute an offence under Section 420 are as follows:-
i) a person must commit the offence of cheating under Section 415;
and
ii) the person cheated must be dishonestly induced to;
a) deliver property to any person; or
b) make, alter or destroy valuable security or anything signed or sealed and capable of being
converted into valuable security. Thus, cheating is an essential ingredient for an act to constitute an
offence under Section 420 I.P.C.
33. The following observation made by this Court in the case of Uma Shankar Gopalika Vs. State of
Bihar & Anr. 25 with almost similar facts and circumstances may be relevant to note at this stage:-Bhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

"6. Now the question to be examined by us is as to whether on the facts disclosed in
the petition of the complaint any criminal offence whatsoever is made out much less
offences under Section 420/120-B IPC. The only allegation in the complaint
petitioner against the accused person is that they assured the complainant that when
they receive the insurance claim amounting to Rs. 4,20,000, they would pay a sum of
Rs. 2,60,000 to the complainant out of that but the same has never been paid. It was
pointed out that on behalf of the complainant that the accused fraudulently
persuaded the complainant to agree so that the accused persons may take steps for
moving the consumer forum in relation to the claim of Rs. 4,20,0000. It is well
settled that every breach of contract would not give rise to an offence of cheating and
only in those cases of breach of contract would amount to cheating where there was
any deception played at the very inception. If the intention to cheat has developed
later on, the same cannot amount to cheating. In the present case, it has nowhere
been stated that at the very inception that there was intention on behalf of the
accused person to cheat which is a condition precedent for an offence under 420 IPC.
"7. In our view petition of complaint does not disclose any criminal offence at all
much less any offence either under Section 420 or Section 120-B IPC and the present
case is a case of purely civil dispute between the parties for which remedy lies before
a civil court by filing a properly constituted suit. In our opinion, in view of these facts
allowing the police investigation to continue would amount to an abuse of the process
of court and to prevent the same it was just and expedient for the High Court to
quash the same by exercising the powers under Section 482 Cr.P.C which it has
erroneously refused."
35. In Vesa Holdings Pvt. Ltd. & Anr. Vs. State of Kerala & Ors. 27, this Court made the following
observation:-
"13. It is true that a given set of facts may make out a civil wrong as also a criminal
offence and only because a civil remedy may be available to the complainant that
itself cannot be ground to quash a criminal proceeding. The real test is whether the
allegations in the complaint disclose the criminal offence of cheating or not. In the
present case, there is nothing to show that at the very inception there was any
inception on behalf of an accused person to cheat which is a condition precedent for
an offence u/s 420 IPC. In our view, the complaint does not disclose any criminal
offence at all. Criminal proceedings should not be encouraged when it is found to be
mala fide or otherwise an abuse of the process of the courts. Superior courts while
exercising this power should also strive to serve the ends of justice. In our opinion, in
view of these facts allowing the police investigation to continue would amount to an
abuse of the process of the court and the High Court committed an error in refusing
to exercise the power under Section 482 Cr.P.C to quash the proceedings."
28. Having gone through the complaint/FIR and even the charge sheet it cannot be said that
avernments made therein bear the allegations against the present accused applicant have primaBhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

facie constituted an offence under Section 420 I.P.C., even in a case where allegations are made in
regard to the irregularity and illegality committed by the company as a whole in the process of
recruitment through C.B.T. The role and responsibility with which the present accused applicant is
entrusted has nowhere his access to the primary datas filled in the prescribed fields of the website,
therefore, in the absence of a culpable role no offence under Section 420 I.P.C. said to have been
made out. In the instant case there is no material to indicate that the present accused applicant had
any malafide intention against the U.P. Jal Nigam or the candidates appearing in the C.B.T. or
against the unsuccessful candidates who appeared in the C.B.T. and some malafide intention or
undue favour with regard to the some illegal gaining undue benefit from the successful candidates in
exclusion to other candidates.
29. For easy reference sections 467, 468, 471 I.P.C. are quoted hereunder:-
467. Forgery of valuable security, will, etc.--Whoever forges a document which
purports to be a valuable security or a will, or an authority to adopt a son, or which
purports to give authority to any person to make or transfer any valuable security, or
to receive the principal, interest or dividends thereon, or to receive or deliver any
money, movable property, or valuable security, or any document purporting to be an
acquittance or receipt acknowledging the payment of money, or an acquittance or
receipt for the delivery of any movable property or valuable security, shall be
punished with 1[imprisonment for life], or with imprisonment of either description
for a term which may extend to ten years, and shall also be liable to fine.
468. Forgery for purpose of cheating.--Whoever commits forgery, intending that the
1[document or electronic record forged] shall be used for the purpose of cheating,
shall be punished with imprisonment of either de−scription for a term which may
extend to seven years, and shall also be liable to fine.
471. Whoever fraudulently or dishonestly uses as genuine any document which he
knows or has reason to believe to be a forged document, shall be punished in the
same manner as if he had forged such document.
30. On perusal of the impugned order dated 9.9.2021 passed by the Special Judge, Anti Corruption
(C.B.I.), Central, Lucknow, it is simply stated therein that cognizance of offences under Section 201,
204, 420, 467, 468, 471 and 120-B I.P.C. read with Section 66 of the I.T. Act, 2000 is taken on the
basis of oral and documentary evidences.
31. Before considering the allegations or facts prima facie constituting the offences under Sections
467, 468, 471 I.P.C. it would be pertinent to go into the definition of forgery as defined under
Section 463 I.P.C. For easy reference Section 463 I.P.C. is quoted hereunder:-
"463. Forgery- Whoever makes any false documents or false electronic record or part
of a document or electronic record, with intent to cause damage or injury, to the
public or to any person, or to support any claim or title, or to cause any person to partBhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

with property, or to enter into any express or implied contract, or with intent to
commit fraud or that fraud may be committed, commits forgery."
The essential ingredients of offence under Section 463 I.P.C. are-
(1) A person makes any document or part of a document.
(2) The document or false electronic record or part of the document or electronic record must be
false.
(3) With intention-
(a) to cause damage or injury to the public or any person; or
(b) to support any claim or title; or
(c) to cause any person to part with his property; or
(d) to enter into any express or implied contract to commit any fraud or that fraud may be
committed.
In furtherance of above essential ingredients the making of false document is also defined under
Section 464 of the I.P.C. according to which dishonest or fraudulent-
(i) making of the false document or false electronic record, signs, seals or executes a document or
part of a document.
(ii) making or transmitting any electronic record or part of any electronic record.
(iii) affixing any digital signature on any electronic record.
(iv) making any mark denoting the execution of a document or the authenticity of the electronic
signature.
Section 467 I.P.C. contemplates forgery of documents which purports to be a valuable security or a
will, or an authority to adopt a son, or which purports to give authority to any person to make or
transfer any valuable security ........ to receive or deliver any money, movable property or valuable
security ....... or receipt acknowledging the payment of money. Likewise who ever fraudulently or
dishonestly uses as genuine any document or any electronic record which he knows or has reason to
believe to be a forged document or electronic record.
32. No evidence, oral or documentary, is referred in the impugned order of taking cognizance of the
charge sheet which also did not include the evidence as to the applicant's alleged or suspected role of
execution, making any false document or false electronic record by making signature, putting sealsBhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

or transmitting any electronic record wholly or partly or affixing any e-signature on any electronic
record or making any mark denoting the execution of any document specifically assigned to have
been committed individually or in connivance with any of the other accused persons. Even no
specific allegation is made in the complaint. The documentary evidence in the form of statement of
present accused-applicant recorded by the Investigating Officer of S.I.T. and the list of employees
engaged by the Aptech company in the project of U.P. Jal Nigam for conducting the C.B.T. to select
and recruit R.G.C., J.E. and A.E. on 1300 posts. The said record specifically refers the role to present
accused applicant at Sr. No.7 as Manager- Software Development, responsible for development
support for U.P. Jal Nigam Project from May 2016 to November 2016.
33. There is no further evidence as to any other acts assigned to or done by the present
accused-applicant, "Bhavesh Jain" except the development of software and handing over them to
the other responsible employees of Aptech company referred in the document dated 4.9.2019,
Annexure No.3 to the counter affidavit.
34. Even prima facie evidence also is not on record against the present accused-applicant with
regard to his access in any capacity to the website for making relevant entries or deleting the
primary datas filled by other responsible employees in the prescribed fields of the website developed
by him. The work of entry is assigned to Vishwajeet Singh at Sr. No.2, Jitendra Dixit at Sr. No.8,
Kuldeep Negi at Sr. No.16 and Ashok Utpreti at Sr. No.17 in annexure no.3 of the counter affidavit,
shown responsible for operation and delivery of contracted project of the U.P. Jal Nigam,
application management and candidates' scheduling and preparing the merit list of the R.G.C's,
A.E.'s and J.E.'s in the project individually and collectively. Except the aforesaid document which is
annexed to the counter affidavit as Annexure No.3 no other documentary evidence specifying the
role of present accused-applicant and activities done by him under the project is included in the
charge sheet, submitted by the Investigating Officer before the court concerned, after completing the
investigation.
35. The Special Court (C.B.I.) has, thus correctly did not take cognizance vide its first order dated
15.7.2021 of offences against the present accused in issue, and took cognizance on the basis of
available evidences only against Md. Azam Khan, Girish Chandra Srivastava, Neeraj Malik,
Vishwajeet Singh, Ajay Kumar Yadav, Santosh Kumar Rastogi, Roshan Fernandeez and Kuldeep
Singh Negi, in various provisions of the I.P.C. and Information Technology Act, 2000 and Section 13
of the Anti Corruption Act. Peculiarly enough subsequent to the submission of first charge sheet,
though no further or new evidences were collected by the Investigating Officer but the
supplementary charge-sheet dated 12.8.2021 was brought on record, placed before the concerned
court which without applying it's mind took cognizance vide the impugned summoning order dated
9.9.2021, against the present accused-applicant also.
36. This would be important to refer an admitted fact, that present accused-applicant was never
posted in Lucknow, his place of posting was in Bombay. Neither there is allegation nor evidence oral
or documentary with regard to any premeditated plan between the applicant and other accused
persons to assist in the forgery alleged to have been committed by the two companies, U.P. Jal
Nigam and Aptech India Ltd. in connivance with each other. Two companies were under a contractBhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

executed legally to conduct examination through C.B.T. for recruitment of employees on 1300 posts
of R.G.C., J.E. and A.E. in U.P. Jal Nigam. It is alleged in the affidavit in support of the application
and also in counter affidavit, that irregularities and illegalities were committed in execution of the
works performed under the contract by both the parties to the contract, in breach of the conditions
stipulated in the contract. Higher officials of both the corporations are alleged and found prima facie
to have breached the conditions under the contract knowingly, willfully and dishonestly, but no civil
action or departmental disciplinary inquiry, if taken, are brought on the record with their
conclusions. In the absence of any prima facie evidence on record of the charge sheet and in the
counter affidavit of the opposite parties also, so as to gather inference of the suspected involvement
of the present accused-applicant in conspiracy with any of the officers, officials and employees,
found prima facie guilty in committing the irregularities and illegalities in the process of recruitment
process under the contract. It seems that the present accused-applicant unnecessarily brought into
the next of implication without logical and legal reasons and basis.
37. Thus, the facts mentioned in the complaint and in both the charge sheets submitted by the
Investigating Officer of the S.I.T. are not disclosing the commission of any cognizable offence under
the relevant sections of the I.P.C. with which the present accused-applicant is arraigned and,
therefore, the cause of action clearly arose for him to challenge the continuance of criminal
proceeding in the impugned order of cognizance dated 9.9.2021.
38. In view of the above facts and discussions the impugned summoning order dated 9.9.2021
passed by the learned Special Court, Anti-corruption, C.B.I. Central, Lucknow is set aside to the
extent of the applicant "Bhavesh Jain" and all the orders passed in furtherance whereof and the
entire subsequent proceedings in Sessions Case No. 752 of 2021 (C.B.I. Vs. Mohd. Azam Khan, etc.)
under Sections 201, 204, 420, 467, 468, 471, 120-B I.P.C. and Section 66 of the I.T Act, 2000 against
the accused applicant arising out of F.I.R. lodged on 25.4.2018 bearing No.2 of 2018 registered at
Police Station- S.I.T. Sadar, Lucknow pending in the court of learned Special Court,
Anti-Corruption, C.B.I. (Central), Lucknow to the extent of present accused applicant "Bhavesh
Jain" are quashed.
39. Accordingly, the application under Section 482 Cr.P.C. is allowed.
Order Date :- 2.6.2022 Gaurav/-
(Vikas Kunvar Srivastav, J.)    Bhavesh Jain vs State Of U.P. Thru. Prin. Secy. Lko. on 2 June, 2022

