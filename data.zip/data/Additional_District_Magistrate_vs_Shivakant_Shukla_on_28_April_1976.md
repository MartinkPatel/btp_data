Additional District Magistrate, ... vs Shivakant Shukla on 28
April, 1976
Equivalent citations: AIR1976SC1207, 1976CRILJ945, (1976)2SCC521,
[1976]SUPPSCR172, 1976(8)UJ610(SC), AIR 1976 SUPREME COURT 1207,
1976 3 SCC 454, 1976 SCC (CRI) 448, 1976 CRI APP R (SC) 298, 1976 2 SCC
521, 1976 SC CRI R 277, 1976 3 SCR 929, 1976 UJ (SC) 610
Author: A.N. Ray
Bench: A.N. Ray, H.R. Khanna, M.H. Beg, P.N. Bhagwati, Y.V. Chandrachud
JUDGMENT
A.N. Ray, C.J.
1. These appeals are by certificates in some cases and by leave in other cases. The State is the
appellant. The respondents were petitioners in the High Courts.
2. The respondents filed applications in different High Courts for the issue of writ of habeas corpus.
They challenged in some cases the validity of the 38th and the 39th Constitution Amendment Acts,
the Proclamation of Emergency by the President under Article 352 of the Constitution made on 25
June, 1975. They challenged the legality and validity of the orders of their detention in all the cases.
3. The State raised a preliminary objection that the Presidential Order dated 27 June, 1975 made
under Article 359 of the Constitution suspending the detenus right to enforce any 01 the rights
conferred by Articles 14, 21 and 22 of the Constitution and the continuance of emergency during
which by virtue of Article 358 all rights conferred by Article 19 stand suspended are a bar at the
threshold for the respondents to invoke the jurisdiction of the High Court under Article 226 of the
Constitution and to ask for writs of habeas corpus.
4. The judgments are of the High Courts of Allahabad, Bombay (Nag-pur Bench), Delhi, Karnataka,
Madhya Pradesh, Punjab and Rajasthan.
5. The High Courts held that notwithstanding the continuance of emergency and the Presidential
Order suspending the enforcement of fundamental rights conferred by Articles 14, 21 and 22 the
High Courts can examine whether an order of detention is in accordance with the provisions of the
Maintenance of Internal Security Act (hereinafter referred to as the Act), which constitute the
conditions precedent to the exercise of powers thereunder excepting those provisions of the Act
which are merely procedural or whether the order was made malafide or was made on the basis ofAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

relevant materials by which the detaining authority could have been satisfied that the order was
necessary: The High Courts also held that in spite of suspension of enforcement of fundamental
rights conferred by Articles 21 and 22 of the Constitution a person's right to freedom from arrest or
detention except in accordance with law can be enforced only where such arrest and detention are
not in accordance with those provisions of the statute which form the conditions precedent to the
exercise of power under that statute as distinguished from merely procedural provisions or are
malafide or are not based on relevant materials by which the detaining authority could have been
satisfied that the order of detention was necessary.
6. The High Courts held that the High Courts could not go into the questions whether the
Proclamation of Emergency was justified or whether the continuance thereof was malafide.
7. The High Courts did not decide about the validity of the 38th and the 39th Constitution
Amendment Acts. The 38th Constitution Amendment Act amended Articles 123, 213, 239(b), 352,
356, 359 and 360. Broadly stated, the 38th Constitution Amendment Act renders the satisfaction of
the President or the Governor in the relevant Articles final and conclusive and to be beyond any
question in any Court on any ground. As for Article 359 Clause (1A) has been inserted by the 38th
Constitution Amendment Act. The 39th Constitution Amendment Act amended Articles 71, 329. 329
(A) and added Entries after Entry 86 in the Ninth Schedule.
8. No arguments were advanced on these Constitution Amendment Acts and nothing thereon falls
for determination in these appeals.
9. It is appropriate to mention here that on 3 December, 1971 in exercise of powers conferred by
Clause (1) of Article 352 of the Constitution the President by Proclamation declared that a grave
emergency exists whereby the security of India is threatened by external aggression.
10. On 25 June, 1975 the President in exercise of powers conferred by Clause (1) of Article 352 of the
Constitution declared that a grave emergency exists whereby the security of India is threatened by
internal disturbances.
11. On 27 June, 1975 in exercise of powers conferred by Clause (1) of Article 359 the President
declared that the right of any person including a foreigner to move any Court for the enforcement of
the rights conferred by Article 14, Article 21 and Article 22 of the Constitution and all proceedings
pending in any Court for the enforcement of the above-mentioned rights shall remain suspended for
the period during, which the Proclamations of Emergency made under Clause (1) of Article 352 of
the Constitution on 3 December, 1971 and on 25 June, 1975 are both in force. The Presidential Order
of 27 June, 1975 further stated that the same shall be in addition to and not in derogation of any
Order made before the date of the aforesaid Order under Clause (1) of Article 359 of the
Constitution.
12. It should be noted here that on 8 January, 1976 there was a notification that in exercise of
powers conferred by Clause (1) of Article 359 of the Constitution the President declares that the
right of any person to move any Court for the enforcement of the rights conferred by Article 19 of theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Constitution and all proceedings pending in any Court for the enforcement of the above-mentioned
rights shall remain-suspended for the period during which the Proclamation of Emergency made
under Clause (1) of Article 352 of the Constitution on 3 December, 1971 and on 25 June, 1975 are in
force.
13. The questions which fall for consideration are two . First, whether in view of the Presidential
Orders dated 27 June, 1975 and 8 January, 1976 under Clause (1) of Article 359 of the Constitution
any writ petition under Article 226 before a High Court for habeas corpus to enforce the right to
personal liberty of a person detained under the Act on the ground that the order of detention or the
continued detention is for any reason not under or in compliance with the Act is maintainable.
Second, if such a petition is maintainable what is the scope or extent of judicial scrutiny particularly
in view of the Presidential Order dated 27 June, 1975 mentioning, inter alia, Article 22 of the
Constitution and also in view of Sub-section (9) of Section 16A of the Act.
14. The Attorney General contended that the object and purpose of emergency provisions is that the
Constitution provides special powers to the Executive because at such tunes of emergency the
considerations of State assume importance. It has been recognised that times of grave national
emergency demand grant of special power to the Executive. Emergency provisions contained in Part
XVIII including Articles 358,, 359(1) and 359(1 A) are constitutional imperatives. The validity of law
cannot be challenged on the ground of infringing a fundamental right mentioned in the Presidential
Order under Article 359(1). Similarly, if the Executive took any action depriving a person of a
fundamental right mentioned in the Presidential Order by not complying with the law such
Executive action could not be challenged because such challenge would amount in substance to and
would directly impinge on the enforcement of fundamental rights mentioned in the Presidential
Order. The reason given by the Attorney General behind the principle is that in times of emergency
the Executive safeguards the life of the nation. Challenge to Executive actions either on the ground
that these are arbitrary or unlawful has been negatived in England in Liversidge v. Anderson [1942]
A. C. 206 and Greene v. Secretary of State for Home Affairs [1942] A. C. 284 and also by this Court
in Sree Mohan Chowdhury v. The Chief Commissioner, Union Territory of Tripura and Makhan
Singh v. State of Punjab .
15. The contentions of the respondents are as follows : The arguments on behalf of the State mean
that during the emergency there is no right to life or liberty. Article 358 is more extensive as the
fundamental right itself is suspended. The Presidential Order under Article 359(1) does not suspend
any fundamental right.
16. Second, the object of Article 359(1) is to bar moving the Supreme Court under Article 32 for the
enforcement of certain specified rights without affecting in any manner the enforcement of common
law and statutory rights to personal liberty under Article 226 before the High Court.
17. Third, Article 359(1) removes the fetter in Part III but does not remove the fetters arising from
the principles of limited power of the Executive under the system of checks and balances based on
separation of powers.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

18. Fourth, while the Presidential Order operates Only in respect of fundamental rights mentioned
in the Presidential Order it would not affect the rights of personal liberty at common law or under
statute law or under natural law.
19. Fifth, Article 359(1) is not to protect illegal orders of the Executive. The Executive cannot flout
the command of Parliament relying on a Presidential Order under Article 359(1). The suspension of
fundamental right or of its enforcement cannot increase the power of the -Executive vis-a-vis the
individual.
20. Sixth, there is no reason to equate the State with the Executive. The suspension of the
fundamental right or the right to enforce it has only this consequence that it enables the Legislature
to make laws violative of the suspended fundamental rights and the Executive to implement such
laws. The suspension of the fundamental right does not enable the Executive to flout legislative
mandates and judicial decisions.
21. Seventh, the Executive can act to the prejudice of citizens only to the extent permitted by valid
laws. The Proclamation of Emergency does not widen the Executive power of the State under Article
162 so as to empower the State to take any Executive action which it is not otherwise competent to
take.
22. Eighth, the right to arrest is conferred by the Act on the States and their officers only if the
conditions laid down under Section 3 of the Act are fulfilled. Therefore, if the conditions laid down
under Section 3 of the Act are not complied with by the detaining authority then the order of
detention would be ultra vires the said Act.
23. Ninth, Habeas corpus is a remedy not only for the enforcement of the right to personal liberty,
whether under natural law or a statute, but is also a remedy for the enforcement of the principle of
ultra vires, viz., when the detaining authority has failed to comply with the conditions laid down in
section 3 of the Act. In such a case the High Court has jurisdiction to issue a writ of habeas corpus
for the enforcement of the principle of ultra vires.
24. In England it was the practice in tunes of danger to the State to pass what were popularly known
as Habeas Corpus Suspension Acts. Suspension did not legalise illegal arrest; it merely suspended a
particular remedy in respect of particular offences. Accordingly it was the practice in England at the
close of the period of suspension to pass an Indemnity Act in order to protect official- concerned
from the consequences of any incidental illegal acts which they might have committed under cover
of the suspension of the prerogative writ.
25. In England the Defence of the Realm Acts 1914-18 empowered the Executive to make regulations
by Order in Council for securing the public safety or for the defence of 'the realm. In The King v.
Holiday Ex parte Zadiq [1917] A.C. 260 the House of Lords held that a regulation was valid which
authorised the Secretary of State to detain a British subject on the grounds of ins hostile origin or
association. It was contended on behalf of Zadiq that there was no provision for imprisonment
without trial. The substantial contention was that general words in a statute could not take away theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

vested right of a subject or alter the fundamental law of the Constitution because it would be
repugnant to the constitutional tradition of the country. The majority of the court swept aside these
arguments and held that on the construction of the Act the Executive had unrestricted powers.
26. During the Second World War the Emergency Powers (Defence) Act, 1939 in England
empowered the making of regulations for the detention of persons by the Secretary of State in the
interests of the public safety or the defence of the realm, and for authority to enter and search any
premises.
27. Although access to the courts was not barred during the Second World War in England the scope
for judicial review of executive action was limited. The courts could not consider whether a
particular regulation is necessary or expedient for the purpose of the Act which authorised it. The
question of necessity or expediency was one for the Government to decide. The court could,
however, hold an act to be illegal as being not authorised by the regulation relied upon to justify it. .
28. It was open to the subject in England to challenge detention by application for a writ of habeas
corpus, but such application had little chance of success in view of the decision of the House of
Lords in Liversidge's case (supra). The House of Lords took the view that the power to detain could
not be controlled by the courts, if only because considerations of security forbade proof of the
evidence upon which detention was ordered. It was sufficient for the Home Secretary to have a belief
which in ins mind was reasonable. The courts would not enquire into the grounds for ins belief,
although apparently they might examine positive evidence of mala fides or mistaken identity. In
Greene's case (supra) the House of Lords held that a mistake on the part of the advisory committee
in failing, as was required by the regulation, to give the appellant correct reasons for ins detention
did not invalidate the detention order. It is noticeable how the same House expressed this view
without any dissent.
29. Dicey states that this increase in the power of the Executive is no trifle, but it falls far short of the
process known in some foreign countries as "suspending the constitutional guarantees" or in France
as the "proclamation of a State of siege". Under the Act of 1881 the Irish executive obtained the
absolute power of arbitrary and preventive arrest, and could without breach of law detain in prison
any person arrested on suspicion for the whole period for which the Act continued in force. Under
the Prevention of Crime (Ireland) Act, 1882 the Irish Executive was armed with extraordinary
powers in the case of certain crimes to abolish right to trial by jury.
30. The Act of Indemnity in England is a retrospective statute which frees persons who had broken
the law from responsibility for its breach, and thus make acts lawful which when they were
committed were unlawful. A Habeas Corpus Suspension Act does not free any person from civil or
criminal liability for a violation of the law. The suspension, indeed, of the Habeas Corpus Act may
prevent the person arrested from taking at the moment any proceeding against the Secretary of
State. While the suspension lasts, he will not be able to get himself discharged from prison. If the
prisoner has been guilty of no legal offence then on the expiration of the Suspension Act the
Secretary of State and ins subordinates are liable to actions or indictments for their illegal conduct.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

31. Dicey stated that the unavowed object of a Habeas Corpus Suspension Act is to enable the
Government to do acts which, though politically expedient may not be strictly legal. The Parliament
which suspends one of the guarantees for individual freedom must hold that a crisis has arisen when
the rights of individuals must be postponed to considerations of State. A Suspension Act would in
fact, fail of its main object, unless the officials felt assured that, as long as they bona-fide, and
uninfluenced by malice or by corrupt motives, carried out the policy of which the Act was visible
sign, they would be protected from penalties for conduct which, though it might be technically a
breach of law, was nothing more than the free exertion for the public good of that discretionary
power which the suspension of Habeas Corpus Act was intended to confer upon the executive.
32. The position in America is described in Cooley on the General Principles of Constitutional Law
in the U.S.A. Fourth Edition. In America the right to the Writ of Habeas Corpus is not expressly
declared in the Constitution, but it is recognised in the provision Article 1 in Section 9 Clause (2)
that the privilege of writ of habeas corpus shall not be suspended, unless when in cases of rebellion
or invasion the public safety may require it. In America the power to suspend the privilege is a
legislative power and the President cannot exercise it except as authorised by law. The suspension
does not legalise what is done while it continues. It merely suspends for the time this particular
remedy. All other remedies for illegal arrests remain, and may be pursued against the parties
making or continuing them.
33. Liberty is confined and controlled by law, whether common law or statute. It is in the words of
Burke a regulated freedom. It is not an abstract or absolute freedom. The safeguard of liberty is in
the good sense of the people and in the system of representative and responsible government which
has been evolved. If extraordinary powers are given, they are given because the emergency is
extraordinary, and we limited to the period of the emergency.
34. Unsuitability of a court of law for determining matters of discretionary policy was referred to by
Lord Parker in the Zamora case [1916] 2 A. C. 107 and Lord Finlay in the Zadiq case (supra). In the
Liversidge case (supra) it was held that the court is not merely an inappropriate tribunal, but one
the jurisdiction of which is unworkable and even illusory in these cases. A court of law could not
have before it the information on which the Secretary acts still less the background of statecraft and
national policy what is and what must determine the action which he takes upon it.
35. The Liversidge case (supra) referred to these observations in the Zadiq case (supra) "However
precious the personal liberty of the subject may be, there is something for which it may well be, to
some extent, sacrificed by legal enactment, namely, national success in the war or escape from
national plunder or enslavement". Liberty is itself the gift of the law and may by the law be forfeited
or abridged.
36. There is no record of any life of an individual being taken away either in our country during
emergency or in England or America during emergency in their countries. It can never be
reasonably assumed that such a think will happen. Some instances from different countries were
referred to by some counsel for the respondents as to what happened there when people were
murdered in gas chambers or people were otherwise murdered. Such instances are intend toAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

produce a kind of terror and horror and are hortative in character. People who have faith in
themselves and in their country will not paint pictures of diabolic distortion and mendacious
alignment of the governance of the country. Quite often arguments are heard that extreme examples
are given to test the power. If there is power, extreme examples will neither add to the power nor rob
the same. Extreme examples tend only to obfuscate reason and reality.
37. The reflect of the Suspension of Habeas Corpus Acts and of Indemnity Acts in England has been
to give every man security and confidence in periods of public danger or apprehension. Rarely,
however, has this been suffered without jealousy, hesitation and remonstrance. Whenever the perils
of the State have been held sufficient to warrant this sacrifice of personal liberty, no Minister or
Magistrate has been suffered to tamper with the law at ins discretion. Where the Government
believes the State to be threatened by traitorous conspiracies during times of grave emergencies the
rights of individuals of ordinary tunes become subordinate to considerations of the State.
38. The pre-eminent questions are four. First, is the Presidential Order under Article 359 a bar at
the threshold Second, is Article 21 the sole repository of right to life and personal liberty Third, is
the Presidential Order subject to the rubric of Rule of Law ? Fourth, is Section 16A(9) of the Act a
rule of evidence ?
39. The first question turns on the depth and content of the Presidential Order. The vital distinction
between Article 358 and Article 359 is that Article 358 suspends the rights only under Article 19 to
the extent that the Legislature can make laws contravening Article 19 during the operation of a
Proclamation of Emergency and the Executive can take action which the Executive is competent to
take under such laws. Article 358 does not suspend any fundamental right. While a Proclamation of
Emergency is in operation the Presidential Order under Article 359(1) can suspend the enforcement
of any or all fundamental rights. Article 359(1) also suspends any pending proceedings for the
enforcement of such fundamental right or rights. The purpose and object of Article 359(1) is that the
enforcement of any fundamental right mentioned in the Presidential Order is barred or it remains
suspended during the emergency. Another important distinction between the two Articles is that
Article 358 provides for indemnity whereas Article 359(1) does not, Article 359(1 A) is on the same
lines as Article 358 but Article 359(1A) now includes all fundamental rights which may be
mentioned in a Presidential Order and is, therefore, much wider than Article 358 which includes
Article 19 only.
40. A person can enforce a fundamental right both in the case of law being made in violation of that
right and also if the Executive acts in non-compliance with valid laws or acts without the authority
of law. It cannot be said that the scope of Article 359(1) is only to restrict the application of the
Article to the Legislative field and not to the acts of the Executive. The reason is that any
enforcement of the fundamental rights mentioned in the Presidential Order is barred and any
challenge either to law or to any act of the Executive on the ground that it is not in compliance with
the valid law or without authority of law will amount to enforcement of fundamental rights and will,
therefore, be within the mischief of the Presidential Order. The effect of the Presidential Order
suspending the enforcement of fundamental right amounts to bar the locus standi of any person to
move the court on the ground of violation of a fundamental right.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

41. The Constitution is the mandate. The Constitution is the rule of law. No one can arise above the
rule of law in 'the Constitution. The decisions of this Court in Mohan Chowdhury's (supra) case,
Makhan Singh's (supra) case and Dr. Ram Manohar Lohia v. State of Bihar and Ors. are that any
court means all courts including this Court and High Courts and the right to initiate legal
proceedings. A person can enforce fundamental rights in this Court under Article 32 as well as in the
High Courts under Article 226. It is idle to suggest that the object of Article 359(1) is that the right to
move this Court only is barred and not the right to move any High Court. Article 226 does not
provide a guaranteed fundamental right like Article 32. This guaranteed right under Article 32 itself
may be suspended by a Presidential Order under Article 359(1). In such a case it could not be said
that the object of the makers of the Constitution is that a person could not move this Court for the
enforcement of fundamental rights mentioned in the Presidential Order but could do so under
Article 226. The bar created by Article 359(1) applies to petitions for the enforcement of
fundamental rights mentioned in the Presidential Order whether by way of an application under
Article 32 or by way of any application under Article 226. [See Makhan Singh's case (supra) and
Ram Manohar Lohia's case (supra)].
42. It is incorrect to say that the jurisdiction and powers of this Court under Article 32 and of the
High Courts under Article 226 are virtually abolished by the Presidential Order without any
amendment of the Constitution. No amendment of the Constitution is necessary because no
jurisdiction and power either of this Court or of the High Court is taken away. When a Presidential
Order teaks away the locus standi of the detenus to move any court for the enforcement of
fundamental rights for the tune being the jurisdiction and powers of this Court and of the High
Courts remain unaltered Article 359(1) is not directed against any court. It is directed against an
individual and deprives him of ins locus standi.
43. The courts cannot either increase or curtail the freedom of individuals contrary to the provisions
of the Constitution. The courts interpret the Constitution and the laws in accordance with law and
judicial conscience and not emotion. It is wrong to say that the Executive has asked or directed any
one not to comply with the conditions of the Act. The question is not whether the Executive should
comply or should not comply with the Act but whether a detenu has a locus standi to move any court
for a writ in the nature of habeas corpus on the ground of non-compliance with the provisions of the
Act.
44. In period of public danger or apprehension the protective law which gives every man security
and confidence in tunes of tranquility, has to give way to interests of the State. The opinion in
England has been that when danger is imminent, the liberty of the subject is subordinated to the
paramount interests of the State. Ring leaders are seized and outrages anticipated. Plots are
disconcerted, and the dark haunts of conspiracy filled with distrust and terror (See
May--Constitutional History of England, Vol. I, pp. 130-135).
45. While the courts of law are in normal tunes peculiarly competent to weigh the competing claims
of individuals and government, they are ill equipped to determine whether a given configuration of
events threatens the life of the community and thus constitutes an emergency. Neither are they
equipped, once an emergency has been recognised particularly a war emergency or emergency onAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

account of security of the country being threatened by internal aggression to measure the degree to
which the preservation of the life of the community may require governmental control of the
activities of the individual. Jurists do not have the vital sources of information and advice which are
available to the executive and the legislature; nor have they the burden of formulating and
administering the continuing programme of the government, and the-political responsibility of the
people, which, although intangibles, are of crucial importance in establishing the context within
which such decisions must be made.
46. Article 359(1) makes no distinction between the threat to the security of India by war or external
aggression on one hand and threat to the security of India by internal disturbance on the other. In
fact, both situations are covered by the expression "grave emergency" in Article 352(1). Apart from
Article 359(1) all provisions of the Constitution laying down the consequences of a Proclamation of
Emergency under Article 352(1) would apply to both situations. The consequences of a Proclamation
of Emergency under Article 352(1) of our Constitution are much wider than in England or America.
47. Article 353 provides that the executive power of the Union shall extend to giving of directions to
any State as to manner in which the executive power thereof is to be exercised. The exercise of such
executive power by the Union totally displaces the provisions of Article 162. Non-compliance with
directions of the Union Executive under Article 353 by any State Executive may attract the
provisions of Article 356 and the President's Rule may be imposed on that State. In such as event,
Parliament may, under Article 357 (f) confer on the President the power of the Legislature of that
State to make laws or to delegate such legislative power to any other authority. In such a situation,
the federal structure and representative Government on which the Constitution is based, may be
completely chastised in the State or States concerned. Article 250 provides that during the operation
of Proclamation of Emergency Parliament may make laws with respect to any of the matters
enumerated in the State List. The Federal structure and representative government may suffer its
full place in that Situation.
48. On the expiry of the operation of the Presidential Order under Article 359(1), the infringement
of the fundamental rights mentioned in the Order, either by the legislative enactment or by an
executive action, may be challenged in a court of law and 2 after such expiation Parliament passes
an Act of Indemnity, the validity and the effect of such legislation may have to be scrutinised. [See
MakJian Singh's case (supra) at 813].
49. The provisions in our Constitution relating to emergency are of wide amplitude. The Executive is
armed with special powers because individual interests are subordinated to State security. If law is
invalid vis-a-vis fundamental rights there cannot be any challenge during the operation of Articles
358 and 359 on the ground that law violates fundamental rights. It is contradictory to say that there
can yet be challenge to orders under that law as being not in accordance with law. Article 19 is a
prohibition against law. Article 1.9 has nothing to do with the Executive. Law under Article 21 can be
punitive or preventive. In Article 22 reference is made to grounds and representation in cases of
preventive detention. If enforcement of Article 22 is suspended one is left with Article 21.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

50. The Act in the present case is law. The Executive orders are under that law. Any allegation that
orders are not under that law Will not rob the orders of the protective umbrella of Article 359. The
challenge by a detenu that law is broken will be enforcement of Article 21 because law contemplated
under Article 21 is substantive as well as procedural law. A law can be broken either of substantive
or procedural parts. Neither enforcement of nor relief to personal liberty is based on Article 19. No
executive action is valid unless backed by law. In the present cases there is law authorising
detention. In the present cases, the writs questioned the validity of detention. The Legislature under
Article 358 is authorised to act in breach of Article 19. The executive can act only in terms of that
law. If this is pre-emergency law it has to satisfy Part III of our Constitution. If it is emergency law it
can violate Article 19 because it is protected by Article 358.
51. Under Article 359 the Presidential Orders have been of two types. On 3 November, 1962 in
exercise of powers conferred by Clause (1) of Article 359 of the Constitution the President declared
that "the right of any person to move any court for the enforcement of the rights conferred by Article
21 and Article 22 shall remain suspended for the period during which the Proclamation of
Emergency issued under Clause (1) of Article 352 on 26 October, 1962 is in force, if such a person
has been deprived of any right under the Defence of India Ordinance 1962 or of any rule or order
made thereunder". The 1975 Presidential Order under Article 359(1) does not have the words "if
such a person has been deprived of any such right under the Defence of India Ordinance 1962 or any
rule or order made thereunder". In other words, the 1962 Presidential Order is limited to the
condition of deprivation of rights under the Defence of India Ordinance or any rule or order made
thereunder whereas in the 1975 Presidential Order as statute is mentioned. The illegality of orders
was challenged in Makhan Singh's case (supra) in spite of the Presidential Order under the 1962
Proclamation on the ground that the impeached orders are not in terms of the statute or they are
made in abuse of law.
52. The decisions of this Court in Mohan Chowdhury's and Makhan Singh's cases (supra) are that
during the operation of a Proclamation of Emergency no one has any locus standi to move any court
for the enforcement of any fundamental rights mentioned in the Presidential Order. The ratio must
necessarily apply to Executive acts because Executive acts are challenged on the grounds of being
contrary to law and- without the authority of law. The submission 61 the respondents that a person
in detention can come to a court of law in spite of the Presidential Order under Article 359(1) and
contend that a habeas corpus should be issued for ins release or that the Executive should answer
the detenu's challenge that the Act complained of is without authority of law or the challenge of the
detenu that the provisions of the Legislative Act under which the detention has been made have not
been complied with are all rooted in the enforcement of fundamental rights to liberty under Articles
21 and 22. If courts will in spite of the Presidential Order entertain such applications and allow the
detenus to enforce to start or continue proceedings or enforce fundamental rights, Article 359(1) will
be nullified and rendered otiose.
53. This Court in Makhan Singh's case (supra) said that if there was challenge to the validity of the
detention order based on any right other than those mentioned in the Presidential Order that
detenu's right to move any court could not be suspended by the Presidential Order because the right
was outside Article 359(1). This was explained by staling that if the detention was challenged on theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

ground that it contravened the mandatory provisions of the relevant Act or that it was malafide and
was proved to be so, the bar of the Presidential Order could have no application.
54. This observation in Makhan Singh's case (supra) is to be understood in the context of the
question that arose for decision there. Decision on a point not necessary for the purpose of or which
does not .fall to be determined in that decision becomes an obiter dictum [See Maha-rajadhiraja
Madhav Rao Jiwaji Rao Scindia Bahadur and Ors. v. Union of India [1971] S. C. R. 9 at pp. 97-98,
193-194. In Makhan Singh's case (supra) the detention orders which were the subject matter of the
judgment were orders made by the Executive under the Defence of India Ordinance or Act and rules
and orders made thereunder which was the express condition for detention in respect of which the
Presidential Order of 1.962 under Article 359(1) applied.
55. The Presidential Order in the present case is on the face of it an un-conditional order and. as
such there is the vital and telling difference between the effect of the Presidential Order of 1962 and
the present Presidential Order. It is obvious that the Government fully conscious of the Presidential
Order of 1962 and its effect as determined by the decisions of this Court in Makhan Singh's case
(supra) and subsequent cases deliberately made the present Presidential Order an un-conditional
order under Article 359(1).
56. Reference may be made to State of Maharashtra v. Prabhakar Pandurang Sangzgiri and Anr.
which clearly pointed out that the Presidential Order of 1962 was a conditional one and therefore if a
person was deprived of ins personal liberty not under the Act or rules and orders made thereunder
but in contravention thereof, ins right to move the courts in that regard would not be suspended.
The decision; of this Court in Pandurang's case (supra) is by the Constitution Bench of five learned
Judges, three of whom were on the Constitution Beach of seven learned Judges deciding Makhan
Singh's case (supra). In Pandurang's case (supra) the ratio was that if a person was deprived of ins
personal liberty not under the Act or rules and orders made thereunder but in contravention
thereof, ins right to move the courts in that regard was not suspended.
57. It, therefore, follows from the decisions in Pandurang's case and Makhan Singh's case (supra)
that the ratio in both the cases was that the 1962 Presidential Order being a conditional one the
enforcement of rights under Articles 21 and 22 was suspended only to the extent of the conditions
laid down in the Presidential Order and the suspension could not operate in areas outside the
conditions. There is no aspect whatever of any condition in the present Presidential Order.
Therefore, the decisions in Makhan Singh's case (supra) and subsequent cases following it have no
application to the present cases where the suspension is not hedged with any condition of
enforcement of any right under Articles 21 and 22. The conclusion for the foraging reasons is that
the Presidential Order is a bar at the threshold.
58. The heart of the matter is whether Article 21 is the sole repository of the right to personal liberty.
If the answer to that question be in the affirmative the Presidential Order will be a bar.
59. The contentions of the Attorney General are two-fold. First, the legal enforceable right to
personal liberty for violation thereof by the Executive is a fundamental right conferred by theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Constitution and is embodied in Article 21. Second, apart from Article 21 the right to personal liberty
against the Executive is neither a common law right nor a statutory right nor a natural right. He
relies on three decisions. The earliest is Girindra Nath Banerjee v. Birendra Nath Pal I. L. R. 54 Cal
727. The others are King Emperor v. Sibnath Banerjee 72 I. A. 241 and Makhan Singh's case (supra).
In the first two decisions it has been held that the right to habeas corpus is only under Section 491 of
the CrPC. In Makhan Singh's case (supra) it has been said that this right under Section 491 became
embodied in Article 21. The statutory right under Section 491 of the CrPC has been deleted from the
new CrPC which came into effect on 1 April, 1974.
60. The arguments on. behalf of the respondents are that the right to life and personal liberty is not
only in Article 21 but also under common law and statutes for these reasons.
61. The right to personal liberty is contained in Articles 19, 20 and 22, and, therefore, Article 21 is
not the sole repository to personal liberty. The respondents rely on the decision in Rustom Cavasjee
Cooper v. Union of India where it was said that the ruling in A. K. Gopalan v. The State of Madras
[1950] 3 S. C. R. 88 that Articles 19 and 22 are mutually exclusive no longer holds the field. The
respondents also rely on the decisions in Shambhu Nath Sarkar v. The State of West Bengal and Ors.
, Haradhan Saha and Anr. v. The State of West Bengal and Ors. and Khudiram Das v. The State of
West Bengal and Ors. in support of 'the proposition that these decisions followed the ruling in the
Bank Nationalisation case (supra). The respondents contend that the Presidential Order bars
enforcement of rights under Articles 14, 19, 21 and 22 but it is open to the respondents to enforce
violation of rights under Article 20. The other, reasons advanced by the respondents are dealt with
hereinafter.
62. The majority view in His Holiness Kesavananda Bharati Sripada-galavaru v. State of Kerala
[1973] Supp. S. C. R. 1 is that there are no natural rights. Fundamental rights in our Constitution are
interpreted to be what is commonly said to be natural rights. The only right to life and liberty is
enshrined in Article 21.
63. In A. K. Gopalan''s case (supra) it has been said that to read law as meaning, natural law is to lay
down vague standards. Law means law enacted by the State. Law must have some firmness. Law
means positive State made law. Article 21 has been interpreted in A. K. Gopalan's case (supra) to
include substantive as well as procedural law in the phrase "procedure established by law". The
reason is obvious. A law providing for procedure depriving a person of liberty must be a law made by
statute. P.D. Shamdasani v. Central Bank of India Ltd. [1952] S. C. R. 391 held that Article 21 is
prohibition against unauthorised executive action. In Shrimati Vidya Verma through next friend R.
V. S. Mani v. Dr. Shiva Narain Verma law in Article 21 has been held to mean State made law.
64. In Makhan Singh's case (supra) it was decided that during the subsistence of the Presidential
Order suspending the enforcement of fundamental rights neither a petition under Article 32 nor a
petition under Article 226 could be moved invoking habeas corpus. An application invoking habeas
corpus under Section 491 of the CrPC cannot similarly be moved in the High Court.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

65. Part III of our Constitution confers fundamental rights in positive as well as in negative
language. Articles 15(1), 16(1), 19, 22(2), 22(5), 25(1), 26, 29(1), 30 and 32(1) can be described to be
Articles in positive language. Articles 14, 15(2), 16(2), 20, 21, 22(1), 22(4), 27, 28(1), 29(2), 31(1) and
(2) are in negative language. It is apparent that most categories of fundamental rights are in positive
as well as in negative language. A fundamental right couched in negative language accentuates by
reason thereof the importance of that right. The negative language is worded to emphasise the
immunity from State action as a fundamental right. [See The State of Bihar v. Maharajadhiraja Sir
Kameshwar Singh of Darbhanga and Ors. [1952] S. C, R. 889 at 988-89]. These fundamental rights
conferred by our Constitution have taken different forms. Some of these fundamental rights are said
to have the texture of Basic Human Rights (See A, K. Gopalan's case (supra) at pp. 96-97, 248, 249,
293 and Bank Nationalisation case (supra) at pp. 568-71, 576-78).
66. Article 31(1) and (2) subordinate the exercise of the power of the State to the concept of the Rule
of Law enshrined in the Constitution. (See Bank Nationalisation case (supra) at p. 568). Similarly,
Article 21 is our Rule of Law regarding life and liberty. No other rule of law can have separate
existence as a distinct right. The negative language of fundamental right incorporated in Part III
imposes limitations on the power of the State and declares the corresponding guarantee of the
individual to that fundamental right. The limitation and guarantee are complementary. The
limitation of State action embodied in a fundamental right couched in negative form is the measure
of the protection of the individual.
67. Personal liberty in Article 21 includes all varieties of rights which go to make personal liberty
other than those in Article 19(1)(d). (See Kharak Singh v. State of U.P. and Ors. The Bank
Nationalisation case (supra) merely brings in the concept of reasonable restriction in the law. In the
present appeals, the Act is not challenged nor can it be challenged by reason of Article 358 and
Article 359(1 A) and the Presidential Order mentioning Article 19 as well.
68. If any right existed before the commencement of the Constitution and the same right with its
same content is conferred by Part III as a fundamental right the source of that right is in Part III and
not in any pre-existing right. Such pre Constitution right has been elevated by Part III as a
fundamental right. The pre-existing right and the fundamental right have to be grouped together as
a fundamental right conferred by the Constitution. See Dhirubha Devisingh Gohil v. The State of
Bombay .
69. If there is a pre Constitution right which is expressly embodied as a fundamental right under our
Constitution, the common law right has no separate existence under our Constitution. (See B.
Shankara Rao Badami and Ors. v. State of Mysore and Anr. . If there be any right other than and
more extensive than the fundamental right in Part III, such right may continue to exist under Article
372.
70. Before the commencement of the Constitution the right to personal liberty was contained in
Statute law, e.g. the Indian Penal Code, the Criminal Procedure Code as also in the common law of
Torts. In the event of any wrongful infringement of the right to personal liberty the person affected
could move a competent court by way of a suit for false imprisonment and claim damages.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

71. Suits for false imprisonment are one of the categories of law of Torts. The common law of Torts
prevailed in our country before the Constitution on the basis of justice, equity and good conscience.
(See Waghela Rajsanfi v. Shiekh Masludin and Ors. 14 I. A 89 at 96, Satish Chandra Chakravarti v.
Ram Doyal De I.L.R. 48 Cal. 388 at 407-10, 425. 426 and Baboo s/o Thakur Dhobi v. Mt. Subanshi
w/o Mangal Dhobi A.I.R. 1942 Nag. 99. This principle of justice, equity and good conscience which
applied in India before the Constitution is generally known as the English Common Law. Apart from
the law of Torts, there was no civil remedy for unlawful infringement of the right to personal liberty
in India before the Constitution.
72. After the amendment of Section 491 of the CrPC in 1923, the right to obtain a direction in the
nature of a habeas corpus became a statutory right to a remedy in India. After 1923 it was not open
to any party to ask for a writ of habeas corpus as a matter of common law. (See Makhan Singh's case
(supra) at pp. 818-19; District Magistrate, Trivandrum v. K. C. Mammen Mappil-lai I.L.R. [1939]
Mad. 708, Matthen v. District Magistrate, Trivandrum L.R. 66 I.A. 222, Girindra Nath Banerjee's
case (supra) and Sibnath Banerjee's case (supra). The previsions of Section 491 of the Criminal
Procedure Code have been repealed recently as being superfluous in view of Article 226. (See 41st
Report of Law Commission of India (Vol. I) p. 307).
73. The present appeals arise from petitions filed in High Courts for writs in the nature of habeas
corpus. The statutory right to remedy in the nature of habeas corpus under Section 491 of the
Criminal Procedure Code cannot be exercised now In view of the repeal of that section. Even if the
section existed today it could not be exercised as a separate right distinct from the fundamental
right, the enforcement of which is suspended by the Presidential Order as was held by this Court in
Makhan Singh's case (supra) at pp. 818-825. There was no statutory right to enforce the right to
personal liberty other than that in Section 491 of the Criminal Procedure Code before the
commencement of the Constitution which could be carried over after its commencement under
Article 372. Law means enacted law or statute law. (See A. K. Gopakm's case (supra) at pp. 112, 199,
276, 277, 288, 307, 308, 309, 321, 322). It follows that law in Article 21 will include all
post-constitutional statute law including the Act in the present case and by virtue of Article 372 all
pre-constitutional statute law including the Indian Penal Code and the Criminal Procedure Code.
74. The expression "procedure established by law" includes substantive as well as procedural law.
(See A. K. Gopalan's case (supra) at p. 111 and S. Krishnan and Ors. v. The State of Madras [1951] S.
C. R. 621 at p. 639). It means some step or method or manner of procedure leading upto deprivation
of personal liberty. A law depriving a person of personal liberty must be a substantive and
procedural law authorising such deprivation. It cannot be a bare law authorising deprivation of
personal liberty. The makers of the Constitution had the Criminal Procedure Code in mind. The
repealed Criminal Procedure Code as well as the present Criminal Procedure Code has substantive
as well as procedural provisions. The substantive as well as the procedural parts in a law depriving a
person of personal liberty must be strictly followed. There is no distinction between the expression
"save by authority of law" in Article 31(1) and the expression "except by authority of law" in Article
265. Laws under Article 31(1) must lay down a procedure containing reasonable restrictions. Law
under Article 265 also lays down a procedure. Therefore, there is no difference between the
expression "except according to procedure established by law" in Article 21 and the expression "saveAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

by authority of law" in Article 31(1) or the expression "except by authority of law" in Article 265.
When Article 21 was enacted it would be a blunder to suggest that the founding fathers only
enshrined the right to personal liberty according to procedure and did not frame the constitutional
mandate that personal liberty could not be taken except according to law.
75. The Attorney General rightly submitted at the outset that Article 21 confers a fundamental right
against the Executive and law in that Article means State law or statute law. In the present appeals,
the respondents allege that Section 3 of the Act has not been complied with. In the present appeals
the Act is not challenged nor can it be challenged on the ground of infringement of Article 19 by
reason of Articles 358, 359.(1) and the Presidential Order. It has been pointed out earlier that
non-compliance with the provisions of the Act cannot be challenged as long as the Presidential
Order is in force.
76. Article 20 states that no person shall be prosecuted and punished for the same offence more
than once. The present appeals do not touch any aspect of Article 20. The reason why reference is
made at this stage to Article 20 is to show that Article 20 is a constitutional mandate to the Judiciary
and Article 21 is a constitutional mandate to the Executive.
77. The respondents contend that "State" in Article 12 will also include the Judiciary and Article 20
is enforceable against the Judiciary in respect of illegal orders. The answer is that Article 20 is a
prohibition against the Judiciary in the cases contemplated there. If a person is detained after the
Judiciary acts contrary to the provisions in Article 20 such detention cannot be enforced against the
Judiciary. In the event of the Judiciary acting contrary to the provisions in Article 20 such detention
can be challenged by moving the court against the Executive for wrongful detention, or conviction or
punishment as the case may be. The expression "No person shall be prosecuted for the same offence
more than once" in Article 20 would apply only to the Executive.
78. The decision in Makhan Singh's case (supra) is that fundamental rights cannot be enforced
against the Judiciary in case of illegal orders. The decision in Ram Narayan Singh v. The State of
Delhi and Ors. [1953] S.C.R.. 652 is no authority for the proposition that fundamental rights can be
enforced against the Judiciary. This Court held that the detention of Ram Narayan was illegal
because Ram Narayan was being detained without any order of remand by the Magistrate. In Ram
Narayan's case (supra) there was no aspect of the bar under Article 359. It is not correct to say that
the suspension of fundamental rights or of their enforcement can increase the power of the
Executive. The effect of suspension or enforcement of fundamental rights is that an individual
cannot move any court for the enforcement of ins fundamental right to personal liberty for the time
being.
79. Reference to Articles 256, 265 and 361 was made by the respondents to show that Article 21 is
not the repository of rights to life and liberty. These references are irrelevant. Article 256 does not
confer any right on any person. It deals with relations between the Union and the State. Article 265
has nothing to do with the right to personal liberty. Article 361(3) refers to the issue of a process
from any court which is a judicial act and not any Executive action. In any event, these Articles have
no relevance in the present appeals.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

80. Reference was made by the respondents to an accused filing an appeal relating to criminal
proceedings to show that Article 21 is not the sole repository of right to life and liberty. In a criminal
proceeding the accused defends himself against the accusation of an offence against him. He does
not move any court for the enforcement of ins fundamental right of personal liberty. In an appeal
against the order of conviction the accused challenges the correctness of the judicial decision. An
appeal or revision is a continuation of the original proceeding. (See Garikapatti Veeraya v. N.
Subbiah Choudhury [1957] S. C. R. 488 and Ahmedabad Mfg. and Calico Ptg. Co. Ltd. v. Ram Tahal
Ramnand and Ors. .
81. The respondents posed the question whether a decree given against the Government could be
enforced because of the Presidential Order. This is irrelevant. However, a decree conclusively
determines the rights of the parties in the suit and after a decree is passed the right of the
decree-holder is not founded on the right which is recognised by the decree but on the decree itself.
This right arising from a decree is not a fundamental right, and, therefore, will not be prima facie
covered by a Presidential Order under Article 359(1).
82. The other examples given by the respondents are seizure of property by Government, requisition
by Government contrary to Articles 31 and 19(1)(f). If any seizure of property is illegal or an
acquisition or requisition is challenged it will depend upon the Presidential Order to find out
whether the proceedings are for the enforcement of fundamental rights covered by the Presidential
Order.
83. Fundamental rights including the right to personal liberty are conferred by the Constitution. Any
pre Constitution rights which are included in Article 21 do not after the Constitution remain in
existence which can be enforced if Article 21 is suspended. If it be assumed that there was any
pre-constitutional right to personal liberty included in Article 21 which continued to exist as a
distinct and separate right then Article 359(1) will be an exercise in futility. In Makhan Singh's case
(supra) there was not suggestion that apart from Article 21 there was any common law or pre
Constitution right to personal liberty.
84. The theory of eclipse advanced on behalf of the respondents is untenable. Reliance was placed
on the decision in Bhikaji Narain Dhakras and Ors. v. The State of Madhya Pradesh and Anr. . The
theory of eclipse refers to pre-constitutional laws which were inconsistent with fundamental rights.
By reason of Article 13(1) such laws did not become void but became devoid of legal force. Such laws
became eclipsed for the time being. The theory of eclipse has no relevance to the suspension of the
enforcement of fundamental rights under Article 359(1). The constitutional provisions conferring
fundamental rights cannot be said to be inconsistent with Article 13(1).
85. Article 21 is not a common law right. There was no pre-existing common law remedy to habeas
corpus. Further, no common law right which corresponds to a fundamental right can exist as a
distinct right, apart from the fundamental right. See Dhirubha Devisingh Gohil v. The State of
Bombay (supra) and B. Shankar Rao Badatni's case (supra). In Gohil's case (supra) the validity of
the Bombay Act of 1949 was challenged on the ground that it took away or abridged fundamental
rights conferred by the Constitution. The Act was held to be beyond question in view of Article 31-BAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

which had been inserted in the Constitution by the First Amendment and the Act being mentioned
as Item 4 of the 9th Schedule. It was said that one of the rights secured by Part III of our
Constitution is a right that the property shall be acquired for a public purpose and under a law
authorising such acquisition and providing for compensation. That is also the very right which was
previously secured to a person under Section 299 of the Government of India Act, 1935. This Court
said that what under the Government of India Act was a provision relating to the competency of the
Legislature, was also clearly in the nature of a right of the person affected. The right under Article
299 which was pre-existing, became along with other fundamental rights for the first time secured
by our Constitution when grouping them together as fundamental rights.
86. The respondents gave the example that although Section 12(2)' of the Act makes it obligatory on
the Executive to revoke the detention order and if the Executive does not do so such Executive
action will amount to non-compliance with the Act. Here again, the detenu cannot enforce any
statutory right under the Act for the same reason that it will amount to enforce ins fundamental
right to personal liberty by contending that the Executive is depriving him of ins personal liberty not
according to "procedure established by law". Similarly, the example given of an illegal detention of a
person by a Police Officer will be met with the same plea.
87. An argument was advanced on behalf of the respondents' that if pre-existing law is merged in
Article 21 there will be conflict with Article 372. The expression "law in force" in Article 372 cannot
include laws which are incorporated in the Constitution viz., in Part III. The expression "law" in
Articles 19(1) and 21 takes in statute law.
88. The respondents contended that permanent law cannot be repealed by temporary law. The
argument is irrelevant and misplaced. The Presidential Order under Article 359(1) is not a law. The
Order does not repeal any law either. The suggestion that Article 21 was intended to afford
protection to life and personal liberty against violation by private individuals was rejected in
Shamdasani's case (supra) because there cannot be any question of one private individual being
authorised by law to deprive another of ins property or taking away the life and liberty of any person
by procedure established by law. The entire concept in Article 21 is against Executive action. In
Vidya Verma's case (supra) this Court said that there is no question of infringement of fundamental
right under Article 21 where the detention complained of is by a private person and not by a State or
under the authority or orders of a State.
89. The Act in the present case is valid law and it has laid down procedure of applying the law. The
validity of the Act has not been challenged and cannot be challenged. The Legislature has
competence to make the law. The procedure, therefore, cannot be challenged because Articles 21
and 22 cannot be enforced. The suggestion of the respondents that the power of the Executive is
widened is equally untenable.
90. The suggestion on behalf of the respondents that the right to private defence is available and if
any one resorted to private defence in resisting detention there might be civil war is an argument to
excite emotion. If there are signs of civil war, as the respondents suggested," it is for the
Government of our country to deal with the situation. It is because of these aspects that emergencyAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

is not justiciable because no court can have proper standard to measure the problems of emergency
in the country. If any person detained finds that the official has the authority to arrest him no
question of resistance arises and if there is no authority the same cannot be challenged during the
operation of the Presidential Order but the person shall have ins remedy for any false imprisonment
after the expiry of the Presidential Order.
91. The respondents submitted that if Article 21 were the repository of a right to personal liberty it
would mean that Article 21 destroyed pre-existing rights and then made a fresh grant. There is no
question of destruction of any right. Our fundamental rights came into existence for the first time
under the Constitution. The fact that Section 491 of the old Criminal Procedure Code has been
abolished in the new Code establishes that the pre-existing right was embodied as a fundamental
right in the Constitution. The right to personal liberty became identified with fundamental right to
personal liberty under Article 21.
92. The third question is whether Rule of Law overrides the Presidential Order. The Presidential
Order does not alter or suspend any law. The rule of law is not a mere catchword or incantation.
Rule of law is not a law of nature consistent and invariable at all times and in all circumstances. The
certainty of law is one of the elements in the concept of the Rule of Law but it is only one element
and, taken by itself, affords little guidance. The essential feature of Rule of Law is that the judicial
power of the State is, to a large extent, separate from the Executive and the Legislature. Rule of Law
is a normative as much as it is a descriptive term. It expresses an ideal as much as a juristic fact. The
Rule of Law is not identical with a free society. If the sphere of the Rule of Law involves what can be
called the "Existence of the Democratic System" it means two things. In the first place the individual
liberties of a democratic system involve the right of the members of each society to choose the
Government under which they live. In the second place come freedom of speech, freedom of
assembly and freedom of association. These are not absolute rights, Their exceptions are justified by
the necessity of reconciling the claims of different individuals to those rights. The criterion whereby
this reconciliation can be effected is the concern of the law to ensure that the status and dignity of all
individuals is to the greatest possible extent observed.
93. Freedom of speech may be limited by conceptions as "clear and present danger", "attack on the
free democratic order". The institutions and procedures by which the fundamental regard for the
status and dignity of the human person can be effected is that rights and remedies are
complimentary to the other. The phrases such as "equality before law" or "equal protection of the
laws" are in themselves equivocal. The supremacy of the law means that the faith of civil liberty
depends on the man who has to administer civil liberty much more than on any legal formula.
Aristotle, pointed out that the rigid certainty of law is not applicable to all circumstances. This plea
would be echoed by the modern administrator called upon to deal with the ever changing
circumstances of economic and social life of the nation.
94. The respondents contend that all executive actions which operate to the prejudice of any person
must have the authority of law to support it. Reliance is placed on the decisions in Rai Sahib Ram
Jawaya Kapur and Ors. v. The State of Punjab , M. P. State v. Bharat Singh , Collector v. Ibrahim &
Co. , Bennet Coleman & Co. v. Union of India and Meenakshi Mills v. Union of India . This isAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

amplified by the respondents to mean that the Executive cannot detain a person otherwise than
under any legislation and on the suspension of Article 21 or the right to enforce it, the Executive'
cannot get any right to act contrary to law.
95. The Executive cannot detain a person otherwise than under valid legislation. The suspension of
any fundamental right does not effect this rule of the Constitution. In normal situations when there
is no emergency and when there is no Presidential Order of the type like the present the situation is
different. In Bharat Singh's case (supra) this Court was concerned with the pre-emergency law and
an order of the Executive thereunder. It was held that the pre-emergency law was void as violative of
Article 19, and, therefore, such a law being pre-emergency law could not claim the protection under
Article 358.
96. The ratio in Bharat Singh's case (supra) is this : Executive action which operates to the prejudice
of any person must have the authority of law to support it. [See also Ram Jaway a Kapur's case
(supra)]. The provisions of Article 358 do not detract from that rule. Article 358 expressly authorises
the State to take legislative or Executive action provided such action was competent for the State to
make or take but for the provisions contained in Part III of our Constitution. Article 358 permits an
Executive action under a law which may violate Article 19 but if the law is void or if there be no law
at all, the Executive action will not be protected by Article 358. Bharat Singh's case (supra)
considered the effect of Article 358 so far the Executive action is concerned, but was not concerned
with any Executive action taken infringing any fundamental right mentioned in a Presidential Order
under Article 359(1).
97. Ibrahim's case (supra), the Bannett Coleman case (supra) and the Meenakshi Mills case (supra)
follow Bharat Singh's case (supra) regarding the proposition that the terms of Article 358 do not
detract from the position that the Executive cannot act to the prejudice of a person without the
authority of law.
98. The ratio in Bharat Singh's case (supra) is that the Madhya Pradesh Public Security Act was
brought into force before the Emergency. Article 358 empowers the legislature to make a law
violating Article 19. Article 358 does not mean that a pre-emergency law violating Article 19 would
have constitutional validity during the period of emergency. The Executive action which was taken
during the emergency on the basis of the pre-emergency law did not have the authority of law
inasmuch as the Madhya Pradesh Act of 1959 was a void law when it was enacted in violation of
Article 19.
99. In Ibrahim's case (supra) the Sugar Control Order 1963 permitted allocation of quotas of sugar.
The State Government ordered that the sugar allocated to the two cities of Hyderabad and
Secunderabad were in entirety to be given to the Co-operative -Stores. Under. Article 358 the
respondents there could not challenge an Executive action which, but for the provisions contained
Article 19, the State was competent to take. But the Executive order there was one which had the
effect of cancelling the licences of the respondents which could be done only after an enquiry
according to the procedure prescribed in the order. The Executive order there was contrary to the
provisions contained in the Sugar Control Order. In other words, the Executive action which was inAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

breach of the order could not be immune from attack under Article 358. In the Bennet Coleman case
(supra) it was said that the Newsprint Control Order could not authorise the number of pages. In the
Meenakshi Mills case (supra) it was said that the Yarn Control Order could not be resisted on the
ground that it had BO direct impact on the rights of the mills.
100. In these four cases referred to there was no question of enforcement of fundamental right
mentioned in the Presidential Order. These four cases were not concerned with any Executive action
taken infringing any fundamental right mentioned in a Presidential Order under Article 359.
101. The suspension of right to enforce fundamental right has the effect that the emergency
provisions in Part XVIII are by themselves the rule of law during times of emergency. There cannot
be any rule of law other than the constitutional rule of law. There cannot be any pre Constitution or
post Constitution Rule of Law which can run counter to the rule of law embodied in the
Constitution, nor can there be any invocation to any rule of law to nullify the constitutional
provisions during the times of emergency.
102. The respondents relied on the decision in Eshugbayi Eleko v. Officer Administering the
Government of Nigeria [1931] A. C 662 in support of the proposition that Rule of Law will always
apply even when there is Presidential Order. It has to be realised that the decision in Eshuqbavi
Eleko cannot over-reach our Constitution.
103. Article 358 does not permit the Executive action to have the authority of law. Article 359
prevents the enforcement of the fundamental rights mentioned in the Presidential Order. It bars
enforcement against any legislation or executive action violating a fundamental right mentioned in
the Presidential Order.
104. The principle in Eshugbayi Eleko's case (supra) will not apply where-Article 359 is the
paramount and supreme law of the country. There is no question of amendment of the concept of
rule of law or any suggestion of destruction of rule of law as the respondents contended because the
Presidential Order under Article 359 neither nullifies nor suspends the operation of any law. The
consequence of the Presidential Order is of a higher import than the suspension of any law because
the remedy for the enforcement of fundamental rights is barred for the time being because of grave
emergency.
105. The respondents contend that if an individual officer acts outside ins authority, it will be an
illegal act and the High Court under Article 226 can deal with it. Reliance is placed on the English
decision in Christie and Anr. v. Leachinsky [1947] A. C. 573 in support of the proposition that the
action of an individual officer will be an Executive action when he acts within the scope of ins
authority.
106. The decision in Leachinsky's case (supra) is an action for false, imprisonment and damages
against two persons of Liverpool City Police for wrongfully arresting a person without informing
that person of the grounds for arrest. That case has no relevance here.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

107. An individual officer acting within the scope of ins official duty would not cease to be so if he
makes an order which is challenged to be not in compliance with the statute under which he is
authorised to make the order. Any challenge to the order of detention would come within the fold of
breach of fundamental right under Article 21, namely, deprivation of personal liberty.
108. The obligation of the Executive to act in accordance with the Act is an obligation as laid down in
Article 21. If such an obligation is not performed, the violation is of Article 21. It will mean that the
right of the person affected will be a violation of fundamental right.
109. The expression "for any other purpose" in Article 226 means for any purpose other than the
enforcement of fundamental rights. A petition for habeas corpus by any person under Article 226
necessarily involves a question whether the detention is legal or illegal. An Executive action if
challenged to be ultra vires a statute cannot be challenged by any person who is not aggrieved by any
such ultra vires action.
110. Section 18 of the Act has been argued by the respondents to mean that a malafide order of
detention cannot be regarded as an order made Under the Act. Section 18 has also been challenged
to suffer from the vice of excessive delegation. Section 18 has been amended by the words "in respect
of whom an order is made or purported to be made under Section 3" in substitution of the words
"detained under this Act". The result is that no person in respect of whom and order is made or
purported to be made under Section 3 shall have any right to personal liberty by virtue of natural
law or common law, if any. It has been earlier held that there is no natural law or common law right
to habeas corpus. The respondents rely on the decisions in Poona Municipal Corporation v. D. N.
Deodher , Kala Bhandar v. Munc. Committee , Indore Municipality v. Niyatnatulla A. I. R. 1971 S. C.
97 and Joseph v. Joseph [1966] 3 All. E. R. 486 in support of the proposition that the expression
purports" means "has the effect of". The respondents contend that Section 18 of the Act can apply
only when a valid order of detention is made. If the section be interpreted to include malafide orders
or orders without jurisdiction then it is said that such interpretation will prevail upon the judicial
power and violate Article 226.
111. The expression "purported to be done" occurs in Section 80 of the CPC. The expression
"purported to be made under Section 3 of the Act" in Section 18 will include an executive act made
by the District Magistrate within the scope of ins authority as District Magistrate, even if the order is
made in breach of the section or is mala fide. (See Hari Singh v. The Crown [1939] F. C. R 159)
Bhagchand Dagadusa v. Secretary of State for India L. R. 54 I. A, 338 at 352, Albert West Meads v.
The King , Anisminic v. Foreign Compensation etc. [1969] 1 All. E R. 208 at 212-13, 237 and
Dakshina Ranjan Ghosh v. Omar Chand Oswal I. L. R. 50 Cal., 992 at 995-1003. As long as the
District Magistrate acts within the scope of ins authority as a District Magistrate an order passed by
him is an order made or purported to be made under Section 3 of the Act.
112. The section applies to any person in respect of whom an order has been made or purported to
be made. There is no question of excessive delegation. Section 18 of the Act lays down the law.
Section 18 of the Act is only an illustration of an application of the Act by the officers authorised by
the Act.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

113. Section 18 identifies the person to whom it applies and in what cases it applies to such a person.
The word "purport" covers acts alleged to be malafide. The decisions to which reference has been
made indicate that the acts whatever their effect be are all acts made or purported to be made under
the Act.
114. A contention is advanced by the respondents that Section 18 of the Act will apply only to
post-detention challenge. This is wrong. Section 18 applies to all orders of detention.
115. Counsel on behalf of the respondents submitted that the High Courts had only heard the
matters on preliminary points and not on the area of judicial scrutiny, and, therefore, this Court
should not express any view on the latter question. There are three principal grounds why this Court
should express views. First. The Bombay High Court (Nagpur Bench) has read down Section 16A(9)
of the Act. One of the appeals is from the judgment of the Bombay High Court (Nagpur Bench). This
judgment directly raises the question of Section 16A(9) of the Act. Second. The Additional Solicitor
General made ins submissions on this part of the case and all counsel for the respondents made
their submissions in reply. Considerable time was spent on hearing submissions on both sides. Time
of the Court is time of the nation. Third. It is only proper that when so much time has been taken on
these questions this Court should express opinions and lay down areas for judicial scrutiny.
116. The respondents contend that if the Presidential Order does not bar the challenge on the
ground that the orders are malafide or that the orders are not made in accordance with the Act the
non-supply of grounds will not affect the jurisdiction of the Court. It is said by the respondents that
the scope of judicial scrutiny is against orders. The respondents submit that court has gone behind
the orders of detention in large number of cases.
117. The respondents submit as follows : It is open to the Court to judge the legality of the orders.
This the Court can do by going beyond the order. Though satisfaction is recorded in the order and
such recording of satisfaction raises the presumption of legality of order the initial onus on a detenu
is only to the extent of creating "disquieting doubts" in the mind of the Court. The doubts are that
the orders are based on irrelevant non-existing facts or on facts on which no reasonable person
could be satisfied in respect of matters set out in Section 3 of the Act. If such a prima facie case is
established the burden shifts and the detaining authority must satisfy the court about the legality of
detention and the detaining authority must remove doubts on all aspects of legality which have been
put in issue. If the detaining authority for whatever reasons fails to satisfy the court either by not
filing an affidavit or not placing such facts which may resolve the doubts about the legality of
detention the court may direct release of the detenus.
118. The respondents submit that all that they want is that if the detenus challenge the orders to be
malafide or to be not in compliance with the statute and if the court does not have any "disquieting
doubts" the court will dismiss the petitions. If the court has any such doubt the court will call for the
return. On a return being made if the court is satisfied that the return is an adequate answer the
court will dismiss the petition. If the court wants to look into the grounds the court will ask for the
production of the grounds and the court itself will look into the grounds but will not show the
grounds to the detenus. In short, the respondents submit that the jurisdiction of the court toAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

entertain the application should not be taken away as a result of the Presidential Order.
119. The appellants submit that if Article 359 is not a bar at the threshold and if the Court can
entertain a petition, judicial review should be limited within a narrow area. In the forefront 16A(9)
of the Act is put because that section forbids disclosure of grounds and infarction in the possession
of the detaining authority. The Nagpur Bench of the Bombay High Court read down Section 16A(9)
but the Additional Solicitor General submitted that Section 16A(9) should not be read down because
it enacts a rule of evidence.
120. The Additional Solicitor General submitted as follows : The scrutiny by courts will extend to
examining first whether detention is in exercise or purported exercise of law. That will be to find out
whether there is a legal foundation for detention. The second enquiry will be whether the law is valid
law. If it is a pre-emergency law the same can be tested as to whether it was valid with reference to
Articles 14, 19, 21 and 22. If it is an emergency legislation the validity of law cannot be gone into
first, because of Article 358, and, second, because of the Presidential Order under Article 359. The
other matters which the court may examine are whether the detaining authority is a competent
authority under the law to pass the order, whether the detenu has been properly identified, whether
the stated purpose is one which ostensibly conforms to law and whether the procedural safeguards
enacted by the law are followed.
121. With regard to grounds of detention it is said by the Additional Solicitor General that if the
grounds are furnished or are required to be furnished the Court can examine whether such grounds
ex-facie justify reasonable apprehension of the detaining authority. Where the grounds are not to be
furnished, it is said, that this enquiry does not arise. The Additional Solicitor General submits that
judicial scrutiny cannot extend to three matters--first, objective appraisal of the essential subjective
satisfaction of the detaining authority, second, examination of the material and information before
the detaining authority for the purpose of testing the satisfaction of the authority, and, third,
directing compulsory production of the file relating to detenu or drawing and adverse inference
from the non-production thereof.
122. Material and information on which orders of preventive detention are passed necessarily
belong to a class of documents whose disclosure would impair the proper functioning of public
service and administration. The file relating to a detention order must contain intelligence reports
and like information whose confidentiality is beyond reasonable question. This was the view taken
in the Liver-sidge case [1942] A. C. 206 at 221, 253, 254, 266, 267, 279 and 280. See also Rogers
case [1973] A. C.1 388 at 400, 401 and 405. If privilege were to be claimed in each case such a claim
would in terms of Sections 123 and 162 of the Evidence Act have been invariably upheld. Article
22(6) also contemplates such claims on behalf of the State. That is why instead of leaving it to
individual decision in each case or to the discretion of individual detaining authorities to make a
claim for privilege, the legislature has enacted Section 16A(9) providing for a general exclusion from
evidence of all such material as would properly fall within the classification.
123. Section 16A cannot be said to be an amendment to Article 226. The jurisdiction to issue writs is
neither abrogated nor abridged. A claim of privilege arises in regard to documents or informationAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

where a party to a suit or proceeding is called upon to produce evidence. Section 16A(9) enacts
provisions analogous to a conclusive proof of presumption. Such a provision is a genuine rule of
evidence. It is in the nature" of an Explanation to Sections 123 and 162 of the Evidence Act. Section
16A(9) is a rule of evidence. Therefore, when the detaining authority is bound by Section 16A(9) and
forbidden absolutely from disclosing such material no question can arise for adverse inference
against the authority. If a detenu makes out a prime facie case and the court calls for a return, the
affidavit of the authority will be an answer. The Court cannot insist on the production of the file or
hold that the case of the detenu stands unrebutted by reason of such non-disclosure. To hold
otherwise would be to induce reckless averments of malafides to force production of the file which is
forbidden by law.
124. Section 16A(9) cannot be read down implying an exception in favour of disclosure to the Court
as was suggested by the Bombay High Court (Nagpur Bench). Such disclosure to the court alone and
not to the detenu will introduce something unknown to judicial procedure. This will bring in an
element of arbitrariness and preclude both parties from representing their respective cases. Further,
it would substitute or super-impose satisfaction of the Court for that of the Executive. This Court has
held that the view of the detaining authority is not to be substituted by the view of the court. (See
State of Bombay v. Atma Ram Sridhar Vaidya [1951] S. C. R. 167 , Shibban Lal Sak-sena v. The State
of Uttar Pradesh and Ors. [1954] S. C. R. 418, Rameshwar Shaw v. District Magistrate, Burdwan and
Anr. , Jaichand Lal v. W. Bengal [1966] Supp. S. C. R. 464, and Ram Manohar Lohia's case (supra).
125. The theory of good return mentioned in the English decisions is based on the language of
Habeas Corups Act and the Rules of the Supreme Court of England. The practice of our Court is
different. The respondents relied on M. M. Damnoo y. J. & K. State in support of the proposition
that the file was produced there and also contended that Section 16A(9) can be struck down as
happened in A, K. Gopalan's case (supra) where Section 14 of the Preventive Detention Act was
struck down. When A. K. Gopalan's case (supra) was decided Article 22 was in force. Prevention of
court from seeing the grounds contravened Article 22. There was no question of privilege. Section 14
of the Preventive Detention Act in A. K. Gopalan's case (supra) offended Article 22. (See A. K.
Gopalan's case 1950 S. C. R. 88 at 130, 217, 242, 283-84, 332-33).
126. In Damnoo's case (supra) there was no question of privilege. The file was produced but there
was no direction of the court to produce the file. Second. There was no aspect of Article 359. Third.
In Damnoo's case (supra) the analogy of Section 14 of the Preventive Detention Act in Gopalan's
case was considered. No provision like Section 16A(9) was on the scene. Fourth, The State did not
rely on the proviso to Section 8 of the relevant Act there to contend that the file could not be
produced.
127. Section 16A(9) of the Act contains definite indications of implied exclusion of judicial review on
the allegations of malafide. It is not possible for the court to adjudicate effectively on malafides. The
reason why Section 16A has been enacted is to provide for periodical review by Government and that
is the safeguard against any unjust or arbitrary exercise of power.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

128. It will be useless to attempt to examine the truth of the fact alleged in the order in a case when
the fact relates to the personal belief of the relevant authority formed at least partly on grounds
which he is not bound to disclose. It is not competent for the court to decide whether the impugned
order of detention under Section 3(1) or the declaration under Section 16A(2) and (3) of the Act
during the emergency is a result of malice or ill-will. The reason is that it is not at all possible for the
court to call for and to have a look at the grounds of the order of detention under Section 3(1) or the
declaration under Section 16A(2) and (3) of the Act that induced the satisfaction in the mind of the
detaining authority that it was necessary to detain the person or to make a declaration against him.
129. The grounds of detention and any information or materials on which the detention and the
declaration were made are by Section 16A(9) of the Act confidential and deemed to refer to matters
of State and to be against public interest to disclose. No one under the provisions of the Act and in
particular Section 16A(9) thereof shall communicate or disclose such grounds, materials or
information except as provided in Section 16A(5) and (8) of the Act. Sub-sections (5) and (8) have
no application in these cases. The court cannot strike down the order as vitiated by malafide and
grant relief since it is not possible for the court without the examination of such grounds, materials
and information to decide whether the order of detention is the result of malice or ill-will. When the
court cannot give any relief on that basis the contention of malafides is not only ineffective but also
untenable. (See Lawrence Joachim Joesph D 'Souza v. The State of Bombay [1956] S. C. R. 382 at
392-93.
130. The provision for periodical review entrusted to the Government under Section 16A(4) of the
Act in the context of emergency provides a .sufficient safeguard against the misuse of power of
detention or arbitrary malafide detention during the emergency. The Government is in full
possession of the grounds, materials and information relating to the individual detentions while
exercising the power of review.
131. The jurisdiction of the court in tunes of emergency in respect of detention under the Act is
restricted by the Act because the Government is entrusted with the task of periodical review. Even if
the generality of the words used in Section 3(1) of the Act may not be taken to show an intention to
depart from the principle in ordinary times that the courts are not deprived of the jurisdiction where
bad faith is involved, there are ample indications in the provisions of the Act, viz., Section 16A(2),
proviso to Section 16A(3), Section 16A(4), Section 16A(5), Section 16A(7)(ii) and Section 16A(9) of
the Act to bar a challenge to the detention on the basis of malafides. (See Smith v. East Elloe Rural
District Council and Ors. [1956] A.C. 736 at 776 and Ram Manohar Lohia's case (supra) at 716, 732).
This Court said that an action to decide the order on the grounds of malafides does not lie because
under the provisions no action is maintainable for the purpose. This Court also referred to the
decision in the Liver-sidge case (supra) where the Court held that the jurisdiction of the court was
ousted in such way that even questions of bad faith could not be raised.
132. The production of the order which is duly authenticated constitutes a peremptory answer to the
challenge. The onus of showing that the detaining authority was not acting in good faith is on the
detenu. This burden cannot be discharged because of the difficulty of proving bad faith in the
exercise of subjective discretionary power vested in the administration. De Smith in ins JudicialAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Review of Administrative Actions 1973 Edition at page 257 scq. has said that the reservation for the
case of bad faith in hardly more than a formality. Detenu will have to discharge the impossible
burden of proof that the detaining authority did not genuinely believe he had reasonable cause.
133. In Lawrence Joachim Joseph D' Souza's. case (supra) malafide exercise of power was untenable
having regard to the grounds on . which detention was based. In the context of emergency Section
3(1) of the Act confers an unlimited discretion which cannot be examined by courts.. This rule of
construction of the phrases "is satisfied", "in the opinion of", "it appears to be", "has reason to
believe" adopted by courts in tunes of national emergency will be rendered nugatory and ineffective
if allegations of malafides are gone into. A distinction is to be drawn between purpose and motive so
that where an exercise of power fulfils the purpose for which power was given, it does not matter
that he who exercised it is influenced by an extraneous motive because when an act is done which is
authorised by the Legislature it is not possible to contest that discretion. So long as the authority is
empowered by law action taken to realise that purpose is not malafide. when the order of detention
is on the face of it within the power conferred, the order is legal.
134. The width and amplitude of the power of detention under Section 3 of the Act is to be adjudged
in the context of the emergency proclaimed by the President. The Court cannot compel the detaining
authority to give the particulars of the grounds on which he had reasonable cause to believe that it
was necessary to exercise this control. An investigation into facts or allegations of facts based on
malafides is not permissible because such a course will involve advertence to the grounds of
detention and materials constituting those grounds which is not competent in the context of the
emergency.
135. For the foregoing reasons the conclusions are as follows :--
First. In view of the Presidential Order dated 27 June, 1975 under Clause (1) of Article
359 of our Constitution no person has locus standi to move any writ petition under
Article 226 before a High Court for habeas corpus or any other writ or order or
direction to enforce any right to personal liberty of a person detained under the Act
on the grounds that the order of detention or the continued detention is for any
reason not under or in compliance with the Act or is illegal or malafide.
Second. Article 21 is the sole repository of rights to life and personal liberty against
the State. Any claim to a writ of habeas corpus is enforcement of Article 21 and, is,
therefore, barred by the Presidential Order.
Third. Section 16A(9) of the Act is valid. It is a rule of evidence and it is not open
either to the detenu or to the court to ask for grounds of detention.
Fourth. It is not competent for any court to go into questions of malafides of the
order of detention or ultra vires character of the order of detention or that the order
was not passed on the satisfaction of the detaining authority.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

136. The appeals are accepted. The judgments of the High Courts are set aside.
H.R. Khanna, J.
137. Law of preventive detention, of detention without trial is an anathema to all those who love
personal liberty. Such a law makes deep inroads into basic human freedoms which we all cherish
and which occupy prime position among the higher values of life. It is, therefore not surprising that
those who have an abiding faith in the rule of law and sanctity of personal liberty do not easily
reconcile themselves with a law under which persons can be detained for long periods without trial.
The proper forum for bringing to book those alleged to be guilty of the infraction of law and
commission of crime, according to them, is the court of law where the correctness of the allegations
can be gone into in the light of the evidence adduced at the trial. The vesting of power of detention
without trial in the executive, they assert, has the effect of making the same authority both the
prosecutor as well as the judge and is bound to result in arbitrariness.
138. Those who are entrusted with the task of administering the land have another viewpoint.
According to them, although they are conscious of the value of human liberty, they cannot afford to
be oblivious of the" need of the security of the State or the maintenance of public order. Personal
liberty has a value if the security of the State is not jeopardised and the maintenance of public order
is not threatened. There can be the administrator assert, no freedom to destroy freedom. Allegiance
to ideals of freedom cannot operate in vacuum. Danger lurks and serious consequences can follow
when thoughts become encysted in fine phrases oblivious of political realities and the impact of real
politik. No government can afford to take risks in matters relating to the security of the State.
Liberty, they accordingly claim, has to be measured against community's need for security against
internal and external peril.
139. It is with a view to balancing the conflicting viewpoints that the framers of the Constitution
made express provisions for preventive detention and at the same time inserted safeguards to
prevent abuse of those powers and to mitigate the rigour and harshness of those provisions. The
dilemma which faced the Constitution makers in balancing the two conflicting viewpoints relating to
liberty of the subject and the security of the State was not, however, laid to rest for good with the
drafting of the Constitution. It has presented itself to this Court in one form or the other ever since
the Constitution came into force. A, K. Gopalan's [1950] S.C.R. 88 was the first case wherein a
Bench of six Judges of this Court dealt with the matter. Another Bench of seven Judges again dealt
with the matted in 1973 in the case of Shambu Nath Sarkar v. State of West Bengal and Ors. . In
between, a number of Benches have dealt with the various facets of the question. One such facet has
now presented itself to this Constitution Bench.
140. The question posed before us is whether in view of the Presidential order dated June 27, 1975
under Clause (1) of Article 359 of the Constitution, any petition under Article 226 before a High
Court for writ of habeas corpus to enforce the right of personal liberty of a person detained under
the Maintenance of Internal Security Act, 1971 (Act 26 of 1971) (hereinafter referred to as MISA) as
amended is maintainable. A consequential question which may be numbered as question No. 2 is, if
such a petition is maintainable, what is the scope or extent of judicial scrutiny. The above questionsAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

arise in criminal appeals Nos. 279 of 1975, 355 and 356 of 1975, 1845-49 of 1975, 380 of 1975, 1926
of 1975, 389 of 1975, 3 of 1976, 41 of 1976 and 46 of 1976. These appeals have been filed against the
orders of Madhya Pradesh High Court, Allahabad High Court, Karnataka High Court, Delhi High
Court, Nagpur Bench of Bombay High Court and Rajasthan High Court whereby the High Courts
repelled the preliminary objections relating to the maintainability of petitions under Article 226 for
writs of habeas corpus on account of 'Presidential order dated June 27, 1975. On the second
question, some of the High Courts expressed the view that this was a matter which would be gone
into while dealing with individual cases on their merits. The other High Courts went into the matter
and expressed their view. This judgment would dispose of all the appeals.
141. MISA was published on July 2, 1971. Section 2 of the Act contains the definition clause. Section
3 grants powers to make orders for detaining certain persons and reads as under :
3. (1) The Central Government of the State Government may,--
(a) if satisfied with respect to any person (including a foreigner) that with a view to
preventing him from acting in any manner prejudicial to--
(i) the defence of India, the relations of India with foreign powers, or the security of
India, or
(ii) the security of the State or the maintenance of public order, or
(iii) the maintenance of supplies and services essential to the community, or
(b) if satisfied with respect to any foreigner that with a view to regulating ins
continued presence in India or with a view to making arrangements for ins expulsion
from India, it is necessary so to do,, make an order directing that such person be
detained.
(2) Any of the following officers, namely :--
(a) district magistrates,
(b) additional district magistrates specially empowered in this behalf by the State
Government,
(c) Commissioners of Police, wherever they have been appointed, may, if satisfied as
provided in Sub-clauses (ii) and (iii) of Clause (a) of Sub-Section (1),, exercise the
power conferred by the said Sub-section.
(3) When any order is made under this section by an officer mentioned in
Sub-section (2), he shall forthwith report the fact to the State Government to which
he is subordinate together with the grounds on which the order has been made andAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

such other particulars as in ins opinion have a bearing on the matter, and; no such
order shall remain in force for more than twelve days after the making thereof unless
in the meantime it has been approved by the State Government:
Provided that where under Section 8 the grounds of detention are communicated by
the authority making. the order after five days but not later than fifteen days from the
date of detention, this Sub-section shall apply subject ,to the modification that for the
words 'twelve days', the words 'twenty-two days' shall be substituted.
(4) When any order is made or approved by the State Government under this section,
the State Government shall Within seven days, report the fact to the Central
Government together with the grounds on which the order has been made and such
other particulars as in the opinion of the State Government have a bearing on the
necessity for the order.
Section 4 and 5 deal respectively with execution of detention orders and the power to regulate place
and conditions of detention. According to Section 6, detention orders are not to be invalidated or
inoperative on the ground that the person to be detained is outside the limits of the territorial
jurisdiction of the Government or officer making the order' or that the place of detention of such
person is outside the said limits. Section 8 requires that the grounds of order of detention should be
disclosed to persons affected by the order and he should be granted the earliest opportunity of
making a representation against the order. Section 9 deals with the Constitution of Advisory Boards.
Section 10 makes provision for reference to Advisory Boards. Section 11 prescribes the procedure of
Advisory Boards and section 12 requires that action should be taken in accordance with the report of
the Advisory Board. According to section 13, the maximum period of detention shall be 12 months
from the date of detention. Section 14 confers power of revocation of detention orders. Section 15
confers power upon the appropriate Government to temporarily release the detained persons.
Section 16 gives protection to action taken in good faith. Section 17 provides for detention up to two
years in certain cases of foreigners. Section 18, which has subsequently been re-numbered as Section
19, provides for the repeal of the Maintenance of Internal Security Ordinance and the saving clause.
142. According to Clause (1) of Article 352 of the Constitution, if the President is satisfied that a
grave emergency exists whereby the security of India or of any part of the territory thereof is
threatened, whether by war or external aggression or internal disturbance, he may, by Proclamation,
make a declaration to that effect. On December 3,, 1971 the President of India issued the following
proclamation of emergency :
In exercise of the powers conferred by Clause (1) of Article 352 of the Constitution, I,
V. V. Giri, President of India; by this Proclamation declare that a grave emergency
exists whereby the security of India is threatened by external aggression.
V. V. Giri President Clause (1) of Article 359 of the Constitution reads as under :Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Where a Proclamation of Emergency is in operation, the President may by order
declare that the right to move any court for the enforcement of such of the rights
conferred by Part III as may be mentioned in the order and all proceedings pending
in any court for the enforcement of the rights so mentioned shall remain suspended
for the period during which the Proclamation is in force or for such shorter period as
may be specified in the order.
On November 16, 1974 the President of India made the following order :
In exercise of the powers conferred by Clause (1) of article 359 of the Constitution,
the President hereby declares that--
(a) the right to move any count with respect to orders of detention which have
already been made or which may hereafter be made under Section 3(1) (c) of the
Maintenance of Internal Security Act, 1971 as amended by Ordinance 11 of 1974, for
the enforcement of the rights conferred by Article 14, Article 21 and Clauses (4), (5),
(6) and (7) of Article 22 of the Constitution, and
(b) all proceedings pending in any court for the enforcement of any of the aforesaid
rights with respect of orders of detention made under the said Section 3(D(c)' shall
remain suspended for a period of six months from the date of issue of this Order or
the period during which the Proclamation of Emergency issued under Clause (1) of
Article 352 of the Constitution on the 3rd December, 1971, is in force, whichever
period expires earlier.'
2. This Order shall extend to the whole of the territory of India.
On June 20, 1975 the President of India amended the above order by substituting twelve months"
for "six months" in the order. On June 25, 1975 the President of India issued another proclamation
of emergency and the same reads as under :
PROCLAMATION OF EMERGENCY In exercise of the powers conferred by Clause
(1) of Article 352 of the Constitution, I Fakhruddin Ali Ahmed, President of India, by
this Proclamation declare that a grave emergency exists whereby the security of India
is threatened by internal disturbance.
Sd/- F. A. Ahmed President New Delhi the 25th June, 1975
143. On June 27, 1975 the President of India made the following order:
In exercise of the powers conferred by Clause (1) of Article 359 of the Constitution,
the President hereby declares that the right of any person (including a foreigner) to
move any court for the enforcement of the rights conferred by Article 14, Article 21
and Article 22 of the Constitution and all proceedings pending in any court for theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

enforce-men of the above mentioned rights shall remain suspended for the period
during which the Proclamation of Emergency made under Clause (1) of Article 352 of
the Constitution on the 3rd December, 1971 and on the 25th June, 1975 are both in
force.
This Order shall extend to the whole of the territory of India except the State of
Jammu and Kashmir.
This Order shall be in addition to and not in derogation of any Order made before the
date of this order under Clause (1) of Article 359 of the Constitution.
On June 29, 1975 another order was issued by the President whereby the words
"except the State of Jammu & Kashmir" in the order dated June 27, 1975 were
omitted. On September 25, 1975 another Presidential order was issued as a result of
which the last paragraph in the Presidential order dated June 27, 1975 was omitted.
144. By Act 39 of 1975 Section 16A was introduced in MISA with effect from June 29, 1975 and the
same reads as under :
16A. (1) Notwithstanding anything contained in this Act or any rules of natural
justice, the provisions of this section shall have effect during the period of operation
of the Proclamation of Emergency issued under Clause (1) of Article 352 of the
Constitution on the 3rd day of December, 1971 or the Proclamation of Emergency
issued under that clause on the 25th day of June, 1975, or a period of twelve months
from the 25th day of June, 1975, whichever period is the shortest.
(2) The case of every person (including a foreigner) against whom an order of
detention was made under this Act on or after the 25th day of June, 1975, but before
the commencement of this section, shall, unless such person is sooner released from
detention, be reviewed within fifteen days from such commencement by the
appropriate Government for the purpose of determining whether the detention of
such person under this Act is necessary for dealing effectively with the emergency in
respect of which the Proclamations referred to in Sub-section (1) have been issued
,hereinafter in this section referred to as the emergency) and if, on such review, the
appropriate Government is satisfied that it is necessary to detain such person for
effectively dealing with the emergency, that Government may make a declaration to
that- effect and communicate a copy of the declaration to the person concerned.
(3) When making an order of detention under this Act against any person (including
a foreigner) after the commencement of this section, the Central Government or the
State Government or, as the case may be, the officer making the order of detention
shall consider whether the detention of such person under this Act is necessary for
dealing effectively with the emergency and if, on such consideration, the Central
Government or the State Government or, as the case may be, the officer is satisfiedAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

that it is necessary to detain such person for effectively dealing with the emergency,
that Government or officer may make a declaration to that effect and communicate a
copy of the declaration to the person concerned:
Provided that where such declaration is made by an officer, it shall be reviewed by the
State Government to which such officer is subordinate within fifteen days from the
date of making of the declaration and such declaration shall cease to have effect
unless it is confirmed by the State Government, after such review, within the said
period of fifteen days.
(4) The question whether detention of any person in respect of whom a declaration
has been made under Sub-section (2) or Sub-section (3) continues to be necessary for
effectively dealing with the emergency shall be reconsidered by the appropriate
Government within four months from the date of such declaration and thereafter at
intervals not exceeding four months and if, on such re-consideration, it appears to
the appropriate Government that the detention of the person is no longer necessary
for effectively dealing with the emergency, that Government may revoke the
declaration.
(5) In making any review, consideration or reconsideration under Sub-sections(2),
(3) or (4), the appropriate Government or officer may, if such Government or officer
considers it to be against public interest to do otherwise act on the basis of the
information and materials in its or ins possession without disclosing the facts or
giving an opportunity of making a representation to the person concerned.
(6) In the case of every person detained under a detention order to which the
provisions of Sub-section (2) apply, being a person the review of whose case is
pending under that Sub-section or in respect of whom a declaration has been made
under that Sub-section,--
(i) Section 8 to 12 shall not apply; and
(ii) Section 13 shah" apply subject to the modification that the words and figures
'which has been confirmed under Section 12' shall be omitted.
(7) In the case of every person detained under a detention order to which the
provisions of Sub-section (3) apply' being a person in respect of whom a declaration
has been made under that Sub-section,--
(i) Section 3 shall apply subject to the modification that for Sub-sections (3) and (4)
thereof,, the following Sub-section shall be substituted, namely :--
(3) when order of detention is made by a State Government or by an officer
subordinate to it, the State Government shall, within twenty days, forward to theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Central Government a report in respect of the order;
(ii) Section 8 to 12 shall not apply; and
(iii) Section 13 shall apply subject to the modification that the words and figures
'which has been confirmed under Section 12' shall be omitted.
Act 39 of 1975 also inserted Section 18 with effect from June 25, 1975 and the same reads as under :
18. No person (including a foreigner) detained under this Act shall have any right to
personal liberty by virtue of natural law or common law, if any.
145. By the Constitution (Thirty-eighth Amendment) Act, 1975 Clauses (4) and (5) which read as
under were added in Article 352 of the Constitution :
(4) The power conferred on the President by this article shall include the power to
issue different Proclamation on different grounds, being war or external aggression
or internal disturbance or imminent danger of war of external aggression or internal
disturbance, whether or not there is a Proclamation already issued by the President
under Clause (1) and such Proclamation is in operation.
(5) Notwithstanding anything in this Constitution,--
(a) the satisfaction of the President mentioned in Clause (1) and Clause (2) shall be
final and conclusive and shall not be questioned in any court on any ground;
(b) subject to the provisions of Clause (2), neither the Supreme Court nor any other
court shall have jurisdiction to entertain any question, on any ground, regarding the
validity of--
(i) a declaration made by Proclamation by the President to the effect stated in Clause
(1); or
(ii) the continued operation of such Proclamation.
Following Clause (1A) was also added after Clause (1) of Article 359 and the same
reads as under:
(1A) While an order made under Clause (1) mentioning any of the rights conferred by
Part III is in operation, nothing in that Part conferring those rights shall restrict the
power of the State as defined in the said Part to make any law or to take any executive
action which the State would but for the provisions contained in that Part be
competent to make or to take, but any law so made shall, to the extent of the
incompetence, cease to have effect as soon as the order aforesaid ceases to operate,Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

except as respects things done or omitted to be done before the law so ceases to have
effect.
The Constitution (Thirty-ninth Amendment) Act, 1975 was published on August 10, 1975 and
inserted the Maintenance of Internal Security Act, 1971 as item 92 in the Ninth Schedule to the
Constitution.
146. On October 17, 1975 Ordinance 16 of 1975 was issued making further amendment in Section
16A of MISA and the same read as under :
(a) for Sub-section (5), the following Sub-section shall be substituted, namely :--
(5) In making any review, consideration or re-consideration under Sub-section (2),
Sub-section (3) or Sub-section (4), the appropriate Government or officer may act on
the basis of the information and materials in its or ins possession without
communicating or disclosing any such information or materials to the person
concerned or affording him any opportunity of making any representation against the
making under Sub-section (2), or the making or confirming under Sub-section (3), or
the non-revocation under Sub-section (4), of the declaration in respect of him;
(b) in Sub-section (7), in Clause (i),--
(i) in the opening portion, for the words 'the following Sub-section', the words 'the
following' shall be substituted;
(ii) in Sub-section (3), as substituted by that clause, for the words 'forward to the
Central Government a report in respect of the order', the words 'report the fact to the
Central Government' shall be substituted;
(iii) after Sub-section (3) aforesaid, the following shall be inserted, namely:
(4) At any time after the receipt of a report under Sub-section (3), the Central
Government may require the State Government to furnish to the Central Government
the grounds on which the order has been made and such other particulars as, in the
opinion of the State Government, have a bearing on the necessity for the order.;
(c) after Sub-section (7), the following Sub-sections shall be inserted, namely:
(8) in the case of any person in respect of whom a declaration has been made by a
State Government under Sub-section (2) or a declaration has been made by a State
Government or an officer subordinate to it or confirmed by the State Government
under Sub-section (3), or a declaration has not been revoked by a State Government
under Sub-section (4), the Central Government may, whenever it considers it
necessary so to do, require the State Government to furnish to the CentralAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Government the information and materials on the basis of which such declaration
has been made or confirmed, or not revoked, as the case may be, and such other
information and materials as the Central Government may deem necessary.
(9) Notwithstanding anything contained in any other law or any rule having the force
of law,--
(a) the grounds on which an order of detention is made under Sub-section (1) of
Section 3 against any person in respect of whom a declaration is made under
Sub-section (2) or Sub-section (3) and any information or materials on which such
grounds or a declaration under Sub-section (2) or a declaration or confirmation
under Sub-section (3) or the non-revocation under Sub-section (4) of a declaration
are based, shall be treated as confidential and shall be deemed to refer to matters of
State and to be against the public interest to disclose and save as otherwise provided
in this Act, no one shall communicate or disclose any such ground, information or
material or any document containing such ground, information or material;
(b) no person against whom an order of detention is made under Sub-section (1) of
Section 3 shall be entitled to the communication or disclosure of any such ground,
information or material as is referred to in Clause (a) or the production to him of any
document containing such ground, information or material.
147. On November 16, 1975 Ordinance 22 of 1975 was issued making certain amendments in MISA.
By Section 2 of the Ordinance the words "twelve days" and "twenty days" in Sub-section (3) of
Section 3 of MISA were substituted by the words "twenty days" and "twenty-five days" respectively.
In Section 14 of the principal Act following Sub-section was substituted for the original Sub-section :
(2) The expiry or revocation of a detention order (hereafter in this Sub-section
referred to as the earlier detention order) shall not bar the making of another
detention order (hereafter in this Sub-section referred to as the subsequent detention
order) under Section 3 against the same person :
Provided that in a case where no fresh facts have arisen after the expiry or revocation
of the earlier detention order made against such person, the maximum period for
which such person, may be detained in pursuance of the subsequent detention order
shall, in no case, extend beyond a period of twelve months from the date of detention
under the earlier detention order or until the expiry of the Defence and Internal
Security of India Act, 1971, whichever is later.
Following Sub-section (2A) was also inserted in Section 16A of the principal Act :
(2A) If the State Government makes a declaration under Sub-section (2) that the
detention of any person in respect of whom a detention order is made by an officer
subordinate to that Government is necessary for dealing effectively with theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

emergency, the State Government shall be deemed to have approved such detention
order and the provisions of Sub-section (3) of Section 3, in so far as they relate to the
approval of the State Government, and of Sub-section (4) of that section, shall not
apply to such detention order.
The amendments made by the Ordinance were given retrospective effect for the purpose of
validating all acts done previously.
148. During the pendency of these appeals, the Maintenance of Internal Security (Amendment) Act,
1976 (Act 14 of 1976) was published on January 25, 1976. This amending Act incorporated and in
some respects modified the changes which had been brought about in the principal Act by ordinance
16 of 1975 and ordinance 22 of 1975. Section 2 and 3 of the amending Act incorporate the changes
which had been introduced by Sections 2 and 3 of Ordinance 22 of 1975. At the same "time sections
2 and 3 of the amending Act make it clear that substitution brought about by those sections shall be
with effect from June 29, 1975. Sections 4, 5 and 6 of the amending Act read as under :
4. In Section 16A of the principal Act,--
(a) after Sub-section (2), the following Sub-section shall be inserted, and shall be
deemed to have been inserted with effect from the 29th day of June, 1975, namely :--
(2A) If the State Government makes a declaration under Sub-section (2) that the
detention of any person in respect of whom a detention order is made by an
officer-subordinate to that Government is necessary for dealing effectively with the
emergency, the State Government shall be deemed to have approved such detention
order and the provision of Sub-section (3) of Section 3, in so far as they relate to, the
approval of the State Government, and of Sub-section (4]I of 'that section, shall not
apply to such detention order.;
(b) for Sub-section (5), the following Sub-section shall be substituted, and shall be
deemed to have been substituted with effect' from the 29th day of June, 1975, namely
:--
(5) In making any review, consideration or reconsideration under Sub-section (2),
Sub-section (3) or Sub-section (4), the appropriate Government or officer may act on
the basis of the information and materials in its .or ins possession without
communicating or disclosing any such information or materials to the person
concerned or affording, him any, opportunity of making any representation against
the making under Sub-section (2), or the making or confirming under Sub-section
(3), or the non-revocation under Sub-section (4), of the declaration in respect of him;
(c) in subjection (7), in Clause (i),--Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

(i) in the opening portion, for the words the following Sub-section', the words 'the
following' shall be substituted; and shall be deemed to have been substituted with
effect from the 29th day of June, 1975;
(ii) in Sub-section (3), as substituted by that clause, for the words 'forward to the
Central Government a report in respect of the order', die words 'report the fact to the
Central Government' shall be substituted, and shall be deemed to have been
substituted with effect from the 29th day of June, 1975;
(iii) after Sub-section (3) aforesaid, the following shall be inserted, and shall be
deemed to have been inserted with effect from the 17th day of October, 1975 namely
:--
(4) At any time after the receipt of a report under Sub-section (3), the Central
Government may require the State Government to furnish to the Central Government
the grounds on which the order has been made and such other particulars as, in the
opinion of the State Government, have a bearing on the necessity for the order.
(d) after Sub-section (7),' the following Sub-sections shall: be; inserted, and shall be,
deemed to have been inserted with effect from the 29th day of June, 1975; namely--
(8) In the case of any person in respect of whom a declaration has been made by a
State Government under Sub-section (2) or a declaration has been made by a State
Government or an officer subordinate to it or confirmed by the State Government
under Sub-section (3) , or a declaration has not been revealed by a state Government
under Sub- section (4), the Central Government may, whenever it considers it
accessory so to do, require the State Government to furnish to the Central
Government the information and materials on the basis of which such declaration
has been made or confirmed, or not revoked as the case may be, and such other
information and materials as the Central Government may deem necessary.
(9) Notwithstanding anything contained in any other law or any rule having the force
of law,--
(a) the grounds on which an order of detention is made or purported to be made
under Section 3 against any person in respect of whom a declaration is made under
Sub-section (2) or Sub-section (3) and any information or materials on which such
grounds or a declaration under Sub-section (3) or the non-revocation under
Sub-section (4) of a declaration are based, shall be treated as confidential and shall
be deemed to refer to matters of State and to be against the public interest to disclose
and save as otherwise provided in this Act, no one shall communicate or disclose any
such ground, information or material or any document containing such ground,
information or material;Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

(b) no person against whom an order of detention is made or purported to be made
under Section 3 shall be entitled to the communication or disclosure of any such
ground, information or material as is referred to in Clause (a) or the production to
him of any document containing such ground, information or material.
5. In Section 18 of the principal Act, for the words 'detained under this Act', the words and figure 'in
respect of whom an order is made or purported to be made under Section 3 shall be substituted, and
shall be deemed to have been substituted with effect from the 25th day of June, 1975.
6. Any act or thing done or purporting to have been done; before the 16th day of November, 1975,
under the principal Act in respect of any person against whom an order of detention was made
under that Act on or after the 25th day of June, 1975 or m respect of any such order of detention
shall, for all purposes, be deemed to be as valid and effective as if the amendments made to the
principal Act by Sections 2 and 3, and Clause (a) of Section 4, of this Act had been in force at all
material times.
149. During the pendency of these petitions under Article 226 of the Constitution of India before the
High Courts for issue of writs of habeas corpus, it was contended on behalf of the Union of India and
the States that view of the Presidential order dated June 27, 1975 under Article 359 suspending the
right of all persons to move any court for the enforcement of the enforcement of the rights conferred
by articles 14, 21 and 22 of the Constitution, petitions for issue of writs of habeas corpus were not
maintainable. Particular stress Was laid upon the fact that the right to move the court for
enforcement of the right under Article 21 had been suspended and such no petition for a writ of
habeas corpus could be preceded with. The above mentioned presidential order was stated to be an
absolute bar to the judicial security of the detention orders. This contention did not find favour with
the High Court and they held that despite the said Presidential order the petitions were
maintainable and could be proceeded with. Although opinions were not unanimous on the point as
to whether the High Court should without examining on the point as to whether the case go into the
question of the area of the judicial scrutiny and if so, what was the area of the judicial , all the nine
High Courts which dealt with the matter came to the conclusion that the Presidential order did not
create an absolute bar to the judicial scrutiny of the validity of the detention. The nine High Court
are:
(1) Delhi (2) karnatka (3) Bombay .(Nagpur Bench) (4) Allahabad (5) Madras (6)
Rajasthan (7) Madhya Pradesh (8) Andhra Pradesh (9) Punjab and Haryana.
150. In these appeals before us, learned Attorney-General on behalf of the appellants has drawn our
attention, to the difference in phraseology of the Presidential order; dated June ,21, 1975 and the
earlier Presidential orders dated November 3, 1962 and November 16, 1974 and has urged that in
view of the absolute nature of the Presidential order of June 27, 1975, petition for a writ of habeas
corpus is not maintainable.
151. There can be no doubt that the Presidential order dated June 27, 1975 has been worded
differently compared to the earlier Presidential orders which were issued under Clause (1) of ArticleAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

359 and that there has been a departure from the pattern which used to be adopted while issuing
such orders. The Presidential order dated November 16, 1974 has already been reproduced earlier.
Presidential order dated November 3, 1962 issued under Clause (1) of Article 359 of the Constitution
redd as under :
ORDER New Delhi the 3rd November, 1962 G.S.R 1464--In exercise pf the power
conferred by Clause(1) of Article 359 of the Constitution the President hereby
declares that the right of any person to move any court for the enforcement of the
right by Article 21 and article 22 of the Constitution shall remain suspended for the
period during which the Proclamation of emergency issued under Clause (1) of Article
352 thereof on the 26th October in 1962 is in force, if such person has been deprived
of any such rights under the Defence of, India Ordinance, 1962 (4 of 1962) or any rule
or order made thereunder.
On November 6, 1962, the rules framed under the Ordinance by the Central
Government were published. On November 11, 1962 the Presidential order
reproduced above was amended and for the words and figure "Article 21", the words
and figures "Articles 14 and 21" were substituted. The Defence of India Ordinance
was subsequently replaced by the Defence of India Act and the rules framed under
the Ordinance were deemed to have been framed under the Act. Perusal of the above
Presidential order of 1962 shows that what was suspended was the right of any
person to move any court for-the enforcement of rights conferred by Articles 14, 21
and 22. The suspension was, however, conditioned by the circumstance that such
person had been deprived of such rights under the Defence of India Act or any rule or
order made thereunder. It was plain that in case a detention order was made or any
other action was taken not under the provisions of the Defence of India Act or any
rule or order made thereunder, the same could not enjoy the protection of the
Presidential order under Article 359. Another effect of the Presidential order was that
as long as the proclamation of emergency was in force, the validity of the provisions
of the Defence of India Act or the rules or orders made thereunder could not be
assailed on the ground of being violative of Articles 14, 21 and 22. It is also clear that
in view of Article 358, while a proclamation of emergency was in operation, nothing
in Article 19 could have restricted the power of the State to make any law or to take
any executive action which the State could but for the provisions contained in Part III
was competent to make or to take.
152. Likewise, under the Presidential order dated November 16, 1974 which has been already
reproduced earlier, what was suspended was the right to move any court with respect to an order of
detention which might have been made or which might be made thereafter under Section 3(1) (c) of
the Maintenance of Internal Security Act as amended for the enforcement of rights conferred by
Articles 14, 21 and Clause (4) to (7) of Article 22 of the Constitution. Proceedings pending in any
court for the enforcement of any of the aforesaid rights with respect to orders of detention made
under Section 3(1)(c) too were suspended. It was plain from the language of the Presidential order
(hat there could be no suspension of the right mentioned in the Presidential order if the detentionAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

order could not be shown to have been made under Section 3(1)(c) of MISA because an order not
under Section 3(1)(c) was outside the Presidential order.
153. The Presidential order of 1962 under Article (1) of the Constitution came to be considered by
this Court in the case of Makhan Singh v. State, of Punjab Gajenndragadkar, J. (as he then was)
speaking for out of the Bench of seven Judges of this Court observed while dealing with the effect of
the Presidential order on a petition of habeas corpus :
We have already seen that the right to move any court which is suspended by Article
359(1) and the Presidential order issued under it is the right for the enforcement of
such of the rights conferred by Part III as may be mentioned in the order. If in
challenging the validity of ins detention order, the detenu is pleading any right
outside the rights specified in the order, ins right to move any court in that behalf is
not suspended, because it is outside Article 359(1) and consequently outside the
Presidential order itself. Let us take a case where a detenu has been detained in
violation of the mandatory provisions of the Act. In such a case, it may be open to the
detenu to contend that ins detention is illegal for the reason that the mandatory
provision of the Act have been contravened. Such a plea is outside Article 359(1) and
tile right of the detenu to move for ins release on such a ground cannot be affected by
the Presidential order.
Take also a ease where the detenu moves the Court for a writ of habeas corpus on the
ground that ins detention has been ordered malafide. It is hardly necessary to
emphasise that the exercise of a power malafide is wholly outside the scope of the Act
conferring the power and can always be successfully challenged. It is true that a mere
allegation that the detention is malafide would not be enough; the detenu will have to
prove the malafides; But if the malafides are alleged, the detenu cannot be precluded
from substantiating ins plea on the ground of the bar created by Article 359(1) and
the Presidential order. That is another kind of plea which is outside the purview of
Article 359(1).
It was further observed :
It is only in regard to that class of cases falling under Section 491(1) (b) where the
legality of the detention is challenged on grounds which fall under Article 359(1) and
Presidential order that the bar would operate. In all other cases falling under Section
491(1) the bar would be inapplicable and proceedings taken on behalf of the detenu
with have to be tried in accordance "with law. We ought to add that these categories
of pleas have been mentioned by us by way of illustrations, and so, they should not be
read as exhausting all the pleas which do not fall within the purview of the
Presidential order.
There is yet another ground on which the validity of the detention may be open to
challenge. If a detenu contends that the operative provision of the law under which heAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

is detained suffers from the vice of excessive delegation and is, therefore, invalid, the
plea thus raised by the detenu cannot at the threshold be said to be barred by the
Presidential order. In terms, it is not a, plea which is relatable to the fundamental
right specified in the said order. It is a plea which is independent of the said rights
and its validity must be examined.
154. In the case of Slate of Maharashtra v. Prabhakar Pandurang Sangzgiri and Anr. Subba Rao J,
(as he then was) speaking for the Constitution bench of this Court observed :
Article 358 of the Constitution suspends the provisions of Article 19, of Part III of the
Constitution during the period the proclamation of emergency is in operation; and
the order passed by the President under Article 359 suspended the enforcement, inter
alia, of Article 21 during the period of the said emergency. But the President's order
was a conditional one. In effect it said that the right to move the High Court or the
Supreme Court remained suspended if such a person had been deprived of ins
personal liberty under the Defiance of India Act, 1962, or any rule or order made
hereunder. If a person was deprived of his personal liberty not under the Act or a rule
or order made thereunder but in contravention thereof, his right to move the said
Courts in that regard would not be suspended. The question, therefore, in this case is
whether the first respondent's liberty, has been restricted in terms of the Defence of
India Riles whereunder he was detained. If it was in contravention of the said Rules
he would have the right to approach the High Court under Article 226 of the
Constitution.
155. Similar view was expressed in the case of Dr. Ram Manohar Lohia v. State of Bihar and Ors.
Sarkar J. (as be then was) in that case observed that where a person was detained in violation of the
mandatory provisions of the Defence of India Act, his right to move the court was not suspended.
Hidayatuilah and Bachawat JJ. referred to the fact that the Presidential order did not say that even
if a person; was proceeded against in breach of the Defence of India" Act or the rules, he could not
move the court or complain that the Act and the Rules under colour of which some action was taken
did not warrant it. The Presidential order was held to have not intended to condone an illegitimate
enforcement of the Defence of India Act, Raghubar Dayal J. held that the Court could go into the
question as to whether the District Magistrate exercised the power of detention under the Defence of
India Rules bonaflde and in accordance with the rules. MudhoBkar J. observed that if a detenu
contends that the order, though it purports to be under Rule 30(1) of the Defence of India Rules,
was not competently made, this Court had a duty to enquire into the matter. Sarkar, Hidayatuilah,
Mudholkar and Bachawat JJ, on consideration of the material before them found that as the
detention order had been made with a view to present the detenu from acting in a manner
prejudicial to the maintenance of law and older and not public order, as contemplated by Rule 30,
the detention, order was not in conformity with law. The petitioner in that case was accordingly
directed to be set at liberty.
156. The observations in the cases referred to-above show that the validity of the detention orders
could be assailed despite the Presidential orders of 1962 and 1974 under Article 359 in case the rightAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

relied upon was not one covered by these Presidential orders. The protection .afforded by those
Presidential of derswa net absolute, it was conditional and confined to ruling out the challenge to
detention orders and other actions taken under the provisions mentioned in those Presidential
orders on the score of contravention of the Articles specified in those orders. If the detention of a
detenu was not in accordance with the previsions mentioned in the Presidential -orders, the
Presidential orders did not have the, effect of affording protection to the detention order and it was
permissible to challenge the validity of the detention on the ground that it had not been made under
the specified provisions but in, contravention, of those provisions.
157. We may now deal with the Presidential order dated June 27, 1975 with which we are concerned.
Unlike the Presidential orders under Clause (1) of Article 359 issued earlier, this Presidential order
makes no reference to any detention order made under any specified provision. It seeks to impose a
blanket suspension of the right of any person, including a foreigner, to move any court for the
enforcement of the rights conferred by Articles 14, 21 and 22 of the Constitution and of all
proceedings pending to, any court for the, enforcement of the above mentioned rights for tile period
during which the proclamation of emergency is in force. The observations which were made by this
Court in the cases referred to above in the context of the phraseology of the earlier Presidential
orders of 1962 and 1974, namely, the detention orders made under specified provisions, cannot now
be relied upon while construing the ambit of the Presidential order o June 27, 1975.
158. The difference in phraseology 08 the Presidential order dated June 27, 1975 and that of the
earlier Presidential orders would not, however, justify the conclusion that because of the new
Presidential order dated June 27, 1975 a detention order need not comply with the requirements of
the law providing for preventive detention. Such a detention order would still be liable to be
challenged in a court on the ground that it does not comply with the requirement of law for
preventive detention if ground for such challenge be permissible in spite of and consistently with the
new Presidential order. The effect of the change in phraseology would only be that such of the
observations which were made in the cases mentioned above in the context of the language of the
earlier Presidential orders cannot now be relied upon. Reliance, however, can still be placed upon
the observations made in those cases which were not linked with the phraseology of the earlier
Presidential orders.
159. Question then arises as to what is the effect of the suspension of the right of a person to move
any court for the enforcement of rights conferred by Articles 14, 21 and 22 of the Constitution, One
obvious result of the above is that no one can rely upon Articles 14,21 and 22 with a view to seek
relief from any court. According to the stand taken by the learned Attorney General, the effect of the
suspension of the right of a person to move any court for the enforcement of the right conferred by
Article 21 is that even if the order for detention has been made- without the authority of law, no
redress can be sought from the court against such detention order. Article 21 of the Constitution
reads as under :
No person shall be deprived of ins life or personal liberty except according to
procedure established by law.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

It is urged that Article 21 is the sole repository of one's right to life or personal liberty.
The moment the right to move any court for enforcement of Article 21 is suspended,
no one can, according to the submission, complain to the court of deprivation of life
or personal liberty for any redress sought from the court on that score would be
enforcement of Article 21. Petition under Article 226 for the issue of a writ of habeas
corpus, it is contended by learned Attorney General, is essentially a petition to
enforce the right of personal liberty and as the right to move any court for the
enforcement of the right conferred by Article 21 is suspended, no relief can be
granted to the petitioner in such petition.
160. In order to assess the force of the above argument, it may be necessary to give the background
and the in story of Article 21. In the original draft of the Indian Constitution, in the Article which
now stands as Article 21 the words used were "in accordance with due process of law" instead of the
words "according to procedure established by law." The concept of expression "due process of law"
or its equivalent "law of the land" traces its lineage for back into the beginning of the 13th century
A.D. The famous 39th chapter of the Magna Carta provides that "no free man shall be taken or
imprisoned or disseized, or outlawed or exiled or in any way destroyed; nor shall we go upon him
nor send upon him but by the lawful judgment of ins peers and by the law of the land." Magna Carta
as a charter of English liberty was confirmed by successive English monarchs. It was in one of these
confirmations (28 Ed, III, Chap. 3) known as "Statute of Westminster of the liberties of London"
that the expression "due process of law" appears to have been used for the first time. Neither of the
expressions "due process of law" or "law of the land" was explained or defined in any of the
documents, but on the authority of Sir Edward Coke it may be said that both the expressions have
the same meaning. In substance, they guaranteed that persons should not be imprisoned without
proper indictment and trial by peers, and that property should not be seized except in proceedings
conducted in due form in which the owner or the person in possession should have an opportunity
to show cause why seizure should not be made. The expression "due process of law" came to be a
part of the US Constitution by the Fifth Amendment which was adopted in 1791 and which provided
that "no person shall.... be deprived of life, liberty or property without due process of law. Similar
expression was used in the Fourteenth Amendment in 1868. It has been said that few phrases in the
law are so elusive of exact apprehension as "due process of law." The United States Supreme Court
has always declined to give a comprehensive definition of it and has preferred that its full meaning
should be gradually ascertained by the process) of inclusion and exclusion in the course of the
decisions as they arise. The expression "due process of law," as used in the US Constitution, has
been taken to impose a limitation upon the powers of the Government, legislative as well as
executive and judicial. Applied in England as protection against executive usurpation and royal
tyranny, in America it became a bulwark against arbitrary legislation. "Due process of law,"
according to Cooley, "means in each particular case such an exercise of the powers: of Government
as the settled maxims of law permit and sanction, and under such safeguards for the protection of
individual rights as those maxims prescribe for the class of cases to which the one in question
belongs" (Constitutional Limitations, Vol. II, p. 741).
161. Till about the middle of the 19th Century, due process clause was interpreted as a restriction
upon procedure, and particularly the judicial procedure, by which the Government, exercises itsAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

power. Principally It related to the procedure by which persons were tried for crimes and
guaranteed to accused persons the right to have a fair trial in Compliance with well established
criminal proceedings. The same principle applied to the machinery or ;, proceedings by which
property rights were adjudicated and by which the powers of eminent domain and taxation were
exercised. ; During this period it was not considered to have any bearing on substantive law at all.
Subsequently view came to be accepted that the concept of due process of law protected rights of
life, liberty and property. This change in judicial thinking was influenced in a great measure by the
industrial development leading to accumulation of large capital in the hands of industrialists and
the emergence of a definite labouring class. What constituted legitimate exercise of the powers of
legislation now came to be a judicial question and no statute was valid unless it was reasonable in
the opinion of the Court The US Supreme Court laid stress upon the word "due" which occurs before
and qualifies the expression "process of law." "Owe" means "what is just and proper" according to
the circumstances of a particular case. The word introduces a variable element in the application of
the doctrine, for what is reasonable in one set of circumstances may not be so in another set of
circumstances. The requirement of due process clause as a substantial restriction on Government
control is also now becoming a thing of the past and the rule is being restricted more and more to its
original procedural aspect (see observations of Mukherjea J. in the case of A. K. Gopdlan, (supra).
162. At the tune the Constitution was being drafted, the Constitutional Adviser Mr. B. N. Rau had
discussions with US Constitutional experts some of whom expressed the opinion that power of
review implied in due process clause was not only undemocratic because it gave the power of vetoing
legislation to the judges, but also threw an unfair burden on the judiciary. This view was
communicated by Mr. Rau to the Drafting Committee which thereupon substituted the words
"except according to procedure established by law" for the words "due process, of law" In dropping
the, words "due process Of' law" the framers of on Constitution prevented the introduction of
elements of Vagueness, uncertainty and changeability which had grown round the due process
doctrine to the United States. The words "except according to procedure established by law" were
taken from Article 31 of the Japanese Constitution, according to which "no person shall be deprived
of life or liberty nor shall any criminal liability be imposed, except according to procedure
established by law. The article is also somewhat similar to Article 4Q(4)(i) of Irish Constitution,
according to which no person shall be deprived of ins personal liberty save in accordance with law."
ft was laid down in Gopalan's case by the majority that the word "law" has been used in Article 21 in
the sense of State-made law and not as an equivalent of law in the abstract or general sense
embodying the principles of natural justice. "The procedure established by law" was held to mean
the procedure established by law made by the State, that is to say, the Union Parliament or the
legislatures of the1 States, Law, i was also observed by Mukherjea J., meant a valid and binding law
under the provisions of the Constitution and not one infringing fundamental rights.
163. The effect of the suspension of the right to move any court for the enforcement of the right
conferred by Article 21, k my opinion, is that when a petition is filed in a court, the court would have
to proceed upon the basis that no reliance can be placed upon that Article for obtaining relief from
the court daring the period of emergency. Question then arises as to whether the rule that no one
shall be deprived of ins life or personal liberty without the authority of law stiff survives during the
period: of emergency despite the Presidential order suspending the right to move any court for theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

enforcement of the-right contained in Article 21. The answer to this question is linked with the
answer to the question as to whether Article 21 is, the sole repository of the right to life and personal
liberty. After giving the matter my earnest consideration, I am of the opinion that Article 21 cannot
be considered" to be the sole repository of the right to life and; personal liberty. The right to life, and
personal: liberty is the most precious right of human beings in civilised societies governed by the
rule of law. Many modern constitutions incorporate certain fundamental rights, including the one
relating to personal freedom. According to Blackstone, the absolute rights of Englishmen were the
rights of personal security, personal liberty and private property. The American Declaration of
Independence (1776) states that all men are created equal, and among their inalienable right are life,
liberty, and the pursuit of happiness. The Second Amendment to the US Constitution refers inter
alia to security of person, while the Fifth Amendment prohibits inter alia deprivation of life and
Bberty without due process of law. The different Declarations of Human Rights and fundamental
freedoms have all laid stress upon the sanctity of life and liberty. they have also given expression in
varying words to the principle that no one shall be derived of his: life or liberty without the authority
of law The International Commission of Jurists, which is affiliated of UNESCO, has been attempting
with, considerable success to give material content to ''the Rule-of Law," an expression used in the
Universal Declaration: of Human Rights. One of its most notable achievement was the Declaration
of Delhi, 1959. This resulted from a Congress held m New Delhi attended by jurists from more than
50 countries and was based on a questionnaire circulated to 75,000: lawyers. "Respect for the
supreme value of human personality" was stated to be the basis of all law (see page 21 of the
Constitutional; and Administrative Law by O. Hood Phillips, 3rd Ed.).
164. Freedom under law, it may be added, is not absolute freedom. It has its own limitations in its
own interest, and can properly be described as regulated freedom. In the words of Ernest Barker, (i)
the truth that every man, ought to be free has for its other side the complementary and
consequential truth that no man can be absolutely free; that (ii) the ased of liberty for each is
necessarily qualified and conditioned by the need of liberty for all: that (iii) liberty in the State or
legal liberty, as never the absolute liberty of all that (iv) liberty within the State is thus a relative and
regulated liberty; and that (v) a relative and regulated liberty; actually, operative and enjoyed, is a
liberty greater in amount than absolute liberty could ever be self indeed such liberty could ever exist,
or even amount to anything more than nothing at all.
165. Rule of law is the antithesis of arbitrariness. Plato believed that if philosophers were kings or
kings philosophers government by will would be intrinsically superior to government by law, and he
so proclaimed in ins Republic. Experience eventually, taught him that this ideal was not obtainable
and that if ordinary men were allowed to rule by will alone the interests of the community would be
scarified to these of the ruler. Accordingly^ in the Laws he modified ins position and urged the
acceptance of the "second best", namely government under law. Since the question of the relative
merits of rule by law as against rule by will has been often debated. In the aggregate the decision has
been in .favour of rule by law. On occasions, however, we have slipped back into government by will
only to return again, sadder and wiser men, to Plato's "second best" when the hard facts of human
nature demonstrated the essential egotism of men and the truth of the dictum that all power
corrupts and absolute power corrupts absolutely. Bracton's dicta that if the king has no bridle one
ought to be put upon in, and that although the king is under no man he is 'under God and the lawAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Fortescue's insistence that the realm of England is a reginem politicium et regale and hence limited
by law; Coke's observation that "Magna Carta is such a fellow that he will have no sovereign"; these
are but a few of the beacons lighting the way to the triumph of the rule of law (see pages 3-6 of the
Rule of Law by H. Malcolm Macdonald and Ors.). Rule of law is now the accepted norm of all
civilised societies. Even if there have been deviations from the rule of law, such deviations have been
covert and disguised for no government in a civilized country is prepared to accept the ignominy of
governing without the rule of law. As observed on page 77 of Constitutional Law by Wade and
Phillips, 8th Ed., the rule of law has come to be regarded as the mark of a free society. Admittedly its
content is different in different countries, nor is it to. be secured exclusively through the ordinary
courts. But everywhere it is identified with the liberty of the individual. It seeks to maintain a
balance between the opposing notions of individual liberty and public order. In every State the
problem arises of reconciling human rights with the requirements of public interest. Such
harmonising can only be attained by the existence of independent courts which can hold the balance
between citizen and State and compel Governments to conform to the law.
166. Sanctity of life and liberty was not something new when the Constitution was drafted. It
represented a fact of higher values which mankind began to cherish in its evolution from a state of
tooth and claw to a civilized existence. Likewise, the principle that no one shall be deprived of ins
life and liberty without the authority of law was not the gift of the Constitution. It was a necessary
corollary of the concept relating to the sanctity of life and liberty; it existed and was in force before
the coming into force, of the Constitution. The idea about the sanctity of life and liberty as well as
the principle that no one shall be deprived of his life and liberty without the authority of law are
essentially two facets of the same concept. This concept grew and acquired dimensions in response
to the inner urges and nobler impulses with the march of civilisation. Great writers and teachers,
philosophers and political thinkers nourished and helped in the efflorescence of the concept by
rousing the conscience of mankind and by making it conscious of the necessity of the concept as
necessary social discipline in self-interest and for orderly existence. According even to the theory of
social compact many aspects of which have now been discredited, individuals have surrendered a
part of their theoretically unlimited freedom in return or the blessings of the government. Those
blessings include governance in accordance with certain norms in the matter of life and liberty of the
citizens. Such norms take the shape of the rule of law. Respect for law, we must bear in mind, has a
mutual relationship with respect for government. Erosion of the respect for law, it has accordingly
been said, affects the respect for the government. Government under the law means, as observed by
Macdonald, that the power to govern shall be exercised only, under conditions laid down in
constitutions and laws approved by either the people or their representatives. Law thus emerges as a
norm limiting the application of power by the government over the citizen or by citizens over their
fellows. Theoretically all men are equal before the law and are equally bound by it regardless of their
status, class, office or authority. At the same time that the law enforces duties it also protects rights,
even against the sovereign. Government under law thus seeks the establishment of an ordered
community in which the individual, aware of ins rights and duties, comprehends the area of activity
within which, as a responsible and intelligent person, he may freely order ins life, Secure from
interference from either the government or other individuals (see Rule of Law, page 6). To quote
further from Professor Macdonald :Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

It is clear enough that high echelon administrators are understandably impatient
with the restraints imposed upon them by the traditional concept of the rule of law as
developed by Dicey. Administrators deal with the implementation of highly technical
and complex matters involving the immediate interests of many citizens. To
accomplish this they are granted wide discretion in the use of administrative power to
effectuate broad policies laid down by the legislatOrs. It is natural, that they should
desire to have the conflicts which arise as the result Of the exercise of their discretion
adjudicated by tribunals composed of experts acquainted with the details of the
matters at issue, rather than by judges trained only in the law. Hence their resistance
to judicial review of administrative 'findings of fact' as opposed to 'findings of law'.
The very things which a court of law prizes--rules of evidence, common law
procedures, even due process--frequently appear to the administrators as
obscurantist devices employed by those who oppose the very principle of the policy
he is attempting to effectuate. Often, secretly if not openly, the administrator
considers ins policy to be the incarnation of the best interests of the people, or at least
of their best interests if they really understood them, and hence considers himself as
arrayed on the side of progress and light against the dark forces of reaction.
Thus our 'wonderland of bureaucracy', as Beck has called it, has sought autonomy
from the traditional rule of courts and law. If it should succeed we should then indeed
be confronted with a vital segment of govern mental power which would have
escaped from legal control and become arbitrary in its acts. To prevent this we have
subjected the acts of administrators to challenge in the courts on the basis of ultra
vires, and provided for judicial review of administrative tribunals' rending of law.
167. To use the words of Justice Brandeis Olmstead v. United States, 277 U. S. 438(1928) with some
modification, experience should, teach us to be most on our guard to protect liberty when the
Government's purposes are beneficent. Men born to freedom are naturally alert to repel invasion-of
their liberty by evil-minded persons. Greatest danger to liberty lies in insidious encroachment by
men of zeal, well-meaning but lacking in due deference for the rule of few.
168. Even in the absence of Article 21 in the. Constitution, the State has got no power to deprive a
person of ins life or liberty without the authority of law. This is the essential postulate and basic
assumption of the rule of law and not of men in all civilised nations. Without such sanctity of life
and liberty, the distinction between a lawless society and one governed by laws would cease to have
any meaning. The principle that no one shall be deprived of his life or liberty without the authority
of law is rooted in, the consideration that life, and liberty are priceless possessions which cannot be
made the plaything of individual whim and caprice and that any act which has the effect of
tampering with life and liberty must receive sustenance from and sanction of the laws of the land.
Article 21 incorporates an essential aspect of that principle and makes it part of the fundamental
rights guaranteed in Part III of the Constitution. It does not, however, follow from the above that if
Article' 21 had not been drafted and inserted in Part III, in that event it would have been permissible
for the State to deprive a person of his life or liberty without the authority of law. No case has been
cited before us to show that before the coming into force of the Constitution or in countries underAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Rule of law where there is no provision corresponding to Article 21, a claim was ever sustained by
the courts that the State can deprive a person of ins life or liberty without the authority of law. In
fact, any suggestion to such a claim Was un-equivocally repelled. In the case of James Sbmmersett
[1772], 16 Cr. pract.289 Lord Mansfield dealt with a case of a negro named Sommersett,: who was
being taken in a ships to Jamaica for sale in a slave market. When the ships-anchored at London
port, a habeas corpus petition was presented by some Englishmen who were moved by the yelling
and cries of Sommersett. In opposition to the petition the slave trader took the plea that there was
no law which prohibited slavery. Lord Mansfield while repelling this objection made the following
observation in respect of slavery which is one of the worst forms of deprivation of personal freedom
:
It is so odious that nothing can be suffered to support it but positive law: whatever
inconveniences, therefore, may follow from this decision, I cannot' say this case is
allowed or approved by the law of England; and therefore the black must be
discharged.
In other case, Fabnqas v. Mostyn 1 Cowp.,161 Lord Mansfield observed on page 173 :
To lay down in an English court of Justice that a Governor acting, by virtue of Letters
Patent, under the Great Seal, is accountable only to God and his own conscience; that
he is absolutely despotic? and can spoil plunder, and affect His Majesty's subjects,
both in their liberty and property, with impunity, is a doctrine that cannot be:
maintained.
The above observations were relied upon in the matter of Ammer Khan 6 Bengal Law
Reports 292. I may also refer to the observations of Lord Atkin in the case of
Eshiuqbavi Eteko v. Officer Administering the Government of Nigeria AIR 1931 P.C.
248:
In accordance with British jurisprudence, no member of the executive can interfere
with the liberty or property of a British subject except on the condition that he can
support the legality of ins action before a Court of Justice. And it is the tradition of
British Justice that Judges should net shrink from deciding such issues in the face of
the executive.
The above rule laid down in Eleko's ease was followed by the High Courts in India
before the coming into force of the Constitution in Prabkakar Kesheo Tare and Ors. v.
Emperor AIR 1943 Nag. 26. Vimlabai Deshpande v. Emperor A.I.R. 1945 Nag. 8,
Htendranath Ghosh v. The Chief Secretary to the Government of Bengal I. L. R. 60
CaL. 364 and in re : Banwari Lal Roy and Ors. 48 C W.N. 766. The rule laid down in
Eleko's case was also followed by the Constitution Beaches of this Court after the
coming force of the Constitution in the cases of Bidi Supply Co. v. The Union of India
and Ors. [1956] S. C. R. 267 and Basheshar Nath v. The Commissioner of Income-tax,
Delhi & Rajasthan and Anr. [1959] Supp. (1) S. C. R. 528.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

169. I am unable to subscribe to the view that when right to enforce the right under Article 21 is
suspended, the result would be that there would be no remedy against deprivation of a person's life
or liberty by the State even though such deprivation is without the authority of law or even in
flagrant violation of the provisions of law. The right not to be deprived of one's life or liberty without
the authority of law was not the creation of the Constitution. Such right existed before the
Constitution came into force. The fact that the framers of the Constitution made an aspect of such
right a part of the fundamental rights did not have the effect of exterminating the independent
identity of such right and of making Article 21 to be the sole repository of that right. Its real effect
was to ensure that a law under which a person can be deprived of ins life or personal liberty should
prescribe a procedure for such deprivation or, according to the dictum laid down by Mukherjea, J. in
Gopalan's case, such law should be a valid law not violative of fundamental rights guaranteed by
Part III of the Constitution. Recognition as fundamental right of one aspect of the pre-Constitutional
right cannot have the effect of making things less favourable so far as the sanctity of life and
personal liberty is concerned .compared to the position if an aspect of such right had not been
recognised as fundamental right because, of the vulnerability of fundamental rights accruing from
Article 359. I am also unable to agree that in view of the Presidential Order in the matter of sanctity
of life and liberty, things would be worse off compared to the state of law as it existed before the
coining into force of the Constitution.
170. The case of Dhirubha Devisingh Gohil v. The. State of Bombay upon which reliance has been
placed by learned Attorney General cannot be of much assistance to him. In that case this. Court
held that the validity of the Borhbay Taluqdari Tenure Abolition Act, 1949 cannot be questioned on
the ground that it takes, away or abridges the fundamental rights conferred by the Constitution of
India in view of the fact that that Act had been inserted in the Ninth Schedule of the Constitution.
This Court also repelled the contention that the said Act was violative of Section 229 of the
Government of India Act, 1935 because, in the opinion of the Court, the right secured by Section 229
was lifted into the formal category of a fundamental right. The principle laid down in that case
cannot be, invoked in a case like the present wherein the area covered by the right existing since
before the Constitution is wider, than the area covered by the fundamental right and the
fundamental right deals with only an aspect of such pre-existing right. Moreover, the correctness of
the view taken in the above case, in my opinion, is open to question in view of the later decision of
Makhan Singh (supra) decided by a Bench of seven Judges wherein it has been observed on page
821 that after the coming into force of the Constitution, a detenu has two remedies, one under
Article 226 or Article 32 of the Constitution and another under Section 491 of the CrPC. Makhan
Singh's case, as discussed elsewhere, shows that the remedy under an earlier statutory provision
would not get obliterated because of the identical remedy by a subsequent Constitutional provision
and that the two can co-exist without losing their independent identity.
171. Preventive detention, though not strictly punishment, is akin to punishment, because of the evil
consequences of being deprived of one's liberty. No one under our laws can be deprived of ins life or
liberty without the authority of law. This would be evident from the fact that if a person without the
authority of law takes another person's life, he would normally be guilty of the offence of culpable
homicide. Likewise, if a person deprives another of ins liberty by confining him, he would in the
absence of any valid justification, be guilty of wrongful confinement. It is for that reason that courtsAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

have insisted upon the authority of law for a public servant to take away someone's life or liberty. An
executioner carrying out the sentence of death imposed by the court would not commit the offence
of homicide, because he is executing the condemned man in obedience to a warrant issued by a
court haying jurisdiction in accordance with the law of the land. Likewise, a jailor confining a person
sentenced to imprisonment is not guilty of the offence of wrongful confinement. The principle that
no one shall be deprived of his life or liberty without the authority of law stems not merely from the
basic assumption in every civilised society governed by the rule of law of the sanctity of life and
liberty, it flows equally from the fact that under out penal laws no one is empowered to deprive a
person of ins life or liberty without the authority of law.
172. The fact that penal laws of India answer to the description of the word "law", which has been
used in Article 21 would not militate against the inference that Article 21 is not the sole repository of
the right to life or personal liberty and that the principle that no one shall be deprived of ins life or
personal liberty without the authority of law flows from the penal laws of India. Nor is it the effect of
Article 21 that penal laws get merged in Article 21 because of the fact that they constitute "law" as
mentioned in Article 21, for were it so the suspension of the right to move a court for enforcement of
fundamental right contained in Article 21 would also result in suspension of the right to move any
court for enforcement of penal . laws.
173. It has been pointed out above that even before the coming into force of the Constitution, the
position under the common law both in England and in India was that the State could not deprive a
person of ins life and liberty without the authority of law. The same was the position under the penal
laws of India. It was an offence under the Indian Penal Code, as already mentioned, to deprive a
person of ins life or liberty unless such a course was sanctioned by the laws of the land. An action
was also maintainable under the law of torts for wrongful confinement in case any person was
deprived of ins personal liberty without the authority of law. In addition to that, we. had Section 491
of the CrPC which provided the remedy of habeas corpus against detention without the authority pf
law. Such laws continued to remain in force in view of Article 372 after the coming into force of the
Constitution. According to that article, notwithstanding the repeal by this Constitution of the
enactments referred to in Article 395 but subject to the other provisions of this Constitution, all the
law in force in the territory of India immediately before the commencement of this Constitution
shall continue in force therein until altered or repealed or amended by a competent legislature or
other competent authority. The law in force, as observed by the majority of he Constitution Bench in
the case of Director of Rationing and Distribution v. The Corporation of Calcutta and Ors. , include
not only the statutory law but also custom or usage haying the force of law as also the common law
of England which, was adopted as the law of the country before the coming into force of the
Constitution. The position thus seems to be firmly established that at the time, the Constitution
came into force, the legal position was that no one could be deprived of ins life or liberty without
the-authority of law.
174. It is difficult to accede to the contention that because of Article 21 of the Constitution, the law
which was already in force that no one could be deprived of ins life or liberty without the authority
of law was obliterated and ceased to remain in force. No rule of construction interpretation warrants
such an inference. Section 491 of the CrPC continued to remain an integral part of that Code despiteAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

the fact that the High Courts were vested with the power of issuing writs of habeas corpus under
Article 226. No submission was ever advanced on the score that the said provision had become a
dead letter of enforceable because of the fact that Article 226 was made a part of the Constitution,
Indeed, in the case of Makhan Singh (supra) Gajendragadkar J. speaking for the majority stated that
after the coming into force of the Constitution, a party could avail of either the remedy of Section
491 of the CrPC or that of Article 226 of the Constitution. The above observations clearly go to show
that constitutional recognition of the remedy of writ of habeas corpus did not obliterate or abrogate
the statutory remedy of writ of habeas corpus. Section 491 of the CrPC continued to be part of that
Code till that Code was replaced by the new Code. Although the remedy of writ of habeas corpus is
not now available under the new CrPC, 1973, the same remedy is still available under Article 226 of
the Constitution.
175. Our attention has been invited to Section 18 of the maintenance of Internal Security Act as
amended. According to that section, no person, including a foreigner, in respect of whom an order is
made or purported to be made under Section 3 shall have any right to personal liberty by virtue of
natural law or common law, if any. This Section would not, in my opinion, detract from my
conclusion that Article 21 is not the sole repository of the right to personal liberty. It has been
pointed out above that the principle that no one shall be deprived of ins life and personal liberty
without the authority of laws follows not merely from common law, it flows equally from statutory
law like the penal law in force in India. The above principle, as would appear from what has been
discussed elsewhere, is also an essential facet of the rule of law. Section 18, therefore, cannot be of
much assistance to the appellants. I am also unable to subscribe to the view that Section 18 would
have the effect of enlarging the ambit of the power of the detaining authority for the purpose of
passing an order for detention. There has been, it needs to be emphasised, no amendment of Section
3 of the Act. Section 18 cannot be construed to mean that even if an order for detention is made on
grounds not warranted by Section 3 of the Act, it shall be taken to be an order under Section 3 of the
Act. Apart from the fact that such an inference is not permissible on the language of Section 18, the
acceptance of this view would also render the validity of Section 18 open to question on the ground
that it suffers from the vice of excessive delegation, of legislative power. The legislature is bound to
lay down the legislative policy by prescribing the circumstances in which an order for detention can
be made. It is not permissible for the legislature to confer, a power of detention without laying down
guidelines and prescribing the circumstances in which such order should be made. To do so would
be tantamount to abdication of legislatitve function for in such an event it would be open to the
detaining authority to detain a person on any ground whatsoever.
176. I agree with the learned Attorney General that if we are to accept ins argument about the scope
of the Presidential order of June 27, 1975, in that event we have to accept it in its entirety and go the
whole hog; there is no half way house in between. So let us examine the consequences of the
acceptance of the above argument. This would mean that if any official, even a head constable of
police, capriciously or maliciously, arrests a person and detains him indefinitely without any
authority of law, the aggrieved person would not be able to seek any relief from the courts against
such detention during the period of emergency. This would also mean that it would not be necessary
to enact any law on the subject and even in the absence of any such law, if any official for reasons
which have nothing to do with the security of State or maintenance of public order, but because ofAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

personal animosity, arrests and puts behind the bar any person or a whole group or family of
persons, the aggrieved person or persons would not be able to seek any redress from a court of law.
The same would be the position in case of threat of deprivation or even actual deprivation of life of a
person because Article 21 refers to both deprivation of life as well as personal liberty. Whether such
things actually come to pass is not the question before us; it is enough to state that all these are
permissible consequences from the acceptance of the contention that Article 21 is the sole repository
of the right to life and personal liberty and that consequent upon the issue of the Presidential order,
no one can approach any court and seek relief during the period of emergency against deprivation of
life or personal liberty. In order words, the position would be that so far as executive officers are
concerned, in matters relating to life and personal liberty of citizens, they would not be governed by
any law, they would not be answerable to any court and they would be wielding more or less
despotic powers.
177. To take another illustration. Supposing the Presidential order under Article 359(1) were to
mention Article 21 but not Article 22. The acceptance of the above submission advanced on behalf of
the appellants would mean that if the State does not release a detenu despite the opinion of the
Advisory Board that there is no sufficient cause for ins detention and thus keeps him in detention in
flagrant violation of the provisions of Article 22, no habeas corpus petition would be maintainable
and this would be so even though Article 22 itself is a fundamental right.
178. The right to move a court for enforcement of a right under Article 19 has now been suspended
by the President under an order issued under Article 359(1). The effect of that, on a parity of
reasoning advanced on behalf of the appellant would be, that no one can file a suit during the period
of emergency against the State for recovery of property or money (which is a form of property)
because such a suit, except in some contingencies, would be a suit to enforce the right contained in
Article 19.
179. Not much argument is needed to show that if two constructions of Presidential order were
possible, one leading to startling results and the other not leading to such results, the court should
lean in favour of such construction as would not lead to such results.
180. Equally well established is the rule of construction that if there be a conflict between the
municipal law on one side and the international law or the provisions of any treaty obligations on
the other, the courts would give effect to municipal law. If, however, two constructions of the
municipal law are possible, the court should lean in favour of adopting such construction as would
make the provisions of the municipal law to be in harmony with the international law or treaty
obligations. Every statute, according to this rule, is interpreted, so far as its language permits, so as
not to be inconsistent with the committee of nations or the established rules of international law,
and the court will avoid a construction which would give rise to such inconsistency unless compelled
to adopt it by plain and unambiguous language. But if the language of the statute is clear, it must be
followed notwithstanding the conflict between municipal and international law which results (see
page 183 of Maxwell on the Interpretation of Statutes, Twelfth Edition.) As observed by
Oppenheim's International law, although municipal courts must apply Municipal Law even if it
conflicts with the law of Nations, there is a presumption against the existence of such a conflict. AsAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

the Law of Nations is based upon the common consent of the different States, it is improbable that
an enlightened State would intentionally enact a rule conflicting with the Law of Nations. A rule of
Municipal Law, which ostensibly seems to conflict with the Law of Nations, must, therefore, if
possible, always be so interpreted as to avoid such conflict (see Vol. I, pages 45-46), Lord Denning
gave expression to similar view in the case of Corocraft Ltd. v. Pan American Airways Inc. [1969] 1
All E. R. 80 when he observed :
The Warsaw Convention is an international convention which is binding in
international law on all the countries who have ratified it: and it is the duty of these
courts to construe our legislation so as to be in conformity with international law and
not in conflict with it.
The rule about the construction of municipal law also holds good" when construing
the provisions of the Constitution as would appear from International Law by
Fenwick, Third Edition, page 90, wherein is observed:
But while in the case of a direct conflict between national and international law, the
rule of national law will of necessity take priority until changed to conform to the
international obligations of the state, there are numerous cases in which the
provisions of the national Constitution of the provisions of a particular legislative act
are not so explicit but that they may be interpreted so as to enable the executive and
the judicial agencies of the state to act in-accordance with the obligations (of
international law.
According to Article 51 our Constitution, the State shall endeavor to inter alia foster
respect for international law and treaty obligations in the dealings of organised
peoples with one another. Relying open that article, Sikri CJ. observed in the case of
Kesavananda Blwrathi v. State of Kerala [1973] Supp. S.C.R. 1:
it seems to me that, in view of Article 51 of the directive principles, this Court must
interpret language of the Constitution, if mot intractable, which is after all a
municipal law, in the light of the United Nations Charter and the solemn declaration
subscribed to by India.
Articles 8 and 9 of the Universal Declaration of Human Rights in respect of which
resolution was passed by the United Nations and was supported by India read as
under :
ARTICLE 8 Everyone has the right to an effective remedy by the competent national
tribunals for acts violating the fundamental rights granted him by the Constitution or
by law.
ARTICLE 9 No one shall be subjected to arbitrary arrest, detention or exile.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

181. While dealing with the Presidential order under Article 359(1), we should adopt such a
construction as would, if possible, not bring it in conflict with the above Articles 8 and 9. From what
has been discussed elsewhere, it is plain that such a construction is not only possible, it is also
preeminently reasonable. The Presidential order, therefore, should be so construed as not to
warrant arbitrary arrest or to bar right to an effective remedy by competent national tribunals for
acts violating basic right of personal liberty granted by law.
182. It has been argued that suspending the right of a person to move any court for the enforcement
of right to life and personal liberty is done under a constitutional provision and therefore it cannot
be said that the resulting situation would mean the absence of the rule of law. This argument, in my
opinion, cannot stand close scrutiny for it tries to equate illusion of the rule of law with the reality of
rule of law. Supposing a law is made that in the matter of the protection of life and liberty, the
administrative officers would not be governed by any law and that it would be permissible for them
to deprive a person of life and liberty without any authority of law. In one sense, it might in that
event be argued that even if lives of hundreds of persons are taken capriciously and maliciously
without the authority of law, it is enforcement of the above enacted law. As observed by Friedman
on page 500 of Law in Changing Society, 2nd Ed., in a purely formal sense, any system of norm
based on a hierarchy of orders, even the organised mass murders of Nazi regime qualify as law. This
argument cannot however, disguise the reality of the matter that hundreds of innocent lives have
been taken because of the absence of rule of law. A state of negation of rule of law would not cease to
be such a state because of the fact that such a state of negation of rule of law has been brought about
by a statute. Absence of rule of law would nevertheless be absence of rule of law even though it is
brought about by a law to repeal all laws. In the words of Wade, Government under the rule of law
demands proper legal limits on the exercise of power. This does not mean merely that acts of
authority must be justified by law, for if the law is wide enough it can justify a dictatorship based on
the tyrannical but perfectly legal principle quod principal placuit legis habet vigorem. The rule of
law requires something further. Powers must first be approved by Parliament, and must then be
granted by Parliament within definable limits (see Administrative Law, Third Edition, page 46). It is
no doubt true that Dicey's concept of rule of law has been criticised by subsequent writers since it
equates the rule of law with the absence not only of arbitrary but even of wide discretionary power.
The following reformulation of Dicey's ideas as applicable to modern welfare state given by H.W.
Jones eliminates the equation of arbitrary and wide discretionary powers :
There are, I believe, ideas of universal validity reflected in Dicey's 'three meanings' of
the rule of law.....(1) in a decent society it is unthinkable that government, or any
officer of government, possesses arbitrary power- over the person or the interests of
the individual; (2) all members of society, private persons and governmental officials
alike, must be equally responsible before the law; and (3) effective judicial-remedies
are more important than abstract constitutional declarations in securing the rights of
the individual against encroachment by the State" (see Law in a Changing Society by
Friedmann, 2nd Ed., page 501).
183. One of the essential attributes of the rule of law is that executive action to the prejudice of or
detrimental to the right of an individual must have the sanction of some law. This principle has nowAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

been well settled in a chain of authorities of this Court.
184. In the case of Rai Sahib Ram Jawaya Kapur and Ors. v. The State of Punjab Mukherjea C.J.
speaking for the Constitution Bench of this Court observed:
Specific legislation may indeed be necessary if the Government require certain
powers in addition to what they possess under ordinary law, in order to carry on the
particular trade or business. Thus when it is necessary to encroach upon private
rights in order to enable the Government to carry on, their business, a specific
legislation sanctioning such course would have to be passed.
185. The above attribute of the rule of law has been specially highlighted in the decision of this
Court1 in the case of State of Madhya Pradesh and Anr. v. Thakur Bharat Singh . In that case the
State Government made an order under Section 3 of the Madhya Pradesh Public Security Act, 1959,
directing that the respondent (i) shall not be in any place in Raipur District, (ii) shall immediately
proceed to and reside in a named town, and (iii) shall report daily to a police station in that town.
The respondent challenged the order by a writ petition under Articles 226 and 227 of the
Constitution on the ground inter alia, that Section 3 infringed the fundamental rights guaranteed
under Article 19 of the Constitution. The High Court declared Clauses (ii) and (iii) of the order
invalid on the ground that Clauses (b) and (c) of Section 3 (i) of the Madhya Pradesh Public Security
Act on which they were based contravened Article 19. On appeal this Court held that Section 3 (i) (b)
violated Article 19 and as it was a pre-emergency enactment, it must be deemed to be void when
enacted. Section 3 (i) (b) was further held not to have revived as a result of the proclamation of
emergency by the President. Counsel for the State submitted in the alternative that even if Section 3
(i) (b) was void, Article 358 protected action, both legislative and executive, taken after
proclamation of emergency, and therefore any executive action taken by the State would not be
liable to be challenged on the ground that it infringed the fundamental freedoms under Article 19;
This contention was repelled. Shah J. (as he then was) speaking for the Court observed :
All executive action which operates to the prejudice of any person must have the
authority of law to support it, and the terms of Article 358 do not detract from that
rule. Article 358 expressly authorises the State to take legislative or executive action
provided such action was competent for the State to make or take, but for the
provisions contained in Part III of the Constitution. Article 358 does not purport to
invest the State with arbitrary authority to take action to the prejudice of citizens and
others: it merely provides that so long as the proclamation of emergency subsists
laws may be enacted, and executive action may be taken in pursuance of lawful
authority, which if the provisions of Article 19 were operative would have been
invalid. Our federal structure is founded on certain fundamental principles: (1) the
sovereignty of the people with limited Government authority i. e. the Government
must be conducted in accordance with the will of the majority of the people. The
people govern themselves through their representatives, whereas the official agencies
of the executive Government possess only such powers as have been conferred upon
them by the people; (2) There is distribution of powers between the three organs ofAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

the State-legislative, executive and judicial-each organ having some check direct or
indirect on the other: and (3) the rule of law which includes judicial review of
arbitrary executive actions. As pointed out by Dicey in ins 'Introduction to the study
of the Law of the Constitution', 10th Edn., at p. 202 the expression 'rule of law' has
three meanings, or may be regarded from three different points of view. 'It means in
the first place, the absolute supremacy or predominance of regular law as opposed to
the influence of arbitrary power, and excludes the existence of arbitrariness, of
prerogative or even of wide discretionary authority on the part of government.' At p.
188 Dicey points out: In almost every continental community the executive exercises
far wider discretionary authority in the matter of arrest, of temporary imprisonment,
of expulsion from its territory, and the like, than is either legally claimed or in fact
exerted by the government in England : and a study of European polities now and
again reminds English readers that wherever there is discretion there is room for
arbitrariness, and that in a republic no less than under a monarchy discretionary
authority on the part of the government must mean insecurity for legal freedom ion
the part of its subjects.' We have adopted under our Constitution not the Continental
system but the British system under which the rule of law prevails. Every act done by
the Government or by its officers must, if it is to operate to the prejudice of any
person, be supported by some legislative authority.
186. In Chief Settlement Commissioner, Rehabilitation Department, Punjab and Ors. etc. v. Om
Parkash and Ors. a Division Bench of this Court observed :
In our constitutional system, the central and most characteristic feature is the
concept of the rule of law which means, in the present context, the authority of the
law courts to test all administrative action by the standard of legality.. The
administrative or executive action that does not meet the standard will be set aside if
the aggrieved person brings the appropriate action in the competent court.
187. In District Collector of Hyderabad and Ors. v. M/s. Ibrahim & Co. etc. the respondents who
were recognized dealers in sugar were prevented by an executive order from carrying on the
business. The question which actually arose for decision before this Court was whether the said
order was protected under Articles 358 and 359 because of the declaration of state of emergency by
the president. Shah j. speaking for Bench of six Judges of this Court observed :
But the executive order immune from attack is only that order which the State was
competent, but for the provisions contained in Article 19, to make. Executive action
of the State Government which is otherwise invalid is not immune from attack,
merely because a proclamation of emergency is in operation when it is taken. Since
the order of the State Government was plainly contrary to the statutory provisions
contained in the Andhra Pradesh Sugar Dealers Licensing Order and the Sugar
Control order, it was not protected under under Article 358 of the Constitution.
Nor had it the protection under Article 259.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

188. In Bennett Coleman & Co. and Ors. v. Union of India Ray J. (as he then was) speaking for the
majority of the Constitution Bench jelled upon Thakur Bharat Singh and M/s. Ibrahim & Co. cases
(supra) and observed :
Executive action which is unconstitutional is not immune during the proclamation of
emergency. During the proclamation of emergency Article 19 is suspended. But it
would not authorise the taking of detrimental executive action during the emergency
affecting the fundamental rights in Article 19 without any legislative authority or in
purported exercise of power conferred by any per-emergency law which was invalid
when enacted.
189. In Shree Meenakshi Mills Ltd. v. Union of India this Court dealt with petitions challenging the
validity of the fixation of price of cotton yarns under an executive order. Objection was raised to the
maintainability of the petitions on the score of proclamation of emergency. This objection was
repelled and reliance was placed on the decision of the Court in the case of Bennett Coleman & Co.
190. In Naraindas Indurkhya v. The State of Madhya Pradesh the Constitution Bench of this Court
to which three of us (Ray C. J, Khanna and Bhagwati JJ.) were parties placed reliance on the
decisions in the cases of Ram Jawaya Kapur, Thakur Bharat Singh and Bennett Coleman & Co.
(surpa)
191. These authorities clearly highlight the principle that executive authorities cannot under the rule
of law take any action to the prejudice of an individual unless such action is authorised by law. A
fortiori it would follow that under the rule of law it is not permissible to deprive a person of ins life
or personal liberty without the authority of law.
192. It may be appropriate at this age to refer to other cases in which stress has been laid on rule of
law by this Court.
193. Wanchoo J. in the case of Director of Rationing and Distribution v. The Corporation of Calcutta
and Ors. stated that in our country the rule of law prevails and our Constitution has guaranteed it by
the provisions contained in Part III thereof as well as other provisions in other Parts.
194. In Bishan Das and Ors. v. The State of Punjab and Ors. S. K. Das J. speaking for the
Constitution Banch of this Court deprecated action taken by the State and its officers on the ground
that it was destructive of the basic principles of the rule of law.
195. In G. Sadanandan vi. State of Kerala and Anr. (supra) Gajendragadkar CJ. speaking for the
Constitution bench observed that the paramount requirement of the Constitution was that even
during emergency the freedom of Indian citizens would not be taken away without the existence' of
justifying necessity specified by the Defence of India Rules.
196. In S. G. Jaisinghani v. Union of India and Ors. , Ramaswami J. speaking for the Constitution
Bench of this Court observed as under :Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

In this context it is important to emphasise that the absence of arbitrary power is the
first essential of the rule of law upon which our whole constitutional system is based.
In a system governed by rule of law, discretion, when conferred upon executive
authorities, must be confined within clearly defined limits. The rule of law from this
point of view means that decisions should be made by the application of known
principles and rules and, in general, such decisions should be predictable and the
citizen should know where he is. If a decision is taken without any principle or
without any rule it is unpredictable and such a decision is the antithesis of a decision
taken in accordance with the rule of law. (See Dicey--'Law of the Constitution'--Tenth
Edn., Introduction ex). 'Law has reached its finest moments', stated Douglas, J. in
United States v. Wunderlick 342 U. S. 98, 'when it has freed man from the unlimited
discretion of some ruler...Where discretion is absolute, man has always suffered'. It is
in this sense that the rule of law may be said to be sworn enemy of caprice.
Discretion, as Lord Mansfield stated it in classic terms in the case of John. Wilkes
(1770) 4 Burr. 2528 at 2539, 'means sound discretion guided by law. It must be
governed by rule, not by humour : It must not be arbitrary, vague and fanciful.
197. In the case of Shrimati Indira Nehru Gandhi v. Shri Raj Naraia both Ray CJ. and Chandrachud
J. laid stress on the rule of Jaw in our constitutional scheme.
198. It would not, in my opinion, be correct to consider rule of law as a vague or nebulous concept
because of its description as an unruly horse by Ivor Jennings. Indeed, according to Jennings, the
rule of law demands in the first place that the powers of the Executive should not only be derived
from law, but that they should be limited by law. Whatever might be the position in peripheral cases,
there are certain aspects which constitute the very essence of the rule of law. Absence of
arbitrariness and the need of the authority of law for official acts affecting prejudicially rights of
individuals is one of those aspects. The power of the courts to grant relief against arbitrariness or
absence of authority of law in the matter of the liberty of the subject may now well be taken to be a
normal feature of the rule of law. To quote from Halsbury's Laws of England, Third Edition, Vol. 7,
para 416, the so-called liberties of the subject are really implications drawn from the two principles
that the subject may say or do what he pleases, provided he does not transgress substantive law, or
infringe the legal rights of others, whereas public authorities including the Crown) may do nothing
but what they are authorised to do by some rule of common law or statute. The essence of rule of
law., according to Prof. Goodhart, is that public officers are governed by law, which limits their
powers. It means Government under law--the supremacy of law over the Government, as distinct
from Government by law--the mere supremacy of law in society generally--which would apply also
to totalitarian states (See page 42 of constitutional and Administrative Law by Hood Phillips, Third
Edition).
199. I may mention that there has been an amendment of Article 359 inasmuch as Clause (1A) has
been added in that article. The effect of the insertion of that clause in Article 359 is that while an
order made under Clause (1) mentioning any of the rights conferred by Part III is in operation,
nothing in that Part conferring those rights shall restrict the power of the State to make any law or
to take any executive action which the State would but for the provisions contained in that Part beAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

competent to make or to take, but any law so made shall, to the extent of the in competency, cease to
have effect as soon as the order aforesaid ceases to operate, except as respects thing done or omitted
to be done before the law so ceases to have effect. Clause (1A) thus protects laws and executive
actions from any attack on validity on the score of being violative of the fundamental rights
mentioned in the Presidential order in the same way as Article 358 protects the laws and executive
actions from being challenged on the ground of being violative of Article 19 during the period of
emergency. If the existence of Article 358 did not have the effect of dispensing with the necessity for
an executive action operating to the prejudice of the right of a citizen of the authority of law, the
same must necessarily be the position after the insertion of Clause (1A) in Article 359. It is
significant that the language of Clause (1A) of Article 359 in material respect is substantially the
same as that of Article 358. The language of Clause (1A) of Article 359 makes it clear that the
protection which is afforded by that clause is to such law or executive action as the State would but
for the provisions contained in Part III of the Constitution be competent to make or take. The word
"competent" has a significance and it is apparent that despite the Presidential order under Article
359(1), in the case of executive action the competence of the State to take such action would have to
be established. Such competence would, however, be judged ignoring the restriction placed by the
provisions of Part III of the Constitution. To put it in other words, Clause (1A) of Article 359 does
not' dispense with the necessity of competence to make law or take executive action. The only effect
of that clause is that during the period of emergency, the restriction placed upon the competence by
fundamental rights would not be there. But it would still be necessary to establish the competence
dehors the restrictions of the fundamental rights.
200. The matter can also be looked at from another angle. Before any public authority can deprive a
person of ins life or personal liberty, two requirements are to be satisfied :
(1) Power must be conferred by law upon such authority to deprive a person of ins life
or liberty; and (2) Law must also prescribe the procedure for the exercise of such
power.
Suspension of the right to move any court for the enforcement of the right under Article 21 can at
the best impinge upon the second requirement; it cannot affect the first requirement which is a
cardinal principle of the rule of law. I am conscious of the fact that though Article 21 refers to
procedure established by law, there are observations in (Gopalan's case that the Article would also
cover substantive law for affording protection to life and liberty. What Article 21 lays down is that no
person shall be deprived of ins life or personal liberty except according to procedure established by
law. Procedure about the exercise of power of depriving a person of ins life or personal liberty
necessarily presupposes that the substantive power of depriving a person of ins life or personal
liberty has been vested in an authority and that such power exists. Without the existence of such
substantive power, no question can arise about the procedure for the exercise of that power. It has,
therefore, been held that though there is no reference to substantive power in Article 21, the said
Article would cover both the existence of the substantive power of depriving a person of ins life and
personal liberty as well as the procedure for the exercise of that power. The question with which we
are concerned is as to what is the effect of the suspension of the right to move a court for the
enforcement of the right contained in Article 21. The effect, it may possibly be argued, is thatAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

consequent upon such suspension, if a person is deprived of ins life or personal liberty under a law
not satisfying the second requirement indicated above, he cannot seek judicial redress on that score.
Would it, however, follow from the suspension of such right that no judicial remedy would be
available if a person is deprived by an authority of ins life or personal liberty even though such an
authority has not been vested with the substantive power of deprivation of life and personal liberty.
The answer to this question in my opinion, should plainly be in the negative. The suspension of the
right to move a court for the enforcement of the right contained in Article 21 cannot have the effect
of debarring an aggrieved person from approaching the courts with the complaint regarding
deprivation of life or personal liberty by an authority on the score that no power has been vested in
the authority to deprive a person of life or liberty. The presupposition of the existence of substantive
power to deprive a person of ins life or personal liberty in Article 21 even though that Article only
mentions the procedure, would not necessarily point to the conclusion that in the event of the
suspension of the right to move any court for the enforcement of Article 21, the suspension would
also dispense with the necessity of the existence of the substantive power. The coexistence of
substantive power and; procedure established by law for depriving a person of ins life and liberty
which is implicit in Article 21 would not lead to the result that even if there is suspension of the right
regarding procedure, suspension would also operate upon the necessity of substantive power. What
is true of a proposition need not be true of the converse of that proposition. The suspension of the
right to move any court for the enforcement of the right contained in Article 21 may have the effect
of dispensing with the necessity of prescribing procedure for the exercise of substantive power to
deprive a person of ins life or personal liberty, it can in no case have the effect of permitting an
authority to deprive a person of ins life or personal liberty without the existence of substantive
power. The close bond which is there between the existence of substantive power of depriving a
person of Ms life or personal liberty and the procedure for the exercise of that power, if the right
contained in Article 21 were in operation, would not necessarily hold good if that right were
suspended because the removal of compulsion about the prescription of procedure for the exercise
of the substantive power would not do away with the compulsion regarding the existence of that
power.
201. It is significant that there is a difference in the language of Article 21 and that of Article 31(1)
wherein the framers of the Constitution said that no one shall be deprived of ins property save by
the authority of law. In considering the effect of Presidential order suspending the right of a person
to move any court for enforcement of right guaranteed by Article 21, we should not treat the words
"except according to procedure established by law" to be synonymous with "save by authority of
law".
202. The President can in exercise o powers conferred by Article 359(1) suspend when the
proclamation of emergency is in operation, the right/to move any court for the enforcement of such
of the fundamental rights as may be mentioned in the order. On the plain language of; Article
359(1), the President has no power to suspend the right to move any court for the enforcement of
rights which are not fundamental rights conferred by Part III of the Constitution. Rights created by
statutes are not fundamental rights conferred by Part III of the Constitution and as such
enforcement of such statutory rights cannot be suspended under Article 359(1). Likewise, Article
359(1) does not deal with obligations and liabilities which flow from statutory provisions, and itAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

would follow that an order under Article 359(1) cannot affect those obligations and liabilities arising
out of statutory provisions. Nor can a Presidential order under Article 359(1) nullify or suspend the
operation of any statute enacted by a competent legislature. Any redress sought from a court of law
on the score of breach of statutory provisions would be outside the purview of Article 359(1) and the
Presidential order made hereunder. The Presidential order cannot put the detenu in a worse
position than that in which he would be if Article 21 were repealed. It cannot be disputed that if
Article 21 were repealed, a detenu would not be barred from obtaining relief under a statute in case
there is violation of statutory4 provisions. Likewise, in the event of repeal of Article 21, a detenu can
rightly claim in a court of law that he cannot be deprived of has life or personal liberty without the
authority of law. Article 359(1) ousts the jurisdiction of the court only in respect of matters specified
therein during the period of emergency. So far as matters not mentioned in Article 359(1) and the
Presidential order thereunder are concerned, the jurisdiction of the court is not ousted. A provision
which has the effect of ousting the jurisdiction of the courts should be construed strictly. No
inference of the ouster of the jurisdiction of the court can be drawn unless such inference is
warranted by the clear language of the provision ousting such jurisdiction. I may in this context
refer to the observations of the Constitution Bench of this Court in the case of K. Anandan Nambiar
and Anr. v. Chief Secretary, Government of Madras and Ors. Gajendragadkar J. speaking for the
Constitution Bench observed :
In construing the effect of the Presidential order, it is necessary to bear in mind the
general rule of construction that where an order purports to suspend the
fundamental rights guaranteed to the citizens by the Constitution, the said order
must be strictly construed in favour of the citizens' fundamental rights.
203. I am also unable to accede to the argument that though the position under law may be that no
one can be deprived of ins right to life or personal liberty without the authority of law, the remedy to
enforce the right to life or personal liberty is no longer available during the period of emergency
because of the suspension of right to move any court for enforcement of right conferred by Article
21. The basic assumption of this argument is that Article 21 is the sole repository of right to life and
personal liberty. Such an assumption, as already stated above, is not well founded. This apart, a
Presidential order under Article 359(1) cannot have the effect of suspending the right to enforce
rights flowing from statutes, nor can it bar access to the courts of persons seeking redress on the
score of contravention of statutory provisions. Statutory provisions are enacted to be complied with
and it is not permissible to contravene them. Statutory provisions cannot be treated as mere pious
exhortations or words of advice which may be abjured or disobeyed with impunity. Nor is
compliance with statutory provisions optional or at the sufferance of the official concerned. It is the
presence of legal sanctions which distinguishes positive law from other systems of rules and norms.
To be a legal system a set of norms must furnish sanctions for some of its precepts. A legal sanction
is usually thought of as a harmful consequence to induce compliance with law. Non-compliance with
statutory provisions entails certain legal consequences. The Presidential order cannot stand in the
way of the courts giving effect to those consequences. To put it differently, the executive authorities
exercising power under a statute have to act in conformity with its provisions and within the limits
set out therein. When a statute deals with matters affecting prejudicially the rights of individuals,
the ambit of the power of the authorities acting under the statute would be circumscribed by itsAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

provisions, and it would not be permissible to invoke some indefinite general powers of the
executive. As observed by Lord Atkinson in the case of Attorney General v. De Keyser's Royal Hotel
Ltd. [1920] A. C. 508, the constitutional principle is that when the power of the Executive to
interfere with the property or liberty of subjects has been placed under Parliamentary control, and
directly regulated by statute, the Executive no longer derives its authority from the Royal
Prerogative of the Crown but from Parliament, and that in exercising such authority the Executive is
bound to observe the restrictions which Parliament has imposed in favour of the subject. It is also
not the result of the Presidential order, as discussed elsewhere, that because of the suspension of the
right to move any court for enforcement of right under Article 21, the remedy of a writ of habeas
corpus ceases to be available against the State. The Presidential order would not preclude a person
from challenging the validity of a law or order on grounds other than violation of Articles 14, 19, 21
and 22. It may be pertinent to refer to a decision of this Court in the case of Jaichand Loll Sethia v.
State of West Bengal [1966] Supp. S .C. R. 464 wherein the Constitution Bench of this Court
observed after referring to the case of Makhan Singh (supra) :
It was pointed out that during the pendency of the Presidential order the validity of
the Ordinance or any rule or order made thereunder cannot be questioned on the
ground that it contravenes Articles. 14, 21 and 22. But this limitation cannot preclude
a citizen from challenging the validity of the Ordinance or any rule or order made
thereunder on any other ground. If the appellant seeks to challenge the validity of the
Ordinance, rule or order made thereunder on any ground other than the
contravention of Articles 14., 21 and 22, the Presidential order cannot come into
operation. It is not also open to the appellant to challenge the order on the ground of
contravention of Article 19, because as soon as a Proclamation of Emergency is issued
by the President under Article 358 the provision of Article 19 are automatically
suspended. But the appellant can challenge the validity of the order on a ground
other than those covered by Article 358, or the Presidential order issued under Article
359(1). Such a challenge is outside the purview of the Presidential order. For
instance, a citizen will not be deprived of the right to move an appropriate Court for a
writ of habeas corpus on the ground that ins detention has been ordered mala fide.
-Similarly, it will be open to the citizen to challenge the order of detention on the
ground that any of the grounds given in the order of detention is irrelevant and there
is no real and proximate connection between the ground given and the object which
the legislature has in view. It may be stated in this context that a mala fide exercise of
power does not necessarily imply any moral turpitude as a matter of law. It only
means that the statutory power is exercised for purposes foreign to those for which it
is in law intended. In other words, the power conferred by the statute has been
utilized for some indirect purpose not connected with the object of the statute or the
mischief it seeks to remedy.
Similar view was expressed in the case of Durgadas Shirali v. Union of India and Ors.
In G. Sadanandan v. State of Kerala and Anr. the Constitution Bench of this Court
speaking through Gajendragadkar CJ. struck down a detention order on the ground
that it was mala fide.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

204. Our founding fathers made Article 226 which confers power on the High Court to issue inter
alia writes in the nature of habeas corpus an integral part of the Constitution. They were aware that
under the US Constitution in accordance with Article 1 Section IX the privilege of the writ of habeas
corpus could be suspended when in cases of rebellion or invasion the public safety may require it.
Despite that our founding fathers made no provision in our Constitution for suspending the power
of the High Courts under Article 226 to issue writs in the nature of habeas corpus during the period
of emergency. They had perhaps in view the precedent of England where there had been no
suspension of writ of habeas corpus since 1881 and even during the course of First and Second
World Wars. It would, in my opinion, be not permissible to bring about the result of suspension of
habeas corpus by a strained' construction of the Presidential order under Article 359(1) even though
Article 226 continues to remain in force during the period of emergency.
205. The writ of habeas corpus ad subjiciendum, which is commonly known as the writ of habeas
corpus,, is a process for securing the liberty of the subject by affording an effective means or
immediate release from unlawful or unjustifiable detention, whether in prison or in private custody.
By it the High Court and the judges of that Court, at the instance of a subject aggrieved, command
the production of that subject, and inquire into the cause of ins imprisonment. If there is no legal
justification for the detention, the party is ordered to be released. Release on habeas corpus is not,
however, an acquittal, nor may the writ be used as a means of appeal (see Halsbury's Laws of
England,, Vol. 11, Third Edition, page 24).
206. In Greene v. Secretary of State for Home Affairs [1942] A.C. 284 Lord Wright observed :
It is clear that the writ of habeas corpus deals with the machinery of justice, not the
substantive law, except in so far as it can be said that the right to have the writ is itself
part of substantive law. It is essentially a procedural writ, the object of which is to
enforce a legal right .... the inestimable value of the proceedings is that it is the most
efficient mode ever devised by any system of law to end unlawful detainments and to
secure a speedy release where the circumstances and the law so required.
207. Writ of habeas corpus was described as under by Lord Birkenhead in the case of Secretary of
State for Home Affairs v. O'Brien [1923] A.C. 603 (609):
It is perhaps the most important writ known to the constitutional, law of England,
affording as it does a swift and imperative remedy in all cases of illegal restraint or
confinement. It is of immemorial antiquity, an instance of its use occurring in the
thirty third year of Edward I. It has through the ages been jealously maintained by
courts of law as a check upon the illegal usurpation of power by the executive at the
cost of the liege.
208. The existence of the power of the courts to issue a writ of habeas corpus is regarded as one of
the most important characteristic of democratic states under the rule of law. The significance of the
writ for the moral health of the society has been acknowledged by all jurists. Hallam described it as
the "principal bulwark of English liberty". The uniqueness) of habeas corpus in the proceduralAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

armory of our law cannot be too often emphasised. It differs from all others remethes in that it is
available to bring into question the legality of a person's restraint and to require justification for
such detention. Of course, this does not mean that prison doors may readily be opened. It does
mean that explanation may be exacted why they should remain closed. It is not the boasting of
empty rhetoric that has treated the writ of habeas corpus as the basic safeguard of freedom. The
great writ of habeas corpus has been for centuries esteemed the best and sufficient defence of
personal freedom (see Human Rights & Fundamental Freedoms by Jagdish Swarup, page 60).
209. As Article 226 is an integral part of the Constitution, the power of the High Court to enquire in
proceedings for a writ of habeas corpus into the legality of the detention of persons cannot,, in my
opinion, be denied. Although the Indian Constitution, as mentioned by Mukherjea CJ. in the case of
Ram Jawaya Kapur (supra), has not recognised the doctrine of separation of powers in its absolute
rigidity, the functions of the different parts or branches of the Government have been sufficiently
differentiated and consequently it can very well be said that our Constitution does not contemplate
assumption* by one organ or part of the State, of functions that essentially belong to another. The
executive can exercise the powers of departmental or subordinate legislation when such powers are
delegated to it by the legislature. It can also, when so empowered exercise judicial functions in a
limited way. The executive however, can never go against the provisions of the Constitution or of any
law. To quota the words of Dr. Ambedkar in the Constituent Assembly :
Every Constitution, so far as it relates to what we call parliament democracy, requires
three different, organs of the State, the executive, the judiciary and the legislature. I
have not anywhere found in any Constitution a provision saying that the executive
shall obey the legislature, nor have I found anywhere in any Constitution a provision
that the executive shall obey the judiciary. Nowhere is- such a provision to be found.
That is because it is generally understood that the provisions of the Constitution are
binding upon the different organs of the State. Consequently, it is to be presumed
that those who work the Constitution, those who compose the Legislature and those
who compose the executive and the judiciary know their functions, their limitations
and their duties. It is therefore to be expected that if the executive is honest in
working the Constitution, then the executive is bound to obey the Legislature without
any kind of compulsory obligation laid down in the Constitution.
Similarly, if the executive is honest in working the Constitution, it must act in
accordance with the judicial decisions given by the Supreme Court. Therefore my
submission is that this is a matter of one organ of the State acting within its own
limitations and obeying the supremacy of the other I organs of the State. In so far as
the Constitution gives a supremacy to that is a matter of constitutional obligation
which is implicit in the Constitution itself.
It was further observed by him :
No constitutional Government can function in any country unless any particular
constitutional authority remembers) the fact that its authority is limited by theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Constitution and that if there is any authority created by the Constitution which has
to decided between that particular authority and any other authority, then the
decision of that authority shall be binding upon any other organ. That is the sanction
which this Constitution gives in order to see that the President shall follow the advice
of ins Ministers, that the executive shall not exceed in its executive authority the law
made by Parliament and that the executive shall not give its own interpretation of the
law which is in conflict with the interpretation of the judicial organ created by the
Constitution.
Article 226 of the Constitution confers power upon the High Courts of issuing
appropriate writs in case it is found that the executive orders are not in conformity
with the provisions of the Constitution and the laws of the land. Judicial scrutiny of
executive orders with a view to ensure that they are not violative of the provisions of
the Constitution and the laws of the land being an integral part of our constitutional
scheme, it is not permissible to exclude judicial scrutiny except to the extent such
exclusion is warranted by the provisions of the Constitution and the laws made in
accordance with those provisions.
210. There is, as already mentioned, a clear demarcation of the spheres of function and power in our
Constitution. The acceptance of the contention advanced on behalf of the appellants would mean
that during the period of emergency, the courts would be reduced to the position of being helpless
spectators even if glaring and blatant instances of deprivation of life and personal liberty in
contravention of the statute are brought to their notice. It would also mean that whatever may be
the law passed by the legislature, in the matter of life and personal liberty of the citizens, the
executive during the period of emergency would not be bound by it and would be at liberty to ignore
and contravene it. It is obvious that the acceptance of the contention would result in a kind of
supremacy of the executive over the legislative and judicial organs of the State, and thus bring about
a constitutional imbalance which perhaps was never in the contemplation of the framers of the
Constitution. The fact that the government which controls the executive has to enjoy the confidence
of the legislature does not detract from the above conclusion. The executive under our constitutional
scheme is not merely to enjoy the confidence of the majority in the legislature, it is also bound to
carry out the legislative intent as manifested by the statutes passed by the legislature. The
Constitution further contemplates that the function of deciding whether the executive has acted in
accordance with the legislative intent should be performed by the courts.
211. The cases before us raise questions of utmost importance and gravity, questions which impinge
not only upon the scope of the different constitutional provisions, but have impact also upon the
basic values affecting life, liberty and the rule of law. More is at stake in these cases than the liberty
of a few individuals or the correct construction of the wording of an order. What is at stake is the
rule of law. If it could be the boast of a great English judge (Lord Mansfield in the case of James
Sommersett) that the air of England is too pure for a slave to breathe, cannot we also say with
justifiable pride that this sacred land shall not suffer eclipse of the rule of law and that the
Constitution and the laws of India do not permit life and liberty to be at the mercy of absolute power
of the executive, a power against which there can be no redress in courts of law, even if it chooses toAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

act contrary to law or in an arbitrary and capricious manner. The question is not whether there can
be curtailment of personal liberty when there is threat to the security of the State. I have no doubt
that there can be such curtailment, even on an extensive scale, in the face of such threat. The
question is whether the laws speaking through the authority of the courts shall be absolutely
silenced and rendered mute because of such threat.
212. No one can deny the power of the State to assume vast powers of detention in the interest of the
security of the State. It may indeed be necessary to do so to meat the peril facing the nation. The
considerations of security of the State must have a primacy and be kept in the forefront compared to
which the interests of the individuals cart only take a secondary place. The motto has to be "Who
lives, if the country these". Extraordinary powers are always assumed by the government in all
countries in times of emergency because of the extraordinary nature of the emergency. The exercise
of the power of detention, it is well-settled,, depends upon the subjective satisfaction of the
detaining authority and the courts can neither act as courts of appeal over the decisions of the
detaining authority nor can they substitute their own opinion for that of the authority regarding the
necessity of detention. There is no antithesis between the power of the State to detain a person
without trial under a law of preventive detention and the power of the court to examine the legality
of such detention. As observed by Lord Atkin in Rex v. Haluday [1917] A.C. 260 while dealing with
the argument that the Defence of Realm Consolidation Act of 1914 and the regulation made under it
deprived the subject of ins right under the several Habeas Corpus Acts,, that is an entire
misconception. The subject retains every right which those statutes confer upon him to have tested
and determined in a court of law, by means of a writ of Habeas Corpus, addressed to the person in
whose custody he may be, the legality of the order or) warrant by virtue of which he is given into or
kept in that custody. To quote the words of Lord Macmillan in the case of Liversidge v. Anderson
[1942] A.C. 206.
It is important to have in mind that the regulation in question is a war measure. This is not to say
that the Court sought to adopt in war time canons of construction different from those they follow in
peace time. The fact that the nation is at war is no justification for any relaxation of the vigilance of
the Courts in seeing that the law is duly " observed, especially in a matter so fundamental as the
liberty of the subject. Rather the contrary.
In dealing with an application for a writ of habeas corpus, the court only ensure that the detaining
authorities act in accordance with the law of preventive detention. The impact upon the individual of
the massive and comprehensive powers of preventive detention with which the administrative
officers are armed has to be cushioned with legal safeguards against arbitrary deprivation of
personal liberty if the premises of the rule of law is not to lose its content and become meaningless.
The chances of an innocent person being detained under a law providing for preventive detention on
the subjective satisfaction of an administrative authority are much greater compared to the
possibility of an innocent person being convicted at trial in a court of law. It would be apposite in
this context to refer to the observations of Professor Alan M. Dershowite :
The available evidence suggest that our system of deter mining past guilt results in
erroneous conviction of relatively few innocent people. We really do seem to practiceAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

what we preach about preferring the acquittal of guilty men over the conviction of
innocent men.
But the indications are that any system of predicting future crimes would result in a
vastly larger number of erroneous confinements--that is, confinements of persons
predicted to engage in violent crime who would not, in fact, do so. Indeed, all the
experience with predicting violent conduct suggests that in order to spot a significant
proportion of future violent criminals, we would have to reverse the traditional
maxim of the criminal law and adopt a philosophy that it is 'better to confine ten
people who would not commit predicted crimes, than to release one who would.
(see p. 313 Crime, Law and Society by Goldstein and Gold-stein) .
It would, therefore, seem to be a matter of melancholy reflection if the courts were to
stay their hand and countenance laxity or condone lapses in relation to compliance
with requirements prescribed by law for preventive detention.
213. In England there was no suspension of the power of the courts to issue a writ of habeas corpus
during the First World War and the Second World War. In India also there was no absolute bar" to
approaching the courts during the Sino-Indian hostilities of 1962 and the Indo-Pak wars of 1965 and
1971. It has not been suggested that because of the existence of the powers of the court to issue writs
of habeas corpus war efforts were in any way prejudicially affected. The United Nations' Economic
and Social Council endorsed the general agreement reached at the Baguio Seminar that "the writ of
habeas corpus or similar remedy of access to the courts to test to legality and bona-fides of the
exercise of the emergency powers should never be denied to the citizen". It drew attention to the
following passage from the report of the seminar ; "All members recognised that in times of
emergency it might be necessary to restrict temporarily the freedom of the individual. But they were
firmly of the view that, whatever temporary restrictive measures might be necessary, recourse to the
courts through the right of habeas corpus or other similar remedy should never be suspended.
Rather the legislature could, if necessary,, subject to well defined procedures safeguarding human
dignity, authorise the temporary detention of persons for reasons specified in the law. By that means
'the executive can act as emergency may require but the ultimate judicial protection of individual
liberty is preserved. Members hold strongly that it is a fundamental principle that the individual
should never be deprived of the means of testing the legality of ins arrest or custody by recourse to
judicial process even in times of emergency. If that principle is departed from, the liberty of the
individual is immediately put in great peril".
214. I am, therefore, of the view that there is no sufficient ground to interfere with the view taken by
all the nine High Courts which went into the matter, that the Presidential order of June 27, 1975 did
not affect the maintainability of the habeas corpus petitions to question the legality of the detention
orders and that such petitions could be proceeded with despite that order.
215. We may now deal with the second question regarding the scope and extent of judicial scrutiny
in petitions for writ of habeas corpus relating to persons detained under MISA. For this purpose itAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

would be appropriate to first deal with the position under the above law so far as cases not covered
by Section 16A are concerned.
216. According to Section 3(1) of MISA, the authorities specified in the Sub-section may if satisfied
with respect to any person (including a foreigner) that with a view to preventing him from acting in
any manner prejudicial to (i) the defence of India, the relations of India with foreigner powers, or
the security of India, or (ii) the security of the State or the maintenance of public order, or (iii) the
maintenance of supplies and services essential to the community, it is necessary so to do make an
order that such person be detained. The words "if satisfied" indicate that the satisfaction of the
authority concerned is a condition precedent to the making of a detention order. Unless therefore
the authority concerned is satisfied on the material before it that it is necessary to detain a person
with a view to prevent him from indulging in any of the specified prejudicial activities, it has no
power to make an order for ins detention. Section 3 also contains an implied injunction that the said
authority shall not detain a person under that Section for reasons other than those specified therein.
Although the satisfaction contemplated by the Sub-section is the subjective satisfaction of the
authority concerned, it is necessary that it should be arrived at in an objective manner. It is
consequently essential that the facts on the basis of which file authority concerned reaches the
conclusion that it is necessary to detain a person should have a rational nexus or probative value and
be germane to the object for which such detention is allowed under Section 3(1) of MISA. In case the
facts which are taken into account are extraneous, not germane or do not have any live link or
reasonable connection with the object for which the detention order can be made, the order would
be liable to be quashed. Even if one out of the many grounds on which a detention order is based is
not germane or legally not tenable, the detention order would be quashed because it is difficult to
predicate that the detaining authority would have come to the requisite satisfaction even in the
absence of that ground. It is plainly not possible to estimate as to how far the irrelevant or untenable
ground operated on the mind of the appropriate authority and contributed to the creation of the
satisfaction on the basis of which the detention order was made. To say that the other ground which
still remains is quite sufficient to sustain the order would be to substitute an objective judicial test
for the subjective decision of the executive authority which is against the legislative policy
underlying the statute.
217. A law of preventive detention is not punitive but precautionary and preventive. The power of
detention under such law is based on circumstance of suspicion and not on proof of allegations is
required at a regular trial for the commission of an offence. Such a power is exercised because of
apprehension of future prejudicial activity on the part of the person ordered to be detained judged in
the light of ins past conduct and propensity. The order for preventive detention in such cases
postulates prior restraint so that the mischief apprehended at the hands of the person ordered to be
detained might not materialise. The consequences of waiting and declining to take action against
that person till the mischief is actually done would quite often be disastrous and the nation may in
some cases have to pay a heavy price for such abstention. The quantum of material available
regarding the conduct and propensity of a person may not be sufficient to warrant ins conviction in
a court of law for an offence and yet if the material is germane to the object for which detention
order can legally be made and the detaining authority is satisfied in view of that material regarding
the necessity of making a detention order, such order-made by that authority would be upheld asAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

being in accordance with law. It is also not difficult to visualise a situation wherein serious, crimes
are committed in broad daylight and yet the witnesses to the, crime are so much terrified and
awestricken that they dare not depose against the culprits in a court of law. In such cases also
because of the difficulty of securing the conviction of the culprits, the courts have upheld the
detention orders, if the activities of the culprits are of such a nature as has a nexus with the object
for which detention order can be made. In a petition for a writ of habeas corpus the courts do not
normally question the veracity and sufficiency of the material on the basis of which the authority
concerned arrives at the conclusion regarding the necessity of detention. In case the detenu
challenges the correctness, or 'truth of the allegations on the basis of which the detention order is
made, he should normally do so by means of representation contemplated by Clause (5) of Article
22. It is legitimate to expect that the authority concerned and the advisory board when the matter
comes up before them shall take into account the stand taken by the detenu regarding those
allegations. It would be also their function to give consideration to any fresh material which may be
produced before them regarding the truth and correctness of those allegations. In a habeas corpus
petition, if it becomes apparent on the record from, the admission made by the detaining authority
in the return or some other evidentiary material of unquestioned authenticity and probative value
that some of the alleged facts upon the basis of which detention order is made are non-existent, the
court would be well justified in quashing the detention order. A court apart from that cannot go
behind the truth of the alleged facts. If the material is germane to the object for which detention is
legally permissible and an order for detention is made on the basis of that material, the courts
cannot sit as a court of appeal and substitute their own opinion for that of the authority concerned
and hold that the authority concerned should not have arrived at the conclusion regarding the
necessity of detention. At the same time, it is necessary that the authority concerned before deciding
to detain a person should apply its mind to the facts before it in a fair and reasonable manner. If the
conclusion arrived at is so unreasonable that no reasonable authority could ever come to it, the
legitimate inference would be that the authority concerned did not apply its mind to the relevant
facts and did not honestly arrive at the conclusion. To use the words of Lord Halsbury in Shrape v.
Wakefield [1891] A.C. 172 at p. 179:
...when it is said that something is to be done within the discretion of the authorities
that something is to be done according to the rules of reason and justice, not
according to private opinion .... according to law and not humour. It is to be, not
arbitrary, vague, fanciful, but legal and regular.
Likewise, if there were no grounds, as observed by Lord Morton in Ross v.
Papadopollos [1958] 2 All. E..R. 23, or which the authority concerned could be
satisfied, the court might infer either that the authority did not honestly form that
view or that in forming it, the authority could not have applied its mind to the
relevant facts. The courts would also interfere if the power of detention is exercised
malafide, not in good faith or for an ulterior purpose. It would follow from the above
that if the power of detention is exercised for an improper purpose, i.e., a purpose not
contemplated by the statute, the order for detention would be quashed.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

218. Between malice in fact and malice in law, as observed by Viscount Haldane L.C. in the case of
Shearer v. Shields [1914] A. C. 808, there is a broad distinction which is not peculiar to any
particular system of jurisprudence. A person who inflicts an injury upon another person in
contravention of the law is not allowed to say that he did so with an innocent mind; he is taken to
know the law, and he must act within the law. He may, therefore, be guilty of malice in law,
although, so far as the state of ins mind is concerned, he acts ignorantly, and in that sense
innocently. Malice in fact is quite a different thing; it means an actual malicious intention on the
part of the person who has done the wrongful act, and it may be, in proceedings based on wrongs
independent of contract, a very material ingredient in the question of whether a valid cause of action
can be stated. The above principle was applied by this Court in detention matters in Bhut Nath v.
State of West Bengal .
219. Normally, it is the past conduct or antecedent history of a person which shows a propensity or a
tendency to act in a particular manner. The past conduct or antecedent history of a person can,
therefore, be appropriately taken into account in making a detention order. It is indeed largely from
the past events showing tendencies or inclinations of a person that an inference can be drawn that
he is likely in the future to act in a particular manner. In order to justify such an, inference, it is
necessary that such past conduct or antecedent history should ordinarily be proximate in point of
time. It would, for instance, be normally irrational to take into account the conduct an activities of a
person which took place ten years, before the date of ins detention and say that even though after
the said incident took place* nothing is known against the person indicating ins tendency to act in a
prejudicial manner, even so on the strength of the said incident which is ten years old, the authority
is satisfied that ins detention is necessary. It is both inexpedient and undesirable to lay down an
inflexible test as to how far distant the past conduct or the antecedent history should be for
reasonably and rationally justifying the conclusion that the person concerned if not detained may
indulge in prejudicial activities. The nature of the activity would have also a bearing in deciding the
question of proximity. If, for example, a person who has links with a particular' foreign power is
known to have indulged in subversive activities when hostilities broke out with that foreign power
and hostilities again break out with that foreign power after ten years, the authorities concerned, if
satisfied on the basis of the past activities that it is necessary to detain him with a view to preventing
him from acting; in a manner prejudicial to the security of India, might well pass a detention order
in respect of that person. The fact that in such a case there is a time lag of ten years between the
activities of the said person and the making of the detention order would not vitiate such an order.
Likewise, a remote prejudicial activity may be so similar to a recent prejudicial activity as may give
rise to an inference that the two are a part of chain of prejudicial activities indicative of a particular
inclination. In such an event the remote activity taken along with the recent activity would retain its
relevance and reliance upon it would not introduce an infirmity. If, however, in a given case and in
the context of the nature of activity the time lag between the prejudicial activity of a detenu and the
detention order made because of that activity is ex facie long, the detaining authority should explain
the delay in the making of the detention order with a view to show that there was proximity between
the prejudicial activity and the) detention order. If the detaining authority fails to do so, in spite of
an opportunity having been afforded to it, a serious infirmity would creep into the detention order
(see Rameshwar Singh v. District. Magistrate Burdwan and Anr. and Sk. Abdul Munnaf v. State of
West Bengal .Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

220. One other requirement of a valid order of detention is that the grounds of detention which are
communicated to the detenu should not be vague sal that he may not be handicapped in making an
effective representation against the detention order. Both Article 22(5) of the Constitution and
Section 8(1) of MISA refer to such representation and provide that the detaining authority shall as
soon as may be, and in any ease not later than the prescribed period, communicate to the person
detained the grounds on which the detention order has been made "and shall afford him the earliest
opportunity of making representation against the order". In view of the Presidential order
suspending the right of a person to move any court for enforcement of specified fundamental rights,
including the one under Article 22(5), it may with plausibility be argued that the vagueness of
grounds of detention would not warrant the quashing of such detention order during the pendency
of the Presidential order on the score of violation of Article 22(5). The Presidential order would,
however, not stand in the way of the court quashing the detention order on the score of the infirmity
of the vagueness of grounds of detention because of the contravention of Section 8(1) of MISA.
221. Every law providing for preventive detention contains certain procedural safeguards. It is
imperative that there should be strict compliance with the requirements of those procedural
safeguards to sustain the validity of detention. Detention without trial results in serious inroads into
personal liberty of an individual. In such cases it is essential to ensure that there is no deviation
from the procedural safeguards provided by the statute. In the matter of even a criminal trial, it is
procedure that spells out much of the difference between the rule of law and the rule by whim and
caprice. The need for strict adherence to strict procedural safeguards is much greater when we are
dealing with preventive detention which postulates detention of a person even though he is not
found guilty of the commission of an offence. To condone or allow relaxation in the matter of
compliance with procedural requirements would necessarily have the effect of practically doing
away with even the slender safeguards provided by the legislature against the arbitrary use of the
provisions relating to preventive detention. The history of personal liberty,, we must bear in mind, is
largely the history of insistence upon procedure. I am, therefore, of the view that it would be wholly
inappropriate to countenance any laxity in the matter of strict compliance with procedural
requirements prescribed for preventive detention. The observations made in the case of Kishori
Mohan v. State of West Bengal A. I. R. 1974 S. C. 1749 have relevance. It was observed by this Court
in that case :
The Act confers extraordinary power on the executive to detain a person without
recourse to the ordinary laws of the land and to trial by courts. Obviously, such power
places the personal liberty of such a person in extreme peril against which he is
provided with a limited right of challenge only. There can, therefore, be no doubt that
such a law has to be strictly construed. Equally also, the power conferred by such a
law has to be exercised with extreme care and scrupulously within the bounds laid
down in such a law.
222. Question then arises as to how far are the recitals in the order of detention binding upon the
court, and upon whom and to what extent does the onus lie in a petition for a writ of habeas corpus
relating to a detained person. In this respect I find that in the case of King Emperor v. Sibnath
Banerji 71 I. A. 241 the Judicial Committee, speaking through Lord Thankerton,, approved theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

following observation of the learned Chief Justice of the Federal Court:
It is quite a different thing to question the accuracy of a recital contained in a duly
authenticated order, particularly where the recital purports to state as a fact the
carrying out of what I regard as a condition necessary to the valid making of that
order. In the normal case the existence of such a recital in a duly authenticated order
will, in the absence of any evidence as to its accuracy, be accepted by a court as
establishing that the necessary condition was fulfilled. The presence of the recital in
the order will place a difficult burden on the detenu to produce admissible evidence
sufficient to establish even a prima facie case that the recital is not accurate.
The matter was considered by this Court by the Constitution Bench of this Court in-
the case of G. Sadanandan v. State of Kerala and Anr. (supra) and it was observed' as
under :
After all, the detention of a citizen in every case is the result of the subjective
satisfaction of the appropriate authority; and so, if a prima facie case is made by the
petitioner that ins detention is either mala fide, or is the result of the casual approach
adopted by the appropriate authority, the appropriate authority should place before
the Court sufficient material in the form of proper affidavit made by a duly
authorised person to show that the allegations made by the petitioner about the
casual character of the decision' or its mala fides, are not well-founded. The failure of
respondent No. 1 to place any such material before us in the present proceedings
leaves us no alternative but to accept the plea made by the petitioner that the order of
detention against him on the 20th October, 1965,, and more particularly, ins
continued detention after the 24th October, 1965, are totally invalid and unjustified.
The initial burden is on the detenu to show that ins detention is mala fide or not in
accordance with law. If the detenu makes out a prima facie case, the burden shifts on
the State and it becomes essential for the State to file a good return. Once substantial
disquieting doubts are raised by the detenu in the mind of the court regarding the
validity of ins detention, it would be the bounden duty of the State to dispel those
doubts by placing sufficient material before the court with a view to satisfy it about
the validity of the detention. In case the detenu fails to discharge the initial burden,
ins petition for writ of habeas corpus would be dismissed. Even if the detenu
discharges the initial burden and makes out a prima facie case against the validity of
ins detention, but the State files a good return and adduces sufficient material before
the court to show that ins detention is valid, the detenu's petition would be
dismissed. In case, however,, the detenu discharges the initial burden and makes out
a prima facie case against the validity of ins detention and the State fails to file a good
return and does not place sufficient material on the record to show that the detention
is valid, a serious infirmity would creep into the State case as might justify
interference by the court and release of the detenu. More than that, it is not necessary
to say for everything in the final analysis would depend upon the individual facts ofAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

the case.
223. We may now turn to the newly added Section 16A of MISA. This Section was inserted by
Section 6 of Act 39 of 1975 with effect from June 29, 1975. Subsequently, there was a further
amendment of Section 16A by Act 14 of 1976 which was published on January 25, 1976. According to
Sub-section (1) of Section 16A, the provisions of the Section would have effect notwithstanding
anything contained in MISA or any rules of natural justice during the period of emergency
proclaimed on December 3, 1971 and June 25, 1975 or a period of 12 months from June 25,, 1975
whichever period was the shortest. Sub-sections (2) and (3) provides for the making of a declaration
to that effect by the authorities concerned if they are so satisfied on consideration that it is necessary
to detain a person for effectively dealing with the emergency. Sub-section (2) deals with cases of
persons against whom orders of detention were made under the Act on or after June 25, 1975 but
before the combine into force of this section, viz., June 29, 1975, while Sub-section (3) deals with
cases of detention in respect of persons against whom orders for detention were made after the
coming into force of the section. The proviso to Sub-section (3) provides for review and the necessity
of confirmation within fifteen days of the declaration by the State Government in case such
declaration is made by an officer subordinate to the State Government. Sub-section (2A) provides
for deemed approval of a detention order made by an officer subordinate to the State Government in
case the State Government makes a declaration that the detention of the person ordered to be
detained is necessary for dealing effectively with the emergency. Sub-section (4) provides for
reconsideration at intervals not exceeding four months of the necessity of detention of a person in
respect of whom a declaration is made under Sub-section (2) or (3). According to Sub-section (5), in
making any review, consideration or reconsideration under Sub-sections (2), (3) or (4), the
appropriate Government or officer may act on the basis of the information and materials in its or ins
possession without communicating or disclosing any such information or materials to the person
concerned or affording him any opportunity of making any representation against the making under
Sub-section (2)M or the making or confirming under Sub-section (3), or the non-revocation under
Sub-section (4), of the declaration in respect of him. Sub-sections (6) and (7) provide inter alia that
Sections 8 to 12 shall not apply in the case of a person detained under a detention order to which the
provisions of Sub-sections (2) and (3) apply. Sub-section (8) authorises the Central Government
whenever it considers it necessary so to do to require the State Government to furnish to the Central
Government the information and materials on the basis of which declaration has/ been made or
confirmed' or not revoked and such other information and materials as the Central Government
may deem necessary.
224. It would appear from what has been stated above that once a declaration is made with respect
to a detenu under Sub-sections (2). or (3) of Section 16A of MISA, the provisions of Sections 8 to 12
of MISA would not apply to such a detenu. The result would be that the grounds of the order of
detention would not be disclosed to the person affected by the order. There would also be no
reference of the case of such a person to the Advisory Board.
225. We may now turn to Sub-section (9) of Section 16A. According to this Sub-section,
notwithstanding anything contained in any other law or any rule haying the force of, law, the
grounds on which an order of detention is made or purported to be made under Sections against anyAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

person in respect of whom a declaration is made under Sub-section (2) or Sub-section (3) and any
information or materials on which such grounds or a declaration under Sub-section (2) or a
declaration or confirmation under Sub-section (3) or the non-revocation under Sub-section (4) of a
declaration are based, shall be treated as confidential, and shall be deemed to refer to matters of
State and to be against the public interest to disclose and save as otherwise provide-ed in this Act,
no one shall communicate or disclose any such ground information or material or any document
containing such ground information or material. According to Clause (b) of Sub-section (9) no
person against whom an order of detention is made or purported to be made under Section 3 shall
be entitled to the communication or disclosure of any such ground, information or material as is
referred to in Clause (a) or the production to him of any document containing such ground,
information or material.
226. So far as the impact of Section 16A(9) is concerned on the extent of the power of judicial
scrutiny in writs of habeas corpus relating to persons detained under MISA, I am of the view that the
matter should not be gone into in these appeals for the following reasons.
227. Out of the nine High Courts which dealt with the question of maintainability of petitions for
writs of habeas corpus, only two, namely, Rajasthan High Court and Nagpur Bench of Bombay High
Court have gone into this aspect, while the other seven have not expressed any view in the matter.
Both Rajasthan High Court and Nagpur Bench of the Bombay High Court have upheld the validity
of; Section 16A(9). While Rajasthan High Court has not read down the provisions of Section 16A(9),
the Nagpur Bench of the Bombay High Court has expressed the view that it would be permissible for
the High Court to call for and peruse the grounds in certain circumstances. The Nagpur Bench, it
may be pointed out, dealt with the provisions of Section 16 A(9), as they then existed before its
amendment by Act 14 of 1976.
228. Before; us arguments have been addressed on behalf of the respondents challenging the
validity of Section 16A(9) on the ground that it is violative of Article 226 inasmuch as it prevents, the
High Court from effectively exercising the jurisdiction under that Article to issue writs of habeas
corpus. In my opinion, it would not be permissible in these appeals against orders disposing of
preliminary objection to decide the question of validity of Section 16A(9). It is manifest that any
decision on the question of the validity of Section 16A(9) would result either in upholding the
validity of the provision or in; striking it down. The latter course is out of question for it would be
plainly impermissible to strike down the provision in appeal by the State when the validity of such
provision has been upheld by the High Court. Likewise, it would be impermissible in these appeals
to record a finding that the ambit of judicial scrutiny is greater than that found by the High Court
even though this Court on consideration of the relevant provisions comes to that conclusion. There
is no appeal before us by the detenu-respondents. This Court in appeal by the State cannot enlarge
the area of the unfavorable decision qua the State and make its position worse compared to what it
was before the filing of the appeal. Procedural propriety in matters relating to appeals forbids such a
course. The appeals before us are primarily against the orders of the High Court disposing of the
preliminary objections relating to the maintainability of petitions under Article 226 for writs of
habeas corpus in view of the Presidential order. The question of extent of judicial scrutiny in the
light of Section 16A should, in ray opinion, be gone into when the whole matter is at large before usAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

and we are not inhibited by procedural and other constraints from going into certain aspects which
have a vital bearing. It is primarily for the High Courts before which the matters are pending to
decide the question of area of judicial scrutiny in the light of Section 16A(9), as amended by Act 14 of
1976. A course which has the effect of bypassing the High Courts and making this Court in appeals
from orders on preliminary objection to decide the matter even before tile matter has been
considered by the High Court in the light of Section 16A, as amended by Act 14 of 1976,, should, in
my opinion, be avoided.
229. The observations on pages 658 and 659 in the case of K. Synthetics Ltd. v. J. K. Synthetics
Mazdoor Union can be of no assistance in this case because what has been laid down there is that
the respondent can support an award of an Industrial Tribunal on a ground not adopted by the
Tribunal so long as in the final result the amount awarded is not exceeded. The observations in that
case do not warrant the enlargement of the area of unfavourable decision against an appellant in the
absence of an appeal by the respondent. Nor does that decision justify adoption of a course which
might conceivably lead to such result. Likewise, no assistance can be derived from Clause (3) of
Article 132 of the Constitution because of the fact that the appeal against the order of the Rajasthan
High Court has been filed in pursuance of a certificate of fitness granted under that article. The only
point on which the Rajasthan High Court has decided against the appellant is regarding the
maintainability of the petition under Article 226. The effect of Article 132(3) would only be that it
would be permissible to assail the order of the High Court on the question of maintainability of the
petition under Article 226 not only on the ground relating to the question of law as to the
interpretation of the Constitution mentioned in the order granting the certificate but also with the
leave of this Court on other grounds. It is, however, not the effect of Article 132(3) that if the High
Court in the impugned order decides two distinct preliminary issues, one in favour of one party and
the other in favour of the opposite party, this Court in an appeal by only one party against that order
of the High Court can also go into the correctness of the issue which has been decided in favour of
the appellant. The fact that the respondents in these appeals have as a matter of abundant caution
addressed arguments on sub-section (9) of Section 16A, so that the submissions of the appellants on
that point may not remain unanswered, would not justify departure from the principle that this
Court cannot, in the absence of an appeal by the respondent, adopt a course which might
conceivably enlarge the area of unfavourable decision against the appellant.
230. I am,, therefore, of the view that the appropriate occasion for going into the question of the
constitutional validity of Section 16A(9) of MISA and its impact on the power and extent of judicial
scrutiny in writs of habeas corpus would' be when the State or detenu, whosoever is aggrieved,
comes up in appeal against the final judgment in any of the petitions pending in the High Courts.
The whole matter would then be at large before us and we would not be inhibited by procedural and
other constraints referred to above. It would not, in my opinion, be permissible or proper to short
circuit the whole thing and decide the matter by bypassing the High Courts who are seized of the
matter.
231. I may now summaries my conclusions :Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

(1) Article 21 cannot be considered to be the sole repository of the right to life and
personal liberty.
(2) Even in the absence of Article 21 in the Constitution, the State has got no power to
deprive a person of ins life or personal liberty without the authority of law. That is the
essential postulate and basic assumption of the rule of law in every civilised society.
(3) According to law in force in India before the coming into force of the Constitution,
no one could be deprived of Ms life or personal liberty without the authority of law.
Such a law continued to be in force after the coming into force of the Constitution, in
view of Article 372 of the Constitution.
(4) Startling consequences would follow from the acceptance of the contention that
consequent upon, the issue of the Presidential order in question no one can seek
relief from courts during the period of emergency against deprivation of life and
personal liberty. If two constructions of the Presidential order were possible, the
court should lean in favour of a view which does not result in such consequences. The
construction which does not result in such consequences is not only possible, it is also
preeminently reasonable.
(5) In a long chain of authorities this Court has laid stress upon the prevalence of the
rule of law in the country, according to which the executive cannot take action
prejudicial to the right of an individual without the authority of law. There is no valid
reason to depart from the rule laid down in those decisions,, some of which were
given by Benches larger than the Bench dealing with these appeals.
(6) According to Article 21, no one can be deprived of ins life or personal liberty
except in accordance with procedure established by law. Procedure for the exercise of
power of depriving a person of ins life or personal liberty necessarily postulates the
existence of the substantive power. When Article 21 is in force, law relating to
deprivation of life and personal liberty must provide both for the substantive power
as well as the procedure for the exercise of such power. When right to move any court
for enforcement of right guaranteed by Article 21 is suspended, it would have the
effect of dispensing with the necessity of prescribing procedure for the exercise of
substantive power to deprive a person of ins life or personal liberty, it cannot have
the effect of permitting an authority to deprive a person of ins life or personal liberty
without the existence of such substantive power.
(7) A Presidential order under Article 359(1) can suspend during the period of
emergency only the right to move any court for enforcement of the fundamental
rights mentioned in the Order. Rights created by statutes being not fundamental
rights can be enforced during the period of emergency despite the Presidential order.
Obligations and liabilities flowing from statutory provisions likewise remain
unaffected by the Presidential order. Any redress sought from a court of law on theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

score of breach of statutory provisions would be outside the purview of Article 359(1)
and the Presidential order made thereunder.
(8) Article 226 under which the High Courts can issue writs of habeas corpus is an
integral part of the Constitution. No power has been conferred upon any authority in
the Constitution for suspending the power of the High Court to issue writs in the
nature of habeas corpus during the period of emergency. Such a result cannot be
brought about by putting some particular construction on the Presidential order in
question.
(9) There is no antithesis between the power of the State to detain a person without
trial under a law of preventive detention and the power of the court to examine the
legality of such detention. In exercising such power the courts only ensure that the
detaining authority acts in accordance with the law providing for preventive
detention.
(10) There is no sufficient ground to interfere with the view taken by all the nine High
Courts which went into the matter that the Presidential order dated June 27, 1975 did
not affect the maintainability of the habeas corpus petitions to question the legality of
the detention orders.
(11) The principles which should be followed by the courts in dealing with petitions
for writs of habeas corpus to challenge the legality of detention are well-established.
(12) The appropriate occasion for this Court to go into the constitutional validity of
Section 16A(9) of MISA and its impact on the power and extent of judicial scrutiny in
writs of habeas corpus would be when the State or a detenu, whosoever is aggrieved,
comes up in appeal against the final judgment in any of the petitions pending in the
High Courts. The whole matter would then be at large before this Court and it would
not be inhibited by procedural and other con straits. It would not be permissible or
proper for this Court to short circuit the whole thing and decide the matter by
by-passing the High Courts who are seized of the matter.
232. Before I part with the case, I may observe that the conscious ness that the view expressed by me
is at variance with that of the majority of my learned brethren has not stood in the way of my ex
pressing the same. I am aware of the desirability of unanimity, if possible. Unanimity obtained
without sacrifice of conviction comments the decision to public confidence. Unanimity which is
merely formal and which is recorded at the expense of strong conflicting views is not desirable in a
court of last resort. As observed by Chief Justice Hughes Prophets' with Honor by Alan Earth 1974
Ed. p. 3-6 judges are not there simply to decide cases, but to decide them as they think they should
be decided, and while if may be regrettable that they cannot always agree, it is better that their
independence should be maintained and recognized than that unanimity should be secured through
its sacrifice, A dissent in a court of last resort to use ins words, is an appeal to the brooding spirit of
the law. to the intelligence of a future day, when a later decision may possibly correct the error intoAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

which the dissenting judge believes the court to have been betrayed.
233. The appeals are disposed of accordingly.
M.H. Beg, J.
234. The two principal questions placed before us for determination in these appeals from decisions
given by various High Courts, on certain preliminary objections to the maintainability and hearing
of Habeas Corpus petitions, under Article 226 of our Constitution, have been stated as follows by the
Attorney General of India:
1. Whether, in view of the Presidential Order dated June 27, 1975, under Clause (1) of
Article 359, any writ petition is maintainable under Article 226, before a High Court
for Habeas Corpus to enforce the right to personal liberty of a person detained under
the Maintenance of Internal Security Act on the ground that the order of detention or
the continued detention is, for any reason, not under or in compliance with
Maintenance of Internal Security Act ?
2. If such a petition is maintainable, what is the scope or extent of judicial scrutiny,
particularly, in view of the aforesaid Presidential Order which covers, inter alia,
Clause (5) of Article 22, and also in view of Sub-section (9) of Section 16A of the
Maintenance of Internal Security Act?
235. If the only reason on which a detention is assailed, could be that the provisions of the
Maintenance of Internal Security Act 26 of 1971 (hereinafter referred to as 'the Act') have not been
complied with, there could be little difficulty in holding, having regard to the natural and obvious
meaning of the suspension of "the right to move any Court for the enforcement" of the fundamental
right to personal liberty, protected by Article 21 of the Constitution, that this right, with whatever it
evolved from; or embraced, could not be the basis for any claim to its enforcement during the
Emergency. All that would then remain to consider would be the exact point at which and the form
in which the order of the Court denying the petitioner an enforcement of the right could be passed.
The last part of the first question, however, also brings into the area of discussion the case where a
petitioner alleges that "for any reason" ins detention falls completely outside the Act. Detenues
allege not merely infraction of some provision of the Act, under which a detention is ordered, but,
more often, that the detention is for extraneous reasons falling either entirely or partially outside the
Act. "Mala fides" is almost invariably alleged presumably on the assumption that almost everything
the detenue considers either wrong or erroneous or improper must be "mala fide".
236. Arguments addressed to us on behalf of the detenues have raised a host of hypothetical
questions, such as : What would be the position if the order of detention, on the face of it, either falls
outside the provisions of the Act or is made mala fide ? Would a detention order, by any
Government servant without even an ostensible or purported statutory authority to support it, not
stand on the same footing as a detention by a private person? Would remedy against detention
which may be patently illegal, without need for any real investigation into facts at all also be barred ?Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Could remedy by way of a writ of Habeas Corpus against any illegal detention by any one in this
country, under any circumstances, be held to be suspended during the Emergency ? The next steps
in the argument on behalf of detenues consisted of attempts to show that there could be no
distinction in principle, between an order which is, prima facie, ultra vires or made mala fide and
one which can be shown to be that only if the facts and circumstances surrounding a detention were
fully investigated in a Court. Processes of reasoning, based on hypothetical cases put forward for
consideration by us, by learned Counsel for the detenus seek, by stages to so expand the area of
maintainability and investigation on claims for writs of Habeas Corpus in the High Courts that, if we
accept them, the result would be that Article 359 of the Constitution and the Presidential orders of
1975 made under it would become entirely meaningless and in fructuous.
237. It seems to me that the two questions set out above, could very well be compressed into a single
question : To what extent, if at all, can a, High Court be moved to assert a right to personal liberty,
by means of a petition under Article 226 for a writ of Habeas Corpus during the operation of the
Presidential order of 27th June, 1975 ?
238. Speaking for myself, I am extremely reluctant to embark on a consideration and decision of any
"pure" question of law. In cases coming up before Courts, no question of law can be "pure" in the
sense that it has no bearing on the facts of a particular case to which it must necessarily be related.
Neither Article 136 nor Article 226 of the Constitution is meant for the exercise of an advisory
jurisdiction. Attempts to lay down the law in an abstract form, unrelated to the facts of particular
cases, not only do not appertain to the kind of jurisdiction exercised by this Court or by the High
Courts under the provisions mentioned above, but may result in misapplications of the law declared
by Courts to situations for which they were not intended at all.
239. Learned Counsel for the detenus have tried to induce us to answer many questions which may
arise in purely hypothetical situations some of which seem to me to be far removed from the realms
of reality. We cannot assume that those who exercise powers of detention are bound to do so, as a
rule, as though they were demented repots--without any regard for law, justice, reason, or honesty
of purpose, solely for achieving objects other than those which are really meant to be served by the
Act. Both sides, however, desire that we should answer questions indicated above on the assumption
that the provisions of law contained in the Act have been infringed, in some way, by the detaining
authorities in a particular case. They want us to indicate degrees of transgression of the provisions,
of the Act, if any, which can justify interference by the High Courts in Habeas Corpus proceedings.
As the facts of no particular case are before us. we can only answer the questions before us with the
help, where necessary, of appropriate hypothetical examples.
240. The learned Attorney General has, very frankly and honestly, submitted that there was no need
to bestow upon actions of the detaining authorities the protections given to them only for the
duration of the Emergency proclaimed under Article 352(1) of the Constitution, if the President did
not really intend to confer certain immunities from judicial scrutiny and interference upon
detentions by executive authorities, even if some of them were contrary to the letter of the law, so
that certain over-riding interests of national security and independence may not be jeopardized. The
Attorney General's submission is that the risks of misuse of powers by the detaining officers andAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

authorities, which are certainly there, must be presumed to have been over-ridden by the higher
claims of national security which the proclamation of Emergency denotes. It was pointed out that a
citizen, or other person who may have been unfairly or illegally detained due to some unfortunate
misapprehension or error, does not loose ins remedy altogether. Only ins right to move a Court for
the enforcement of any of the rights conferred by Part III .of the Constitution would be suspended
for the time being. He could always approach higher Governmental authorities. All of them could
not be so unreasonable as to deny redress in a case of genuine injustice.
241. The propositions thus stated appear to be so reasonable and are so well founded, as I shall
endeavour to show later, in the course of this judgment, in the Constitutional and legal history and
the case law of other countries, during periods of Emergency, from whose constitutions what has
been described as the "ancient writ of Habeas Corpus" has been taken and transplanted into our
Constitution that it may seem somewhat surprising that their correctness should be doubted or
denied at all. The propositions have, however, not only been vehemently assailed but the attacks
upon them were sought to be supported by attempts to engraft theories upon our Constitution
which, if accepted, will destroy the basic principle of the supremacy of the written Constitution
which I attempted, in Smt. Indira Nehru Gandhi v. Shri Raj Narain to explain at some length.
242. If the clear and unequivocal language of Article 359(1) of our Constitution is the bed-rock on
which the Attorney General's arguments to sustain the preliminary objections to the maintainability
of Habeas Corpus petitions during the Emergency rest, learned Counsel for the detenus have put
forward theories of a nebulous natural law and a common law which, on close scrutiny, appear to
me to resolve themselves into what, according to the notions of learned Counsel for the detenus, the
law ought to be. Strenuous attempts have been made to dress up these notions in the impressive
garb of the "Rule of Law" which evokes the genuine and our and respectful devotion of lawyers and
public spirited citizens. But, the mere veneration of a caption, without an understanding of what it
really denoted in the past and what it means or should mean today, is another name for obfuscation
of thought.
243. Even in England, the reputed home of the Rule of Law, the rather loose, general, and in exact
meaning given to the term by Dicey to describe and glorify certain assumedly special characteristics
of the English Constitution, have given place to more realistic, critical, and scientific views of the
"Rule of Law" and what Dicey meant by it. Sir Ivor Jennings, in "The; Law and the Constitution"
(3rd Edn. p. 296) pointed out :
Dicey honestly tried (in The Law of the Constitution, not in ins polemical works) to
analyse, but, like most, he saw the Constitution through ins own spectacles, and ins
vision was not exact. The growth of the new functions of the State has made much of
ins analysis irrelevant. Moreover, the argument "from history or, what is the same
thing, from the Constitution must be used with discretion. To say that a new policy is
'unconstitutional' is merely to say that it is contrary to tradition, and it must always
be considered whether the tradition is relevant to new circumstances. Even if the rule
of law as Dicey expounded it had been exact, it would not be a sufficient argument to
say of any proposal, as the Committee on Ministers' Powers said on a minor point,Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

that it was contrary to the rule of law.
244. Those who glibly talk of the Rule of Law, as expounded by Dicey, forget that Prof. Dicey had
made a very gallant and effective (I would not like to use here a colloquial expression, "desperate",
to describe it) attempt to repel the correctness of what he called "the dark saying" of de Tocqueville
that the largely conventional "English Constitution has no real existence 'ellen existe point)" (See :
page 22 of the Dicey's "Introduction to the Study of the Law of the Constitution"--10th Edn.). He
was at pains to show that the Constitutional Law of England did exist. It lived and functioned not
only in the hearts and minds of Englishmen, also reflected in Parliament, but through the force of
healthy conventions and highly disciplined habits of life and thought of the British people. These
conventions and habits had, behind them, the sanction not only of a powerful and intelligent public
opinion but also of the control by the Houses of Parliament, wrested from the Crown in the course of
instoric constitutional struggles, over the finances of the nation. Dicey distinguished this peculiarly
British Constitutional Law from "political ethics" which, according to him, was "mis-called
Constitution Law". It was not, he pointed out, like: International law, the "vanishing point" of law.
245. Dicey succeeded, at least so far as his statement of the Rule of Law is concerned, in doing
nothing more than indicating, under this heading, certain common guiding principles for Courts as
well as Legislators to follow when they needed these. Hence, he said that the Rule of law and the
legal Sovereignty of Parliament were allies in England. According to him, both these principles so
operated as to always support and strengthen each other. This idealistic rosy optimism, reflecting
the Whig tradition of minimum interference with individual freedoms and representing the
Constitutional jurisprudence of the hey-day of a laissez faire British economic prosperity, was
destined to be displaced by the more "down to the earth" pragmatism of the Twentieth Century
Britain, attempting to meet economic difficulties and distress through socialistic planning and to
build a welfare State by making laws which appeared to those brought up on the traditional
postulates of Dicey's Rule of Law to deny the validity of its basic assumptions.
246. The first of these assumptions or meanings was that any deprivation of personal liberty or
property must not only be for a "distinct breach of law" but ''established in the ordinary legal
manner before the ordinary Courts of the land". He contrasted this "with every system of
government based on the exercise by persons in authority of wide, arbitrary, or discretionary powers
of constraint". He concluded, from what he regarded as a basic feature of the British Constitution,
that all modes of dispensing justice, through specialised administrative authorities and bodies, must
necessarily be autocratic and unfair. He compared the British system with the one under which
Voltaire, in 1717, was "sent to the Bastille for a poem which he had not written, of which he did not
know the author, and with the sentiments of which he did not agree". The second assumption of
Dicey's Rule of Law was : "Every man, whatever be his rank or condition, is subject to the ordinary
law of the realm and amenable to the jurisdiction of the ordinary tribunals". He overlooked the not
infrequent injustice caused in England of his time, due to want of adequate remedies against the
servants of the Crown, by applications of the maxim : "The King can do no wrong". He wrote "With
us every official, from the Prime Minister down to a constable or a collector of taxes, is under the
same responsibility for every act done without legal justification as any other citizen". The third
assumption on which Dicey's Rule of Law rested was what he called "the predominance of the legalAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

spirit" which he described "as a special attribute of English Institutions". He explained :
We may say that the Constitution is pervaded by the rule of law on the ground that
the general principles of the Constitution was for example the right to personal
liberty, or the right of public meeting) are with us the result of judicial decisions
determining the rights of private persons in particular cases brought before the
Courts; whereas under many foreign constitutions the security (such as it is) given to
the rights of individuals results, or appears to result from the general principles of the
constitution.
Dicey observed :
There is in the English Constitution an absence of these declarations or definitions of
rights so dear to foreign constitutionalists. Such principles, moreover, as you can
discover in the English Constitution are, like all maxims established by judicial
legislation, mere generalisations drawn either from the decisions or dicta of judges,
or from statutes which, being passed to meet special grievances, bear a close
resemblance to judicial decisions, and are in effect judgments pronounced by the
High Court of Parliament. To put what is really the same thing in a somewhat
different shape, the relation of the rights of individuals to the principles of the
Constitution is not quite the same in countries like Belgium, where the Constitution
is the result of a legislative act, as' it is in England, where the Constitution itself is
based upon legal decisions.
247. Thus, Dicey depicted the British Parliament, while performing even its legislative functions, as
if it was a Court following the path shown by judges filled with the spirit of law and with meticulous
concern for all the canons of justice. He concluded : "Our Constitution, in short, is a Judge-made
Constitution and it bears on its face all the features, good and bad, of judge made law".
248. Dicey thought that the difference between the unwritten British Constitution and a written
Constitution, such as that of Belgium, was not merely a formal one, but revealed entirely differing
approaches to basic freedoms. He observed :
The matter to be noted is, that where the right to individual freedom is a result
deduced from the principles of the constitution, the idea readily occurs that the right
is capable of being suspended or taken away. Where, on the other hand, the right to
individual freedom is part of the Constitution because it is inherent in the ordinary
law of the land, the right is one which can hardly be destroyed without a thorough
revolution in the institutions and manners of the nation.
249. After making the distinction mentioned above, Dicey deals with "the so-called suspension of
the Habeas Corpus Act". He said that it bears "a certain similarity to what is called in foreign
countries 'suspending the constitutional guarantees'".. He euphemistically, explained :Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

But, after all, a statute suspending the Habeas Corpus Act falls very far short of what
its popular name seems to imply; and though a serious measure enough, is not, in
reality, more than a suspension of one particular remedy for the. protection of
personal freedom. The Habeas Corpus Act may be suspended and yet Englishmen
may enjoy almost all the rights of citizens. The Constitution being based on the rule
of law, the suspension of the constitution, as far as such a thing can be conceived
possible, would mean with us nothing less than a revolution.
250. If Dicey, bewitched by the beauties of an unwritten British Constitution could have been
shocked by any modern transgressions of the basic principles of his "Rule of Law"--in the
Introduction to later editions of his book, Dicey modified his earlier views, to some extent, about the
nature and purposes of "Droit Administratif", accepted the inevitability of change, and noticed the
logical consequences of what he himself had described, in his "Law and Opinion in England", as the
Collectivist or Socialistic trend--he would have been even more shocked by the proposition that the
cherished principles of his Rule of Law could override the statute law which the British Parliament
could make and unmake in the exercise, of what Dicey called the "Sovereignty of Parliament". The
truth is that Dicey did not, at first, visualise the possibility of any conflict between the Rule of Law
and the principles of Parliamentary Sovereignty in England. And, correctly understood and applied,
there should not be serious conflict between them. But, are principles always correctly understood
and applied ?
251. Jennings critically commented upon Dicey's views (See : "The Law and the Constitution" 3rd
Edn. p. 294) as follows :
The rules which in foreign countries naturally form part of a constitutional code
"mostly do not exist in England, for the recognised (or legal) supremacy of
Parliament prevents any fundamental distribution of powers and forbids the
existence of fundamental rights. The supremacy of Parliament is the Constitution. It,
is recognised as fundamental law just as a written Constitution is recognised as
fundamental law. Various Public authorities--the Crown, the Houses of Parliament,
the courts, the administrative authorities--have powers and duties. Most of them are
determined by statute. Some are traditional, and so are 'determined' by the common
law. The powers of administrative authorities in respect of 'fundamental liberties' are
mainly contained in statutes. But even if they were not, I do not understand how it is
correct to say that "the rules are the consequence of the rights of individuals and not
their source. The powers of the Crown and of other administrative authorities are
limited by the rights of individuals; or the rights of individuals are limited by the
powers of the administration. Both statements are correct; and both powers and
rights come from the law--from the rules.
252. Thus, Jennings pointed out that what was material was the existence of rules, as a part of
Constitutional law, and not their sources or forms. He tried to show that the basic rule being the
supremacy of Statutory law that was "The Constitution" in Britain. No other rule could compete with
it or stand in its way or be a substitute for it. Dicey, on the other hand, believed that the difference inAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

sources and forms of rules made a great difference in approach and outlook. But, Dicey also treated
the judge-made Rule of Law and the rights "guaranteed" by a written Constitution as alternatives or
different modes of protecting same species of rights. He never dreamt of looking upon them both as
simultaneously existing and available under a written Constitution in addition to what such a
Constitution contained.
253. Dicey, indicated the basic distinction between the Constitutional position in England,, with an
unwritten Constitution where the supremacy of Parliament prevailed, and that in the United States
of America, with a written Constitution which was supreme. But, despite the differences in the
logical consequences of an unwritten constitution, in a country so largely governed by its
conventions and disciplined habits of life and thought as Dicey's England, and those of the written
Constitution of the U.S.A.., one common feature, shared by both English and American systems, was
the large amount of judicial Constitutional law making which took place in both countries.
254. In Britain, although the Parliament is the supreme law-giver, yet, as Dicey pointed out, there
was, out of respect for the judicial function and the Rule of Law, an acceptance of judge made law as
the constitutional law of the land which the Parliament could alter, whenever it liked, but did not
think of altering presumably because it served very well, the needs of British people who took pride
in their judge-made law. Of course, if Parliament did make a law on any subject-- and it has made
some laws on Constitutional matters also--the Courts could not think of questioning the validity of
the law so made.
255. In America, not only was the doctrine of judicial review of legislation, established by Marshall,
C. J., in Marbury v. Madison (1803)-(1 Cranch 137), but the "due process" clauses, introduced by the
5th amendment (1791) and by the 14th amendment (1868) of the American Constitution, became
the most prolific sources of judicial law-making. They gave to the American Courts an amplitude of
power to indulge in what is called "judicial legislation" which our Constitution makers, after
considerable debate, deliberately eschewed by using the expression "procedure established by law"
instead of the "due process of law". Willis, adverting to the very skeletal character of the American
Constitution, said :
Our original Constitution was not an anchor but a rudder. The Constitution of one
period has not been the Constitution of another period. As one period has succeeded
another, the Constitution has become larger and larger.
256. In A. K. Gopalan v. The State of Madras [1950] S. C. R. 88 @ p. 109, the earliest case in which a
comprehensive discussion of fundamental guaranteed freedoms in our Constitution took place,
Kania, C. J., after referring to observations of Munro, of James Russell Lowell, of Willis, and of
Cooley, on the American Constitution, noted about the nature of our Constitution (at p. 109) :
The Constitution itself provides in minute details the legislative powers of the
Parliament and the State Legislatures. The same feature is noticeable in the case of
the judiciary, finance, trade, commerce and services. It is thus quite detailed and the
whole of it has to be read with the same sanctity, without giving undue weight to PartAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

III or Article 246, except to the extent one is legitimately and clearly limited by the
other.
257. The position in this country is clearly one in which the fundamental law found in the
Constitution is paramount. The Constitution provides the test for the validity of all other laws. It
seeks to determine the spheres of executive and legislative and judicial powers with meticulous care
and precision. The judicial function, though wider in range when interpreting or applying other
Articles of the Constitution, particularly Articles 14 and 19, the enforcement of which is also
suspended during the current Emergency, is especially constricted by the elaborate provisions of
Articles 21 and 22, which deal with personal liberty and preventive detention. The wider the sweep
of the provisions of Article 21 and 22 the more drastic must be the effect of suspending their
enforcement. After all, suspension does not and cannot mean retention under a disguise.
258. The only Rule of Law which can be recognised by Courts of our country is what is deducible
from our Constitution itself. The Constitution is, for us, the embodiment of the highest "positive
law" as well as the reflection of all the rules of natural or ethical or common law lying behind it
which can be recognised by Courts. It seems to me to be legally quite impossible to successfully
appeal to some spirit of the Constitution or to any law anterior to or supposed to lie behind the
Constitution to frustrate the objects of the express provisions of the Constitution. I am not aware of
any Rule of Law or reason which could enable us to do that. What we are asked to do seems nothing
short of building some imaginary parts of a Constitution, supposed to lie behind our existing
Constitution, which could take the place of those parts of our Constitution whose enforcement is
suspended and then to enforce the substitutes. And, we were asked by some learned Counsel,
though not by all, to perform this ambitious task of judicial Constitution making without even using
the crutches of implied imperatives of our Constitutional provisions as though we had some plenary
legislative Constituent powers. Fortunately, Judges in this country have no such powers. And, those
who are meant to so function as to keep the other authorities and organs of State within the limits of
their powers cannot themselves usurp powers they do not possess. That is the path of descent into
the arena of political controversy which is so damaging for the preservation of the impartiality and
prestige of the judicial function. We cannot, therefore, satisfy those who may feel the urge, as Omar
Khayyam did "to shatter" what they regard as "this sorry scheme of things entire" and to "remould"
it nearer their "heart's desire". I think we must make it clear that the spirit of law or the Rule of Law,
which we recognise, cannot, however ominously around like some disembodied ghost serving as a
substitute for the living Constitution we actually have. It has to be found always within and
operating in harmony with and never outside or in conflict with what our Constitution enjoins. All
that we can do is to faithfully explain what the Constitution and its spirit mean. We cannot alter or
twist these.
259. The distinction made above between law as it exists and as it has to be recognised and enforced
by the State's judicial organs, and "the law", if we may call it that at all, which could only constitute
some rules of ethics but could not been forced at all, whatever may be its moral worth, was thus
stated by John Codman Hurd in ins "Law of Freedom and Bondage in the United States" (Negro
Universities Press, New York (Vol. I, at p. 3) :Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Now, jurisprudence is taken to be the science of a rule not merely existing, but one
which is actually operative or enforced in or by the will of society or the state. The
Science of what rule ought to be made operative by the will of the state is a different
thing; it is a science of rules regarded only as existing, whether operative in civil
society--that is enforced--or not.
A rule made operative by the authority of society, or of the state, is a rule identified
with the expressed will of society or of the State. The will of the state, indicated in
some form of expression, is the law, the subject of jurisprudence, and no natural rule
which may exist, forms a part of the law unless identified with the will of the state so
indicated. What the state wills is the conterminous measure of law, no preexisting
rule is the measure of that will.
260. John Codman Hurd went on to point out that judicial authorities constituted by the State can
only carry out the mandates of the positive law which, for purposes of enforcement, must be deemed
to embody all the pre-existing enforceable natural and ethical values.
261. Enforceability, as an attribute of a legal right, and the power of the judicial organs of the State
to enforce the right, are exclusively for the State, as the legal instrument of Society, to confer or take
away in the legally authorised manner. It follows from these basic premises of our Constitutional
jurisprudence that Courts cannot, during a constitutionally enjoined period of suspension of the
enforceability of Fundamental Rights through Courts, enforce what may even be a "fundamental
right" sought to be protected by Part III of the Constitution. The Attorney General has, very fairly
and rightly, repeatedly pointed out that no substantive right, whether declared fundamental or not,
except the procedural rights converted into substantive ones by Article 32, could be suspended.
Even the enforcement in general, of all such rights is not suspended. Only the enforcement of
specified rights through Courts is suspended for the time being.
262. The enforceability of a right by a constitutionally appointed judicial organ has necessarily to
depend upon the fulfilment of two conditions : firstly, its recognition by or under the Constitution as
a right; and, secondly, possession of the power of its enforcement by the judicial organs. Now, if a
right is established, on facts, as a right, it will certainly satisfy the first condition. But, if the right is
unenforceable, because the power-of its enforcement by Courts is constitutionally suspended or
inhibited, for the duration of the Emergency, its mere recognition or declaration by Courts, either as
a right or as a fundamental right, could not possibly help a petitioner to secure ins personal liberty.
Article 226 of the Constitution is not meant for futile and unenforceable declarations of right. The
whole purpose of a writ of Habeas Corpus is to enforce a right to personal freedom after the
declaration of a detention as illegal when it is so found upon investigation.
263. It may be that many moral and natural obligations exist outside the Constitution and even
outside any positive law--this is not denied by the learned Attorney General at all--but, their
existence is not really relevant for purposes of petitions for writs of Habeas Corpus which lie only to
enforce legally enforceable rights. Neither the existence nor the possibilities of denials of any rights
by the detaining officers of the State, due to fragilities of human nature and errors of judgment, areAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

denied by the Attorney General. All that is denied is the correctness of the assertion that they are
enforceable, during the period of Emergency, through Courts, if they fall within the purview of rights
whose enforcement is suspended.
264. The result of the few very general observations made above by me, before examining, in greater
depth, any of the very large number of connected questions and side issues raised--I doubt whether
it is necessary or of much use, in view of my opinion on the preliminary issue of enforceability, to
consider all of them even if it were possible for me to do so--may be summarised as follows :
Dicey's Rule of Law, with special meanings given to it, was meant to prove the
existence and peculiarities of the unmodified English Constitutional Law. According
to Dicey himself, these features either did not exist elsewhere or were the very
objectives of .provisions of written Constitutions of other countries. On Dicey's very
exposition, no ordinary Judge-made law or common law could survive in opposition
to statutory law in England, or, in conflict with a written Constitution where there
was one. Enforceability of rights, whether they are constitutional or common law or
statutory, in constitutionally prescribed ways by constitutionally appointed judicial
organs, is governed solely by the terms of the written instrument in a Constitution
such as ours. The scope for judicial law making on the subject of enforcement of the
right to personal freedom was deliberately restricted by our Constitution makers. In
any case, it is difficult to see any such scope when "enforcement" itself is suspended.
All we can do is to determine the effect of this suspension. We have now to consider
in greater detail: What is it the enforcement of which is suspended and what, if
anything,, remains to be enforced ?
265. In this country, the procedure for the deprivation as well as enforcement of a right to personal
freedom is governed partly by the Constitution and partly by ordinarily statutes. Both fall within the
purview of "procedure". Article 21 of the Constitution guarantees, though the guarantee is negatively
framed, that "no person shall be deprived of ins life or personal liberty except according to
procedure established by law". If an enforcement of this negatively framed right is suspended, a
deprivation contrary to the prescribed procedure is not legalised. The suspension of enforcement
does not either authorise or direct any authority to violate the procedure. It has to be clearly
understood that what is suspended is really the procedure for the enforcement of a right through
Courts which could be said to flow from the infringement of a statutory procedure. If the
enforcement of a right to be free, resulting derivatively from both the Constitutional and statutory
provisions, based on an infraction of the procedure, which is statutory in cases of preventive
detention, is suspended, it seems to me to be impossible to lay down that it becomes enforceable
when that part of the procedure which is mandatory is violated but remains unenforceable so long
as the part of the procedure infringed is directory. Such a view would, in my opinion, introduced a
distinction which is neither warranted by the language of Article 359 of the Constitution nor by that
of the Presidential Orders of 1975. If the claim to assert the right is one based on violation of
procedure, the degree of violation may affect the question whether the right to be free is established
at all, but, it should not, logically speaking, affect the result where the enforcement of the right, even
in a case in which it has become apparent, is suspended.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

266. The question, however, which has been most vehemently argued is : Does Article 21 exhaust
every kind of protection given to rights to personal freedom ? Another way in which this question
was put is : Is Article 21 of the Constitution "the sole repository" of the substantive as well as
procedural rights embraced by the expression "personal liberty" ? One of the contentions before us
was that Article 21 does not go beyond the procedural protection to persons who may be deprived of
personal liberty.
267. Mr. Jethmalani, learned Counsel appearing for one of the detenues, contended that personal
freedom was a by-product of the removal of constraints or hindrances to the positive freedom of
action of the individual. The contention seemed to be that procedure for deprivation of personal
liberty being one of the ways of imposing positive constraints, the removal of a negative procedural
protection could not dispense with the necessity to establish a right of the detaining authority under
some positive or statutory law to deprive a person detained of ins liberty whether the authority
concerned followed the right procedure or not in doing so. The argument is that proof of a just and
reasonable cause, falling within the objects of the Act so as to create a liability to be detained, must
precede the adoption of any procedure to detain a person under the Act. A "satisfaction" that one of
the grounds of detention, prescribed by Section 3 of the Act, is there, was thus said to be a
"condition precedent" to the exercise of jurisdiction to detain. This argument obviously proceeded
on a restricted meaning given to the "procedure established by law". It is very difficult to see why the
satisfaction, required by Section 3 of the Act, is not really part of "procedure established by law".
268. There is, however, an even more formidable difficulty in the way of this argument. If, as it is
undeniable, the procedure under Article 226 is the direct procedural protection, which is suspended
by the terms of the Presidential Order, read with Article 359, Article 226 will not be available to the
detenue at all, for the time being, for showing absence of the required "satisfaction", as a condition
precedent to a valid detention order under Section 3 of the Act. If the "right to move any Court" can
be suspended-- Article 359 is very clear on the point--there remains no right, for the time being, to
an inquiry into conditions which may enable a party to secure release in assertion of rights
guaranteed either by Article 21 or by other Articles whose "enforcement" is suspended. Indeed, the
clear object of such a suspension seems to me to be that Courts should not undertake inquiries into
the violations of the alleged right.
269. If the fundamental rights in Part III of the Constitution are not suspended, as they obviously
are not, but only their enforcement can be and is suspended what is really affected is the power
conferred on Courts by Articles 32 and 226 of the Constitution. The power of the Courts is the direct
and effective protection of the rights sought to be secured indirectly by Article 21, and perhaps less
indirectly, by some other Articles and laws. Indeed, it is the basic protection because other
protections operate through it and depend on it. If this is curtailed temporarily, the other affected
protections become automatically inoperative or ineffective so far as Courts are concerned.
270. It is no answer to say that the Constitutional power of High Courts cannot be affected by a
Presidential order under Article 359 which is as much a part of the Constitution as Article 226. Both
Articles were there from the commencement of the Constitution. 1 do not see how it can be
reasonably urged that our Constitution makers did not visualise and intend that the PresidentialAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

order under Article 359 must, for the duration of the Emergency, necessarily limit the powers of
High Courts under Article 226 albeit indirectly by suspending rights to enforcement of fundamental
rights.
271. It is also not possible for a detenue to fall back upon the last part of Article 226 of the
Constitution which enables the use of powers given by this Article "for any other purpose". Sq long
as that purpose is enforcement of a right which is covered by Articles 14 or 19 or 21 or 22 either
separately or conjointly, as the enforcement of each of these is now suspended, the inhibition will be
there. Moreover, we have no case before us in which a detenu asks for an order for any purpose
other than the one which can only be served by the issue of a writ of Habeas Corpus. Each detenu
asks for that relief and for no other kind of writ or order. Therefore, there is no need to consider
"any other purpose".
272. It is true that some of the learned Counsel for the detenus have strongly relied upon "any other
purpose", occurring at the end of Article 226, for enabling the High Court to undertake an
investigation suo motu into the question whether the executive is performing its duties. Other
Counsel have submitted that such an enquiry suo motu can be undertaken by this Court or by a High
Court in exercise of powers to issue writs of Habeas Corpus quite apart from the enforcement of the
right of a detenu to any writ or order. As I have indicated earlier, I am not prepared to answer purely
hypothetical questions, except within certain limits, that is to say, only so far as it is necessary for
the purposes of illustrating my point of view. I do not think that the powers of Courts remain
unaffected by the suspension of rights or locus standi of detenus. A Court cannot, in exercise of any
supposed inherent or implied or unspecified power, purport to enforce or in substance enforce a
right the enforcement of which is suspended. To permit such circumvention of the suspension is to
authorise doing indirectly what law does not allow to be done directly. Assuming, for purposes of
argument, that there is some unspecified residue of judicial power in Courts of Record in this
country, without deciding what it could be, as that question does not really arise in cases before us,
there must be undeniable facts and circumstances of some very grave, extraordinary, and
exceptional character to justify the use of such powers, if they exist at all, either by this Court or by
the High Courts. So long as the powers of Government are exercised by the chosen representatives
of the people, their exercise is presumed to be of the people and for the people. It has to be borne in
mind that the validity of the declaration of Emergency under Article 352 has neither been nor can it
be constitutionally challenged in view of Article 352(5) of the Constitution. And, the validity of
Presidential Orders of 1975 under Article 359 has not been questioned.
273. So far, I have only indicated the nature of the problems before us and my general approach to
them. Before specifically answering questions, stated at the outset, I will deal, as briefly as possible,
under the following Six main heads, with such of the very large number of points raised and
authorities cited before us as appear to me to be really necessary for answering the questions calling
for our decision :
(A) "Rights conferred by Part III" of our Constitution from the point of view of
Personal Freedom.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

(B) Power to issue writs of Habeaus Corpus and other powers of High Courts under
article 226 of the constitution.
(C) The objects of the Maintenance of Internal Security Act ('the Act') and the
amendments of it.
(D) The purpose and meaning of Emergency provisions, particularly Article 359 of
our Constitution.
(E) The effect of the Presidential orders, particularly the order of 27th June, 1975, on
the rights of Detenus.
(F) The Rule of Law, as found in our Constitution, and how it operates during the
Emergency.
(A) "Rights conferred by Part III" from the point of view of personal freedom.
274. It is somewhat difficult to reconcile the language of ^a purported conferment of rights upon
themselves by citizens of India with their political sovereignty. The language of the preamble to the
Constitution recites that it is they who were establishing the legally Sovereign Democratic Republic
with the objects given there. Of course, some rights are "conferred" even on non-citizens, but that
does not remove the semantic difficulty which gave rise to some argument before us. It seems to me
that if, as this Court has already explained earlier (e.g. by me in Shrimati Indira Nehru Gandhi's case
(supra), the Constitution, given unto themselves by the people, is legally supreme, it will not be
difficult to assign its proper meaning to the term "conferred". I do not find the theory unacceptable
that there was a notional surrender by the people of India of control over their several or individual
rights to a sovereign Republic by means of a legally supreme Constitution to which we owe
allegiance. It only means that we recognise that the Constitution is supreme and can confer rights
and powers. We have to look to it alone and not outside it for finding out the manner in which and
the limits subject to which individual citizens can exercise their separate freedoms. There has to be
necessarily, as a result of such a process of Constitution making, a notional surrender of individual
freedom so as to convert the possibility of "licence" to all, which ends in the exploitation and
oppression of the many weak by the few strong, into the actuality of a freedom for all regulated by
law or under the law applicable to all. This seems to me to be a satisfactory explanation of the
language of conferment used with reference to rights.
275. Apart from the explanation given above, of the language of conferment, the meaning of placing
some rights in Part III, whatever be the language in which this was done, is surely to select certain
rights as most essential for ensuring the fulness of lives of citizens. The whole object of guaranteed
fundamental rights is to make those basic aspects of human freedom, embothed in fundamental
rights, more secure than others not so selected. In thus recognising and declaring certain basic
aspects; of rights as fundamental by the Constitution of the country, the purpose was to protect
them against undue encroachments upon them, by the legislative, or executive, and, sometimes even
judicial (e.g. Article 20) organs of the State. The encroachments must remain within permissibleAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

limits and must take place only in prescribed modes. The intention could never be to preserve
something concurrently in the field of Natural Law or Common Law. It was to exclude all other
control or to make the Constitution the sole repository of ultimate control over those aspects of
human freedom which were guaranteed there.
276. I have already referred to Dicey's attempt to show that one of the meanings of the Rule of Law
in England was that the law made by the ordinary Courts served purposes sought to be achieved in
other countries by means of written Constitutions. This meant that one of the two systems governs
the whole field of fundamental rights but not both. This very idea is thus put by Keir & Lawson in
"Cases in Constitutional Law (5th Edn. p. 11) :"
The judges seem to have, in their minds an ideal constitution, comprising those
fundamental rules of common law which seem essential to the liberties of the subject
and the proper government of the country. These rules cannot be repealed but by
direct and unequivocal enactment. In the absence of express words or necessary
intendment, statutes will be applied subject to them. They do not override the statute,
but are treated, as it were, as implied terms of the statute. Here may be found many
of those fundamental rights of man which are directly and absolutely safeguarded in
the American Constitution or the Declaration des droits de I homme.
277. In the passage quoted above, Rules of Natural Justice, which are impliedly read into statutes
from the nature of functions imposed upon statutory authorities or bodies, are placed on the same
footing as "fundamental fights of men which are directly and absolutely safeguarded" by written
Constitutions. There is, however, a distinction between these two types of basic rights. The implied
rules of natural justice do not, as has been repeatedly pointed put by us, over-ride the express terms
of a statute. They are only implied because- the functions which the statute imposes are presumed to
be meant to the exercised in accordance with these rules. Hence, they are treated as though they
were parts of enacted law. This Court has repeatedly applied this principle (see : e.g. State of Orissa
v. Dr. (Miss) Binapani Dei and Ors.
278. The principles of natural justice which are so implied must always hang, if one may so put it, on
pegs of statutory provisions or necessarily follows from them. They can also be said sometimes to be
implied as necessary parts of the protection of equality and equal protection of laws conferred by
Article 14 of the Constitution where one of the pillars of Dicey's principles of the Rule of Law is
found embodied. Sometimes, they may be implied and read into legislation dealing with rights
protected by Article 19 of the Constitution. They could, at times, be so implied because restrictions
on rights conferred by Article 19 of the Constitution have to be reasonable. Statutory provisions
creating certain types of functions may become unreasonable, and, therefore, void unless rules of
natural justice were impliedly annexed to them. And, the well known method of construction is : "ut
res magis valeat guam pereat"--to prefer the construction which upholds rather than the one which
invalidates. Thus, rules of natural justice, even when they are read into statutory provisions, have no
independent existence. They are annexed to statutory duties or fundamental rights so long as they
are not expressly excluded. Their express exclusion by statute may, when the enforcement of
fundamental rights is not suspended, affect the validity of a statute: But, that is so because of theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

requirements of Articles 14 and 19 of the Constitution and not because they are outside the
Constitution altogether.
279. It is also very difficult for me to understand what is meant by such "Common Law" rights as
could co-exist and compete with constitutional provisions or take their place when the constitutional
provisions become unenforceable or temporarily inoperative. The whole concept of such alleged
Common Law is based on an utter misconception of what "Common Law" means. The origin of
Common Law in England is to be found in the work done by the King's Judges, who, through their
judicial pronouncements, gave to the people of that country a law common to the whole country in
the place of the peculiar or conflicting local customs. Let me quote here from a recent book by Prof.
George W. Keeton on "English Law--The Judicial Contribution" (at p. 68-69), about what Judges
appointed by Henry the II of Anjou did :
It is in his reign that something recognisable as a Common Law begins to emerge. It
is an amalgam of Anglo-Saxon and Danish customs and Norman laws governing
military tenures, both of which are about to be transformed by several mighty
agencies--the ever-expanding body of original writs, of which Glanville wrote; the
assizes which Henry introduced; and finally, by the activities of his judges, whether at
Westminster or on Circuit. It is significant that although for some centuries to come,
English law was to remain remarkably rich in local customs, we no longer hear, after
Henry's reign, of the laws of Mercia, Wessex and Northum-bria, but of a Common
Law of England--that is to say, the law of the king's courts, about which treatises of
the calibre of Bracton and Fleta would be written almost exactly a century later, and
as the concluding words of Pollock and Maitland's great work remind us, they and
their judicial colleagues were building, not for England alone but for king-less
common-wealths on the other shore of the Atlantic Ocean'--and now, one can
perhaps add, for many other commonwealths, too. This we owe ultimately, not to a
Norman Conqueror, nor even to a distinguished line of Saxon , kings, but to a
bow-legged and unprepossessing prince of Anjou, of restless energy and great
constancy of purpose who built, perhaps, a good deal better than even he knew.
280. Such were the origins of the Common Law in England. It is true that Common Law did try to
dig its tentacles into Constitutional Law as well. Chief Justice Coke not only denied to King James
the 1st the power to administer justice directly and personally, but he went so far as to claim for the
King's Courts the power to proclaim an Act of Parliament invalid, in Dr. Bonham's case, if it sought
to violate a principle of natural law. Such claims, however, were soon abandoned by Common Law
Courts.
281 It is interesting to recall that, after ins dismissal, by King James the 1st, in 1616, Sir Edward
Coke entered politics and became a Member of the House of Commons in Liskeard. He led a group
which resisted Royal claims. He was the principal advocate of the Petition of Rights which
Parliament compelled a reluctant King of England to accept in 1628. Courts of justice, unable to
withstand Royal onslaughts on their authority, joined hands with Parliament and laid down some of
the rules which, according to Dicey, gave the Rule of Law to England. Thus, the judge-madeAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

fundamental rights, which Parliament would not disturb, out of innate respect for them, existed,
legally speaking, because Parliament, representing the people, wanted them. They could not
compete with or obstruct the legal authority of Parliament. Coke's doctrine, however, found
expression in a Constitution which enabled judges to test the validity of even legislation with
reference to fundamental rights. This is also one of the primary functions of Chapter III of our own
Constitution. Another function of provisions of this chapter is to test the validity of the State's
executive action.
282. So far as Article 21 of the Constitution is concerned, it is abundantly clear that it protects the
lives and liberties of citizens primarily from legally unwarranted executive action. It secures rights to
'procedure established by law'. If that procedure is to be established by statute law, as it is meant to
be, this particular protection could not, on the face of it, be intended to operate as a restriction upon
legislative power to lay down procedure although other Articles affecting legislation on personal
freedom might. Article 21 was only meant, on the face of it, to keep the exercise of executive power,
in ordering deprivations of life or liberty, within the bounds of power prescribed by procedure
established by legislation.
The meaning of the expression "procedure established by law" came in for discussion at
considerable length, by this Court, in A. K. Gopalan's case (supra). The majority of the learned
Judges clearly held there that it furnishes the guarantee of "Lex", which is equated with statute law
only, and not of "Jus" or a judicial concept of what procedural law ought really to be. The whole
idea, in using this expression, taken deliberately from the Japanese Constitution on the advice,
amongst others, of Mr. Justice Felix Frankfurter of the American Supreme Court, was to exclude
judicial interference with executive action in dealing with lives and liberties of citizens and others
living in our country on any ground other than that it is contrary to procedure actually prescribed by
law, which, according to the majority view in Gopalan's case, meant only statute law. The majority
view was based on the reason, amongst others, that, according to well established canons of
statutory construction, the express terms of "Lex" (assuming, of course, that the "Lex" is otherwise
valid), prescribing procedure, will exclude "Jus" or judicial notions of "due process" or what the
procedure ought to be.
283. Appeals to concepts of "Jus" or a just procedure were made in Gopalan's case (supra), as
implied by Article 21, in an attempted application of "Jus" for testing the validity of statutory
provisions. Although, no such question of validity of the procedure established by the Act in
ordering actual deprivations of personal liberty has arisen before us, yet, the argument before us is
that we should allow use of notions of "Jus" and the doctrine of ultra vires by the various High
Courts in judging the correctness of applications of the established procedure by executive
authorities to each case at a time when the Presidential Order of 27th June 1975 precludes the use of
Article 21 by Courts for enforcing a right to personal liberty. Therefore, the question which arises
here is whether "Jus" held by this Court, in Gopalan's case, to have been deliberately excluded from
the purview of procedure established by law", can be introduced by Courts, through a back door, as
though it was an independent right guaranteed by Chapter III or by any other Part of the
Constitution. I am quite unable to accede to the suggestion that this could be done.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

284. We have been referred to the following passage in R. C. Cooper v, Union of India , to
substantiate the submission that the decision of this Court in Gopalan's case (supra), on the
question mentioned above, no longer holds the field :
We have found it necessary to examine the rationale of the two lines of authority and
determine whether there is anything in the Constitution which justifies this
apparently inconsistent development of the law. In our judgment, the assumption in
A.K. Gopalan's case that certain Articles in the Constitution exclusively deal with
specific matters and ' in determining whether there is infringement of the individual's
guaranteed rights, the object and the form of the State action alone need be
considered, and effect of the laws on fundamental rights of the individuals in general
will be ignored cannot be accepted as correct. We hold that the validity 'of law' which
authorises deprivation of property and 'a law' which authorises compulsory
acquisition of property for a public purpose must be adjudged by the application of
the same tests. A citizen may claim in an appropriate .case that the law authorising
compulsory acquisition of property imposes fetters upon ins right to hold property
which are not reasonable restrictions in the interests of the general public.
285. It seems to me that Gopalan's case (supra) was merely cited, in Cooper's case (supra), for
illustrating a line of reasoning which was held to be incorrect in determining the validity of "law" for
the acquisition of property solely with reference to the provisions of Article 31. The question under
consideration in that case was whether Articles 19(1)(f) and 31(2) are mutually exclusive. Even if, on
the strength of what was held in Cooper's case (supra), we hold that the effects of deprivation upon
rights outside Article 21 have also to be considered in deciding upon the validity of "Lex", and that
the line of reasoning in Gopalan's case (supra), that the validity of a law relating to preventive
detention must be judged solely with reference to the provisions of Article 21 of the Constitution, is
incorrect, in view of the opinion of the majority of learned Judges of this Court in Cooper's case
(supra), it seem to me that this is hardly relevant in considering whether any claims based on
natural law or common law can be enforced. There is no challenge before us based on Article 19, to
any provision of the Act. Moreover, now that the enforcement of Article 19 is also suspended, the
question whether a law dealing with preventive detention may directly or indirectly infringe other
rights contained in Article 19 of the Constitution is not relevant at all here for this additional reason.
286. Mr. Shanti Bhushan, appearing for some of the detenu, seems to have seriously misunderstood
the meaning of the majority as well as minority views of Judges of this Court in His Holiness
Kesava-nanda Bharati Sripadagalavaru v. State of Kerala [1973] Suppl. S. C. R. 1 @ 918 when he
submitted that, as the majority view there was not that natural rights do not exist, these rights could
be enforced in place of the suspended guaranteed fundamental rights. One learned Judge after
another in that case emphatically rejected the submission that any theory of natural rights could
impliedly limit powers of Constitutional amendment contained in Article 368 of the Constitution. In
doing so, none of us held that any natural rights could impliedly become legally enforceable rights.
287. Dwivedi, J., in Kesavananda Bharti's case (supra) said about what could be characterised as a
far more "unruly horse" than public policy (at p. 918):Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Natural Law has been a sort of religion with many political and constitutional
thinkers. But it has never believed in a single Godhead. It has a perpetually growing
pantheon. Look at the pantheon, and you will observe there : 'State of Nature'.
'Nature of Man'. 'Reason', 'Cod', 'Equality', 'Liberty', 'Property', 'Laissez Faire',
'Sovereignty', 'Democracy', 'Civilised Decency', 'Fundamental Conceptions of Justice'
and even 'War'.
The religion of Natural Law has its illustrious Priestly Heads such as Chrysippus,
Cicero, Seneca, St. Thomas Acquinas, Grotius, Hobbes, Locke, Paine, Hamilton,
Jefferson and Trietschke. The pantheon is not a heaven of peace. Its gods are locked
in constant internecine conflict.
Natural Law has been a highly subjective and fighting faith. Its bewildering variety of
mutually warring gods has provoked Kelson to remark : "Outstanding representatives
of the natural law doctrine have proclaimed in the name of Justice or Natural Law
principles which not only contradict one another, but are in direct opposition to
many positive legal orders. There is no positive law that is not in conflict with one or
the other of these principles; and it is not possible to ascertain which of them has a
better claim to be recognised than any other. All these principles represent the highly
subjective value judgments of their various authors about what they consider to be
just or natural.
288. If the concepts of natural law are too conflicting to make them a secure foundation for any
alleged "right", sought to be derived from it, until it is accepted and recognised by a positive law,
notions of what Common Law is and what it means, if anything, in this country, are not less hazy
and unsettled.
289. Mr. Setalvad, in ins Hamlyn Memorial Lectures on "Common Law in India", treated the whole
body of general or common statute law and Constitutional Law of this country as though they
represented a codification of the Common Law of England. If this view is correct, Common Law
could not be found outside the written Constitution and statute law although English Common Law
could perhaps be used to explain and interpret our statutory provisions where it was possible to do
so due to some uncertainty.
290. Sometimes, Judges have spoken of the principles of "Justice, equity, and good conscience" (See
: Satish Chandra Chakramurthi v. Ram Dayal De I. L. R. 48 Cal. 388 @ 407-410 Waghela Raj Sanji
v. Sheik Mashuddin and Ors. 14 Indian Appeals p. 89 @ 96 Baboo S/o Thakur Dhodi v. Mst.
Subanshi W/o Mangal A. I. R. 1942 Nag. 99, as sources of "Common Law" in this; country. One with
some knowledge of development of law in England will distinguish the two broad streams of , law
there : one supposed to be derived from the customs of the people, but, actually based on judicial
concepts of what custom is or should properly be; and. another flowing from the Court of the
Chancellor, the "Keeper of the King's Conscience", who used to be approached when plain demands
of justice failed to be met or caught in the meshes of Common Law, or, were actually defeated by
some statute law which was being misused. The two streams, one of Common Law and another ofAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Equity, were "mixed" or "fused" by statute as a result of the Judicature Acts in England at the end of
the last century in the sense that they became parts of one body of law administered by the same
Courts, although they are still classified separately due to their separate origins. In Stroud's Judicial
Dictionary, we find (See : Vol. I, 4th Edn. p. 517) : "The common law of England is that body of law
which has been judicially evolved from the general custom of the realm".
291. Here, all that I wish to indicate is that neither rights supposed to be recognised by some"
natural law nor those assumed to exist in some part of Common Law could serve as substitutes for
those conferred by Part III of the Constitution. They could not be, on any principle of law or justice
or reason, virtually added to part III as complete replacements for rights whose enforcement is
suspended, and 'then be enforced, through constitutionally provided machinery, as the unseen
appendages of the Constitution or as a separate group of rights outside the Constitution meant for
the Emergency which suspends but does not resuscitate in a new form certain rights.
292. A submission of Dr. Ghatate, appearing for Mr. Advani, was that we should keep in mind the
Universal Declaration of Human Rights in interpreting the Constitution. He relied on Article 51 of
the Constitution, the relevance of which for the cases before us is not at all evident to me. He also
relied on the principle recognised by British Courts that International Law is part of the law of the
land. Similarly, it was urged, it is part of our law too by reason of Article 372 of the Constitution. He
seemed to imply that we should read the universal declaration of human rights into our Constitution
as India was one of the signatories to it. These submissions appear to me to amount to nothing more
than appeals to weave certain ethical rules and principles into the fabric of our Constitution which is
the paramount law of this country and provides the final test of validity and enforceability of rules
and rights through Courts. To advance such arguments is to forget that our Constitution itself
embodies those rules and rights. It also governs the conditions of their operation and suspension.
Nothing which conflicts with the provisions of the Constitution could be enforced here under any
disguise.
293. Emergency provisions in our Constitution are, after all, a recognition and extension of the
individual's natural law right of self-defence, which has its expression in positive laws, to the State,
the legal organisation through which society or the people in its collective aspect, functions for the
protection of the common interests of all. Such provisions or their equivalents exist in the
Constitutions of even the most advanced democratic countries of the world. No lawyer can seriously
question the correctness, in Public International Law, of the proposition that the operation and
effects of such provisions are matters which are entirely the domestic concern of legally sovereign
States and can brook no outside interference.
294. Subba Rao, C.J., speaking for five learned Judges of this Court, in 7. C. Golaknath and Ors. v.
State of Punjab and Anr. :
Now, what are the fundamental rights ? They are embothed in Part III of the
Constitution and they may be classified thus : (i) right to equality, (ii) right to
freedom, (iii) right against exploitation, (iv) right to freedom of religion, (v) cultural
and educational rights, (vi) right to property, and (via) right to constitutionalAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

remethes. They are the rights of the people preserved by our Constitution.
"Fundamental rights" are the modern name for what have been traditionally known
as "natural rights". As one author puts : "they are moral rights which every human
being everywhere at all times ought to have simply because of the fact that in
contradistinction with other beings, he is rational and moral". They are the
primordial rights necessary for the development of human personality. They are the
rights which enable a man to chalk out ins own life in the manner he likes best. Our
Constitution, in addition to the well-known fundamental rights, also included the
rights of the minorities, untouchables and other backward communities, in such
rights.
295. I do not know of any statement by this Court of the relation between natural rights and
fundamental constitutional rights which conflicts with what is stated above.
296. Hidayatullah, J., in Golaknath's case (supra) observed (at p, 877) :
What I have said does not mean that Fundamental Rights are not subject to change
or modification. In the most inalienable of such rights a distinction must be made
between possession of a right and its exercise. The first is fixed and the latter
controlled by justice and necessity. Take for example Article 21 :
No person shall be deprived of ins life or personal liberty except according to
procedure established by law'. Of all the rights, the right to one's life is the most
valuable. This Article of the Constitution, therefore, makes the right fundamental.
But the inalienable right is curtailed by a murderer's conduct as viewed under law
The deprivation, when it takes place, is not of the right which was immutable but of
the continued exercise of the right.
297. The contents of Article 21 were considered at some length and given a wide connotation by this
Court in Gopalan's case (supra). Patanjali Sastri, J., held at pages 195-196 :
It was further submitted that Article 19 declared the substantive rights of personal
liberty while Article 21 provided the procedural safeguard against their deprivation.
This view of the correlation between the two Articles has found favour with some of
the Judges in the High Courts which have had occasion to consider the constitutional
validity of the impugned Act. It is, however, to be observed that Article 19 confers the
rights therein specified only on the citizens of India, while Article 21 extends the
protection of life and personal liberty to all persons citizens and non-citizens alike.
Thus, the two Articles do not operate in a conterminous field, and this is one reason
for rejecting the correlation suggested. Again, if Article 21 is to be understood as
providing only procedural safeguards, where is the substantive right to personal
liberty, of non-citizens to be found in the Constitution ? Are they denied such right
altogether ? If they are to have no right of personal liberty, why is the procedural
safeguard in Article 21 extended to them ? And where is that most fundamental rightAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

of all, the right to life, provided for in the Constitution? The truth is that Article 21,
like its American prototype in the Fifth and Fourteenth Amendments of the
Constitution of the United States, presents an example of the fusion of procedural
and substantive rights in the same provision. The right to live, though the most
fundamental of all, is also one of the most difficult to define and its protection
generally takes the form of a declaration that no person shall be deprived of it save by
due process of law or by authority of law. 'Process' or 'procedure' in this context
connotes both the act and the manner of proceeding to take away a man's life "or
personal liberty. And the first and essential step in a procedure established by law for
such deprivation must be a law made by a competent legislature authorising such
deprivation.
Mahajan, J., also observed at pages 229-230:
Article 21, in my opinion, lays down substantive law as giving protection to fife and
liberty inasmuch as it says that they cannot be deprived except according to the
procedure established by law; in other words, it means that before a person can be
deprived of ins life or liberty as a condition precedent there should exist some
substantive law conferring authority for doing so and the law should further provide
for a mode of procedure for such deprivation. This Article gives complete immunity
against the exercise of despotic power by the executive. It further gives immunity
against invalid laws which contravene the Constitution. It gives also further
guarantee that in its true concept there should be some form of proceeding before a
person can be condemned either in respect of ins life or ins liberty. It negatives the
idea of fantastic arbitrary and oppressive forms of proceedings. The principles
therefore underlying Article 21 have been kept in view in drafting Article 22.
Das, J., said at page 295 :
If personal liberty as such is guaranteed by any of the sub-clauses of Article 19(1) then
why has it also been protected by Article 21 ? The answer suggested by learned
Counsel for the petitioner is that personal liberty as a substantive right is protected
by Article 19(1) and Article 21 gives only an additional protection by prescribing the
procedure according to which that right may be taken away. I am unable to accept
this contention. If this argument were correct, then it would follow that our
Constitution does not guarantee to any person, citizen or non-citizen, the; freedom of
ins life as a substantive right at all, for the substantive right to life does not fall within
any of the sub-clauses of Clause (1) of Article 19.
He also said at p. 306-307 :
Article 21, as the marginal note states, guarantees to every person 'protection of life
and personal liberty'. As I read it, it defines the substantive fundamental right to
which protection is given and does not purport to prescribe any particular procedureAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

at all. That a person shall not be deprived of ins life or personal liberty except
according to procedure established by law is the substantive fundamental right to
which protection is given by the Constitution. The avowed object of the article, as I
apprehend it, is to define the ambit of the right to life and personal liberty which is to
be protected as a fundamental right. The right to life and personal liberty protected
by Article 21 is not an absolute right but is a qualified right--a right circumscribed by
the possibility or risk of being lost according to procedure established by law.
398. It will thus be seen that not only all steps leading up to the deprivation of
personal liberty but also the substantive right to personal freedom has been held, by
implication, to be covered by Article 21 of the Constitution.
399. In Kharak Singh v. the State of U.P. and Ors. , the wide import of personal
liberty, guaranteed by Article 21, was considered. By a majority of 4 against 2 learned
Judges of this Court, it was held that the term "personal liberty", as used in Article 21,
is a compendious one and includes all varieties of rights to exercise of personal
freedom, .other than those dealt with separately by Article 19, which could fall under
a broad concept of freedom of person. It was held to include freedom from
surveilance, from physical torture, and from all kinds of harassment of the person
which may interfere with ins liberty.
300. Thus, even if Article 21 is not the sole repository of all personal freedom, it will
be clear, from a reading of Gopalan's case (supra) and Kharak Singh's case (Supra),
that all aspects of freedom of person are meant to be covered by Articles 19 and 21
and 22 of the Constitution. If the enforcement of these rights by Courts is suspended
during the Emergency an inquiry by a Court into the question whether any of them is
violated by an illegal deprivation of it by executive authorities of the State seems
futile.
301. For the reasons indicated above I hold as follows :--
302. Firstly, fundamental rights are basic aspects of rights selected from what may
previously have been natural or common law rights. These basic aspects of rights are
elevated to a new level of importance by the Constitution. Any other co-extensive
rights, outside the Constitution, are necessarily excluded by their recognition as or
merger with fundamental rights.
303. Secondly, the object of making certain general aspects of rights fundamental is
to guarantee them against illegal, invasions of these rights by executive, legislative, or
judicial organs of the State. This necessarily means that these safeguards can also he
legally removed under appropriate constitutional or statutory provisions, although
their suspension does not, by itself, take away the illegalities or their legal
consequences.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

304. Thirdly, Article 21 of the Constitution has to be interpreted comprehensively
enough to include, together with Article 19, practically all aspects of personal
freedom. It embraces both procedural and substantive rights. Article 22 merely
makes it clear that deprivations of liberty by means of laws regulating preventive
detention would be included in "procedure established by law" and indicates what
that procedure should be. In that sense, it could be viewed as, substantially, an
elaboration of what is found in Article 21, although it also goes beyond it inasmuch as
it imposes limits on ordinary legislative power.
305. Fourthly, taken by itself, Article 21 of the Constitution is primarily a protection
against illegal deprivations by the executive action of the State's agents or officials,
although, read with other Articles, it could operate also as a protection against
unjustifiable legislative action purporting to authorise deprivations of personal
freedom.
306. Fifthly, the most important object of making certain basic rights fundamental by
the 'Constitution is to make them enforceable against the State and its agencies
through the Courts.
307. Sixthly, if the protection of enforceability is validly suspended for the duration of
an Emergency, declared under constitutional provisions, the Courts will have nothing
before them to enforce so as to be able to afford any relief to a person who comes with
a grievance before them.
(B) Power to issue writs of Habeas Corpus and oilier powers of High Courts under Article 226 of the
Constitution.
308. Reliance has been placed on behalf of the detenus on the following statement of the law found
in Halsbury's Laws of England (Vol. 11, p. 27, paragraph 15), where dealing with the jurisdiction to
issue such writs in England it is said :
The right to the writ is a right which exists at common law independently of any
statute, though the right has been confirmed and regulated by statute. At common
law the jurisdiction to award the writ) was exercised by the Court of Queen's Bench,
chancery, and Common Pleas, and, in a case of privilege, by the Court of Exchequer.
It is, therefore, submitted that the High Courts as well as this Court which have the
same jurisdiction to issue writs of Habeas Corpus as English Courts have to issue
such writs at common law.
309. The argument seems to me to be based on several misconceptions :
310. Firstly, there are no Courts of the King or Queen here to issue writs of Habeas Corpus by reason
of any "prerogative" of the Britisk Monarch. The nature of the writ of Habeas Corpus is given in theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

same volume of Halsbury's Laws of England, dealing with Crown proceedings, at page 24, as follows
:
40. The prerogative writ of habeas corpus. The writ of habeas corpus and
subjiciendum, which is commonly known as the writ of habeas corpus, is a
prerogative process for securing the liberty of the subject by affording an effective
means of immediate release from unlawful or unjustifiable detention, whether in
prison or in private custody. It is a prerogative writ by which the Queen has a right to
inquire into the causes for which any of her subjects are deprived of their liberty. By it
the High Court and the judges of that Court, at the instance of a subject aggrieved,
command the production of that subject, and inquire into the cause of ins
imprisonment. If there is no legal justification for the detention, the party is ordered
to be released. Release on habeas corpus is not, however, an acquittal, nor may the
writ be used as a means of appeal.
311. It will be seen that the Common Law power of issuing the writ of Habeas Corpus is possessed by
only certain courts which could issue "prerogative" writs. It is only to indicate the origin and nature
of the writ that the writ of habeas corpus is known here as a "prerogative" writ. The power to issue it
is of the same nature as a "prerogative" power inasmuch as the power, so long as it is not suspended,
may carry with it an undefined residue of discretionary power. Strictly speaking, it is a constitutional
writ. The power to issue it is conferred upon Courts in this country exclusively by our Constitution.
All the powers of our Courts flow from the Constitution which is the source of their jurisdiction. If
any provision of the Constitution authorises the suspension of the right to obtain relief in any type of
cases, the power of Courts is thereby curtailed even though a general jurisdiction to afford the relief
in other cases may be there. If they cannot issue writs of Habeas Corpus to enforce a right to
personal freedom against executive authorities during the Emergency, the original nature of this
writ issuing power-comparable to a "prerogative" power, cannot help the detenu.
312. Secondly, as I have already indicated, whatever could be formerly even said to be governed by a
Common Law prerogative power becomes merged in the Constitution as soon as the Constitution
takes it over and regulates that subject. This is a well recognised principle of law. I will only cite
Attorney-General v. De Keyser's Royal Hotel Limited [1920] A. C. 508 @ 526, where Lord Dunedin,
in answer to a claim of the Crown based on prerogative, said (at p. 526) ;
None the less, it is equally certain that if the whole ground of something which could be done by the
prerogative is covered by the statute, it is the statute that rules. On this point I think the observation
of the learned Master of the Rolls is unanswerable. He says : "What use could there be in imposing
limitations, if the Crown could at its pleasure disregard them and fall back on prerogative ?.
313. Thirdly, if there is no enforceable right either arising under the Constitution or otherwise, it is
useless to appeal to any general power of the Court to issue a writ of Habeas Corpus. The
jurisdiction to issue an order of release, on a Habeas Corpus petition, is only exercisable after due
enquiry into the cause of detention. If the effect of the suspension of the right to move the Court for
a writ of Habeas Corpus is that no enquiry can take place, beyond finding out that the cause is oneAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

covered by the prohibition, mere possession of some general power will not assist the detenu.
314. If the right to enforce personal freedom through a writ of habeas corpus is suspended, it cannot
be said that the enforcement can be restored by resorting to "any other purpose". That other
purpose could not embrace defeating the effect of suspension of the enforcement of a Constitutional
guarantee. To hold that would be to make a mockery of the Constitution.
315. Therefore, I am unable to hold that anything of the nature of a writ of habeas corpus or any
power of a High Court under Article 226 could come to the aid of a detenu when the right to enforce
a claim to personal freedom, sought to be protected by the Constitution, is suspended.
(C) The objects of the Maintenance of Internal Security Act the Act') and the amendments of it.
316. As this Court has recently held, in Haradhan Saha and Anr. v. The State of West Bengal and
Ors. preventive detention is to be differentiated from punitive detention. Nevertheless, it is evident,
whether detention is preventive or punitive, it necessarily results in the imposition of constraints,
which, from the point of view of justice to the detenu. should not be inflicted or continue without
fair and adequate and careful scrutiny into its necessity. This Court pointed out that Article 22 of the
Constitution was designed to guarantee these requirements of fairness and justice which are
satisfied by the provisions of the Act. It said in said Haradhan Saha and Anr. (supra) (at p. 784):
Constitution has conferred rights under Article 19 and also adopted preventive
detention to prevent the greater evil of elements imperiling the security, the safety of
a State and the welfare of the Nation. It is not possible to think that a person who is
detained will yet be free to move or assemble or form association or unions or have
the right to reside in any part of India or have the freedom of speech or expression.
317. Provision for preventive detention, in itself, is a departure from ordinary norms. It is generally
resorted to either in times of war or of apprehended internal disorders and disturbances of a serious
nature. Its object is to prevent a greater danger to national security and integrity than any claim;
which could be based upon a right, moral or legal, to individual liberty. It has been aptly described
as a "jurisdiction of suspicion." See : Khudiram Das v. State of West Bengal , State of Madras v. V. G.
Row A.I. R. 1952 S. C. 197 @ 200; R. v. Halliday [1917] A. C. 260 @ 275. It enables executive
authorities to proceed on bare suspicion which has to give rise to a "satisfaction", as the condition;
precedent to passing a valid detention order, laid down as follows in Section 3 of the Act :
3 (1) (a) if satisfied with respect to any person (including a foreigner) that with a view
to preventing him from acting in any manner prejudicial to--
(i) the defence of India, the relations of India with foreign powers, or the security of
India, or
(ii) the security of the State or the maintenance of public order, orAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

(iii) the maintenance of supplies and services essential to the community, or
(b) if satisfied with respect to any foreigner that with a view to regulating ins
continued presence in India or with a view to making arrangements for ins expulsion
from India. It is necessary so to do, make an order directing that such person is
detained.
318. The satisfaction, as held consistently by a whole line of authorities of this Court, is a
"subjective" one. In other words, it is not possible to prescribe objective standards for reaching that
satisfaction. Although the position in law, as declared repeatedly by this Court, has been very clear
and categorical that the satisfaction has to be the subjective satisfaction of the detaining authorities,
yet, the requirements for supply of grounds to the detenu, as provided in Section 8 of the Act in
actual practice, opened up a means of applying a kind of objective test by Courts upon close scrutiny
of these grounds. The result has, been, according to the Attorney General, that" the subjective
satisfaction of the detaining authorities has 'tended to be substituted by the subjective satisfaction of
Court on the objective data provided by the grounds, as to the need to detain for purposes of the Act.
The question thus arose : Did this practice not frustrate the purposes of the Act ?
319. The position of the detenu has generally evoked the sympathy of lawyers and law Courts,. They
cherish a tradition as zealous protectors of personal liberty. They are engaged in pointing out, day in
and day out, the essentials of fair trial. They are used to acting strictly on the rules of evidence
contained in the Indian Evidence Act. The possibility of indefinite incarceration, without anything
like a trial, not unnaturally, seems abhorrent to those with such traditions and habits of thought and
action.
320. There is an aspect which perhaps tends to be overlooked in considering matters which are
generally placed for weighment on the golden scales of the sensitive judicial balance. It is that we are
living in a world of such strain and stress, satirised in a recent fictional depiction of the coming
future, if not of a present already enveloping us. in Mr. Alva Toffler's "Future Shock", with such fast
changing conditions of life dominated by technological revolutions as well as recurring economic,
social, and political crises, with resulting obliterations of traditional values, that masses of people
suffer from psychological disturbances due to inability to adjust themselves to these changes and
crises. An example of such maladjustment is provided by what happened to a very great and gifted
nation within living memory. The great destruction, the inhuman butchery, and the acute suffering
and misery which many very civilised parts of the world had to pass through, because some
psychologically disturbed people led by Adolf Hitler, were not prevented in time from misleading
and misguiding the German nation, is still fresh in our minds. Indeed the whole world suffered, and
felt the effects of the unchecked aberrant Nazi movement in Germany and the havoc it unleashed
when it acquired a hold over the minds and feelings of the German people with all the vast powers of
modern science at their disposal. With such recent examples before them, it was not surprising that
our Constitution makers, quite far sightedly, provided not only for preventive detention in our
Constitution but also introduced Emergency provisions of a drastic nature in it. These seem to be
inescapable concomitants of conditions necessary to ensure for the mass of the people of a backward
country, a life of that discipline without which the country's security, integrity, independence, andAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

pace of progress towards the objectives set before us by the Constitution will not be safe.
321. I do not know whether it was a too liberal application of the principle that courts must lean in
favour of the liberty of the citizen, which is, strictly speaking, only a principle of interpretation for
cases of doubt or difficulty, or, the carelessness with which detentions were ordered by Subordinate
officers in the Districts, or the inefficiency in drafting of the grounds of detention, which were not
infrequently found to be vague and defective, the result of the practice developed by Courts was that
detenus did, in quite a number of cases, obtain from High Courts, and, perhaps even from this
Court, orders of release on Habeas Corpus petitions on grounds on which validity of criminal trials
would certainly not be affected.
322. In Prabhu Dayal Deorah etc etc. v. District Magistrate Kanirup and Ors. . I ventured, with great
respect, in my minority opinion, to suggest that the objects of the Act may be frustrated if Courts
interfere even before the machinery of redress under the Act through Advisory Boards, where
questions relating to vagueness or irrelevance or even sufficiency of grounds could be more
effectively thrashed out than in Courts in proceedings under Article 32 or 226 of the Constitution,
had been allowed to complete its full course of operation. In some cases, facts were investigated on
exchange of affidavits only so as to arrive at a conclusion that some of the facts, upon which
detention orders were passed, did not exist at all. In other cases, it was held that even if a single
non-existent or vague ground crept into the grounds for detention, the detention order itself was
vitiated as it indicated either the effects of extraneous matter or carelessness or non-application of
mind in making the order. Courts could not separate what has been improperly considered from
what was properly taken into account. Hence detentions were held to be vitiated by such defects. In
some cases, the fact that some matter too remote in time from the detention order was taken into
consideration, in ordering the detention, was held to be enough to invalidate the detention. Thus,
grounds supplied always operated as an objective test for determining the question whether a nexus
could reasonably exist between the grounds given and the detention order or whether some
infirmities had crept in. The reasonableness of the detention became the justiciable issue really
decided. With great respect, I doubt whether this could be said to be the object of preventive
detention provisions authorised by the Constitution and embothed in the Act. In any case, it was the
satisfaction of the Court by an application of a kind of objective test more stringently than the
principle of criminal procedure, that a defective charge could be amended and would not vitiate a
trial without proof of incurable prejudice to the accused, which became, for all practical purposes,
the test of the correctness of detention orders.
323. I have ventured to indicate the background which seems to me to have probably necessitated
certain amendments in the Act in addition to the reasons which led to the proclamation of
Emergency, the effects of which are considered a little later below. We are not concerned here with
the wisdom of the policy underlying the amendments. It is, however, necessary to understand the
mischief aimed at so as to be able to correctly determine the meaning of the changes made.
324. The Central Act 39 of 1975 which actually came into effect after Emergency added Section 16A
to the Act, to Sub-sections of which have been the subject matter of arguments before us. They read
as follows :Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

(2) The case of every person (including a foreigner) against whom an order of
detention was made under [this Act on or after the 25th day of June, 1975, but before
the commencement of this section, shall, unless such person is sooner released from
detention, be viewed within fifteen days from such commencement by the
appropriate Government for the purpose of determining whether the detention of
such person under this Act is necessary for dealing effectively with the emergency in
respect of which the Proclamations referred to in Sub-section (1) have been issued
(hereafter in this Section referred to as the emergency) and if, on such review, the
appropriate Government is satisfied that it is necessary to detain such person for
effectively dealing with the emergency, that Government may make a declaration to
that effect and communicate a copy of the declaration to the person concerned.
(3) When making an order of detention under this Act against any person (including
a foreigner) after the commencement of this section, the Central Government or the
State Government or, as the case may be, the officer making the order of detention
shall consider whether the detention of such person under this Act is necessary for
dealing effectively with the emergency and if, on such consideration, the Central
Government or the State Government or, as the case may be, the officer is satisfied
that it is necessary to detain such person for effectively dealing with the emergency,
that Government or officer may make a declaration to that effect and communicate a
copy of the declaration to the person concerned:
Provided that where such declaration is made by an officer it shall be reviewed by the
State Government to which such officer is subordinate within fifteen days from the
date of making of the declaration and such declaration shall cease to have effect
unless it is confirmed by the State Government, after such review, within the said
period of fifteen days.
325. Act No. 14 of 1976, which received the Presidential assent on 25th January, 1976, added
Section, 16A(9) which runs as follows :
16A(9) Notwithstanding anything contained in any other law or any rule having the
force of law,--
(a) the Grounds on which an order of detention is made or purported to be made
under Section 3 against any person in respect of whom a declaration is made under
Sub-section (2) or Sub-section (3) and any information or materials on which such
grounds or a declaration under Sub-section (2) or declaration or confirmation under
Sub-section (3) or the non-revocation under Sub-section (4) of a declaration are
based, shall be treated as confidential and shall be deemed to refer to matters of State
and to be against the public interest to disclose and save as otherwise provided in this
Act, on one shall communicate or disclose any such ground, information or material
or any document containing such ground, information or material;Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

(b) No person against whom an order of detention is made or purported to be made
under Section 3 shall be entitled to the communication or disclosure of any such
ground, information or material as is referred to in Clause (a) or the production to
him of any document containing such ground, information or material.
This Section and Section 18 of the Act are the only provisions whose validity is challenged before us.
326. It appears to me that the object of the above mentioned amendments was to affect the manner
in which jurisdiction of Courts in considering claims for relief's by detenus on petitions for writs of
Habeas Corpus was being exercised so that the only available means that had been developed for
such cases by the Courts, that is to say, the scrutiny of grounds supplied under Section 8 of the Act.,
may be removed from the judicial armory for the duration of the Emergency. It may be mentioned
here that Article 22(5) and 22(6) of the Constitution provided as follows :
22(5) When any person is detained in pursuance of the order made under any law
providing for preventive detention, the authority making the order shall, as soon as
may be, communicate to such person the grounds on which the order has been made
and shall afford him the earliest opportunity of making a representation against the
order.
22(6) Nothing in Clause (5) shall require the authority making any such order as is
referred to in that clause to disclose facts which such authority considers to be
against the public interest to disclose.
327. The first contention, that Section 16A(9) affects the jurisdiction of High Courts under Article
226, which an order under Article 359(1) could not do, appears to me to be untenable. I am unable
to see how a Presidential Order which prevents a claim for the en forcement of a fundamental right
from being advanced in a Court, during the existence of an Emergency, could possibly be said not to
be intended to affect the exercise of jurisdiction of Courts at all.
328. The second argument, that Section 16A(9) amounts to a general legislative declaration in place
of judicial decisions which Courts had themselves to give after considering, on the facts of each case,
whether Article 22(6) could be applied, also does not seem to me to be acceptable. The result of
Section 16A(9), if valid, would be to leave the presumption of correctness of an order under Section
3 of the Act, good on the face of it, untouched by any investigation relating to its correctness. Now, if
this be the object and effect of the amendment, it could not be said to go beyond making it
impossible for detenus to rebut a presumption of legality and validity which an order under Section
3 of the Act, if prima facie good, would raise in an event. The same result could have been achieved
by enacting that a detention order under Section 3, prima facie good, will operate as "conclusive
proof" that the requirements of Section 3 have been fulfilled. But, as the giving of grounds is not
entirely dispensed with under the Act even as it now exists this may have left the question in doubt
whether Courts could call upon the detaining authorities to produce the grounds. Enactment of a
rule of conclusive proof is a well established form of enactments determining substantive rights in
the form of procedural provisions.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

329. In any case, so far as the rights of a detenu to obtain relief are hampered, the question raised
touches the enforcement of the fundamental right to personal freedom. Its effect upon the powers of
the Court under Article 226 is, as I have already indicated, covered by the language of Article 359(1)
of the Constitution. It is not necessary for me to consider the validity of such a provision if it was to
be applied at a time not covered by the Emergency, or whether it should be read down for the
purposes of a suit for damages where the issue is whether the detention was ordered by a particular
officer out of "malice in fact" and for reasons completely outside the purview of the Act itself. That
sort of inquiry is not open, during the Emergency, in proceedings under Article 226.
330. On the view I take, for reasons which will be still clearer after a consideration of the remaining
questions discussed below., I think that, even the issue that the detention order is vitiated by "malice
in fact" will not be justiciable in Habeas Corpus proceedings during the Emergency although it may
be in an ordinary suit which is not filed for enforcing a fundamental right but for other relief's. The
question of bona fides seems to be left open for decision by such suits on the language of Section 16
of the Act itself which says :
16. No suit or other legal proceedings shall lie against the Central Government or a
State Government, and no suit, prosecution or other legal proceedings shall lie
against any person, for anything in good faith done or intended to be done in
pursuance of this Act.
331. Section 16 of the Act seems to leave open a remedy by way of suit for damages for wrongful
imprisonment in a possible case of what may be called "malice in fact". In the cases before us, we are
only concerned with Habeas Corpus proceedings under Article 226 of the Constitution where in my
opinion, malice in fact could not be investigated as it is bound to be an allegation subsidiary to a
claim for the enforcement of a right to personal liberty, a fundamental right which cannot be
enforced during the Emergency.
332. In Sree Mohan Chowdhury v. The Chief Commissioner, Union Territory of Tripura [1964] 3 S.
C. R- 442 at 450, a Constitution Bench of this Court, after pointing out that Article 32(4)
contemplated a suspension of the guaranteed right only as provided by the Constitution, said (at p.
450-451) :
The order of the President dated November 3, 1962, already set out, in terms,
suspends the right of any person to move any Count for the enforcement of the rights
conferred by Articles 21 and 22 of the Constitution, during the period of Emergency.
Prima facie, therefore, the petitioner's right to move this Court for a writ of Habeas
Corpus,, as he has purported to do by this petition, will remain suspended during the
period of the Emergency. But even then it has been contended on behalf of the
petitioner that Article 359 does not authorise the suspension of the exercise of the
right guaranteed under Article 32 of the Constitution and that, in terms, the
operation of Article 32 has not been suspended by the President. This contention is
wholly unfounded. Unquestionably, the Court's power to issue a writ in the nature of
habeas corpus has not been touched by the President's Order, but the petitioner'sAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

right to move this Court for a writ of that kind has been suspended by the Order of
the President passed under Article 359(1). The President's Order does not suspend all
the rights vested in a citizen to move this Court but only ins right to enforce the
provisions of Articles 21 and 22. Thus, as a result of the President's Order aforesaid,
the petitioner's right to move this Court, but not this Court's power under Article 32,
has been suspended during the operation of the Emergency, with the result that the
petitioner has no locus standi to enforce ins right, if any, during the Emergency.
333. It is true that the Presidential Order of 1975, like the Presidential Order of 1962, does not
suspend the general power of this Court under Article 32 or the general powers of High Courts
under Article 226, but the effect of taking away enforceability of the right of a detenu to personal
freedom against executive authorities is to affect the locus standi in cases which are meant to be
covered by the Presidential Order. Courts, even in Habeas Corpus proceedings, do not grant relief
independently of rights of the person deprived of liberty. If the locus standi of a detenu is suspended
no one can claim,, on ins behalf, to get ins right enforced. The result is to affect the powers of Courts,
even if this be an indirect result confined to a class of cases, but, as the general power to issue writs
of Habeas Corpus is not suspended, this feature was, quite rightly, I respectfully think, pointed out
by this Court in Mohan Chowdhury's case (supra). It would not be correct to go further and read
more into the passage cited above than seems intended to have been laid down there. The passage
seems to me to indicate quite explicitly, as the language of Article 359(1) itself shows., that the
detenu's right to move the Courts for the enforcement of ins right to personal freedom, by proving
an illegal deprivation of it by executive authorities of the State, is certainly not there for the duration
of the Emergency. And, to the extent that Courts do not, and, indeed, cannot reasonably, act without
giving the detenu some kind of a right or locus standi, their power to proceed with a Habeas petition
against executive authorities of the State is itself impaired. It may be that, in form and even in
substance., a general power to issue writs of Habeas Corpus, remains with Courts. But, that could
only be invoked in cases falling entirely outside the purview of; the Presidential Order and Article
359(1). That is how I, with great respect, understand the effect of Sree Mohan Chowdhury's case
(supra).
334. It is possible that, if a case so patently gross and clear of a detention falling, on the face of the
order of detention or the return made to a notice from the Court outside the provisions of the Act on
the ground of personal malice of the detaining authority, or, some other ground utterly outside the
Act, arises so that no further investigation is called for, it may be possible to contend that it is not
protected by the Presidential Order of 27th June, 1975, and by the provisions of Article 359(1) of the
Constitution at all. If that could be patent, without any real investigation or inquiry at all, it may
stand on the same footing as an illegal detention by a private individual. The mere presence of an
official seal or signature on a detention order, in such a purely hypothetical case, may not be enough
to convert it into a detention by the State or its agents or officers. That is the almost utterly
inconceivable situation or type of case which could still be covered by the general power to issue
writs of Habeas Corpus. There may, for example, be a case of a fabricated order of detention which,
the alleged detaining officer, on receipt of notice, disclaims. It is admitted that Part III of the
Constitution is only meant to protect citizens against illegal actions of organs of the State and not
against wrongs done by individuals. The remedy by way of a writ of Habeas Corpus is more general.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

It lies even against illegal detentions by private persons although not under Article 32 which is
confined to enforcement of fundamental rights (Vide : Shrimati Vidya Verma through next friend R.
V. S. Mani, v. Dr. Shiv Narain . The Attorney General also concedes that judicial proceedings for trial
of accused persons would fall outside the interdict of the Presidential Order under Article 359(1).
Therefore, it is unnecessary to consider hypothetical cases of illegal convictions where remethes
under the ordinary law are not suspended.
335. Now, is it at all reasonably conceivable that a detention order would, on the face of it, state that
it is not for one of the purposes for which it can be made under the Act or that it is made due to
personal malice or animus of the officer making it ? Can we, for a moment, believe that a return
made on behalf of the State, instead of adopting a detention order, made by an officer duly
authorised to act, even if there be a technical flaw in it, admit that it falls outside the Act or was
made mala fide and yet the State is keeping the petitioner in detention ? Can one reasonably
conceive of a case in which, on a Habeas Corpus petition, a bare look at the detention order or on the
return made, the Court could hold that the detention by a duly authorised officer under a duly
authenticated order, stands on the same footing as a detention by a private person? I would not like
to consider purely hypothetical, possibly even fantastically imaginary, cases lest we are asked to act,
as we have practically been asked to, on the assumption that reality is stranger than fiction., and that
because, according to the practice of determining validity of detention orders by the contents of
grounds served, a number of detentions were found, in the past, to be vitiated, we should not
presume that executive officers will act according to law.
336. Courts must presume that executive authorities are acting in conformity with both the spirit
and the substance of the law : "Omina praesumutur rite esse acts", which means that all official acts
are presumed to have been rightly and regularly done. If the burden to displace that presumption is
upon the detenu, he cannot, on a Habeas Corpus petition under Article 226 of the Constitution., ask
the Court to embark upon an inquiry, during the Emergency, to allow him to rebut this
presumption. To do so would, in my opinion, be plainly to countenance a violation of the
Constitution.
337. A great deal of reliance was placed on, behalf of the detenus, on the principle stated by the Privy
Council in Eshuqbayi Eleko v. Officer Administering the Government of Nigeria and Anr. [1931] A.C.
662 @ 670 where Lord Aktin said (at p. 670) :
Their Lordships are satisfied that the opinion which has prevailed that the Courts
cannot investigate the whole of the necessary conditions is erroneous. The Governor
acting under the Ordinance acts solely under executive powers, and in no sense as a
Court. As the executive he can only act in pursuance of the powers given to him by
law. In accordance with British jurisprudence no member of the executive can
interfere with the liberty or property of a British subject except on the condition that
he can support the legality of ins action before a court of justice. And it is the
tradition of British justice that judges should not shrink from deciding such issues in
the face of the executive. The analogy of the powers of the English Home Secretary to
deport alienee was invoked in this case. The analogy seems very close. TheirAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Lordships entertain no doubt that under the legislation in question, if the Home
Secretary deported a British subject in the belief that he was an alien,, the subject
would have the right to question the validity of any detention under such order by
proceedings in habeas corpus, and that it would be the duty of the Courts to
investigate the issue of alien or not.
338. The salutary general principle, enunciated above, is available, no doubt, to citizens of this
country as well in normal times. But it was certainly not meant to so operate as to make the
executive answerable for all its actions to the Judicature despite the special provisions for preventive
detention in an Act intended to safeguard the security of the nation, and, muchless, during an
Emergency., when the right to move Courts for enforcing fundamental rights is itself suspended.
Principles applicable when provisions, such as those which the Act contains, and a suspension of the
right to move Courts for fundamental rights, during an Emergency, are operative, were thus
indicated, in Liversidge v. Sir John Anderson and Anr. [1942] A. C. p. 206 @ 217 & 219 & 273 by
Viscount Maughan (at p. 219) :
There can plainly be no presumption applicable to a regulation made under this
extraordinary power that the liberty of the person in question will not be interfered
with, and equally no presumption that the detention must not be made to depend (as
the terms of the Act indeed suggest) on the unchallengeable opinion of the Secretary
of State.
Following the ratio decidendi of Rex v. Secretary of State for Home Affairs, Ex parte
Lees [1941] 1 K. B. 72, the learned Law Lord said (at p. 217).
As 1 understand the judgment in the Lees case it negatived the idea that the court had
any power to inquire into the grounds for the belief of the Secretary of State (his good
faith not being impugned) or to consider whether there were grounds on which he
could reasonably arrive at his belief.
In Liversidge's case (supra), the Court's power to inquire into the correctness of the
belief of the Secretary of State was itself held to be barred merely by the terms of a
Regulation made under a statute without even a constitutional suspension of the
right to move Courts such as the one we have before us.
339. In Liversidge's case (supra), Lord Wright explained Eshuqbayi Elekos' case (supra), cited
before their Lordships., as follows: (at p. 273) :
The other matter for comment is the decision in Eshuqbayi Eleko v. Officer
Administering the Government of Nigeria (1931) (A.C. 662), where the government
claimed to exercise certain powers, including deportation, against the appellant. The
appellant applied for a writ of habeas corpus, on the ground that the ordinance relied
on gave by express terms the powers it contained only against one who was a native
chief, and who had been deposed, and where there was a native custom requiring himAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

to leave the area, whereas actually not one of these facts was present in the case. It
was held in effect that the powers given by the ordinance were limited to a case in
which these facts existed. It was a question of the extent of the authority given by the
ordinance. That depended on specific facts., capable of proof or disproof in a court of
law, and unless these facts existed, there was no room for executive discretion. This
authority has, in my opinion, no bearing in the present case, as I construe the powers
and duties given by the regulation. There are also obvious differences between the
ordinary administrative ordinance there in question and an emergency power created
to meet the necessities of the war and limited in its operation to the period of the war.
The powers cease with the emergency. But that period still continues and, it being
assumed that the onus is on the respondents in this action of unlawful imprisonment,
the onus is sufficiently discharged, in my opinion, by the fact of the order having been
made by a competent authority within the ambit of the powers entrusted to him and
being regular on its face.
340. Viscount Maugham, in Greene v. Secretary of State for Home Affairs [1942] A.C. 284 @ 293,
after referring to a very comprehensive opinion of Wilmot C. J. on the nature of Habeas Corpus
proceedings in Common Law, pointed out that a return, good on its face and with no affidavit in
support of it, could not be disputed on the application for a writ. At Common Law, the "sacred"
character of the return, as Wilmot C. J. called it, even without a supporting affidavit, could not be
touched except by the consent of the parties", because the whole object of the writ was to enquire
into the existence of a legally recognised cause of detention, in a summary fashion, and not into the
truth of facts constituting the cause. By the Habeas Corpus Act of 1816, the powers of Courts were
extended so that it became possible to go behind the return in suitable cases other than those where
a person was confined for certain excepted matters including criminal charges. In these excepted
matters the return was and is still conclusive so that English Courts do not go behind them. In
Greene's case, (supra), the rule of presumptive correctness of the return was applied to the return
made on behalf of the Secretary of State to the extent of treating it as practically conclusive. It was
held that the mere production of the Home Secretary's order, the authenticity and good faith of
which were not impugned, constituted a complete answer to an application for a writ of Habeas
Corpus and that it was not necessary for the Home Secretary to file an affidavit. It is interesting to
note that, in that case, which arose during the Emergency following the war of 1939, the failure of
the Advisory Committee to supply the correct reasons for ins detention to the petitioner were not
held to be sufficient to invalidate ins incarceration. On the other hand, in this country., a violation of
the obligation to supply grounds of detention has been consistently held to be sufficient to invalidate
a detention before the changes in the Act and the Presidential Order of 1975.
341. By Section 7 of the Act 39 of 1975, Section 18 was added to the Act with effect from 25th June,
1975. This provision reads :
18, No person (including a foreigner) detained under this Act shall have any right to
personal liberty by virtue of natural law or common law, if any.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

In view of what I have pointed out earlier, this provision was not \ necessary. It
appears to have been added by way of abundant caution.
342. By Section 5 of the amendment Act 14 of 1976 another amendment was made in Section 18,
substituting, for the words "under this Act" used in Section 18, the words "in respect of whom an
order is made or purported to have been made under Section 3", retrospectively from 25th day of
June, 1975.
343. These amendments are covered by Article 359 (1A) of the Constitution., so that their validity is
unassailable during the Emergency on the ground of violation of any right conferred by Part III of
the Constitution. Nevertheless, the validity of Section 18 of the Act, as it stands, was challenged on
the ground, as I understand it, that, what is described as "the basic structure'' of the Constitution
was violated because, it was submitted, the Rule of Law, which is a part of the "basic structure" was
infringed by the amended provisions. As I have indicated below., I am unable to subscribe to the
view that the theory of basic structure amounts to anything more than a mode of interpreting the
Constitution. It cannot imply new tests outside the Constitution or be used to defeat Constitutional
provisions. I am unable to see any force in the attack on the validity of Section 18 of the Act on this
ground.
344. The result of the amendments of the Act, together with the emergency provisions and the
Presidential Order of 27th June, 1975, in my opinion, is clearly that the jurisdiction of High Courts is
itself affected and they cannot go beyond looking at the prima facie validity of the return made. The
production of a duly authenticated order, purporting to have been made by an officer competent to
make it under Section 3 of the Act, is an absolute bar to proceeding further with the hearing of a
Habes Corpus .petition.
(D) The purpose and meaning of Emergency provisions, particularly Article 359 of our Constitution.
345. From the inception of our Constitution, it was evident that the framers of it meant to establish a
secular democratic system of Government with certain objectives before it without which real
democracy is a mirage. Hence, they provided us not only with an inspiring Preamble to the,
Constitution and basic Fundamental Rights to citizens, but also with Directive Principles of State
Policy so as to indicate how not only a political, but, what is more important, social and economic
democracy, with maximum practicable equality of status and opportunity, could be attained. They
foresaw that it may be necessary, for preserving the system thus set up and for ensuring a rapid
enough march towards the objectives placed before the people of India, to give the executive branch
of Government wide powers, in exceptional situations, so that it may deal with all kinds of
emergencies effectively, and, thereby, safeguard the foundations of good Government which lie in
discipline and orderliness combined with speedy and substantial justice. The late Prime Minister
Jawaharlal Nehru once said : "You may define democracy in a hundred ways, but surely one of its
definitions is self-discipline; of the community. The more the self-discipline, the less the imposed
discipline".Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

346. Laws and law Courts are only a part of a system of that imposed discipline which has to take its
course when self-discipline fails. Conditions may supervene, in the life of a nation, in which the
basic values we have stood for and struggled to attain, the security, integrity, and independence of
the country, or the very conditions on which existence of law and order and of law courts depend,
may be imperilled by forces operating from within or from outside the country. _ What these forces
are, how they are operating, what information exists for the involvement of various individuals,
wherever placed, could not possibly be disclosed publicly or become matters suitable for inquiry into
or discussion in a Court of Law.
347. In Liversidge v. Sir John Anderson (supra) the following passages from Rex v. Halliday [1917]
A.C. 260 @ p. 271, 269, were cited by Lord Romer to justify principles adopted by four out five of
their Lordships in Liversidges case in their judgments : (1) Per Lord Atkins (at p. 271) :
However precious the personal liberty of the subject may be, there is something for
which it may well be, to some extent sacrificed by legal enactment, namely, national
success in the war, of escape from national plunder or enslavement'.
(2) Per Lord Finlay, L.C. (at p. 269).
It seems obvious that no tribunal for investigating the question whether circumstances of suspicion
exist warranting some restraint can be imagined less appropriate than a Court of law.
After citing the two passages quoted above, Lord Romer observed, in Liversidge''s case (supra) (at p.
281):
I respectfully agree. I cannot believe that the legislature or the framers of the
regulation ever intended to constitute the courts of this country the ultimate judges of
the matters in question.
348. If, as indicated above, the opinion of the overwhelming majority of the Law Lords of England,,
in Liversidge's case (supra), following the principles laid down earlier also in Rex. v. Halliday Ex
Pane Zadig's (supra), was that the jurisdiction of Courts is itself ousted by a statutory rule vesting
the power of detention on a subjective satisfaction, based possibly on nothing more than a detenu's
descent from or relationship or friendship with nationals of a country with which England may be at
war, and that the Secretary of State's order indicating that he was satisfied about one of these
matters, on hearsay information which could not be divulged in courts, in the interests of national
safety and security, was enough, I do not think that either our Constitution in contemplating an
ouster of jurisdiction of Courts in such cases, or our parliament, in enacting provisions which have
that effect, was going beyond the limits of recognised democratic principles as they operate during
emergencies. In fact, decisions on what restraints should be put and on which persons., during a
national emergency, in the interests of national security, are matters of policy as explained below,
which are outside the sphere of judicial determination.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

349. Situations of a kind which could not even be thought of in England are not beyond the range of
possibility in Asian and African countries or even in Continental Europe or in America judging from
events of our own times. Indeed, we too have had our fill of grim tragethes, including the
assassination of the father of the nation, which could rock the whole nation and propel it towards
the brink of an unfathomable abyss and the irreparable disaster which anarchy involves.
350. Let me glance at the Constitutional History of England from where we took the writ of Habeas
Corpus.
351. Sir Erskine May wrote (See : Constitutional History of Eneland, Chapter XI) : "
The writ of habeas corpus is unquestionably the first security of civil liberty. It brings
to light the cause of every imprisonment, approves its lawfulness., or liberates the
prinsoner. It exacts obedience from the highest courts : Parliament itself submits to
its authority. No right is more justly valued. It protects the subject from unfounded
suspicions, from the aggressions of power, and from abuses in the administration of
justice. Yet, this protective law, which gives every man security and confidence, in
times of tranquility, has been suspended, again and again, in periods of public danger
or apprehension. Rarely, however, has this been suffered without jealousy, hesitation,
and remonstrance; and whenever the perils of the State have been held sufficient to
warrant this sacrifice of personal liberty, no Minister or magistrate has been suffered
to tamper with the law at ins discretion. Parliament alone, convinced of the exigency
of each occasion, has suspended, for a time, the right of individuals, in the interests of
the State.
The first years after the Revolution were full of danger. A dethroned king, aided by
foreign enemies., and a powerful body of English adherents, was threatening the new
settlement of the Crown with war and treason. Hence, the liberties of Englishmen, so
recently assured, were several times made to yield to the exigencies of the State.
Again, on occasions of no less peril--the rebellion of 1715. the Jacobite conspiracy of
1722, and the invasion of the realm by the Pretender in 1745--the Habeas Corpus Act
was suspended. Henceforth, for nearly half a century, the law remained inviolate.
During the American War, indeed, it had been necessary to empower the king to
secure persons suspected of high treason, committed in North America, or on the
high seas, or of the crime of piracy : but it was not until 1794 that the civil liberties of
Englishmen at home were again to be suspended. The dangers and alarms of that
dark period have already been recounted. Ministers, believing the State to be
threatened by traitorous conspiracies, once more sought power to countermine
treason by powers beyond the law.
Relying upon the report of a secret committee, Mr. Pitt moved 'for a bill to empower
ins Majesty to secure and detain persons suspected of conspiring against ins person
and Government. He justified this measure on the ground that whatever the
temporary danger of placing such power in the hands of the Government,, it was farAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

less than the danger with which the Constitution and society were threatened. If
Ministers abused the power entrusted to them, they would be responsible for its
abuse. It was vigorously opposed by Mr. Fox, Mr. Grey, Mr. Sheridan, and a small
body of adherents. They denied the disaffection imputed to the people, ridiculed the
revelations of the committee, and declared that no such dangers threatened the State
as would justify the surrender of the chief safeguard of personal freedom. This
measure would give Ministers absolute power over every individual in the kingdom.
It would empower them to arrest, on suspicion, any maa whose opinions were
abnoxious to them--the advocates of reform., even the members of the Parliamentary
Opposition. Who would be safe, when conspiracies were everywhere suspected, and
constitutional objects and language believed to be the mere cloak of sedition? Let
every man charged with treason be brought to justice; in the words of Sheridan,
'where there was guilt, let the broad axe fall, but why surrender the liberties of the
innocent ?
The strongest opponents of the measure, while denying its present necessity,
admitted that when danger is imminent, the liberty of the subject must be sacrificed
to the paramount interests of the State. Ring leaders must be seized, outrages
anticipated, plots disconcerted, and the dark haunts of conspiracy filled with distrust
and terror. And terrible indeed was the power now entrusted to the executive.
Though termed a suspension of the Habeas Corups Act, it was, in truth, a suspension
of Magna Charta, and of the cardinal principles of the common law. Every man had
hitherto been free from imprisonment until charged with crime, by information upon
oath, and entitled to a speedy trial; and the judgment of ins peers. But any subject
could now be arrested on suspicion of treasonable practices, without specific charge
or proof of guilt, ins accusers were unknown; and in vain might he demand public
accusation and trial. Spies and treacherous accomplices., however circumstantial in
their narratives to Secretaries of State and law officers, shrank from the witness-box;
and their victims rotted in gaol. Whatever the judgment, temper, and good faith of
the executive, such a power was arbitrary, and could scarcely fail to be abused.
Whatever the danger by which it was justified, never did the subject; so much need
the protection of the laws, as when Government and society were filled with
suspicions and alarm.
352. It was not until 1801 that the Act was considered "no longer defensible on grounds of public
danger" and Lord Thurlow announced that he could "not resist the impulse to deem, men innocent
until tried and convicted". It was urged in defence of a Bill indemnifying all those who may have
misused or exceeded their powers during the period of suspension of the Habeas Corpus in England
that, unless it was passed, "those channels of information would be stopped on which Government
relied for guarding the public peace". Hence,, a curtain was drawn to shield all whose acts could
have been characterised as abuse or excess of power.
353. It is unnecessary to cite from Dicey or modern writers of British Constitutional Law, such as
M/s. Wade and Phillips, to show how, in times of emergency, the ordinary functions of Courts, and,Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

in particular, powers of issuing writs of Habeas Corpus, have been curtailed. In such periods,
legislative measures known as "suspension of the Habeas Corpus Act", followed by Acts oE
Indemnity, after periods of emergency are over, have been restored to in England. But, during the
first world war of 1914 and the last world war of 1939, it was not even necessary to suspend the
Habeas Corpus Act in England. The Courts themselves, on an interpretation of the relevant
regulations under the Defence of Realm Act, abstained from judicial interference by denying
themselves power to interfere.
354. In Halsbitry's Laws of England (4th Edn. Vol. 8, para 871, page 624), we find the following
statement about the Crown's Common Law prerogative power in an Emergency :
The Crown has the same power as a private individual of taking all measures which
are absolutely and immediately necessary for the purpose of dealing with an invasion
or other emergency.
And, as regards statutory powers of the Crown (See : Emergency Powers Act., 1920,
Sec. 1; Emergency Powers Act, 1964, Sec 1), we find (see para 983, page 627) :
If it appears to Her Majesty that events of a specified nature have occurred or are
about to occur, Her Majesty may by proclamation declare that a state of emergency
exists. These events are those of such a nature as to be calculated, by interfering with
the supply and distribution of food, water, fuel or light, or with the means of
locomotion, to deprive the community, or any substantial portion of the community,
of the essentials of life. No proclamation is to be in force for more than one month.,
without prejudice to the issue of another proclamation at or before the end of that
period.
XXX XXX XXX XXX Where a proclamation of emergency has been made, and so
long as it remains in force, the Crown has power by Order in Council to make
regulations for securing the essentials of life to the Community.
355. In America also, the suspension of the right to writs of Habeas Corpus, during emergencies, so
as to temporarily remove the regular processes of law, is permissible by legislation (See : Cooky's
Constitutional Lanv", 4th Edn. Chapter 34, p. 360), but it is limited by (Article 1., Sec. 9, clause 2)
the American Constitution to situations in which there may be a rebellion or an invasion (See :
Willis on "Constitutional Law of United States", 1936 edn. p. 441 and p.- 5/0). Even more drastic
consequences flow from what is known in France as declaration of a '"State of Seige", and, in other
countries, as a "Suspension of Constitutional Guarantees.
356. Under our Constitution, it will be seen, from an analysis of emergency provisions, that there is
no distinction between the effects of a declaration of Emergency, under Article 352(1), whether the
threat to the security of the State is from internal or external sources. Unlike some other countries,
powers of Presidential declarations under Article 352(1) and 359(1) of our Constitution are immune
from challenge in Courts even when the Emergency is over.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

357. Another noticeable feature of our Constitution is that, whereas the consequences given in
Article 358, as a result of a Proclamation under Article 352 (1), are automatic, Presidential Orders
under Article 359(1) may have differing consequences, from emergency to emergency, depending
upon the terms of the Presidential Orders involved. And then, Article 359 (1A), made operative
retrospectively by the 38th Constitutional amendment, of 1st August, 1975, makes it clear that both
the Legislative and Executive Organs of the State, are freed, for the duration of the Emergency, from
the limits imposed by Part III of the Constitution.
358. It is unnecessary to refer to the provisions of Articles 356 and 357 except to illustrate the
extremely wide character of Emergency powers of the Union Govt. which can, by recourse to these
powers, make immune from judicial review, suspend the federal features of our Constitution which
have, sometimes, been elevated to the basic level. These provisions enable the Union Govt. to
supersede both the legislative and executive wings of Government in a State in the event of a failure
of Constitutional machinery in that State, and to administer it through any person or body of
persons under Presidential directions with powers of the State Legislature "exercisable by or under
the authority of Parliament". Article 360, applicable only to Proclamations of financial emergencies,
with their special consequences, indicates the very comprehensive character of the Emergency
provisions contained in part XVIII of our Constitution. We are really directly concerned only with
Articles 352 and 353 and 358 and 359 as they now stand. They are reproduced below :
352. (1) If the President is satisfied that a grave emergency exists whereby the
security of India or of any part of the territory thereof is threatened, whether by war
or external aggression or internal disturbance, he may, by Proclamation make a
declaration to that effect.
(2) A Proclamation issued under Clause (1)-
(a) may be revoked by a subsequent Proclamation;
(b) shall be laid before each House of Parliament;
(c) shall cease to operate at the expiration of two months unless before the expiration of that period
it has been approved by resolution of both Houses of Parliament :
Provided that if any such Proclamation is issued at a time when the House of the
People has been dissolved or the dissolution of the House of the People takes place
during the period of two months referred to in sub-Clause (c), and if a resolution
approving the Proclamation has been passed by the Council of States, but no
resolution with respect to such Proclamation has been passed by the House of the
People before the expiration of that period, the Proclamation shall cease to operate at
the expiration of thirty days from the date on which the House of the People first sits
after its reconstitution unless before the expiration of the said period of thirty days a
resolution approving the Proclamation has been also passed by the House of the
People.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

(3) A Proclamation of Emergency declaring that the security of India or of any part of
the territory thereof is threatened by war or by external aggression or by internal
disturbance may be made before the actual occurrence of war or of any such
aggression or disturbance if the President is satisfied that there is imminent danger
thereof.
(4) The power conferred on the President by this Article shall include the power to
issue different Proclamations on different grounds, being war or external aggression
or internal disturbance or imminent danger of war or external aggression or internal
disturbance, whether or not there is a Proclamation already issued by the President
under Clause (1) and such Proclamation is in operation.
(5) Notwithstanding anything in this Constitution,--
(a) the satisfaction of the President mentioned in Clause (1) and Clause (3) shall be
final and conclusive and shall not be questioned in any court on any ground;
(b) subject to the provisions of Clause (2), neither the Supreme Court nor any other
court shall have jurisdiction to entertain any question, on any ground, regarding the
validity of--
(i) a declaration made by Proclamation by the President to the effect stated in Clause
(1); or
(ii) the continued operation of such Proclamation.
353. While a Proclamation of Emergency is in operation, then--
(a) notwithstanding anything in this Constitution, the executive power of the Union shall extend to
the giving of directions to any State as to the manner in which the executive power thereof is to be
exercised;
(b) the power of Parliament to make laws with respect to any matter shall include power to make
laws conferring powers and imposing duties, or authorising the conferring of powers and the
imposition of duties, upon the Union or officers and authorities of the Union as respects that matter,
notwithstanding that it is one which is not enumerated in the Union List.
358. While a Proclamation of Emergency is in operation, nothing in Article 19 shall restrict the
power of the State as defined in Part III to make any law or to take any executive action which the
State would but for the provisions contained in that part be competent to make or to take, but any
law so made shall, to the extent of the in competency, cease to have effect as soon as the
Proclamation ceases to operate, except as respects things done or omitted to be done before the law
so ceases to have effect.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

359 (1) Where a Proclamation of Emergency is in operation, the President may by order declare that
the right to move any court for the enforcement of such of the rights conferred by Part III as may be
mentioned in the order and all proceedings pending in any court for the enforcement of the rights so
mentioned shall remain suspended for the period during which the Proclamation is in force or for
such shorter period as may be specified in the order.
(1A) While an order made under Clause (1) mentioning any of the rights conferred by Part III is in
operation, nothing in that Part conferring those rights shall restrict the power of the State as defined
in the said Part to make any law or to take any executive action which the State would but for the
provisions contained in that Part be competent to make or to take, but any law so made shall, to the
extent of the incompetency, cease to have effect as soon as the order aforesaid ceases to operate,
except as respects things done or omitted to be done before' the law so ceases to have effect.
(2) An order made as aforesaid may extend to the whole or any part of the territory of India.
(3) Every order made under Clause (1) shall, as soon as may be after it is made, be laid before each
House of Parliament.
359. Before dealing with relevant authorities on the meaning and effects of Article 358 and 359 of
the Constitution, I will indicate the special features and context of the Presidential Order of 27th
June, 1975, as compared with the Presidential Order of 3rd November, 1962. which was the subject
matter of earlier pronouncement of this Court on which considerable reliance has been placed on
behalf of the detenus. In fact, the next two topics are so connected with the Emergency provisions
that there is bound to be a good deal of overlapping between what I have, for the sake of
convenience only, tried to discuss under three heads. Different heads or names are not infrequently
used only to indicate different aspects of what is really one connected subject matter. Perhaps the
last and concluding topic is wide enough to cover the scope of the whole discussion.
360. E. The effect of the Presidential Orders and particularly the order of 21st June, 1975, on the
rights of detenus.
361. The Presidential Order of 3rd November 1962 was issued after the proclamation of Emergency
under Article 352(1) on 26th October, 1962. That proclamation said :
...a grave emergency exists whereby the security of India is threatened by external
aggression.
On the other hand, the Presidential Order of 27th June, 1975, with which we are
concerned here was issued under a proclamation which declares "that a grave
emergency exists whereby the security of India is threatened by internal
disturbances".
362. There was also a Presidential proclamation of 3rd December, 1971, repeating the terms of the
proclamation of 26th October, 1962, as under:Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

In exercise of the powers conferred by Clause (1) of Article 352 of the Constitution, I,
V. V. Giri, President of India, by this Proclamation declare that a grave emergency
exists whereby the security of India is threatened by external aggression.
363. The Presidential Order of 3rd November, 1962, reads as follows :
In exercise of the powers conferred by Clause (1) of Article 359 of the Constitution,
the President hereby declares that the right of any person to move any court for the
enforcement of the rights conferred by Article 21 and Article 22 of the Constitution
shall remain suspended for the period daring which the Proclamation of Emergency
issued under Clause (1) of Article 352 thereof on the 26th October, 1962 is in force, if
such person has been deprived of any such rights under the Defence of India
Ordinance, 1962 (4 of 1962) or ally rule or order made thereunder.
364. The Presidential Order of 27th June, 1975, runs as follows :
In exercise of the powers conferred by Clause (1) of Article 359 of the Constitution,
the; President hereby declares that the right of any person (including a foreigner) to
move any Court for the enforcement of the rights conferred by Article 14, Article 21
and Article 22 of the Constitution and all proceedings pending in any court for the
enforcement of the abovementioned rights shall remain suspended for the period
daring which the Proclamations of Emergency made under Clause (1) of Article 352
of the Constitution on the 3rd December, 1971 and on the 25th June, 1975 are both in
force.
(2) This Order shall extend to the whole of the territory of India except the State of
Jammu and Kashmir.
(3) This Order shall be in addition to and not in derogation of any order made before
the date of this Order under Clause (1) of Article 359 of the Constitution.
365. The striking differences in the terms of the two Presidential Orders set out above are :
(1) The Presidential Order of 1962 did not specify Article 14 of the Constitution, but
Article 14, guaranteeing equality before the law and equal protection of laws to all
persons in India, is mentioned in the 1975 order. To my mind, this does make some
difference between the intentions behind and effects of the two Presidential Orders.
(2) The Presidential Order of 1962 expressly hedges the suspension of the specified
fundamental rights with the condition, with regard to deprivations covered by
Articles 21 and 22 of the Constitution that, "if such person is deprived of such right
under the Defence of India, Act, 1962, or any rules or order made thereunder". In
other words, on the terms of the 1962 Presidential Order, the Courts were under a
duty to see whether a deprivation satisfies these conditions or not. They couldAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

adjudicate upon the question whether a detention was under the Act or a rule made
thereunder. On the other hand, the Presidential Order of 1975 unconditionally
suspends the enforcement of the rights conferred upon "any person including a
foreigner" to move any Court for the enforcement of the rights conferred by Articles
14 21 and 22 of the Constitution. The Courts are, therefore, no longer obliged or able
to test the validity of a detention by examining whether they conform to statutory
requirements. They will have to be content with compliance shown with forms of the
law.
(3) Presidential Order of 1962 makes no mention of pending proceedings, but the
1975 order suspends all pending proceedings for the enforcement of the rights
mentioned therein. This further clarifies and emphasizes that the intention behind
the Presidential Order of 1975 was to actually affect the jurisdiction of Courts in
which proceedings were actually pending. The inference from this feature also is that
all similar proceedings in future will, similarly, be affected.
366. The result is that I think that there can be no doubt whatsoever that the Presidential Order of
27th June, 1975, was a part of an unmistakably expressed intention to suspend the ordinary
processes of law in those cases where persons complain of infringement of their fundamental rights
by the executive authorities of the State. The intention of the Parliament itself to bring about this
result, so that the jurisdiction of Courts under Article 226, in this particular type of cases, is itself
affected for the duration of the emergency, seems clear enough from the provisions of Section
16A(9) of the Act, introduced by Act No. 14 of 1976, which received Presidential assent on 25th
January, 1976, making Section 16A(9) operative retrospectively from 25th June, 1975.
367. The question before us is : What is the intention behind the Presidential Order of 27th June,
1975 '? After assigning a correct meaning to it, we have to determine whether what was meant to be
done lay within the scope of powers vested by Article 359 of the Constitution in the President. There
is no doubt in my mind that the object of the Presidential Order of 27th June, 1975, by suspending
the enforcement of the specified rights, was to affect the powers of Courts to afford relief to those the
enforcement of whose rights was suspended. A I have already indicated, this was within the purview
of Article 359(1) of the Constitution. Hence, the objection that the powers of the Court under Article
226 may indirectly be affected is no answer to the direct suspension of rights which was bound to
have its effect upon the manner in which jurisdiction is or could reasonably be exercised even if that
jurisdiction cannot be itself suspended for all types of cases. It is enough if the ambit of the power to
suspend under Article 359(1) is such as to make exercise of the jurisdiction to protect guaranteed
fundamental rights not reasonably possible.
368. Section 16A(9) also appears to me, as held by My lord the Chief Justice, to make it impossible
for Courts to investigate questions relating to the existence or absence of bona fides at least in
proceedings under Article 226 of the Constitution. It is clear that the validity of Section 16A(9)
cannot be challenged on the ground of any violation of Part III of the Constitution in view of the
provisions of Article 359(1A).Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

369. No previous decision of this Court deals with a situation which results from the combined effect
of a Presidential Order couched in the language of the Order of 27th June 1975, and a statutory
provision, such as Section 16A(9) of the Act, the validity of which cannot be challenged. Hence,
strictly speaking, earlier decisions are not applicable. I will, however, consider them under the next
heading as considerable argument has taken place before us on the assumption that these cases do
apply to such a situation.
(F) The Rule of Law as found in our Constitution, and how it operates during the Emergency.
370. As I have indicated earlier in this judgment, the term Rule of Law is not a magic wand which
can be waved to dispel every difficulty. It is not an Aladin's Lamp which can be scratched to invoke a
power which brings to any person in need whatever he or she may desire to have. It can only mean,
for lawyers with their feet firmly planted in the realm of reality, what the law in a particular State or
country is and what it enjoins. That law in England is the law made by Parliament. That is why Sir
Ivor Jennings said (See : Law and the Con- situation-III Edn.) that "in England supremacy of
Parliament is the Constitution". And naturally, the Constitution of a country and not something
outside it contains the Rule of Law of that country. This means that the Rule of Law must differ in
shades of meaning and emphasis from time to time and country to country. It could not be rigid,
unchanging, and immutable like the proverbial laws of the Medes and Persians. Nevertheless, one
has to understand clearly what it means in a particular context. It cannot be like some brooding
omnipotence in the skies. Its meaning cannot be what anyone wants to make it. It has to be, for each
particular situation, indicated by the Courts which are there to tell the people what it means.
371. This Court has, in no unmistakable terms, indicated what the Constitution means and how the
Rule of Law embedded in it works even during Emergencies.
372. A statement of the Rule of Law by Jackson, J., in Youngstown Sheet & Tube Co. v. Sawyer 343
U.S. 579, 655, quoted with approval by this Court, in Chief Settlement Commissioner, Rehabilitation
Department Punjab and Ors. etc. v. Om Parkcish and Ors. @ 661 etc. (at page 661):
With all its defects delays and inconveniences men have discovered no technique for
long preserving free government except that the Executive be under the law, and that
the law be made by Parliamentary deliberations.
373. It was explained there :
In our constitutional system, the central and most: characteristic feature is the
concept of the rule of law which means, in the present context, the authority of the
law courts to test all administrative action by the standard of legality. The
administrative or executive action that does not meet the standard will be set aside if
the aggrieved person brings the appropriate action in the competent court. The rule
of law rejects the conception of the Dual State in which governmental action is placed
in a privileged position of immunity from control of law. Such a notion is foreign to
our basic constitutional concept.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

374. This statement, no doubt, includes the concept of determination by Courts of the question
whether an impugned executive action is within the bounds of law. However, it presupposes : firstly,
the existence of a fixed or identifiable rule of law which the executive has to follow as distinguished
from a purely policy decision open to it under the wide terms of the statute conferring a
discretionary power to act; and, secondly, the power of the Courts to test that action by reference to
the Rule. Even, in Emergencies, provided the power of the Court to so test the legality of some
executive act is not curtailed, Courts will apply the test of legality "if the person aggrieved brings the
fiction in the competent Court". But, if the locus standi of the person to move the Court is gone and
the competence of the Court to enquire into the grievance is also impaired by inability to peruse the
grounds of executive action or their relationship with the power to act, it is no use appealing to this
particular concept of the Rule of law set out above. It is just inapplicable to the situation which
arises here. Such a situation is governed by the Emergency provisions of the Constitution. These
provisions contain the Rule of Law for such situations in our country.
375. In Mohd. Yaqub etc. v. the State of Jammu & Kashmir , a seven Judge bench of this Court
pointed out that, whereas Article 358, by its own force, suspends the guarantees of Article 19, Article
359(1) has the effect of suspending the operation of specified fundamental rights (strictly speaking it
is enforcement only which is suspended) so that these concepts cannot be used to test the legality of
executive action. Now, much of what Dicey meant by the Rule of Law was certainly sought to be
embothed in Part III of our Constitution. If, however, the application of Articles 14, 19, 21 and 22 of
the Constitution is suspended, it is impossible to say that there is a Rule of Law found there which is
available for the Courts to apply during the emergency to test the legality of executive action.
Makhan Singh v. State of Punjab , a seven Judge decision of this Court was sought to be made a
foothold for several arguments on behalf of the detenus. It, however, seems to me to have laid down
more propositions which demolish various contentions advanced on behalf of the detenus than
those which could assist them. One main question considered in that case was whether Section
491(1)(b) of the CrPC could afford a statutory remedy, by an order or direction in the nature of a writ
of Habeas Corpus, at a time when enforcement of the fundamental right to personal liberty was
suspended by the Presidential Order of 1962 already set out above. The suggestion that a Common
Law remedy by way of writ of Habeas Corpus exists, even after Section 491 was introduced in the
Criminal Procedure Code in 1923, was negatived. The sweep of Article 359 (1) of the Constitution,
taking in the jurisdiction of "any Court", was held wide enough to cover any kind of relief claimed by
a petitioner for the enforcement of a specified fundamental right. Inter alia, it was held (at p.
821-822) :
If Article 359(1) and the Presidential Order issued under it govern the proceedings
taken under Section 491(l)(b), the fact that the court can act suo motu will not make
any difference to the legal position for the simple reason that if a party is precluded
from claiming ins release on the ground set 'out by him in ins petition, the Court
cannot, purporting to act suo motu, pass any order inconsistent with the provisions
of Article 359(1) and the Presidential Order issued under it. Similarly, if the
proceedings under Section 491(1)(b) are in by Article 359(1) and the Presidential
Order, the arguments based on the provisions of Article 372 as well as Articles 225Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

and 375 have no validity. The obvious and the necessary implication of the
suspension of the right of the citizen to move any court for enforcing ins specified,
fundamental rights is to suspend the jurisdiction of the Court pro tanto in that behalf.
This is exactly the interpretation which I have adopted above of Sree Mohan
Chowdhury's case (supra).
376. It was also held in Makhan Singh's case (supra) that, as no attack on the validity of the Defence
of India Act of 1962 and the Rules framed thereunder, on the ground of violation of fundamental
rights, was open during the emergency, no petition was maintainable on the ground of such alleged
invalidity. It was held (at p. 825-826) there :
Therefore, our conclusion is that the proceedings taken on behalf of the appellants
before the respective High Courts challenging their detention on the ground that the
impugned Act and the Rules are void because they contravene Articles 14, 21 and 22,
are incompetent for the reason that the fundamental rights which are alleged to have
been contravened are specified in the Presidential Order and all citizens are
precluded from moving any Court for the enforcement of the said specified rights.
377. After having decided the questions actually calling for determination in that case,
Gajendragadkar, J., speaking for the majority, expressed some views on the possible pleas which
may still be open to petitioners in hypothetical cases despite the Presidential Order of 1962, set out
above, passed under Article 359(1). He said (at page 828):
If in challenging the validity of ins detention order, the detenu is pleading any right
outside the rights specified in the order, ins right to move any court in that behalf is
not suspended, because it is outside Article 359(1) and consequently outside the
Presidential Order itself. Let us take a case where a detenu has been detained in
violation of the mandatory provisions of the Act. In such a case, it may be open to the
detenu to contend that ins detention is illegal for the reason that the mandatory
provisions of the Act have been contravened. Such a plea is outside Article 359(1) and
the right of the detenu to move for ins release on such a ground cannot be affected by
the Presidential Order.
378. Again, it was observed (at page 828-829) :
Take also a case where the detenu moves the Court for a writ of habeas corpus on the
ground that ins detention has been ordered malafide. It is. hardly necessary to
emphasise that the exercise of a power malafide is wholly outside the scope of the Act
conferring the power and can always be successfully challenged. It is true that a mere
allegation that the detention or malafide would not be enough, the detenu will have
to prove the malafides. But in the mala-fides are alleged, the detenu cannot be
precluded from substantiating ins plea on the ground of the bar created by Article
359(1) and the Presidential Order. That is another kind of plea which is outside theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

purview of Article 359(1).
The two passages set out above, stating what may be the position in purely
hypothetical cases, are the mainstrays of some of the arguments for the petitioners.
But, none of the Counsel for the petitioners has stated how these observations are
applicable to facts of the case of the particular petitioner for whom he appears.
Assuming, however, that the hypothetical cases indicate good grounds on which a
Habeas, Corpus petition could be allowed even in an Emergency, it was certainly not
decided in Makhan Singh's case (supra) what the process could be for ascertaining
that one of these grounds exist. If that process involves a consideration of evidence in
support of a plea, such as that of mala fides, in proceedings under Article 226,, the
most important evidence would be grounds of detention. These grounds constituted
the lever which could have been and was used in the past by Courts to reach decisions
on various pleas, such as the plea that the order was not passed after due application
of mind to the facts of the detenu's case or that the satisfaction reached was not with
regard to legally relevant grounds at all. No such means are available now. This
difficulty was certainly not in the way at the time of the decision in Makhan Singh's
case (supra).
379. I am, therefore, of the opinion that pleas which involve any adduction of evidence would, at any
rate, be entirely excluded by the combined effect of the terms of the Presidential Order of 27th June,
1975, read with the amended provisions of Section 16A(9) of the Act. A perusal of S. Pratap Singh v.
State of Punjab , will show the kind of evidence which often becomes necessary to justify a plea of
"malice in fact". Pleas about vires of the detention order itself (e.g. whether it is based on irrelevant
grounds or was not passed after due application of mind) often require investigation of questions of
fact involving scrutiny of actual grounds of detention which is hit by the embargo against an
assertion of a right to move for enforcement of the right to personal freedom and prohibition against
disclosure of grounds. So long as the executive authorities of the State purport to act under the Act.,
their preliminary objection against further hearing will prevail unless, of course, the officer
purporting to detain had, in fact, not been invested at all with any authority to act in which case the
detention would, in my opinion, be on the same footing as one by a private person who has no legal
authority whatsoever to detain. But, such a defect has to be apparent either on the face of the order
or admitted in the return. Moreover, it can be cured by an adoption of the order by the State.
380. Detentions which not only do not but could not possibly have any apparent, ostensible., or
purported executive authority of the State whatsoever to back them, could be equated with those by
private persons. The suspension of enforcement of specified fundamental rights operates only to
protect infringements of rights by the State and its authorised agents, acting or purporting to act, in
official capacities which they could and do hold. A claim to an order of release from such a patently
illegal detention, which is not by the State or on its behalf, could be enforced even during the current
Emergency. But there is no such case before us. All the cases before us are, as far as I know, of
detentions by duly empowered official under, prima fade, good orders. The possibility, however, of
so unlikely a hypothetical case where there is a lack of legal power to act, which could be easily
removed by the executive authorities of the State concerned themselves, whenever they desire to doAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

so, is only mentioned to illustrate my view that the test of legality, applied by Courts, is not entirely
abrogated and abandoned in the current emergency. But, it can be only one which should be
applicable without going into facts lying behind the return. The presumption of validity of a duly
authenticated order of an officer authorised to pass it is conclusive in Habeas Corpus proceedings
during the current Emergency.
381. State of Madhya Pradesh and Anr. v. Thakur Bharat Singh was another decision of the
Constitution Bench of this Court relied upon strongly on behalf of detenus. In that case, an order
prohibiting a petitioner from residing in a specified area under Section 3(1) (b) of the Madhya
Pradesh Public Security Act, 1959, which was found to be void, because the provision infringed
Article 19 of the Constitution, was held to be challengeable during an Emergency despite the
provisions of Article 358 of the Constitution. The ground of the decision was that, although, the
empowering provision could not have been challenged if it was contained in an enactment made
during the emergency, yet, as the provision was made by an Act passed at a time when Article 19 was
operative,, the invalidity of the provision could be demonstrated despite the existence of the
emergency. I do not think that there is any such case before us. It seems to me to be possible to
distinguish the case on the ground that it was a case of patent voidness of the order passed so that
the principle of legality, which is not suspended, could be affirmed even apart from enforcement of a
specified fundamental right. I think it was placed on such a footing by Shah J., speaking for this
Court.
382. State of Maharashtra v. Prabhakar Pandurang Sangzgiri and Anr. [1966] SUPP- S. C. R- 702,
another decision of the Constitution Bench of this Court, was also cited. There, an illegal order
prohibiting the sending out of jail by a detenu of a book on matters of scientific interest only, for
publication, was quashed by a High Court, under Article 226 of the Constitution, despite the
Presidential order under Article 359 of the Constitution, on the ground that there was no condition
at all in the Bombay Conditions of Detention Order, 1951, authorising the Government of
Maharashtra to prohibit the publication of a book of purely scientific interest just because the
petitioner happened to be detained under the Defence of India Rules, 1962. The High Court's view
was affirmed by this Court. This case has nothing to do with preventive detention. It is a case in
which this Court held that an ultra vires order could be set aside. This could be done under the
residuary jurisdiction of the High Court, which could operate for "any other purpose". The mere
existence of the emergency could not, it was held, suspend this power. The test applied was of bare
illegality outside Article 19 of the Constitution.
383. In Dr. Ram Manohar Lohia v. State of Bihar and Ors. , this Court did, in a petition under Article
32 of the Constitution apply the test of a satisfaction required on relevant grounds, by Rule 30,
Sub-rule 1, Defence of India Rules, 1962, as a condition precedent to detention, because the grounds
of detention were mentioned in the detention order itself so that they could be used to determine
whether the detention order fell within the purposes of the Act. The writ petition was allowed. The
alleged satisfaction of the District Magistrate, who was the detaining authority, was found, on the
ground given for detention, to fall outside Rule 30. It was held that the Presidential Order under
Article 359 was not intended to condone violations of the Defence of India Act or the rules made
thereunder and did not authorise ultra vires or mala fide detentions. It was pointed out here thatAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

satisfaction about the need to detain in the interests of "law and order" was not the same thing as
one in the interests of "public order". In this case, a well-known distinction between "public order"
and "law and order", was drawn by Hidayatullah, J., in the following terms :
It will thus appear that just as "public order" in the rulings of the Court (earlier cited)
was said to comprehend disorders of less gravity than those affecting "security of
State", "law and order" also comprehends disorders of less gravity than those
affecting "public order". One has to imagine three concentric circles. Law and order
represents the largest; circle within which is the next circle representing public order
and the smallest circle represents security of State. It is then easy to see that an act
may affect law and order but not public order just as an act may affect public order
but not security of the State. By using the expression "maintenance of law and order"
the District Magistrate was widening ins own field of action and was adding a clause
to the Defence of India Rules.
384. I take the decision of this Court in Dr. Lohia's case to mean that. if the order, on the face of it.,
is bad and does not satisfy the requirements of the law authorising detention, the detenu may be
released. Sarkar, J., pointed out there :
The satisfaction of the Government which justifies the order under the rule is a
subjective satisfaction. A court cannot enquire whether grounds existed which would
have created; that satisfaction on which alone the order could have been made in the
mind of a reasonable person. If that is so--and that indeed is what the respondent
State contends--it seems to me that when an order is on the face of it not in terms of
the rule, a court cannot equally enter into an investigation whether the order of
detention was in fact, that is to say, irrespective of what is stated in it, in terms of the
rule. In other words, in such a case the State cannot be heard to say or prove that the
order was in fact made., for example, to prevent acts prejudicial to public order which
would bring it within the rule though the order does not say so. To allow that to be
done would be to uphold a detention without a proper order.
385. The case was also decided on a consideration of evidence on the ground that there was an area
of enquiry opened up by the grounds given for entry by the Court. I do not know how any decision
could have been given in Dr. Lohia's case if grounds of detention were not found to be bad on the
very face of the order stating those grounds, or, it there was no door left open for judicial scrutiny
due to a provision such as Section 16A(9) of the Act before Us. Thus, the law considered and applied
in Dr. Lohitfs case was different from the law we have to apply under a different set of circumstances
as explained above.
386. In K. Anandan Nambiar and Anr. v. Chief Secretary, Government of Madras and Ors. , a writ
petition under Article 32 of the Constitution by a Member of Parliament during the currency of an
emergency and a Presidential Order, was dismissed although ins locus standi to maintain the
petition was affirmed on the following ground :Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

The petitioners contend that the relevant Rule under which the impugned orders of
detention have been passed, is invalid on grounds other than those based on Articles
14, 19, 21 and 22., and if that plea is well-founded, the last clause of the Presidential
Order is not satisfied and the bar created by it suspending the citizens' fundamental
rights under Articles 14, 21 and 22 cannot be pressed into service.
387. Apparently, the view adopted in Nambiar's case (supra) was that to question the validity of the
provision under which the detention order is made could not be equated with an allegation of
infringement of procedure established by law. Moreover, this decision was also in a different context
with a different set of applicable provisions. None of the cases before us involves the assertion that
the power under which the detention order purports to be made itself did not exist in the eye of law.
388. In Durga Dass Shirali v. Union of India and Ors. , a Habeas Corpus petition against a detention
order under Rule 30 of the Defence of India Rules, 1962, was again dismissed. But, it was held that
Article 358 and the Presidential Order under Article 359(1) did not debar the petitioner from
assailing ins detention on the ground of mala fides or on the ground that any of the grounds
mentioned in the order of detention is irrelevant. This case is also distinguishable on the ground
that the context., from the point of view of the applicable law. was different.
389. In Jai Lal v. State of West Bengal [1966] Supply. S. C. R. p. 4, 64, this Court, after taking
evidence by affidavits into account and considering the pleas of mala fides, rejected the petitioner's
case although the petitioner was held, on the strength of earlier decisions of this Court, entitled to
raise the pleas of mala fides despite the Proclamation of emergency and the Presidential order.
Again, the context and the applicable law there were different.
390. We, however, see that, despite the Proclamation of emergency and a Presidential Order under
Article 359(1), this Court has held that High Courts, in exercise of their supervisory jurisdiction,
could entertain Habeas Corpus petitions and enforce the principle of legality against the detaining
authorities. No doubt, the executive and the legislative organs of the State were fully aware of the
nature and effect of the decisions of this Court. It is, therefore., not surprising that, by means of a
differently phrased Presidential Order of 17th June. 1975, and the amendment in the Act.
introducing rather drastic provisions of Section 16A of the Act, the intention has been made clear
that preventive detention should be a matter controlled exclusively b\ the executive departments of
the State.
391. It was contended by Mr. Tarkunde that the Rule of Law under our Constitution is embothed in
the principle of Separation of Powers. It is very difficult for me to see the bearing of any such
doctrine on a pure and simple question of determination of the meaning of constitutional and
statutory provisions couched in words which leave few doubts unresolved. However, as arguments
based on this doctrine were advanced, I will deal with the manner in which, I think, laws relating to
preventive detention fit in with the extent to which our Constitution recognises the doctrine.
392. In Rai Sahib Ram Jawaya Kapur and Ors. v. The Stale of Punjab , Mukherjea, C.J., speaking for
this Court, said :Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

The Indian Constitution has not indeed recognised the doctrine of separation of
powers in its absolute rigidity but the functions of the different parts of branches of
the Government have been sufficiently differentiated and consequently it can very
well be said that our Constitution does not contemplate assumptions, by one organ or
part of the State, of functions that essentially belong to another. The executive indeed
can exercise the powers of departmental or subordinate legislation when such powers
are delegated to it by the legislature.
He further added :
Our Constitution, though federal in its structure, is modelled on the British
Parliamentary system where the executive is deemed to have the primary
responsibility for the formulation of governmental policy and its transmission into
law though the condition precedent to the exercise of this responsibility is its
retaining the confidence of the legislative branch of the State.
393. If an order of preventive detention is not quasi-judicial, as it cannot be because of the
impossibility of applying any objective standards to the need for it in a particular case, there could
be no question of violating any principle of separation of powers by placing preventive detention
exclusively within the control of executive authorities of the State for the duration of the Emergency.
That seems to me to be the effect of the emergency provisions of the Constitution and the
amendments of the Act already dealt with by me.
394. Commenting upon Liversidge's case (supra) in "The Law Quarterly Review" (1942) (Vol. 58-p.
2)., the celebrated jurist and authority on English Constitutional history and law, Sir William Holds
worth, supporting majority decision there, opined:
The question turns not, as Lord Atkin says upon whether the common law or the
statute law has postulated a 'reasonable' cause for a decision or an action, but upon
the question whether or not the decision or the action to be taken on a reasonable
cause raises a justiciable issue. Clearly the question whether a person is of hostile
origin or associations so that it is necessary to exercise control over him, raises, not a
justiciable., but a political or administrative issue.
He added :
On principle this distinction seems to me to be clearly right. If the issue is justiciable,
if, that is, it raises an issue within the legal competence of the Court to try, the Court
can decide on the facts proved before it whether a cause or a suspicion is reasonable,
for it knows: the law as to what amounts in the circumstances to a cause or a
suspicion which is reasonable. If, on the other hand, the issue is not justiciable, if,
that is, it turns, not on a knowledge of the law as to what amounts in the
circumstances to a reasonable cause or suspicion, but on political or administrative
considerations, it can have no knowledge of the weight to be attached to factsAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

adduced to prove the reasonableness or unreasonableness of the cause or
suspicion...... for it has neither the knowledge nor the means of acquiring the
knowledge necessary to adjudicate upon the weight to be attached to any evidence
which might be given as to the existence of circumstances of suspicion or as to the
reasonableness of belief. Since, therefore, it is impossible to apply an objective
standard through the agency of the Courts, the only possible standard to be applied is
the subjective standard, so that the Secretary of State's statement that he had a
reasonable cause for ins belief must be conclusive.
395. If the meaning of the emergency provisions in our Constitution and the provisions of the Act is
clearly that what lies in the executive field, as indicated ..above,, should not be subjected to judicial
scrutiny or judged by judicial standards of correctness, I am unable to see how the Courts can
arrogate unto themselves a power of judicial superintendence which they do not, under the law
during the emergency, possess.
396. Dean Roscoe Pound, in the Green Foundation Lectures on "Justice According to Law" (Yale
University Press, 1951) begins ins answer to the question as to what justice is by a reference" to the
posting Pilate, who would not stay for the answer because he knew that philosophers disagreed so
much, in their answers, that there could be no completely satisfactory answer. He divides justice
itself into three heads., according to the three types of bodies or authorities which could administer
it, and discusses the advantages and disadvantages of each : Legislative, Executive, Judicial. He
rejects "Legislative Justice", said to be most responsive to popular will, as too "uncertain, unequal,
and capricious". He said that its history, even in modern times, was filled with "legislative
lynchings"., and that this kind of justice was too susceptible to "the influence of personal
solicitation, lobbying, and even corruption", and subject to guests of passion, prejudice, and
partisanship. He thought that executive or administrative justice, which becomes inevitable in
carrying out vast schemes of modern socialistic control and planning of economic, social, and
cultural life of the people by the State was also, despite its own mechanisms of control against
misuse of power., fraught with serious dangers indicated by him. Finally, Dean Pound finds judicial
justice, though not entirely immune from error--and, sometimes, grievous and costly error--to be
superior to the other two types of justice despite its own inherent shortcomings as compared with
executive or administrative justice for special types of cases.
397. Now, the question before us is not whether Courts should apply the high standards of "judicial
justice" to the facts of each individual case which are not before us for consideration at all. The
question) before us is purely one of the interpretation of laws as we find them. If, on a correct
interpretation of the legal provisions, we find that the jurisdiction of Courts was itself meant to be
ousted, for the duration of the emergency, to scrutinise the facts or reasons behind detention orders
purporting to have been made under the Act, because the judicial process suffers from inherent
limitations in dealing with cases of this type, we are bound, by the canons of "judicial justice" itself,
to declare that this is what the laws mean.
398. It appears to me that it does not follow from a removal of the normal judicial superintendence,
even over questions of vires, of detention orders, which may require going into facts behind theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

returns, that there is no Rule of Law during the emergency or that the principles of ultra vires are
not to be applied at all by any authority except when, on the face of the return itself, it is
demonstrate in a Court of Law that the detention does not even purport to be in exercise of the
executive power or authority or is patently outside the law authorising detention. It seems to me
that the intention behind emergency provisions and of the Act is that,, although such executive
action as is not susceptible to judicial appraisement, should not be subjected to it, yet, it should be
honestly supervised and controlled by the hierarchy of executive authorities themselves. It enhances
the powers and, therefore, the responsibilities of the Executive.
399. A maxim of justice is sometimes said to be : "Let the heavens fall but justice must be done ". As
applied to judicial justice, it means that justice must accord with the highest standards of objective,
impartial, unruffled dictates of a clear judicial conscience working "without rear or favour, affection
or ill-will". It does not mean that the object of "judicial justice" is either to make "the heavens fall" or
that it-should be oblivious to consequences of judicial verdicts on the fate of the nation. It fully
recognises the legal validity of the principle adopted by the English House of Lords in both Saaiq's
case (supra) and Liversidge's case (supra) : "Salus Populi Est Supreme Lex" (regard for the public
welfare is the highest law). This is the very first maxim given Broom's Legal Maxim under the first
head : "Rules founded on public policy" (See Broom's "Legal Maxims" p. 1).
400. It is not my object to animadvert here at length on any weaknesses in our legal or judicial
system. I would., however, like to point out that judicial justice can only be "justice according to
law". It tends more often to accord with legal justice than moral justice. Not only are the fact finding
powers of Courts limited by rules of evidence and procedure, but the process of fact finding and
adjudication can miss their objects due to the buying power of money over venel witnesses and the
capacity of the wealthy to secure the best forensic talents in the country even if we do not take into
account the liability of judges, like the) rest of human beings, to err. Ends of justice can be frustrated
by all kinds of abuses of the processes of Courts.
401. The machinery of executive justice, though not hide-bound by technical rules of evidence and
procedure, can also be and often is inordinately dilatory. Its wheels can be clogged by red-tape and
by corrupt clerical underlings if their palms are not greased by honest citizens. Even those in the
upper echelons of the bureaucracy can be sometimes hopelessly unable to see the true objects of an
administrative scheme or of the policy embodied in a statute. They tend to be more anxious to
'please their superiors than to do justice so that matters in which executive heads may not get
interested are liable to be neglected for years and even forgotten, whereas others, in which they are
interested, received speedy attention. They are not even aided by lawyers who, whatever else may be
said about them, have undoubtedly imagination, courage, independence, and devotion to their
client's interests. In any case, executive justice lacks the appearance of detachment. Justiciable
disputes between the State and the citizen, on principles of natural justice, require independent
authorities for their resolution. It is for this reason that Article 226 of the Constitution places
administrative action and inaction, even at the highest levels, under judicial superintendence, when
it impinges on rights of persons, although this may have given rise to problems of its own either due
to misuse by litigants of the powers of High Courts under Article 226 of the Constitution or want of
clarify in the drafting of our statutes or the difficulties experienced by the executive officers ofAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Government in understanding the laws or the manner in which their own dirties are to be carried
out.
402. Considerations, such as those mentioned above, arising out of alleged carelessness with which,
according to the learned Counsel for the detenus, detentions are sometimes ordered, were placed
before us so that we may not deny powers of rectification of apparent errors of detaining officers to
High Courts. It was stated by one learned Counsel that a detention order was once issued against a
person who was dead. Obviously, no detention order could be executed against a dead person and
no writ petition could be moved on behalf of such a person. I have, however., no doubt, that the
machinery of the preventive detention is not so defective as to prevent executive authorities at the
highest levels from doing justice in appropriate cases where real injustice due to misrepresentations
or mis-apprehensions of fact is brought to their notice. Not only are the highest executive
authorities, under whose supervision the administration of preventive detention laws is expected to
take place, better able than the High Courts, acting under Article 226 of the Constitution, to go into
every question of fact and are in a much better position to know all relevant facts, but their
knowledge of the meaning of laws to be administered and the policies underlying them could not be
less, even if they are not better, known to them than to the High Courts on such a matter as
preventive detention. As already indicated, it raises essentially matters of policy. Courts cannot
decide what individuals with what kind of associations and antecedents should be detained. In some
cases., the associations and affiliations of individuals with groups or organisations may certainly be
matters of common public knowledge. But, it is only the membership and associations of persons
which may be matters of public knowledge. The nature of information, and the manner in which
individuals or organisations concerned may do something, which may constitute a danger to the
security of the State, are matters of appraisement of situations and policies on which information
could certainly not be broadcast.
403. I, therefore, think that a challenge to the validity of Section 16A(9) based either on the
submission that grounds for detention do not call for secrecy or that the provision is an unwarranted
invasion of judicial power, even in an emergency, is not well-founded. I will indicate below the
safeguards which exist in the Act itself for obtaining redress on the executive side in cases' of
preventive detention. As was held by this Court in Ram Jawaya Kapur's case (supra), there is no
such strict separation of powers under our Constitution as one finds in the American Constitution.
No particular provision of the Constitution could be pointed out in support of the proposition that
preventive detention is a matter in which judicial superintendence must necessarily be preserved as
a part of the doctrine of separation of powers.
404. Section 3., sub. sec. 3 of the Act shows that the detaining officer has to submit a report
forthwith on a case of preventive detention, together with grounds of detention and particulars of
the case, for the approval of the State Government. The detention order itself, unless approved by
the State Government, lapses automatically after 12 days. In special cases, covered by Section 8 of
the Act, the proviso to Section 3. sub. sec. 3, makes the initial order, subject to the approval of the
State Government., operative for 22 days. In cases covered by Section 16A(2) and (3) of the Act, in
which no grounds of detention are to be supplied to the detenu, the State Government has to review
and confirm the order if the detention is to, continue beyond 15 days. Section 14 of the Act providesAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

for revocation of detention orders without prejudice to the provisions of Section 21 of the General
Clauses Act, 1897. The power of revocation may be exercised not only by the detaining officer
concerned, but by the State Government or the Central Government also. Temporary release of
persons detained is also provided for by Section 15 of the Act on the order of the appropriate
Government, so as to prevent undue hardship and to meet special contingencies. The provisions of
Article 353(a) of the Constitution also enable the Union Government to issue directions to a State
Government relating to the manner in which a State's executive power is to be exercised during the
Emergency. Means of redress, in cases such as those of mistaken identity or misapprehension of
facts or detentions due to false and malicious reports circulated by enemies, are thus still open to a
detenu by approaching executive authorities. There is no bar against that. What is not possible is to
secure a release by an order of a Court in Habeas Corpus proceedings after taking the Court behind a
duly authenticated prima facie good return.
405. An argument before us, to which I would like to advert here, was that, notwithstanding the
emergency provisions., some undefined or even denned principles of Rule of Law, outside the
emergency provisions, can be enforced by the High Courts in exercise of their powers under Article
226 of the Constitution because the Rule of Law has been hold by this Court to be a part of the
inviolable ''basic structure" of the Constitution. It was submitted that, as this basic structure was
outside even the powers of amendment of the Constitution under Article 368 of the Constitution, it
could not be affected by emergency provisions or by provisions of the Act. We were asked to atleast
interpret the emergency provisions and the Act in such a way as to preserve what was represented to
be the "Rule of Law" as a part of the basic structure of the Constitution.
406. It seems to me that the theory of a "basic structure" of the Constitution cannot be used to build
into the Constitution an imaginary part which may be in conflict with Constitutional provisions, The
Constitution cannot have a base cut away from the super-structure. Indeed, as explained above, it
seems to me that the emergency provisions could themselves be regarded as part of the basic
structure of ;he Constitution. At any rate, they are meant to safeguard the basis of all orderly
Government according to law.
407. Speaking for myself, I do not look upon the theory of a basic structure of the Constitution as
anything more than a part of a well-recognised mode of construing a document. The Constitution,,
like any other document, has to be read and construed as a whole. This is the common principle
which was applied, though in different ways and with differing results, both by Judges taking the
majority as well as minority views in Kcmvananda Bfiarti's case (supra). Some of the learned Judges
thought that, by an application of this rule, the scope of the power of amendment, contained in
Article 368 of the Constitution, was limited by certain principles which, though not expressly laid
down in Article 368, could be read into the word "amendment" as implied limitations upon powers
under Article 368. On the other hand, other learned Judges (including myself) took the view that,
considering the provisions of the Constitution as a whole, the powers of amendment of the
Constitution in Article 368, which operated on all parts of the Constitution itself and embraced even
the power of amending Article 368 of the Constitution, could not reasonably be so limited. The
theory, therefore, was nothing more than a method o; determining the intent behind the
constitutional provisions. It could not and did not build and add a new part to the Constitution.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

408. It was then urged that want of bona fides was expressly left open for determination by Courts
even in an emergency in Liversidge's case. It must no:, however, be forgotten that Liversidge's case
was not u decision upon a habeas corpus proceeding, but, it came to the House of Lords at an
interlocutory stage of a suit for damages for false imprisonment when Liversidge was denied access
to particulars of grounds of ins detention. The question considered there was whether he could-ask
for them as a matter of right. The House of Lords denied him that right.
409. In Greene's case (supra)., which was heard with Liversidge's case (supra) by the House of
Lords, the decision was that the return made on behalf of the Secretary of State could not be
questioned. It is true that even in Greene's case (supra), a theoretical exception was made: for a case
of want of bona fides. I call it "theoretical" because such a case is perhaps not easily conceivable in
England. It also requires some explanation as to what could be meant by holding that a return is
"conclusive", but the bona fides of the order can be challenged. The explanation seems to me to be
that want of bona fides or "malice in fact" was placed on the same footing as fraud, which nullifies
and invalidates the most solemn proceedings. It may, however, be pointed out that, in Greene's case
(supra), it was not held that mala fides or any other invalidating fact could be proved during the
emergency in habeas corpus proceedings. An explanation of an almost forma exception for a case of
want of bona fides could be that the reservation of such a plea was meant only for such proceedings
in which "malice in fact" could reasonably be gone into and adjudicated upon. The position before
us, however., is very clear. Section 16A(9) imposes a bar which cannot be overcome in Habeas
Corpus proceedings. In addition, a specific suspension or enforcement of the right of personal
freedom against executive authorities places the presumption arising from a duly authenticated
order of a legally authorised detaining officer on a richer footing than a merely ordinary rebut table
presumption for purposes of proceedings under Article 226 of the Constitution. These are, as
already indicated, summary proceedings.
410. I may point out here that the term "mala fide" is often very loosely used. Even in England, the
scope of malice is wide enough to include both "malice in law" and "malice in fact". Lord Haldane in
Shearer v. Shields [1914] A.c. 808, said:
Between 'malice in fact' and 'malice in law' there is a broad distinction which is not
peculiar to any system of jurisprudence. The person who inflicts a wrong or an injury
upon any person in contravention of the law is not allowed to say that he did so with
an innocent mind. He is taken to know the flaw and can only act within the law. He
may, therefore, be guilty of 'malice in law', although., so far as the state of ins mind
was concerned he acted ignorantly, and in that sense innocently. 'Malice in fact' is a
different thing. It means an actual malicious intention on the part of the person who
has done the wrongful act.
411. Now, applying the broad concepts of "malice in law", as stated above, it has often been argued
before us, in cases of preventive detention, that the burden is upon the executive authorities of
proving the strict legality and correctness of every step in the procedure adopted in a case of
deprivation of personal liberty. To ask the executive authorities to satisfy such a requirement,, in
accordance with what has been called the principle in Eshuqbayi Eleko's case (supra) would be inAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

my opinion., to nullify the effect of the suspension of the enforceability of the procedural: protection
to the right of personal freedom. To do so is really to make the Presidential Order under Article
359(1) of the Constitution ineffective. Therefore, no question of "malice in law" can arise in Habeas
Corpus proceedings when such a protection is suspendend. As regards the issue of "malice in fact",
as T have already pointed out, it cannot be tried at all in a Habeas Corpus proceeding although it
may be possible to try it in a regular suit the object of which is not to enforce a right to personal
freedom but only to obtain damages for a wrong done which is not protected by the terms of Section
16 of the Act. The possibility of such a suit should be another deterrent against dishonest use of
these powers by detaining officers.
412. Mr. Mayakrishnan, learned Counsel for one of the detenus, contended that state of emergency,
resulting from the Presidential Order of 27th June, 1975, cannot be equated with a situation in
which Martial Law has been proclaimed. The argument seems to be that if the jurisdiction of Courts
to enforce the right to personal freedom is affected, the resulting position would be no different from
that which prevails when Martial Law is declared.
413. There is no provision in our Constitution for a declaration of Martial Law. Nevertheless, Article
34 of the Constitution recognises the possibility of Martial Law in this country. It provided :
34. Notwithstanding anything in the foregoing provisions of this Part, Parliament
may by law indemnify any person in the service of the Union of a State or any other
person in respect of any act done by him in connection with the maintenance or
restoration of order in any area within * the territory of India where martial law was
in force or validate any sentence passed, punishment inflicted, forfeiture ordered or
other act done under martial law in such area.
414. As there is no separate indication in the Constitution of conditions in which Martial Law could
be "proclaimed", it could be urged that a Presidential Order under Article 359(1) has a similar effect
and was intended to provide for situations in which Martial Law may have to be declared in any part
of the country. But, a Presidential Order under Article 359(1) of the Constitution would, ordinarily,
have a wider range and effect throughout the country than the existence of Martial Law in any
particular part of the country. The Presidential Proclamations are meant generally to cover the
country as a whole. "Martial Law" is generally of a locally restricted application. Another difference
is that conditions in which what is called "Martial Law" may prevail result in taking over by Military
Courts of powers even to try offences; and, the ordinary or civil Courts will not interfere with this
special jurisdiction under extraordinary conditions. Such a taking over by Military Courts is
certainly outside the provisions of Article 359(1) of the Constitution taken by itself. It could perhaps
fall under Presidential powers under Articles 53 and 73 read with Article 355. Article 53(2) lays
down :
53(2) Without prejudice to the generality of the foregoing provision the supreme
command of the Defence Forces of the Union shall be vested in the President and the
exercise thereof shall be regulated by law.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

And, Article 355 provider,:
355. It shall be the duty of the Union to protect every State against external
aggression and internal disturbance and to ensure that the government of every State
is carried on in accordance with the provisions of this Constitution.
A similarity in results, however, between Martial Law and conditions resulting from a Presidential
Order under Article 359(1) is that, if no provision is made by an Act of Indemnity, the civil liabilities
of military or civil officers, acting mala fide and outside the law, are not removed ipso facto by either
Martial Law or the Proclamation of Emergency.
415. In Halsbury's Laws of England (4th Edn. vol. 8, para 982, page 625), an explanation of Martial
Law, as it is known in British Constitutional Law, is given as follows :
The Crown may not issue commissions in tune of peace to try civilians by martial law;
but when a state of actual war, or of insurrection, not or rebellion amounting to war
exists, the Crown and its officers may use the amount of force necessary in the
circumstances to restore order. This use or force is sometimes termed "martial law".
When once a state of actual war exists the civil courts have no authority to call in
question the actions of the military authorities, but it is for the civil courts to decide,
if their jurisdiction is invoked, whether a state of war exists which justifies the
application of martial law. The powers such as they are, of the military authorities
cease and those of the civil courts resumed ipso facto with the termination of the
State of war; and in the absence of an act of Indemnity, the civil courts may inquire
into the 24--833SCIJ76 legality of anything done during the state of war. Even if
there is an Act of Indemnity couched in the usual terms, malicious acts will not be
protected. Whether this power of using extraordinary measures is really a prerogative
of the Crow, or whether it is merely an example of the common law right and duty of
ail, ruler and sublet alike, to use the amount of free necessary to suppress disorder, is
not uite free from doubt. It is however, clear that so-called military courts set up
under martial law are not really courts at all and so an order of prohibition will not
issue to restrain them. Probably the correct view to take of martial law itself is that it
is no law at all.
416. It is not at all necessary for the purposes of the decision of cases before us to determine how
proclamations of emergency are related to the more drastic conditions in which ' Martial Law" if is
law at all, may come into existence due to the very necessities of a situation It is evident that the
emergency provisions of our Constitution with situate. It is evident that the emergency provisions of
our Constitution are very comprehensive.. They are intended not merely to deal with situations
when actual out-break of hostilities with another country has taken place and a war is going on but
also when the country's peace, prowess, security and independence are threatened by dangers other
internal or external or both. Whether there is a "grave emergency", falling within Article 352(1), is a
matter entirely for the President to determine.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

417. Attempts were made by some Seamed Counsel to paint very gloomy pictures of possible
consequences if this Court held that no relief was open to petitioners against deprivation of their
personal when a number of cases of serious misuse of their powers by the detaining officers were
said to be in evidence. do not think that it is either responsible advocacy or the performance of any
partriotic or public duty to suggest that powers of preventive detention are being misused in the
current emergency when our attention could not be drawn to the allegations in a single case even by
way of illustration of the alleged misuse instead of drawing upon one's own imagination to conjure
up phantoms. In fact I asked some learned Counsel to indicate the alleged facts of any particular
case before us to enable us to appreciate how the power of preventive detention had been misused.
Mostly, the answers given were that the facts of the cases were not before us at this stage which is
true. But. it is significant that no case of alleged "malice in fact" could be even brought to our notice.
418. It seems to me that Courts can safely act on the presumption that powers of preventive
detention are not being abused. The theory that preventive detention serves a psycho-therapeutic
purpose may not be correct. But the Constitutional duty duty of every Govt. faced with threats of
wide spread disorder and chaos to meet it with appropriate steps cannot be denied. And if one can
refer to a member of common knowledge appearing from newspaper reports a umber of detenus
arrested last year have already been released. This shows that the whole situation whole situation is
periodically reviewed. Furthermore we under stand that the care and concern bestowed by the State
authorities ' upon the welfare of detenus who are well housed ,we fed and well treated., is almost
maternal Even parents have to take appropriate preventive action against these children who may
threaten to burn down the house they live in.
419. If there are, under our Constitution some obligations or overriding powers or duties vested in
superior Courts as learned Counsel for the detenus seemed to be contending for , to enforce the
claims of constitutionality quite apart from the suspended powers and duties of Courts to enforce
fundamental rights. I an sure that the current Emergency, justified not only the rapid improvements
due to it in the seriously dislocated national economy and discipline but also by the grave danger of
tomorrow, apparent to those who have the eyes to see them, averted by it, could not possibly provide
the occasion for the discharge of such powers, if any, in the courts set up by the they must always be
guided by the principle already indicated: "Sauls Populi Supreme Lex" . Indeed, as I understand
even the majority view in Golaknath's cases(supra), it was that. deposite the invalidity of
constitutional amendments of provisions containing fundamental rights, to, to give effect to the view
would be contrary to this principle. The case for the detenus before us, 'however fails on preliminary
hurdles. Despite strenuous efforts, their learned Counsel were quite unable to show any
constitutional invalidity, directly or indirectly, in any of the measures taken, whether legislative or
executive, by or on behalf of the State.
420. The real question for determination by us relates only to the meaning and effect of the
Constitutional and statutory provisions indicated above which are applicable during the current
Emergency. A large number of other questions including even some quite remotely connected with
the real question involved were permitted by this Court t to be argued because of the went concern
and anxiety of this Court when problems relating to neuronal liberty are raised. In the interpretation
of the relevant provisions adopted by me the validity of detention orders purporting to be passedAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

under the Act cannot be challenged in Habeas Corpus proceedings.. Judicial proceedings in criminal
Courts, not meant for the enforcement of fundamental rights, are not either at the initial or
appellate or revisional stages covered by the Presidential order of 1975. Habeas Corpus petitions are
not maintainable in such cases on another ground. It is that the prisoner is deemed to be in proper
custody under orders of a Court.
421. My answer to the two questions set out in the beginning of this judgment.. which I compressed
into one is as follows:
A prima facie valid detention order that is to say, one duly authenticated and passed
by an officer authorised to make it recording purported satisfaction to detain the
petitioner under the maintenance of Internal Security Act. Which is operative either
before or after its confirmation by the Government is a complete answer to a petition
for a writ of Habeas Corous. Once such an order is shown to exist in response to a
notice for a writ of Habeas Corpus, the High Court cannot inquire into its validity or
vires on the ground of either mala fides of any kind or of non-compliance with any
provision of the Maintenance of internal Security Act in Habeas Corpus proceedings.
The preliminary objection of the State must be accepted in such a case.
422. The result is that the appeals before us are allowed and the judgment and order of the High
Court in each case is set aside. The High Court concerned will itself now pass an order on each
petition in accordance with law as laid down by this Court and the provisions of Article 359(1) of the
Constitution.
Y.V. Chandrachud, J.
423. During the last few years, many questions of far-reaching constitutional importance have
engaged the attention of this Court but these appeals, perhaps, present problems of the gravest
magnitude. They involve an adjustment between two conflicting considerations, the liberty of the
individual on one hand and exigencies of the State on the other. This balancing of the most precious
of human freedoms--the liberty of the subject--as against the most imperative of the State's
obligations--the security of the State--gives rise to multi-dimensional problems quite beyond the
scope and compass of each right considered separately and in isolation. Can the freedom of the
individual be subordinated to the exigencies of the State and if so, to what extent ? The Constitution
concedes to the Executive the power of Preventive detention, but in the name of national security
can that jurisdiction of suspicion be so exercised as to reduce the guarantee of personal liberty to a
mere husk ? Detention without trial is a serious inroad on personal freedom but it bears the sanction
of our Constitution. The Constituent Assembly composed of politicians, statesmen, lawyers and
social workers who had attained a high status in their respective specialties and many of whom had
experienced the travails of incarceration owing solely to their political beliefs, resolved to put Article
22, clauses (3) to (7) into the Constitution, may be as a necessary evil. But does that mean that, more
as a rule than as an exception, any person can be detained without disclosing the grounds of
detention to him or to the Court which may be called upon to try ins Habeas Corpus petition ? And
can such grounds and the information on which the grounds are based be deemed by a rule ofAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

evidence to relate to the affairs of the State, therefore, confidential and therefore privileged? Blind,
unquestioning obethence does not flourish on English soil, said Lord Simonds in Christie v.
Leachinsky [1947] A.C. 573 ,591 Will it flourish on Indian soil ? These broadly are the sensitive
questions for decision and importantly, they arise in the wake of * Proclamations of Emergency
issued by the President
424. Part XVIII of the Constitution, called "Emergency provisions", consists of Articles 352 to 360.
Article 352(1) provides that if the President is satisfied that a grave emergency exists whereby the
security of India or of any part of the territory thereof is threatened, whether by war or external
aggression or internal disturbance, he may, by Proclamation, make a declaration to that effect. A
Proclamation issued under Clause (1) is required by Clause (2)(b) to be laid before each House of
Parliament and by reason of Clause (2) (c) it ceases to operate at the expiration of two months
unless before the expiration of that period it has been approved by resolutions of both Houses of
Parliament. By Clause (3) of Article 352, a Proclamation of Emergency may be made before the
actual occurrence of war or of external aggression or internal disturbance, if the President is
satisfied that there is imminent danger thereof. Clause (5) (a) makes the satisfaction of the President
under Clauses (1) and (3) final, conclusive and non-justiciable. By Clause (5)(b), neither the
Supreme Court nor any other court has jurisdiction, subject to the provisions of Clause (2), to
entertain any question on any ground regarding the validity of a proclamation issued under Clause
(1) or the continued operation thereof.
425. Article 358 provides that :
While a Proclamation of Emergency is in operation, nothing in Article 19 shall restrict
the power of the State as defined in 'Part III to make any law or to take any executive
action which the State would but for the provisions contained in that Part be
competent to make or to take, but any law so made shall, to the extent of the in
competency, cease to have effect as soon as the Proclamation ceases to operate,
except as respects things done or omitted to be done before the law so ceases to have
effect.
426. Article 359(1) empowers the President, while a Proclamation of Emergency is in operation, to
declare by order that :
. . .the right to move any court for the enforcement of such of the rights conferred by
Part III as may be mentioned in the order and all proceedings pending in any court
for the enforcement of the rights so mentioned shall remain suspended for the period
during which the Proclamation is in force or for such shorter period as may be
specified in the order.
Clause (1A), which was inserted retrospectively in Article 359 by Section 7 of the
Thirty-eighth Amendment Act, 1975, provides :Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

While an order made under Clause (1) mentioning any of the rights conferred by Part
III is in operation, nothing. in that Part conferring those rights shall restrict the
power of the State as defined in the said Part to make any law or to take any executive
action which the State would but for the provisions contained in that Part be
competent to make or to take, but any law so made shall, to the extent of the
incompetency, cease to have effect as soon as the order aforesaid ceases to operate,
except as respects thinks done or omitted to be done before the law so ceases to have
effect.
Clause (3) of Article 359 requires that every order made under Clause (1) shall, as
soon as may be after it is made, be laid before each House of Parliament.
427. Article 352 was resorted to for the first time when hostilities broke out will) China. On October
26, 1962 the President issued a Proclamation declaring that a grave emergency existed whereby the
security of India was threatened by external aggression. This proclamation was immediately
followed by the Defence of India Ordinance, 4 of 1962, which was later replaced by the Defence of
India Act, 196?. On November 3, 1962 the President issued an Order under Article 359(1) of the
Constitution, which was later amended by an Order dated November 11, 1962 stating that :
the right of any person to move any court for the enforcement of the rights conferred
by Article 14, Article 21 and Article 22 of the Constitution shall remain suspended for
the period during which the proclamation of emergency issued under Clause (1) of
Article 352 thereof on the 26th October, 1962, is in force, if such person has been
deprived of any such rights under the Defence of India Ordinance, 1962 (4 of 1962) or
any rule, or order made thereunder.
(Emphasis supplied).
Article 14 was added to the Order of November 3, 1962 by the amendment dated
November 11, 1962. The emergency declared on October 26, 1962 was revoked by a
Proclamation dated January 10, 1968 issued under Article 352(2)'(a) of the
Constitution.
428. The Defence of India Act, 1962 was to remain in force during the period of operation of the
Proclamation of Emergency issued on October 26, 1962 and for a period of six months thereafter.
The Act of 1962 expired on July 10, 1968.
429. The maintenance of Internal Security Act. 26 of 1971, (MISA), was brought into force on July 2,
1971 in the shadow of hostilities with Pakistan. Section 3(1) of that Act provides as follows :
3. (1) The Central Government or the State Government may.--
(a) if satisfied with respect to any person (including a foreigner) that with a view to
preventing him from acting in any manner prejudicial to--Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

(i) the defence of India, the relations of India with foreign powers, or the security of
India, or
(ii) the security of the Stale or the maintenance of public order, or
(iii) she maintenance of supplies and services essential to the community, or
(b) if satisfied with respect to any foreigner that with a view to regulating his
continued presence in India or with a view to linking arrangements for his expulsion
from India, it is necessary so to do make mi order directing that such person be
detained.
430. Section 8 of the Act requires that the grounds on which the order of detention is made shall be
commutate to the detenu within a certain period but that the authority making the order .nay net
disclose facts which it considers to be against the public interest to disclose.
431. Consequent on the Pakistani aggression, the President issued a Proclamation of Emergency on
December 3, 1971 on the ground that the security of India was threatened by external aggression. By
an order dated December 5. 1971 issued under Article 359(1) of the Constitution, the right of
foreigners' to move any court for the enforcement of rights conferred, by Articles 14, 21 and 22 was
suspended.
432. In September 1974 the MISA was amended by Ordinance 11 of 1974 to include Sub-section (c)
in Section 3(1), by which be right to detain was given as against smugglers and offenders under the
Foreign Exchange Regulation Act, 1947. On November 16, 1974 the President issued a Declaration
under Article 359(1) suspending the right of persons detained under Section 3(1)(c) of the MISA to
move for enforcement of the rights conferred by Article 14, Article 21 and Clauses (4), (5), (6) and
(7) of Article 22 of the Constitution..
433. On June 25, 1975 the President issued a Proclamation under Article 352(1) declaring that a
grave emergency existed whereby the security of India was threatened by internal disturbance. On
June 27, 1975 the President issued an Order under Article 359(1) which reads as follows :
G.S.R. 361 (E)--In exercise of powers conferred by Clause (1) of Article 359 of the
Constitution, the President hereby declares that the right of any person (including a
foreigner) to move any court for the enforcement of the Rich's conferred by Article
14, Article 21 and Article 22 of the Constitution and all proceedings pending in any
court for the enforcement of the above mentioned rights shall remain suspended for
the period during which the proclamation of emergency made under Clause (1) of
Article 352 of the Constitution on the 3rd December, 1971 and on the 25th of June,
1975 are both in force.
The Order shall extend to the whole of the territory of India.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

This Order shall be in addition to and not in derogation of any Order made before the
date of this Order under Clause (1) of Article 359 of the Constitution.
434. Various persons detained under Section 3(1) of the MIS A filed petitions in different High
Courts for the issue of the writ of Habeas Corpus. When those petitions came up for hearing, the
Government raised a preliminary objection to their maintainability on the ground that in asking for
release by the issuance of a writ of habeas corpus, the detenus were in substance claiming that they
had been deprived of their personal liberty in violation of the procedure established by law, which
plea was available to them under Article 21 of the Constitution only. The right to move for
enforcement of the right conferred by that Article having been suspended by the Presidential Order
dated June 27, 1975 the petitions, according to the Government, were liable to be dismissed at the
threshold. The preliminary objection has been rejected for one reason or another by the High Courts
of Allahabad, Bombay, Delhi, Karnataka, Madhya Pradesh, Punjab and Rajasthan. Broadly, these
High Courts have taken the view that despite the Presidential Order it is open to the detenus to
challenge their detention on the ground that it is ultra vires, as for example, by showing that the
order on the face of it is passed by an authority not empowered to pass it, or it is in excess of the
power delegated to the authority, or that the power has been exercised in breach of the conditions
prescribed in that behalf by the Act under which the order is passed, or that the order is not in strict
conformity with the prevision of the Act. Some of these High Courts have further held that the
detenus can attack the order of detention on the ground that it is malafide, as for example, by
showing that the detaining authority did not apply its mind to the relevant considerations, or that
the authority was influenced by irrelevant considerations, or that the authority was actuated by
improper motives. Being aggrieved by the finding recorded by these Rich Courts on the preliminary
point, the State Governments and the Government of India have filed these appeals, some under
certificates granted by the High Courts and some by special leave granted by this Court. The High
Courts of Andhra Pradesh, Kerala and Madras have upheld 'he preliminary objection.
435. During the pendency of these appeals and while the hearing was in progress, the President
issued an order dated January 8, 1976 under Article 359(1) declaring that the right to move any
court for the enforcement of the rights conferred by Article 19 and the proceedings pending in any
court for the enforcement of those rights shall remain suspended during the operation of the
Proclamations of Emergency dated December 3, 1971 and June 25, 1975.
436. On behalf of the appellants, the appeals were argued by the learned Attorney-General and the
learned Additional Solicitor-General. The learned Advocates-General of various States argued in
support of their contentions. A string of counsel appeared on behalf of "the respondents, amongst
them being Shri Shanti Bhushan, Shri V. M. Tarkunde, Shri R. B. Jethmalani, Shri S. J. Sorabji, Shri
A. B. Dewan, Shri C. K. Daph'ary, Dr. N. M. Ghatate, Shri G. C. Dwivedi, Shri Santokh Singh, Shri
Sharad Manohar, Shri Daniel Latin" and Shri Mayakrishnan. The learned Advocate-General of
Gujarat generally supported their submissions.
437. The learned Attorney-General contended that Article 21 is the sole repository of the right to life
and personal liberty and if the right to move any court for the enforcement of that right is suspended
by the Presidential Order issued under Article 359(1), the detenus have no locus standi to file theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

writ petitions and therefore these petitions must be dismissed without any further inquiry into the
relevance of the material on which the grounds of detention are based or the relevance of the
grounds or the bona fides of the detaining authority, if the MISA permits the non-disclosure of
grounds and indeed prevent their disclosure, there is no question of inquiring into the reasons or
grounds of detention and courts must accept at its face value the subjective satisfaction of the
detaining authority as recorded in the order of detention. "There is no half-way house" asserted the
Attorney-General. But, not inconsistently with the basic submission that the detenus have no locus
standi to file the petitions for habeas corpus, he conceded that the court may grant relief if the
detention order is on the face of it bad, as for example, if it is passed by a person not authorised to
pass it, or if it is passed for a purpose outside those mentioned in Section 3(1) of the MISA or if it
does not bear any signature at all.
438. The learned Additional Solicitor-General indicated during the course of ins argument the limits
of judicial review in the event of the court rejecting the main submission of the Attorney-General.
He contended that Section 16A(9) of MISA contains but a rule of evidence and is therefore not open
to attack on the ground that it encroached upon the jurisdiction of the High Court under Article 226
of the Constitution. Since Section 16AC9) is not unconstitutional, no court can ask for the
production of the file relating to a detenu or ask for the disclosure of the grounds of detention. If
such disclosure is not made, no adverse inference can be raised by holding that by reason of
non-disclosure, the detenu's case stands unrebutted. The learned Additional Solicitor-General
contended that there was no warrant for reading down Section 16A(9) so as to permit disclosure to
the court, to the exclusion of the parties and if any inquiry is permissible at all into a habeas corpus
petition, the inquiry must be limited to the following points : (i) Whether the order is made in
exercise or purported exercise of power conferred by a law; (ii) If such law was pre-emergency law,
is it a valid law; (iii) whether the authority which passed the order is duly empowered to do so by the
law; (iv) Whether the person sought to be detained is the person named in the order of detention;
(v) Whether the stated purpose of the detention is one that comes within the law; (vi) Have the
procedural safeguards enacted by the law been followed; and (vii) Where grounds are furnished (i.e.
when 16-A does not apply) do such grounds ex-fade justify the apprehension of the detaining
authority or is it vitiated by a logical non-sequltur ? Such an inquiry, according to the learned
Counsel, can never extend to an objective appraisal of the material and the information for the
purpose of testing the validity of the subjective satisfaction of the detaining authority.
439. The arguments advanced on behalf of the respondents covered a wide range but they may be
summarized thus:
1. The object of Article 359(1) and the effect of an order issued under it is to remove
restraints against. The Legislature so that during the emergency, it is free to make
laws in violation of the fundamental rights mentioned in the Presidential Order.
2. Under a Constitution which divides State functions into Executive, Legislative and
Judicial, the executive functions must be discharged consistently with the valid laws
passed by the Legislature and the order and decrees passed by the Judiciary. The
suspension of the right to enforce fundamental right cannot confer any right on theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Executive to court the law by which it is bound as much in times of emergency as in
times of peace. Since there is a valid law regulating preventive detention, namely, the
MISA, every order of detention . passed by the Executive must conform to the
conditions prescribed by that law.
3. Article 359(1) may remove fetters imposed by Part III but it cannot remove those
arising from the principle of rule of law or from the principle of the limited power of
the Executive under the system of checks and balances based on separation of
powers.
4. The obligation cast on the Executive to act in accordance with the law docs not
arise from any particular Article of the Constitution but from the inherent
compulsion arising from the principle of rule of law which is a central feature of our
constitutional system and is a basic feature of the Constitution. The suspension of the
right to enforce Article 31 does not automatically entail the suspension of the rule of
law. Even during emergency, the rule of law is not and cannot be suspended.
5. The Presidential Order under Article 359(1) may bar the enforcement of
fundamental rights mentioned in the order by a petition under Article 32 before the
Supreme Court. But. the Presidential Order cannot bar the enforcement of rights
other than fundamental rights by a petition filed under Article 226 in the High Court.
6. Common law rights as well as statutory rights to personal liberty can be enforced
through writ petitions file under Article 226, despite the Presidential Order issued
under Article 359(1). Similarly, contractual rights, natural rights and
non-fundamental constitutional rights like those under Articles 256, 265 and 361 (3)
of the Constitution, can be enforced under Article 226. Article 226 empowers the
High Courts to issue writs and directions for the enforcement of fundamental rights,
"and for any other purpose".
7. The essence of the inquiry in a Habeas Corpus petition is whether the detention is
justified by law or is ultra VIRES. the law. Such an inquiry is not shut cut by the
suspension of the rural to enforce- fundamental rights.
8. It the Presidential Order is construed as a bar 10 the maintainability of the writ
petitions under Article 22ft of the Constitution, that Article shall have been amended
without a proper and valid constitutional amendment,
9. Article 21 of the Constitution is not the sole repository of the right to life or
personal liberty. There is no authority for the proposition that; on the contention; 01
fundamental right by Part III the corresponding pre-existing rights merged with the
fundamental rights and that with the suspension OL fundamental rights, the
corresponding pre-existing rights also got suspended.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

10. Suspension of the right lo enforce Article 21 cannot put a citizen in a worse
position than in the pre Constitution period. The pre Constitution right of liberty was
a right in rein and was totally dissimilar from the one created by Article 21. The pre
Constitution right was merely a right not to be detained, save under the authority of
law.
11. Civil liberty or personal liberty is not a conglomeration of positive rights. It is a
negative concept and constitutes an area of free action because no law exists
curtailing it or authorising its curtailment.
12. Section 16A(9) of the MISA A is unconstitutional as it encroaches upon the High
Courts' powers under Article 226 of the Constitution by creating a presumption that
the grounds on which the order of detention is made and any information or
materials on which the grounds are based shall be treated as confidential and shall be
deemed to refer to matters of State, so that it will be against the public interest to
disclose the same.
13. Section 18 of MISA as amended by Act 39 of 1975 which came into force with
effect from June 25, 1975 cannot affect the maintainability of the present petitions
which were filed before the Amendment.
14. The dismissal of writ petitions on the ground that such ' petitions are barred by
reason of the Presidential Order issued under Article 359(1) would necessarily mean
that during the emergency no person has any right to life or personal liberty; and
15. If the detenus are denied any forum for the redress of their grievances, it would be
open to the Executive to whip the detenus to starve them, to keep them in solitary
confinement and even to shoot them, which would be a startling state of affairs in a
country governed by a written Constitution having in it a Chapter on Fundamental
Rights. The Presidential Order cannot permit the reduction of Indian citizens into
slaves.
The validity of the 38th and 39th Constitution (Amendment} Acts was not challenged by the
respondents.
440. The key to these rival contentions can be found in the emergency provisions contained in
Chapter XVIII of the Constitution. The Presidential declaration of emergency is made final,
conclusive and non-justiciable by Clause (5) of Article 352, which was introduced by the 38th
Amendment retrospectively. But apart from the fact that the Constitution itself has given finality to
declarations of emergency made by the President, it is difficult to see how a Court of law can look at
the declaration of emergency with any mental reservations. The facts and circumstances leading to
the declaration of emergency are and can only be known to the Executive, particularly when an
emergency can be declared, as provided in Article 352(3), before the actual occurrence of war,
external aggression or internal disturbance, so long as the President is satisfied that there isAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

imminent danger thereof. The actual occurrence of war or external aggression or internal
disturbance can be there for anyone to see but the imminent danger of these occurrences depends at
any given moment on the perception and evaluation of the national or international situation,
regarding which the court of law can neither have full and truthful information nor the means to
such information. Judge and Jury alike may form their personal assessment of a political situation
but whether the emergency should be declared or not is a matter of high State policy and questions
of policy are impossible to examine in courts of law. The High Courts whose judgments are under
appeal have, with the greatest respect, failed to perceive this limitation on the power of judicial
review, though in fairness to them it must be stated that none of them has held that the declaration
of emergency is open to judicial scrutiny. But at the back of one's mind is the facile distrust of
executive declarations which recite threat to the security of the country, particularly by internal
disturbance. The mind then weaves cobwebs of suspicion and the Judge, without the means to
knowledge of full facts, covertly weighs the pros and cons of the political situation and substitutes
ins personal opinion for the assessment of the Executive, which, by proximity and study, is better
placed to decide whether the security of the country is threatened by an imminent danger of internal
disturbance. A frank and unreserved acceptance of the Proclamation of emergency, even in the teeth
of one's own pre-disposition. is conducive to a more realistic appraisal of the emergency provisions.
441. A declaration of emergency produces far-reaching consequences. While it is in operation the
executive power of the Union, by reason of Article 353, extends to the giving of directions to any
State as to the manner in which the executive power thereof is to be exercised. Secondly, the power
of Parliament to make laws with respect to any matter includes, during emergency, the power to
make laws conferring powers and imposing duties or authorising the conferring of power sand
imposition of duties upon the Union or officers and authorities of the Union as respects that matter,
notwithstanding that the matter is not enumerated in the Union List. Article 354 confers power on
the President to direct that the provisions of Articles 268 to 279, which deal with distribution of
revenues between the Union and the States, shall have effect subject to such exceptions or
modifications as the President thinks fit, but not extending beyond the expiration or the financial
year in which the proclamation ceases to operate. A Proclamation of emergency automatically
curtails the operation of Article 19. As provided in Article 358, while the Proclamation is in
operation nothing in Article 19 shall restrict the power of the State to make any law or to take any
executive action which the State would but for the provisions contained in Part III be competent to
make or to take. Any law so made ceases to have effect to the extent of the in competency as soon as
the proclamation ceases to operate.
442. Then comes Article 359 which is directly in point. It authorises the President to issue an order
declaring the suspension of the right to move any court for the enforcement of such of the rights
conferred by Part III as the President may specify in his Order. Clause (1A) which was introduced in
Article 359 by the 38th Amendment Act retrospectively has, inter alia, transported the provisions of
Article 358 into Article 359 during the operation of an Order made by the President under Article
359(1). The Orders issued by the President in the instant case under Article 359(1) provide for the
suspension of the right to move any court for the enforcement of the rights conferred by Articles 14,
19, 21 and clauses (4) to (7) of Article 22. Article 21 of the Constitution runs thus :Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

No person shall be deprived of his life or personal liberty except according to
procedure established by law.
443. The principal question for decision in these appeals is whether, notwithstanding the fact that
the Order issued by the President under Article 359(1) suspends the right of every person to move
any court for the enforcement of the right to personal liberty conferred by Article 21, it is open to a
person detained under a law of preventive detention like the MISA to ask for his release by filing a
petition in the High Court under Article 226 of the Constitution for the writ of habeas corpus.
444. The writ of habeas corpus is described by May in his 'Constitutional History of England (Ed.
1912, Vol. II, p. 130 (Chapter XI) ) as the first security of civil liberty. Julius Stone in Social
Dimensions of Law and Justice (Ed. 1966, p. 203), calls it a picturesque writ with an extraordinary
scope and flexibility of application. The Latin term "habeas corpus" means 'you must have the body'
and a writ for securing the liberty of the person was called habeas corpus ad subjiciendum. The writ
affords an effective means of immediate release from an unlawful or unjustifiable detention,
whether in prison or in private custody. The writ is of highest constitutional importance being a
remedy available to the lowliest subject against the most powerful government.
445. The liberty of the individual is the most cherished of human freedoms and even in face of the
gravest emergencies, Judges have played a historic role in guarding that freedom with zeal and
jealousy, though within the bounds, the farthest bounds, of constitutional power. The world-wide
interest generated by the lively debate in Liversidge v. Sir John Anderson and Anr.[1942] A.C. 206;
Lord Atkin, p. 244 has still not abated. And repeated citation has not blunted the edge of Lord
Atkin's classic dissent where he said:
I view with apprehension the attitude of judges who on a mere question of cons
ruction when face to face with claims involving the liberty of the subject show
themselves more executing minded than the executive. ...In this country , amid the
clash of arms, the laws are not silent. They may be changed, but they speak the same
language in war as in peace.... In this case I have listened to arguments which might
have been addressed acceptably to the court of King's Bench in the time of Charles I.
446. Sir William Blackstone in his 'Commentaries on the Laws of England (4th Ed., Vol I pp. 105 to
107) says that the preservation of personal liberty is of great importance to the public because if it
were left in the power of ever the highest person to imprison anyone arbitrarily there would soon be
an end of all other rights and immunities. "To bereave a man of life, or by violence to confiscate his
estate, without accusation ortrial, would be so gross and notorious an act of despotism, as must at
once convey the alarm of tyranny throughout the whole kingdom; but confinement of the person, by
secretly hurrying him to gaol, where his sufferings are unknown or forgotten, is a less public, a less
striking, and therefore a more dangerous engine of arbitrary government." The learned
commentator goes on to add: "And yet, sometimes, when the state is in real danger, even this may
be a necessary measure. But the happiness of our Constitution is, that it is not left to the executive
power to determine when the danger of the state is so great, as to render this measure expedient; for
it is the parliament only, or legislative power, that, whenever it sees proper, can authorize theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Crown, by suspending the Habeas Corpus Act for a short and limited time, to imprison suspected
persons without giving any reason for so doing."
447. May in his 'Constitutional History of England (Ed. 1912, p. 124, 130)' says that during the
course of the last century every institution was popularized and every public liberty was extended
but long before that period Englishmen had enjoyed personal liberty as their birthright. It was more
prized and more jealously guarded than any other civil right. "The Star Chamber had fallen: the
power of arbitrary imprisonment had been wrested from the Crown and Privy Council: liberty had
been guarded by the Habeas Corpus Act...." Speaking of the writ of habeas corpus May says that it
protects the subject from unfounded suspicions, from the aggressions of power and from abuses in
the administration of justice. "Yet this protective law, which gives every man security and
confidence, in times of tranquility, has been suspended, again and again, in periods of public danger
or apprehension. Rarely, however, has this been suffered without jealousy, hesitation, and
remonstrance; and whenever the perils of the state have been held sufficient to warrant this sacrifice
of personal liberty, no Ministeror magistrate has been suffered to tamper with the law at his
discretion. Parliament alone, convinced of the exigency of each occasion, has suspended, for a time,
the rights of individuals, in the interests of the State."
448. Dicey in his Introduction to the Study of the Law of the Constitution (10th Edition) says that:
During periods of pipoticial excitement the power or duty of the Courts to issue a writ
of habeas corpus, and thereby compel the speedy trail or release of persons charges
with crime, has been found an inconvenient of dangerous limitation on the authority
of the executive government. Hence has arisen the occasion for statutes which are
popularly called Habeas Corpus Suspension Acts.
449. E.C.S. Wade AND Godfrey PHILLIPS observe in their Constitutional Law (8th Ed., Chapter 48,
717, 718) that times of Grave National Emergency, normal constitutional principle must if necessary
give way TO the overriding need to deal with the emergency. According to the learned authors :
It has always been recognised that times of grave national emergency demand the of
special powers to the Executive. At such Times arbitrary arrest and imnrsonment
may be legalised by Act of Parliament. Modern war demands the abandonment of
personal liberty in that the duty of compulsory national service necessarily takes
away for the time being the right of the individual to cheese his occupation.
The learned authors refer to the English practice of passing Habeas Corpus
Suspension Acts in times of danger to the State. These Acts prevented the use of
habeas corpus and as soon as the period of suspension was over anyone who for the
time being had been denied the assistance of the writ could bring an action for false
imprisonment. Suspension did not legalise illegal arrest. it merely suspended a
particular remedy and therefore, a practice grew under which at the close of the
period of suspension an Indemnity Act would be passed in order to protect officials
from the consequences of any illegal act which they might have committed underAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

cover of the suspension of the prerogative writ.
450. Thomas M. Ccoley says in the "General Principles of Constitutional Law (4th Ed. Chapter
XXXIV, pp. 360-361) in the U.S.A. that though the right to the writ of habeas corpus by which the
liberty of the citizens is protected against arbitrary arrests is not. expressly declared in the American
Constitution, it is recognised in Article 1, Section 9, Clause 2 which says that :
The privileges of the writ of habeas corpus shall not be suspended, unless when in
cases of rebellion or invasion the public safety may require it.
It would appear that in America something similar to the passing of Acts of
Indemnity has been done by making provisions in State Constitutions.
451. Thus, though the liberty of the individual is a highly prized freedom and though the writ of
habeas corpus is a powerful weapon by which a common man can secure his liberty, there are times
in the history of a Nation when the liberty of the individual is required to be subordinated to the
larger interests of the State. In times of grave disorders, brought about by external aggression or
internal disturbance, the stability of political institutions becomes a sine qua non of the guarantee of
all other rights and interests. "To assert an absolute exemption from imprisonment in all cases, is
inconsistent with every idea of law and political society; and in the end would destroy all civil
liberty, by rendering its protection impossible.", (Blackstone's Commentaries on the Laws of
England. 4th Ed , Vol III pp. 125-126) The "clear and present danger test" evolved by Justice Holmes
in Schenck v. United States 249 U.S. 47 (1919), may well be extended to cases like the present where
there is a threat of external aggression. On the heels of American entry into the first World War on
June 15, 1917, the Congress adopted the Espionage Act creating three new offences which went
beyond the prohibition of spying and sabotage. It prescribed a punishment of a fine of 10,000
dollars and 20 years' imprisonment. A year later, the Act was amended by what is popularly called
the Sedition Act which rendered it illegal even to say anything to obstruct the sale of United States
bonds or to say anything contemptuous regarding the form of Government of the United States. A
unanimous court upheld Schenck's conviction under the Act for propagating that compulsory
service in the Armed Forces was "a monstrous wrong against humanity in the interest of Wall
Street's chosen few". The judgment was delivered in 1919 when the war was already over and
Holmes J. held that things that can be said in times of peace will not be endured during times of war
and no court will regard them as protected by any constitutional right.
452. The emergency provisions were incorporated into our Constitution on the strength of
experience gained in England and U.S.A. But the object of Article 359 is to confer wider power on
the President than the power to merely suspend the right to file a petition for the writ of habeas
corpus. Article 359 aims at empowering the President to suspend the right to enforce all or any of
the fundamental rights conferred by Part III. It is in order to achieve that object that Article 359
does not provide that the President may declare that the remedy by way of habeas corpus shall be
suspended during emergency. Personal liberty is but one of the fundamental rights conferred by
Part 111 and the writ of habeas corpus is peculiar to the enforcement of the right to personal liberty.
It must follow that the suspension of the right to enforce the right conferred by Article 21 means andAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

implies the suspension of the right to file a habeas corpus petition or to take any other proceeding to
enforce the right to personal liberty conferred by Article 21.
453. But then it is urged on behalf of the respondents that by their writ petitions, respondents did
not seek to enforce the right to personal liberty conferred by Article 21 or possessed by them apart
from it. They were really seeking a declaration that the order of detention was illegal for the reason
that it did not comply with the requirements of the law under which it was passed. In support of this
argument reliance is placed upon a passage in H.W.R. Wade's Administrative Law (3rd Ed. , pp. 127,
128) to the effect that habeas corpus is a remedy not only for the enforcement of the right to
personal liberty but is also a remedy for the enforcement of the principle of ultra vires. This
argument lacks substance and overlooks the realities of the situation. It may be open to a detenu by
filing a petition for the writ of habeas corpus to contend that order under which he is detained is
ultra vires of the statute to which the order owes its existence. But one must have regard to the
substance of the matter and not to mere form. The real and substantial relief which the detenu asks
for by a writ of habeas corpus is that he should be freed from detention and the reason for the relief
is that the order of detention is ultra vires. It is clear, apart from the form in which the relief may or
may not be clothed, that the respondents through their writ petitions were moving the High Courts
for enforcing their right to personal liberty. The history of the writ of habeas corpus which is
succinctly narrated in the late Mr. M. C. Setalvad's 'The Common Law in India' (Pages 37-41 (Ed.
1960, Hamlyn Lectures) shows that the writ of habeas corpus which was in its inception a purely
procedural writ gradually developed into a constitutional remedy furnishing a most powerful
safeguard for individual freedom. Mr. Setalvad quotes that the writ has been described as "the key
that unlocks the door to freedom". Respondents were surely not interested in obtaining an academic
declaration regarding the ultra vires character of their detention. They wanted the door to freedom
to be opened by the key of the habeas corpus writ.
454. Equally untenable is the contention that Article 226 which occurs in Chapter V, Part VI of the
Constitution is an entrenched provision and, therefore, under Article 368 no amendment can be
made to Article 226 without ratification by the Legislatures of not less than one-half of the States. It
is true that Article 226 is an entrenched provision which cannot suffer an amendment except by
following the procedure prescribed by the proviso to Article 368(2). But the Presidential Order is
issued under the Constitution itself and if its true construction produces a certain result, it cannot be
said that some other Article of the Constitution stands thereby amended. Article 359(1) provides for
the passing o[an order by the President declaring that the right to move for the enforcing of
fundamental rights mentioned in the Order shall be suspended. That may, in effect, affect the
jurisdiction of the High Courts to entertain a petition for the issuance of the writ of habeas corpus.
But that docs not bring about any amendment of Article 226 within the meaning of: Article 368,
which speaks of amendments to the Constitution by the Parliament in the exercise of its
constitutional power. Article 226 and Article 359(1) are parts of the same fundamental instrument
and a certain interpretation of one of these Articles cannot amount to an amendment of the other.
455. It is also not correct to say that any particular interpretation of: Article 359(1) will mean the
abolition of the jurisdiction and power of the Supreme Court under Article 32 and of the High
Courts under Article 226 of the Constitution. The true implication of the Presidential Order is toAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

take away the right of any person to move any court for the enforcement of the rights mentioned in
the Order. In strict legal theory the jurisdiction and powers of the Supreme Court and the High
Courts remain the same as before since the Presidential Order merely takes away the locus standi of
a person to move these Courts for the enforcement of certain fundamental rights during the
operation of the Proclamation of Emergency. It is important to appreciate that the drive of Article
359(1) is not against the courts but is against individuals, the object of the Article being to deprive
the individual concerned of his normal right to move the Supreme Court or the High Court for the
enforcement of the fundamental rights conferred by Part 111 of the Constitution. In Sree Mohan
Chowdlwry v. The Chief Commissioner, Union Territory of Tripura a Constitution Bench of this
Court, dealing with an Order issued by the President on November 3, 1962 under Article 359(1),
observed :
...Unquestionably, the Court's power to issue a writ in the nature of habeas corpus
has not been touched by the President's Order, but the petitioner's right to move this
Court for a writ of that kind has been suspended by the Order of the President passed
under Article 359(1). " The President's Order does not suspend all the rights vested in
a citizen to move this Court but only his right to enforce the provisions of Articles 21
and 22. Thus, as a result of the President's Order aforesaid, the petitioner's right to
move this Court, but not this Court's power under Article 32 has been suspended
during the operation of Emergency, with the result that the petitioner has no locus
standi to enforce his right, if any. during the Emergency.
456. According to the respondents, the limited object of Article 359(1 ) is to remove restrictions on
the power of the Legislature so that during the operation of the emergency it would be free to male
laws in violation of the fundamental rights specified in the Presidential Order. This argument loses
sight of' the distinction between the provisions of Article 358 and Article 359(1A) on the one hand
and of Article 359(1) on the other. Article 358, of its own force, removes the restrictions on the
power of the Legislature to make laws inconsistent with Article 19 and on the power of the Executive
to take action under a law which may thus violate Article 19. Article 358 does not suspend any right
which was available under Article 19 to any person prior to the Proclamation of Emergency. under
Article 359(1) the President is empowered to suspend the right of an individual to move any court
for the enforcement of the rights conferred by Part III as may be mentioned in the Order.
Consequent upon such Order, all proceedings pending in any court for the enforcement of the rights
so mentioned remain suspended during the period that the Proclamation is in force or such shorter
period as the Order may specify. Article 359 (I) is thus wider in scope than Article 358. This
distinction has an important bearing on the main point under consideration because it shows that it
was not enough to provide that nothing in Article 19 shall restrict the power of the State to make any
law or to take any executive action which the State would, but for the provisions contained in Part
III, be competent to make or take. In order to effectuate the purposes of emergency, it was necessary
further to provide that no person would have any right to move for the enforcement of his
fundamental rights mentioned in the Presidential Order and that pending proceedings in that behalf
shall remain suspended during the operation of the emergency. It seems elementary that a
fundamental right can be enforced as much in regard to a law which takes away that right contrary
to the provisions of the Constitution as against the Executive, if it acts contrary to the provisions of aAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

law or without the authority of law. In view of he language of Article 359(1) and considering the
distinction between it and the provisions of Article 358, there is no justification for restricting the
operation of Article 359(1) as against laws made by the Legislature in violation of the fundamental
rights.
457. Reliance was placed by the respondents on the decisions of this Court in Sree Mohan
Chowdliury v. The Chief Commissioner, Union Territory of Tripura [1964] 3 S.C R. 142 and Makhan
Singh v. State of Punjab in support of their contention that Article 359(1) operates in the legislative
and not in the executive field. These decisions do not support such a proposition. On the contrary, it
is clear from the two decisions that the effect of the Presidential Order under Article 359(1) is (o take
away the locus standi of a person to move any court for the enforcement of his fundamental rights
which are mentioned in the Order. Neither of the two cases deals directly with the question whether
the operation of Article 359(1) is restricted to the legislative held but, if at all, the ratio of those cases
may be logically extended to cover executive acts also. During times of emergency, it is the Executive
which commits encroachments on personal liberties and the object of Article 359(1) is to empower
the President to suspend the right to move any court for the enforcement of a right to complain
against the actions of the Executive, no less than against the laws passed by the Legislature, if either
the one or the other contravenes any of the fundamental rights mentioned in the Order.
458. This position was controverted by the respondents from several angles. It was contended that
in a Constitution which divides State functions into Executive, Legislative and Judicial, the executive
functions must be discharged consistently with the laws passed by the Legislature and the orders
and decrees passed by the judiciary. The suspension of the right to enforce fundamental rights
cannot confer any privilege on the Executive to flout the law by which it is bound as much in times
of emergency as in times of peace. Therefore, the argument proceeds, there being a valid law
regulating preventive detention, namely the MISA, every order of detention passed by the Executive
must conform to the conditions prescribed by that law. The current of thought underlying this
argument was highlighted by a learned Counsel for the respondents by saying that it is strange that
in the face of a law passed by the Parliament, which in passing the law must assume that it will be
obeyed, the Executive can flout the law with impunity by relying on the Presidential Order issued
under Article 359(1). Yet another point of view presented on this aspect of the case was that
permitting the Executive to defy and disobey the law made by the Legislature is tantamount to
destroying one of the important basic features of the Constitution that the Executive is bound by the
laws made by the Legislature. Finally, it was urged that the Preamble to the Constitution speaks of a
Sovereign Democratic Republic and, therefore, the Executive which is subordinate to the Legislature
cannot act to the prejudice of the citizen save to the extent permitted by laws validly made by the
Legislature which is the chosen representative of the people.
459. In view of the true scope and object of Article 359(1), which has already been dealt with above,
these arguments have to be rejected. In the first place, it is difficult to appreciate the argument of
'basic features' because we are not concerned to pronounce upon the validity of an amendment
made to the Constitution by a parliamentary measures. We are concerned to understand the scope
of Article 359(1) and what it implies. That Article is as much a basic feature of the Constitution as
any other and it would be inappropriate to hold that because in normal times the ConstitutionAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

requires the Executive to obey the laws made by the Legislature, therefore, Article 359(1) which is an
emergency measure, must be construed consistently with that position. The argument of basic
feature is wrong for yet another reason that Article 359(1) does not provide that the Executive is free
to disobey the laws made by the Legislature. At the cost of repetition it must be said that what
Article 359(1) achieves is merely the suspension of the right of an individual to move a court for the
assertion of his fundamental rights which have been mentioned in the Presidential Order, even if
such rights arc contravened either by the Legislature or by the Executive. To permit a challenge in a
court of law to an order of detention, which is an executive action, on the ground that the order
violates a fundamental right mentioned in the Presidential Order, is to permit the detenu to enforce
a fundamental right during emergency in a manner plainly contrary to Article 359(1). The language
of that Article, it is admitted on all hands, is clear and unambiguous.
460. The constitutional consequences of a Proclamation of Emergency are grave and far-reaching.
Legislatures can, during emergencies, make laws in violation of the seven freedom guaranteed by
Article 19; the President has the power to suspend the right to move for the enforcement of all or any
of the fundamental rights mentioned in the order issued under Article 359(1); the Executive power
of the Union extends during emergencies to giving directions to any State or to the manner in which
the executive power thereof is to be exercised. This particular power conferred on the Union
Executive is in total violation of the provisions of Article 162 of the Constitution and indeed of the
federal structure which is one of the principal features of our Constitution; if any State Executive
fails to comply with the directions given by the Union Executive under Article 353(a), the
"President's rule" can be imposed on that State under Article 356, in which event the Parliament is
entitled under Article 357(1) to confer on the President the power of the Legislature of that State to
make laws. The Parliament can even authorize the President to delegate such legislative power to
any other authority. The democratic structure of the Constitution stands severely eroded in such a
situation. Finally, Parliament acquires during emergencies the power to make laws on matters
which are numerated in the State List. If consequences so fundamentally subversive of the basic
federal structure of the Constitution can ensue during emergencies, it is not as revolting as may be
appear at first sight that even if the Executive does not obey the mandate of the Legislature, the
citizen is powerless to move any court for the protection of his fundamental rights, if these rights are
mentioned in the Presidential Order.
461. A facet of the same argument was presented on behalf of the respondents with even greater
force. It was urged that Article 359(1) may remove fetters imposed by Part III but it cannot ever
remove the fetters arising from the principle of rule of law or from the principle of the limited power
of the Executive under a system of checks and balances based on separation of powers. The
obligation cast on the Executive to act in accordance with law does not, according to the
respondents, arise from any particular Article of the Constitution but it arises from the inherent
compulsion of the rule of law which is a central basic feature of our constitutional system. The
suspension of the right to enforce Article 21 cannot automatically entail the suspension of the rule of
law because, even during an emergency the argument proceeds, the rule of law is not and cannot be
suspended. The Executive has a limited authority under the Indian Constitution and it can act
within the residual area as it pleases, so long as it does not act to the prejudice of the citizen. It is
always incumbent on the Executive to justify its action on the basis of law and this, according to theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

respondents, is the principle of legality or the rule of law.
462. The respondents' argument that all executive action which operates to the prejudice of a person
must have the authority of law to support it is indisputably valid in normal situations. In the absence
of a Proclamation of Emergency and in the absence of a Presidential Order under Article 359(1) of
the kind that we have in the instant case, the Executive is under an obligation to obey the law and if
it acts to the prejudice of anyone by disobeying the law, its action is liable to be challenged by an
appropriate writ. That the rule of law must prevail in normal times is the rule of law under the
Indian Constitution. But it is necessary to clear a misconception. Even though the compulsion to
obey the law is a compulsion of normal times, Article 358 takes in those cases only in which the
executive purports to act under the authority of a law. It does not envisage that the executive can-act
without the apparent authority of law. In other words, Article 358 enables the Legislature to make
laws in violation of Article 19 and the Executive to act under those laws, despite the fact that the laws
constitute an infringement of the fundamental rights conferred by Article 19.
463. The argument of the respondents that the Presidential Order under Article 359(1) cannot ever
suspend the rule of law requires a close examination, particularly in view of some of the decisions of
this Court which apparently support that contention.
464. In State of Madhya Pradesh and Anr. v. Thakur Bharat Singh [l967] 2 S. C. R. 454 the State
Government, on April 24, 1963 made an order under Section 3 of the Madhya Pradesh Public
Security Act, 1959 directing that the respondent shall not be in any place in Raipur District, that he
shall immediately proceed to and reside in a named town and that he shall report daily to a police
station in that town. The order was challenged by the respondent by a writ petition under Articles
226 and 227 of the Constitution on the ground that Section 3 infringed the fundamental rights
guaranteed by Article 19(1)(d) and (e) of the Constitution. The respondent succeeded in the High
Court which declared a part of the order invalid on the ground that Section 3(1)(b) of the Act was
violative of Article 19(1)(d) of the Constitution. In appeal, it was contended in this Court on behalf of
the State Government that so long as the state of emergency declared on October 20, 1962 was in
force, the respondent could not move the High Court by a petition under Article 226 on the plea that
by the impugned order his fundamental right guaranteed under Article 19(1)(d) was infringed. It
was further contended on behalf of the State Government that even if Section 3(1)(b) was held to be
void, Article 358 protected legislative as well as executive action taken after the Proclamation of
Emergency and therefore the order passed by the Government after the emergency was declared
could not be challenged as infringing Article 19. Describing this latter argument as involving "a
grave fallacy", a Constitution Bench of this Court dismissed the State's appeal holding, that for acts
done to the prejudice of the respondent after the declaration of emergency under Article 352, no
immunity from the process of the Court could be claimed under Article 358 of the Constitution since
the order was not supported by any valid legislation. Shah J. who spoke on behalf of the Bench
observed in his judgment that all executive action which operates to the prejudice of any person
must have the authority of law to support it and that the terms of Article 358 do not detract from
that rule. Article 358, according, to this Court, did not purport to invest the State with arbitrary
authority to take action to the prejudice of citizens and others but it merely provides that so long as
the Proclamation of Emergency subsists, laws may be enacted and executive action may be taken inAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

pursuance of lawful authority, which if the provisions of Article 19 were operative would have been
invalid.
465. It is important to bear in mind that Bharat Singh's case was concerned with a pre-emergency
law, though the impugned order was passed thereunder during the operation of emergency. The law
having been passed in 1959, which was before the declaration of emergency, it had to comply with
Article 19 and if it did not, it was void to the extent of the inconsistency. Since the law was held to be
violative of Article 19 it could not claim any protection under Article 358. That Article lifts
restrictions on legislative power "while a proclamation of emergency is in operation," that is to say,
it enables laws to be made during the emergency, ever if they conflict with Article 19. The executive
is then free to act under those laws. But, if the law is void for the reason that having been made prior
to the emergency it violates Article 19, or if there is no law at all under the purported authority of
which the executive has acted, the executive action is not protected by Article 358. Bharat Singh's
case is distinguishable for the additional reason that it was only concerned with the effect of Article
358 and no question arose therein with regard to any executive action infringing a fundamental
right mentioned in a Presidential Order issued under Article 359(1). I have already indicated the
vital difference between Article 358 and Article 359(1). The latter bars the enforcement of any
fundamental right mentioned in the Presidential Order, thereby rendering it incompetent for any
person to complain of its violation, whether the violation is by the Legislature or by the Executive. In
other words, Article 359(1) bars the remedy by depriving an aggrieved person of his locus to
complain of the violation of such of his fundamental rights as are mentioned in the Presidential
Order.
466. Respondents also relied in support of the same submission on the decisions of this Court in
District Collector of Hyderabad and Ors. v. M/s. Ibrahim & Co. etc. [1970]3 S. C. R. 498 Bennett
Coleman & Co. and Ors. v. Union of India and Ors. and Shree Meenakshi Mills Ltd. v. Union of India
[1974] 7 S. C. R. 398. 405 ,406 and 428. These decisions are founded on the same principle as
Rharat Singh's case and are distinguishable for the same reason. In Ibrahim's case, the existing
licences of recognised dealers in sugar were cancelled by the State Government and a monopoly
licence was given to a Cooperative Stores thereby preventing the dealers by a mere executive order
from carrying on their business. A question arose in the appeal whether the order of the State
Government canceling the licences of the dealers was protected under Articles 358 and 359 of the
Constitution as the President had declared a state of emergency on October 20, 1962. This question
was answered in the negative on the ground that the executive order which was immune from attack
is only that order which the State was competent to make but for the provisions contained in Article
19. Since the executive action of the State Government was invalid apart from Article 19, it was not
immune from attack merely because a Proclamation of Emergency was in operation. The important
point of distinction is that in Ibrahim's case, the impugned order was not made under the authority
reserved by the Defence of India Ordinance or the rules made thereunder but was issued merely in
pursuance of the policy laid down by the Central Government in entrusting the distribution of sugar
exclusively to co-operative societies. In Bennett Coleman Company's case the impugned Newsprint
Control Policy was an emanation of the old policy which was enunciated prior to the Proclamation of
Emergency. Relying on Ibrahim's case and Bharat Singh's case, this Court held that Article 358 does
not authorise the taking of detrimental executive action during the emergency without anyAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

legislative authority or in purported exercise of power conferred by a pre-emergency law which was
invalid when enacted. The decision in Bennett Coleman Company's case was followed in Meenakshi
Mills' case where the executive action taken during the emergency did not have the authority of any
valid law and the impugned orders having been made under a pre-emergency law were not immune
from attack under Article 358,
467. Respondents relied on a passage in the judgment of Ramaswami J. who spoke on behalf of the
Court in Chief Settlement Commissioner, Rehabilitation Devartment, Punjab and Ors. etc. v. Om
Parkash and Ors. etc. [9681] 3 S. C. R. 655, 660-661 to the effect that whatever legislative power the
executive administration possesses must be derived directly from the delegation of the legislature
and exercised validly only within the limits prescribed. The Court emphatically rejected the notion
of inherent or autonomous law-making power in the executive administration of the country and
observed that the rule of law rejects the conception of the Dual State in which governmental action
is placed in a privileged position of immunity from control by law on the ground that such a notion
is foreign to our basic constitutional concepts. Respondents also relied upon the decision of the
Privy Council in Eshupbavi Eleko v. Officer Administering the Government of Nieeria [1931] A. C.
662, 670 where Lord Atkin observed that in accordance with the British jurisprudence, no member
of the Executive can interfere with the liberty or property of a British subject except on the condition
that he can support the legality of his action before a Court of" Justice. Our attention was repeatedly
drawn to a further observation made by Lord Aktin that it is a tradition of British justice that Judges
should not shrink from deciding such issues in the face of the executive. These observations have
been considered be this Court in Makhan Singh's case where, speaking on behalf of the majority,
Gajendragadkar J. said that the sentiments expressed by Lord Aktin were noble and eloquent but it
was necessary to have regard to the previsions of our Constitution by which we are governed and
which has itself made emergency provisions in order to enable the nation to meet the challenge of
external aggression or internal disturbance. The principle enunciated in Eleko's case, however lofty
and stirring, has no relevance here because we have to consider the meaning and effect of Article
359(1) which has no parallel in the English law. Eleko's principle is unquestionably supreme in
times of peace and so is the validity of the observations made by Ramaswami J. in Om Prakash's
case. Both of those cases were concerned with a totally different problem, the problem of peace, not
of war or internal disturbance.
468. The 'Rule of Law' argument like the 'Basic Feature' argument is intractable. Emergency
provisions contained in Part XVIII of the Constitution which are designed to protect the security of
the State arc as important as any other provision of the Constitution. If the true construction and
effect of Article 359(1) is as I have stated it to be, it is impossible to hold that such a construction
violates the rule of law. The rule of law, during an emergency, is as one finds it in the provisions
contained in Chapter XVIII of the Constitution. There cannot be a brooding and omnipotent rule of
law drowning in its effervescence the emergency provisions of the Constitution.
469. The Advocate General of Gujarat had peculiar problems to voice, arising out of the fluid and
uncertain political situation in his State. He was unable to appreciate how the Executive
Government of the State could defy a parliamentary mandate contained in the MISA, cither as
regards the procedural or the substantive part of that law. Whatever may be the requirements ofAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

emergency, he seemed to contend, the Gujarat Government could not, save at grave peril to its
existence, defy the provisions of a law made by the Parliament. The anguish and embarrassment of
the learned Advocate General is understandable, but the short answer to his contention is that, on
the record, the Government of Gujarat has not been asked to flout the MISA and indeed no one can
dispute the right of the State Government to ensure compliance with the laws of the land. Indeed,
that is its plain and foremost duty. The important consideration is that in the event of State
Government coming to pass an order of detention in violation of MISA, the detenu will have no right
to enforce his corresponding fundamental right if it is mentioned in the Presidential Order. The
learned Advocate General built his argument as if, during emergencies, the executive is under an
obligation to flout the laws of the land. Article 359(1) neither compels nor condones the breaches by
the executive of the laws made by the legislature. Such condonation is the function of an Act of
Indemnity.
470. I must now take up for consideration a very important plank of the respondents' argument that
Article 21 is not the sole repository of the right to life and personal liberty. This argument has been
presented before us from aspects too numerous to mention and scores of instances have been cited
to buttress it. This was to some extent inevitable because quite a few counsel argued the same point
and each had his peculiar, favourite accent. I will try to compress the arguments without, I hope,
sacrificing their thematic value.
471. The respondents' arguments may be put thus ;
(1) Article 21 is not the sole repository of the right to personal liberty because that right can be found
in Articles 19(1) (b), 20 and 22 also, in view of the decision in the Bank Nationalisation case [1970] 3
S.C.R. 530, 578, which overruled Gopalan's case [1950] S. C. R. 88, these rights are not mutually
exclusive and therefore the suspension of the right to enforce Article 21 cannot affect the right
conferred by Articles 19, 20 and 22.
(2) Article 21 is not the sole repository of the right to personal liberty because, (i) an accused
convicted of murder and sentenced to death can assert his right to life by challenging the conviction
and sentence in appeal, in spite of the Presidential Order under Article 359(1); (ii) if a person is
wrongfully confined, he can ask for hi-; personal liberty by prosecuting the offender in spite of the
Presidential Order; and (iii) if a money-decree is passed against the Government., the decree can be
enforced even if the right to enforce the right to property is suspended by the Presidential Order.
(3) Prior to the enactment of the Constitution statutory, contractual and common law rights were in
existence and those lights can be taken away only by the Legislature. They cannot be affected by the
Presidential Order. The pre Constitution common law and statutory rights to personal liberty
continued in force by reason of Article 372 of the Constitution, since those rights were not repugnant
to any provision of the Constitution. If the fundamental right to personal liberty is suspended by the
Presidential Order, the pre Constitution laws will begin to operate by reason of the theory of eclipse.
There is no authority for the proposition that on the conferment of fundamental rights by the
Constitution, the corresponding pre-existing rights merged in the fundamental rights and that with
the suspension of fundamental rights, the corresponding pre-existing rights also got suspended.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Article 21 is different in content from the common law right to personal liberty which was available
against private individuals also, Since Article 21 merely elevates the right of personal liberty to the
status of a fundamental right, the pre Constitution rights cannot be suspended by the Presidential
Order. The object of Article 21 is to give and not to take. In fact, the very language of that Article
shows that, instead of conferring the right to personal liberty, it assumed its existence in the first
place and then proceeded by a negative Drovision to prohibit its deprivation. Examples of such pre-
Constitution rights arc :
(i) rights available under the Indian Penal Code and the Criminal Procedure Code;
(ii) rights available under the law of torts especially the right to sue for damages for
false imprisonment; and (iii) the remedy of habeas corpus available under Section
491, Criminal Procedure Code, since the year 1923.
(4) Non-fundamental constitutional rights like those arising under Articles 256, 265
and 361(3) or natural rights or contractual rights or the statutory rights to personal
liberty arc not affected by the Presidential Order. Statutory rights can only be taken
away in terms of the statute and not by an executive fiat. By reason of Article 256. the
executive power of every State must ensure compliance with the laws made by the
Parliament. The executive power of the States must therefore comply with Section 56
and 57 of the Criminal Procedure Code and a person aggrieved by the violation of
those provisions can enforce his statutory right to personal liberty in spite of the
Presidential Order. By Article 265 no tax can be levied or collected except by
authority of law. A person affected by the violation of this provision can enforce his
right to property even if Article 19 is suspended. If a process happens to be issued
against the Governor of a State in contravention of Article 361(3), the Governor can
exercise his right to personal liberty despite the Presidential Order under Article
359(1). Similarly, in cases not covered by Section 16A of the MISA, if the Advisory
Board opines that the detention is unjustified, the detenu can compel the
Government to accept that opinion, in spite of the Presidential Order.
(5) Even after the passing of a Presidential Order, Parliament may create new rights
to personal liberty and such rights can be en forced in spite of the Presidential Order.
(6) Civil liberty or personal liberty is not a conglomeration of positive rights. It
operates in an area of free action and no law can possibly curtail it.
(7) If a law affecting the fundamental right to personal liberty is void for want of
legislative competence, it can be challenged in spite of the Presidential Order.
(8) The suspension of the right to enforce personal liberty cannot confer a licence on
executive officers to commit offences against the law of the land, and if they do so,
they can be brought to book in spite of the Presidential Order.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

472. I look at the question posed by the respondents from a different angle. The emergency
provisions of the Constitution arc designed to protect the Security of the State and in order to
achieve that purpose, various powers have been conferred on the Parliament and the President by
Chapter XVIII of the Constitution. One of such powers is to be found in Article 359(1) under which
the President, during the operation of the emergency, can issue an order suspending the right to
move any court for the enforcement of all or any of the fundamental rights conferred by Part III.
Proceedings commenced prior to the issuance of such an order, including proceedings taken prior to
the declaration of the emergency itself, automatically remain suspended during the emergency or
for such shorter period as the President may in his order specify. The object of empowering the
President to issue an order under Article 359(1) suspending the enforcement of the right to personal
liberty conferred by Part III of the Constitution cannot be to save all other rights to personal liberty
except the one conferred by Part III, which to me seems totally devoid of meaning and purpose.
There is nothing peculiar in the content of the right to personal liberty conferred by Part III so that
the Constitution should provide only for the suspension of the right to enforce that particular kind of
right, leaving all other rights to personal liberty intact and untouched. In limes of emergencies the
executive, unquestionably though unfortunately, is constrained to take various forms of action in
derogation of the rights of citizens and others, including the cherished right to personal liberty. The
Constitution aims at protecting the executive, during the operation of emergency, from attacks on
the action taken by it in violation of the rights of individuals. Accordingly, in so far as the right to
personal liberty, for example, is concerned one of the objects of the emergency provisions is to
ensure that no proceeding will be taken or continued to enforce that right against the executive
during the operation of the emergency. The executive is then left free to devote its undiluted
attention to meeting the threat to the security of the State. This purpose cannot ever be achieved by
interpreting Article 359(1) to mean that every right to personal liberty shall be enforceable and every
proceeding involving the enforcement of such right shall continue during the emergency, except to
the extent to which the right is conferred by Part III of the Constitution. The existence of the right to
personal liberty in the pre Constitution period was surely known to the makers of the Constitution.
The assumption underlying the respondent's argument is that in spite of that knowledge, the
Constituent Assembly decided that all those rights will reign supreme in their pristine glory even
during the emergency and what will remain in abeyance is only the enforcement of the right to
personal liberty conferred by Part III. The right to personal liberty has no hallmark and therefore
when the right is put in action it is impossible to identify whether the right is one given by the
Constitution or is one which existed in the pre Constitution era. If the argument of the respondents
is correct, no action to enforce the right to personal liberty can at all fall within the mischief of the
presidential Order even if it mentions Articles 19, 20, 21 and 22 because, every preliminary objection
by the Government to a petition to enforce the right to personal liberty can be effectively answered
by contending that what is being enforced is either the natural right to personal liberty or generally,
the pre Constitution right to personal liberty. The error of the respondents' argument lies in its
assumption, and in regard to the argument of some of the counsel in the major articulate premise,
that the qualitative content of the non-constitutional or pre-constitutional right to personal liberty is
different from the content of the right to personal liberty conferred by Part III of the Constitution.
The right to personal liberty is the right of the individual to personal freedom, nothing more and
nothing less. That right along with certain other rights was elevated to the status of a fundamental
right in order that it may not be tinkered with and in order that a mere majority should not be ableAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

to trample over it. Article 359(1) enables the President to suspend the enforcement even of those
rights which were sanctified by being lifted out of the common morass of human rights. If the
enforcement of the fundamental rights can be suspended during an emergency, it is hard to accept
that the right to enforce non-fundamental rights relating to the same subject matter should remain
alive.
473. Article 359(1) contains three important Clauses : (1) The Proclamation of Emergency must be in
operation at the time when the President issues his order; (2) The President must issue an order
declaring the suspension of the right to move any court; and (3) The power of the President to
declare such suspension can extend to such rights only as are conferred by Part III. If these three
conditions are satisfied, no person can move any court for the enforcement of such of the rights
conferred by Part III as are mentioned in the Presidential Order.
474. The first and foremost question to ask when a proceeding is filed to enforce a right as against
the Government while a Proclamation of Emergency is in operation is, whether the right is
mentioned in the Presidential Order and whether it is the Kind of right conferred by Part III. Article
21, for example, confers the right to life and personal liberty. The power of the President therefore
extends under Article 359(1) to the suspension of the right to move any court for the enforcement of
the right to life and personal liberty. The President cannot suspend the enforcement of any right
unless that right is included in Part III which confers fundamental rights. The President, in my
opinion, would be acting within the strict bounds of his constitutional power if, instead of declaring
the suspension of the right to enforce the right conferred by Article 21 he were to declare that "the
right not to be deprived of life and personal liberty except according to procedure established by
law" shall remain suspend during the emergency.
475. Article 359(1) does not really contemplate that while declaring the suspension of the right to
move any court, the President must or should specify the Article or the Articles of the Constitution
the enforcement of rights conferred by which shall be suspended. What Article 359(1) contemplates
is that the President can declare the suspension of the right to move any court for the enforcement
of the rights mentioned in Part III. The words "conferred by Part III" which occur in Article 359(1)
are not intended to exclude or except from the purview of the Presidential Order, rights of the same
variety or kind as are mentioned in Part III but which were in existence prior to the Constitution or
can be said to be in existence in the post Constitution era, apart from the Constitution. The
emphasis of the Article is not the right to suspend the enforcement of the kind of rights mentioned
in Part III and not on the fact that those rights are conferred by Part III. To put it differently, the
words "conferred by Part III" are used only in order to identify the particular rights the enforcement
of which can be suspended by the President and not in order to impose a limitation on the power of
the President so as to put those rights which exist or which existed apart from the Constitution,
beyond the reach of the Presidential Order. The respondents by their petitions arc enforcing their
right to personal liberty and that right is a right conferred by or mentioned in Part 111 of the
Constitution. As 1 have said above, if instead of saying that the right to enforce the right conferred
by Article 21 shall be suspended the President were to say that the right not to be deprived of life or
personal liberty except according to procedure established by law will remain suspended, no
argument of the kind made before us could reasonably have been made. The true effect of theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Presidential Order, though worded in the way it is, is the same as it would have been, had it been
worded in the manner have indicated.
476. It therefore does not make any difference whether any right to personal liberty was in existence
prior to the enactment of the Constitution, either by way of a natural right, statutory right, common
law right or a right available under the law of torts. Whatever may be the source of the right and
whatever may be its justification, the right in essence and substance is the right to personal liberty.
That right having been included in Part III, its enforcement will stand suspended if it is mentioned
in the Presidential Order issued under Article 359(1).
477. The view which I have taken above as regards the scope and meaning of Article 359(1) affords
in my opinion a complete answer to the contention of the respondents that since Article 21 is not the
sole repository of the right to personal liberty, the suspension of the right to enforce the right
conferred by that Article cannot affect the right to enforce the right of personal liberty which existed
apart from that Article. I have held that on a true interpretation of the terms of the Presidential
Order read with Article 359(1), what is suspended is the right to move for the enforcement of the
right to personal liberty whether that right is conferred by Constitution or exists apart from and
independently of it. Otherwise, the Constitution has only done much ado about nothing.
478. All the same I would like, briefly, to deal with the argument of the respondents on its own
merit, particularly the illustrations cited in support of that argument.
479. It is true that in view of the decision in the Bank Nationalisation case , the right conferred by
Articles 21 and 19 cannot be treated as mutually exclusive. But the suspension of the right to enforce
the right of personal liberty means the suspension of that right wherever it is found unless its
content is totally different as from one Article to another. The "right conferred by Article 21" is only
a description of the right of personal liberty in order to facilitate its exact identification and such a
description cannot limit the operation of the Presidential Order to those cases only where the^ right
to personal liberty is claimed under Article 21.
480. The circumstance that the pre Constitution rights continued in force after the enactment of the
Constitution in view of Article 372 does not make any difference to this position because, even
assuming that certain rights to personal liberty existed before the Constitution and continued
thereafter as they were not repugnant to any provision of the Constitution, all rights to personal
liberty having the same content as the right conferred by Article 21 would fall within the mischief of
the Presidential Order.
481. The theory of 'eclipse" has no application to such cases because that theory applies only when a
pre Constitution law becomes devoid of legal force on the enactment of the Constitution by reason of
its repugnancy to any provision of the Constitution. Such laws are not void but they are under an
eclipse so long as the repugnancy lasts. When the repugnancy is removed, the eclipse also is
removed and the law becomes valid.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

482. As regards the doctrine of "merger" it is unnecessary to go to the length of saying that every
prior right to personal liberty merged in the right to personal liberty conferred by Part III. Whether
it merged or not, it cannot survive the declaration of suspension if the true effect of the Presidential
Order is the suspension of the right to enforce all and every right to personal liberty. In that view, it
would also make no difference whether the right to personal liberty arises from a statute or from a
contract or from a constitutional provision contained in some Part other than Part III.
483. As regards the illustrations, it is neither proper nor possible to take each one of them separately
and answer them. Hypothetical illustrations cannot establish a point and practical difficulties have
to be solved as and when they arise. But some of the more important illustrations taken by the
respondents' counsel seem to me to have a simple answer. For example, when an accused challenges
his conviction for murder and the sentence of death imposed on him for that offence, his remedy by
way of an appeal is not barred by the Presidential Order because he is only trying to get rid of a
judgment which holds him guilty of murder. It is not he who moved the court for his personal liberty
but it is the prosecution which dragged him to the court to prove the charge of murder against him.
The accused only defends the charge of criminality whether it is in the trial court or m a higher
court. Similarly, if a person is wrongfully confined, the prosecution of the offender is not intended or
calculated to secure the personal liberty of the victim. The court may in proper cases pass an order
releasing the complainant from wrongful confinement but the true object of the prosecution is to
punish the person who has committed an offence against the penal law of the land. As regards
decretal rights against the Government, what the decree-holder enforces in execution is not his right
to property. The original cause of action merges in the decree and therefore what is put into
execution is the rights arising under the decree. The illustration regarding the issuance of a process
against the Governor of a State need not be pursued seriously because such an event is hardly ever
likely to happen and if it does, the gubernatorial rights may possibly withstand the Presidential
Older under Article 359(1). As regards the flouting of the opinion of the Advisory Board by the
Government, a writ of mandamus compelling the Government to obey the mandate of the law may
perhaps stand on a different footing as the very nature of such a proceeding is basically different.
Lastly, it is unrealistic to believe that alter the passing of the Presidential Order suspending the
existing constitutional rights, Parliament would create new rights to personal liberty so as to nullify
the effect of the Presidential Order. The easier way for the Parliament would be to disapprove of the
Proclamation of emergency when it is placed before it under Article 352(2) (b) of the Constitution or
to disapprove of the Presidential Order issued under Article 359(1) when it is placed before it under
Article 359(3) of the Constitution. But as I have said earlier, it is difficult to furnish a clear and
cogent answer to hypothetical illustrations. In the absence of necessary facts one can only make an
ad hoc answer, as I have attempted to do regarding the possible issuance of a process against the
Governor of a State. Actually, Article 361(3) speaks of a "Process" for the arrest or imprisonment of a
Governor issuing from any court. Fundamental rights can be exercised as against judicial orders but
the circumstances in which such a process may come to be issued, if at all, may conceivably affect
the decision of the question whether a presidential Order issued under Article 359(1) can bar the
remedy of an aggrieved Governor.
484. In so far as the illustrative cases go, I would like to add that Article 256 which was chosen by
the respondents as the basis of an illustration does not seem to confer any right on any individual.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

That Article appears in Part XI which deals with relations between the Union and the States. A
failure to comply with Article 256 may attract serious consequences but no court is likely to
entertain a grienvance at the instance of the private party that Article 256 has not been complied
with by a State Government. As regards the claim to personal liberty founded on a challenge to an
order on the ground of excessive delegation, I prefer to express no firm opinion though the greater
probability is that such a challenge may fail in face of a Presidential Order of the kind which has
been passed in the instant case.
485. I have held above that the existence of common law rights prior to the Constitution will not
curtail the operation of the Presidential Order by excepting those rights from the purview of the
Order. I may add that the decision of this Court in Dhirubha Devisingh Gohil v. The State of Bombay
an authority for the proposition that if any pre Constitution right has been elevated as a
fundamental right by its incorporation in Part III, the pre-existing right and the fundamental right
arc to be considered as having been grouped together as fundamental rights "conferred" by the
Constitution. The decision in Makhan Singh v. State of Punjab also shows that once right to obtain a
direction in the nature of habeas corpus became in 1923 a statutory right to a remedy after the
enactment of Section 491 of the CrPC, it was not open to any party to ask for a writ of habeas corpus
as a matter, of common law.
486. It was contended for the respondents that the High Court have jurisdiction under Article 226 to
issue writs and directions not only for the enforcement of fundamental rights but "for any other pur
pose" and since by their petitions they had really asserted their non fundamental rights, the High
Courts had the jurisdiction to issue appropriate writs or directions upholding those rights in spite of
the Presidential Order. This argument cannot be accepted because the entire claim of the
respondents is that the order of detention are in violation of the MISA, which in substance means
that the respondents have been deprived of their personal liberty in violation of Article 21 of the
Constitution. By that Article, no person can be deprived of his life or personal liberty except
according to procedure established by law. The grievance of the respondents is that they have been
deprived of their personal liberty in violation of the procedure established or prescribed by the
MISA. In substance therefore they are complaining of the violation of a fundamental right, which it
is not open to them to do in view of the Presidential Order by which the right to move any court for
the enforcement of the right conferred by Article 21 has been suspended.
487. This judgment, long as it is, will be incomplete without at least a brief discussion of some of the
important decisions of this Court which were referred to during the course of arguments time and
again. Before doing so, a prefatory observation seems called for. The Earl of Halsbury L. C. said in
Quinn v. Leathem [1901] A. C. 495, 506 that the generality of the expressions which may be found in
a judgment are not intended to be expositions of the whole law but are governed and qualified by the
particular facts of the case in which such expressions are to be found. this Court in the State of
Orissa v. Sudhansu Sekhar Misra and Ors. uttered the caution that it is not a profitable task to
extract a sentence here and there from a judgment and to build upon it because the essence of the
decision is its ratio and not every observation found therein. Counsel have not done any such
shearing but I thought I might being the study of cases with a self-admonition.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

488. A decision of this Court on which the greatest reliance was placed by the respondents is
Makhan Singh v. State of Punjab . The appellants therein were detained under Rule 30(1)(b) of the
Defence of India Rules made by the Central Government under Section 3 of the Defence of India
Ordinance, 1962. They applied for their release to the Punjab and Bombay High Court under Section
491(1)(b) of the CrPC, their contention being that certain Section of the Defence of India Act and
Rule 30(1) (b) of the Defence of India Rules were unconstitutional since they contravened their
fundamental rights under Articles 14, 21 and 22(4) (5) and (7) of the Constitution. The High Court
held that in view of the Presidential Order which was issued on November 3, 1962 under Article
359(1) of the Constitution, the petitions of habeas corpus filed by the appellants were barred. Being
aggrieved by the orders dismissing their petitions, the detenus filed appeals in this Court which were
heard by a Constitution Bench consisting of 7 Judges. The judgment of the majority was delivered by
Ganjendragadkar J. Subba Rao J. gave a dissenting judgment.
489. Both the majority and the minority judgments agree that the Presidential Order would take
away the right to move the Supreme Court under Article 32 and the High Court under Article 226
for the enforcement of the rights mentioned in the Order. But while the majority took the view that
the petition under Section 491 of the Criminal Procedure Code was also barred, Subha Rao J. held
that the petitioners' right to ask for relief by filing an application under Section 491 was not affected
by the Presidential Order. This difference in the view of the majority and the minority is now of no
consequence as Section 491 has ceased to be on the Statute Book after April 1, 1974 when the new
CrPC came into force.
490. The conclusion of the Court in Makhan Singh's case may be summed up thus:
1. Article 359 is reasonably capable of only one construction as its language is clear
and unambiguous.
2. The suspension of Article 19 contemplated by Article 358 removes during the
pendency of the emergency the fetters created on the legislative and executive powers
by Article 19 and if the legislatures make laws or the executive commits acts which
are inconsistent with the rights guaranteed by Article 19, their validity is not open to
challenge either during the continuance of the emergency or even thereafter.
3. As soon as the Proclamation ceases to operate, the legislative enactments passed
and the executive actions taken during the course of the said emergency shall be
inoperative to the extent to which they conflict with the rights guaranteed under
Article 19 because as soon as the emergency is lifted, Article 19 which was suspended
during emergency is automatically revived and begins to operate.
4. Article 359, on the other hand, does not purport expressly to suspend any of the
fundamental rights. What the Presidential Order purports to do by virtue of the
power conferred of the President by Article 359(1) is to bar the remedy of the citizens
to move any court for the enforcement of the specified rights.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

5. The Presidential Order cannot widen the authority of the legislatures or the
executive; it merely suspends the rights to move any court to claim a relief on the
ground that the rights conferred by Part III have been contravened if the said right
are specified in the Order. If at the expiration of the Presidential Order, Parliament
passes any legislation to protect executive action taken during the pendency of the
Presidential Order and afford indemnity to the executive in that behalf, the validity
and the effect of such legislative action may have to be carefully scrutinised.
6. The words "the right to move any court" which occur in Article 359(1) refer to the
right to move any court of competent jurisdiction including both the Supreme Court
and the High Court.
7. In determining the question as to whether a particular proceeding falls within the
mischief of the Presidential Order or not, what has to be examined is not so much the
form which the proceeding has taken, or the words in which the relief is claimed, as
the substance of the matter and whether before granting the relief claimed by the
citizen it would be necessary for the Court to enquire into the question whether any
of his specified fundamental rights have been contravened. If any relief cannot be
granted to the citizen without determining the question of the alleged infringement of
the said specified fundamental rights that is a proceeding which falls under Article
359(1) and would, therefore, be hit by the Presidential Order issued under the said
Article.
8. The right to ask for a writ in the nature of habeas corpus which could once have
been treated as matter of Common Law has become a statutory right after 1923, and
after Section 491 was introduced in the Cr. P. C, it was not open to any citizen in
India to claim the writ of habeas corpus on grounds recognised by Common Law
apart from the provision of Section 491(1)(b) itself.
9. Whether or not the proceedings taken under Section 491(1) (b) fall within the
purview of the Presidential Order, must depend upon the construction of Article
359(1) and the Order, and in dealing with this point, one must look at the substance
of the matter and not its form.
10. It is true that there are two remedies open to a party whose right of personal
freedom has been infringed; he may move the Court for a writ under Article 226(1) of
Article 32(1) of the Constitution, or he may take a proceeding under Section 491(l)(b)
of the Code. But despite the fact that either of the two remedies can be adopted by a
citizen who has been detained improperly or illegally, the right which he claims is the
same if the remedy sought for is based on the ground that there has been a breach of
his fundamental rights; and that is a right guaranteed to the citizen by the
Constitution, and so, whatever is the form of the remedy adopted by the detenu, the
right which he is seeking to enforce is the same. Therefore the prohibition contained
in Article 359(1) and the Presidential Order will apply as much to proceedings underAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Section 491(1)(b) as to those under Article 226(1) & Article 32(1).
11. If the detenu is prohibited from asking for and order of release on account of the
Presidential Order, it would not be open to him to claim a mere declaration either
under Section 491 or under Articles 32 or 226 that the detention is unconstitutional
or void.
12. The right specified in Article 359(1) includes the relevant right, whether it is
statutory, constitutional or constitutionally guaranteed.
491. After recording these conclusions the majority judgment proceed to consider the question as to
Which are the pleas which are op to a person to take in challenging the legality or the propriety of 1
detention, either under Section 491 (1)(b) or under Article 226(1). T conclusions of the Court on this
question are as follows:
(a) If in challenging the validity of his detention order, the detenu is pleading any
right outside the rights specified in the Order, his right to move any court in that
behalf is not suspended, because it is outside Article 359(1) and consequently outside
the Presidential Order itself." (Emphasis supplied) Accordingly if a detenu is
detained in violation of the mandatory provisions of the Act it would be open to him
to contend that his detention is illegal. "Such a plea is outside Article 359(1) and the
right of the detenu to move for his release on such a ground cannot be affected by the
Presidential Order."
(b) The exercise of a power malafide is wholly outside the scope of the Act conferring
the power and can always be successfully challenged.
(c) It is only in regard to that class of cases falling under Section 491(1) (b) where the
legality of the detention is challenged on grounds which fall under Article 359(1) and
the Presidential Order that the bar would operate. In all other cases falling under
Section 491(1) the bar would be inapplicable and proceedings taken on behalf of the
detenu will have to be tried in accordance with law.
(d) If a detenu contends that the operative provision of the law under which he is
detained suffers from the vice of excessive delegation and is, therefore, in valid, the
plea thus raised by the detenu cannot at the threshold be said to be barred by the
Presidential Order. In terms, it is not plea which is relatable to the fundamental
rights specified in the said Order. It is a plea which is independent of the said rights
and its validity must be examined. (The Court, however, rejected the contention that
the impugned provisions of the Act suffered from the vice of excessive delegation.)
492. No judgment can be read as if it is a statute. Though the judgment of the majority contain the
conclusions set out in (a) to (d) above, I see no doubt that these conclusions owe their justification
to the peculiar wording of the Presidential Order which was issued in that case. The Order datedAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

November 3, 1962, which was the subject matter of Makhan Singh's case, has been set out at the
beginning of this judgment. That order suspends the right of a person to enforce the rights conferred
by Articles 14, 21 and 22 "if such person has been deprived of any such rights under the Defence of
India Ordinance, 1962 (4 of 1962) or any rule or order made thereunder". The Presidential Order
dated June 27, 1975 with which we are concerned in the instant case does not contain any clause
similar to the one extracted above from the order dated November 3, 1962. The inclusion of that
clause in the earlier Order has a significant impact on the question under consideration because,
under the earlier Presidential Order the right to move the court was taken away only if a person was
deprived of his rights under the Defence of India Ordinance or under any rule or order made under
the Ordinance. A petition for habeas corpus filed during the operation of the Presidential Order
dated November 3, 1962 was not barred at the threshold because the detenu was entitled to satisfy
the court that though his detention purported to be under the Defence of India Ordinance or the
Rules it was in fact not so. The detenu could establish this by satisfying the court that the detaining
authority had no power to detain him, which could be shown by pointing out that the pre-conditions
of the power to detain were not fulfilled. It was also open to the petitioner to establish that the order
was vitiated by mala fides because a mala fide order has no existence in the eye of law and mala fides
would take the order out of the statute.
493. The same state of affairs continued under the two subsequent Presidential Orders dated
November 16, 1974 and December 23, 1974. All the three orders were conditional and were
dependent for their application on the fulfilment of the condition that the person concerned was
deprived of his rights under the Defence of India Ordinance or any rule or order made under it. The
Presidential Order of June 27, 1975 makes a conscious and deliberate departure from the three
earlier orders, the object obviously being to deprive the detenu of the argument that he has been
detained under an order only purports to have been passed under a particular Act but is in fact in
derogation thereof, the terms of the Act having not been complied with. The Order of June 27, 1975
is not subject to any condition-precedent for its application and, therefore, there is no question of
the detenu satisfying the court that any pre-condition of the power of detention has not fulfilled.
Some of the observations in Makhan Singh case may appear to support the argument that certain
pleas which are referred to therein are outside the scope of Article 359(1) itself. With great respect,
those observations really mean that the pleas are outside the Presidential Order. Article 359(1) is
only an enabling provision and the validity of a plea cannot be tested with reference to that Article.
The right to move a court for the enforcement of the rights conferred by Part III is not taken away by
Article 359(1). It is the Presidential Order passed in pursuance of the powers conferred by that
Article by which such a consequence can be brought about.
494. It would be useful in this connection to refer to the decision of this Court in Dr. Ram Manohar
Lohia v. State of Bihar and Ors. . The appellant therein was also detained under Rule 30(1) (b) of the
Defence of India Rules, 1962, and he moved this Court under Article 32 of the Constitution for his
release. The petition was argued on the basis that it was filed for the enforcement of the right to
personal liberty under Articles 21 and 22 of the Constitution. A preliminary objection was raised on
behalf of the Government that the petition was barred by reason of the Presidential Order dated
November 3, 1962, the same as in Makhan Singh's case (supra) Sarkar J., who shared the majority
view repelled the preliminary objection by saying that the petition could have been dismissed at theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

threshold if the Order of November 3, 1962 were to take away all rights to personal liberty under
Articles 21 and 22. According to the learned Judge, the particular Presidential Order did not do so in
that, it was a conditional order which deprived a person of his right to move a court for the
enforcement of a right to personal liberty only if he was deprived of it by the Defence of India Act or
any rule or order made under it. "If he has not been so deprived, the Order does not take away his
right to move a court." This shows that if the first Presidential Order was unconditional like the
Order in the instant case, Dr. Lohia's petition would have been rejected by this Court at the
threshold. The judgment of Hidaya-tullah J., who on behalf of himself and Bachawat J. concurred
with the view of Sarkar J., also shows that the conditional Presidential Order left an area of inquiry
open as to whether the action was taken by a competent authority and was in accordance with the
Defence of India Act and the rules made thereunder.
495. Yet another case arose under Rule 30(1)(b) of the Defence of India Rules, 1962 involving the
interpretation of the first Presidential Order dated November 3, 1962. That case is K. Anandan
Nambkii and Anr. v. Chief Secretary, Government of Madras and Ors. Gajendra-gadkar C.J., who
delivered the judgment of the Constitution Bench referred to Makhan Singh's case and pointed out
that the sweep of the Presidential Order dated November 3, 1962 was limited by its last clause and,
therefore, it was open to the detenu to contend that the order of detention was contrary to the
conditions prescribed in that behalf by the Defence of India Act or the rules made thereunder.
496. In State of Maharashtra v. Prabhakar Pandurang Sangzgiri and Anr. the respondent, who was
detained under an order passed under Section 30(1)(b) of the Defence of India Rules, 1962, sought
permission from the State Government for publishing a book which he had written while in jail. On
the Government refusing the permission, he filed a petition under Article) 226 of the Constitution
for an appropriate direction and after that petition was allowed by the High Court, the Government
of Maharashtra filed an appeal in this Court. Subba Rao J., who delivered the judgment of the
Bench, observed while dismissing the appeal that the President's Order dated November 3, 1962 was
a conditional order and, therefore, if a person was deprived of his personal liberty not under the Act
or a rule or order made thereunder but in contravention thereof, his right to move the court in that
regard would not be suspended.
497. These judgments bring out clearly the ratio of Makhan Singh's case which arose out of the first
Presidential Order dated November 3, 1962. The Presidential Order with which we are concerned in
the instant case is not subject to the pre-condition that the detenu should have been deprived of his
rights under any particular Act and, therefore, there is no scope for the inquiry whether the order is
consistent or in conformity with any particular Act. This important distinction has not been fully
appreciated in some of the judgments under appeal.
498. The observations contained in the majority judgment in Makhan Singh's case that the exercise
of a power mala fide is wholly outside the scope of the Act conferring the power and can always be
successfully challenged at once raises the question whether in spite of the Presidential Order dated
June 27, 1975 it is open to the respondents to show that the order of detention in any particular case
is vitiated by mala fides. The proposition that a mala fide order has no existence in the eye of law is
not peculiar to Makhan Singh's case but has been accepted in various decisions of this Court, two ofAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

them being Jaichand Lall Sethia v. State of West Bengal and Ors. [1966] Supp. S. C. R. 464, and
Durgadas Shirali v. Union of India and Ors. . A mala fide exercise of power does not necessarily
imply any moral turpitude and may only mean that the statutory power is exercised for purposes
other than those for which the power was intended by law to be exercised. In view of the fact that an
unconditional Presidential Order of the present kind affects the locus standi of the petitioner to
move any court for the enforcement of any of his fundamental rights mentioned in the Order, it
would not be open to him to show that the statutory power has been exercised for a purpose other
than the one duly appointed under the law. So long as the statutory prescription can be seen on the
face of the order to have been complied with, no further inquiry is permissible as to whether the
order is vitiated by legal mala fides.
499. As regards mala fides in the sence of malice-in-fact, the same position must hold good because
the Presidential Order operates as a blanket ban on any and every judicial inquisition into the
validity of the detention order. Makhan Singh's case as also Jaichand Lall Sethia's and Durgadas
Shirali's arose under the Defence of India Rules, 1962 and the relevant Presidential Order which
applied was the one dated November 3, 1962 which, as stated above, was a conditional order. If in
any given case an order of detention appears on the very face of it to be actuated by an ulterior
motive, the court would have jurisdiction to set it aside because no judicial inquiry of any sort is
required to be undertaken in such a case. But short of such ex-facie vitiation, any challenge to a
detention order on the ground of actual mala fides is also excluded under the Presidential Order
dated June 27, 1975.
500. Section 16A(9) of the MISA which was introduced by the Third Amendment Ordinance, 16 of
1975, with effect from June 29, 1975 must make a significant difference to the question whether in
spite of the Presidential Order, it is open to a detenu to challenge his detention on the ground of
mala fides. Prior to the enactment of Section 16A(9), the detaining authority was under an
obligation by reason of Section 8(1) of the MJSA to communicate to the detenu the grounds of
detention. The only exception was as stated in Section 8(2), that the detaining authority need not
disclose facts which it considers to be against the public interest to disclose. Section 16A(1) provides
that the provisions of Section 16A shall have effect during the period of operation of Proclamation of
Emergency issued on December 3, 1971 and on June 25, 1975 or for a period of 12 months from June
25, 1975 whichever period is the shortest. By Sub-section (2) of Section 16A, the case of every person
against whom an order of detention was made under the MISA on or after June 25, 1975 but before
the commencement of Section 16A on June 29, 1975 is required to be reviewed by the appropriate
Government for the purpose of determining whether the detention of such person is necessary for
dealing effectively with the emergency. If the answer be in the affirmative, the Government is
required to make a declaration to that effect. By Sub-section (3), whenever an order of detention is
made under the Act after June 29, 1975 the officer making the order of" detention or the appropriate
Government is similarly required to consider whether the detention of the persons is necessary for
dealing effectively with the emergency. If so, a declaration is required to be made to that effect.
Sub-section (9) (a) of Section 16A provides that the grounds on which an order of detention is made
against any person in respect of whom a declaration is made under Sub-section (2) or Sub-section
(3) of Section 16A and any information or materials on which such grounds are based "shall be
treated as confidential and shall be deemed to refer to matters of State and to be against the publicAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

interest to disclose and save as otherwise provided in this Act. no one shall communicate or disclose
any such grounds, information or material or any document containing such ground, information or
material." Clause (b) of Section 16A (9) provides that no person against whom an order of detention
is made under Sub-section (1) of Section 3 shall be entitled to the communication or disclosure of
any such ground, information or material, as is referred to in Clause (a) or the production to him of
any document containing such ground, information or material.
501. I will deal with the constitutionality of Section 16A(9) later but on the assumption that it is
valid, it is plain that not only is a detenu in regard to whom the necessary declaration is made not
entitled to be furnished with the grounds of detention or the material or information on which the
grounds are based, but neither the Government nor the officer passing the order of detention can
communicate or disclose the grounds, material or information since they are deemed to refer to
matters of State and against the public interest to disclose. In view of this cast-iron prohibition, it is
difficult to see how, at least those detenus falling within Sub-sections (2) and (3) of Section 16A can
possibly establish, even prim a facie a charge of factual mala fides. It is the grounds of detention
from which generally a plea of mala fides is spelt out and if the court has access to the grounds, the
material and the information, it becomes possible to unravel the real motive of detention. In the
absence of these aids, a charge of factual mala fides can only be a fling in the air and cannot hope to
succeed. The observation in Makhan Singh's case, therefore, that the exercise of a power mala fide
can always be successfully challenged would not apply to cases falling under Sub-sections (2) and
(3) of Section 16A. by reason of the provisions contained in Sub-section (9) of that Section .
502. Turning to the constitutional validity of Section 16A(9), the contention of the respondents is
that Clause (a) of Section 16A(9) by which the grounds of detention and the information and
materials on which the grounds are based shall be treated as confidential and shall be deemed to
refer to matters of State and to be against the public interest to disclose is not a genuine rule of
evidence but is designed to encroach upon the jurisdiction of the High Courts under Article 226 of
the Constitution and is, therefore, void. It is urged that the amendment made by the Parliament in
the exercise of its ordinary legislative power comes into direct conflict with the High Court's
jurisdiction under Article 226 because it would be impossible for any High Court to consider the
validity of an order of detention when a petition for habeas corpus comes before it, if the law
prohibits the disclosure of the grounds of detention and the necessary information or materials to
the High Court.
503. It is a relevant consideration for examining the charge that the true purpose of Section 16A(9)
is to encroach on the powers of the High Court under Article 226, that the operation of Section 16A
itself is limited to the period during which the two proclamations of emergency dated December 3,
1971 and June 25, 1975 are in operation or for a period of 12 months from. June 25, 1975 whichever
period is the shortest. Following the proclamations of emergency, the President has issued orders
under Article 359(1). By the order dated June 27, 1975 the vary locus standi of the detenu to enforce
any of his fundamental rights mentioned in the Presidential Order is taken away and consequently,
there is no matter of substance into which the High Courts in the exercise of their writ jurisdiction
can legitimately inquire. The injunction contained in Section 16A(9) is from this point of view
innocuous, for it purports to create a check on a power which for all practical purposes has but aAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

formal existence. Section 16A(9) is in aid of the constitutional power conferred by Article 359(1) and
further effectuates the purpose of the Presidential Order issued under that Article. If so it cannot be
declared unconstitutional.
504. Quite apart from this position, I am unable to agree that the rule enunciated in Section 16A(9)
is not a genuine rule of evidence. It is true that grounds of detention used to be disclosed before the
emergence of Section 16A(9) but that does not mean that the grounds on which the order of
detention is based or the information or materials on which the grounds are based are not or cannot
be of a confidential nature. More likely than not, such grounds, material and information would be
of a confidential nature relating to matters of State which would be against the public interest to
disclose. Instead of leaving each individual matter to be judged under Section 123 of the Evidence
Act by the Head of the Department concerned, who can give or withhold the permission as he thinks
fit, Parliament would appear to have considered that since the grounds, material and information in
detention cases are of a confidential nature, it would be much more satisfactory to provide that they
shall be deemed to refer to matters of State.
505. If Section 16A(9) is unconstitutional so would Sections 123, 124 and 162 of the Evidence Act.
Section 123 gives the necessary discretion to the Head of the Department concerned. By reason of
Section 124, the High Court cannot compel any public officer to disclose communications made to
him in official confidence if the ' officer considers that the public interest would suffer by the
disclosure. By Section 162, the High Court cannot inspect a document if it refers to matters of State.
But these provisions do not constitute an invasion of the High Court's jurisdiction under Article 226.
The writ jurisdiction of the High Court under that Article has to be exercised consistently with the
laws made by competent legislatures within the area of their legislative power. I do not think that it
is open to any High Court to say that the law may be otherwise valid but since it interferes with the
High Court's power to undertake the fullest enquiry into the matter before it, the law becomes
unconstitutional. The principles of res judicata and estoppel, the conclusive presumptions of law
and various provisions of substantive law deny a free play to courts in the exercise of their
jurisdiction. These are not for that reason unconstitutional qua the High Court's jurisdiction under
Article 226.
506. Counsel for the respondents cited the parallel of Section 14 of the Preventive Detention Act,
1950 which was struck down by this Court in A. K. Gupalan v. The State [1950] S. C. R. 88.
Sub-section (1) of that Section provided, in substance, that no court shall, except for certain
purposes, allow any statement to be made or any evidence to be given before it of the substance of
any communication of the grounds on which a detention order was made against any person or of
any representation made by him. Sub-section (2) of Section 14 made it an offence for any person to
disclose or publish without the previous authorization of the Government any contents or matter
purporting to be contents of any communication or representation referred to in Sub-section (1).
The right to enforce Article 22 of the Constitution was not suspended by any Presidential Order
when Gopalan's case was decided and therefore the court was entitled to find whether that Article
was emplaced with. The limits of judicial review have to be co-extensive and commensurate with the
right of an aggrieved person to complain of the invasion of his rights. Since in Gopalan's case, it was
open to the detenu to contend that the grounds of detention did not bear any connection with theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

order of detention, the Court was entitled to examine the grounds in order to determine whether the
plea of the detenu was well-founded. As Section 14 debarred the court from examining the material
which it was entitled under the Constitution to examine, it was declared ultra vires. (See pages
130-131, 217-218, 244, 285 and 333). In the instant case the Presidential Order deprives the
respondents of their very locus standi and therefore, Section 16A(9) cannot be said to shut out an
inquiry which is other wise within the jurisdiction of the High Court to make.
507. Reliance was also placed by the respondents on the decision of this Court in Mohd. Maqbool
Damnoo v. State of Jammu and Kashmir [1972] 2 S. C. R. 1014 in which it was observed that the
proviso to Section 8, which was inserted by the Jammu and Kashmir Preventive Dentention
(Amendment) Act, 1967, would have been unconstitutional if it had the same effect as Section 14 of
the Preventive Detention Act was found to have in Gopalan's case Damnoo's case did not involve any
question of privilege at all and in fact the relevant file was produced by the Government for the
perusal of the High Court. The case also did not involve any question under Article 359(1) and the
effect of a provision like Section 16A(9) was not even hypothetically considered by the Court.
508. The view of the Bombay High Court that Section 16A(9) may be read down so as to enable the
court to examine the forbidden material is impossible to sustain. What use can a court make of
material which it cannot disclose to the detenu and how can it form a judicial opinion on matters not
disclosed to a party before it? The High Court, at the highest, could satisfy its curiosity by tasting the
forbidden fruit but its secret scrutiny of the grounds and of the file containing the relevant
information and material cannot enter into its judicial verdict.
509. I am, therefore, of the opinion that the challenge made by the respondents to the
constitutionality of Section 16A(9) must fail.
510. Section 18 need not detain me long because it merely declares that no person who is detained
under the Act shall have any right to personal liberty by virtue of natural law or common law, if any.
The 'natural law' theory was discarded in Kesavananda Bharati's case [1973] Supp. S. C. R. 1 and
likewise the common law theory was rejected in Makhan Singh's case. The Section only declares
what was the true law prior to its enactment on June 25. 1975. The amendment of Section 18 by the
substitution of the words "in respect or whom an order is made on purported to be made under
Section 3" in place of the words "detained under this Act" does not render the Section open to a
challenge on the ground of excessive delegation. The words "purported to be made" have been
inserted in order to obviate the challenge that the detention is not in strict conformity with the
MISA. Such a challenge is even otherwsie barred under the Presidential Order. The object of the
added provision is not to encourage the passing of lawless orders of detention but to protect during
emergency orders which may happen to be in less than absolute conformity with the MISA. The
executive is bound at all times to obey the mandate of the legislature but the Presidential Order bars
during a certain period the right to complain of any deviation from that rule.
511. In numerous cases detenus have been released by this Court and by the High Courts on the
ground that there is no nexus between the grounds of detention and the object of the law under
which the order of detention is made or that the acts complained of are too distant in point of timeAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

to raise an apprehension that the past conduct of the detenu is likely to project itself into the future
or that the grounds are too vague for the formation even of subjective satisfaction or that irrelevant
and extraneous considerations have materially influenced the mind of the detaining authority. On
some few occasions detention orders have also been set aside on the ground of factual mala fides. An
unconditional Presidential Order obliterates (his jurisprudence by striking at the very root of the
matter. Locus of the detenu is its chosen target and it deprives him of his legal capacity to move any
court for the vindication of his rights to the extent that they are mentioned in the Presidential Order.
In their passion for personal liberty courts had evolved, carefully and laboriously, a sort of
"detention jurisprudence" over the years with the sole object of ensuring that the executive does not
transcend its duty under the law. In legal theory that obligation still remains but its violation will
now furnish no cause of action, at least to an extent, and to a significant extent. Amidst the clash of
arms and conflict of ideologies, laws will now be silent but in times when the Nation is believed to be
going through great strains and stresses, it may be necessary to entrust sweeping powers to the
State. And it is no small comfort that those powers are granted with the consent of the Parliament.
The people of this country are entitled to expect when they go to the ballot-box that their chosen
representatives will not willingly suffer an erosion of the rights of the people. And the Parliament,
while arming the executive with great and vast powers of Government, may feel fairly certain that
such powers will be reasonably exercised. The periodical reviews of detention orders. the checks and
counter-checks which the law provides and above all the lofty faith in democracy which ushered the
birth of the Nation will, I hope, eliminate all fear that great powers are capable of the greatest abuse.
Ultimately, the object of depriving a few of their liberty for a temporary period has to be to give to
many the perennial fruits of freedom.
512. I find it not so easy to summarize my conclusions in simple, straightforward sentences. The
many-sided issues arising before us do not admit of a monosyllabic answer--'yes', or 'no'. All the
same these broadly are my conclusions :
(1) The Order issued by the President on June 27, 1975 under Article 359(1) of the
Constitution docs not suspend the fundamental principle that all executive action
must have the authority of law to support it.. Nor does the Presidential Order give to
the executive a charter to disobey the laws made by the Parliament, which is the
supreme law-making authority.
(2) The aforesaid Presidential Order, however, deprives a person of his locus standi
to move any court, be it the Supreme Court or the High Court, for the en forcemeat of
his fundamental rights which are mentioned in the Order. Such deprivation or
suspension ensures during the period that the Proclamation of Emergency is in force
or for such shorter period as may be specified in the Order.
(3) The dominant purpose of the petitions filed by the respondents in the High
Courts is to obtain an order of release from detention by enforcing the right to
personal liberty. The purpose is not to obtain a mere declaration that the order of
detention is ultra vires the Act under which it is passed. The former plea is barred by
reason of the Presidential Order. The latter plea is also barred because regard mustAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

be had to the substance of the matter and not to the form in which the relief is asked
for.
(4) The Presidential Order dated June 27, 1975 bars any investigation or inquiry into
the question whether the order of detention is vitiated by mala fides, factual or legal,
or whether it is based on extraneous considerations or whether the detaining
authority had reached his subjective satisfaction validly on proper and relevant
material.
(5) Whether or not Article 21 of the Constitution is the sole repository of the right to
personal liberty, in a petition filed in the High Court under Article 226 of the
Constitution for the release of a person de tainted under the MISA, no relief by way of
releasing the detenu can be granted because no person has the legal capacity to move
any court to ask for such relief. The Presidential Order takes away such legal capacity
by including Article 21 within it. The source of the right to personal liberty is
immaterial because the words" "conferred by" which occur in Article 359(1) and in
the Presidential Order are not words of limitation.
(6) The Presidential Order does not bring about any amendment of Article 226 and is
not open to challenge on that ground.
(7) The Presidential Order neither bars the right of an accused to defend his personal
liberty in the court of first instance or in a higher court, nor does it bar the execution
of decrees passed against the Government, nor does it bar the grant of relief other or
less than the release of the detenu from detention.
(8) Section 16A(9) of the MISA is not unconstitutional on the ground that it
constitutes an encroachment on the writ jurisdiction of the High Court under Article
226. There is no warrant for reading down that Section so as to allow the court to
inspect the relevant files to the exclusion of all other parties.
(9) Section 18 of the MISA does not suffer from the vice of excessive delegation and is
a valid piece of legislation.
513. And so we go back to The Zamora [1916] 2 A. C. 77, Rex v. Halliday [1917] A. C. 260, 271,
Liversidge v. Anderson [1942] A. C. 206, Greene v. Secretary of State [1942] A. C. 284. A jurisdiction
of suspicion is not a forum for objectivity; "Those who are responsible for national security must be
the sole judges of what the national security requires"; "However precious the personal liberty of the
subject may be, there is something for which it may well be, to some extent, scarified by legal
enactment, namely, national success in the war, or escape from national plunder or enslavement".
As a result, perhaps the only argument which the court can entertain is whether the authority which
passed the order of detention is duly empowered to pass it, whether the detenu is properly identified
and whether on the face of the order the stated purpose of detention is within the terms of law.
These questions, in almost all cases, will have an obvious answer.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

514. Counsel after counsel expressed the fear that during the emergency, the executive may whip
and strip and starve the detenu and if this be our judgment, even shoot him down. Such misdeeds
have not tarnished the record of Free India and I have a diamond-bright, diamond-hard hope that
such things will never come to pass.
P.N. Bhagwati, J.
515. These appeals by special leave raise issues of gravest constitutional importance. They affect
personal liberty which is one of our most cherished freedoms and impinge on the rule of law which
is one of the great principles that lies at the core of constitutional democracy and gives content to it.
Does a Presidential Order under Article 359, Clause (1) specifying Article 21 silence the mandate of
the law and take away personal liberty by making it unenforceable in a court of law, or does judicial
scrutiny of legality of detention stand untouched and unimpaired, so that, despite such Presidential
Order, a person who is illegally detained can seek his freedom by invoking the judicial process. That
is the agonizing question before the Court.
516. The facts giving rise to these appeals have been fully set out in the judgment of my Lord the
Chief Justice and it is not necessary for me to reiterate them as nothing turns on the facts. None of
the writ petitions out of which these appeals arise has in fact been finally disposed of on merits.
Barring the writ petitions before the Rajasthan High Court and the Nagpur Bench of the Bombay
High Court, where one additional question has been considered, the only question that has been
decided in these writ petitions is as to their maintainability in view of the Presidential Order dated
27th June, 1975 issued under Article 359, Clause (1) of the Constitution. The High Courts of
Allahabad, Madhya Pradesh, Andhra Pradesh, Delhi, Karnataka and Rajasthan and the Nagpur
Bench of the Bombay High Court before whom these writ petitions were heard on the preliminary
issue as to maintainability, took the view that the Presidential Order, dated 27th June, 1975, did not
wholly bar the maintainability of these petitions, but left open certain grounds of challenge which
could yet be urged against the validity of the order of detention. These different High Courts were
not agreed upon what were the grounds of challenge which were thus available to an applicant
despite the Presidential Order dated 27th June, 1975. There were differences of opinion amongst
them, but for the purpose of the present appeals, it is not necessary to refer to those differences as
they are not material. The Rajasthan High Court and the Nagpur Bench of the Bombay High Court
also considered the interpretation and validity of Section 16A, Sub-section (9) of the Maintenance of
Internal Security Act, 1971 and while the Rajasthan High Court accepted the interpretation of that
Sub-section canvassed on behalf of the Government and upheld its validity even on that
interpretation, the Nagpur Bench of the Bombay High Court held the Sub-section to be valid by
reading it down so as not to exclude the power of the High Court under Article 226 of the
Constitution to call for the grounds, information and materials on which the order of detention was
based. Since in the view of these High Courts, the writ petitions filed by the detenus were
maintainable, though on certain limited grounds of challenge, each of the writ petitions was directed
to be set down for hearing on merits. Thereupon each of the aggrieved State Governments obtained
special leave to appeal against the decision of the concerned High Court and that is how the present
appeals have come before this Court.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

517. Two questions arise for consideration in these appeals. They have been formulated by the
learned Attorney General appearing on behalf of the Union of India in the following terms :
(1) Whether, in view of the Presidential Order dated June 27, 1975 under Clause (1) of
Article 359, any writ petition under Article 226 before a High Court for habeas corpus
to enforce the right to personal liberty of a person detained under MISA on the
ground that the order of detention or the continued detention is for any reason, not
under or in compliance with MISA is maintainable ?
(2) If such a petition is maintainable, what is the scope or extent of judicial scrutiny,
particularly, in view of the said Presidential Order mentioning, inter alia, Clause (5)
of Article 22 and also in view of Sub-section (9) of Section 16A of MISA?
So far as the second question is concerned, it may be pointed out straightaway that the learned
Attorney General with his usual candor conceded that if his first contention in regard to
maintainability of a writ petition for habeas corpus is not accepted and the writ petition is held
maintainable, the area of judicial scrutiny would remain the same as laid down in the decisions of
this Court, subject only to the qualification that the grounds, information and materials, on which
the order of detention is based, would not be available either to the detenu or to the High Court by
reason of suspension of enforcement of the right conferred by Clause (5) of Article 22 and the
enactment of Section 16A, Sub-section (9) of the Maintenance of Internal Security Act, 1971. The
only point which would, therefore, require to be considered under the second question is in regard
to the interpretation and validity of Sub-section (9) of Section 16A.
518. Before we proceed to consider the first question which turns on the true interpretation and
effect of the Presidential Order dated 27th June, 1975, it would help to place the problem in its
proper perspective if we first examine what is an emergency and how institutions and procedures
different from those in normal times are necessary to combat it. It would be both profitable and
necessary to embark upon this inquiry, because Article 359, Clause (1) under which the Presidential
Order dated 27th June, 1975 has been issued is a consequential provision which comes into
operation when a Proclamation of Emergency is issued by the President under Article 352. It is
evident that a national emergency creates problems for a democracy no less than for other
governments. A totalitarian Government may handle such a situation without embarrassment. But
the apparent necessities evoked by danger often conflict gravely with the postulates of constitutional
democracy. The question arises--and that was a question posed by Abraham Lincoln on July 4, 1861
: can a democ ratio constitutional government beset by a national emergency be strong enough to
maintain its own existence without at the same time being so strong as to subvert the liberties of the
people it has been instituted to defend. This question is answered affirmatively by the incontestable
facts of history if we have regard to the experience of emergency governments of three large modern
democracies--the United States, Great Britain and France. There is no reason why the Indian
experience should be otherwise, if the basic norms of constitutionalism in assumption of emergency
powers are observed. What are these basic norms in a constitutional democracy and what is the
purpose behind assumption of emergency powers are matters which I shall presently discuss. But
before I do so, let me first consider what are the different types of emergency which may plague theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

government of a country.
519. There are three types of crisis in the life of a democratic nation, three well defined threats to its
existence both as nation and democracy. The first of these is war, particularly a war to repel invasion
when "a State must convert its peace-time political and social order into a war-time fighting
machine and over-match the skill and efficiency of the enemy". There may be actual war or threat of
war or preparations to meet imminent occurrence of war, all of which may create a crisis situation of
the gravest order. The necessity of concentration of greater powers in the Government and of
contraction of the normal political and social liberties cannot be disputed in such a case, particularly
when the people are faced with a grim horror of national enslavement. The second crisis is threat or
presence of internal subversion calculated to disrupt the life of the country and jeopardize the
existing of the constitutional government. Such activity may stem from a variety of causes. Perhaps
the most common is disloyalty to the existing form of government, often accompanied by a desire to
effect changes by violent means. Another cause may be strong disaffection with certain government
policies. Communal demands for States within the Federal on linguistic or religious lines may fall
within this category. Or the presence of powerful lawless elements with perhaps no political
motivation, but for various reasons beyond the scope of ordinary machinery of the law, may give rise
to this problem. The third crisis, one recognised particularly in modern times as sanctioning
emergency action by constitutional government, is break down or potential break down of the
economy. It must be recognised that an economic crisis is as direct a threat to a nation's continuing
constitutional existence as a war or internal subversion. These are three kinds of emergencies which
may ordinarily imperil the existence of a constitutional democracy.
520. Now, it is obvious that the complex system of government of a constitutional democratic State
is essentially designed to function under normal peaceful conditions and is often unequal to the
exigencies of a national crisis. When there is an emergency arising out of a national crisis, a
constitutional democratic government has to be temporarily altered to whatever degree necessary to
overcome the peril and restore normal conditions. This alteration invariably involves government of
a stronger character. The government has to assume larger powers in order to meet the crisis
situation and that means that the people would have fewer rights. There can be no doubt that crisis
government means strong and arbitrary government and as pointed out by Cecil Carr in his Article
on "Crisis Legislation in Great Britain" published during the Second World War "in the eternal
dispute between Government and liberty, crisis means more government and less liberty." In fact
Scrutton, L.J. never a fulsome admirer of government departments, made the classic remark in his
judgment in Ronnfeldt v. Phillips 35 Times Law Reports 46 that war cannot be carried on according
to the principles of Magna Carta and there must be some modification of the liberty of the subject in
the interests of the State, The maxim salus populi suprema lex esto, that is public safety is the
highest law of all, must prevail in times of crisis and the people must submit to temporary
abdication of their constitutional liberties in order to enable the government to combat the crisis
situation which might otherwise destroy the continued existence of the nation.
521. While dealing with the emergency powers which may be assumed by a constitutional
democracy to deal effectively with a national crisis, it is necessary to refer to the celebrated writ of
habeas corpus. It is the most renowned contribution of the English common law to the protection ofAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

human liberty. It is one of the most ancient writs known to the Common Law of England. It is a writ
of immemorial antiquity "throwing its roots deep into the genius" of the Common Law. It is not
necessary to trace the early history of this writ which is to be found in the decision of this Court in
Kanu Sanyal v. District Magistrate, Darjeeling and Ors. [9731] 2 S. C. C. 674. Suffice it to state that
by the 17th Century this writ had assumed great constitutional importance as a device for impugning
the validity of arbitrary imprisonment by the executive and by invoking it, a person unlawfully
imprisoned could secure his release. As pointed out by Holdsworth in Vol. 1 of his "History of
English Law", "its position as the most efficient protector of the liberty of the subject was
unquestioned after the great Rebellion". It was for this reason that men began to assign as its direct
ancestor the clauses of the Magna Carta which prohibited imprisonment without due process of law.
This may not be strictly accurate, but there can be no doubt that, far more effective than any other
remedy, this writ helped to vindicate the right of freedom guaranteed by the famous words of the
Magna Carta. The decision in Darnel's case (1627) 3 ST 1 was a set-back in the struggle for liberty
since it eroded to some extent the effectiveness of the writ by taking the view that a return that the
arrest was "by the special command of the King" was a good and sufficient return to the writ, which
meant that a lawful cause of imprisonment was shown. But the Petition of Right, 1627 overruled this
decision by declaring such a case of imprisonment to be unlawful. In the same way, it was enacted in
the Habeas Corpus Act, 1640 abolishing the Star Chamber that any person committed or imprisoned
by order of the Star Chamber or similar bodies or by the command of the King or of the Council
should have his habeas corpus. There were also various other defects which were revealed in course
of time and with a view to remedying those defects and making the writ more efficient as an
instrument of securing the liberty of the subject unlawfully detained, reforms were introduced by
the Habeas Corpus Act, 1679, and when even these reforms were found insufficient, the Habeas
Corpus Act, 1816 was enacted by which the benefit of the provisions of the Habeas Corpus Act, 1679
was made available in cases of civil detention and the judges were empowered to inquire into the
truth of the facts set out in the return to the writ. The machinery of the writ was thus perfected by
legislation and it became one of the most important safeguards of the liberty of the subject and, as
pointed out by Lord Halsbury, L.C., in Cox v. Hakes [1890] 15 A. C. 506 it has throughout "been
jealously maintained by courts of law as a check upon the illegal usurpation of power by the
executive at the cost of the liege".
522. Now, in the United States of America, the right to this important writ of habeas corpus by
means of which the liberty of a citizen is protected against arbitrary arrest, is not expressly declared
in the Constitution, but it is recognised in Article I, Placitum 9, Clause (2) of the Constitution which
declares that "The privilege of the writ of habeas corpus shall not be suspended, unless, when in
cases of rebellion or invasion, the public safety may require it". Cooley in his "General Principles of
Constitutional Law in the U.S.A." points out : "The privilege of the writ consists in this : that, when
one complains that he is unlawfully imprisoned or deprived of his liberty, he shall be brought
without delay before the proper court or magistrate for an examination into the cause of his
detention, and shall be discharged if the detention is found to be unwarranted. The suspension of
the privilege consists in taking away this right to an immediate hearing and discharge, and in
authorising arrests and detentions without regular process of law." The suspension of the privilege
of the writ does not legalise what is done while it continues : it merely suspends for the time being
the remedy of the writ.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

523. The decision of Chief Justice Taney in ex P. Merryman 17 Fed. Cas. 144 (C. C. D. Md. 1861)
contains the leading American discussion of the suspension of the writ of [habeas corpus in a
temporary emergency. In the spring of 1861, the eve of the American Civil War, President Lincoln
was confronted by a state of open insurrection in the State of Maryland following the fall of Fort
Sumter on April 15. Railroad communication to the northern United States had been severed by the
Marylanders on April 20 and the Sixth Massachusetts Militia reached Washington only after
fighting its way through the City of Baltimore. In these circumstances and under the increasing
threat of secession, President Lincoln issued a Proclamation on April 27 authorising General
Penfield Scot to suspend the writ of habeas corpus "at any point on or in the vicinity of the military
line which is now, or shall be used between the City of Philadelphia and the City of Washington".
Another Proclamation of July 2 extended this power to a similar area between Washington and New
York. John Merryman who was a Marylander openly recruited a company of soldiers to serve in the
Confederate Army and became their drill master and in consequence he was arrested by the army of
Lincoln and held prisoner in Fort McHenry. He applied for a writ of habeas corpus and, despite the
Presidential authorisation suspending the writ, the Supreme Court presided over by Chief Justice
Taney granted the writ on the view that the power to suspend the privilege of the writ is a legislative
power and the President cannot exercise it except as authorised by law. History tells us that
President Lincoln declined to implement the order of the Supreme Court and this would have led to
a major constitutional crisis, but the Congress hastened to resolve the controversy by enacting
legislation authorising the President to suspend the privilege of the writ whenever in his judgment
the public safety requires it. It would, therefore, be seen that even in United States of America,
where personal liberty is regarded as one of the most prized possessions of man, the Congress has
the power to suspend the writ of habeas corpus and this power has been exercised in the past,
though very sparingly.
524. So also in Great Britain the writ of habeas corpus which, as May points out, "is unquestionably
the first security of liberty" and which "protects the subject from unfounded suspicions, from
aggressions of power" has been suspended, again and again, in periods of public danger or
apprehension. Parliament, convinced of the exigencies of the situation, has on several occasions
suspended, for the time being, the rights of individuals in the interests of the State. This of course
has had the effect of arming the executive with arbitrary power of arrest by making it impossible for
a person detained to secure his release even if his detention is illegal. It has resulted in great
diminution in the security of personal freedom, for, suspension of habeas corpus is verily, in
substance and effect, suspension of the right of personal liberty granted in Magna Carta, But it has
been justified on the ground that whatever be the temporary danger of placing such power in the
hands of the Government, it is far less than the danger with which the Constitution and the society
are threatened, or to put it differently "when danger is imminent, the liberty of the subject must be
sacrificed to the paramount interests of the State". Moreover, on each occasion when the writ of
habeas corpus has been suspended, the suspension of the writ has invariably been followed by an
Act of Indemnity "in order to protect officials concerned from the consequences of any incidental
illegal acts which they might have committed under cover of suspension of the propogative writ".
During the period of emergency, many illegalities might have been committed by the executive in
order to deal with a crisis situation and all such illegalities have been retrospectively legalised by an
Indemnity Act.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

525. I may now turn to consider the emergency provisions under our Constitution. Unlike many of
the older constitutions, our Constitution speaks in detail on the subject of emergency in Part XVIII.
That Part consists of a fascicules of Articles from Article 352 to Article 360. Article 352 enacts that if
the President is satisfied that a grave emergency exists whereby the security of India or of any part
of the territory thereof is threatened, whether by war or external aggression or internal disturbance,
he may, by Proclamation, make a declaration1 to that effect and such Proclamation is required to be
laid before each House of Parliament and approved by resolutions of both Houses before the
expiration of two months. It is not necessary that there should be actual occurrence of war or
external aggression or internal disturbance in order to justify a Proclamation of Emergency. It is
enough if there is imminent danger of any such crisis. It will be seen that this Article provides for
emergencies of the first two types mentioned above. The third type of emergency threatening the
financial stability of India or any part thereof is dealt with in Article 360 but we are not concerned
with it and hence it is not necessary to consider the provisions of that Article. So far as the
emergencies of the first two types are concerned, the constitutional implications of a declaration of
emergency under Article 352 are much wider than in the United States or Great Britain. These are
provided for in the Constitution itself. In the first place, Article 250 provides that while a
Proclamation of Emergency is in operation, Parliament shall have the power to make laws for the
whole or any part of the territory of India with respect to any of the matters enumerated in the State
List, which means that the federal structure based on separation of powers is put out of action for
the time being. Secondly, Article 353 declares that during the time that Proclamation of Emergency
is in force, the executive power of the Union of India shall extend to the giving of direction to any
State as to the manner in which the executive power thereof is to be exercised and this provision also
derogates from the federal principle which forms the basis of the Constitution. If there is
non-compliance by any State with the directions given by the Union under Article 353, such
non-compliance may attract the provisions of Article 356 and 'President's rule' may be imposed
under that Article and in such event, Parliament may. under Article 357, Clause (1), confer on the
President the power of the legislature of the State to make laws or to delegate such legislative power
to any other authority. This not only contradicts the federal principle, but also strikes at the root of
representative form of government. Then there are two Articles, Article 358 and Article 359, which
set out certain important consequences of Proclamation of Emergency and they read as follows :
358. While a Proclamation of Emergency is in operation, nothing in Article 19 shall
restrict the power of the State as defined in Part III to make any law or to take any
executive action which the State would but for the provisions contained in that Part
be competent to make or to take, but any law so made shall, to the extent of the
incompetency, cease to have effect as soon as the Proclamation ceases to operate,
except as respects things done or omitted to be done before the law so ceases to have
effect.
359. (1) Where a Proclamation of Emergency is in opera-tion, the President may by
order declare that the right to move any court for the enforcement of such of the
rights conferred by Part III as may be mentioned in the order and all proceedings
pending in any court for the enforcement of the rights so mentioned shall remain
suspended for the period during which the proclamation is in force or for suchAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

shorter period as may be specified in the order.
(1A) While an order made under Clause (1) mentioning any of the rights conferred by Part III is in
operation, nothing in that Part conferring those rights shall restrict the power of the State as defined
in the said Part to make any law or to take any executive action which the State would but for the
provisions contained in that Part be competent to make or to take, but any law so made shall, to the
extent of the in competency, cease to have effect as soon as the order aforesaid ceases to operate,
except as respects things done or omitted to be done before the law so ceases to have effect.
(2) An order made as aforesaid may extend to the whole or any part of the territory of India.
(3) Every order made under Clause (1) shall, as soon as may be after it is made, be laid before each
House of Parliament.
526. It may be pointed out that Clause (1A) did not form part of Article 359 when the Constitution
was originally enacted but it was introduced with retrospective effect by the Constitution
(Thirty-eighth Amendment) Act, 1975. We are not directly concerned in these appeals with the
interpretation of Article 358 and Clause (1A) of Article 359, but in order to arrive at the proper
meaning and effect of Clause (1) of Article 359, it will be relevant and somewhat useful to compare
and contrast the provisions of Article 358 and Clause (1A) of Article 359 on the one hand and Clause
(1) of Article 359 on the other.
527. It would be convenient at this stage to set out the various steps taken by the Government of
India from time to time in exercise of the emergency powers conferred under Part XVIII of the
Constitution. When hostilities broke out with Pakistan in the beginning of December 1971, the
President issued a Proclamation of Emergency dated 3rd December, 1971 in exercise of the powers
conferred under Clause (1) of Article 352 declaring that "a grave emergency exists whereby the
security of India is threatened by external aggression". This was followed by two orders, one dated
5th December, 1971 and the other dated 23rd December, 1974, issued by the President under Clause
(1) of Article 359. It is not necessary to reproduce the terms of these two Presidential Orders since
they were subsequently rescinded by a Presidential Order dated 25th December, 1975 issued under
clause d) of Article 359. Whilst the first Proclamation of Emergency dated 3rd December, 1971 based
on threat of external aggression continued in force, the President issued another Proclamation of
Emergency dated 25th June, 1975 declaring that "a grave emergency exists whereby the security of
India is threatened by internal disturbance". This Proclamation of Emergency was also issued in
exercise of the powers conferred under Article 352, Clause (1) and it was followed by a fresh
Presidential Order dated 27th June, 1975 under Clause (1) of Article 359. The President, by this
Order made under Clause (1) of Article 359, declared that "the right of any person, (including a
foreigner) to move any court for the enforcement of the rights conferred by Article 14, Article 21 and
Article 22 of the Constitution and all proceedings pending in any court for the enforcement of the
above mentioned rights shall remain suspended for the period during which the Proclamations of
Emergency made under Clause (1) of Article 352 of the Constitution on the 3rd December, 1971 and
on the 25th June, 1975 are both in force". The writ petitions out of which the present appeals arise
were filed after the issue of this Presidential Order and it was on the basis of this Presidential OrderAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

that it was contended on behalf of the State Governments and the Union of India that the writ
petitions were not maintainable, since, by moving the writ petitions, the detenus sought
enforcement of the right of conferred by Article 21. This contention was substantially negatived by
the High Courts and hence the present appeals were brought by the State Governments and the
Union of India raising the same contention as to the maintainability of the writ petitions. It may be
pointed out that whilst the present appeals were pending before this Court, the President issued
another Order dated 8th January, 1976 under Clause (1) of Article 359 suspending the enforcement
of the rights conferred by Article 19. This Presidential Order is not material, but I have referred to it
merely for the sake of completeness.
528. Now the orders of detention challenged by the detenus in the different writ petitions were all
expressed to be made in exercise of the powers conferred by Section 3 of the Maintenance of
Internal Security Act, 1971. The detenus challenged them on various grounds, namely, the orders of
detention were not in accordance with the provisions of the Act, they were not preceded by the
requisite subjective satisfaction which constitutes the foundation for the making of a valid order of.
detention, they were actuated by malice in law or malice in fact or they were outside the authority
conferred by the Act. The substance of these grounds, according to the Union of India and the State
Governments, was that, by these orders of detention, the detenus, were deprived of their personal
liberty otherwise than in accordance with the procedure established by law. This constituted
infraction of the fundamental right conferred by Article 21 and the writ petitions of the detenus
were, therefore, clearly proceedings for enforcement of that fundamental right. But by reason of the
Presidential Order dated 27th June, 1975, the right to move any court for enforcement of the
fundamental right conferred by Article 21 was suspended during the period when the Proclamations
of Emergency dated 3rd December, 1971 and 25th June, 1975 were in force and, therefore, the
detenus had no locus standi to file the writ petitions and the writ petitions were barred. The answer
to this contention given on behalf of the detenus was--and here we are setting out only the broad
general argument--that Article 21 merely defines an area of free action and does not confer any right
and hence it is outside the scope and ambit of Article 359, Clause (1) and consequently outside the
Presidential Order itself. It was also urged on behalf of the detenus that it is a basic principle of the
rule of law that no member of the executive can interfere with the liberty of a person except in
accordance with law. The principle of the rule of law was recognised and declared by the Judicial
Committee of the Privy Council in Eshugbayi Eleko v. Officer Administering the Government of
Nigeria [1931] A. C. 662 and it was uniformly administered by courts in India as the law of the land
prior to the coming into force of the Constitution. It was consequently law in for in the territory of
India immediately before the commencement of the Constitution and by reason of Article 372, it
continued in force ever after the coming into force of the Constitution and since then it has been
repeatedly recognised and adopted by this Court as part of Indian jurisprudence in several decided
cases. Moreover, apart from being continued under Article 372 as law in force, this principle of the
rule of law stems from the constitutional scheme itself which is based on the doctrine of distribution
of powers amongst different bodies created by the Constitution. Under the constitutional scheme
the executive is a limited executive and it is bound to act in accordance with law and not go against
it. This obligation of the executive not to act to the detriment of a person without the authority of
law can be enforced under Article 226 by issue of a writ "for any other purpose". When a detenu files
a petition under Article 226 challenging the validity of the order of detention on the ground that it isAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

not in accordance with the Act or is outside the authority conferred by the Act, he seeks to enforce
this obligation against the State Government and the suspension of enforcement of the fundamental
right under Article 21 does not affect the maintainability of his writ petition. The detenus also
contended that in any event the right to personal liberty was a statutory right and the suspension of
the fundamental right conferred by Article 21 did not carry with it suspension of the enforcement of
this statutory right. The Union of India and the State Governments rejoined to this contention of the
detenus by saying that Article 21 was the sole repository of the right of personal liberty and there
was no common law or statutory right in a person not to be deprived of his personal liberty except in
accordance with law, apart from that contained in Article 21 and, therefore, the writ petitions filed
by the detenus were in substance and effect petitions for enforcement of the right conferred by
Article 21 and hence they were not maintainable.
529. Before we proceed to consider these contentions which have been advanced before us, it is
necessary to remind ourselves that the emergency provisions in Part XVIII of the Constitution make
no distinction whether the emergency is on account of threat to the security of India by war or
external aggression or on account of threat to the security of India by internal disturbance. The same
provisions are applicable alike in both situations of emergency, irrespective of the reason for which
emergency, has been declared. The legal consequences are the same and, therefore, whatever
interpretation we place on Article 359, Clause (1) in the present case which relates to declaration of
emergency on account of internal disturbance would apply equally where the emergency is declared
on account of war or external aggression by a hostile power. If we take the view that the Presidential
Order under Article 359, Clause (1) suspending enforcement of Article 21 does not bar the remedy of
a detained person to seek his release on the ground that his detention is illegal, it would be open to a
detained person to challenge the legality of his detention even when there is emergency on account
of war or external aggression, because, barring Article 359, there is no other provision in the
Constitution which can even remotely be suggested as suspending or taking away the right to move
the Court in cases of illegal detention. The consequence would be that even in a perilous situation
when the nation is engaged in mortal combat with an enemy, the courts would be free to examine
the legality of detention and even if a detention has been made for efficient prosecution of the war or
protecting the nation against enemy activities, it would be liable to be struck down by the courts if
some procedural safeguard has been violated though it may be bona fide and through inadvertence.
This would imperil national security and the Government of the day would be helpless to prevent it.
The question is : whether such is the interpretation of Article 359, Clause (1). Of course, if that is the
only possible interpretation, we must give effect to it regardless of the consequence, leaving it to the
constituent authority to amend the Constitution, if it so thinks fit. But we may ask ourselves : could
the Constitution makers have intended that even in times of war or external aggression, there
should be no power in the President, as the head of the Nation, to bar judicial scrutiny into legality
of detention. It may be pointed out that even in the United States of America, the President has
power under Article I Placitum 9, Clause (2) of the United States Constitution to suspend the
privilege of the writ of habeas corpus "when in cases of rebellion or invasion the public safety may
require it". The British Parliament has also on several occasions in the past suspended the writ of
habeas corpus by legislative enactment, though in limited classes of cases. The Constitution makers
were obviously aware that even in these countries which are essentially democratic in character and
where the concept of constitutional government has had its finest flowering, the power to excludeAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

judicial review of legality of detention through the means of a writ of habeas corpus has been given
to the Supreme legislature or the head of the State and they must have realised that this was a
necessary power in times of national peril occasioned by war or external aggression. Could the
Constitution makers have intended to omit to provide for conferment of this power on the head of
the State in our Constitution?
530. We must also disabuse our mind of any notion that the emergency declared by the
Proclamation dated 25th June, 1975 is not genuine, or to borrow an adjective used by one of the
lawyers appearing on behalf of the interveners, is 'phoney'. This emergency has been declared by the
President in exercise of the powers conferred on him under Article 352, Clause (1) and the validity of
the Proclamation dated 25th June, 1975 declaring this emergency has not been assailed before us.
Mr. Shanti Bhushan and the other learned Counsel appearing on behalf of the detenus in fact
conceded before us that, for the purpose of the present appeals, we may proceed on the assumption
that the declaration of emergency under the Proclamation dated 25th June, 1975 is valid. But if this
emergency is taken as' valid, we must equally presume that it is genuine and give full effect to it,
without any hesitation or reservation.
531. With these prefatory observations I will now turn to examine Clause (1) of Article 359 under
which the Presidential Order has been issued. The language of this clause is clear and explicit and
does not present any difficulty of construction. It says that where a Proclamation of Emergency is in
operation, the President may by order suspend the right to move any court for the enforcement of
such of the rights conferred by Part III as may be mentioned in the Order. Any or all of the rights
conferred by Part III can find a place in the Presidential Order. Whilst the Presidential Order is in
force, no one can move any court for the enforcement of any of the specified fundamental rights. I
shall presently discuss whether Article 21 can be said to confer any right, but assuming it does--and,
as will be evident shortly, that is my conclusion--the right to move any court for the enforcement of
the fundamental right guaranteed by Article 21 may be suspended by specifying it in the Presidential
Order. When that is done, no one can move any court, and any court would mean any court of
competent jurisdiction, including the High Courts and the Supreme Court., for enforcement of the
right conferred by Article 21. The words "the right to move any court for the enforcement" are wide
enough "to include all claims made by citizens in any court of competent jurisdiction when it is
shown that the said claims cannot be effectively adjudicated upon without examining the question
as to whether the citizen is, in substance, seeking to enforce any of the specified fundamental
rights". Vide Makhan Singh v. State of Punjab . Therefore, there can be no doubt that in view of the
Presidential Order which mentions Article 21, the detenus would have no locus standi to maintain
their writ petitions, if it could be shown that the writ petitions were for enforcement of the right
conferred by Article 21.
532. That should logically take me straight to a consideration of the question as to what is the scope
and content of the right conferred by Article 21, for without defining it, it would not be possible to
determine whether the right sought to be enforced by the detenus in their writ petitions is the right
guaranteed under Article 21 or any other distinct fight. But before I examine this question, it would
be convenient first to deal with Clause (1A) of Article 359 and ascertain its meaning and effect.
Clause (1A) of Article 359 did not find a place in the Constitution when it was originally enacted, butAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

it was inserted with retrospective effect by the Constitution (Thirty-eighth) Amendment Act, 1975. It
provides that while an order made under Clause (1) of Article 359 mentioning any of the rights
conferred by Part III is in operation, nothing in that Part conferring those rights shall restrict the
power of the State to make any law or to take any executive action which the State would, but for the
provisions contained in that Part, be competent to make or to take. It will be noticed that the
language of Clause (1A) of Article 359 is in the same terms as that of Article 358 and the decisions
interpreting Article 358 would, therefore, afford considerable guidance in the interpretation of
Clause (1A) of Article 359. But before I turn to those decisions, let me try to arrive at the proper
meaning of that clause on a plain interpretation of its language.
533. In the first place, it is clear that Clause (1 A) of Article 359 is prospective in its operation, for it
says that, while a Presidential Order is in operation, nothing in the Articles mentioned in the
Presidential Order shall restrict the power of the State to make any law or to take any executive
action which the State would, but for the provisions contained in Part III, be competent to make or
to take. This clause does not operate to validate a legislative provision or executive action which was
invalid because of the constitutional inhibition before the Proclamation of Emergency. Secondly, it
may be noted that the fundamental rights operate as restrictions on the power of the State, which
includes the executive as well as the legislature. When a Presidential Order is issued under Article
359, Clause (1), the fundamental right mentioned in the Presidential Order is suspended, so that the
restriction on the power of the executive or the legislature imposed by the fundamental right is lifted
while the Presidential Order is in operation and the executive or the legislature is free to make any
law or to take any action which it would, but for the provisions contained in Part III, be competent
to make or to take. The words "but for the provisions contained in that Part", that is, but for the
fundamental rights, means "if the fundamental rights were not there". The question which has,
therefore, to be asked is : if the fundamental rights were not there in the Constitution, would the
executive or the legislature be competent to make the impugned law or to take the impugned
executive action? If it could, it would not be restricted from doing so by reason of the particular
fundamental right mentioned in the Presidential Order. The Presidential Order would, therefore,
have the effect of enlarging the power of the executive of the legislature by freeing it from the
restriction imposed by the fundamental right mentioned in the Presidential Order, but it would not
enable the legislature or the executive to make any law or to take any executive action which it was
not otherwise competent to make or to take. Now it is clear that, if the fundamental rights were not
there in the Constitution, the executive being limited by law would still be unable to take any action
to the prejudice of a person except by authority of law and in conformity with or in accordance with
law and, therefore, even if the Presidential Order mentions Article 21, Clause (1A) of Article 359
would not enable the executive to deprive a person of his personal liberty without sanction of law
and except in conformity with or in accordance with law. If an order of detention is made by the
executive without the authority of law, it would be invalid and its invalidity would not be cured by
Clause (1A) of Article 359, because that clause does not protect executive action taken without lawful
authority. An unlawful order of detention would not be protected from challenge under Article 21 by
reason of Clause (1A) of Article 359 and the detenu would be entitled to complain of such unlawful
detention as being in violation of Article 21, except in so far as his right to move the court for that
purpose may be held to have been taken away by Clause (1) of Article 359.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

534. This interpretation of Clause (1A) of Article 359 is clearly supported by the decision of this
Court in State of Madhya Pradesh v. Thakur Bharat Singh and the subsequent decisions following it,
which relate to the interpretation of the similarly worded Article 358. What happened in Bharat
Singh's case (supra) was that whilst the Proclamation of Emergency dated October 20, 1962 was in
operation, the State Government made an order under Sub-section (1) of Section 3 of the Madhya
Pradesh Public Security Act, 1959 directing that Bharat Singh shall not be in any place in Raipur
District and shall immediately proceed to and reside in Jhabua. Bharat Singh challenged the validity
of the order inter alia on the ground that Sub-section (1) of Section 3 of the Act infringed the
fundamental rights guaranteed under Clauses (d) and (e) of Article 19(1). The State Government
sought to meet the challenge by pleading the bar of Article 35 S. But this Court held that Article 358
had no application because Sub-section (1) of Section 3 of the Act which was impugned in the
petition was a pre-emergency legislation. this Court, speaking through Shah, J. observed :
Article 358 which suspends the provisions of Article 19 during an emergency declared
by the President under Article 352 is in terms prospective : after the proclamation of
emergency nothing in Article 19 restricts the power of the State to make laws or to
take any executive action which the State but for the provisions contained in Part III
was competent to make or take. Article 358 however does not operate to validate a
legislative provision which was invalid because of the constitutional inhibition before
the proclamation of emergency.
this Court accordingly proceeded to consider the validity of Section 3, Sub-section (1)
of the Act and held that Clause (b) of that Sub-section was unconstitutional as it
infringed the fundamental rights under clauses (d) and (e) of Article 19(1) and if it
was void before the Proclamation of Emergency,' "it was not revived by the
Proclamation".
535. But on this view, another contention was put forward on behalf of the State Government and
that was that Article 358 protects not only legislative but also executive action taken after the
Proclamation of Emergency and, therefore, executive action taken by the State would not be liable to
be challenged on the ground that it infringes the fundamental rights under Article 19, and
consequently, the Order of the State Government, though made under void law was protected
against challenge under Article 19. This contention was also rejected by the Court in the following
words :
In our judgment, the argument involves a grave fallacy. All executive action which
operates to the prejudice of any person must have authority of law to support it and
the terms of Article 358 do not detract from that rule. Article 358 does not purport to
invest the State with arbitrary authority to take action to the prejudice of citizens and
others it merely provides that so long as the proclamation of emergency subsists laws
may be enacted, and executive action may be taken in pursuance of lawful authority,
which if the provisions of Article 19 were operative would have been invalid.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

The view taken by the Court was that it is only where executive action is taken in
pursuance of lawful authority that it is immune from challenge under Article 19 and
in such a case even if it conflicts with the fundamental rights guaranteed under that
Article, it would be valid. But where executive action is taken without lawful
authority, as for example, where it is taken without the authority of any law at all or
in pursuance of a law which is void, it is not protected from challenge under Article 19
by Article 358 and it would be void to the extent it violates Article 19.
536. The same view was taken by this Court in District Collector of Hyderabad v. M/s. Ibrahim &.
Co. [1970] 3 S. C. R. 498 where this Court said, without referring expressly to the decision in Bharat
Singh's case (supra) that "-- the executive order immune from attack is only that order which the
State was competent, but for the provisions contained in Article 19, to make", and that "executive
action of the State Government, which is otherwise invalid, is not immune from attack merely
because the Proclamation of Emergency is in operation when it is taken". The reference here was to
immunity from attack under Article 19 and it was held that executive action which was contrary to
law and hence invalid, was not protected from attack under Article 19 by reason of Article 358. So
also in Bennett Coleman & Co. v. Union of India , this Court referred to the decisions in Bharat
Singh's case (supra) and Ibrahim's case (supra) and observed : "Executive action which is
unconstitutional is immune during Proclamation of Emergency. During the Proclamation of
Emergency Article 19 is suspended. But it would not authorise the taking of detrimental executive
action during the emergency affecting fundamental rights in Article 19 without any legislative
authority or any purported exercise of power conferred by any pre-emergency law which was invalid
when enacted". this Court also said to the same effect in Shree Meenakshi Mills Ltd. v. Union of
India: "-- if it can be shown that the executive action taken during the emergency has no authority of
a valid Jaw, its constitutionality can be challenged". These observations clearly show that where
executive action is taken without any legislative authority or in pursuance of a law which is void, it
would not be protected by Article 358 from challenge under Article 19 and it would be
unconstitutional to the extent to which it conflicts with that Article.
537. If this be the interpretation of Article 358 as laid down in the decision'; of this Court, a fortiori a
like interpretation must be placed on Clause (1A) of Article 359, as both are closely similar in form
as well as language. It must, therefore, be held that even though a Presidential Order issued under
Clause (1) of Article 359 mentions Article 21, where it is found that a detention has not been made in
pursuance of lawful authority or in other words, the detention is without the authority of law,
whether by reason of there being no law at all or by reason of the law under which the detention is
made being void, Clause (1 A) of Article 359 would not protect it from challenge under Article 21 and
it would be in conflict with that Article. The only question then would be whether the detenu would
be entitled to challenge the validity of the detention as being in breach of Article 21, in view of
Clause (1) of Article 35'' read with the Presidential Order mentioning Article 21.
538. Now, at the outset, a contention of a preliminary nature was advanced by Mr. Shanti Bhushan,
learned Advocate appearing on behalf of some of the detenus, that Clause (1) of Article 359 can have
no operation in cases where a detenu seeks to enforce his right of personal liberty by challenging the
legality of his detention. Mr. Shanti Bhushan contended, and in this contention he was stronglyAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

supported by Mr. Jeth-malani, that personal liberty is not a conglomeration of positive rights but is
merely a negative concept denoting an area of free action to the extent to which law does not curtail
it or authorise its curtailment and such a negative right cannot by its very nature be the subject of
conferment under Article 21. The argument of counsel based on this contention was that when
Article 359 Clause (1) speaks of suspension of "the right to move any court for the enforcement of
such of the rights conferred by Part III as may be mentioned in the order", it cannot include
reference to the right of personal liberty in Article 21, because it cannot be said of such a right that it
is conferred by Article 21. It was urged that Article 21 cannot therefore appropriately find a place in
a Presidential Order under Clause (1) of Article 359 and even if it is erroneously mentioned there; it
can have no legal sequitur and cannot give rise to the consequences set out in Clause (1) of Article
359. This argument was sought to be supported by reference to two well known text books on
jurisprudence, one by Salmond and the other by Holland and the Declaration of the Rights of Man
and the Citizen adopted by the French National Assembly was also relied upon for this purpose.
There is, however, no merit in this argument. The words 'rights conferred by Part III' cannot be read
in isolation, nor can they be construed by reference to theoretical or doctrinaire considerations.
They must be read in the context of the provisions enacted in Part III in order to determine what are
the rights conferred by the provisions in that Part. Part III is headed "Fundamental Rights" and it
deals with fundamental rights under seven heads, namely, right to equality, right to freedom, right
against exploitation, right to freedom of religion, cultural and educational rights, right to property
and right to constitutional remedies. Articles 19 to 22 occur under the heading "Right to Freedom"
and what is enacted in Article 21 is a right, namely, the right to life and personal liberty. It is true
that Article 21 is couched in negative language, but it is axiomatic that to confer a right it is not
necessary to use any particular form of language. It is not uncommon in legislative practice to use
negative language for conferring a right. That is often done for lending greater emphasis and
strength to the legislative enactment. One instance may be found in Section 298, Sub-section (1) of
the Government of India Act, 1935 which provided that no subject of His Majesty domiciled in India
shall on grounds only of religion, place of birth descent, colour or any of them be ineligible for office
under the Crown in India, or be prohibited on any such grounds from acquiring, holding or
disposing of property or carrying on any occupation, trade, business or profession in British India.
Though this provision was couched in negative language, the Judicial Committee of the Privy
Council in Punjab Province v. Daulat Singh 73 Indian Appeals 59 construed it as conferring a right
on every subject of His Majesty, domiciled in India.
539. Similarly, Article 14 also employs negative language and yet it was construed to confer a
fundamental right on every person within the territory of India, S. R. Das, C.J., pointed out in
Basheshar Nath v. The Commissioner of Income Tax, Delhi & Rajasthan [1959] Supp. (1) S. C. R.
529 that it is clear from the language of Article 14 that "The command of that Article is directed to
the State and the reality of the obligation thus imposed on the State is the measure of the
fundamental right which every person within the territory of India is to enjoy."
(emphasis supplied)
540. Article 31, Clause (1) is also couched in negative language : it is almost in the same form as
Article 21. Speaking about Article 31, S. R. Das, J. observed in State of Bihar v. MaharajadhirajAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Kameshwar Singh, of Dharbhanga and Ors. [1952] S. C. R. 889 at p. 988. "It confers a fundamental
right in so far as it protects private property from State action. The only limitation put upon the
State action is the requirement that the authority of law is prerequisite for the exercise of its power
to deprive a person of his property. This confers some protection on the owner, in that, he will not
be deprived of his property save by authority of law and this protection is the measure of the
fundamental right. It is to emphasise this immunity from State action as a fundamental right (that
the clause has been worded in negative language ..." (emphasis supplied). If Article 31(1), by giving a
limited immunity from State action, confers a fundamental right, it should follow equally on a parity
of reasoning that Article 21 also does so. In fact, this Court pointed out in so many terms in P. D.
Shamdasani v. Central Bank of India Ltd. [1952] S. C. R. 391 : that Clause (1) of Article 31 "is a
declaration of fundamental right of private property in the same negative form in which Article 21
declares the fundamental right to life and liberty".
541. Then again in R. C. Cooper v. Union of India this Court in a majority judgment to which ten out
of eleven judges were parties said:
--it is necessary to bear in mind the enunciation of the guarantee of fundamental
rights which has taken different forms. In some cases it is an express declaration of a
guaranteed right : Article 29(1), 30(1), 26, 25 and 32, in others to ensure protection of
individual rights they take specific forms of restrictions on State action--legislative or
executive --Articles 14, 15, 16, 20, 21, 22(1), 27 and 28; The enunciation of rights
either express or by implication does not follow a uniform pattern. But one thread
runs through them; they seek to protect the rights of the individual or groups of
individuals against infringement of those rights within specific limits. Part III of the
Constitution weaves a pattern of guarantees on the texture of basic human rights.
This statement of the law establishes clearly and without doubts that Article 21
confers the fundamental right of personal liberty.
542. Let us, for a moment, consider what would be the consequences if Article 21 were construed as
not conferring a right to personal liberty. Then there would be no fundamental right conferred by
Article 21 and even if a person is deprived of his personal liberty otherwise than in accordance with
the procedure established by law and there is infringement of Article 21, such person would not be
entitled to move the Supreme Court for a writ of habeas corpus under Article 32, for that Article is
available only for enforcement of the rights conferred by Part III. That would be a startling
consequence, as it would deprive the Supreme Court of a wholesome jurisdiction to protect the
personal liberty of an individual against illegal detention. Let it not be forgotten that the Supreme
Court has exercised this jurisdiction in a large number of cases over the last 25 years and set many
detenus at liberty where it found that they were illegally detained. All this exercise of jurisdiction in
the past would be rendered illegal and void. Ever since the commencement of the Constitution, this
Court has always regarded Article 21 as conferring the fundamental right of personal liberty which
can be enforced in this Court by a petition under Article 32 and there is no justification for departing
from this well settled constructional position.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

543. What then is the scope and ambit of this fundamental right conferred by Article 21 ? The first
question that arises in this connection is : what is the meaning and content of the word 'personal
liberty' in this Article ? This question came up for consideration before a Bench of six judges of this
Court in Kharak Singh v. State of U.P. and Ors. . The majority judges took the view "that 'personal
liberty' is used in the Article as a compendious term to include within itself all the varieties of rights
which go to make up the 'personal liberties' of man other than those dealt with in the several of
clauses of Article 19 (1). In other words, while Article 19(1) deals with particular species or attributes
of that freedom, 'personal liberty' in Article 21 takes in and comprises the residue". The minority
judges, however disagreed with this view taken by the majority and explained their position in the
following words : "No doubt the expression 'personal liberty' is a comprehensive one and the right to
move freely is an attribute of personal liberty. It is said that the freedom to move freely is carved out
of personal liberty and, therefore, the expression 'personal liberty' in Article 21 excludes that
attribute. In our view, this is not a correct approach. Both are independent fundamental rights,
though there is overlapping. There is no question of one being carved out of another. The
fundamental right of life and personal liberty have many attributes and some of them are found in
Article 19. If a person's fundamental right under Article 21 is infringed, the State can rely upon a law
to sustain the action, but that cannot be a complete answer unless the said law satisfies the test laid
down in Article 19(2) so far as the attributes covered by Article 19(1) are concerned." There can be
no doubt that in view of the decision of this Court in R. C. Coopers case (supra) the minority view
must be regarded as correct and the majority view must be held to have been overruled. No attribute
of personal liberty can be regarded as having been carved out of Article 21. That Article protects all
attributes of personal liberty against executive action which is not supported by law. It is not
necessary for the purpose of the present appeals to decide what those attributes are or to identify or
define them. It is enough to say that when a person is detained, there is deprivation of personal
liberty within the meaning of Article 21.
544. Now Article 21 gives protection against deprivation of personal liberty but what is the nature
and extent of this protection ? In the first place, it may be noted that this protection is only against
State action and not against private individuals. Vide P. D. Shamdasani v. Central Bank of India Ltd.
(supra) and Smt. Vidya Verma v. Dr. Shiv Narain [1955] 2 S. C. R. 983 Secondly, it is clear from the
language of Article 21 that the protection it secures is a limited one. It says and I am quoting here
only that part of the Article which relates to personal liberty, that no one shall be deprived of his
personal liberty except by the procedure prescribed by law. The meaning of the word 'law' as used in
this Article came to be considered by this Court in A. K. Gopalan v. State of Madras [1950] S. C. R.
88 and it was construed to mean 'enacted law' or 'State law'. Kania, C.J., observed : "It is obvious
that--law must mean enacted law", and to the same effect spoke Patanjali Sastri, J., when he said :
"In my opinion 'law' in Article 21 means 'positive or State made law' ". So also Mukherjea, J., said
that his conclusion was that "in Article 21 the word 'law' has been used in the sense of State made
law", and Das, J. too expressed the view that law in Article 21 must mean State made law. The only
safeguard enacted by Article 21, therefore, is that a person cannot be deprived of his personal liberty
except according to procedure prescribed by 'State made' law. If a law is made by the State
prescribing the procedure for depriving a person of his personal liberty and deprivation is effected
strictly in accordance with such procedure, the terms of Article 21 would be satisfied and there
would be no infringement of the right guaranteed under that Article.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

545. Now, based on the phraseology "except according to procedure established by law" in Article
21, an argument was advanced on behalf of the detenus that it is only where procedure prescribed by
the law has not been followed in making the order of detention that Article 21 is attracted and the
right conferred by that Article is breached and not where an order of detention is made without
there being any law at ail or where there is a law, outside the authority conferred by it. It was urged
that where an order of detention is challenged as mala fide or as having been made without the
requisite subjective satisfaction, the challenge would not be on the ground of breach of the
procedure prescribed by the Act but it would be on the ground that the order of detention is outside
the authority of the Act and such a challenge would not be covered by Article 21. This argument is, in
my opinion, wholly unsustainable. It is clear on plain natural construction of its language that
Article 21 imports two requirements : first, there must be a law authorising deprivation of personal
liberty, and secondly, such law must prescribe a procedure. The first requirement is indeed implicit
in the phrase "except according to procedure prescribed by law". When a law prescribes a procedure
for depriving a person of personal liberty, it must a fortiori authorise such deprivation. Article 21
thus provides both substantive as well as procedural safeguards. This was pointed out by Patanjali
Sastri, J. in A. K. Gopalan v. State of Madras (supra) at page 195 of the Report where the learned
Judge said :
If Article 21 is to be understood as providing only procedural safeguards, where is the
substantive right to personal liberty of non-citizens to be found in the Constitution ?
Are they denied such right altogether ? If they are to have no right of personal liberty,
why is the procedural safeguard in Article 21 extended to them ? And where is that
most fundamental right of all, the right to life, provided for in the Constitution ? The
truth is that Article 21,--presents an example of the fusion of procedural and
substantive rights in the same provision--the first and essential step in a procedure
established by law for such deprivation must be a law made by a competent
legislature authorising such deprivation.
Mahajan, J. also pointed out in the same case at page 229 of the Report :
Article 21, in my opinion, lays down substantive law as giving protection to life and
liberty inasmuch as it says that they cannot be deprived except according to the
procedure established by law; in other words, it means that before a person can be
deprived of his life or liberty as a condition precedent there should exist some
substantive law conferring authority for doing so and the law should further provide
for a mode of procedure for such deprivation.
S. R. Das, J. too spoke in the same strain when he negatived the argument "that
personal liberty as a substantive right is protected by Article 19(1) and Article 21 gives
only an additional protection by prescribing the procedure according to which that
right may be taken away." It would, therefore, be seen that both the safeguards of
Article 21, substantive as well as procedural, have to be complied with in order that
there should be no infraction of the right conferred by that Article. Where there is a
law authorising deprivation of personal liberty, but a person is detained otherwiseAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

than in conformity with the procedure prescribed by such law, it would clearly
constitute violation of Article 21. And so also there would be breach of Article 21, if
there is no law authorising deprivation of personal liberty and yet a person is
detained, for then the substantive safeguard provided in the Article would be
violated. Therefore, when a detenu challenges an order of detention made against
him on the ground that it is mala fide or is not preceded by the requisite subjective
satisfaction, such challenge would fall within the terms of Article 21.
546. It is also necessary to point out two other ingredients of Article 21. The first is that there must
not only be a law authorising deprivation of personal liberty, but there must also be a procedure
prescribed by law, or in other words, law must prescribe a procedure. Vide observations of Fazal Ali,
J. at page 169, Pataujali Sastri, J. at page 205, Mahajan, J. at pages 229 and 230 and S. R. Das, J. at
page 319 of the Report in A. K. Gopalan's case (supra). Article 21, thus, operates not merely as a
restriction on executive action against deprivation of personal liberty without authority of law, but it
also enacts a check on the legislature by insisting that the law, which authorises deprivation, must
establish a procedure. What the procedure should be is not laid down in this Article, but there must
be some procedure and at the least, it must conform to the minimal requirements of Article 22.
Secondly, 'law' within the meaning of Article 21 must be a valid law and not only must it be within
the legislative competence of the legislature enacting it, but it must also not be repugnant to any of
the fundamental rights enumerated in Part III, Vide Shambhu Nath Sarkar v. The State of West
Bengal and Khudiram Das v. The State of West Bengal and Ors.
547. It was contended by Mr. Jethmalani on behalf of some of the detenus that when a Presidential
Order suspends enforcement of the right conferred by Article 21, its effect is merely to suspend
enforcement of the aforesaid two ingredients and, therefore, the only claims which a detenu is
interdicted from enforcing, whilst the Presidential Order is in operation, are : (1) that the law
authorising deprivation does not prescribe a procedure, and (2) that it does not impose reasonable
restrictions on the freedom guaranteed under Article 19. This contention is plainly erroneous and
does not need much argument to refute it. In the first place, the requirement that the law which
authorises deprivation of personal liberty should not fall foul of Article 19, or for the matter of that,
with any other fundamental right set out in Part III, is not a requirement of Article 21, but it is a
requirement of Article 13. Secondly, the effect of suspension of enforcement of Article 21 by the
Presidential Order is that no one can move any court for enforcement of the right conferred by
Article 21, whilst the Presidential Order is in operation. The right conferred by Article 21 is the right
not to be deprived of personal liberty except according to procedure prescribed by law. Therefore,
when the executive detains a person without there being any law at all authorising detention or if
there is such law, otherwise than in accordance with its provisions, that would clearly be in violation
of the right conferred by Article 21 and such violation would a fortiori be immune from challenge by
reason of the Presidential Order: It must follow inevitably from this that when a detenu challenges
an order of detention on the ground that it is mala fide or is not in accordance with the provisions of
the Act or is outside the authority conferred by the Act, he would be seeking to enforce the right of
personal liberty conferred on him under Article 21 and that would be inhibited by the Presidential
Order.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

548. That takes me to a consideration of the concept of the rule of law on which so much reliance
was placed on behalf of the detenus in order to save their writ petitions from the lethal effect of the
Presidential Order. The contention on behalf of the detenus was that their writ petitions were for
enforcement of the right of the personal liberty based on the principle of the rule of law that the
executive cannot interfere with the liberty of a person except by authority of law and that was not
within the inhibition of the Presidential Order. The question is : what is this principle of the rule of
law and does it exist under our Constitution as a distinct and separate constitutional principle,
independently and apart from Article 21, so as to be capable of enforcement even when enforcement
of Article 21 is suspended by the Presidential Order.
549. The Great Charter of Liberties of England, commonly known as the Magna Carta, was granted
under the seal of King John in the meadow called Runnymede on 15th June, 1215. This was followed
within a couple of years by a revised version of the Charter which was issued in the name of Henry
III in 1217 and ultimately with slight amendments, another Charter was re-issued by Henry III in
1225 and that document has always been accepted as containing the authorised text of Magna Carta.
Whenever reference is made to Magna Carta, it is to the Charter of 1225 which is also described as "9
Henry III (1225)". Magna Carta, according to Sir Ivor Jennings symbolises "what we should now call
the rule of law, government according to law or constitutional government" which means that all
power should come from the law and that "no man, be he king or minister or private person is above
the law". It recognised that "the liberties of England, which means the liberties of all free
men--depended on the observance of law by King, lord and commoner alike", and "without law
there is no liberty". Cap. XXTX contains the famous clause of the Magra Carta which provided that:
"No free man shall be taken, or imprisoned, or dispossessed, of his free tenement, or liberties, or
free customs, or be outlawed, or exiled, or in any way destroyed; nor will we condemn him. nor will
we commit him to prison, excepting by the legal judgment of his peers, or by the laws of the land."
Thus, for the first time the great principle was enunciated--though even before, it was always part of
the liberties of the subject--that no one shall be imprisoned or deprived of his liberty except by the
authority of the law of the land. The power of the King to arrest a person or to deprive him of his
liberty was circumscribed by law. That is why Bracton said about the middle of the 13th Century
"--the king himself ought not to under man but under God and under the law, because the law
makes the King. Therefore, let the King attribute to the law what the law attributes to the King,
namely, lordship and power, for there is no king where will governs and not law". Magna Carta was
confirmed again by the successive kings on the insistence of Lords and commons and. the rule of law
embodied in Magna Carta governed the actions of the King vis-a-vis his subjects. But this great
principle of liberty was placed in jeopardy in the 17th Century when a claim was made by the King
that he had a prerogative right to arrest and detain a subject and this prerogative right was
necessary for the defence of the Realm. When the King sought to raise moneys from the subjects
without the sanction of the Parliament, it was resisted by Darnel and others and they were on that
account committed to prison under the orders of the King. On the application of these persons, who
were so imprisoned, a writ of habeas corpus was issued and the return made to it on behalf of the
King was that they were imprisoned per special mandate Domini Regis (1627 St. Tr. I warnel's case).
This return was considered sufficient and the writ was discharged. The effect of this decision was
that King needed no authority of law in order to deprive a subject of his personal liberty. But the
Parliament was quick to nullify this decision by enacting the Petition of Right, 1628 and itAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

reaffirmed the right to personal liberty in Section 3 of that Act and declared such a cause of
imprisonment to be unlawful. The principle that the Executive cannot interfere with the liberty of a
subject unless such interference is sanctioned by the authority of law was thus restored in its full
vigour.
550. Blackstone in his Commentaries on the Laws of England, vol. 1, 4th ed. p. 105 stated the
principle in these terms :
-- the law of England regards, asserts and preserves the personal liberty of
individuals. This personal liberty consists in the power of locomotion, of changing
situation, or removing one's person to whatsoever place one's own inclination may
direct; for imprisonment or restraint, unless by due course of law--It cannot ever be
abridged at the mere discretion of the magistrate, without the explicit permission of
the laws. Here again, the language of the Great Charter is, that no free man shall be
taken or imprisoned, but by the lawful judgment of his equals, or by the law of the
land.
(emphasis supplied) Since then, the validity of this principle has never been doubted
and the classical statement of it is to be found in the oft quoted passage from the
judgment of Lord Atkin in Eshugbayi (Eleko) v. Officer Administering the
Government of Nigeria (supra) where the learned Law Lord said :
The Governor acting under the Ordinance acts solely under executive powers, and in
no sense a Court. As the executive he can only act in pursuance of the powers given to
him by law. In accordance with British jurisprudence no member of the executive can
interfere with the liberty or property of a British subject except on the condition that
he can support the legality of his action before a Court of Justice. And it is the
tradition of British justice that Judges should not shrink from deciding such issues in
the face of the executive.
Since in this country prior to the commencement of the Constitution, we were
administering British jurisprudence, this constitutional principle was equally
applicable here. That was the direct result of the binding authority of the decision of
the Privy Council in the aforementioned case. But quite apart from that, the courts in
India uniformly accepted this constitutional principle as part of the law of the land.
Vide Secretary of State for India v. Hari Bhanji [1882] I. L. R. 5 Mad. 273 and
Province of Bombay v. Khushaldas Advani [1950] S. C. R. 621. Bose, J., in P. K. Tare
v. Emperor A. I. R. 1943 Nag. 26 quoted with approval the aforesaid passage from the
judgment of Lord Atkin and pointed out that before the executive can claim power to
override the rights of the subject "it must show that the legislature has empowered it
to do so". The learned Judge also referred to the following passage from the
dissenting judgment of Lord Atkin in Liversidge v. Anderson [1942] 42 A. C. 206 "It
has always been one of the pillars of freedom, one of the principles of liberty for
which, on recent authority, we are now fighting(that the Judges are no respecter ofAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

persons and stand between the subject and any attempted encroachments on his
liberty by the executive; alert to see that any coercive action is justified in law."
(emphasis supplied), and, pointing out that Lord Macmillan and Lord Wright also
agreed with this principle, observed that these principles of liberty "to which Lord
Atkin refers, apply as much to India as elsewhere". So also in Vimlabai Deshpande v.
Emperor A. I. R. 1945 Nag. 8 the same two passages, one from the judgment of Lord
Atkin in Eshugbayi's case (supra) and the other from the judgment in Liversidge's
case (supra) were referred to with approval by Bose and Sen, JJ.
551. It was also accepted by a Division Bench of the Calcutta High Court consisting of Malik and
Remfry, JJ. in Jitendranath Ghosh v. The Chief Secretary to the Government of Bengal I. L. R. 60
Cal. 364 at 377 that "-in accordance with British jurisprudence, and with the jurisprudence of British
India, no member of the executive can interfere with the liberty or property of a British subject, or of
a foreigner in our land, except on the condition that he can, and, if duly called upon, must support
the legality of his action before a court of justice". The Division Bench pointed out that "the courts
can, and in a proper case must, consider and determine the question whether there has been a fraud
on an Act or an abuse of powers granted by the legislature, Eshugbayi Eleko's case".
552. Ameer Ali, A.C.J., and S. R. Das, J. also quoted with approval In re : Banwarilal Roy (48 Cal.
Weekly Notes 766 at 780) the aforesaid passage from the judgment of Lord Atkin in Eshugbayi
Eleko's case (supra) and relied on the decision in Jitendranath Ghosh's case (supra) and particularly
the observations from the judgment in that case which I have just reproduced. These observations
clearly show that in our country, even in pre Constitution days, the executive was a limited
executive, that is, an executive limited by law and it could act only in accordance with law.
553. It would be seen from the above discussion that, even prior to the Constitution, the principle of
rule of law that the executive cannot act to the prejudice of a person without the authority of law was
recognised as part of the law of the land and was uniformly administered by the courts. It was
clearly 'law in force' and ordinarily, by reason of Article 372, it would have continued to subsist as a
distinct and separate principle of law even after the commencement of the Constitution. But when
the Constitution was enacted, some aspects of this principle of rule of law were expressly recognised
and given constitutional embodiment in different Articles of the Constitution.. Thereafter they did
not remain in the realm of unwritten law. Article 21 enacted one aspect of the principle of rule of law
that executive cannot deprive a person of his life or personal liberty without authority of law and
added a requirement that the law which authorises such deprivation must prescribe a procedure.
Another aspect of the principle of rule of law was enacted in Clause (1) of Article 31. namely, that no
one shall be deprived of his property save by authority of law. That is why it was pointed out by
Shah, J. in R .C. Cooper's case (supra) that "Clauses (1) and (2) of Article 31 subordinate the exercise
of the power of the State to the basic concept of the rule of law". A third aspect was
constitutionailsed in various sub-clauses of Clause (1) of Article 19 inhibiting executive action
unsupported by law, which conflicted with the different freedoms guaranteed in these sub-clauses.
Then Article 265 recognised and enacted a yet fourth aspect, namely, that no tax shall be levied and
collected without authority of law. Article 19, Clause (1), Article 21, Article 31, Clause (1) and Article
265 thus embody different aspects of the principle of rule of law. We are concerned in these appealsAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

only with Article 21 and, therefore, I shall confine my discussion only to that Article.
554. Now, to my mind, it is clear that when this principle of rule of law that the executive cannot
deprive a person of his liberty except by authority of law, is recognised and embodied as a
fundamental sight and enacted as such in Article 21, it is difficult to comprehend how it could
continue to have a distinct and separate existence, independently and apart from this Article in
which it has been given constitutional vesture. I fail to see how it could continue in force under
Article 372 when it is expressly recognized and embodied as a fundamental right in Article 21 and
finds a place in the express provisions of the Constitution. Once this principle is recognised and
incorporated in the Constitution and forms part of it, it could not have any separate existence apart
from the Constitution, unless it were also enacted as a statutory principle by some positive law of the
State. This position indeed become incontrovertible when we notice that, while recognising and
adopting this principle of rule of law as a fundamental right, the Constitution has denned its scope
and ambit and imposed limitation on it in the shape of Article 359A, clauses (1) and (1A). When the
Constitution makers have clearly intended that this right should be subject to the limitation imposed
by Article 359, Clause (1) and (1A), it would be contrary to all canons of construction to hold that the
same right continues to exist independently, but free from the limitation imposed by Article 359,
Clauses (1) and (1A). Such a construction would defeat the object of the Constitution makers in
imposing the limitation under Article 359, Clauses (1) and (1A) and make a mockery of that
limitation. The consequence of such a construction would be that, even though a Presidential Order
is issued under Clause (1) of Article 359 suspending the right to move the court for enforcement of
the right guaranteed under Article 21, the detenu would be entitled to ignore the Presidential Order
and challenge the order of the detention on the ground that it is made otherwise than in accordance
with law, which is precisely the thing which is sought to be interdicted by the Presidential Order.
The Presidential Order would in such a case become meaningless and ineffectual. Can an
interpretation be accepted which would reduce to futility Article 359, Clause (1) in its application in
relation to Article 21 ? Could the Constitution makers have intended such a meaning ? The only
explanation which could be offered on behalf of the detenus was that the object of Article 359,
Clause (1) is merely to prevent a person from moving the Supreme Court under Article 32 for
enforcing the right of personal liberty and it is not intended to effect the enforcement of the right of
personal liberty based on the rule of law by moving the High Court under Article 226. But this
explanation is-wholly unconvincing. It is difficult to understand why the Constitution makers should
have intended to bar only the right to move the Supreme Court under Article 32 in so far as the right
of personal liberty is concerned. There would be no point in preventing a citizen from moving the
Supreme Court directly under Article 32 for securing his release from illegal detention, While at the
same time leaving it open to him to move the High Court for the same relief and then to come to the
Supreme Court In appeal, if necessary. That would be wholly irrational and meaningless. Therefore,
the only way in which meaning and effect can be given to the Presidential Order suspending the
enforcement of the right of personal liberty guaranteed under Article 21 is by holding that the
principle of rule of law, that the executive cannot interfere" with the personal liberty of any person
except by authority of law, is enacted in Article 21 and it does not exist as a distinct and separate
principle conferring a right of personal liberty, independently and apart from that Article.
Consequently, when the enforcement of the right of personal liberty conferred by Article 21 is
suspended by a Presidential Order, the detenu cannot circumvent the Presidential Order andAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

challenge the legality of his detention by falling back on the supposed right of personal liberty based
on the principle of rule of law.
555. It was also said on behalf of the detenus that under our constitutional set up, the executive is
bound to act in accordance with law and this obligation of the executive arises from the very basis of
the doctrine of distribution of powers amongst different bodies created by the Constitution as also
from the terms of Articles 73, 154 and 256 of the Constitution. This obligation, contended the
detenus, could be enforced against the executive under Article 226 by issue of a writ "for any other
purpose". Now, it is true that under our Constitution, the executive is a limited executive and it is
bound to act in accordance with law and cannot disobey it. If the Maintenance of Internal Security
Act, 1971 says that the executive shall be entitled to detain a person only on the fulfilment of certain
conditions and according to a specified procedure, it cannot make an order of detention if the
prescribed conditions are not fulfilled or the specified procedure is not followed. The executive is
plainly and indubitably subordinated to the law and it cannot flout the mandate of the law but must
act in accordance with it. The Judicial Committee of the Privy Council pointed out this
constitutional position in Eastern Trust Company v. Mckenzie Mann & Co. Ltd. [1915] A. c. 750 in an
appeal from the Supreme Court of Canada : "The non-existence of any right to bring the Crown into
Court--does not give the Crown immunity from all law, or authorize the interference by the Crown
with private rights at its own mere will--It is the duty of the Crown and of every branch of the
Executive to abide by and obey the law. (emphasis supplied)". This rule must naturally apply with
equal force in our constitutional set up and that was recognised by this Court in Rai Sahib Rain
Jawaya Kapur v. The State of Punjab where Mukherjea, J., speaking on behalf of the Court said : "In
India, as in England, the executive has to act subject to the control of the legislature" and proceeded
to add : "--the executive Government are bound to conform not only to the law of the land but also
to the provisions of the Constitution--" In Bharat Singh's case (supra) also, this Court pointed out :
"Our federal structure is founded on certain fundamental principles : (1) the sovereignty of the
people with limited Government authority i.e. the Government must be conducted in accordance
with the will of the majority of the people. The people govern themselves through their
representatives, whereas the official agencies of the executive Government possess only such powers
as have been conferred upon them by the people; (2) There is distribution of powers between the
three organs of the State--Legislative, executive and judicial--each organ having some check direct
or indirect on the other; and (3) the rule of law which includes judicial review of arbitrary executive
action". The obligation of the executive to act according to law and not to flout or disobey it is,
therefore, unexceptionable and cannot be disputed. But this obligation, in so far as personal liberty
is concerned., is expressly recognised and enacted as a constitutional provision inter alia in Article
21 and when the Constitution itself has provided that the enforcement of this obligation may be
suspended by a Presidential Order, it is difficult to see how the intention of the Constitution makers
can be allowed to be defeated by holding that this obligation exists independently of Article 21 and it
can be enforced despite the imitation imposed by the constitutional provision The same reasoning
which I have elaborated in the preceding paragraph would equally apply to repel the present
argument.
556. Before I go to the decided cases, I must refer to one argument which strongly supports the view
I am taking. It is almost conclusive. It is an argument for which I must express my indebtedness toAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Prof. P. K. Tripathi. In an Article written on 'Judicial and Legislative Control over the Executive
during Martial Law' and published in the Journal Section of All India Reporter at page 82, Prof. P.
K. Tripathi has suggested that considerations of Martial Law may support the conclusion that a
Presidential Order mentioning Article 21 takes away, wholly and completely, the right of an
individual to obtain a writ of habeas corpus challenging the legality of his detention. I must of course
hasten to make it clear that there is no Martial law anywhere in the territory of India at present and
I am referring to it only in order to buttress the conclusion otherwise reached by me. The concept of
Martial law is well known in the British and Americas jurisprudence. When a grave emergency
arises in which the executive finds itself unable to restore order by employing the ordinary civilian
machinery and it becomes necessary for it to use force, it may declare what is commonly termed
'martial law'. Martial law means that the executive calls the military to its aid and the military,
acting under the general authority of the executive, proceeds to quell violence by violence. When
martial law is in force, it is well settled that the courts cannot issue a writ of habeas corpus or
otherwise interfere with the military authorities or the executive to protect the life or liberty of an
individual, even if illegal or mala fide action is taken or threatened to be taken by the military
authorities or the executive. To give only one example : In Ireland in John Allan's case [1921] 2 Irish.
Reports 241, the martial law authorities ordered all persons to deposit their fire arms within
twenty-four hours with the army authorities on pain of death. John Allen, who failed to obey, was
arrested and sentenced by the military tribunal, which was, in law, a mere body of army men
advising the officer commanding, to death, and the martial law authorities announced the day and
date when he was to be executed. The court was moved on behalf of John Allen on the ground that
the order of the military tribunal was invalid, but the court refused to interfere on the theory that
when martial law is properly declared, the court will not issue habeas corpus during the period when
martial law is in force. It is the basic characteristic and essence of martial law that during the time
that it is in force, the individual cannot enforce his right to life and liberty by resorting to judicial
process and the courts cannot issue the writ of habeas corpus or pass any similar orders.
557. Now, under our Constitution there does not appear to be any express provision conferring
power on the executive to declare martial law. But it is implicit in the text of Article 34 of the
Constitution that the Government may declare martial law in any area within the territory of India.
What are the legal implications and consequences of declaration of martial law is not provided any
where in the Constitution. It is, therefore, obvious that merely declaring martial law would not, by
itself, deprive the courts of the power to issue the writ of habeas corpus or other process for the
protection of the right of the individual to life and liberty. In our country, unlike England, the right
to life and liberty is secured as a fundamental right and the right to move the Supreme Court for
enforcement of this right is also guaranteed as a fundamental right. Also the power to issue a writ or
order in the nature of habeas corpus has been expressly conferred on the High Courts by a
constitutional provision, namely, Article 226. Therefore, the declaration of martial law, which is not
even expressly provided in the Constitution, cannot override the provisions of the Article conferring
the right to life and liberty as also of Articles 32 and 226 and, unless the right of an individual to
move the courts for enforcement of the right to life and liberty can be suspended or taken away by or
under an express provisions of the Constitution, the individual would be entitled to enforce the right
to life and liberty under Article 32 or Article 226 or by resorting to the ordinary process of law, even
during martial law. That would be contradictory of the basic and essential feature of martial law andAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

make it impossible to impose effective martial law anywhere at any time in the territory of India.
Such a consequence could never have been imagined by the Constitution makers. They could never
have intended that the Government should have the power to declare martial law and yet it should
be devoid of the legal effect which must inevitably follow when martial law is in force. Moreover,
Article 34 itself presupposes that acts contrary to law may be committed by the military authorities
or the executive during the time when martial law is in force and that is why it provides that after
the martial law ceases to be in force, Parliament may by law indemnify "any person in the service of
the Union or of a State or any other person in respect of any act done by him in connection with the
maintenance or restoration of order in any area--where martial law was in force or validate any
sentence passed, punishment inflicted, forfeiture ordered or other act done under martial law in
such area". This provision clearly postulates that during the time that martial law is in force, no
judicial process can issue to examine the legality of any act done by the military authorities or the
executive in connection with the maintenance or restoration of order. But, how is this result to be
achieved under the Constitution ?
558. The only provision in the Constitution which authorises temporary suspension or taking away
of the right of an individual to move any court for enforcement of his right to life and liberty is
Article 359, Clause (1). If the Presidential Order under Clause (1) of Article 359 suspending
enforcement of the fundamental right under Article 21 were construed not to have the effect of
barring an individual from moving the court for impugning the legality of the act of the executive
interfering with his life or liberty, on the assumption that in doing so, he is merely enforcing his
right to life or personal liberty based on the rule of law, the result would be that even when and
where martial law is in force, courts will continue to have the power to examine the legality of the act
of the executive, because, as explained earlier, the mere declaration of martial law does not, under
our Constitution, have the effect of taking away that power. That would be plainly an insufferable
situation which would carry the power of courts even beyond that claimed by the United States
courts in the case of the ex parte Milligan (1866) 4 Wallace 2 which case went to the farthest limit
and which has for that reason been criticised by great authorities like E. S. Corwin and has not been
consistently followed even by the United States Supreme Court Vide Moyer v. Peabody (1909) 212 U.
S. 76 and Duncan v. Kohan-meku (1945) 327 U. S. 304. There can be no two opinions that during
martial law the courts cannot and should not have power to examine the legality on the action of the
military authorities or the executive on any ground whatsoever, including the ground of mala fide.
But, if the courts are to be prevented from exercising such power during martial law, that situation
can be brought about only by a Presidential Order issued under Article 359, Clause (1) and in no
other way and the Presidential Order in so far as it suspends the enforcement of the right of
personal liberty conferred under Article 21 must be construed to bar challenge to the legality of
detention in any court, including the Supreme Court and the High Courts, whilst the Presidential
Order is in operation.
559. I may also in this connection refer to the decision of the House of Lords in Attorney General v.
De Keyser's Royal Hotel [1920] A. C. 508. There, in May 1916, the Crown, purporting to act under
the Defence of Realm Consolidation Act, 1914 and the Regulations made thereunder took possession
of a hotel for the purpose of housing the Headquarters' personnel of the Royal Flying Corps and
denied the legal right of the owners to compensation. The owners yielded up possession underAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

protest and without prejudice to their right and by a Petition of Right, they asked for a declaration
that they were entitled to compensation under the Defence Act, 1842. The Crown was plainly liable
to pay compensation under the Statute, but it sought to justify its action in taking possession of the
hotel without payment of compensation, under the sanction of the Royal Prerogative. The question
which, therefore, arose for consideration before the House of Lords was whether the Royal
Prerogative was available to the Crown for taking possession of the hotel without compensation,
when the statute authorised taking of such possession but on condition on payment of
compensation. The House of Lords unanimously held that, in view of the statutory provision on the
subject, the Royal Prerogative to take property without payment of compensation did not subsist
and the principle laid down was that where by Statute, the Crown is empowered to do what it might
heretofore have done by virtue of its prerogative, it can no longer act under the prerogative and
must act under and subject to the conditions imposed by the statute. Lord Dunedin in the course of
his speech observed :
None the less, it is equally certain that if the whole ground of something which could
be done by the prerogative is covered by the statute, it is the statute that rules.
Lord Atkinson quoted with approval the following pregnant passage from the
judgment of the Master of the Rolls in the same case :
Those powers which the executive exercises without Parliamentary authority are
comprised under the comprehensive term of the prerogative. Where, however,
Parliament has intervened and has provided by statute for powers, previously within
the prerogative, being exercised in a particular manner and subject to the limitations
and provisions contained in the statute, they can only be so exercised. Otherwise,
what use would there be in imposing limitations, if the Crown could at its pleasure
disregard them and fall back on prerogative ?
and pointed out that the question posed by the Master of the Rolls was unanswerable.
The learned Law Lord then proceeded to add :
It is quite obvious that it would be useless and meaningless for the Legislature to
impose restrictions and limitations upon, and to attach conditions to, the exercise by
the Crown of the powers conferred by a statute, if the Crown were free at its pleasure
to disregard these provisions, and by virtue of its prerogative do the very thing the
statutes empowered it to do.
The other learned Law Lords who participated in the decision also made observations
to the same effect in the course of their speeches.
560. Now it is obvious that the contention of the detenus in the present case is very similar to that
advanced on behalf of the Crown in De Keyser's Royal Hotel's case (supra). It almost seems to be an
echo of that contention and it must inevitably be answered the same way. When the right of
personal liberty based on the rule of law which existed immediately prior to the commencement ofAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

the Constitution has been enacted in the Constitution as a fundamental right in Article 21 with the
limitation that, when there is a Proclamation of Emergency, the President may, by Order under
Article 359, Clause (1) suspend its enforcement, it is impossible to imagine how that right of
personal liberty based on the rule of law can continue to exist as a distinct and independent right
free from the limitation as to enforcement contained in Article 359, Clause (1). It would be
meaningless and futile for the Constitution makers to have imposed this limitation in regard to
enforcement of the right of personal liberty guaranteed by Article 21, if the detenu could, with
impunity, disregard such limitation and fall back on the right of personal liberty based on the rule of
law.
561. There is a decision of this Court in Dhimbha Devisingh Gohil v. The State of Bombay which
clearly supports this view. The question which arose for determination in this case was whether the
Bombay Taluqdari Tenure Abolition Act, 1949 was a valid piece of legislation. When this Act was
enacted by the Bombay Legislature, the Government of India Act, 1935 was in force and the validity
of this Act was challenged on the ground that it was in violation of Section 299, Sub-section (2) of
the Government of India Act, 1934. Since this Act was included in the Ninth Schedule to the
Constitution by the Constitution of India (First Amendment) Act, 1951, the State contended that by
reason of Article 31-B, this Act was immune from attack of the kind put forward on behalf of the
petitioner. Article 31-B provides inter alia that none of the Acts specified in the Ninth Schedule nor
any of the provisions thereof shall be deemed to be void or ever to have become void on the ground
that such act or provision is inconsistent with or takes away or abridges any of the right conferred by
any provisions of Part III. The petitioner disputed the applicability of Article 31-B on the ground
that the protection under that Article was confined only to "9 challenge based on the provisions of
Part III of the Constitution and did not extend to a challenge based on violation of Section 299,
Sub-section (2) of the Government of India Act, 1935. The petitioner relied on the words "-- is
inconsistent with or takes away or abridges any rights conferred by any provisions" of Part III and
contended that inconsistency with or taking away or abridgement of the right conferred by s. 299,
Sub-section (2) of the Government of India Act, 1935 was not within the protection of Art 31-B. This
contention of the petitioner was negatived and it was held by this Court speaking through
Jagannatha Das, J. :
When Article 31-B protects is not a mere "contravention of the provisions" of Part III
of the Constitution but an attack on the grounds that the impugned Act is
"inconsistent with or takes away or abridges any of the rights conferred by any
provisions of this Part." One of the rights secured to a person by Part III of the
Constitution is a right that his property shall be acquired only for public purposes
and under a law authorising such acquisition and providing for compensation which
is either fixed by the law itself or regulated by principles specified by the law. That is
also the very right which was previously secured to the person under Section 299 of
the Government of India Act. The challenge now made to the validity of the
impugned Act is based on the alleged violation of that right."--" But it is urged, that
even so, Article 31-B protects only the violation of the fundamental right in so far as
"it was conferred by Part III of the Constitution" and that this right cannot be said to
have been "conferred" by the Constitution. We cannot agree with this contention.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

This is clearly a case where the concerned right which was secured under Section 299
of the Government of India Act in the form of a fetter on the competency of the
Legislature and which in substance was a fundamental right, was lifted into the
formal category of a fundamental right along with other fundamental rights
recognised in the present Constitution. There is therefore nothing inappropriate in
referring to this right which was preexisting, along with the other fundamental rights
for the first time secured by this Constitution, when grouping them together, as
fundamental rights "conferred" by the Constitution.
562. This Court held that when Article 31-B protected the Act against attack on the ground that the
Act is "inconsistent with or takes away or abridges any of the rights conferred by any provisions of
"Part III, the protection extended to giving immunity against violation of the right secured by
Section 299, Sub-section (2) of the Government of India, 1935 because that was the very right lifted
into the category of fundamental right and enacted as Article 31, Clause (2) of the Constitution and it
could accordingly with appropriateness, be referred to as the right conferred by Article 31, Clause
(2). On the parity of reasoning, it may be said that the right based on the principle of rule of law that
no one shall be deprived of his life or personal liberty except by authority of law, which was a
pre-existing right, was lifted into the category of fundamental right and enacted as Article 21 and
hence it became a fundamental right conferred by Article 21 and ceased to have any distinct and
separate existence.
563. The maxim 'expressum facit cessare taciturn' that is what is expressed makes what is silent
cease, would also clearly be applicable in the present case. This maxim is indeed a principle of logic
and common sense and not merely a technical rule of construction. It was applied in the
construction of a constitutional provision in Shankara Rao Badami v. State of Mysore . The
argument which was advanced in that case was that the existence of public purpose and the
obligation to pay compensation were necessary concomitants of compulsory acquisition of private
property and so the term 'acquisition' in Entry 36 of List II of the Seventh Schedule to the
Constitution must be construed as importing by necessary implication the two conditions of public
purpose and payment of adequate compensation, and consequently, the Mysore (Personal and
Miscellaneous) Inams Abolition Act, 1955, which provided for acquisition of the rights of the
inamdars in inam estates in Mysore State without payment of just and adequate compensation was
beyond the legislative competence of the State Legislature. This argument was rejected on the
ground that the limitations of public purpose and payment of compensation being expressly
provided for as conations of acquisition in Article 31(2), there was no room for implying either of
these limitations in the interpretation of the term 'acquisition' in Entry 36 of List II. Ramaswamy, J.,
speaking on behalf of the Court observed :
It is true that under the Common law of eminent domain as recognised in
Anglo-Saxon jurisprudence the State cannot take the property of its subject unless
such property is required for a public purpose and without compensating the owner
for its loss. But when these limitations are expressly provided for in Article 32(2) and
it is further enacted that no law shall be made which takes away or abridges these
safeguards, and any such law, if made, shall be void, there can be no room forAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

implication, and the words 'acquisition of property' in entry 36 must be understood
in their natural sense of the act of acquiring property, without importing into the
phrase an obligation to pay compensation or a condition as to the existence of a
public purpose. In other words, it is not correct to treat the obligation to pay
compensation as implicit in the legislative entry 33 of List I or legislative entry 36 of
List II for it is separately and expressly provided for in Article 31(2). The well known
maxim expresum facit cessare taciturn is indeed a principle of logic and
commonsense and not merely a technical rule of construction. The express provision
in Article 31(2) that a law of acquisition .in order to be valid must provide for
compensation will, therefore, necessarily exclude all suggestion of an implied
obligation to provide for compensation sought to be imported into the meaning of the
word "acquisition" in entry 36 of List II. In the face of the express provision of Article
31(2), there remains no room for reading any such implication in the legislative
heads.
Similarly, in the present case, on an application of the maxim expressum facit cessare
taciturn, the express provision in Article 21 that no person shall be deprived of his life
or personal liberty except according to procedure prescribed by law will necessarily
exclude a provision to the same effect to be gathered or implied from the other
provisions of the Constitution.
564. I find myself fortified in this conclusion by the view taken on a similar question under the Irish
Constitution which also contains a catena of Articles conferring fundamental rights Kelly in his book
one. 'Fundamental Rights in the Irish Law and Constitution' points out "that the various
fundamental fights which were previously notionally present in the common law have been
subsumed in and replaced by the written guarantees" and, therefore., these rights cannot be found
elsewhere than in the Constitution. The decision of the High Court of Justice in Ireland in 'State
(Walsh and Ors.) v. Lennon and Ors. 1942 Irish Reports 112 has also adopted the same view. The
petitioners in this case, who were detained in Arbour Hill Military Detention Barracks awaiting trial
on a charge of murder before a Military Court established under Emergency Powers (No. 41) Order,
1940, made an application to the High Court for an order of habeas corpus directed to the Governor
of the Detention Barracks in which they were held and for an order of prohibition directed to the
President and members of the Military Court before whom it was ordered by Emergency Powers
(No. 41F) Order, 1941 that they should be tried. The application inter alia challenged the validity of
the Emergency Powers (No. 41 F) Order, 1941 on the ground that it was ultra vires the Government,
as it directed that the Military Court, which was to try the petitioners, should try them together and
so precluded the Court from exercising its discretion and control over its own procedure and was
thus violativc of the right of a citizen to insist that he shall not be tried on a criminal charge save in
due course of law and was, also in conflict with the right of a citizen to personal liberty. The right of
personal liberty was guaranteed by Article 40, Section 4, Sub-section (1) of the Constitution, while
the right of a citizen charged with a criminal offence to insist that he shall not be tried save in due
course of law was to be found in Article 38, Section 1. The respondents relied on Article 28, Section
3, Sub-section (;3) of the Constitution which provided : "Nothing in this Constitution shall be
invoked to invalidate any law enacted by the Oireachtas which is expressed to be for the purpose ofAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

securing the public safety and the preservation of the State in time of war or armed rebellion or to
nullify any act done or purported to be done in pursuance on any such law." and contended that by
reason of this provision, the Emergency Powers (No. 41 F) Order, 1941 was protected from challenge
on the ground of contravention of Article 38, Section 1 and Article 40, Section 4, Sub-section (1) of
the Constitution. This contention clearly had the effect of putting the petitioners out of court and.,
therefore, they sought to get round this difficulty by arguing that the constitutional rights, which
they claimed to have been infringed were derived not from the written constitution, but from the
Common Law, and consequently. Article 28, Section 3, Sub-section (3) of the Constitution did not
stand in their way. This argument, which was very similar to the present argument advanced before
us, was unhesitatingly rejected by all the three judges who took part in the decision. Maguire J. said
:--
The contention is that the constitutional principles which assure to a citizen his
personal liberty., his right to resort to this Court for an order of habeas corpus, his
right that he shall not be tried on a criminal charge save in due course of law, have as
their source the Common Law, and exist side by side with these rights in the written
Constitution. In support of this contention reliance is placed on the decision of the
Supreme Court in Burke's Case (1940) I.R. 136), particularly on the passage in the
judgment of Murnaghan J. at p. 171, where he says 'certain constitutional principles
are stated in the Constitution but many other important constitutional principles
have been accepted as existing in the law then in force.
565. I do not find in the judgment of Murnaghan J. or elsewhere in the judgments in that case any
basis for the contention that these rights are to be found in a body of principles which exist side by
side with the written Constitution, having their source in the Common Law, and of equal validity
with the principles stated in the Constitution, and which on the argument here, would have the
added virtue that they are uncontrolled by Article 28, s. 3, Sub-section 3. The constitutional rights
relied upon in this case find clear expression in Article 40 and 38 of the Constitution. In my view
they cannot be found elsewhere than in the Constitution.
566. The advantages of a written Constitution are manifest. Such a Constitution can, and our
Constitution does, give rights such as these definite and clear expression. Our Constitution can, and
does, protect them against being whittled away save with great difficulty. The framers of the
Constitution have provided that, after the passage of a limited time, many, though not all .,of the
rights which it gives are put beyond the reach of interference by ordinary . law. The framers have,
however, deliberately inserted Article 28, s. 3, Sub-section 3, which is clearly designed to prevent the
Courts from invoking anything in the Constitution to invalidate enactments passed, or to nullify acts
done, or which purport to be done,, in pursuance of Acts passed for securing the public safety or the
preservation of the State in time of war."
Gavan Duffy, J. also observed to the same effect :
The applicants seek, in the alternative, to base their claims to habeas corpus and
prohibition upon antecedent rights of personal liberty and regular trial at CommonAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Law: but, whether or not the imminent Common Law of Ireland needed generally any
Article 50 (containing the laws in force) to retain its vigour, the particular Common
Law principles here invoked must both, in my opinion, of necessity have merged in
the express provisions declaring how the two corresponding rights are to be in force
under the new polity established by An Bunreacht.
And so did Martin Maguire, J. when he said :
It is argued, in the alternative, that, apart from the Constitution and existing side by
side with it, there is a body of constitutional law, founded on Common Law, and
comprising the same constitutional rights which the prosecutors seek to assert, and
in respect of which they demand the relief claimed in these proceedings. This
argument involves the propositions that the State has two Constitutions, the one
enacted by the people, written and denned; the other unwritten and undefined, and
that the latter may be invoked, or called in aid, to the extent even of defeating the
clear terms of the Constitution where a conflict real or apparent is alleged between
them. There is no authority for these propositions. I am unable to accept this
argument.
On this view, all the three judges of the High Court held that the Emergency Powers
(No 41-F) Order,, 1941 was immune from challenge by reason of Article 28, Section 3,
Sub-section (3) of the Constitution. This decision was taken in appeal and affirmed
by the Supreme Court, but this point about the continuance of the common law rights
side by side in the constitution, was not examined since it was obvious that the
Emergency Powers (No. 41 F) Order, 1941 should not be set at naught on the ground
of repugnancy to any supposed Common Law rights. It will be seen that there is a
close analogy between this decision of the High Court and the present case and the
observations of the three judges quoted above are directly applicable here.
567. The detenus, however, strongly relied on the decisions of this Court in Bharat Singh's case
(supra), Ibralum & Co.'s case (supra) Berrnet Coleman & Co.'s case (supra) and Shree Meenakshi
Mills' case (supra) in support of their contention that the principle of rule of law that the executive
cannot' act to the prejudice of a person except by authority of law continues to exist as a distinct and
independent principle unaffected inter alia by the enactment of Article 21. I have already referred to
these decisions earlier and it will be evident from what I have said, that these decisions do not lay
down any such proposition as is contended for on behalf of the detenus. What these decisions say is
only this, namely, that Article 358 protects against challenge under Article 19 only such executive
action as is "taken under lawful authority and if any executive action is taken without authority of
law or. in pursuance of a law which is void, it will not be protected from challenge under Article 19
by Article 358 and it will be void to the extent to which it conflicts with Article 19. These decisions,
properly read, do not support the thesis put forward on behalf of the detenus.
568. The detenus then relied on the decision of this Court in Bidi Supply Co. v. Union of India [1956]
S. C. R. 267. There, an omnibus order was made under Section 5, Sub-section (7A) of the IncomeAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Tax Act transferring cases of the petitioner form one place to another. The petitioner challenged this
order as being outside the power conferred under Section 5, Sub-section (7A) and hence violative of
the fundamental rights guaranteed to him by Articles 14, 19(1) (f) and (b) and 31 of the Constitution.
this Court held that the omnibus order made in this case was not contemplated or sanctioned by
Sub-section (7A) of Section 5 and, therefore, the petitioner was still entitled to the benefit of the
provisions of Sub-sections (1) and (2) of Section 64 and since the Income Tax authorities had by an
executive order., unsupported by law, picked out the petitioner for discriminatory-treatment, there
was violation of the equality clause of the Constitution and hence the petitioner was entitled to relief
under Article 32 of the Constitution setting aside the impugned order. S.R. Das-, C.J., speaking on
behalf of the Court, observed :
As said by Lord Aktin in Eshugbayi Eleko's case the executive can only act in
pursuance of the powers given to it by law and it cannot interfere with the liberty,
property and rights of the subject except on the condition that it can support the
legality of its action before the Court. Here there was no such order of transfer as is
contemplated or functioned by Sub-section (7A) of Section 5 and, therefore, the
present assessee still has the right, along with all other Bidi merchants carrying on
business in Calcutta, to have his assessment proceedings before the Income-'ax
Officer OL the area in which his place of business is situate. The income-tax
authorities have by an executive order, unsupported by law, picked out this petitioner
and transferred all his cases by an omnibus order unlimited in point of time.
(Emphasis supplied).
and since the action of the Income-tax authorities was contrary to Sub-sections (1)
and (2) of Section 64, the impugned order was held to be bad. Hence it will be
noticed that the impugned order operated to the prejudice of the petitioner by
affecting his rights under Section (1) and (2) of Section 64 but it did not affect any of
his rights under Article 19 or Article 21 or Clause (1) of Article 31 and therefore, the
principle of rule of law that the executive cannot act to the prejudice of a person
without authority of law could be legitimately invoked. It continued to be in law in
force to the extent to which if was not recognised and enacted in any provision of the
Constitution.
569. The next decision to which I must refer in this connection is Bishan Das and Ors. v. The State of
Punjab . This was a petition under Article 32 of the Constitution and the action of the officers of the
State Government impugned in this case was forcible dispossession of the petitioners of properties
which were in their management and possession. The challenge to the impugned action of the
officers of the State Government was based on violation of the fundamental right guaranteed under
Clause (1) of Article 31. this Court upheld the challenge and struck down the impugned action as
being without the authority of law and while doing so, made the following observations which were
strongly relied on behalf of the detenus : "Before we part with this case, we feel it our duty to say
that the executive action taken in this case by the State and its officers is destructive of basic
principle of the rule of law--the action of the Government in taking the) law into their hands andAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

dispossessing the petitioners by the display of force, exhibits a callous disregard of the normal
requirements of the rule of law--We have here a highly discriminatory and autocratic act which
deprives a person of the possession of property without reference to any law or legal authority",
(emphasis supplied). These observations made in the context of a petition for enforcement of the
fundamental right under Article 31, Clause (1) clearly show that this Court regarded the principle of
rule of law that no person shall be deprived of his property "without reference to any law or legal
authority" as embodied in Article 31, Clause (1) and did not rely upon this principle of rule of law as
a distinct and independent principle apart from Article 31, Clause (1) : otherwise the petition under
Article 32 would not have been maintainable and this Court could not have granted relief.
570. The last decision to which I must refer is the decision of this Court in State of Bihar v.
Kameshwar Prasad Verma . That was a case arising out of a petition for a writ of habeas corpus filed
under Article 226 for release of one Bipat Gope from illegal detention. this Court held that the State
Government had failed to show under what lawful authority Bipat had been re-arrested and in the
absence of such lawful authority, the detention was illegal. Kapur, J., speaking on behalf of the Court
referred with approval to the observations of Lord Atkin in Eshugbayi Eleko's case (supra) and
pointed out : "It is the same jurisprudence which has been adopted in this country on the basis of
which the courts of this country exercise jurisdiction". These observations were relied upon on
behalf of the detenus to contend that the principle of rule of law in Eshugbayi Elekos case (supra)
was held by this Court to have been adopted in this country and it must, therefore, be enforced
independently of Article 21. But I do not think that is the effect of these observations. What Kapur,
J., said was only this, namely that the principle of rule of law in Eshugbayi Eleko's case (supra) had
been adopted in this country. He did not make it clear how it had been adopted nor did he say that it
had been adopted as a distinct and independent principle apart from the fundamental rights. There
can be no doubt that the principle in Eshogbayi Eleko's case (supra) had been adopted in this
country in Article 21 to the extent to which it protects personal liberty. It will, thererefore., be seen
that there is no decision of this Court which says that there is a right of personal liberty based on the
rule of law distinct and independent from that guaranteed by Article 21.
571. I must now turn to the decision of this Court in Makhan Singh v. State of Punjab (supra) on
which very strong reliance was placed on behalf of the detenus. That was a decision given in a batch
of twenty-six appeals from the decisions of the High Courts of Bombay and Punjab. The appellants
in these six appeals were detained respectively by the Punjab and the Maharashtra State
Governments under Rule 30(1") (b) of the Defence of India Rules made by the Central Government
in exercise of the powers conferred on it by Section 3 of the Defence of India Ordinance, 1962. They
applied to the Punjab and the Bombay High Courts respectively under Section 491(1) (b) of the CrPC
and alleged that they had been improperly and illegally detained. Their contention was that Section
3(2)(15)(i) and Section 40 of the Defence of India Act, 1962 which replaced the Defence of India
Ordinance and Rule 30(1) (b) under which they were detained were constitutionally invalid because
they contravened their fundamental rights under Articles 14, 21 and 22 C4) (5) and (7) of the
Constitution and so they claimed that an order should be passed in their favour directing the
respective State Governments to set them at liberty. There was in operation at that time a
Proclamation of Emergency dated 26th October, 1962 issued by the President under Article 352,
Clause (1) on account of the Chinese aggression. The President had also issued an order dated 3rdAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

November, 1962 under Article 359, Clause (1) suspending the right of any person to move any court
for the enforcement of the rights conferred by Articles 21 and 22 "if such person has been deprived
of any such rights under the Defence of India Ordiance, 1962 (4 of 1962) or any rule or order made
thereunder." The contention of the State Governments based on this Presidential Order was--and
that contention found favour with both High Courts--that the Presidential Order created a bar which
precluded the appellants from maintaining the petitions under Section 491 (1) (b) of the CrPC. On
this contention. two questions arose for determination before this Court. The first was as to what
was the true scope and effect of the Presidential Order and the second was whether the bar created
by the Presidential Order operated in respect of applications made by the appellants under Section
491(l)(b) of the CrPC. this Court in a majority judgment delivered by Gajendragadkar, J., analysed
the provisions of Article 359, Clause (1) and held that the words "any court" in that Article must be
given their plain grammatical meaning and must be construed to mean any court of competent
jurisdiction which would include the Supreme Court and the High Courts before which the specified
rights can be enforced by the citizens". The majority judgment then proceeded to add ; "The sweep
of Article 359(1) and the Presidential Order issued under it is thus wide enough to include all claims
made by citizens in any court of competent jurisdiction when it is shown that the said claims cannot
be effectively adjudicated upon without examining the question as to whether the citizen is, in
substance, seeking to enforce any of the said specified fundamental rights. " Having thus disposed of
the first question, the majority judgment went on to consider the second question and after
analysing the nature of the proceedings under Section 491(1) (b) of the CrPC, held that the
prohibition contained in Article 359, Clause (1) and the Presidential Order would apply "as much "to
proceedings under Section 491(1)(b) as to those under Article 226(1) and Article 32(1)". It was
obvious that on this view, the petitions under Section 491(1)(b) were not maintainable,, since the
only ground on which they challenged the orders of detention was that the provisions of Section
3(2)(15)(i) as well as Rule 30(1)(b) were invalid as offending against Articles 14, 21 and 22 and in the
circumstances it was not necessary for this Court to express any opinion on the question as to what
were the pleas available to a citizen under the Presidential Order in challenging the legality or
propriety of his detention. Still, however, the majority judgment proceeded to give its opinion on
this question? in the following terms :
It still remains to consider what are the pleas which are now open to the citizens to
take in challenging the legality or the propriety of their detentions either under
Section 491 (1)(b) of the Code or Article 226(1) of the Constitution. We have already
seen that the right to move any court which is suspended by Article 359(1) and the
Presidential Order issued under it is the right for the enforcement of such of the
rights conferred by Part III as may be mentioned in the Order. If in challenging the
validity of his detention order, the detenu is pleading any right outside the rights
specified in the Order, his right to move any court in that behalf is not suspended,
because it is outside Article 359(1) and consequently outside the Presidential Order
itself. Let us take a case where a detenu has been detained in violation of the
mandatory provisions of the Act. In such a case, it may be open to the detenu to
contend that his detention is illegal for the reason that the mandatory provisions of
the Act have been contravened. Such a plea is outside Article 359(1) and the right of
the detenu to move for his release on such a ground cannot be affected by theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Presidential Order.
Take also a case where the detenu moves the Court for a writ of habeas corpus on the
ground that his detention has been ordered malafide. It is hardly necessary to
emphasise that the exercise of a power malafide is wholly outside the scope of the Act
conferring the power and can always be successfully challenged. It is true that a mere
allegation that the detention is malafide would not be enough : the detenu will have
to prove the malafides. But if the mala-fides are alleged, the detenu cannot be
precluded from substantiating his; plea on the ground of the bar created by Article
359(1) and the Presidential Order. That is another kind of plea which is outside the
purview of Article 359(1).--We ought to add that these categories of pleas have been
mentioned by us by way of illustration., and so, they should not be read as exhausting
all the pleas which do not fall within the purview of the Presidential Order.
The strongest reliance was placed on behalf of the detenus on these observations in
the majority judgment. It was contended on behalf of the detenus that the
observations clearly showed that if an order of detention is challenged on the ground
that it is in violation of the mandatory provisions of the Act or is made malafide, such
a plea would be outside Article 359, Clause (1) and would not be barred by a
Presidential Order specifying Article 21. The detenus, in support of this contention
leaned heavily on the words 'such a plea is outside Article 359(1) and the right of the
detenu to move for his release on such a ground cannot be affected by the
Presidential Order", and "that is another kind of plea which is outside the purview of
Article 359(,1) occurring in these observations and urged that such a plea was held to
be permissible because it was outside the purview of Article 359, Clause (1) and not
because it was outside the terms of the particular Presidential Order.
572. Now, at first blush, these observations do seem to support the contention of the detenus. But
there are two very good reasons why I do not think these observations can be of much help in the
determination of the question before us. In the first place, the question as to what were the other
pleas available to a detenu in challenging the legality or propriety of his detention, despite the
President Order dated 3rd November, 1962, was not in issue before the Court and did not fall, to be
decided and the aforesaid observations made by the Court on this question were, therefore, clearly
obiter. These observations would undoubtedly be entitled to great weight, but, as pointed out by this
Court in H. Maharajadhiraja Madhav Rao Jiwaji Rao Scindia Bahadur and Ors. v. Union of India
"an obiter cannot take the place of the ratio. Judges are not oracles". These observations do not,
therefore, have any binding effect and they cannot be regarded as conclusive on the point. Moreover,
it must be remembered that when we are considering the observations of a high judicial authority
like this Court, the greatest possible care must be taken to relate the observations of a judge to the
precise issues before him and to confine such observations, even though expressed in broad terms,
in the general compass of the question before him, unless he makes it clear that he intended his
remarks to have a wider ambit. It is not possible for judges always to express their judgments so as
to exclude entirely the risk that in some subsequent case their language may be misapplied and any
attempt at such perfection of expression can only lead to the; opposite result of uncertainty and evenAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

obscurity as regard the case in hand. It may be noted that, in this case the Presidential Order dated
3rd November, 1962, which came up for consideration before the Court,, was a conditional order,
inasmuch as it operated to suspend the right of any person to move any court for enforcement of the
rights conferred by Articles 21 and 22, only if he was deprived of any such rights under the Defence
of India Act, 1962 or any rule or order made under it. It was in the context of this Presidential Order
that the aforesaid observations were made by this Court. It is obvious that, on the terms of this
Presidential Order, if a person was deprived of his personal liberty otherwise than in accordance
with the provisions of the Defence of India Act, 1962 or any rule or order made under it, his right to
move the Court for enforcement of his right of personal liberty under Article 21 would not be barred
by the Presidential Order. That is why it was said in this case, that, if the detention is illegal for the
reason that the mandatory provisions of the Defence of India Act., 1962 or, any rule or order made
thereunder have been contravened or that the detention has been ordered mala fide, such a plea
would not fall within the terms of the Presidential Order and hence it would be outside the purview
of Article 359, Clause (1). That is the only way in which these observations can and must be
understood. It was pointed out by the House of Lords as far back as 1901 in Queen v. Leatham
[1901] A. C. 495 "Every judgment must be read as applicable to the particular facts proved, or
assumed to be proved, since the generality of the expressions which may be found there are not
intended to be exposition of the whole law, but are governed and qualified by the particular facts in
which such expressions are to be found." this Court had also occasion to point out in the State of
Orissa v. Sudhansu Sekhar Misra that the observations in a judgment must be "only in the context of
the question that arose for decision." It would not be right, as observed by this Court in Madhav Rao
v. Union of India (supra), "to regard a word, a clause or a sentence occurring in a judgment of this
Court, divorced from its context, as containing a full exposition on the law on a question"
particularly "when the question did not even fall to be answered in that judgment". Here, in the
present case, unlike the Presidential Order dated 3rd November, 1962, which was a conditional
Order, the Presidential Order dated 27th June, 1975 is, on the face of it. an unconditional one and;
as such there is a vital difference in effect between the Presidential Order dated 3rd November, 1962
and the present Presidential Order. In fact, it appears that because of the interpretation and effect of
the Presidential Order dated 3rd November, 1962 given in this case and the subsequent cases
following it, the President deliberately and advisedly departed from the earlier precedent and made
the present Presidential Order an unconditional one. These observations made in the context of a
conditional Presidential Order cannot, therefore, be read as laying down that a plea that an order of
detention is not in accordance with the provisions of law or is mala fide is outside the purview of
Article 359,, Clause (1) and would not be barred even by an unconditional Presidential Order such as
the one we have in the present case.
573. This distinguishing feature of Makhan Singh's case (supra) was in fact highlighted and
emphasised in the subsequent decision of this Court in A. Nambiar v. Chief Secretary There
Gajendragadkar, C.J., stressed the conditional nature of the Presidential Order dated 3rd
November, 1962 and indicated that it was in view of the last clause of the Presidential Order, that
the aforesaid observations were made by this Court in Makhan Singh's case. The learned Chief
Justice explained the position in the following words :Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

In Makhan Singh Tarsikka v. The Slate of Punjab a Special Bench of this Court has
had occasion to consider the effect of the Proclamation of Emergency issued by the
President and the Presidential Order with which we are concerned in the present writ
petitions.--this Court took the precaution of pointing out that as a result of the issue
of the Proclamation of Emergency and the Presidential Order, a citizen would not be
deprived of his right to move the appropriate court for a writ of habeas corpus on the
ground that his detention has been ordered mala fide. Similarly, it was pointed out
that if a detenu contends that the operative provisions of the Defence of India
Ordinance under which he is detained suffer from the vice of excessive delegation,
the plea thus raised by the detenu cannot, at the threshold, be said to be barred by the
Presidential Order, because, in terms, it is not a plea which is relatable to the
fundamental rights specified in the said order.
Let us refer to two other pleas which may not fall within the purview of the
Presidential Order. If the detenu, who is detained under an order passed under Rule
30(1)(b), contends that the said Order has been passed by a delegate outside the
authority conferred on him by the appropriate Government under Section 40 of the
Defence of India Act. or it has been exercised inconsistently with the conditions
prescribed in that behalf,, a preliminary bar against the competence of the detenu's
petition cannot be raised under the Presidential Order, because the last clause of the
Presidential Order would not cover such a petition, and there is no doubt that unless
the case falls under the last clause of the Presidential Order, the bar created by it
cannot be successfully invoked against a detenu. Therefore, our conclusion is that the
learned Additional Solicitor-General is not justified in contending that the present
petitions are incompetent under Article 32 because of the Presidential Order. The
petitioners contend that the relevant Rule under which the impugned orders of
detention have been passed, is invalid on grounds other than those based on Articles
14, 19, 21 and 22, and if that plea is well-founded, the last clause of the Presidential
Order is not satisfied and the bar created by it suspending the citizens' fundamental
rights under Articles 14, 21 and 22 cannot be pressed into service.
These observations, and particularly the portions underlined by me, clearly show that
it was because of the conditional nature of the Presidential Order that the view was
taken that if a detente contends that tie order of detention has been made mala fide
or that it has been passed by a delegate outside the authority conferred on him under
the Act or that it has been exercised inconsistently with the conditions prescribed in
that behalf", that is, it is not in accordance with the provisions of law, such a plea
would not be barred at the threshold by the Presidential Order. The conditional
nature of the Presidential Order was also stressed by this Court in State of
Maharashtra v. Prabhakar Pandurang Sangzgiri [1966] 1 S.C.R. 702 where this Court,
speaking through Subba Rao, J., pointed out that in view of the last clause of the
Presidential Order, "if a person was deprived of his personal liberty not under the Act
or a rule or order made thereunder, but in contravention thereof, his right to move
the said courts", that is the High Court and the Supreme Court "in that regard wouldAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

not be suspended".
574. It was then contended on behalf of the detenus that in any event the right of personal liberty is
a natural right which inheres in every one from the moment of his birth and this right can always be
enforced by the detenus under Article 226 by a writ "for any other purpose" and the Presidential
Order does not operate as a bar. When, in answer to this contention the Union of India and the State
Governments relied on His Holiness Kesavananda Bharati Sripadagalavaru v. State of Kerala [1963]
Supp. S.C.R. 1, the detenus urged that Kesavananda Bharati's case (supra) did not say that there is
no natural right inhering in a person, but all that it said was that natural rights do not stand in the
way of amendment of the Constitution. Kesavanand Bharati's case (supra) according to the detenus,
did not negative the existence and enforceability of natural rights. But this contention of the detenus
is clearly belied by the observations from the judgments of at least seven of the judges who decided
Kesavanand Bharati's case (supra). Ray, C. J. said at pages 419 of the Report: "Fundamental rights
are conferred by the Constitution. There are no natural rights under our Constitution." Palekar, J.,
also said at page 594 of the Report : "The so called natural rights--have in course of time--lost their
utility as such in the fast changing world and are recognised in modern political constitutions only
to the extent that organised society is able to respect them." So also Khanna, J. said at page 703 of
the Report: "-- the later writers have generally taken the view that natural rights have no proper
place outside the Constitution and the laws of the State. It is up to the State to incorporate natural
rights, or such of them as are deemed essential, and subject to such limitations as are considered
appropriate, in the Constitution of the laws made by it. But independently of the Constitution and
the laws of the State, natural rights can have no legal sanction and cannot be enforced." Mathew, J.,
too, spoke to the same effect when he said at page 814 of the Report : "Although called 'rights', they
are not per se enforceable in courts unless recognised by the positive law of a State". Beg, J. also
discounted the theory of natural rights at pages 881 and 882 of the Report and Dwivedi, J. observed
at page 910 of the Report that to regard fundamental rights as natural rights overlooks the fact that
some of these rights did not exist before the Constitution and '"were begotten by our specific
national experience". Chandrachud, J., was equally emphatic in saying at pages 975 and 976 of the
Report that "There is intrinsic evidence in Part III of the Constitution to show that the theory of
natural rights was not recognised by our Constitution makers--The natural theory stands, by and
large, repudiated today--The belief is now widely held that natural rights have no other than
political value". It may be pointed out that Subba Rao. I, also in I.C. Golak Nath and Ors. v. State of
Punjab at page 789 of the Report rejected the theory of natural rights independent and apart from
fundamental rights in Part III. He said : ''Fundamental rights are the modern name for what have
been traditionally known as natural rights". There is, therefore, no scope for the contention that
even if the enforcement of the Fundamental right conferred by Article 21 is suspended by the
Presidential Order, the detenu can still enforce a supposed natural right of personal liberty in a
court of law.
575. I may also refer to one other argument advanced on behalf of the detenus that in any event the
right not to be deprived of personal liberty except by authority of law is a statutory right which can
be enforced despite the Presidential Order suspending enforcement of the right of personal liberty
guaranteed under Article 21. I agree and there can be no doubt about it that if the positive law of the
State decrees that no person shall be deprived of his personal liberty except according to theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

procedure prescribed by law, the enforcement of such statutory right would not be barred by the
Presidential Order. But 1 am afraid, the premise on which this argument is founded is incorrect.
There is no legislation in our country which confers the right of personal liberty by providing that
there shall be no deprivation of it except in accordance with law. On the contrary, Section 18 of the
Maintenance of Internal Security Act, 1971 enacts that no person in respect of whom an order of
detention is made or purported to be made under Section 3 shall have any right to personal liberty
by virtue of natural law or common law. if any. The Indian Panel Code in Section 342 undoubtedly
makes it penal to wrongfully confine any person and the offence of wrongful confinement postulates
that no one shall be deprived of his personal liberty except by authority of law. But it can hardly be
said on that account that Section 342 of the Indian Penal Code confers a right of personal liberty.
The utmost that can be said is that this Section proceeds on a recognition of the right of personal
liberty enacted in Article 21 and makes it an offence to wrongfully confine a person in breach of the
right conferred by that constitutional provision.
576. Then I must refer to one other contention of the detenus and that is that the remedy under
Article 226 can be invoked not only for the purpose of enforcement of the fundamental rights, but
also "for any other purpose". These words greatly enlarge the jurisdiction of the High Court and the
High Court can issue a writ of habeas corpus if it finds that the detention of a person is illegal. It is
not necessary for this purpose that the court should be moved by the detenu. It is sufficient if it is
moved by any person affected by the order of detention. When it is so moved and it examines the
legality of the order of detention, it does not enforce the right of personal liberty of the detenu, but it
merely keeps the executive within the bounds of law and enforces the principle of legality. The
remedy of habeas corpus is a remedy in public law and hence it cannot be excluded by suspension of
enforcement of the right of an individual. This contention of the detenus does appear, at first sight,
to be quite attractive, but I am afraid, it is not well founded. It fails to take into account the
substance of the matter. When an applicant moves the High Court for a writ of habeas corpus, he
challenges the legality of file order of detention on the ground that it is not in accordance with law.
That challenge proceeds on the basis that the executive cannot deprive a person of his personal
liberty except by authority of law and that is why the order of detention is bad. But once it is held
that the obligation of the executive not to deprive a person of his personal liberty except in
accordance with law is to be found only in Article 21 and no where else, it must follow necessarily
that, in challenging the legality of the detention, what the applicant claims is that there is infraction
by the executive of the right of personal liberty conferred under Article 21 and that immediately
attracts the applicability of the Presidential Order. If we look at the substance of the matter and
analyse what is it exactly that the High Court is invited to do, it will be clear that what the applicant
wants the High Court to do is to examine whether the executive has carried out the obligation
imposed upon it by Article 21 not to deprive a person of his personal liberty except according to the
procedure prescribed by law and if it finds that the executive has failed to comply with this
obligation, then to strike down the order of detention. That is precisely what is not permitted to be
done by the Presidential Order, for it plainly amounts to enforcement of the right of personal liberty
conferred by Article 21. The words "any other purpose" cannot be availed of for the purpose of
circumventing the constitutional inhibition flowing from the Presidential Order.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

577. It is necessary to point out that Article 359 Clause (1) and the Presidential Order issued under it
do not have the effect of making unlawful actions of the executive lawful. There can be no doubt that
the executive is bound to act in accordance with law and cannot flout the command of law. The
executive cannot also act to the detriment of a person without authority of law or except in
accordance with law. If the executive takes any action which is not supported by law or is contrary to
law, its action would be unlawful. This unlawful characteristic of the action is not obliterated by the
Presidential Order issued under Article 359 Clause (1). Article 359, Clause (1) and the Presidential
Order issued under it do not give any power to the executive to alter or suspend or flout the law nor
do they enlarge the power of the executive so as to permit it to go beyond what is sanctioned by law.
They merely suspend the right of a person to move any court for redress against the unlawful action
of the executive, if his claim involves enforcement of any of the fundamental rights specified in the
Presidential Order. This is a position akin in some respects to that in the United States when the
privilege of the writ of habeas corpus is suspended under Article 1, Placitium 9, Clause (2) of the
United States Constitution and in Great Britain when the Habeas Corpus Suspension Act is passed.
It must inevitably follow from this position that as soon as the emergency comes to an end and the
Presidential Order ceases to be operative, the unlawful action of the executive becomes actionable
and the citizen is entitled to challenge it by moving a court of law.
578. It will be clear from what is stated above that whilst a Presidential Order issued under Article
359, Clause (1) is in operation, the rule of law is not obliterated and it continues to operate in all its
vigour. The executive is bound to observe and obey the law and it cannot ignore or disregard it. If
the executive commits a breach of the law, its action would be unlawful, but merely the remedy
would be temporarily barred where it involves enforcement of any of the fundamental rights
specified in the Presidential Order. This would be obvious if we consider what would be the position
under the criminal law. If the executive detains a person contrary 'to law or shoots him dead without
justifying circumstances, it would clearly be an offence of wrongful confinement in one case and
murder in the other, punishable under the relevant provisions of the Indian Penal Code, unless the
case falls within the protective mantle of Section 76 or 79 and the officer who is responsible for the
offence would be liable to be prosecuted, if there is no procedural bar built by the CrPC against the
initiation of such prosecution. The Presidential Order suspending the enforcement of Article 21
would not bar such a prosecution and the remedy under the Indian Penal Code would be very much
available. The offence of wrongful confinement or murder is an offence against the society and any
one can set the criminal law in motion for punishment of the offender. When a person takes
proceedings under the CrPC in connection with the offence of wrongful confinement or murder or
launches a prosecution for such offence, he cannot be said to be enforcing the fundamental right of
the detenu or the murdered man under Article 21 so as to attract the inhibition of the Presidential
Order.
579. So also, if a positive legal right is conferred on a person by legislation and he seeks to enforce it
in a court, it would not be within the inhibition of a Presidential Order issued under Article 359,
Clause (1). Take for example the class of cases of detention where no declaration has been made
under Sub-sections (2) and (3) of Section 16A. This category would cover cases where orders of
detention have been passed prior to June 25, 1975, because in such cases no declaration under
Sub-sections (2) or (3) of Section 16A is contemplated and it would also cover the rather exceptionalAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

cases where orders of detention have been made after 25th June, 1975 without a declaration under
Sub-section (2) or Sub-section (3) of Section 16A. Sections 8 to 12 would continue to apply in such
cases and consequently the detaining authority would be under an obligation to refer the case of the
detenu to the Advisory Board and if the Advisory Board reports that there is in its opinion no
sufficient cause for the detention of the detenu,, the State Government would be bound to revoke the
detention order and release the detenu. That is the plain requirement of Sub-section (2) of Section
12. Now. suppose that in such a case the State Government fails to revoke the detention order and
release the detenu in breach of its statutory obligation under Sub-section (2) of Section 12. Can the
detenu not enforce this statutory obligation by filing a petition for a writ of mandamus ? The answer
must obviously be: he can. When he files such a petition for a writ of mandamus, he would be
enforcing his statutory right under Sub-section (2) of Section 12 and the enforcement of such
statutory right would not be barred by a Presidential Order specifying Article 21. The Presidential
Order would have no operation where a detenu is relying upon a provision of law to enforce a legal
right conferred on him and is not complaining of absence of legal authority in the matter of
deprivation of his personal liberty.
580. I may also refer by way of another illustration to Section 57 of the CrPC Code, 1973. This
Section provides that no police officer shall retain in custody a person arrested without warrant for a
longer period than under all the circumstances of case is reasonable, and such period shall not, in
the absence of a special order of a magistrate under Section 167, exceed 24 hours exclusive of the
time necessary for the journey from the place of arrest to the magistrate's court. There is clearly a
legal injunction enacted by this Section requiring a police officer not to detain an arrested person in
custody for a period longer than 24 hours without obtaining a special order of a magistrate and to
release him on the expiration of such period of 24 hours, if in the meantime such special order is not
obtained. If, in a given case, an arrested person is detained in custody by the police officer for a
period longer than 24 hours without obtaining an order of a magistrate, can he not apply to the
magistrate that he should be directed to be released by the police officer under Section 57 ? Would
such an application be barred by a Presidential Order specifying Article 21 ? I do not think so. When
the arrested person makes such an application, he seeks to enforce a statutory obligation imposed
on the police officer and a statutory right created in his favour by Section 57 and that would not be
barred, because what is suspended by a Presidential Order specifying Article 21 Is the right to move
the court for enforcement of the fundamental right conferred by that Article and not the right to
move the court for enforcement of the statutory right to be released granted under Section 57.
581. I may take still another example to illustrate the point I am making. Take a case where an order
of detention has been made without a declaration under Sub-section (2) or Sub-section (3) of
Section 16A). Sections 8 to 12 would admittedly apply in such a case and under Section 8, the
detaining authority would be bound to communicate to the detenu the grounds on which the order
of detention has been made and to afford him the earliest opportunity of making a representation to
the appropriate government. If, in a given case, the detaining authority declines to furnish the
grounds of detention to the detenu or to afford him an opportunity of making a representation, in
violation of the statutory right conferred on him under Section 8, can be detenu not enforce this
statutory right by filing a petition for a writ of mandamus against the detaining authority ? Would it
be any answer to such an application that the enforcement of the fundamental right conferred byAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

Article 22, Clause (5) has been suspended by the Presidential Order? The answer is plainly: no.
There are two rights which the detenu has in this connection: one is the fundamental right conferred
by Article 22, Clause (5) and the other is the statutory right conferred by Section 8. Though the
content of both these rights is the same, they have distinct and independent existence and merely
because enforcement of one is suspended, it does not mean that the other also cannot be enforced.
The 'theory of reflection' which found favour with the Kerala High Court in Fathima Beebi v. M. K.
Ravindranathan (1975) Cr. I. L. J. 1164 is clearly erroneous. If the right conferred under Section 8
were a reflection of the fundamental right conferred by Article 22, Clause (5) as the Kerala High
Court would have us believe, the removal of the fundamental right under Article 22, Clause (5),
which is the object reflected, must necessarily result in the effacement of the right under Section 8
which is said to constitute the reflection. But even if Article 22, Clause (5) were deleted from the
Constitution, Section 8 would still remain on the statute book until repealed by the legislature. The
Presidential Order would, not, therefore, bar enforcement of the right conferred by Section 8.
582. To my mind, it is clear that if a petition or other proceeding in court seeks to enforce a positive
legal right conferred by some legislation, it would not be barred by the Presidential Order. I may
also point out that, in the present case, if I had taken the view that there is. independently and apart
from Article 21, a distinct and separate right not to be deprived of personal liberty except according
to law, I would have held, without the slightest hesitation, that the Presidential Order suspending
enforcement of the fundamental right conferred by Article 21 does not have the effect of suspending
enforcement of this distinct and separate legal right. But since I have come to the conclusion, for
reasons already discussed, that there is no such distinct and separate right of personal liberty apart
from and existing side by side with Article 21, it must be held that when a detenu claims that his
detention is not under the Act or in accordance with it, he seeks to enforce the fundamental right
conferred by Article 21 and that is barred by the Presidential Order. Of course, this does not mean
that whenever a petition for a writ of habeas corpus comes before the Court, it must be rejected
straightaway without even looking at the averments made in it. The Court would have to consider
whether the bar of the Presidential Order is attracted and for that purpose, the Court would have to
see whether the order of detention is one made by an authority empowered to pass such an order
under the Act; if it is not, it would not be State action and the petition would not be one for
enforcement of the right conferred by Article 21. On this view in regard to the interpretation of the
constitutional provision, it is unnecessary to go into the question of construction and validity of
Section 18 of the Act.
583. It was strongly urged upon us that if we take the view that the Presidential Order bars the right
of a person to move a court even when his detention is otherwise than in accordance with law, there
would be no remedy against illegal detention. That would encourage the executive to disregard the
law and exercise arbitrary powers of arrest. The result would be--so ran the argument--that the
citizen would be at the mercy of the executive : every one would be living in a state of constant
apprehension that he might at any time be arrested and detained : personal liberty would be at an
end and our cherished values destroyed. Should we accept a construction with such fearful
consequences was the question posed before us. An impassioned appeal was made to us to save
personal liberty against illegal encroachments by the executive. We were exhorted to listen to the*
voice of judicial conscience as if judicial conscience were a blithe spirit like Shelley's Skylark free toAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

sing and soar without any compulsions. I do not think I can allow myself to be deflected by such
considerations from arriving at what I consider to be the correct; construction of the constitutional
provision. The apprehensions and fears voiced on behalf of the detenus may not altogether be ruled
out. It is possible that when vast powers are vested in the executive, the exercise of which is immune
from judicial scrutiny, they may sometimes be abused and innocent persons may be consigned to
temporary detention. But merely because power may sometimes be abused, it is no ground for
denying the existence of the power. All power is likely to be abused. That is inseparable from the
nature of human institutions. The wisdom of man has not yet been able to conceive of a government
with power sufficient to answer its legitimate ends and at the same time incapable of mischief. In the
last analysis, a great deal must depend on the wisdom and honesty., integrity and character of those
who are in charge of administration and the existence of enlightened and alert public opinion. It was
Lord Wright who said in Liversidge v. Siglov Anderson (supra) that "the safeguard of British liberty
is in the good sense of the people and in the system of representative and responsible government
which has been evolved."
584. It is true that, if, in a situation of emergency, judicial scrutiny into legality of detention is held
to be barred by a Presidential Order specifying Article 21, illegalities might conceivably be
committed by the executive in exercise of the power of detention and unlawful detentions might be
made against which there would be no possibility of redress. The danger may not be dismissed as
utterly imaginary, but even so, the fact remains that when there is a crisis-situation arising out of an
emergency, it is necessary to best the Government with extra-ordinary powers in order to enable it
to overcome such crisis-situation and restore normal conditions. Even Harold Laski conceded in his
Article on "Civil Liberties in Great Britain in Wartime" that "the necessity--of concentrating
immense power in a Government waging total war is beyond discussion" and what he said there
regarding a Government waging total war must apply equally in relation to a Government engaged
in meeting internal subversion or disturbance, for the two stand on the same footing so far as our
Constitution is concerned. Now, when vast powers are conferred on the executive and judicial
scrutiny into the legality of exercise of such powers is excluded,, it is not unlikely that illegalities
might be committed by the executive in its efforts to deal with the crisis situation. Dicey, in his
"Introduction to the Study of Law of the Constitution" frankly admits that it is "almost certain that,
when the suspension of the Habeas Corpus Act makes it possible for the Government to keep
suspected persons in a prison for a length of time without bringing them to trial, a smaller or greater
number of unlawful acts will be committed, if not by the members of Ministry themselves, at any
rate by their agents." But howsoever unfortunate this situation might be, that cannot be helped. The
Constitution permits judicial scrutiny to be barred during times of emergency, because it holds that
when a crisis arises in the life of the nation, the rights of individuals must be postponed to
considerations of State and national safety must override any other considerations. I may add that
there is nothing very unusual in this situation because, as already pointed out above,, such a
situation is contemplated even in countries like the United States of America and Great Britain
which are regarded as bastions of democracy. But at the same time it must be remembered by the
executive that, because judicial scrutiny for the time being is excluded, its responsibility in the
exercise of the power of detention is all the greater. The executive is under an added obligation to
take care to see that it acts within the four corners of the law and its actions are beyond reproach. It
must guard against misuse or abuse of power, for, though such misuse or abuse may yieldAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

short-term gains, it is a lesson of history which should never be forgotten that ultimately means
have a habit of swallowing up ends.
585. Before I leave this question, I may point out that, in taking the view T have, I am not unaware
of the prime importance of the rule of law which, since the dawn of political history,, both in India of
Brahadaranyaka Uunishad and Greece of Aristotle, has tamed arbitrary exercise of power by the
government and constitutes one of the basic tenets of constitutionalism. I am not unmindful of the
famous words of Lord Atkin in his powerful dissent in Liversidge v. Anderson (supra) that "amid the
clash of arms"--and much more so in a situation of emergency arising from threat of internal
subversion--"laws are not silent. They may be changed, but they speak the same language in war and
in peace". I am also conscious--and if I may once, again quote the words of that great libertarian
Judge : "Judges are no respect-or of persons and stand between the subject and any attempted
encroachments on his liberty by the executive, alert to see that any coercive action is justified in
law". But at the same time it cannot be overlooked that, in the ultimate analysis, the protection of
personal liberty and the supremacy of law which sustains it must be governed by the Constitution
itself. The Constitution is the paramount and supreme law of the land and if it says that even if a
person is detained otherwise than in accordance with the law, he shall not be entitled to enforce his
right of personal liberty, whilst a Presidential Order under Article 359, Clause (1) specifying Article
21 is in force I have to give effect to it. Sitting as I do, as a Judge under the Constitution, I cannot
ignore the plain and emphatic command of the Constitution for what I may consider to be necessary
to meet the ends of justice. It is said that law has the feminine capacity to tempt each devotee to find
his own image in her bosom. No one escapes entirely.. Some yield blindly, some with sophistication.
Only a few more or less effectively resist. I have always leaned in favour of upholding; personal
liberty, for, I believe, it is one of the most cherished values of mankind. Without it life would not be
worth living. It is one of the pillars of free democratic society. Men have readily laid down their lives
at its altar, in order to secure it, protect it and preserve it. But I do not think it would be right for me
to allow my love of personal liberty to cloud my vision or to persuade me to place on the relevant
provision of the Constitution a construction which its language cannot reasonably bear. I cannot
assume to myself the role of Plato's 'Philosopher King' in order to render what I consider ideal
justice between the citizen and the State. After all,, the Constitution is the law of all laws and there
alone judicial conscience must find its ultimate support and its final resting place. It is in this spirit
of humility and obedience to the Constitution and driven by judicial compulsion, that I have come to
the conclusion that the Presidential Order dated 27th June, 1975 bars maintainability of a writ
petition for habeas corpus where an order of detention is challenged on the ground that it is mala
fide or not under the Act or not in compliance with it.
586. On the view I have taken in regard to the answer to be given to the first question, it would be
unnecessary to consider the second question, but since the second question has been debated fully
and elaborate arguments have been advanced before us touching not only the interpretation but also
the validity of Sub-section (9) (a), of Section 16A, I think it will be desirable if I pronounce my
opinion, on this question as well. But before I proceed to do so, I may make it clear once again that
though this question is framed in general terms and so framed, it invites the Court to consider the
area of judicial scrutiny in a petition for a writ of habeas corpus, it is not really necessary to embark
on a consideration of this issue, since it was conceded by the learned Attorney General, and in myAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

opinion rightly, that the area of judicial scrutiny remains the same as laid down in the decision of
this Court, subject only to such diminution or curtailment as may be made by Sub-section (9) (a) of
Section 16A. The learned Additional Solicitor General, who argued this question on behalf of the
Union of India, took us through various decisions of English courts on the is to as to what is the
nature of the jurisdiction which the Court exercises in a petition for a writ of habeas corpus, and
what is the manner in which such jurisdiction must be exercised. It is not necessary for the ,purpose
of these appeals to wade through these decisions and to analyse them, because the practice in our
country in regard to the exercise of this jurisdiction, as it has evolved over the years as a result of the
decisions of this Court, is a little different from that prevailing in England. This Court has never
insisted on strict rules of pleading in cases involving the liberty of at person nor placed undue
emphasis, on the question as to on whom the burden of proof lies. Even a postcard, written by a
detenu from jail has been sufficient to activise this Court into examining the legality of detention.
this Court has consistently shown great anxiety for personal liberty and refused to throw out a
petition merely on the ground that docs not disclose a prima facie case invalidating the order of
detention. Whenever a petition for a writ of habeas corpus has come up before this Court, it has
almost invariably issued a rule calling upon the detaining authority to justify the detention. this
Court has on many occasions pointed out that when a rule is issued,, it is incumbent on the
detaining authority to satisfy the Court that the detention of the petitioner is legal and in conformity
with the mandatory provisions of the Act. Vide Naranjan Singh v. Stale of Madhya Pradesh , Shaikh
Hanif, Gudma Majhi & Kamal Saha v. State of West Bengal [1974] 2 S.C.R. 258 and Dulal Roy v. The
District Magistrate, Burdwan and Ors.. It has also been insisted by this Court that, in answer to the
Rule, the detaining authority must place all the relevant facts before the Court which would show
that the detention is in accordance with the provisions of the Act. It would be no argument on the
part of the detaining authority to say that a particular ground is not taken in the petition. Vide
Nizanuiddin v. The State of West Bengal [1975] 2 S.C.R. 593. Once the Rule is issued, it is the
bounden duty of the Court to satisfy itself that all the safeguards provided by law have been
seruplously observed and the citizen is not deprived of his personal liberty otherwise than in
accordance with law. Vide Mohd. Alam v. State of West Bengal Khudirain Das v. State of West
Bengal and Ors. This practice marks a slight departure from that obtaining in Cinland but it has
been adopted by this Court in view of the peculiar socio-economic conditions prevailing in the
country. Where large masses of people are poor, illiterate and ignorant and access to the courts is
not easy on account of lack of financial resources, it would be most unreasonable to insist that the
petitioner should set out clearly and specifically the grounds on which he challenges the order of
detention an make out a prima facie case in support of those grounds before a Rule can be issued on
he petition and when the Rule is issued, the detaining authority should not be liable to do anything
more than just meet the specific grounds of challenge put forward by the petitioner in the petition.
Of course, I must make it clear that where an order of detention is challenged as mala fide, a clear
and specific averment to that effect would have to be made in the petition and in the absence of such
averment, the court would not entertain the plea of mala fide. The petitioner would have to make
out a prima facie case of mala fide before the detaining authority can be called upon to meet it.
Whether a prima facie case has been made out or not would depend on the particular facts and
circumstances of each case, but the test would be whether the prima facie case made out is of such a
nature that the Court feels that it requires investigation. The Court would then investigate and
decide the question of mda fide on the basis of the material which may be placed before it by bothAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

parties.
587. What is the area of judicial scrutiny in a petition for a writ of habeas corpus has been laid down
by this Court in: numerous decisions. It is not necessary to refer to all these decisions, since there is
one recent decision, namely, Khudiram Das v. State of West Bengal (supra) where the entire law on
the subject has been reviewed by a Bench of four judges: of this Court. There,, the effect of the
previous decisions has been considered and the law has been summarised at pages 843 to 845 of the
Report in a judgment delivered by me on behalf of the Court. I have carefully listened to the most
elaborate arguments advanced before us in this case and even after giving my most serious
consideration to them, I still adhere to all that I said in Khudiram Das's case (supra). I maintain that
the subjective satisfaction of the detaining authority is liable to be subjected to judicial scrutiny on
the grounds enumerated by me in Khudiram Das's case (supra) and the decision in Khudiram Das's
case (supra) lays down the correct law on the subject. The only question is : how far and to what
extent Sub-section (9) (a) of Section 16A has encroached upon this area of judicial scrutiny and
whether it is a valid piece of legislation.
588. Now the first question that arises for consideration is as to what is the correct interpretation of
Section 16A, Sub-section (9) (a). That Sub-section reads as follows :
(9) Notwithstanding anything contained in any other law or any rule having the force
of law--
(a) the grounds on which an order of detention is made or purported to be made
under Section 3 against any person in respect of whom,, a declaration is made under
Sub-section (2) or Sub-section (3) and any information or materials on which such
grounds or a declaration under Sub-section (2) or a declaration or confirmation
under Sub-section (3) or the non-revocation under subjection (4) of a declaration are
based, shall be treated as confidential and shall be deemed to refer to matters of State
and to be against the public interest to disclose and save as otherwise provided in this
Act, no one shall communicate or disclose any such ground, information or material
or any document containing such ground, information or material;
The argument urged on behalf of the detenus was that Sub-section (9) (a) of Section 16A should be
read down and construed so as not to exclude the power of the High Court in the exercise of its
jurisdiction under Article 226 to call for the grounds, information and materials on which the order
of detention is made and the declaration under Sub-section (2) is based with a view to satisfying
itself as regards the legality of the detention. It was pointed out on behalf of the detenus that, unlike
Section 54 of the Indian Income-tax Act, 1922 and Section 14 of the Preventive Detention Act, 1950,
Sub-section (9) (a) of Section 16A does not include any reference to a court and it is clear that it is
not directed, against the Court. Reliance was also placed on behalf of the detenus on the following:
statement of the law in Wigmore on Evidence (3rd ed.) vol. 8 at page 801, Article 2379 : "Any statute
declaring in general terms that official records are confidential should be liberally construed to have
an implied exception for disclosure when needed in court of justice", and reference was also made to
the decision of the English Court in Lee v. Burrell 170 English Reports 1402 in support of theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

proposition that in a statutory provision, like Sub-section (9) (a) of Section 16A, the Court must read
an implied exception in favour of the Court and particularly the High Court exercising constitutional
function under Article 226. It was also stressed on behalf of the detenus that if a wider construction
is placed on Sub-section (9) (a) of Section 16A taking within its sweep the High Court exercising
jurisdiction under Article 226, that Sub-section would be rendered void as offending Article 226 and
hence the narrower construction must be preferred which excludes the High Court from the purview
of the Sub-section. This contention, attractive though it may seem because it has the merit of saving
judicial scrutiny from being rendered ineffectual and illusory, is not justified by the plain language
of Sub-section (9) (a) of Section 16A and hence, despite these weighty considerations which have
been pointed out on behalf of the detenus. I find myself unable to accept it.
589. It is true that Sub-section (9) (a) of Section 16A does not specifically refer to any court. It does
not say in so many terms, as did Section 54 of the Indian Income-tax Act, 1922, that no court shall
require any officer to produce before it the grounds, information and materials on which the order
of detention is made or the declaration under Sub-section (2) or Sub-section (3) is based, nor does it
contain any provision, like Section 14 of the Preventive Detention Act, 1950 that no court shall allow
any statement to be made or any evidence to be given of such grounds, information and materials.
But there is inherent evidence in the Sub-section itself to show that it is intended to prevent
disclosure of such grounds, information and materials before a court. It says that the grounds,
information and materials on which the order of detention is made or the declaration under
Sub-section (2) or Sub-section (3) is based "shall be treated as confidential and shall be deemed to
refer to matters of State and to be against public interest to disclose". There is clearly an echo here of
Section 123 of the Indian Evidence Act. That Section is intended to prevent disclosure in a court of
"unpublished official records relating to any affairs of State" and likewise, Sub-section (9) (a) of
Section 16A must also be held to be designed to achieve the same end, namely, prevent, inter alia,
disclosure in a court. The words "shall be treated as confidential" and " shall be deemed to be
against the public interest to disclose" are very significant. If they are to have any meaning at all,
they must be construed as prohibiting disclosure even to a court. How can the grounds, information
and materials referred to in this Sub-section remain 'confidential, if they can be required to be
produced before a court? How can they be permitted to be disclosed to a court when the legislature
says in so many terms that it would be against the public interest to disclose them. Even if the court
holds its sittings in camera, there would be a real danger of leakage and that might, in a given case,
jeopardize national security and weaken the efforts towards meeting the crisis-situation arising out
of the emergency. Vide observations in the speech of Lord Wright at page 266 in Liversidge's case
(supra). Sub-section (9) (a) of Section 16A cannot, therefore, be read down so as to imply an
exception in favour of disclosure to a court.
590. But then it was contended on behalf of the detenus that if, on a proper construction of its
language, Sub-section (9) (a) of Section 16A precludes the High Court in exercise of its jurisdiction
under Article 226, from calling for the production of the grounds, information and materials on
which the order of detention is made or the declaration under Sub-section (2) or Sub-section (3) is
based, it would impede the exercise of its constitutional power by the High Court and make it
virtually ineffective and hence it would be void as offending Article 226. This contention requires
serious consideration. Prima facie it appears to be formidable, but for reasons which 1 shallAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

immediately proceed to state, I do not think it is well founded.
591. There can be no doubt that Article 226 is a constitutional provision and it empowers the High
Court to issue a writ of habeas corpus for enforcement of the fundamental right conferred by Article
21 and also for any other purpose. The High Court has, therefore, constitutional power to examine
the legality of detention and for that: purpose, to inquire and determine whether the detention is in
accordance with the provisions of law. Now, obviously this being a constitutional power, it cannot be
taken away or abridged by a legislative enactment. If there is any legislative provision which
obstructs or retards the exercise of this constitutional power, it would be void. There are several
decisions of this Court which recognise and lay down this proposition. It was said by this Court in
one of its early decisions in Hari Vishnu Kamath v. Syed Ahmad Ishaque and Ors. [1955] 1 S.R. 1104
that the jurisdiction under Article 226 having been conferred by the Constitution, limitation cannot
be placed on it except by the Constitution itself. So also n Durga Shankar Mehta v. Thakur Raghuraf
Singh and Ors. this Court, while considering the effect of Section 105 of the Representation of the
People Act, 1951 which gave finality to an order made by the Election Tribunal, observed that that
Section cannot "cut down and affect the overriding powers which this Court can exercise in the
matter of grant of special leave under Article 136", and the same rule was applied to Article 226 in
Raj Krushna Base v. Binod Kanungo and Ors. [1954] S. C. R. 913 where the Court held that Section
105 cannot take away or whittle down the power of the High Court: under Article 226. The same
view was taken by this Court in In re : The Kerala Education Bill, 1957 [1959] S. C. R. 995 where S.
R. Das, C. J., speaking on behalf of the Court said in relation to Article 226 that "No enactment of a
State legislature can, as long as that Article stands, fake away or abridge the jurisdiction and power
conferred on the High Court by that Article". this Court in Prem Chand Garg v. Excise
Commissioner, U.P. Allahabad [1963] Supp. 1 S. C. R. 885 actually struck down Rule 12 of Order
XXXV of the Supreme Court Rules which required the petitioner in a writ petition under Article 32
to furnish security for the cost of the respondent, on the ground that it retarted or obstructed the
assertion or vindication of the fundamental right guaranteed under Article, 32 by imposing a
pecuniary obligation on the petitioner. The principle of this decision must equally apply in a case
where the legislative provision impedes or obstructs the exercise of the constitutional power of the
High Court under Article 226. It is, therefore, clear that if it can be shown that Sub-section (9) (a) of
Section 16A abridges or whittles down the constitutional power of the High Court under Article 226
or obstructs or retards its exercise, it would be void as being in conflict with Article 226.
592. Now, it is settled law that when a petition for writ of habeas corpus is filed and a Rule is issued,
it is the bounden duty of the Court to satisfy itself that all the safeguards provided by law have been
scrupulously observed and the liberty of the detenu has not been taken away otherwise than in
accordance with law. Vide Khudiram Das v. State of West Bengal (supra). The Court may also for the
purpose of satisfying itself as regards the legality of detention, call for the record of the case relating
to the detention and look into it. That is what the Court did in Biren Dutta and Ors. v. Chief
Commissioner of Tripura and Anr. , an interim order was made by this Court "directing that the
Chief Secretary to the Tripura Administration shall forthwith transmit to this Court the original file
in respect of the detenus concerned" since the Court wanted to satisfy itself that the Minister or the
Secretary or the Administrator had reviewed the eases of the detenus and arrived at a decision that
their detention should be continued. So also in M. M. Damnoo v. J & K State Court required theAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

State Government to produce the file containing the grounds of detention so that the Court could
satisfy itself that "the grounds on which the detenu has been detained have relevance to the security
of the State". It would, therefore, be seen that if there is a legislative provision which prohibits
disclosure of the grounds, information and materials on which the order of detention is based and
prevents the Court from calling for the production of such grounds, information and materials, it
would obstruct and retard the exercise of the constitutional power of the High Court under Article
226 and would be void as offending that Article.
593. This was the basis on which Section 14 of the Preventive Detention Act, 1950 was struck down
by this Court in A. K. Gopakm's case (supra). That Section prohibited the disclosure of the grounds
of detention communicated to the person detained and the representation-' made by him against the
order of detention and barred the court from allowing such disclosure to be made except for
purposes of a prosecution for such disclosure. It was held by this Court-in fact by all the judges who
participated in the decision--that this Section was void as it contravened inter alia Article 32. Kanta,
C. J. observed at page 130 of the Report in a passage of which certain portions have been underlined
by me for emphasis :
By that Section the Court is prevented (except) for the purpose of punishment for
such disclosure) from being informed, either by a statement or by leading evidence,
of the substance of the grounds conveyed to the detained person under Section 7 on
which the order was made, or of any representation made by him against such order.
It also prevents the Court from calling upon any public officer to disclose the;
substance of those grounds or from the production of the proceedings or report of the
advisory board which may be declared confidential. It is clear that if this provision is
permitted to stand, the Court can have no material before it to determine whether the
grounds are sufficient or not. I do not mean whether the grounds are sufficient or
not. It even prevents the Court from ascertaining whether the alleged grounds of
detention have anything to do with the circumstances or class or classes of cases
mentioned in Section 12(1) (a)-
Patanjali Sastri, J., also observed to the same effect at page 217 of the Report :
If the grounds are too vague to enable him to make any such representation, or if they
are altogether irrelevant to the object of his detention, or are such as to show that his
detention is not bona fide, he has the further right of moving this Court and this
remedy is also guaranteed to him under Article 32. These rights and remedies, the
petitioner submits, cannot be effectively exercised, if he is pre-vented on pain of
prosecution, from disclosing the grounds to the Court. There is great force in this
contention--The argument (of the Attorney General) overlooks that it was recognised
in the decision referred to above that it would be open to the Court to examine the
grounds of detention in order to see whether they were relevant to the object which
the legislature had in view, such as, for instance, the prevention of acts prejudicial to
public safety and tranquility, or were such as to show that the detention was not bona
fide. An examination of the grounds for these purposes is made impossible by SectionAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

14, and the protection afforded by Article 22(5) and Article 32 is thereby rendered
nugatory. It follows that Section 14 contravenes the provisions of Article 22 (5) and
Article 32 in so far as it prohibits the person detained from disclosing to the Court the
grounds of his detention communicated to him by the detaining authority or the
representation made by him against the order of detention, and prevents the Court
from examining them for the purpose aforesaid, and to that extent it must be held
under Article 13 (2) to be void.
(emphasis supplied).
And so did the other learned Judges. It is clear from what they said that inasmuch as
Section 14 prohibited the disclosure of the grounds of detention and prevented the
Court from looking at them for the purpose of deciding whether the detention is legal,
it was violative of Article 32 which conferred a fundamental right on a detenu to
move this Court for impugning the legality of his detention.
594. The same view was taken by a Constitution Bench of this Court in M. M. Damnoo v. J. & K.
State (supra). In fact, the observations of Kania, C. J. in A. K. Gopalan's case (supra), which I have
reproduced above, were quoted with approval in this decision. The petitioner in this case challenged
the legality of his detention by the State of Jammu & Kashmir on several grounds. One of the
grounds was that the proviso to Section 8 of the Jammu & Kashmir Preventive Detention Act was
void as it conflicted with Section 103 of the Constitution of Jammu & Kashmir. Section 103 was in
the same term as Article 226 and it conferred power on the High Court of Jammu & Kashmir to
issue inter alia a writ of habeas corpus Section 8 of the Preventive Detention Act required the
detaining authority to communicate to the detenu the grounds on which the order of detention was
made, but the proviso to that Section dispensed with the requirement in case of "any person
detained with a view to preventing him from acting in any manner pre-judicial to the security of the
State if the authority making the order--directs that the person detained may be informed that it
would be against the public interest to communicate to him the grounds on which his detention has
been made". The argument of the petitioner was that the proviso to Section 8 of the Preventive
Detention Act was violative of Section 103, since it debarred the High Court and this Court from
calling for the grounds of detention and thus made it virtually impossible for the High Court and
this Court to examine the legality of the detention. this Court agreed that there would have been
some force in the contention of the petitioner, if the High Court and this Court were prevented from
calling upon the State Government to produce the grounds of detention, but it pointed out that the
proviso to Section 8 was not ultra vires "because the proviso and the Act do not bar the High Court
and this Court from looking into the validity of the detention". this Court, after referring to the
observations made by Kania. C.J. in A. K. Gopalan's case (supra) in regard to Section 14 of the
Preventive Detention Act, 1950 said :
But fortunately there is no similar provision in this Act and it leaves the High Court
and the Supreme Court free to exercise the jurisdiction by calling upon the State in
appropriate cases to produce before it the grounds of detention and other material in
order to satisfy itself that the detenu was being detained in accordance with law. If itAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

were not so, we would have difficulty in sustaining the proviso.
It will, therefore, be seen that prima facie this Court was of the view that if the
proviso to Section 8 had debarred the High Court and this Court from requiring the
grounds of detention to be produced "before them, it would have been difficult to
sustain that proviso.
595. The learned Additional Solicitor General, however, sought to distinguish these two decisions
and contended that Sub-section (9) (a) of Section 16A merely enacts a rule of evidence and it cannot,
therefore, be said to obstruct or retard the exercise of the constitutional power of the High Court
under Article 226 so as to be in conflict with that Article. Now, there can be no doubt, although at
one time in the course of his arguments Mr. Shanti Bhushan contended to the contrary, that a rule
of evidence can always be enacted by the legislature for the purpose of regulating the proceedings
before the High Court under Article 226. A rule of evidence merely determines what shall be
regarded as relevant and admissible material for the purpose of enabling the Court to come to a
decision in the exercise of its jurisdiction and it does not in any way detract from or affect the
jurisdiction of the Court and it cannot, in the circumstances, be violative of Article 226. But in order
that it should not fall foul of Article 226, it must be a genuine rule of evidence. If in the guise of
enacting a rule of evidence, the legislature in effect and substance disables and impedes the High
Court from effectively exercising its constitutional power under Article 226, such an enactment
would be void. It will be colourable exercise of legislative power. The legislature cannot be permitted
to violate a constitutional provision by employing an indirect method. If a legislative provision,
though in form and outward appearance a rule of evidence, is in substance and reality something
different, obstructing or impeding the exercise of the jurisdiction of the High Court under Article
226, the form in which the legislative provision is clothed would not save it from condemnation. Let
us, therefore, examine whether Sub-section (9) (a) of Section 16A enacts a genuine rule of evidence
or it is a colourable piece of legislation in the garb of a rule of evidence. If it is the former, it would
be valid; but if it is latter, it would be an indirect and covert infringement of Article 226 and hence
void.
596. Now, it is well settled that in order to determine the true character of a legislative provision, we
must have regard to the substance of the provision and not its form. We must examine the effect of
the provision and not be misled by the method and manner adopted- or the phraseology employed.
Sub-section (9) (a) of Section 16A is inform and outward appearance a rule of evidence which says
that the grounds, information and materials on which the order of detention is made or the
declaration under Sub-section (2) or Sub-section (3) is based shall be treated as confidential and
shall be deemed to refer to matters of State and be against the public interest to disclose. But in
substance and effect, is it a genuine rule of evidence? The argument on behalf of the detenus was
that it is only a legislative device adopted by the legislature for the purpose of excluding the grounds,
information and materials from the scrutiny of the Court and thereby making it virtually impossible
for the Court to examine the legality of the detention and grant relief to the detenu. If the veil is
removed, contended the detenus, the position is no different from that obtaining in A. K. Gopalan's
case (supra) where Section 14 of the Preventive Detention Act, 1950 was struck down as constituting
a direct assault on Article 226. It was pointed out that, in every case of detention, the grounds,Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

information and materials would not necessarily refer to matters of State and be against the public
interest to disclose. Since, even orders of detention purported to be made under Section 3 are
brought within the purview of Sub-section (9) (a) of Section 16A, the grounds, information and
materials in cases of such detention may be wholly unrelated to the objects and purposes set out in
Section 3 and in that event, they would mostly have nothing to do with matters of State and it may
not be possible to say that their disclosure would injure public interest. But even so, Sub-section (9)
(a) of Section 16A surrounds such grounds, information and materials with the veil of secrecy and,
to use the words of Mahajan, J. in A. K. Gopalan's case (supra), places "an iron curtain around
them". This Sub-section, according to the detenus, compels the Court to shut its eyes to reality and
presume by a legal fiction that in every case, whatever be the actuality--and in many cases the
actuality may be otherwise--the grounds, information and materials shall be deemed to refer to
matters of State and shall be against the public interest to disclose. This contention of the detenus is
undoubtedly very plausible and it caused anxiety to me. but on deeper consideration, I think it
cannot be sustained.
597. It is significant to note that Sub-section (9) (a) of Section 16A is a provision enacted to meet the
emergency declared under the Proclamations dated 3rd December, 1971 and 25th June, 1975. Vide
Sub-section (1) of Section 16A. It comes into operation only when there is a declaration made under
Sub-section (2) or Sub-section (3) that the detention of the person concerned is necessary for
dealing effectively with the emergency. The condition precedent to the applicability of the
Sub-section is that there should be a declaration under Sub-section (2) or Sub-section (3) in respect
of the person detained. It may also be noted that though the words "or purported to be made" were
added after the words "an order of detention is made" in the Sub-section by the Maintenance of
Internal Security (Amendment) Act, 1976, no such or similar words were added in relation to the
declaration under Sub-section (2) or Sub-section (3). Sub-section (9) (a) of section 16A, therefore,
assumes a valid declaration under Sub-section (2) or Sub-section (3) and it is only when such a
declaration has been made, that Sub-section (9) (a) of Section 16A applies or in ether words it is only
in cases where a person is detained in order to deal effectively with the emergency that the
disclosure of the grounds. information and materials is prohibited by Sub-section (9) (a) of Section
16 A.
598. I have already pointed out how emergency can create a crisis situation imperiling the existence
of constitutional democracy and jeopardizing the functioning of the social and political machine. It
is therefore, reasonable to assume that where a person is detained in order to deal effectively with
the emergency, the grounds, information and materials on which the order of detention is made or
the declaration under Sub-section (2) or Sub-section (3) is based would, by, and large, belong to a
class of documents referring to matters of State which it would be against public interest to disclose.
What was observed by two of the Law Lords in Liversidge's case (supra) would be applicable in such
a case, Viscount Maugham said at page 221 of the Report. "it is obvious that in many cases he will be
acting on information of the most confidential character, which could not be communicated to the
person detained or disclosed in court without the greatest risk of prejudicing the future efforts of the
Secretary of State in this and like matters for the defence of the realm--It is sufficient to say that
there must be a large number of cases in which the information on which the Secretary of State is
likely to act will be of a very confidential nature," and Lord Wright also observed to the same effectAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

at page 266 of the Report : "In these cases full legal evidence or proof is impossible, even if the
Secretary does not claim that disclosure is against the public interest, a claim which must
necessarily be made in practically every case, and a claim which a judge necessarily has to admit." In
view of the fact that the detention is made in order to deal effectively with the emergency, the
grounds, information and materials would in most cases be confidential and if a claim of privilege
were made under Section 123 of the Indian Evidence Act, it would almost invariably be held
justified. The Legislature, therefore, taking into account the privileged character of the grounds,
information and materials in the generality of cases, enacted Sub-section (9)(a) of Section 16A
laying down a rule that the grounds, information and materials shall be deemed to refer to matters
of State which it would be injurious to public interest to disclose, instead of leaving it to the
discretion of the detaining authority to make a claim of privilege in each individual case and the
court to decide it. The rule enacted in Sub-section (9) (a) of Section 16A bears close analogy to a rule
of conclusive presumption and in the circumstances, it must be regarded as a genuine rule of
evidence. I may make it clear that if the grounds, information and materials were not, by and large,
of such a character as to fall within the class of documents relating to matters of State which it would
be injurious to public interest to disclose, I would have found it impossible to sustain this statutory
provision as a genuine rule of evidence. If the grounds, information and materials have no relation
to matters of State or they cannot possibly be of such a character that their disclosure would injure
public interest, the Legislature cannot, by merely employing a legal fiction, deem them to refer to
matters of State which it would be against public interest to disclose and thereby exclude them from
the judicial ken. That would not be a genuine rule of evidence : it would be a colourable legislative
device --a fraudulent exercise of power. There can be no blanket ban on disclosure of the grounds,
information and materials to the High Court or this Court, irrespective of their true character. That
was the reason why Section 14 of the Preventive Detention Act, 1950 was struck down by this Court
in A. K. Gopalan's case (supra) and this Court said in M. M. Damnoo's case (supra) that if the
proviso to Section 8 had debarred the High Court and this Court from calling for the grounds of
detention and looking into them, it would have been difficult to sustain that proviso. But here, on
account of the declaration under Sub-section (2) or Sub-section (3), which, as I said above, must be
a valid declaration in order to attract the applicability of Sub-section (9) (a) of Section 16A, the
grounds, information and materials in almost all cases would be of a confidential character falling
within the class of documents privileged under Section 123 and hence the rule enacted in the
Sub-section genuinely partakes of the character of a rule of evidence. It may be pointed out that if
the declaration under Sub-section (2) or Sub-section (3) is invalid Sub-section (9) (a) of Section 16A
will not be attracted and the grounds, information and materials on which the order of detention is
made would not be privileged under that Sub-section. I am, therefore, of the view that Sub-section
(9) (a) of Section 16A enacts a genuine rule of evidence an it does not detract from or affect the
jurisdiction of the High Court under Article 226 and hence it cannot be successfully assailed as
invalid.
599. I accordingly answer the first question by saying that the Presidential Order dated June 27,
1975 bars maintainability of a petition for a writ of habeas corpus where an order of detention is
challenged on the ground that it is vitiated by mala fides, legal or factual, or is based on extraneous
considerations or is not under the Act or is not in compliance with it. So far as the second question is
concerned, I do not think there is any warrant for reading down Sub-section (9) (a) of Section 16A soAdditional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

as to imply an exception in favour of disclosure to the Court, and, on the interpretation placed by me
on that provision, T hold that it does not constitute an encroachment on the constitutional
jurisdiction of the High Court under Article 226 and is accordingly not void. In the circumstances, I
allow the appeals and set aside the judgments of the High Courts impugned in the appeals.
ORDER
600. By majority--
1. In view of the Presidential Order dated 27 June 1975 no person has any locus standi to move any
writ petition under Article 226 before a High Court for habeas corpus or any other writ or order or
direction to challenge the legality of an order of detention on the ground that the order is not under
or in compliance with the Act or is illegal or is vitiated by malafides factual or legal or is based on
extraneous considerations;
2. Section 16A(9) of the Maintenance of Internal Security Act is constitutionally valid;
3. The appeals are accepted. The judgments are set aside;
4. The petitions before the High Courts are now to be disposed of in accordance with the law laid
down in these appeals.Additional District Magistrate, ... vs Shivakant Shukla on 28 April, 1976

