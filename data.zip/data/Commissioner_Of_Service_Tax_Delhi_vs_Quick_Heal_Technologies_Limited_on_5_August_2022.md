Commissioner Of Service Tax Delhi vs Quick Heal Technologies
Limited on 5 August, 2022
Author: Abhay S. Oka
Bench: Abhay S. Oka
                                                                          REPORTABLE
                                     IN THE SUPREME COURT OF INDIA
                                       CIVIL APPELLATE JURISDICTION
                                      CIVIL APPEAL NO. 5167 OF 2022
                                         (DIARY NO. 24399 OF 2020)
                         COMMISSIONER OF SERVICE TAX DELHI             …APPELLANT(S)
                                                    VERSUS
                         QUICK HEAL TECHNOLOGIES LIMITED              …RESPONDENT(S)
                                                      WITH
                                 CIVIL APPEAL NOS. 5168−5169 OF 2022
                          (ARISING OUT OF S.L.P. (CIVIL) NOS. 6715−6716 OF 2022)
                                                JUDGMENT
J.B. PARDIWALA, J. :
1. Since the issues raised in both the captioned cases are the same, those were taken
up for hearing analogously and are being disposed of by this common judgment.
Civil Appeal (Diary No. 24399 of 2020)
2. Delay condoned.
3. This appeal under Section 35L(b) of the Central Excise Act, 1944 (for short, ‘the Act 1944’), as
made applicable to the service tax by Section 83 of Chapter V of the Finance Act, 1994 (for short,
‘the Act 1994’), is at the instance of the revenue and is directed against the order No. 50022/2020
dated 09.01.2020 passed by the Customs, Excise and Service Tax Appellate Tribunal, New Delhi (for
short, ‘the Tribunal’) in the Service Tax Appeal No. 51175 of 2016 by which the Tribunal allowed the
appeal filed by the respondent herein (assessee) thereby set aside the Order in Original dated
28.01.2016 passed by the Additional Director General (Adjudication) DGCEI, Delhi.
FACTUAL MATRIXCommissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

4. For the sake of convenience, the appellant herein shall be referred to as the “revenue” and the
respondent herein shall be referred to as the “assessee”.
5. The assessee is registered with the Service Tax Commissioner, Pune−III for providing taxable
services, inter alia, under the category of “Information Technology Software Service”. The assessee
is engaged in the development of Quick Heal brand Antivirus Software which is supplied along with
the license code/product code either online or on the replicated CDs/DVDs to the end−customers in
India.
6. It appears from the materials on record that it came to the notice of the Directorate General of
Central Excise Intelligence (Headquarters) that the assessee engaged in the development of Quick
Heal brand Antivirus Software had not been paying service tax prior to 01.07.2012 on the services
covered under the category of “Information Technology Software Service” falling under Item No. (vi)
of clause (zzzze) of sub−section (105) of Section 65 of the Act 1994 w.e.f 01.07.2012 on the services
covered under the category of “Information Technology Software Service” under Section 66E(d) of
the Act 1994 for providing Quick Heal brand Antivirus Software license key/code supplied along
with the CD/DVD replicated with the Quick Heal brand Antivirus Software through the
dealers/distributors to the end− customers in India.
7. In the aforesaid context, an inquiry was initiated against the assessee and at the end of the same,
the revenue reached to the conclusion that the assessee is liable to pay service tax on the
transactions with the end−customers to supply the license codes/keys of Quick Heal brand Antivirus
Software in the retail packs. The revenue reached to the conclusion that the assessee had failed to
pay the service tax on the consideration received for the supply of the license codes/keys of
Antivirus Software to the end−customers in retail packs during the period between 01.03.2011 and
31.03.2014.
8. In such circumstances referred to above, a show cause notice dated 02.02.2015 came to be issued
to the assessee by the Additional Director General, DGCEI (Hqrs.), New Delhi proposing a
demand/recovery of service tax amounting to Rs.
62,73,05,953.36p. (Rupees Sixty Two Crore Seventy Three Lakh Five Thousand Nine Hundred
Three and paise Thirty Six Only) on the taxable value of Rs. 5,30,94,66,783/− (Rupees Five Arab
Thirty Crore Ninety Four Lakh Sixty Six Thousand Seven Hundred Eighty Three Only) for supplying
Quick Heal Antivirus Software replicated CDs/DVDs in the retail packs (i.e. Information Technology
Software Service) through its dealers/distributors to the end−customers in India for the period
between 01.03.2011 and 31.03.2014 under the proviso to Section 73(1) of the Act 1994 by invoking
the extended period of limitation with interest and penalty.
9. The show cause notice referred to above was adjudicated by the Additional Director General
(Adjudication), DGCEI, Delhi, who, in turn, confirmed the demand of service tax amount to Rs.
56,07,05,595/− (Rupees Fifty Six Crore Seven Lakh Five Thousand Five Hundred Ninety Five Only)
alleged to have been not paid by the assessee on the service of Information Technology Software
Service vide its Order in Original dated 28.01.2016.Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

10. The assessee, being aggrieved with the order passed by the Additional Director General
(Adjudication), DGCEI, preferred the Service Tax Appeal No. 51175 of 2016 before the Tribunal.
11. The Tribunal allowed the appeal filed by the assessee herein essentially on the following three
grounds:− i. The antivirus software did not have an element of interactivity.
ii. As per the decision of the Supreme Court in the case of Tata Consultancy Services v. State of
Andhra Pradesh, (2005) 1 SCC 308, (“TCS”), the pre− packaged/canned software would be treated
as goods.
Once the software is put on a medium like a CD and then sold, such software would be treated as
goods.
iii. The Central Board of Excise & Customs (CBEC) issued guidelines when the negative regime was
issued on 1.7.2012. The guidelines clarified that the pre−packaged/canned software would not be
goods even if there was a licence.
12. The revenue, being dissatisfied with the order passed by the Tribunal, has come up before this
Court with the present appeal under Section 35L(b) of the Act 1944.
13. The revenue has in its memorandum of appeal formulated the following questions of law for
consideration of this Court:− “(i) Whether the Tribunal is right in holding that the transaction in the
present case results in the right to use the software and would amount deemed sale?
(ii) Whether the Antivirus Software license key/code supplied by the respondent along with
CD/DVD replicated with Quick Heal Brand Antivirus Software through dealers/distributors to the
End−Customers is liable to Service Tax?
(iii) Whether the service provided by the respondent is classifiable under Information Technology
Service liable to service tax under Section 65(105)(zzzze) of the Finance Act, 1994 prior to
01.07.2012 and under Section 66E(f) of the Finance Act, 1994 w.e.f. 01.07.2012?
(iv) Whether the transfer of goods by way of hiring, leasing, licensing or any such manner without
transfer of right of use such goods, is a declared service under clause (1) of Section 66E of the
Finance Act, 1994?” SUBMISSIONS ON BEHALF OF THE REVENUE :
14. The learned counsel appearing for the revenue vehemently submitted that the
Tribunal committed a serious error in passing the impugned order by relying upon
the decision of this Court in TATA Consultancy Services (supra). He would submit
that the question before this Court in the case of the TATA Consultancy Services
(supra) was whether the canned software sold by the appellants therein could be
termed to be “goods” under the Andhra Pradesh General Sales Tax Act, 1957 and
hence, assessable to the sales tax? He submitted that the principal contention of the
appellants before this Court in the case of the TATA Consultancy Services (supra) wasCommissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

that the canned software was “intangible property” and hence would not come within
the definition of the “goods”. He would submit that the issue was clearly not whether
the canned software was “goods” or “service”. He laid much stress on the fact that no
argument was canvassed on the canned software being a service. Since the question
did not pertain to the canned software being a “service”, this Court did not make any
comment on whether the canned software could be a “service”.
He would submit that in such circumstances, the Tribunal committed an error in relying on the ratio
of the decision of this Court in the case of TATA Consultancy Services (supra).
15. The learned counsel would further submit that the entire transaction of selling or trading of the
software can be divided into two stages:−
(a) Up to the replication of the Master CD by the replicators under the terms of agreement. This is
covered by this Court’s judgment in the case of TATA Consultancy Services (supra). There rises no
dispute of paying duty at this stage, since, the recording of the software on their CDs and making
them marketable makes it ‘Goods’ which is chargeable to the Central Excise Duty;
(b) The supply to the end−users under a separate End User Licensing Agreement, consists of 2
parts:
(i) Supply of Antivirus software in the CD.
(ii) Providing electronic updates to the software originally provided.
16. He would submit that the present dispute is one relating to part (b) as above of the transaction.
17. Referring to the decision of this Court in the case of Bharat Sanchar Nigam Ltd. v. Union of
India, (2006) 3 SCC 1, (for short, ‘BSNL’), he would submit that the same deals with the “composite
transaction” of giving telephone connection that involves service and sale. It was held therein by the
majority that it is possible for the State to tax the sale element provided there is a discernible sale
and the “dominant intention” test is satisfied. To put it in other words, the learned counsel would
submit that the test for a composite contract other than those mentioned in the Article 366(29A) of
the Constitution continues to be “did the parties have in mind or intend separate rights arising out
of the sale of goods?”. If there was no such intention, there is no sale even if the contract could be
disintegrated. According to the learned counsel, the test for deciding whether a contract falls into
one category or the other is as to what is 'the substance of the contract’. He pointed out that in the
case of BSNL (supra) it was held that what amounts to being “goods” in the sale transaction remains
primarily a matter of contract and intentions.
18. He placed strong reliance on the decision of the Madras High Court in the case of M/s Infotech
Software Dealers Association v. Union of India, 2010 (20) S.T.R. 289 (Mad.), wherein the High
Court took the view that the supply of packaged antivirus software to the end user by charging
license fee as per the end user license agreement amounts service and not sale. The Madras HighCommissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

Court held that for the purpose of imposition of tax, the nature of transaction should be looked into.
19. In such circumstances referred to above, the learned counsel appearing for the revenue, prays
that there being merit in his appeal, the same may be allowed by answering the proposed questions
of law in favour of the revenue and against the assessee.
SUBMISSIONS ON BEHALF OF THE ASSESSEE :
20. On the other hand, Mr. Arvind P. Datar, the learned senior counsel appearing for the assessee,
vehemently opposed this appeal by submitting that no error, not to speak of any error of law, could
be said to have been committed by the Tribunal in passing the impugned order. He would submit
that in para 29 of the impugned order the Tribunal rightly rejected the contention of the revenue
that the antivirus software was interactive. Mr. Datar would submit that the Tribunal rightly held
that a programme could be said to be interactive only when it involves the user to have exchange of
information or when there is action and communication between the user and the software. The
learned senior counsel gave an example by pointing that the MS Word, Excel, etc. are interactive
softwares which can be run only after the receipt of the instructions from the user. On the other
hand, there is no interactivity in an antivirus software as there is no requirement of giving any
command for detecting and removing the virus. In other words, no manual input is required to
operate an antivirus software as it acts automatically upon detecting any virus. He would submit
that the antivirus software which is installed in a computer system cannot be treated as an
interactive software.
21. The learned senior counsel thereafter took this Court through the decision rendered by this
Court in the case of TATA Consultancy Services (supra). The learned senior counsel offered the
following comments on the impact of the decision in the case of TATA Consultancy Services (supra)
:− “4.1 The question as to whether software can be treated as goods was referred to a bench of five
judges in the aforesaid TCS case.
4.2 The State of Andhra Pradesh had levied VAT/sales tax on software CDs, which were packed and
sold to customers. This Hon’ble Court, after extensive consideration of India and U.S. decisions,
held that even though the copyright in a software program may remain with the originator of the
program, the moment the software is loaded onto a CD and copies are made and marketed, they
become goods, “which are susceptible to sales tax”. 4.3 There is no difference between sale of a
software program on a CD/floppy disc or the sale of music or film CD. It categorically held that the
software and the medium cannot be split up in a sale of a computer software, which is a sale of
goods. Apart from the judgment of Justice Variava, Justice S.B. Sinha gave a concurring opinion
giving additional reasons as to why software, which is put on a medium and sold, is in the nature of
a commodity and has to be treated as goods. The learned judge also held that the definition of
canned software would be exigible to sales tax. 4.4 In the present case, the impugned CESTAT order
has reproduced several paragraphs from the TCS ruling and concluded in paragraph 35/Page 54,
Vol. I that once software is put in a media and marketed, it would become goods.Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

4.5 The negative regime of service tax came into force on July 1, 2012. Barring specific exemptions,
almost all contracts were to be treated as services when they were supplied for consideration.
Service tax was sought to be levied on Information and Technology Service, under section 65(53a)
which reads as follows:
(53a) “information technology software” means any representation of instructions,
data, sound or image, including source code and object code, recorded in a machine
readable form, and capable of being manipulated or providing interactivity to a user,
by means of a computer or an automatic data processing machine or any other device
or equipment;
4.6 Similarly, the definition of taxable services is contained in section 65(105) (zzzze) which are also
reproduced earlier.
4.7 While the above definitions were prevailing prior to 01.07.2012, section 66E(d) – provided for
declared service under the new negative regime and read as follows:
“development, design, programming, customization, adaptation, upgradation,
enhancement, implementation of information technology software” 4.8 Further,
section 65B (28) defined “information technology software” which was almost
identical to the earlier definition under section 65 (63a).”
22. The learned senior counsel thereafter made his submissions on the CBEC
Circular/Education Guide. Following comments have been offered as regards the said
Circular in the written note furnished to this Court:− “5.1 After the negative regime
came into force on 1.7.2012, reproduced above, the CBEC Education Guide issued the
following guidelines:
(i)Pre−packaged or canned software would not be covered by the entry relating to
information technology software. This is because such software as “goods” as held by
the Supreme Court in the TCS case. The guidelines specifically reproduced the text of
the Supreme Court ruling.
(ii)It then concluded that if pre−packaged or canned software, were sold, then the
transaction would be in the nature of a sale of goods and no service tax would be
levied.”
23. The learned senior counsel thereafter submitted as regards the excise duty/tariff
entry and exemption notifications as under :− “6.1 It is pertinent to note that S. No.
84A of the third schedule to the Central Excise Act, 1944, deals with entry 8523 80 20
corresponding to “Packaged software or canned software”. The Explanation provided
thereunder defined “packaged software or canned software” as a software which is
intended for sale or capable of being sold off−the−shelf.Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

6.2 Moreover, Notification No:14/2011 CE dated 01− 03−2011 adopted this definition and exempted
excise duty on such “packaged software or canned software”.”
24. He vehemently submitted that the transaction cannot be bifurcated into two components as
suggested by the revenue i.e.
(i) sale of CD, and (ii) supply of updates. In this regard, he submitted as under :− “7.1 During the
arguments, the Department submitted that apart from the sale of CD, the updates which were to be
provided under the contract would amount to service. It is submitted that this is incorrect because
the pre−packaged antivirus software which is sold in the box has a condition of sale that updates for
the period of license would be also provided to the person who has purchased the goods without any
further consideration. These updates are part and parcel of the sale of software itself and cannot be
divorced from the transaction and treated separately as a service. 7.2 Indeed, every pre−packaged
software that was sold in a box, where there it is Tally or Word or Excel, would also include supply of
updates for the period of licence.
7.3 Further, section 65B (44) defined service to mean any activity carried out by a person for a
consideration and includes a declared service. In the present case, no separate consideration is
charged for the updates which are part and parcel of the sale of goods itself. Consequently, even if
the updates are treated as declared services under section 66E(d), no consideration is charged for
such service separately. 7.4 In BSNL v. Union of India it was categorically held that the contract
cannot be vivisected or split out. Once a lumpsum has been charged for the sale of CD and sales tax
has been paid thereon, the Department cannot levy service tax on the entire sale consideration once
again on the ground that updates are being provided.”
25. In the last, the learned senior counsel submitted that the payment of VAT and service tax are
mutually exclusive. He would submit that :− “8.1 It is well settled that sales tax and VAT is covered
by Entry 54 of List−II in the VII Schedule of the Constitution. Only State Legislatures can levy VAT
on the sale of goods. On the other hand, service tax is leviable under the Finance Act, 1994 (as
amended) on the provision of service and such levy is permissible under Entry 97 of List−I. 8.2 It is
also well settled that there could be no overlapping of taxes as the taxing powers have been carefully
split between Union and the State. Accordingly, the taxation of goods has been allotted to the State
Legislatures while taxing of service is retained by the Centre.
8.3 In Imagic Creative Pvt. Ltd. v. CCT, (2008) 9 STR 337 (SC) : (2008) 2 SCC 614, this Court held
that payment of VAT and service tax are mutually exclusive. After the TCS judgment, the
controversy was put to rest in intellectual property where software or music or film which has been
put on a medium such as a CD will be treated as goods and consequently can subject only to sales
tax/VAT.”
26. In such circumstances referred to above, the learned senior counsel appearing on behalf of the
assessee, prays that there being no merit in the present appeal, the same may be dismissed.
ANALYSIS :Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

27. Having heard the learned counsel appearing for the parties and having gone through the
materials on record, the only question that falls for our consideration is, whether the Tribunal
committed any error in passing the impugned order?
28. Before we advert to the rival submissions canvassed on either side, we must look into some of
the reasons assigned by the Tribunal while allowing the appeal preferred by the assessee against the
order of the adjudicating authority. We quote:− “25. The contention of the Appellant is that the
software developed by it can neither be manipulated nor does it provide any interactivity to a user
and, therefore, does not satisfy the requirement of “information technology software”. According to
the Appellant, once the computer system is booted, the Antivirus Software begins its activity of
detecting the virus and continues to do so till the time the computer system remains booted. Thus,
there is no interactivity or requirement of giving any commands to the software to perform the
function of detecting and removing virus from the computer system.
The Appellant further contends that the software developed by it is quite distinct from software like
ERP, EXCEL, MS Word, where there is a constant to and from interaction between the user and the
computer system containing the said software. These softwares perform their function only after
receipt of input from the user, which is not the case in the Antivirus Software developed by the
Appellant.
x x x
28. The Adjudicating Authority, however, has not accepted the contention of the Appellant and has
observed that the software can issue commands to scan drives, both internal and external and that it
has an interface with the user to tune−up the personal computer and that it has also a parallel
control feature. These features, according to the Adjudicating Authority, need a command by the
user to the software and, therefore, it is interactive.
29. It is not possible to accept this finding. The Antivirus Software developed by the Appellant is
complete in itself to prevent virus in the computer system. Once the computer system is booted, the
Antivirus Software begins the function of detecting the virus, which continues till the time the
computer system remains booted. The computer system only displays a message that viruses existed
and that they have been detected and removed. No interactivity takes place nor there is any
requirement of giving any command to the software to perform its function of detecting and
removing virus from the computer system. It is also seen from the meaning assigned to “interactive”
that a program should involve the user in the exchange of information. There has to be action and
communication between the two. A user should communicate with the computer facility and receive
rapid responses, which can be used to prepare the next inputs. In contract, in other softwares like
ERP, EXCEL, MS Word, there is continues interaction between the user and the computer system
and these softwares perform only after receipt of input from the user.
30. Such being the position, no service tax was leviable under section 65(105)(zzzze) of the Act prior
to 1 July, 2012. Even after 1 July, 2012 the definition of “information technology software” under
section 65B(28) remained the same and so also service tax was not leviable.Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

31. The matter can be examined from another angle. Section 65B (51) defines a “taxable service” to
mean any service on which service tax is leviable under section 66B. Section 66B provides that there
shall be levied service tax on the value of all services, other than those services specified in the
negative list, provided or agreed to be provided in the taxable territory by one person to another and
collected in such manner as may be prescribed. Section 65B (44) define “service” to mean any
activity carried out by a person for consideration, and includes a declared service, but shall not
include, amongst others, an activity which constitutes merely such transfer, delivery or supply of any
goods which is “deemed to be a sale” within the meaning of clause (29A) of article 366 of the
Constitution.”
29. The Tribunal thereafter proceeded to consider the decision of this Court rendered in the case of
TATA Consultancy Services (supra). Upon analysis of the ratio of the said decision, the Tribunal
recorded the following findings :− “35. It is clear from the aforesaid decision of the Supreme Court
in Tata Consultancy Services that intellectual property, once it is put on the media and marketed
could become “goods” and that a software may be intellectual property and such intellectual
property contained in a medium is purchased and sold in various forms including CDs.
36. Section 65B (44) of the Act also excludes from the definition of “service” any activity which
constitutes merely such transfer, delivery or supply of any goods which is deemed to be a sale within
the meaning of clause (29A) of article 366 of the Constitution. As noticed above, the Supreme Court
in Tata Consultancy Services held that Canned Software supplied in CDs would be “goods”
chargeable to sales tax/VAT and no service tax can be levied.”
30. The Tribunal thereafter, in para 37 of its order, considered the CBEC Education Guide for
service tax containing the official guidelines for new system of levy of service tax. After due
consideration of the same, it recorded the following findings in para 38:− “38. A perusal of the
aforesaid guidelines would indicate that after making a reference to the judgment of Supreme Court
in Tata Consultancy Services, it mentions that a transaction would be in the nature of sale of goods
when a pre−packaged or Canned Software is sold, and no service tax would be leviable. However, a
license to use the software which does not involve the transfer of “right to use” would neither be a
transfer of title in goods nor a deemed sale of goods. Such an activity would fall in the ambit of
definition of “service”. Thus, if a pre−packaged or Canned Software is not sold but is transferred
under a license to use such software, the terms and conditions of the license to use such software
would have to be seen to arrive at a conclusion whether the license to use the packaged software
involves a transfer of “right to use” such software in the sense the phrase has been used in sub−
clause (d) of article 366(29A) of the Constitution. The guidelines also provide that in case a license
to use pre−packaged software imposes restrictions on the usage of such licenses, which restriction
interfere with the free enjoyment of the software, then such a license would not result in transfer of
“right to use” the software within the meaning of Clause 29(A) of article 366 of the Constitution.
However, every condition imposed would not make it leviable to service tax. The condition should
be such so as to restrain the right to free enjoyment on the same lines as a person who has otherwise
purchased goods is able to have.”Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

31. The Tribunal thereafter proceeded to consider the terms of the agreement to ascertain whether
there was transfer of the “right to use goods”. The Tribunal in para 44 of its order recorded the
following relevant provisions of the Quick Heal Internet Security End−User License Agreement:−
“16. BY USING THIS SOFTWARE OR BY ACCEPTING OUR SOFTWARE USAGE AGREEMENT
POLICY OR ATTEMPTING TO LOAD THE SOFTWARE IN ANY WAY, (SUCH ACTION WILL
CONSTITUTE A SYMBOL OF YOUR CONSENT AND SIGNATURE), YOU ACKNOWLEDGE AND
ADMIT THAT YOU HAVE READ, UNDERSTOOD AND AGREED TO ALL THE TERMS AND
CONDITIONS OF THIS AGREEMENT, THIS AGREEMENT ONCE ACCEPTED BY "YOU"[ AS AN
INDIVIDUAL (ASSUMING YOU ARE ABOVE 18 YEARS AND/OR HAVING LEGAL CAPACITY TO
ENTER INTO AN AGREEMENT), OR THE COMPANY OR ANY LEGAL ENTITY THAT WILL BE
USING THE SOFTWARE (HEREINAFTER REFERRED TO AS YOU' OR YOUR' FOR THE SAKE
OF BREVITY] SHALL BE A LEGALLY ENFORCEABLE AGREEMENT BETWEEN YOU AND
QUICK HEAL TECHNOLOGIES PRIVATE LIMITED, PUNE, INDIA (HEREINAFTER REFERRED
TO AS "QUICK HEAL") AND YOU SHALL HAVE THE RIGHTS TO USE THE SOFTWARE
SUBJECT TO THE TERMS AND CONDITIONS MENTIONED IN THIS AGREEMENT OR AS
AMENDED BY QUICK HEAL FROM TIME TO TIME. IF YOU DO NOT AGREE TO ALL THE
TERMS AND CONDITIONS BELOW, DO NOT USE THIS SOFTWARE IN ANY WAY AND
PROMPTLY RETURN IT OR DELETE ALL THE COPIES OF THIS SOFTWARE IN YOUR
POSSESSION.
In consideration of payment of the License Fee, which is a part of the price, evidenced by the
Receipt. Quick Heal grants the Licensee, a non−exclusive and non− transferable right. Quick Heal
reserves all rights not expressly granted, and retains the title and ownership of the software,
including all subsequent copies in any media. This software and the accompanying written materials
are the property of Quick Heal and are copyrighted. Copying of the software or the written material
is expressly forbidden. In addition to this security software, Quick Heal offers you Quick Heal
Remote Device Management Services to manage your device(s).
Quick Heal reserves all rights not expressly granted, and retains the title and ownership of the
software, including all subsequent copies in any media, This software and the accompanying written
materials are the property of Quick Heal and are copyrighted.
1. DEFINITIONS −−−−−−−−−−−−−− B. "License period" means the period as more particularly
described in this Agreement. −−−−−−−−−−−−−− G. “Updates” means collections of any or all among
virus definition files including detections and solutions for new viruses along with the corrections,
improvements or modifications to the software.
2. DO's & DON'TS You can:
A. make copy of the software for backup purpose or for the purpose of sharing
through various means (and such backup copy must be destroyed when you lose the
right to use the Software or is terminated for any other reason according to the
legislation in force in the country of your principal residence or in the country where
You are using the software) and replace lost, destroyed, or becomes unusable.Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

B. use one copy of the software on a single computer. In case of multiuser pack, use of
the software only on the said number of systems as mentioned on the packaging. C.
install the software on a network, provided you have a licensed copy of the software
for each computer that can access the software over that network.
D. avail Quick Heal RDM service to manage your device (a maximum of 10 devices in
one account.) You cannot:
A. emulate, or adapt any portion of the software. B. sublicense, rent or lease any
portion of the software. C. try making an attempt to reveal/discover the source code
of the software.
D. debug, decompile, disassemble, modify, translate, reverse engineer the software.
E. create derivative works based on the software or any portion thereof with sole
exception of a non−waivable right granted to You by any applicable legislation. F.
remove or alter any copyright notices or other proprietary notices on any copies of
the software. G. reduce any part of the software to human readable form. H. use the
software in the creation of data or software used for detection, blocking or treating
threats described in the user manual.
I. use for unlicensed and illegal purpose. J. remove your user account from Quick
Heal RDM service once registered K. retrieve deleted location entries and back up
data from the user account on the Quick Heal RDM service. L. attempt to gain
unauthorized access to Quick Heal RDM networks.
5. LICENSE PERIOD A. You are entitled to use this software/ RDM Services from the
date of license activation until the expiry date of the license.
B. You understand, agree and accept that you are entitled for the updates and technical support via
the Internet and telephone. Any use of this software/RDM Services for any other purposes is strictly
forbidden and prohibited and Quick Heal reserves to take any action against such unauthorized
usage.
C. License for use of Quick Heal RDM service to manage devices shell be valid till your device
security software license is valid.
D. You agree, understand that any unauthorized usage of the software/ RDM services or breach of
any/all terms and conditions stated herein the Agreement shall result in automatic and immediate
termination of this Agreement and the License granted hereunder and which may result in criminal
and/ Or civil action by Quick Heal and/ Or its agents against you including but not limited to right
to block the key file/ License key/ product key and without any refund to You and without any prior
intimation/ notice to you in this regard. E. If you have acquired the specific language localization of
the software/ RDM service, you will not be able to activate the software by applying the activationCommissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

code of other language localization.
F. Quick Heal does not guarantee the protection from the threats more particularly described in the
user manual after the License to use the software/RDM service is terminated for any reason.
6. FEATURES OF SOFTWARE A. During the license period of the software/RDM services, You have
the right to use features of software/RDM service.
B. During the license Period of the Software/RDM, You have the right to receive free updates of the
software and Quick Heal RDM service via Internet as and when Quick Heal publishes the updated
virus− database and free version upgrade as and when Quick Heal releases new version upgrade.
You agree, understand and accept that You will be required to regularly download the updates
published by Quick Heal. Any and all updates/ upgrades you receive from Quick Heal shall be
governed by this Agreement, or as amended from time to time by Quick Heal.
C. You agree, accept and acknowledge:
I. that You are solely responsible for the configuration of the software/ RDM services
settings and the result, actions, inactions initiated due to the same and Quick Heal
assumes no liability/ responsibility in any case and the Clause of Indemnification
shall be applicable. II. that Quick Heal assumes no liability/responsibility for any
date deletion, including but not limited to any deletion/ loss of personal, and/or
confidential date; and/or uninstallation of third−party apps; and/or change in
settings; specifically authorized by You or occurs due to the actions, inactions
(whether intentional or not) by You or any third party whom You have authorized to
use, handle you Device due to features or software/RDM services.
III. that to avail/use certain features of the software/RDM services, you may be
required to incur some cost and that Quick Heal does not warrant that the usage of
certain features of the software/RDM services are free of cost and that Quick Heal
shall not entertain and expressly disclaims, any claim for reimbursement of any
expenses including but not limited to any direct or incidental expenses arising out of
Your usage of such features of the software/RDM services. IV. that you be solely
responsible and shall comply all applicable laws, regulations of India and any foreign
laws including without limitation, privacy, obscenity, confidentiality, copyright laws
for using any report, date, information derived as a result of using the software and
Quick Heal RDM services.
V. that while using the software, Quick Heal suggests some actions to be initiated by
You in your sole benefit, for example Quick Heal software may suggest You to
uninstall infected applications, however such actions are suggestive and Quick Heal
takes no responsibility/liability if you perform such suggestive actions or not and
Quick Heal assumes no responsibility/ liability for any liability arising out of such
actions/inactions.Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

9. QUICK HEAL STATUS UPDATE Upon every update of licensed copy, Quick Heal
Update module will send current product status information to Quick Heal Internet
Centre. The information that will be sent to the Internet Centre includes the Quick
Heal protection health status like, which monitoring service is in what state in the
system. The information collected does not contain any files or personal date. The
information will be used to provide quick and better technical support for legitimate
customers. All the registered user/subscribers will get the updates free of cost from
the date of license activation until the expiry date of the license.
13. Intellectual Property The software, source code, activation code, license keys,
documentation, systems, ideas, information, content, design, and other matters
related to the software, Quick Heal RDM services, trademarks are the sole
proprietary and intellectual property rights of Quick Heal protected under the
Intellectual Property Laws and belongs to Quick Heal. Nothing contained in this
Agreement grant You any rights, title, interest to intellectual property, including
without limitation any error corrections, enhancements, updates, or modifications to
the software and Quick Heal RDM service whether made by Quick Heal or any third
party. You understand and acknowledge that you are provided with a license to use
this software and Quick Heal RDM services subject to the terms and conditions of
this Agreement.”
32. After due consideration of the terms of agreement, the Tribunal proceeded to
observe the following in para 45 of the impugned order :− “45. The agreement
provides that the licensee shall have right to use software subject to terms and the
conditions mentioned in the agreement. The licensee is entitled to use the
software/RDM services from the date of license activation until the expiry date of the
license. The licensee is also entitled for the updates and technical support. The
conditions set out in the agreement do not interfere with the free enjoyment of the
software by the licensee. Merely because ―Quick Heal retains title and ownership of
the software does not mean that it interferes with the right of the licensee to use the
software.”
33. The Tribunal ultimately concluded as under while allowing the appeal filed by the
assessee herein :− “51. Thus, viewed from any angle, the transaction in the present
Appeal results in the right to use the software and would amount to “deemed sale”. It
is, therefore, not possible to accept the contention of the learned Authorized
Representative of the Department that the transaction would not be covered under
sub−clause (d) of article 366(29A) of the Constitution.”
34. Thus, from the aforesaid, it is evident that the Tribunal laid much emphasis on
the fact that in accordance with the agreement the licensee has the right to use the
software subject to the terms and the conditions laid therein. The Tribunal took
notice of the fact that in accordance with the agreement the licensee is entitled to use
the software/RDM service from the date of the activation of the license till the date ofCommissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

its expiry. The Tribunal also took into consideration the fact that the licensee is also
entitled for the updates and the technical support. In view of the Tribunal, the right
to use the software would amount to the “deemed sale”. The Tribunal rejected the
contention of the revenue that the transaction would not be covered under sub−
clause (d) of the Article 366(29A) of the Constitution.
RELEVANT PROVISIONS OF LAW
35. The New definition of the term “service” has been given under the clause 44 of
Section 65B of the Act 1994 which reads as follows :− “(44) “service” means any
activity carried out by a person for another for consideration, and includes a declared
service, but shall not include−
(a) an activity which constitutes merely,–
(i) a transfer of title in goods or immovable property, by way of sale, gift or in any
other manner; or
(ii) such transfer, delivery or supply of any goods which is deemed to be a sale within
the meaning of clause (29A) of Article 366 of the Constitution; or
(iii) a transaction in money or actionable claim;
(b) a provision of service by an employee to the employer in the course of or in relation to his
employment;
(c) fees taken in any Court or tribunal established under any law for the time being in force.
Explanation 1.− For the removal of doubts, it is hereby declared that nothing contained in this clause
shall apply to,– (A) the functions performed by the Members of Parliament, Members of State
Legislative, Members of Panchayats, Members of Municipalities and Members of other local
authorities who receive any consideration in performing the functions of that office as such member;
or (B) the duties performed by any person who holds any post in pursuance of the provisions of the
Constitution in that capacity; or (C) the duties performed by any person as a Chairperson or a
Member or a Director in a body established by the Central Government or State Governments or
local authority and who is not deemed as an employee before the commencement of this section.
Explanation 2.−For the purposes of this clause, transaction in money shall not include any activity
relating to use of money or its conversion by cash or by any other mode, from one form, currency or
denomination, to another form, currency or denomination for which a separate consideration is
charged;
Explanation 3.– For the purposes of this Chapter,−Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

(a) an unincorporated association or a body of persons, as the case may be, and a member thereof
shall be treated as distinct persons;
(b) an establishment of a person in the taxable territory and any of his other establishment in a
non−taxable territory shall be treated as establishments of distinct persons.
Explanation 4.− A person carrying on a business through a branch or agency or representational
office in any territory shall be treated as having an establishment in that territory;”
36. The analysis of the definition of “service” as above makes it clear that the service will not include
those activities which includes transfer, delivery or supply of any goods which is deemed to be sale
within the meaning of Clause (29A) of Article 366 of the Constitution.
37. Clause (29A) of Article 366 of the Constitution of India defines the deemed sale. This clause
reads as follows:− “(29A) tax on the sale or purchase of goods includes—
(a) a tax on the transfer, otherwise than in pursuance of a contact, of property in any goods for cash,
deferred payment or other valuable consideration;
(b) a tax on the transfer of property in goods (whether as goods or in some other form) invoked in
the execution of a works contract;
(c) a tax on the delivery of goods on hire purchase or any system of payment by instalments;
(d) a tax on the transfer of the right to use any goods for any purpose (whether or not for a specified
period) for cash, deferred payment or other valuable consideration;
(e) a tax on the supply of goods by any unincorporated association or body of persons to a member
thereof for cash, deferred payment or other valuable consideration;
(f) a tax on the supply, by way of or as part of any service or in any other manner whatsoever, of
goods, being food or any other article for human consumption or any drink (whether or not
intoxicating), where such supply or service, is for cash, deferred payment or other valuable
consideration, and such transfer, delivery or supply of any goods shall be deemed to be a sale of
those goods by the person making the transfer, delivery or supply and a purchase of those goods by
the person to whom such transfer, delivery or supply is made;”
38. Thus, the above clause specifies the cases which the tax in relation to sale and purchase of goods
will include and also outlines its applicability even in the case of deemed sale.
39. Section 66E deals with the concept of declared services.
This Section reads as follows:− “66E. The following shall constitute declared services, namely:––Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

(a) renting of immovable property;
(b) construction of a complex, building, civil structure or a part thereof, including a complex or
building intended for sale to a buyer, wholly or partly, except where the entire consideration is
received after issuance of completion−certificate by the competent authority.
Explanation.− For the purposes of this clause,− (I) the expression “competent authority” means the
Government or any authority authorized to issue completion certificate under any law for the time
being in force and in case of nonrequirement of such certificate from such authority, from any of the
following, namely:– (A) architect registered with the Council of Architecture constituted under the
Architects Act, 1972; (20 of 1972.) or (B) chartered engineer registered with the Institution of
Engineers (India); or (C) licensed surveyor of the respective local body of the city or town or village
or development or planning authority;
(II) the expression “construction” includes additions, alterations, replacements or remodeling of any
existing civil structure;
(c) temporary transfer or permitting the use or enjoyment of any intellectual property right;
(d) development, design, programming, customisation, adaptation, upgradation, enhancement,
implementation of information technology software;
(e) agreeing to the obligation to refrain from an act, or to tolerate an act or a situation, or to do an
act;
(f) transfer of goods by way of hiring, leasing, licensing or in any such manner without transfer of
right to use such goods;
(g) activities in relation to delivery of goods on hire purchase or any system of payment by
instalments;
(h) service portion in the execution of a works contract;
(i) service portion in an activity wherein goods, being food or any other article of human
consumption or any drink (whether or not intoxicating) is supplied in any manner as a part of the
activity.”
40. Thus, the declared services include the services of renting of immovable property, works
contract, hire purchase/instalment payment system, supply of food/drink, etc. In other words,
under the Constitution what is related to deemed sale is also covered under the deemed service as
per the above Section.
41. The Transfer of Right to use goods for case, deferred payment or value consideration is
considered as deemed sale under sub−clause (d) of Article 366(29A) of the Constitution of India.Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

Right to use of tangible goods service has also been brought under the service tax net by the Finance
Act, 2008, with effect from 16.05.2008 vide notification No. 18/2008−ST, dated 10.05.2008
whereby taxable service has been defined under Section 65(105)(zzzzj) of the Act 1994 to mean as:−
“Any services provided or to be provided, to any person, by any other person in relation to supply of
tangible goods including machinery, equipment and appliances for use, without transferring right of
possession and effective control of such machinery, equipment and appliances.” POSITION OF LAW
42. TATA Consultancy Services (supra) was a case in which the specific issue of computer software
packages was considered as is the concern in the present case also. There was, however, a distinction
drawn insofar as the 'uncanned software' and 'canned software' alternatively termed as 'unbranded'
and 'branded' is concerned. The distinction is in that a 'canned software' contains programmes
which can be used as such by any person purchasing it, while an 'uncanned software' is one prepared
for a particular purchaser's requirements by tweaking the original software to adapt to the specific
requirements of a particular entity. While a 'canned software' could be sold over the shelf, an
'uncanned software' is programmed to specific and particular needs and requirements.
This Court held that in India the test to determine whether a property is “goods”, for the purpose of
sales tax, is not confined to whether the goods are tangible or intangible or incorporeal.
The correct test would be to determine whether an item is capable of abstraction, consumption and
use and whether it can be transmitted, transferred, delivered, stored, possessed, etc. It was held that
both in the case of 'canned' and 'uncanned' software all these are possible (sic para 16). Associated
Cement Companies Ltd. v. Commissioner of Customs, (2001) 4 SCC 593, was heavily relied on by
this Court. It was held:− "27. In our view, the term "goods" as used in Article 366(12) of the
Constitution and as defined under the said Act is very wide and includes all types of movable
properties, whether those properties be tangible or intangible. We are in complete agreement with
the observations made by this Court in Associated Cement Companies Ltd. A software program may
consist of various commands which enable the computer to perform a designated task. The
copyright in that program may remain with the originator of the program. But the moment copies
are made and marketed, it becomes goods, which are susceptible to sales tax. Even intellectual
property, once it is put on to a media, whether it be in the form of books or canvas (in case of
painting) or computer discs or cassettes, and marketed would become "goods". We see no difference
between a sale of a software program on a CD/floppy disc from a sale of music on a cassette/CD or a
sale of a film on a video cassette/CD. In all such cases, the intellectual property has been
incorporated on a media for purposes of transfer. Sale is not just of the media which by itself has
very little value. The software and the media cannot be split up. What the buyer purchases and pays
for is not the disc or the CD. As in the case of paintings or books or music or films the buyer is
purchasing the intellectual property and not the media i.e. the paper or cassette or disc or CD. Thus
a transaction/sale of computer software is clearly a sale of "goods" within the meaning of the term as
defined in the said Act. The term "all materials, articles and commodities" includes both tangible
and intangible/incorporeal property which is capable of abstraction, consumption and use and
which can be transmitted, transferred, delivered, stored, possessed, etc. The software programs have
all these attributes".Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

28. At this stage it must be mentioned that Mr Sorabjee had pointed out that the High Court has, in
the impugned judgment, held as follows:
"... In our view a correct statement would be that all intellectual properties may not
be 'goods' and therefore branded software with which we are concerned here cannot
be said to fall outside the purview of 'goods' merely because it is intellectual property;
so far as 'unbranded software' is concerned, it is undoubtedly intellectual property
but may perhaps be outside the ambit of 'goods'."
(emphasis supplied)
29. Mr Sorabjee submitted that the High Court correctly held that unbranded software was
"undoubtedly intellectual property". Mr Sorabjee submitted that the High Court fell in error in
making a distinction between branded and unbranded software and erred in holding that branded
software was "goods". We are in agreement with Mr Sorabjee when he contends that there is no
distinction between branded and unbranded software. However, we find no error in the High Court
holding that branded software is goods. In both cases, the software is capable of being abstracted,
consumed and use. In both cases the software can be transmitted, transferred, delivered, stored,
possessed, etc. Thus even unbranded software, when it is marketed/sold, may be goods. We,
however, are not dealing with this aspect and express no opinion thereon because in case of
unbranded software other questions like situs of contract of sale and/or whether the contract is a
service contract may arise".
43. Associated Cement Companies Ltd. (supra) considered the question whether the drawings,
designs, etc. relating to machinery or industrial technology were goods, leviable to duty of customs
on their transaction value at the time of import. It was argued that the transfer of technology or
know−how though valuable was intangible. The technology when transmitted to India on some
media does not get converted from an intangible thing to tangible thing or chattel and that in a
contract by supply of services there is no sale of goods, was the argument.
Reading Section 2(22) of the Customs Act, 1962 which defines the word "goods", including clause (c)
"baggage" and clause (e) "any other kind of moveable property", it was held that any moveable
article brought into India by a passenger as part of his baggage can make him liable to pay customs
duty as per the Customs Tariff Act, 1975. Any media whether in the form of books or computer disks
or cassettes which contain information technology or ideas would necessarily be regarded as “goods”
under the aforesaid provisions of the Customs Act, these items being moveable goods, covered by
Section 2(22)(e) of the Customs Act. What was transferred was technical advice on information
technology. But the moment the information or advice is put on a media, whether paper or diskettes
or any other thing, the supply is of a chattel. It is in respect of the drawings, designs, etc. which are
received that payment is made to the foreign collaborators. The question whether the papers or
diskettes etc. containing advice and/or information are goods for the purpose of the Customs Act
was answered in the affirmative. This Court clearly held that "the intellectual property when put on
a media would be regarded as an article on the total value of which customs duty is payable". "When
technical material is supplied whether in the form of drawings or manuals the same are goods liableCommissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

to customs duty on the transaction value in respect thereof". It was concluded so in paragraph 46:
"46. The concept that it is only chattel sold as chattel, which can be regarded as
goods, has no role to play in the present statutory scheme as we have already
observed that the word "goods" as defined under the Customs Act has an inclusive
definition taking within its ambit any moveable property. The list of goods as
prescribed by the law are different items mentioned in various chapters under the
Customs Tariff Act, 1997 or 1999. Some of these items are clearly items containing
intellectual property like designs, plans, etc".
(underlining by us for emphasis)
44. We may also refer to and rely upon a decision of this Court in the case of 20th Century Finance
Corpn. Ltd. v. State of Maharashtra, reported in (2000) 6 SCC 12. In this decision, this Court
considered the incorporation of clause (d) of Clause (29A) of Article 366 of the Constitution referred
to above. It is apt to quote the following relevant portion from the judgment :− “26… The various
sub−clauses of clause (29A) of Article 366 permit the imposition of tax thus: sub− clause (a) on
transfer of property in goods; sub− clause (b) on transfer of property in goods; sub− clause (c) on
delivery of goods; sub−clause (d) on transfer of the right to use goods; sub−clause (e) on supply of
goods; and sub−clause (f) on supply of services. The words and such transfer, delivery or supply. In
the latter portion of clause (29A), therefore, refer to the words transfer, delivery and supply, as
applicable, used in the various sub− clauses. Thus, the transfer of goods will be a deemed sale in the
cases of sub−clauses (a) and (b), the delivery of goods will be a deemed sale in case of sub−clause
(c), the supply of goods and services respectively will be deemed sales in the cases of sub− clauses
(e) and (f) and the transfer of the right to use any goods will be a deemed sale in the case of sub−
clause (d). Clause (29A) cannot, in our view, be read as implying that the tax under sub−clause
(d) is to be imposed not on the transfer of the right to use goods but on the delivery of the goods for
use. Nor, in our view, can a transfer of the right to use goods in sub−clause (d) of clause (29A) be
equated with the third sort of bailment referred to in Bailment by Palmer, 1979 edition, page 88. The
third sort referred to there is when goods are left with the bailee to be used by him for hire, which
implies the transfer of the goods to the bailee. In the case of sub−clause (d), the goods are not
required to be left with the transferee. All that is required is that there is a transfer of the right to use
the goods. In our view, therefore, on a plain construction of sub− clause (d) of Clause (29A), the
taxable event is the transfer of the right to use the goods regardless of when or whether the goods
are delivered for use. What is required is that the goods should be in existence so that they may be
used. And further contract in respect thereof is also required to be executed. Given that, the locus of
the deemed sale is the place where the right to use the goods is transferred. Where the goods are
when the right to use them is transferred is of no relevance to the locus of the deemed sale. Also of
no relevance to the deemed sale is where the goods are delivered for use pursuant to the transfer of
the right to use them, though it may be that in the case of an oral or implied transfer of the right to
use goods, it is effected by the delivery of the goods.”Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

45. While holding that in a contract for the transfer of the right to use goods, the taxable event
would be the execution of the contract for delivery of the goods, it was observed :− “27. Article
366(29A)(d) further shows that levy of tax is not on use of goods but on the transfer of the right to
use goods. The right to use goods accrues only on account of the transfer of right. In other words,
right to use arises only on the transfer of such a right and unless there is transfer of right, the right
to use does not arise. Therefore, it is the transfer which is sine qua non for the right to use any
goods. If the goods are available, the transfer of the right to use takes place when the contract in
respect thereof is executed. As soon as the contract is executed, the right is vested in the lessee.
Thus, the situs of taxable event of such a tax would be the transfer which legally transfers the right
to use goods. In other words, if the goods are available irrespective of the fact where the goods are
located and a written contract is entered into between the parties, the taxable event on such a
deemed sale would be the execution of the contract for the transfer of right to use goods. But in case
of an oral or implied transfer of the right to use goods it may be effected by the delivery of the
goods.” (Emphasis Supplied)
46. In BSNL (supra) this Court took the view that a telephone service is nothing but a “service”.
However, the nature of the transaction involved in providing the telephone connection may be a
composite contract of “service” and “sale”.
There may be a transfer of right to use the “goods” as defined in the providing of access or telephone
connection by the telephone service provider to a subscriber. Justice Ruma Pal, speaking for the
Bench in her separate judgment, took the view that a subscriber to a telephone service could not
reasonably be taken to have intended to purchase or obtain any right to use electromagnetic waves
or radio frequencies when a telephone connection is given. Nor does the subscriber intend to use
any portion of the wiring, the cable, the satellite, the telephone exchange, etc. At the most, the
concept of the sale in a subscriber's mind would be limited to the handset that might have been
purchased for the purposes of getting a telephone connection. As far as the subscriber is concerned,
no right to the use of any other goods, incorporeal or corporeal, is given to him with the telephone
connection. In such circumstances, it was held that the electromagnetic waves or radio frequencies
are not “goods” within the meaning of the word “either in Article 366(12) or for the purpose of
Article 366(29A)(b)”. Emphasis was laid on the fact, whether there are any deliverable goods or not.
If there are no deliverable goods in existence, like the one in BSNL (supra), there is no transfer of
user under Article 366(29A)(b) at all.
47. Justice Dr. AR. Lakshmanan, in his separate but concurring judgment, highlighted the following
attributes in para 97 of the judgment to constitute a transaction for the transfer of right to use the
goods:− “97. … a. There must be goods available for delivery;
b. There must be a consensus ad idem as to the identity of the goods;
c. The transferee should have a legal right to use the goods − consequently all legal consequences of
such use including any permissions or licenses required therefor should be available to the
transferee;Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

d. For the period during which the transferee has such legal right, it has to be the exclusion to the
transferor − this is the necessary concomitant of the plain language of the statute viz. a "transfer of
the right to use" and not merely a licence to use the goods;
e. Having transferred the right to use the goods during the period for which it is to be transferred,
the owner cannot again transfer the same rights to others.”
48. In the case of BSNL (supra), His Lordship noticed that none of the aforesaid attributes were
present in the relationship between the telecom service provider and a consumer of such services.
49. His Lordship thereafter in para 117 of the judgment referred to the Sale of Goods Act, 1930. We
quote para 117 as under:− “117. Sale of Goods Act, comprehends two elements, one is a sale and the
other is delivery of goods. 20th Century Finance Corporation Limited vs. State of Maharashtra,
2000 (6) SCC 12 at p. 44, para 35 ruled that "35. (c) where the goods are available for the transfer of
right to use the taxable event on the transfer of right to use any goods is on the transfer which
results in right to use and the situs of sale would be the place where the contract is executed and not
where the goods are located for use.
(d) In cases where goods are not in existence or where there is an oral or implied transfer of the
right to use goods, such transactions may be effected by the delivery of the goods. In such cases the
taxable event would be on the delivery of goods."
50. Ultimately, His Lordship took the view that as no goods’ elements were involved, the transaction
was purely one of service as there was no transfer of right to use the goods at all.
51. The following principles to the extent relevant may be summed up:−
(a) The Constitution (Forty−sixth) Amendment Act intends to rope in various economic activities by
enlarging the scope of “tax on sale or purchase of goods” so that it may include within its scope, the
transfer, delivery or supply of goods that may take place under any of the transactions referred to in
sub−clauses (a) to (f) of Clause (29A) of Article 366.
The works contracts, hire purchase contracts, supply of food for human consumption, supply of
goods by association and clubs, contract for transfer of the right to use any goods are some such
economic activities.
(b) The transfer of the right to use goods, as distinct from the transfer of goods, is yet another
economic activity intended to be exigible to State tax.
(c) There are clear distinguishing features between ordinary sales and deemed sales.
(d) Article 366(29A)(d) of the Constitution implies tax not on the delivery of the goods for use, but
implies tax on the transfer of the right to use goods. The transfer of the right to use the goods
contemplated in sub−clause (d) of clause (29A) cannot be equated with that category of bailmentCommissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

where goods are left with the bailee to be used by him for hire.
(e) In the case of Article 366(29A)(d) the goods are not required to be left with the transferee. All
that is required is that there is a transfer of the right to use goods. In such a case taxable event
occurs regardless of when or whether the goods are delivered for use. What is required is that the
goods should be in existence so that they may be used.
(f) The levy of tax under Article 366(29A)(d) is not on the use of goods. It is on the transfer of the
right to use goods which accrues only on account of the transfer of the right.
In other words, the right to use goods arises only on the transfer of such right to use goods.
(g) The transfer of right is the sine qua non for the right to use any goods, and such transfer takes
place when the contract is executed under which the right is vested in the lessee.
(h) The agreement or the contract between the parties would determine the nature of the contract.
Such agreement has to be read as a whole to determine the nature of the transaction. If the
consensus ad idem as to the identity of the good is shown the transaction is exigible to tax.
(i) The locus of the deemed sale, by transfer of the right to use goods, is the place where the relevant
right to use the goods is transferred. The place where the goods are situated or where the goods are
delivered or used is not relevant.
52. From the judicial decisions, the settled essential requirement of a transaction for the transfer of
the right to use the goods are :
(i) it is not the transfer of the property in goods, but it is the right to use the property
in goods;
(ii) Article 366(29A)(d) read with the latter part of the clause (29A) which uses the
words, “and such transfer, delivery or supply”… would indicate that the tax is not on
the delivery of the goods used, but on the transfer of the right to use goods regardless
of when or whether the goods are delivered for use subject to the condition that the
goods should be in existence for use;
(iii) in the transaction for the transfer of the right to use goods, delivery of the goods
is not a condition precedent, but the delivery of goods may be one of the elements of
the transaction;
(iv) the effective or general control does not mean always physical control and, even if
the manner, method, modalities and the time of the use of goods is decided by the
lessee or the customer, it would be under the effective or general control over the
goods;Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

(v) the approvals, concessions, licences and permits in relation to goods would also
be available to the user of goods, even if such licences or permits are in the name of
owner (transferor) of the goods, and
(vi) during the period of contract exclusive right to use goods along with permits,
licenses, etc., vests in the lessee.
CONSTRUCTION OF AGREEMENT BETWEEN THE PARTIES:−
53. The salient features of the Quick Heal Internet Security End−User License Agreement are as
follows:−
1. Grant of License, not ownership In consideration of payment of the License Fee, which is a part of
the price, Quick Heal (developer) grants the purchaser (end−user) a license which is non−exclusive
and non−transferable. The developer reserves all rights not expressly granted and retains the title
and ownership of the software, including all subsequent copies in any media.
2. Termination The End−user is entitled to use the software till the date on which the license
expires. Any unauthorised usage of the software would result in automatic and immediate
termination of the agreement and the license granted.
3. Breach of Contract The developer reserves to take any action against unauthorised usage. This
may be criminal/civil action by the developer, including the right to block the key file/License
key/product key with neither issuance of any notice nor refund to the end−user.
4. Right to Updates During the license period of the software, the end−users are entitled to receive
free software updates via Internet. The End−users will be required to regularly download these
updates, which shall be governed by the agreement or as amended by the developer.
5. Limiting Liability The End−users are solely responsible for configuring the software settings and
the results, actions, inactions initiated due to the same. The developer assumes no liability for any
deletion or modification authorised by the user in any case, and the indemnification clause would
become applicable.
6. Disclaiming Warranties Certain features of the software may require additional payment. The
developer disclaims any claim for reimbursement of expenses arising out of end−users’ usage of
such features.
7. Governing Law The End−users are obliged to comply with all laws, regulations of India and any
foreign law, including privacy, obscenity, confidentiality, copyright laws, while using the software.
8. Data Collection On updating every licensed copy, the developer would collect “the current product
status information”, which include the state of monitoring service in the system. This information is
used for improving the developer’s technical support towards its customers. No files or personalCommissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

data is collected.
9. Intellectual Property Rights of the Developer The End−users do not have any right, title, or
interest to the intellectual property, including any error corrections, enhancements, updates, or
modifications to the software, whether made by the developer or third party.
54. In Delta International Ltd. v. Shyam Sundar Ganeriwalla, (1999) 4 SCC 545 : AIR 1999 SC 2607
and Ramdev Food Products (P) Ltd. v. Arvindbhai Rambhai Patel, (2006) 8 SCC 726, this Court
quoted with approval the following principles of construction of contracts from the ‘Interpretation
of Contracts’ by Kim Lewison, Q.C. as follows.
“1.03 For the purpose of the construction of contracts, the intention of the parties is the meaning of
the words they have used. There is no intention independent of that meaning.
6.09 Where the words of a contract are capable of two meanings, one of which is lawful and the
other unlawful, the former construction should be preferred.
Sir Edward Coke [Co. Litt. 42a] expressed the proposition thus:
‘It is a general rule, that whensoever the words of a deed, or of one of the parties
without deed, may have a double intendment and the one standeth with law and
right, and the other is wrongful and against law, the intendment that standeth with
law shall be taken.’ In more modern times that statement was approved by the Privy
Council in Rodger v. Comptoir D'Escomple de Paris, (1869) LR 2 PC 393 : 16 ER 618,
in which Sir Joseph Napier, delivering the advice of the Board said:
‘The rule that words shall be construed most strongly against him who uses them
gives place to a higher rule; higher because it has a moral element, that the
construction shall not be such as to work a wrong.’ Similarly, in Fausset v. Carpenter,
(1831) 2 Dow & Cl 232 : 6 ER 715, the House of Lords accepted the submission of
counsel that the court:
‘… in judging of the design and object of a deed, will not presume that a party
executing the deed meant to do and did what he was wrong in doing, when a
construction may be put on the instrument perfectly consistent with his doing only
what he had a right to do.
However, the question of construction should not be approached with a leaning in
one direction or another. Thus although the law frowns upon covenants in restraint
of trade, nevertheless such a covenant should not be approached on the basis that it is
prima facie illegal. ‘You are to construe the contract, and then see whether it is legal.’”
55. The sum and substance of the ratio of the case of BSNL (supra) as discernible is
that the contract cannot be vivisected or split into two. Once a lumpsum has beenCommissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

charged for the sale of CD (as in the case on hand) and sale tax has been paid
thereon, the revenue thereafter cannot levy service tax on the entire sale
consideration once again on the ground that the updates are being provided. We are
of the view that the artificial segregation of the transaction, as in the case on hand,
into two parts is not tenable in law. It is, in substance, one transaction of sale of
software and once it is accepted that the software put in the CD is “goods”, then there
cannot be any separate service element in the transaction. We are saying so because
even otherwise the user is put in possession and full control of the software. It
amounts to “deemed sale” which would not attract service tax.
56. In view of the aforesaid, we have reached to the conclusion that the impugned
order of the Tribunal suffers from no jurisdictional or any other legal infirmity
warranting any interference at our end in the present appeal.
57. In the result, the appeal fails and it is hereby dismissed.
58. There shall be no order as to costs.
59. Pending application(s), if any, also stands disposed of.
CIVIL APPEALS ARISING OUT OF S.L.P. (CIVIL) NOS. 6715− 6716 OF 2022
60. Leave granted.
61. These appeals, by special leave, are at the instance of the assessee and is directed against the
order passed by the High Court of Judicature at Madras in Writ Appeal No. 1881 of 2021 and CMP
No. 11998 of 2021 decided on 05.08.2021 by which the High Court dismissed the writ appeal
thereby affirming the Order in Original dated 26.04.2018 passed by the respondent herein.
FACTUAL MATRIX
62. The appellant herein obtained the antivirus software replicated from the units in Himachal
Pradesh duly assessed to Nil Central Excise duty under the Notification No. 50/2003 CE dated
10.06.2003, and sold antivirus software in the CD form i.e., as a “packaged software or canned
software” both indigenously by remitting appropriate VAT or exported the same. Disputes were
raised by the tax authorities claiming that the activities of the appellant herein came within the
ambit of the Information Technology Software Service as defined under Section 65(105)(zzzze) of
the Act 1994. The initial notices issued ended in the confirmation of demand on the ground that
since the appellant was providing the key and allowing updates online, it amounted to digital
delivery and therefore it would fall under the above taxable entry.
63. The appellant preferred statutory appeals against these orders passed by the Tribunal, Chennai
Branch.Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

64. The Tribunal was pleased to grant interim stay as the appellant had paid VAT on the sale of the
software. While the appeals were pending before the Tribunal, Chennai Branch, the Department
continued to issue further show cause notices from time to time along with the issued statement of
demand for these periods. The appellant filed a detailed reply dated 17.04.2018 contending that no
service tax was payable as the liability towards the VAT had already been discharged and the
software being goods could not be made exigible to service tax.
Despite the clear pronouncement by this Court, an Order−in− Original dated 26.04.2018 was passed
confirming tax on the regime value charged by the appellant for the sale of the software on which the
VAT was paid including the value of the software exported, leading to the excessive demand not
authorized under law. Further, the authority observed in para 6.6 of his order that in terms of the
judgment of this Hon’ble Court in TCS, the character of the software as goods cannot be taken away
and that it fell within the ambit of “deemed sales”.
The said authority further imposed penalty and levied interest as well.
65. The appellant filed Writ Petition No. 25923 of 2018 before the Madras High Court and a learned
single Judge admitted the writ petition and also granted interim stay noting that the VAT had
already been paid on the goods.
66. While the writ petition was pending, the Tribunal, Chennai Branch followed the decision of the
Tribunal, Delhi Bench in the case of Quick Heal Technologies Ltd. (supra) and allowed the appeals
filed by the appellant in their earlier cases. It is significant to note that against this order of the
Tribunal, Chennai Bench no further appeal has been filed by the Department and thus, the view
taken by the Tribunal became final in so far as the appellant is concerned.
67. When the above−mentioned Writ Petition No. 25923 of 2018 came up for final disposal, the
learned single Judge vide order dated 29.10.2020 dismissed the Writ Petition, inter alia, on the
ground that the High Court was not bound by the decision of the Tribunal, Delhi Bench in the case
of Quick Heal Technologies Ltd. and the appellant’s own order passed by the Tribunal, Chennai
Bench.
68. Aggrieved by the order of the learned single Judge, the appellant preferred the Writ Appeal No.
1881 of 2021 against the order dated 29.10.2020 passed by the learned single Judge in Writ Petition
No. 25923 of 2018. The Division Bench vide order dated 05.08.2021 declined to interfere with the
order of the learned single Judge on the ground that an earlier Division Bench decision of the
Madras High Court in the case of M/s Infotech Software Dealers Association v. Union of India
(supra) covered the issue. It also held that the anti−virus software which is installed in the hardware
would interact whenever the user of the computer engages the system.
69. In such circumstances referred to above, the appellant herein has come up before this Court by
filing the present appeals.Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

70. These appeals should succeed in the light of the reasoning assigned by us while dismissing the
Civil Appeal (Diary No. 24399 of 2020), as above.
71. However, while allowing these appeals, we may only observe that in the case of M/s Infotech
Software Dealers Association v. Union of India (supra) the challenge was to the validity of Section
65(105)(zzzze) levying service tax on the information technology software service. The High Court
held that the question whether the software is “goods” or not would depend on the facts and
circumstances of individual case. It is evident on plain reading of the judgment rendered by the
Madras High Court in the case of M/s Infotech Software Dealers Association (supra) that it has not
referred to the decision of this Court in the case of TATA Consultancy Services (supra).
72. We take notice of the fact that the appellant herein had also filed a Review Petition No. 205 of
2021 against the order dated 05.08.2021 in the Writ Appeal No. 1881 of 2021, which came to be
rejected vide order dated 20.12.2021.
73. In view of the judgment rendered above in Civil Appeal (Diary No. 24399 of 2020), these appeals
should succeed and deserve to be allowed.
74. In the result, the appeals are allowed. The impugned order passed by the High Court dated
05.08.2021 in the Writ Appeal No. 1881 of 2021 as also the order dated 20.12.2021 passed in the
Review Petition No. 205 of 2021 in Writ Appeal No. 1881 of 2021 are hereby set aside.
75. There shall be no order as to costs.
76. Pending application(s), if any, also stands disposed of.
……………………………………..J. (ABHAY S. OKA) …………………………………….J. (J.B. PARDIWALA)
NEW DELHI;
AUGUST 05, 2022Commissioner Of Service Tax Delhi vs Quick Heal Technologies Limited on 5 August, 2022

