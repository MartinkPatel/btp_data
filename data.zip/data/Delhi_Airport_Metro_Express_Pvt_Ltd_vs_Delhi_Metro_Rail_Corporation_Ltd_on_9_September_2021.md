Delhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail
Corporation Ltd. on 9 September, 2021
Equivalent citations: AIRONLINE 2021 SC 708
Author: L. Nageswara Rao
Bench: S. Ravindra Bhat, L. Nageswara Rao
                                                REPORTABLE
         IN THE SUPREME COURT OF INDIA
          CIVIL APPELLATE JURISDICTION
             Civil Appeal No. 5627 of 2021
       (Arising out of SLP (C) No. 4115 of 2019)
Delhi Airport Metro Express Pvt. Ltd.
                                            .... Appellant(s)
                           Versus
Delhi Metro Rail Corporation Ltd.
                                         …. Respondent (s)
                           WITH
             Civil Appeal No. 5628 of 2021
       (Arising out of SLP (C) No. 8311 of 2019)
                   JUDGMENT
L. NAGESWARA RAO, J.
Leave granted.
1. Whether in exercise of its power under Section 37 of the Arbitration and Conciliation Act, 1996
(hereinafter, ‘ the 1996 Act’), the Division Bench of the Delhi High Court was right in interfering
with the award dated 11.05.2017 passed by the Arbitral Tribunal in favour of the Appellant - Delhi 1 |
Page Airport Metro Express Pvt. Ltd. (hereinafter, ‘ DAMEPL’ or the ‘Concessionaire’), is the
question that arises for consideration in these Appeals.
2. Delhi Metro Rail Corporation Ltd. (hereinafter, ‘ DMRC’), a joint venture of the Government of
India and the Government of National Capital Territory of Delhi, proposed implementation of the
Airport Metro Express Line project in New Delhi, from New Delhi Railway Station to Dwarka Sector
21 via Indira Gandhi International Airport, New Delhi (hereinafter, ‘AMEL’). The approximateDelhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

length of the project was 22.7 kilometers. It was decided to develop the project by engaging a
concessionaire for financing, design, procurement, installation of all systems (including but not
limited to rolling stock, overhead electrification, track, signaling and telecommunication, ventilation
and air conditioning, automatic fare collection, baggage check-in and handling, depot and other
facilities). DMRC had to undertake design and construction of basic civil structure for the project,
which was in the nature of a public private partnership.
3. The bid of a consortium comprising Reliance Energy Limited (renamed as Reliance Infrastructure
Limited) and M/s Construcciones y Auxiliar de Ferrocarriles, S.A. was accepted 2 | Page by DMRC,
by issuing a letter of acceptance on 21.01.2008. Thereafter, on 25.08.2008, a Concession Agreement
was entered into between DMRC and DAMEPL for design, installation, commissioning, operation
and maintenance of the AMEL. It was agreed between the parties that all civil works as well as
appointment of consultants, land acquisition and other clearances from the Government and other
authorities have to be obtained by DMRC and the design, supply, installation, testing and
commissioning of various systems like rolling stock, power supply, overhead equipment, signalling,
track system, platform, screen doors, ventilation, architectural finishing etc. were to be provided by
DAMEPL. As the work could not be completed in time, extensions were granted and finally, safety
clearances were obtained from the Commissioner of Metro Railway Safety (hereinafter, the ‘CMRS’
or ‘Commissioner’) on 10.01.2011. The date of commercial operation was achieved on 23.02.2011.
4. On 22.03.2012, DAMEPL requested DMRC for a joint inspection of viaduct and its bearings
before expiry of the defect liability period of the civil contractors. Another letter was written by
DAMEPL on 23.05.2012, complaining of issues relating to the design and quality in the installation
of viaduct 3 | Page bearings. It was mentioned in the said letter that there were signs of girders
having sunk at some locations as a result of deformations/cracks. DMRC responded to the said
letter of DAMEPL on 08.06.2012 by which DAMEPL was informed that inspections were carried out
at the locations pointed out by DAMEPL and no bearings were found damaged. However, DMRC
admitted that grouting material filled above/below the bearings was damaged/loosened for which
action would be taken to repair them on priority. Due to the said defects, DMRC advised DAMEPL
to impose speed restrictions as deemed necessary in the interest of safety.
5. The Ministry of Urban Development, Government of India convened a meeting of all the
stakeholders on 02.07.2012. The views of all the parties relating to the defects were obtained and a
Joint Inspection Committee was formed. An interim report was submitted by the Joint Inspection
Committee after inspection on 4 th & 5th July, 2012. Subsequently, DAMEPL stopped operations of
the Line on 08.07.2012.
6. A notice was issued by DAMEPL on 09.07.2012, asking DMRC to cure the defects in DMRC’s
works within a period of 90 days from the date of the notice, failing which it shall be treated as a
breach having Material Adverse Effect on the 4 | Page Concessionaire under the Concession
Agreement. In the said notice dated 09.07.2012, ‘a non-exhaustive list of defects’ was set out by
DAMEPL. Thereafter, a number of meetings were conducted between the parties which were
attended by SYSTRA, the original design consultant for the viaduct sections. It appears from the
record that DMRC had also engaged some other agencies for carrying out the repair work.Delhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

7. DAMEPL issued a notice dated 08.10.2012 terminating the Concession Agreement as, according
to it, the defects that were pointed out in the notice dated 09.07.2012 were not cured within a period
of 90 days, resulting in an Event of Default under the Concession Agreement. DMRC invoked
arbitration under Article 36.2 of the Concession Agreement on 23.10.2012. On 22.01.2013, the Line
was restarted with reduced speed after a certificate sanctioning resumption was issued by the
Commissioner on 18.01.2013. According to DAMEPL, it agreed to operate the Line only as an agent
in public interest and on instructions of DMRC, although DAMEPL’s stance was not accepted by
DMRC. DAMEPL stopped its operations on 30.06.2013 and handed over the Line to DMRC on the
next day.
5 | Page
8. At this stage, it is relevant to refer to Article 36 of the Concession Agreement which refers to
dispute resolution. Article 36.2.2, read with Article 36.2.3, provides that all disputes, whatsoever
arising between the parties, out of, touching upon or relating to construction, measuring, operation
or effect of the Concession Agreement or the breach thereof, shall be settled through arbitration by
reference to a sole arbitrator, where the total value of claims do not exceed Rs.1,500,000/-. Beyond
this limit, the dispute shall be referred to three arbitrators who will be selected from a panel of
engineers with requisite qualifications and professional experience relevant in the field to which the
Concession Agreement relates. The panel shall be from serving or retired engineers of government
departments or of public sector.
9. The main issue that arose for determination before the Arbitral Tribunal constituted under the
Concession Agreement is the validity of the termination notice dated 08.10.2012. DMRC claimed
that the termination notice issued by DAMEPL is illegal, as DMRC had taken various steps
honouring its obligations under the Concession Agreement. A direction was sought from the Arbitral
Tribunal to DAMEPL to take over operations of the AMEL under the Concession Agreement, 6 |
Page and in the alternative, to grant compensation of Rs.3,173 crore with interest of 18% per annum.
Further monetary reliefs were sought by DMRC. The claim of compensation sought by DMRC was
dependent on the determination of the main issue, i.e., the validity of the termination notice dated
08.10.2012. DMRC also raised an issue on the real motive of DAMEPL to terminate the Concession
Agreement. DAMEPL justified the termination as being in conformity with the Concession
Agreement and consequently, filed a counter claim seeking an amount of Rs.3,470 crore as
termination payment along with interest and further amounts as detailed in the counter claim, on
the ground that DMRC did not cure the defects in the civil structure in terms of the cure notice
dated 09.07.2012. As DMRC did not comply with its obligations under Article 29.5.1(i), DAMEPL
justified the termination notice dated 08.10.2012 and the consequent claim of termination payment
from DMRC under Article 29.5.2.
10. The Arbitral Tribunal formulated the following primary issues for consideration in relation to
the termination notice dated 08.10.2012: -
“i) Were there any defects in the civil structure of the airport metro line?Delhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

7 | Page
(ii) If there were defects, did such defects have a material adverse effect on the
performance of the obligation of DAMEPL under CA?
(iii) If there were defects in the civil structure, which had a material adverse effect on the
performance of the obligations under the CA by DAMEPL, have such defects been cured by DMRC
and / or have any effective steps been taken within a period of 90 days from the date of notice by
DAMEPL to cure the defects by DMRC and thus were DMRC in breach of the CA as per 29.5.1 (i)?”
11. In assessing whether the defects pointed out by DAMEPL were cured and/or effective steps to
cure them were taken by DMRC within the time stipulated in the notice dated 09.07.2012, the
Arbitral Tribunal undertook an in-depth analysis of the defects in the civil structure and steps taken
for their repair/rectification. Insofar as the existence of defects is concerned, the Arbitral Tribunal
concluded that there were as many as 1551 cracks in 367 girders, i.e., 72 % of the girders were
affected by such cracks. Reports of inspections conducted at the behest of DMRC, giving mapping
data of the cracks, were relied upon by the Tribunal to hold that such cracks were spread in a large
number of 8 | Page girders. The Tribunal referred to the meeting dated 02.07.2012 conducted by the
Ministry of Urban Development during which the Managing Director, DMRC expressed his views
that the cracks occurred during “lowering” and not during operations. The evidence of Mr. Muls of
Systra was considered by the Arbitral Tribunal to hold that they were not sure of the cause of the
cracks. On account of such large numbers of cracks in the base slab of the pre-stressed concrete
girders in about a year of train operation, coupled with unreliable measurement of crack depth and
non-serious inspection of the repairs by an agency appointed by DMRC, the Arbitral Tribunal was of
the opinion that these defects adversely impacted the integrity of the structure. As effective steps
were not taken within the cure period of 90 days, the Tribunal held that DMRC was in breach of the
Concession Agreement, resulting in Material Adverse Effect on the Concessionaire.
12. As far as twist in the girders were concerned, the Arbitral Tribunal found that there were about
80 girders with twists varying between 10 to 20 mm which had not been rectified and no effective
steps were taken to cure the defects in such girders. The defects pointed out by DAMEPL regarding
gaps between the shear key and the girder being 9 | Page more than 25 mm and between 10 mm to
25 mm were not addressed and only gaps below 10 mm were addressed by some grinding, detailed
methodology for which was not brought out by DMRC in its evidence, as per the findings of the
Arbitral Tribunal. Therefore, the Tribunal concluded that these defects were neither cured nor
effective steps taken by DMRC within the cure period up to 08.10.2012, constituting a material
breach on the part of DMRC. On the basis of the above findings and findings in relation to other
defects, deficiencies and constraints in the civil structure of the AMEL which are not referred to
herein, the Arbitral Tribunal concluded that the defects had not been cured within the cure period of
90 days from 09.07.2012 nor had effective steps been taken to cure such defects. Ergo, the
termination notice issued by DAMEPL on 08.10.2012 was valid.
13. Having decided on the validity of the termination notice, the Tribunal went on to consider
certain legal issues so as to determine questions around specific performance of the contract, orDelhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

alternatively, the award of damages and the outcome of the counter claim filed by DAMEPL. One
such issue considered by the Arbitral Tribunal was whether the issue of certificate by the
Commissioner on 18.01.2013, giving clearance for resuming operations of the AMEL, 10 | P a g e
showed that the defects were duly cured. After examining the certificate issued by the
Commissioner, the Arbitral Tribunal held that while the Commissioner had sanctioned resumption
of services, certain conditions were imposed, essentially relating to the restriction of speed up to 50
km per hour, which had a material bearing on the prime purpose of the AMEL intended to serve as a
high-speed connectivity line. Moreover, the Commissioner himself recognized that the operation of
the Line had to be regularly monitored. The subsequent operation of the Line by DMRC was found
to be not relevant for determining the validity of the termination notice dated 09.07.2012. The
Arbitral Tribunal answered this issue in favour of DAMEPL. On consideration of the counter claim
of DAMEPL, the principal issue that came up before the Arbitral Tribunal was on determination of
the amount of Termination Payment payable by DMRC under the Concession Agreement. In this
regard, the Tribunal had to determine the quantum payable under each component of Termination
Payment, one of which was ‘Adjusted Equity’. DAMEPL sought payment of an amount of Rs.3,470
crore as Termination Payment. In this total, an amount of Rs.685 crore, which had been infused by
DAMEPL’s promoter, was factored in by DAMEPL for the purposes of calculating 11 | P a g e
‘Adjusted Equity’. Relying on the relevant clauses of the Concession Agreement, the Tribunal first
sought to determine the portion of funds that would qualify as ‘Equity’ under the Concession
Agreement, which would then be used for arriving at the figure of ‘Adjusted Equity’. Out of Rs.685
crore which was sought to be slotted under the head ‘Equity’ by DAMEPL, an amount of Rs.611.95
crore was determined to be ‘Equity’ by the Tribunal, on the basis of the evidence produced and the
construction of the relevant provisions of the Concession Agreement. Thereafter, the Tribunal
worked out ‘Adjusted Equity’ at Rs.983.02 crore and awarded a total amount of Rs.2782.33 crore,
along with further interest, as Termination Payment to be made to DAMEPL.
14. DMRC filed a petition under Section 34 of the 1996 Act for setting aside the award of the Arbitral
Tribunal dated 11.05.2017 in the Delhi High Court, which was dismissed by the learned Single Judge
of the High Court by a judgement dated 06.03.2018 observing that grounds for interference had not
been made out by DMRC. The learned Single Judge held that the findings recorded by the Arbitral
Tribunal on facts, law and interpretation of the Concession Agreement were all within the realm of
the Arbitral Tribunal and they needed no intervention by the Court exercising its power 12 | P a g e
under Section 34 of the 1996 Act. He was also of the view that the Court cannot substitute its view
when there are two views possible and the view taken by the Arbitral Tribunal is a plausible one.
15. DMRC filed an appeal under Section 37 of the 1996 Act read with Section 13 of the Commercial
Courts, Commercial Division and Commercial Appellate Division of High Courts Act, 2015 (the title
since amended to Commercial Courts Act, 2015), challenging the correctness of the judgment passed
by the learned Single Judge on 06.03.2018 dismissing the objections filed by DMRC under Section
34 of the 1996 Act. The Division Bench reversed the judgement of the learned Single Judge and
allowed the appeal filed by DMRC. The award passed by the Arbitral Tribunal was partly set aside.
The parties were left to invoke the arbitration clause for adjudication of the issues that were not
decided by the Division Bench. The judgement of the Division Bench dated 15.01.2019 is assailed in
these Appeals.Delhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

16. DMRC has also filed SLP (C) No.8311 of 2019 challenging the correctness of the aforesaid
judgement of the Division Bench in relation to the issues of grant of interest, waiver of the
termination notice due to DAMEPL’s conduct of operating the project for more than five months
from 13 | P a g e 22.01.2013, refusal by the Division Bench to grant relief of specific performance of
the Concession Agreement and non- consideration of the issue pertaining to the real reason for the
termination of the Concession Agreement by DAMEPL. Reasons given by the Division Bench for
setting aside the award
17. The Division Bench of the High Court held that the award of the Arbitral Tribunal had recorded
two different termination dates. As the Tribunal had based its reasoning on the validity of the
termination notice on two different dates leading to confusion and ambivalence as to the
termination notice and the date of termination, the award was found to be suffering from the vices
of perversity, irrationality and patent illegality. The High Court observed that in deciding the
question on defects in the civil structure and whether effective steps were taken to cure the defects,
the Arbitral Tribunal had committed serious error by holding, without ‘reason’, that the vital
evidence of the sanction granted by the CMRS for resumption of commercial operations of the
AMEL and the fact that DMRC had successfully operated the AMEL from 30.06.2013 till the date of
the award without any adverse incident were inconsequential. The High Court found 14 | P a g e
fault with the Arbitral Tribunal in virtually negating the certificate issued by the CMRS under the
Delhi Metro Railway (Operation and Maintenance) Act, 2002 (hereinafter, ‘the Delhi Metro Act’)
and held that the cumulative effect of the findings of the award on this issue ‘shocked the conscience
of the court’.
18. On the issue of Adjusted Equity, while considering the approach taken by the Arbitral Tribunal
for computation of the amounts payable under Article 29.5.2, the High Court was of the opinion that
the Tribunal’s reasoning was completely flawed and perverse. The High Court ruled that the
reasoning adopted by the Tribunal was patently illegal and the conclusion reached after doing so,
was one which no reasonable person would have come to. According to the High Court, the
treatment of Rs.611.95 crore as ‘Equity’ by the Tribunal, on the ground that such a project could not
have been executed with only Rs.1 lakh as equity funded by DAMEPL’s promoter (in terms of share
capital), was based on an assumption that the debt-to-equity ratio is commonly 60:40 or 80:20,
contrary to the evidence on record. This was held to be an egregious mistake committed by the
Tribunal. The High Court also found fault with the award which ignored the resolution passed by the
board of directors of DAMEPL on 15 | P a g e 16.03.2011, by which the amount of Rs. 611.95 crore
was converted to subordinated debt. The High Court held that ‘Adjusted Equity’ under the
Concession Agreement does not contemplate funds recognized as subordinated debt to be treated as
‘Equity’. With respect to the interpretation of the various provisions of the Concession Agreement
and the resultant conclusions on ‘Adjusted Equity’, the High Court held that the findings of the
Tribunal on this issue were in violation of Sections 28(1)(a) and 28(3) of the 1996 Act, as elaborated
in Associate Builders v. Delhi Development Authority1, as contractual provisions had been
interpreted in a way no fair-minded and reasonable person would.
19. In light of the reasons mentioned, the High Court set aside the conclusions of the Arbitral
Tribunal on the validity of the termination notice and that Rs.611.95 crore was ‘Equity’ for theDelhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

purpose of Article 29.5.2 of the Concession Agreement. Consequently, the award of Rs.2,782.33
crore to DAMEPL was set aside. In view of the above findings, the High Court considered the
direction for payment of interest to have become infructuous. The High Court felt that it would be
inappropriate to hear the parties on the issue of restitution at that stage and granted liberty to the
parties to 1 (2015) 3 SCC 49 16 | P a g e move appropriate applications under the 1996 Act to seek
remedies available to them.
Contours of the Court’s power to review arbitral awards
20. The 1996 Act was enacted to consolidate and amend the law relating to domestic arbitration,
international commercial arbitration and enforcement of foreign arbitral awards and also to define
the law relating to conciliation and for matters connected therewith, by taking into account the
United Nations Commission on International Trade Law (UNCITRAL) Model Law on International
Commercial Arbitration and the UNCITRAL Conciliation Rules. One of the principal objectives of
the 1996 Act is to minimize the supervisory role of courts in the arbitral process. With respect to
Part I of the 1996 Act, Section 5 imposes a bar on intervention by a judicial authority except where
provided for, notwithstanding anything contained in any other law for the time being in force. An
application for setting aside an arbitral award can only be made in accordance with provisions of
Section 34 of the 1996 Act. Relevant provisions of Section 34 (as they were prior to the Arbitration
and Conciliation (Amendment) Act, 2015) read as under:-
17 | P a g e “34. Application for setting aside arbitral award.
— (1) Recourse to a Court against an arbitral award may be made only by an application for setting
aside such award in accordance with sub-section (2) and sub- section (3).
(2) An arbitral award may be set aside by the Court only if—
(a) the party making the application furnishes proof that—
(i) a party was under some incapacity, or
(ii) the arbitration agreement is not valid under the law to which the parties have subjected it or,
failing any indication thereon, under the law for the time being in force; or
(iii) the party making the application was not given proper notice of the appointment of an
arbitrator or of the arbitral proceedings or was otherwise unable to present his case; or
(iv) the arbitral award deals with a dispute not contemplated by or not falling within the terms of the
submission to arbitration, or it contains decisions on matters beyond the scope of the submission to
arbitration:
Provided that, if the decisions on matters submitted to arbitration can be separated
from those not so submitted, only that part of the arbitral award which containsDelhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

decisions on matters not submitted to arbitration may be set aside; or
(v) the composition of the arbitral tribunal or the arbitral procedure was not in
accordance with the agreement of the parties, unless such agreement 18 | P a g e was
in conflict with a provision of this Part from which the parties cannot derogate, or,
failing such agreement, was not in accordance with this Part;
or
(b) the Court finds that—
(i) the subject-matter of the dispute is not capable of settlement by arbitration under the law for the
time being in force, or
(ii) the arbitral award is in conflict with the public policy of India.
Explanation.—Without prejudice to the generality of sub-clause (ii), it is hereby declared, for the
avoidance of any doubt, that an award is in conflict with the public policy of India if the making of
the award was induced or affected by fraud or corruption or was in violation of section 75 or section
81. …”
21. An amendment was made to Section 34 of the 1996 Act by the Arbitration and Conciliation
(Amendment) Act, 2015 (hereinafter, ‘the 2015 Amendment Act’). A perusal of the statement of
objects and reasons of the 2015 Amendment Act would disclose that the amendment to the 1996 Act
became necessary in view of the interpretation of the provisions of the 1996 Act by courts in certain
cases which had resulted in delay of disposal of arbitration proceedings and increase in interference
by courts in arbitration matters, which had the tendency to defeat the object of the 1996 Act.
19 | P a g e Initially, the matter was referred to the Law Commission of India to review the
shortcomings in the 1996 Act in detail. The Law Commission of India submitted its 176 th Report,
recommending various amendments to the 1996 Act. However, the Justice Saraf Committee on
Arbitration constituted by the Government, was of the view that the proposed amendments gave
room for substantial intervention by the court and were also contentious. Thereafter, on reference,
the Law Commission undertook a comprehensive study of the amendments proposed by the
Government, keeping in mind the views of the Justice Saraf Committee and other stakeholders. The
246 th Report of the Law Commission was submitted on 05.08.2014. Acting on the
recommendations made by the Law Commission in its 246th Report, amendments by way of the
2015 Amendment Act were made to several provisions of the 1996 Act, including Section 34. The
amended Section 34 reads as under: -
“34. Application for setting aside arbitral award. — (1) Recourse to a Court against an
arbitral award may be made only by an application for setting aside such award in
accordance with sub-section (2) and sub- section (3).Delhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

20 | P a g e (2) An arbitral award may be set aside by the Court only if—
(a) the party making the application furnishes proof that—
(i) a party was under some incapacity, or
(ii) the arbitration agreement is not valid under the law to which the parties have subjected it or,
failing any indication thereon, under the law for the time being in force; or
(iii) the party making the application was not given proper notice of the appointment of an
arbitrator or of the arbitral proceedings or was otherwise unable to present his case; or
(iv) the arbitral award deals with a dispute not contemplated by or not falling within the terms of the
submission to arbitration, or it contains decisions on matters beyond the scope of the submission to
arbitration:
Provided that, if the decisions on matters submitted to arbitration can be separated
from those not so submitted, only that part of the arbitral award which contains
decisions on matters not submitted to arbitration may be set aside; or
(v) the composition of the arbitral tribunal or the arbitral procedure was not in
accordance with the agreement of the parties, unless such agreement was in conflict
with a provision of this Part from which the parties cannot derogate, or, failing such
agreement, was not in accordance with this Part; or
(b) the Court finds that—
21 | P a g e
(i) the subject-matter of the dispute is not capable of settlement by arbitration under the law for the
time being in force, or
(ii) the arbitral award is in conflict with the public policy of India.
Explanation 1. —For the avoidance of any doubt, it is clarified that an award is in conflict with the
public policy of India, only if,—
(i) the making of the award was induced or affected by fraud or corruption or was in violation of
section 75 or section 81; or
(ii) it is in contravention with the fundamental policy of Indian law; or
(iii) it is in conflict with the most basic notions of morality or justice.Delhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

Explanation 2. —For the avoidance of doubt, the test as to whether there is a contravention with the
fundamental policy of Indian law shall not entail a review on the merits of the dispute.
(2-A) An arbitral award arising out of arbitrations other than international commercial arbitrations,
may also be set aside by the Court, if the Court finds that the award is vitiated by patent illegality
appearing on the face of the award:
Provided that an award shall not be set aside merely on the ground of an erroneous
application of the law or by re-appreciation of evidence. …”
22. A cumulative reading of the UNCITRAL Model Law and Rules, the legislative intent with which
the 1996 Act is made, Section 5 and Section 34 of the 1996 Act would make it clear 22 | P a g e that
judicial interference with the arbitral awards is limited to the grounds in Section 34. While deciding
applications filed under Section 34 of the Act, courts are mandated to strictly act in accordance with
and within the confines of Section 34, refraining from appreciation or re-appreciation of matters of
fact as well as law. (See: Uttarakhand Purv Sainik Kalyan Nigam Limited. v. Northern Coal Field
Limited. 2, Bhaven Construction Through Authorised Signatory Premjibhai K. Shah v. Executive
Engineer Sardar Sarovar Narmada Nigam Ltd. and Another3 and Rashtriya Ispat Nigam Limited v.
Dewan Chand Ram Saran4).
23. For a better understanding of the role ascribed to courts in reviewing arbitral awards while
considering applications filed under Section 34 of the 1996 Act, it would be relevant to refer to a
judgment of this Court in Ssangyong Engineering and Construction Company Limited v. National
Highways Authority of India (NHAI) 5 wherein R.F. Nariman, J. has in clear terms delineated the
limited area for judicial interference, taking into account the amendments brought about by the
2015 Amendment Act. The relevant 2 (2020) 2 SCC 455 3 2021 SCC OnLine SC 8 4 (2012) 5 SCC
306 5 (2019) 15 SCC 131 23 | P a g e passages of the judgment in Ssangyong (supra) are noted as
under: -
“34. What is clear, therefore, is that the expression “public policy of India”, whether
contained in Section 34 or in Section 48, would now mean the “fundamental policy of
Indian law” as explained in paras 18 and 27 of Associate Builders [Associate Builders
v. DDA, (2015) 3 SCC 49: (2015) 2 SCC (Civ) 204] i.e. the fundamental policy of
Indian law would be relegated to “Renusagar” understanding of this expression. This
would necessarily mean that Western Geco [ONGC v. Western Geco International
Ltd., (2014) 9 SCC 263 : (2014) 5 SCC (Civ) 12] expansion has been done away with.
In short, Western Geco [ONGC v. Western Geco International Ltd., (2014) 9 SCC 263
: (2014) 5 SCC (Civ) 12] ,as explained in paras 28 and 29 of Associate Builders
[Associate Builders v. DDA, (2015) 3 SCC 49 : (2015) 2 SCC (Civ) 204] , would no
longer obtain, as under the guise of interfering with an award on the ground that the
arbitrator has not adopted a judicial approach, the Court's intervention would be on
the merits of the award, which cannot be permitted post amendment.Delhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

However, insofar as principles of natural justice are concerned, as contained in Sections 18 and
34(2)
(a)(iii) of the 1996 Act, these continue to be grounds of challenge of an award, as is contained in para
30 of Associate Builders [Associate 24 | P a g e Builders v. DDA, (2015) 3 SCC 49 : (2015) 2 SCC
(Civ) 204] .
35. It is important to notice that the ground for interference insofar as it concerns “interest of India”
has since been deleted, and therefore, no longer obtains. Equally, the ground for interference on the
basis that the award is in conflict with justice or morality is now to be understood as a conflict with
the “most basic notions of morality or justice”. This again would be in line with paras 36 to 39 of
Associate Builders [Associate Builders v. DDA, (2015) 3 SCC 49 : (2015) 2 SCC (Civ) 204] , as it is
only such arbitral awards that shock the conscience of the court that can be set aside on this ground.
36. Thus, it is clear that public policy of India is now constricted to mean firstly, that a domestic
award is contrary to the fundamental policy of Indian law, as understood in paras 18 and 27 of
Associate Builders [Associate Builders v. DDA, (2015) 3 SCC 49: (2015) 2 SCC (Civ) 204], or
secondly, that such award is against basic notions of justice or morality as understood in paras 36 to
39 of Associate Builders [Associate Builders v. DDA, (2015) 3 SCC 49 : (2015) 2 SCC (Civ) 204] .
Explanation 2 to Section 34(2)(b)(ii) and Explanation 2 to Section 48(2)(b)(ii) was added by the
Amendment Act only so that Western Geco [ONGC v. Western Geco International Ltd., 25 | P a g e
(2014) 9 SCC 263 : (2014) 5 SCC (Civ) 12] ,as understood in Associate Builders [Associate Builders v.
DDA, (2015) 3 SCC 49 : (2015) 2 SCC (Civ) 204] , and paras 28 and 29 in particular, is now done
away with.
37. Insofar as domestic awards made in India are concerned, an additional ground is now available
under sub-section (2-A), added by the Amendment Act, 2015, to Section 34. Here, there must be
patent illegality appearing on the face of the award, which refers to such illegality as goes to the root
of the matter but which does not amount to mere erroneous application of the law. In short, what is
not subsumed within “the fundamental policy of Indian law”, namely, the contravention of a statute
not linked to public policy or public interest, cannot be brought in by the backdoor when it comes to
setting aside an award on the ground of patent illegality.
38. Secondly, it is also made clear that reappreciation of evidence, which is what an appellate court
is permitted to do, cannot be permitted under the ground of patent illegality appearing on the face of
the award.
39. To elucidate, para 42.1 of Associate Builders [Associate Builders v. DDA, (2015) 3 SCC 49 :
(2015) 2 SCC (Civ) 204] , namely, a mere contravention of the substantive law of India, by itself, is
no longer a ground available to set aside 26 | P a g e an arbitral award. Para 42.2 of Associate
Builders [Associate Builders v. DDA, (2015) 3 SCC 49 : (2015) 2 SCC (Civ) 204] , however, would
remain, for if an arbitrator gives no reasons for an award and contravenes Section 31(3) of the 1996
Act, that would certainly amount to a patent illegality on the face of the award.Delhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

40. The change made in Section 28(3) by the Amendment Act really follows what is stated in paras
42.3 to 45 in Associate Builders [Associate Builders v. DDA, (2015) 3 SCC 49 : (2015) 2 SCC (Civ)
204] , namely, that the construction of the terms of a contract is primarily for an arbitrator to
decide, unless the arbitrator construes the contract in a manner that no fair-minded or reasonable
person would; in short, that the arbitrator's view is not even a possible view to take. Also, if the
arbitrator wanders outside the contract and deals with matters not allotted to him, he commits an
error of jurisdiction. This ground of challenge will now fall within the new ground added under
Section 34(2-A).
41. What is important to note is that a decision which is perverse, as understood in paras 31 and 32
of Associate Builders [Associate Builders v. DDA, (2015) 3 SCC 49 : (2015) 2 SCC (Civ) 204] , while
no longer being a ground for challenge under “public policy of India”, would certainly amount to a
patent illegality appearing on the face of the 27 | P a g e award. Thus, a finding based on no evidence
at all or an award which ignores vital evidence in arriving at its decision would be perverse and
liable to be set aside on the ground of patent illegality. Additionally, a finding based on documents
taken behind the back of the parties by the arbitrator would also qualify as a decision based on no
evidence inasmuch as such decision is not based on evidence led by the parties, and therefore, would
also have to be characterised as perverse.”
24. This Court has in several other judgments interpreted Section 34 of the 1996 Act to stress on the
restraint to be shown by courts while examining the validity of the arbitral awards. The limited
grounds available to courts for annulment of arbitral awards are well known to legally trained
minds. However, the difficulty arises in applying the well-established principles for interference to
the facts of each case that come up before the courts. There is a disturbing tendency of courts setting
aside arbitral awards, after dissecting and reassessing factual aspects of the cases to come to a
conclusion that the award needs intervention and thereafter, dubbing the award to be vitiated by
either perversity or patent illegality, apart from the other grounds available for annulment of the
award. This approach would lead to corrosion of the object of the 1996 Act and the 28 | P a g e
endeavours made to preserve this object, which is minimal judicial interference with arbitral
awards. That apart, several judicial pronouncements of this Court would become a dead letter if
arbitral awards are set aside by categorising them as perverse or patently illegal without
appreciating the contours of the said expressions.
25. Patent illegality should be illegality which goes to the root of the matter. In other words, every
error of law committed by the Arbitral Tribunal would not fall within the expression ‘patent
illegality’. Likewise, erroneous application of law cannot be categorised as patent illegality. In
addition, contravention of law not linked to public policy or public interest is beyond the scope of
the expression ‘patent illegality’. What is prohibited is for courts to re-appreciate evidence to
conclude that the award suffers from patent illegality appearing on the face of the award, as courts
do not sit in appeal against the arbitral award. The permissible grounds for interference with a
domestic award under Section 34(2-A) on the ground of patent illegality is when the arbitrator takes
a view which is not even a possible one, or interprets a clause in the contract in such a manner which
no fair-minded or reasonable person would, or if the arbitrator commits an error of jurisdiction by
wandering outside the 29 | P a g e contract and dealing with matters not allotted to them. AnDelhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

arbitral award stating no reasons for its findings would make itself susceptible to challenge on this
account. The conclusions of the arbitrator which are based on no evidence or have been arrived at by
ignoring vital evidence are perverse and can be set aside on the ground of patent illegality. Also,
consideration of documents which are not supplied to the other party is a facet of perversity falling
within the expression ‘patent illegality’.
26. Section 34 (2) (b) refers to the other grounds on which a court can set aside an arbitral award. If
a dispute which is not capable of settlement by arbitration is the subject-matter of the award or if
the award is in conflict with public policy of India, the award is liable to be set aside. Explanation
(1), amended by the 2015 Amendment Act, clarified the expression ‘public policy of India’ and its
connotations for the purposes of reviewing arbitral awards. It has been made clear that an award
would be in conflict with public policy of India only when it is induced or affected by fraud or
corruption or is in violation of Section 75 or Section 81 of the 1996 Act, if it is in contravention with
the fundamental policy of Indian law or if it is in conflict with the most basic notions of morality or
justice. In Ssangyong (supra), this 30 | P a g e Court held that the meaning of the expression
‘fundamental policy of Indian law’ would be in accordance with the understanding of this Court in
Renusagar Power Co. Ltd. v. General Electric Co.6 In Renusagar (supra), this Court observed that
violation of the Foreign Exchange Regulation Act, 1973, a statute enacted for the ‘national economic
interest’, and disregarding the superior courts in India would be antithetical to the fundamental
policy of Indian law. Contravention of a statute not linked to public policy or public interest cannot
be a ground to set at naught an arbitral award as being discordant with the fundamental policy of
Indian law and neither can it be brought within the confines of ‘patent illegality’ as discussed above.
In other words, contravention of a statute only if it is linked to public policy or public interest is
cause for setting aside the award as being at odds with the fundamental policy of Indian law. If an
arbitral award shocks the conscience of the court, it can be set aside as being in conflict with the
most basic notions of justice. The ground of morality in this context has been interpreted by this
Court to encompass awards involving elements of sexual morality, such as prostitution, or awards 6
1994 Supp (1) SCC 644 31 | P a g e seeking to validate agreements which are not illegal but would
not be enforced given the prevailing mores of the day. 7
27. In light of the principles elucidated herein for interference with an arbitral award by a court in
exercise of its jurisdiction under Section 34 of the 1996 Act, we proceed to consider the questions
that arise in these Appeals as to whether the Division Bench of the High Court was right in setting
aside the award of the Arbitral Tribunal dated 11.05.2017.
Validity of the termination notice and consequences of the CMRS sanction
28. Mr. Harish Salve, learned Senior Counsel appearing for the Appellant (DAMEPL), submitted
that the High Court committed an error in setting aside the award of the Arbitral Tribunal by
deviating from the well-settled principles for interference under Sections 34 and 37 of the 1996 Act.
The findings recorded by the Arbitral Tribunal in relation to the existence of defects in the civil
structure and failure on the part of DMRC in curing those defects/not taking effective steps to cure
the defects are findings of fact which cannot be made subject to review by the court exercising its
jurisdiction under Section 34. He asserted that interpretation of the 7 Ssangyong (supra) 32 | P a g eDelhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

provisions of the Concession Agreement is within the domain of the Arbitral Tribunal and even if
such interpretation is not the most accurate interpretation in the opinion of the court, the award
cannot be set aside if the Arbitral Tribunal has taken a possible view. He contended that the
certificate issued by the CMRS, which was relied upon by DMRC, was considered by the Tribunal to
rightly conclude that the conditions imposed for restarting the AMEL showed that the defects were
not cured. He further submitted that the cure notice was issued on 09.07.2012 demanding the
rectification of defects within a period of 90 days from the date of the notice, as per the Concession
Agreement. After the expiry of 90 days, the termination notice dated 08.10.2012 had been issued.
He stated that there cannot be any doubt that the defects had to be cured within 90 days from the
date of the cure notice. He emphasized that the observations of the High Court as regards confusion
in the mind of the Arbitral Tribunal regarding the date of the termination notice are unfounded. The
relevant portions of the award were shown to the Court to argue that the Arbitral Tribunal was clear
in its mind that the defects had to be cured within 90 days from the date of cure notice dated
09.07.2012. On the defects not being cured within the 90-day period, the termination notice was 33
| P a g e issued on 08.10.2012, with the effective date of termination as 07.01.2013. The further
submission made on behalf of DAMEPL is that the subsequent successful operation of the AMEL for
nearly four years is not relevant for adjudication of the disputes between the parties by the Arbitral
Tribunal. Finally, according to Mr. Salve, the High Court committed a palpable error in setting aside
the award.
29. Mr. P.S. Narasimha and Mr. Parag Tripathi, learned Senior Counsel appearing for DMRC, on the
other hand, supported the judgment of the Division Bench of the High Court by arguing that the
award is contrary to public policy. Mr. Narasimha relied upon the Delhi Metro Act and the Rules
made thereunder to submit that the CMRS is the sole authority to determine the safety of the Metro
Railway and the certificate issued by the Commissioner on 18.01.2013 is conclusive proof of the fact
that the defects pointed out by DAMEPL had been rectified. It was contended on behalf of DMRC
that the period for curing the defects did not lapse on expiry of 90 days from the initial notice dated
09.07.2012 but extended for another 90 days from the termination notice dated 08.10.2012.
According to the Respondent, a serious error was committed by the Arbitral Tribunal in its
interpretation of Article 29.5.1 of the Concession Agreement.
34 | P a g e Abundant material placed by DMRC to show effective steps were taken to cure the
defects was not considered by the Arbitral Tribunal. The Commissioner in exercise of his powers
conferred by the Delhi Metro Act permitted the opening of the AMEL on 18.01.2013 after
considering all safety aspects and the AMEL has been in operation since then without any adverse
event. The subsequent smooth functioning of the AMEL is a relevant consideration which was
ignored by the Arbitral Tribunal. DAMEPL’s participation in several meetings that were conducted
which led to inspections and steps taken to address the defects as well as the AMEL being run by
DAMEPL from 22.01.2013 to 30.06.2013 would show that even DAMEPL was aware that effective
steps had been taken to cure the defects.
30. Termination by DAMEPL for DMRC Event of Default is dealt with in Article 29.5.1 which reads
as under: -Delhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

“29.5 Termination for DMRC Event of Default 29.5.1 The Concessionaire may after
giving 90 (ninety) days notice in writing to DMRC terminate this Agreement upon
the occurrence and continuation of any of the following events (each a "DMRC Event
of Default"), unless any such DMRC Event of Default has 35 | P a g e occurred as a
result of Concessionaire Event of Default or due to a Force Majeure Event.
(i) DMRC is in breach of this Agreement and such breach has a Material Adverse
Effect on the Concessionaire and DMRC has failed to cure such breach or take
effective steps for curing such breach within 90 (ninety) days of receipt of notice in
this behalf from the Concessionaire;
(ii) DMRC repudiates this Agreement or otherwise evidences an irrevocable intention
not to be bound by this Agreement;
(iii) GoI or GNCTD or any Governmental Agency have by an act of commission or
omission created circumstances that have a Material Adverse Effect on the
performance of its obligations by the Concessionaire and have failed to cure the same
within 90 (ninety) days of receipt of notice by DMRC in this behalf from the
Concessionaire;
(iv) DMRC has delayed any payment that has fallen due under this Agreement if such
delay exceeds 90 (ninety) days.” 36 | P a g e
31. By referring to certain paragraphs of the award, the Division Bench of the High Court held that
there was confusion in the mind of the Arbitral Tribunal relating to the actual date of termination,
which would have a material bearing on the exegesis of Article 29.5.1. The confusion around the date
of termination is highlighted by the High Court by referring to the award of the Arbitral Tribunal in
which it was held that the defects were not cured within the 90-day period from the date of the cure
notice dated 09.07.2012. However, in paragraphs 128, 130 and 131, the Arbitral Tribunal, while
considering the counter claim, referred to 07.01.2013 as the date of termination of the Concession
Agreement. It is clear from a careful examination of the award that the Arbitral Tribunal had in
precise terms held that the defects had to be cured within 90 days from the date of the cure notice
dated 09.07.2012. Further, the Arbitral Tribunal held that the termination notice dated 08.10.2012
was issued as defects were not cured. The Tribunal expressed its view that consequently, the
effective date of termination was 07.01.2013, which is 90 days from the termination notice. As there
is no ambiguity in the findings of the Arbitral Tribunal regarding the time given for curing the
defects and the effective date of termination of 37 | P a g e the Concession Agreement, we are not in
agreement with the findings of the Division Bench that there is an ambivalence in the award
concerning the date of termination, having a bearing on the final outcome of the award. The
ancillary issue that arises for consideration is whether the period for curing the defects is 180 days
or 90 days under Article 29.5.1 of the Concession Agreement. The Arbitral Tribunal in its award has
clearly held that DMRC failed to cure the defects before the expiry of 90 days from the initial notice
laying down the non-exhaustive list of defects issued on 09.07.2012. The said conclusion is the
outcome of interpretation of Article 29.5.1 of the Concession Agreement by the Tribunal. An attemptDelhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

was made by the learned Senior Counsel appearing for the Respondent to impress upon this Court
that as the termination notice would become effective only after 90 days from the date of its issue,
i.e., 08.10.2012, DMRC could avail this period as well to address the defects and if the defects stood
cured or effective steps were taken within this additional 90-day period, the termination notice
became defunct and should not be effectuated. Construction of a provision of the Concession
Agreement is within the domain of the Arbitral Tribunal. The view taken by the Arbitral Tribunal
that the defects have to be cured within 38 | P a g e 90 days from the date of the cure notice, failing
which DAMEPL is entitled to terminate the Concession Agreement, is a possible interpretation of
Article 29.5.1. We refuse to interfere with the findings of the Arbitral Tribunal on this point, even
assuming a different view can be taken on a reading of the said Article.
32. The High Court was of the view that the Tribunal committed a grave error in ignoring the CMRS
certificate, as the Tribunal lost sight of the binding nature of the certificate. According to the
Division Bench, the Arbitral Tribunal went wrong in considering the issue of the CMRS certificate as
a separate issue, distinct from the questions pertaining to the termination of the Concession
Agreement. The Delhi Metro Act was promulgated for the operation, maintenance and regulation of
the working of the metro railway in the National Capital Region, metropolitan city and metropolitan
area. The Commissioner of Metro Railway Safety, appointed under Section 7 of the said Act, has the
duty to inspect the metro railway with a view to determine whether it is fit to be opened for the
public carriage of passengers and report thereon to the Central Government as required thereunder.
Section 15 of the Delhi Metro Act provides that before granting sanction to the opening of the metro
railway by the 39 | P a g e Central Government under Section 14, a report has to be obtained from
the Commissioner certifying fitness of the metro railway so as not to be of any danger to the public.
Rule 11 of the Opening of Delhi Metro Railway for Public Carriage of Passengers Rules, 2002
imposes a duty on the Commissioner to inquire into all relevant matters concerning safety before
coming to a conclusion that the metro railway should be opened. Sanction to open the metro railway
line for public carriage of passengers is granted by the Central Government after considering the
report of the Commissioner on the fitness and safety aspects. The contention on behalf of DMRC is
that the certificate issued by the Commissioner is binding on the Arbitral Tribunal and the Tribunal
could not have taken a different view. In addition thereto, the certificate is conclusive of the fact that
there were no defects in the civil structure, as otherwise, the Commissioner would not have
permitted the AMEL to be opened. On the basis of the certificate issued by the Commissioner, the
Respondent has argued that all defects pointed out by DAMEPL had been cured. In any event,
effective steps had been taken to cure the defects by periodical meetings and inspections being held.
40 | P a g e
33. The Arbitral Tribunal was called upon by the parties to decide whether there was a breach of the
Concession Agreement due to the fault of DMRC and whether the defects pointed out by DAMEPL
were cured within the period specified in the notice dated 09.07.2012. Safety of the AMEL was not
an issue that fell for determination by the Arbitral Tribunal, though DAMEPL had insisted on not
continuing operations of the Line citing safety concerns arising from the defects in its structural
integrity. It is no doubt true that the Commissioner is the competent authority to determine the
safety of the AMEL. It is also beyond cavil that the Commissioner would not have grantedDelhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

permission to restart the AMEL unless it was of the opinion that restarting of commercial
operations would not pose a danger to the public. However, the certificate by itself cannot come to
the rescue of DMRC to show that the defects pointed out by DAMEPL were cured within the expiry
of 90 days from 09.07.2012. The finding of the Arbitral Tribunal that the defects were not cured is
one of fact which cannot be interfered with by the court.
34. The CMRS certificate dated 18.01.2013 was relied upon by DMRC before the Arbitral Tribunal as
a strong piece of evidence to support its case that the defects were cured.
41 | P a g e DMRC did not contend before the Tribunal that the CMRS certificate is binding and is
conclusive of the defects being cured/effective steps taken to cure the defects. The conditions
imposed by the Commissioner relating to speed restrictions and close monitoring of the Line,
according to the Tribunal, support the contention of DAMEPL that the defects were not fully cured.
The issue before the Tribunal was whether the defects were cured within 90 days from the notice
dated 09.07.2012 and the certificate dated 18.01.2013 is relevant for deciding the said issue. We are
not in agreement with the High Court’s view that the issue of the CMRS certificate being dealt with
separately has a bearing on the Tribunal’s determination of the validity of the termination notice.
The members of the Arbitral Tribunal, nominated in accordance with the agreed procedure between
the parties, are engineers and their award is not meant to be scrutinised in the same manner as one
prepared by legally trained minds. In any event, it cannot be said that the view of the Tribunal is
perverse. Therefore, we do not concur with the High Court’s opinion that the award of the Tribunal
on the legality of the termination notice is vitiated due to the vice of perversity.
42 | P a g e
35. The Division Bench referred to various factors leading to the termination notice, to conclude that
the award shocks the conscience of the court. The discussion in paragraph 97 of the impugned
judgement amounts to appreciation or re- appreciation of the facts which is not permissible under
Section 34 of the 1996 Act. The Division Bench further held that the fact of the AMEL being
operated without any adverse event for a period of more than four years since the date of issuance of
the CMRS certificate, was not given due importance by the Arbitral Tribunal. As the arbitrator is the
sole judge of the quality as well as the quantity of the evidence, the task of being a judge on the
evidence before the Tribunal does not fall upon the court in exercise of its jurisdiction under Section
34.8 On the basis of the issues submitted by the parties, the Arbitral Tribunal framed issues for
consideration and answered the said issues. Subsequent events need not be taken into account.
36. For the aforementioned reasons, the conclusion of the Division Bench that the award of the
Arbitral Tribunal suffers from patent illegality and shocks the conscience of the court is held to be
erroneous.
Adjusted Equity 8 State of Rajasthan v. Puri Construction Co. Ltd. and Another (1994) 6 SCC 43 | P
a g eDelhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

37. Article 29.5.2 of the Concession Agreement which deals with Termination Payment is as
follows:-
“29.5.2 Upon termination by the Concessionaire on account of DMRC Event of
Default, DMRC shall pay to the Concessionaire, by way of Termination Payment, an
amount equal to
a) Debt Due;
b) 130 % of the Adjusted Equity;
c) Depreciated Value of the Project Assets, if any, acquired and installed on the
Project after the 10 th anniversary of the COD.”
38. It is relevant to note the definitions of ‘Adjusted Equity’, ‘Concessionaire’s Capital Costs’, ‘Debt
Due’, ‘Equity’, and ‘Subordinate debt’ as provided in the Concession Agreement, which read as
follows: -
“Adjusted Equity” means the Equity funded in Indian Rupees and adjusted on the
first day of the current month (the “Reference Date”), in the manner set forth below,
to reflect the change in its value on account of depreciation and variations in WPI,
and for any Reference Date occurring:
a) on or before COD, the Adjusted Equity shall be a sum equal to the Equity funded in
Indian Rupees and expended on the Project, revised to the extent of one half of the
variation in WPI occurring between the first day of the month of Appointed Date and
the Reference Date;
44 | P a g e
b) from COD and until the 4th (fourth) anniversary thereof, an amount equal to the
Adjusted Equity as on COD shall be deemed to be the base (the “Base Adjusted
Equity”) and the Adjusted Equity hereunder shall be a sum equal to the Base
Adjusted Equity, revised at the commencement of each month following COD to the
extent of variation in WPI occurring between COD and the Reference Date;
c) after the 4th (fourth) anniversary of COD, the Adjusted Equity hereunder shall be a sum equal to
the Base Adjusted Equity, reduced by 0.42% (zero point four two per cent) (This number shall be
substituted in each case by the product of 100 divided by the number of months comprising the
Concession Period. For example, the figure for a 20 year Concession Period shall be 100/240 =
0.416 rounded off to decimal points i.e. 0.42) thereof at the commencement of each month following
the 4th (fourth) anniversary of the Project Completion Date and the amount so arrived at shall be
revised to the extent of variation in WPI occurring between COD and the Reference Date; and the
aforesaid shall apply, mutatis mutandis, to the Equity funded in Indian Rupees. For the avoidance ofDelhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

doubt, the Adjusted Equity shall, in the event of Termination, be computed as on the Reference Date
immediately preceding the Termination Date; provided that no reduction in the Base Adjusted
Equity shall be made for a period equal to the duration, if any, for which the Concession Period is
extended, but the revision on account of WPI shall continue to be made.” 45 | P a g e
“Concessionaire’s Capital Costs” means following:
• Prior to COD, the cost of the Concessionaire’s Works as set forth in the Financing
Documents plus any further additional capital cost for any Change of Scope
instructed since the finalisation of the Financing Documents; and • After COD, the
actual capital cost of the Concessionaire’s Works upon Project Completion as
certified by the Statutory Auditors.” “Debt Due” means the aggregate of the following
sums expressed in Indian Rupees outstanding on the Transfer Date:
a) the principal amount of the debt provided by the Senior Lenders under the
Financing Agreements for financing the Total Project Cost (the “principal”) but
excluding any part of the principal that had fallen due for repayment two years prior
to the Termination Date;
b) all accrued interest, financing fees and charges payable under the Financing
Agreements on, or in respect of, the debt referred to in Sub-clause (a) above until the
Transfer Date but excluding (i) any interest, fees or charges that had fallen due one
year prior to the Transfer Date, (ii) any penal interest or charges payable under the
Financing Agreements to any Senior Lender, and (iii) any pre-payment chares in
relation to accelerated repayment of debt except where such charges have arisen due
to Authority Default; and
46 | P a g e
c) any Subordinated Debt which is included in the Financial Package and disbursed by lenders for
financing the Total Project Cost.” “Equity” means the sum expressed in Indian Rupees representing
the equity share capital of the Concessionaire and shall include the funds advanced by any Member
of the Consortium or by any of its shareholders to the Concessionaire for meeting the equity
component of the Concessionaire’s Capital Costs.” “Subordinated Debt” means the aggregate of the
following sums expressed in Indian Rupees or in the currency of debt, as the case may be,
outstanding as on the date of termination:
a) the principal amount of debt provided by lenders or the Concessionaire for
meeting the Concessionaire’s Capital Cost and subordinated to the financial
assistance provided by the Senior Lenders; and
b) all accrued interest on the debt referred to in Sub-
clause (a) above but restricted to the lesser of actual interest rate and a rate equal to 5% (five per
cent) above the Bank Rate in case of loans expressed in Indian Rupees and lesser of the actualDelhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

interest rate and six-month LIBOR (London Inter Bank Offer Rate) plus 2% (two per cent) in case of
loans expressed in foreign currency, but does not include any interest that had fallen due one year
prior to the Termination Date;
47 | P a g e provided that if all or any part of the Subordinated Debt is convertible into Equity at the
option of the lenders and/ or the Concessionaire, it shall for the purposes of this Agreement be
deemed to be Subordinated Debt even after such conversion and the principal thereof shall be dealt
with as if such conversion had not been undertaken.”
39. The Tribunal focused on two components of Termination Payment, which are (i) ‘Debt Due’, and
(ii) 130 % of the ‘Adjusted Equity’. According to the Appellant, the Division Bench committed an
error in concluding that the expression ‘Adjusted Equity’ in the Concession Agreement should be
calculated by taking into account only the share capital of DAMEPL. The Appellant contended that
the Tribunal had rightly held that the expression ‘Adjusted Equity’ should include the money
brought in by DAMEPL’s promoter and had fairly concluded that the amount of Rs.611.95 crore was
used as expenses, thereby qualifying as ‘Concessionaire’s Capital Costs’ under the Concession
Agreement. The Tribunal was correct in holding that the amount of Rs.611.95 crore advanced by
DAMEPL’s promoter would qualify for inclusion under the definition of ‘Equity’ on a plain reading
of the said definition. Construction of the contract is within the jurisdiction of the Tribunal and
merely because another view 48 | P a g e is possible, the court cannot interfere with such
construction and substitute its own view.
40. On the other hand, it was contended by DMRC that the amount of Rs.611.95 crore was recorded
as ‘share application money’ in the balance sheet of DAMEPL as on 31.03.2010. However, the said
amount was shown as subordinated debt in the balance sheet as on 31.03.2011. The Respondent
referred to the resolution passed by the board of directors of DAMEPL on 16.03.2011, in which a
decision was taken to convert the share application money into subordinated debt. DMRC urged
that the conversion of the share application money as subordinated debt was a calculated move on
the part of DAMEPL. If the share application money had been allowed to retain the nature of equity,
DAMEPL would have lost the entire amount in the event of termination of the Concession
Agreement by DMRC for Concessionaire Event of Default in terms of Article 29.1.1. After electing to
convert the share application money into subordinated debt, DAMEPL should not be permitted to
claim that for the purposes of computation of ‘Adjusted Equity’, the said amount be treated as
‘Equity’. It was further argued on behalf of the Respondent that no material was produced by
DAMEPL to show that the amount of Rs. 611.95 crore was 49 | P a g e actually used for
‘Concessionaire’s Capital Costs’. Reference was also made to the testimony of one of the witnesses
produced by DAMEPL to contend that the amount of Rs.611.95 crore cannot be treated as equity in
accordance with the provisions of the Companies Act, 2013. DMRC contended that the High Court
aptly set aside the findings recorded by the Tribunal in respect of computation of ‘Adjusted Equity’.
41. We do not intend to re-examine the entire material on record for the purpose of deciding
whether the High Court was right in reversing the conclusion of the Tribunal in relation to
computation of the amount under Article 29.5.2 of the Concession Agreement. The opinion of the
Tribunal is that the amount of Rs.611.95 crore was an amount advanced by DAMEPL’s promoterDelhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

which was not disputed by DMRC. The contention advanced by DMRC, that it was only the equity
share capital as is understood within the meaning of the Companies Act, 2013 which is liable to be
paid by DMRC under Article 29.5.2, was rejected by the Tribunal. The view taken by the Tribunal
that the amount contributed by a member of the consortium or by shareholders to meet the
‘Concessionaire’s Capital Costs’ in any form, including where such funds are classified as
subordinated debt, cannot be 50 | P a g e treated as ‘Subordinated Debt’ in terms of its definition in
the Concession Agreement, is a reasonable and possible view. On the other hand, the Division Bench
of the High Court relied upon the board resolution dated 16.03.2011 and held that the Tribunal
ought not to have treated the said amount as ‘Equity’ after the share application money was
converted into subordinated debt. After a detailed consideration of the relevant clauses of the
Concession Agreement, the High Court held that the Tribunal had committed a serious error in its
tabulation of ‘Adjusted Equity’ by completely ignoring the evidence on record.
42. Even assuming the view taken by the High Court is not incorrect, we are afraid that a possible
view expressed by the Tribunal on construction of the terms of the Concession Agreement cannot be
substituted by the High Court. This view is in line with the understanding of Section 28(3) of the
1996 Act as a ground for setting aside the arbitral award, as held in Associate Builders (supra) and
thereafter upheld in Ssangyong (supra). No case has been made out by the High Court to establish
violation of Section 28(3). Having carefully examined the Concession Agreement, the findings
recorded by the Tribunal and the findings recorded by the Division Bench, we are not in a position
to hold that the opinion of the 51 | P a g e Tribunal on inclusion of Rs.611.95 crore under ‘Equity’ is a
perverse view. It cannot be said that the Tribunal did not consider the evidence on record, especially
the resolution dated 16.03.2011 passed by DAMEPL’s board of directors. We also do not find fault
with the approach of the Tribunal that the understanding of the term equity as per the Companies
Act, 2013 is not relevant for the purposes of determining ‘Adjusted Equity’ in light of the express
definition of the term in the Concession Agreement. As has been held in Ssangyong (supra), mere
contravention of substantive law as elucidated in Associate Builders (supra) is no longer a ground
available to set aside an arbitral award. The support placed by the Division Bench on the
interpretation of Section 28(1)(a) of the 1996 Act as adopted in Associate Builders (supra) is,
therefore, no longer good law. In view of the foregoing, we set aside the findings of the High Court
and uphold the award by the Tribunal in respect of the computation of Termination Payment under
Clause 29.5.2.
Grounds of challenge in SLP (C) No. 8311 of 2019 filed by DMRC
43. One of the legal issues considered by the Tribunal is whether DAMEPL waived their rights to
terminate after 52 | P a g e participating in the reconciliation process and after operating the AMEL
for more than five months from 22.01.2013 to 30.06.2013. As the participation of DAMEPL in
several meetings held after issuance of the termination notice dated 09.07.2012 and its decision to
continue operating the AMEL was without prejudice, the Tribunal rejected the submission of DMRC
that the doctrine of waiver applied and that DAMEPL was estopped from terminating the
Concession Agreement after having actively participated in the process of rectifying the defects
pointed out. The Division Bench of the High Court approved the said finding on the ground that the
decision of the Tribunal could not be held to be flawed within the limited scrutiny afforded to courtsDelhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

under Section 34 of the 1996 Act. In our view, the Division Bench of the High Court rightly refrained
from interfering with the findings on waiver by the Tribunal.
44. The prayer for a direction to DAMEPL for specific performance of its obligations under the
Concession Agreement to operate the AMEL was refused by the Tribunal. The Division Bench of the
High Court in its judgment observed that the said findings had not been challenged before the High
Court. Therefore, there is no reason for this 53 | P a g e Court to adjudicate on the point of specific
performance of the Concession Agreement.
45. The Tribunal awarded interest in accordance with the terms of the Concession Agreement on
termination payment. DMRC contended before the High Court that the award in respect of interest
had to be set aside on the ground that it would result in unjust enrichment. After a thorough
consideration of Article 29.8 and Article 36.2.6.1 of the Concession Agreement, the High Court has
rightly refused to interfere with the findings by the Tribunal relating to interest and we see no cause
for interference.
46. For the aforementioned reasons, the Appeal filed by DAMEPL is allowed and the judgment of
the Division Bench of the High Court is set aside. The Appeal arising out of SLP(C) No. 8311 of 2019
filed by DMRC is dismissed.
.....................................J. [ L. NAGESWARA RAO ] .....................................J. [ S. RAVINDRA BHAT ]
New Delhi, September 09, 2021.
54 | P a g eDelhi Airport Metro Express Pvt. Ltd. vs Delhi Metro Rail Corporation Ltd. on 9 September, 2021

