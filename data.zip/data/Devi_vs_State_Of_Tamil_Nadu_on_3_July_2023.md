Devi vs State Of Tamil Nadu on 3 July, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                                    H.C.P.No.375 of 2023
                                      IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                    DATED : 03.07.2023
                                                          CORAM
                                        THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                        and
                                       THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                   H.C.P.No.375 of 2023
                     Devi                                                      ..          Petitioner
                                                            Vs.
                     1.State of Tamil nadu
                       Rep by The Secretary,
                       Home, Prohibition & Excise Department,
                       Fort.St.George, Chennai-600 009.
                     2.The Commissioner of Police,
                       Greater Chennai Police Commissioner,
                       The Commissioner office
                       Vepery, Chennai – 07.
                     3.The Superintendent of Police,
                       Central Prison, Puzhal, Chennai – 66.
                     4.The Inspector of Police,
                       P5 M.K.B. Nagar Police Station,
                       Chennai.                                           ..          Respondents
                                  Petition filed under Article 226 of the Constitution of India
                     praying for issuance of a writ of habeas corpus calling for the records
                     relating to the detention order in Memo No.461/BCDFGISSSV/2022
                     dated 12.12.2022 passed by the 2nd respondent under the Tamil Nadu
                     Act 14 of 1982 and set aside the same and direct the respondents to
                     Page Nos.1/9Devi vs State Of Tamil Nadu on 3 July, 2023

https://www.mhc.tn.gov.in/judis
                                                                                          H.C.P.No.375 of 2023
                     produce the petitioner's son Vasudevan, s/o. Raja, the detenu, now
                     confined in Central Prison, Puzhal, Chennai before this Court and set
                     the petitioner's son Vasudevan, s/o. Raja, aged 21 years the detenu
                     herein at liberty.
                                  For Petitioner           :      Mr.N.Naresh
                                  For Respondents          :      Mr.E.Raj Thilak
                                                                  Additional Public Prosecutor
                                                          ORDER
[Order of the Court was made by M.SUNDAR, J.,] When the captioned 'Habeas Corpus Petition'
(hereinafter 'HCP' for the sake of convenience and clarity) was listed in the Admission Board on
15.03.2023, this Court made the following order:
'Captioned Habeas Corpus Petition has been filed in this Court on 06.03.2023 inter
alia assailing a detention order dated 12.12.2022 bearing reference
No.46/BCDFGI|SSSV/2023 made by 'second respondent' [hereinafter 'Detaining
Authority' for the sake of convenience and clarity]. To be noted, fourth respondent is
the Sponsoring Authority.
2. To be noted, mother of the detenu is the petitioner.
3. Mr.N.Naresh, learned counsel on record for habeas corpus petitioner is before us. Learned
counsel for petitioner submits that ground case qua the detenu is for alleged offences under Sections
341, 294(b), 323, 397 and 506(ii) of 'Indian Penal Code, 1860 (Act 45 of 1860)' ['IPC' for brevity] in
Crime No.837 of 2022 on the file of P-5, M.K.B.Nagar Police Station.
https://www.mhc.tn.gov.in/judis
4. The aforementioned detention order has been made on the premise that the detenu is a 'Goonda'
under Section 2(f) of 'The Tamil Nadu Prevention of Dangerous Activities of Bootleggers, Cyber law
offenders, Drug-offenders, Forest-offenders, Goondas, Immoral traffic offenders, Sand-offenders,
Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)'
[hereinafter 'Act 14 of 1982' for the sake of convenience and clarity].
5. The detention order has been assailed inter alia on the ground that remand order was not
properly translated in Tamil, which prevented the detenu from making an effective representation.
6. Prima facie case made out for admission. Admit. Issue Rule nisi returnable by four weeks.Devi vs State Of Tamil Nadu on 3 July, 2023

7. Mr.R.Muniyapparaj, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice for
all respondents.
List the captioned Habeas Corpus Petition accordingly.'
2. The aforementioned order made in the 15.03.2023 Admission listing shall be read as an integral
part and parcel of this order which means that the short forms, short references and abbreviations
used in the order in the Admission listing shall be used in the instant order also.
3. There are seven adverse cases. The ground case which constitutes substantial part of substratum
of the impugned preventive detention order is Crime No.837 of 2022 on the file of P5 M.K.B.
https://www.mhc.tn.gov.in/judis Nagar Police Station for alleged offences under Sections 341,
294(b), 323, 397 and 506(ii) of IPC. Owing to the nature of the challenge to the impugned detention
order, it is not necessary to delve into the factual matrix or be detained further by facts.
4. Mr.N.Naresh, learned counsel on record for petitioner and Mr.E.Raj Thilak, learned State
Additional Public Prosecutor for all respondents are before us.
5. In the Admission Board, the point that the remand order was not properly translated in Tamil
point was projected. In the final hearing today, learned counsel for petitioner pivoted his campaign
against the impugned detention order on the incorrect/improper translation point. The remand
order dated 27.11.2022 pertaining to ground case at page No.205 of the grounds booklet says
'Section 41 Cr.P.C. complied with' whereas in the Tamil translation at page No.206 of the grounds
booklet, there is no mention about the same. The remand order in English and Tamil read as
follows:
'English Version:
https://www.mhc.tn.gov.in/judis Marginally noted accused produced before me at
05.00 p.m. on 27.11.2022 at my residence. Grounds of arrest explained to accused.
No complaint against police. Reason stated in remand report satisfied. U/S 41 Cr.P.C.
Complied with. Free legal aid explained. Remanded to judicial custody till
09.12.2022.' 'Tamil Version:
                                        vjphp       ,d;W     khiy         05/00      kzpastpy;           vdJ
                                  trpg;gplj;jpy;    M$h;   bra;ag;gl;lhh;/    ifJf;fhd          fhuz';f;s
                                  tpthpf;fg;gl;lJ/      fhty;      JiwapdUf;F               vjpuhf       g[fhh;
                                  VJkpy;iy/          ifJ         mwpf;ifapy;          Vw;Wf;bfhs;sg;gl;l
                                  fhuz';fs;        jPtpukhdit/    ,ytr        rl;l       cjtp       fpilf;Fk;
                                  vd;gJ    Fwpj;J      tpthpf;fg;gl;lJ/      vjphpia      09/12/2022     tiu
ePjpkd;wf; fhtypy; milg;gjw;F Mizaplg;gLfpwJ/'
6. We are informed that the literacy level of the detenu is 11th standard and he is a school drop out.
We are also informed that the detenu is conversant only with Tamil.Devi vs State Of Tamil Nadu on 3 July, 2023

7. In this view of the matter, we find that flaw in the translation is very serious and it certainly
affects the rights of the detenu to make an effective representation which are rights and
constitutional https://www.mhc.tn.gov.in/judis safeguard enshrined in Article 22(5) of the
Constitution of India. We remind ourselves of Powanammal case which also on facts arose out of the
preventive detention case. In Powanammal case in similar circumstances i.e., similar fact situation,
Honourable Supreme Court addressed to itself the issue of providing a detenu with translated copies
in a language in which the detenu is conversant with and answered the same interalia by saying that
it is imperative and not providing translated copy in a language which the detenu is conversant with
vitiates preventive detention. Powanammal case i.e., Powanammal Vs. State of Tamil Nadu is
reported in (1999) 2 SCC 413 and the relevant paragraphs wherein the question which the
Honourable Supreme Court addressed to itself and the manner in which the question was answered
are paragraphs 6 and 16 which read as follows:
'6. The short question that falls for our consideration is whether failure to supply the
Tamil version of the order of remand passed in English, a language not known to the
detenue, would vitiate her further detention.
16. For the above reasons, in our view, the non-supply of the Tamil version of the
English document, on the facts and in the circumstances, renders her continued
detention https://www.mhc.tn.gov.in/judis illegal. We, therefore, direct that the
detenue be set free forthwith unless she is required to be detained in any other case.
The appeal is accordingly allowed. '
8. Applying Powanammal principle, we have no hesitation in saying that the
impugned detention order in the case on hand deserves to be dislodged.
9. Apropos, the sequitur is, captioned HCP is allowed. Impugned detention order
dated 12.12.2022 bearing reference Memo.No.461/BCDFGISSSV/2022 made by the
second respondent is set aside and the detenu Thiru.Vasudevan, aged 21 years, son of
Thiru.Raja, is directed to be set at liberty forthwith, if not required in connection with
any other case / cases. There shall be no order as to costs.
                                                                      (M.S.,J.)        (R.S.V.,J.)
                                                                            03.07.2023
                     Index : Yes
                     Neutral Citation : Yes
                     mmi
P.S.: Registry to forthwith communicate this order to Jail authorities in Central
Prison,Puzhal, Chennai.
https://www.mhc.tn.gov.in/judis ToDevi vs State Of Tamil Nadu on 3 July, 2023

1.The Secretary to Government, Home, Prohibition & Excise Department, Fort.St.George,
Chennai-600 009.
2.The Commissioner of Police, Greater Chennai Police Commissioner, The Commissioner office
Vepery, Chennai – 07.
3.The Superintendent of Police, Central Prison, Puzhal, Chennai – 66.
4.The Inspector of Police, P5 M.K.B. Nagar Police Station, Chennai.
5.The Public Prosecutor, High Court, Madras.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL, J., mmi 03.07.2023
https://www.mhc.tn.gov.in/judisDevi vs State Of Tamil Nadu on 3 July, 2023

