Apoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March,
2024
Author: Pamidighantam Sri Narasimha
Bench: Pamidighantam Sri Narasimha, A.S. Bopanna
2024 INSC 223                                                            REPORTABLE
                                    IN THE SUPREME COURT OF INDIA
                                   CRIMINAL APPELLATE JURISDICTION
                               CRIMINAL APPEAL NO(S).               /2024
                            (ARISING OUT OF SLP (CRL.) NO(S). 5463-5464/2023
             APOORVA ARORA & ANR. ETC.                                 …. APPELLANT(S)
                                                    VERSUS
             STATE (GOVT. OF NCT OF DELHI) & ANR.                    …RESPONDENT(S)
                                                      WITH
                                     CRIMINAL APPEAL NO(S).             /2024
                                     (Arising out of SLP (Crl.) No. 6786/2023
                                     CRIMINAL APPEAL NO(S).             /2024
                                     (Arising out of SLP (Crl.) No. 5532/2023
                                    CRIMINAL APPEAL NO(S).             /2024
                                 (Arising out of SLP (Crl.) No. 8385-8387/2023
                                                JUDGMENT
PAMIDIGHANTAM SRI NARASIMHA, J.
1. Leave granted.
2. The appellants/accused are the actors, casting director, script writers, creator of the web-series
‘College Romance’1, and the media company that owns the YouTube channel on which the TVF
Media Labs Private Ltd.
web-series was hosted2. They are sought to be investigated and prosecuted for production,
transmission, and online publication of obscene and sexually-explicit material under Sections 67
and 67A of the Information Technology Act, 20003. The appellants’ petition under Section 482 ofApoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

the Code of Criminal Procedure, 19734 for quashing the orders of the Additional Chief Metropolitan
Magistrate and Additional Sessions Judge directing registration of FIR against them was dismissed
by the High Court by the order impugned before us.5 Having considered the matter in detail and for
the reasons to follow, we have allowed the appeal, set aside the judgment of the High Court, and
quashed the FIR bearing number 403/2023 dated 16.04.2023 at PS Mukherjee Nagar, Delhi against
the appellants under Sections 67 and 67A of the IT Act.
3. Facts: The short facts leading to filing of the present appeal are as follows:
3.1 A complaint was filed by respondent no. 2 before the Assistant Commissioner of
Police that Season 1, Episode 5 of the web-series, titled ‘Happily F****d Up’, has
vulgar and obscene language in its title and various portions of the Contagious Online
Media Network Pvt Ltd.
‘IT Act’ hereinafter.
‘CrPC’ hereinafter.
In Criminal Miscellaneous Case No. 2399 of 2020, Criminal Miscellaneous Case No. 2215 of 2020
and Criminal Miscellaneous Case No. 2214 of 2020, judgment dated 06.03.2023 (‘Impugned
judgment’ hereinafter). episode, constituting an offence under Sections 292, 294 and 509 of the
Indian Penal Code6, Sections 67 and 67A of the IT Act, and Sections 2(c) and 3 of the Indecent
Representation of Women (Prohibition) Act, 19867. On 13.03.2019, the complainant filed an
application under Section 200 read with Section 156(3) of the CrPC before the ACMM seeking
registration of FIR. The Investigating Officer conducted an enquiry and filed an Action Taken
Report on 09.04.2019 stating that no cognisable offence is made out and in fact, there is no
obscenity in the allegedly offending content.
3.2 However, the ACMM, by order dated 17.09.2019, allowed the complainant’s application and
directed the registration of an FIR against the appellants under Sections 292 and 294 of the IPC and
Sections 67 and 67A of the IT Act as the vulgar language used is prima facie capable of appealing to
prurient interests of the audience and is hence obscene.
3.3 The appellants filed a revision petition before the Additional Sessions Judge, who by order dated
10.11.2020 ‘IPC’ hereinafter.
‘IRWP Act’ hereinafter.
partially modified the order of the ACMM and directed the registration of FIR only under Sections
67 and 67A of the IT Act by relying on the decision of this Court in Sharat Babu Digumarti v.
Government (NCT of Delhi)8. 3.4 The appellants then filed a petition under Section 482 CrPC
before the High Court for quashing the above- mentioned orders, which came to be dismissed by the
judgment dated 06.03.2023, impugned herein. Against the dismissal and the consequent direction
to register FIR under Sections 67 and 67A of the IT Act, the present appeals are filed by all theApoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

accused/appellants. 3.5 Pursuant to the directions of the High Court, an FIR was registered under
Sections 67 and 67A of the IT Act against the appellants on 16.04.2023.
4. Reasoning of the High Court: The High Court, while dismissing the petition for quashing, held
that the object of Sections 67 and 67A of the IT Act is to punish the publication and transmission of
obscene and sexually explicit material in the cyber space. It relied on the ‘community standard test’
to determine whether the material is obscene, as laid down by this Court in (2017) 2 SCC 18, 2016
INSC 1131.
Aveek Sarkar v. State of West Bengal 9 and followed in decisions of various High Courts10. By
applying this test, the High Court held as follows: First, applying the standard of a common prudent
man, it found that the episode did not use civil language and there was excessive use of profanities
and vulgar expletives, and a clear description and reference to sexually explicit acts. The
determination of how the content impacts a common man must be determined in the Indian
context, as per Indian morality, keeping in mind contemporary standards of civility and morality.11
In the allegedly offending portion (in Season 1, episode 5 from 5:24 to 6:40 minutes and 25:28 to
25:46 minutes), the male protagonist in a conversation with the female protagonist uses terms
describing male and female genitalia and sexual acts, thereby making them sexually explicit and
arousing prurient feelings. While the female protagonist is heard objecting to the language and
expressing disgust over it, she does so by repeating the same to the male protagonist. The male
protagonist then uses more vulgar expletives and indecent language, which is repeated by the (2014)
4 SCC 257, 2014 INSC 75.
G. Venkateswara Rao v. State of AP in Writ Petition 1420 of 2020; Jaykumar Bhagwanrao Gore v.
State of Maharashtra 2017 SCC OnLine Bom 7283; Pramod Anand Dhumal v. State of Maharashtra
2021 SCC OnLine Bom 34; Ekta Kapoor v. State of MP 2020 SCC OnLine MP 4581, as cited in paras
23-26 of the impugned judgment.
In para 37 of the impugned judgment, the High Court relied on Samaresh Bose v. Amal Mitra (1985)
4 SCC 289, 1985 INSC 205 where it was held that the regard must be given to contemporary morals
and national standards in judging whether content is obscene. female protagonist in a later part of
the episode. The High Court held that the depiction of a sexually explicit act is not necessarily
through filming but can also be through spoken language. It was found that the persons who are
likely to be affected or persons whom such content can deprave or corrupt are impressionable minds
in the present case, as there is no disclaimer or warning that classifies the web-series as being
suitable only for persons who are 18 years or above. The content crossed the threshold of decency
considering its availability to the public, including children. Further, the Court felt that the episode
could not be heard in the courtroom without shocking or alarming the people and to maintain the
decorum of language.
5. Second, a representation that the language used in the episode is the one used in the country and
by its youth in educational institutions is not protected under the guarantee of freedom of speech
under Article 19(1)(a). Third, that the online content curator and the intermediaries are in violation
of the Information Technology (Intermediary Guidelines and Digital Media Ethics Code) Rules,Apoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

2021 as the content has not been correctly classified as ‘A-rated’ and there is no warning regarding
the use of profanities and expletives. Lastly, the Court took note that vulgar language, profanities,
and swear words must be regulated in the public domain and on social media platforms as they are a
threat to impressionable minds like children of tender age. Further, a representation that the use of
such language in general parlance is the “new normal” is a distortion of facts as it is still not spoken
in the presence of the elderly, women and children, or at religious places. To maintain linguistic
morality, the sanctity and reverence of languages must be protected.
6. The High Court also rejected the appellants’ contention that the mandatory procedure under
Section 154(3) of the CrPC, which is an important procedural safeguard, was not followed before
resort to Section 156(3). The High Court preliminarily negatived this submission by holding that
Section 154(3) only uses the term “may” and not “shall”, and that the complainant anyways
approached the ACP, Cyber Cell, North District, who is the authority higher to the SHO.
7. Submissions of the Appellants: We heard Mr. Mukul Rohatgi, Mr. Harish Salve, Ms. Madhavi
Divan, Mr. Sajan Poovayya, Sr. Advocates. Learned senior counsels for the appellants have argued
that the allegedly offending portions of Season 1, Episode 5 of the web-series do not meet the
threshold for obscenity and that the High Court has erred in characterising the material as obscene.
Further, these portions do not contain any sexually explicit act and as such no offence under
Sections 67 or 67A of the IT Act is made out. Elaborating their submissions, the appellants’ argued:
7.1 Section 67 of the IT Act, that criminalises the publication and transmission of
obscene material in electronic form, covers material which is lascivious or appeals to
the prurient interest or if its effect is such as to tend to deprave and corrupt persons
who are likely, having regard to all relevant circumstances, to read, see or hear the
matter contained or embodied in it. As per Aveek Sarkar (supra), the determination
of whether some material is obscene must be made by the ‘community standard test’
by considering the work as a whole and then looking at the specific material that has
been alleged to be obscene in the context of the whole work. The web-series is a
romantic comedy that traces the life of a group of friends who are in college. Its
intention is to paint a relatable picture of college life in a cosmopolitan urban setting.
There are two specific portions that have been alleged to be obscene. The first
segment is where the male protagonist, named Bagga, indiscriminately uses
expletives that are heard by the female protagonist, named Naira. Naira objects to the
use of such language and points out that the literal meaning of the terms is absurd.
Bagga states that these terms are not meant to be taken literally and are a part of
common parlance. Naira reiterates her disapproval and threatens Bagga with
consequences if he continues to speak in such a manner. Bagga ‘inadvertently’ uses
another expletive, due to which Naira leaves from there. In the second segment,
Naira and Bagga are with a wider group of friends where Naira is incensed by the
statements of another friend and angrily uses the same expletives as Bagga, at which
Bagga is delighted. Learned senior counsel has argued that when these scenes are
considered individually and in the context of the web-series as a whole, they are not
obscene. They only portray the absurdity of the literal meaning of these terms andApoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

show their inevitable presence in common language, including by those who
disapprove of their use.
7.2 Relying on Samaresh Bose v. Amal Mitra12 and Bobby Art International v. Om
Pal Singh Hoon13, learned senior counsel has argued that while the alleged portions
are vulgar, vulgarity does not equate to obscenity. Mere words cannot amount to
obscenity unless they involve lascivious elements that arouse sexual thoughts and
feelings, which is not the effect of the scenes in the present case.
7.3 The effect of the words must be tested from the standard of an “ordinary man of
common sense and prudence”14, “reasonable, strong-minded, firm and courageous”
person and not from the perspective of a hypersensitive person or a weak and
vacillating mind15. The terms used in the allegedly offending portions do not refer to
any sexually explicit act and are not obscene as per the community standard test.
Therefore, no offence of obscenity is made out under Section 67 of the IT Act.
7.4 Learned senior counsel has also argued that the scenes do not contain any
sexually explicit act or conduct, as is required for an offence under Section 67A.
Relying on (1985) 4 SCC 289, 1985 INSC 205.
(1996) 4 SCC 1, 1996 INSC 595.
K.A. Abbas v. Union of India (1970) 2 SCC 780, 1970 INSC 200. Ramesh s/o Chotalal Dalal v. Union
of India (1988) 1 SCC 668, 1988 INSC 44. various cases by this Court,16 they argue that the words in
a penal provision must be strictly interpreted. The term ‘sexually explicit act or conduct’ does not
cover profanities/ expletives/ swear words, even if the literal meaning of these terms refers to sexual
acts. The literal meaning is not intended through the common usage of these words. Rather, they are
an expression of emotions such as frustration, rage, and anger.
7.5 Learned senior counsel has also relied on the 50th Standing Committee Report on the 2006
Amendment Bill to the IT Act that introduced the provision, and various High Court decisions,17 to
argue that the intention of Section 67A is to criminalise the publication and transmission of
pornographic material that depicts sexual acts or contains sexually explicit conduct that falls short
of actual depiction of sexual acts. Since the alleged segments in this case only contain expletives and
do not contain any explicit visual or Sakshi v. Union of India, (2004) 5 SCC 518, 2004 INSC 383;
Sanjay Dutt v. State through CBI, Bombay (II), (1994) 5 SCC 410, 1994 INSC 371; Girdhari Lal
Gupta v. D.H. Mehta, (1971) 3 SCC 189, 1970 INSC 164; Union of India v. Rajiv Kumar, (2003) 6
SCC 516, 2003 INSC 320; US Technologies International (P) Ltd. v. Commissioner of Income Tax,
(2023) 8 SCC 24, 2023 INSC 329. Vijesh v. State of Kerala, 2021 SCC OnLine Ker 854; Pramod
Anand Dhumal v. State of Maharashtra, (2021) SCC OnLine Bom 34; Majeesh K. Mathew v. State of
Kerala, 2018 SCC OnLine Ker 23374; Ritesh Sidhwani v. State of U.P., 2021 SCC OnLine All 856;
Jaykumar Bhagwanrao Gore v. State of Maharashtra, 2017 SCC OnLine Bom 7283.
verbal depiction of sexual activity, there is no offence under Section 67A.Apoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

7.6 It is of course rightly argued that the right to freedom of speech under Article 19(1)(a) protects
artistic creativity and expression.
7.7 Lastly, the learned senior counsel has argued that a higher threshold of tolerance must apply in
the present case as the web-series is a form of “pull media”. In pull media, the consumer has more
choice in deciding whether or not they wish to view some particular content. Unlike television or
radio, where obscene material may be publicly broadcasted and there is little to no choice to the
users in terms of what content is made available, the consumption of pull media over the internet
gives the viewer complete control and decision-making over what they watch. Therefore, the
web-series is only available and accessible to those persons who wish to view it, and hence a higher
threshold of obscenity must be applied to “pull content”.
8. Submissions of the complainant: We have heard learned counsel Mr. Arvind Singh,
advocate-in-person, who is the complainant (respondent no. 2). He has argued that the present case
is not fit for quashing. The alleged content of the web-series falls within the purview of Sections 67
and 67A of the IT Act and also offends Sections 3 and 4 of the Indecent Representation of Women
(Prohibition) Act, 1986, which the High Court has failed to consider. Relying on the community
standard test and the judgments of this Court in Aveek Sarkar (supra) and Devidas Ramachandra
Tuljapurkar v. State of Maharashtra18, learned counsel has argued that the abovementioned
portions of the web- series are obscene and sexually explicit. First, the material appeals to prurient
interest in sex, as determined by the average person applying contemporary community standards.
The titles of the episodes and the plot revolves around college students engaging in sexual activity.
The content of the episodes also uses sexually explicit language and expletives, which cannot be
termed as the “new normal”. Second, the material portrays sexual conduct in a patently offensive
way. Third, the material lacks serious literary, artistic, political or scientific value. Fourth, the
material tends to arouse sexually impure thoughts. Fifth, the material is not in the larger interest of
public good or in the interest of art, literature, science and therefore, the obscenity is not justified.
Learned (2015) 6 SCC 1, 2015 INSC 414.
counsel has also pointed out that the material in the present case is freely available on the internet
and is accessible to any person, including children and hence must be regulated in the interests of
public order, morality, and decency.
9. Analysis: The central issue is whether the use of expletives and profane language in the titles and
content of the episodes of the web-series ‘College Romance’ constitutes an offence of publication
and transmission of obscene and sexually explicit content under Sections 67 and 67A of the IT Act.
We will examine each of these provisions in the context of ‘obscenity’ for the purpose of Section 67
and ‘sexually explicit material’ for the purpose of Section 67A.
A. Whether the material is ‘obscene’:
10. We will first deal with the contention that the material is obscene. Section 67 of the IT Act is as
follows:Apoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

“67. Punishment for publishing or transmitting obscene material in electronic
form.–Whoever publishes or transmits or causes to be published or transmitted in
the electronic form, any material which is lascivious or appeals to the prurient
interest or if its effect is such as to tend to deprave and corrupt persons who are
likely, having regard to all relevant circumstances, to read, see or hear the matter
contained or embodied in it, shall be punished on first conviction with imprisonment
of either description for a term which may extend to three years and with fine which
may extend to five lakh rupees and in the event of second or subsequent conviction
with imprisonment of either description for a term which may extend to five years
and also with fine which may extend to ten lakh rupees.”
11. This Court has laid down the meaning, test, standard, and method for determining whether some
material is obscene in the context of Section 292 of the IPC.
12. Section 292 defines ‘obscene’ as a book, pamphlet, paper, writing, drawing, painting,
representation, figure or any other object that is lascivious, appeals to the prurient interest, or has
such effect, if taken as a whole, that tends to deprave and corrupt persons who are likely to read, see
or hear the matter contained in it. The provision criminalises the sale, distribution, public
exhibition, circulation, import, export, etc of obscene material. The provision excludes such material
when the publication is justified as being for public good on the ground that it is in the interest of
science, art, literature, or learning or other objects of general concern; such material is kept or used
for bona fide religious purposes; it is sculptured, engraved, painted or represented on or in ancient
monuments and temples. The relevant portion of Section 292 has been extracted for reference:
“292. Sale, etc., of obscene books, etc.—(1) For the purposes of sub-section (2), a
book, pamphlet, paper, writing, drawing, painting, representation, figure or any other
object, shall be deemed to be obscene if it is lascivious or appeals to the prurient
interest or if its effect, or (where it comprises two or more distinct items) the effect of
any one of its items, is, if taken as a whole, such as to tend to deprave and corrupt
persons, who are likely, having regard to all relevant circumstances, to read, see or
hear the matter contained or embodied in it.” It is evident that “obscenity” has been
similarly defined in Section 292 and Section 67 as material which is:
     i.      lascivious; or
     ii.     appeals to the prurient interest; or
     iii.    its effect tends to deprave and corrupt persons who are
likely, having regard to all relevant circumstances, to read, see or hear the matter
contained or embodied in it.
However, the difference between them is only that Section 67 is a special provision that applies
when the obscene material is published or transmitted in the electronic form.19 Since the allegedApoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

offending material is a web-series, the case must be considered under Section 67 of the IT Act20 but
the same test for obscenity as laid down under Section 292 will apply since the provisions are
similarly worded in that respect. In this context we will examine how obscenity is understood.
13. Recounting the development through judicial precedents: This Court upheld the constitutional
validity of Section 292 as a reasonable restriction on free speech and applied the Hicklin test21 to
determine whether the book ‘Lady Chatterley’s Lover’ was Sharat Babu Digumarti (supra).
ibid.
(1868) LR 3 QB 360.
obscene in the decision of Ranjit D. Udeshi v. State of Maharashtra.22 As per the Hicklin test, a
material is obscene if it has the tendency to deprave and corrupt the minds of those who are open to
such immoral influences and into whose hands the publication is likely to fall:23 “… I think the test
of obscenity is this, whether the tendency of the matter charged as obscenity is to deprave and
corrupt those whose minds are open to such immoral influences, and into whose hands a
publication of this sort may fall … it is quite certain that it would suggest to the minds of the young
of either sex, or even to persons of more advanced years, thoughts of a most impure and libidinous
character.”
14. This test lays emphasis on the potentiality of the material to deprave and corrupt by immoral
influences.24 To determine this, the Court must apply itself to consider each work at a time. It must
take an overall view of the obscene matter in the setting of the whole work but also consider the
obscene matter by itself and separately to find out whether it is so grossly obscene and it is likely to
deprave and corrupt. A mere stray word or insignificant passage would not suffice to qualify the
material as obscene.25 The Court also clarified that sex and nudity in art and literature cannot in
and of themselves be regarded as evidence of obscenity without AIR 1965 SC 881, 1964 INSC 171.
ibid, para 14.
ibid, para 19.
ibid, 20, 21.
something more.26 Sex must be treated in manner that is offensive to public decency and morality,
when judged by our national standards, and must be likely to pander to lascivious, prurient, sexually
precocious minds, and appeal to or have the tendency to appeal to the “carnal side of human nature”
for it to be obscene.27
15. The Court also emphasised its role in maintaining a delicate balance between protecting freedom
of speech and artistic freedom on the one hand, and public decency and morality on the other. It
held that when art and obscenity are mixed, the art must be so preponderating that the obscenity is
pushed into the shadows or is trivial and insignificant and can be overlooked.28 Similarly, if theApoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

matter has a preponderating social purpose and gain that overweighs the obscenity of the content
(such as medical textbooks), then such material is constitutionally protected by freedom of speech
and cannot be criminalised as obscene.29
16. The Court followed the Hicklin test and Ranjit Udeshi (supra) in Shri Chandrakant Kalyandas
Kakodkar v. State of Maharashtra30 but it also introduced certain caveats and refined the test to
some extent. Considering the material in that case, a ibid, para 16.
ibid, paras 21 and 22.
ibid, para 21.
ibid, paras 9, 22, and 29.
(1969) 2 SCC 687, 1969 INSC 202.
Marathi short story Shama, the Court held that the story read as a whole does not amount to
pornography or pander to the prurient interest. Even if the work is not of high literary quality and is
immature and of bad taste, there was nothing that could deprave or corrupt those in whose hands it
is likely to fall, including adolescents.31 The Court also cautioned that the standard for the artist or
the writer is not that the adolescent mind must not be brought in contact with sex or that the work
must be expunged of all references to sex, irrespective of whether it is the dominant theme.32 The
test for obscenity was stated as: “What we have to see is that whether a class, not an isolated case,
into whose hands the book, article or story falls suffer in their moral outlook or become depraved by
reading it or might have impure and lecherous thoughts aroused in their minds.”33
17. In KA Abbas v. Union of India34 the Court summarised the test and process to determine
obscenity as follows:
“(1) Treating with sex and nudity in art and literature cannot be regarded as evidence
of obscenity without something more.
(2) Comparison of one book with another to find the extent of permissible action is
not necessary.
ibid, paras 9 and 10.
ibid, para 12.
ibid, para 12.
(1970) 2 SCC 780, para 48.Apoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

(3) The delicate task of deciding what is artistic and what is obscene has to be performed by courts
and in the last resort, by the Supreme Court and so, oral evidence of men of literature or others on
the question of obscenity is not relevant.
(4) An overall view of the obscene matter in the setting of the whole work would of course be
necessary but the obscene matter must be considered by itself and separately to find out whether it
is so gross and its obscenity is so decided that it is likely to deprave or corrupt those whose minds
are open to influence of this sort and into whose hands the book is likely to fall.
(5) The interests of contemporary society and particularly the influence of the book, etc., on it must
not be overlooked. (6) Where obscenity and art are mixed, art must be so preponderating as to
throw obscenity into shadow or render the obscenity so trivial and insignificant that it can have no
effect and can be overlooked. (7) Treating with sex in a manner offensive to public decency or
morality which are the words of our Fundamental Law judged by our national standards and
considered likely to pender to lescivious, pourlent or sexually precocious minds must determine the
result. (8) When there is propagation of ideas, opinions and informations or public interests or
profits, the interests of society may tilt the scales in favour of free speech and expression. Thus
books on medical science with intimate illustrations and photographs though in a sense immodest,
are not to be considered obscene, but the same illustrations and photographs collected in a book
form without the medical text would certainly be considered to be obscene. (9) Obscenity without a
preponderating social purpose or profit cannot have the constitutional protection of free speech or
expression. Obscenity is treating with sex in a manner appealing to the carnal side of human nature
or having that tendency. Such a treating with sex is offensive to modesty and decency.
(10) Knowledge is not a part of the guilty act. The offender's knowledge of the obscenity of the book
is not required under the law and it is a case of strict liability.”
18. In Samaresh Bose (supra), which has been relied on by the appellants, this Court differentiated
vulgarity from obscenity. The material in question in this case was a Bengali novel titled ‘Prajapati’.
The Court noted that while slang and unconventional words had been used in the book along with
suggestions of sexual acts, there was no description of any overt act of sex. The words are vulgar and
create a feeling of disgust and revulsion and may shock the reader but this does not necessarily
amount to obscenity, which is the tendency to deprave and corrupt.35 It held that the use of slang
and unconventional words; an emphasis on sex; a description of female bodies; and narrations of
feelings, thoughts and actions in vulgar language in the novel do not render the material obscene.36
Further, a mere reference to sex is insufficient for obscenity and does not make a material
unsuitable for adolescents.37
19. The Court also summarised the process that must be followed to objectively assess whether some
material is obscene. It held that the judge must first place himself in the position of the author to
understand his perspective and what he seeks to convey and whether it has any literary or artistic
value. The judge must then place himself in the position of a reader of every age group in whose
hands the book (or material) is likely to fall and determine the Samaresh Bose (supra), para 35.Apoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

ibid, para 35.
ibid, para 35.
possible effect or influence of the material on the minds of such persons. The relevant portion reads:
“29. …As laid down in both the decisions of this Court earlier referred to, “the
question whether a particular article or story or book is obscene or not does not
altogether depend on oral evidence, because it is the duty of the court to ascertain
whether the book or story or any passage or passages therein offend the provisions of
Section 292 IPC”. In deciding the question of obscenity of any book, story or article
the court whose responsibility it is to adjudge the question may, if the court considers
it necessary, rely to an extent on evidence and views of leading literary personage, if
available, for its own appreciation and assessment and for satisfaction of its own
conscience. The decision of the court must necessarily be on an objective assessment
of the book or story or article as a whole and with particular reference to the passages
complained of in the book, story or article. The court must take an overall view of the
matter complained of as obscene in the setting of the whole work, but the matter
charged as obscene must also be considered by itself and separately to find out
whether it is so gross and its obscenity so pronounced that it is likely to deprave and
corrupt those whose minds are open to influence of this sort and into whose hands
the book is likely to fall. Though the court must consider the question objectively with
an open mind, yet in the matter of objective assessment the subjective attitude of the
Judge hearing the matter is likely to influence, even though unconsciously, his mind
and his decision on the question. A Judge with a puritan and prudish outlook may on
the basis of an objective assessment of any book or story or article, consider the same
to be obscene. It is possible that another Judge with a different kind of outlook may
not consider the same book to be obscene on his objective assessment of the very
same book. The concept of obscenity is moulded to a very great extent by the social
outlook of the people who are generally expected to read the book. It is beyond
dispute that the concept of obscenity usually differs from country to country
depending on the standards of morality of contemporary society in different
countries. In our opinion, in judging the question of obscenity, the Judge in the first
place should try to place himself in the position of the author and from the viewpoint
of the author the Judge should try to understand what is it that the author seeks to
convey and whether what the author conveys has any literary and artistic value. The
Judge should thereafter place himself in the position of a reader of every age group in
whose hands the book is likely to fall and should try to appreciate what kind of
possible influence the book is likely to have in the minds of the readers. A Judge
should thereafter apply his judicial mind dispassionately to decide whether the book
in question can be said to be obscene within the meaning of Section 292 IPC by an
objective assessment of the book as a whole and also of the passages complained of as
obscene separately. In appropriate cases, the court, for eliminating any subjective
element or personal preference which may remain hidden in the subconscious mindApoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

and may unconsciously affect a proper objective assessment, may draw upon the
evidence on record and also consider the views expressed by reputed or recognised
authors of literature on such questions if there be any for his own consideration and
satisfaction to enable the court to discharge the duty of making a proper assessment.”
20. The Court then applied this test to the novel in question. By placing themselves in the position of
the author and judging the work from his perspective, the Court found that his intention was to
expose social evils and ills, for which the author has used his own technique. Similarly, the Court
placed itself in the position of the readers who are likely to read the book. It held that the book was
likely to be read by readers of “both sexes and all ages between teenagers and the aged” and found
that while it may create a sense of shock and disgust, no reader would be depraved, debased, or
encouraged to lasciviousness by reading the book.38
21. In Bobby Art International (supra) the question before the Court was whether certain scenes
from the film ‘Bandit Queen’ that depicted rape and nudity were obscene. Here, obscenity was not
considered under Section 292 but under the 1991 Guidelines for Censor Board certification under
the Cinematograph Act, 1952.39 The Court did not cite or follow the Hicklin test as laid down ibid.
The relevant guidelines, as extracted in Bobby Art International (supra), are as follows:
“15. The guidelines earlier issued were revised in 1991. Clause (1) thereof reads thus:
in Ranjit Udeshi (supra) and Chandrakant Kalyandas (supra).
Instead, it relied on the Guidelines and laid down the test for obscenity as follows:
“22. The guidelines aforementioned have been carefully drawn. They require the
authorities concerned with film certification to be responsive to the values and
standards of society and take note of social change. They are required to ensure that
“artistic expression and creative freedom are not unduly curbed”. The film must be
“judged in its entirety from the point of view of its overall impact”. It must also be
judged in the light of the period depicted and the contemporary standards of the
people to whom it relates, but it must not deprave the morality of the audience.
Clause 2 requires that human sensibilities are not offended by vulgarity, obscenity or
depravity, that scenes degrading or denigrating women are not presented and scenes
of sexual violence against women are avoided, but if such scenes are germane to the
theme, they be reduced to a minimum and not particularised.”
22. The Court first considered the plot and theme of the film as a whole and then considered the
individual scenes of nudity and “1. The objectives of film certification will be to ensure that—
(a) the medium of film remains responsible and sensitive to the values and standards of society;
(b) artistic expression and creative freedom are not unduly curbed;Apoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

(c) certification is responsive to social change;
(d) the medium of film provides clean and healthy entertainment; and
(e) as far as possible, the film is of aesthetic value and cinematically of a good standard.” Clause (2)
states that the Board of Film Censors shall ensure that— “2. (vii) human sensibilities are not
offended by vulgarity, obscenity or depravity; ***
(ix) scenes degrading or denigrating women in any manner are not presented;
(x) scenes involving sexual violence against women like attempt to rape, rape or any form of
molestation or scenes of a similar nature are avoided, and if any such incident is germane to the
theme, they shall be reduced to the minimum and no details are shown; ***” Clause (3) reads thus:
“3. The Board of Film Certification shall also ensure that the film—
(i) is judged in its entirety from the point of view of the overall impact; and
(ii) is examined in the light of the period depicted in the film and the contemporary
standards of the country and the people to which the film relates, provided that the
film does not deprave the morality of the audience.” rape. Judging the work as a
whole and the alleged offending material specifically, the Court held that the scenes
are likely to evoke tears, pity, horror, and shame. Only a perverted mind might be
aroused in such a situation, and the purpose of censorship is not to protect the
pervert or assuage the susceptibilities of the over-sensitive.40 Further, the use of
swear words and expletives that are heard everyday was also held to be harmless.41
The Court rather emphasised the overarching social purpose and message of the film
– to condemn rape and violence against women by showing the trauma and
emotional turmoil of a victim of rape and to evoke sympathy for her and disgust for
the rapist.42 Thus, the material was held as not being obscene.
23. Similarly, in Director General, Directorate General of Doordarshan v. Anand Patwardhan43, the
Court applied the test of ‘contemporary community standards’ to determine whether a documentary
is obscene for the purpose of certification and telecast on Doordarshan. A three-prong test for
obscenity was formulated as follows:
ibid, paras 27 and 28.
ibid, para 29.
ibid, paras 28, 31, 33.
(2006) 8 SCC 433, 2006 INSC 558.Apoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

“(a) whether “the average person, applying contemporary community standards” would find that the
work, taken as a whole, appeals to the prurient interest;
(b) whether the work depicts or describes, in a patently offensive way, sexual conduct specifically
defined by the applicable state law; and
(c) whether the work, taken as a whole, lacks serious literary, artistic, political, or scientific value.”44
24. The Court relied on Ramesh v. Union of India,45 where it was held that the effect of the words
must be judged from the standards of a reasonable, strong-minded, firm and courageous person,
and not from the perspective of weak and vacillating minds or those who sense danger in every
hostile point of view.46 Considering the documentary as a whole to determine its message, which
cannot be conveyed by watching only certain bits, it was held that the film portrays social evils and
does not seek to cater to the prurient interests of any person.47
25. The law on determining obscenity has been summarised and reiterated in Ajay Goswami v.
Union of India48 where the Court cited both Indian precedent and American jurisprudence. The
principles that can be culled out from the judgment are as follows:
ibid, para 32.
(1988) 1 SCC 668, 1988 INSC 44.
Directorate General of Doordarshan (supra), para 37. ibid, para 38.
(2007) 1 SCC 143, 2006 INSC 995.
i. Obscenity must be judged with regard to contemporary mores and national standards.49 ii. The
work must be judged as a whole and the alleged offending material must also be separately
examined to judge whether they are so grossly obscene that they are likely to deprave and corrupt
the reader or viewer.50 There must be a clear and present danger that has proximate and direct
nexus with the material.51 iii. All sex-oriented material and nudity per se are not always obscene.52
iv. The effect of the work must be judged from the standard of an average adult human being.53
Content cannot be regulated from the benchmark of what is appropriate for children as then the
adult population would be restricted to read and see only what is fit for children.54 Likewise,
regulation of material cannot be as per the standard of a hypersensitive man and must be judged as
per an “ordinary man of common sense and prudence”.55 ibid, para 67.
ibid, para 68.
ibid, para 70.
ibid, paras 7 and 61.Apoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

ibid, para 7.
ibid, para 62.
ibid, para 71.
v. Where art and obscenity are mixed, it must be seen whether the artistic, literary or social merit of
the work overweighs its obscenity and makes the obscene content insignificant or trivial. In other
words, there must be a preponderating social purpose or profit for the work to be constitutionally
protected as free speech. Similarly, a different approach may have to be used when the material
propagates ideas, opinions, and information of public interest as then the interest of society will tilt
the balance in favour of protecting the freedom of speech (for example, with medical textbooks).56
vi. The Court must perform the task of balancing what is artistic and what is obscene. To perform
this delicate exercise, it can rely on the evidence of men of literature, reputed and recognised
authors to assess whether there is obscenity.57
26. In S. Khushboo v. Kanniammal,58 the issue pertained to quashing of FIR filed against the
appellant, inter alia under Section 292 of the IPC, for an interview in a magazine where she called
for ibid, para 66.
ibid, para 69.
(2010) 5 SCC 600, 2010 INSC 247.
the social acceptance of premarital sex, especially in live-in relationships, and cautioned women to
take adequate protection to prevent unwanted pregnancies and sexually transmitted infections. The
Court held that no offence was made out under Section 292 as the content is not lascivious (i.e.,
expressing or causing sexual desire); does not appeal to the prurient interest (i.e., excessive interest
in sexual matters); and does not have the effect of tending to deprave and corrupt persons who are
likely to read, hear, or see the material.59 It was reiterated that mere reference to sex does not make
the material obscene without examining the context of such reference.60 The Court held that
obscenity must be gauged with respect to “contemporary community standards that reflect the
sensibilities as well as the tolerance levels of an average reasonable person.”61 In this case, the
appellant had not described any sexual act or said anything that arouses sexual desire in the mind of
a reasonable and prudent reader to make the content obscene.62 Hence the FIR was quashed by this
Court.
ibid, para 24.
ibid, para 25.
ibid, para 27.
ibid, para 28.Apoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

27. A Division Bench of this Court in Aveek Sarkar (supra) also quashed an FIR under Section 292
against the magazine cover of Sports World and Anandbazar Patrika that carried the image of Boris
Becker, a tennis player, posing nude with his fiancée, who are an interracial couple. The Court held
that while judging a photograph, article or book to be obscene, “regard must be had to the
contemporary mores and national standards and not the standard of a group of susceptible or
sensitive persons”.63 The Court held that the Hicklin test must not be applied as it “judged for
obscenity based on isolated passages of a work considered out of context and judged by their
apparent influence on most susceptible readers, such as children or weak-minded adults.”64 Even in
the United States, where the test was first formulated, the courts no longer apply the Hicklin test
and instead apply the test formulated in Roth v. United States65 where the US Supreme Court held
that sex-related material is obscene only when it has the tendency of exciting lustful thoughts when
judged from the perspective of an average person by applying the community standards test.
Similarly, in Canada, the dominant test is the ‘community Aveek Sarkar (supra), para 18.
ibid, para 20.
354 US 476 (1957).
standards problem test’ as per which a work qualifies as obscene when the exploitation of sex is its
dominant characteristic and such exploitation is undue.66 Taking note of these jurisprudential
developments, the Court in Aveek Sarkar markedly moved away from the Hicklin test to the
“community standard test” where the material is considered as a whole to determine whether the
specific portions have the tendency to deprave and corrupt.67
28. Applying this test, it was held that a picture of a nude/semi- nude woman is not per se obscene
unless it arouses sexual desire or overtly reveals sexual desire or has the tendency of exciting lustful
thoughts.68 In the present case, the posture and the background of the woman posing with her
fiancée, whose photograph was taken by her father, does not have the tendency to deprave or
corrupt those in whose hands the magazine would fall when considered in light of the broader social
message of the picture against apartheid, racism, and to promote love and marriage across race.69
We may note that this Court followed the community standards test in Devidas Ramachandra
Tuljapurkar (supra).
R v. Butler, (1992) 1 SCR 452 (Can SC) as cited in Aveek Sarkar (supra), para 22. Aveek Sarkar
(supra), para 23.
ibid, para 23.
ibid, paras 27 and 28.
29. Lastly, in N. Radhakrishnan v. Union of India,70 it was again held that the Court must not be
guided by the sensitivity of a pervert viewer and the setting of the whole work, its purpose, and the
constituent elements of the character must be kept in mind while judging for obscenity.71Apoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

30. Application of the principles in the above-referred precedents to the facts of the present case:
The purpose of elaborately tracing the precedents on Section 292 is to identify the essential content
of the offence of obscenity, the test and the standard by which the allegedly offending material must
be judged, and the oral and documentary evidences and the process that the court must rely on and
follow for arriving at its conclusion.
31. For applying the test for obscenity to the allegedly offending portions of the web-series, it is
important to take note of the approach adopted by the High Court.
32. The High Court purportedly applied the community standard test as laid down in Aveek Sarkar
(supra) to arrive at its conclusion.72 It correctly states the position of law that to determine whether
certain content is obscene, the standard of (2018) 9 SCC 725, 2018 INSC 784.
ibid, para 33.
Impugned judgment, paras 21 and 22.
determination is that of an ordinary common person and not a hypersensitive person.73
33. Wrong question, wrong answer: However, the High Court has incorrectly framed the question
for inquiry. The issue framed by the High Court is whether the language employed in the episode is
contemporarily used by the youth and whether it meets the threshold of decency. The High Court
has framed the question for inquiry in the following terms:
“29. As stated above, this Court had watched a few episodes of the web series “College
Romance” and the episode in question to decide the case more effectively and fairly.
The intent behind watching the said web series was to analyze fairly as to whether the
contention raised on behalf of the petitioners that the language used in the web series
is “in language”, or is “language used by new generation in colleges”, or “the students
in law colleges and the younger generation in colleges uses this language only”, is
without merit or not.
30. This Court also wanted to test/examine the test of a common prudent man in
practicality, acting itself as a common prudent person, so as to check as to whether
such language, in fact, can be heard by a common prudent man without being
embarrassed or finding it against decency or against the concept of decency…”
(emphasis supplied)
34. From a plain reading of Section 67 and the material that is characterised as ‘obscene’ therein, it
is clear that the High Court posed the wrong question, and it has naturally arrived at a wrong
answer. At the outset, the enquiry under Section 292 of the IPC or under Section 67 of the IT Act
does not hinge on whether the ibid, para 28.Apoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

language or words are decent, or whether they are commonly used in the country. Rather, from the
plain language of the provision, the inquiry is to determine whether the content is lascivious,
appeals to prurient interests, or tends to deprave and corrupt the minds of those in whose hands it is
likely to fall.74 The High Court embarked on a wrong journey and arrived at the wrong destination.
35. Profanity is not per se obscene: The second threshold error is in the finding of the High Court
that the language is full of swear words, profanities, and vulgar expletives that could not be heard in
open court and also that it is not the language of the youth. Based on this finding, the High Court
has held that the content is obscene as it “will affect and will tend to deprave and corrupt
impressionable minds”. In its own words, the High Court held:
“30. …this Court found that the actors/protagonists in the web series are not using
the language used in our country i.e. civil language. The Court not only found
excessive use of “swear words”, “profane language” and “vulgar expletives” being
used, it rather found that the web series had a series of such words in one sentence
with few Hindi sentences here and there. In the episode in question, there is clear
description and reference to a sexually explicit act. The Court had to watch the
episodes with the aid of earphones, in the chamber, as the profanity of language used
was of the extent that it could not have been heard without shocking or alarming the
people around and keeping in mind the decorum of language which is maintained by
a common prudent man whether in professional or public domain or even with
family members at home. Most certainly, this Court notes that this is not the
language that nation’s youth or otherwise citizens Section 67, IT Act; Ranjit Udeshi
(supra).
of this country use, and this language cannot be called the frequently spoken
language used in our country.
36. When the entire content of the series is seen in the light of above, it would lead any common
person to a conclusion that the language used in the web series is foul, indecent and profane to the
extent that it will affect and will tend to deprave and corrupt impressionable minds. Therefore, on
the basis of this finding it can be held that the content of the web series will certainly attract the
criminality as envisaged under Section 67 of the Information Technology Act.” (emphasis supplied)
The specific material which the High Court found to be obscene, i.e., that which tends to deprave
and corrupt impressionable minds, was “foul, indecent and profane” language. Nothing more. The
High Court has equated profanities and vulgarity with obscenity, without undertaking a proper or
detailed analysis into how such language, by itself, could be sexual, lascivious, prurient, or depraving
and corrupting. It is well-established from the precedents cited that vulgarity and profanities do not
per se amount to obscenity.75 While a person may find vulgar and expletive-filled language to be
distasteful, unpalatable, uncivil, and improper, that by itself is not sufficient to be ‘obscene’.
Obscenity relates to material that arouses sexual and lustful thoughts, which is not at all the effect of
the abusive language or profanities that have been employed in the episode. Rather, such language
may Samaresh Bose (supra), para 35; Bobby Art International (supra), para 29; NS Madhanagopal
v. K. Lalitha, 2022 SCC OnLine SC 2030, 2022 INSC 1323.Apoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

evoke disgust, revulsion, or shock.76 The reality of the High Court’s finding is that once it found the
language to be profane and vulgar, it has in fact moved away from the requirements of obscenity
under Section 67 of the IT Act. The High Court failed to notice the inherent contradiction in its
conclusions.
36. No objective consideration: Third, the High Court has erred in the legal approach followed by it
while assessing whether the material is obscene. In Samaresh Bose (supra), this Court has laid
down, in great depth and detail, the process and method that must be followed to objectively judge
whether the material is obscene.77 The court must consider the work as a whole and then the
specific portions that have been alleged to be obscene in the context of the whole work to arrive at its
conclusion.78 Further, the court must first step into the position of the creator to understand what
he intends to convey from the work and whether it has any literary or artistic value. It must then
step into the position of the reader or viewer who is likely to consume the work and appreciate the
possible influence on the minds of such reader.79 However, the Samaresh Bose (supra), para 35.
Samaresh Bose (supra), para 29.
ibid; Ranjit Udeshi (supra), paras 20 and 21.
Samaresh Bose (supra), para 29.
High Court has not followed this judicial process before arriving at its conclusion, which is as
follows:
“43. Coming back to case at hand, the specific complaint of petitioner is that in
Episode 05 of Season 01, airtime starting from 5 minutes and 24 seconds onwards
upto 6 minutes and 40 seconds as well as from 25 minutes and 28 seconds upto 25
minutes and 46 seconds, the language of male and female protagonist is full of
obscenity, vulgar words and expletives, without there being any warning or filter
imposing restriction of age of viewers to whom the content should be visible. The
language used in Episode 05 of Season 01 was heard by this Court, and the level of
obscenity of the language and sentences used was such that this Court cannot
reproduce it in the judgment itself for the purpose of adjudication. The language used
in the web series at the abovementioned time referred to a sexually explicit act in
spoken language. It is not just an expletive, but is profane and vulgar language being
used referring to a sexually explicit act which certainly cannot be termed common or
commonly accepted language. Rather the female protagonist in the series itself is
heard objecting to the male protagonist and expressing her disgust over use of this
language by repeating the same language herself to the male protagonist. In answer
to that, the male protagonist further uses more vulgar expletives and indecent
language which is bound to disgust a normal prudent man, if heard in public. Later in
the said episode, the female protagonist uses the same obscene, sexually explicit
language to others and the male protagonist is seen enjoying and appreciating her
conduct. The male protagonist uses words describing male and female genitalia andApoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

sexual act, thus by words, painting pictures of sexually explicit act which brings it
under ambit of arousing prurient feelings by so doing. There’s no escape from the
same by saying that the said act was not done, shown or filmed. Depiction does not
connote filming alone but conveying by a medium, which in this case is spoken
language. Therefore, the content as discussed above will attract the criminality as laid
down under Section 67 as well as 67A of IT Act.” (emphasis supplied)
37. It is evident from the above passages that the High Court has taken the meaning of the language
in its literal sense, outside the context in which such expletives have been spoken. While the literal
meaning of the terms used may be sexual in nature and they may refer to sexual acts, their usage
does not arouse sexual feelings or lust in any viewer of ordinary prudence and common sense.
Rather, the common usage of these words is reflective of emotions of anger, rage, frustration, grief,
or perhaps excitement. By taking the literal meaning of these words, the High Court failed to
consider the specific material (profane language) in the context of the larger web-series and by the
standard of an “ordinary man of common sense and prudence”. When we notice the use of such
language in the context of the plot and theme of the web-series, which is a light-hearted show on the
college lives of young students, it is clear that the use of these terms is not related to sex and does
not have any sexual connotation. Neither did the creator of the web-series intend for the language to
be taken in its literal sense nor is that the impact on a reasonable viewer who will watch the
material. Therefore, there is a clear error in the legal approach adopted by the High Court in
analysing and examining the material to determine obscenity.
38. Furthermore, the objectivity with which a judicial mind is expected to examine the work in
question was completely lost when the High Court evidently could not extricate itself from the
courtroom atmosphere. The sensitivity and discomfort of the High Court is evident when it held:
“29. …The Court had to watch the episodes with the aid of earphones, in the chamber,
as the profanity of language used was of the extent that it could not have been heard
without shocking or alarming the people around and keeping in mind the decorum of
language which is maintained by a common prudent man whether in professional or
public domain or even with family members at home…”
39. Application of wrong standard: The last issue is that of the standard or perspective used by the
High Court to determine obscenity. It is well-settled that the standard for determination cannot be
an adolescent’s or child’s mind, or a hypersensitive person who is susceptible to such influences.80
However, the High Court has incorrectly used the standard of “impressionable minds” to gauge the
effect of the material and has therefore erred in applying the test for obscenity correctly.81
40. The High Court has made several remarks on the need to maintain linguistic purity, civility, and
morality by retaining the purity of language and deprecating the representation of expletives-filled
language as the “new normal”. The real test is to examine if the language is in anyway obscene under
Section 67 of Chandrakant Kalyandas (supra), para 12; Samaresh Bose (supra), para 35; Ajay
Goswami (supra); Aveek Sarkar (supra), para 20.Apoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

Impugned judgment, paras 35, 36 and 74.
the IT Act. The approach adopted by the High Court, as explained earlier, is based on irrelevant
considerations.
41. Similarly, the metric to assess obscenity and legality of any content cannot be that it must be
appropriate to play in the courtroom while maintaining the court’s decorum and integrity. Such an
approach unduly curtails the freedom of expression that can be exercised and compels the maker of
the content to meet the requirements of judicial propriety, formality, and official language. Here
again, the High Court committed a serious error in decision- making.
42. The High Court has also expressed concern and anxiety about the free availability of the
web-series on the internet to the youth and that it was not classified as being restricted to those
above the age of 18 years. While such anxiety is not misplaced, the availability of content that
contains profanities and swear words cannot be regulated by criminalising it as obscene. Apart from
being a non-sequitur, it is a disproportionate and excessive measure that violates freedom of speech,
expression, and artistic creativity.
43. For the reasons stated above, we are of the opinion that the High Court was not correct in its
conclusion that the web-series has obscene content and that therefore the provisions of Section 67 of
the IT Act are attracted.
B. Whether the material is ‘sexually explicit’ for the purpose of Section 67A:
44. Section 67A of the IT Act criminalises the publication and transmission of
sexually explicit content. The provision is as follows:
“67A. Punishment for publishing or transmitting of material containing sexually
explicit act, etc., in electronic form.– Whoever publishes or transmits or causes to be
published or transmitted in the electronic form any material which contains sexually
explicit act or conduct shall be punished on first conviction with imprisonment of
either description for a term which may extend to five years and with fine which may
extend to ten lakh rupees and in the event of second or subsequent conviction with
imprisonment of either description for a term which may extend to seven years and
also with fine which may extend to ten lakh rupees.”
45. The High Court has not given any reason whatsoever on how Section 67A is
attracted to the facts of the present case. In our opinion, the offence of Section 67A is
not at all made out.
46. The facts of the present case certainly do not attract Section 67A as the
complainant’s grievance is about excessive usage of vulgar expletives, swear words,
and profanities. There is no allegation of any ‘sexually explicit act or conduct’ in the
complaint and as such, Section 67A does not get attracted.Apoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

47. Section 67A criminalises publication, transmission, causing to publish or transmit
– in electronic form – any material that contains sexually explicit act or conduct.
Though the three expressions “explicit”, “act”, and “conduct” are open-textured and
are capable of encompassing wide meaning, the phrase may have to be seen in the
context of ‘obscenity’ as provided in Section 67.
Thus, there could be a connect between Section 67A and Section 67 itself. For example, there could
be sexually explicit act or conduct which may not be lascivious. Equally, such act or conduct might
not appeal to prurient interests. On the contrary, a sexually explicit act or conduct presented in an
artistic or a devotional form may have exactly the opposite effect, rather than tending to deprave
and corrupt a person.
C. Quashing the FIR:
48. No offence of publication or transmission of any material in electronic form,
which is obscene, lascivious, or appealing to prurient interest, and/or having the
effect of tending to deprave and corrupt persons, as provided under Section 67 of the
IT act, is made out. Equally, no case of publication or transmission of material
containing sexually explicit act or conduct, as provided under Section 67A, is made
out from the bare reading of the complaint. It is settled that a court must exercise its
jurisdiction to quash an FIR or criminal complaint when the allegations made
therein, taken prima facie, do not disclose the commission of any offence.82
49. In view of the above, we allow the appeals against the judgment of the High Court
dated 06.03.2023 in Criminal Miscellaneous Case No. 2399 of 2020, Criminal
Miscellaneous Case No. 2215 of 2020 and Criminal Miscellaneous Case No. 2214 of
2020, and set aside the judgment of the High Court, and quash FIR 403/2023
registered at Police Station Mukherjee Nagar, Delhi dated 16.04.2023 under Sections
67 and 67A of the IT Act against the appellants herein.
50. Pending applications, if any, shall stand disposed of.
……..……………………………….J. [A.S. Bopanna] .………….………………………….J. [Pamidighantam Sri
Narasimha] New Delhi;
March 19, 2024 State of Haryana v. Bhajan Lal, (1992) SCC Supp (1) 335, 1992 INSC 357; State of
AP v. Golconda Linga Swamy, (2004) 6 SCC 522, 2004 INSC 404; Zandu Pharmaceutical Works Ltd
v. Mohd Sharaful Haque, (2005) 1 SCC 122, 2004 INSC 628.Apoorva Arora vs State (Govt. Of Nct Of Delhi) on 19 March, 2024

