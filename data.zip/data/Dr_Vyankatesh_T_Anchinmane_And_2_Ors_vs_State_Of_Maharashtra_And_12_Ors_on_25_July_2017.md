Dr.Vyankatesh T Anchinmane And 2 Ors vs State Of
Maharashtra And 12 Ors on 25 July, 2017
Author: M. S. Sonak
Bench: M. S. Sonak
skc/dss                                                  JUDGMENT - OPINION 2797-15 25 JULY
                   IN THE HIGH COURT OF JUDICATURE AT BOMBAY
                         CIVIL   APPELLATE  JURISDICTION
                               WRIT PETITION NO.  2797   OF  2015
                                               WITH
                                CIVIL APPLICATION NO. 2301 OF 2015
                                               AND
                                CIVIL APPLICATION NO. 2531 OF 2015
                                               AND
                                CIVIL APPLICATION NO. 161 OF 2016
                                                IN
                                WRIT PETITION NO.  2797   OF  2015
            The State of Maharashtra
            through the Chief Secretary
            Government of Maharashtra
            & Anr.                                 ..     Petitioners
                  vs.
            Shri Vijay Ghogre & Ors.               ..     Respondents 
                                              WITH
                                  WRIT PETITION NO. 3009 OF 2015
            Vimukta Jatis, Nomadic Tribes
            And Special Backward Class
            Employees And Officers 
            Association, Mumbai & Ors.                    ..       Petitioners
                  vs.
            Vijay Ghogre & Ors.                           ..      Respondents
                                            WITH
                             WRIT PETITION NO. 1590 OF 2015 (O.S.)
            Dr. Vyankatesh T. Anchinmane & Ors.           ..      Petitioners
                  vs.
            State of Maharashtra & Ors.                   ..      Respondents
                                            WITHDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

                             WRIT PETITION NO. 3287  OF 2004 (O.S.)
            Best Officers  Association                    ..      Petitioner
                  vs.
            The State of Maharashtra & Ors.               ..      Respondents
                                                                                        1/44
          ::: Uploaded on - 25/07/2017                   ::: Downloaded on - 08/08/2017 01:31:51 :::
 skc/dss                                                         JUDGMENT - OPINION 2797-15 25 JULY
            Appearances :
            Mr.  Rafique   Dada   -   Sr.   Advocate   /   Special   Counsel   with   Mr.   A.B. 
            Vagyani - Government Pleader, Mr. V. B. Thadani - AGP, Ms G. R. 
            Golatkar - AGP, Mr. P. P. More - AAGP and Mr. Rohan Sawant - AGP 
            for   the   Petitioners   -   State   in   (AS)   WP   2797/2015     and   for 
            Respondents - State in (AS) WP 3009 of 2015.
            Mr. A.Y. Sakhare - Sr. Advocate with Mr. A. A. Karande for Petitioners 
            in (AS) WP 3009/2015 and for Respondent Nos.16,17,19 and 21 in 
            (AS) WP 2797/2015. 
            Mr. A. V. Anturkar - Senior Advocate with Mr. Prathamesh Bhargude 
            i/b. Mr. S.B. Deshmukh for  Petitioners in (OS) WP 1590/2015.
            Mr. G.K. Masand i/b Mr. Ajeet Manwani for the Petitioners in (OS) 
            WP 3287/2004.
            Mr. S.C. Naidu   with Mr.   C.T. Chandratre, Mr. Rahul Tanwani, Mr. 
            Aniket Poojari and Ms   S. Naidu for Respondent Nos.1 to 4, 27 and 
            28  in (AS) WP No. 2797/2015 and for Applicant  in CAW 2531 of 
            2015.
            Mr. Ashok N. Kotangale with Mr. Arun D. Nagarjun and Mr. Pradip 
            Badgude i/b. Mr. A. K. Saxena for Respondent No. 7 in (AS) WP 
            2797 of 2015.
            Ms Kavita Anchan with Mr. Arsh Misra i/b. M/s. M. V. Kini & Co. for 
            Respondent No. 4 in (OS) WP 3287 of 2004.
                                     CORAM :  M. S. SONAK, J.
             Date of Reserving the Judgment (Opinion):       15   July  2017
             Date of Pronouncing the Judgment  (Opinion): 25  July   2017
            JUDGMENT  (OPINION) :
-
1] Heard learned counsel for the parties.
2] The Hon'ble the Chief Justice by order dated 23rd January 2017, has made this Reference in
terms of Rule 7 of Chapter I of The Bombay High Court, Appellate Side Rules, which inter aliaDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

provides that the point of difference of opinion between Judges of a Division Bench shall be decided
in the manner provided for in section 98 of the Code of Civil Procedure or section 392 of the Code of
Criminal Procedure as the case may be. Such Reference was necessitated on account of divergent
opinions expressed by the Hon'ble Justice skc/dss JUDGMENT - OPINION 2797-15 25 JULY Anoop
V. Mohta (opinion dated 26th July 2016) and Hon'ble Justice A. A. Sayed (opinion dated 21 st
December 2016) in writ petition no. 2797 of 2015 and connected matters.
3] In his opinion dated 26th July 2016, Hon'ble Justice Anoop V. Mohta has reversed the MAT's
judgment dated 28 th November 2014 which had held the Maharashtra State Public Services
(Reservations for Scheduled Castes, Scheduled Tribes, De-Notified Tribes (Vimukta Jatis), Nomadic
Tribes, Special Backward Category and other Backward Classes) Act 2001 (Reservation Act) and GR
dated 25 th May 2004 as ultra vires the Constitution. On the other hand, Hon'ble Justice A. A.
Sayed, in his opinion dated 21 st December 2016 has held that the GR dated 25th May 2004 is ultra
vires the Constitution. On the aspect of constitutional validity of the Reservation Act, Hon'ble
Justice A. A. Sayed has held that such question did not legitimately arise in the facts and
circumstances and was merely academic. Therefore, the MAT, was not justified in deciding the
question of the constitutional validity of the Reservation Act. Apart from such fundamental
divergence, the Hon'ble Judges have issued certain consequential directions, which again, are at
some variance with each other.
4] Upon due consideration of the submissions of the learned counsel for the parties and the careful
reading and consideration of the divergent opinions, the material points of difference which are
stated to arise, can be crystallized as follows:
(i) Whether the Reservation Act is indeed intra vires as held in some portions of the
opinion dated 26 th July 2016 or whether the question of constitutional validity of the
Reservation Act was merely academic and therefore, was not skc/dss JUDGMENT -
OPINION 2797-15 25 JULY required to be decided either by the MAT or this Court,
as held in the opinion dated 21st December 2016 ?
(ii) Is the GR dated 25th May 2004, to the extent it makes provisions for reservations
in matters of promotion in favour of backward class of citizens other than SC/STs
ultra vires Article 16(4A) of the Constitution, as held in the opinion dated 21st
December 2016?
(iii) Is the GR dated 25th May 2004, to the extent it makes provisions for
reservations in matters of promotion in favour of SC/STs ultra vires Article 16(4A) of
the Constitution because there was no quantifiable data before the State to form an
opinion that SC/STs were not adequately represented in the services under the State
as held in the opinion dated 21 st December 2016?
(iv) Whether, in the facts and circumstances of the cases, directions in clauses (ii),
(iii), (iv) and (v) of the opinion dated 21st December 2016 could or were required to
be issued?Dr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

5] Mr. Dada, Mr. Sakhare and Mr. Anturkar have reiterated the submissions made by them before
the Division Bench. They submit that Ghogre, et al. had no legitimate surviving grievance regards
reservations at the stage of initial recruitment. At their behest, MAT was not at all justified in going
into the question of constitutional validity of the Reservation Act and striking down the same. They
submit that the issues of constitutionality of statutes must never be decided for academic purposes
or unless they are absolutely necessary for the purposes of grant or denial of reliefs to the
petitioners. In support, they rely upon the decisions of the Hon'ble Supreme Court in Naresh
Shridhar Mirajkar and ors. Vs. skc/dss JUDGMENT - OPINION 2797-15 25 JULY State of
Maharashtra and ors.1, State of Karnataka vs. Registrar General, High Court of Karnataka2 and The
State of Bihar Vs. Rai Bahadur Hurdut Roy Moti Lall Jute Mills and anr.3 6] On the aspect of the
constitutional validity of the GR dated 25th May 2004, Mr. Dada, Mr. Sakhare and Mr. Anturkar
have again reiterated their submissions before the Division Bench. To justify reservations at the
stage of promotions in favour of backward class of citizens other than SC/STs, strong reliance was
placed upon certain observations in Commissioner of Commercial Taxes, A.P. Hyderabad vs. G.
Sethumadhava Rao4. Mr. Anturkar also submitted that such reservations are protected under the
generic Article 14 by applying the doctrine of classification.
7] Mr. Dada and Mr. Sakhare submitted there was ample quantifiable data before the State for
formation of opinion that such backward class of citizens, which includes SC/STs were not
adequately represented in the services under the State. They submit that neither the MAT nor this
Court can scan such quantifiable data, as, if, they were exercising appellate jurisdiction. They relied
upon Barium Chemicals Ltd. vs. Company Law Board 5, to submit that the scope of judicial review
in such matters is extremely limited.
8] Mr. Anturkar submitted that unless the 'scope of canvas' and 'nature of criteria' to be applied is
determined, it is impermissible to conclude that there is any infirmity in the formation of opinion by
the State that the members of SC & ST have been inadequately 1 37 AIR 1967 SC 1 2 (2000) 7 SCC
333 3 AIR 1960 SC 378 4 1996 (7) SCC 512 5 1966 Supp. SCR 311 skc/dss JUDGMENT - OPINION
2797-15 25 JULY represented in the services under the State. The expression "making provision"
found in Article 16(4-A) of the Constitution refers to making provision for reservation in a particular
cadre. Mr. Anturkar therefore, submits that the question of appreciation of quantifiable data shall
have to be only at the stage of issuance of advertisements for reservations in promotion. He submits
therefore, there was no necessity to strike down the GR dated 25 th May 2004, which is only an
instrument which enables the State to make provisions. He submits that in a given case, if, despite
lack of quantifiable data any advertisement is issued for providing for reservations at the stage of
promotions, only then, such action may be judicially reversed but there was no necessity to strike
down the GR dated 25th May 2004.
9] Mr. Naidu, the learned counsel for Ghogre, Gunale and others, however, disputes this position
and submits that the issue of constitutionality of the Reservation Act was not academic, in the facts
and circumstances of the case. He submits that MAT was justified in declaring the Reservation Act
ultra vires and striking down the same.Dr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

10] On the aspect of the constitutional validity of the GR dated 25th May 2004, Mr. Naidu has
reiterated the submissions made on behalf of Ghogre, et al. before the Division Bench.
11] On the aspect of certain directions issued in the opinion dated 21st December 2016, Mr. Naidu
submits that the same are quite wide and may not be consistent with the Rulings of the Supreme
Court. He submits that overall, the opinion dated 21 st December 2016 is required to be endorsed
with some modifications.
skc/dss JUDGMENT - OPINION 2797-15 25 JULY The question of constitutional validity of the
Reservation Act - Whether, only an academic question?
12] The record reveals that the original petitioners, i.e. Ghogre et al. were mainly concerned with the
issue of reservations at the stage of promotions. At their behest, therefore, there does not appear to
have been any good reason for the MAT to go into the issue of constitutional validity of the
Reservation Act. The MAT, in response to the submissions made by learned counsel appearing for
the State that the issue of constitutionality may not be decided only for academic purposes, held that
since the writ petitions were transferred by the High Court to the MAT for disposal in accordance
with law and since, the petitions raised the issue of constitutionality of the Reservation Act, such
issue, was required to be decided. This does not appear to be correct.
13] The MAT also accepted the submissions on behalf of Ghogre et. al that the provision for
reservation at the stage of direct recruitment to the extent of 52% affects their chances of promotion
to some extent. However, in my opinion, upon consideration of the record and substantial relief
applied for, it is quite clear that Ghogre et al. were mainly concerned with the issue of reservation at
the stage of promotions and not concerned with the issue of percentage of reservations at the stage
of direct recruitment. Accordingly, the MAT was not justified in going into the issue of
constitutionality of the Reservation Act at the behest of Ghogre et al. 14] In paragraph 144 of the
opinion dated 26 th July 2016, the position that constitutionality of a statute need not be decided
only for academic purposes appears to have been accepted. The same reads thus :
skc/dss JUDGMENT - OPINION 2797-15 25 JULY "The Statute need not be declared ultra-vires for
the Academic purposes.
144. On going through even the affidavits, including Para 26 to 41 and the counter-affidavit filed by
the parties, read with the documents, charts, statements and the various reports, so recorded above,
and as those are sufficient to consider the case of the State about the existence of data, vacancy and
the representation requirement for the particular community. This is also in view of the fact that
there is no specific contra material, except simple denial. We have noted, apart from the backlog and
the vacancies and the requirement for providing the promotions to all the categories, further
material for the years 2004 to 2011 are updated upto 31 March 2013, are also placed on record
through the exhibits and charts. It is necessary to know that the reservation in promotion are made
subject to various orders passed by the Supreme Court and the High Courts. No actual affected list
and/or special seniority list and/or action are placed on record by the contesting party. The
Constitutional validity, therefore, in our view, ought not to have been decided only for the academicDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

purposes.
i) Naresh Shridhar Mirajkar & Ors. Vs. State of Maharashtra & Ors. (Para 16).
ii) State of Karnataka Vs. Registrar General, High Court of Karnataka
iii) The State of Bihar Vs. Rai Bahadur Hurdut Roy Moti Lall Jute Mills & Anr."
(Emphasis supplied) 15] Even the observations in paragraph 125 of the opinion dated 26th July
2016 suggest that the issue of constitutionality has been left open for determination in other
pending matters. The paragraph 125, reads thus :
"125. However, the Tribunal need to act within the scope and jurisdiction as provided
under the Tribunal Act. There are Writ petitions whereby, the constitutional validity
of the Reservation Act itself are challenged directly in the High Court by other
similarly affected persons. Those will be heard separately."
 skc/dss                                                           JUDGMENT - OPINION 2797-15 25 JULY
            16]      Since   in   certain   paragraphs   of   the   opinion   dated   26 th  July 
2016 there is reference to the Reservation Act being constitutionally valid and the
conclusion in paragraph 183 (3) reads "The Reservation Act is valid. However,
subject to timely revision" there arises necessity for clarification on this aspect.
Further, since, the issue of constitutional validity of the Reservation Act was not
required to be decided by the MAT for academic purposes, so also, such issue was not
required to be decided by this Court, as such decision, again, would be a decision only
for academic purposes.
17] In Naresh Mirajkar (supra), the Constitution Bench of the Supreme court has
emphasized that in dealing with constitutional matters, it is necessary that the
decision of the court should be confined to the narrow points which a particular
proceeding raises before it. Often enough, in dealing with the very narrow point
raised by a writ petition wider arguments are urged before the court, but the court
should also be careful not to cover ground which is strictly not relevant for the
purpose of deciding the petition before it. Obiter observations and discussion of
problems not directly involved in any proceeding should be avoided by courts dealing
with all matters brought before them; but this requirement becomes almost
compulsive when the court is dealing with constitutional matters.
18] In State of Bihar vs. Rai Bahadur Hurdut Roy (supra), again, the Constitution
Bench of the Supreme Court has held that in case where vires of statutory provisions
are challenged on constitutional grounds, it is essential that the material facts shouldDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

first be clarified and ascertained with a view to determine whether the impugned
statutory provisions are attracted; if they are, the constitutional skc/dss JUDGMENT
- OPINION 2797-15 25 JULY challenge to their validity must be examined and
decided. If, however, the facts admitted or proved do not attract the impugned
provisions there is no occasion to decide the issue about the vires of the said
provisions. Any decision on such question would in such a case be purely academic.
Courts are and should be reluctant to decide constitutional points merely as matters
of academic importance.
19] This means that though the MAT's judgment and order dated 28th November
2014, to the extent, it has struck down the Reservation Act is required to be interfered
with, such interference is not on the ground that the Reservation Act is to be
adjudicated as valid, but on the ground that such issue was not required to be decided
by the MAT, since, such issue, did not, legitimately arise in the facts and
circumstances of the cases before the MAT. This also means that the issue of
constitutional validity of the Reservation Act is left open for determination in an
appropriate case and in an appropriate action in future.
20] I, therefore, agree with Hon'ble Mr. Justice A.A. Sayed's opinion dated 21st
December 2016 that, in the facts and circumstances of the present cases, the issue of
constitutional validity of the Reservation Act was not required to be gone into and
decided by the MAT and therefore, the MAT, was not justified in striking down the
Reservation Act.
th Is the GR dated 25 May 2004, to the extent it makes provisions for reservations in
matters of promotion in favour of backward class of citizens other than SC/STs ultra
vires Article 16(4A) of the Constitution ?
21] In order to determine whether Article 16(4A) enables the State to make
provisions for reservation in matters of promotion, in skc/dss JUDGMENT -
OPINION 2797-15 25 JULY favour of any backward class of citizens, other than
SCs/STs, reference is necessary to the constitutional position prior to the
introduction of Article 16(4A) in the Constitution.
22] Article 16(1) and 16(2), to begin with, mandate equality of opportunity in matters
relating to employment to any office under the State. Article 16(4), however provides
that nothing in Article 16 shall prevent the State from making any provision for the
'reservation of appointments or posts in favour of any backward class of citizens'
which, in the opinion of the State, is not adequately represented in the services under
the State.
23] Though, Article 16(4) makes no specific reference to SCs/STs, it is apparent that
the expression 'any backward class of citizens', in Article 16(4) would include within
its sweep SCs/STs. In fact, in Indra Sawhney and Ors. vs. Union of India & Ors.6 atDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

paragraph 803 (SCC PP 729-731), the Supreme Court, in the precise context, has
observed thus :
"Even so, it is beyond controversy that scheduled castes and scheduled tribes are also
included in the expression 'backward class of citizens' and that separate reservations
can be provided in their favour'.
[Emphasis supplied] 24] In General Manager, S. Rly. vs. Rangachari7, State of Kerala
vs. N. M. Thomas8 and Akhil Bharatiya Soshit Karamchari Sangh (Railway) vs.
Union of India9, the Supreme Court had held that the expression 'appointment' in
Article 16(4), includes not merely initial appointment i.e. direct recruitment but also
promotion. It is on basis 6 1992 Supp. (3) SCC 217 7 (1962) 2 SCR 586 8 (1976) 2 SCC
310 9 (1981) 1 SCC 246 skc/dss JUDGMENT - OPINION 2797-15 25 JULY of this
interpretation that reservation in favour of any backward class of citizens, which
would, as noted earlier, include SCs/STs, was sustained not only at the stage of initial
appointment but also in matters of promotions to the services under the State.
25] However, in Indra Sawhney decided on 16th November 1992, the Constitution
Bench expressly overruled Rangachari, N. M. Thomas and Karamchari Sangh and
held that the expression 'appointment' in Article 16(4) is restricted only to initial
appointment and would not extend in matters of promotion to services in the State.
26] Although, the Constitution Bench in Indra Sawhney, permitted earlier
interpretation to operate for a period of five years, there was much uproar and
discontent. Even the Government is reported to have felt that the decision in Indra
Sawhney adversely affected the interest of SCs/STs in services, since, they had not
reached the required level. Therefore, the Constitution (Seventy Seventh
Amendment) Act 1995 was enacted to introduce clause 16(4A) in the Constitution.
The interpretation of the Constitution Bench in Indra Sawhney, had, in fact, deprived
both SCs/STs and other backward classes, the benefit of reservations in matters of
promotion. However, as is evident from the Statement of Objects and Reasons to the
Constitution (Seventy Seventh Amendment) Act 1995, the emphasis was on restoring
such benefit to SCs/STs only and not generally in favour of 'backward class of
citizens'.
27] The Statement of Objects and Reasons, reads thus :
skc/dss JUDGMENT - OPINION 2797-15 25 JULY "Statement of Objects and
Reasons.--The Scheduled Castes and the Scheduled Tribes have been enjoying the
facility of reservation in promotion since 1955. The Supreme Court in its judgment
dated 16-11-1992 in the case of Indra Sawhney v. Union of India, however, observed
that reservation of appointments or posts under Article 16(4) of the Constitution is
confined to initial appointment and cannot extend to reservation in the matter of
promotion. This ruling of the Supreme Court will adversely affect the interests of theDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

Scheduled Castes and the Scheduled Tribes. Since the representation of the
Scheduled Castes and the Scheduled Tribes in services in the States has not reached
the required level, it is necessary to continue the existing dispensation of providing
reservation in promotion in the case of the Scheduled Castes and the Scheduled
Tribes. In view of the commitment of the Government to protect the interests of the
Scheduled Castes and the Scheduled Tribes, the Government have decided to
continue the existing policy of reservation in promotion for the Scheduled Castes and
the Scheduled Tribes . To carry this out, it is necessary to amend Article 16 of the
Constitution by inserting a new clause (4-A) in the said article to provide for
reservation in promotion for the Scheduled Castes and the Scheduled Tribes".
[Emphasis supplied] 28] Further, though it was easily possible for the Parliament to use the
expression 'in favour of backward class of citizens' in Article 16(4A), consciously, such expression
was avoided and instead, the expression 'in favour of the scheduled castes and scheduled tribes' was
used in Article 16(4A). This is evident on plain reading of the provisions in Article 16(4) and 16(4A)
of the Constitution.
29] The text, the context coupled with legislative history as reflected in the Statement of Objects and
Reasons makes it clear that Article 16(4A) enables the State to make provisions for reservation in
matters of promotion in favour of SCs/STs only, which, in the opinion of the State, are not
adequately represented in the services under the State. Conversely, Article 16(4A) does not skc/dss
JUDGMENT - OPINION 2797-15 25 JULY enable, the State to make provisions for reservations in
the matter of promotions in favour of the larger class of 'any backward class of citizens' other than
SCs/STs.
30] As noted earlier, Article 16(4) uses the expression 'in favour of any backward class of citizens'. In
contrast, Article 16(4A) uses the expression 'in favour of the Scheduled Castes and the Scheduled
Tribes'. This means that in the same Article 16, in its two clauses (4) and (4A), different expressions
have been used. Such conscious difference, will have to be respected. The acceptance of the
interpretation suggested by Mr. Dada, Mr. Sakhare and Mr. Anturkar, would obliterate such
conscious difference in use of the two distinct expressions. By a process of interpretation, the
expression 'in favour of any backward class of citizens', cannot be read into Article 16(4A), when, the
legislature, in enacting Article 16(4A), has, consciously chosen to use another expression which
restricts the benefit of reservation at the stage of promotions 'in favour of the scheduled castes and
the scheduled tribes' only. The interpretation suggested on behalf of the State, would therefore, do
violence to the constitutional text, which is to be avoided.
31] When the Legislature uses the same word or the same expression in different parts of the same
section or statute, there is, unless the context otherwise requires, a presumption that the word or
expression is used in the same sense throughout. From this it also follows that when, in relation to
the same section or statute, different words or different expressions are used, there is a presumption
that they are not used in the same sense.
 skc/dss                                                             JUDGMENT - OPINION 2797-15 25 JULYDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

            32]     The Supreme Court, in B.R. Enterprises v. State of U.P.10   has 
held that the expression "trade and business" in Article 298 has a different meaning from "trade and
commerce" in Article 301 of the Constitution. In Member, Board of Revenue v. Arthur Paul
Benthall11, the expression "distinct matters" occurring in Section 5 of the Stamp Act, 1899, was held
to be different and distinct from the expression "two or more of the descriptions in Schedule 1"
occurring in Section 6. Venkatarama Aiyar, J. observed : "when two words of
different import are used in a statute in two consecutive provisions, it would be
difficult to maintain that they are used in the same sense." Thus applying the
principles of Interpretation of Statutes, it is not possible to hold that the expression
"in favour of Scheduled Caste and Scheduled Tribes" occurring in Article 16 (4A)
must be read as "in favour of any Backward Class of citizens".
33] This position stands further clarified in the decision of M. Nagaraj & Ors. vs. Union of India &
Ors. 12, where, the challenge was to the very introduction of Article 16(4A) as violative of the basic
structure of the Constitution.
34] The petitioners in M. Nagaraj had urged that the Parliament by enacting Article 16(4A) had
virtually appropriated 'judicial power' to itself and acted as appellate authority to reverse the judicial
pronouncement in Indra Sawhney. This, it was urged, was violative of the basic structure of the
Constitution. Further, it was urged that Article 16(4A), by providing reservation and consequential
seniority in favour of SCs/STs at the stage of promotion, had made a very serious dent to the
guarantee of equality under Articles 14 and 16(1) 10 1999 (9) SC 700 11 AIR 156 SC 35 12 (2006) 8
SCC 212 skc/dss JUDGMENT - OPINION 2797-15 25 JULY of the Constitution. It was urged that
such a provision would seriously impair efficiency in the services. The petitioners relying upon the
'width test' urged that the very introduction of Article 16(4A) was violative of the basic structure of
the Constitution.
35] The respondents, which includes, the Union of India however defended the constitutional
amendment by urging that Article 16(4A) and 16(4B) were only enabling provisions. Further, it was
emphasized that Article 16(4A) is a special provision which provides for reservations at the stage of
promotions, only to SCs/STs. It was urged that if SCs/STs and OBCs are lumped together, most of
the vacancies will be gobbled up by the OBCs and therefore, the special provision in Article 16(4A)
was restricted only to SCs/STs. It was urged that the reservation at the stage of promotions, was a
limited reservation restricted only to SCs/STs. On this basis, it was urged that 'risk element' pointed
out in Indra Sawhney, stands reduced. It was urged that such limited reservation restricted only to
SCs/STs passes the muster of 'width test' prescribed for determining whether a constitutional
amendment violates the basic structure of the Constitution. Finally, it was urged that carving out
SCs/STs from a wider class of 'any backward class of citizens' was not only constitutional exercise
but was a constitutional obligation under Article 46.Dr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

36] The aforesaid contentions of the respondents in M. Nagaraj, which would include the Union of
India, are quite significant, particularly since most of such submissions were accepted by the
Constitution Bench in holding that the Parliament had not violated the basic structure of the
Constitution in enacting Article 16(4A). (See paragraph 13 at page 239 of M. Nagaraj).
 skc/dss                                                           JUDGMENT - OPINION 2797-15 25 JULY
            37]     As   noted   earlier,   Constitution   Bench   in  M.   Nagaraj,     has 
accepted the submission that since the benefit under Article 16(4A) was confined only to SCs/STs
and did not extend to the wider class of 'any backward class of citizens', the constitutional provision
passed the muster of 'width test' and the constitutional amendment was therefore not violative of
the basic structure. The Constitution Bench, at several places, has emphasized and re-emphasized
that the benefit of reservations at the stage of promotions enabled by Article 16(4A) was confined
only to SCs/STs and did not extend to the wider class of 'any backward class of citizens'. The
relevant observations from M. Nagaraj have been extensively quoted in the opinion dated 21st
December 2016. However, for reference of convenience, pertinent extracts from paragraphs 85, 86,
97, 99, 114, 115 and 121 of M. Nagaraj, are quoted below :
"85. ........ Therefore, the Government felt that it was necessary to continue the
existing policy of providing reservation in promotion confined to SCs and STs alone.
......"
"86. ....... It gives freedom to the State to provide for reservation in matters of
promotion. Clause (4-A) of Article 16 applies only to SCs and STs........."
******* "97. As stated above, clause (4-A) of Article 16 is carved out of clause (4) of Article 16. Clause
(4-A) provides benefit of reservation in promotion only to SCs and STs......."
****** "99. This proviso was added following the benefit of reservation in promotion conferred upon
SCs and STs alone. .............. The proviso is confined to SCs and STs alone. The said proviso is
compatible with the scheme of Article 16(4-A)".
 skc/dss                                                            JUDGMENT - OPINION 2797-15 25 JULY
                                                     *******
"114. In Indra Sawhney the equality which was protected by the rule of 50%, was by balancing the
rights of the general category vis-à-vis the rights of BCs en bloc consisting of OBCs, SCs and STs. On
the other hand, in the present case the question which we are required to answer is: whether within
the egalitarian equality, indicated by Article 16(4), the sub-classification in favour of SCs and STs isDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

in principle constitutionally valid. Article 16(4-A) is inspired by the observations in Indra Sawhney
vide paras 802 and 803 (of SCC) in which this Court has unequivocally observed that in order to
avoid lumping of OBCs, SCs and STs which would make OBCs take away all the vacancies leaving
SCs and STs high and dry, the State concerned was entitled to categorise and sub- classify SCs and
STs on one hand vis-à-vis OBCs on the other hand. We quote herein below paras 802 and 803 of the
judgment in Indra Sawhney: (SCC pp. 729-31)"
* * ** *
"115. Therefore, while judging the width and the ambit of Article 16(4-A) we must ascertain whether
such sub- classification is permissible under the Constitution. The sub-classification between
"OBCs" on one hand and "SCs and STs" on the other hand is held to be constitutionally permissible
in Indra Sawhney. In the said judgment it has been held that the State could make such
sub-classification between SCs and STs vis-à-vis OBCs. It refers to sub- classification within the
egalitarian equality (vide paras 802 and 803). Therefore, Article 16(4-A) follows the line suggested
by this Court in Indra Sawhney. In Indra Sawhney on the other hand vide para 829 this Court has
struck a balance between formal equality and egalitarian equality by laying down the rule of 50%
(ceiling limit) for the entire BCs as "a class apart" vis-à-vis GC. Therefore, in our view, equality as a
concept is retained even under Article 16(4-A) which is carved out of Article 16(4)."
***** "121. ............. These impugned amendments are confined only to SCs and STs. ........."
38] The decision of the Constitution Bench in M. Nagaraj was once again considered and followed in
Uttar Pradesh Power skc/dss JUDGMENT - OPINION 2797-15 25 JULY Corporation Limited vs.
Rajesh Kumar & Ors. 13 and Suresh Chand Gautam vs. State of Uttar Pradesh & Ors. 14. The
principles which emerge from the decision in M. Nagaraj were summarized in paragraph 81 of
Rajesh Kumar and the extract of summary in paragraph 81(v), which is relevant in the present
context, reads thus:
"The State has to form its opinion on the quantifiable data regarding adequacy of
representation. Clause (4-A) of |Article 16 is an enabling provision. It gives freedom
to t he State to provide for reservation in matters of promotion. Clause (4-A) of
Article 16 applies only to SCs and STs. The said clause is carved out of Article 16(4-A).
Therefore, clause (4-A) will be governed by the two compelling reasons -
"backwardness" and "inadequacy of representation", as mentioned in Article 16(4). If
the said two reasons do not exist, then the enabling provision cannot be enforced."
[Emphasis supplied] 39] Mr. Dada, Mr. Sakhare and Mr. Anturkar in support of their contention
that Article 16(4A) enables the State to make provisions for reservation in matters of promotion in
favour of any backward class of citizens and not merely SC/STs, lay great emphasis on the
observations in paragraph 10 of G. Sethumadhava Rao, which read thus :-
"10. The Parliament by amending the Constitution and introducing Article 16(4A) has
removed the base as interpreted by this Court in Indra Sawhney's case thatDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

appointment does not include promotion by making express provisions that when the
State forms an opinion that members of the Scheduled Castes or Scheduled Tribes
are not adequately represented in any service or to any class or classes of base in the
service under the State, the State is empowered to make provisions for reservation by
promotion. Article 16(1) does not prevent the State from making such a provision. In
Indra Sawhney's case also, this Court reiterated that right to equality under Article
16(1) is equally applicable to the Scheduled Castes and Scheduled Tribes and 13
(2012) 7 SCC 1 14 (2016) 11 SCC 113 skc/dss JUDGMENT - OPINION 2797-15 25
JULY Article 16(4) is not an exception. Reservation is part of the scheme of equality
under Article 16(1). Article 16(4A) would establish that the interpretation put up in
Rangachari's. Thomas' and Karamchari Sangh's cases received parliamentary
approval. It would thus be clear that as a principle of law, rule of reservation can
apply not only to initial recruitment but also in promotions where the State is of the
opinion that Scheduled Castes and Scheduled Tribes are not adequately represented
in promotional posts in class or classes of service under the State. It is seen that Rule
22 of the general Rules provides reservation for appointment by direct recruitment.
By Constitutional parameters and interpretation of law by this Court, reservation
under Articles 16(1) and 16(4) would include reservation in promotion as well."
(Emphasis supplied) 40] In my opinion, the aforesaid observations in G. Sethumadhava Rao, make
no dent to the legal position emerging from M. Nagaraj, Rajesh Kumar and Suresh Gautam for the
following reasons :-
(a) In the first place, the precise issue as to whether Article 16(4A) enables the State
to make provisions for reservation in matters of promotion in favour of backward
class citizens, other than SC/STs did not arise for consideration in G. Sethumadhava
Rao;
(b) Secondly, when Rangachari, N. M. Thomas and Karamchari Sangh were decided,
Article 16(4A) was not even existing in the Constitution. These three cases were
decided in the context of the provisions in Article 16(4) of the Constitution. As noted
earlier, there is a marked distinction between the expression used in Article 16(4) i.e.
'in favour of any backward class of citizens' and the expression used in Article 16(4A)
i.e. 'in favour of scheduled castes and scheduled tribes';
(c) Thirdly, 'parliamentary approval' referred to in of G. Sethumadhava Rao, at the
highest, concerns the skc/dss JUDGMENT - OPINION 2797-15 25 JULY
interpretation in Rangachari, N. M. Thomas and Karamchari Sangh that expression
'appointment', refers not merely to initial recruitment i.e. direct recruitment but
would also include 'promotion' in favour of SC/STs which position had been declared
incompetent in Indra Sawhney;
(d) Fourthly, G. Sethumadhava Rao was decided in the year 1996 , i.e., almost a
decade prior to M. Nagaraj which deals directly with the interpretation andDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

constitutional validity of Article 16(4A) of the Constitution. Therefore, it is not
possible to construe the authority as being in variance with the Constitution Bench in
M. Nagaraj or for that matter, the text of Article 16(4A) of the Constitution.
41] Further, G. Sethumadhava Rao will have to be construed having regard to certain settled
principles concerning interpretation of precedents. A decision is an authority for the question of law
determined by it. Such a question is determined having regard to the fact situation obtaining
therein. Therefore, while applying the ratio, it is not permissible to pick out a word or a sentence
from the judgment de hors the context in which the said question arose for consideration. The
judgment must be read in its entirety and the observations therein should receive consideration in
the light of the questions raised before it. A decision is not an authority for a proposition which did
not fall for its consideration. (See. Punjab National Bank vs. R.L. Vaid15, State of Gujarat Vs. Akhil
Gujarat Pravasi16, A-One Granites vs. State of U.P.17 ).
15 2004 (7) SCC 698, 2004 (3) SCC 537
16 2004(5) SCC 155
17 2004 (3) SCC 537
 skc/dss                                                              JUDGMENT - OPINION 2797-15 25 JULY
             42]     In construing precedents, it is necessary to focus on the ratio 
             decidendi.    A   decision   is   only   an   authority   for   what     is   actually 
decided. What is of essence in a decision is its ratio and not every observations found therein nor
what logically follows from the various observations in the judgment. Every judgment must be read
as applicable to the particular facts, since the generality of the expression which may be found there
is not intended to be exposition of the whole law, but governed and qualified by the particular facts
of the case. It would, therefore, not be profitable to extract a sentence here and there from the
judgment and to build upon it because the essence of the decision is its ratio and not every
observations found therein. A word or a clause or a sentence in the judgment cannot be regarded as
a full exposition of law (See Union of India Vs. Dhanvanti Devi18).
43] Applying the aforesaid principles, it is not possible to hold that G. Sethumadhava Rao is an
authority for the proposition that Article 16(4A) enables the State to make provisions for
reservations in matters of promotion in favour of any backward class of citizens other than SC/STs.
44] Mr. Anturkar's submission that reservations in favour of any backward class of citizens other
than SC/STs at the stage of promotion is protected under the generic Article 14 of the ConstitutionDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

also cannot be accepted. Such submission was not endorsed by the other learned senior advocates in
the matter. Even though Article 14 may be styled as the generic Article dealing with equality, it is
Article 16 which is the specific article dealing with equality in matters of public employment.
Further, it is Article 16(4) 18 1996 (6) SCC 44 skc/dss JUDGMENT - OPINION 2797-15 25 JULY
which enables the State to make provisions for reservation of appointments or posts in favour of any
backward class of citizens which, in the opinion of the State, is not adequately represented in the
services under the State. As noted earlier, this article, as interpreted by the Constitution Bench in
Indra Sawhney enables the State to make provision for reservations only at the initial stage of
appointment i.e. direct recruitment. The interpretation in Indra Sawhney has been diluted by the
introduction of Article 16(4A), which, however, applies only to SC/STs and not to any backward
class of citizens, other than SC/STs. The scope and import of a constitutional amendment cannot be
permitted to be unduly expanded. This will precisely result, if, the submission of Mr. Anturkar is to
be accepted.
45] Upon cumulative consideration of all such factors, I agree with Hon'ble Mr. Justice A.A. Sayed's
opinion dated 21 st December 2016 that the GR dated 25 th May 2004, to the extent, it makes
provisions for reservations at the stage of promotions in favour of any backward class of citizens
other than SC/STs is ultra vires Article 16(4A) of the Constitution of India and liable to be struck
down.
th Is the GR dated 25 May 2004, to the extent it makes provisions for reservations in matters of
promotion in favour of SC/STs ultra vires Article 16(4A) of the Constitution because there was no
quantifiable data before the State to form an opinion that SC/STs were not adequately represented
in the services under the State ?
46] The GR dated 25th May 2004 was issued by the State Government before it could have the
benefit of the interpretation of Article 16(4A) in M. Nagaraj decided by the Constitution Bench on
skc/dss JUDGMENT - OPINION 2797-15 25 JULY 19th October 2006.
47] Article 16 (4A), no doubt enables the State to make provisions for reservation in matters of
promotion in favour of SC/STs provided, such SC/STs , in the opinion of the State are not
adequately represented in the services under the State. Further, the proviso to Article 335 also
enables the State to make provisions in favour of the SC/STs for relaxation in qualifying marks in
any examinations or lowering the standards of evaluation, for reservations in matters of promotions
to any class or classes of services or posts in connection with the affairs of the Unions or of a State
consistently with the maintenance of efficiency of administration.
48] In M. Nagaraj, the Constitution Bench has clearly held that Article 16 (4A) follows the pattern
specified in Articles 16(3) and 16(4) of the Constitution. Article 16(4A) , in terms, emphasizes the
opinion of the States in the matter of adequacy of representation. This article enables the State, in
appropriate cases depending upon the ground reality to make provisions for reservations in matters
of promotions provided, the State has quantifiable data to form its opinion regarding adequacy of
representation. Since, Article 16(4A) is carved out of Article 16(4), its interpretation as well as
exercise of power thereunder will be governed by the following three factors:Dr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

                    (a)     Backwardness ;
                    (b)     Inadequacy of representation ; and 
                    (c)     Overall efficiency of administration (Article 335) .
            49]     In  M. Nagaraj, the Constitution Bench has held that in every 
case where the State decides to provide reservation in matters of promotions in favour of SC/STs,
there must exist at least two skc/dss JUDGMENT - OPINION 2797-15 25 JULY circumstances,
namely, "backwardness" and "inadequacy of representation". Further, regard must also be had to
the overall efficiency of administration (Article 335). These factors are no doubt context specific in
the sense that there is no fixed yardstick to identify and measure these three factors. However, it is
imperative that the State which is desirous of providing reservations in matters of promotions in
favour of SC/STs must be conscious of these factors and further, such consciousness must be
reflected in the existence of and in the consideration of quantifiable data, which again, must be
contemporaneous and not outdated or antiquated (See Ram Singh Vs.Union of India19). If the State
fails to identify and measure backwardness, inadequacy of representation and overall administrative
efficiency, then, the provision for reservation would be invalid and liable to be struck down.
50] It is only on the basis of aforesaid interpretation that the Constitution Bench in M. Nagaraj
rejected the contention that the constitutional amendment by which Article 16(4A) was introduced
violated the basic structure of the Constitution. In fact, the validity of the Constitutional
Amendment Act was upheld "subject to" the interpretation as aforesaid. (See paragraph 121 to 124 of
SCC at pages 278-279 in M. Nagaraj).
51] Mr. Dada and Mr. Sakhare could not and did not dispute the legal position that the State must be
possessed of quantifiable data in order to enable it to form its opinion on the aspects of
backwardness, inadequacy of representation and overall efficiency of administration before
provision is made for reservation in terms of Article 16 (4A) of the Constitution. However, they
submit that such 19 (2105) 4 SCC 697 skc/dss JUDGMENT - OPINION 2797-15 25 JULY
quantifiable data was in existence on basis of which the opinion was arrived at before the GR dated
25 th May 2004 was issued. Relying upon Barium Chemicals Ltd., they submit that judicial review in
such matters is extremely limited and MAT has exceeded the scope of such limited judicial review.
52] Barium Chemicals Ltd, no doubt, lays down that the formation of the opinion is subjective but
the existence of the circumstances relevant to the inference as the sine qua non for action must be
demonstrable. If their existence is questioned , it has to be proved at least prima facie. It is not
sufficient to assert that those circumstances exist and give no clue to what they are, because the
circumstances must be such as to lead to conclusions of certain definiteness. Rohtas Industries Vs.
S.D. Agarwal 20, which considers and explains Barium Chemicals Ltd., lays down that the existence
of circumstances are open for judicial review though the opinion formed by the Government, may
not be. Further, if the circumstances are such as would persuade no reasonable authority to form the
opinion, then, the decision is liable to be struck down.Dr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

53] In Commissioner of Income Tax vs. Mahindra and Mahindra Ltd.21, the Supreme Court, after
considering Barium Chemicals Ltd., has held that if the action or decision is perverse or is such that
no reasonable body of persons, properly informed, could come to or has been arrived at by the
authority misdirecting itself or adopting wrong approach or has been influenced by irrelevant or
extraneous matter, the court would be justified in interfering with the same.
20 1969 (1) SCC 325
21 1983(4) SCC 392
 skc/dss                                                         JUDGMENT - OPINION 2797-15 25 JULY
            54]     In Shalini Soni vs. Union of India22 , the Supreme Court has 
observed that it is an unwritten rule of the law, constitutional and administrative, that whenever a
decision making function is entrusted to the subjective satisfaction of a statutory functionary, there
is an implicit obligation to apply mind to pertinent and proximate matters only, eschewing
irrelevant and remote. This means that existence of satisfaction may not be ordinarily challengeable,
but if in reaching the satisfaction, the Government or Authority misapprehends the nature of the
conditions, or proceeds upon irrelevant material, or ignores relevant materials, the jurisdiction of
the courts to examine the satisfaction is not excluded.
55] In the present case, the State seeks to rely upon the following material, which, according to it,
constitutes 'quantifiable data' as contemplated by M. Nagaraj and other decisions which follow :-
                     (i)     Thade Committee Report - 1961;
                     (ii)     B.D. Deshmukh Report - 1964;
                     (iii)   Wadhwa Committee Report - 1992;
                     (iv)    Edate Committee Report - 1999;
                     (v)     State Backward Class Commission Reports - from 1997 
                             to 2008;
                     (vi)    The Census Reports - 1931, 1991 and 2001;
                     (vii) Special Backward Classes File;
(viii) Reports obtained from various Government Departments indicating backlog of vacancies.
56] Conscious of the parameters of judicial review in such matters, it is necessary to note that most
of such material relied upon by the 22 (1980) 4 SCC 544 skc/dss JUDGMENT - OPINION 2797-15
25 JULY State is quite irrelevant for determining the three factors of backwardness, inadequacy ofDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

representation and overall efficiency of administration, which are pre-conditions and the
constitutional imperatives before provision is made for reservation in terms of Article 16(4A) of the
Constitution.
57] The Thade Committee Report (1961), Wadhwa Committee Report (1992), Edate Committee
Report (1991) and the various State Backward Class Commission Report were mostly unconcerned
with SC/STs, but were concerned mainly with inclusion or exclusion of backward class of citizens
other than SC/STs. The same is position with Special Backward Classes File. As noted earlier, Article
16(4A) enables the State to make provision for reservation in matters of promotion in favour of
SC/STs only, which in the opinion of the State are not adequately represented in the services under
the State. The material or for that matter the alleged quantifiable data which has no nexus with
SC/STs is therefore, irrelevant and extraneous to the formation of opinion as contemplated by
Article 16(4A) of the Constitution. This aspect has been considered in great details by the MAT and
in the opinion dated 21st December 2016 58] The B.D. Deshmukh Committee Report does make
reference to the position of SC/STs. However, this was a report prepared in the year 1964 and
therefore, such a report, cannot be regarded as contemporaneous data. Rather, there is no reason to
fault the MAT which has styled such data as outdated and antiquated.
59] The Census Reports 1931, 1991 and 2001 reflect figures of backward class of citizen including
SC/STs. Such material, by itself, hardly qualifies as some quantifiable data as contemplated by
Article skc/dss JUDGMENT - OPINION 2797-15 25 JULY 16 (4A) as interpreted by the Constitution
Bench in M. Nagaraj and later decisions. The Census Report of 1931, which mainly concerns the
population of Vimukta Jati and Nomadic Tribes is again, quite irrelevant and in any case, outdated
and antiquated.
60] The Reports obtained from various Government Departments indicating backlog of vacancies
again, can hardly be regarded as quantifiable data as contemplated by Article 16 (4A) as interpreted
by the Constitution Bench in M. Nagaraj and later decisions. As observed in the opinion dated 21 st
December 2016, such data, reflects the position arising out of implementation of Circular dated 27th
October 2008 which had provided that the vacancy to a reserved post for a particular category shall
be rolled over to another reserved category in the event of non-availability of the particular reserved
category candidate. This Circular was ultimately struck down by the Division Bench of this Court in
Magas Varga Karmchari Adhikari Suraksha Mahasangh vs. State of Maharashtra 23. Further, such
reports, are premised on the basis that the percentage of reservation in promotional posts for
reserved category was 33%, which includes SC/STs to the extent of 20% only. Since, Article 16(4A)
of the Constitution is confined to SC/STs alone, the basic premise upon which such backlog
vacancies reports was based, stands seriously eroded.
61] In paragraph 29 of the opinion dated 21 st December 2016, there is reference to statistics
obtained under Right to Information Act which suggests that the posts held by SC/STs far exceed
even the percentage of reservation prescribed in the GR dated 25 th May 2004, which is 13% for SCs
and 7% for STs. No doubt, the figures 23 2013 (5) Mh.L.J. 640 skc/dss JUDGMENT - OPINION
2797-15 25 JULY reflected in the last column are slightly exaggerated since they take into account
the filled posts and not the total strength of the cadre. However, even, if the total strength of theDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

cadre is taken into account, the figures, far exceed the prescribed reservation percentage at least for
SC category. It is therefore, apparent that the State has not carried out the exercise of collection of
quantifiable data as contemplated by M. Nagaraj and other decisions, which follow it. In Rajesh
Kumar case, after culling out the principles stated in M. Nagaraj, the Supreme Court has graphically
stated that a fresh exercise in accord with the law laid down in M. Nagaraj is a categorical
imperative. In the absence of such an exercise, the GR dated 25th May 2004, to the extent, it makes
provisions for reservations in matters of promotions in favour of SCs/STs is liable to be set aside.
62] Since, it is the State which asserts that it has undertaken the exercise of collecting quantifiable
data consistent with the decision of the Constitution Bench in M. Nagaraj, it was for the State to
shed some light on the 'extent of canvas' or 'nature of criteria' applied by it for determining whether
SC/STs are adequately represented in the services under the State. Besides, in paragraphs 82/83 of
M. Nagaraj, the Constitution Bench has clarified that the appropriate Government has to apply the
'cadre strength' as a unit in the operation of the roster in order to ascertain whether a given
class/group is adequately represented in the service. The cadre strength as unit also ensures that the
upper ceiling limit of 50% is not violated. The roster has to be post specific and not vacancy based.
Accordingly, it is not possible to accept Mr. Anturkar's contention that the GR dated 25th May 2004
cannot be struck down unless the extent of canvas or the nature of criteria for determining skc/dss
JUDGMENT - OPINION 2797-15 25 JULY adequacy of representation is made clear by Ghogre et al.
or the MAT.
63] The GR dated 25th May 2004, if allowed to stand, will enable the State to provide for
reservation at the stage of promotion in favour of categories of persons specified therein. GR dated
25 th May 2004, even proceeds to prescribe the percentage of reservation in favour of such
categories of persons. Taking into consideration the provisions of Article 16(4A) as interpreted by
the Constitution Bench in M. Nagaraj, the State was not empowered to issue such a GR, without
undertaking the exercise of collection of quantifiable data and forming its opinion on basis of such
quantifiable data that, SC/STs have not been adequately represented in the services under the State.
Since, there is no such quantifiable data placed on record, it is not possible to accept Mr. Anturkar's
contention that the GR dated 25th May 2004 be saved and advertisements, if not backed by
quantifiable data be set aside. Besides, when it comes to filling up posts by promotion, normally,
there is no question of issuing any advertisement as in the case of direct recruitment.
64] Upon cumulative consideration of all these factors, I agree with the Hon'ble Mr. A. A. Sayed's
opinion dated 21 st December 2016 that the GR dated 25th May 2004, to the extent it makes
provisions for reservations in the matter of promotion in favour of SC/STs is ultra vires Article
16(4A) of the Constitution because the constitutional imperatives as prescribed in M. Nagaraj have
not been adhered to.
Whether, in the facts and circumstances of the cases, directions in clauses (ii), (iii), (iv) and (v) of
the opinion dated 21st December 2016 could or were required to be issued?
 skc/dss                                                             JUDGMENT - OPINION 2797-15 25 JULYDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

           65]      The   operative   portion   of   the   opinion   dated   21st  December 
           2016 reads thus :
"69. For all the aforesaid reasons, the Petitions are partly allowed and the following order is passed:
ORDER
(i) The impugned judgment and order of the Tribunal is set aside so far it holds that
the Maharashtra State Public Services [Reservations for Scheduled Castes, Scheduled
Tribes, De-
notified Tribes (Vimukta Jatis), Nomadic Tribes, Special Backward Category and Other Backward
Classes] Act, 2001 is ultra vires the Constitution of India. In other words, the challenge to the
validity of the said Reservation Act fails;
(ii) The Government Resolution on promotions dated 25 May 2004 is held bad in law and struck
down being contrary to Article 16(4A) and contrary to the decision of 5-Judge Constitution Bench of
Supreme Court in Nagaraj. The State Government shall take necessary corrective steps/measures
within 12 weeks from today;
(iii) Inasmuch as Articles 16(4) and 16(4A) are enabling provisions, unless the State Government in
terms of Nagaraj, if so advised, carries out the exercise of collecting quantifiable data with regard to
backwardness and adequate representation and forms an opinion that reservations are necessary
after analyzing such data keeping in mind the overall administrative efficiency, the State
Government shall treat the SC/ST employees and the open/OBC/DT/NT/SBC category of
employees at par in matters of promotion. Though the Reservation Act is saved, to balance equities,
it is directed that unless such exercise in terms of Nagaraj is carried out by 31 December 2017, the
State Govt shall treat the backward class communities at par with the forward class in direct
recruitment on and from 01 January 2018. The State Govt shall, if necessary, consider revisiting the
provisions of section 4 of the Reservation Act, if and after such exercise is carried out;
(iv) Inasmuch as the reservation in direct recruitment in terms of section 4 of the Reservation Act
goes beyond the 50% ceiling limit and no extraordinary circumstances have been made out by the
State Government to grant 2% reservation to SBC over and above the ceiling limit of 50%, the
Maharashtra State Backward Class Commission shall examine the inclusion of SBC afresh without
being influenced by any earlier recommendations or Government decisions on this aspect, within a
period of 3 months from today. It is however clarified skc/dss JUDGMENT - OPINION 2797-15 25
JULY that if the State Govt places before the Commission within 6 weeks from today, its decision of
intention to carry out the exercise in terms of Nagaraj and intention to revisit section 4, if necessary,
as stated in clause (iii) above, this direction shall not operate.
(v) If such exercise is not carried out and completed by the State Government within the stipulated
period, it will be open for the Tribunal/Court to examine the validity of the Reservation Act in an
appropriate and fit case, without being influenced by this judgment and order.Dr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

(A.A. Sayed J.)"
66] As regards clause (i), there is no dissent on the issue that the MAT was not
justified in striking down the Reservation Act. Only certain observations in the
opinion dated 26 th July 2016 suggest that the constitutional validity is required to be
upheld, whereas, the opinion dated 21st December 2016 takes the view the issue of
constitutional validity of the Reservation Act was merely academic and therefore, the
MAT, was not justified in going into such issue at the behest of Ghogre, et al. in the
matters before it. As discussed earlier, I have already concurred with the view
expressed in opinion dated 21 st December 2016. Therefore, to the operative portion
in clause (i)of the opinion dated 26 th December 2016, I would only add by way of
clarification that the issue of constitutional validity of the Reservation Act is left open
to be decided in a appropriate case and on an appropriate occasion.
67] The directions in clause (ii) above, are in two parts. The first part declares GR
dated 25th May 2004 ultra vires and strikes down the same. The second part reads
thus :
"The State Government shall take necessary corrective steps / measures within 12
weeks from today."
 skc/dss                                                             JUDGMENT - OPINION 2797-15 25 JULY
              68]     As noted earlier, I entirely concur with the first part and join 
Hon'ble Justice A. A. Sayed in declaring the GR dated 25 th May 2004 ultra vires and
striking down the same. However, with respect, I am unable to endorse the second
part for reasons discussed hereafter. For similar reasons, and again with respect, I
am also unable to endorse the directions in clauses (iii), (iv) and
(v) of the operative portion of the opinion dated 21 st December 2016.
69] From the combined reading and analysis of the directions in second part of clause (ii) and
clauses (iii), (iv) and (v), the following position emerges :
(a) The State has been directed to take necessary 'corrective steps / measures' within
12 weeks;
(b) The expression 'corrective steps / measures' when construed in the context,
means and implies collection of quantifiable data to form opinion in the matter of
reservations at the stage of promotions in favour of SC/STs;Dr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

(c) This in effect, amounts to issue of writ of mandamus to the State and its
functionaries to collect quantifiable data regards backwardness, adequacy of
representation and overall efficiency of administration in the services and on basis of
the same to take decision in the matter of reservations at the stage of promotions in
favour of SC/STs in a time bound manner;
(d) The State Government is also directed to collect quantifiable data in the context of
Article 16(4) and on basis of the same to revisit the provisions of section 4 of the
Reservation Act which has provided for reservation to the extent of 52% at the stage
of initial recruitment in services;
 skc/dss                                                            JUDGMENT - OPINION 2797-15 25 JULY
                       (e)      The   Maharashtra   State   Backward   Class   Commission 
has also been directed to examine the inclusion of Special Backward Category (SBC)
afresh within a period of 3 months uninfluenced by any earlier recommendations or
decisions. This is on the basis that there are no exceptional circumstances made out
to exceed the reservation percentage ceiling limit of 50% and it is the 2% reservation
in favour of SBC, which breaches the ceiling limit;
(f) If the exercise as directed in clauses (iii) and (iv) is not carried out and completed
within the stipulated period, liberty is granted to Tribunals / Court to examine
validity of Reservation Act, uninfluenced by the judgment and order.
70] The issuance of directions as aforesaid, in sum and substance amount to the issuance of a writ of
mandamus to the State and its functionaries to collect quantifiable data for the purpose of taking a
decision in the matter of reservations at the stage of promotions in favour of SC/STs. This also
amounts to issuance of writ or direction to revisit the provisions of section 4 of the Reservation Act
in the context of breach of ceiling limit of 50% percentage by additional 2% at the stage of initial
recruitment in the services.
71] To my mind, the issuance of a writ of mandamus or directions as aforesaid may not be
appropriate in view of the law laid down by the Supreme Court in the following three decisions, out
of which at least the first two appear to be directly in point:-
(i) Suresh Chand Gautam vs. State of Uttar Pradesh;
(ii) Central Bank of India vs. SC/ST Employees Welfare Association24;
(iii)   Census Commr. vs. R. Krishnamurthy25
24 (2015) 12 SCC 308
25 (2015) 2 SCC 796Dr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

 skc/dss                                                             JUDGMENT - OPINION 2797-15 25 JULY
              72]     The position that a writ of mandamus cannot issue to collect
data or to form opinion and take decision as aforesaid has been considered and
accepted at paragraphs 95 and 96 of Hon'ble Justice Anoop V. Mohta's opinion dated
26th July 2016. I concur with this position, but, with respect, I am unable to concur
with the conclusion which follows. The opinion after stating the legal position
proceeds to state that since no such writ of mandamus can issue, the available the
data has to be respected and accepted and on the basis of the same, the validity of the
Reservation Act and the GR dated 25th May 2004, sustained.
73] In Suresh Chand Gautam, the core issue considered by the Supreme Court was 'whether in the
context of Articles 16(4-A) and 16(4-B), a writ or direction can be issued to the State Government or
its functionaries or the instrumentalities of the State to collect and gather the necessary data for the
purpose of taking a decision as regards the promotion and consequential fixation of seniority.' This
was because a writ of mandamus was applied to direct the State to constitute a Committee or
appoint a Commission to make a survey and collect necessary qualitative data of SC/STs in the
services of the State for granting reservation in promotion in the light of direction in M. Nagaraj.
74] The Supreme Court, after considering in detail the concept of mandamus and the circumstances
in which it can issue, observed that though the relief applied may appear to be 'innocuous or simple'
the Court has to apprise itself of an existing right or power to be exercised regard being held to the
conception of duty. The prayer to issue mandamus to the State to carry out the exercise of skc/dss
JUDGMENT - OPINION 2797-15 25 JULY collecting quantifiable data, is a prayer to issue
mandamus to exercise discretion whether or not to provide for reservation at the stage of promotion
in favour of SC/STs, which is ordinarily impermissible.
75] A writ of mandamus to collect material or data which is in the realm of condition precedent for
exercising a discretion which flows from the enabling constitutional provision, would not come
within the principle of exercise of power coupled with duty, and therefore, will not be issued.
Articles 16(4A) and 16(4B) are enabling constitutional provisions. The State is not bound to make
reservations for SC/STs in matter of promotion. Therefore, there is no duty. In such a situation, to
issue a mandamus to collect a data would amount to asking the authorities whether there is ample
data to frame a rule or regulation. This will be in a way, entering into the domain of legislation, for it
is a step towards commanding to frame a legislation or delegated legislation for reservation. A writ
of mandamus of such a nature cannot be issued (See paragraph 48 of Suresh Chand Gautam). TheDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

Supreme Court, in the context of the relief applied for in the petition observed: 'The relief in the
present case, when appositely appreciated, tantamounts to a prayer for issue of a mandamus to take
a step towards framing of a rule or a Regulation for the purpose of reservation for Scheduled Castes
and Scheduled Tribes in matter of promotions. In our considered opinion a writ of mandamus of
such a nature cannot be issued.' 76] In Central Bank of India case, the Supreme Court, after
extensive reference to M. Nagaraj reiterated that clauses (4) and (4A) of Article 16 of the
Constitution are only enabling provisions skc/dss JUDGMENT - OPINION 2797-15 25 JULY and
not some provisions imposing a constitutional duty. The Supreme Court, in the matter of issuance of
writ of mandamus in cases of such nature observed: 'At the same time, it is also to be borne in mind
that Clauses 4 and 4A of Article 16 of the Constitution are only the enabling provisions which permit
the State to make provision for reservation of these category of persons. Insofar as making of
provisions for reservation in matters of promotion to any class or classes of post is concerned, such a
provision can be made in favour of SC/ST category employees if, in the opinion of the State, they are
not adequately represented in services under the State. Thus, no doubt, power lies with the State to
make a provision, but, at the same time, Courts cannot issue any mandamus to the State to
necessarily make such a provision. It is for the State to Act, in a given situation, and to take such an
affirmative action.' 77] In Census Commr. case, the Supreme Court was dealing with the correctness
of the judgment of the High Court wherein the High Court had directed that the Census Department
of Government of India shall take such measures towards conducting the caste-wise census in the
country at the earliest and in a time- bound manner, so as to achieve the goal of social justice in its
true sense, which is the need of the hour'. In this context, the Supreme Court, at paragraph 25
observed: 'Interference with the policy decision and issue of a mandamus to frame a policy in a
particular manner are absolutely different. The Act has conferred power on the Central Government
to issue notification regarding the manner in which the census has to be carried out and the Central
Government has issued notifications, and the competent authority has issued directions. It is not
within the domain of the court to legislate. The skc/dss JUDGMENT - OPINION 2797-15 25 JULY
courts do interpret the law and in such interpretation certain creative process is involved. The courts
have the jurisdiction to declare the law as unconstitutional. That too, where it is called for. The court
may also fill up the gaps in certain spheres applying the doctrine of constitutional silence or
abeyance. But, the courts are not to plunge into policy-making by adding something to the policy by
ways of issuing a writ of mandamus'.
78] The directions issued to the Maharashtra State Backward Class Commission are in the context of
the provisions of section 4 of the Reservation Act, which concerns reservations at the stage of initial
recruitment. As noted earlier, in these petitions, Ghogre et al. were mainly concerned with the issue
of reservations at the stage of promotions and not the issue of reservations at the stage of initial
recruitment. In fact, it is on this basis that the issue of constitutional validity of the Reservation Act,
which would include the provisions of section 4 thereof has not been gone into. The issue of
revisiting the provisions of an Act with a view to considering whether the provisions call for any
amendment is an issue almost exclusively within the domain of the legislature. In such a matter, the
Courts, will not issue a mandamus or directions in the nature of mandamus. If, in a given case, the
Courts find that the legislative provision is ultra vires the Constitution, the Courts may declare it to
be so and even strike down the same. Thereafter, it will be for the legislature to decide upon the
further course of action.Dr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

79] Further, merely because the reservation for SBC is 2%, it cannot be said that it is this reservation
of 2% in favour of SBC which is required to be considered afresh. If, the ceiling of 50% in skc/dss
JUDGMENT - OPINION 2797-15 25 JULY the matter of reservations is breached and if no
exceptional circumstances are found to be existing, then, the Courts can sustain reservation to the
extent of 50% generally leaving it to the legislature or the executive, as the case may be, to effect
suitable adjustments within the ceiling limit of 50%. In any case, all these are policy decisions and
no mandamus or directions in the nature of mandamus may be issued in this regard.
80] To legislate or revisit any legislation is almost within the exclusive domain of the legislature. In
Suresh Chand Gautam the Supreme Court has held that Courts do not formulate any policy and
remain away from making anything that would amount to legislation, rules and regulations or policy
relating to reservation. The Courts can test the validity of the same when they are challenged. The
Court cannot direct making legislation or for that matter any kind of sub-ordinate legislation. In
certain decisions, the Supreme Court may have itself framed guidelines for sustaining certain rights
of women, children and prisoners or under trial prisoners. The said category of cases fall in a
different compartment. They are in different sphere than what is envisaged in Article 16(4A) and
16(4B) of the Constitution whose constitutional validity has been upheld by the Constitution Bench
with certain qualifiers. Therefore, in my opinion, no directions could be issued either to the State
Government or the State Legislature to consider revisiting the provisions of Section 4 of the
Reservation Act.
81] The directions in clause (v) are redundant because they depend upon the exercise in terms of
clauses (iii) and (iv). Since, in my opinion, no mandamus or direction in the nature of skc/dss
JUDGMENT - OPINION 2797-15 25 JULY mandamus could issue to undertake the exercise in
clauses (iii) and (iv), there was no necessity imposing any fetter upon the exercise of jurisdiction by
a competent Tribunal / Court examining the constitutional validity of the Reservation Act. The
direction in clause (v) is capable of interpretation that the constitutional validity of the Reservation
Act may not be gone into by a competent Tribunal / Court until the expiry of the period within
which the State Government and/or the Maharashtra State Backward Commission is directed to
complete the exercise in terms of clauses (iii) and (iv) of the operative portion of the opinion dated
21st December 2016. Further, since the question of constitutional validity of the Reservation Act has
already been kept open for determination in an appropriate case and on an appropriate occasion,
issuance of any direction in terms of clause
(v) was quite redundant and unnecessary.
82] In the opinion dated 21st December 2016, the aforesaid directions in second part of clause (ii)
and clauses (iii), (iv) and
(v) are sourced to the order in S.V. Joshi vs. State of Karnataka (CITED ORDER 2)26 .
83] The question as to 'whether in the context of Articles 16(4- A) and 16(4-B), a writ or direction
can be issued to the State Government or its functionaries or the instrumentalities of the State to
collect and gather the necessary data for the purpose of taking a decision as regards the promotionDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

and consequential fixation of seniority', did not arise and was therefore not considered in S. V. Joshi
. In fact, paragraph 1 of S.V. Joshi notes that in view of the subsequent events, the writ petition has
become infructuous and is 26 (2012) 7 SCC 41 skc/dss JUDGMENT - OPINION 2797-15 25 JULY
accordingly dismissed. In contrast, the question precisely arose in Suresh Chand Gautam and was
described as 'the core issue' in paragraph 36 (at page 139 of SCC Report). The question has been
squarely decided holding that a mandamus of such nature cannot issue. Besides, the directions in
S.V. Joshi, in the context of the subsequent events noted therein, appear to relate to the exercise of
powers under Article 142 of the Constitution, which powers, are not vested in High Courts.
84] Accordingly, with respect, I am unable to concur with the directions in the second part of clause
(ii) and in clauses (iii), (iv) and (v) of the operative portion of Hon'ble Justice A. A. Sayed's opinion
dated 21st December 2016.
Conclusions :
85] In the context of the points of difference as crystalized in paragraph 4 of this
Opinion, I would answer this Reference in the following terms:
(a) I agree with the Hon'ble Justice A. A. Sayed's opinion dated 21st December 2016
that in the facts and circumstances of the present cases, the issue of constitutional
validity of the Reservation Act was not required to be gone into and decided by the
MAT.
Accordingly, the MAT's judgment and order dated 28th November 2014, to the extent it strikes
down the Reservation Act, is liable to be set aside. The issue of constitutional validity of the
Reservation Act is therefore kept open for determination in an appropriate case and on an
appropriate occasion;
 skc/dss                                                           JUDGMENT - OPINION 2797-15 25 JULY
                            (b)       I agree with the Hon'ble Mr. Justice A. A. Sayed's 
opinion dated 21st December 2016 that the GR dated 25th May 2004 to the extent it makes
provisions for reservations in matters of promotions in favour of De- Notified Tribes (A), Nomadic
Tribes (B), Nomadic Tribes (C), Nomadic Tribes (D) and Special Backward Classes is ultra vires
Article 16 (4A) of the Constitution and therefore liable to be struck down.
(c) I agree with the Hon'ble Mr. Justice A. A. Sayed's opinion dated 21st December 2016 that the GR
dated 25th May 2004 to the extent it makes provisions for reservations in matters of promotions in
favour of SC/STs is ultra vires Article 16(4A) of the Constitution for want of adherence to the
constitutional imperatives prescribed in M. Nagaraj case and therefore, the same is liable to be
struck down.Dr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

(d) With respect, I am unable to concur with the following portion of clause (ii) of the operative
portion of Hon'ble Mr. Justice A. A. Sayed's opinion dated 21 st December 2016 :
"The State Government shall take necessary corrective steps/measures within 12
weeks from today;"
(e) With respect, I am unable to concur with any of the directions in clauses (iii), (iv) and (v) of
Hon'ble Mr. Justice A. A. Sayed's opinion dated 21 st December 2016;
 skc/dss                                                                 JUDGMENT - OPINION 2797-15 25 JULY
                86]          In   terms   of   Rule   7   of   Chapter   I   of   Bombay   High   Court, 
Appellate Side Rules, let these matters be placed before the Hon'ble Division Bench.
(M. S. SONAK, J.) Chandka/SherlaDr.Vyankatesh T Anchinmane And 2 Ors vs State Of Maharashtra And 12 Ors on 25 July, 2017

