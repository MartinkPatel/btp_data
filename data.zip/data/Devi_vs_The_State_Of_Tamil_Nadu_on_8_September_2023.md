Devi vs The State Of Tamil Nadu on 8 September, 2023
Author: M.Sundar
Bench: M.Sundar
    2023:MHC:4123
                                                                                 H.C.P.No.757 of 2023
                                      IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                    DATED : 08.09.2023
                                                          CORAM
                                        THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                        and
                                       THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                  H.C.P.No.757 of 2023
                     Devi                                                           .. Petitioner
                                                            Vs
                     1.The State of Tamil Nadu
                       Rep. By its Additional Chief Secretary to Government,
                       Home, Department of Prohibition and Excise,
                       Secretariat, Fort St.George, Chennai -9.
                     2.The Commissioner of Police,
                       Avadi City Police, Commissioner Office,
                       Avadi, Chennai – 600 054.
                     3.The Inspector of Police,
                       M2 Madhavaram Milk Colony Police Station,
                       Chennai.
                     4.The Superintendent of Prison,
                       Central Prison – II, Puzhal, Chennai.                     .. Respondents
                                  Petition filed under Article 226 of the Constitution of India
                     praying for issuance of a writ of habeas corpus to call for the records in
                     No.97/BCDFGISSSV/2023 dated 12.04.2023 on the file of the second
                     respondent herein and set aside the same as illegal and produce the
                     detenu Sundarraj @ David, son of Suresh, aged 22 years, nowDevi vs The State Of Tamil Nadu on 8 September, 2023

                     Page Nos.1/9
https://www.mhc.tn.gov.in/judis
                                                                                     H.C.P.No.757 of 2023
                     confined at Central Prison – II, Puzhal, Chennai before this Court and
                     set him at liberty.
                                  For Petitioner         :     Mr.Ilayaraja Kandasamy
                                  For Respondents        :     Mr.E.Raj Thilak
                                                               Additional Public Prosecutor
                                                           ORDER
[Order of the Court was made by M.SUNDAR, J.,] Captioned 'Habeas Corpus Petition' ['HCP' for the
sake of brevity] has been filed by mother of detenu assailing a 'preventive detention order dated
12.04.2023 bearing reference No.97/BCDFGISSSV/2023' [hereinafter 'impugned preventive
detention order' for the sake of convenience and brevity] made by 'second respondent' (hereinafter
'detaining authority' for the sake of convenience). To be noted, third respondent is the sponsoring
authority.
2. Impugned preventive detention order has been made under 'The Tamil Nadu Prevention of
Dangerous Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-offenders,
Goondas, Immoral traffic offenders, Sand-offenders, Sexual-offenders, Slum- grabbers and Video
Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' https://www.mhc.tn.gov.in/judis [hereinafter
'Act 14 of 1982' for the sake of convenience and clarity] on the premise that the detenu is a 'Goonda'
within the meaning of Section 2(f) of Act 14 of 1982.
3. There are seven adverse cases. The ground case which constitutes substantial part of substratum
of the impugned preventive detention order is Crime No.118 of 2023 on the file of M-2 Madhavaram
Milk Colony Police Station for alleged offences under Sections 341, 294(b), 336, 427, 392, 397,
506(ii) of 'The Indian Penal Code (45 of 1860)' [hereinafter 'IPC' for the sake of convenience and
clarity]. Owing to the nature of the challenge to the impugned preventive detention order, it is not
necessary to delve into the factual matrix or be detained further by facts.
4. Mr.Ilayaraja Kandasamy, learned counsel on record for petitioner and Mr.E.Raj Thilak, learned
State Additional Public Prosecutor for all respondents are before us.
5. Learned counsel for petitioner predicated his campaign against the impugned preventive
detention order on the ground that https://www.mhc.tn.gov.in/judis the subjective satisfaction
arrived at by the detaining authority qua imminent possibility of detenu being released on bail is
impaired.Devi vs The State Of Tamil Nadu on 8 September, 2023

6. Elaborating on the aforementioned point on subjective satisfaction, learned counsel for petitioner
drew our attention to a portion of paragraph 4 of the impugned preventive detention order which
reads as follows:
'4...In a similar case registered at under section 294(b), 341, 323, 397, 336, 427 and
506(ii) IPC, in J-4 Kotturpuram Police Station Crime No.43/2018, the bail was
granted by the Court of Principal Sessions Judge at Chennai in
Crl.M.P.No.1759/2018. Hence, I infer that it is very likely of his coming out on bail in
M-2 Madhavaram Milk Colony Police Station Crime Nos.114/2023 and 117/2023 and
there is a real possibility of his coming out on bail in M-2 Madhavaram Milk Colony
Police Station Crime No.118/2023 case by filing bail application before the
appropriate court, since in similarly placed cases bails are granted by courts after a
lapse of time...' https://www.mhc.tn.gov.in/judis
7. Thereafter, learned counsel placed before us the grounds booklet as served on the detenu and
drew our attention to page Nos.135 to 138 thereat wherein Aravind's case bail order (similar case)
made in English by the learned Sessions Judge and what according to the Detaining Authority's
Tamil translation version were furnished to the detenu. On a perusal of the bail order in English and
the Tamil translated version brings to light that the bail order in English refers to pending cases
against the petitioner with specificity as regards years in paragraph 6 but in the Tamil translation
the same is missing.
8. Learned Prosecutor in response to the above arguments submitted that only the mentioning of
the years of pending cases with specificity is missing but otherwise the translation is largely correct.
9. We carefully considered the rival submissions. We find from the confession statement of the
detenu at page Nos.88 to 90 of the grounds booklet that the literacy level of the detenu is only 9 th
Standard in School. Therefore, it is not merely a case of improper translation it is also a case of
giving orders with different contents in https://www.mhc.tn.gov.in/judis English and Tamil version
which can baffle a person whose literacy level is only 9th Standard in School. This means that when
a detenu is baffled, his right to make an effective representation against the impugned preventive
detention order gets impaired.
10. We also remind ourselves of Powanammal case i.e., Powanammal Vs. State of Tamil Nadu,
wherein Hon'ble Supreme Court addressed to itself this translation point in a similar fact situation.
The question which the Hon'ble Supreme Court addressed to itself is captured in paragraph 6 and
the manner in which a Hon'ble Bench of the Supreme Court answered this question is captured in
paragraph 16. To be noted, Powanammal case is reported in (1999) 2 SCC 413 and paragraphs 6 and
16 {as in SCC journal} read as follows:
'6.The short question that falls for our consideration is whether failure to supply the
Tamil version of the order of remand passed in English, a language not known to the
detenue, would vitiate her further detention.Devi vs The State Of Tamil Nadu on 8 September, 2023

16. For the above reasons, in our view, the non-supply of the Tamil version of the
English document, on the facts and in the circumstances, renders her continued
detention illegal. We, https://www.mhc.tn.gov.in/judis therefore, direct that the
detenue be set free forthwith unless she is required to be detained in any other case.
The appeal is accordingly allowed. '
11. Therefore, this is a case of improper translation as well as providing documents
with different contents in two different languages impairing the detenu's right to
make an effective representation. The net sequitur is the impugned preventive
detention order is vitiated and the same deserves to be dislodged.
12. Ergo, the sequitur is, captioned HCP is allowed. Impugned preventive detention
order dated 12.04.2023 bearing reference No.97/BCDFGISSSV/2023 made by the
second respondent is set aside and the detenu Thiru.Sundarraj @ David, aged 22
years, Son of Thiru.Suresh, is directed to be set at liberty forthwith, if not required in
connection with any other case / cases. There shall be no order as to costs.
                                                                      (M.S.,J.)        (R.S.V.,J.)
                                                                             08.09.2023
                     Index : Yes
                     Neutral Citation : Yes
                     mmi
P.S: Registry to forthwith communicate this order to Jail authorities in Central
Prison II, Puzhal, Chennai.
https://www.mhc.tn.gov.in/judis To
1.The Additional Chief Secretary to Government, Home, Department of Prohibition and Excise,
Secretariat, Fort St.George, Chennai -9.
2.The Commissioner of Police, Avadi City Police, Commissioner Office, Avadi, Chennai – 600 054.
3.The Inspector of Police, M2 Madhavaram Milk Colony Police Station, Chennai.
4.The Superintendent of Prison, Central Prison – II, Puzhal, Chennai.
5.The Public Prosecutor, High Court, Madras.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL, J., mmi 08.09.2023
https://www.mhc.tn.gov.in/judisDevi vs The State Of Tamil Nadu on 8 September, 2023

