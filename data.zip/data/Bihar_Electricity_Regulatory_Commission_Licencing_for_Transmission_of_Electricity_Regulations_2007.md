Bihar Electricity Regulatory Commission (Licencing for
Transmission of Electricity) Regulations, 2007
BIHAR
India
Bihar Electricity Regulatory Commission (Licencing
for Transmission of Electricity) Regulations, 2007
Rule
BIHAR-ELECTRICITY-REGULATORY-COMMISSION-LICENCING-FOR-TRANSMISSION-OF-ELECTRICITY-REGULATIONS-2007
of 2007
Published on 5 April 2007• 
Commenced on 5 April 2007• 
[This is the version of this document from 5 April 2007.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Bihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations,
2007Published vide No. Notification No. BERC/Regl/7/06-2/2007, dated 5th April, 2007, Bihar
Gazette (Extraordinary) No. 355, dated 10.4.2007Notification No. BERC/Regl/7/06-2/2007. - In
exercise of powers conferred under Section 181 read with Sections 15,16 and 18 of the Electricity Act,
2003 (36 of 2003) and all other powers enabling the Commission in this behalf, the Bihar Electricity
Regulatory Commission hereby makes the following Regulations:
Chapter 1
Preliminary
1. Short Title, Extent and Commencement.
- (i) These Regulations shall be called the Bihar Electricity Regulatory Commission (Licencing for
Transmission of Electricity) Regulations, 2007.(ii)These Regulations extend to the whole State of
Bihar.(iii)These Regulations shall come into force on the date of their publication in the Official
Gazette of the State.
2. Definitions and Interpretation.
(1)In these Regulations, unless the context otherwise requires:-(a)"Act" means the Electricity Act,
2003 (36 of 2003).(b)"Annual Accounts" means the accounts of the Transmission LicenseeBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

prepared in accordance with the provisions of the Companies Act, 1956, and/or in such other
manner as may be directed by the Commission from time to time in terms of the provisions of the
Act.(c)"Applicant" means the person who made an application for grant of a licence for intra-state
transmission of electricity.(d)"Area of Transmission" means the area stated in the transmission
licence within which the Transmission Licensee is authorised to establish, operate and maintain
transmission lines and transmission system.(e)"Auditors" means the Transmission Licensee's
auditors, and if the Transmission Licensee is a company, auditors holding office in accordance with
the requirements of the Companies Act 1956, as amended from time to time.(f)"Commission" means
the Bihar Electricity Regulatory Commission.(g)"Distribution Licensee" means a person or a
company licensed to operate and maintain a distribution system for supplying electricity to the
consumers in the area of licence.(h)"Generator" means a person or company owning a plant or
apparatus which generates electricity and is connected to a transmission system.(i)"Regulations"
means the Regulations made by the Commission, under the provisions of the Act.(j)"Secretary"
means the Secretary to the Commission(k)"Supply" means the supply of electricity and the word
"Supplier" is construed accordingly.(l)"Transmission Licence" means a licence granted by the
Commission to a person/company under Section 14(a) of the Act for establishing, operating and
maintaining of transmission lines and transmission system in the area specified in the licence. The
words "Transmission Licensee" shall be construed accordingly.(m)"Transmission System" means a
network of interconnected extra high voltage electric lines (overhead lines and cables, transformers,
switchgear and other associated equipment and apparatus) owned or controlled by the transmission
licensee for connecting various generating stations and sub stations and distribution system for the
purpose of conveyance of electricity.(2)Words and phrases not defined in these Regulations Words
and phrases used in these Regulations and defined in the Electricity Act, 2003 shall have the same
meaning as defined therein. Words and phrases defined neither in these Regulations nor in the
Electricity Act, 2003 but defined in other Acts and laws will have the meaning as defined therein
unless the context requires otherwise. Words and phrases defined neither in these Regulations nor
in any Act (or Law) shall have the same meaning as used in general electrical engineering practice
and electricity industry.(3)Interpretation. - In these Regulations, the following shall be interpreted
as:(a)Words in the singular include the plural and vice versa(b)Words in the masculine gender
include the feminine gender and vice versa.(c)the terms "include" or "including" shall be considered
as followed by "without limitation" or "but not limited to" whether they are actually followed by
similar expressions or not in these Regulations.(d)References to these Regulations shall be
construed as references to the Regulations as amended or modified from time to time.(e)The
headings are inserted for convenience.(f)References to various Acts, Laws, Rules, Regulations and
guidelines shall be construed as including all amendments notified thereto.
Chapter 2
Procedure for Grant of Transmission Licence
3. Application for grant of Transmission Licence.
(1)Any person intending to engage in the business of transmission of electricity in the State of Bihar,
shall make an application to the Commission for grant of licence in the form specified in Appendix 1Bihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

and in the manner directed by the Commission and accompanied by such fee as may be prescribed
under Section 15(1) of the Act by the Government of Bihar.The fee shall be payable by Bank
draft/Pay order drawn in favour of Secretary/ Bihar Electricity Regulatory Commission from time to
time.(2)Any person intending to apply for licence shall duly comply with the conditions and
requirements laid down by the Commission.(3)The Commission may, if it considers necessary,
invite applications from the public fulfilling such eligibility requirements, as may be specified by the
Commission from time to time for grant of licence for transmission of electricity by a public notice
through issue of advertisements in newspapers always guaranteeing the principle of
transparency.(4)The application for grant of licence shall be signed by the applicant or by an
authorised signatory on behalf of the applicant and shall be addressed to the Secretary of the
Commission. The application shall be filed in six (6) sets accompanied by documents and particulars
required to be provided as per the application form specified in Appendix - 1 to the
Regulations.(5)The application for licence shall be supported by an affidavit duly notarised.
4. Recommendations of State Transmission Utility (STU).
(1)The applicant shall immediately on making application in manner specified above, forward a
copy of the application along with all the enclosures to the State Transmission Utility for its
recommendations.(2)The State Transmission Utility shall acknowledge receipt of the application
and shall within thirty (30) days of the receipt of said application, send its recommendations, if any,
to the Commission.(3)The State Transmission Utility shall whether it sends its recommendations or
not, submit a report to the Commission on the following aspects within thirty days of receipt of copy
of the application for grant of licence.(a)Whether the assets mentioned in the application form for
licence form part of Intra-State Transmission System.(b)Whether the assets mentioned in the
application form part of the transmission plan.(c)Whether the completion schedule mentioned in
the application is feasible, synchronizes with expansion of other parts.(d)Technical suitability of the
assets.(e)Justifiability of the estimated cost of completion indicated in the application.(f)Any other
relevant information the State Transmission Utility desire to convey to the Commission.(4)The
recommendations, if any, and report by the State Transmission Utility shall be endorsed to the
Applicant.(5)The Commission shall take into consideration the comments of the State Transmission
Utility but the recommendations and the report of the State Transmission Utility shall not be
binding on the Commission.
5. Acknowledgement of Application.
- Upon receipt of the application for grant of licence along with prescribed fee, the designated officer
of the Commission shall note thereon the date of its receipt and enter the particulars in a register to
be maintained for the purpose and allot a reference number on the application. The designated
officer shall send to the applicant an acknowledgement stating the date of receipt and the reference
number.Bihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

6. Calling for additional information.
- The Commission may, upon scrutiny of the application, require the applicant to furnish within a
period to be specified, such additional information or particulars or documents as the Commission
may consider it to be necessary for the purpose of considering the application.
7. Intimation regarding due filing of the application.
- If the Commission finds that the application is complete and accompanied by all requisite
information, particulars and documents and is in compliance with all the requirements, the
Secretary shall intimate applicant if application is ready for being considered for grant of licence, in
accordance with the procedures provided in the Act and these Regulations.
8. Publication of notice of application.
(1)The applicant shall within seven (7) days from the date of submission of application, publish
public notice in at least two daily newspapers, one in English language and other in Hindi language
having wide circulation in the area of transmission of electricity for which the licence is sought, with
the following particulars,(i)Name of the Applicant in bold at the top clearly bringing out whether the
Applicant is an individual, or a partnership firm registered under the Indian Partnership Act, 1932
(9 of 1932), or a private limited company or a public limited company, incorporated under the
Companies Act, 1956 (1 of 1956) or any other incorporated or unincorporated body giving full
particulars of its office address and also the registered office address if any;(ii)A statement that the
Applicant has submitted an application to the Bihar Electricity Regulatory Commission (BERC) for
grant of Licence for transmission of electricity in the area (to be specified) in the State of Bihar
under sub-section (1) of Section 15 of the Act.(iii)Financial and technical strength of the applicant,
management profile shareholding pattern, summary of activities and past experience in similar
activities.(iv)Proposed geographical areas within which the Applicant will undertake transmission of
electricity as stated in the application submitted to the Commission;(v)A statement to the effect that
the application and other documents filed before the Commission from time to time, are available
with the Applicant for inspection by any person;(vi)The names, addresses and other necessary
details of person(s) nominated by the applicant in major cities or towns of area of proposed
Transmission licence, who can make available for inspection the application and other documents or
from whom they can be purchased in person or by post at reasonable charges, not exceeding
photocopying charges;(vii)A statement to the effect that complete application is available on the
website of the Applicant or any other authorised website and can be downloaded free of cost;(viii)A
statement that objections and suggestions if any, may be filed before the Secretary, BERC within 30
days from the publication of the notice giving full address of office of the Commission:Provided that
the applicant may request the Commission to permit it to refrain from publishing any of the above
information in order to protect its business interests or rights in intellectual property with sufficient
and reasonable grounds and the Commission may grant such request after due
consideration:Provided further that the Applicant may be required to publish, in the manner
specified, a non-confidential summary of the above information.(2)The applicant shall within seven
days from the date of publication of the aforesaid notice submit to the Commission an affidavit withBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

the details of the notice published alongwith copies of the relevant newspapers in which the notices
have been published.
9. Service of notice of the application.
(1)The Commission may direct that notice of the application be served on any designated
representative of the Central Government, the State Government, any local authority or any other
authority or person or body as the Commission may deem appropriate.(2)Any person who has made
an application for grant of licence shall, within seven days after making such application, publish a
notice of his application with such particulars and in such manner as may be specified and a licence
shall not be granted -(a)until the objections, if any, received by the Commission in response to
publication of the application have been considered by it:Provided that no objection shall be so
considered unless it is received before the expiration of thirty days from the date of the publication
of such notice as aforesaid;(b)until, in the case of an application for a licence for an area including
the whole or any part of any cantonment, aerodrome, fortress, arsenal, dockyard or camp or of any
building or place in the occupation of the Government for defence purposes, the Appropriate
Commission has ascertained that there is no objection to the grant of the licence on the part of the
Central Government.
10. Public Inspection of Application and Documents.
(1)The applicant shall make available for public inspection copies of the application (with all
enclosures), for grant of licence in his own office and also in the offices of the local authorities
located in the proposed area of the transmission licence.(2)The applicant shall also supply a copy of
the application to any person who requisitions for it on payment of the cost which shall not exceed
the cost of photocopying.
11. Objections.
(1)Any person intending to object to the grant of transmission licence shall file objections by way of
affidavit within thirty (30) days from the date of issue of publication of the notice referred to in
Regulation 8(1) above annexing thereto proof of having served copy of such objection upon the
applicant. The objections shall be addressed to the Secretary of the Commission.(2)The Secretary
shall serve copies of all objections received by him to the applicant within one week from the last
date for filing of objections specified in sub clause (viii) of Regulation 8(1) above.(3)The applicant
shall submit comments on the objections received in response to the notice within fifteen (15) days
of receipt of the copies of the objections from the Secretary.
12. Hearing and local inquiry.
(1)Upon compliance by the applicant of all the conditions pertaining to the submission of
documents, obtaining of permissions and publication of the notice and upon the expiry of the time
for filing of the objections is over, the Commission may consider the application through a hearingBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

or without hearing as it considers appropriate.(2)(a)If any person objects to the grant of licence
applied for under the Act, the Commission may, if it considers necessary, cause a local inquiry to be
held for which the notice in writing shall be given to the applicant and the objector and concerned
parties, if any(b)Where a local enquiry is ordered and held under clause (a) above, the Commission
shall in its order requiring the local enquiry or by further order in writing, specify the time within
which the local enquiry is to be completed:Provided that the Commission may, for reasons to be
recorded in writing, extend the time fixed by it for the local enquiry.(c)In case a local inquiry is
ordered and conducted under Regulation 12(2)(a) above, a memorandum of the result of the
enquiry made shall be prepared and signed by the applicant, objector, the Officer or person
designated for the purpose and such other person as the Commission may direct.(d)The result of the
local enquiry shall be considered by the Commission while hearing the application for grant of
Licence.(3)The Commission on deciding to follow a public hearing shall give notice of hearing
intimating the name of person filing objection, place, date and time of hearing to the applicant, the
Central Government, the State Government, the local authority and such other authority, person or
body as the Commission considers appropriate.
13. Grant of Transmission Licence.
(1)Before granting a licence under Section 14 of the Act, the Commission shall publish a notice in
two daily newspapers one in English and other in Hindi language having wide circulation in the area
for which licence is sought, stating the name and address of the person to whom it proposes to issue
the licence;(2)After hearing, under Regulation 12, the Commission may decide to grant or refuse to
grant licence and if it decides to grant licence, it may do so on general terms and conditions and with
such modifications to the general conditions and on such specific conditions as the Commission may
decide:Provided that the Commission in no event shall reject an application without giving applicant
an opportunity of being heard, either by requiring the applicant to file response in writing or by
conducting an oral hearing.(3)When Commission has approved grant of transmission licence, the
applicant shall be informed of such approval and also the conditions to be satisfied by the applicant
including the initial and annual licence fees to be paid by the applicant for grant of the licence. The
licence and the condition of licence shall be in the form specified in Appendix -2 of these
Regulations:Provided that the Commission may add or alter or amend the form specified for a
licence as it may at its discretion, deem necessary.(4)On receiving an intimation in writing from the
applicant that he is willing to accept a licence on the terms approved by the Commission and after
the applicant satisfies the conditions imposed for grant of the licence, the Commission may direct
the applicant to publish licence or such part thereof in abridged form as the Commission considers
to be appropriate.(5)The Commission may issue a licence for intra-state Transmission of electricity
on being satisfied that the Applicant qualifies for issue of such licence under the provisions of the
Act, rules and regulations for the time being in force.(6)The Commission shall immediately after
issue of a licence, forward a copy of the licence to the Government of Bihar, State Transmission
Utility, Central Electricity Authority, local authority, and to such other person/body as the
Commission considers necessary.Bihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

14. Date of commencement and duration of licence.
(1)The licence shall commence from the date which the Commission may direct for its
enforcement.(2)The licence shall be in force for a period of twenty five years, from the date of
commencement unless it is revoked by the Commission.
15. Deposit of maps and proforma.
(1)When a licence has been granted, four (4) sets of maps and proforma containing the particulars
specified in clause (2) below shall be signed and dated to correspond with the date of the notification
of the grant of the licence.(2)The particulars to be given in the proforma under clause (1) above shall
be as under:-(a)A short title descriptive of the proposed utility together with the address and
description of the applicant, and if the applicant is a company, the names of all the Directors of the
company;(b)Type of licence granted;(c)Location of the proposed area of operation;(d)A description
of the proposed area of operation; and(e)The general conditions, the deviation therefrom and also
the specific conditions, if any, which the Commission has laid down in the licence with justification
for any deviation granted from general conditions;(3)While Two sets of such maps and proforma
shall be deposited with the Commission, one set each shall be deposited with STU and transmission
licensee after due attestation by the Secretary or an officer authorised by the Secretary in this
behalf.(4)The licensee, whenever required by the Commission shall furnish maps and proforma in
an electronic form.
16. Deposit of printed copies of licence.
(1)Every person who is granted a licence shall within thirty days of the grant thereof arrange to keep
the following as specified by Central Electricity Authority.(a)adequate number of copies of the
licence printed;(b)adequate number of maps prepared showing the area of activity or area of supply
as specified in the licence;(c)a copy of such licence and maps for public inspection at all reasonable
times at his head office, at his local offices (if any) and at the office of every local authority within the
area of activity or area of supply as the case may be.(2)Every such licensee shall, within the aforesaid
period of thirty days, supply free of charge one copy of the licence and the relevant maps to every
local authority within the area of activity or area of supply as the case may be, and shall also make
necessary arrangements for the sale of printed copies of the licence to all persons applying for the
same, at a price not exceeding normal photocopying charges thereof.
17. Amendment of the Transmission Licence.
(1)The Commission may initiate proceedings for amendment of a transmission licence suo motu or
on an application of the transmission licensee or on receiving complaint or information from any
person.(2)The application for amendment of the licence made by the licensee, shall be in such form
as may be directed by the Commission. Such application shall be accompanied with a statement of
the proposed amendment and shall be supported by an affidavit.(3)The applicant shall within seven
(7) days from the date of admission of the application for amendment, publish a notice in two dailyBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

news papers, one in English language and other in local language, having wide circulation in area of
operation of the transmission licence sought to be amended, giving the following particulars:(i)Brief
Details of existing Transmission Licence;(ii)Proposed amendments to the existing Transmission
Licence; and(iii)Brief reasons for seeking the amendment.(iv)The names, addresses and other
necessary details of the person(s) nominated by the applicant in major cities or towns of area of
proposed transmission licence, who can make available for inspection application and other
documents or from whom they can be purchased in person or by post at reasonable charges, not
exceeding photocopying charges;(v)A statement that any person, desirous of making any suggestion
or objection to the proposed amendment, may do so by filing written petition in six copies addressed
to the Secretary within thirty days from the date of the first publication of the notice.(4)Where an
amendment to a Transmission Licence is proposed by the Commission suo motu, the Commission
shall publish a notice in two daily newspapers one in English language and the other in Hindi
language having wide circulation in the area of operation of the Transmission Licence sought to be
amended, giving the following particulars:(i)Name of the Transmission Licensee and address of
main office in the area of supply;(ii)Description of alteration or amendment proposed to be made by
the Commission;(iii)Brief reasons for proposed alteration or amendment;(iv)A statement that any
person, desirous of making any suggestion or objection to the proposed amendment, may do so by
filing written petition in six copies addressed to the Secretary within thirty days from the date of the
first publication of the notice.All objections to the proposed amendment, received within one month
from the date of first publication of notice, shall be considered by the Commission before effecting
or rejecting the proposed amendment.(5)Unless otherwise specified in writing by the Commission,
the procedure specified in these Regulations for grant of licence, in so far it can be applied, shall be
followed while dealing with an application for amendment of the licence.(6)In case of an application
proposing alterations or modifications in respect of area of supply, comprising the whole or any part
of any cantonment, aerodrome, forests, dockyard or camp or of any building or place in the
occupation of the Government for defence purpose, the Commission shall not make any alterations
or modifications except with the consent of Central Government.
18. Contravention by Transmission Licensee.
- The Commission may pass such orders as it thinks fit in accordance with the provisions of the Act
and these Regulations if there is a contravention of the terms and conditions of licence by the
Licensee.
19. Revocation of the Transmission Licence.
(1)The Commission may revoke a transmission licence on its own or on application of the Licensee
or on receiving any complaint from any person in accordance with the provisions of the Act, and,
these Regulations in any of the following circumstances;(i)Where the conditions and circumstances
under which the licence was granted no longer exist.(ii)Where the Commission concludes, after
enquiry, that the licensee willfully defaulted in carrying out his duties under the Act or the rules or
regulations made thereunder or under the terms and conditions of the licence or has failed to
comply with the directives of the Commission.(iii)Where the circumstances of the licensee as
perceived by the Commission indicate that the licensee's financial, managerial and technicalBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

capabilities are no longer adequate for fulfilling his duties and discharging obligations under the Act
and conditions of the licence.(iv)Where the licensee persistently fails to fulfill his part in
maintaining Grid Standards and, as a result, the distribution systems and the generating units are
jeopardized and quality of supply to consumers suffers frequently and the licensee does not take
corrective action.(2)The licence shall not be revoked unless a thorough enquiry is conducted by the
adjudicating officer appointed by the Commission under Section 143 of the Act.(3)The Licensee
shall be given not less than three months' notice stating clearly the grounds on which the
Commission proposes to revoke the licence.(4)If the Commission decides to revoke the licence, the
Commission shall serve a notice of revocation upon the licensee stating the effective date from
which such revocation shall take effect. The Commission shall also forward a copy of the order of
Revocation to the State Government, STU, CEA, Local Authority and to such other person/body as
the Commission considers it necessary.(5)The Commission may instead of revoking the licence pass
any other order in foisting such terms and conditions subject to which the licensee shall be
permitted to operate his business.(6)When Commission has given notice of revocation of licence
and the licensee is willing to relinquish his licence (and does not plan to take remedial and
improvement measures and does not request the Commission to drop revocation proposal), the
licensee may, after prior approval of the Commission, sell the undertaking of the Licensee to any
person/company which is found eligible by the Commission for grant of transmission licence,
without prejudice to any proceedings which may be or has been initiated or any penalty which may
be imposed by the Commission.
20. Deemed grant of the Transmission Licence.
(1)Until otherwise directed by the Commission, any person engaged in the business of transmission
of electricity under the provisions of the repealed laws or any Act shall be deemed to have applied
for and granted the Transmission Licence under the first provision to Section 14 of the Act, and
subject to the fulfillment of the conditions contained in Regulation 20(2)(2)The licensee under
Regulation 20(1) shall:(i)not directly or indirectly undertake trading in electricity or transmission or
supply of electricity outside its area of operation and transmission and supply of electricity shall be
strictly restricted to the relevant approved purpose;(ii)establish the electric line or works only within
the area of operation;(iii)furnish to the Commission such information required by the Commission
for the purposes of the discharge of the functions of the Commission as the Commission may from
time to time direct;(iv)comply with the provisions of the Act, the Regulations of the Commission,
technical codes such as Grid Code, Supply Code, Standards of Performance or any other guidelines
issued by the Commission;(v)comply with all applicable rules and regulations concerning the safety
and security of the operation; and(vi)comply with any directions which the Commission may issue
from time to time in regard to the charges which licensee may levy on the consumers taking into
account the charges prevailing in the nearby area of supply of electricity supplied by a
licensee.(3)The Commission shall be entitled to issue appropriate directions from time to time as it
may consider it to be necessary and take appropriate action against a licensee under this Regulation
in accordance with the provisions of the Act for any breach of conditions of license.(4)The
Commission may, by an interim or final order, direct the Licensee under this Regulation to cease to
transmit electricity in the area of operation or any part thereof.(5)If any difference or dispute arises
as to whether the person is entitled to undertake transmission of electricity as a Licensee underBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

these Regulations, the decision thereon of the Commission shall be final.
Chapter 3
Miscellaneous
21. Savings.
(1)Nothing in these Regulations shall be deemed to limit or affect the power of the Commission to
issue such directives or orders as may be necessary to meet the ends of justice or to prevent abuse of
the procedures laid down by the Commission.(2)Nothing in these Regulations shall bar the
Commission from adopting in conformity with the provision of the Act, a procedure which is at
variance with any of the provisions of these Regulations if the Commission for reasons to be
recorded in writing deems it necessary or expedient for dealing with such matter or class of
matters.(3)Nothing in the Regulations shall, explicitly or impliedly, bar the Commission from
dealing with any matter or exercising any power under the Act for which no Regulation have been
framed and the Commission may deal with such matters with powers and functions in such a
manner as it thinks fit.
22. Power to Remove Difficulties.
- Whenever any difficulty arises in giving effect to any of the provisions of these Regulations, the
Commission may by general or special order take any action, necessary in its opinion, for removing
such difficulty:Provided that such action of the Commission shall not be inconsistent with the
provisions of Act.
23. Power to Amend.
- The Commission may, at any time, add, vary, alter, modify or amend any of the provisions of these
RegulationsAppendix-1Application form for grant of Transmission LicenceParticulars of the
Applicant
1. Name of the Applicant:
2. Form of Incorporation, if any:
3. Address:
4. name, Designation & Address of the contact person :Bihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

5. Contact Tel. Nos.:
6. Fax No.:
7. E-mail ID:
8. Place of Incorporation/Registration :
9. Year of Incorporation/Registration :
10. Geographical Area within which proposes to undertake transmission :
11. Following documents are to be enclosed :
(a)Certificate of registration/incorporation :(b)Certificate of commencement of business
:(c)Memorandum of Association and Articles of Association :(d)Original power of attorney of the
signatory to commit the Applicant or its promoter:(e)Details of Income Tax Registration :(f)All the
documents required in the Regulations :
12. Details of Financial Data of Applicant. - Not worth (in equivalent Indian
Rupees-conversion to be done at the rate of exchange prevailing at the end
of each year) for immediate past 5 (five) financial years (Specify financial
year as applicable)
DD/MM/YY to DD/MM/YY In Home Currency Exchange rate used In equivalent Indian Rupees
    
    
    
    
Copies of Annual Reports or certified audited results to be enclosed in support of above.
13. Annual Turnover (in equivalent Indian Rupees. - conversion to be done at
the rate of exchange prevailing at the end of each year) for immediate past 5
(five) financial years. (Specify financial year as applicable)
DD/MM/YY to DD/MM/YY In Home Currency Exchange rate used In equivalent Indian Rupees
    
    
    
    Bihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

Copies of Annual Reports or certified audited results to be enclosed in support of above.
14. Certificate of Credit Rating
15. Certificate of 'Standard' borrowal account
16. Certificate stating that RBI has not classified the Applicant as a 'wilful
defaulter'.
17. List of documents enclosed in support of SI. Nos. (10) and (11) above:
Name of the document(a)(b)(c)(d)18. (a) Whether Applicant himself shall be financing the proposed
transmission of electricity fully on its own balance sheet(a)If Yes, proposed equity from the
Applicant(i)Amount(ii)Percentage
19. In case the Applicant proposes to tie up with some other Agency for
equity, then name & address of such agency :
(a)Name, designation & address of reference person of the other Agency:(b)Contact Tel No.:(c)Fax
No.:(d)E-mail ID:(e)Proposed equity from the other Agency(i)Amount(ii)Percentage of total
equity(iii)Currency in which the equity is proposed(f)Consent letter of the other agency to associate
with the Applicant for equity participation to be enclosed.(g)Nature of proposed tie-up between the
applicant and the other agency.
20. Details of debt proposed for the transmission activity:
(a)Details of lender:(b)Amount to be sourced from various lenders :(c)Letters from the lenders in
support of the above to be enclosed.
21. Organisation & Managerial Capability of the Applicant : (The Applicant is
required to enclose proof of their Organisational & Managerial Capability, in
terms of the Regulations, in form of proposed organizational structure &
curricula vitae of various executives proposed office and communication
facilities, etc.).
22. Approach & Methodology: (The Applicant is required to describe
approach & methodology for setting up its transmission system and conduct
of the business of transmission of electricity as proposed by it. This should
contain a statement of the Applicant's plan on conduct of the business of
transmission of electricity during the first year after the grant of licence andBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

future plans for the said business during the next five years.)
23. Data relating to the applicant's future business :
(h)Five year Business Plan for transmission or distribution of electricity for which the application is
being made and funding arrangements for meeting its obligations under proposed licence for
maintenance, operation, improvement and expansion for future load growth.(i)Five year annual
forecasts of costs, sales, revenues and project financing stating the assumptions underlying the
figures provided.(Signature of the Applicant)Dated:Appendix-IITransmission LicencePart -1
Transmission Licence1.1The Bihar Electricity Regulatory Commission under Section 14 of the
Electricity Act, 2003 hereby grants this licence to M/s.....................having its registered office
at...................to construct, maintain and operate intra-state transmission lines, substations and
associated installations described in the Schedule attached to this licence and with the powers and
upon the terms and conditions specified here in. The terms and conditions of this licence are the
sum total of the terms and conditions specified in this licence and those specified in the Bihar
Electricity Regulatory Commission (Granting of Licence for Transmission of Electricity)
Regulations, 20061.2The licence is not transferable1.3The grant of licence to the licensee shall not in
any manner restrict the right of the Commission to grant a licence to any other person within the
same area for the transmission system other than the project described in the schedule attracted to
this licence. The licensee shall not claim any exclusivity.1.4The licence shall, unless revoked earlier,
continue to be in force for a period of 25 (twenty five) years from the date of issue.
2. Definitions.
2.1Unless the context otherwise requires in these conditions:-"Accounting Statement" means, for
each financial year, accounting statements comprising a profit and loss account, a balance sheet and
a statement of sources and application of funds, together with notes thereto and such other
particulars and details and in the manner as the Commission may direct from time to time and
showing that(i)charged from the Licensed Business to any Other Business or vice versa together
with a description of the basis of that charge; or(ii)determined by apportionment or allocation
between the LicensedBusiness and any Other Business of the Transmission Licensee together with a
description of the basis of the apportionment or allocation."Act" means the Electricity Act, 2003 (36
of 2003)."Annual Accounts" means the accounts of the Transmission Licensee prepared in
accordance with the provisions of the Companies Act, 1956, and/or in such other manner as may be
directed by the Commission from time to time in terms of the provisions of the Act;"Area of
Transmission" means the area stated in the Transmission Licence within which the Transmission
Licensee is authorised to establish, operate and maintain transmission lines;"Auditors" means the
Transmission Licensee's auditors, holding office in accordance with the requirements of Sections
224 to 234A or Section 619 as appropriate of the Companies Act, 1956 (1 of 1956)."Authorised" in
relation to any person, business or activity, means authorised by licence granted under Section 14 of
the Act or deemed to be granted under the first, second, third and fifth proviso to Section 14 of the
Act or exemption granted under Section 13 of the Act;"Central Commission" means the Central
Electricity Regulatory Commission constituted under Section 3 of the Electricity Regulatory
Commission Act, 1998."Commission" means the Bihar Electricity RegulatoryBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

Commission."Consumer" means the end or final user of electricity;"Deemed Licensee" means the
person authorized under the first, second, third and fifth provisos to Section 14 of the
Act;"Distribution" means the conveyance or wheeling of electricity by means of a Distribution
System;"Force Majeure" means events beyond the reasonable control of the Licensee including, but
not limited to earthquake, cyclone, flood, storm, war, terrorist attack, civil commotion or other
similar occurrence that lead to any act that would involve a breach of relevant laws or regulations
concerned with electrical safety;"Generating Set" means any plant or apparatus for the production
of electricity and shall, where appropriate, include a generating station comprising of one or more
than one generating unit;"State Grid Code" means the Grid Code specified by the Commission in
accordance to Section 86(l)(h) of the Act covering all material technical aspects relating to
connections to and the operation of the Grid and the use of a Transmission System, and in so far as
relevant to the operation and use of a Transmission System, the operation of electric lines and
electrical plant connected to the Transmission System, the Distribution Systems, or the system of
any supplier."Intervening Transmission Facilities" means the electric lines owned or operated by a
Transmission Licensee where such electric lines can be utilized for transmitting electricity for and
on behalf of another licensee;"Licensed Business" means the business of Transmission of electricity
as authorised under the Transmission licence;"Major Incident" means an incident associated with
the Transmission of electricity, which results in a significant interruption of service, substantial
damage to equipment, or loss of life or significant injury to human beings, or as otherwise directed
by the Commission and shall also include any other incident which the Commission expressly
declares to be a major incident;"Operational Control" means possessing the authority to make
operational decisions such as commissioning and utilisation of units, transmission lines and
equipment."Other Business" means Business of the Transmission Licensee other than the Licensed
Business."Performance Standard" means the standards as may be determined by the Commission
pursuant to Section 57 of the Act;"Person" Shall include any company or body corporate or
association or body of individuals, whether incorporated or not, or artificial juridical
person;"Regulations" means the Regulations made by the Commission, under the provisions of the
Act;"State" means the State of Bihar"State Government" means the Government of Bihar."Transfer"
shall include the sale, exchange, gift, lease, licence, loan, securitisation, mortgage, charge, pledge or
grant of any other encumbrance or otherwise permitting any encumbrance to subsist or parting with
physical possession or any other disposition or dealing;"Transmission Business" means the
Authorised business of a Transmission Licensee to transmit electricity through any system owned
and/or operated by such Licensee;"Transmission Operating Standards" means the standards related
to the Transmission Licensee's operation of the Transmission System as approved by the
Commission;"Transmission Planning and Security Standards" means the standards related to the
adequacy of the Transmission Licensee's system planning and security of its Transmission System
as approved by the Commission;"Transmission System" means the system consisting mainly of
extra high voltage electric lines having nominal voltage of 66 kV and higher and shall include all
plant and equipment in connection with transmission, owned or controlled by the Transmission
Licensee."Use of System" means use of the Transmission System for the transportation of electricity
for any person pursuant to a contract entered into with the Transmission Licensee;"Users" means
any one who uses the Transmission System.2.2Words, terms and expressions to which meanings are
assigned by Act shall have the same meaning in these ConditionsBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

3. Terms of the Licence
3.1The Transmission Licence shall come into force on the date mentioned by the Commission in the
order granting licence on specified terms and conditions and shall remain in force for a period of
twenty five years.3.2The terms and conditions specified in licence are subject to modifications or
amendments to be made by the Commission in accordance with the provisions of the Act or this
Licence.
4. Compliance with Laws, Rules and Regulations. - (1) The Transmission
Licensee shall comply with the provisions of the Act and the Rules made
thereunder and Regulations, orders and directions issued by the
Commission from time to time and the provisions of all other applicable laws.
(2)The Transmission Licensee shall act in accordance with these General Conditions except where
the Transmission Licensee is exempted from any provisions of these General Conditions at the time
of the grant of licence or otherwise specifically obtains approval of the Commission for any deviation
therefrom.(3)The Transmission Licensee shall duly comply with the orders and directions of the
National Load Despatch Centre, Regional Load Despatch Centre and the State Load Despatch
Centre and other functions under the Act.
Part II – General Conditions
5. Directions. - The Licensee shall always comply with the Regulations,
Orders and Directions issued by the Commission from time to time and shall
also so act in accordance with the terms of this Licence, except where the
Licensee obtains the approval of the Commission for any deviation of such
directions and terms.
6. Activities from which the transmission licensee is prohibited. - The
licensee shall be prohibited from carrying out following activities:-
(1)The licensee shall not acquire any interest in the business of a distribution license.(2)The licensee
shall not, either directly or through its subsidiary, engage in the business of trading of
electricity.(3)When the licensee is engaged in "Other Business" (reference: Section 41 of the Act) the
main transmission business shall not subsidize the "Other Business".
7. Activities requiring prior consent. - The licensee shall obtain prior approval
of the Commission before carrying out the following:-
(1)undertaking any transaction to acquire by purchase or take over or otherwise the utilities of any
transmission licensee.(2)merge his utility with the utility of any other transmissionBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

licensee(3)assign his licence or transfer its utility or any part thereof to any person by sale, lease,
exchange or otherwise.
8. Activities of the Licensee. -
8.1The Licensee shall perform his duties stipulated in Section 40 of the Act and fulfill the terms and
conditions stipulated in the licence.8.2The Licensee shall build, maintain and operate an efficient
coordinated transmission system.8.3The licensee shall operate the transmission system
economically so that the transmission charges can be kept minimum and thereby the component of
transmission cost in the tariff is also kept minimum.8.4The Licensee shall operate the transmission
system in such a manner that the parameters are maintained in the ranges prescribed in the Central
Electricity Authority's Grid Standards all the time and ensure that the system is available at all times
for generators to inject power (of agreed quantum) and for distribution licensees to draw power (of
agreed quantum).8.5The licensee shall co-ordinate with Regional Power Committee, Regional and
State Load Despatch Centres, Central Transmission Utility, State Transmission Utility, generating
companies and licensees to ensure uninterrupted supply to the consumers.8.6The licensee shall
obtain prior written approval from the Commission before entering into any agreement with
another company for supply of power to consumers in his area.8.7The licensee shall maintain up to
date records of energy transmitted by each element of the system and produce the same to the
Commission whenever required.8.8The licensee shall establish adequate communication and
information system facilities before commencing transmission.8.9The licensee shall act in a prudent
and reasonable manner in utilization of the licence for obtaining credit facilities.8.10The licensee
shall under all circumstances retain operational control over his assets in the case of mortgage of his
assets.8.11The Licensee shall seek approval of the Commission before advancing loans, or issuing
any guarantee for any obligation of any person except when made or issued for the purposes of the
Licensed Business, however loans to employees pursuant to their terms of service and advances to
suppliers in the ordinary course of business are excluded from the requirement to seek such
approval.8.12The Licensee may engage any affiliate to provide any goods or services to the licensee,
in connection with its transmission business, subject to the following conditions.(a)the transaction
will be on an arms-length basis;(b)the transaction will be structured consistent with any regulation
framed by the Commission relating to the provision of goods and services with respect to the
transmission business; and(c)licensee will give 15 days notice to the Commission prior to
commencement of the proposed arrangement.
9. Other Business.
- The business(es) which the licensee carries out other than the main transmission business for full
utilization of his assets shall be termed "Other Business".9.1The licensee shall carryout Other
Business for optimum utilization of its assets with prior intimation to the Commission.9.2The
licensee shall carry out the Other Business in a way that the main transmission business is not
prejudiced or adversely affected by the Other Business.9.3The transmission assets shall not be
encumbered to support the Other Business.9.4The licensee shall not give any subsidies to support
Other Business.9.5A proportion of the revenues derived from such Other Business shall be utilized
for reducing the transmission charges.9.6The licensee shall not enter into any contract or otherwiseBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

engage in the business of trading of electricity.9.7Separate accounts shall be maintained for the
main transmission business and each of Other Businesses such that of revenues, expenses, assets
and liabilities pertaining to each of the Other Businesses can be identified and distinguished from
those of the licensed business (transmission).
10. Accounts.
10.1(a)The financial year of the licensee shall run from the first of April to the following 31st of
March.(b)If the Companies Act, 1956 is applicable to the licensee, the licensee shall maintain
separate accounts both to satisfy the requirements of the Commission and the Companies Act,
1956.(c)The licensee shall prepare accounting statements in full shape and transmit them to the
auditors.(d)The licensee shall take necessary corrective action to rectify the defects in activities and
method of maintaining accounts based on the auditors' report.(e)The licensee shall submit to the
Commission, copies of the accounting statements and auditors' report for the licensed business and
also each of the Other Businesses within the time limit specified by the Commission.10.2The
licensee shall cooperate with, and assist any officer deputed by the Commission to verify the
licensee's accounts.10.3The licensee shall publicise accounts statements and auditors' report for
each financial year in the manner the Commission directs and make them available at a price equal
to the cost of duplication.
11. Prohibition of Undue Reference
11.1The licensee shall not show undue preference to any person.11.2The licensee shall furnish to the
Commission without undue delay such information, documents and details related to the licensed
business or any Other Business of the Licensee as the Commission may require for its own purpose
or for the purpose of the Government of India, State Government, Central Commission and Central
Electricity Authority.
12. Major Incidents
12.1The licensee shall notify to the Commission any major incident that has occurred in the area of
the transmission licensee. A deviation from any part of the transmission system from standard
operating condition which was triggered by cross boundary effect, in the system of generators,
distribution system or in the system of extra high voltage consumers which has resulted in the loss
of equipment or life of a person or animal, shall be deemed a major incident. The licensee shall
also.(a)submit a detailed report giving facts of the incidents, the causes and the adverse effects on
the total power system. (The total power, system comprises the transmission system, generating
units, distribution systems and the systems of the EHT consumers).(b)submit a note containing the
licensee's analysis of the major incident and suggestions for carrying out remedial measures for
preventing recurrence of such major incidents.(c)send copies of the report and note to the State
Load Despatch Centre, State Transmission Utility, State Government, and Chief Electrical
Inspectorate etc.12.2The decision of the Commission whether a particular incident is a major
incident or not would be final.12.3On an incident brought to its notice, the Commission may direct
the licensee to submit a report. In such a case the licensee shall submit a detailed report and alsoBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

suggest remedial measures to be taken, to the Commission.12.4The Commission may direct an
independent person to investigate in the case of a major incident and submit his report.12.5The
Commission may analyse the report and the information received from all sources and will decide
whether a major incident is a Force Majeure event or is caused by violation of conditions of licence
or provisions of Grid Code or provisions of the Act or the rules and regulations under the
Act.12.6The Commission may decide the following:-(i)Remedial measures to be taken by one or
more operators (or owners) of the parts of the total power system (including the transmission
licensee) to prevent recurrence of similar major incidents.(ii)Punitive measures to be imposed on
one or more persons for lapses which caused the major incident.(iii)Compensation to be paid by one
party to another party [by the owner (or operator) of a segment of the total power system to the
owner (or operator) of another segment of the total power system].12.7The Commission shall send
its views and decisions on the major incident to the State Load Despatch Centre, Chief Electrical
Inspector, State Transmission Utility etc.
13. Investments
13.1The Licensee shall not make any investment under any scheme or schemes except in an
economical and efficient manner and in terms of this Licence and in accordance with the
Regulations, guidelines, directions and orders, the Commission which may issue from time to
time.13.2The Licensee shall promptly notify the Commission, schemes in relation to the
Transmission System which the Licensee from time to time proposes to implement together with
relevant details, including the estimated cost of such schemes, with requisite break-up and proposed
investment plans. The Licensee shall furnish to the Commission such further details and
clarification as to the schemes proposed as Commission may require from time to time. The
schemes proposed may be implemented by Licensee subject to the following conditions.(a)If the
scheme does not involve major investment as defined hereunder without need for any specific
approval from the Commission but subject however to any reasonable direction or condition which
the Commission may give or impose during implementation of the scheme.(b)If the scheme involves
major investment after taking prior approval of the Commission as provided in condition
13.3.(c)The term "major investment" means any planned investment in or acquisition of
transmission facilities, the cost of which, when aggregated with all other investments or acquisitions
(if any) forming part of the same overall transaction, equals or exceeds Rupees 500 lakhs.13.3The
Licensee shall make an application for obtaining prior approval of the Commission for schemes
involving major investments as per the procedure which the Commission may specify from time to
time and demonstrate to the satisfaction of the Commission that,(a)there is a need for the major
investment in the Transmission System which the Licensee proposes to undertake.(b)the Licensee
has examined the economic, technical, system and environmental aspects of all viable alternatives to
the proposal for investing in or acquiring new transmission system assets, to meet such need
and:(c)the Licensee has invited and finalised tenders for procurement of equipment material and/or
services relating to such major investment in accordance with a transport tendering procedure as
may be specified by the Commission from time to time.13.4The Licensee shall submit to the
Commission along with the "Expected Revenue Calculation", the annual investment plan for
ensuing financial year and shall make investment in the said financial year in accordance with the
said investment plan. In case of unforeseen contingencies, reallocation of funds within the schemesBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

listed in the annual investment plan, the Licensee may do so provided such reallocation in respect of
individual projects does not exceed Rs. 500 lakhs, and Commission has been duly informed. If on
account of unforeseen circumstances the Licensee is required to make investment in a scheme which
does not find a place in the annual investment plan, the Licensee may do so upto the limit of Rs. 500
lakhs after intimating the Commission.
14. Transfer of Assets
14.1The Licensee shall not, in a single transaction or a set of related transactions, transfer or
relinquish Operational Control over any land, building, or other asset whose book value at the time
of the proposed Transfer exceeds Rs. 500 lakhs, without complying with the following:14.2The
Licensee shall give to the Commission prior written notice of its intention to transfer or relinquish
Operational Control over any asset whose value exceeds Rs. 500 Lakhs and disclose all relevant
facts. The Commission may, within 30 days of the receipt of the notice seek further information in
support of the transaction and shall, generally within 30 days of such further information being
submitted by the Licensee, and where no such further information is sought by the Commission as
above, within 60 days of the filing of the application, allow the transfer arrangement subject to such
terms and conditions on modifications as considered appropriate or reject the same for reasons
recorded in writing in the order.14.3The Licensee may transfer or relinquish Operational Control
over any asset as is specified in any notice given under above condition 14.2 if(a)the Commission
confirms in writing that it consents to such Transfer or relinquishment of Operational Control
subject to such conditions as the Commission may impose, or14.4The Licensee may transfer or
relinquish Operational Control over any asset where(a)The Commission has issued direction
containing a general consent (whether or not subject to conditions) to(i)Transactions of a specified
description and/or(ii)Transfer or relinquishment of Operational Control over assets of a specified
description, and/or(iii)Transfer or relinquishment of Operational Control is in accordance with any
conditions to which the consent is required(b)Transfer or relinquishment of Operational Control in
question is required by or under the mandate of any other Act or(c)Asset in question was acquired
and used by the Licensee exclusively or primarily in connection with any Other Business and it has
been authorised to carry on and does not constitute a legal or beneficial interest in land or otherwise
form part of the Transmission System or is not otherwise an asset required for the Licensed
Business.14.5Notwithstanding what is stated above the Licensee will be entitled to utilise the assets
as a means of facilitating funding or financing the Licensed Business in the ordinary course of
business, subject to the conditions.(a)That the Licensee will inform the Commission about such
arrangements at least 15 days prior to the effective date of the relevant agreements.(b)The Licensee
acts in a prudent and reasonable manner in such utilisation of assets.
15. Rights of the Licensee
(a)The licensee may erect and commission overhead transmission lines, lay cables of transmission
voltage and construct substations in accordance with the transmission plans in order to fulfill the
conditions stipulated in the licence. He shall comply with the safety regulations issued by the
Central Electricity Authority and relevant laws under Sections 67, 68 and 69 of the Act in acquisition
of land for lines and substations and while executing works.(b)The licensee shall inform theBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

Commission and STU whenever construction work on a new transmission component is
commissioned.
16. Payment of Licence Fee
16.1Within such period as the Commission may direct, after coming into force of this licence, the
Transmission Licensee shall pay to the Commission an initial fee as specified by the Commission on
a prorata basis for the balance period of the financial year or and in such manner as directed by the
Commission.16.2As long as licence remains in force, the licensee shall be liable to pay to the
Commission an annual fee as specified by the later on or before 15th April of every year. The
Commission may review the quantum of annual licence fee after every three years.16.3Where the
licensee fails to pay to the Commission any of the fees due under conditions 16.1 or 16.2 by the due
dates:(a)the licensee shall be liable to pay to the Commission interest on the outstanding amount at
a simple interest rate of 1.5 percent per month, the interest being payable for the period beginning
on the day after which the amount became due, and ending on the day when payment is made
and;(b)the licensee shall be subject to the proceedings for the recovery of such fee specified in the
Act and;(c)the Commission may revoke the licence pursuant to Section 19 of the Act and condition
17 of the licence.16.4The licensee shall be entitled to take into account any fee paid by it under
condition 16 in the determination of aggregate revenue made in accordance with condition 23 but
shall not take into account any interest paid pursuant to the condition 16.3.
17. Revocation of Licence. - Subject to the provisions of Section 19 of the Act
and the Regulations (Licencing for Transmission of Electricity) framed
thereunder, Commission may at any time initiate proceedings against the
Transmission Licensee for revocation of the Transmission licence and if so
satisfied in such proceedings that the public interest so requires, it may
revoke the Transmission licence in any of the circumstances stated in the
Regulation 19 of (Licencing for Transmission of Electricity) Regulations,
2006.
18. Amendment of Licence Conditions. - These General conditions of licence
may be altered or amended by the Commission subject to provision of
Section 18 of the Act and the Regulations (Licencing for Transmission of
Electricity) Regulations, 2006 framed thereunder and in any of the
circumstances stated in the condition clause 17 of Regulation. (Grant of
licence for Transmission of Electricity Regulation 2006).
Part III – Technical ConditionsBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

19. Transmission Planning and Security Standards;
Power Supply Planning and Security Standards;Transmission Operating Standards; andPower
Supply Operating Standards19.1The Licensee shall plan and operate the Transmission System so as
to ensure that the Transmission System is capable of providing an efficient, coordinated and
economical system of Transmission. In particular, the Licensee shall:(a)plan and develop its
Transmission System in accordance with the Transmission System Planning and Security Standards
together with the Grid Code as approved by the Commission; and.(b)operate the Licensee's
Transmission System in accordance with the Transmission System Operating Standards together
with the Grid Code as approved by the Commission.19.2The licensee shall make arrangements,
within twelve months from the date of issue of Licence, to comply with the Power Supply Planning
and Security Standards and Power Supply Operating Standards.19.3The Licensee shall, within 60
days from the date when Licence becomes effective; submit to the Commission the existing
• Planning and Security Standards, }Standards for its Transmission
• Operating Standards System
• Planning and Security Standards }Standards for its Power Supply
System
• Operating Standards
Including those relating to:
• Generation Capacity connected to its TransmissionSystem being
followed by the Licensee.  
Such existing standards, with such modification as the Commission may direct, shall continue to
remain in effect until new standards approved by the Commission pursuant to condition 19.4 take
effect.19.4(a)The Licensee shall, within six months, or such longer time as the Commission may
allow, after Licence has become effective, prepare, in consultation with the Suppliers, Generating
Companies, Central Transmission utility, Regional Electricity Boards and such other Person as the
Commission may specify, and submit to the Commission for approval the Licensee's proposal for
Transmission Planning and Security Standards. Transmission Operating Standards, Power Supply
Planning and Security Standards and Power Supply Operating Standards in accordance with
condition 19.(b)The Transmission Planning and Security Standards, Transmission Operating
Standards, Power Supply Planning and Security Standards and Power supply Operating Standards
submitted by the License pursuant to this paragraph, with such modifications as the Commission
may require, shall take effect from such date as the Commission may specify.19.5The Licensee shall
not be in breach of its obligations under the Licence if it has failed to meet the Transmission
Planning and Security Standards or the Transmission Operating Standards directly due to Force
Majeure, provided, the Licensee has used its reasonable efforts, to the extent reasonably possible, to
comply with the Transmission Planning and Security Standards or the Transmission Operating
Standards as the case may be.19.6The Licensee shall make reasonable arrangements to provide for
sale to Suppliers, sufficient electricity to meet Power Supply Planning and Security Standards and
Power Supply Operating Standards approved by the Commission.19.7The Licensee shall, in
consultation with Suppliers, the Generating Companies, Distribution Licensees in the state, the
Central Transmission Utility, the regional Electricity Board and such other persons as theBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

Commission may order, review Standards and their implementation on each occasion. Following
such review, the Licensee shall send to the Commission.(a)a report on the outcome of such review,
and(b)any revision which the Licensee proposes to make to such documents from time to time
(having regard to the outcome of such review); and(c)any written representations or objections
(including those not accepted by the Licensee) from Suppliers, Generating Companies, Central
Transmission Utility, regional Electricity Board and such other Persons as the Commission may
order during consultation process.The Commission may, upon application of the Licensee, relieve
the Licensee from obligation to review the standards and their implementation, to such extent as
shall be specified in directions issued to the Licensee by the Commission for the purposes of this
condition.19.8Having regard to any written representations or objections referred to in condition
19.7(c), and following such further consultation (if any) as the Commission may consider
appropriate, it may issue directions requiring the Licensee to revise the standards in such manner as
may be specified in the directions.19.9The Commission may issue directions requiring the licensee
to revise any of the standards in such manner as may be specified by the Commission.19.10The
Licensee shall, on an annual basis:(a)forecast the demand for power within the Area of
Transmission and Bulk Supply in each of the next succeeding 10 years; and.(b)prepare and submit
forecasts to the Commission in accordance with the guidelines issued by the Commission from time
to time.19.11The Licensee shall within 3 months of the end of each financial year, submit to the
Commission a report indicating the performance of the Transmission System during the previous
financial year. The Licensee shall, if required by the Commission, publish a summary of the report
in a manner to be determined by the Commission.
20. Compliance with Grid Code by the Transmission Licensee
20.1The transmission license shall ensure due compliance with the Indian Electricity Grid Code and
Bihar State Electricity Grid Code.20.2The Commission may, on reasonable grounds and after
consultation with the affected Generation Company, Transmission Licensee the State
TransmissionUtility the State Load Despatch Centre and electricity traders, issue direction relieving
the licensee of its obligation in respect of such parts of the State Grid Code and to such extent as may
be decided by the Commission.
21. Central Scheduling and Despatch
21.1Having regard to information provided to it by Suppliers. Generating Companies Central
Transmission Utility, Distribution Licensees and other utilities in the region (including information
as to forecast levels of electricity demand and availability of generation capacity) and keeping into
consideration requirements of the Transmission Planning and Security Standards and the
Transmission operating Standards referred to in this Licence, the Licensee shall undertake
operational planning matching to possible output of all Generating Sets contracted to it and any
other Bulk Supply and other sources or electrical energy connected to the Licensee's Transmission
System (including a reserve of generation to provide a security margin or generation availability)
with forecast demand after taking into account, inter alia:(a)unavailability of Generating Sets;
and(b)constraints from time to time imposed by technical limitations on the Total System or
interconnections with other transmission systems or any part(s) thereof;(c)consistent with thisBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

condition 21.1 and in accordance with the Grid Codes, for the removal from service of parts of the
transmission systems for maintenance, repair extension of reinforcement.21.2Taking account of the
factors referred to in condition 21.2 the Licensee shall schedule and issue direct instructions for
despatch of power from the Generating Sets and other sources of power as are at such times
available to generate electricity and which are subject to despatch instructions.(b)in ascending order
of relevant prices that are offered for the generation of electricity into the Total System, keeping in
view the constraints on hydro-electric generation, and.(c)as will in aggregate (and after taking
account of electricity delivered to or from the Total System from or to other sources) be sufficient to
match at all times (to the extent possible having regard to the availability of Generation sets)
expected demand, taking account of information provided by Suppliers, the Central Transmission
Utility and the Regional Electricity Board together with an appropriate margin of reserve.21.3The
factors referred to in condition 21.2 include:(a)expected demand (including losses):(b)Economic
and technical constraints from time to time imposed on the Total System or any part or parts
thereof.(c)the dynamic operating characteristics of available Generating Sets and.(d)other matters
provided for in the Grid Code.21.4The Licensee shall provide to the Commission such information
as the Commission shall require concerning the merit order despatch described in condition 21.2 (a)
or any aspect of its operation. Note: In this Condition 21:"available" means such state of a
Generating Set that it can respond successfully to a call to service by the entity with authority to
despatch the system, and its"availability" be construed accordingly, "central despatch" means the
process of scheduling and issuing direct instructions by the Licensee as referred to in condition
21.Part - IV
22. Requirement to Offer Terms for Use of System and Connection to System
22.1The licensee shall make such arrangements for use of the Transmission System by third parties
as are specified in the condition 22. On application made by any such third party, the Licensee shall
offer to enter into an agreement with that person for the use of the Transmission System.(a)to
accept into the Transmission System electricity provided by that Person;(b)to deliver such
electricity, adjusted for losses of electricity, to a designated exit point;(c)that specifies that use of
System charges to be paid by the user, shall be in accordance with Part V.Explanation. - The third
parties referred to in this condition 22.1 means.(i)Persons authorised under a legislation enacted by
the Union of India to wheel power across the Transmission System in an inter-state conveyance of
energy.(ii)Such persons as the Commission may authorise to use the Transmission system.22.2On
application made by a Supplier for grant of a connection to a Consumer wishing to be connected
directly to the Transmission System, the Licensee shall offer to enter into an agreement with such
Supplier and/or Consumer, as the case may be, for connection to the Transmission System or for
modification of such an existing connection and such offer shall make provision for(a)carrying out
of works necessary to make the required connection, including the installation of meters.(b)carrying
out any necessary work to reinforce the Licensee's Transmission System.(c)connection charges to be
paid in accordance with Part V and(d)date of completion and such other terms as are relevant to the
circumstances.22.3The Licensee shall offer terms for agreements in accordance with condition 22.1
or 22.2 as soon as practicable but (save where the Commission consents to a longer period) no more
than two months after an application under condition 22.1 or 22.2 is made.22.4The Licensee shall
not be obliged pursuant to condition 22 to offer to enter or to enter into any agreement if itBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

is.(a)likely to involve the Licensee;(i)in breach of its duties under Section 17 of the Act; or(ii)in
breach of any Rules or Regulations relating to safety or standards applicable to the Transmission
Business including, the Indian Electricity Rules, 1956; or(iii)in breach of the Grid Code; or(iv)in
breach of any of the conditions of this Licence; or if(b)the persons making the application does not
undertake to comply with the Grid Code from time to time in force to the extent that it is applicable
to that Person; or(c)in case of persons making application for Use of System under condition 22.1
such person ceases to be authorised as specified therein; or(d)in case the persons do not have the
financial resources to pay the transmission charges.22.5If, after a period, which appears to the
Commission to be reasonable for the purpose, the Licensee has failed to enter into an agreement
with any applicant referred to in condition 22.1 and 22.2 pursuant to a request under condition 22,
the Commission may at the request of a party settle such terms in dispute between the Licensee and
that Person and, the Licensee shall forth with enter into and implement such agreement in
accordance with its terms as settled by the Commission.22.6The Licensee shall prepare and submit
to the Commission on annual basis, a settlement showing in respect of each of the 5 succeeding
financial years, forecasts of circuits capacity, power flows and loading on the Transmission System
under standard planning criteria, together with:(a)such further information as shall be reasonably
necessary to enable any Person seeking use of System to identify and evaluate the opportunities
available when connecting to and making use of such system; and(b)a commentary prepared by the
Licensee indicating the Licensee's views as to those parts of the Licensee's Transmission System
most suited to new connections and transport of further quantities of electricity.22.7At the request
of a person or a supplier who wishes to use the Transmission System under condition 22.1 or 22.2
the Licensee shall prepare an update to the above statement, incorporating most recent data but
specifically including any facility for which any other Person or a Supplier has requested use of and
connection to the Transmission System.22.8The Licensee may make a charge for any statement
given or sent to Persons seeking Use of System, of an amount reflecting the Licensee's reasonable
costs of providing such a statement.Part-V Expected Revenue Calculation and Tariffs
23. Expected Revenue and Tariff Filings
23.1The Licensee shall follow the methodology, procedures and other directions included in the
Tariff Regulations while filing statements of expected revenue from charges and for proposing or
amending any or all of its tariffs.23.2The amount that the licensee is permitted to recover from its
tariffs in any financial year is the amount that the Commission determines in accordance with the
financial principles and their applications provided in Section 62 of the Electricity Act, 2003, as will
allow the licensee a fair opportunity to earn a reasonable return.23.3The Licensee shall establish a
tariff as approved by the Commission, for the Licensee's Transmission Business and shall calculate
its charges in accordance with this License, the Regulations, the orders of the Commission and other
requirements prescribed by the Commission from time to time.23.4The Licensee may publish a
tariff for its Transmission of electricity reflecting the tariff charges and the other terms and
conditions contained in the approved tariffs referred to in condition 23.2 above or as directed by the
Commission.23.5The Licensee may apply to the Commission to amend its tariffs in accordance with
the Act and applicable Regulations and directions of the Commission.23.6The Licensee may apply to
the Commission to amend its tariffs in accordance with the Act if the Commission so requires in
order to remove any undue discrimination identified by the Commission or to cause the licensee'sBihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

expected revenue to correspond to the amount that it is permitted to recover under this
Licence.Part-VI Miscellaneous Matters
24. Miscellaneous Matters
24.1All issues arising in relation to interpretation of these General Conditions shall be a matter for
the determination of the Commission and the decision of the Commission on such issues shall be
final, subject only to the right of appeal under Section 111 of the Act.24.2The Commission may at the
time of grant of Transmission Licence waive or modify the application of any of the provisions of
these General Conditions either in the order granting the licence or by Specific Conditions made
applicable to a Transmission Licence.
25. These General Conditions shall apply to all Transmission Licensees after
they come into force and also to all deemed Transmission Licensees under
Section 14 of the Act.
Transmission Licence
Schedule
.................Area of Transmission(Name of Licensee)The entire state of Bihar including cantonment,
airdrome, fortresses, arsenal, dockyard or camp of any building or place in occupation of Central
Government for defence purposes, where permission has been obtained.Bihar Electricity Regulatory Commission (Licencing for Transmission of Electricity) Regulations, 2007

