Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors
on 14 November, 1980
Equivalent citations: 1981 AIR 298, 1981 SCR (2) 185, AIR 1981 SUPREME
COURT 298, 1981 (1) SCC 246, (1980) 4 SCC 329, 1981 SCC (L&S) 50
Author: V.R. Krishnaiyer
Bench: V.R. Krishnaiyer, R.S. Pathak, O. Chinnappa Reddy
           PETITIONER:
AKHIL BHARATIYA SOSHIT KARAMCHARI SANGH (RAILWAY)REPRESENTED
        Vs.
RESPONDENT:
UNION OF INDIA AND ORS.
DATE OF JUDGMENT14/11/1980
BENCH:
KRISHNAIYER, V.R.
BENCH:
KRISHNAIYER, V.R.
PATHAK, R.S.
REDDY, O. CHINNAPPA (J)
CITATION:
 1981 AIR  298            1981 SCR  (2) 185
 1981 SCC  (1) 246
 CITATOR INFO :
 E&R        1985 SC1495  (19,75)
 F          1987 SC 537  (22)
 RF         1987 SC 990  (16)
 RF         1988 SC 959  (12)
 RF         1991 SC1902  (36)
 R          1991 SC2288  (12)
 RF         1992 SC   1  (90,125)
ACT:
     Constitution of  India, 1950-Arts. 16, 46 and 335-Scope
of-Reservation  of  posts  under  the  State  in  favour  of
Scheduled  Castes  and  Scheduled  Tribes-Carry  forward  of
unfilled posts for three years-validity of-
HEADNOTE:Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

     In  so   far  as  the  initial  recruitment  and  later
promotion to  classes II,  III and  IV  are  concerned,  the
Railway Administration  provided for  reservation of certain
percentage of  vacancies for  candidates  belonging  to  the
Scheduled Castes  and Scheduled  Tribes. Since,  despite the
special provision  the intake  of these communities into the
Railway  Services   continued  to   be  negligible   further
concessions and  relaxations were  offered from time to time
to members  belonging to  the Scheduled Castes and Scheduled
Tribes. Even  so, in  many cases  the vacancies reserved for
them remained  unfilled.  Yet  another  step  taken  by  the
Railway Administration  to keep  open the reserved vacancies
was to  adopt a  policy of  "carry forward"  of the unfilled
reserved vacancies for at least three years.
     In obedience  to the policy decision of the Ministry of
Home Affairs,  the Railway  Board issued  certain directives
designed to  protect and  promote the interest of members of
the Scheduled  Castes and  Scheduled Tribes in the matter of
their employment  in the  Railway Administration. The policy
directive of reserving certain percentage of posts in favour
of  these  communities  having  not  proved  effective,  the
Railway Board  altered the  rules "with  a view  to securing
increased representation  of Scheduled  Castes and Scheduled
Tribes in  the Railway  Services" (Annexure  D). The Railway
Board authorised  the recruiting  bodies to  slur  over  low
places obtained  by Scheduled  Castes and  Scheduled  Tribes
candidates except  where  it  was  found  that  the  minimum
standard necessary  for the maintenance of efficiency of the
administration  had   not  been   reached.  The   appointing
authorities were  directed to  give additional  training and
coaching to  the recruits  so that they might come up to the
standard  of   other  recruits   appointed  alongwith  them.
Likewise  where   direct  recruitment,   otherwise  than  by
examination, was  provided for,  the Railway  Board directed
the selection  of  Scheduled  Castes  and  Scheduled  Tribes
candidates fulfilling  a lower  standard of suitability than
from other  communities, so  long as  the candidates had the
prescribed minimum  educational and technical qualifications
and the  appointing  authorities  were  satisfied  that  the
lowering  of   standards  would   not  unduly   affect   the
maintenance of efficiency of administration.
     In the  case  of  selection  posts  the  Railway  Board
decided that  promotions from class IV to class III and from
class  III  to  class  II  were  of  the  nature  of  direct
recruitment and  the prescribed  quota  of  reservation  for
Scheduled Castes  and Scheduled Tribes should be provided as
in direct recruitment. This reser-
186
vation was  confined to  'selection  posts'.  In  regard  to
filling of  "general posts"  in class III it was stated that
they were  in the  nature  of  direct  recruitment  and  the
reservation for  Scheduled Castes  and Scheduled  Tribes  as
applicable  to   direct  recruitment   should  be   applied.Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

(Annexure F).
     In 1969  the Railway Board further revised their policy
in regard  to the       reservation and other concessions to
the Scheduled  Castes and  Scheduled  Tribes  candidates  in
posts filled  by promotion (Annexure H). The circular stated
that in  promotion by  selection from class III to class II,
if a member of the Scheduled Castes and Scheduled Tribes was
within the  zone of  eligibility the employee would be given
one grading  higher than the grading otherwise assignable to
him on the basis of his record of service.
     In April,  1970  the  percentage  of  vacancies  to  be
reserved for  Scheduled  Castes  and  Scheduled  Tribes  was
raised from  121/2%   and 5%  to 15%  and 71/2% respectively
(Annexure I). By the same order the "carry forward" rule was
altered from 2 to 3 years.
     In 1973  the Railway  Board issued  a directive stating
that the  quota of  15%   and 71/2% for Scheduled Castes and
Scheduled  Tribes   may  be   provided    promotion  to  the
categories and  posts in classes I, II, III and IV filled on
the basis  of  the  seniority-cum-suitability  provided  the
element of  direct recruitment  to  those  grades  does  not
exceed 50% (Annexure K).
     In August, 1974 the Railway Board further directed that
if the  requisite number  of Scheduled  Castes and Scheduled
Tribes candidates were not available for being placed on the
panel in  spite of  the various  relaxations the  best among
them i.e. those who secure highest marks should be earmarked
for being  placed on  the panel  to the extent vacancies had
been reserved  in their  favour. The  Scheduled  Castes  and
Scheduled Tribes  candidates so  earmarked might be promoted
ad hoc  for a  period of  six months  against the  vacancies
reserved for  them. During  the period  of  six  months  the
administration was  asked to  give them  all facilities  for
improving their  knowledge and for coming upto the requisite
standard. The  procedure was required to be applied in cases
of promotion  to the posts filled on the basis of seniority-
cum-suitability (Annexure N).
     A further  modification to  the then existing rules was
made by  Annexure 'O'  which stated  that  "reservations  in
posts filled by promotion under the existing scheme would be
applicable to  all grades  or services  where the element of
direct recruitment,  if any,  does not  exceed  66  2/3%  as
against 50% as at present".
     It was  contended on  behalf of  the  petitioners  that
Scheduled Castes  cannot be  a favoured  class in the public
services because  (i) they  are "castes"  and   cannot claim
preference qua  castes unless  specially  saved  by  Article
16(4) which  speaks of  "class" and  not "castes", (ii) that
Article 16(4)  could not  apply to  promotional  levels  and
(iii) efficiency  of administration envisaged by Article 335
had  been   jeopardised  by  the  impugned  circulars  which
fomented frustration  among the  civil services and produced
inefficiency by  placing men  of lower  efficiency and  lessAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

experience in higher posts.
187
A preliminary  objection was  raised that  since  the  first
petitioner was  an  unrecognised union, it was not a "person
aggrieved" and so its petition was unsustainable.
     Dismissing the petitions
     [Per majority  Krishna Iyer  and Chinnappa  Reddy,  JJ,
Pathak J.  concurring in  the  result  with  reservation  on
certain questions]
     There is  nothing illegal  or unconstitutional  in  the
impugned orders.
[Per Krishna Iyer, J]
     The argument  that since  the first  petitioner was  an
unrecognized association  the petition  is  not  sustainable
must be  overruled because  whether the petitioners belonged
to a  recognised union or not, the fact remains that a large
body of  persons with  a common  grievance exists  and  they
approached  this   Court  under   Article  32.  Our  current
processual jurisprudence  is broad-based and people oriented
and envisions  access to  justice through  "class  actions",
"public    interest    litigation"    and    "representative
proceedings". The  narrow concept  of cause  of  action  and
person  aggrieved  and  individual  litigation  is  becoming
obsolescent in some jurisdictions. [224 G-H]
     The well  settled position in law is that the State may
classify, based  upon  substantial  differentia,  groups  or
classes  and   this  process   does  not  necessarily  spell
violation of  Articles 14  to 16.  Therefore, in the present
case if the Scheduled Castes and Scheduled Tribes stand on a
substantially  different  footing  they  may  be  classified
groupwise and treated separately. [232 B-C]
     The fundamental right of equality of opportunity has to
be read as justifying the categorisation of Scheduled Castes
and Scheduled Tribes separately for the purpose of "adequate
representation" in  the services under the State. The object
is constitutionally sanctioned in terms as Article 16(4) and
46 specificate.  The classification  is just and reasonable.
[233 G-H]
     Apart  from  Article  16(1),  Article  16(2)  expressly
forbids discrimination  on the  ground of caste and here the
question arises  as to  whether  the  Scheduled  Castes  and
Tribes are  castes within  the  meaning  of  Article  16(2).
Assuming that  there is discrimination, Article 16(2) cannot
be invoked unless it is predicated that the Scheduled Castes
are  "castes".  There  are  sufficient  indications  in  the
Constitution to  suggest that  the Scheduled  Castes are not
mere castes.  They may  be something  less or something more
and the  time badge  is not the fact that the members belong
to a  caste but  the circumstance  that they  belong  to  an
indescribably backward human group. [234 A-C]
Articles 14 to 16 form a Code by themselves and contain
a  constitutional   fundamental  guarantee.   The  Directive
Principles which  are fundamental  in the  governance of theAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

country enjoin  upon  the  State  the  duty  to  apply  that
principle in making laws. Article 46 obligates the State the
promote with  special  care  the  educational  and  economic
interests of  the weaker  sections  of  the  people  and  in
particular of the Scheduled Castes and the Scheduled Tribes.
Article 46  read with  Article 16(4) makes it clear that the
exploited lot  of the  harijan groups  in the  past shall be
extirpated with special care by the State. [210 F; 211 A-C]
188
     At the  same time  reservations under Article 16(4) and
promotional strategies  under Article  46 should not be used
to  imperil   administrative  efficiency   in  the  name  of
concessions to  backward classes.  The  positive  accent  of
Article 335  is that  the claims  of  these  communities  to
equalisation of  representation in  services under the State
shall be  taken into  consideration. The negative element of
this Article is that measures taken by the State pursuant to
the  mandate   of  Articles  16(4),  46  and  335  shall  be
consistent with  and not  subversive of  the maintenance  of
efficiency of administration. [211 D-F]
     Under Article 341, Scheduled Castes become such only if
the President specifies any castes, races or tribes or parts
or groups  within castes, races or tribes for the purpose of
the Constitution.  It is the socioeconomic backwardness of a
social bracket  that is  decisive and  not mere  birth in  a
caste. [212 A]
     Annexure F relates only to selection posts and has been
expressly  upheld  in  Rangachari's  case.  The  quantum  of
reservation is  not excessive;  the field  of eligibility is
not too  unreasonable; the  operation of  the reservation is
limited  to   selection   posts   and   no   relaxation   of
qualifications is  written into  the  circular  except  that
candidates of  the Scheduled  Castes  and  Scheduled  Tribes
communities  should  be  judged  in  a  sympathetic  manner.
Moreover administrative  efficiency is  secure because there
is a  direction to  give such  staff additional training and
coaching, to bring them upto the standard of others. [239 F-
G]
     There is  no vice  in giving  one grade  higher than is
otherwise assignable  to an employee. based on the record of
his service rendering the promotional prospects unreasonable
because this concession is confined to only 25% of the total
number of  vacancies in a particular grade or post filled in
a year and there is no rampant vice of every harijan jumping
over the  heads of others. More importantly, this is only an
administrative device of showing a concession or furtherance
of prospects  of selection. Even as under Articles 15(4) and
16(4) lesser  marks are  prescribed as  sufficient for these
communities or  extra  marks  are  added  to  give  them  an
advantage, the  regrading is one more method of boosting the
chances of  selection of  these communities.  The prescribed
minimum qualification  and standard of fitness are continued
even  for   Scheduled  Castes  and  Scheduled  Tribes  underAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

Annexure H. [240 B-D]
     Annexure I is unexceptionable since all that it does is
to readjust the proportion of reservation in conformity with
the latest census. [240 E-F]
     Similarly "carry  forward" raised  from  two  years  to
three years  cannot be  struck down.  There is  no prospect,
even if  the vacancies  are carried  forward, of  sufficient
number of  Scheduled Castes  and Scheduled Tribes candidates
turning out  to fill  them. Moreover,  there is  a provision
that  if  a  sufficient  number  of  candidates  from  these
communities are  not found,  applicants from  the unreserved
communities would  be given appointment provisionally. After
three years these vacancies cease to be reserved. [240 G-A]
     Even in  Devadasan's case, this Court has laid down the
proposition  that  under  Article  16(4)  reservation  of  a
reasonable percentage  of posts  for member of the Scheduled
Castes and  Scheduled Tribes is within the competence of the
State. What was struck down was that the reservations should
not be  so excessive  as to  create a monopoly or to disturb
unduly the  legitimate claims  of other communities. By this
rule there is no danger of the total vacancies
189
being gobbled  up by  the harijan/girijan  groups  virtually
obliterating Article  16(1). The  problem of giving adequate
representation to  backward classes under Article 16(4) is a
matter for  the Government  to consider, bearing in mind the
need for a reasonable balance between the rival claims. [241
B-F]
     Subject to  the condition  that the  carry forward rule
shall not  result in  any given  year in  the  selection  or
appointment  of   Scheduled  Castes   and  Scheduled  Tribes
candidates considerably  in excess of 50%, the Annexure I is
upheld. [242 E]
     There is  nothing unreasonable  or wrong in Annexure J.
Once the  parameters of reservation are within the framework
of  the   fundamental  rights,   minute  scrutiny  of  every
administrative measure is not permissible. [242 F]
     Annexure K is beyond reproach. As between selection and
non-selection posts  the role  of merit is functionally more
relevant in  the former  than in the latter. If in selecting
top officers,  posts could  be reserved for Scheduled Castes
and Scheduled  Tribes with lesser merit it cannot rationally
be argued  that for  the posts  of peons,  or lower division
clerks reservation  would  spell  calamity.  The  part  that
efficiency plays  is far  more in  the case  of higher posts
than in the appointments to the lower posts. [243 D]
     Dilution of  efficiency caused by the minimal induction
of a  small percentage  of reserved candidates cannot affect
the  over-all   administrative   efficiency   significantly.
Moreover, care  has been  taken to  give in-service training
and coaching to correct the deficiencies. [244 B-C]
[Chinnappa Reddy, J concurring]
     The preamble to the Constitution of India proclaims theAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

resolution of  the people  to secure  to  all  its  citizens
justice, social,  economic and political, equality of status
and opportunity  and  to  promote  fraternity  assuring  the
dignity of  the individual. The right to equality before the
law and  equality of  opportunity in  the matter  of  public
employment are  guaranteed as  fundamental rights. The State
is enjoined  upon by the Directive Principles to promote the
welfare  of   the  people,   to   endeavour   to   eliminate
inequalities in  status, facilities  and  opportunities  and
special provisions  have been  made, in  particular, for the
protection and  advancement  of  the  Scheduled  Castes  and
Scheduled Tribes  in recognition  of their  low  social  and
economic status and their failure to avail themselves of any
opportunity of self-advancement. In short the constitutional
goal is  the establishment of a socialist democracy in which
justice-economic, social and political is secure and all men
are equal  and have equal opportunity. Inequality whether of
status, facility  or opportunity  is to end, privilege is to
cease and  exploitation is  to go. The under-privileged, the
deprived and the exploited are to be protected and nourished
so as  to take  their place in an egalitarian society. State
action is  to be  towards those  ends. It is in this context
that Article  16 has  to be interpreted when State action is
questioned as contravening Article 16. [255 A-F]
     A Constitution,  such as  ours, must  receive  generous
interpretation so  as to  give  an  its  citizens  the  full
measure of  justice so  proclaimed. While  interpreting  the
Constitution the  expositors must  concern themselves not so
much with  words  as  with  the  spirit  and  sense  of  the
Constitution which  could  be  found  in  the  Preamble  the
Directive Principles and other such provisions. [256 G]
190
     At one time it was assumed that because the fundamental
rights are  enforce able  in a  court of law while Directive
Principles are  not, the former were superior to the latter,
that way  of  thinking  has  become  obsolete.  The  current
thinking is  that while  Fundamental  Rights  are  primarily
aimed at  assuring political freedom to the citizens against
excessive State  action, the  Directive Principles are aimed
at securing  social and  economic  freedoms  by  appropriate
State   action.    The   Directive   Principles   are   made
unenforceable in a limited sense because no Court can compel
a Legislature to make laws. But that does not mean that they
are less  important than Fundamental Rights or that they are
not binding on the various organs of the State. They are all
the same fundamental in the governance of the country and it
shall be  the duty of the State to apply these principles in
making laws.  The  Directive  Principles  should  serve  the
Courts as  a Code  of Interpretation.  Every law attacked on
the ground  of infringement  of Fundamental  Right should be
examined to  see if the impugned law does not advance one or
other of  the Directive  Principles or  if it  is not in the
discharge of  some of the undoubted obligations of the StateAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

towards its  citizens  flowing  out  of  the  Preamble,  the
Directive   Principles   and   other   provisions   of   the
Constitution. [257 A-G]
     Reservation of posts and all other measures designed to
promote  the  participation  of  the  Scheduled  Castes  and
Scheduled Tribes  in public  services at  all levels  are  a
necessary consequence  flowing from  the Fundamental  Rights
guaranteed by  Article 16(1).  This very  idea is emphasized
further by  Article 16(4)  which is  not in the nature of an
exception to  Article 16(1)  but a facet of that Article. In
the State  of Kerala v. N.M. Thomas the court has repudiated
the theory propounded in earlier cases that Article 16(4) is
in the  nature of  an exception  to Article  16(1). It is no
longer correct  to say that laws aimed at achieving equality
as permissible exceptions. Such laws are necessary incidents
of equality. [258 D-F]
     Minister of Home Affairs v. Fisher [1979]3 All E.R. 21,
State of Kerala & Anr. v. N.M. Thomas & Ors. [1976] 1 S.C.R.
906 @  930-933 and  The General Manager, Southern Railway v.
Rangachari [1962]2 S.C.R. 586 referred to.
     The figures  quoted from the report of the Commissioner
of Scheduled  Castes and Scheduled Tribes for the year 1977-
78 reveal  how slow  and insignificant the progress achieved
by the  members  of  these  communities  in  the  matter  of
participation in  the Railway  Administration had  been. Far
from acquiring  any monopolistic or excessive representation
over any  category of  posts these  communities are  nowhere
near being  adequately represented.  Neither the reservation
rule nor  the "carry  forward"  rule  for  these  years  has
resulted in  any such disastrous consequence. Therefore, the
complaint of the petitioners that the circulars had resulted
in excessive  representation of these communities is without
foundation generally  or with  reference to  any  particular
year. [246 D-G]
     There is  no substance  in the argument that efficiency
of  administration  would  suffer  if  the  Railway  Board's
directives were  followed in  the matter of reservations and
promotions.  The  Railway  Board  had  stated  that  minimum
standards were  insisted upon  for every  appointment and in
the case  of candidates  wanting in  requisite standards  of
efficiency  those  with  higher  marks  were  given  special
intensive  training  to  enable  them  to  come  up  to  the
requisite standards.  In the  case of  posts which  involved
safety of movement of trains there was no
191
relaxation of standards in favour of candidates belonging to
Scheduled Castes and Scheduled Tribes and they were required
to pass the same rigid tests as others.[265 A-B]
     There  is   no  fixed   ceiling   to   reservation   or
preferential treatment in favour of the Scheduled Castes and
Scheduled Tribes though generally reservation may not be far
in excess  of 50%  about which  there is  no rigidity. Every
case must be decided on its own facts. [265 E]Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

     There is nothing illegal or unconstitutional in any one
of the impugned orders and circulars. [265 G]
[Pathak J  concurring in  the  result  with  reservation  on
certain questions.]
Article 46  of the  Constitution enjoins upon the State
to treat  with special  care the  educational  and  economic
interest of  the  weaker  sections  of  the  people  and  in
particular the Scheduled Castes and Scheduled Tribes. One of
the  modes   in  which   the  economic   interest  of  these
communities  can   be  promoted   is   by   reservation   of
appointments or  posts in their favour in services under the
State where  they are  not adequately represented. By virtue
of Article 16(4), when the State intends to make reservation
of appointments  or posts  in favour of these communities in
services under  it nothing  in Article  16  prevents  it from
doing so. Article 335 provides that claims of the members of
these communities  shall be  taken into consideration in the
making of  appointments to  services and posts in connection
with  the  affairs  of  the  Union  or  a  State.  But  such
consideration must  be consistent  with the  maintenance  of
efficiency of administration which is regarded as paramount.
It is  dictated by the common good and not of a mere section
of the  people. Therefore,  whatever is  done in considering
the claims  of Scheduled Castes and Scheduled Tribes must be
consistent with  the need  for maintenance  of efficiency of
administration. This  Article contains  a single  principle,
namely, the  advancement of  Scheduled Castes  and Scheduled
Tribes but  through modes and avenues which must not detract
from the maintenance of an efficient administration. [250 B-
H]
     For securing  an efficient administration the governing
criterion in  the matter  of appointments to posts under the
State is  excellence and  the emphasis is solely on quality.
The selection  is made  regardless of religion, race, caste,
sex, descent,  place of birth or residence. However, a quota
of the posts may be reserved in favour of backward citizens.
But the  interests of  efficient administration require that
at least  half the  total number  of posts  be kept  open to
attract the best of the nation's talent. If it was otherwise
an excess  of the  reserved quota  would convert  the  State
service  into   a  collective  membership  predominantly  of
backward  classes.   The  maintenance   of   efficiency   of
administration is  bound to be adversely affected if general
candidates of  high merit  are correspondingly excluded from
recruitment. Viewed  in that  light the  maximum of  50% for
reserved  quota   appears  fair  and  reasonable,  just  and
equitable violation  of which  would contravene Article 335.
[251 B-D]
     M. R  Balaji v.  State of  Mysore [1963] Supp. 1 S.C.R.
439, 470,  T. Devadasan v. Union of India [1964]4 S.C.R. 680
and State  of Kerala  v. N.  M. Thomas  [1976]1  S.C.R.  906
referred to.
192Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

JUDGMENT:
ORIGINAL JURISDICTION: Writ Petition Nos. 1041-1044 of 1980.
(Under Article 32 of the Constitution) Shanti Bhushan, K. K. Venugopal, A. T. M. Sampath, P. N
Ramalingam and R. Satish for the Petitioner.
Lal Narain Sinha, Att. General of India, M. K. Banerjee, Addl. Sol. Genl. and Miss A. Subhashini for
Respondents Nos. 1-5.
P. R. Mridul, P. H. Parekh, C. B. Singh, B. L. Verma, Rajan Karanjawal and Miss Vineeta Caprihan
for the Intervener.
K. B. Rohtagi and Praveen Jain for the Intervener. R. K. Garg and P. K. Jain for the Intervener.
S. K. Bagga for the Intervener.
Altaf Ahmed for the Intervener.
S. Balakrishnan for the Intervener.
P. H. Parekh for Respondent No. 6 in W.P. No. 1042/79. The following judgments were delivered:
KRISHNA IYER. J.
The Root Thought The abolition of slavery has gone on for a long time. Rome
abolished slavery, America abolished it, and we did, but only the words were
abolished not the thing.
This agonising gap between hortative hopes and human dupes vis a vis that serf-like
sector of Indian society, strangely described as Scheduled Castes and Scheduled
Tribes (SCs and STs, for short), and the administrative exercises to bridge this big
hiatus by processes like reservations and other concessions in the field of public
employment is the broad issue that demands constitutional examination in the
Indian setting of competitive equality before the law and tearful inequality in life. A
fasciculus of directions of the Railway Board has been attacked as ultra vires and the
court has to pronounce on it, not philosophically but pragmatically. "The
philosophers have only interpreted the world in various ways; the point is to change
it" -this was the founding fathers' fighting faith and serves as perspective-setter for
the judicial censor.Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

The Backdrop The social backdrop to the forensic problem raised in this litigation is
best projected by lines of poetry quoted in Nehru's Autobiography:
Bowed by the weight of centuries he leans Upon his hoe and gazes on the ground, The
emptiness of ages on his face, And on his back the burden of the world.
The Problem The dynamics and dialectics of social justice vis a vis the special
provisions of the Constitution calculated to accelerate the prospects of employment
of the harijans and the girijans in the civil services with particular emphasis on
promotions of these categories in the Indian Railways that, in all these cases, is the
cynosure of judicial scrutiny, from the angle of constitutionality in the context of the
guarantee of caste-free equality to every person. Petitioners' Challenge The gravamen
of the constitutional accusation levelled in this bunch of quasi-class actions under
Art. 32 of the Constitution and argued by a battery of counsel led by Shri Shanti
Bhushan, with heat and light, passion and reason, is the heartless discrimination
shown against vast numbers of members employed by the Railway Administration
through its policy directives, by bestowal of unconscionably 'pampering' concessions,
at promotion levels, on these social brackets belonging to the historically suppressed
SCs & STs, heedless of over-all administrative efficiency in the Indian Railways and
frustrating the promotional hopes of the larger human segments of economically
downtrodden senior members. The fall-out of this 'benign discrimination' of helping
out the weakest sections has been to blow up, out of all proportion to the social
realities, the 'backwardness' syndrome so as embrace many politically powerful
castes disguised as Backward Classes. This constitutional amulet, rooted largely in
caste, the petitioners lament, has been misused and applied in educational and
employment fields on an escalating scale. The perverted result is that a caste-riven
nation is a spectre that haunts the land, pushing back the patriotic prospect of a
homogenised Indian Society of casteless equality and projecting instead the divisive
alternative of a heterogeneous caste map of Bharat. The fundamental failure of this
sterile scheme of reservation- wise circumvention of the fundamental right to
equality, ideologically and pragmatically speaking, has deepened the pathological
condition of communalism besetting the Indian polity and split the have-nots into
snarling camps-a consummation disastrously contrary to the constitutional design of
abolition of socioeconomic inequality through activist stratagem of equalisation
geared to actual attainment of integrated equality.
Logically, the argument leads to the formulation that each caste and community is
bargaining politically for bigger bites of the educational-and-employment cake so
much so merit becomes irrelevant or takes a back seat and 'backward' birth brings a
boon. The constitutional stultification of an integrated India through misuse of
'reservation' power provided for in Arts. 15 and 16 meant for the direct 'dalits' the
pollution, by the political Executive, of our founding creed of an egalitarian order by
playing casteification politics and the morbid dilution of 'backwardness' marring the
dream of a secular republic by the nightmare of a feudal vivisection of the people-ifAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

this picture drawn by some counsel be true, even in part, the basic task of
transforming the economic order through social justice will be baulked through
destructive communal disputes among the masses. Maybe, this may weaken the
social revolution, leave an indelible stain and incurable wound on the body politic
and justify the censure by history of the engineers of our political power and electoral
processes. Hearing the arguments of the petitioners one wonders, "Is caste the largest
political party ?" Has protective discrimination, so necessary in an insufferably
unequal society, created a Frankenstein's monster ?
Have we no dynamic measures to drown social, economic and educational
backwardness of whole masses except the traditional self-perpetuating
quasi-apartheidisation called 'reservation' ? Surely, our democratic, secular socialist
republic is no wane moon but a creative power rooted in equal manhood, an
egalitarian reservoir of vast human potential, a demographic distribution of talent
benumbed by brahman centuries of social injustice but now seeking human
expression under a new dispensation where 'chill penury' shall no longer 'repress
their noble rage'.
Caste, undoubtedly, in a deep-seated pathology to eradicate which the Constitution
took care to forbid discrimination based on caste, especially in the field of education
and services under the State. The rulings of this court, interpreting the relevant
Articles, have hammered home the point that it is not constitutional to base
identification of backward classes on caste alone qua caste. If a large number of
castes masquerade as backward classes and perpetuate that division in educational
campuses and public offices, the whole process of a caste-free society will be
reversed. We are not directly concerned with backward classes as such, but with the
provisions ameliorative of the Scheduled Castes and the Scheduled Tribes.
Nevertheless, we have to consider seriously the social consequences of our
interpretation of Art. 16 in the light of the submission of counsel that a vested interest
in the caste system is being created and perpetuated by over-indulgent concessions,
even at promotional levels, to the Scheduled Castes and the Scheduled Tribes, which
are only a species of castes. "Each according to his ability" is being substituted by
"each according to his caste", argue the writ petitioners and underscore the
unrighteous march of the officials belonging to the SCs & STs over the humiliated
heads of their senior and more meritorious brothers in service. The after-math of the
caste-based operation of promotional preferences is stated to be deterioration in the
over-all efficiency and frustration in the ranks of members not fortunate enough to be
born SCs & STs. Indeed, the 'inefficiency' bogie was so luridly presented that even the
railway accidents and other operational calamities and managerial failures were
attributed to the only villain of the piece viz., the policy of reservation in promotions.
A constitutionally progressive policy of advantage in educational and official career
based upon economic rather than social backwardness was commended before us by
counsel as more in keeping with the anti-caste, pro-egalitarian tryst with our
constitutional destiny. And, Shri Shanti Bhushan, at one stage, helped the courtAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

realise the consequences of its verdict if it upheld the pampering package of
promotional preferences by warning us of running battles in the streets, a sort of
caste-war, against birth based 'privileges' for the harijan-girijan millions. Our
Approach Of course, judicial independence has one dimension, not fully realised by
some friends of freedom. Threats of mob hysteria shall not deflect the court from its
true accountability to the Constitution, its spirit and text belighted by all the
sanctioned materials The other invisible sacrifice of judicial independence relevant to
this case is the unwitting surrender to "the spirit of the group in which the accidents
of birth or education or occupation or fellowship have given us (judges) a place. No
effort or revolution of the mind will overthrow utterly and at all times the empire of
these subconscious loyalties." We quote what the great Justice Cardozo has
courageously confessed :
I have spoken of the forces of which judges avowedly avail to shape the form and
content of their judgments. Even these forces are seldom fully in consciousness. They
lie so near the surface, however, that their existence and influence are not likely to be
disclaimed. But the subject is not exhausted with the recognition of their power. Deep
below consciousness are other forces, the likes and the dislikes, the predilections and
the prejudices, the complex of instincts and emotions and habits and convictions,
which make the man whether he be litigant or judge...... The great tides and currents
which engulf the rest of men do not turn aside in their course and pass the judges
by........... We shall never be able to flatter ourselves, in any system of judicial
interpretation, that we have eliminated altogether the personal measures of the
interpreter. In the moral sciences, there is no method or procedure which entirely
supplants that subjective reason. We may figure the task of the judge, if we please, as
the task of a translator, the reading of signs and symbols given from without. None
the less, we will not set men to such a task, unless they have absorbed the spirit, and
have filled themselves with a love, of the language they must read.
The British echo of this judicial weakness is heard in Prof. Griffith's words:
These judges have by their education and training and the pursuit of their profession
as barristers, acquired a strikingly homogeneous collection of attitudes, beliefs and
principles, which to them represents the public interest.
The emphasis on the subtle invasions from within upon functional autonomy and
forensic objectivity mentioned by Cardozo will be evident when we turn to the
pathetic saga of the depressed classes, even today, painted by the other side. The
learned Attorney General, less militant but not less firm in his submissions, called all
this a caricature of the poignant facts of life and called upon us to assess the facts
with cold objectivity and warm humanity casting aside possible sympathies suggested
by Justice Cardozo and Prof. Griffith.Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

We, as judges dealing with a socially charged issue of constitutional law, must never
forget that the Indian Constitution is a National Charter pregnant with social
revolution, not a Legal Parchment barren of militant values to usher in a democratic,
secular, socialist society which belongs equally to the masses including the
harijan-girijan millions hungering for a humane deal after feudal colonial history's
long night.
Granville Austin quotes profusely from the Constituent Assembly proceedings to
prove the goal of the Indian Constitution to be social revolution. Radhakrishnan,
representing the broad consensus, said that India must have a 'socioeconomic
revolution' designed not only to bring about the real satisfaction of the fundamental
needs of the common man, but to go much deeper and bring about 'a fundamental
change in the structure of Indian society'.
The Cultural Core of the Constitutional Protection:
Let us get some glimpses of history to get a hang of the problem. 'In thy book record
their groans' may be the right quote to begin with. We cannot blink at the agony of
the depressed classes over the centuries condemned by all social reformers as rank
irreligion and social injustice. Swami Vivekananda, for instance, stung by glaring
social injustice, argued(2):
The same power is in every man, to the one manifesting more, the other less. Where
is the claim to privilege. All knowledge is in every soul, even in the most ignorant, he
has not manifested it, but, perhaps he has not had the opportunity the environments
were not, perhaps, suitable to him. When he gets the opportunity he will manifest it.
The idea that one man is born superior to another has no meaning in Vedanta; that
between two nations one is superior and the other inferior has no meaning
whatsoever........ Men will be born differentiated; some will have more power than
others. We cannot stop that.... but that on account of this power to acquire wealth
they should tyrannies and ride roughshod over those, who cannot acquire so much
wealth, is not a part of the law, and the fight has been against that. The enjoyment of
advantage over another is privilege, and throughout ages the aim of morality has
been its destruction.............
Our aristocratic ancestors went on treading the common masses of our country under
foot till they became helpless, till under this torment the poor, poor, people nearly
forgot that they were human beings. They have been compelled to be merely hewers
of wood and drawers of water for centuries, so much so, that they are made to believe
that they are born as slaves, born as hewers of wood and drawers of water. With all
our boasted education of modern times, if anybody says a kind word for them, I often
find our men shrink at once from the duty of lifting them up, these poor
downtrodden people. Not only so, but I also find that all sorts of most demoniacal
and brutal arguments, culled from the crude ideas of hereditary transmission, andAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

other such gibberish from the western world are brought forward in order to
brutalise and tyrannies over the poor, all the more......
Aye, Brahmins, if the Brahmin has more aptitude for learning on the ground of
heredity than the Pariah, spend no more money on the Brahmin's education, but
spend all on the Pariah. Give to the weak, for there all the gift is needed. Our poor
people, these down- trodden masses of India, therefore, require to hear and to know
what they really are. Aye, let every man and woman and child, without respect of
caste or birth, weakness and strength, hear and learn that behind the strong and the
weak, behind the high and the low, behind everyone, there is that Infinite Soul,
assuring that infinite possibility and the infinite capacity of all to become great and
good. Let us proclaim to every soul-'Arise, awake and stop not till the goal is reached.
Arise, awake ! Awake from the hyprotism of weakness. None is really weak; the soul
is infinite, omnipotent and omniscient. Stand up, assert yourself, proclaim the God
within you, do not deny Him ! Too much of inactivity, too much of weakness, too
much of hypnotism has been and is upon our race........ Power will come, glory will
come, goodness will come, purity will come, and everything that is excellent will
come, when this sleeping soul is roused to self-conscious activity..........
Our proletariat are doing their duty........ is there no heroism in it ? Many turn out to
be heroes, when they have some great task to perform. Even a coward easily gives up
his life, and the most selfish man behaves disinterestedly when there is a multitude,
to cheer them on but blessed indeed is he who manifests the same unselfishness and
devotion to duty in the smallest of acts. unnoticed by all-and it is you who are actually
doing this, ye ever-trampled labouring classes of India ! I bow to you.
There was the Everest presence of Mahatma Gandhi, the Father of the Nation, who
staked his life for the harijan cause. There was Baba Saheb Ambedkar-a mahar by
birth and fighter to his last breath against the himalayan injustice to the harijan
fellow millions stigmatised by their genetic handicap-who was the Chairman of the
drafting committee of the Constituent Assembly. There was Nehru, one of the
foremost architects of Free India, who stood four square between caste suppression
by the upper castes and the socialist egalitarianism implicit in secular democracy.
These forces nurtured the roots of our constitutional values among which must be
found the fighting faith in a casteless society, not by obliterating the label but by
advancement of the backward, particularly that pathetic segment described
colourlessly as Scheduled Castes and Scheduled Tribes. To recognise these poignant
realities of social history and so to interpret the Constitution as to fulfil itself, not
eruditely to undermine its substance through the tyranny of literality, is the task of
judicial patriotism so relevant in Third World conditions to make liberation a living
fact.Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

The learned Attorney General drew our attention to the yawning gap between the
legitimate expectations of the socially depressed SC & ST and their utter under
representation in the Public Services except in such mean jobs as of scavengers and
sweepers where no other caste was forthcoming. Equality of opportunity would be
absent so long as equalisation strategy was not put into action, and the State, stage by
stage and with great care and experimental eye, took steps to secure the ends of Arts.
16(1) and 16(4), read in the light of the Preambular promise of equality, fraternity and
dignity, the Part IV directive of promotion of educational and economic interests of
the SC & ST and the Special Chapter, especially Art. 336, devoted to better
representation of the SC & ST in the services and posts in connection with the affairs
of the Union and States. We could not apprehend the social dimension of the stark
squalour of SC&ST by viewing Art. 16 (4) through a narrow legal aperture but only by
an apercu of the broader demands of social democracy, without which the Republic
would cease to be a reality to one-fifth of Indian humanity.
The final address to the Constituent Assembly by Dr. Ambedkar drives home this
point, not to interpret but to illumine the scheme of the equality code and the
casteless society plea :
The third thing we must do is not to be content with mere political democracy. We
must make our political democracy a social democracy as well. Political democracy
can-
not last unless there lies at the base of it social democracy. What does social
democracy mean ? It means a way of life which recognises liberty, equality and
fraternity as the principles of life. These principles of liberty, equality and fraternity
are not to be treated as separate items in a trinity. They form a union of trinity in the
sense that to divorce one from the other is to defeat the very purpose of democracy.
Liberty cannot be divorced from equality, equality cannot be divorced from liberty.
Nor can liberty and equality be divorced from fraternity. Without fraternity, liberty
and equality could not become a natural course of things. It would require a
constable to enforce them. We must begin by acknowledging the fact that there is
complete absence of two things in Indian society. One of these is equality. On the
social plane, we have in India a society based on the principles of graded inequality
which means elevation of some and degradation for others. On the economic plane,
we have a society in which there are some who have immense wealth as against many
who live in abject poverty. On the 26th January 1950, we are going to enter into a life
of contradictions. In politics we will have equality and in social and economic life we
will have inequality. In politics we will be recognizing the principle of one man one
vote and one vote one value. In our social and economic structure, continue to deny
the principle of one man one value. How long shall we continue to live this life of
contradictions ? How long shall be continue to deny equality in our social and
economic life ? If we continue to deny it for long, we will do so only by putting our
political democracy in peril. We must remove this contradiction at the earliestAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

possible moment or else those who suffer from inequality will blow up the structure
or political democracy which this Assembly has so laboriously built up (emphasis
added). Indeed from another angle of vision, Art. 16(4) serves to correct a gross social
distortion and denial of human rights to whole groups ostracised by feudal history. A
holistic concept of human rights includes among its components socioeconomic
rights for, without basic conditions of social justice, survival with human dignity is an
impossibility. Thus, a great socioeconomic plan to uplift the harijan-girijan groups is
a must for living equality, proclaimed by Arts. 14 to 16, to become an active reality. It
must be stated that the petitioners did not contest the need for State action to raise
the lot of these backward most social sectors but objected, its widespread erosion of
the right to basic equality which belongs to the have-nots in the country. Where do
we draw the line ?
These are the disturbing issues going to the root of progressive nationalism raised by
the writ petitioners and turned against them by the State, but we are not inclined or
entitled to venture into the political wisdom of governmental policies vis a vis
'backward' community, calculus save where constitutionality, falling within the
judicial jurisdiction, confronts us. We must therefore confine the forensic focus to the
specific issue of profound import projected by the aggrieved petitioners whose chief
attack is against being passed over, seniority and superior merit notwithstanding, in
favour of alleged neophytes or nitwits merely because, by birth, the latter belong to
the SC&ST species, trampling underfoot, in the process, the fundamental rights of
equal opportunity entrenched in Arts. 14 and 16(1) of the Constitution.
The dimensions of the problem, the human numbers involved and the agitational potential said to
be simmering in the civil services were vividly drawn at the bar by one side. The tragic tale of
die-hard decades of inequality even after Freedom, the socioeconomic miles to go' and the
constitutional 'promises to keep' (over which judges will not legally sleep) before the dalit brethren
may break their chains and become at least distant neighbours to the less socially handicapped
sector, were highlighted pragmatically, statistically, hierarchically, even desperately, by the
proponents of the impugned circulars (Annexures F to O covered by Prayers I to X). These
submissions serve as poignant background but the decision on the vires of the Railway Board's
directives will depend on constitutional interpretation applied to Indian actualities, not to idealised
abstractions or theoretical possibilities. True, the politicisation of casteism its infiltration into
unsuspected human territories and the injection of caste- consciousness in schools and colleges via
backward class reservation are a canker in the rose of secularism. More positive measures of
levelling up by constructive strategies may be the developmental needs. But the judicial process
while considering constitutional questions, must keep politics and administrative alternatives as out
of bounds except to the extent economics, sociology and other disciplines bear scientifically upon
the proposition demanding court pronouncement. Here the sole issue, spread out into the validity of
the supposed sinful circulars (Annexures F to O covered by Prayers I to X) is whether Art. 16, in its
sweep and savings, does permit State action in favour of socially and economically backward classes,
especially the constitutionally favoured category called the SC & ST, to the point of liberal
concessions slurring over 'age', 'merit' and the like, not merely at the initial entrance gate but even atAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

the higher promotional docks.
Whether alternative policies should have been chosen by Government or would have served better
to remove the handicaps of the SC & STs, whether the advantages conferred on these classes are too
generous and overly compassionate and whether the considerable numbers of the economically
destitute receive the same sympathy as social have-nots categorised as SC & ST these and other
speculative maybes, are beyond the courts orbit save where Art. 16 is hit by these omissions and
commissions. Nor is it the court's province to question the conscionableness or propriety of
constitutional provisions which display ultra concern for members of the SC & ST. The court
functions under the Constitution, not over it, interprets the Constitution, not amends it, implements
its provisions, not dilutes it through personal philosophy projected as constitutional construction.
Objective tuned to constitutional wavelengths is our function and if-only if-constitutional
guarantees have clearly been violated will the court declare as non est such governmental projects as
go beyond the mandates of Part III read in harmony with Part IV. If, on a reasonable construction,
the Administration's special provisions under Art. 16(4) exceed constitutional limits, it is the duty of
the court to strike dead such project. Even so, while viewing the legal issues we must not forget what
is elementary that law cannot go it alone but must function as a member of the sociological
ensemble of disciplines.
If one out of a few reasonably tenable constructions of the constitutional provisions vis a vis the
impugned executive directives may sustain the latter, the court should and would refrain from using
the judicial guillotine. There is a comity of coordinate constitutional instrumentalities geared to
shared constitutional goals which persuades the judicature to sustain rather than slay, save where
the breach is brazen, the transgression is plain or the effective co-existence of the fundamental right
and the administrative scheme is illusory. This Court has, on former occasions, upheld executive
and legislative action hovering "perilously near" but not plunging into unconstitutionality (see In re:
Kerala Education Bill (1959 SCR 995 at 1064). It is a constant guideline which we must vigilantly
remember, as we have stated earlier, that our Constitution is a dynamic document with destination
social revolution. It is not anaemic nor neutral but vigorously purposeful and value-laden as they
very descriptive adjectives of our Republic proclaim. Where ancient social injustice freezes the
'genial current of the soul' for whole human segments our Constitution is not non-aligned. Activist
equalisation, as a realistic strategy of producing human equality, is not legal anathema for Arts. 14
and 16. To hold otherwise is constitutional obscurantism and legal literalism, allergic to
sociologically intelligent interpretation.
The Preamble which promises justice, liberty and equality of status and opportunity within the
framework of Secular, Socialist Republic projects a holistic perspective. Art. 16 which guarantees
equal opportunity for all citizens in matters of State Service inherently implies equalisation as a
process towards equality but also hastens to harmonize the realistic need to jack up 'depressed'
classes to overcome initial handicaps and join the national race towards progress on an equal
footing and devotes Art. 16(4) for this specific purpose. In a given situation of large social categories
being submerged for long, the guarantee of equality with the rest is myth, not reality, unless it is
combined with affirmative State action for equalisation geared to promotion of eventual equality.
Article 16(4) is not a jarring note but auxiliary to fair fulfillment of Art. 16(1). The prescription ofAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

Art. 16(1) needs, in the living conditions of India, the concrete sanction of Art. 16(4) so that those
wallowing in the social quagmire are enabled to rise to levels of equality with the rest and march
together with their brethren whom history had not so harshly hamstrung. To bury this truth is to
sloganise Art. 16(1) and sacrifice the facts of life.
This is not mere harmonious statutory construction of Art. 16(1) and (4) but insightful perception of
our constitutional culture, reflecting the current of resurgent India bent on making, out of a sick and
stratified society of inequality and poverty, a brave new Bharat. If freedom, justice and equal
opportunity to unfold one's own personality, belong alike to bhangi and brahmin, prince and
pauper, if the panchama proletariat is to feel the social transformation Art. 16(4) promises, the State
must apply equalising techniques which will enlarge their opportunities and thereby progressively
diminish the need for props. The success of State action under Art. 16(4) consists in the speed with
which result-oriented reservation withers away as, no longer a need, not in the everwidening and
everlasting operation of an exception [Art. 16(4)] as if it were a super-fundamental right to continue
backward all the time. To lend immortality to the reservation policy is to defeat its raison de'etre; to
politicise this provision for communal support and Party ends is to subvert the solemn undertaking
of Art. 16(1), to costeify 'reservation' even beyond the dismal groups of backward-most people,
euphemistically described as SC & ST, is to run a grave constitutional risk. Caste, ipso facto, is not
class in a secular State.
The authentic voice of our culture, voiced by all the great builders of modern India, stood for
abolition of the hardships of the pariah, the mlecha, the bonded labour, the hungry, hard-working
half-slave, whose liberation was integral to our Independence. To interpret the Constitution rightly
we must understand the people for whom it is made- the finer ethos, the frustrations, the
aspirations, the parameters set by the Constitution for the principled solution of social disabilities.
This synthesis of ends and means, of life's maladies and law's remedies is a part of the know-how of
constitutional interpretation if alienation from the people were not to afflict the justicing process. A
statute rarely stands alone. Back of Minerva was the brain of Jove, and behind Venus was the spume
of the ocean.
These broader observations are necessary to set our sights right, to appreciate that our Constitution
lays the gravestone on the old unjust order and the cornerstone of the new humane order. This
constitutional consciousness is basic to interpretative wisdom. We may now start with the facts of
the case and spell out the particular problems demanding our consideration. Constitutional
questions cannot be viewed in vacuo but must be answered in the social milieu which gives it living
meaning. After all, the world of facts enlivens the world of words. And logomachy is not law but a
fatal, though fascinating, futility if alienated from the facts of life. So, before pronouncing on the
legality of the impugned ten orders we must sketch the social setting in which they were issued and
the socioeconomic facts which clothe Art. 16(4) with flesh and blood.
'The wisest in council, the ablest in debate and the most agreeable companion in the commerce of
human life, is that man who has assimilated to his understanding the greatest number of facts.' The
facts The Indian Railways, with an impressive record of expansion, employs colossal numbers of
servants in various typically hierarchical classes and grades. While the Indian Railways Act, 1890,Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

substantially regulates many of the functions of the railway administration in India, the Railway
Board is constituted under the Indian Railway Board Act, 1905, with a view more effectively to
control the administration of railways. The Central Government is statutorily empowered to invest
the Railway Board with all or any of the powers and functions of the Central Government under the
Indian Railways Act, 1890. Power is also given by s. 2 to vest in the Railway Board the capacity to
make general rules for railways administered by the Government. Of course, the investment of
powers upon the Railway Board is, broadly speaking, subject to the condition that the Central
Government retains the ultimate authority in all matters connected with the Railway
Administration. The Ministry of Home Affairs, in the Government of India, deals usually with all
matters of personnel, conditions of service of the Central Government staff and the like. Policy
decisions regarding matters covered by Art. 16(4) apparently originate from the Ministry of Home
Affairs and emanate to the various institutions like the Railway Board which responsively
implement them. In the present case, ten directives were issued by the Railway Board on different
occasions, which disclosed 'benign discrimination' in favour of Scheduled Castes and Scheduled
Tribes and are challenged by the petitioners as 'reverse discrimination', if we may use that
expression popularised in American legalese. These directives were designed to protect and promote
the interests of members of the SC & ST in the matter of their employment under the Indian Railway
Administration and they specially related to the softer criteria for promotion. The Railway Board
acted, as is discernible from the relevant orders, in obedience to the policy decisions of the Ministry
of Home Affairs. Some argument was addressed on the validity of the Railway Board's orders on
procedural and other technical grounds. We see no substance in them. The Board was bound to
carry out the Central Government's directives under Art. 16(4) and did it. The broader issue of
'benign discrimination' deserves close study.
The meat of the matter, to put it that way, is the gross discrimination alleged to be implicit in the
several Circulars of the Railway Board and the non-applicability of Art. 16(4) to save these circulars.
The focus of this litigation must primarily turn on that issue and the court must navigate towards
egalitarian justice at the level of promotion posts in the public services, keeping the land- mark
rulings of this Court as mariner's compass. The disturbing perpetuation of socioeconomic
suppression of a whole fifth of Indian manhood-the dalits-and the righteous resistance to prolonged
'reverse casteism' resulting in deepening demoralization of the economically oppressed-the
soshits-have been projected by counsel on the forensic screen as a conflict between equalisation and
equality. Our founding fathers, familiar with social dialectics and socialist enlightenment, surely
would have intended to bring both these have-not categories together as a broad brotherhood
against the die-hard Establishment and would never have contemplated a fratricidal strategy which
would blind and divide brothers in distress-the dalits and the soshits-and harm the integration of
the nation and its developmental march. Unless by dialectical approach sociologists lay bare this
false dilema of dalits versus soshits, the growing distrust in democracy will deepen, the
jurisprudence of constitutional revolution and egalitarian justice will fade in the books and the
founding hopes of January 26, 1950, will sour into cynical dupes of the masses, decades after! Wider
perspectives must, therefore, inform our study of the equality code (Arts. 14 to 16) to rid it of social
contradictions and read into it the need for a dalit soshit partnership in demanding social justice.
Felix Frankfurter set the judicial function when he said :(1) A Judge should be compounded of the
faculties that are demanded of the historian and the philosopher and the prophet. The last demandAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

upon him-to make some forecast of the consequences of his action-is perhaps the heaviest. To pierce
the curtain of the future, to give shape and visage to mysteries still in the womb of time, is the gift of
the imagination. It requires poetic sensibilities with which judges are rarely endowed and which
their education does not normally develop. These judges must have something of the creative artist
in them; they must have antennae registering feeling and judgment beyond logical, let alone
quantitative, proof.
Be that as it may, the court must go to the constitutional basics for guidance, decode the articles
indifferent to agitational portents and ideological speculations, but responsive to the urgent
implementation of Art. 38 into the reality of Indian life. Article 38 reads:
38(1). The State shall strive to promote the welfare of the people by securing and
protecting as effectively as it may a social order in which justice, social, economic and
political shall inform all the institutions of the national life.
(2) The State shall in particular, strive to minimise the inequalities in income, and
endeavour to eliminate inequalities in status, facilities and opportunities, not only
amongst individuals but also amongst groups of people residing in different areas or
engaged in different vocations.
(emphasis added) The learned Attorney General, while emphasising the egalitarian commitment of
the Constitution over the whole range of public services throughout their career, defended the
impugned orders by law and logic, pragmatics and statistics, and countered the hypotheticals of the
petitioners by the actual furnished by official facts and figures. He also relied on a few precedents, in
particular, Rangachari's case(1) and Thomas's case(2) both of which bind this Bench. He also sought
to explain away the effect of Balaji's case(3) and Devadason's case(4) on which the other side had
heavily relied to nullify some of the circulars.
The Union of India placed before us its case that notwithstanding measures for bringing the gap in
the matter of gross under-representation in the Administration, no adequate improvement had been
registered and, and so, more dynamic State action, to fulfil its constitutional tryst with the frustrated
fifth of the people described as SC & ST, became necessitous. The raw reality of meagre harijan and
girijan presence in the public services conscientised the Administration into taking a series of
cautions steps to catalyse the prospects of these categories entering the many Departments of
Government not merely at the initial stage but also at promotional points and in appointments to
supervisory posts so as to become members of the higher echelons. The learned Attorney General
contended that such affirmative actions, slurring over fanatical and financial insistence on so-called
merit and seniority, was in conformity with Art. 16(1) itself and, in any case, was protected by
Art.16(4). Maybe, the human numbers outside the SC & ST honestly suffer some meyhem in their
career especially at the higher notches of promotion after long stagnation and are bitter that the
shudra or panchama steals a march over him now, although the poignant pages of earlier history
have been a negation of personhood then for millions of the dregs of society, desperately driving Dr.
Ambedkar to vow "I shall not die a Hindu". But the synthesis of Art. 16, not the antithesis between
Art. 16(1) and Art. 16(4), gives the clue to creative constitutional construction.Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

The learned Attorney General's plea was that in a society of chronic inequality and scarcity of
employment, actual equality could never be midwifed without birth pangs, and discriminatory
unconstitutionality could not vitiate programmes meant to achieve real-life equality, unless we took
a pragmatic view. This approach is permissible if we follow Chief Justice Warren:
Our judges are not monks or scientists, but participants in the living stream of our
national life, steering the law between the dangers of rigidity on the one hand and of
formlessness on the other. Our system faces no theoretical dilemma but a single
continuous problem: how to apply to ever-changing conditions the never-changing
principles of freedom.
Let us draw the precise battle lines to contain the constitutional conflict within the
actual limits. Equality of opportunity in matters of State employment is a
constitutional guarantee and no citizen can be discriminated against on the score
only of sex, caste, descent, place of birth or residence. So, one point pressed before us
is that Scheduled Castes cannot be a favoured class in the public services because
they are 'castes' and cannot claim preference qua castes unless specially saved by Art.
16(4). And Art. 16(4) speaks of class, not caste and the two are different, however,
politically convenient the confusion may be. Another vital contention put forward by
counsel for the petitioners was that Art. 16(4) could not apply to promotional levels.
A third basic plea was that efficiency of administration was a constitutional
consideration under Art. 335 and could not be a sacrificial goat to propitiate the
backward class Kali. The impugned circulars offended against efficiency, both by
fomenting frustration among the Civil Services indirectly producing inefficiency and
by manning higher posts which demand higher skills with men of lower competitive
calibre and less experience in service thus posting 'efficiency risks' in strategic
positions violating Art. 335.
The contentious issue is now clear. Are SC & ST mere castes within the sense of Art.
16(2) ? If so, can Art. 16(4) help these castes through rule of promotional partiality ?
And, in any case, can Art. 16(4) rescue rules of benign discrimination if the impact
thereof is generation of gross inefficiency in administration ? Is not economic 'have
notism' a better yardstick of backwardness in secular India?
A brief resume of the structure of the Railway Services may help understand the rival
arguments in their precise setting. The pyramid begins, at the base, with Class IV
posts and rises to the apex, by stages, through Class III, Class II and Class I. True to
our hierarchical culture, pervasive in Indian Services, there are further sub- divisions,
consisting of many categories in each class and many grades in each category. The
agencies for recruitment are the Union Public Service Commission, the Railway
Service Commission and the top officers authorised by the Railway Board in this
behalf. Ordinarily the first entry into each category is filled by direct recruitment, if
we may use language loosely. Thereafter, appointments to higher grades/categories
are usually by promotion. The promotional processes are traditionally two-fold, viz.,Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

(a) by departmental selection based on merit-cum-seniority, and (b) by escalation, in
the order of seniority, from the lower to the higher grade/category, subject, of course
to being weeded out if found unfit. Candidates belonging to SC&ST receive certain
pronounced advantages both at the stage of initial recruitment and later at the
promotion stage. The Indian Railway Establishment Manual a compendious
collection of rules and directions bearing on the conditions of employment of railway
personnel, sets out all the information. Speaking population-wise and in approximate
terms, the Scheduled Castes constitute about 15% and the Scheduled Tribes 7 1/2%.
Broadly based on the ratio of the strength of SC&ST to the whole population, the
Railway Administration provided for reservation for candidates belonging to the
SC&ST. This percentage of reservation applied to Class IV, Class III, Class II and, in a
limited way, to Class I posts. The reservation is worked out by the method known as
40-point roster. These special provisions notwithstanding the intake of these
communities, stagnating at the bottom of the Indian policy, continued to be
chronically niggardly. To increase the rate of absorption of SC&ST into the services,
further facilities, concessions and relaxations were offered from time to time. Despite
these seemingly attractive employment opportunities the dismal backwardness in the
matter of representation in administration from among the SC&ST was such that the
vacancies reserved for them remained, in many cases, unfilled by SC & ST candidates.
Lest the overall representation of the members of the SC&ST should continue
deplorably negligible Government adopted a policy of "carry forward", for upto three
recruitment years, of reserved vacancies if enough number of candidates from the
said groups did not get selected. The "carry forward" rule was calculated to keep open
reserved vacancies for at least three years so that the under representation could be
made up at least in part. Homogenisation of the dalits into the national mainstream
was regarded as vital to our democracy by the State and these positive strategies of
special opportunities vis a vis SC&ST had, as its raison d'etre, only the imperative
need to exercise the haunting spectre of the socially and economically suppressed
species and to abolish the utter squalour of SC&ST so that the community at large
could march ahead without haggard groups dragging their feet. Social conscience
considers balanced democratic development as the humane justification for selective
discrimination.
With this backdrop, we may epitomise the ten 'tainted' directives and scan them for
their unconstitutionality.
Special provisions for depressed classes and even other castes have a pre-constitution
history. After the Constitution was enacted the legality of old rules based on caste
became moot and the Central Government revised its policy. The post-Constitution
re-incarnation of the communal G.O. concentrated not on caste orientation but on
elimination of socioeconomic suppression and the diverse ways to achieve this
objective.Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

We must remember, in this context, not merely the four classes of Service but also the
broad division of the staff into selection and non-selection posts. The first policy
statement of the Union of India on the issue of better representation of SC&ST in
Government Service begins with Resolution No. 42/21/49-NG 8 of September 13,
1950. To understand the functional compulsions, purpose, orientation and
constitutional parameters relevant to such a policy formulation we have to refer to a
few articles of the Constitution.
Articles 14 to 16 form a code by themselves and embody the distilled essence of the
Constitution's casteless and classless egalitarianism. Nevertheless, our founding
fathers were realists, and so did not declare the proposition of equality in its bald
universality but subjected it to certain special provisions, not contradicting the soul
of equality, but adapting that never changing principle to the ever-changing social
milieu. That is how Arts. 15(4) and 16(4) have to be read together with Arts. 15(1) and
16(1). The first sub-article speaks of equality and the second sub- article amplifies its
content by expressly interdicting caste as a ground of discrimination. Article 16(4)
imparts to the seemingly static equality embedded in Art. 16(1) a dynamic quality by
importing equalisation strategies geared to the eventual achievement of equality as
permissible State action, viewed as an amplification of Art. 16(1) or as an exception to
it. The same observation will hold good for the sub-articles of Art. 15. Thus we have a
constitutional fundamental guarantee in Arts. 14 to 16; but it is a notorious fact of our
cultural heritage that the Scheduled Castes and the Scheduled Tribes have been in
unfree Indian nearly dehumanised, and a facet of the struggle for Freedom has been
the restoration of full personhood to them together with the right to share in the
social and economic development of the country. Article 46 is a Directive Principle
contained in Part IV. Every Directive Principle is fundamental in the governance of
the country and it shall be the duty of the State to apply that principle in making law.
Article 46, in emphatic terms, obligates the State.
"to promote with special care the educational and economic interests of the weaker
sections of the people, and, in particular, of the Scheduled Castes and Scheduled
Tribes, and shall protect them from social injustice and all forms of exploitation.
Reading Art. 46 together with Art. 16(4) the luscent intent of the
Constitution-framers emerges that the exploited lot of the harijan girijan groups in
the past shall be extirpated with special care by the State. The inference is obvious
that administrative participation by SC&ST shall be promoted with special care by
the State. Of course reservations under Art. 16(4) and promotional strategies
envisaged by Art. 46 may be important but shall not run berserk and imperil
administrative efficiency in the name of concessions to backward classes. Article 335
enters a caveat in this behalf:
335. The claims of the members of the scheduled Castes and the Scheduled Tribes
shall be taken into consideration consistently with the maintenance of efficiency ofAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

administration, in the making of appointments to services and posts in connection
with the affairs of the Union or of a State.
The positive accent of this Article is that the claims of SC&ST to equalisation of
representation in services under the State, having regard to their sunken social status
and impotence in the power system, shall be taken into consideration. The negative
element, which is part of the Article, is that measures taken by the State, pursuant to
the mandate of Arts. 16(4), 46 and 335, shall be consistent with and not subversive of
"the maintenance of efficiency of administration".
Within this broad constitutional framework the Central Government worked out its policy, way back
in 1950, and made subsequent alterations in keeping with the needs of the situation, the poor
progress registered, the militant impatience of the affected SC&ST and the improved tactics to
hasten abolition of the depressed status of these groups by effective equalisation with the rest.
Even here, it may be noticed that the Constitution has given a special position for the Scheduled
Castes and the Scheduled Tribes.
Article 341 makes it clear that a 'Scheduled Caste' need not be a 'caste' in the conventional sense
and, therefore, may not be a caste within the meaning of Arts. 15(2) or 16(2). Scheduled Castes
become such only if the President specifies any castes, races or tribes or parts or groups within
castes, races or tribes for the purpose of the Constitution. So, a group or a section of a group, which
need not be a caste and may even be a hotchpotch of many castes or tribes or even races, may still be
a Scheduled Caste under Art. 341. Likewise, races or tribal communities or parts thereof or part or
parts of groups within them may still be Scheduled Tribes (Art. 342) for the purpose of the
Constitution. Under this definition, one group in a caste may be a Scheduled Caste and another from
the same caste may not be. It is the socioeconomic backwardness of a social bracket, not mere birth
in a caste, that is decisive. Conceptual errors creep in when traditional obsessions obfuscate the
vision.
This aspect has been referred to in the State of Kerala v. N. M. Thomas by me, and dealt with at
more length by Ray, C.J.:
Scheduled Castes and Scheduled Tribes are not a caste within the ordinary meaning
of caste. In Bhaiyalal v. Hari kishan Singh and Ors.(2) this Court held that an enquiry
whether the appellant there belonged to the Dohar caste which was not recognised as
a Scheduled Caste and his declaration that he belonged to the Chamar caste which
was a Scheduled Caste could not be permitted because of the provisions contained in
Article 341. No Court can come to a finding that any Caste or any tribe is a Scheduled
Caste or Scheduled Tribe. Scheduled Caste is a caste as notified under Article
366(25). A notification is issued by the President under Article 361 as a result of an
elaborate enquiry. The object of Article 341 is to provide protection to the members of
Scheduled Castes having regard to the economic and educational backwardness from
which they suffer.Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

The President notifies Scheduled Castes not with reference to any caste
characteristics but their abysmal backwardness, as is evident from the scheme of Part
XVI. He appoints, under Art. 338, a Special Officer whose duty is to investigate into
all matters relating to safeguards for the SC&ST. The Constitution provides not
merely for adequate representation of SC&ST to services and posts under the Union
and States, but also provides for reservation of seats for SC&ST in the Legislatures.
The cursory study of the Articles relating to the status and safeguards of SC&ST puts
it beyond doubt that the founding fathers have assigned to them a special place and
shown towards them special concern and charged the State with special mandates to
redeem these handicapped human sectors from their grossly retarded situation.
Indeed, they are not merely backward, but are the backwardmost and cannot be
equated with just any other caste in the Hindu fold. It is, therefore, problematic
whether Art. 16(2) when it refers to equality among castes deals with the Scheduled
Castes which, as shown above, may even be made of a plurality of castes or groups or
races and may vary from State to State. Also, a caste, subjected qua caste, to the most
humiliating handicaps may be a backward class although the Court will hesitate to
equate caste with class except where the degree of dismalness is dreadful. The
relevance of this point will be clear when we deal with the legal submissions of
counsel.
We will now state, in an abbreviated form, the various measures of the Railway Board
(in response to decisions of the Ministry of Home Affairs) for reservation in services
of SC&ST.
After noting the policy of communal representation in the Services before the
Constitution and the constitutional ban on discrimination by way of reservation on
the ground of caste save in the case of SC&ST (and in some cases Anglo- Indians with
whom we are unconcerned here) the Home Ministry proceeded to spell out the new
stance:
Pending the determination of the figures of population at the Census of 1951 the
Government of India have decided to make the following reservations in recruitment
to posts and services under them:
(a) Scheduled Castes:-The existing reservation of 12 1/2 % of vacancies filled by direct
recruitment in favour of the Scheduled Castes will continue in the case of recruitment
of posts and services made, on an all-India basis by open competition, i.e. through
the Union Public Service Commission or by means of open competitive test held by
any other authority. Where recruitment is made otherwise than by open competition
the reservation for Scheduled Castes will be 16-2/3 as at present.
(b) Scheduled Tribes:-Both in recruitment by open competition and in recruitment made otherwise
than by open competition there will be a reservation in favour of members of Scheduled Tribes of
5% of the vacancies filled by direct recruitment.Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

......Under the Constitution all citizens of India are eligible for consideration for appointment to
posts and services under the Central Government irrespective of their domicile or place of birth and
there can be no recruitment to any Central Service which is confined by rule to the inhabitants of
any specified area. In practice however recruitment to class I and II services and posts is likely to
attract candidates from all over India and will be on a truly all-India basis, while for the majority of
Class III services & posts which are filled otherwise than through the Union Public Service
Commission only those residing in the area or locality in which the Office is located are likely to
apply. In the latter class of cases the percentages of reservations for Scheduled Castes and Scheduled
Tribes will be fixed by Government taking into account the population of the Scheduled Castes and
Scheduled Tribes in that area.
Reservations were excluded for promotions and minimum qualifications were a 'must'. But age
relaxation by 3 years (from the maximum fixed for others) was allowed. This policy is not challenged
as unconstitutional and rightly so.
However, this special provision showed only minimal concessions to SC&ST, being the first
cautious, conservative, post-constitutional measure under Art. 16(4). But law is what law does. Did
this reluctant relaxation only on a few grounds work? Constant monitoring of law-in-action, with an
eye on the end result, is social engineering. The goal here was to awaken the sleeping soul and
harness the harijan resource by mainstreaming techniques constitutionally sanctioned. The policy
proved non-viable and a change of strategy was called for and by Annexure D the Railway Board
altered the rules "with a view to securing increased representation of Scheduled Castes and
Scheduled Tribes in the Railway Services". At the instance of the Home Ministry the Railway Board
decided on 5-10-1955 that more realistic relaxations were needed and authorised recruiting bodies
to slur over low places obtained by the SC&ST candidates:
.....except where such authority considers that the minimum standard necessary for
the maintenance of efficiency of the administration has not been reached. Whenever
candidates are selected in this manner, the appointing authorities will make
necessary arrangements to give additional training and coaching to the recruits so
that they might come up to the standard of other recruits appointed along with them.
The anxiety to level up the lowly human layers by special training so as to maintain
administrative efficiency is evident in this directive.
Likewise, where direct recruitment, otherwise than by examination was provided for,
taking of SC&ST candidates '..... fulfilling a lower standard of suitability than from
other communities, was permitted so long as the candidates have the prescribed
minimum education and technical qualifications and the appointing authorities are
satisfied that the lowering of standards will not unduly affect the maintenance of the
efficiency of administration.' Here again, obsession with 'efficiency' is manifest. Then
comes what is called the 'carry forward' rule:
(3)(a) if a sufficient number of candidates considered suitable by the recruiting
authorities, are not available for the communities for whom reservations are made inAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

a particular year, the unfilled vacancies should be treated as unreserved and filled by
the best available candidates. The number of reserved vacancies thus treated as
unreserved will be added as an additional quota to the number that would be
reserved in the following year in the normal course, and to the extent to which
approved candidates are not available in that year against this additional quota, a
corresponding addition should be made to the number of reserved vacancies in the
second following year.
* * * *
(b) In the event of suitable Scheduled Caste candidate not being available, a
Scheduled Tribe candidate can be appointed in the subsequent reserved vacancy and
vice versa subject to adjustment in the subsequent points of the roster.
The quota for two years, if carried forward, would not materially affect the stream of 'merit-worthy'
candidates, nor substantially diminish the prospects of non-SC&ST candidates in a given year. So
the Railway Board introduced the principle consistently with Art. 335.
Government moved further because real power could be shared by the weakest sections only if the
doors of the higher decks were pened to them. The higher echelons are the real controllerates, not
the menial levels, hierarchically structured as our society is. Obviously, Art. 16(4) was not designed
to get more harijans into Government as scavengers and sweepers but as 'officers' and 'bosses', so
that administrative power may become the common property of the high and low, homogenised and
integrated into one community. Social stratification, the bane of the caste system, could be undone
and vertical mobility won not by hortative exercises but by experience of shared power.
Viewed thus, the 'open sesame' strategy for entry into superior cadres could only be by extending
concessions at higher levels of 'promotions'. Annexure D did not make reservations for SC&ST for
promotion posts, but merely asked for sympathy on the part of promoting authorities. Lachrymal
exercises, even in government directives, are in practice, little more than skin-deep; and elitist
alibis, when the ancient anguish of the lowliest & the lost besieges the citadels of the status quo,
readily checkmate ameliorative moves. The harijan lot, in administrative services at the promotional
levels, remained a paper hope, a teasing illusion and a promise of unreality. Article 46, whether we
like it or not, ordains that the State shall 'with special care' promote the interests of the SC&ST. And
so long as the harijan-girijan remained an alien to the Civil Service and the janitors for the higher
chambers of Administration were themselves non-harijan-girijan gentlemen, he would be a naive
sociologist who thought that mere plea for more sympathy made in official orders would work
magic. Government, on a performance audit of its policy of 'no reservation' for promotion posts,
discovered that the harijan could hardly reach higher positions. More effective methods were
needed.
A radical change in policy was effected by the Railway Board through Annexure F of April 27, 1959.
'Merit', sanctified by tradition, lost the battle. 'Tradition is a great retarding force, the vis inertiae of
history;' and so, heroic measures of progressive thrust, the Railway Board realised, alone couldAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

effect the break-through and bring the harijan-girijan groups into the higher brackets of
Administration Annexure was promulgated providing for reservation in promotions. This has been
challenged before us.
The tepid provision opening up promotion posts for 'reserved' categories was first confined to Class
III and Class II, Class I being too sacrosanct to be soiled by meritless members. Annexure F reads:
Sub: Reservation for members of Scheduled Castes and Scheduled Tribes in posts
filled by promotion in Railways.
Reference is invited to Board's letter No. E55CMI/3 dated 5-10-55. The Railway
Board have, in partial modification of para IV of the above letter, decided as follows:-
(a) Promotion from Class IV to Class III and from Class III to Class II.
The Railway Board have decided that promotions from Class IV to Class III and from Class III to
Class II service are of the nature of direct recruitment and the prescribed quota of reservation for
Scheduled Castes and Scheduled Tribes should be provided as in direct recruitment. The field of
eligibility in the case of Scheduled Castes and Scheduled Tribes candidates should be four times the
number of posts reserved without any condition of qualifying period of service in their case, subject
to the condition that such consideration should not normally extend to staff beyond two grades
immediately below the grade for which the selection is held.
This reservation was confined to 'selection posts' and the circular was explicit that "there will be no
quota for Scheduled Castes and Scheduled Tribes candidates in respect of promotion to
"non-selection" posts. For "general posts"
of certain types in Class III, it was laid down:
(c) "General Posts" in Class III.
There are certain other types of posts on Railways such as Passenger Guides, Welfare Inspectors,
Safety Inspectors Platform Inspectors, Publicity Inspectors, Vigilance Inspectors, etc., which are
ex-cadre posts filled by drawing staff from more than one branch. Filling of these posts is in the
nature of direct recruitment and the reservation for Scheduled Castes and Scheduled Tribes as
applicable to direct recruitment should be applied."
More chances to pass tests, additional training and coaching to raise the standard of the
sub-standard were also provided for in the Board's order. Homage was thus paid to the
'administrative efficiency' component of Art. 335.
This departure regarding reservation at the promotion tier for selection posts was challenged before
this Court but upheld in Rangachari's case. We will dwell at some length on that ruling later but we
may merely mention than an appeal was made to us by counsel for the petitioners that we shouldAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

reconsider, by reference to a larger bench, the ratio of Rangachari which has been approvingly
referred to for nearly two decades by this Court, acted upon by Government throughout and enjoys,
if we may say so with great respect, our full concurrence. Constitutional propositions on which a
whole nation directs its destiny are not like Olympic records to be periodically challenge and broken
by fresh exercises in excellence but solemn sanctions, with judicial seal set thereon, for the country
to navigate towards the haven of human development for everyone. To play cross-word puzzle with
constitutional construction is to profane it, unless, of course, a serious set-back to the progress of
human rights or surprise reversal of constitutional fundamentals has happened. We find the
question discussed, decided and consistently followed since Rangachari and see no reason to open
the Pandora's box. So it was that we rejected the plea for reconsideration.
Even so, the alternative method of containing Art, 16(4) within the contours of Rangachari was open
to counsel and that has been done in argument as will be evident from the discussion on the vires of
the subsequent orders of the Board. All the fire was turned by petitioners' counsel on promotion
'excesses' through Railway Board circulars. Annexure H of August 27, 1979 is one such:
Annexure H The Railway Board have now revised their policy in regard to reservation
and other concessions to Scheduled Castes and Scheduled Tribes in posts filled by
promotion....
The particular concessions are concretised thus:
(B) Promotion by selection method (i) Class II appointments:
In promotion by selection from Class III to Class II, as a measure of improving
representation of Scheduled Castes/ Scheduled Tribes, it has now been decided that,
if they are within the zone of eligibility the Scheduled Caste and Scheduled Tribe
employees will be given, by the Selection/Departmental promotion Committee, one
grading higher than the grading otherwise assignable to them on the basis of their
record of service i.e. if any Scheduled Caste or Scheduled Tribe employee has been
categorised by the Committee, on the basis of his record of service as "Good", he
should be recategorised by the Committee as "Very Good". Likewise, if any Scheduled
Caste or Scheduled Tribe employee is grades as "Very Good" on the basis of his
record of service, he will be recategorised by the Committee as "Outstanding". Of
course, if any Scheduled Caste or Scheduled Tribe employee has already been
categorised by the Committee as "Outstanding" on the basis of his record of service,
no recategorisation will be needed in his case. This recategorisation will then form
the basis of allotment of marks in respect of 'Record of service'.
The above concession would be confined to only 25 per cent of the total number of
vacancies in a particular grade or post filled in a year.
In the matter of selection to Class III and Class IV posts the concession runs thus:Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

There will be reservation of 12 per cent and 5 per cent of the vacancies for Scheduled
Castes and Scheduled Tribes respectively in promotions made by selection in or to
Class III and Class IV posts, in grades or services in which the element of direct
recruitment, if any, does not exceed 50 per cent. Promotion against reserved
vacancies will continue to be subject to the candidates satisfying the prescribed
minimum qualifications and standards of fitness. II. It has also been decided that in
respect of promotions to selection posts in Class III where safety aspect is not
involved, the qualifying marks under "Professional ability" in respect of Scheduled
Caste and Scheduled Tribe candidates should be 25 out of 50 instead of 30 out of 50
as applicable to the candidates belonging to the unreserved groups. Similarly,
qualifying marks in aggregate in respect of Scheduled Castes and Scheduled Tribes
should be 50 out of 100 instead of 60 out of 100 for others.
It must be noticed that while grading has been modified and qualifying marks
reduced as indicated above, for SC&ST, care has also been taken to exclude from
these concessions, posts which involve "safety aspects" and not to relax prescribed
minima of qualifications and standards of fitness. Article 335 has been honoured,
making a margin on merit inevitable when choosing the second best.
The next Order assailed by counsel is that of 20th April 1970 (Annexure I) and its highlights are
revealed by relevant excerpts:
ANNEXURE I The policy of the Government of India in regard to reservations for
Scheduled Castes and Scheduled Tribes in posts and services under the Government
of India was laid down in the Ministry of Home Affairs Resolution No.
42/21/49/NGS dated 13th September, 1950 circulated with Railway Board's letter
No. E47CMI/49/3 dated 23rd December, 1950. The question of revising the
percentages of reservation for Scheduled Castes and Scheduled Tribes in post and
services under the Government of India in the light of the population of these
communities as shown in the 1961 census has been under consideration of the
Government for some time. It has now been decided in modification of the decisions
contained in paras 2 and 4(1) of the Ministry of Home Affairs' Resolution dated 13th
September 1950, that the following reservations will hereafter be made for the
Scheduled Castes and Scheduled Tribes in posts and services which are filled by
direct recruitment; What are they? 12% and 5% are raised to 15% and 7% respectively
for SCs and STs, consequent on the census picture and population ratio. Likewise, in
local or regional recruitments (presumably, they are inferior posts) the population
ratio prevalent in the concerned States was to be the basis for reservation quota for
SC&ST.
By the same order, the "carry forward" rule was carried a little further forward by
increasing it, in the absence of suitable candidates from SC&ST, from 2 to 3 years. It
was also provided that the reserved vacancies, if candidates were available (and vice
versa) could well be filled by them, instead of being thrown open to the generalAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

community.
The Board's letter dated April 29, 1970 made a further change by revising the roster.
Positions Nos. 1, 4, 8, 14, 17, 22, 28, 36 were to go to SC/ST candidates. The Note
takes care to avoid total deprivation of changes for a particular year for general
candidates when the vacancies are few:
NOTE: If there are only two vacancies to be filled in a particular year, not more than
one may be treated as reserved and if there be only one vacancy, it should be treated
as unreserved. If on this account, a reserved point is treated as unreserved the
reservation may be carried forward to the subsequent three recruitment years.
Similar provisions, though somewhat different in detail, were made for posts filled by
direct recruitment otherwise than by open competition.
A big break with the past was next made by the Board's proceedings of 11-1-1973
(Annexure K) which hurt the lower classes of employees whose promotion was
regulated by seniority-cum-suitability (i.e., non-selection posts, according to official
jargon). That directive states:
ANNEXURE K After careful consideration the Board have now decided that a quota
of 15% and 7 1/2% for Scheduled Castes and Scheduled Tribes respectively may also
be provided in promotion to the categories and posts in Class I, II, III and IV filled on
the basis of seniority-cum-suitability provided the element of direct recruitment to
those grades, if any, does not exceed 50%.
The number of reserved vacancies in a recruitment year (viz., financial year on the
Railways) should be determined under Board's letter No. E(SCT) 70CM15/10 dated
20-4-70...........
In the case of reserved community candidates equal to the number of reserved
vacancies are not found suitable for promotion even with relaxed standard, the
reserved vacancies may be dereserved after following the procedure prescribed for
dereservation as in the case of selection categories. The quota so dereserved will be
carried forward to three subsequent recruitment years; the year in which no panel is
formed is not to be taken into account for this purpose.
This order has been fiercely attached as unconstitutional. The order attached in
Rangachari's case (supra) related to selection posts at the promotion level but
Annexure K (11-1- 1973) covers promotion to non-selection posts. The whole gamut of
promotions in Classes II, III and IV areas thus comes under the reservation formula.
Annexure I extended the principle of reservation to lower ranks of Class I services (i.e. Junior Class I
scale). The 'carry forward' project, calculated to ensure adequate representation by broadening theAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

time zone to three years, was applicable to all cases of reservations in promotion posts.
One of the major broadside attacks made on the validity of the Railway Board's circulars was the
serious peril to administrative efficiency, a non-negotiable value under Art.
335. The hazards to railway travel, it was urged, would so increase because of the harijan component
and its sub- standard performance that rail-road accidents would escalate and threaten human life!
We must, by way of antidote to this caricature, notice, however, that provisions for special training
and coaching where the recruit was somewhat sub- standard, was specially insisted on and this, at
least partially, overcame the 'awesome' deficiency. No factual material to blame all the ills of the
Indian Railways on the reservation policy was placed before us except a hunch in a Report to be
referred to later. If harijans were excluded would railway accidents have a long holiday ? Courts are
not credulity in robes ! A comprehensive programme of balancing administrative competency with
adequacy of SC&ST representation was attempted by the Railway Board in Annexure M which
provided for in-service training for candidates who were below standard. This letter of the Board
dated 31st August 1974 recalled the earlier letter of 27-4-1959 which provided:
While filling the posts on promotion, however, candidates of three communities
should be judged in a sympathetic manner and arrangements made where necessary
to give to such staff additional training and coaching, to bring them upto the standard
of others. In the light of actual experience and the complex of considerations implied
in Arts. 16(4), 46 and 335 the Board directed, with disturbing concern for the
continued exclusion of SC&ST candidates, as follows:
The matter has been further considered by the Board and it has been decided that if,
during the selection proceedings it is found, that the requisite number of Scheduled
Caste and Scheduled Tribe candidates are not available for being placed on the panel
in spite of the various relaxations, already granted, the best among them i.e. who
secure highest marks, should be earmarked for being placed on the panel to the
extent vacancies have been reserved in their favour. The panel excluding the names of
such persons may also be declared provisionally. Thereafter the Scheduled Caste and
Scheduled Tribe candidates who have been so earmarked may be promoted ad hoc
for a period of six months against the vacancies reserved for them. During the said six
months period, the Administration should give them all facilities for improving their
knowledge and coming upto the requisite standard, if necessary by organising special
coaching classes. At the end of the six months period, a special report should be
obtained on the working of these candidates and the case put up by the Department
concerned to the General Manager through SPO(RP) for a review. The continuance of
the Scheduled Caste and Scheduled Tribe candidates in the higher grades would
depend upon this review. If the candidates are found to have come upto the requisite
standard, their names would be included in the panel and the vacancies dereserved
and filled in the usual manner by candidates from other communities. The procedure
indicated in the preceding para would also apply to promotion to the posts filled on
the basis of seniority-cum-suitability, with the only difference that the Review at theAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

end of the six months period would be carried out by the authority competent to
approve the Select List.
This directive takes good care of harijan-girijan obtuseness, if any.
We move on to Annexure N of February 21, 1976 which relates to carrying forward of
reserved vacancies remaining unfilled. We need not go into its details except to state
that further facilities are offered to SC&ST promotees, on account of unsatisfactory
intake as a fact.
Although on paper what might appear to be pampering concessions were offered to
SC&ST candidates, the painful reality, according to the Union of India, was alarming
under-representation and utter inadequacy of SC&ST personnel in the Railway
Services. Arithmetical manipulations and national concessions incorporated in
government proceedings did not impact on the raw life of depressed classes unless
activist tactics of upgrading the competence and awareness of those human sectors
were fruitfully carried out in a result-oriented manner. The Union of India and the
Railway Board apparently pinned their faith on increasing the percentage hoping that
thereby more harijans would be attracted. The twin reservations of 15% and 7 1/2%
for the SCs and STs to be filled by promotion in Class I, II, III and IV services,
whereby seniority-cum-suitability or selection on the strength of competitive
examinations, had all along been limited in such manner as not to exceed 50%, even
on the application of the 'carry forward' formulae. Since this did not ensure fair
representation, a change was contemplated by Annexure O:
The question of enlarging the scope of the existing scheme of reservation for
Scheduled Castes and Scheduled Tribes in the aforesaid cases has been under the
consideration of the Government of India for some time past and in partial
modification of the instructions contained in the above letters it has now been
decided that henceforth the reservations in posts filled by promotion under the
existing scheme as indicated above would be applicable to all grades or services
where the element of direct recruitment, if any, does not exceed 66-2/3% as against
50 per cent as at present. What was done was to raise the maximum from 50% to
66-2/3% its vice, writ on its face-according to counsel's argument- being promotion
of inefficiency along with promotion of SC&ST appointees. The furious charges of
inefficiency in Administration, injected by incompetence imported through SC&ST
candidates and by frustration and demoralisation of the non-SC&ST members who
were passed over by their less competent juniors, was sought to be supported by
reliance on the Report of the Railway Accidents Enquiry Committee 1968. There was
reference in it to discontent among supervisors inter alia on account of the procedure
of reservation of posts for SC&ST. It is true that the Report has a slant against the
SC&ST promotion policy notwithstanding the assurance given by the Railway Board
to the Committee that instructions had been issued not to relax standards in favour of
SC&ST members where safety was involved. We need hardly say that it is strainingAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

judicial gullibility to breaking point to go that far. This is an argumentum an
absurdum though urged by petitioners with hopeful ingenuity. Nor are we concerned
with certain newspaper items and representations about frustration and stagnation.
On the other hand, the plea, forcefully put forward that economic backwardness
should be the touchstone of any reservation policy in a secular, socialist republic may
merit better examination. Surely, extraneous factors, however passionately projected,
cannot shake or shape judicial conclusions which must be founded on constitutional
criteria and relevant facts only. What then is the defence of the Union to the charge of
departure from equal treatment for all citizens alike ? What is the principle derivable
from the precedents on the points raised ?
A technical point is taken in the counter affidavit that the 1st petitioner is an
unrecognised association and that, therefore, the petitioner to that extent, is not
sustainable. It has to be overruled. Whether the petitioners belong to a recognised
union or not, the fact remains that a large body of persons with a common grievance
exists and they have approached this Court under Art. 32. Our current processual
jurisprudence is not of individualistic Anglo- Indian mould. It is broad-based and
people-oriented, and envisions access to justice through 'class actions', 'public
interest litigation', and 'representative proceedings'. Indeed, little Indians in large
numbers seeking remedies in courts through collective proceedings, instead of being
driven to an expensive plurality of litigations, is an affirmation of participative justice
in our democracy. We have no hesitation in holding that the narrow concept of 'cause
of action' and 'person aggrieved' and individual litigation is becoming obsolescent in
some jurisdictions. It must fairly be stated that the learned Attorney General has
taken no objection to a non-recognised association maintaining the writ petitions.
The case of the Union of India is that Arts. 46, 335, 16(1) and 16(4) must be taken as a
constitutional package and not read in isolation. In that view, the policy of
reservation is geared to equalisation of opportunities for employment and, therefore,
a fulfillment of Art. 16(1). Reading the two sub-articles as complementary to each
other and giving a wider connotation to the expression "appointment", the learned
Attorney General sought to include in its semantic circle appointments by way of
promotion, deputation, transfer and on contract. On this footing, it was urged that
Art. 16(4) completely protected the various directives regarding appointments by
promotion. It is the case of the Government that SC&ST have all along suffered social
and economic deprivation and utter under- representation in the Government
service. Naturally, reservation to boost the chances of the SC&ST in Government
services had to be resorted to as a pragmatic policy of levelling up. Having regard to
administrative efficiency and other social factors, Government had been reviewing
the position from time to time and had tailored its reservation policy to fit the needs
of a given service or state of affairs. The stand of the State is that-
....once the Government have decided after reviewing the overall position of
representation of Scheduled Castes/Scheduled Tribes in Government Services thatAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

the reservation principles should continue in certain types of appointments, the
reservation of a certain number of vacancies have to be provided, irrespective of
whether Scheduled Castes/Scheduled Tribes are already duly represented or not in
specific cadres of the Services.
Although Rangachari's case covered only selection posts, the Union of India took the
view that the same principle held good for nonelection posts also. In fact, if at all the
prospects of SC&STs in Government Service were to be improved, it had to begin
with non-selection posts. They are the lower categories where the members of the
SC&ST have a chance. Provision of reservation in Class I services would be
theoretically attractive to SC&STs but not so much in practice.
....reservation in promotional appointments made by means of
seniority-cum-suitability is necessary because the Scheduled Castes/Scheduled
Tribes who generally occupy the lower positions in the recruitment/promotional
panels cannot get further promotion at all or as per the requisite percentage
alongwith other employees because of their very low position in the seniority list The
submission of the Central Government is that not with standing the extension of the
principle of reservation, the presence of harijans and girijans is sparse. ...In this
connection, an extract from the half yearly report of the Ministry of Railways for the
period ending 31-3-1978 showing the representation of the Scheduled Castes and
Scheduled Tribes in the various Railway Services presented to the Parliament by the
Government is reproduced below....
The table furnished as in 1978 shows that Scheduled Castes have in Class I around 7%
representation, in Class II 9.5%, in Class III 11.1% and even in Class IV (excluding
safaiwalas) only 18%. Safaiwalas, who are menials like scavengers and sweepers, are
mostly drawn from harijans since other communities consider such jobs infra dig. So,
there is 83% representation of SCs among safaiwalas. This is not because of
representation but because no one else is forthcoming for such 'untouchable' jobs.
The Scheduled Tribes have a more pathetic tale to tell. In Class I services they have
1% representation, in Class II, 1.8%, in Class III, 2.2% and in Class IV (excluding
safaiwalas) 5.1% and even among safaiwalas only 1.5%. On the basis of these statistics
the Railway Board's case is that adequacy of representation for SC&STs even
according to their population (forgetting centuries of total exclusion) is a long way
off.
These official figures culled from the Reports of the Commissioner for Scheduled
Castes and Scheduled Tribes are for employment in Central Govt. not confirmed to
the Railways, and reveal how a square deal to SCs and STs may take centuries,
observing the current snail's pace in the intake.
Social realists will read these pessimistic figure of the last ten years which prove the
myth and negate the neurotic rhetoric about the SC&ST communities havingAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

cornered all the posts in the Central Government from Chaprasi to Secretary,
accelerating there by the impending calamity of administrative collapse due to the
disproportionate presence of the 'inefficient' social components! A mere formula of
reservation is not the factum of recruitment. That is morbid fancy. The truth is that
more aggressive policies than paper reservations are the need if equality and
excellence are the creed. Reservation is but one strategy and historically has
established itself. More must be done by a complex of processes by which
harijans/girijans will get boosted in 'capabilities', and mainstreamed to share in the
Civil Service cake. The poor annual assimilation into the public employment sector of
the weakest social segments makes a tragic mockery of the statistical jugglery of
harijan monopoly. Any theory or formula is best tested by how it works, not by how it
is worded. Nikita Kruschev once remarked: "...a theory isolated from practice, is
dead, and practice which is not illumined by ....theory is blind". The theoretical attack
on over representation flowing from the reservation rule must be tried out in
practice, as the figures for the last 10 years show; and the justification for more
facilities and higher percentage in public employment must be validated by the thesis
of social justice. Assertions either way end in a blind alley. That is why we have been
at pains to project the constitutional theory and resultant representation of SC and
ST reservations under Art. 16(4).
Percentage of reservations made in favour of Scheduled Castes (SC) and Scheduled
Tribes (ST).
------------------------------------------------------------
Class I Class II Class III Class IV As on ---------- ---------- ----------- ------------
SC ST SC ST SC ST SC ST
------------------------------------------------------------ 1-1-70 . . . 2.36 0.40 3.84 0.37
9.27 1.47 18.09 3.59 1-1-71 . . . 2.58 0.41 4.06 0.43 9.89 1.70 18.37 3.65 1-1-72 . . . 2.99
0.50 4.13 0.44 9.77 1.72 18.61 3.82 1-1-73 . . . 3.14 0.50 4.52 0.49 10.05 1.95 18.37
3.92 1-1-74 . . . 3.25 0.57 4.59 0.49 10.33 2.13 18.53 3.84 1-1-75 . . . 3.43 0.62 4.98
0.59 10.71 2.27 18.64 3.99 1-1-76 . . . 3.46 0.68 5.41 0.74 11.31 2.51 18.75 3.93 1-1-77 . .
. 4.16 0.77 6.77 0.77 11.84 2.78 19.07 4.35 1-1-78 . . . 4.50 0.85 6.44 0.88 12.22 2.86
19.13 4.66 1-1-79 . . . 4.75 0.94 7.37 1.03 12.55 3.11 19.32 5.19
------------------------------------------------------------
The facts, in the statement we have digested from the Reports of the Commissioner
for Scheduled Castes and Scheduled Tribes, conclusively show the long distance to
travel before the SC&ST members in the civil services can be said to have and a fair or
at least a proportional deal. Classes II and III for the whole of the central services
have a range of 3.84% to 7.37% and 9.27% to 12.55% for Scheduled Castes and 0.37%Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

to 1.03% and 1.47% to 3.11% for Scheduled Tribes while their eligibility is of the order
of 15% and 7-1/2% respectively. What a grievous beeway after 33 long years may be
the acid comment of the victim sector (i.e. the harijans and the girijans).
The Central Government has countered the submission of the petitioners, presented
persuasively by Shri Venogopal, that reservation compounded by the carry forward
rule has ended up almost in cent per cent reservation to SC&STs (thus wholly
excluding others from job opportunities). The counter-affidavit states thus:
I do not admit that the Government is giving 100% reservation to the Scheduled
Castes and Scheduled Tribes. I submit that normally only 15% and 7-1/2% of the
vacancies by means of a roster mechanism are reserved for the Schedule Castes and
Scheduled Tribes respectively. However, in the following cases, it may look as if 100%
of the available vacancies are being given to the Scheduled Castes/Scheduled
Tribes...... Of course, based on Rangachari (supra) the State contends that entry even
at the promotional points is constitutionally permitted and protected. The grievance
that junior harijans steal a march over other senior members of service is exceptional
rather than general, according to the Railway Board, and, in any case, is inevitable
where reservation is permissible. Furthermore the Ministry of Railways, having
regard to Art. 335 had taken special care to give training, coaching and the like, to
prevent inefficiency and to promote competency of SC&ST members in service. The
deponent on behalf of the Union of India has explained the position thus:
I submit that the Ministry of Railways, in 1974 after reviewing the position of intake
of Scheduled Castes and Scheduled Tribes in groups of posts filled by promotion in
Railway Services, and on the basis of a recommendation made by the Parliamentary
Committee on the Welfare of Scheduled Castes and Scheduled Tribes, introduced a
scheme of training of the Scheduled Castes/Scheduled Tribes employees on the jobs
of the posts to which they are to be promoted. According to this scheme, if, during
selection proceedings, it is found that the Scheduled Castes/ Scheduled Tribes of
requisite standards are not available for being placed on the panel, the best among
them numbering to the extent of reserved vacancies i.e. who secure the highest
marks, are provided with in-service training. For this purpose, such candidates are
promoted an ad hoc basis for a period of six months to the grade of the post on the
jobs of which they are to receive training. During the said six months' period, the
administration give them all facilities for improving their knowledge and coming
upto the requisite standard, if necessary by organising special coaching classes. At the
end of six months' period, a special report is obtained on the working of such
candidate which is reviewed by the General Manager or other competent authority.
If, as a result of this review, they are found to have come upto the requisite standard
of fitness to hold the post on regular basis, they are included in the panel and are
promoted to the grade regularly. If, however, the said review reveals that such
candidates, even after receiving the training on the jobs to which they are to be
promoted regularly, have not come upto requisite standard of suitability, suchAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

candidates are immediately reverted to the grade from which they were given ad hoc
promotion for the purpose of training.
A further plea is taken that temporary promotions on ad hoc basis are sometimes
given to SC&ST members purely for short duration "for the purpose of imparting
them with in- service training on the jobs of the post to which they aspire for
promotion". This had to be treated as a training period rather than an
unconstitutional promotion over the heads of seniors. In short, the factual
submission of massive infiltration of incompetent harijans/girijans into the Railway
Service vertically all along the line is refuted by facts and figures. Secondly, the legal
contentions of the petitioners have also been contested by the Union of India (given
earlier).
In this background, we may formulate the following points round which arguments
have ranged and then deal with some mini-submissions and technical objections put
forward before us.
(1) Does Art. 16(1) insist on absolute equality or permit realistic and rational
classification of unequal classes and treatment of such classes differently ?
(2) Do SC&STs stand in a different class from the rest of the Indian community?
(3) Are SC&ST castes, within the scope of Art. 16(2) ?
If so, does Art. 16(4) save special provisions in their favour in matters promotion and allied matters
?
(4) Do the directives under attack impair administrative efficiency to a degree that it is violative of
Art. 335 ?
(5) Do the ten circulars reduce the fundamental right under Art. 16(1) to a husk or cipherise it
altogether ?
We must state certain constitutional fundamentals and societal elementals before we make a
dialectical study of the basic issues thrown up by these cases. Most of the submissions made by
counsel for petitioners cannot survive Rangachari and Thomas (supra) and our task is simplified by
abiding by the propositions laid down therein, because these twin rulings bind us being of benches
of five and seven judges. Even though we would, we could not and even though we could, we would,
not depart from the holdings in these twin land-mark cases which set the gravestone on many of the
contentions.
What are the constitutional fundamentals bearing on egalite vis a vis backward classes, especially
the SC&STs ? What are the social essentials afflicting the life-style of the SCs&STs ? What is
economic backwardness as distinct from social injustice and how does the Constitution strike theAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

path of remedial jurisprudence harmonising the demands of both categories?
A luminous preface to the constitutional values nullified by social realities is found in Dr.
Ambedkar's address to the Constituent Assembly earlier extracted, which draws poignant attention
to the life of contradictions between the explosive social and economic inequalities and the
processes of political democracy. "How long shall we continue to live this life of contradictions ?
How long shall we continue to deny equality in our social and economic life?" Was the interrogation
before the framers of the Constitution and they wanted to enforce the principle of 'one man, one
value'. This perspective must inform the code of equality contained in Arts. 14 to 16. Equality being a
dynamic concept with flexible import this Court has read into Arts. 14 to 16 the pragmatic doctrine
of classification and equal treatment to all who fall within each class. But care must be taken to see
that classification is not pushed to such an extreme point as to make the fundamental right to
equality cave in and collapse. (See observations in Triloki Nath Khosa and Ors. v. State of Jammu
and Kashmir Ray, C.J. in Kerala v. Thomas epitomised the position in a few passages:
Articles 14, 15 and 16 from part of a string of constitutionally guaranteed rights.
These rights supplement each other. Article 16 which ensures to all citizens equality
of opportunity in matters relating to employment is an incident of guarantee of
equality contained in Article 14. Article 16(1) gives effect to Article 14. Both Articles 14
and 16(1) permit reasonable classification having a nexus to be the object to be
achieved.
Discrimination is the essence of classification... Classification is, therefore, to be
founded on substantial differences which distinguish persons grouped together from
those left out of the groups and such differential attributes must bear a just and
rational relation to the object sought to be achieved....
There is no denial of equality of opportunity unless the person who complains of
discrimination is equally situated with the person or persons who are alleged to have
been favoured. Article 16(1) does not bar a reasonable classification of employees or
reasonable tests for their selection. State of Mysore v. V. P. Narasinga Rao. This
equality of opportunity need not be confused with absolute equality...... Under Article
16(1) equality of opportunity of employment means equality as between members of
the same class of employees and not equality between members of separate,
independent class.... The rule of parity is the equal treatment of equals in equal
circumstances. The rule of differentiation in enacting laws differentiating between
different persons or things in different circumstances. The circumstances which
govern one set of persons or objects may not necessarily be the same as governing
another set of persons or objects so that the question of unequal treatment does not
really arise between persons governed by different conditions and different sets of
circumstances.... A classification in order to be constitutional must rest upon
distinctions that are substantial and not merely illusory. The test is whether it has a
reasonable basis free from artificiality and arbitrariness embracing all and omitting
none naturally falling into that category.Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

The learned Chief Justice relied upon earlier decisions to substantiate this
proposition. In Triloki Nath Khosa v. State of J & K(1) this Court had held that the
State may make rules guided by realities just as the legislature "is free to recognise
degrees of harm and it may confine its restrictions to those classes of cases where the
need is deemed to be the clearest." Thus we arrive at the constitutional truism that
the State may classify, based upon substantial differentia, groups or classes and this
process does not necessarily spell violation of Arts. 14 to Therefore, in the present
case if the SC&STs stand on a substantially different footing they may be classified
group-wise and treated separately since there is a Great Divide between the SC&STs
on the one hand and the rest of the Indian community on the other. This is no matter
of speculation or investigation because the Constitution itself has recognised the
direst socioeconomic backward status of these species of humanity. We may quote
Ray, C.J. where he observed:
The Constitution makes a classification of Scheduled Castes and Scheduled Tribes in
numerous provisions and gives a mandate to the State to accord special or favoured
treatment to them. Article 46 contains a Directive Principle of State Policy-
fundamental in the governance of the country enjoining the State to promote with
special care educational and economic interests of the Scheduled Castes and
Scheduled Tribes and to protect them from any special injustice and exploitation.
Article 335 enjoins that the claims of the members the Scheduled Castes and
Scheduled Tribes to the services and posts in the Union and the States shall be taken
into consideration. Article 338 provides for appointment by the President of a Special
Officer for the Scheduled Castes and Scheduled Tribes to investigate all matters
relating to the safeguards provided for them under the Constitution. Article 341
enables the President by public notification to specify castes, races or tribes which
shall be deemed to be Scheduled Castes in the States and the Union Territories.
Article 342 contains provision for similar notification in respect of Scheduled Tribes.
Article 366(24) and (25) defines Scheduled Castes and Scheduled Tribes. The
classification by the impugned rule and the order is with a view to securing adequate
representa-
tion to Scheduled Castes and Scheduled Tribes in the services of the State as
otherwise they would stagnate in the lowest rung of the State services.
Article 335 of the Constitution states that claims of members of the Scheduled Castes
and Scheduled Tribes shall be taken into consideration in the making of
appointments to the services and posts in connection with affairs of the State
consistent with the maintenance of efficiency of administration. I had made similar
observations in the same case: The Directive Principles of State Policy, fundamental
in the governance of the country, enjoin on the State the promotion 'with special care
the educational and economic interests of the weaker sections of the people, and, in
particular, of the Scheduled Castes and the Scheduled Tribes... and protect them from
social injustice'. To neglect this obligation is to play truant with Art. 46. Undoubtedly,Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

economic interests of a group-as also social justice to it-are tied up with its place in
the services under the State. Our history, unlike that of some other countries, has
found a zealous pursuit of government jobs as a mark of share in State power and
economic position. Moreover, the biggest-and expanding, with considerable State
undertaking, employer is Government, Central and State, much so appointments in
the public services matter increasingly in the prosperity of backward segments. The
Scheduled Castes and Scheduled Tribes have earned special mention in Art. 46 and
other weaker section' in this context means not every 'backward class' but those
dismally depressed categories comparable economically and educationally to
Scheduled Castes and Scheduled Tribes.
Proceeding on this footing, the fundamental right of equality of opportunity has to be
read as justifying the categorization of SC&STs separately for the purpose of
"adequate representation" in the service under the State. The object is
constitutionally sanctioned in terms, as Arts. 16(4) and 46 specificate. The
classification is just and reasonable. We may, however, have to test whether the
means used to reach the end are reasonable and do not outrun the purposes of the
classification. Thus the scope of the case is narrowed down.
Of course, apart from Art. 16(1), Art. 16(2) expressly forbids discrimination on the
ground of caste and here the question arises as to whether the Scheduled Castes and
Tribes are castes within the meaning of Art. 16(2). Even assuming that there is
discrimination, Art. 16(2) cannot be invoked unless it is predicated that the
Scheduled Castes are 'castes'. Terminological similarities are an illusory guide and we
cannot go by verbal verisimilitude. It is very doubtful whether the expression caste
will apply to Scheduled Castes. At any rate, Scheduled Tribes are identified by their
tribal denomination. A tribe cannot be equated with a caste. As stated earlier, there
are sufficient indications in the Constitution to suggest that the Scheduled Castes are
not mere castes. They may be something less or some thing more and the time badge
is not the fact that the members belong to a caste but the circumstance that they
belong to an indescribably backward human group. Ray, C.J. in Kerala v. Thomas
(supra) made certain observations which have been extracted earlier to make out that
"Scheduled Castes and Scheduled Tribes are not a caste within the ordinary meaning
of caste". Since a contrary view is possible and has been taken by some judges a
verdict need not be rested on the view that SCs are not castes. Even assuming they
are, classification, if permitted, will validate the differential rules for promotion.
Moreover, Art. 16(4) is an exception to Art. 16(2) also.
The constitutional enquiry is whether the harijan/girijan fold is so sharply marked off
from the rest of the Indian human family as to justify classification for considerate
treatment in the field of public employment ?
Let us be sure of the social facts. Mark Twain cynically remarked once: "Get your
facts first, and them you can distort them as much as you please." By that token, letAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

us scan the status of the SC&STs, the result of reservations in habilitating them into
State services and the depressment impact on efficiency by supersession of
meritorious seniors. It is a fact of our social history and a blot on our cultural heritage
that 135 million men and women, described as SC&STs, have been suffering as
"suppressed classes", denied human dignity and languishing as de facto bonded
labour. They still are, in several places, "worse than the serf and the slave" and "their
social standard is lower than the social standard of ordinary human beings"
(Ambedkar). Tortured, violated and even murdered, the saga of the SC&STs is not
only one of economic exploitation but of social ostracisation. Referring to the sorrows
of the suppressed shudras (what I prefer to call the panchama proletariat) Swami
Vivekananda demanded shudra raj and refuted the incapabilities of the groaning
untouchables:
"Aye, Brahmins, if the Brahmin has more aptitude for learning on the ground of
heredity than the Pariah, spend no more money on the Brahmin's education but
spend all on the Pariah. Give to the weak, for there all the gift is needed... Our poor
people, these downtrodden masses of India, therefore, require to hear and to know
what they really are. Aye, let every man and woman and child, with-out respect of
caste or birth, weakness and strength, hear and learn that behind the strong and the
weak, behind the high and the low, behind everyone, there is that Infinite Soul,
assuring that infinite possibility and the infinite capacity of all to become great and
good. Let us proclaim to every soul 'Arise, awake and stop not till the goal is reached.'
Arise, awake! To make democracy functional and the republic real the social and
economic personality of these backwardmost sections had to be restored. From this
angle, the ancient injustice on the shudras among the shudras has to be liquidated by
effective equalising measures. Power, material power, is the key to socioeconomic
salvation and the State being the nidus of power the framers of the Constitution have
made provision for representation of these weaker sections both in the legislature
and the executive.
More poignant is the fact that all the welfare programmes have been only on paper,
not in practical life. With all the 'pampering' complained of, we find that these
downtrodden millions remain at the bottom of the socioeconomic scale and totter in
the administrative services surviving with difficulty and securing some promotion
here or there amidst a hostile milieu. If the concessions, reservations, relaxations and
other partisan provisions had actually brought into the Services a considerable
percentage at least commensurate with their population, maybe, the grievance voiced
may ring true. But as late as 1971, a former Minister, B. S. Murthy, in his book
"Depressed and Oppressed (Forever in Agony)" has given a sombre picture of the
actual plight of the harijans of India and the figures of employment in Government
Services of Scheduled Castes and Tribes as on 1-1-1970 (20 years after the
Constitution) furnished by him (p. 74) are tell tale. In Class I services
percentage-wise these castes which constitute 22.5% of India's population had 0.40%
in Class II, 0.40, in Class III, 1.47 and in Class IV, 3.41. This was socioeconomicAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

democracy in reverse gear and a callous picture of under-representation in
administration as if harijans and girijans were still untouchable and unapproachable,
vis-a-vis Services under the State. Once we realise with John Tyndall that "It is as
fatal as it cowardly to blink facts because they are not to our taste", the wind is taken
out of the sails of the case of the petitioners. For, in truth and actual life whatever the
Railway Board's orders may say the representation of the SC&STs remains
substantially below the sanctioned level although fair representation, at least in
proportion to their population is what is demographically just, ignoring for the
moment the neutralisation of the iniquitions past.
We must remember that Art. 14 speaks of equality before the law and Art. 16
vouchsafes equality of opportunity. The social dynamics of equality involve the
strategy of equalisation in a society of stratification through casteification. One of us
did observe :
"In a spacious sense, 'equal opportunity' for members of a hierarchical society makes
sense only if a strategy by which the under privileged have environmental facilities
for developing their full human potential. This consummation is accomplished only
when the utterly depressed groups can claim a fair share in public life and economic
activity, including employment under the State, or when a classless and casteless
society blossoms as a result of positive State action. To help the lagging social
segments, by special care, is a step towards and not against a larger and stabler
equality.....
It is a statistically proved social reality in India that the depressed employment
position of harijans is the master problem in the battle against generations of
retardation, and 'reservation' and other solutions have made no significant impact on
their employment in public services. In such an unjust situation, to maintain
mechanical equality is to perpetuate actual inequality. A battery of several
programmes to fight down this fell backwardness must be tried out by the State."
Subha Rao, J. in Devadasan's case brought out the need for equalisation to produce
stable equality in society by a telling imagery. Although he was in a minority on one
point in that case, that did not detract from the validity or force of the general
observations:
Article 14 lays down the general rule of equality. Article 16 is an instance of the
application of the general rule with special reference to opportunity of appointments
under the State. It says that there shall be equality of opportunity for all citizens in
matters relating to employment or appointment to any office under the State. If it
stood alone, all the backward communities would go to the wall in a society of uneven
basic social structure; the said rule of equality would remain only an utopian
conception unless a practical content was given to it. Its strict enforcement brings
about the very situation it seek to avoid. To make my point clear, take the illustrationAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

of a horse race-one is a first class-race horse and the other an ordinary one. Both are
made to run from the same starting point. Though theoretically they are given equal
opportunity to run the race, in practice the ordinary horse is not given an equal
opportunity to compete with the race horse. Indeed, that is denied to it. So a
handicap may be given either in the nature of extra weight or a start from a longer
distance. By doing so, what would otherwise has been a force of a competition would
be made a real one. The same difficulty had confronted the makers of the
Constitution at the time it was made. Centuries of calculated oppression and habitual
submission reduced a considerable section of our community to a life of serfdom. It
would be well nigh impossible to raise their standards if the doctrine of equal
opportunity was strictly enforced in their case. They would not have any chance if
they were made to enter the open field of competition without Adventitious aids till
such time when they could stand on their own legs.
A strikingly similar strain of justice thinking has been developed in other
jurisdictions in the field of equal protection and benign discrimination by Polyvos G.
Polyviou in his book "The Equal Protection of the Laws". It may be meaningful to
notice the argument :
"....focuses on the concepts of equal treatment and equal opportunity, professes to
construe them realistically, and declares that '(t) he minority applicant does not have
an opportunity "equal" to the white's because the discriminatory denial of
educational, professional and cultural opportunities for generations past has severely
handicapped him in any contest of early intellectual attainment'. As Professor Cox
has well put the question, '(d) we achieve equality by putting each individual on the
same starting line today or by giving minority applicants head-starts designed to
offset the probable consequences of past discrimination and injustice against the
group with which the applicant is identified ?
The same author deals with 'reverse discrimination' in school admissions and refers
to Prof. Dworkin's socio-jural defense of preferences:
Nor should it be forgotten in this connection that, at least in terms of traditional
theory, rights to equal treatment and to freedom from discrimination, as normally
conceived, are personal and individual, and that '(e)qual protection is not achieved
through (the) indiscriminate imposition of inequalities for the alleged benefit of
groups, however disadvantaged. Benevolent quotas and reverse discrimination on
this view, fatally offend fundamental notions of individualism inherent in the notion
of equality. In answer, it may be said that to regard the concept of equality simply
from this (traditionally) individualistic point of view is to take an unduly restrictive
view of its social function and to ignore its allegedly multifaceted character. Or, to
adopt a somewhat different strategy, one may read the right to equal treatment (both
the more general right to equality and the right enshrined in the constitutional
guarantee of equal protection) in a particularly abstract way and formulate it in suchAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

a manner that it is not necessarily violated by the adoption of benign racial
classifications. In this way, Professor Dworkin distinguishes between two 'different
sorts of rights' which individuals may be said to have. The first is the right to equal
treatment, which is the right to an equal distribution of some opportunity or
resource, and the second is the right to treatment as an equal, 'which is the right, not
to receive the same distribution of some burden or benefit, but to be treated with the
same respect and concern as anyone else'. For Dworkin it is the right to treatment as
an equal that is fundamental, whilst the right to equal treatment is only derivable,
and it is the former that, as a general matter, is given 'constitutional standing' by the
Equal Protection Clause. In other words, white applicants for admission to Law
School who may have been turned away because of the reservation of some places for
members of disadvantaged minority groups cannot (in a case like the one set out
above) successfully complain, the reason being that they do not have a right to equal
treatment in the assignment of places, but they do have the right to be treated as
equals, that is, with equal respect, concern and sympathy, in the making of decisions
as to which admissions standards should be used. More specifically, this right is
viewed by Dworkin as meaning that each candidate for admission has a right that his
interests should be looked at 'as fully and sympathetically' as the interests of any
others when decisions are being taken as to which of the many possible criteria for
admission to elevate to the status of the pertinent ones. But if this condition is
satisfied, rejected white applicants will fail in their contention that the particular
admissions program was unfair and unconstitutional (even if they had been
effectively excluded from consideration as a result of the adoption of racial criteria in
determining the allocation of some of the available places). The simple question
Dworkin would ask in these cases is whether the particular admissions program
serves a proper policy that respects the right of all members of the community to be
treated as equals, but not otherwise. No debate is needed to uphold reservation in
promotions as such. Not only has Rangachari sustained it in regard to selection posts,
Thomas's case decided by a Bench of seven Judges, has expressly approved
Rangachari. The only question bearing on reservation vis-a-vis promotion is as to
whether it is unconstitutional if it is extended to non-selection posts while it is
constitutional in regard to selection posts.
Anyway, Annexure F, one of the circulars sought to be quashed by the petitioners
relates only to selection posts and has been expressly upheld in Rangachari's case.
The quantum of reservation is not excessive; the field of eligibility is not too
unreasonable, the operation of the reservation is limited to selection posts and no
relaxation of qualifications is written into the circular except that candidates of the
SC&ST communities "should be judged in a sympathetic manner". Moreover,
administrative efficiency is secure because there is a direction "to give such staff
additional training and coaching, to bring them up to the standard of others". The
rejection of the invalidatory contention of the petitioners is inevitable.Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

Annexure H is bad for unconstitutionality according to the petitioners for many
reasons. For one thing, an SC/ST employee gets one grading higher than otherwise
assignable to him on the record of his service. So much so, if he is 'good' he will be
categorised as 'very good'. This fiction or fraud in grading is said to be a vice
rendering the promotional prospects unreasonable. We do not agree. Superficially
viewed, this clumsy process of reclassifying ability may strike one as disingenuous. Of
course, this concession is confined to only 25% of the total number of vacancies in a
particular grade or post filled in a year. So there is no rampant vice of every harijan or
girijan jumping over the heads of others. More importantly, we think this is only an
administrative device of showing a concession or furtherance of prospects of
selection. Even as under Art. 15(4) and Art. 16(4) lesser marks are prescribed as
sufficient for SC&STs or extra marks are added to give them an advantage the
re-grading is one more method of boosting the chances of selection of these
depressed classes. There is nothing shady about it. If there is advancement of
prospects of SC&ST by addition of marks or prescribing lesser minimum marks or by
relaxing other qualifications, I see no particular outrage in re- categorisation which is
but a different mode of conferring an advantage for the plain and understandable
reason that SC&STs do need some extra help. It is important to note that the
prescribed minimum qualifications and standards of fitness are continued even for
SC&STs under Annexure H. The other vice pointed out against Annexure H is that
the qualifying marks in respect of SC&ST candidates is somewhat less than is
applicable to candidates of unreserved groups. There is no merit in this objection and
no good ground exists which militates against the constitutionality of Annexure H.
Annexure I is also unexceptionable since all that it does: is to readjust the proportion
of reservation in conformity with the latest Census. Posts for which recruitment,
realistically speaking, takes place on a regional basis are subjected to reservation
taking into account the percentage of SC&ST population in the concerned State. This
is also reasonable. Likewise, the carry forward rule being raised from 2 years to 3
years also cannot be struck down. It must be realised that law is not an abstraction
but an actual prescription in action. So what we have to be more careful about is to
scrutinise whether the carry forward rule by being increased to 3 years is going to
confer a monopoly upon the SC&ST candidates and deprive others of their
opportunity for appointment. From the percentage furnished by the Railway Board
we find that even if we carry forward vacancies for any number of years there is no
prospect, within the reasonable future, of sufficient number of SC & ST candidates
turning up to fill them. There is a provision that if sufficient number of candidates
from the SC & ST are not found, applicants from the unreserved communities will be
given the appointment provisionally. After 3 years those vacancies cease to be
reserved. Going by the actuals it is clear that no serious infraction of any individual's
fundamental right under Art. 16(1) takes place and no monopoly is conceivably
conferred on SC&ST candidates, they are not available in sufficient numbers to reach
anywhere near the percentage reserved.Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

Even going by the majority, Devadasan's case ( ' ) lays down the proposition that
under Art. 16(4) "reservation of a reasonable percentage B of posts for members of
the Scheduled Castes and Tribes is within the competence of the State. What the
percentage ought to be must necessarily depend upon the circumstances obtaining
from time to time." Madholkar, J. speaking for the majority has struck down only one
restriction. "In order to effectuate the guarantee each year of recruitment will have to
be by itself and the representation for backward communities should not be so
excessive as to create a monopoly or to disturb unduly the legitimate claims of other
communities." (emphasis added). Unlimited reservation of appointments may be
impermissible because it renders Art. 16(1) nugatory. At the same time, Art. 16(4),
calculated to promote social justice and expressive of the deep concern of the
Constitution for the limping bracket of Indians, must be given full play. That is why
the only restraint imposed by Mudholkar, J. is that an exercise of power under Art.
16(4) "does not mean that the provision made by the State should have the effect of
virtually obliterating the rest of the Article, particularly clauses (1) and (2) thereof."(')
By the three-year 'carry forward' rule one is unable to see how, in practice, the total
vacancies will be gobbled up by the harijan/girijan groups "virtually obliterating" Art.
16(1). The court has made it very clear that the problem of giving adequate
representation to backward classes under Art. 16(4) is a matter for the Government
to consider, bearing in mind the need for a reasonable balance between the rival
claims as pointed out in Balaji's case.(2) It is true that in Balaji's case and Devadasans
case(l) 'the carry forward' rule for backward classes for exceeded 50% and was struck
down. We must remember that the percentage of reservation for backward classes
including SC&ST was rather high in both the cases. In Devadasan's case the court
went into the actuals, not into the hypothetical. This is most important. The Court
actually verified the degree of deprivation of the 'equal opportunity' right and
discovered: (3 ) In the case before us 45 vacancies have actually been filled out of
which 29 have gone to members of the Scheduled (1) [1964] 4 SCR 680 at 695.
(2) [1963] Supp. 1 SCR 439.
(3) Ibid at 693-94.
Castes and Tribes on the basis of reservation permitted by the carry forward rule. This comes to
about 64.4% of reservation. Such being the result of the operation of the carry for ward rule we
must, on the basis of the decision in Balaji's case hold that the rule is bad.
(emphasis added) What is striking is that the Court did not take an academic view or make a
notional evaluation but checked up to satisfy itself about the seriousness of the infraction of the
right. On that footing, the petitioners have not demonstrated that in any particular year, virtually
and in actual terms of promotion, there has been-a substantial excess over 50% in favour of the
SC&ST promotees. Mathematical calculations, departing from realities of the case, may startle us
without justification, the apprehension being misplaced. All that we need say is that the Railway
Board shall take care to issue instructions to see that in no year shall SC&ST candidates be actuallyAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

appointed to substantially more than 50% of the promotional posts. Some excess will not affect as
mathematical precision is different in human affairs, but substantial excess will void the selection.
Subject to this rider or condition that the 'carry forward' rule shall not result, in any given year, in
the selection or appointments of SC&ST candidates considerably in excess of 50%, we uphold
Annexure I. Heated arguments about the hurt caused by Annexure 'J' have been addressed to us. It
deals with the 40-point roster and the posts allotted to the SC&ST allottees. Once the fundamental
premises are accepted there is nothing unreasonable or wrong in Annexures 1 and 2 to Annexure J.
It is significant that with a view to prevent total exclusion of others there is a provision that if there
are only two vacancies in a given year, in more than one may be treated as reserved and if there is
only one vacancy, it should be treated as unreserved. Implementation of reservations necessarily
involves practical steps like evolving a roster system. Once the parameters of reservation are within
the framework of the fundamental rights, minute scrutiny of every administrative measure and
hunting for unconstitutionality is not permissible.
Far more serious is the criticism of Annexure 'K' on the basis of which reservations were introduced
even to promotion posts filled by the 'seniority-cum-suitability' rule. Some other relaxations and con
cessions also are granted under it to SC/ST candidates. But the maximum mayhem inflicted by
Annexure K is in the extension of the operation of promotional reservation to non-selection posts. It
was urged that Rangachari (supra) did not cover non-selection posts and, there fore, could not be an
authority to sustain its validity. There is no force in this submission.
The sting of the argument against reservation is that it promotes inefficiency in administration by
choosing sub- standards candidates in preference to those with better mettle. Competitive skill is
more relevant in higher posts, especially those where selection is made by competitive
examinations. Lesser classes of posts, where promotion is secured mechanically by virtue of
seniority except where the candidate is unfit, do not require a high degree of skill as in the case of
selection posts. (See 1968 1 SCR p. 721 at
734). It is obvious that as between selection and non- selection posts the role of merit is functionally
more ` relevant in the former than in the latter. And if in Rangachari reservation has been held valid
in the case of selection posts, such reservation in non-selection posts is an afortiori case. If, in
selecting top officers you may reserve posts for SC/ST with lesser merit, how can you rationally
argue that for the posts of peons or lower division clerks reservation will spell calamity ? The part
that efficiency plays is far more in the case of higher posts than in the appointments to the lower
posts. On this approach Annexure K is beyond reproach.
One may easily sympathise with holders of non- selection posts. They are many in number in the
lower stations of life. They are economically backward and burdened with the drudgery of life. That
is why there is a ballyhoo raised by a larger number of people when some categories in far more
distressing social situations enter the arena with preferential treatment. Looking at the problem
from the point of view of law and logic and the constitutional justification under Art. 16(4) for
reservation in favour of the panchama proletariat there is nothing to strike down in Annexure K. As
between the socially, even economically depressed and the economically backward, the Constitution
has emphatically cast its preference for the former. Who are we, as Judges to question the wisdom ofAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

provisions made by Government within the parameters of Art. 16(4)? The answer is obvious that the
writ of the court cannot quash what is not contrary to the Constitution however tearful the
consequences for those who may be adversely affected. The progressive trend must, of course, be to
classify on the have-not basis but the SC/ST, category is, generally speaking, not only deplorably
poor but also humiliatingly pariah in their lot. Maybe, some of the forward lines of the backward
classes have the best of both the words and their electoral muscle qua caste scares away even radical
parties from talking secularism to them. We are not concerned with that II dubious brand. In the
long run, the recipe for backwardness is not creating a vested interest in backward castes but
liquidation of handi caps, social economic, by constructive projects. All this is in another street and
we need not walk that way now.
Trite arguments about efficiency and inefficiency are a trifle phoney because, after all, at the higher
levels the harijan/girijan appointees are a microscopic percentage and even in the case of Classes III
and II posts they are negligible. The preponderant majority coming from the well reserved
communities are presumably efficient and the dilution of efficiency caused by the minimal induction
of a small percentage of 'reserved' candidates cannot affect the over-all administrative efficiency
significantly. Indeed, it will be gross exaggeration to visualise a collapse of the Administration
because 5 to 10% of the total number of officials in the various classes happen to be sub-standard.
Moreover, care has been taken to give in-service training and coaching to correct the deficiency.
It is fashionable to say-and there is, perhaps, some truth in it- that from generation to generation
there is a deterioration in efficiency in all walks of life from politics to pedagogy to officialdom and
other professions. Nevertheless, the world has been going forward and only parties whose personal
interest is affected forecast a doom on account of progressive deficiency in efficiency. We are not
impressed with the misfortune predicted about governmental personnel being manned by morons
merely because a sprinkling of harijans/girijans happen to find their way into the Services. Their
apathy and backwardness are such that in spite of these favourable provisions, the unfortunates
have neither the awareness nor qualified members to take their rightful place in the Administration
of the country. The malady of modern India lies elsewhere, and the merit-mongers are greater risks
in many respects than the naive tribals and the slightly better off low castes. Nor does the specious
plea that because a few harijans are better off, therefore, the bulk at the bottom deserves no jack-up
provisions merit scrutiny. A swallow does not make a summer. Maybe, the State may, when social
conditions warrant, justifiably restrict harijan benefits to the harijans among the harijans and forbid
the higher harijans from robbing the lowlier brethren We have adverted to Annexure M earlier in
this judgment which shows the determination of Government to impart in-service training to those
SC&ST candidates who are found to be below par. Even temporary promotions on an ad hoc basis
are limited to six months only to give training and experience than the spoil permanently the
efficiency of the system. The Annexure has come under attack because the reservation quota has
been raised thereby from 50 to 66- 2/3%. We have earlier dis cussed this aspect and pointed out that
what is important is not so much the figures mentioned on paper but the facts and circumstances in
real life. We have also entered a caveat that in any particular year there shall not, as a fact, be a
substantial increase upon 50% of induction of 'reserved' candidates. It is true that Shri Venugopal,
counsel for some of the petitioners tried to demonstrate that on account of reservation percentages
coupled with the carry forward rule it is perfectly within the realm of possibility that in some years aAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

monopoly may be conferred on the SC&ST candidates for certain categories or classes of posts. The
mystic "maybe" do not scare us. The actual "must be" will alert us. The Constitution deals with social
realities, not speculative possibilities. I have limited the physical operation of reservation in any
particular year in such a manner that there will be a real opportunity for the exercise of the right
under Art. 16(1) for every candidate of the unreserved communities.
Certain minor attacks such as that a candidate of the SC&ST communities who has failed may still
be tried if other successful candidates from those communities are not forthcoming. This may seem
strange disbelief in examinations as measure of merit. But to read stray provisions in isolation may
be unfair to the scheme. Look at the desperate State in which Government is trying to give fair
representation to harijans/girijans in Administration. These miserables suppressed by centuries of
trampling are still slumbering despite inducements to awaken. It is a genetic calumny and
unscientific assertion to castigate the SC&ST communities as possessed of less intellectual potential
what with Valmiki and Vyasa to Baba Sahib Ambedkar. The darkening and be numbing
environment of ages in which shudras and panchamas have suffered their mental powers to be
chained accounts for their seeming, retardation. Once brighter atmosphere and better opportunity
enliven their talent their contribution to the Indian treasury will raise the human resources and
democratic status of Bharat. A democracy of talent is an inarticulate major premise of our culture.
The fundamental question arises as to what is "merit" and "suitability". Elitists whose sympathies
with the masses have dried up are, from the standards of the Indian people, least suitable to run
Government and least meritorious to handle state business, if we envision a Service State in which
the millions are the consumers. A sensitized heart and a vibrant head, tuned to the tears of the
people, will speedily quicken the developmental needs of the country, including its rural stretches
and slum squalour. Sincere dedication and intellectual integrity-these are some of the major
components of "merit" and "suitability"-not degrees from Oxford or Cambridge, Harvard or
Stanford or simian, though Indian, institutions. Unfortunately, the very orientation of our selection
process is distorted and those like the candidates from the SC&ST who, from their birth, have had a
traumatic understanding of the conditions of agrestic India have, in one sense, more capability than
those who have lived under affluent circumstances and are calIous to the human lot of the sorrowing
masses. Moreover, our examination system makes memory the master of 'merit' and banishes
creativity into exile. We need not enter these areas where a fundamental transformation and a
radical re-orientation even in the assessment of the qualities needed by the personnel in the
Administration and the socialist values to be possessed by the echelons in office is a consummation
devoutly to be wished. This may have to be subjected to a national debate. The colonial hangover
still clings to our selection processes with superstitious tenacity and narrower concepts of efficiency
and merit are readily evolved to push out Gandhis and J.Ps, Ambedkars and Nehrus, to mention but
a few who knew the heart-beats of the people. I diva gate and make these observations only to
debunk the exaggerated argument about harijans and girijans being sub-standard. We may put
aside this angle of vision and approach the problem traditionally because every new idea has
resistance to encounter before acceptance, every original thought has been branded a hearsay. Be
that as it may, the constitutional merits of the various Board Circulars now discussed do not warrant
their judicial 'execution'-subject to certain cautionary limitations already indicated.Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

The argument that there are rich and influential harijans who rob all the privileges leaving the
serf-level sufferers as suppressed as ever. The Administration may well innovate and classify to
weed out the creamy layer of SC&ST but the court cannot force the State in that behalf.
For a comparative thought we may glance at Polyviou's 'The Equal protection of the laws': (') "A
third argument traditionally employed against the use of preferential discrimination is that
affirmative measures of the kind discussed here may significantly curtail efficiency. It does indeed
stand to reason that the immediate result of benignity in admission and selection process will
almost certainly be the selection of those who are not as competent or as able as some of those left
out. 'Special admission programmes, almost by definition, operate to in sure that students are
placed in schools for which they are (1) The equal protection of the laws by G. Polyviou p.
360. not qualified ! The same objection applies with equal, if not more, force to the area of
employment and elsewhere. One possible answer is that the importance of efficiency must be
compared with and ultimately set against the significance of integration or the prevention of
discrimination, and that integration and the rectification of socially harmful deprivation are the
more pressing needs. Or one can fall back on the very different arguments that traditional admission
processes are unfair because these are geared to the usual type of applicant and that preferential
treatment after all only seeks to counteract such inherent bias. There is a human problem behind
these writ petitions which we clearly appreciate. Most of the Classes II, III and IV employees are
economically backward and struggle for survival what with price spirals and other tribulations. They
hope, after years of yeomen service, to get some promotion and augment their poor resources in the
afternoon of their life. Then they find another class, with which the Constitution shows ultra
sympathy, elbowing them out, not on a massive scale, but minimally. Even this marginal push hurts
these species living at subsistence level and so they scream. The economically backward and the
socio-economically backward truly belong to the 'have-not' camp and must jointly act to bring about
a transformation of the economic order by putting sufficient pressure and make Art. 38 a living
reality. Estrangement between the two categories weakens the militancy of a joint operation to inject
social justice in the current economic order. The truth is that the employment market is
distressingly a musical chair business and when starvation faces men their sympathy for their far
weaker brethren vanishes. The true solution for the country's problems, as reflected in these writ
petitions, is in developmental expansion involving the millions, rather than denial to the weakest
sector of Indian life the morsel to which it is justly entitled. Even Administration will do well to
remember that Indian despair, after infinite patience, may augur danger unless 'the sorry scheme of
things entire' is remoulded nearer to Art. 38. Even these observations are made only to emphasise
that the legal content of the contentions put forward by the petitioners is less than presentable
although their economic grievance may be agonisingly genuine. The Court has its limitations unlike
the Administration and can give justice only under the Constitution and not over it.
The human pressure behind these writ petitions is the chronic drought of employment opportunities
despite talent enough to make deserts bloom. So long as this scarcity persists and power goes with
office, the jaundiced politics of snatching the jobs going, initially or at promotion level, by hook or
crook, is the only 'development' that takes place, whatever the National Plans proclaim. The vast
human potential of the harijans and girijans, on-fifth of the Indian people, goes to thistles and everyAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

communal effort to twist the politics of power for promoting chances of getting jobs becomes
inevitable caste being a deeprooted pathology in our country. Thus jobbery, politics, casteism and
elections make an unholy, though invisible, alliance against national development which alone can
liberate Indians from social and economic privation. If democracy itself thus plays into the hands of
hostile forces, the jurisprudence of keeping the backward as backward and perpetuation of
discrimination as a vested caste right may prevail as a rule of life.
The remedy of 'reservations' to correct inherited imbalances must not be an overkill. Backward
classes, outside the Scheduled Castes and Tribes, cannot bypass Art. 16(2) save where very
substantial cultural and economic disparity stares at society. The dubious obsession with
'backwardness' and the politicking with castes labelled backward classes may, on an appropriate
occasion, demand judicial examination. The politics of power cannot sabotage the principles of one
man, one value. No sociological explanation for the flood of ruinous writ petitions regarding service
conditions can be found except on this basis. Behind the writ petitions we deal with now is caste
clamour to keep all the jobs safe from being 'robbed' by 'reserved' communities. It is forward caste
versus backward caste, wearing the casteless caste-marks! And the political process is likewise
caste-polluted Gunnar Myrdal writes in his Asian Drama: ( ' ) The type of appeal that can be made
by politicians has also changed greatly since the liberation movement. They can no longer put the
blame for poverty and stagnation on colonial masters, but must explain why there is not great
progress now that India is independent Thus a key to the understanding of the power of the political
bosses is the inherited social stratification of India and, above all, its caste system. At election times
the caste groups function as political vote banks whereby the ballots of their members are joined to
the candidate with a party label. For this reason alone the local political bosses have a vested interest
in preserving the social and economic status quo and exploiting it as a matrix for political action.
(1) Gunnar Myrdal, Asian Drama, Vol. I, pp.
M. N. Srinivas, the noted sociologist is more than right (1) A One cannot help wondering whether
the drive to political maturity is, after all, a good thing in a country which has still not had a proper
social revolution. It may well result in premature old age. We need now, not stagnation wearing the
mask of stability and scrambling acrimoniously over the same shrunken cake, but progress by the
constructive process of explosive rural development and exploitation of the untapped human
potential of the Scheduled Castes and Scheduled Tribes. Sterile 'reservations' will not help us go
ahead unless, alongside of it, we have heroic national involvement of the masses in actual action, not
paper-logged plan exercises. In the last analysis, privation can be banished only by production,
discontent by distributive justice and litigation by socially relevant Justice. The writ petitions are,
regrettably, negative, although the driving force of penury deserves sympathy. This, perhaps, is a
materialist interpretation of 'service litigation' and a trim foot-note to these writ petitions. D Before
I conclude, I must strike a futuristic note. Excellence and equality may cooperating fruitfully and
need not compete destructively. Ultimately harijan/girijan militancy must find fulfillment in
effective main-streaming and creative contribution. While they have miles to go, they have promises
to keep. The poignant words of the Reverend Jesse Jackson come to my mind (1) "I don't see how,
we can survive as a people if we don't have a great push for excellence now....A lot of what we've
done in the past will be in vain if we don't. We can make one of the most valid contributions toAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

Western civilization, even more of a contribution than slavery. Because slavery was our great
contribution against our will. Now it's time for us to make a great contribution as an act of will."
Given the opportunity and the environment, the Indian dalits can make India great and give up
crutches.
The writ petitions as well as the Special Leave Petitions cannot but be dismissed.
PATHAK, J.-My brothers Krishna Iyer and Chinnappa Reddy are agreed that the writ petitions
should be dismissed. They have held against the petitioners on the several contentions raised in the
(1) M. N. Srinivas, "Changing Attitudes in India Today" Yogana, October I 1961, p. 26.
case. With respect, I find myself unable to agree with all that they have said.
I intend to confine myself here to certain aspects of the case which appear to possess a fundamental
importance.
Three provisions of the Constitution relate to reservations for Scheduled Castes and Scheduled
Tribes. They are Art. 46, Art. 16(4) and Art. 335. The three form a single frame of reference. Art. 46,
a Directive Principle of State Policy, proclaims the principle that the State shall promote with special
care the educational and economic interests of the weaker sections of the people, and, in particular,
of the Scheduled Castes and the Scheduled Tribes, and shall protect them from social injustice and
all forms of exploitation. One of the modes in which the economic interests of the Scheduled Castes
and Scheduled Tribes can be promoted is the reservation of appointments or posts in their favour in
services under the State where they are not adequately represented. Art. 16(4) declares that when
the State intends to make such provision nothing in Art. 16 shall prevent it from doing so. The
equality of opportunity guaranteed to all citizens in matters relating to employment or appointment
to any office under the State will not restrain the State from making such reservation. It is now well
accepted that the "equality provisions of Part III of the Constitution constitute a single code,
illustrating the multi-faceted character of the central concept of equality. Art. 16(4) also is one facet.
It enables a backward class of citizens, by the process of reservation in Government service, to move
along the road to ultimate equality with the more advanced classes. It is part of the process of
equalization. Then follows Art. 335. It provides that the claims of the members of the Scheduled
Castes and Scheduled Tribes shall be taken into consideration in the making of appointments to
services and posts in connection with the affairs of-the Union or a State, but-and this is
imperative-such consideration must be consistent with the maintenance of efficiency of
administration. The paramount need is to maintain the efficiency of administration. That is dictated
by the common good. It embraces the need of all, the national good, and not of a mere section of the
people. To its primacy all else is subordinate. Therefore, whatever is done in considering the claims
of the Scheduled Castes and Scheduled Tribes must be consistent with that supreme need, the
maintenance of efficiency of administration. Art. 335, it must be clearly stated, does not contain a
positive principle, the advancement of Scheduled Castes and Scheduled Tribes, and a negative
principle, the maintenance of efficiency of administration. This analysis of the article does not truly
comprehend its contents. - It contains a single principle, the A advancement of Scheduled Castes
and Scheduled Tribes, but through modes and avenues which must not detract from theAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

maintenance of an efficient administration. That limitation is imposed as a clear and positive
condition.
A generally acknowledged and long established principle for securing an efficient administration is
throwing open the doors to general recruitment, either directly or by promotion, where the
governing criterion is excellence and the emphasis is solely on quality. I he net of selection is spread
far and wide, and the competitive best are collected, regardless of religion, race, caste, sex, descent,
place of birth or residence. However, a quota of the posts may be reserved in favour of a backward
class of citizens, but the interests of an efficient administration require that at least half the total
number of posts be kept open to attract the best of the nation`s talent and not more than half be
made the sum of reserved quotas. If it was otherwise, an excess of reserved quotaas would convert
the State service into a collective membership predominantly of backward classes. This, it is evident,
will be inconsistent with the all-important goal of maintaining the efficiency of administration. In
considering the proportion of reserved quotas in the context of college admissions, this ('court laid
down in M. R. Balaji v. State of Mysore(') that broadly a special provision providing for reservation
should be less than 50%, .and how much less than 50% would depend upon the relevant prevailing
circumstances in each case. And, in this connection, Gajendragadkar, J. (as he then was) speaking
for the Court, observed:
" .. when the State makes a special provision for the advancement of the weaker
sections of society specified in Art. 15(4), it has to approach its task objectively and in
a rational manner. Undoubtedly, it has to take reasonable and even generous steps to
help the advancement of weaker elements; the extent of the problem must be
weighed, the requirements of the community at large must be borne in mind and a
formula must be evolved which would strike a reasonable balance between the
several relevant considerations."
(Emphasis supplied) The Court struck down the reservation of 68% as constitutionally Invalid.
(1) [1963] Supp. 1 S.C.R. 439. 470.
The principle that reserved quotas should not together exceed 50% of the vacancies available in a
year was affirmed by this Court, by a majority of four learned judges to one, in T. Devadasan v.
Union of India,(') as the reason for striking down a "carry forward" rule which, for promotions in the
Central Secretariat Service, permitted a carry forward for two successive years of the annual
reserved quota. It was found in that case that observance of the rule had resulted in 65%, of the
vacancies of the year being filled by reserved quotas, current and carried forward. The "carry
forward" rule was held constitutionally invalid on the basis that for the purpose of Art. 16(1) each
year of recruitment had to be considered as a distinct unit for applying the 50% rule. Mudholkar, J.,
on behalf of the majority, said:
"We would like to emphasize that the guarantee contained in Art. 16(1) is for ensuring
equality of opportunity for all citizens relating to employment, and to appointments
to any office under the State. This means that on every occasion for recruitment theAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

State should see that all citizens are treated equally. The guarantee is to each
individual citizen and, therefore, every citizen who is seeking employment or
appointment to an office under the State is entitled to be afforded an opportunity for
seeking such employment or appointment whenever it is intended to be filled. In
order to effectuate the guarantee each year of recruitment will have to be considered
by itself and the reservation for backward communities should not be so excessive as
to create a monopoly or to disturb unduly the legitimate claims of other
communities."
It seems to me that apart from the impact that an excessive reservation in a particular year is bound
to have on the general community of citizens, there is the further far-reaching significance this
assumes in the context of Art. 335. The maintenance of efficiency of administration is bound to be
adversely affected if general candidates of high merit are correspondingly excluded from
recruitment because the large bulk of the vacancies, numbering anything over 50%, is allotted to the
reserved quota. In view of a maximum age limit invariably prescribed, some of such meritorious
candidates may be loss to the service altogether. Viewed in that light, a maximum of 50% for
reserved quotas in their totality is a rule which appears fair and reasonable, just and equitable, and
violation of which would contravene Art
335. (1) [1964] 4 S.C.R. 680.
It has been urged by the respondents that Devadasn (supra) is A no longer good law in view of the
7-Judge decision in State of Kerala v N. M. Thomas('). It does appear from some of the individual
Judgments delivered in the latter case that although Devadas (supra) has not been expressly
overruled by a majority of the Bench there are observations by the majority of Judges which throw
doubt on the validity of the principle enunciated by it and ultimately the Court has upheld the
promotion of 34 Scheduled Caste and Scheduled Tribe candidates among the total promotion of 51
candidates. It would seem then that there is an apparent conflict between Devadas (supra) and N.
M. Thomas (supra). The validity of Rule 13AA of the Kerala State and Subordinate Service Rules,
1958 was questioned in N. M. Thomas (supra). That Rule permitted the exemption of Scheduled
Caste and Scheduled Tribe members from passing the promotion tests for a specified period. That
more than 50% of the promotions went to the Scheduled Caste and Scheduled Tribe candidates was
a consequence of the operation of Rule 13AA. It is doubtful whether the petitioners' challenge to the
"carry forward" rule can avoid what has been said in N. M. Thomas (supra) and, therefore, a
conclusion in their favour does not seem possible in this case. As the position is not clear, and in any
event as my learned brothers have taken a definite view in favour of the "carry forward" rule, I have
confined myself to expressing these observations.
The petitioners have challenged other provisions prescribed in favour of members of the Scheduled
Castes and Scheduled Tribes and have attempted to support their submissions by reference to data
purporting to prove that those measures have resulted in reverse discrimination and are also
inconsistent with the maintenance of efficiency of administration. We have been taken through
charts and statistics among other documentary material but the material placed before us does not
clearly and definitely establish what it seeks to prove. In the circumstances, it is not possible toAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

record a finding in favour of the petitioners on those points. G Accordingly, the writ petitions are
dismissed but without any order as to costs.
CHINNAPPA REDDY J.-In the name of Equality (of opportunity), we are asked to deny Equality (of
opportunity), in these Writ Petitions. That we cannot do and that we will not do. If we do that we
will be subverting the spirit and the sense of the Constitution. The (1) [1976] 1 S.C.R. 906.
petitioners claim that their Fundamental Right to Equality of Opportunity in the matter of public
employment, guaranteed by Art. 16(1) of the Constitution has been flouted by a series of orders and
circulars issued by the Railway Board reserving posts at several levels and making various
concessions in favour of members of the Scheduled Castes and the Scheduled Tribes. This has been
done, it is claimed, at the cost of efficiency, though forbidden by Art. 335 of the Constitution. The
plain answer of the respondents is that everyone of the orders and circulars has the backing of Art.
16(1), 16(4) and other special provisions of the Constitution and that the alarm of inefficiency is
nothing but a bogey.
My brother Krishna Iyer, J. has considered the questions raised in his own characteristic,
scintillating way and in some depth. Though respect for my brother would ordinarily prevent me
from venturing to write a separate opinion, specially when I agree whole heatedly with his
conclusions and the, route traversed by him, I propose to make, in this case, certain general
observations because I expect the same questions to be raised repeatedly in different situations and
in different forms and it is just as well that I project my own prosaic and pedestrian point of view,
without going into the detail or depth already explored by my brother.
The class of people known compendiously as 'the Scheduled Castes', recognized and described as
such in the Constitution of India have been treated as 'casteless' outcastes and untouchables and
have been oppressed and subjected to every manner of depravation and discrimination for centuries
upon centuries by a unique system of social and economic segregation, a system of "graded
inequality"
(Dr. B.R. Ambedkar), of "gradation and degradation" (Dr. C.R. Reddy) and of
"gigantic cold-blooded repression" ( Rabindranath Tagore). And for centuries they
were even prevented from protesting their plight. Nor was any attempt made by the
superior and elitist classes to know anything about them. All that a Scheduled Caste
parent could do was to lament:
"Hush, my child; don't cry, my treasure;
Weeping is in vain, For the enemy will never Understand our pain.
For the ocean has its limits Prisons have their walls around But our suffering and our
torment have no limit and no bound."Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

Then, in 1950, came the Constitution rousing expectations, raising hopes, making promises and
generally heralding a new, a bitter and a more decent life for the underprivileged and the oppressed
people of India. While the preamble to the Constitution proclaims the resolution of the people to
constitute India into a Sovereign (also. 'Socialist, Secular', Since the 42nd Amendment) Democratic
Republic and to secure to all its citizens, "Justice, Social, economic and political" and "Equality of
Status and opportunity" and to promote 'Fraternity, assuring the dignity of the individual", while the
Right to Equality before the Law (Art. 14) and Equality of Opportunity n the matter of public
employment (Art. 16) are guaranteed as Fundamental Rights and while the State is enjoyed by the
Directive Principles of State Policy to promote the welfare of the p people by securing a social order
in which justice, social, economic and political shall inform all the institutions of the national life
Art. 38(1), to endeavour to eliminate inequalities in status, facilities and opportunities Art. 38 (2),
and, to direct its policy towards securing that the ownership and control of the material resources of
the community are so distributed as best to subserve the common good Art. 39(b) and that the
operation of the economic system does not result in the concentration of wealth and means of
production to the common detriment Art. 39(c), pursuant to the very preamble and the provisions
of the Constitution, special provisions have been made. in particular, for the protection and
advancement of the Scheduled Castes and the Scheduled Tribes in recognition of their existing, low
social and economic status and the consequent inability and failure on their part to avail themselves
of any opportunity for self- advancement. It is recognized that the failure of the State to create a
climatic situation and provide the necessary impetus for the increasing participation of the members
of the Scheduled Castes and the Scheduled Tribes in the public services would tentamount to a
denial to them of equal opportunity in the matter of public employment. Art. 335 which is included
in part XVI of the Constitution dealing with 'special provisions relating to certain classes' expressly
provides:
"The claims of the members of the Scheduled Castes and the Scheduled Tribes shall
be taken into consideration, consistently with the maintenance of efficiency of
administration in the making of appointments to services and posts in connection
with the affairs to the Union or of a State."
Art. 46, one of the Directive Principles of State Policy, enjoins:
"The State shall promote with special care the educational and economic interest of
the weaker sections of the people, and, in particular, of the Scheduled Castes and the
Scheduled Tribes, and shall protect them from social in justice and all forms of
exploitation." - i Art. 16 (1) and 16 (4) which guarantee equality of opportunity in
matters of public employment read as follows:
"16 (1) There shall be equality of opportunity for all citizens in matters relating to
employment or appointment to any office under the State."
"16 (4) Nothing in this article shall prevent the State from making any provision for
the reservation of appointments or posts in favour of any backward class of citizens
which, in the opinion of the State is not adequately represent in the services underAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

the State "
Art. 16 (2) which bars discrimination on certain rounds is as follows:
"16 (2) No citizen shall, on grounds only of religion, race, caste, sex, descent, place of
birth, residence or any of them, be ineligible for, or discriminated against in respect
of, any employment or office under the State."
Now, it has been said, very rightly, a Constitutional instrument is sui generis and, obviously and
necessarily, its interpretation cannot always run on the same lines as the interpretation of statutes
made in exercise of the powers conferred by it. A constitution, like ours, born of an anti-imperialist
struggle, influenced by Constitutional instruments, events and r evolutions elsewhere, in search of a
better world and wedded to the idea of justice, economic, social and political, to all, must receive a
generous interpretation so as to give all its citizens the full measure of justice so proclaimed instead
of 'the austerity of tabulated legalism'(1). And so, when the Constitutional instrument to be
expounded is a constitution like the Indian Constitution, the expositors are to concern themselves
not with words and mere words only, but, as much, with the philosophy or what we may call 'the
spirit and the sense' of the Constitution. Here we do not have to venture upon a voyage of discovery
to find the spirit and the sense of the Constitution; we do not have to look to any extraneous sources
for inspiration and guidance; they may be sought and found in the Preamble to the Constitution, in
the Directive Principles of State Policy, and other such provisions.
See Minister of Home Affairs :
[1979] (3) All E.R. 21.
Because Fundamental Rights are justiciable and Directive Principles are not, it was
assumed, in the beginning, that Fundamental Rights held a superior position under
the Constitution than the Directive Principles, and that the latter were only of
secondary importance as compared with the Fundamental Rights. That way of
thinking is of the past and has become obsolete. It is now universally recognised that
the difference between the Fundamental Rights and Directive Principles lies in this
that Fundamental Rights are primarily aimed at assuring political freedom to the
citizens by protecting them against excessive State action while the Directive
Principles are aimed at securing social and economic freedoms by appropriate, State
action. The Fundamental Rights are intended to foster the ideal of a political
democracy and to prevent the establishment of authoritarian rule but they arc of no
value unless they can be enforced by resort to Courts. So they are made justiciable.
But, it is also evident that notwithstanding their great importance, the Directive
Principles cannot in the very nature of things be enforced in a Court of law. It is
unimaginable that any Court can compel a legislature to make a law If the Court can
compel Parliament to make laws then Parliamentary democracy would soon be
reduced to an oligarchy of Judges. It is in that sense that the Constitution says that
the Directive Principles shall not be enforceable by Courts. It does not mean thatAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

Directive Principles are less important than Fundamental Rights or that they are not
binding on the various organs of the State. Art. 37 of the Constitution emphatically
states that Directive Principles are 'nevertheless Fundamental in the governance of
the country and it shall be the duty of the State to apply these principles in making
laws. It follows that it becomes the duty of the Court to apply the Directive Principles
in interpreting the Constitution and the laws. The Directive Principles should serve
the Courts as a code of interpretation. Fundamental Rights should thus be
interpreted in the light of the Directive Principles and the later should, whenever and
wherever possible, be read into the former. Every law attacked on the ground of
infringement of a Fundamental Right should, among other considerations, be
examined to find out if the law does not advance one or other of the Directive
Principles or if it is not in discharge of some of the undoubted obligations of the
State, constitutional or otherwise, towards its citizens or sections of its citizens,
flowing out of the preamble. the Directive Principles and other provisions of the
Constitution.
So, we have it that the Constitutional goal is the establishment of a Socialist
Democracy which Justice, economic, social and political is secure and all men are
equal and have equal opportunity. Inequality, whether of status, facility or
opportunity, is to end, privilege is to cease and exploitation is to go. The
under-privileged, the deprived and the exploited are to be protected and nourished so
as to take their place in an egalitarian society. State action is to be towards those
ends. It is in this context that Art. 16 has to be interpreted when State action is
questioned as contravening Art. 16.
Let us now take a look at Art. 16(1) and Art 16(4). Art. 16(1) guarantees equality of
opportunity for all citizens in matters relating to employment or appointment to any
office under the State. To the class of citizens who are economically and socially
backward this guarantee will be no more than mere wishful thinking, and mere
'vanity....wind and confusion", if it is not translated into reality by necessary state
action to protect and nurture such class of citizens so as to enable them to shake off
the heart- crushing burden of thousand years' deprivation from their shoulders and
to claim a fair proportion of participation in the Administration. Reservation of posts
and all other measures designed to promote the participation of The Scheduled
Castes and the Scheduled Tribes in the Public Services at all levels are in our opinion
necessary consequences flowing fro the Fundamental Right guaranteed by Art. 16(1)S
This very idea is emphasised further by Art. 16(4). Art. 16(4) is not in the nature of an
exception to Art. 16(1). It is a facet of Art. 16(1) which fosters and furthers the idea of
equality of opportunity with special reference to an under privileged and deprived
class of citizens to when egalite de droit (formal or legal equality) is not egalite de fait
(practical or factual equality). It is illustrative of what the State must do to wipe out
the distinction between egalite de droit and egalite de fait. It recognises that the right
to equality of opportunity includes the right of the underprivileged to conditions
comparable to or compensatory of those enjoyed by the privileged. Equality ofAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

opportunity must be such as to yield 'Equality of Results' and not that which simply
enables people, socially and economically better placed, to win against the less
fortunate, even when the competition is itself otherwise equitable. John Rawls in 'A
Theory of Justice' demands the priority of equality in a distributive sense and the
setting up of the Social System "so that no one gains or loses from his arbitrary place
in the distribution of natural assets or his own initial position in society without
giving or receiving compensatory advantages in return". His basic principle of social
justice is: "All social primary goods-liberty and opportunity, income and wealth, and
the bases of self-respect-are to be distributed equally unless an unequal distribution
of any or all these goods is to the advantage of the least favoured". One of the
essential elements of his conception of social A justice is what he calls the principle of
redress: "This is the principle that undeserved inequalities call for redress; and since
inequalities of birth and natural endowment are undeserved, these inequalities are
somehow to be compensated for". Society must, therefore, treat more favourably
those with fewer native assets and those born into less favourable social positions. If
the statement that 'Equality of opportunity must yield Equality of Results' and if the
fulfillment of Articles 16(1) in Art. 16(4) ever needed a philosophical foundation it is
furnished by Rawls' Theory of Justice and the Redress Principle.
The interpretation of Arts. 16(1) and 16(4) came up for consideration in several cases
before this Court. Perhaps the most important of them is State of Kerala & Anv. v. N.
M. Thomas & Ors.,(1) which was decided by a Bench of seven Judges. The question
was whether a certain rule which gave a longer period of exemption to members
belonging to Scheduled Castes and Scheduled Tribes than to others from passing
certain departmental tests in order to be eligible for promotion from the Post of
Lower Division Clerk to that of Upper Division Clerk was not violative of Art. 16(1) of
the Constitution. The Court by a majority of five to two upheld the rule as valid. Ray,
C. J., observed:
"The rule of equality within Articles 14 and 16(1) will not be violated by a rule which
will ensure equality of representation in the services for unrepresented classes after
satisfying the basic needs of efficiency of administration. Article 16(2) rules out some
basis of classification including race, caste, descent, place of birth etc. Article 16(4)
clarifies and explains that classification on the basis of backwardness does not fall
within Article 16(2) and is legitimate for the purposes of Article 16(1). If preference
shall be given to a particular under-represented community other than a backward
class or under-represented State in an All India Service such a rule will contravene
Article 16(2). A similar rule giving preference to an under-represented backward
community is valid and will not contravene articles 14, 16(1) and 16(2). Article 16(4)
removes any doubt in this respect".
(I) [1976] 1 SCR 906 @930-933.Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

"The classification of employees belonging to Scheduled Castes and Scheduled Tribes
for allowing them an extended period of two years for passing the special tests for
promotion is a just and reasonable classification having rational nexus to the object
of providing equal opportunity for all citizens in matters relating to employment or
appointment to public office."
xx xx xx "The Constitution makes a classification of Scheduled Castes and Scheduled
Tribes in numerous provisions and gives a mandate to the State to accord special or
favoured treatment to them."
xx xx xx "Article 335 of the Constitution states that claims of members of the
Scheduled Castes and Scheduled Tribes shall be taken into consideration in the
making of appointments to the services and posts in connection with affairs of the
State consistent with the maintenance of efficiency of administration. The impugned
rule and the impugned orders are related to this constitutional mandate."
"Our constitution aims at equality of status and opportunity for all citizens including
those who are socially, economically and educationally backward. The claims of
members Or backward classes require adequate representation in legislative and
executive bodies. If members of Scheduled Castes and Tribes, who are said by this
Court to be backward classes, can maintain minimum necessary requirement of
administrative efficiency, not only representation but also preference may be given to
them to enforce equality and to eliminate inequality. Articles 15 (4) and 16(4) bring
out the position of backward classes to merit equality Special provisions are made for
the advancement of backward classes and reservations of appointments and posts for
them to secure adequate representation. These provisions will bring out the content
of equality guaranteed by Articles 14, 15(1) and 16(1). The basic concept of equality is
equality of opportunity for appointment. Preferential treatment for members of
backward classes with due regard to administrative efficiency alone, can mean
equality of opportunity for all citizens. Equality under Article 16 could not have a
different content from equality under Article 14. Equality of opportunity for unequals
can only mean aggravation of inequality Equality of opportunity admits
discrimination with reason and prohibits discrimination without reason.
Discrimination with reasons means rational classification for differential treatment having n nexus
to the constitutionally permissible object. Preferential representation for the backward classes in
services with due regard to administrative efficiency is permissible object and backward classes are a
rational classification recognised by our Constitution. Therefore, differential treatment in standards
of selection are within the concept of equality".
xx xx xx xx "All legitimate methods are available for equality of opportunity in service under Article
16(1). Article 16(1) is affirmative whereas Article 14 is negative in language. Article 16(4) indicates
one of the methods of achieving equality embodied in Article 16(1)". Equally illuminating
observations were made by Mathew, J., Beg., J., Krishna Iyer, J., and Fazal Ali, J., in their separateAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

concurring opinions but I do not propose to extract them in the interest of space. It is enough to
mention that all five learned judges who constituted the majority were emphatic in repudiating the
theory (propounded in earlier cases) that Art. 16(4) was in the nature of an exception to Art. 16(1).
All were agreed that Art. 16(4) was a facet, an illustration or a method of application of Art. 16(1).
So, it is now no longer necessary to apologetically explain laws aimed at achieving equality as
permissible exceptions; it can now be boldly claimed that such laws are necessary incidents of
equality.
It all began with The General Manager), Southern Railway v. Rangachari(1). Two circulars issued by
the Railway Board reserving selection (promotional) posts in Class III of the Railway Service in
favour of the members of the Scheduled Castes and the Scheduled Tribes, were questioned in that
case as offending Art. 16. It was contended that Art. 16(4) applied only to reservation of posts at the
stage of initial appointment and not to promotional posts. The contention was rejected and it was
held that Art. 16(4) applied at the stage of initial appointment as well as at the stage of promotion by
selection.It was in the case that observations were made to the (1) [1962] 2 SCR 586.
effect that Art. 16(4) was in the nature of an exception to Art. 16(1), but, as we have seen such a view
is no longer tenable in view of State of Kerala & Anr. v. N. M. Thomas & Ors. (supra).
Much of the argument of the learned counsel for the petitioners was anchored to, T. Devodasan v.
Union of India(z & Anr.(1) 17 1/2% of vacancies in an establishment were reserved for members of
the scheduled Castes and Scheduled Tribes. Alongside the reservation rule, there operated what is
known as "the carry-forward rule" familiar to all Govt. employees and those connected with 'service
problems'. The carry-forward rule so operated in the particular case that out of 45 appointments
made by the Government 29 were from among the candidates belonging to the Scheduled Castes
and Scheduled Tribes. In other words the reservation Came to 65% which was far in excess of the
177% originally contemplated by the Reservation rule. In those circumstances, a Constitution Bench
of this Court (Subba Rao, J. dissenting) declared the carry-forward rule bad. The Court did not
strike down the carry-forward rule on the ground that it was inherently vicious or on the
hypothetical consideration that it was bound to lead to vicious results in the future if permitted to
operate without inhibition. The judgment of the Court was founded upon the viciousness exposed by
the actual working of the rule in practice. The learned judges indicated that the repercussions of
such a rule would have to be watched from year to year.
Another case upon which the petitioners placed reliance was M. R. Balaji & Ors. v. State, of
Mysore(2). In that case the percent age of seats reserved in the Engineering and Medical colleges for
the educationally and socially backward classes and Scheduled Castes and Scheduled Tribes came to
68% leaving only 32% of the seats for the merit pool. The Court held that generally and broadly
reservation should not exceed 50%. The actual percentage was to depend upon the relevant
prevailing circumstances in each case. As the reservation in that case for exceeded what was
generally and broadly permissible, the reservation was held to be bad. There again the Court was
concerned directly with the immediate, actual, practical result of the Reservation rule.Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

In A. Peeriakaruppan, etc. Y. State of Tamil Nadu & Ors.,(3) reservation of 41% of the seat in
medical college in the State of (1) [1964] 4 SCR 680.
(2) [1963] Suppl. I SCR 439.
(3) [1971] 2 SCR 430 @ 441-442.
Tamil Nadu for students coming from socially and educationally back-ward classes was upheld.
Hegde, J., observed (at p. 441-442):
"There is no basis for the contention that the reservation made for backward classes
is excessive. We were not told why it is excessive. Undoubtedly we should not forget
that it is against the immediate interest of the Nation to exclude from the portals of
our medical colleges qualified and competent students but then the immediate
advantages of the Nation have to be harmonised with its long range interests. It
cannot be denied that unaided many sections of the people in this country cannot
compete with the advanced sections of the Nation. Advantages secured due to
historical reasons should not be considered as fundamental mental rights. Nation's
interest will be best served-taking a long range view-if the backward classes are
helped to march forward and take their place in line with the advanced sections of the
people. That is why in Balaqi's case [1931] Suppl 1 SCR (439), this Court held that the
total of reservations for backward classes, scheduled castes and scheduled tribes
should not ordinarily exceed 50% of the available seats. In the present case it is 41%.
On the material before us we are unable to hold that the said reservation is
excessive".
In State of Punjab v. Hiralal & Ors.,(l) a rule reserving the first out of every ten vacancies to a
member of the Scheduled Castes and Scheduled Tribes and providing for 'carry-forward' of the
vacancy if suitable candidate was not available was struck down by the High Court by visualising
various hypothetical cases which could lead to anomalous situations in which a person getting the
benefit of reservation may jump over the heads of several of his seniors not only in his own grade
but even in higher grades. This Court reversed the decision of the High Court observing:
"The extent of reservation to be made is primarily a matter for the State to decide. By
this we do not mean to say that the decision of the State is not open to judicial re
view. The reservation must be only for the purpose of giving adequate representation
in the service to the Scheduled Castes, Scheduled Tribes and Backward Classes".
xx xx (1) [1971] 3 SCR 267 @ 272, 273, 274.
"The mere fact that the reservation made may give extensive benefits to some of the
persons who have the benefit of the reservation does not by itself make the
reservation bad. The length of the leap to be provided depends upon the gap to be
covered".Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

xx xx xx xx "There was no material before the High Court and there is no material
before us from which we can conclude that the impugned order is violative of Art.
16(1). Reservation of appointments under Art. 16(4) cannot be struck down on
hypothetical grounds or on imaginary possibilities. He who assails the reservation
under that Art. must satisfactorily establish that there has been a violation of Art.
16(1)".
The report of the Commissioner for Scheduled Castes and Scheduled Tribes for 1977-78 and the
'Reports on the progress made in the intake of Scheduled castes and Scheduled Tribes against
vacancies reserved for them in recruitment and promotion categories in the Rail ways' for the half
years ending March 31, 1974, March 31, 1975, September 30, 1976, March 31, 1977 and September
30, 1979 were placed before us. they reveal how painfully slow and woefully in significant has been
progress achieved by the members of the Scheduled Castes and Scheduled Tribes in the matter of
their participation in the Railway administration. My brother Krishna Iyer J has extracted some of
the facts and figures. I do not think it is necessary for me to refer to them over again. It is sufficient
to say that members of the Scheduled Castes and Scheduled Tribes far from acquiring any
monopolistic or excessive representation over any category of posts (other than sweepers) are
nowhere near being adequately represented. Neither the Reservation rule nor the 'carry-forward for
three years' rule has resulted in any such 'disastrous' consequences. The complaint of the petitioners
that the circulars and orders had resulted in excessive representation of the Scheduled Castes and
Scheduled Tribes is without foundation generally or with reference to any particular year.
One of the contentions vehemently submitted by the learned counsel for the petitioners was that
efficiency of administration would suffer and safety of the travelling public would consequently be
jeopardised if reservations were made and promotions affected in the manner sought to be done by
the Railway Board. This is claimed by the respondents to be no more than a bogey. In the counter
affidavit filed on behalf of the Railway Board it has been pointed out that minimum standards arc
insisted upon for every appointment and in the case of candidates wanting in requisite standards,
those h with the highest marks are given special intensive training to enable them to come up to the
requisite standards. In the case of posts which involve the safety of movement of trains there is no
relaxation of standards in favour of candidates belonging to Scheduled Castes and Scheduled Tribes
and they are required to pass the same rigid tests as other candidates.
Therefore, we see that when posts whether at the stage of initial appointment or at the state of
promotion are reserved or other preferential treatment is accorded to members of the Scheduled
Castes, Scheduled Tribes and other socially and economically backward classes, it is not a
concession or privilege extended to them, it is in recognition of their undoubted Fundamental Right
to Equality of Opportunity and in discharge of the Constitutional obligation imposed upon the state
to secure to all its citizens 'Justice, social, economic and political' and 'Equality to status and
opportunity', to assure 'the dignity of the individual' among all citizens, to 'promote with special D.
care the educational and economic interests of the weaker section of the people', to ensure their
participation on equal basis in the administration of the affairs of the country and generally to foster
the ideal of a 'Sovereign, Socialist, Secular, Democratic Republic'. Every lawful method is
permissible to secure the due representation of the Scheduled Castes and Scheduled Tribes in theAkhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

public Services. There is no fixed ceiling to reservation or preferential treatment in favour of the
Scheduled Castes and Scheduled Tribes though generally reservation may not be far in excess of fifty
percent. There is no rigidity about the fifty percent rule which is only a convenient guideline laid
down by Judges. Every case must be decided with reference to the present practical results yielded
by the application of the particular rule of preferential treatment and not with reference to
hypothetical results which the application of the rule may yield in the future. Judged in the light of
this discussion I am unable to find anything illegal or unconstitutional in any one of the impugned
orders and circulars. Each order and circular has been individually discussed by my brother Krishna
Iyer J with whose reasoning and conclusions I agree and to which I wish to add no more.
PBR Petitions dismissed.Akhil Bharatiya Soshit Karamchari ... vs Union Of India And Ors on 14 November, 1980

