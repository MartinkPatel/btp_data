Facebook. Inc vs The State Of West Bengal & Anr on 3 January,
2018
Author: Siddhartha Chattopadhyay
Bench: Siddhartha Chattopadhyay
                      IN THE HIGH COURT AT CALCUTTA
                     (CRIMINAL REVISIONAL JURISDICTION)
                           C.R.R. No. 2332 of 2017
                               Facebook. Inc
                                     Vs.
                       The State of West Bengal & Anr.
Present : The Hon'ble Justice Siddhartha Chattopadhyay
For the Petitioner                  :     Mr. Siddharth Luthra, Sr. Adv.,
                                          Mr. Souvik Mitter,
                                          Mr. Nitin Saluza,
                                          Ms. Saansh Purohit,
                                          Mr. Manu Krishnan,
                                          Ms. Richa Srivastava,
                                          Ms. Suhani Dwivedi,
                                          Ms. Arunima Dey.
For the Union of India              :     Mr. Kaushik Chanda, Ld. A.S.G,
                                          Mr. Rahul Sarkar.
For the State                       :     Mr.   Kishore Dutta, Ld. A.G.,
                                          Mr.   Saswata Gopal Mukherjee, Ld. P.P.,
                                          Mr.   Bibhas Chatterjee, Ld. Spl. P.P.,
                                          Mr.   Ayan Basu,
                                          Mr.   Goutam Banerjee.
Heard On                            :     20.12.2017.
Judgment Delivered On               :      03.01.2018.
Siddhartha Chattopadhyay, J.:
Being dissatisfied with the order dated 18.06.2017, passed by the learned Chief Metropolitan
Magistrate, Calcutta, the present petitioner has prayed for quashing of the said order. By the said
impugned order, the learned C.M.M. has directed the present petitioner to remove the entire
Facebook pages available at "The Darjeeling Chronicle". Pursuant to that order of the learned
C.M.M., the local police has sent a notice under Section 91 Cr.P.C. on 19.06.2007 and asked the
petitioner to immediately block and remove the relevant pages.Facebook. Inc vs The State Of West Bengal & Anr on 3 January, 2018

2. The petitioner herein has challenged the said order as well as the action of the local police on
following grounds:-
(1) That the C.M.M. has passed the impugned order just mechanically and without
any application of mind.
(2) The said order was beyond the jurisdiction of the said Court in view of Rule 10 of
Information Technology Rules 2009. (3) That the learned C.M.M. has acted without
adhering to the relevant Sections 177 to 184 Cr.P.C. which deals with the jurisdiction
of a criminal court, (4) That the learned trial court ought to have considered Sections
95 and 96 Cr.P.C., since it is a special statue.
(5) Relevant rules i.e. IT (Procedures and Safeguards for blocking for access to
information by public) rules were not complied with.
3. At the time of hearing, learned Counsel Mr. Luthra appearing on behalf of the petitioner
contended that no F.I.R. was registered and in spite of that learned trial court has passed an order to
that effect. The impugned order bears the words "G.D. Extract No. 582, dated 17.06.2017."
4. On perusal of the impugned order I find that there is no registration of F.I.R. and the learned
C.M.M. has passed the order in connection with Cyber Police Station G.D. Entry No. 582 dated
17.06.2017. After going through the first part of the impugned order, I find that there was a prayer
for issuance of notice under Rule 10 of Information Technology Rules 2009. The Investigating
Officer has mentioned that due to such contents of Facebook, there may be some subversive
activities against the Government, and there is reasonable apprehension that it may invite other
turbulent activities in that area. The learned C.M.M. has passed the order "the prayer of
Investigating Officer is allowed." No reason is mentioned. From the second part of the order, it
appears that the O/C cyber-crime has prayed for issuance of notice under Rule 10 of Information
and Technology Rules 2009, upon the group co-ordinator Cyber Law Division, Department of
Electronics and Information Technology, 6, C.G.O. Complex, Lodhi Road, New Delhi- 110003 for
blocking of the Facebook page and the links. This time also the learned C.M.M. has passed the order
"the prayer of Investigating Officer is allowed." Similarly no reason is there. Therefore, it is crystal
clear that there is no application of mind by the learned C.M.M. It is perhaps needless to say that an
order without assigning any reason is an order non-est. Therefore, the grievance of the petitioner
that the learned trial court did not apply his mind is amply justified. There being no registration of
F.I.R., how the Investigating Officer has made a prayer before the learned C.M.M.?
5. Now, this court is under an obligation to see whether the procedural aspects have ben complied
with or not. Learned Counsel appearing on behalf of the petitioner contended that the provisions
laid down in Information and Technology (procedure and safeguards for blocking for access of
information by public) Rules 2009 have not been complied with. According to him, it ought to have
been routed through by the designated officer. To come to a finding relevant provisions of the said
rules are to be recapitulated. Rule 3 deals with designated officer. It says 'The Central Government
shall designate by notification in Official Gazette, an officer of the Central Government not belowFacebook. Inc vs The State Of West Bengal & Anr on 3 January, 2018

the rank of a Joint Secretary, as the "Designated Officer", for the purpose of issuing direction for
blocking for access by the public any information generated, transmitted, received, stored or hosted
in any computer resource under sub-section (2) of section 69A of the Act.' Rule 4 speaks "Every
organization for the purpose of these rules, shall designate one of its officer as the Nodal Officer and
shall intimate the same to the Central Government in the Department of Information Technology
under the Ministry of Communications and Information Technology, Government of India and also
publish the name of the said Nodal Officer on their website. Rule 5 contends Direction by
Designated Officer.-The Designated Officer may, on receipt of any request from the Nodal Officer of
an organization or a competent court, by order direct any Agency of the Government or
intermediary to block for access by the public any information or part thereof generated,
transmitted, received, stored or hosted in any computer resource for any of the reasons specified in
sub-section (1) of section 69A of the Act. Rule 6. Forwarding of request by organisation.-(1) Any
person may send their complaint to the Nodal Officer of the concerned organisation for blocking of
access by the public any information generated, transmitted, received, stored or hosted in any
computer resource:
Provided that any request, other than the one from the Nodal Officer of the
organisation, shall be sent with the approval of the Chief Secretary of the concerned
State or Union territory to the Designated Officer.
Provided further that in case a Union territory has no Chief Secretary, then, such
request may be approved by the Adviser to the Administrator of that Union territory.
(2) The organisation shall examine the complaint received under sub-
rule (1) to satisfy themselves about the need for taking of action in relation to the reasons
enumerated in sub-section (1) of section 69A of the Act and after being satisfied, it shall send the
request through its Nodal Officer to the Designated Officer in the format specified in the Form
appended to these rules.
(3) The Designated Officer shall not entertain any complaint or request for blocking of information
directly from any person.
(4) The request shall be in writing on the letter head of the respective organisation, complete in all
respects and may be sent either by mail or by fax or by e-mail signed with electronic signature of the
Nodal Officer:
Provided that in case the request is sent by fax or by e-mail which is not signed with
electronic signature, the Nodal Officer shall provide a signed copy of the request so as
to reach the Designated Officer within a period of three days of receipt of the request
by such fax or e-mail.
(5) On receipt, each request shall be assigned a number alongwith with the date and
time of its receipt by the Designated Officer and he shall acknowledge the receiptFacebook. Inc vs The State Of West Bengal & Anr on 3 January, 2018

thereof to the Nodal Officer within a period of twenty four hours of its receipt."
6. In this case the State Government or the police authority did not draw the attention of the
'Designated Officer' whose duty it was to issue direction in terms of Sub-Section (2) of Section 69A
of the Act. The word "Organisation" is defined in terms of Rule 2 of the aforesaid rules:-
"Organisation" means-
(i) Ministries or Departments of the Government of India;
(ii) State Governments and Union territories;
(iii) any agency of the Central Government, as may be notified in the Official Gazette,
by the Central Government;
On a conjoint reading of Rule 5 and Rule 6 it appears that the designated officer upon a request
from the Nodal Officer of an organisation or a competent court by order direct any agency of the
Government or intermediary to block for access by the public any information. The said rules of
2009 also speak that even if any information other than the one from the Nodal Officer of the
organisation is received, shall be sent with the approval of the Chief Secretary of the State to the
appropriate authority for blocking of access. Admittedly, in this case those procedures and those
rules were not complied with at all.
7. The learned Advocate General Mr. Kishore Dutta has submitted that situation was of such a
nature for which the blocking of access to those pages were the need of the hour. Due to exigency
they have drawn the attention of the competent court. He argued that a competent court may pass
such an order. Of course, the court has the power to deal with the issue in extreme circumstances. It
cannot be ruled out that for such contents of Facebook, there was likely to cause disturbances of law
and order in that locality. It is our common knowledge that at the relevant point of time an agitation
of violent nature was going on to separate hill areas from the State of West Bengal and chance of
emotional blackmailing was also there. The sentiments of some people of hill areas and at the same
time emotions of many persons of other parts of West Bengal were there. A small faction of people
demanded for separation and other group of people did not want separation. Therefore, contents of
Facebook might create trouble, and that was the view of the Government.
8. Learned Advocate General contended, referring Para 4 of the affidavit in opposition, that Section
69A of the Act nor the rules provide that an F.I.R. is to be registered and that G.D. entry is not
sufficient. Practically this submission is devoid of any merit. On a careful reading of Section 69A (1),
it appears that to prevent incitement to the commission of any cognizable offence an officer specially
authorized can invoke the said rules. It is perhaps needless to say that if any cognizable offence is
made out the officer-in-charge of a police station is bound to register the same. This is mandatory
and not optional. Here the police authority sensed about the cognizable offence, yet no F.I.R. was
lodged. Therefore, if any chance of committing any cognizable offence is made out and for which
action is required to be taken under Section 69A of the Act, F.I.R. is mandatory. Admittedly in thisFacebook. Inc vs The State Of West Bengal & Anr on 3 January, 2018

case that has not been done. The very act does not say that the Court is authorized to do it. The
Court assumes its jurisdiction only in terms of Rule 5 and Rule 10 I.T. (procedure and safeguards for
blocking for access to information by public) rules.
9. In the interest of academic discussion I may be permitted to reproduce Section 69A. [S. 69A.
Power to issue directions for blocking for public access of any information through any computer
resource.- (1) Where the Central Government or any of its officers specially authorized by it in this
behalf is satisfied that it is necessary or expedient so to do, in the interest of sovereignty and
integrity of India, defence of India, security of the State, friendly relations with foreign States or
public order or for preventing incitement to the commission of any cognizable offence relating to
above, it may subject to the provisions of sub-section (2), for reasons to be recorded in writing by
order, direct any agency of the Government or intermediary to block for access by the public any
information generated, transmitted, received, stored and hosted in any computer resource.
(2) The procedure and safeguards subject to which such blocking for access by the public may be
carried out, shall be such as may be prescribed.
(3) The intermediary who fails to comply with the direction issued under sub-section (1) shall be
punished with an imprisonment for a term which may extend to seven years and shall also be liable
to fine.]
10. In the aforesaid sections it is clearly mentioned that the Central Government or any of its officers
specially authorized by it in this behalf, order for preventing incitement to the commission of any
cognizable offence and in so doing he has to record his reasons in writing and only then a direction
can be given to the agency concerned. A court can never be an authorized officer of Central
Government. Only rider has been given under Rule 5 and 10 of the said rules where the competent
court can do it. Therefore, the argument advanced by the learned Advocate General is
demonstratably unsustainable.
11. Regarding jurisdiction of the Court, he contended referring a notification dated 23rd August,
2010, that the learned C.M.M. court is to take cognizance of the cases arising out of cyber police
station. In reply, learned Counsel appearing on behalf of the petitioner contended that the so called
incitement to the offence took place in the District of Darjeeling and for which the learned C.M.M.,
Kolkata has no jurisdiction at all. The learned Counsel appearing on behalf of the petitioner
contended that the learned C.M.M. could have acquired jurisdiction if the subject consent was
posted from within the territorial jurisdiction of the learned C.M.M. I am unable to espouse the
same on the ground that if the contents are visible in Kolkata, the learned C.M.M. has the
jurisdiction to entertain it. I am in respectful disagreement with him on the ground that whoever is
aggrieved due to any contents of the Facebook has the right to approach before the concerned
authority or nearest court of his locality. Here the stand of the state is such, that at the time of
surfing internet of Facebook, Kolkata Police has noticed it and naturally Kolkata Police Cyber Crime
Police Station approached before the learned C.M.M. But in this case no F.I.R. was lodged by the
Cyber Crime Police Station. Only a G.D. entry was lodged and on the basis of that learned C.M.M.
has assumed his jurisdiction. The jurisdiction of learned C.M.M. cannot be overruled, but whetherFacebook. Inc vs The State Of West Bengal & Anr on 3 January, 2018

the action taken by learned C.M.M. under a G.D.E. is lawful or not that will be considered later.
12. The learned Advocate General further submitted that power under Section 69A of the
Information Technology Act 2000 is pari materia of Section 144 of Cr.P.C. Let me examine his such
contentions in the light of the aforesaid provisions.
Section 69A of the Act is to be exercised by a particular authority as envisaged in the Act. The scope
of exercising that section is also specified there i.e. 'in the interest of sovereignty and integrity of
India, defence of India, security of the State, friendly relations with foreign states or public order or
for preventing incitement to the commission of any cognizable offence.'
13. Section 144 of Cr.P.C. deals with circumstances, when the same can be exercised i.e. "to prevent
or tends to prevent, obstruction, annoyance or injury to any person lawfully employed or danger to
human life, health or safety or a disturbances of the public tranquillity or a riot or an affray".
14. Therefore, scope of exercising the aforesaid sections are well defined. Section 69A is having a
penal section and the intermediary who fails to comply with the directions under Section
sub-section 1 shall be punished with an imprisonment for a term which may extend to seven years
and shall also be liable to fine.
15. The order of the Executive Magistrate in connection with Section 144 Cr.P.C. is valid normally
for sixty days but the State Government may extend it for six months more.
16. The argument canvassed by the learned Advocate General does not impress me much. An
Executive Magistrate cannot pass any order beyond his territorial jurisdiction. Jurisdiction of cyber
law is wide enough and for that reason Section 69A of the Act is codified and our Hon'ble Apex
Court clearly held that Information Technology Act is a complete code.
17. Learned Advocate General further contended that there are some Metropolitan Magistrates, who
enjoy the jurisdiction and power of an executive court. It is true that the Metropolitan Magistrates
viz. Metropolitan Magistrate Court No. 10 and Court No. 3 enjoy that executive power. But the
learned C.M.M. cannot enjoy that power unless notified. Therefore, this argument also does not hold
any water.
18. Learned Special P.P. Bibhash Chatterjee, after supporting the contention of the state, argued that
in view of Rule 7 and Rule 8(4) of IT (Procedure and Safeguards, ete.) Rules 2009 that there is a
committee for examination of request. Rule 9 speaks "In case of an order from a competent court in
India for blocking of any information or part thereof generated, transmitted, received, stored or
hosted in a computer resource, the Designated Officer shall, immediately on receipt of certified copy
of the court order, submit it to the Secretary, Department of Information Technology and initiate
action as directed by the court." According to him, since there is a court order so the designated
officer sent it to the Department concerned. According to him, there is no such illegality.Facebook. Inc vs The State Of West Bengal & Anr on 3 January, 2018

19. Learned Additional Solicitor General contended that they have nothing to say because as a
component part of federal structure of our constitution they have done their duties i.e. 'Raj Dharma'.
He submitted categorically that they have not gone into the merit of the application nor considered
the merit of the order of the court in any way.
20. Question was raised by the learned Advocate General that the Court can pass an order on the
basis of GDE. The word G.DE is not defined in the code. Section 154 Cr.P.C. speaks "....... reduced to
writing as aforesaid, shall be signed by the person giving it and the substance thereof shall be
entered in a book to be kept by such officer in such form as the State Government may prescribe in
this behalf. The said register is popularly known as formal F.I.R. The written complaint is attached
to it. The Section 155 (1) Cr.P.C. also speaks" ..... he shall enter or cause to be entered the substance
of the information in a book to be kept by such officer in such form as the State Government may
prescribe ........... It deals with non-cognizable offence and other informations excluding cognizable
offence. In a case of non-cognizable case, the police cannot investigate without the order of the
magistrate. The learned C.M.M. while passing the impugned order did not consider all these aspects
in its proper perspectives.
21. The learned Counsel appearing on behalf of the petitioner referred to the decisions reported in
Gopalji Prasad vs. State of Sikkim (1981 CRLJ 60), the celebrated judgment in case of Shreya
Singhal vs. Union of India (2015) 5 SCC 1. Since the ratio of those judgments are well settled and
still holds the field, I do not like to discuss them in detail.
22. From the aforesaid discussion, it is crystal clear that learned C.M.M. has passed the order on a
wrong premise. He did not apply his mind, nor considered the scope of application of the
Information Technology Act and relevant rules. Accordingly, the impugned order is set aside.
23. But at the same time it cannot be said that the road is closed for ever. The State Government,
after observing the legal formalities as mentioned in the special statute, may invoke the same, if
situation so warrants and still prevails. After all 'law and order' is the urgent desideratum of the
state.
24. Therefore, the omega is the revisional application succeeds.
25. Let a copy of this order be sent to the learned trial Court for information and taking necessary
action, as well as to the Director General of Police, West Bengal for necessary action.
26. Urgent certified photocopy of this order, if applied for, be supplied to the parties upon
compliance with all requisite formalities.
(SIDDHARTHA CHATTOPADHYAY, J.) A.F.R/N.A.F.R.Facebook. Inc vs The State Of West Bengal & Anr on 3 January, 2018

