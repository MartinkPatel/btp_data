A.P. Farmers Organisation Rules, 1997
ANDHRA PRADESH
India
A.P. Farmers Organisation Rules, 1997
Rule A-P-FARMERS-ORGANISATION-RULES-1997 of 1997
Published on 27 December 2018• 
Commenced on 27 December 2018• 
[This is the version of this document from 27 December 2018.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
A.P. Farmers Organisation Rules, 1997Published vide Notification No. G.O.Ms.No.541, Irrigation &
Command Area Development (CAD.IV) Department, dated 27.12.2018Last Updated 12th June,
2018In exercise of the powers conferred by Section 43, read with Sections 2, 3, 4, 6, 8, 12, 14, 15, 16,
17, 18, 19, 20, 21, 22, 24, 25 and 28 of the Andhra Pradesh Farmers Management of Irrigation
Systems Act, 1997 (Act 11 of 1997), the Governor of Andhra Pradesh hereby makes the following
Rules:-
1. Short Title.
- These rules may be called the Andhra Pradesh Farmers Organisation Rules, 1997 (with updated
Amendments, 2018).
2. Definition.
- In these rules, unless the context otherwise requires:-(i)"Act" means the Andhra Pradesh Farmers
Management of Irrigation Systems Act, 1997.(ii)"Farmers Organisation" means water users
association at the primary level, Distributory Committee at the secondary level and project
committee at the project level.(iii)[ "Commissioner" means an officer appointed by the Government
as Commissioner, Command Area Development Authority.] [Added by Notification No. G.O. Ms.
No.17, Water Resources (CADA) Department, dated 8.2.2019 (w.e.f. 27.12.2018).]
3. Every Farmers Organisation shall be a body corporate having a distinct
name, an office, a common seal and shall by the said name sue and be sued.
4. The objects of the Farmers Organisation shall be as follows:
(i)with due regard to the rights of members shall function in [a] [Inserted by Notification No. G.O.
Ms. No.17, Water Resources (CADA) Department, dated 8.2.2019 (w.e.f. 27.12.2018).] democraticA.P. Farmers Organisation Rules, 1997

manner through consensus respecting the rights and duties of all members;(ii)to make their
organization a viable, vibrant, and functioning entity;(iii)[ To assist the Water Resources
Department in effective Water management with the objective of equitable distribution of water in
the entire command with special focus on supplying water to farmers at the tail end areas;
[Substituted by Notification No. G.O. Ms. No.17, Water Resources (CADA) Department, dated
8.2.2019 (w.e.f. 27.12.2018).](iv)To assist the Water Resources Department for the upkeep of the
Irrigation Systems and protecting them against any damages and to assist the Government in
collection of Water Tax and dues, make prudent investment of their resources;(v)To motivate all the
stake holders for achieving the objectives of Participatory Irrigation Management;](vi)to work in
close coordination with Government departments and its agencies;(vii)to strive for sustainable
water resources management and development;(viii)to ensure in dissemination of
information;(ix)to build up a reliable database;(x)in areas of high water requirement like cropped
areas, effective soil and water conservation techniques should be adopted with the guidance of
departmental agencies;(xi)sustainable and effective land use system should be
followed;(xii)implementation of agro-forest ecosystem wherever water erosion is a serious
threat;(xiii)adoption of integrated watershed management system and integrated balanced nutrient
management system;(xiv)to ensure that hydraulic structures are preserved and protected, without
any modification unless otherwise approved by an authority vested with such powers;(xv)to work
towards maintaining and sustaining an ecological balance and prevent degradation of the
environment particularly soils and quality of water;(xvi)to strive towards becoming sustainable
institution through a process of capacity building, skill up gradation and recovery of costs, wherever
necessary; and xvii) to optimize productivity and production consistent with the availability of water
supplies.Rights of Farmers Organisation
5. The rights of the Farmers Organisation shall be as follows:
(i)to obtain information in time about water availability, opening / closing of main canal, periods of
supply and quantity of supply, closure of canals etc.;(ii)[ To assist the Water Resources Department
for distribution among the water users on agreed terms of equity and social justice;] [Substituted by
Notification No. G.O. Ms. No.17, Water Resources (CADA) Department, dated 8.2.2019 (w.e.f.
27.12.2018).](iii)to receive water according to an approved time schedule;(iv)to allocate water to
non-members;(v)to levy separate fees for maintenance of the system;(vi)to levy any other fee or
service charges, to meet management costs and any other expenses;(vii)to utilize the canal bunds as
long as such use is not obstructive, or destructive to hydraulic structures - by planting timber, fuel,
or fruit trees or grass for augmenting the income of the Farmers Organisation;(viii)to obtain the
latest information about new crop varieties, and their pattern, package of practices, weed control,
etc., for agriculture extension service, and purchase inputs such as seeds, fertilizers and pesticides;
for use of its members;(ix)to have full freedom to grow any crop other than those expressly
prohibited by a law and adjust crop areas within the total water allocated without causing injury to
neighboring lands;(x)to participate in planning, and designing of micro-system;(xi)To suggest
improvements / modifications in the layout of Field Channels/Field Drains to supply water to all the
farmers in the command; and(xii)to plan and promote use of the ground water.Responsibility of The
Farmers OrganisationA.P. Farmers Organisation Rules, 1997

6. The responsibility of Farmers Organisation shall be as follows:
(i)to prepare the schedules of water deliveries and communicate to the concerned;(ii)to organize
preparation of crop plan to match water deliveries with crop requirements;(iii)to supply water to all
members in the command area as per the approved terms;(iv)to carry out timely maintenance and
repairs to the distributory system including drains and other properties;(v)to organize repairs of the
system by the farmers free of cost or on payment;(vi)to avoid and prevent misuse and wastage of
water;(vii)to use water economically and judiciously and furnish data, to the Water Resources
Department on water use, irrigated area, irrigation efficiency, and crop yields;(viii)to inspect water
utilisation by the farmers in the command; assess irrigated crop areas and collect data on crop
yields;(ix)to impose and recover penalties or fines for misuse and wastage of water and tampering or
damaging with the irrigation network controls, sluices, outlets etc., as per the provision of the
Act;(x)to educate farmers on preparing fields and adopting modern methods of field irrigation, such
as borders, furrows, graded bunding for all round efficiency;(xi)to educate farmers on new crop
varieties, packages of practices, pesticides, weedicides, etc.;(xii)to procure and hire implements and
gadgets for agricultural operation where feasible and needed.;(xiii)to improve the system for
efficient and economical use of available / allocated water, for efficient production of crops;
and(xiv)to minimize conveyance and operational losses.Rights of Member Users
7. The rights of the member users shall be as follows:
(i)to suggest improvements/ modifications in water deliveries;(ii)to get information relating to
water availabilities, allocations, opening /closing of canals and outlets, period of supply, frequency,
etc.;(iii)to receive water as per specified quota for use;(iv)to have the freedom of growing any crop,
other than those prohibited by law, adjusting the areas within the water allocated and without
causing adverse effect to the crops of other farmers;(v)to sell or transfer the water share to any other
water user within the operational area of water users association;(vi)to participate in the General
body meeting and receive annual reports; and;(vii)to receive equitable benefits from the activities of
the organization;Responsibility of Member Users
8. The responsibilities of the member users shall be as follows:
(i)to maintain the micro-level system particularly the turn outs, field channels, structures, and field
drains;(ii)to be aware of the rules of operation of water supply framed by the Farmers Organisation
for each season;(iii)to adhere to the water delivery schedules;(iv)not to tamper with the system by
breaching, cross bunding, damaging the structure in the minor or field channel;(v)to close the
turnout fully after the allotted turn or time is over;(vi)to conserve water and make judicious use of
the irrigation supply;(vii)to divert water if not required during the turn or time allotted, so as not to
damage other farmers field;(viii)to follow proper irrigation methods like borders, furrows, check
basins etc.;(ix)to get the lands leveled /shaped for efficient utilization of land and water and to
prevent deep percolations leading to water logging and salinity in the downstream areas;(x)to-pay
the irrigation fees, water tax and service charges regularly and in time;(xi)to avoid misuse/wastage
of water, taking water out of turn, taking more time than allotted;(xii)to avoid trampling of Field
Channels/ Field Drains, by crossing at unauthorised points by men and cattle;(xiii)to maintain FieldA.P. Farmers Organisation Rules, 1997

Channels/Field Drains in the reaches specified by the Water User Association, or contribute to
labour /cost for maintenance, whenever required;(xiv)to permit inspection of :(a)irrigated
area;(b)measurement of irrigated area;(c)observation of water levels in dug wells/ bores/ tube
wells;(d)crop - cutting experiments for assessing productivity / production; and(xv)to respect
easementary rights and other customary practices in vogue in the system.
9. General Body.
- (i) The General body of a Farmers Organisation shall comprise of all members as specified, under
subsection 4 of Section 3 of the Act, in respect of a water users association; sub-section (3) of
Section 5 of the Act in respect of a Distributory Committee, sub-section 3 [and 4 of Section 7]
[Added as per G.O.Ms.No.53, datedt 11-4-2008.] in respect of a Project Committee.(ii)The General
Body shall be assisted by the Competent Authorities as notified under Section 21 of the Act. The
Competent Authority (Engineering) shall have the right to attend the meeting and record his views,
but shall have no right to vote.
10. The General Body Meetings.
- (i) The General Body shall meet at least twice in a year, once before the Kharif and once before the
Rabi season. The meetings shall be presided over by the Chairman, President and in his absence
[Vice-Chairman (or) vice-President] [Added as per G.O.Ms.No.53, datedt 11-4-2008.] as the case
may be.(ii)The General Body may also be called at any time by the President or Managing
Committee members through a majority resolution or by Members of the Organisation through a
requisition signed by not less than 1/3rd of the Members with voting rights.(iii)A General Body
meeting shall be held on receipt of a direction to do so from the Government or from the
Commissioner, or by the next higher tier of the Farmers Organisation in respect of matters relating
to urgent public importance and for any specific purpose.
11. Notice for General Body.
- (i) On receipt of a notice either under sub-rule (2) or (3) of rule 10 the Managing Committee of the
Farmers Organisation shall convene a General Body Meeting within 20 days by giving 7 days prior
notice of the date, time and place of the meeting and also the agenda.(ii)Notice for the General Body
meeting shall be sent at least 7 days in advance of the date of the meeting along with the Agenda.
Notice may be sent by hand/ post / publication /beat of tom-tom and display on the notice board of
the Organization.
12. Quorum for the General Body.
- (i) At all the meetings of the General Body, the quorum shall be 1/3rd of the members and all
resolutions shall be carried by a majority of the members present and voting;(ii)If there is no
quorum for the meeting, the meeting shall be adjourned and be convened again at a date and time
not later than two days of the first/original meeting;(iii)For the adjourned General Body Meeting,A.P. Farmers Organisation Rules, 1997

no quorum is required and resolutions would be carried by a majority of the members present and
voting; and iv) At a requisitioned General Body Meeting, the items specified in the agenda alone will
be discussed. No other subjects will be discussed without the express permission of the
Chairman/President or the majority decision of the members present in the meeting.
13. Minutes of the Meeting.
- (i) Every proceeding of the General Body shall be recorded in the minutes book maintained for the
purpose and authenticated by the Chairman / President or the person who has presided over the
meeting, as the case may be. A copy of the minutes shall be sent to the authority at the next higher
tier and to the concerned Executive Engineer in respect of Water Users Association in Minor
Irrigation Systems.Powers and Functions of General Body of Farmers Organisation
14. The General Body shall have the following powers and functions, namely.
- (i) to identify their Representatives by convening meetings as per the directions of the Government
(or) Commissioner;(ia)[ to identify their Representatives by convening meetings as per the
directions of the Government (or) Commissioner.] [Inserted by Notification No. G.O. Ms. No.17,
Water Resources (CADA) Department, dated 8.2.2019 (w.e.f. 27.12.2018).](ii)to approve the
Operational Plan for each crop season and review its implementation in the area of operation;(iii)to
allocate water amongst various main canals distributaries /minors/outlets, according to the
operational plan approved;(iv)to decide on the manner of regulation and distribution of water;(v)to
prepare annual and long-term financial and works plans and prioritize works for
maintenance/repairs/ upkeep, rehabilitation of the irrigation system as per the directions of the
Government (or) Commissioner;(vi)to approve annual financial budget and review performance of
the previous year budget;(vii)to appoint auditors for the annual audit and/or concurrent audit and
to fix fees for the same;(viii)to set up sub-committees of Members for various activities and
functions of the Organisation;(ix)to create or/setup such fund as may be required for different
activities/works;(x)to levy a fees as defined under Section 20 of the Act;(xi)to decide on permissible
administrative expenses within the ceilings prescribed, from time to time by the Government (or)
Commissioner; and(xii)to carry out the recall proceedings as per Section 10 of the Act.Note. - The
Sub-Rule No:9 is omitted earlier as per G.O.Ms.No.53, Dt:11-4-2008 andSub-Rule 11 is now omitted
(in view of omission of section 22 (iii) of Act and also due to newly adding of one more sub-Rule as
sl.No.1. Hence, the Sl.Nos are corrected accordingly.Composition and Functions of Managing
Committee
15. The composition and functions of the Managing Committee shall be as
follows:
(i)[The Managing Committee in respect of Farmers Organisations shall comprise of (i) the
President, Vice-President and the members of Territorial Constituencies in respect of Water Users
Association as specified in sub-section (1) of Section 4 of the Act; (ii) the President and
Vice-President and Members in respect of Distributory Committee as specified in sub-section (1) ofA.P. Farmers Organisation Rules, 1997

Section (6) of the Act; and (iii) the Chairman and Vice-Chairman and members in respect of Project
Committee as specified in sub-section (1) of Section 8 of the Act.;] [Added as per G.O.53, dated
11-4-2008.](ii)The Meetings of the Managing Committee shall be held at least once in every month
at the office of the Organization. The meeting may however, be held more frequently if it so
required. A meeting requisitioned, shall be held within 7 days of the receipt of requisition for such a
meeting by the Chairman/President;(iii)Notice for the meeting shall be sent by hand/post/ delivery
or published on the Notice Board;(iv)The Chairman / President shall preside over the meetings of
the Managing Committee.In his absence, the Vice-Chairman (or) Vice-President shall preside over
the meeting as the case may be;(v)Every proceedings of the Managing Committee shall be recorded
in the minutes book maintained for the purpose, by the person chairing the meeting. A copy of the
minutes shall be sent to the authority of the next higher tier and to the concerned Executive
Engineer in respect of Water Users Associations in Minor Irrigation Systems;(vi)The quorum for the
meeting shall be 1/3rd of the members. All resolutions shall be carried by a majority of the members
present and voting; and(vii)If there is no quorum for the meeting, the meeting shall be adjourned to
a date and time not later than three days and be convened again. For an adjourned meeting no
quorum is required.Co-Option of Members
15A. [ Co-option of members in to Managing Committee of Farmers
Organisation shall be as follows. [Added as per G.O.53, dated 11-4-2008.]
- (i) Managing Committee of Water Users Association: Gram Panchayat shall nominate two Gram
Panchayat members i.e., one male member and one Female member in to the Managing Committee
of Minor Irrigation Water Users Association. In case there are more than the one Gram Panchayat in
Water Users Association the nomination shall be from the Gram Panchayat whose ayacut is more in
the Water Users Association area of operation. For Major and Medium Irrigation Water Users
Associations there is no cooption of members from Gram Panchayat.(ii)Managing committee of
Distributory Committee: All the Mandal Presidents in the area of operation of Distributory
Committee shall be nominated to the Managing Committee of the Distributory Committee. The
nomination shall be made by the District Collector.(iii)Managing Committee of Medium Irrigation
Project Committee: All the Mandal Presidents, Members of Legislative Assembly, [Members of
Legislative Counsel], and Members of Parliament in the area of Operation of Medium Project shall
be nominated to the Managing Committee of the Project committee. The nomination shall be made
by the District Collector.(iv)Managing Committee of Major Irrigation Project Committee: all the
Members of Legislative assembly, [Members of Legislative Counsel] [Inserted as per G.O.272, dated
23-10-2009.], Members of Parliament and ZillaParishad Chairpersons in the area of operation of
Major Project shall be nominated to the Mangaing Committee of the Project committee. The
nomination shall be made by the Government.Note. - 1. The members co-opted to the Managing
Committee of Farmers Organisations shall not have any voting right.
2. While nominating the Rajya sabha members, and Members of Legislative
Counsel, the criteria of name of the individual in the voters list of General
elections is to be considered for co-option.]A.P. Farmers Organisation Rules, 1997

Powers and Functions of The Managing Committee
16. The powers and the functions of the Managing Committee shall be as
follows.
- (i) to prepare and implement Operational Plan for each season in its area of operation;(ii)to
prepare and implement Kharif and Rabi plans for various crops to be grown;(iii)to prepare budget
and allocate resources for various activities;(iv)to prepare and implement annual and long term
plans for repairs , maintenance, rehabilitation for development of the irrigation and drainage
systems and to accord administrative sanction as per the orders given by the Government from time
to time and taking up works as per availability of resources on priority;(v)to prepare or cause to be
prepared annual accounts of incomes and expenditures, and assets and liabilities;(vi)to ensure
equitable distribution of water among various water users;(vii)to evolve and implement systems of
regulation control, monitoring and reporting of water use and land use;(viii)to recommend
appointment of auditors for annual audit or concurrent audit to General Body;(ix)to organize
execution of works as per Orders issued by the Government (or) Commissioner from time to
time;[***] [Omitted '(x) to recommend formation of sub-Committees to the General Body for
undertaking various activities;' by Notification No. G.O. Ms. No.17, Water Resources (CADA)
Department, dated 8.2.2019 (w.e.f. 27.12.2018).](xi)to settle disputes amongst the members;(xii)to
nominate one of its members to operate the funds of the organization when the post of President
(or) Vice-President falls vacant.(xiii)to provide developmental services to the Members related to
irrigation and agriculture;(xiv)to take up training programme for members;(xv)to prepare annual
list of all Water Users and Members with voting rights;(xvi)to assist the Revenue, Water Resources
and Agriculture Departments in the preparation and Maintenance of basic records;(xvii)to maintain
and operate a Reserve fund as per directions of the Government (or) Commissioner;(xviii)to
scrutinize the audit reports and rectify defects and report to the General Body;(xix)to carry out and
implement all decisions of the General Body; and(xx)to establish a management information system
and submit periodical report as may be prescribed by Government.Duties of Chairman / President
17. The duties of the Chairman/ President of a Farmers Organisation shall be
as follows.
- (i) to preside over the General Body Meetings and Managing Committee Meetings and conduct the
meetings in a peaceful and democratic manner;(ii)to sign and authenticate the minutes of the
meetings and also other records of the Farmers Organisation as may be required;(iii)to have only a
casting vote in the event of equality of votes on any matter being decided upon by the General Body
or the Managing Committee, as the case may be;(iv)to be the custodian of all records, properties of
the Farmers Organisation;(v)render full and complete accounts of all transactions of the Farmers
Organisation;(vi)to sign all contracts and documents on behalf of the Farmers Organisation;(vii)to
have powers to operate the accounts of Farmers Organisation jointly with Vice-Chairman /
Vice-President;(viii)to represent the case of the Farmers Organisation in any dispute before
Distributory Committee or Project Committee or Apex committee or the Government, as the case
may be;(ix)to be an authorized representative of the Farmers Organisation at all other forums,A.P. Farmers Organisation Rules, 1997

meetings called by any authority;(x)to be accountable for all transactions;(xi)to conduct the affairs
of the Farmers Organisation in a democratic, free, fair and transparent manner; andNote. - In view
of omission of Sub-Rule 10, the sl.nos of next sub-rules are changed and arranged in sequence order
xii) to submit annual reports to the General Body on the activities of the Farmers
Organisation.Duties of Vice-Chairman and Vice-President
17A. The duties of Vice Chairman/ Vice President of a Farmers Organisation
shall be as follows.
- (i) to discharge all the functions of the Chairman / President of the Farmers Organisations, in the
absence of Chairman / President;(ii)to sign and authenticate the minutes of meeting where Vice
Chairman / Vice President presides over the meeting as in Sub-Rule (1);(iii)to be the joint account
holder along with the Chairman / President provided that, in case of difference of opinion in the
matter of signing the cheques, the matter shall be placed before the Managing Committee, whose
decision shall be final;(iv)to be the convener of water management sub-committee;(v)To carry out
all the functions of the water management sub-committee and such other decisions of General Body
and Managing Committee on water regulation and schedule of water release.Resignations
17B.
(i)Any member of the Managing Committee or the President or the Vice-President of a Water Users
Association in Major, Medium or Minor Irrigation system may resign his/ her office by tendering
resignation in writing to the Superintending Engineer concerned directly in person or through
registered post with acknowledgment due.(ii)The President and Vice President of Distributory
Committee of a Major Irrigation system may resign his office by tendering resignation in writing to
the Chief Engineer concerned directly in person or through registered post with acknowledgement
due.(iii)Any Chairman / Vice Chairman of a Project Committee of Major/ Medium Irrigation system
may resign his/ her office by tendering resignation in writing to the Commissioner directly in person
or through Registered post with acknowledgement due.(iv)The Authority accepting the resignation
shall cause to enquire through the concerned Competent Authority of the Farmers Organisation
whether the person resigning has(a)any dues to the Farmers Organisation;(b)indulged in any
financial irregularities;(c)abused his power during his incumbency; and(d)misappropriated the
assets of Farmers Organisation.(v)Any resignation shall be accepted within 30 calendar days
including the day of receipt of letter of resignation and day of acceptance of resignation and such
order of acceptance of resignation shall be served to the person resigned in writing and
acknowledgement obtained for taking necessary action.Filling Up of Vacancies
17C.
A vacancy arising due to disqualification, death, or resignation, or recall or by any reason in any tier
of the Farmers Organisation shall be filled in the manner detailed below:A.P. Farmers Organisation Rules, 1997

1. Vacancies in Water Users Association:
(i)President(a)In the event of a vacancy of President in a Water Users Association, the
Vice-President of that Water Users Association shall discharge the functions of the President from
the date of occurrence of such vacancy, till the vacancy is filled in by election.(b)In Major Irrigation
Projects, the Vice-President so discharging the functions of President is eligible to represent his
Water Users Association in the Distributory Committee. However, he is not eligible to contest for
the post of the President or the Vice-President of the Distributory Committee.(c)In a Medium
Irrigation Project, the Vice- President so discharging the functions of President is eligible to
represent his Water Users Association in the Project Committee of that Medium Irrigation Project.
However he is not eligible to contest for the post of a Chairman or Vice-Chairman in the Project
Committee.(d)The Vice-President discharging the functions of the President shall maintain the
Bank account jointly with another Managing Committee member nominated by the Managing
Committee for the purpose, till the vacancy of the President is filled in by
election.(ii)Vice-President.(a)To fill in a vacancy of post of Vice-President in a Water Users
Association, the President shall convene a special meeting of the managing committee which shall
nominate the Vice-President from among the members of the Managing Committee, in the presence
of Competent Authority (Engineering) with in fifteen days from the date of occurrence of such
vacancy. Vice-President shall be nominated from upper reach if the President is from lower reach
and vice versa.(b)The Vice-President so elected in the casual vacancy, shall continue in the office till
the vacancy of Vice-President is filled in by elections.(iii)Territorial Constituency member(a)To fill a
vacancy of a Territorial constituency member, the President shall convene a special meeting of the
managing committee which shall nominate a water user who is a voter in that territorial
constituency, to act as member of managing committee, within 15 days from the date of occurrence
of such vacancy. However, such person is not eligible for election for the post of President or Vice
President in Water Users Association during the period of such transitional arrangements.(b)The
nominated member continues to hold the post only till a member of the territorial constituency is
selected in the manner prescribed, in the causal vacancy.(iv)Convening Special Meeting. - The
President shall convene a Special Meeting of the Managing Committee within 15 days from the date
of occurrence of vacancy of Vice-President or member of territorial constituency for filling up of any
causal vacancy.
2. Vacancies in a Distributory Committee
(i)President(a)In the event of vacancy of a president in a Distributory Committee, the Vice-
President of the Distributory Committee shall discharge the functions of the President from the date
of occurrence of such vacancy till the vacancy is filled in by election.(b)The Vice-President
discharging the functions of President is eligible to represent his Distributory Committee in the
Project Committee. However he is not eligible to contest for the post of Chairman or Vice-Chairman
of the Project Committee.(c)The Vice-President who is also discharging the functions of the
President shall maintain the Bank Account jointly with another Managing Committee member
nominated by the Managing Committee for the purpose till the vacancy of the President is filled in
by election.(ii)Vice President(a)To fill the vacancy of the post of Vice-President in a Distributory
Committee, the President shall convene the meeting of the managing committee which shallA.P. Farmers Organisation Rules, 1997

nominate the Vice-President from among the members of the managing committee in the presence
of the Competent Authority (Engineering) within the fifteen days from the date of occurrence of
such vacancy.(b)The Vice-President so elected shall continue in the office till the vacancy of Vice -
President is filled in by elections.(iii)Convening Special Meeting. - Convening of Special meeting
within 15 days from the date of occurrence of vacancy of Vice-President, shall be the personal
responsibility of the President.
3. Vacancies in a Project Committee.
(i)Chairman(a)In the event of vacancy of a Chairman in a Project committee, the Vice-Chairman of
that Project Committee shall discharge the functions of the Chairman from the date of occurrence of
such vacancy till the vacancy is filled in by election.(b)The Vice-Chairman discharging the functions
of the Chairman shall maintain the Bank Account jointly with another Managing Committee
member nominated by the Managing Committee for the purpose till the vacancy of the Chairman is
filled in by election.(ii)Vice Chairman(a)To fill the vacancy of the post of Vice-Chairman in a Project
committee, the Chairman shall convene a special meeting of the managing committee which shall
nominate the Vice-Chairman from among the members of the managing committee in the presence
of the Competent Authority (Engineering) within fifteen days from the date of occurrence of such
vacancy.(b)The Vice-Chairman so elected shall continue in the office till the vacancy of Vice -
Chairman filled in by election.(iii)Convening Special Meeting. - Convening of Special meeting within
15 days from the date of occurrence of vacancy of Vice-Chairman, shall be the personal
responsibility of the Chairman.Settlement of Disputes
17D. Any dispute or difference touching the constitution, management,
powers or functions of a Farmers Organisation arising shall be determined
as follows.
(1)Disputes in Major Irrigation System(a)Any dispute or difference arising between Water users in a
Water Users Association shall be determined by the managing committee of Water Users
Association concerned.(b)Any dispute or difference arising between water users and the managing
committee of a water User Association or between two or more Water Users Associations shall be
determined by the managing committee or Distributory Committee.(c)Any dispute or difference
arising between two or more Distributory Committees shall be determined by the Managing
Committee of Project Committee.(d)Any dispute or differences arising between two or more Project
Committees shall be determined by the Apex Committee, whose decision shall be final.The
Executive Engineer, Superintending Engineer and Chief Engineer will be the authorities for
settlement of disputes in place of Distributory Committee, Project Committee and Apex Committee
respectively when these bodies are not functioning.(2)Dispute in Medium Irrigation Projects(a)Any
dispute or difference arising between Water users in a Water Users Association shall be determined
by the managing committee of the Water Users Associations. Any dispute or difference arising
between water users and the Managing Committee of Water Users Association or between two or
more Water Users Associations shall be determined by the project committee.(b)Any dispute or
differences arising between two or more Project Committees shall be determined by the ApexA.P. Farmers Organisation Rules, 1997

Committee, whose decision shall be final. The Executive Engineer and Superintending Engineer will
be the authorities for settlement of disputes in place of Project Committee and Apex Committee
respectively when these bodies are not functioning.(3)Disputes in Minor Irrigation System:(a)Any
such disputes or difference arising between in a Water Users Association shall be determined by the
managing committee of that Water Users Associations concerned.(b)Any such disputes or difference
arising between Water Users and the managing committee of Water Users Association or between
two or more Water Users Associations shall be determined by the Executive Engineer
concerned.Time limit for settlement of disputes. - Every dispute or difference under the rule shall be
settled within thirty days from the date of reference of the dispute or difference.Appeals
17E. A Party to a dispute or difference aggrieved by any decision made or
order passed under Rule 17 D, may prefer appeal in the manner detailed
below.
(1)Appeals in Major Irrigation Projects(a)Any party to a dispute or difference aggrieved by the
decision made or order passed by the managing committee of a Water Users Association may appeal
to the managing committee of the Distributory Committee, whose decision thereon shall be
final.(b)Any party to a dispute or difference aggrieved by the decision made or order passed by the
managing committee of a Distributory Committee may appeal to a Project committee whose
decision thereon shall be final.(c)Any party to a dispute or difference aggrieved by the decision made
or order passed by the managing committee of a Project Committee may appeal to the Apex
Committee whose decision thereon shall be final.In case Distributory Committee or Project
Committee or Apex Committee is not functioning, the appellate authority will be the Superintending
Engineer, Chief Engineer and the Government respectively, and whose decision there on shall be
final.(2). Appeals in Medium Irrigation System(a)Any party to a dispute or difference aggrieved by
the decision made or order passed by the managing committee of a Water Users Association may
appeal to the managing committee of the Project Committee, whose decision thereon shall be
final.(b)Any party to a dispute or difference aggrieved by the decision made or order passed by the
managing committee of a Project Committee may appeal to the Apex Committee, whose decision
thereon shall be final.In case of Project Committee or Apex Committee is not functioning the
appellate authority will be the Superintending Engineer and Chief Engineer respectively whose
decision thereon shall be final
3. Appeals in Minor Irrigation System
(a)Any party to a dispute or difference aggrieved by the decision made or order passed by the
managing committee of a Water Users Association may appeal to the Executive Engineer
Concerned, whose decision thereon shall be final.(b)Any party to a dispute or difference aggrieved
by the decision made or order passed by the Executive Engineer may appeal to the Superintending
Engineer concerned, whose decision thereon shall be final.A.P. Farmers Organisation Rules, 1997

4. Time limit for Preferring an appeal. - Any appeal under the Rule shall be
preferred within thirty days of communication of the decision or the order to
the person aggrieved.
5. Time limit for settlement of appeals. - Every appeal under the rule shall be
settled within thirty days from the date of filing of the appeal.
Inspection of Records
17F. Inspection of records of a Farmers Organisation shall be as follows.
- 1. Water Users Association:(a)The Competent Authority shall be the inspecting authority for any
Water Users Association in his jurisdiction.(b)The inspecting authority shall have access to all
records, to be maintained by the Water Users Association and shall affix his signature and date on
the records and registers with his remarks, upon inspection.(c)Any misappropriation of funds or
misuse of power noticed shall be brought to the notice of the Superintending Engineer concerned
who shall take further action in accordance with the provisions of the Act and the Rules.
2. Distributory Committee.
(a)The Competent Authority shall be the inspecting authority for any Distributory Committee in his
jurisdiction.(b)The inspecting authority shall have the access to all records to be maintained by
Distributory Committee and shall affix his signature and date on the records and register with his
remarks, upon inspection.(c)Any misappropriation of funds, or misuse of power noticed, shall be
brought to the notice of the Chief Engineer who shall take further action in accordance with the
provisions of the Act and the Rules.
3. Project Committee.
(a)The competent authority shall be the inspecting authority for any Project committee in his
jurisdiction.(b)The inspecting authority shall have the access to all records to be maintained by
Project Committee and shall affix his signature and date on the records and register with his
remarks, upon inspection.(c)Any misappropriation of funds, or misuse of power noticed, shall be
brought to the notice of the Commissioner who shall take further action in accordance with the
provisions of the Act and the Rules.Authority To Remove Office Bearers of Farmers Organisation
17G. The following are the authorities to remove the erring office bearers of
the Farmers Organisations.
- (i) Removal of office bearers:(a)The Superintending Engineer concerned shall be the authority to
issue directions for proper functioning of the Water Users Association and remove any member of
territorial constituency or President or Vice President of any Water Users Association in hisA.P. Farmers Organisation Rules, 1997

jurisdiction under Section 41A of the Act.(b)The Chief Engineer concerned shall be the authority to
issue directions for proper functioning of the Distributory Committee and remove any president or
Vice President of Distributory Committee in his jurisdiction under Section 41A of the Act.(c)The
Commissioner shall be the authority to issue directions for proper functioning of Project Committee
and remove any Chairman or Vice-Chairman of Project committee in his jurisdiction under Section
41A of the Act.Note. - The authority mentioned above shall give a reasonable opportunity to the
aggrieved party to represent their cases before they are removed from their posts.
2. Authority for Appeal.
(a)Any party aggrieved by any decision made or order passed by the Superintending Engineer under
the rule may appeal to the District Collector concerned, whose decision thereon shall be final.(b)Any
party aggrieved by any decision made or order passed by the Chief Engineer under the rule may
appeal to the Commissioner whose decision thereon shall be final.(c)Any party aggrieved by any
decision made or order passed by the Commissioner under the rule may appeal to the Government,
whose decision thereon shall be final.Transitional Arrangements
17H. Transitional arrangements for the Farmers Organisation are as follows.
- 1. Officer: After completion of the term of elected bodies of the Farmers Organisation, and where
no incharge arrangements are made all the records of the concerned Farmers Organisation shall be
handed over to the following officers as per the specific instructions from the Government who will
exercise powers and to perform the function of the Farmers Organisations.(a)Deputy Executive
Engineer concerned shall be the authority to take over the charge of the Water Users Association
with all records and exercise the powers and perform the functions of the Farmers Organisations till
such time such Water Users Association is constituted or reconstituted.(b)The Executive Engineer
concerned shall be the authority to take over the charge of the Distributory Committee with all
records and exercise the powers and perform the functions of the Farmers Organisations till such
time, such Distributory Committee is constituted or reconstituted.(c)The Superintending Engineer
concerned shall be the authority to take over the charge of the Project committee with all records
and exercise the powers and perform the function of the Farmers Organisations till such time the
Project Committee is constituted or reconstituted.Note. - The Superintending Engineer/ Executive
Engineer / Deputy Executive Engineer who has taken over the Farmers Organisation shall be
assisted by the subordinate staff under his Administrative / Technical Control.
2. The Government may, by Notification, appoint an officer or officers or the
outgoing President or Chairman of the Farmers Organisations whose
performance is adjudged as good as prescribed or a managing committee
consisting of President, Vice- President and four (4) members as appointed
by the General Body of Farmers Organisations by consensus to exercise the
powers and perform the functions of a Farmers Organisation and the
Managing Committee thereof till such time such Farmers Organisation isA.P. Farmers Organisation Rules, 1997

duly constituted or reconstituted and such Managing Committee assumes
office under the provision of this Act.
3. The outgoing President or Chairman of the Farmers Organisation and
other members having no arrears of water tax payable to Government, who
took lot of initiative in water regulation and provided good leadership in
discharging their functions may be considered for appointment under the
above Rule.
Note. - 17(H) (1) omitted and 17(H) 2 may be read as 17 (H) 1
17. (H) 2 as per Amendment made to section 34 of act
17.
(H)3 is newly addedMaintenance of Feeder Channels
17I. The Water Users Associations shall maintain the feeder channels on the
upstream of tank bed as follows.
-(a)Desilting of feeder channels in sectioning.(b)Removal of weed growth, trees and the like in the
channel bed.(c)Breach closing.(d)Removal of encroachments with the help of local Revenue
authorities,.(e)Removal of mounds and maintaining bed slopes of feeder channels.(f)All other
measures required to insure adequate inflow in to the tank through the feeder channels.Constitution
and Functions of Sub-Committee
18.
The constitution and functions of the Sub-Committees shall be as follows:
1. The General Body of a Farmers Organisation may constitute specific
Sub-Committees under Section 11 of the Act, to carry out specific functions
as assigned by the General Body;
2. The composition of the Sub-Committee shall be as follows:
(i)The Convener of a Sub-Committee shall be a member of the Managing Committee other than the
Chairman/ President;(ii)In the case of a Project committee and their members of the subcommittee,
not exceeding four will be selected from Presidents of Water Users Associations in that
project;(iii)In the case of Distributory Committee and their members of the subcommittee, not
exceeding four shall be selected from the Territorial Constituencies of the water Users AssociationsA.P. Farmers Organisation Rules, 1997

either in the general body of the Distributory Committee or from its territorial constituencies within
its jurisdiction. However, not more than one Territorial Constituency (TC), member of Water Users
Association can be co-opted in that Sub-Committee;(iv)In the case of Water Users Association the
other members not exceeding four shall be drawn from out of members with voting rights, out of
four one may be woman preferably; and(v)No member shall represent more than one
subcommittee.
3. The following Committees may be constituted by a Farmers Organisation:
(i)Finance and Resources sub-committee;(ii)Works sub-commit tee;(iii)Water Management
sub-committee;(iv)Monitoring-Evaluation and Training sub-committee;Note. - After Rule 17, the
Rules 17 A to 17 I are inserted as per G.O.Ms.No.53, dt:11-4-2008.
4. Functions of the sub-committee
(i)Finance and Resource sub-committee(a)to mobilize and collect resources;(b)to ensure collection
of dues from Members as levied under Section 20 of the Act;(c)to recommend the Managing
Committee on the use and deployment of resources; and(d)to maintain records relating to financial
matters.(ii)Works sub-committee:(a)to recommend estimates of works for administrative
approval;.(b)to supervise works and ensure quality control; and(c)to approve payments for
works.(iii)Water Management sub-committee:(a)to carry out the decisions of the Managing
Committee and of the General Body on water regulation, schedule of water release;(b)to organise
patrolling of the canal, channels and regulate the use of water;(c)to check the irrigation and
drainage system regularly;(d)to record the water deliveries;(e)to report to the Managing Committee
any violations in the use of water; and(f)to maintain records of land owners and water users.(g)the
Vice-Chairman / Vice-President shall be the Convener of this Sub-Committee under Rule
17(A).(iv)Monitoring-Evaluation and Training sub-committee:(a)to identify training needs and
organize training to the Water Users;(b)to educate in optimum use of water;(c)to monitor specific
items like area irrigated, productivity, disputes settlement and resources building;
5. The Sub-Committees shall meet as frequently as necessary. The members
of the Managing Committee in charge of the sub-committees will preside
over the meetings and maintain the record of discussions and decisions.
6. The Sub-Committees shall function under the general super intendence,
control and direct ion of the Managing Committee of the organization.
Procedure for Taking up Works
19. The procedure for taking up the works shall be as follows.
- The works in a Farmers Organisation shall be categorized as follows:-A.P. Farmers Organisation Rules, 1997

1. Normal Operation and Maintenance Works
a. Desilting;b. Weed removal;c. Embankment repairs;d. Revetment;e. Repairs to shutters;f. Repairs
to masonry and lining;g. Cleaning & Oiling of screw gearing shutters;h. Painting of hoists and gates
etc.;i. Emergent breach closing works;j. Maintenance of inspection paths;k. Formation of cross
bunds; andl. Lifting of water by oil Engines / Generators.
2. Deferred Maintenance Works (Rehabilitation Works)
a. Reconstruction of sluices;b. Reconstruction / repairs to Drops & Regulators;c. Reconstruction of
measuring devices;d. Rehabilitation of the system; and
3. Original Works.
a. Modernization of the system; andb. A Farmers Organisation shall take up the normal Operation &
Maintenance and deferred maintenance works i.e., regular works costing up to Rs. 5.00 lakhs or as
per the limit prescribed by the Government from time to time and the works shall be executed by the
Farmers Organisations under the supervision of the Water Resources Department at the rates not
exceeding the estimated rates. The works costing above Rs. 5.00 lakhs or the limit prescribed by the
Government are to be entrusted by the Department duly calling tenders.The Government may also
prescribe procedures from time to time for the works taken up under various programmes including
External Aided projects.Original works shall be taken up by the Department duly calling tenders or
as prescribed by the Government from time to time under various programs.The procedure for the
works taken up by the Farmers Organisations is as follows:
4. System Diagnosis for maintenance works.
(i)Prior to the commencement of every crop season (Kharif & Rabi) the Managing Committee and
Competent Authority (Engg) of every Farmers Organisation shall undertake to assess the condition
of the system (system diagnosis) through a participatory walk-through exercise.(ii)The Farmers
Organisation shall inspect each and every hydraulic structure and record its status.(iii)They have to
identify all the critical reaches which need immediate repair as listed out in above. The Competent
Authority (Engg) shall assist the Farmers Organisation in preparation of detailed list of works to be
undertaken.
5. Prioritizing works. - The Managing committee of the Farmers Organisation
shall discuss the list so prepared and fix up priority of works to be taken up
immediately.
6. Preparation of Estimates. - The competent authority (Engg.) and Works
Sub-Committee shall prepare estimates for the works so prioritized
according to the hydraulic particulars as maintained by the Water ResourcesA.P. Farmers Organisation Rules, 1997

Department at the prevailing schedule of rates within a fortnight.
6.
(i)The proposals for taking up various works under various categories required scrutiny of CAD
committee for approval of the annual Action Plan for O & M and deferred maintenance in each of
the project that would include tax re-plough, category B and other Capital and Revenue grant.
7. Administrative Approval. - (i) Managing Committee of the Farmers
Organisation shall accord Administrative Approval for the works taken up
with water tax plough back amounts and own resources. The Works
Sub-Committee shall recommend estimates of works for administrative
approval. The Administrative Approval is subject to availability of funds.
Each administrative approval shall be recorded in the register of
Administrative Approvals.
(ii)For the works taken up with the funds including government grants other than water tax plough
back amounts and own resources, the administrative approval shall be as per the departmental rules
in vogue.
8. Technical sanction. - (i) The power for giving technical sanction by the
Competent Authority (Engg.) shall be based on the approval of the Executive
Engineer/ Superintending Engineer / Chief Engineer as per the existing
Government limits.
(ii)The Competent Authority, shall record all the technical sanction in the register of technical
sanction; and(iii)The technical sanction shall not exceed the Administrative Approval.Explanation 1.
- In respect of a Distributory Committee and the Project Committee, the Competent Authority
concerned may cause the technical sanction to be given by an appropriate officer under his control.
9. Manner of Taking up works. - (a) Works as approved by the Managing
Committee of the Farmers Organisation shall be taken up for execution by
the Farmers Organisation itself;
(b)Under no circumstances can a Chairman/ President or Managing Committee Member of the
Farmers Organisation execute a work directly in his individual capacity;(c)The cost of works
executed shall not exceed the estimated costs;(d)The Competent Authority shall record the
pre-measurements and final measurements for quantifying the work done for making payments by
the Farmers Organisation. These measurements shall be check measured by higher authorities as
per rules and procedure of Water Resources Department;(e)The procedure adopted by the
Competent Authority in preparation of estimates, bills etc., shall be subject to verification by higherA.P. Farmers Organisation Rules, 1997

officials as normally applicable to department;(f)In exigencies, when any of the Farmers
Organisation is not existing or function by any reason the normal Operation & Maintenance,
Deferred Maintenance works i.e., regular works costing up to Rs 5.00 lakhs or the limit as
prescribed by the Government from time to time in the jurisdiction of such Farmers Organisation
shall also be taken up by the department duly following the rules and procedures in vogue;
10. Maintenance and Adherence to the Designed Hydraulic Particulars. - The
competent authority shall be responsible for the maintenance and adherence
to the approved hydraulic particulars. He shall ensure strictly that the
designed hydraulic particulars of an irrigation system are not altered with. He
shall guide the Farmers Organisation in supervising works.
11. Limitation on Works. - No Farmers Organisation shall have the power to
interfere with the designed hydraulic particulars of an Irrigation system. Any
violation will invite the penal provisions under Section 23 and also
prosecution under Section 24 of the Act; and the rules made there under.
12. Publication of List of Works to be taken up. - (a) The lists of works to be
taken up should be given wide publicity by means of display in the office of
the Farmers Organisation and other public places and institutions within the
area;
(b)Along with the lists other particulars of works, estimates, values, and mode of execution should
be given wide publicity, and(c)If any member wishes to have access to any of the records relating to
works to be taken up, he may do so on payment of the fee as fixed by the Farmers Organisation.
13. Freedom to add other Funds or Extra Contributions. - The members are
free to contribute resources either in cash or by way of material or labour.
14. Proof of works done. - The Competent Authority shall maintain L.F. Book
and M. Book for recording the work done by the Farmers Organisation. The
L.F Book and M. Book shall bear the number assigned by the Division duly
attested by the Executive Engineer and these books shall be under the
personal custody of Competent Authority.
15. Payment for the Works done. - All payments for works done above Rs.
10,000/- shall be paid by cheque. The Farmers Organisation shall maintain a
record of all payments made in the cash book date-wise.A.P. Farmers Organisation Rules, 1997

16. Quality control. - (i) Quality control checks shall be as per departmental
norms.
(ii)In case of special programmes or External Aided projects, the quality control checks shall be as
prescribed from time to time.Note. - Rule 19 ("Procedure for taking up works") is substituted as per
the G.O.Ms.No.46, dt:23-2-2007 In sub-Rule 19 (1), k & l are added as per G.O.Ms.No.82, dt:
3-8-2016The sub-rule 6(i) is added as per G.O.Ms.no.21, dt:5-3-2010Social Audit of Farmers
Organisation
20. At the end of each crop season the Farmers Organisation shall conduct
social audit as detailed below.
(i)Social audit shall be for both water utilization against the water budgeting and expenditure
incurred for maintenance of the system with reference to funds available to each of the Farmers
Organisation.(ii)The social audit shall cover;(a)Equity in water distribution;(b)Increase in
production;(c)Increase in productivity;(d)Crop diversification;(e)Multiple cropping;(f)Water use
efficiency;(g)Utilization of resources for execution of works(h)Improvement in the cultivated area of
the Farmers Organisation compared to previous season; and(i)Quality of works undertaken.(iii)The
social audit so conducted shall be made known to all the beneficiaries under the Farmers
Organisation by way of displaying a list containing the benefits accrued with reference to funds
spent on the notice board of the office of each of the Farmers Organisation.(iv)Whenever a work is
taken up the estimated cost of the work, item of work proposed to be executed, details of the
executors of the work etc., are to be exhibited on a board at the place of the work; so that every
beneficiary under the Farmers Organisation is aware of the details of the work being executed and
expenditures to be incurred.(v)The competent authority notified shall render all assistance in the
conduct of the social audit. The Revenue and Agriculture Officials shall also render the requisite
assistance.(vi)The social audit so conducted shall be recorded and copy thereof be sent to the
Distributory Committee in the case of water users Association, to the project committee in the case
of Distributory Committee; to the Commissioner in the case of Project Committee.(vii)The auditor
shall incorporate the social audit report in his annual audit report together with his specific
observations on rectification of defects, if any, noticed in the social audit.Operational Plan and
Water Budgeting
21. Water Budget for Farmers Organisation.
- The Managing Committee of the respective Farmers Organisation shall, along with the assistance
of the competent authority, prepare a water budget for the area of operation under its control as
detailed below:(i)One month before the onset of the Kharif season, the Project Committee shall,
subject to such directions as may be given by government from time to time, work out the
anticipated inflows and existing availability in the reservoir and work out the water allocation to all
the Dist ributory Committees; the Distributory Committees intern shall allocate the water made
available to water users association in its jurisdiction:Provided that in the case of medium irrigat ion
projects, the Project Committee shall allocate to the Water Users Associations.(ii)A FarmersA.P. Farmers Organisation Rules, 1997

Organisation in distributing water to its member constituents shall have regard to allocations meant
for drinking waters, or for any specified purpose as may be decided by Government from time to
time.(iii)For the Rabi season, the Project Committee will determine the area to be thrown open for
irrigation based upon the actual availability of water at the beginning of Rabi Season. The water so
available shall be allocated equitably among the Distributory Committees and water users
associations. In the case of medium or minor irrigation system, equitable distribution shall be
achieved by adopting circular rotation over a period.(iv)Each of the Farmers Organisation, shall
draw up an operational plan which shall specify the quantity of water to be drawn on a fortnightly
basis.(v)The drawls of water shall be monitored each day at specified gauge points as decided by the
Farmers Organisation.(vi)Review of the drawls and distribution shall be done by each of the
Farmers Organisation at the end of each fortnight and corrective measures taken.(vii)At the end of
each season the respective Farmers Organisation shall prepare a report of water received and
utilized along with the area irrigated, quantity of water supplied and extent of crops.(viii)Th e
Farmers Organisation shall analyse the short comings and deviations in water budget and report to
the next higher tier.(ix)In respect of a minor irrigation system the water users association shall
decide the operational plan, date of release of water which are to be thrown open for irrigation
depending upon the storage/inflows into the system.Water Regulation
22. After a water budget is prepared, the Farmers Organisation shall draw up
a plan of water regulation as follows:
(a)the dates of release and closure shall be informed to all members well in advance;(b)equitable
distribution of water amongst all users shall be the main principle in water regulation;(c)a Farmers
Organisation shall draw water and monitor flows based on the operational plan prepared;(d)a
Warabandi Schedule (Turn-Schedule) shall be prepared for each outlet in a Farmers
Organisation;(e)the Farmers Organisation shall, carryout Azmoish of the ayacut with the assistance
of the Competent Authority along with the Agriculture and Revenue personnel; and(f)a Farmers
Organisation may, for the purpose of monitoring, install such devices as may be required within its
jurisdiction.
23. Accounts Finance.
- 1. The Farmers Organisation shall open an account in a Nationalized Bank or Government
Cooperative bank in its name and shall be operated jointly by the President/Chairman and 1Vice
President / Vice Chairman. The Farmers Organisation shall maintain the cash book and accounts of
expenditure with appropriate vouchers and receipts.
2. Every expenditure should be supported by a receipt, or voucher which
shall be duly passed for payment by the president or any member of the
Managing Committee authorized by him.A.P. Farmers Organisation Rules, 1997

3. All expenditure has to be approved by the finance sub-committee, at least
once a month.
Account Registers to be maintained.
4. Every Farmers Organisation shall maintain accounts register. Each of the
following record shall bear the name, address and the seal of the Farmers
Organisation and shall be machine numbered; namely:-
(a)Cash book;(b)Bill registers;(c)Contingent registers;(d)Anamath register (Day book);(e)Receipt
books; and(f)Cheque registers.Note. - 1 substituted as per G.O.Ms.no.53
5. [The amounts realized from fisheries, grass, usufruct, and sale of trees
etc., may be credited to the Water Users Association Bank account.] [added
as per G.O. Ms. no. 53]
Records to be Maintained
24. Each of the Farmers Organisation shall maintain the following records,
other than the records specifically mentioned in the Act and the rules.
(a)The following Maps shall be maintained by each water users association; namely: -(i)map
showing the boundaries and jurisdiction of the Association, Water conveyance system, within the
boundaries of the association;(ii)map showing the localized/notified ayacut with S.Nos., (Form-AA)
and(iii)map showing the areas under irrigation not falling within notified ayacut.(b)The following
registers shall be maintained; namely:-(1)Property Register:(i)Inventory Register (Form
-I)(ii)Register of vacant lands and buildings (Form -II)(iii)Register of income on miscellaneous
property (Form-III)(iv)Register of Machinery (Form-IV)(2)Membership Register: Both with voting
rights and without voting rights with details of ayacut Localized / Non-localized and area cultivated
(Form-V)(3)Water flow Register: Canal guage Register (Form-VI)(4)Sanctions Register: Register of
Administrative and Technical sanctions and payments (Form -VII)(5)Cash Register: Cash Book
(Form-VIII)(6)Special fee and tax collection Register: (Form-IX)(7)Minutes Register: (Form X and
X.A)(i)General Body(ii)Managing Committee(iii)Separate Register for Committees.Note. - The
sub-rule (b) of 24 is substituted as per G.O.Ms.No.21, dt:30-1-1999
25. Levy & Collection of Fees.
- 1. The Farmers Organisation can levy a fee as prescribed under Section 20 of the Act,A.P. Farmers Organisation Rules, 1997

2. A fee can be levied only on the resolution of the General Body.
(i)the purpose of levying a fee shall:(a)to provide facilities or ;(b)to provide specific services;(c)to
meet many urgent needs of the Farmers Organisation;(d)to build up assets of the Farmers
Organisation; and(e)to improve the system.(ii)The competent authority shall prepare the estimates
in case any works are to be taken up under this rule.The Managing Committee shall then decide on
the levy of a fee proportionate to the landholding or to the number of members and send a demand
notice.
3. All fees collected shall be duly accounted for through proper receipts.
4. A fee collected for a specific purpose shall be used only for that purpose.
(a)where a member has defaulted in payment of such levy levied by a Farmers Organisation, the
Managing Committee shall prepare a list of defaulters along with amounts due, which shall be
furnished to the Tahsildar of the area in whose jurisdiction the area of operation of a Farmers
Organisation lies for recovery under Section 30 of the Act.
5. The Government may prescribe the rates of fees from time to time for any
of the purposes.
Financial Audit
26. At the end of each financial year, and not later than three months after the
commencement of the new financial year, each of the Farmers Organisation
shall cause its accounts to be audited as follows:
(i)the Managing Committee shall, appoint an Auditor who has adequate experience in normal
auditing work;(ii)the Auditor so appointed shall be a person of repute in the area of operation of the
Farmers Organisation who has reasonable knowledge in accounts or any recognised auditor;(iii)the
appointment of the Auditor shall be approved by the Managing Committee of the Farmers
Organisation;(iv)the Auditor so appointed shall take all steps necessary to scrutinise the accounts of
receipts and expenditure, within thirty days of his appointment and furnish the audit report along
with the statement of accounts and balance sheet to the President of the concerned Farmers
Organisation, duly attesting the same;(v)the audit report shall be submitted to the general body in
its meeting for its approval;(vi)the Managing Committee of a Farmers Organisation shall furnish the
implementation report to the General Body on all matters as pointed out in the audit report and the
Managing Committee shall implement the decisions of the General Body in this regard; and(vii)if
the overall transactions exceed Rs.20.00 lakhs per annum, the Farmers Organisation shall engage
the services of a Chartered Accountant.A.P. Farmers Organisation Rules, 1997

27. Offences and Penalties.
- 1. The Competent Authority shall have a right to take action on any of the offence specified under
Section 23 of the Act and offences shall be booked in Preliminary Offence Report in Form XI by the
Competent Authority.
2. The Competent Authority shall give a notice of the offence to the
individual.
3. The individual who has committed the offence shall be given reasonable
opportunity, to explain his point of view.
4. If the offence is proved beyond doubt, the officer not below the rank of Dy.
Executive Engineer having jurisdiction over the area in Form XII may fix an
amount as fine, as specified under Section 25 of the Act and get it recovered.
5. The fine amount should be adequate enough to rectify the tampering or
damage in the system and injury caused to others.
6. The money recovered as per sub-rule (4) above shall be duly
acknowledged and accounted for.
7. In all cases, where the damage due to the offence is estimated to be more
than Rs.10,000/-, the individual (or) group of individuals who indulged in
causing damages, alterations (or) obstructions in any irrigation system is/are
liable for prosecution under Section 24 of the Act. In such cases, an officer
not below the rank of Executive Engineer having jurisdiction over the area is
authorized to issue prosecution orders against the individual/individuals.
Note. - In view of omission of sub-Rule 4 & 9, the sl. nos of the next sub-rule are changed and
arranged in sequence orderFunctions of Competent Authority
28.
In the functioning of the Managing Committee of the Farmers Organisation, the Competent Author i
ty, appointed under sub-section (1) of Section 21 of the Act, shall:-A.P. Farmers Organisation Rules, 1997

1. attend the meetings convened by the Managing Committee, and participate
in the discussions. However, he shall not have any voting right. He is the
custodian of all the vital records and Registers of the Government and also
in charge of all the Structures and irrigation systems in his jurisdiction;
2. assist in the preparation of maintenance plan;
3. prepare estimates for works identified for execution; the estimate shall be
prepared as per the norms and the rules prescribed by the Water Resources
Department from time to time and also obtain approval for action Plan from
CAD Committee.
3.
a The Competent Authority is primarily responsible for proper upkeep of the Irrigation structures &
orderly Water Regulation.
4. to accord or obtain technical sanction from the officer competent to the
maintenance works, as per the powers delegated. The technical sanction
shall be limited to the administrative sanctions for the work;
5. ensure that no alteration or change is made in the irrigation system, with
reference to the approved hydraulic particulars;
6. bring to the notice of higher authorities of Water Resources Department
any tampering or changes made in the system, by any Farmers Organisation
in contravention of the hydraulic particulars. He shall ensure that action is
taken in accordance with the Sections 23, 24 and 25 of the Act as the case
may be for the damages caused and also take immediate action for its
restoration;
7. provide technical details of the system and guidance to the member of the
Managing Committee;
8. record measurements for the work done and pass the bills for payments
by Farmers Organisation based on the approval of the works sub-committee.A.P. Farmers Organisation Rules, 1997

9. to conduct recall proceedings of a Chairman or Vice-Chairman or
President or Vice-President or member of managing committee of Farmers
Organisation.
Note. - in view of omission of the sub-rule 8 to 13, the sl. Nos of the next sub-rules are changed and
arranged in a sequence order. And also the sub-rule 28(9) is brought from the GO 53, dtd
11-4-2008Competent Authority (Engineering)
28A. The following officers shall be Competent Authority (Engineering) for
different tiers of Farmers Organisation.
- 1. Water Users Association level. - Officer of the rank of Assistant Executive Engineer (AEE) or
Assistant Engineer (AE) shall be the Competent Authority (Engineering) for Water Users
Associations as notified by the Government.
2. Distributory Committee level. - Officer of the rank of Deputy Executive
Engineer (DEE) shall be the Competent Authority (Engineering) for
Distributory Committee (DC) of Major Irrigation Project as notified by the
Government.
3. Project Committee level. - Officer of the rank of Executive Engineer (EE)
shall be the Competent Authority (Engineering) for Project Committee (PC) of
Medium Irrigation Project as notified by the Government.
Officer of the rank of Superintending Engineer (SE) shall be the Competent Authority (Engineering)
for Project Committee (PC) of Major Irrigation Project as notified by the Government.Competent
Authority (Agriculture)
28B. The following officers shall be competent Authority (Agriculture) for
different tiers of Farmers Organisations.
- 1. Water Users Association level: (Water Users Associations)Mandal Agricultural Officer (MAOs)
shall be competent authority (Agriculture ) to Water User Association (WUA).
2. Distributory Committee level:
Assistant Director of Agriculture (Regular) shall be competent authority to the Distributory
Committees of major Irrigation Project.A.P. Farmers Organisation Rules, 1997

3. Project Committee level:
(a)Joint Director of Agriculture (JDA) of the District Concerned shall be competent authority to
Project committee of Major Irrigation Project.(b)Deputy Director of Agriculture (DDA) of the
concerned district shall be competent authority to Project committee of Medium Irrigation
Project.The Functions of competent authority (Agriculture ) are as follows:-
1. Attend General Body meetings convened by the managing committee
(M.C) or members through requisition, at least twice in a year, one before
Kharif and another before Rabi season.
2. Assist the Managing Committee in the preparation of Action Plan for
Agriculture production and also contingent plans in case of contingency.
3. Provide literature on irrigated agriculture published by the department or
any other reputed organizations.
4. Arrange trainings on irrigated agriculture in consultation with Deputy
Director of Agriculture (DDA) Farmers Training Centre (FTC), District
Irrigation Agronomist (DIAs), Acharya N.G. Ranga Agricultural University
(ANGRAU), Non Government Organization (NGO) or any other organization.
5. Organise on farm Demonstrations (OFDs) in the holdings of Water Users
Association members with or without Government aid (selection should be
made in the General Body Meetings).
6. Conduct interaction meetings at 2 or 3 critical stages of the crop.
7. Celebrate field day in the presence of farmers, Water Resources
Department & Revenue Department officials and record the yields.
8. Record the yields of crop cutting (CC) Experiments conducted by the
Directorate of Economics Statistics, if the experiments happen to fall in the
area of Water Users Association.
9. If there are no crop cutting experiments in the WUA area, conduct special
crop cutting experiments for each crop and season with the help of Assistant
Statistical Officer from the office of the Tahsildar.A.P. Farmers Organisation Rules, 1997

10. Guide the farmers in the maintenance of the following Records and
Registers.
• On Farm Demonstration (OFD Register)• Soil Map and Soil Testing results• Statistical register
including yield data of preceding 5 years i.e., Crop wise normal areas, yield , Yield potentiality of
crops etc.,• Agricultural literature.
11. Collect success stories of the farmers who got good yields and display at
prominent places of the village and introduce the farmers in the General
Body meetings.
12. Provide technical inputs regularly to all the members of Farmers
Organisation for increasing productivity of irrigated crops.
13. Ensure to grow Irrigated Dry (I.D) crops in the tail end areas of canals in
the place of paddy for increasing crop intensity.
14. Educate Farmers Organisations on reduction of cost of cultivation of
irrigation of irrigated and I.D, crops for getting economical returns by
adopting Integrated Nutrient Management (INM) & Integrated Pest
Management (IPM) etc.,
General
29.
1. The Farmers Organisation shall assist the Government/ Commi s s ioner
/Gove rnment author i t i es in implementing the various provisions of the Act
and Rules; and it shall abide by the directions/orders given by the
Government/Commissioner.
2. The Farmers Organisation shall assist the District Collector and Election
Authorities in the conduct of elections.
3. Every year, in the month of April, an updated list of landholders shall be
prepared in Form "B" who used irrigation water. Also other water users such
as industrial units, bathing ghats, fishermen societies and such other
categories will be maintained in Form 'C'.A.P. Farmers Organisation Rules, 1997

4. Claims and objections shall be received by the Managing Committee and
decisions taken before the end of April. Decisions of the Managing
Committee will be subject to appeal to General Body and orders of the
General Body will be final.
5. Those members who do not abide by the decisions of the Managing
Committee/ General Body who do not pay the water cess/ taxes or who do
not make contributions towards the activities of the association shall be
subjected to the following course of action; namely
(a)the General Body of Association may take a decision not to supply water or provide benefits to
such person;(b)the General Body may order for recovery of damages and cause them to reimburse
the loss caused to the assets or income of the Farmers Organisation;(c)the General Body may take a
decision to prosecute such persons in a court of law.(1)Property RegisterGovernment of Andhra
PradeshIrrigation and Command Area Development DepartmentWatervUsees'
Association_____________________________Mandal_________________________District.Form
- IInventory Register FormDetails Of System And Command Structures
Sl. No Details of canal at off take MinorDetails of canal /
F.CDetails of structure
Bed
WidthOther details Dimensions/
Lined / unlinedStructure Name /
NatureDetails / Dimensions /
Hydraulic stractures
      
The above details of (A) Canal and (B) Structures from off take to end of canal and the details of
structures on canals taken off from the main source are to be posted in separate pages as shown in
the proforma.Form - IIRegister of Vacant Lands and Buildings
Sl.No LocationSy. No. of Land
extent /Details of
BuildingsDescription of
Building R.C.C/
Tails etc,Extent of
landClassification Remarks
Mandal VillageSy. No of land
ExtentWet I.D./Dry
1 2 3 4 5 6 7 8910
          
Form  IIIRegister of Income on Miscellaneous Property
Sl. No YearIncome
of fishingIncome
on
TreesIncome
on
Grass
Area
of
Tank/
KuntaAuction
AmountAmount
ReceivedDueArea of
Tank/
KuntaAuction
AmountAmount
ReceivedDue DetailsAuction
AmountAmount
ReceivedDueA.P. Farmers Organisation Rules, 1997

1 2 3 4 5 6 7 8 9 10 11 12 1314
              
Income on
Lease /
Rent of
Land/
StructuresIncome
from
Machinery/
Mechanical
EquipmentOthers
Income
DetailsAuction
AmountAmount
ReceivedDue DetailsAuction
AmountAmount
ReceivedDue DetailsAuction
AmountAmount
ReceivedDue
15 16 17 18 19 20 21 22 23 24 25 26
            
Form - IVRegisteer of Machinery
Sl. NoDetails of Machine Make/
Model /Engine No. etcDate Purchase
procurementReceived
FromValue of
MachineRemarks
Book
valuePresent Assessed Value
1 2 3 4 5 6 7
       
Form  VRegister of MembershipDetails of Members With Voting Rights(Form-A)
Sl.No Details of voter Mandal Village Sy.No Extent of Land Area cultivated
Name Fathers' Name WET I.D WET I.D
1 2 3 4 5 6 7 8910
          
Details of Members Without Voiting Rights(Form-B)
Sl.No Details of voter Mandal Village Sy.No Extent of Land Area cultivated
Name Fathers' Name WET I.D WET I.D
1 2 3 4 5 6 7 8910
          
Wua-Details of Other Members(Form-C)
Sl. No Organisation / Name Water Use Members Name Address
1 2 3 4 5
     
Form-VIWater Flow RegisterCanal Gauge Register
Bed width:   
Supply depth at end: Guage: Discharge:
Date TimeGauge depth at start
of Association
JurisdictionDischarge in
CusecsGauge depth at end of
Association
JurisdictionDischarge in
cusecsWater
Used
In
cusecsIn
M.C.ftA.P. Farmers Organisation Rules, 1997

1 2 3 4 5 6 7 8
        
Form-VIISanctions RegisterRegister of Administrative and Technical Sanctions and Payments
Sl.NoDetails
of worksAdministrative
SanctionTechnical
sanction by
competent
AuthoritiesDate of
CommencementPeriod/
Target Date
of
CompletionFinancial
DetailsCompleted
WorkDetails of
Inspection of
works/Remarks
M.C.
Resolution
No. & DateEstimate
ValueDate of
SanctionDate /
Amount 1st
Advance
paymentDate / Amount
Subsequent
paymentDateFinal
value of
work/
Payment
1 2 3 4 5 6 7 8 9 10111213
             
Form - VIIICash Book
Cash Register : -  
Recepts Payments
Cash Book of_____________ Water
Users'Associations_____________Village_____________Mandal,______________Districtfor
the Month of__________
{|
Date No. of Receipts Particulars of Receipt Opening Balance Amount Remarks
1 2 3 4 5 6
      
|
Date Voucher No Particulars of Payment Payment by Cheque No. Remarks
Cash cheque
1 2 3 4 5 6 7
       
|}Form - IXSpecial Fee / Tax Collection Register
Sl.NoDetails of
ResolutionCollected
FromLevy
AmountAmount
PaidDueCash Book
referenceRemarks
Date Sl.No
1 2 3 4 5 6 7 8 9
         
Form-XAgenda
Date Item No.
1 2
  
Form - X.AMinutes Register
Date Agenda Item No. Discussions and ResolutionsA.P. Farmers Organisation Rules, 1997

1 2 3
   
Form -XI[See Rule 27(1) of A.P. Farmers Organization Rules]Prelimenary Offences Report(Under
Section 23 of APFMIS Act 1997)
1.Name and address of the person(s)who committedoffence :
2.Nature of offence :
3.Place where offence occurred :
4.Estimated value of the damage caused by offence :
5.Name and address of the witness :
Signature of the witnessSignature of the accused.Signature of the Competent AuthorityForm
-XII[See rule 27(5) of A.P. Farmers Organization Rules]Composition Form(under Section 25 of
APFMIS Act 1997)
1Name and address of the person(s)who committed offence :
2Nature of offence :
3Place where offence occurred :
4Estimated value of the damage caused by offence :
5Whether notice served to the accused givingopportunity (i.e., within 7 days) to explain his point
of view,if so the date and time.:
6Whether explanation of the accused received :
7Decision of the Competent Authority :
8Whether offence proved beyond doubt, if so thedetails :
9Fine imposed by the Deputy Exective Engineer /Recommended to the next higher for
prosecution.:
Signature of Deputy Executive Engineer[See Rule 27(8)]Proceedings of The Executive
Engineer,.......................Proc. No............Dated. ..............Sub: -Ref: -Order:The Competent Authority
(Assistant Executive Engineer) and (Deputy Executive Engineer) have submitted the preliminary
offence report / fine imposed report for the damages caused by the accused and recommended for
prosecution under the provisions of the Act.Under Section 24 of the APFMIS Act, 1997 (Act 11 of
1997) and Sub-rule 7 of Rule 27 of Andhra Pradesh Farmers Organization Rule, 1997, the accused is
punishable under penal provisions of the Act. In the circumstances explained by the Competent
Authority (Deputy Executive Engineer) in the reference cited the following accused are hereby
ordered to be prosecuted.
1. Sri./Smt....................
2. ....................
3. ....................
The Dy. E.E. is requested to file the charge sheet in the Hon,ble Judicial first class Magistrate Court,
.................... immediately and report compliance.Executive Engineer,........................ToThe Dy.A.P. Farmers Organisation Rules, 1997

Executive Engineer,........................Sub-Division..................Village.A.P. Farmers Organisation Rules, 1997

