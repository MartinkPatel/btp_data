A.Lilly vs The State Of Tamil Nadu on 30 October, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                             HCP(MD)No.1182 of 2023
                          BEFORE THE MADURAI BENCH OF MADRAS HIGH COURT
                                                     DATED : 30.10.2023
                                                          CORAM :
                                     THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                    and
                                    THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                   HCP(MD)No.1182 of 2023
                     A.Lilly                                                    ... Petitioner
                                                              vs.
                     1. The State of Tamil Nadu,
                        Rep. by Secretary to Government,
                        Home, Prohibition and Excise Department,
                        Secretariat, Chennai – 600 009.
                     2. The District Collector and District Magistrate,
                        Kanniyakumari District, Nagercoil.
                     3. The Superintendent,
                        Central Prison, Palayamkottai,
                        Tirunelveli.                                            ... Respondents
                            Petition filed under Article 226 of the Constitution of India praying
                     for issuance of a Writ of Habeas Corpus, calling for the entire records,
                     connected with the detention order of the respondent No.2 in P.D.No.28
                     of 2023 dated 14.05.2023 and quash the same and direct the respondents
                     to produce the body or person of the detenu, namely petitioner's son i.e.,
                     Jegan son of Achuthan aged about 36 years now detained at Central
                     Prison, Palayamkottai before this Court and set him at liberty forthwith.
                                  For Petitioner     : Mr.N.Pragalathan
                                  For Respondents : Mr.A.Thiruvadi Kumar
                                                        Additional Public Prosecutor
https://www.mhc.tn.gov.in/judis
                     Page No.1 of 9A.Lilly vs The State Of Tamil Nadu on 30 October, 2023

                                                                                  HCP(MD)No.1182 of 2023
                                                          ORDER
[Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus Petition'
[hereinafter 'HCP' for the sake of brevity] was listed in the Admission Board on 26.09.2023, a
Hon'ble Coordinate Division Bench made the following order in the Admission Board:
2. It has now become necessary to set out a thumbnail sketch of factual matrix and we
do so in the paragraphs infra.
3. Today, the captioned matter is in the Final Hearing Board.
https://www.mhc.tn.gov.in/judis
4. Mr.N.Pragalathan, learned counsel on record for petitioner and Mr.A.Thiruvadi Kumar, learned
State Additional Public Prosecutor for all respondents are before us.
5. Captioned 'Habeas Corpus Petition' [hereinafter 'HCP' for the sake of convenience and clarity] has
been filed by the mother of the detenu assailing the 'preventive detention order dated 14.05.2023
bearing reference in P.D.No.28 of 2023' [hereinafter 'impugned preventive detention order' for the
sake of brevity and convenience]. To be noted, sponsoring authority has not been arrayed as a
respondent and we find that Station House Officer of Kulasekaram Police Station, is the sponsoring
authority [hereinafter 'sponsoring authority' for convenience and brevity] and second respondent is
the detaining authority as impugned preventive detention order has been made by second
respondent.
6. Impugned detention order has been made under 'The Tamil Nadu Prevention of Dangerous
Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-offenders, Goondas, Immoral
traffic offenders, Sand-offenders, Sexual-offenders, Slum-grabbers and Video
https://www.mhc.tn.gov.in/judis Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' [hereinafter
'Act 14 of 1982' for the sake of convenience and clarity] on the premise that the detenu is a 'Goonda'
within the meaning of Section 2(f) of Act 14 of 1982.
7. There are four adverse cases and one ground case. The ground case which constitutes substantial
part of substratum of the impugned preventive detention order is Crime No.53 of 2023 on the file of
Kulasekaram Police Station, for alleged offences under Sections 294(b), 397 and 506(ii) of 'Indian
Penal Code, 1860 (Act 45 of 1860)' ['IPC' for brevity]. Considering the nature of the challenge to the
impugned detention order, it is not necessary to delve into the factual matrix of the case.
8. In the final hearing today, learned counsel predicated his campaign against the impugned
preventive detention order on the point that the detenu was arrested on 23.03.2023 but theA.Lilly vs The State Of Tamil Nadu on 30 October, 2023

impugned preventive detention order has been made only on 14.05.2023 resulting in live and
proximate link between grounds and purpose of detention getting snapped.
https://www.mhc.tn.gov.in/judis
9. Mr.Thiruvadi Kumar, learned State Additional Public Prosecutor, submits that materials had to
be collected and time was consumed in this exercise.
10. We remind ourselves of Sushanta Kumar Banik's case [Sushanta Kumar Banik Vs. State of
Tripura & others reported in 2022 LiveLaw (SC) 813 : 2022 SCC OnLine SC 1333]. To be noted,
Banik case arose under 'Prevention of Illicit Traffic in Narcotic Drugs and Psychotropic Substances
Act, 1988' [hereinafter 'PIT NDPS Act' for the sake of brevity] in Tirupura, wherein after considering
a proposal by a Sponsoring Authority and after noticing the trajectory the matter took, Hon'ble
Supreme Court held that the 'live and proximate link between grounds of detention and purpose of
detention snapping' point should be examined on a case to case basis. Hon'ble Supreme Court has
held in Banik case law that this point has two facets. One facet is 'unreasonable delay' and the other
facet is 'unexplained delay'. We find that the captioned matter falls under latter facet i.e.,
unexplained delay. https://www.mhc.tn.gov.in/judis
11. To be noted, Banik case has been respectfully followed by this Court in Gomathi Vs.The Principal
Secretary to Government and others reported vide Neutral Citation of Madras High Court being
2023/MHC/334, Sadik Basha Yusuf Vs. The State of Tamil Nadu and others reported vide Neutral
Citation of Madras High Court being 2023/MHC/733, Sangeetha Vs. The Secretary to the
Government and others reported vide Neutral Citation of Madras High Court being
2023:MHC:1110, N.Anitha Vs. The Secretary to Government and others reported vide Neutral
Citation of Madras High Court being 2023:MHC:1159 and a series of similar orders in HCP cases.
12. To be noted, the first adverse case is in Crime No.434 of 2021 on the file of Kulasekaram Police
Station for alleged offences under Sections 457 and 380 of IPC [alleged occurrence on 03.12.2021],
second adverse case is Crime No.07 of 2023 on the file of Kulasekaram Police Station for alleged
offences under Sections 457 and 380 of IPC [alleged occurrence on 16.01.2023], third adverse case
is Crime No.35 of 2023 on the file of Kulasekaram Police Station for alleged offences under Sections
457 and 380 of IPC [alleged occurrence on 02.03.2023]; fourth adverse case is Crime No.40 of 2023
on the file of Kulasekaram Police https://www.mhc.tn.gov.in/judis Station for alleged offences
under Section 379 of IPC [alleged occurrence on 06.03.2023], ground case is Crime No.53 of 2023
on the file of Kulasekaram Police Station, for alleged offences under Sections 294(b), 397 and
506(ii) of IPC [alleged occurrence on 22.03.2023]. There are four adverse cases. One of the year
2021 and therefore that pales into insignificance or in other words, that has become stale as regards
the impugned preventive detention order is concerned. The other three adverse cases are of the year
2023 but there is no disputation or contestation before us that arrest of the detenu on 22.03.2023
was in adverse cases 2, 3 and 4 and the ground case. Therefore, we are convinced that time
consumed remains unexplained owing to which the live and proximate link between grounds of
detention and purpose of detention has snapped in the case on hand.A.Lilly vs The State Of Tamil Nadu on 30 October, 2023

13. Before concluding, we also remind ourselves that preventive detention is not a punishment and
HCP is a high prerogative writ.
14. Ergo, the sequitur is, captioned HCP is allowed. Impugned preventive detention order dated
14.05.2023 bearing reference in P.D.No. 28 of 2023 made by the second respondent is set aside and
the detenu https://www.mhc.tn.gov.in/judis Thiru.Jegan, aged about 36 years, son of
Thiru.Achuthan, is directed to be set at liberty forthwith, if not required in connection with any
other case / cases. There shall be no order as to costs.
                                                                    (M.S., J.)   (R.S.V., J.)
                     Index               : Yes                            30.10.2023
                     Neutral Citation    : Yes
                     PKN
P.S: Registry to forthwith communicate this order to Jail authorities in Central Prison,
Palayamkottai.
To
1. The Secretary to Government, Home, Prohibition and Excise Department, Fort St.George,
Chennai – 600 009.
2. The District Collector and District Magistrate, Kanniyakumari District, Nagercoil.
3. The Superintendent, Central Prison, Palayamkottai, Tirunelveli.
4. The Additional Public Prosecutor, Madurai Bench of Madras High Court, Madurai.
5. The Joint Secretary to Government, Public (Law and Order) Department, Secretariat, Chennai.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J.
and R.SAKTHIVEL, J.
PKN ORDER MADE IN DATED : 30.10.2023 https://www.mhc.tn.gov.in/judisA.Lilly vs The State Of Tamil Nadu on 30 October, 2023

