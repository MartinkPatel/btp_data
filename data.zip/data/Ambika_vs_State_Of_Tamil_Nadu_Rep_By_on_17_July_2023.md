Ambika vs State Of Tamil Nadu Rep. By on 17 July, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                                       H.C.P.No.88 of 2023
                                    IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                      DATED: 17.07.2023
                                                             Coram
                                      THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                     and
                                     THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                      H.C.P.No.88 of 2023
                     Ambika                                                               .. Petitioner
                                                                vs
                     1.State of Tamil Nadu Rep. By
                       The Additional Chief Secretary to Government,
                       Home, Prohibition and Excise Department,
                       Fort St.George, Chennai – 600 009.
                     2.The Commissioner of Police
                       The Greater Chennai City
                       Vepery, Chennai – 600 007
                     3. The Superintendent of Prison
                        Central Prison, Puzhal, Chennai – 600 066
                     4. The Inspector of Police
                        P-1, Pulianthope Police Station
                        Chennai                                            .. Respondents
                                  Petition filed under Article 226 of the Constitution of India praying
                     for issuance of a writ of habeas corpus calling for the records relating to
                     the detention order in Memo No.437/BCDFGISSSV/2022, dated
                     25.11.2022 passed by the second respondent under the Tamilnadu Act 14
https://www.mhc.tn.gov.in/judis
                     1/9
                                                                                     H.C.P.No.88 of 2023
                     of 1982 and set aside the same and direct the respondents to produce theAmbika vs State Of Tamil Nadu Rep. By on 17 July, 2023

                     pet's nephew Marimuthu, son of Devaraj, aged about 35 years, the
                     detenu, now confined in Central Prison, Puzhal,Chennai before this Court
                     and set him at liberty.
                                  For Petitioner            :     Mr.S.Senthilvel
                                                                  for Mr.C.Johnson Samuel
                                  For Respondents           :     Mr.E.Raj Thilak,
                                                                  Additional Public Prosecutor
                                                            ORDER
[Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus Petition'
[hereinafter 'HCP' for the sake of convenience and clarity] was listed in the Admission Board on
23.01.2023, this Court made the following order:
' Captioned Habeas Corpus Petition has been filed in this Court on 10.01.2023 inter
alia assailing a detention order dated 25.11.2022 bearing reference
No.437/BCDFGISSSV/2022 made by 'second respondent' [hereinafter 'Detaining
Authority' for the sake of convenience and clarity]. To be noted, fourth respondent is
the Sponsoring Authority.
2. Aunt of the detenu is the petitioner.
https://www.mhc.tn.gov.in/judis
3. Mr.C.Johnson Samuel, learned counsel on record for habeas corpus petitioner is before us.
Learned counsel for petitioner submits that ground case qua the detenu is for alleged offences under
Sections 147, 148, 324, 307 and 506(ii) of IPC in Crime No.616 of 2022 on the file of P-1 Pulianthope
Police Station.
4. The aforementioned detention order has been made on the premise that the detenu is a 'Goonda'
under Section 2(f) of 'The Tamil Nadu Prevention of Dangerous Activities of Bootleggers, Cyber law
offenders, Drug-offenders, Forest-offenders, Goondas, Immoral traffic offenders, Sand-offenders,
Sexual- offenders, Slum-grabbers and Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)'
[hereinafter 'Act 14 of 1982' for the sake of convenience and clarity].
5. The detention order has been assailed inter alia on the grounds that similar order relied on by the
Detaining Authority belongs to some other accused and similar case materials were not properly
furnished to the detenue.
6. Prima facie case made out for admission. Admit. Issue Rule Nisi returnable in four weeks.
7. Mr.R.Muniyapparaj, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice for
all https://www.mhc.tn.gov.in/judis respondents. List the captioned Habeas Corpus PetitionAmbika vs State Of Tamil Nadu Rep. By on 17 July, 2023

accordingly.'
2. The aforementioned order made in the 23.01.2023 Admission listing shall be read as an integral
part and parcel of this order which means that the short forms, short references and abbreviations
used in the order in the Admission listing shall be used in the instant order also.
3. There is one adverse case and one ground case. The ground case which constitutes substantial
part of substratum of the impugned preventive detention order is Crime No.616 of 2022 on the file
of P1 Pulianthope Police Station for alleged offences under Sections 147, 148, 324, 307 and 506(ii) of
IPC. Owing to the nature of the challenge to the impugned preventive detention order, it is not
necessary to delve into the factual matrix or be detained further by facts.
4. Mr.S.Senthilvel, learned counsel representing the counsel on record for petitioner and Mr.E.Raj
Thilak, learned State Additional Public Prosecutor for all respondents are before us.
5. Learned counsel for petitioner submits that 'live and proximate link' between the grounds of
detention and purpose of detention has snapped as date of remand in the ground case is 21.10.2022
but the https://www.mhc.tn.gov.in/judis impugned detention order has been made only on
25.11.2022.
6. Mr.E.Raj Thilak, learned State Additional Public Prosecutor, submits to the contrary by saying
that materials had to be collected and time was consumed for the same. Considering the facts and
circumstances of the case and nature of ground case, we find that this explanation of learned State
Additional Public Prosecutor is unacceptable.
7. We remind ourselves of Sushanta Kumar Banik's case [Sushanta Kumar Banik Vs. State of
Tripura & others reported in 2022 LiveLaw (SC) 813 : 2022 SCC OnLine SC 1333]. To be noted,
Banik case law arose under 'Prevention of Illicit Traffic in Narcotic Drugs and Psychotropic
Substances Act, 1988' [hereinafter 'PIT NDPS Act' for the sake of brevity] in Tirupura, wherein after
considering the proposal by the Sponsoring Authority and after noticing the trajectory the matter
took, Hon'ble Supreme Court held that the 'live and proximate link between grounds of detention
and purpose of detention snapping' point should be examined on a case to case basis. Hon'ble
Supreme Court has held in Banik case law that this point has two facets. One facet is 'unreasonable
delay' and other facet is 'unexplained delay'. We find that the captioned
https://www.mhc.tn.gov.in/judis matter falls under latter facet i.e., unexplained delay.
8. To be noted, Banik case has been respectfully followed by this Court in Gomathi Vs.The Principal
Secretary to Government and others reported vide Neutral Citation of Madras High Court being
2023/MHC/334, Sadik Basha Yusuf Vs. The State of Tamil Nadu and others reported vide Neutral
Citation of Madras High Court being 2023/MHC/733, Sangeetha Vs. The Secretary to the
Government and others reported vide Neutral Citation of Madras High Court being
2023:MHC:1110, N.Anitha Vs. The Secretary to Government and others reported vide Neutral
Citation of Madras High Court being 2023:MHC:1159 and a series of other orders in HCP cases.Ambika vs State Of Tamil Nadu Rep. By on 17 July, 2023

9.To be noted, one adverse case viz., Crime No.261 of 2021 on the file of P1, Pulianthope Police
Station for alleged offences inter-alia under Section 379 read with Section 34 of IPC is of the year
2021 and therefore, time consumed remains unexplained.
10. Before concluding, we also remind ourselves that preventive https://www.mhc.tn.gov.in/judis
detention is not a punishment and HCP is a high prerogative writ.
11. Ergo, the sequitur is, captioned HCP is allowed. Impugned detention order dated 25.11.2022
bearing reference No.437/BCDFGISSSV/2022 made by the second respondent is set aside and the
detenu Thiru.Marimuthu, aged 35 years, son of Thiru.Devaraj, is directed to be set at liberty
forthwith, if not required in connection with any other case / cases. There shall be no order as to
costs.
(M.S.,J.) (R.S.V.,J.) 17.07.2023 Index : Yes Neutral Citation : Yes gpa P.S: Registry to forthwith
communicate this order to Jail authorities in Central Prison, Puzhal.
To
1. The Additional Chief Secretary to Government, Home, Prohibition and Excise Department, Fort
St.George, Chennai – 600 009.
2.The Commissioner of Police The Greater Chennai City Vepery, Chennai – 600 007
3. The Superintendent of Prison Central Prison, Puzhal, Chennai – 600 066
4. The Inspector of Police https://www.mhc.tn.gov.in/judis P-1, Pulianthope Police Station Chennai
5.The Public Prosecutor, High Court, Madras.
M.SUNDAR, J., and R.SAKTHIVEL , J., gpa 17.07.2023 https://www.mhc.tn.gov.in/judis
https://www.mhc.tn.gov.in/judisAmbika vs State Of Tamil Nadu Rep. By on 17 July, 2023

