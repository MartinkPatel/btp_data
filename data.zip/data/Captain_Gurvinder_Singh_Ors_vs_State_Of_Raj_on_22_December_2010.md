Captain Gurvinder Singh &Ors vs State Of Raj on 22 December,
2010
Author: Arun Mishra
Bench: Arun Mishra
 1.     D.B.Civil Writ Petition No.13491/2009
        Captin Gurvinder Singh & ors.   
                        V/s
        State of Rajasthan
2.      D.B.Civil Writ Petition No.12810/2009
        G.Sharma        
                V/s
        State of Rajasthan
3.      D.B.Civil Writ Petition No.13884/2009
        All India Equality Forum        
                        V/s
        State of Rajasthan & anr.
22.12.2010
Hon'ble the Chief Justice Mr.Arun Mishra
Hon'ble Mr.Justice Mahesh Bhagwati
Mr.S.P.Sharma           )
Mr.Shobhit Tiwari       )-for the petitioners.
Mr.Sandeep Singh        )
Mr.P.P.Rao, Senior Counsel       )
Mr.G.S.Bapna, Advocate General )
Mr.V.Garg                                        )
Mr.Sarvesh Jain                  )-for respondents.
Mr.Praveen Poswal for            )
Mr.V.S.Gurjar                            )      
Mr.R.R.Baisla                            )      
ReportableCaptain Gurvinder Singh &Ors vs State Of Raj on 22 December, 2010

These writ petitions have been filed by the petitioners assailing the vires of Rajasthan Scheduled
Castes, Scheduled Tribes, Backward Classes, Special Backward Classes and Economically Backward
Classes (Reservation of Seats in Educational Institutions in the State and of Appointments and Posts
in Services under the State) Act, 2008 (hereinafter referred to as the Act of 2008). Prayer has also
been made to direct the State Government to review the ceiling limit of reservation in favour of SC,
ST and OBC of 16%, 12% and 21% respectively.
Facts are being noticed from Civil Writ Petition No.13491/2009 wherein the petitioner no.4-Samta
Andolan, which is a registered society, has submitted that constitutional intent is to reduce the
reservation. It is submitted that the foremost requirement for reservation is to collect quantifiable
data in overall State relating to the population as well as relating to economical standard of the caste
in general and people in that caste in particular. After having collected such datas and further
making a comparative statement with respect to other castes in the State only for the purposes of
providing upliftment of particular class or caste, reservation can be provided. 100 point roster is
being applied and reservation has been increased. The Act of 2008 has been published in the
Rajasthan Gazette on 31st July, 2009 under which various castes including Gurjars and Rebaries
have been included in the SC/ST, OBC, Special Backward Classes (SBC) and Economically Backward
Classes (ECB). While enacting the aforesaid Act of 2008, the State has not relied upon any census
conducted in this regard and no exercise at the level of the State was ever done to ascertain whether
any particular caste is actually socially backward or not. The petitioners sought information under
the Right to Information Act which indicates that no such study has been undertaken by the State
Government. It is further averred that so far as Gurjars and Rebaries are concerned, they were
included in Other Backward Classes. However, due to political stir, the State Government without
examining the issue, came up with the Notification dated 31st July, 2009 notifying the Act of 2008.
Now, reservation of seats in educational institutions in the State has been provided to the extent of
68% to SC, ST, OBC, SBC and EBC. 16% for Scheduled Castes, 12% for Scheduled Tribes, 21% for
Backward Classes, 5% for Special Backward Classes and 14% for Economically Backward Classes
with the rider that persons belonging to the creamy layer shall not be eligible for consideration
against the reserved quota of seats in any educational institution in the State. However, provision of
creamy layer shall not be applicable to the reservation for the Scheduled Castes and Scheduled
Tribes. The aforesaid reservation in service has been provided vide section 4 of the Act of 2008. As
per mandate of the Supreme Court in M.Nagaraj & ors. V/s Union of India and ors.
((2006) 8 SCC 212), no quantifiable datas are being collected of various castes or so called backward
classes in the State of Rajasthan. In-fact, there was no need for giving any further reservation as by
efflux of time, there is upliftment of the persons belonging to backward classes. The petitioners have
applied for furnishing certain datas, but that has not been furnished. However, whatever datas,
which have been furnished, indicate that State has no reliable and up-to-date datas regarding
representation of the different class or caste in the public employment. Adequate representation
does not mean proportionate representation. With the passage of time, most of the tribal population
have lost their tribal character and does not fulfil the criteria laid down by the Apex Court for
providing reservation. All tribal groups have been represented in public employment not only
adequately but more than proportionately.Captain Gurvinder Singh &Ors vs State Of Raj on 22 December, 2010

The State Government has also issued Notification dated 25.8.2009 in exercise of the power
conferred under section 2(b) of the Act of 2008 and has increased the ceiling financial limit for
creamy layer from 2.5 lacs to 4.5 lacs. The aforesaid notification is not constitutionally valid as it
would not be possible to percolate down the benefit to the needy. The Act is incompatible with the
constitutional intentment and is against the mandate of Indra Sawhney V/s Union of India (1992
Supp (3) SCC 217). The validity of 77th, 81st and 85th Amendment was challenged before the
Supreme Court in M.Nagaraj's case (supra) and the Apex Court has enumerated the essential
criteria that study has to be done for providing reservation. The Apex Court has made it clear that
creamy layer is required to be excluded from SC/ST apart from OBC otherwise it would be against
the mandate of Article 16(1) of the Constitution. The gap between BPL and ceiling limit of creamy
layer is huge. The State ought to have made endeavour to reduce reservation and it has acted
contrary to the intentment of the Constitution by enhancing reservation upto 68%.
In the return filed by the State Government, it is contended that the State of Rajasthan has
separated Gurjar community from Other Backward Classes and had separately given 5% reservation
to Gurjars, Gadia Lohars, Banjaras and Raikas as Special Backward Classes (SBC). Under the Act of
2008, provision for reservation to the extent of 14% for Economically Backward Classes (EBC) had
been made. Due to the aforesaid provision, reservation has exceeded to the extent of 68%. Gurjar
community has been held as most backward caste/class by the Backward Class Commission headed
by Kaka Kalekar. Other cognate communities are not adequately represented in the services of the
State. The Committee headed by Justice J.R.Chopra was appointed looking to the demand of
Gurjars to grant them status as Scheduled Tribe. The Commission has found that Gurjars are
inadequately represented in the services of the State and they are socially and educationally
backward. Gurjars, Gadia Lohars, Banjaras and Raikas are the communities, which are dependent
upon villiage commons for their livelihood. They are also being nomadic communities at times.
Considering the report of the Committee, positive and proactive action has been taken by the State.
A case had been made out to exceed reservation beyond 50% considering the peculiar situation. The
Act of 2008 has been enacted with a view to uplift Gurjars, Gadia Lohars, Banjaras and Raikas.
Mandate of Indra Sawhney (supra) and M.Nagaraj (supra) has not been violated. The Committee
employed the following criteria for identifying the special backward class:-
(i) Low social position in the traditional caste hierarchy.
(ii) General educational advancement among the major section of caste/community.
(iii) Inadequate representation in government service.
(iv) Inadequate representation in the field of trade, commerce and industry.
In Chapter-V of the report, the Committee examined the status of the Gurjars. The petitions cannot
be said to be maintainable. The action is intended to bring equality. The petitions being meritless
deserve dismissal.Captain Gurvinder Singh &Ors vs State Of Raj on 22 December, 2010

Rejoinder has been filed by the petitioners pointing out that in Rajasthan, no Committee has been
formed and Kaka Kalekar Commission was a Commission for All India and there was no
commission specifically for the State of Rajasthan. Datas have not been collected for increasing the
extent of reservation. Increase in reservation is politically motivated. Reliance has also been placed
on the decision of the Apex Court in Suraj Bhan Meena & Anr. V/s State of Rajasthan & ors. (Special
Leave Petition (Civil) No.6385 of 2010 decided on 7.12.2010) in which decision in the case of
M.Nagaraj (supra) was relied upon and the judgment of this Court quashing Notifications dated
28.12.2002 and 25.4.2008 issued by the State of Rajasthan was upheld on the ground that no
exercise was undertaken in terms of Article 16(4-A) to acquire quantifiable data regarding the
inadequacy of representation of the Scheduled Castes and Scheduled Tribes communities in public
services. The point of reference to Chopra Committee is whether Gurjars should be included in ST
category with which Chopra Committee did not agree. Thus, no study was undertaken by Chopra
Committee with respect to Gurjar belonging to Special Backward Classes particularly when Gurjars
were already covered under the category of OBC. There was no rhyme or reason to provide them
special status by including them in Special Backward Classes without undertaking requisite study.
Mr.S.P.Sharma, Mr.Shobhit Tiwari amd Mr.Sandeep Singh, learned counsel appearing on behalf of
the petitioners have submitted that the provisions of Sections 3 and 4 of the Act of 2008 are illegal
and arbitrary, inasmuch as, reservation has been enhanced upto 68% without undertaking requisite
study and collecting quantifiable datas and without considering the criteria laid down by the Apex
Court in M.Nagaraj's case (supra). The Act of 2008 could not have been enacted without
undertaking any study. Notification has also been issued with respect to enhancement of financial
limit of creamy layer in the Other Backward Classes from 2.5 lacs to 4.5 lacs. The effect of
notification would be detrimental even to the Other backward classes and benefit is going to be
usurp by higher income group. There was no rhyme or reason behind increasing the income from
2.5 lacs to 4.5 lacs for being creamy layer. Reliance has also been placed on the decision of the Apex
Court in the case of S.V.Joshi & ors.V/s State of Karnataka & ors.
(Writ Petition (Civil) No.259 of 1994 decided on 13th July, 2010). In any case, the reservation could
not have been exceeded 50% and efforts should have been made to reduce it by undergoing requisite
study. Gurjars are already included in the Other Backward Classes and Chopra Committee has
opined that they could not have been treated as Members of ST category, there was no reason for
creating Special Backward Class for Gurjars, Gadia Lohars, Banjaras and Raikas. Point of reference
to Chopra Committee was not for creating Special Backward Class, no such category could have been
created. The reservation which has been provided to the Economically Backward Classes (EBC) and
to the extent of 14% is also impermissible and suffers from the same vice and is clearly hit by the
decisions of the Apex Court in the cases of M.Nagaraj (supra), Indra Sawhney (supra) and Ashoka
Kumar Thakur V/s Union of India and ors. ((2008) 6 SCC 1).
Mr.P.P.Rao, learned Senior Counsel appearing with Mr.G.S.Bapna, Advocate General on behalf of
the State submitted that the Act of 2008 has been enacted considering the down-trodden status of
Gurjars, Gadia Lohars, Banjaras and Raikas and in order to bring about equality and duly
considering the representation in the State services and taking into account the report of the Chopra
Committee, though the point referred to Chopra Committee was with respect to whether GurjarsCaptain Gurvinder Singh &Ors vs State Of Raj on 22 December, 2010

could be treated as tribal persons for inclusion in Scheduled Tribes, but observations have been
made in report that Gurjars are most backward class. It is further submitted that in the case of
S.V.Joshi (supra), the Apex Court has only directed to collect quantifiable data, but the Act has not
been struck down. In case this Court directs further quantifiable datas to be collected, they are ready
to do so. However, their action is justified in the prevailing backwardness of the aforesaid
castes-Gurjars, Gadia Lohars, Banjaras and Raikas.
After hearing the learned counsel for the parties at length and after going through the materials
placed on record, it could not be disputed that there is a need to identify and collect quantifiable
data showing backwardness of the class and inadequacy of representation of that class in the public
employment, keeping in mind maintenance of efficiency in administration. Reservation has to be
decided on facts of each case. In the instant case, it could not be disputed at bar that the State has
not undertaken any study nor collected quantifiable datas before enhancing reservation upto 68%.
Thus, the Act of 2008, which has been enacted so as to enhance the reservation upto 68% could not
be said to be justified.
The Apex Court in the case of Suraj Bhan (supra) has observed:-
44. The vital issue which fell for determination was whether by virtue of the
implementation of the Constitutional Amendments, the power of Parliament was
enlarged to such an extent so as to ignore all constitutional limitations and
requirements. Applying the "width" test and "identity" test, the Constitution Bench
held that firstly it is the width of the power under the impugned amendments
introducing amended Articles 16(4-A) and 16(4-B) that had to be tested. Applying the
said tests, the Constitution Bench, after referring to the various decisions of this
Court on the subject, came to the conclusion that the Court has to be satisfied that the
State had exercised its power in making reservation for Scheduled Castes and
Scheduled Tribes candidates in accordance with the mandate of Article 335 of the
Constitution, for which the State concerned would have to place before the Court the
requisite quantifiable data in each case and to satisfy the Court that such reservation
became necessary on account of inadequacy of representation of Scheduled Castes
and Scheduled Tribes candidates in a particular class or classes of posts, without
affecting the general efficiency of service. The Constitution Bench went on to observe
that the Constitutional equality is inherent in the rule of law. However, it's reach is
limited because its primary concern is not with efficiency of the public law, but with
its enforcement and application. The Constitution Bench also observed that the width
of the power and the power to amend together with its limitations, would have to be
found in the Constitution itself. It was held that the extension of reservation would
depend on the facts of each case. In case the reservation was excessive, it would have
to be struck down. It was further held that the impugned Constitution Amendments,
introducing Article 16(4-A) and 16(4-B), had been inserted and flow from Article
16(4), but they do not alter the structure of Article 16(4) of the Constitution. They do
not wipe out any of the Constitutional requirements such as ceiling limit and the
concept of creamy layer on one hand and Scheduled Castes and Scheduled Tribes onCaptain Gurvinder Singh &Ors vs State Of Raj on 22 December, 2010

the other hand, as was held in Indra Sawhney's case (supra). Ultimately, after the
entire exercise, the Constitution Bench held that the State is not bound to make
reservation for Scheduled Castes and Scheduled Tribes candidates in matters of
promotion but if it wished, it could collect quantifiable data touching backwardness
of the applicants and inadequacy of representation of that class in public employment
for the purpose of compliance with Article 335 of the Constitution.
45. In effect, what has been decided in M.Nagaraj's case (supra) is part recognition of
the views expressed in Virpal Singh Chauhan's case (supra), but at the same time
upholding the validity of the 77th, 81st, 82nd and 85th amendments on the ground
that the concepts of "catch-up" rule and "consequential seniority" are judicially
evolved concepts and could not be elevated to the status of a constitutional principle
so as to place them beyond the amending power of the Parliament. Accordingly, while
upholding the validity of the said amendments, the Constitution Bench added that, in
any event, the requirement of Articles 16(4-A) and 16(4-B) would have to be
maintained and that in order to provide for reservation, if at all, the tests indicated in
Article 16(4-A) and 16(4-B) would have to be satisfied, which could only be achieved
after an inquiry as to identity.
46. The position after the decision in M. Nagaraj's case (supra) is that reservation of
posts in promotion is dependent on the inadequacy of representation of members of
the Scheduled Castes and Scheduled Tribes and Backward Classes and subject to the
condition of ascertaining as to whether such reservation was at all required. The view
of the High Court is based on the decision in M.Nagaraj's case (supra) as no exercise
was undertaken in terms of Article 16(4-A) to acquire quantifiable data regarding the
inadequacy of representation of the Schedule Castes and Scheduled Tribes
communities in public services. The Rajasthan High Court has rightly quashed the
notifications dated 28.12.2002 and 25.4.2008 issued by the State of Rajasthan
providing for consequential seniority and promotion to the members of the
Scheduled Castes and Scheduled Tribes communities and the same does not call for
any interference. Accordingly, the claim of Petitioners Suraj Bhan Meena and Sriram
Choradia in Special Leave Petition (Civil) No.6385 of 2010 will be subject to the
conditions laid down in M.Nagaraj's case (supra) and is disposed of accordingly.
Consequently, Special Leave Petition(C)Nos.7716, 7717, 7826 and 7838 of 2010, filed
by the State of Rajasthan, are also dismissed.
Reliance has been placed by the Apex Court on the decision in M.Nagaraj (supra) to hold that such
study and collection of quantifiable data is necessary before making provision for reservation in the
matter of providing accelerated promotion also.
In M.Nagaraj (supra), the Apex Court has laid down the extent of reservation thus:
55. Word of caution against excess reservation was first pointed out in G.M., S.Rly v.
Rangachari, Gajendragadkar, J. giving the majority judgment said that reservationCaptain Gurvinder Singh &Ors vs State Of Raj on 22 December, 2010

under Article 16(4) is intended merely to give adequate representation to backward
communities. It cannot be used for creating monopolies or for unduly or
illegitimately disturbing the legitimate interests of other employees. A reasonable
balance must be struck between the claims of backward classes and claims of other
employees as well as the requirement of efficiency of administration.
56. However, the question of extent of reservation was not directly involved in
Rangachari. It was directly involved in M.R. Balaji v. State of Mysore with reference
to Article 15(4). In this case, 60% reservation under Article 15(4) was struck down as
excessive and unconstitutional. Gajendragadkar, J. observed that special provision
should be less than 50 per cent, how much less would depend on the relevant
prevailing circumstances of each case.
57. But in State of Kerala v. N.M. Thomas Krishna Iyer, J. expressed his concurrence
with the views of Fazal Ali, J. who said that although reservation cannot be so
excessive as to destroy the principle of equality of opportunity under clause (1) of
Article 16, yet it should be noted that the Constitution itself does not put any bar on
the power of the Government under Article 16(4). If a State has 80% population
which is backward then it would be meaningless to say that reservation should not
cross 50%.
58. However, in Indra Sawhney the majority held that the rule of 50% laid down in
Balaji was a binding rule and not a mere rule of prudence.
59. Giving the judgment of the Court in Indra Sawhney, Jeevan Reddy, J. stated that
Article 16(4) speaks of adequate representation not proportionate representation
although proportion of population of backward classes to the total population would
certainly be relevant. He further pointed out that Article 16(4) which protects
interests of certain sections of society has to be balanced against Article 16(1) which
protects the interests of every citizen of the entire society. They should be
harmonised because they are restatements of the principle of equality under Article
14. (emphasis added).
With respect to study necessary for reservation, the Apex Court has laid down that
there is a need of maintenance of efficiency in administration and there are
numerous factors which have to be considered and Chopra Committee has not gone
into all these aspects. The Apex Court held thus:
46.The point which we are emphasizing is that ultimately the present controversy is
regarding the exercise of the power by the State Government depending upon the
fact-situation in each case. Therefore, 'vesting of the power' by an enabling provision
may be constitutionally valid and yet 'exercise of the power' by the State in a given
case may be arbitrary, particularly, if the State fails to identify and measure
backwardness and inadequacy keeping in mind the efficiency of service as requiredCaptain Gurvinder Singh &Ors vs State Of Raj on 22 December, 2010

under Article 335.
107.It is important to bear in mind the nature of constitutional amendments. They
are curative by nature. Article 16(4) provides for reservation for backward classes in
cases of inadequate representation in public employment. Article 16(4) is enacted as
a remedy for the past historical discriminations against a social class. The object in
enacting the enabling provisions like Articles 16(4), 16(4A) and 16(4B) is that the
State is empowered to identify and recognize the compelling interests. If the State has
quantifiable data to show backwardness and inadequacy then the State can make
reservations in promotions keeping in mind maintenance of efficiency which is held
to be a constitutional limitation on the discretion of the State in making reservation
as indicated by Article 335. As stated above, the concepts of efficiency, backwardness,
inadequacy of representation are required to be identified and measured. That
exercise depends on availability of data. That exercise depends on numerous factors.
It is for this reason that enabling provisions are required to be made because each
competing claim seeks to achieve certain goals. How best one should optimize these
conflicting claims can only be done by the administration in the context of local
prevailing conditions in public employment. This is amply demonstrated by the
various decisions of this Court discussed hereinabove. Therefore, there is a basic
difference between 'equality in law' and 'equality in fact' (See: 'Affirmative Action' by
William Darity). If Articles 16(4A) and 16(4B) flow from Article 16(4) and if Article
16(4) is an enabling provision then Articles 16(4A) and 16(4B) are also enabling
provisions. As long as the boundaries mentioned in Article 16(4), namely,
backwardness, inadequacy and efficiency of administration are retained in Articles
16(4A) and 16(4B) as controlling factors, we cannot attribute constitutional invalidity
to these enabling provisions. However, when the State fails to identify and implement
the controlling factors then excessiveness comes in, which is to be decided on the
facts of each case. In a given case, where excessiveness results in reverse
discrimination, this Court has to examine individual cases and decide the matter in
accordance with law. This is the theory of 'guided power'. We may once again repeat
that equality is not violated by mere conferment of power but it is breached by
arbitrary exercise of the power conferred.
117. The test for judging the width of the power and the test for adjudicating the
exercise of power by the concerned State are two different tests which warrant two
different judicial approaches. In the present case, as stated above, we are required to
test the width of the power under the impugned amendments. Therefore, we have to
apply "the width test". In applying "the width test" we have to see whether the
impugned amendments obliterate the constitutional limitations mentioned in Article
16(4), namely, backwardness and inadequacy of representation. As stated above,
these limitations are not obliterated by the impugned amendments. However, the
question still remains whether the State concerned has identified and valued the
circumstances justifying it to make reservation. This question has to be decided
case-wise. There are numerous petitions pending in this Court in which reservationsCaptain Gurvinder Singh &Ors vs State Of Raj on 22 December, 2010

made under State enactments have been challenged as excessive. The extent of
reservation has to be decided on facts of each case. The judgment in Indra Sawhney
does not deal with constitutional amendments. In our present judgment, we are
upholding the validity of the constitutional amendments subject to the limitations.
Therefore, in each case the Court has got to be satisfied that the State has exercised
its opinion in making reservations in promotions for SCs and STs and for which the
State concerned will have to place before the Court the requisite quantifiable data in
each case and satisfy the Court that such reservations became necessary on account
of inadequacy of representation of SCs/ STs in a particular class or classes of posts
without affecting general efficiency of service as mandated under Article 335 of the
Constitution.
The Apex Court held that in every case where the State decides to provide for reservation there must
exist two circumstances, namely, 'backwardness' and 'inadequacy of representation'. Backwardness
has to be based on objective factors whereas inadequacy has to factually exist. In the instant case,
this exercise has not been done by the State before increasing the percentage of reservation.
In M.Nagaraj (supra), the Apex Court has concluded thus:-
121.The impugned constitutional amendments by which Articles 16(4A) and 16(4B)
have been inserted flow from Article 16(4). They do not alter the structure of Article
16(4). They retain the controlling factors or the compelling reasons, namely,
backwardness and inadequacy of representation which enables the States to provide
for reservation keeping in mind the overall efficiency of the State administration
under Article 335. These impugned amendments are confined only to SCs and STs.
They do not obliterate any of the constitutional requirements, namely, ceiling-limit of
50% (quantitative limitation), the concept of creamy layer (qualitative exclusion), the
sub-classification between OBC on one hand and SCs and STs on the other hand as
held in Indra Sawhney , the concept of post-based Roster with in-built concept of
replacement as held in R.K.Sabharwal.
122. We reiterate that the ceiling-limit of 50%, the concept of creamy layer and the
compelling reasons, namely, backwardness, inadequacy of representation and overall
administrative efficiency are all constitutional requirements without which the
structure of equality of opportunity in Article 16 would collapse.
123. However, in this case, as stated above, the main issue concerns the "extent of
reservation". In this regard the State concerned will have to show in each case the
existence of the compelling reasons, namely, backwardness, inadequacy of
representation and overall administrative efficiency before making provision for
reservation. As stated above, the impugned provision is an enabling provision. The
State is not bound to make reservation for SC/ST in matter of promotions. However,
if they wish to exercise their discretion and make such provision, the State has to
collect quantifiable data showing backwardness of the class and inadequacy ofCaptain Gurvinder Singh &Ors vs State Of Raj on 22 December, 2010

representation of that class in public employment in addition to compliance of Article
335. It is made clear that even if the State has compelling reasons, as stated above,
the State will have to see that its reservation provision does not lead to excessiveness
so as to breach the ceiling-limit of 50% or obliterate the creamy layer or extend the
reservation indefinitely.
In the instant case, the study, which has been held to be necessary, has not been admittedly
undertaken by the State. It has also increased the percentage of reservation to 68% in oblivion of
aforesaid decisions. When Gurjars were already in backward classes what prompted it to create
Special Backward Classes as compared to other backward classes, has not been indicated by
comparable data. Question is also of creating EBC when backward class was already having concept
of creamy layer. No such exercise to create such class and within class has been undertaken and
mind has not been applied to extent of reservation which is permissible considering efficiency in
administration. The point of reference to Chopra Committee was different.
The Apex Court in S.V.Joshi (supra) has passed the following order on 13.7.2010:-
Writ Petition (C) No.259 of 1994 Learned counsel for the petitioners states that, in
view of the subsequent events, this writ petition has become infructuous, which is,
accordingly dismissed.
This writ petition, basically has become infructuous because the petitioners have
since retired. However, this order of dismissal of the writ petition would not result in
denial of pensionary benefits to the petitioners herein.
Writ Petition (C) Nos.454/1994, 473/1994, 238/1995 and 35/1996:
The short question which arises for determination in these writ petitions, is whether
the quantum of reservation provided for in Tamil Nadu Backward Classes, Scheduled
Castes and Scheduled Tribes (Reservation of Seats in Educational Institutions and of
Appointments to the Posts in the Services under the State ) Act, 1993, is valid?
The impugned Act received the Presidential assent on 19th July, 1994.
Subsequent to the filing of the above writ petitions, Articles 15 and 16 of the
Constitution have been amended vide Constitution [Ninety-third Amendment) Act,
2005 and Constitution (Eighty-first Amendment) Act, 2000 respectively, which
Amendment Acts have been the subject-matter of subsequent decisions of this Court
in the cases of M. Nagaraj & Ors. Vs. Union of India & Ors., reported in 2006(8)
S.C.C. 212 and Ashoka Kumar Thakur Vs. Union of India & Ors., reported in 2008 (6)
S.C.C.1, in which, inter alia, it has been laid down that if a State wants to exceed fifty
per cent reservation, then it is required to base it's decision on the quantifiable data.
In the present case, this exercise has not been done. Therefore, keeping in mind the
said parameter, we direct the State to place the quantifiable data before the TamilCaptain Gurvinder Singh &Ors vs State Of Raj on 22 December, 2010

Nadu State Backward Classes Commission and, on the basis of such quantifiable data
amongst other things, the Commission will decide the quantum of reservation. We
are informed by learned Solicitor General that such data in the form of Reports,
which are subsequently prepared, is already available.
Consequently, these writ petitions stand disposed of with a direction to the State
Government to re-visit and take appropriate decision in the light of what is stated
above.
It needs to be mentioned that the interim orders passed by this Court from time to
time in relation to admissions to Educational Institutions shall continue to be in force
and in operation for a period of one year from today.
In the circumstances, we are not expressing any opinion on the validity of 1993 Act at
this stage.
The Registry is directed to send the records and proceedings, if any, connected to
these writ petitions back to the State.
Writ Petition (C) No.471 of 1994:
By this writ petition, Government Order dated 25th July, 1994, passed by the State of
Karnataka, is sought to be challenged only to the extent that it provides for
reservation in excess of fifty per cent, both in the matter of Admission to Educational
Institutions and in the matter of Recruitment to Service.
On 9th September, 1994, the present writ petition had come up for directions along
with I.A. No.4 in Writ Petition (C) No.438 of 1994. In this case, we are concerned
only with Writ Petition (C) No.471 of 1994. On the said date, this Court passed the
order in the following terms:
The State Government shall be at liberty to make reservations in terms of the law laid
down by this Court in Indra Sawhney case [reported in 1992 Suppl.(3) SCC 217] It
was also made clear that the State Government can make reservations upto fifty
percent, inclusive of Scheduled Castes, Scheduled Tribes and Other Backward
Classes.
We may state that, subsequent to the filing of this writ petition in 1994, Articles 15
and 16 of the Constitution have been amended vide Constitution [Ninety-third
Amendment] Act, 2005 and Constitution [Eighty-first Amendment] Act, 2000,
respectively. Moreover, subsequent decisions in the cases of M.Nagaraj & Ors. Vs.
Union of India & Ors, reported in 2006 (8) S.C.C. 212 and Ashoka Kumar Thakur Vs.
Union of India & Ors., reported in 2008 (6) S.C.C.1, are also required to be kept in
mind by the State Government, if at all, it seeks to pass any other order in nearCaptain Gurvinder Singh &Ors vs State Of Raj on 22 December, 2010

future.
Subject to above, this writ petition stands disposed of.
Writ Petition (C) No.694 of 1994:
By this writ petition, challenge is laid to Sections 4, 5 and 7 of the Karnataka
Scheduled Castes, Scheduled Tribes and Other Backward Classes [Reservation of
Seats in Educational Institutions and of Appointments or Posts in the [Services under
the State] Act, 1994. By interim Order dated 11th November, 1994, this Court has
stayed the operation of Sections 4, 5 and 7 of the 1994 Act, which is in operation till
date. It is not in dispute that, after the filing of this writ petition and during it's
pendency, Articles 15 and 16 of the Constitution have been amended vide
Constitution [Ninety-third Amendment] Act, 2005, and Constitution [Eighty-first
Amendment] Act, 2000, respectively. Further, after the filing of the writ petition,
various pronouncements have been made by the judgments of the Constitution
Benches of this Court in the cases of M. Nagaraj & Ors. Vs. Union of India & Ors.,
reported in 2006 (8) S.C.C.212 and Ashoka Kumar Thakur Vs. Union of India & Ors.,
reported in 2008 (6) S.C.C. 1. Under the said decisions, which have been rendered in
the light of Constitution [Eighty-first Amendment] Act, 2000, and Constitution
[Ninety-third Amendment] Act, 2005, reservation exceeding fifty per cent could be
made only on the basis of quantifiable data before the Government. It appears that
till today, this exercise has not been undertaken and the State Government has not
collected the quantifiable data. It has not presented such data before the Court.
In the circumstances, we hereby direct the State of Karnataka to re-visit Sections 4, 5
and 7 of 1994 Act in the light of the judgments of this Court, referred to above. We
give one year's time to the State Government to take appropriate decision, if so
advised. The interim order dated 11th November, 1994, will continue to operate for a
period of one year from today. After one year, liberty is given to the petitioner, if so
advised, to move this Court if no steps are taken by the State Government, as directed
above.
Subject to above, this writ petition stands disposed of.
The Apex Court has taken note of amendment made in Articles 15 and 16 of the
Constitution vide Constitution (Ninety-third Amendment) Act, 2005 and
Constitution (Eighty-first Amendment) Act, 2000 respectively and decisions in the
cases of M.Nagaraj (supra) and Ashoka Kumar Thakur (supra) and has held that the
State is required to keep in mind the aforesaid provision before it seeks to pass any
order in future. The Apex Court has also held that in case State wants to exceed 50%
reservation then it is required to base its decision on the quantifiable data and as this
exercise has not been done, therefore, keeping in mind the said parameter, the Apex
Court directed the State to place the quantifiable data before Tamil Nadu StateCaptain Gurvinder Singh &Ors vs State Of Raj on 22 December, 2010

Backward Classes Commission and on the basis of quantifiable data amongst other
things, the Commission will decide the quantum of reservation.
In the matter of State of Karnataka, the Apex Court duly considered the aforesaid
provision and decision and held in the context of Karnataka Scheduled Castes,
Scheduled Tribes and other backward Classes (Reservation of Seats in Educational
Institutions and of Appointments or Posts in the (Services under the State) Act, 1994
that operation of Sections 4, 5 and 7 of the Act of 1994 was stayed and amendment to
Articles 15 and 16 of the Constitution has been made vide Constitution (Ninety-third
Amendment) Act, 2005 and Constitution (Eighty-first Amendment) Act, 2000
respectively and considering the pronouncement in M.Nagaraj (supra) also laid down
that reservation could be made only on the basis of quantifiable data before the
Government and as this exercise has not been undertaken and the State Government
has not collected the quantifiable data nor presented such data before the Court, the
Apex Court directed the State of Karnataka to re-visit Sections 4, 5 and 7 of the Act of
1994 in light of the judgments of the Apex Court. One year's time was given to the
State Government to take appropriate decision. The interim order was ordered to be
continued for a period of one year.
In the instant case, the State Government has not made any study nor collected the
quantifiable data, which is necessary. When certain community is already in
backward class what makes it special one as compared to others in backward class
was not point of reference to Chopra Committee, when concept of creamy layer
exclusion was existing in backward classes what led to providing further reservation
to EBC has been not made clear in any comparable data. In view of the decisions of
the Apex Court in the cases of M.Nagaraj (supra), Indra Sawhney (supra) and Ashoka
Kumar Thakur (supra), we direct that the State Government shall re-visit Sections 3
and 4 of the Act of 2008 as well as the Notifications. The State Government shall
keep in mind that benefit of reservation is provided to the needy and is not usurp by
the persons in the same class who have already come up on higher level income
group. Reservation to the higher income group is not envisaged in the Other
Backward Classes. The State shall keep in mind the law laid down by the Apex Court
in various decisions in Indra Sawhney (supra), M.Nagaraj (supra) and Ashoka Kumar
Thakur (supra). The State shall also consider the extent of reservation which it can do
in light of aforesaid decisions and of providing of further reservation than existing.
We direct the State not to give effect to the Sections 3 and 4 of the Act of 2008 and
the Notification with respect to enhancing financial limit of creamy layer from 2.5
lacs to 4.5 lacs. Let the State reconsider provision for creating Special Backward
Class, provision of 14% reservation to EBC also.
As agreed, let the matter be referred to the Rajasthan State Backward Classes
Commission and the State Government shall place before the Commission the
quantifiable data of numerous factors which is necessary in light of the Apex Court
decisions in the case of M.Nagaraj (supra) and Ashoka Kumar Thakur (supra). AsCaptain Gurvinder Singh &Ors vs State Of Raj on 22 December, 2010

collection of quantifiable data is going to consume sufficient time, let this exercise be
completed within a period of one year. The petitioners shall also be given opportunity
amongst others in accordance with law to present their case before the Commission.
It is reiterated that stay shall continue till the matter is decided afresh and even if the
State decides to enhance reservation beyond the percentage which was existing prior
to coming into force the Act of 2008, the State shall not give effect to the said
enhanced percentage of reservation for a period of two months thereafter. As agreed,
we leave all the questions raised in the petitions to be examined by the State at first
instance in light of amended provisions of Articles 15 and 16 of the Constitution and
decisions of Apex Court in Indra Sawhney (supra), M.Nagaraj (supra), Ashoka Kumar
Thakur (supra), Suraj Bhan Meena (supra) and S.V.Joshi (supra).
The writ petitions thus stand disposed of in terms of the aforesaid observations and
directions.
(Mahesh Bhagwati)J.                      (Arun Mishra)C.J.
ParmarCaptain Gurvinder Singh &Ors vs State Of Raj on 22 December, 2010

