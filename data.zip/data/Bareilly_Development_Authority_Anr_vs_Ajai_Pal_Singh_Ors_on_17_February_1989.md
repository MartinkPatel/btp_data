Bareilly Development Authority & Anr vs Ajai Pal Singh & Ors on
17 February, 1989
Equivalent citations: 1989 AIR 1076, 1989 SCR (1) 743, AIR 1989 SUPREME
COURT 1076, (1989) 1 ALL WC 425, (1989) 1 KER LT 52, (1989) 1 JT 368 (SC),
1989 (2) SCC 116
Author: S.R. Pandian
Bench: S.R. Pandian, G.L. Oza
           PETITIONER:
BAREILLY DEVELOPMENT AUTHORITY & ANR.
        Vs.
RESPONDENT:
AJAI PAL SINGH & ORS.
DATE OF JUDGMENT17/02/1989
BENCH:
PANDIAN, S.R. (J)
BENCH:
PANDIAN, S.R. (J)
OZA, G.L. (J)
CITATION:
 1989 AIR 1076            1989 SCR  (1) 743
 1989 SCC  (2) 116        JT 1989 (1)   368
 1989 SCALE  (1)439
ACT:
U.P.  Urban  (Planning and Development) Act,  1973 :  S.4
Bareilly  Development  Authority--Construction  of  dwelling
units--Whether  entitled to revise cost of houses/flats  and
rate  of monthly instalments-Applicants whether entitled  to
assail the action of the Authority in writ petition.
    Constitution  of  India,  1950: Articles 12,  14,  32 &
226--Bareilly Development Authority--Whether other authority
for purpose of Article 12--Construction of flats and  dwell-
ing  units--Cost  of  flats/rate of  instalment  revised  on
allotment--Whether amenable to writ jurisdiction.
HEADNOTE:
    The  appellant-Authority  offered to register  names  ofBareilly Development Authority & Anr vs Ajai Pal Singh & Ors on 17 February, 1989

intending applications desirous of purchasing LIG, MIG,  HIG
and  EWS type houses/flats. The 'General Information  Table'
given  in the brochure indicated the type of houses,  corre-
sponding  income groups, cost, initial payment to  be  made,
rate  of interest and approximate monthly instalments.  Note
(1) under the said table stated that the cost shown  therein
was  only estimated cost and it would increase  or  decrease
according  to the rise or fail in the price at the  time  of
completion  of  the houses, while Note (2) stated  that  the
date  given therein could be amended as felt  necessary.  By
clauses  12 and 13 contained in the brochure  the  Authority
reserved  its discretion to change, alter or modify  any  of
the  terms  and/or conditions of the allotment as  and  when
necessary.
    All the respondents registered their names for allotment
of the flats in accordance with the terms and conditions  in
the  brochure  and made the initial  deposit.  Subsequently,
they  received  notices from the  Authority  intimating  the
revised cost of houses and the amount of monthly  instalment
rates which were almost double of those initially stated  in
the  'General Information Table'. The respondents were  fur-
ther  informed  that those who intend to buy houses  on  the
revised price/instalments must send their written acceptance
by  the date specified other-wise their claims would not  be
included  in the lots to be drawn. Except a few,  all  other
respondents gave their unequivocal and unconditional written
consent. Hence their names were included in the
743
 744
draws and on becoming lucky in the draw, they were  allotted
their respective houses.
    At  this stage. all the respondents approached the  High
Court under Article 226 of the Constitution challenging  the
revised  terms and conditions on the ground that the  appel-
lants were estopped from changing the conditions subject  to
which  the  respondents  had applied  for  registration  and
deposited the initial payment, that the enhancement of  cost
of  the  house amounting to almost double of  the  estimated
cost as shown in the brochure and the increase of the month-
ly  instalments were much beyond their means and  that  this
arbitrary and unilateral stand of the appellants was to  the
prejudice of the respondents. These petitions were  resisted
by  the appellants by contending that the  respondents  were
estopped from challenging the varied terms and conditions of
the allotment after having consented.
    The  High  Court found the action of  the  Authority  in
fixing the revised cost and instalments arbitrary and unrea-
sonable and directed the appellant-Authority to re-determine
the cost of the flats and instalments payable by them  after
hearing the parties.
    In  these appeals by special leave it was contended  for
the  appellant-Authority that the income of  the  applicants
was relevant only to determine the category of the scheme inBareilly Development Authority & Anr vs Ajai Pal Singh & Ors on 17 February, 1989

which they had to be included for eligibility to get a house
under the scheme but not for enhancement of the cost of  the
house and monthly instalments, that it had fixed the cost of
the  houses  and the rate of instalments after  taking  into
consideration the escalation in the price of building  mate-
rial, labour charges, cost of transport and allied  valuable
factors  which  all enter into the price fixation,  that  in
price fixation the executive has a wide discretion and it is
only answerable provided there is any statutory control over
its policy of price fixation, and that after the parties had
entered  into  the  field of ordinary contract,  as  in  the
instant  case. the relations were no longer covered  by  the
constitutional provisions but by the legally valid  contract
which  determines the rights and obligations of the  parties
inter se
Allowing the appeals,
    HELD:  1.  Where the contract entered into  between  the
State and the persons aggrieved is non-statutory and  purely
contractual and the rights are governed only by the terms of
the  contract, no writ or order can be issued under  Article
226 of the Constitution of India so as
 745
to  compel  the authorities to remedy a breach  of  contract
pure and simple. [755C]
    Radhakrishna  Agarwal & Ors. v. State of Bihar  &  Ors.,
[1977]  3 SCR 249; Premji Bhai Parmar & Ors. etc.  v.  Delhi
Development  Authority & Ors. [1980] 2 SCR 704 and  D.F.O.v.
Biswanath Tea Company Ltd., [1981] 3 SCR 662 referred to.
    The  respondents  in the instant  case  had  voluntarily
registered themselves as applicants only after fully  under-
standing the terms and conditions of the brochure, inclusive
of cls. 12 and 13 and Notes 1 and 2 of the General  Informa-
tion Table under which the Authority had reserved its  right
to  change the terms and conditions as and when felt  neces-
sary evidently depending upon the escalation of the  prices.
The  Authority  did not compel anyone of the  applicants  to
purchase the flat at the rates subsequently fixed by it  and
pay  the increased monthly instalments. On the contrary  the
option  was left over only to the allottees. All  the  same,
the  respondents gave their written consent  unconditionally
accepting  the  changed  and varied  terms  and  conditions.
[753H;754A-C]
    The  respondents after accepting the conditions  imposed
by  the Authority had thus entered into the realm of a  con-
cluded contract pure and simple with the Authority and hence
they  could only claim the right conferred upon them by  the
said  contract and were bound by the terms of  the  contract
unless  some statute stepped in and conferred  some  special
statutory  obligations on the part of the Authority  in  the
contractual field. The contract between the respondents  and
the  Authority  did not contain any statutory  terms  and/or
conditions. [754C-E]
    Even conceding that the Authority had the trappings of aBareilly Development Authority & Anr vs Ajai Pal Singh & Ors on 17 February, 1989

State or would be comprehended in 'other authority' for  the
purpose of Article 12 of the Constitution, while determining
price of the houses flats constructed by it and the rate  of
monthly instalments to be paid, the 'authority' or its agent
after entering into the field of ordinary contract had acted
purely  in its executive capacity. Thereafter the  relations
were  no longer. governed by the  Constitutional  provisions
but  by  the  legally valid contract  which  determined  the
rights  and  obligations of the parties  inter-se.  In  this
sphere, they could only claim rights conferred upon them  by
the contract in the absence of any statutory obligations  on
the  part  of the Authority in the said  contractual  field.
[754G-H; 755A-B]
Ramana Dayaram Shetty v. The International Airport Authority
 746
of India & Ors., AIR 1979 S.C. 1628.
    The  High Court while exercising its jurisdiction  under
Article  226 of the Constitution had, therefore, gone  wrong
in  its finding that there was arbitrariness and  unreasona-
bleness on the part of the appellants in increasing the cost
of the houses/flats and the rate of monthly instalments, and
giving  directions  in  the writ petitions  as  prayed  for.
[755D-E]
JUDGMENT:
CIVIL APPELLATE JURISDICTION: Civil Appeal Nos. 2809- 2812A of 1986.
From the Judgment and Order dated 6.2.1986 of the Alla- habad High Court in Civil Misc. W.P. Nos.
2274, 2983, 3860, 4558 and 3202 of 1984.
Rajinder Sachher and Bharat Sanghal for the Appellants. Harbans Lal, Dr. Meera Agarwal, R.C.
Misra and Arun Madan for the Respondents.
The Judgment of the Court was delivered by S. RATNAVEL PANDIAN, J. These five appeals by
Special Leave under Article 136 of the Constitution of India are preferred against the Judgment and
Or, let dated 6.2.86 passed by the Allahabad High Court in Civil Misc. Writ Petition No. 2274/84
connected with Civil Misc. Writ Peti- tion Nos. 2983/84, 3860/84, 4558/84 & 3202/84 directing
the respondents (appellants herein) to re-determine the cost of the appellants' (respondents herein)
flats and instalments payable by them after hearing their grievances. Since identical contentions are
urged in all the ap- peals, we are rendering a common judgment.
As it is said that Civil Appeal No. 2809/86 arising out of Civil Misc. Writ Petition No. 2274/84 is
more comprehen- sive and the facts alleged therein may be taken as represen- tative in character,
the facts relating to this appeal are briefly stated.Bareilly Development Authority & Anr vs Ajai Pal Singh & Ors on 17 February, 1989

The Bareilly Development Authority (hereinafter re- ferred. as 'BDA'), the first appellant was
constituted under Section 4 of the U.P. Urban Planning and Development Act, 1973 by the State
Government for the purposes of development in the District of Bareilly., With a view to casing the
acute housing problem in the said District, the BDA has undertaken construction of dwelling units
for people belonging to different income groups styled as 'Lower Income Group', 'Middle Income
Group', 'High Income Group' and the 'Economically Weaker Sections' (hereinafter referred as LIG,
MIG, HIG and EWS respectively). The BDA issued' an advertisement offering to register names of
intending applicants desirous of purchas- ing dwelling houses/flats in any one of the different
income groups intended to be constructed by the BDA. In this appeal i.e. Civil Appeal No. 2809/86,
the respondents 1 to 17 and 20 got themselves registered for allotment of flats in MIG scheme and
respondents 18 and 19 in HIG scheme with the BDA in accordance with the terms and conditions
contained in the brochure issued by the Authority. The following table of the brochure shows the
necessary details inclusive of the esti- mated cost for the different types of flats under various
categories:
Type of Range of Cost Initial Interest Approx House Income payment monthly
instalment MIG Rs. 1000 to Rs.64,000 Rs.5000 12% Rs.551 p.m. for Rs. 1500 p.m. 15
yrs.
HIG Rs. 1500 and Rs. 1, 15,000 Rs.7000 12% Rs. 1440 above p.m. p.m. for 10 yrs.
LIG Rs.351 to Rs.35,000 Rs.2000 11% Rs.345 p.m. for Rs. 1000 p.m. 15 yrs.
EWS Rs.350 p.m. Rs. 11,000 Rs, 100 7% Rs.89 p.m. for 20 yrs.
The note under the 'General Information Table' given in the said brochure states that the cost shown
therein is only estimated cost and it would increase or decrease according to the rise or fail in the
price at the time of completion of the houses/flats.
All the respondents registered.their names' for MIG, HIG and EWS flats as the case may be and
made the initial deposit. Thereafter, the respondents in MIG group received indentical notices dated
19/20.1.84 from the Secretary, Bareilly Devel- opment Authority (second appellant) intimating that
the revised cost of houses/flats of MIG group as well as the amount of monthly instalment would be
as follows:
2. Cost of the house Rs. 1,27,000
3. Down payment to be made/ Rs.35,000 paid on allotment fixed for the payment of
remaining amount
5. Rate of yearly interest 13.5%
6. Amount of monthly instalment Rs. 1,031.50 with interest.Bareilly Development Authority & Anr vs Ajai Pal Singh & Ors on 17 February, 1989

By the said notice, the respondents in MIG group were informed that 40% of the houses/flats
mentioned in the notice would be given to the allottees who would deposit the entire cost in one
cash payment and that the other allottees who intend to buy houses/flats on the above revised
price/instalments must send by 28.1.84 their written accept- ance on the annexed proforma to the
Registration Section of the office of the BDA otherwise their claims would not be included in the lots
to be drawn on 31.1.1984. Except the respondents Nos. 13, 17, 18 and 20, all other respondents in
reply to those notices gave their unequivocal and uncondi- tional written consent. Hence their
names were included in the draw and on being lucky in the draw, the respondents barring the above
4 were allotted their respective houses. After allotment, they were asked to complete the other
formalities and make down payments in accordance with the notice. dated 19/20.1.1984, by a
further notice dated 3.2.1984 (Annexure 'F'). Similar notices were issued to all the registered
allottees for all types of houses and the respondents were also intimated that in case any of the
registered persons does not want to purchase the house, his name would not be included in the draw
but he would have his choice later on.
At this stage, all the respondents in these appeals approached the High Court under Article 226 of
the Constitu- tion of India challenging the revised terms and conditions of the BDA on the ground
that the petitioners were estopped from changing the conditions subject to which the respond-
ents-applicants had applied for registration and deposited the initial payment in the year 1980; that
the enhancement of cost of the house/flat amounting almost double of the estimated cost as shown
in the brochure while inviting the applications and the increase of the monthly instalments are
much beyond the means of the respondents and that this arbitrary and unilateral stand of the
petitioners is to the prejudice of the respondents. On the above contentions, the respondents prayed
in their respective petitions for issue of writ of mandamus directing the petitioners to maintain the
allotment of the flats in their favour on the original terms and conditions, to hand over the
possession of the same and further to restrain the petitioners from cancelling the original allotment.
The above plea was resisted by the petitioners strongly relying on certain conditions contained in
the brochure especially of clauses 12 and 13 as per which the BDA has reserved its discretion to
change, alter or modify any of the terms and/or conditions of the allotment given in the brochure;
that its decision would be final with regard to any matter concerning the registration and allot- ment
and that the BDA has right to relax any condition in its discretion. It has been further contended
that respond- ents barring 13, 17, 18 and 20 have given their written acceptance to the changed
conditions as mentioned in the notice dated 19/20.1.1984 and as such they are not entitled to the
reliefs claimed in the writ petition. According to the petitioners the increase in the cost and the
interest demanded from the respondents is neither arbitrary nor unreasonable and the High Court
is not the proper forum for examining in detail the terms regarding payment of instal- ments in the
circumstances of the present case, and if the respondents were not agreeable to the changed terms
and conditions, they could as well resile from their consent. Finally, it was contended that the
respondents are estopped from challenging the varied terms and conditions of the allotment after
having consented.
The High Court though repelled the contention of the respondents (allottees) based on the principle
of promissory estoppel, made the following observations with regard to the case of the respondents
in the MIG category:Bareilly Development Authority & Anr vs Ajai Pal Singh & Ors on 17 February, 1989

"In the circumstances of the present case the fixation of monthly instalment to the
tune of Rs.1031.50 from the petitioners of MIG group whose income is hardly Rs.
1500 per month appears to us smack- ing of arbitrariness and unreasonableness on
the part of the contesting opposite party (petitioners herein)";
"In the circumstances of the present case, we are not satisfied that the contesting
opposite party has succeeded in establishing its demand of double the estimated cost
by facts and figures. The end of justice demands that the authority should refix the
cost of the peti- tioner's flats after hearing their grievance."
The High Court answered the objections taken by the petitioners herein that the respondents have
consented for the changed terms and conditions observing, "We think that the consent obtained
from the petitioners was also not reasonable act on the part of the contesting opposite par- ties
(appellants herein)". Finally, the High Court adopting the above reasoning in respect of the cases of
other re- spondents also falling under various categories directed the appellants herein in all the
writ petitions "to re-determine the cost of the petitioners' (respondents herein) flats and instalments
payable by them after heating their grievances."
Being aggrieved by the impugned judgment the appellants have filed these appeals by special leave.
Shri Rajinder Sachher, St. Adv. after taking us through the relevant documents and the additional
affidavit filed by the second respondent and the reply affidavit assailed the reasonings given by the
High Court contending that the said Court has erroneously held that the BDA has failed to justi- fy
the demand of the enhancement in the cost of houses/flats as well as the increase of the monthly
instalments in dis- proportionate to their income, because the income of the applicant was relevant
only to determine the category of the scheme in which the applicant had to be included for eligi-
bility to get a house/flat under the scheme but not for enhancement of the cost of the houses/ flats
and monthly instalments. According to him since the declared policy of the BDA being 'No Profit No
Loss', it had fixed the cost of the houses/flats and the rate of instalments after taking into
consideration of the escalation of the building materi- al, labour charges, cost of transport and the
allied valu- able factors which all enter into the price fixation, and as such the High Court is not
correct in going into the ques- tion of computation of cost of the construction of houses/flats and the
plea of clerical mistakes exercising its jurisdiction under Article 226 of the Constitution of India. He
further submits that the High Court has gone wrong in importing the principle laid down in Ramana
Dayaram Shetty v. The Interna- tional Airport Authority of India & Ors., AIR 1979 Supreme Court
1628 to the present facts and circumstances of the case in view of the fact that in price fixation the
execu- tive has a wide discretion and it is only answerable provid- ed there is any statutory control
over its policy of price fixation and it is not the function of the High Court to sit in judgment over
such matters of economic policy. It has been vehemently urged that after the parties have entered
into the field of ordinary contract, the relations are no longer covered by the constitutional
provisions but by the legally valid contract which determines the rights and obligations of the parties
inter-se.Bareilly Development Authority & Anr vs Ajai Pal Singh & Ors on 17 February, 1989

The fact that all respondents had applied for registra- tion only on acceptance of terms and
conditions contained in the brochure inclusive of Clauses 12 & 13 as well as the conditions
mentioned in the Notes 1 and 2 of the 'General Information Table' of the said brochure, and further
the respondents barring respondents Nos. 13, 17, 18 and 20 in MIG group gave their reply accepting
the changed terms and conditions as per letter dated 19/20.1.1984 cannot be chal- lenged in view of
the unassailable documentary evidence namely Annexures 'A', 'D', 'E' and 'F'.
Now, we shall reproduce some of the relevant conditions of the brochure as well as the changed
conditions contained in the letter dated 19/20.1.1984. Clauses 12 and 13 of the brochure issued by
the BDA and the notes 1 and 2 of the General Information Table thereto read thus:
Clause 12 For allotment by lottery all the above-men- tioned terms and rules given in
the booklet would ordinarily be followed but the Develop- ment Authority will have
the right to change, enhance or amend any of the terms and/or condition as and
when it thinks necessary and at its discretion.
Clause 13 The decision of the Development Authority in regard to any matter in
relation to the regis- tration application will be final. It would have the right to relax
any of the conditions at its discretion. The fight to sell by auc- tion the Middle Income
Group and Higher Income Group plots/houses or any portion thereof, of the various
schemes, will also vest in the Devel- opment Authority.
General Information Table Note: (1) The cost shown in the column 4 is only
estimated cost. It will increase or decrease according to the rise or fall in the price at
the time of completion of the property.
Note: (2) The data given in the above mentioned table can be amended as felt neces-
sary.
The last paragraph of the letter dated 19/20.1.84 (Annexure 'D') reads thus:
"If you want to buy the house on the above price/instalment then you must send by
28.1.1984 your written acceptance on the annexed proforma to the Registration
Section of this office."
It may be mentioned here that in this letter (Annexure 'D'), the BDA has informed the allottees of
MIG about the enhancement of the cost of the houses/flats as well as the increase of the monthly
instalment and the rate of yearly interest etc. and requested the allottees to give their written
acceptance so that their names could be included in the list.
The respondents except the four above have sent their written acceptance to the letter (Annexure
'D'). For a better appreciation of the case of the appellants, we think that as an example the letter
(Annexure 'E') of the first respondent in this case namely Shri Ajay Pal Singh may be reproduced:Bareilly Development Authority & Anr vs Ajai Pal Singh & Ors on 17 February, 1989

"I, Ajay Pal Singh, S/o Shri Sujan Singh want to take a Middle Income Group house
in the Housing Scheme No. 2 situated at Tibrinath of the Bareilly Development
Authority on payment by instalment. I have seen the house and am satisfied. I accept
the rules of the Bareilly Development Authority."
Only on the basis of the written acceptance, the name of the first respondent was included in the
draw and he has successful in getting the allotment of House No. 37 in MIG type which fact if clearly
borne out by the letter from the second respondent (Annexure 'F'). In this connection, it is
worthwhile to note that the first respondent, Shri Ajay Pal Singh is the Principal of Shri Guru
Govind Singh Inter College and his educational qualifications are M.A. (Econ. & Hist.), B.Sc., B.Ed.,
LL.B. From the above, it is clear that all the respondents who have sent their applications for
registration with initial payment only after having fully understood the terms and conditions of the
brochure inclu- sive of the Clauses 12 and 13 and Notes 1 and 2 of the General Information Table as
per which the BDA has reserved its right to change, enhance or amend any of the terms and/or
conditions as and when felt necessary, and also the right to relax any of the conditions at its
discretion, and that the cost shown in the column 4 of the brochure was only estimated cost subject
to increase or decrease according to the rise or fail in the price at the time of completion of the
property. This is not only the case of the applicants of MIG scheme but also of the other applicants
falling under the other categories i.e. HIG, LIG and EWS. So it cannot be said that there was a
mis-statemennt or incorrect statement or an fraudulent concealment in the information supplied in
the brochure published by the BDA on the strength of which all the applicants falling under the
various categories applied and got their names registered. In such a circum- stance the respondents
cannot be heard to say that the BDA has arbitrarily and unreasonably changed the terms and
conditions of the brochure to the prejudice of the respond- ents.
More so, the respondents barring respondent Nos. 13, 17, 18 and 20 after having given their written
consent accepting the changed and varied terms and conditions as shown in the letter dated
19/20.1.84 are not justified in contending that the BDA has gone back on its original terms' and
conditions and has substituted new conditions to their detriment. It is quite un-understandable that
the persons like the first respondent who is highly educated, occupying the post of the Principal of a
College and who has accepted the changed terms and conditions by his letter is making these allega-
tions against the BDA.
The respondents were under no obligation to seek allot- ment of houses/flats even after they had
registered them- selves. Notwithstanding, they voluntarily registered them- selves as applicants,
only after fully understanding the terms and conditions of the brochure inclusive of Clauses 12 and
13 and Notes 1 and 2 of the General Information Table which we have reproduced above, they are
now trying to obtain the houses/flats at the price indicated in the bro- chure at the initial stage
conveniently ignoring the other express conditions by and under which the BDA has reserved its
right to change the terms and conditions as and when felt necessary, evidently depending upon the
escalation of the prices. One should not loose sight of the fact that the BDA did not compel anyone
of the applicants to purchase the flat at the rates subsequently fixed by it and pay the increased
monthly instalments. On the contrary, the option was left over only to the allottees. In fact, the
respond- ents in Civil Appeal No. 2809 of 1986 except the four above mentioned haveBareilly Development Authority & Anr vs Ajai Pal Singh & Ors on 17 February, 1989

unconditionally accepted the changed terms and conditions.
Thus the factual position in this case clearly and unambiguously reveals that the respondents after
voluntarily accepting the conditions imposed by the BDA have entered into the realm of concluded
contract pure and simple with the BDA and hence the respondents can only claim the right
conferred upon them by the said contract and are bound by the terms of the contract unless some
statute steps in and confers some special statutory obligations on the part of the BDA in the
contractual field. In the case before us, the contract between the respondents and the BDA does not
con- tain any statutory terms and/or conditions. When the factual position is so, the High Court
placing reliance on the decision in Ramana Dayaram Shetty case (AIR 1979 SC 1628) has
erroneously held:
"It has not been disputed that the contesting opposite party is included within the
term 'other authority' mentioned under Article 12 of the Constitution. Therefore, the
contesting opposite parties cannot be permitted to act arbitrarily with the principle
which meets the test of reason and relevance. Where an author- ity appears acting
unreasonably this Court is not powerless and a writ of mandamus can be issued for
performing its duty free from arbitrariness or unreasonableness."
This finding, in our view, is not correct in the light of the facts and circumstances of this case
because in Ramana Dayaram Shetty case there was no concluded contract as in this case. Even
conceding that the BDA has the trap- pings of a State or would be comprehended in 'other authori-
ty' for the purpose of Article 12 of the Constitution, while determining price of the houses/flats
constructed by it and the rate of monthly instalments to be paid, the 'authority' or its agent after
entering into the field of ordinary contract acts purely in its executive capacity. Thereafter the
relations are no longer governed by the constitutional provisions but by the legally valid contract
which determines the rights and obligations of the parties inter-se. In this sphere, they can only
claim rights conferred upon them by the contract in the absence of any statutory obligations on the
part of the authority (i.e. B.D.A. in this case) in the said contractual field.
There is a line of decisions where the contract entered into between the State and the persons
aggrieved is non- statutory and purely contractual and the rights are governed only by the terms of
the contract, no writ or order can be issued under Article 226 of the Constitution of India so as to
compel the authorities to remedy a breach of contract pure and simple Radhakrishna Agarwal &
Ors. v. State of Bihar & Ors., [1977] 3 SCR 249; Premji Bhai Parmar & Ors. etc. v. Delhi
Development Authority & Ors, [1980] 2 SCR 704 and D.F.O. v. Biswanath Tea Company Ltd., [1981]
3 SCR 662. In view of the authoritative judicial pronouncements of this Court in the series of cases
dealing with the scope of interference of a High Court while exercising its writ jurisdiction under
Article 226 of the Constitution of India in cases of non-statutory concluded contracts like the one in
hand, we are constrained to hold that the High Court in the present case has gone wrong in its
finding that there is arbitrariness and unreasonableness on the part of the appel- lants herein in
increasing the cost of the houses/flats and the rate of monthly instalments and giving directions in
the writ petitions as prayed for.Bareilly Development Authority & Anr vs Ajai Pal Singh & Ors on 17 February, 1989

For the reasons hereinbefore stated, we set aside the judgment of the High Court and accordingly
allow all the appeals. There will be no order as to costs.
Before parting with the judgment, we would like to observe that it is open to the respondents to
approach the appellants for correction of any clerical mistakes in the calculation, if any and they are
at liberty to move any proper authority for any remedy if they are otherwise legal- ly entitled to.
P.S.S.                                         Appeals   al-
lowed.Bareilly Development Authority & Anr vs Ajai Pal Singh & Ors on 17 February, 1989

