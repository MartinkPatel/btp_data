Assistant General Manager State Bank Of ... vs Radhey Shyam
Pandey on 2 March, 2020
Equivalent citations: AIRONLINE 2020 SC 273
Author: Arun Mishra
Bench: B.R. Gavai, M.R. Shah, Arun Mishra
                                                     1
                                                                         REPORTABLE
                                   IN THE SUPREME COURT OF INDIA
                                    CIVIL APPELLATE JURISDICTION
                                     CIVIL APPEAL NO.2463 OF 2015
         ASSISTANT GENERAL MANAGER & ORS.                           … APPELLANTS
                                                 VERSUS
         RADHEY SHYAM PANDEY                                        … RESPONDENT
                                                   WITH
                                 CIVIL APPEAL NOS.2287−2288 OF 2010
                                 CIVIL APPEAL NOS.5035−5037 OF 2012
                                    CIVIL APPEAL NO.10813 OF 2013
                                             JUDGMENT
ARUN MISHRA, J.
1. The question involved is whether the respondent−employees are entitled to pension on
completion of 15 years of service as per the State Bank of India Voluntary Retirement Scheme (for
short, “the VRS framed in 2000”).
2. The matter has been referred to larger Bench due to conflict of opinion between the Judges as to
the admissibility of pension under the VRS.Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

3. After obtaining approval of the Government of India, the Indian Bank Association (IBA) evolved a
Voluntary Retirement Scheme. The Central Board of Directors of the State Bank of India (in short
‘the SBI’) adopted and approved the scheme in its meeting held on 27.12.2000 for implementing the
VRS for the employees of the bank by retiring them on completion of 15 years of service with the
benefit provided in the scheme. The scheme had been drawn up, keeping in view the guidelines
issued by the IBA. “Memorandum” dated 26.12.2000 was submitted by the Deputy Managing
Director and the Corporate Development Officer for according approval to the proposals contained
in the Memorandum as also for adopting the scheme as Annexure ‘B’ to the Memorandum.
4. The basis of Memorandum dated 26.12.2000, was the advice by IBA vide letter dated 31.8.2000
in which it was pointed out that they deliberated with the Government of India, Ministry of Finance
(Banking Division), at its meeting with the Finance Minister, with Chief Executives of public sector
banks on 13.6.2000. The human resource and manpower planning in public sector banks were
reviewed, and a Committee was constituted to examine the issues concerned to public sector banks
and to suggest suitable remedial measures. The Committee considered the economic reforms set in
motion in the year 1990, the high establishment cost and low productivity in public sector banks. It
was felt that the banks convert their human resource into assets compatible with the business
strategies through a variety of measures. The data available indicated that 43% of the employees in
public sector banks were in the 46 + age group, and only 12% were in the 25−35 age group. It was
felt that this pattern has severe implications for the banks regarding mobility, training, development
of skills, and succession plans for higher−level positions. The workforce was in excess. In order to
remedy the situation, the Committee placed before the Government two schemes, viz., Sabbatical
Leave, and a Voluntary Retirement Scheme. The IBA vide letter dated 13.7.2000 sought no objection
from the Government for circulating the schemes to the banks for consideration and adoption by
their Boards. The Government conveyed on 29.8.2000 that it did not have any objection for
adopting and implementing the scheme by the respective Board of Directors. It advised that the
banks may adopt these schemes for sabbatical leave and voluntary retirement based on the essential
features of the schemes given in the annexure to the letter. The scheme provided eligibility for all
permanent employees with 15 years of service. It provided for amount of ex gratia and other benefits
accepted by the Government of India which were to be provided (i) gratuity as per the Gratuity
Act/service gratuity, as the case may be; (ii) pension (including commuted value of pension)/bank’s
contribution towards provident fund; and (iii) leave encashment as per rules.
5. After the Central Board of SBI approved the proposals contained in the memorandum on
27.12.2000, a circular was issued on 29.12.2000 in which it was mentioned that the IBA advised
that as the Committee constituted by the Finance Ministry recommended introduction of a VRS in
order to rationalise the manpower, the Government of India has no objection for adopting and
implementing the VRS. It was clearly stated in the Circular dated 29.12.2000 that the Central Board
of Directors accorded approval for adopting and implementing the SBI voluntary Retirement
Scheme drawn up, “keeping in view the guidelines issued by the IBA." Copy of the scheme was
placed as Annexure B. The scheme was open from 15.1.2001 till 31.1.2001. Specimen applications
and other related forms inter alia for pension were also circulated, which formed part of the circular.
The circular also made it clear that gratuity, provident fund contribution as per the Provident Fund
Rules, pension in terms of the SBI Employees’ Pension Fund Rules, leave encashment to beAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

provided beside the amount of ex gratia.
6. The heart and soul of the scheme were that benefits to be given on completion of 15 years of
service. The eligibility for benefits was provided to those who had completed 15 years of service as
on 31.12.2000.
7. The SBI submitted that it reserved a right under the scheme to modify, amend or cancel it or any
of the clauses and to give effect to it from any date deemed fit. The Deputy Managing Director−
cum−CDO was the competent authority for the purpose. As specific queries were raised, a
clarification was issued by the Deputy Managing Director on 15.1.2001, in which about a query
whether an employee on completing 15 years of pensionable service as on the relevant date of
retirement, would be entitled to pensionary benefits, in response, para 6(c) of the scheme was
reiterated, and it was also mentioned that as per the existing rules, employees who had not
completed 20 years of pensionable service, were not eligible for pension.
8. The clarification issued by the Deputy General Manager was not in the form of modification or
amendment of the scheme. The Deputy General Manager in clarification quoted the provisions and
simply stated the position of a rule that the pensionable service was 20 years. The communication
was clarificatory and did not have the effect of modifying the SBI VRS scheme as approved and
adopted.
9.(a) Radhey Shyam Pandey questioned the refusal of the bank to pay pension, vide communication
dated 26.9.2006 in the writ application filed in the High Court at Allahabad. He retired on 31.3.2001
under the SBI VRS. On 18.3.2001, the bank accepted the offer of the employee to retire him
voluntarily. He was aged 59 years three months and had nine months service still to go before
attaining the age of superannuation. On 31.3.2001, when the VRS became effective, he had put in 19
years, nine months, and 18 days of pensionable service. He had to retire on completion of 60 years,
and would have put in a little more than 20 years of pensionable service.
(b) The High Court held that the case of the employee fell under the Second Part of Rule 22(i)(a). He
was in service of the bank on and after 11.11.1993 and completed ten years of pensionable service,
and further, he attained the age of 58 years before the date he retired. The High Court opined that
the clarification was not part of the VRS scheme. The employee retired outside rule as per the
contractual retirement scheme. The contract had to prevail. In Pension Fund Rules, Clause (a) in
Rule 22(i) was inserted to give the employees the benefit of pension after ten years of pensionable
service even if they had joined late. The High Court found that the matter was covered by Rule
22(i)(a). The admissible benefit cannot be denied. If a contracting party is entitled to take benefit of
a permissible clause, then it cannot be denied to him.
(c) In the Chairman, State Bank of India & Ors. v. Mihir Kumar Nandi & Anr. (C.A. Nos. 5035−
5037/2012), a Division Bench of the High Court of Calcutta dismissing the intra−court appeal,
affirmed the order of the learned Single Judge and directed to make the payment of pension. The
employee was appointed on 21.5.1988. He opted for VRS on 15.1.2001. The acceptance was conveyed
on 17.3.2001 by which he was informed that he would be relieved of his duties on 31.3.2001. VideAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

letter dated 2.8.2001, the employee was granted a pension at the rate of Rs.1024 per month.
However, vide communication dated 30.8.2001, the pension payment order, together with payment
of commuted value, was stopped in view of the amendment of Rule 22 of the Pension Fund Rules.
Though the amendments in Pension Fund Rules were made effective with effect from 31.3.2001, and
the age of retirement had been raised from 58 years to 60 years, w.e.f. 22.5.1998, this had
necessitated increase in age for admission to Pension Fund to 58 years specified in Rule 22(i)(a) of
the Rules so that the employees who have retired/are retiring on attaining the age of 60 years after
completing ten years of pensionable service on or after 22.5.1998 are eligible for pension.
(d) The Central Board of the SBI in its meeting held on 30.1.2001 accorded approval to the
amendment in Rules 8 and 22(i)(a) of the Rules as set out in Annexure 1. The Trustees of the SBI
Employees’ Pension Fund in their meeting on 30.10.2001 adopted the amended rules.
Consequently, a Circular was issued on 8.11.2001. The amendment was given effect from 31.3.2001,
the date on which it was notified, though it was adopted by the Trustees of the SBI Trust Pension
Fund in October 2001.
(e) A Division Bench of the High Court held respondent−employee, as per rules on 17.3.2001, the
date on which his offer was accepted, was eligible to get the pension. On 31.3.2001, the amended
rules were published, which took away the existing right to get the pension. In VRS Scheme, it was
mentioned that the pension would be payable in accordance with the rules as on 31.3.2001. The
employee had no means of knowing about the future amendment of the Pension Rules, which would
be detrimental to his interest. If he had known the fact, then he would not have opted for the
scheme. The silence maintained by the employer in such a situation amounted to a fraud on its part.
The High Court relied upon section 17 of the Contract Act and Illustration (d) to section 19 of the
Contract Act. The High Court further held that it was the duty of the employer to disclose that there
would be a future amendment on the last date of their service by which their right to pension would
be taken away. The same cannot but be said to be unfair and arbitrary. Thus, the High Court held
that action is violative of Article 14 of the Constitution of India. The employee is entitled to the relief
of pension along with interest.
10. Ramesh Prasad Nigam (supra) had joined the services in 1984 in the clerical cadre and was
confirmed on 2.3.1985. He had applied for VRS, having completed 15 years of service and 57 years of
age. The clarification was internal circulation. It was not within the knowledge of employees; as
such, he was entitled to the pension.
11. (a) In C.A. Nos.2287−88/2010, M.P. Hallan joined the services of the bank on 18.5.1981 as a
clerk. The acceptance under VRS was communicated on 17.3.2001. On 27.3.2001, he applied to
withdraw his request made under VRS as retirement was w.e.f. 31.3.2001. The Bank declined
application on 18.4.2001 on the ground that the last date of withdrawal of the application was
15.2.2001. The employee claimed pension under Pension Fund Rules in terms of SBI Employees’
Pension Fund Rules (hereinafter referred to as ‘Pension Rules’). By writing a letter on 12.4.2001, the
claim of the employee for withdrawal of application for voluntary retirement, pension, and leave
encashment was again declined on 4.7.2001. Thereafter, he filed a writ petition in the High Court of
Punjab & Haryana.Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

(b) The High Court rejected the claim concerning the withdrawal from VRS. As the last date for
withdrawal was over, and acceptance had been communicated, however, considering Rule 22 of the
Pension Rules, the High Court opined that as the employee completed more than 19 years and ten
months of service on 31.3.2001, therefore, the first part of clause one of Rule 22 is not applicable.
Further, the third part of clause (a) is not applicable as he has completed ten years of service but not
attained the age of 60 years. The case of the employee was covered under the second part of clause
(a) of Rule 22, which enabled the member to get a pension if an employee in the service of the bank
on or after 1.11.1993, and completed ten years pensionable service and attained 58 years age. The
employee applied in terms of the Pension Rules prevailing in January 2001. Alternatively, if an
employee was in service of the bank on or after 1.11.1993, having completed ten years of pensionable
service and on attaining the age of 58 years, shall be entitled to a pension. Thus, he fulfilled the
requirement of second part of clause (a) of Rule 22 as he was in service of the bank on 1.11.1993 and
completed ten years of pensionable service, and the age of 58 years, therefore, in terms of Rule 22,
he was entitled to pension as well as leave encashment dues along with interest at the rate of 9
percent per annum.
12. On behalf of the bank, it was submitted that VRS 2000 stipulated that the pension in terms of
SBI Pension Fund Rules on the relevant date, i.e., 31.3.2001, was to be provided. In other words, in
case the employee was entitled to a pension in terms of Pension Rules and not otherwise. A
provision was added in Rule 22(1) of the Pension Rules in the year 1986, accordingly, the pension
was to be granted in all cases relating to voluntary retirement on completion of 20 years of service.
The employees opting for the SBI−VRS would be governed only by Rule 22(i)(c) as it falls under the
category of voluntary retirement. Under Rule 22(iii), a member who has been permitted to retire
under clause 22(i)(c) shall be entitled to a proportionate pension, which is on completion of 20 years
of pensionable service. Eligibility clause 3 has nothing to do with the admissibility of the pension. It
was further submitted that the employees who completed ten years of pensionable service and were
60 years of age were entitled to pension; while employees under the VRS on completion of 15 years
would not get pension and for that 20 years' service was necessary, the submission of employees
that it would be discriminatory is based on incorrect premise. There is no challenge to the SBI
Pension Rules or SBI−VRS. The bank provided the pensionable service period of 10 years on
attaining the age of 60 years in terms of reservation policy. The bank appoints late entrants like ex−
servicemen who, after serving in Armed Forces, join the bank and are left only with about ten years
of service before they attain the age of superannuation. It is to grant benefit to such a particular
category of employees that a period of 10 years on attaining the age of superannuation of 60 years
was provided in Rule 22(i)(a).
13. The appellants further submitted that 20 years' period is provided in case of voluntary
retirement to ensure that an employee on whom the bank has spent a considerable amount during
training, works for a substantial period before he seeks retirement. It is a uniform policy followed by
the bank. Regulation 28 was amended in 2002 providing for 15 years of service. It applies to the
employees who are governed by the Bank Employees' Pension Regulations, 1995. These regulations
do not apply to SBI employees as the SBI Pension Rules govern them. SBI employees are entitled to
Provident Fund, gratuity and pension in terms of the Rules on completion of 20 years of service.
Thus, there cannot be any comparison of SBI employees with the employees of other nationalisedAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

banks. The clarification dated 11.01.2000 has also been relied on by the bank. Now more than 19
years have passed and to grant a pension to all those who have retired, w.e.f. 1.4.2001 would cast a
huge financial liability on the bank.
14. It was submitted on behalf of the employees that the decision rendered by the High Court is
appropriate. No case for interference is made out in appeals. The very essence of the VRS was the
admissibility of pension on completion of 15 years of service and other benefits. Once the scheme
was adopted and approved by the Central Board of SBI, the clarification could not have been made
to the detriment of employees. The clarification did not have effect of the amendment, modification,
or cancellation of the VRS scheme as approved and adopted by Board. The amendment in the
Pension Regulations of 1995 was carried out by other public sector banks with retrospective effect in
2002, though the scheme was floated and implemented in the year 2000−2001. However, the
benefits were extended on the strength of the VRS scheme even before amending the Regulations of
1995. The SBI adopted the Scheme in toto and Pension Rule 22 providing eligibility of 20 years
applies only to those cases where employees seek retirement in the ordinary course of completion of
10 years or 20 years, as the case may be. The VRS was taken in the specific scheme providing
eligibility and benefits on completion of 15 years of service, and that constituted a concluded
contract. It was not open to the bank to alter the terms. In case the bank's submission is accepted, it
would lead to a situation that employees who have already reached the age of superannuation,
would have been entitled to take VRS. The bank has misled the employees, and the action could not
be said to be fair. Once an offer was accepted and after that to amend the rules or not to amend the
rules till 31.3.2000 depended on exercise of power by SBI which may have the effect to deprive the
pension when the option was not available even to withdraw the offer as it was the last day of the
employment. Rule 22 was amended, that too with retrospective effect. Thus, the employees who
joined service after retirement from other services, have completed the age of 58 years and were in
employment as on 1.11.1993 were entitled to a pension. They have also been deprived of the benefit
of pension, which would have been otherwise available to them. In case pension was not to be paid,
it was not a profitable bargain for them to forego pension only for ex gratia benefit. It was
incumbent upon the SBI to amend the Rule, in case it was necessary to do so. Otherwise, also, the
meaning of the expression “pension” to be paid as per rules was that proportionate pension to be
awarded to the employees with 15 years’ service who were eligible for benefits granted as specified in
the circular and the VRS scheme. The clarification issued on 11.1.2000 only pointed out the
provisions of the VRS scheme as well as the existing position of the rule. It could not have effect to
take away the benefit in any manner which became available to the employees of obtaining the
pension on completion of 15 years of permanent pensionable service. On the one hand, employees
who served for ten years and attained the age of superannuation were entitled to pension and to
deprive the same to a permanent employee who rendered the service for 15 years, would be per se
discriminatory, unfair and arbitrary. Once the scheme was floated and approved, the bank being
State within the purview of Article 12 of the Constitution of India, it would not be permissible for it
to discriminate and act unfairly. The VRS constituted an independent contract and was binding
upon the bank. The benefits could not have been taken away from eligible employees who accepted
VRS, which was implemented by the bank for its benefit to induct new skills as well as to rationalise
the workforce. Thus, appeals being bereft of merit, deserve dismissal.Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

15. The main question is whether, under the scheme as approved and adopted by the Central Board
of SBI, the pension is admissible to the employees on completion of 15 years of permanent service.
Connected question is whether employees have been denied benefit of pension unfairly and
arbitrarily contrary to the essential terms of the scheme.
16. Firstly, it is necessary to consider the nature of the package, which was accepted in the resolution
by the Central Board of Directors of SBI in its meeting dated 27.12.2000. As already mentioned,
exercise was done in order to rationalise the workforce as it was felt that banks were overstaffed.
The IBA advised the SBI regarding the issues confronting the public sector banks. In the
memorandum submitted to the Central Board of Directors of SBI, the following facts were
mentioned as to the adoption of Scheme in right earnest and requirement of manpower planning:
“The data available with IBA indicates that 43% of employees in Public Sector Banks
are in the 46+ age group, and only 12% are in the 25−35 age group. This pattern has
serious implications for the Banks with reference to mobility, training, development
of skills, and succession plans for higher−level positions. This, coupled with excess
manpower wherever it exists, would come in the way of induction of new skills and
proper career progression.
The Committee has recommended the introduction of a Voluntary Retirement
Scheme that would assist the Banks in their effort to optimise their human resources
and achieve a balanced age and skills profile in keeping with their business strategies.
IBA has advised that the Government of India has conveyed that they have no
objection to the banks' placing before their respective Boards of Director's proposals
for adopting and implementing the Voluntary Retirement Scheme. It has been
advised that Banks may adopt the scheme after obtaining their Boards' approval and
implement it in right earnest.” (emphasis supplied) "a) The high establishment costs
of the Bank vis−à−vis the foreign banks and new private sector banks have been a
matter of concern. The percentage of staff expenses to total expenses in the Bank is
21.85 against the percentage of 7.66 and 3.04 for foreign banks and new private
sector banks, respectively. Even if we compare it with other Public Sector Banks, our
ratio is adverse.
d) With the computerisation of accounting and other work at a large number of
branches, manpower, which was needed for balancing of books, is now rendered
surplus. This indicates an imperative need to rationalize the manpower at these
branches. While we have already initiated steps for the productive redeployment of
staff at these branches through shift banking and seven−day banking, there still
exists scope for improvement in this area. Most of these branches are situated in
metropolitan and urban centers. Incidentally, the experience of other banks in
respect of voluntary retirement schemes shows that a maximum number of
applications have been received from these centers.Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

f) As against the average of 43% of employees in Public Sector Banks in the 46+ age
group, we have 47% of the employees in this age group. Of this, 1/5th are in the age
group of 56 and above. To put it simply, 21,824 employees will reach the age of
superannuation and retire by March 2005.
In the light of the above−mentioned factors, it will be seen that the manpower of the Bank will
undergo major changes in the ensuing years in number and deployment. Further, considering the
variety of business the Bank undertakes, and its special role in the banking sector, over−emphasis
on quantitative parameters would be inappropriate. An approach paper on Manpower Planning is
placed at Annexure−‘A’. Considering the various aspects of Manpower Planning, we are of the view
that the Voluntary Retirement Scheme should be employed as a moderate tool to right−size the
manpower in State Bank of India."
In the light of aforesaid, it is clear that the VRS scheme was devised as a tool to reduce overstaffing.
The memorandum submitted to the Central Board contained the following significant aspects:
“Keeping in view the above, the IBA guidelines and the feedback received from other
Banks, the draft ‘SBI Voluntary Retirement Scheme (SBIVRS)’ is prepared and placed
for approval at Annexure−‘B.' It is proposed to introduce SBIVRS for employees who
have as on 31−12−2000, completed 40 years of age or 15 years of service as approved
by the Government of India and conveyed by IBA. In terms of the IBA scheme, the
Banks’ Boards may specify any other category as ineligible. We propose to exclude
the Watch and Ward staff as these positions cannot be reduced. We also propose to
exclude highly skilled and qualified staff from the Scheme.
SBIVRS will be voluntary in nature. The decision to seek retirement under the
Scheme rests with the employee only. The management will retain the discretion as
to whether to accept or not the request for voluntary retirement under the Scheme.
We have to ensure that while, on the one hand, our Bank benefits by the rightsizing of
the staff strength, on the other, any sudden exodus of a very large number of staff
does not destabilise the normal operations of the Bank. Considering the attractive
features of the Scheme, in terms of ex−gratia payment, etc., a large number of
applications are expected. However, the Bank will have to control the outflow
according to its requirements. Towards this end, it will be necessary to retain the
discretion with the management of the Bank to limit the number of employees
allowed to retire in each category of staff to be covered under SBIVRS, and we
propose to retain such discretion."
(emphasis supplied) It was proposed to introduce a VRS for employees who on
31.12.2000, completed 15 years of service as approved by the Government of India
and conveyed by IBA. So, it assumes significance that what was approved and
conveyed, in terms of the IBA scheme, the Banks’ Boards were permitted to specify
any other category as ineligible. The SBI considering its requirement proposed to
exclude the Watch and Ward staff as these positions could not be reduced. It was alsoAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

proposed to exclude the highly skilled and qualified staff from the scheme.
Funds outlay was also proposed in the memorandum submitted to the Central Board as under:
“FUNDS OUTLAY As per the estimate received from Bank's actuary, an outlay of
approximately Rs. 2100 crores would be required for the implementation of SBIVRS
if 10% of the employees opt for retirement. The break−up being as under:
          Ex−gratia                                 Rs.   1300.00 crores
          Leave encashment                          Rs.   180.00 crores
          Additional Provision for Gratuity         Rs.   140.00 crores
          Additional Provision for Pension          Rs.   480.00 crores
(These estimates may undergo a change on receipt of clarification from Government
of India as to the components of ‘Pay’ for the purpose of Ex−gratia)” A provision was
made for the pension. The bank reserved the right to modify, amend or cancel any or
all the clauses. The Deputy Managing Director and CDO would be the competent
authority.
Following is the relevant clause regarding modification of the scheme:
“MODIFICATION OF THE SCHEME Bank reserves the right to modify, amend or
cancel any or all the clauses of the Scheme and to give effect thereto from any date it
may deem fit. The Dy. Managing Director and CDO would be the Competent
Authority for the purpose.” The effective date of retirement was 31.3.2001. The
relevant clause is extracted hereunder:
“EFFECTIVE DATE OF RETIREMENT While the SBIVRS will be open to employees
from 15th January 2001 to 31st January 2001 (both days included), the retirement
under SBIVRS is proposed to be given effect from 31 st March 2001."
17. The letter dated 31.8.2000 annexed to memorandum submitted to the Central Board of the SBI
is also of utmost significance in order to understand what was accepted by the Central Board. The
relevant portion of the letter dated 31.8.2000 of IBA is extracted hereunder:
“Attention is invited to letter DO No. 11/1/99−IR dated 22.05.2000, addressed to the
Chief Executive of public sector banks by the Government of India, Ministry of
Finance (Banking Division), wherein banks have been advised to carry out detailed
manpower planning in order to adopt measures to have optimum human resource at
various levels in keeping with the business strategies and requirements of each bank.
At the meeting the Finance Minister had with Chief Executives of public sector banks on 13th June
2000, the human resource and man−power planning in public sector banks were reviewed, and a
Committee was constituted to examine the issues confronting public sector banks in that regard andAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

suggest suitable remedial measures."
“In order to remedy this situation with the urgency that circumstances demand, the Committee has
placed before the Government two schemes, viz., Sabbatical Leave and a Voluntary Retirement
Scheme that would assist the banks in their effort to optimise their human resource and achieve a
balanced age and skills’ profile in keeping with their business strategies. Salient features of the two
schemes are given in the Annexure.
IBA, vide its letter dated 13th July 2000, has sought no objection from the Government for
circulating the schemes to the Banks for consideration and adoption by their Boards. The
Government have conveyed to us that they have no objection to the banks' placing the two schemes
before their respective Board of Directors for adopting and implementing the above schemes. It has
been advised that the Banks may adopt these schemes for sabbatical and voluntary retirement based
on the essential features of the schemes given in the Annexure, after obtaining their Board’s
approval and implement them in right earnest.” (emphasis supplied) “Banks are also requested to
take special note of the following:
1. Section 10(10C) of the Income Tax Act read with Rule 2BA.
2. As per the amendments brought in by the Finance Act 2000, so long as the bank
complies with the rules framed under Section 10(10C), prior approval from the Chief
Commissioner or Director General of Income−tax, as the case may be, is not required
for VRS.
3. Income−tax shall be deducted at source in respect of ex−gratia exceeding Rs.5.00
lakhs or such other ceiling as may be prescribed under the Income−tax Act.
4. Only completed years of service will be reckoned for arriving at the minimum
eligible service. Subject to this, fraction of service of six months and above will be
reckoned as one year for the purpose of calculating the ex−gratia.
5. While exercising discretion to decline applications for VRS or to make exceptions
in the case of employees categorised as ineligible for VRS, the decision should not be
discriminatory among employees who are similarly placed and the reasons therefor
should be recorded.
6. The competent authority for accepting VRS for the various categories/class of
employee should be clearly laid down by the Board of Directors.
7. Banks should ensure compliance with requirements under labour legislations
before giving effect to the Scheme.”
18. IBA’s letter dated 31.8.2000 makes clear the salient features of the VRS scheme that all
permanent employees with 15 years of service were eligible to retire. Ineligible persons have alsoAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

been specified. In unqualified terms, it was mentioned in the annexures that such employees would
be entitled to the amount of ex gratia of 60 days’ salary for each completed year of service or salary
for the number of months service is left, whichever is less. Other benefits admissible were gratuity,
pension including the commuted value of pension, bank's contribution towards provident fund, and
leave encashment as per rules. Thus, scheme was to grant pension to all such employees who opted
for VRS on completion of 15 years of service and other benefits as specified in the scheme. The
Government of India, Ministry of Finance, Department of Economic Affairs, (Banking Division),
that it communicated approval vide letter dated 29.8.2000 to IBA, it was sent to the SBI also, the
same is extracted hereunder:
“F. No. 11/1/99−IR (Vol.II) Government of India Ministry of Finance Department of
Economic Affairs (Banking Division) New Delhi, dated the 29th August 2000 To The
Chairman Indian Banks‘ Association MUMBAI Sub:− Human Resource Management
and Manpower Planning in Public Sector Banks−Introduction of a Voluntary
Retirement Scheme/Scheme for Sabbatical Leave.
Sir, I am directed to refer to IBA's letter No. PD/ACAP/GOVT/521 dated 13th July
2000 sending therewith a copy of the interim report of the Committee on Human
Resource Management in Public Sector Banks and requesting for no objection from
the Government for circulating to banks Voluntary Retirement Scheme and Scheme
for granting Sabbatical Leave for consideration and adoption by their Boards, and to
say that Government has no objection to the proposals contained therein.
2. The draft circular letter sent by IBA has been slightly modified. Copy of the
modified draft is enclosed herewith.
3. It is requested that a copy of the circular issued to the banks may please be sent to
Banking Division for record.
Yours faithfully Sd/− (U.P. SINGH) DIRECTOR (IR)”
19. The agenda submitted on 27.12.2000 for consideration of the Central Board of SBI along with
resolution are extracted as under:
“AGENDA NO.3 Man− Power Planning and SBI Voluntary Retirement Scheme (SBI
VRS) Submitted Memorandum dated the 26th December 2000 by the Deputy
Managing Director & Corporate Development Officer, recommending that for the
reasons stated therein, approval be accorded for the proposals contained in the
Memorandum as also for adopting the stated approach to manpower planning and
introduction SBIVRS in terms of the provisions contained in the Scheme at Annexure
‘B‘ of the Memorandum.
Copies of the Memorandum were placed before the Directors present at the Meeting.Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

‘‘APPROVED” (SEAL)
20. Annexure ‘B’ to the memorandum contained the VRS. The VRS was prepared in view of the
guidelines of the IBA. The amount of ex gratia and other benefits specified in the scheme under
clauses 5/ 6 of the scheme are extracted hereunder:
“5. Amount of Ex−gratia:
The staff members whose request for retirement under SBIVRS has been accepted by
Competent Authority will be paid an amount of ex−gratia of 60 days‘ salary (pay plus
stagnation increments plus dearness allowance) for each completed year of service
(for this purpose fraction of service of six months and above will be taken as one year
and accordingly service of less than six months will not be counted) or salary for the
number of months service is left, whichever is less. Fraction of a month, if any, will be
ignored.
‘Relevant Date‘ means the date on which the employee ceases to be in service of the
Bank as a consequence of the acceptance of the Bank as a consequence of the
acceptance of the request for voluntary retirement under the Scheme. For the
purpose of calculation of ex−gratia, 60 days‘ salary mentioned in the Scheme is to be
taken as equivalent to 2 months‘ salary (with reference to salary for the month in
which employee is relieved from service on Voluntary Retirement.
Income Tax shall be deducted at source in respect of ex−gratia exceeding Rs. 5.00
lakhs or such other ceiling as may be prescribed under the Income Tax Act on the
relevant date.“ The benefits were as under:
“6. Other benefits
(a) Gratuity as payable under the extant instructions on the relevant date.
(b) Provident Fund contribution as per State Bank of India Employees‘ Provident
Fund Rules as on relevant date.
(c) Pension in terms of State Bank of India Employees‘ Pension Fund Rules on the
relevant date (including commuted value of pension).
(d) Encashment of balance of Privilege Leave, as applicable, on the relevant date.
(e) Respective facilities extended to officers/others such as retention of
accommodation, telephone, car, continuation of housing loan, etc. will be extended to
officers. Others retiring under SBIVRS as per present dispensations, at the discretion
of Competent Authority. However, in such cases of retention of physical facilities,
50% of the amount of ex−gratia payable will be released only after the employeeAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

surrenders the facility. No interest, however, will be paid for the amount so withheld.
All other outstanding loans/advances will have to be repaid before date of retirement
under SBIVRS, failing which the amount of ex−gratia and other terminal benefits
payable to the employee will be appropriated towards the outstanding
loans/advances;
and the balance only will be payable to the employee.”
21. Most significantly, the scheme of the IBA, accepted by the Board on 27.12.2000, was for
providing pension on completion of 15 years of service. The pension specified in clause 6 of scheme
was to be worked out in terms of the Pension Fund Rules including the commuted value of the
pension. It was not mentioned in the VRS adopted by the SBI that the person on completion of 15
years would not be entitled to the benefit of pension. On the other hand, proposal of IBA, as
approved by the Government of India, was accepted in toto by SBI. When gauged in terms of the
proposals of the IBA, the essential feature was that an employee was entitled to get pension on
completion of 15 years of service. The meaning of the expression "pension” in terms of the rules
would be proportionate pension on completion of 15 years of service as per the terms of calculation
provided in Rule 23 of the Pension Rules. VRS is an independent contract and the background in
which it was floated, pension on completion of 15 years of service was an essential part of the
scheme of VRS 2000, as approved by the Government and floated by the IBA and adopted by all the
Banks, and Pension Rules were to be amended accordingly.
22. The Government of India suggested to the IBA to amend Regulation 29 of the Regulations of
1995 so that the employees do not lose the benefit of pension, the IBA may work out modalities and
suggest amendments, if any, required to be made in the Pension Regulations to ensure that the
employees get the benefit of pension. The letter dated 5.9.2000 of Government of India is extracted
hereunder:
“F. No. 4/8/4/2000−IR Government of India, Ministry of Finance, Department of
Economic Affairs (Banking Division) New Delhi, 5−9−2000 To The Personnel
Advisor, Indian Banks’ Association, Mumbai Sub.: Amendment to Regulation 29 of
the Pension Regulations. Sir, I am directed to refer to this Division's Letter No.
11/1/99 IR dated 29−8−2000, conveying the Government's no objection for
circulation of Voluntary Retirement Scheme in public sector banks. The Scheme,
inter alia, provides that employees with 15 years of service or 40 years of age shall be
eligible to take voluntary retirement under the Scheme. As per the provisions
contained in Regulation 29 of the Pension Regulations, an employee can take
voluntary retirement after 20 years of qualifying service and thereafter becomes
eligible for pension.
Thus, employees having rendered 15 years of service or completing 40 years of age but not having
completed 20 years of service shall not be eligible for pensionary benefits on taking voluntary
retirement under the Scheme.Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

In order to ensure that such employees do not lose the benefit of pension, IBA may work out
modalities and suggest amendments, if any, required to be made in the Pension Regulations to
ensure that these employees also get the benefit of pension.
Yours faithfully, sd/− (U.P. Singh) Director (IR)”
23. SBI issued a circular on 10.1.2001 with respect to the withdrawal of the application submitted
under the scheme. It was decided that the employee could withdraw the application on or before
15.2.2001 by making a written request.
24. Clarification was issued on 15.1.2001 to a query raised, whether or not the employees on
completing 15 years of pensionable service would be entitled to pensionary benefits. Following is a
relevant portion:
“3. Whether or not the employees, completing 15 years of pensionable service as on
relevant date (date of retirement under SBIVRS), will be entitled for pension
benefits?
In this connection, we invite a reference to para 6(c) of the Scheme forwarded under
the cover of Staff Circular letter No. CDO/81 dated 30/12/2000. The payment of
pension to the employee retiring under SBIVRS would be governed by State Bank of
India Employees Pension Fund Rules on the relevant date (including commuted
value of pension). However, as per existing rules, employees who have not completed
20 years of Pensionable Service are not eligible for pension.” It is clear from answer
that the staff circular dated 30.12.2000 was reiterated. Payment of pension to an
employee retiring under VRS would be governed by rules on the relevant date, i.e.,
31.3.2001. At the same time, the position of the existing rule was indicated that those
employees who had not completed 20 years of pensionable service were not eligible
for a pension. It was not clarified what was the meaning and purport of para 6(c) of
the scheme. It was not mentioned that an employee would not be entitled to pension
on 15 years of service as per the scheme approved by the Government of India and
floated by the IBA and adopted by the Central Board of SBI.
The above clarification being in form of opinion, could not be said to have caused a
modification, amendment, or cancellation of any of the clauses of VRS or resolution
passed by the Board, nor it was so stated.
It was necessary to state that on completion of 15 years of service, employees would
not be paid pension. The existing rule position was known to everybody, whereas the
scheme was framed for providing pension on completion of 15 years of service.
25. Rule 22 of the Pension Rules of SBI as it existed up to 9.3.2001 and amended are extracted
hereunder:Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

Existing Rule “22(i) A member shall be entitled to a pension under these rules on
retiring from the Bank’s service−
(a) After having completed 20 years' pensionable service provided that he has
attained the age of 50 years or if he is in the service of the Bank on or after 01.11.93,
after having completed ten years pensionable service provided that he has attained
the age of 58 years.
(b) After having completed twenty years' irrespective of the age he shall have attained
if he shall satisfy the authority competent to sanction his retirement by approved
medical certificate or otherwise that he is incapacitated for further active service;
(c) After having completed twenty years pensionable service, irrespective of the age
he shall have attained at his request in writing;
(d) After twenty−five years' pensionable service.“ Amended Rule “22(i) A member
shall be entitled to a pension under these rules on retiring from the Bank’s service−
(a) After having completed twenty years' pensionable service provided that he has
attained the age of fifty years or if he is in the service of the Bank on or after 01.11.93,
after having completed 10 years, pensionable service provided that he has attained
the age of fifty−eight years or if he is in the service of the bank on or after 22.05.1998.
After having completed ten years, pensionable service provided that he has attained
the age of sixty years.
(b) After having completed twenty years' pensionable service, irrespective of the age
he shall have attained if he shall satisfy the authority competent to sanction his
retirement by approved medical certificate or otherwise that he is incapacitated for
further active service;
(c) After having completed twenty years pensionable service, irrespective of the age
he shall have attained at his request in writing;
(d) After twenty−five years' pensionable service."
26. It is clear from Rule 22 that pension is admissible to an employee thus:
1) After having completed 20 years’ pensionable service provided that he has attained
the age of 50 years; or
2) If he is in the service of the Bank on or after 01.11.1993, after having completed 10
years pensionable service provided that he has attained the age of 50 years; orAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

3) If he is in the service of the Bank on or after 22.05.1998, after having completed 10
years pensionable service provided that he has attained the age of 60 years.
27. Rule 22(1)(c) was incorporated in the Pension Fund Rules w.e.f. 20.9.1986 when the bank
decided inter alia to introduce VRS on completion of 20 years of service. The unamended rule
22(i)(a) provided the normal age of retirement to be 58 years. Thereafter, as per the guidelines
issued by the Government on 22.5.1998, the age of retirement was increased from 58 to 60 years.
Accordingly, Rule 22(i)
(a) was proposed to be amended on 30.1.2001, and instead of 58 years, the age of retirement of 60
years was to be incorporated. On 28.5.1998, the Executive Committee of the Central Board of SBI
pending amendment to the related service rules adopted the age of retirement as 60 years. The
amendment was notified on 31.3.2001 and approved by the Trustees of the SBI Employees’ Pension
Fund on 30.10.2001.
28. Similar scheme of VRS concerning nationalised banks was implemented according to the
decision of the Government of India. In Punjab & Sind Bank, it was to remain open from 1.12.2000
to 31.12.2000; Punjab National Bank: 1.11.2000 to 30.11.2000; Bank of India: 15.11.2000 to
14.12.2000; Union Bank of India: 1.12.2000 to 31.12.2000; United Bank of India: 1.1.2001 to
31.1.2001. In SBI, the said scheme was adopted by the Central Board on 27.12.2000.
29. The State Bank of India was constituted under the SBI Act, 1955. The nationalised banks were
taken over in terms of the Banking Companies (Acquisition and Transfer of Undertakings) Act,
1970. Under the Act of 1970, the Punjab National Bank (Employees) Pension Regulations, 1995,
were framed. Regulation 28, provided pension on attaining the age of superannuation, and
Regulation 29 provided pension on voluntary retirement on completion of 20 years of qualifying
service. Regulation 29(5), applicable to the banks mentioned above, provided that the qualifying
service of an employee retiring voluntarily under the Regulation shall be increased by a period not
exceeding five years, subject to the condition that the total qualifying service rendered by such
employee shall not exceed 33 years.
30. The VRS 2000 came up for consideration before this Court in Bank of India & Ors. v. O.P.
Swarnakar & Ors., (2003) 2 SCC 721 in the context of Regulation 29(5) of Regulations, 1995. The
Court held that the scheme is contractual and provided for pensionary benefits on completion of 15
years of service. The decision was followed in HEC Voluntary Retd. Employees Welfare Society v.
Heavy Engineering Corporation Ltd., (2006) 3 SCC 708.
31. Due to introduction of Scheme, Regulation 28 of Regulations of 1995 was proposed to be
amended. It was amended in the year 2002 with a retrospective effect from 1.9.2000. By way of
amendment, a proviso has been inserted in Regulation 28 thus:
“28. Superannuation pension.—Superannuation pension shall be granted to an
employee who has retired on his attaining the age of superannuation specified in the
Service Regulations or Settlements.” “Provided that pension shall also be granted toAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

an employee who opts to retire before attaining the age of superannuation, but after
having served for a minimum period of 15 years in terms of any scheme that may be
framed for the purpose by the Bank’s Board with the concurrence of the
Government.” (emphasis supplied)
32. The employees who opted for VRS on completion of 15 years of service within the specified
period in 2000/2001, were given the benefit of pension. The Regulations came to be amended in
2002 with the retrospective effect. However, the benefit under Regulation 29(5) was not extended to
the optees/employees who completed 20 years of service by adding 5 years of qualifying service.
Regulations 29(1) and 29(5) applicable to the said banks are extracted hereunder:
“29. Pension on voluntary retirement.—(1) On or after the 1st day of November 1993
at any time, after an employee has completed twenty years of qualifying service he
may, by giving notice of not less than three months in writing to the appointing
authority retire from service:
Provided that this sub−regulation shall not apply to an employee who is on
deputation or on study leave abroad unless after having been transferred or having
returned to India he has resumed charge of the post in India and has served for a
period of not less than one year:
Provided further that this sub−regulation shall not apply to an employee who seeks
retirement from service for being absorbed permanently in an autonomous body or a
public sector undertaking or company or institution or body, whether incorporated or
not to which he is on deputation at the time of seeking voluntary retirement:
Provided that this sub−regulation shall not apply to an employee who is deemed to
have retired in accordance with clause (1) of Regulation 2.
xxx (5) The qualifying service of an employee retiring voluntarily under this
Regulation shall be increased by a period not exceeding five years, subject to the
condition that the total qualifying service rendered by such employee shall not in any
case exceed thirty−three years and it does not take him beyond the date of
superannuation.”
33. The scheme in question came up for consideration in O.P. Swarnakar & Ors. (supra), in which
SBI was one of appellants in C.A. Nos.3561−65/2002, the appeals were decided by this Court by a
common judgment. It noted that reference to pension as per rules was made for computation of
pension, and the employees who had completed 15 years of service were to be extended the benefit
of VRS 2000 along with pension and other benefits. IBA wrote a letter dated 11.12.2000 to all public
sector banks for amending Pension Regulations, 1995. The IBA mentioned that pension was to be
paid to the employees as per VRS 2000. They would be eligible for pro−rata pension; as such,
Regulation 28 be amended. The employees who applied for voluntary retirement after having
rendered 15 years’ service, under a special/ad hoc scheme formulated with the specific approval ofAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

the Government and the Board of Directors would be eligible for pro−rata pension for the period of
service rendered as if they were to retire on attaining the age of superannuation on that date. The
letter made it clear that the Government of India approved the pension to be given on completion of
15 years of service. The scheme was for extending the benefit of pension to the employees retiring on
completion of 15 years of permanent service, and the Government of India also desired that the IBA
advised banks to make necessary amendments to their pension regulations, as mentioned in the
Annexure. Thus, the essence of the VRS scheme was the benefit of pro−rata pension as per the rules
on completion of 15 years of pensionable service.
34. It is apparent that the very fulcrum of the scheme was a felt need for inducting new workforce,
with adequate knowledge of new skills such as modern technology, foreign exchange, venture
capital, e− commerce, money management, etc. as pointed out by the Ministry of Finance in its
letter dated 22.5.2000. The banks were overstaffed and for effective management and manpower
planning, the desirability of introducing VRS was felt in order to rationalise the workforce and skill.
Hence a Committee was constituted by the Central Government. In pursuance of report of the
Committee, a policy decision was taken to frame the VRS. The scheme applied to employees who, on
the date of the application, completed 15 years of service. The employees specified therein were
otherwise not eligible to seek voluntary retirement on completion of 15 years under the
rules/regulations. Under the scheme floated by the other banks, identical reliefs were admissible, as
in SBI VRS. The Scheme of Punjab National Bank is extracted hereunder:
“7. x x x “Amount of ex gratia An employee seeking voluntary retirement under the
Scheme will be entitled to the ex gratia amount mentioned below in para (a) or (b),
whichever is less:
(a) 60 days’ salary (pay plus stagnation increments plus special pay plus dearness
relief) for each completed year of service;
OR
(b) salary for the number of months of service left;
Other benefits An employee seeking voluntary retirement under the Scheme will be eligible for the
following benefits in addition to the ex gratia amount mentioned in para 6 above of this Scheme:
(i) Gratuity as per the Payment of Gratuity Act, 1972 or gratuity payable under the
Service Rules, as the case may be, as per existing rules.
(ii)(a) Pension (including commuted value of pension) as per PNB (Employees)
Pension Regulations, 1995.
OR
(b) Bank’s contribution towards PF as per existing rules.Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

(iii) Leave encashment as per existing rules.” (emphasis supplied)
35. The eligibility criteria in all the schemes, including SBI VRS, clearly provided that employees
who completed 15 years of service and particular age shall be eligible to apply. The benefits to which
they were entitled, were culled out. In other banks, the pension was as per Pension Regulation, 1995.
Thus, on eligibility of an employee, admissibility of the available reliefs in Scheme followed i.e., the
amount of ex gratia and other benefits, including pension, were to be paid as provided in the
scheme. Otherwise, there was no purpose of retiring an employee with 15 years of service as they
were not eligible for retirement as per the rules before completion of 20 years of service in all
nationalised banks as well as SBI. A reference to the admissibility of the pension as per rules/
regulations was made in all the VRS to mean that proportionate pension shall be admissible as
provided in rules, this Court has noted it in O.P. Swarnakar (supra), thus:
“49. An offer indisputably can be made to a group of persons collectively which is
capable of being accepted individually, but the question which has to be posed and
answered is as to whether having regard to the service jurisprudence; the principles
of the Indian Contract Act would be applicable in the instant case. It is the specific
case of the “banks” that the Schemes had been floated by way of contract. It does not
have any statutory flavour. Reference to the Pension Scheme framed under the
Regulations was made for computation of the pension.” (emphasis supplied)
36. Significantly in O.P. Swarnakar (supra), this Court observed that employees must have
proceeded to apply for VRS on the basis even though they have merely completed 15 years of service,
which was not a qualifying service, under the Pension Regulations of Bank, they would be entitled to
benefits in terms of the VRS scheme. The Court observed thus:
“89. Furthermore, a large number of employees have withdrawn their offer only
when a proviso was sought to be added to Regulation 28 aforementioned. In terms of
the Scheme the employees, who expected to get benefits of sub− regulation (4) of
Regulation 29 would be deprived therefrom. It is not in this dispute that the
qualifying period for receiving pension was 20 years. Only upon completion of 20
years, in terms of the statutory regulation contained in Regulation 29, an employee
could opt for voluntary retirement, and in terms thereof, he would be entitled to the
benefits specified therein. The said Regulations had specifically been mentioned for
the purpose of computation, which would include invocation of sub−regulation (4) of
Regulation 29, providing for relaxation of 5 years towards the qualifying period. The
employees must have proceeded on the basis that despite the fact that they have
merely rendered 15 years of service, which was not a qualifying service under the
Regulations, they would be entitled to the pensionary benefits in terms of the
Scheme. By introducing the proviso to Regulation 28 pension was sought to be made
pro rata in place of full pension.” (emphasis supplied)
37. In O.P. Swarnakar & Ors. (supra), it was held that the scheme was not a part of statutory
regulations. It was in the realm of contract. That being so, the Central Government did not need toAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

place the same before Parliament; and secondly, if the same was a regulation, the laying−down rule
is merely directory and not mandatory. This Court relied upon the decisions in Jan Mohd. Noor
Mohd. Bagban v. State of Gujarat, AIR 1966 SC 385 and Atlas Cycle Industries Ltd. v. State of
Haryana; 1979 (2) SCC 196 and held that the scheme could not be said to be bad in law, thus:
“124. Firstly, the Scheme is not a part of the statutory regulation. It was in the realm
of contract. That being, so it was not necessary for the Central Government to place
the same before Parliament.
125. Secondly, even if the same was a regulation, the laying− down rule is merely a
directory one and not mandatory.
126. In Jan Mohd. case, AIR 1966 SC 385, the law is stated in the following terms:
(AIR pp. 394−95, para 18) “18. Finally, the validity of the rules framed under Bombay
Act 22 of 1939 was canvassed. By Section 26(1) of the Bombay Act, the State
Government was authorised to make rules for the purpose of carrying out the
provisions of the Act. It was provided by sub−section (5) that the rules made under
Section 26 shall be laid before each of the Houses of the Provincial Legislature at the
session thereof next following and shall be liable to be modified or rescinded by a
resolution in which both Houses concur, and such rules shall, after notification in the
Official Gazette, be deemed to have been modified or rescinded accordingly. It was
urged by the petitioner that the rules framed under Bombay Act 22 of 1939 were not
placed before the Legislative Assembly or the Legislative Council at the first session,
and therefore they had no legal validity. The rules under Act 22 of 1939 were framed
by the Provincial Government of Bombay in 1941. At that time, there was no
Legislature in session, the Legislature having been suspended during the emergency
arising out of World War II. The session of the Bombay Legislative Assembly was
convened for the first time after 1941 on 20−5−1946, and that session was prorogued
on 24−5−1946. The second session of the Bombay Legislative Assembly was
convened on 15−7−1946, and that of the Bombay Legislative Council on 3−9−1946
and the rules were placed on the Assembly Table in the second session before the
Legislative Assembly on 2−9−1946 and before the Legislative Council on 13−9−1946.
Section 26(5) of Bombay Act 22 of 1939 does not prescribe that the rules acquired
validity only from the date on which they were placed before the Houses of
Legislature. The rules are valid from the date on which they are made under Section
26(1). It is true that the Legislature has prescribed that the rules shall be placed
before the Houses of Legislature, but failure to place the rules before the Houses of
Legislature does not affect the validity of the rules, merely because they have not
been placed before the Houses of the Legislature. Granting that the provisions of
sub−section (5) of Section 26 by reason of the failure to place the rules before the
Houses of Legislature were violated, we are of the view that sub−section (5) of
Section 26 having regard to the purposes for which it is made, and in the context in
which it occurs, cannot be regarded as mandatory. The rules have been in operation
since the year 1941, and by virtue of Section 64 of Gujarat Act 20 of 1964, theyAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

continue to remain in operation."
127. In Atlas Cycle Industries' case, (1979) 2 SCC 196, the same view has been
reiterated.
128. We, therefore, are of the opinion that the Scheme in question cannot be said to
be bad in law.”
38. The Court concerning the provision of withdrawal held that the relevant clause of the scheme
created an enforceable right in case the State Bank failed to adhere to its preferred policy.
39. In our opinion, the reference in the SBI VRS to the admissible benefits, like pension shall be as
per the pension rules, was for the purpose of computation of pension. It is apparent from a reading
of the scheme that proportionate pension was admissible to employees as noted in para 49 of O.P.
Swarnakar & Ors. (supra). A similar expression was used in the schemes of nationalised banks also.
This Court has noted expression in the scheme that pension as per rules to mean for computation of
pension. The formula for computation for a pension is provided in Rule 23 of the SBI Pension Rules.
40. It is of utmost significance that the Central Board in its meeting dated 27.12.2000 accorded
approval “for the proposals contained in the Memorandum.” A bare perusal of the memorandum
makes it clear that the letter of IBA dated 31.8.2000 was enclosed as part of the memorandum
submitted to the Central Board. In the memorandum, it was mentioned "that the Government of
India conveyed that they had no objection to the banks' placing before their respective Boards of
Director's proposals for adopting and implementing the Voluntary Retirement Scheme. It advised
that Banks may ‘adopt’ the scheme after obtaining their Boards' approval and implement it in ‘right
earnest’." The memorandum also contained that the employees who completed 15 years of service
were to be the beneficiaries of VRS as approved by the Government of India and conveyed by the
IBA. The approval by Government of India and scheme, conveyed by IBA, was to provide for the
benefit of pension on completion of 15 years of service. The same was an essential condition of the
scheme. The Annexure, which was part of the memorandum, provided inter alia the benefit of
pension, including the commuted value of pension without any rider of completion of 20 years
period of service. Once SBI accepted the proposals contained in the memorandum, when we gauge
the scheme in the light of the subject matter of the memorandum which was unconditionally
approved, it became clear and beyond the pale of doubt that in VRS (Annexure B) inasmuch as the
expression to provide the benefit of pension as per rules was only for providing the proportionate
pensionary benefit of the qualifying service on and above 15 years, rendered by an employee.
41. The IBA advised the banks for amending the rules. The Government of India, Ministry of
Finance, also issued a letter dated 5.9.2001 to the Bank to amend the rules. There was a proposal to
amend the rules. After the scheme was implemented in 2000, the nationalised banks, including the
Punjab National Bank, amended their rules in 2002 with retrospective effect. However, the fact
remains the VRS schemes were implemented by banks governed by the Banking Companies Act,
1970, by making payment of pension though Regulation 28 of Regulation of 1995 provided for 20
years of qualifying service at the relevant time. Once a particular scheme of VRS, based on theAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

recommendations of Committee formed by Government of India, was formulated and floated by
IBA. In all fairness, it was required to be implemented in right earnest in that form in which it was
approved and adopted by the Board of Directors of SBI on 27.12.2000. In case the Board of
Directors were of the opinion that the scheme was not acceptable to them, they could have rejected
it or could have stated they reject the proposal for paying pension on completion of 15 years of
service which was the essence of a scheme formed to reduce workforce of Bank and for achieving
other objectives. Nonetheless, on the contrary, resolution dated 27.12.2000 indicates that the
proposals of IBA/Government was approved unconditionally. Thus, in case it was so necessary to
amend the pension rules as done by other banks, it was incumbent upon the State Bank of India to
amend its rules either after implementation of the scheme as was done by other banks or before
giving effect to VRS.
42. It is also significant to mention that SBI accepted the scheme as approved by the Government
and floated by IBA. In case SBI had declined to accept or wanted to modify, it was necessary for it to
take approval of Government of India as to its scheme. As per section 49, the Central Government
has the power to make rules. Section 50 deals with the power of Central Government to make
regulations. Section 50(1) provides that the Central Board, after consultation with the Reserve Bank
of India and with the previous sanction of the Central Government, can make Regulations. Under
Section 50(2)(o), the Regulations can be made by the Central Board with the previous sanction of
the Central Government with respect to superannuation pension and other funds for the benefit of
the employees of the State Bank. Section 50(2)(o) reads:
“50. Power of Central Board to make regulations.—(1) The Central Board may, after
consultation with the Reserve Bank and with the previous sanction of the Central
Government [by notification in the Official Gazette,] make regulations, not
inconsistent with this Act and the rules made thereunder, to provide for all matters
for which provision is expedient for the purpose of giving effect to the provisions of
this Act.
(2) In particular, and without prejudice to the generality of the foregoing power, such
regulations may provide for— xxx
(o) the establishment and maintenance of superannuation pension, provident or
other funds for the benefit of the employees of the State Bank or of the State Bank or
of the dependents of such employees or for the purposes of the State Bank, and the
granting of superannuation allowances, annuities and pensions payable out of any
such fund;]”
43. Thus, it is apparent that the Central Board of SBI could not have framed a scheme different than
the one approved by the Central Government on its own, nor could have implemented it without
approval of the Central Government. In case it wanted to modify or amend the scheme, as approved
by the Government of India, it was incumbent upon it to send its modified scheme to the Central
Government for approval. No scheme for VRS could have been framed without approval of the
Government of India. In fact, the Central Board accepted the proposal of IBA, as approved by theAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

Government of India. In case SBI’s stand is accepted, its scheme would have been valid as no
modification could have been made without approval of the Government of India. In fact, no such
modification was made, as held above.
44. Once it approved the Scheme SBI being an instrumentality of State under Article 12, is bound by
the principle of fairness and representation made that it accepted the contents of memorandum and
the scheme floated by IBA and invited the applications based on approving the memorandum which
contained proposal of pension on rendering 15 years of permanent pensionable service, it could not
later on wriggle out of its obligation taking a rigmarole by claiming shelter of the Rules or by not
amending the Rules or by issuing a clarification which was fanciful, irrational and contrary to the
spirit of the resolution of the Board. It would amount to an unfair and unreasonable action to
deprive the employees of the benefit of pension because of the decision taken by the Central Board
of Directors.
45. SBI is bound by resolution of Central Board of Directors. The Scheme was with the approval of
the Government of India and accepted, implemented by all the banks in true spirit except by SBI. It
cannot be permitted to act unfairly by virtue of having superior bargaining power by issuing vague
clarification to the detriment of the economic interest of the employees. Clarification did not have
the effect of re−writing or superseding the resolution of the Central Board nor effect of making
modifications in the resolution passed by the Central Board of the SBI.
46. The VRS scheme was not floated by the SBI on its own volition. It was pursuant to an exercise
that was undertaken by the IBA in view of the recent developments of modern technology
considering the age group of the employees in the bank, the need to have a new skill, and to
rationalise the manpower; a decision was taken. It was decided at the Government level to provide
pension after completion of 15 years of service as a special measure, the banks were bound to
implement it in that manner or not at all. The Central Board of Directors of the SBI accepted the
VRS proposal of Government and IBA without any reservation of not providing pension along with
other benefits, as mandated in the VRS scheme. The action of the instrumentality of the State
cannot be violative of Article 14. It cannot be permitted to act arbitrarily. Articles 15 and 16 provide
for equality and provide for an umbrella against discrimination.
47. Though the Deputy General Manager was authorised by the Central Board of Directors to
amend, modify or cancel the VRS. The Rules were amended by other banks later in 2002. It was not
stated in answer to the query that under the VRS scheme, a person who has rendered 15 years of
qualifying service would not be entitled to a pension. Nor it was so stated in resolution dated
27.12.2000 of the Central Board of SBI. That apart, Deputy General Manager tried to interpret VRS
scheme in isolation without considering what was approved by the Board. Not only the scheme but
also the memorandum have to be read together to understand resolution of Board. Once the
memorandum containing the IBAs proposal of providing pension was approved in absolute terms,
the clarification could not be of any value to dilute the otherwise clear and unambiguous resolution
of the Board of Directors. The Deputy General Manager did not have any such wide and arbitrary
power to defeat the claim of the employees for pension on completion of 15 years of permanent
service, which was their right. The action of D.G.M. could not be said to be in accordance with theAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

resolution. The pension was the essence of the scheme, depriving it could not be said to be
authorised, such action can only be termed as unfair and unreasonable and patently violative of
Articles 14, 16, and 21 of the Constitution of India.
48. Yet another aspect which cannot be lost sight is that the bank mentioned in the scheme that the
benefit would be admissible as per the rule which prevails on the appointed day, i.e., 31.3.2001.
Thus, it is apparent that when VRS scheme was floated, it was in contemplation of amendment of
rules which was suggested by the IBA and the Government of India in its communication dated
5.9.2001 so that employees were not deprived of the benefit of pension.
49. The question arises in case the bank accepts the proposal of VRS, and does not alter its rules, can
employees be deprived of the benefit of pension in such an unconscionable manner over an event on
which they had no control. It would be nothing, but an outcome of unfair and arbitrary act in case
the SBI never intended to act upon the scheme it ought not to have accepted it, and once it approved
VRS, it was incumbent upon it to amend its rule, if necessary, as was done by other banks in 2002
after scheme worked out in the year 2000. Even otherwise once it accepted the proposal of the
Government of India, it would be violative of provisions of Articles 14 and 16 to permit it to wriggle
out of its obligation under the guise that the bank did not amend its rules or pension was not
admissible as per existing rules, mainly when the scheme provided for eligibility for pension on
completion of 15 years, that formed independent contract. If the bank is permitted to get rid of the
scheme due to Rule position, then the scheme itself would become void and unenforceable. Bank
cannot act in a fanciful manner, particularly with respect to retirement under VRS which was
contractual and deny benefit of pension, a right accrued to the employees for receiving the pension
in view of the memorandum and the resolution passed by the Central Board of Directors adopting
memorandum and the SBI−VRS.
50. (a). The rights under contract cannot be taken away, and they become enforceable by a court of
law. Bank cannot be permitted to make a representation and later on wriggle out of its obligation. It
is not permissible to make a “misrepresentation”. Under section 19 of the Contract Act, when
consent is obtained by coercion, fraud, or ‘misrepresentation,' the agreement is voidable at the
option of the aggrieved party. In Central Inland Water Transport Corporation Ltd. & Anr. v. Brojo
Nath Ganguly & Anr., (1986) 3 SCC 156, this Court considered the contract of employment between
the Central Inland Water Transport Corporation and its employees and also the rules. In that
context, observed thus:
“75. Under Section 19 of the Indian Contract Act, when consent to an agreement is
caused by coercion, fraud or misrepresentation, the agreement is a contract voidable
at the option of the party whose consent was so caused. It is not the case of either of
the contesting respondents that there was any coercion brought to bear upon him or
that any fraud or misrepresentation had been practiced upon him. Under Section 19−
A, when consent to an agreement is caused by undue influence, the agreement is a
contract voidable at the option of the party whose consent was so caused and the
court may set aside any such contract either absolutely or if the party who was
entitled to avoid it has received any benefit thereunder, upon such terms andAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

conditions as to the court may seem just. Sub−section (1) of Section 16 defines
"Undue influence" as follows:
“16. ‘Undue influence’ defined.—(1) A contract is said to be induced by ‘undue
influence’ where the relations subsisting between the parties are such that one of the
parties is in a position to dominate the will of the other and uses that position to
obtain an unfair advantage over the other.” The material provisions of sub−section
(2) of Section 16 are as follows:
“(2) In particular and without prejudice to the generality of the foregoing principle, a
person is deemed to be in a position to dominate the will of another—
(a) where he holds a real or apparent authority over the other ....” We need not
trouble ourselves with the other sections of the Indian Contract Act except Sections
23 and 24. Section 23 states that the consideration or object of an agreement is lawful
unless inter alia the court regards it as opposed to public policy. This section further
provides that every agreement of which the object or consideration is unlawful is
void. Under Section 24, if any part of a single consideration for one or more objects,
or anyone or any part of any one of several considerations for a single object is
unlawful, the agreement is void. The agreement is, however, not always void in its
entirety for it is well settled that if several distinct promises are made for one and the
same lawful consideration, and one or more of them be such as the law will not
enforce, that will not of itself prevent the rest from being enforceable.
The general rule was stated by Willes, J., in Pickering v. Ilfracombe Ry. Co. (1868) LR 3 CP 235 (at
p. 250) as follows:
"The general rule is that, where you cannot sever the illegal from the legal part of a
covenant, the contract is altogether void; but where you can sever them, whether the
illegality be created by statute or by the common law, you may reject the bad part and
retain the good."
(emphasis supplied)
(b). In Brojo Nath Ganguly (supra), this Court considered the concept of unconscionable bargain
and as to actions showing no regard for conscience; irreconcilable with what is right or reasonable,
observed thus:
“76. Under which head would an unconscionable bargain fall? If it falls under the
head of undue influence, it would be voidable but if it falls under the head of being
opposed to public policy, it would be void. No case of the type before us appears to
have fallen for decision under the law of contracts before any court in India nor has
any case on all fours of a court in any other country been pointed out to us. The word
“unconscionable” is defined in the Shorter Oxford English Dictionary, Third Edition,Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

Volume II, page 2288, when used with reference to actions, etc. as "showing no
regard for conscience; irreconcilable with what is right or reasonable." An
unconscionable bargain would, therefore, be one which is irreconcilable with what is
right or reasonable.” (emphasis supplied)
(c). Chitty on Contracts was referred in Brojo Nath Ganguly (supra) about the old
ideas of freedom of contract in modern times, 25 th Edn., Vol. 1, para 4, Chitty
observed:
“79. In this connection, it is useful to note what Chitty has to say about the old ideas
of freedom of contract in modern times. The relevant passages are to be found in
Chitty on Contracts, 25th Edn., Vol. I, in paragraph 4, and are as follows:
"These ideas have to a large extent lost their appeal today. 'Freedom of contract,' it
has been said, 'is a reasonable social ideal only to the extent that equality of
bargaining power between contracting parties can be assumed, and no injury is done
to the economic interests of the community at large.' Freedom of contract is of little
value when one party has no alternative between accepting a set of terms proposed by
the other or doing without the goods or services offered. Many contracts entered into
by public utility undertakings and others take the form of a set of terms fixed in
advance by one party and not open to discussion by the other. These are called
'contracts d’adhesion’ by French lawyers. Traders frequently contract, not on
individually negotiated terms, but on those contained in a standard form of contract
settled by a trade association. And the terms of an employee’s contract of
employment may be determined by agreement between his trade union and his
employer, or by a statutory scheme of employment. Such transactions are
nevertheless contracts notwithstanding that freedom of contract is to a great extent
lacking.
Where freedom of contract is absent, the disadvantages to consumers or members of
the public have, to some extent, been offset by administrative procedures for
consultation, and by legislation. Many statutes introduce terms into contracts which
the parties are forbidden to exclude, or declare that certain provisions in a contract
shall be void. And the courts have developed a number of devices for refusing to
implement exemption clauses imposed by the economically stronger party on the
weaker, although they have not recognized in themselves any general power (except
by statute) to declare broadly that an exemption clause will not be enforced unless it
is reasonable. Again, more recently, certain of the judges appear to have recognized
the possibility of relief from contractual obligations on the ground of 'inequality of
bargaining power.'"
What the French call “contracts d’adhesion," the American call "adhesion contracts"
or "contracts of adhesion." An "adhesion contract" is defined in Black’s Law
Dictionary. 5th Edn., at page 38, as follows:Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

“Adhesion contract.—Standardized contract form offered to consumers of goods and
services on essentially ‘take it or leave it’ basis without affording consumer realistic
opportunity to bargain and under such conditions that consumer cannot obtain
desired product or services except by acquiescing in form contract. Distinctive feature
of adhesion contract is that weaker party has no realistic choice as to its terms. Not
every such contract is unconscionable.”
80. The position under the American law is stated in Reinstatement of the Law —
Second as adopted and promulgated by the American Law Institute, Volume II which
deals with the law of contracts, in Section 208 at page 107, as follows:
“§ 208. Unconscionable Contract or Term If a contract or term thereof is
unconscionable at the time the contract is made a court may refuse to enforce the
contract, or may enforce the remainder of the contract without the unconscionable
term, or may so limit the application of any unconscionable term as to avoid any
unconscionable result.” In the Comments given under that section, it is stated at page
107:
“Like the obligation of good faith and fair dealing (§ 205), the policy against
unconscionable contracts or terms applies to a wide variety of types of conduct. The
determination that a contract or term is or is not unconscionable is made in the light
of its setting, purpose and effect. Relevant factors include weaknesses in the
contracting process like those involved in more specific rules as to contractual
capacity, fraud and other invalidating causes; the policy also overlaps with rules
which render particular bargains or terms unenforceable on grounds of public policy.
Policing against unconscionable contracts or terms has sometimes been
accomplished by adverse construction of language, by manipulation of the rules of
offer and acceptance or by determinations that the clause is contrary to public policy
or to the dominant purpose of the contract. Uniform Commercial Code § 2−302
Comment 1 .... A bargain is not unconscionable merely because the parties to it are
unequal in bargaining position, nor even because the inequality results in an
allocation of risks to the weaker party. But gross inequality of bargaining power,
together with terms unreasonably favourable to the stronger party , may confirm
indications that the transaction involved elements of deception or compulsion, or
may show that the weaker party had no meaningful choice, no real alternative, or did
not in fact assent or appear to assent to the unfair terms.” (emphasis supplied) There
is a statute in the United States called the Universal Commercial Code, which applies
to contracts relating to sales of goods. Though this statute is inapplicable to contracts
not involving sales of goods, it has proved very influential in what is called in the
United States, "non−sales" cases. It has many times been used either by analogy or
because it was felt to embody a generally accepted social attitude of fairness going
beyond its statutory application to sales of goods. In the Reporter's Note to said
Section 208, it is stated at p. 112: "It is to be emphasized that a contract of adhesion is
not unconscionable per se, and that all unconscionable contracts are not contracts ofAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

adhesion. Nonetheless, the more standardised the agreement and the less a party
may bargain meaningfully, the more susceptible the contract or a term will be to a
claim of unconscionability.” (emphasis supplied) The position has been thus summed
up by John R. Peden in ‘The Law of Unjust Contracts’ published by Butterworths in
1982, at pages 28−29:
“... Unconscionability represents the end of a cycle commencing with the Aristotelian
concept of justice and the Roman law laesio enormis, which in turn formed the basis
for the medieval church’s concept of a just price and condemnation of usury. These
philosophies permeated the exercise, during the seventeenth and eighteenth
centuries, of the Chancery court’s discretionary powers under which it upset all kinds
of unfair transactions. Subsequently the movement towards economic individualism
in the nineteenth century hardened the exercise of these powers by emphasising the
freedom of the parties to make their own contract. While the principle of pacta sunt
servanda held dominance, the consensual theory still recognized exceptions where
one party was overborne by a fiduciary, or entered a contract under duress or as the
result of fraud. However, these exceptions were limited and had to be strictly proved.
It is suggested that the judicial and legislative trend during the last 30 years in both
civil and common law jurisdictions has almost brought the wheel full circle. Both
courts and parliaments have provided greater protection for weaker parties from
harsh contracts. In several jurisdictions this included a general power to grant relief
from unconscionable contracts, thereby providing a launching point from which the
courts have the opportunity to develop a modern doctrine of unconscionability.
American decisions on Article 2.302 of the UCC have already gone some distance into
this new arena....” The expression “laesio enormis” used in the above passage refers
to “laesio ultra dimidium vel enormis” which in Roman law meant the injury
sustained by one of the parties to an onerous contract when he had been overreached
by the other to the extent of more than one−half of the value of the subject− matter,
as for example, when a vendor had not received half the value of property sold, or the
purchaser had paid more than double value. The maxim “pacta sunt servanda"
referred to in the above passage, means "contracts are to be kept."
(emphasis supplied) This Court held that due to inequality of bargaining power,
unreasonable terms, unreasonable favour to the stronger party may involve an
element of deception or compulsion, or may show that the weaker party had no
meaningful choice. The Court in Brojo Nath Ganguly (supra) also observed that in the
sphere of the law of contract, the test of reasonableness or fairness has emerged.
Even an unreasonable clause cannot be enforced as that would be unconscionable.
Here the reasonable construction in the matter is that the pension is clearly
admissible as per the resolution passed by the Central Board of Directors of SBI,
which is sought to be denied, it was for SBI to amend Rules. Such an action would be
unconscionable, and courts cannot be said to be powerless in such a situation toAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

enforce the SBI VRS with an obligation to make payment of pension.
(d). This Court considered the enforcement of unreasonable contracts and
enforceability thereof in Brojo Nath Ganguly (supra) thus:
“83. Yet another theory which has made its emergence in recent years in the sphere
of the law of contracts is the test of reasonableness or fairness of a clause in a contract
where there is inequality of bargaining power. Lord Denning, MR, appears to have
been the propounder, and perhaps the originator —at least in England, of this theory.
In Gillespie Brothers & Co. Ltd. v. Roy Bowles Transport Ltd., (1973) QB 400, where
the question was whether an indemnity clause in a contract, on its true construction,
relieved the indemnifier from liability arising to the indemnified from his own
negligence, Lord Denning said (at pages 415−416):
“The time may come when this process of ‘construing’ the contract can be pursued no
further. The words are too clear to permit of it. Are the courts then powerless? Are
they to permit the party to enforce his unreasonable clause, even when it is so
unreasonable, or applied so unreasonably, as to be unconscionable? When it gets to
this point, I would say, as I said many years ago:
‘there is the vigilance of the common law which, while allowing freedom of contract,
watches to see that it is not abused’: John Lee & Son (Grantham) Ltd. v. Railway
Executive, (1949) 2 All ER 581.
It will not allow a party to exempt himself from his liability at common law when it would be quite
unconscionable for him to do so.” (emphasis supplied) In the above case, the Court of Appeal
negatived the defense of the indemnifier that the indemnity clause did not cover the negligence of
the indemnified. It was in Lloyds Bank Ltd. v. Bundy (1974) 3 All ER 757 that Lord Denning first
clearly enunciated his theory of "inequality of bargaining power." He began his discussion on this
part of the case by stating (at page 763) :
“There are cases in our books in which the courts will set aside a contract, or a
transfer of property, when the parties have not met on equal terms, when the one is
so strong in bargaining power and the other so weak that, as a matter of common
fairness, it is not right that the strong should be allowed to push the weak to the wall.
Hitherto those exceptional cases have been treated each as a separate category in
itself. But I think the time has come when we should seek to find a principle to unite
them. I put on one side contracts or transactions which are voidable for fraud or
misrepresentation or mistake. All those are governed by settled principles. I go only
to those where there has been inequality of bargaining power, such as to merit the
intervention of the court.” (emphasis supplied) He then referred to various categories
of cases and ultimately deduced therefrom a general principle in these words (at page
765):Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

“Gathering all together, I would suggest that through all these instances there runs a
single thread. They rest on ‘inequality of bargaining power.' By virtue of it, the
English law gives relief to one who, without independent advice, enters into a
contract on terms which are very unfair or transfers property for a consideration
which is grossly inadequate, when his bargaining power is grievously impaired by
reason of his own needs or desires, or by his own ignorance or infirmity, coupled with
undue influences or pressures brought to bear on him by or for the benefit of the
other. When I use the word 'undue,' I do not mean to suggest that the principle
depends on proof of any wrongdoing. The one who stipulates for an unfair advantage
may be moved solely by his own self−interest, unconscious of the distress he is
bringing to the other. I have also avoided any reference to the will of the one being
‘dominated’ or ‘overcome’ by the other. One who is in extreme need may knowingly
consent to a most improvident bargain, solely to relieve the straits in which he finds
himself. Again, I do not mean to suggest that every transaction is saved by
independent advice. But the absence of it may be fatal. With these explanations, I
hope this principle will be found to reconcile the cases.” (emphasis supplied)
(e). The Court clearly held that the contracts, which are the outcome of
misrepresentation, cannot be enforced, and inequality of bargaining power merit the
intervention of the court. In A. Schroeder Music Publishing Co. Ltd. v. Macaulay
(formerly Instone) (1974) 1 WLR 1308, Lord Diplock made the following observations
at pp. 1315−16 thus:
"84. …. "My Lords, the contract under consideration in this appeal is one whereby the
respondent accepted restrictions upon the way in which he would exploit his earning
power as a songwriter for the next ten years. Because this can be classified as a
contract in restraint of trade the restrictions that the respondent accepted fell within
one of those limited categories of contractual promises in respect of which the courts
still retain the power to relieve the promisor of his legal duty to fulfill them. In order
to determine whether this case is one in which that power ought to be exercised, what
your Lordships have in fact been doing has been to assess the relative bargaining
power of the publisher and the songwriter at the time the contract was made and to
decide whether the publisher had used his superior bargaining power to exact from
the songwriter promises that were unfairly onerous to him. Your Lordships have not
been concerned to inquire whether the public have in fact been deprived of the fruit
of the song writer's talents by reason of the restrictions, nor to assess the likelihood
that they would be so deprived in the future if the contract were permitted to run its
full course. It is, in my view, salutary to acknowledge that in refusing to enforce
provisions of a contract whereby one party agrees for the benefit of the other party to
exploit or to refrain from exploiting his own earning power, the public policy which
the court is implementing is not some 19th century economic theory about the benefit
to the general public of freedom of trade, but the protection of those whose
bargaining power is weak against being forced by those whose bargaining power is
stronger to enter into bargains that are unconscionable. Under the influence ofAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

Bentham and of laissez faire the courts in the 19th century abandoned the practice of
applying the public policy against unconscionable bargains to contracts generally, as
they had formerly done to any contract considered to be usurious; but the policy
survived in its application to penalty clauses and to relief against forfeiture and also
to the special category of contracts in restraint of trade. If one looks at the reasoning
of 19th−century judges in cases about contracts in restraint of trade one finds lip
service paid to current economic theories, but if one looks at what they said in the
light of what they did, one finds that they struck down a bargain if they thought it was
unconscionable as between the parties to it and upheld it if they thought that it was
not.
So I would hold that the question to be answered as respects a contract in restraint of
trade of the kind with which this appeal is concerned is: ‘Was the bargain fair?’ The
test of fairness is, no doubt, whether the restrictions are both reasonably necessary
for the protection of the legitimate interests of the promisee and commensurate with
the benefits secured to the promisor under the contract. For the purpose of this test,
all the provisions of the contract must be taken into consideration.”
(f). A term which exempts the stronger party from his ordinary common law liability
should not be given effect except when it is reasonable, as observed in Levison v.
Patent Steam Carpet Co. Ltd., (1949) 2 All ER 581 at 584 relied upon in Brojo Nath
Ganguly (supra) thus:
“85. The observations of Lord Denning, M.R., in Levison v. Patent Steam Carpet Co.
Ltd. are also useful and require to be quoted. These observations are as follows (at
page 79) :
"In such circumstances as here the Law Commission in 1975 recommended that a
term which exempts the stronger party from his ordinary common law liability
should not be given effect except when it is reasonable: see The Law Commission and
the Scottish Law Commission Report, Exemption Clauses, Second Report (1975)
(August 5, 1975), Law Com. No. 69 (H.C. 605), pp. 62, 174; and there is a Bill now
before Parliament, which gives effect to the test of reasonableness. This is a gratifying
piece of law reform: but I do not think we need wait for that Bill to be passed into law.
You never know what may happen to a Bill. Meanwhile, the common law has its own
principles ready to hand. In Gillespie Bros. & Co. Ltd. v. Roy Bowles Transport Ltd.
(1973) QB 400, I suggested that an exemption or limitation clause should not be
given effect if it was unreasonable, or if it would be unreasonable to apply it in the
circumstances of the case. I see no reason why this should not be applied today, at
any rate in contracts in standard forms where there is inequality of bargaining
power.”
(g). Courts have to construe the contracts according to the tenor. In this regard, in
Brojo Nath Ganguly (supra), the Court considered the question thus:Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

“87. In Photo Production Ltd. v. Securicor Transport Ltd. (1980) AC 827, a case
before the Unfair Contract Terms Act, 1977, was enacted, the House of Lords upheld
an exemption clause in a contract on the defendants' printed form containing
standard conditions. The decision appears to proceed on the ground that the parties
were businessmen and did not possess unequal bargaining power. The House of
Lords did not, in that case, reject the test of reasonableness or fairness of a clause in a
contract where the parties are not equal in bargaining position. On the contrary, the
speeches of Lord Wilberforce, Lord Diplock, and Lord Scarman would seem to show
that the House of Lords in a fit case would accept that test. Lord Wilberforce, in his
speech, after referring to the Unfair Contract Terms Act, 1977, said (at page 843) :
“This Act applies to consumer contracts and those based on standard terms and
enables exception clauses to be applied with regard to what is just and reasonable. It
is significant that Parliament refrained from legislating over the whole field of
contract. After this Act, in commercial matters generally, when the parties are not of
unequal bargaining power, and when risks are normally borne by insurance, not only
is the case for judicial intervention undemonstrated, but there is everything to be
said, and this seems to have been Parliament’s intention, for leaving the parties free
to apportion the risks as they think fit and for respecting their decisions.” (emphasis
supplied) Lord Diplock said (at page 850−51):
“Since the obligations implied by law in a commercial contract are those which, by
judicial consensus over the years or by Parliament in passing a statute, have been
regarded as obligations which a reasonable businessman would realise that he was
accepting when he entered into a contract of a particular kind, the court’s view of the
reasonableness of any departure from the implied obligations which would be
involved in construing the express words of an exclusion clause in one sense that they
are capable of bearing rather than another, is a relevant consideration in deciding
what meaning the words were intended by the parties to bear.” (emphasis supplied)
Lord Scarman, while agreeing with Lord Wilberforce, described (at page 853) the
action out of which the appeal before the House had arisen as “a commercial dispute
between parties well able to look after themselves” and then added: “In such a
situation what the parties agreed (expressly or impliedly) is what matters, and the
duty of the courts is to construe their contract according to its tenor."
88. As seen above, apart from judicial decisions, the United States and the United
Kingdom have statutorily recognised, at least in certain areas of the law of contracts,
that there can be unreasonableness (or lack of fairness, if one prefers that phrase) in
a contract or a clause in a contract where there is inequality of bargaining power
between the parties although arising out of circumstances not within their control or
as a result of situations not of their creation. Other legal systems also permit judicial
review of a contractual transaction entered into in similar circumstances. For
example, Section 138(2) of the German Civil Code provides that a transaction is void
"when a person" exploits "the distressed situation, inexperience, lack of judgmentalAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

ability, or grave weakness of will of another to obtain the grant or promise of
pecuniary advantages ... which are obviously disproportionate to the performance
given in return". The position, according to the French law, is very much the same."
(h). In Brojo Nath Ganguly (supra), it was pointed out what court should do in such a matter thus:
“89. Should then our courts not advance with the times? Should they still continue to
cling to outmoded concepts and outworn ideologies? Should we not adjust our
thinking caps to match the fashion of the day? Should all jurisprudential
development pass us by, leaving us floundering in the sloughs of 19th−century
theories? Should the strong be permitted to push the weak to the wall? Should they
be allowed to ride roughshod over the weak? Should the courts sit back and watch
supinely while the strong trample underfoot the rights of the weak? We have a
Constitution for our country. Our judges are bound by their oath to "uphold the
Constitution and the laws." The Constitution was enacted to secure to all the citizens
of this country social and economic justice. Article 14 of the Constitution guarantees
to all persons equality before the law and the equal protection of the laws. The
principle deducible from the above discussions on this part of the case is in
consonance with right and reason, intended to secure social and economic justice and
conforms to the mandate of the great equality clause in Article 14. This principle is
that the courts will not enforce and will, when called upon to do so, strike down an
unfair and unreasonable contract, or an unfair and unreasonable clause in a contract,
entered into between parties who are not equal in bargaining power. It is difficult to
give an exhaustive list of all bargains of this type. No court can visualize the different
situations which can arise in the affairs of men. One can only attempt to give some
illustrations. For instance, the above principle will apply where the inequality of
bargaining power is the result of the great disparity in the economic strength of the
contracting parties. It will apply where the inequality is the result of circumstances,
whether of the creation of the parties or not. It will apply to situations in which the
weaker party is in a position in which he can obtain goods or services or means of
livelihood only upon the terms imposed by the stronger party or go without them. It
will also apply where a man has no choice, or rather no meaningful choice, but to give
his assent to a contract or to sign on the dotted line in a prescribed or standard form
or to accept a set of rules as part of the contract, however unfair, unreasonable and
unconscionable a clause in that contract or form or rules may be. This principle,
however, will not apply where the bargaining power of the contracting parties is equal
or almost equal. This principle may not apply where both parties are businessmen,
and the contract is a commercial transaction. In today’s complex world of giant
corporations with their vast infrastructural organizations and with the State through
its instrumentalities and agencies entering into almost every branch of industry and
commerce, there can be myriad situations which result in unfair and unreasonable
bargains between parties possessing wholly disproportionate and unequal bargaining
power. These cases can neither be enumerated nor fully illustrated. The court must
judge each case on its own facts and circumstances.”Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

(i). The Court in Brojo Nath Ganguly (supra) held that the contract, which affected a
large number of persons if they are unconscionable, unfair, and unreasonable, the
contract is voidable. The court would not compel each person with whom the party
with superior bargaining power had contracted to go to court to adjudge the contract
voidable and would result in a multiplicity of litigation. It observed:
“91. Is a contract of the type mentioned above to be adjudged voidable or void? If it
was induced by undue influence, then under Section 19−A of the Indian Contract Act,
it would be voidable. It is, however, rarely that contracts of the types to which the
principle formulated by us above applies are induced by undue influence as defined
by Section 16(1) of the Indian Contract Act, even though at times they are between
parties one of whom holds a real or apparent authority over the other. In the vast
majority of cases, however, such contracts are entered into by the weaker party under
pressure of circumstances, generally economic, which results in inequality of
bargaining power. Such contracts will not fall within the four corners of the definition
of “undue influence” given in Section 16(1). Further, the majority of such contracts
are in a standard or prescribed form or consist of a set of rules. They are not contracts
between individuals containing terms meant for those individuals alone. Contracts in
prescribed or standard forms or which embody a set of rules as part of the contract
are entered into by the party with superior bargaining power with a large number of
persons who have far less bargaining power or no bargaining power at all. Such
contracts which affect a large number of persons or a group or groups of persons, if
they are unconscionable, unfair, and unreasonable, are injurious to the public
interest. To say that such a contract is only voidable would be to compel each person
with whom the party with superior bargaining power had contracted to go to court to
have the contract adjudged voidable. This would only result in multiplicity of
litigation, which no court should encourage and would also not be in the public
interest. Such a contract or such a clause in a contract ought, therefore, to be
adjudged void. While the law of contracts in England is mostly judge−made, the law
of contracts in India is enacted in a statute, namely, the Indian Contract Act, 1872. In
order that such a contract should be void, it must fall under one of the relevant
sections of the Indian Contract Act. The only relevant provision in the Indian
Contract Act, which can apply is Section 23, when it states that "The consideration or
object of an agreement is lawful, unless ... the court regards it as ... opposed to public
policy."
(j). The Court also considered the “public policy”. The same is not the policy of a
particular Government. It connotes some matter which concerns the public good and
the public interest. Action has to be subservient to public policy. This Court in the
context of Contract Act and Public Policy made the following observations:
“92. The Indian Contract Act does not define the expression "public policy" or
"opposed to public policy." From the very nature of things, the expressions "public
policy," "opposed to public policy," or "contrary to public policy" are incapable ofAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

precise definition. Public policy, however, is not the policy of a particular
government. It connotes some matter which concerns the public good and the public
interest. The concept of what is for the public good or in the public interest or what
would be injurious or harmful to the public good or the public interest has varied
from time to time. As new concepts take the place of old, transactions which were
once considered against public policy are now being upheld by the courts, and
similarly, where there has been a well− recognized head of public policy, the courts
have not shirked from extending it to new transactions and changed circumstances
and have at times not even flinched from inventing a new head of public policy. There
are two schools of thought— "the narrow view" school and "the broad view" school.
According to the former, courts cannot create new heads of public policy, whereas the
latter countenances judicial law−making in this area. The adherents of "the narrow
view" school would not invalidate a contract on the ground of public policy unless
that particular ground had been well−established by authorities. Hardly ever has the
voice of the timorous spoken more clearly and loudly than in these words of Lord
Davey in Janson v. Driefontein Consolidated Gold Mines Ltd.: "Public policy is
always an unsafe and treacherous ground for legal decision." That was in the year
1902. Seventy−eight years earlier, Burrough, J., in Richardson v. Mellish, (1824−34)
All ER 258, described public policy as "a very unruly horse, and when once you get
astride it you never know where it will carry you." The Master of the Rolls, Lord
Denning, however, was not a man to shy away from unmanageable horses and in
words which conjure up before our eyes the picture of the young Alexander the Great
taming Bucephalus, he said in Enderby Town Football Club Ltd. v. Football Assn.
Ltd. (1971) Ch 591: "With a good man in the saddle, the unruly horse can be kept in
control. It can jump over obstacles." Had the timorous always held the field, not only
the doctrine of public policy but even the Common Law or the principles of Equity
would never have evolved.
Sir William Holdsworth in his "History of English Law,"
Volume III, page 55, has said:
"In fact, a body of law like the common law, which has grown up gradually with the
growth of the nation, necessarily acquires some fixed principles, and if it is to
maintain these principles, it must be able, on the ground of public policy or some
other like ground, to suppress practices which, under ever new disguises, seek to
weaken or negative them."
It is thus clear that the principles governing public policy must be and are capable, on proper
occasion, of expansion or modification. Practices which were considered perfectly normal at one
time have today become obnoxious and oppressive to public conscience. If there is no head of public
policy which covers a case, then the court must in consonance with public conscience and in keeping
with public good and public interest declare such practice to be opposed to public policy. Above all,
in deciding any case which may not be covered by authority, our courts have before them the beaconAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

light of the Preamble to the Constitution. Lacking precedent, the court can always be guided by that
light and the principles underlying the Fundamental Rights and the Directive Principles enshrined
in our Constitution.
93. The normal rule of Common Law has been that a party who seeks to enforce an agreement which
is opposed to public policy will be non−suited. The case of A. Schroeder Music Publishing Co. Ltd. v.
Macaulay (1974) 1 WLR 1308, however, establishes that where a contract is vitiated as being
contrary to public policy, the party adversely affected by it can sue to have it declared void. The case
may be different, where the purpose of the contract is illegal or immoral. In Kedar Nath Motani v.
Prahlad Rai, AIR 1960 SC 213, reversing the High Court and restoring the decree passed by the trial
court declaring the appellants’ title to the lands in suit and directing the respondents who were the
appellants’ benamidars to restore possession, this Court, after discussing the English and Indian law
on the subject, said: (at page 873) :
"The correct position in law, in our opinion, is that what one has to see is whether the
illegality goes so much to the root of the matter that the plaintiff cannot bring his
action without relying upon the illegal transaction into which he had entered. If the
illegality be trivial or venial, as stated by Williston and the plaintiff is not required to
rest his case upon that illegality, then public policy demands that the defendant
should not be allowed to take advantage of the position. A strict view, of course, must
be taken of the plaintiff's conduct, and he should not be allowed to circumvent the
illegality by resorting to some subterfuge or by misstating the facts. If, however, the
matter is clear and the illegality is not required to be pleaded or proved as part of the
cause of action, and the plaintiff recanted before the illegal purpose was achieved,
then, unless it be of such a gross nature as to outrage the conscience of the court, the
plea of the defendant should not prevail."
The types of contracts to which the principle formulated by us above applies are not contracts which
are tainted with illegality but are contracts which contain terms which are so unfair and
unreasonable that they shock the conscience of the court. They are opposed to public policy and
require to be adjudged void.”
51. This Court also considered the law of contract and its interpretation in changing times in Delhi
Transport Corporation v. D.T.C. Mazdoor Congress & Ors., (1991) Supp 1 SCC 600 thus:
“279. In paragraph 4 of Chitty on Contracts (25th edn., vol. 1) it is stated that
"freedom of contract is a reasonable social ideal only to the extent that equality of
bargaining power between contracting parties can be assumed and no injury is done
to the economic interest of the community at large."
280. In Anson’s Law of Contract at pages 6 and 7 stated the scope of freedom of
contract in the changing circumstances thus:Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

"Today the position is seen in a very different light. Freedom of contract is a
reasonable social ideal only to the extent that equality of bargaining power between
contracting parties can be assumed, and no injury is done to the economic interests
of the community at large. In the more complicated social and industrial conditions
of a collectivist society, it has ceased to have much idealistic attraction. It is now
realised that economic equality often does not exist in any real sense and that
individual interests have to be made to subserve those of the community hence there
has been a fundamental change both in our social outlook and in the policy of the
legislature towards contract and the law today interferes at numerous points with the
freedom of the parties to make what contract they like. The relation between
employers and employed, for example, have been regulated by statutes designed to
ensure that the employee’s condition of work are safe, that he is properly protected
against redundancy, and that he knows his terms of service. The public has been
protected against economic pressure by such measures as the Rent Acts, the Supply
of Goods (Implied Terms) Act, the Consumer Credit Act, and other similar
enactments. These legislative provisions will override any contrary terms which the
parties may make for themselves. Further, the legislature has intervened in the
Restrictive Trade Practices Act, 1956, and the Fair Trading Act, 1973 to promote
competition in industry and to safeguard the interests of consumers. This
intervention is specially necessary today when most contracts entered by ordinary
people are not the result of individual negotiation. It is not possible for a private
person to settle the terms of his agreement with a British Railways Board or with a
local electricity authority.” The 'standard form' contract is the rule. He must either
accept the terms of this contract in toto or go without. Since, however, it is not
feasible to deprive oneself of such necessary services, the individual is compelled to
accept on those terms. In view of this fact, it is quite clear that freedom of contract is
now largely an illusion."
52. (a). It has been emphasised in D.T.C. (supra) that the period of contract is to be reasonable and
the employee has a right to know the conditions of work and he is properly protected against
redundancy. Approving decision in Central Inland Water Transport Corporation Ltd. & Anr. v. Brojo
Nath Ganguly & Anr. (1983) 3 SCC 156 Court held thus:
“282. In Brojo Nath case (1986) 3 SCC 156, Madon, J. elaborately considered the
development of law relating to unfair or unreasonable terms of the contract or
clauses thereof in extenso, and it is unnecessary for me to traverse the same grounds
once over. The learned Judge also considered the arbitrary, unfair, and unbridled
power on the anvil of distributive justice or justness or fairness of the procedure
envisaged therein. The relevant case law in that regard was dealt with in extenso in
the light of the development of law in the Supreme Court of United States of America
and the House of Lords in England and in the continental countries. To avoid
needless burden on the judgment, I do not repeat the same reasoning. I entirely agree
with the reasoning, and the conclusions reached therein on all these aspects."Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

(b). This Court in D.T.C. (supra) with respect to the alteration of Government
contracts and the right of the State to impose unconstitutional conditions, observed:
“283. The problem also could be broached from the angle whether the State can
impose unconstitutional conditions as part of the contract or statute or rule etc. In
(1959−60) 73 Harvard Law Review, in the Note under the caption ‘Unconstitutional
Condition’ at pages 1595−96 it is postulated that the State is devoid of power to
impose unconstitutional conditions in the contract that the power to withhold
largesse has been asserted by the State in four areas i.e. (1) regulating the right to
engage in certain activities; (2) administration of government welfare programme;
(3) government employment; and (4) procurement of contracts. It was further
adumbrated at pages 1602−03 thus:
"The sovereign's constitutional authority to choose those with whom it will contract
for goods and services is, in effect, a power to withhold the benefits to be derived
from economic dealings with the government. As government activity in the
economic sphere increases, the contracting power enables the government to control
many hitherto unregulated activities of contracting parties through the imposition of
conditions. Thus, regarding the government, as a private entrepreneur, threatens to
impair constitutional rights. The government, unlike a private individual, is limited
in its ability to contract by the Constitution. The federal contracting power is based
upon the Constitution's authorisation of these acts 'necessary and proper' to the
carrying out of the functions which it allocates to the national government. Unless
the objectives sought by terms and conditions in government contracts requiring the
surrender of rights are constitutionally authorised, the conditions must fall as ultra
vires exercise of power.” Again at page 1603, it is further emphasised thus: “When
conditions limit the economic benefits to be derived from dealings with the
government to those who forego the exercise of constitutional rights, the exclusion of
those retaining their rights from participation in the enjoyment of these benefits may
be violative of the prohibition, implicit in the due process clause of Fifth Amendment
and explicit in the equal protection clause of the Fourteenth Amendment against
unreasonable discrimination in the governmental bestow of advantages. Finally,
disabling those exercising certain rights from participating in the advantages to be
derived from contractual relations with the government may be a form of penalty
lacking in due process. To avoid invalidation for any of the above reasons, it must be
shown that the conditions imposed are necessary to secure the legitimate objectives
of the contract, ensure its effective use, or protect society from the potential harm
which may result from the contractual relationship between the government and the
individual.”
284. Professor Guido Calabresi of Yale University Law School in his “Retroactivity,
Paramount Power and Contractual Changes” (1961−62) 71 Yale Law Journal 1191,
stated that the government can make contracts that are necessary and proper for
carrying out any of the specific clauses of the Constitution or power to spend forAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

general welfare. The Federal Government has no power, inherent or sovereign, other
than those specifically or explicitly granted to it by the Constitution. At page 1197, it is
further stated thus:
“The government acts according to due process standards for the due process clause
is quite up to that task without the rule. Alterations of government contracts are not
desirable in a free country even when they do not constitute a ‘taking’ of property or
impinge on questions of fundamental fairness of the type comprehended in due
process. The government may make changes, but only if war or commerce require
them and not on the broader and more ephemeral grounds that the general welfare
would be served by the change. Any other rule would allow the government to welch
almost at will.” xxx
286. In Brojo Nath case (supra, after elaborate consideration of the doctrine of
“reasonableness or fairness” of the terms and conditions of the contract vis−a−vis the
relative bargaining power of the contracting parties this Court laid down that the
principles deducible from the discussion made therein is in consonance with right or
reason intended to secure socio− economic justice and conform to mandate of the
equality clause in Article 14. The principle laid was that courts will not enforce and
will, when called upon to do so, strike down an unfair and unreasonable contract or
an unfair and unreasonable clause in a contract, entered into between parties who are
not equal in bargaining power …. It will apply to situations in which the weaker party
is in a position in which he can obtain goods or services or means of livelihood only
upon the terms imposed by the stronger party or go without them. It will also apply
where a man has no choice, or rather no meaningful choice, but to give his assent to a
contract or to sign on the dotted line in a prescribed or standard form or to accept a
set of rules as part of the contract, however unfair, unreasonable and unconscionable
a clause in that contract or form or rules may be. This principle, however, will not
apply where the bargaining power of the contracting parties is equal or almost equal
or where both parties are businessmen, and the contract is a commercial transaction.
287. In today’s complex world of giant corporations with their vast infrastructural
organisations the State through its instrumentalities and agencies has been entering
into almost every branch of industry and commerce and field of service, there can be
myriad situations which result in unfair and unreasonable bargains between parties
possessing wholly disproportionate and unequal bargaining power. These cases can
neither be enumerated nor fully illustrated. The court must judge each case on its
own facts and circumstances.” (emphasis supplied) The Court held that there can be
myriad situations which result in unfair and unreasonable bargains, which are the
outcome of an unequal bargaining power. Each case has to be seen on its own facts
and circumstances.
(c). In D.T.C. (supra), the Court also held that Article 14 sheds light on public policy to curb
arbitrariness thus:Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

“294. In Basheshar Nath v. CIT, AIR 1959 SC 149, S.R. Das, C.J. held that Article 14 is
founded on a sound public policy recognised and valued in all States, and it
admonishes the State when it disregards the obligations imposed upon the State.
295. In E.P. Royappa v. State of Tamil Nadu, (1974) 4 SCC 3, Bhagwati, J. (as he then
was) held that Article 14 is the genus while Article 16 is a specie. Article 16 gives effect
to the doctrine of equality in all matters relating to public employment. The basic
principle which, therefore, informs both Articles 14 and 16 is equality and inhibition
against discrimination. "Equality is a dynamic concept with many aspects and
dimensions, and it cannot be “cribbed, cabined and confined” within traditional and
doctrinaire limits. From a positivistic point of view, equality is antithetical to
arbitrariness. In fact, equality and arbitrariness are sworn enemies; one belongs to
the rule of law in a republic while the other, to the whim and caprice of an absolute
monarch. Where an act is arbitrary, it is implicit in it that it is unequal both according
to political logic and constitutional law and is therefore violative of Article 14, and if it
affects any matter relating to public employment, it is also violative of Article 16.
Articles 14 and 16 strike at arbitrariness in State action and ensure fairness and equality of
treatment. In Maneka Gandhi case (1978) 1 SCC 248, it was further held that the principle of
reasonableness, which legally as well as philosophically, is an essential element of equality or non−
arbitrariness pervades Article 14 like a brooding omnipresence. In Ramana case (1979) 3 SCC 489, it
was held that it is merely a judicial formula for determining whether the legislative or executive
action in question is arbitrary and therefore constituting denial of equality. If the classification is not
reasonable and does not satisfy the two conditions, namely, rational relation and nexus, the
impugned legislative or executive action would plainly be arbitrary, and the guarantees of equality
under Article 14 would be breached. Wherever, therefore, there is arbitrariness in State action,
whether it be of legislature or of the executive or of an "authority" under Article 12, Article 14,
"immediately springs into action and strikes down such State action." In fact, the concept of
reasonableness and non− arbitrariness pervades the entire constitutional scheme and is a golden
thread which runs through the whole of the fabric of the constitution.
302. Article 14 is the general principle, while Article 311(2) is a special provision applicable to all
civil services under the State. Article 311(2) embodies the principles of natural justice, but proviso to
clause (2) of Article 311 excludes the operation of principles of natural justice engrafted in Article
311(2) as an exception in the given circumstances enumerated in three clauses of the proviso to
Article 311(2) of the Constitution. Article 14 read with Articles 16(1), and 311 are to be harmoniously
interpreted that the proviso to Article 311(2) excludes the application of the principles of natural
justice as an exception; and the applicability of Article 311(2) must, therefore, be circumscribed to
the civil services and be construed accordingly. In respect of all other employees covered by Article
12 of the Constitution, the dynamic role of Article 14 and other relevant articles like Article 21 must
be allowed to have full play without any inhibition, unless the statutory rules themselves, consistent
with the mandate of Articles 14, 16, 19 and 21 provide, expressly such an exception.” (emphasis
supplied)Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

(d). Arbitrariness in State action whether of the legislature or the executive or of an authority under
Articles 12, 14 and 21 comes into play to strike down such an action. The Court in D.T.C. (supra)
held thus:
“303. Article 19(1)(g) empowers every citizen the right to avocation or profession etc.
which includes right to be continued in employment under the State unless the
tenure is validly terminated consistent with the scheme enshrined in the fundamental
rights of the Constitution. Therefore, if any procedure is provided for deprivation of
the right to employment or right to the continued employment till the age of
superannuation as is a source to right to livelihood, such a procedure must be just,
fair and reasonable. This Court in Fertilizer Corporation Kamgar Union (Regd.),
Sindri v. Union of India (1981) 1 SCC 568, held that Article 19(1)(g) confers a broad
and general right which is available to all persons to do works of any particular kind
and of their choice. Therefore, whenever there is arbitrariness in State action —
whether it be of the legislature or of the executive or of an authority under Article 12,
Articles 14 and 21 spring into action and strikes down such an action. The concept of
reasonableness and non− arbitrariness pervades the entire constitutional spectrum
and is a golden thread which runs through the whole fabric of the Constitution.
Therefore, the provision of the statute, the regulation or the rule which empowers an
employer to terminate the services of an employee whose service is of an indefinite
period till he attains the age of superannuation, by serving a notice or pay in lieu
thereof must be conformable to the mandates of Articles 14, 19(1)(g) and 21 of the
Constitution. Otherwise, per se, it would be void. In Moti Ram Deka case, AIR 1964
SC 600, Gajendragadkar, J. (as he then was) after invalidating the Rules 149(3) and
148(3) under Article 311(2) which are in pari materia with Regulation 9(b) of the
Regulations also considered their validity in the light of Article 14 and held thus:
(SCR p. 731) “Therefore, we are satisfied that the challenge to the validity of the
impugned Rules on the ground that they contravene Article 14 must also succeed.”
This was on the test of reasonable classification as the principle then was applied.
Subba Rao, J. (as he then was) in a separate but concurring judgment, apart from
invalidating the rule under Article 311(2) also held that the rule infringed Article 14 as
well, though there is no elaborate discussion in that regard. But, Das Gupta, J.
considered elaborately on this aspect and held: (SCR p. 770) “Applying the principle
laid down in the above case to the present Rule, I find on the scrutiny of the Rule that
it does not lay down any principle or policy for guiding the exercise of discretion by
the authority who will terminate the service in the matter of selection or
classification. Arbitrary and uncontrolled power is left in the authority to select at its
will any person against whom action will be taken. The rule thus enables the
authority concerned to discriminate between two railway servants to both of whom
Rule 148(3) equally applied by taking action in one case and not taking it in the other.
In the absence of any guiding principle in the exercise of the discretion by the
authority, the Rule has, therefore, to be struck down as contravening the
requirements of Article 14 of the Constitution."Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

308. In Ramana case (1979) 3 SCC 489, it has been held that: (SCC p. 504, para 10) “It is indeed
unthinkable that in a democracy governed by the rule of law, the executive government or any of its
officers should possess arbitrary power over the interests of the individual.” The procedure adopted
should match with what justice demands. History shows that it is always subtle and insidious
encroachments made ostensibly for a good cause that imperceptibly but surely erode the
foundations of liberty.” (emphasis supplied)
(e). An employer cannot act in a manner that is in the negation of just, fair, and reasonable
procedure. The Court held:
“329. I am, therefore, inclined to hold that the courts, though, have no power to
amend the law by process of interpretation but do have power to mend it so as to be
in conformity with the intendment of the legislature. Doctrine of reading down is one
of the principles of interpretation of statute in that process. But when the offending
language used by the legislature is clear, precise, and unambiguous, violating the
relevant provisions in the Constitution, resort cannot be had to the doctrine of
reading down to blow life into the void law to save it from unconstitutionality or to
confer jurisdiction on the legislature. Similarly, it cannot be taken aid of to
emasculate the precise, explicit, clear and unambiguous language to confer arbitrary,
unbridled and uncanalised power on an employer which is a negation to just, fair and
reasonable procedure envisaged under Articles 14 and 21 of the Constitution and to
direct the authorities to record reasons, (sic) unknown or unintended procedure, in
the manner argued by the learned counsel for the appellants.” (emphasis supplied)
(f). In D.T.C. (supra) this Court also relied upon S.G. Jaisinghani v.
Union of India, AIR 1967 SC 1427 :
“331. x x x “In this context it is important to emphasise that the absence of arbitrary power is the
first essential of the rule of law upon which our whole constitutional system is based. In a system
governed by rule of law, discretion, when conferred upon executive authorities, must be confined
within defined limits. The rule of law from this point of view means that decisions should be made
by the application of known principles and rules and, in general, such decisions should be
predictable, and the citizen should know where he is. If a decision is taken without any principle or
without any rule, it is unpredictable, and such a decision is the antithesis of a decision taken in
accordance with the rule of law. (See Dicey: Law of the Constitution, 10th edn., Introduction cx.)
‘Law has reached its finest moments,' stated Douglas, J. in United States v. Wunderlich 342 US 98,
‘when it has freed man from the unlimited discretion of some ruler …. Where discretion is absolute,
man has always suffered.’ It is in this sense that the rule of law may be said to be the sworn enemy of
caprice. Discretion, as Lord Mansfield stated it in classic terms in the case of John Wilkes (1770) 4
Burr 2528, ‘means sound discretion guided by law. It must be governed by rule, not by humour: it
must not be arbitrary, vague and fanciful’”.
(emphasis supplied)Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

(g). The Court emphasised that the decision has to be predictable and it cannot be uncertain. The
decision has to be taken by application of known principles and rules. The exercise of power cannot
be whimsical or capricious. This Court in D.T.C. (supra) held:
“332. In an appropriate case where there is no sufficient evidence available to inflict
by way of disciplinary measure, penalty of dismissal or removal from service and to
meet such a situation, it is not as if that the authority is lacking any power to make
rules or regulations to give a notice of opportunity with the grounds or the material
on records on which it proposed to take action, consider the objections and record
reasons on the basis of which it had taken action and communicate the same.
However, scanty the material may be, it must form foundation. This minimal
procedure should be made part of the procedure lest the exercise of the power is
capable of abuse for good as well as for whimsical or capricious purposes for reasons
best known to the authority and not germane for the purpose for which the power
was conferred. The action based on recording reasoning without communication
would always be viewed with suspicion. Therefore, I hold that conferment of power
with wide discretion without any guidelines, without any just, fair or reasonable
procedure is constitutionally anathema to Articles 14, 16(1), 19(1)(g) and 21 of the
Constitution. Doctrine of reading down cannot be extended to such a situation.”
(emphasis supplied)
53. On the basis of aforesaid principles, it is apparent that once the Central Board of
Directors accepted the memorandum for making payment of pension, in case it was
not accepting the proposal in the memorandum, it ought to have said clearly that it
was not ready to accept the proposals of the Government and the IBA and rejects the
same. Once it approved the proposals referred to in the memorandum, which were on
the basis of IBA's letter and Government of India's decision it was bound to
implement it in true letter and spirit. By accepting the same, binding obligation was
created upon the SBI to make payment of pension on completion of 15 years of
service. It cannot invalidate its own decision by relying on fact it failed to amend the
rule, whereas other Banks did it later on with retrospective effect.
They cannot invalidate otherwise valid decision by virtue of exclusive superior power to amend or
not to amend the rule and act unfairly and make the entire contract unreasonable based on
misrepresentation. It was open to the Board of Directors to reject the proposal. Once it accepted the
proposal to make payment of pension on completion of 15 years of service as proposed in the
memorandum, though the scheme is tried to be interpreted by the SBI that pension was to be
admissible as provided in the rule that refers to proportionate pension as noted by this Court in O.P.
Swarnakar & Ors., (supra), and what was decided by Government of India/IBA, was not taken away
rather adopted by the Central Board of Directors. The scheme of contractual nature has to be read in
the context and in the backdrop of facts and what has been resolved by the Board of Directors. There
is no ambiguity with respect to the admissibility of pension when the memorandum and the scheme
are read together. In case of ambiguity and even if two interpretations are possible in the backdrop
of facts of the case, one in favour of the employees has to be adopted and so−called clarificationAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

dated 11.1.2000 even if considered in the manner so as to deny the benefit of pension, has to be held
to be unenforceable, illegal and contrary to law.
54. It is apparent from the eligibility clause of the VRS scheme that eligibility is provided for the
employees having 15 years of pensionable service and they will be entitled for benefits as provided in
the scheme. The eligibility clause, when read with clauses providing the benefit, i.e., clauses 5 and 6
of the scheme, leaves no room for any doubt and makes it clear that employees with 15 years of
service were treated as eligible to claim the benefit of the scheme floated by SBI. It was not the
provision in the VRS scheme that incumbents having completed 20 years of service would be
entitled for pensionary benefits. The scheme was carved out specially for attracting the employees
by providing pension and other benefits to eligible persons like ex gratia, gratuity, pension and leave
encashment. Deprivation of pension would make them ineligible for the benefits and would run
repugnant to the eligibility clause.
55. The submission raised on behalf of the SBI that the draft scheme nowhere stipulated that 15
years’ service would be the eligibility or that on completion of 15 years' service, the incumbent would
be eligible for pension, is factually incorrect. It is apparent from the material circumstances,
documents, and correspondence that the decision was taken at all levels including the one by the
Central Board of Directors of SBI, that the benefit of pension was to be given to the employees on
completion of 15 years of service. In that perspective, vagueness of scheme of SBI, if any, can be of
no advantage as it is clear beyond the pale of doubt that pension was heart and soul of the scheme
with ex gratia on completion of 15 years of service. It is due to the reason that the benefit was to be
accorded to the incumbents having completed 15 years of service, Regulation 28 as applicable to
other nationalised banks was proposed to be modified as reflected in the letter of IBA dated
11.12.2000 and Government of India letter dated 5.9.2000. Later on, the regulation was amended in
2002 after the scheme had already been implemented in right earnest. There was not even an iota of
doubt that VRS was to give benefits to all eligible employees having completed 15 years of service. It
was apparent from the letter dated 29.12.2000 of SBI that the guidelines of IBA were approved by
the Central Board of Directors in its meeting dated 27.12.2000. Para 2 of the letter dated 29.12.2000
of SBI Deputy Managing Director−cum−SDO is extracted hereunder:
"2. Accordingly, the Central Board of Directors, in its meeting held on 27.12.2000,
has accorded approval for adopting and implementing the Voluntary Retirement
Scheme for the employees of the Bank, namely "SBI Voluntary Retirement Scheme
(SBIVRS).” The Scheme "SBIVRS" has been drawn up, keeping in view the guidelines
issued by IBA. A copy of the Scheme is placed at Annexure ‘B’.” (emphasis supplied)
56. As noted in O.P. Swarnakar & Ors., (supra), the case of bank itself was that it was
a contractual scheme. The expression "pension"
as per rules was only for the purpose of working out the proportionate pension. It was clearly
decided to open the scheme to employees who have put in 15 years of service. It was not provided in
the scheme that the incumbent was required to render a pensionable service of 20 years as per the
rules in order to acquire eligibility for the pension. The submission made on behalf of SBI is tooAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

tenuous to be accepted. It was observed in para 89 of O.P. Swarnakar & Ors., (supra) quoted above
that the employee must have proceeded on the basis of 15 years of service then they were entitled to
pensionary benefits.
The Court further observed in O.P. Swarnakar & Ors., (supra) that the scheme is enforceable thus:
“92. However, the case of the State Bank of India stands slightly on a different
footing. Firstly, the State Bank of India had not amended the Scheme. It, as noticed
hereinbefore, even permitted withdrawal of the applications after (sic by) 15th
February. The Scheme floated by the State Bank of India contained a clause (clause 7)
laying down the mode and manner in which the application for voluntary retirement
shall be considered. The relevant clause, as referred to hereinbefore, creates an
enforceable right. In the event the State Bank failed to adhere to its preferred policy,
the same could have been specifically enforced by a court of law. The same would,
therefore, amount to some consideration."
57. While construing a contract, the language and surrounding circumstances of the
overall scheme, memorandum and letters are to be read conjointly to find out
whether any departure made by the Board of Directors in its Resolution dated
27.12.2000 is of pivotal significance. In this case, the decision was taken by it of
approval of the IBA scheme as proposed. Its binding effect cannot be changed on the
basis what parties choose to say afterward, nor they can be permitted to wriggle out.
The contract is required to be read as a whole. It is apparent on a bare reading that
optees will be eligible for proportionate pension under the Pension Regulations of the
bank and therefore, the bank bears the risk of lack of clarity, if any.
58. In Bank of India & Anr. v. K. Mohandas & Ors., (2009) 5 SCC 313 wherein several
other banks were also parties, the question arose as to the nature of VRS, 2000. The
Court noted the objectives, the amendment made in Regulation 28 in 2002,
providing for 15 years of service. The scheme was open in November−December,
2000 and in Union Bank of India in January, 2001. The employees claimed that
those who completed 20 years of service, were entitled to the benefit of provisions
contained in Regulation 29(5) of Employees’ Pension Regulations, 1995 applicable to
the said banks. They claimed having completed the qualifying service of 20 years
under Regulation 29, were entitled for 5 years’ increase in the service tenure subject
to the maximum of 33 years which was not given to them on the ground that the
benefit of VRS was available to incumbents having completed 15 years of service as
provided in amended Regulation 28, and Regulation 29 was not applicable. This
Court held that the benefit of VRS was available to the employees having completed
15 years of service, but the additional benefit which was available on completion of 20
years of service was also admissible as provided in Regulation 29(5).
59. While considering the aforesaid similar scheme of VRS, this Court observed with
respect to the construction of the contract on the basis of the import of the words.Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

The intention of the parties must be ascertained from the language they have used
and considered in the light of surrounding circumstances, and the meaning cannot be
changed by a course of conduct adopted by the parties in acting under it. This Court
in K. Mohandas (supra) held thus:
“28. The true construction of a contract must depend upon the import of the words
used and not upon what the parties choose to say afterwards. Nor does subsequent
conduct of the parties in the performance of the contract affect the true effect of the
clear and unambiguous words used in the contract. The intention of the parties must
be ascertained from the language they have used, considered in the light of the
surrounding circumstances and the object of the contract. The nature and purpose of
the contract is an important guide in ascertaining the intention of the parties.
29. In Ottoman Bank of Nicosia v. Ohanes Chakarian, Lord Wright made these
weighty observations: (AIR p. 29) “… that if the contract is clear and unambiguous,
its true effect cannot be changed merely by the course of conduct adopted by the
parties in acting under it.”
30. In Ganga Saran v. Firm Ram Charan Ram Gopal AIR 1952 SC 9, a four−Judge
Bench of this Court stated: (AIR p. 11, para
6) “6. … Since the true construction of an agreement must depend upon the import of
the words used and not upon what the parties choose to say afterwards, it is
unnecessary to refer to what the parties have said about it.”
31. It is also a well−recognised principle of construction of a contract that it must be
read as a whole in order to ascertain the true meaning of its several clauses and the
words of each clause should be interpreted so as to bring them into harmony with the
other provisions if that interpretation does no violence to the meaning of which they
are naturally susceptible. (North Eastern Railway Co. v. Lord Hastings, 1900 AC
260)”
60. With respect to lack of clarity in the scheme, this Court in K. Mohandas (supra)
relied on maxim verba chartarum fortius accipiuntur contra proferentem to hold that
banks who were responsible for formulation of the terms in the contractual Scheme,
bear the risk of lack of clarity. Thus, the benefit has to be given to the employees by
making interpretation against the banks. The Court held :
“32. The fundamental position is that it is the banks who were responsible for
formulation of the terms in the contractual Scheme that the optees of voluntary
retirement under that Scheme will be eligible to pension under the Pension
Regulations, 1995, and, therefore, they bear the risk of lack of clarity, if any. It is a
well−known principle of construction of a contract that if the terms applied by one
party are unclear, an interpretation against that party is preferred (verba chartarumAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

fortius accipiuntur contra proferentem).
33. What was, in respect of pension, the intention of the banks at the time of bringing
out VRS 2000? Was it not made expressly clear therein that the employees seeking
voluntary retirement will be eligible for pension as per the Pension Regulations? If
the intention was not to give pension as provided in Regulation 29 and particularly
sub−regulation (5) thereof, they could have said so in the Scheme itself. After all,
much thought had gone into the formulation of VRS 2000, and it came to be framed
after great deliberations. The only provision that could have been in mind while
providing for pension as per the Pension Regulations was Regulation 29.
Obviously, the employees, too, had the benefit of Regulation 29(5) in mind when they offered for
voluntary retirement as admittedly Regulation 28, as was existing at that time, was not applicable at
all. None of Regulations 30 to 34 was attracted."
(emphasis supplied)
61. In K. Mohandas (supra) the Court considered the argument that Regulation 28 would be
applicable only for providing 15 years of eligibility as provided by way of amendment of Regulation
of 1995, and held that as the banks are “State” within the meaning of Article 12, it would be an
arbitrary action on their part to deny the benefit of section 29(5), and there has to be harmonious
construction to the scheme and Pension Regulations, thus:
“35. We are afraid; it would be unreasonable if amended Regulation 28 is made
applicable, which had not seen the light of the day and which was not the intention of
the banks when the Scheme was framed. The banks in the present batch of appeals
are public sector banks and are "State" within the meaning of Article 12 of the
Constitution and their action even in contractual matters has to be reasonable, lest,
as observed in O.P. Swarnakar (2003) 2 SCC 721, it must attract the wrath of Article
14 of the Constitution.
36. Any interpretation of the terms of VRS 2000, although contractual in nature,
must meet the test of fairness. It has to be construed in a manner that avoids
arbitrariness and unreasonableness on the part of the public sector banks who
brought out VRS 2000 with an objective of rightsizing their manpower. The banks
decided to shed surplus manpower. By formulation of the special scheme (VRS
2000), the banks intended to achieve their objective of rationalising their force as
they were overstaffed. The special Scheme was, thus, oriented to lure the employees
to go in for voluntary retirement. In this background, the consideration that was to
pass between the parties assumes significance and a harmonious construction to the
Scheme, and the Pension Regulations, therefore, has to be given.
37. The amendment to Regulation 28 can, at best, be said to have been intended to
cover the employees with 15 years of service or more but less than 20 years of service.Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

This intention is reflected from the communication dated 5−9−2000 sent by the
Government of India, Ministry of Finance, Department of Economic Affairs (Banking
Division) to the Personnel Advisor, Indian Banks’ Association.” (emphasis supplied)
It opined that the amendment to Regulation 28 of 1995 Regulation intended to cover
15 years of service, i.e., employees with 15 years of service who have not completed 20
years of service. A similar action to amend the Rule was required to be taken by the
SBI, but it failed to take it after having floated a similar scheme. It kept it uncertain
what would be the position of the rule as on the appointed date, i.e., 31.3.2001. Be
that as it may. But it was crystal clear that the incumbent with 15 years of service was
eligible for the benefit as provided in the scheme itself. The benefit clause has to be
read with the eligibility criteria. Once VRS was formulated and adopted by the SBI in
toto, it constituted a complete contractual package in itself.
62. As urged on behalf of SBI if section 23 of the Contract Act is applied, then how it is helpful to the
bank, is not understandable. In case it is held that the very scheme was opposed to the law/rules, the
entire scheme would fall down. Once it adopted the scheme, invited applications and the employees
acted upon it and retired on the basis of the scheme, they cannot be left in lurch. In case its
submission is accepted, the Scheme becomes violative of Section 23 of Contact Act, the bank would
have to suffer the consequences of striking down of the very scheme and would be required to
reinstate the employees and to pay them the salary and other benefits. However, SBI accepted the
scheme, it was incumbent upon it to bring the rules in consonance with the similar VRS scheme as
was done by other banks. The SBI accepted the scheme on 27.12.2000 without any ifs and buts.
Thus, the anomaly was the outcome of the bank's inaction to propose and make amendment of
rules. In such a scenario, the action of SBI is violative of Articles 14, 16 and 21 of the Constitution.
The situation created by itself is not going to benefit the bank to lend support to arbitrary action.
The bank was bound to extend the benefits by amending the rules, if necessary, to salvage the
situation for itself. Breach of law has been committed by the SBI itself, its action is arbitrary and it
cannot be permitted to take advantage of its own wrong.
63. The pension cannot be dealt with arbitrarily and cannot be denied in an unfair manner. The
concept of pension was considered in D.S. Nakara & Ors. v. Union of India, (1983) 1 SCC 305. The
right to a pension can be enforced through the court, it observed :
“20. The antequated notion of pension being a bounty, a gratuitous payment
depending upon the sweet will or grace of the employer not claimable as a right and,
therefore, no right to pension can be enforced through Court has been swept under
the carpet by the decision of the Constitution Bench in Deokinandan Prasad v. State
of Bihar (1971) 2 SCC 330 wherein this Court authoritatively ruled that pension is a
right and the payment of it does not depend upon the discretion of the Government
but is governed by the rules and a government servant coming within those rules is
entitled to claim pension. It was further held that the grant of pension does not
depend upon anyone’s discretion. It is only for the purpose of quantifying the amount
having regard to service and other allied matters that it may be necessary for the
authority to pass an order to that effect but the right to receive pension flows to theAssistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

officer not because of any such order but by virtue of the rules. This view was
reaffirmed in State of Punjab v. Iqbal Singh, (1976) 2 SCC 1.
22. In the course of transformation of society from feudal to welfare and as socialistic
thinking acquired respectability.
State obligation to provide security in old age, an escape from undeserved want was recognised and
as a first step pension was treated not only as a reward for past service but with a view to helping the
employee to avoid destitution in old age. The quid pro quo was that when the employee was
physically and mentally alert, he rendered unto master the best, expecting him to look after him in
the fall of life. A retirement system, therefore, exists solely for the purpose of providing benefits. In
most of the plans of retirement benefits, everyone who qualifies for normal retirement receives the
same amount (see Retirement Systems for Public Employees by Bleakney, p.
33).” This Court observed that the principal aim of the socialist State as envisaged in the Preamble is
to eliminate inequality. The basic framework of socialism is to provide security in the fall of life to
the working people and especially provides security from the cradle to the grave when employees
have rendered service in heydays of life, they cannot be destituted in old age, by taking action in an
arbitrary manner and for omission to complete obligation assured one. Though there cannot be
estoppel against the law but when a bank had the power to amend it, it cannot take shelter of its own
inaction and SBI ought to have followed the pursuit of other banks and was required to act in a
similar fair manner having accepted the scheme.
64. Resultantly, we are of the opinion that the employees who completed 15 years of service or more
as on cut−off date were entitled to proportionate pension under SBI VRS to be computed as per SBI
Pension Fund Rules. Let the benefits be extended to all such similar employees retired under VRS
on completion of 15 years of service without requiring them to rush to the court. However,
considering the facts and circumstances, it would not be appropriate to burden the bank with
interest. Let order be complied with and arrears be paid within three months, failing which amount
to carry interest at the rate of 6 per cent per annum from the date of this order. The appeals are
accordingly disposed of. No costs.
                                             …………………………J.
                                             (Arun Mishra)
                                             ………………….……..J.
                                             (M.R. Shah)
New Delhi;                                   …….…………………..J.
March 2, 2020.                               (B.R. Gavai)Assistant General Manager State Bank Of ... vs Radhey Shyam Pandey on 2 March, 2020

