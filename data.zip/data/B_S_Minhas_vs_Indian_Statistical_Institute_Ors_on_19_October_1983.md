B.S. Minhas vs Indian Statistical Institute & Ors on 19 October,
1983
Equivalent citations: 1984 AIR 363, 1984 SCR (1) 395, AIR 1984 SUPREME
COURT 363, 1984 LAB. I. C. 15, 1984 UJ (SC) 77, (1984) KER LT 5, (1983) 96
MAD LW 187, 1984 (16) LAWYER 1 (1), (1984) 1 LABLJ 67, (1984) 1 LAB LN
239, (1984) 1 SERVLJ 217, 1984 SCC (L&S) 26, 1983 (4) SCC 582
Author: R.B. Misra
Bench: R.B. Misra, P.N. Bhagwati
           PETITIONER:
B.S. MINHAS
        Vs.
RESPONDENT:
INDIAN STATISTICAL INSTITUTE & ORS.
DATE OF JUDGMENT19/10/1983
BENCH:
MISRA, R.B. (J)
BENCH:
MISRA, R.B. (J)
BHAGWATI, P.N.
CITATION:
 1984 AIR  363            1984 SCR  (1) 395
 1983 SCC  (4) 582        1983 SCALE  (2)574
 CITATOR INFO :
 R          1986 SC1571  (57)
 RF         1991 SC1173  (5)
ACT:
Constitution of India. Articles 12 and 32.
     Indian Statistical Institute-A society registered under
the Societies  Registration Act-Financed  and controlled  by
Central Government-Whether  'other authority' within meaning
of Article  12-Whether amenable  to writ  jurisdiction under
Article 32.
Civil Service
     Indian  Statistical  Institute-Director-Vacancy  of-Bye
law No.  2 of  Institute require  vacancy to  be  publicised
before  recruitment-Whether   obligatory  for  Institute  to
follow  the   bye-law-No  minutes   of  selection  committee
maintained or  circulated amongst  members-Selection whetherB.S. Minhas vs Indian Statistical Institute & Ors on 19 October, 1983

valid.
Indian Statistical  Institute Act  1959 Ss 4, 5, 6, 7, 9
and 12.
     Indian  Statistical   Institute-Institute  of  National
Importance-Whether 'other  authority' within  the meaning of
Article 12 of the Constitution.
HEADNOTE:
     The Indian  Statistical Institute  was registered under
the Societies  Registration Act,  and governed by the Indian
Statistical Institute  Act,  1959.  Its  control  completely
vested in  the Union  of India,  respondent  no.  5  in  the
appeal. The  Institute had been declared as an 'Institute of
National Importance.
     The chief  executive body  of  the  Institute  was  the
Council, respondent  no. 2  which consisted of 25 members of
whom three  were representatives  of the Central Government.
The Council  was headed  by a  chairman who  was elected. In
order  to   discharge  the   administrative   and   academic
responsibility of  the Institute a Director was appointed by
the Council. Respondent no. 4 was appointed as a Director.
     The petitioner  in his  Writ  Petition  challenged  the
appointment of  respondent no. 4 on the ground that he was a
person] of  much higher  academic and  other accomplishments
and far superior to the said respondent.
396
     In the  Writ Petition  it was  contended: (i) Bye-law 2
expressly requires  that the  vacancy of Directorship should
be suitably  publicised but in the present case no publicity
whatsoever  was   given  to  the  vacancy  of  Directorship.
Publicity was  necessary if  the appointment  was to be fair
and free from partiality and that many were not aware of the
vacancy of  the post  of Director  till the  actual order of
appointment was  made. (ii)  He was  eminently suitable  for
being  appointed   to  the  post  in  view  of  the  various
contributions in  the field  of his work and the active part
played by  him in  resolving the  administrative problems of
the Institute,  and (iii)  no bio-data  or  information  was
placed before  the Council  which under the bye-laws was the
appointing authority  to enable  the members  to  gauge  the
comparative suitability of various candidates.
     The petition  was resisted on behalf of respondent Nos.
1 and  2 by contending: (i) the petition is not maintainable
under Article  32 of  the Constitution as respondents Nos. 1
and 2  are not  'state'  or  'other  authority'  within  the
meaning of  Art. 12  of the Constitution. (ii) Even assuming
that there has been a violation of bye-law 2 no writ can lie
to correct  the same as the alleged bye-law has no statutory
basis inasmuch  as the  Institute has  been declared  as  an
Institution of  National Importance', the bye-laws not being
statutory the respondents are under no obligation to observeB.S. Minhas vs Indian Statistical Institute & Ors on 19 October, 1983

the procedure  Laid down  therein, and  (iii) the petitioner
was duly and properly considered for selection to the post.
     Allowing the writ petition,
^
     HELD: (i) The order of appointment dated August 3, 1979
of Respondent  No. 4  as the Director of Respondent No. 1 is
quashed and  set aside.  Before Respondent No. 1 proceeds to
select a  new Director,  it will comply will the requirement
of bye-law  2 by giving suitable publicity to the vacancy in
the office or Director. [413 F]
     (ii) There  can be no doubt that respondent No. 2 is an
'authority'  within   the  meaning  of  Article  12  of  the
Constitution and,  therefore, the writ petition filed by the
petitioner is competent and maintainable. [409 G]
     In the instant case, the money required for funding the
Institute is provided entirely by the Central Government and
even if any other moneys are to be received by the Institute
it can  be done  only  with  the  approval  of  the  Central
Government, and  the accounts  of the Institute have also to
be submitted  to the Central Government for its scrutiny and
satisfaction. The  Society has to comply with all directions
as may  be issued  by the Central Government. The control of
the Central Government is deep and pervasive and, therefore,
it is  an instrumentality  of the  Central Government and as
such is  an 'authority'  within the meaning of Article 12 of
the  Constitution.   It  is,   therefore,  subject   to  the
constitutional obligations  under Articles  14 and 16 of the
Constitution. [408 C-D]
     Ajay Hasia  etc. v. Khalid Mujib Sehravardi & Ors. etc.
[1981] 2 SCR 79 referred to
397
     2. (i) It is obligatory on the part of respondent No. 1
to follow the bye-laws for the bye-laws have been framed for
the conduct of its affairs to avoid arbitrariness. [410 G]
     (ii) Compliance with bye-law 2 seems to be necessary in
the name  of fair-play.  If  the  vacancy  in  the  post  of
Director had  been publicised  as contemplated by bye-law 2,
all the  persons eligible  for the post may have applied and
in that  case, the  field of  consideration would  have been
enlarged and  the selection  committee or  the Council would
have had  a much  larger field from which to choose the best
available reason  and that  would have  removed all doubt of
arbitrariness from  the mind of those eligible for the post.
[411 B]
     Ramana  Dayaram   Shetty   v.   International   Airport
Authority of  India (1979)  3 SCR 1014; Viteralli v. Seton 3
Law Fd.  Second Series 1012; A.S. Ahluwalia v. Punjab [1975]
3 SCR 82; Sukhdev v. Bhagatram [1975] 3 SCR 619 referred to.
     (iii) In the case of appointment of a Director, bye-law
2 clearly  provides for publicity, the object being that all
concerned may know about the vacancy and either applications
or recommendations may be made for the post and the names of
the eligible  candidates may be brought before the selectionB.S. Minhas vs Indian Statistical Institute & Ors on 19 October, 1983

committee for its consideration. [412 H-413 A]
     (iv) It  is not  suggested that  appointments to  every
post must  be made only after advertising or publicising the
vacancy. That  would not be right, for there are quite a few
posts at  the top  level as  for example  Commander of Armed
Forces or  the Chief  Justice or  the Judges  of the Supreme
Court or  the High  Court, which cannot be and should not be
advertised or  publicised, because  they are posts for which
there should  be no  lobbying nor should any applications be
allowed to be entertained. [411 C-D]
     (v) It  is not  for the  Court to  determine who is the
superior of  the two  candidates and who should be selected.
It is  for the  authorities concerned to select from amongst
the available  candidates.  The  members  of  the  selection
committee as  also the  members of  the Council were eminent
persons and  they may be presumed to have taken into account
all relevant  considerations before  coming to a conclusion.
But in  the absence  of publicity as contemplated by bye-law
2, it  cannot be  said that all other qualified persons like
the  petitioner   were  also  considered  by  the  selection
committee for appointment, in the absence of any application
by them  for the  post or  any recommendation of them by any
other authority or individual. [412 C-E]
     3. It  is always  desirable that  in public  bodies the
minutes of  the proceedings  regarding selection  should  be
properly maintained  in order  to obviate  any suspicion  or
doubt and  such minutes  along with  the relevant  documents
should be  placed before  the final authority entrusted will
the task of selection for appointment. [412 A]
     In the instant case, there is nothing on record to show
that the  Council was  at any time informed as to what names
had been  considered by  the selection committee or that the
names of  the petitioner  had been considered but respondent
No. 4 was found superior. [411 H]
398
JUDGMENT:
ORIGINAL JURISDICTION: Writ Petition No. 1519 of 1979. (Under article 32 of the Constitution of
India ) V.M. Tarkunde, P.H. Parekh and Miss Caprihan for the Petitioner R.R. Garg, L.R. Singh and
Gopal Singh for Respondents 1 & 2.
D.P. Singh, L.R. Singh and Mr. Gopal Singh for Respondents 3 & 4.
Harbans Lal and G.S. Narain for Respondent No. 5. Miss A. Subhashini, C.V. Subba Rao and R.N.
Poddar for the Union of India.
The Judgment of the Court was delivered by MISRA J.: By the present petition under Article 32 of
the Constitution the petitioner seeks to challenge the appointment of Shri B.P. Adhikari, respondentB.S. Minhas vs Indian Statistical Institute & Ors on 19 October, 1983

No. 4, as the Director of the Indian Statistical Institute, respondent No.
1. The Indian Statistical Institute is a Society registered under the Societies Registration Act. It is
governed by the Indian Statistical Institute Act, 1959 (hereinafter referred to as 'the Act'). Its control
completely vests in the Union of India, respondent No. 5. It is wholly financed by the Union of India.
All the functions of the Institute are controlled by the Union of India, as is evident from the various
provisions of the Act. Under s. 8 of the Act the annual work programmes of the Institute and the
general financial estimates in respect of such work are settled by committees appointed by the
Central Government and the Institute obviously cannot undertake any research or training
programmes without the approval of the Central Government. The Institute carries on an integrated
programme of training, teaching and research in statistics and application of statistical techniques
in other disciplines. The Institute has been declared as an 'Institution of National Importance' under
the Act. Under s. 4 of the Act the Institute has been empowered to grant such degrees and diplomas
in statistics as may be determined by the Institute from time to time. In accordance with the
provisions of s. 5 of the Act the Central Government pays to the Institute in each financial year such
sums of money as the Government considers necessary by way of grant. Loan or otherwise to enable
the Institute to discharge efficiently its functions including research, education, training, project
activities and statistical work relating to planning for national development. Section. 6 of the Act
deals with audit of accounts of the Institute by auditors duly qualified to act as auditors of
companies under the Companies Act, 1956 and selected by the Central Government after
consultation with the Comptroller and Auditor-General of India. Section 7 of the Act restricts the
powers of the Institute to alter, extend or abridge its memorandum or rules and regulations and to
sell or otherwise dispose of its property acquired with the money specifically provided for such
acquisition by the Central Government except with the previous approval of the Central
Government. Section 9 empowers the Central Government to constitute a committee, inter alia, for
reviewing and evaluating the work done by the Institute and the progress made by it as also advising
Government generally on any matter which in the opinion of the Central Government is of
importance in connection with the work of the Institute. Section 11 of the Act empowers the Central
Government to issue directions to the Institute. Section 12 authorises the Central Government to
assume control over the Institute under certain extreme circumstances.
The Institute receives grants from the Central Government to meet almost the entire expenditure on
its plan and non-plan activities. The chief executive body of the Institute is the Council, respondent
No. 2, consisting of 25 members including three representatives of the Central Government. The
Council is headed by the Chairman elected to that position by the Council by a simple majority from
amongst the names proposed by the President or members of the Council. The election of the
Chairman of the Council is governed by bye-laws of the Institute.
The initial appointment to carry out research and teaching work is to the post of professor. The next
post in the hierarchy is of Research professor and the highest in the hierarchy is the post of
Distinguished scientist. In order to discharge the administrative and academic responsibilities of the
Institute, a Director, with distinctive administrative and academic acumen, is appointed by the
Council, respondent No. 2. Shri B. P. Adhikari, respondent No. 4, was appointed as the Director of
the Institute by an order dated 3rd August, 1979. This order of appointment has been challenged byB.S. Minhas vs Indian Statistical Institute & Ors on 19 October, 1983

the petitioner on various grounds.
According to the petitioner he was a Distinguished Scientist of the Institute at the relevant time. To
start with, he was appointed to the post of Economist in the Indian Statistical Institute on 1st
October, 1962 on a monthly pay of Rs. 1000/- in the time scale of RS. 750-50- 1250 plus special pay
of Rs. 350/- per month. Within a year he was promoted as Professor in the time scale of Rs. 1000-
50-1500 with a starting pay of Rs 1400/- per month, and from 1st October, 1967 he had been
holding the post of Research Professor in the time scale of Rs. 1600-100-1900. On 1st January 1968
he was made officer-in-Charge and. entrusted with all technical matters, administration and
developmental plans relating to planning and regional survey units special training in Delhi. He was
given a allowance of Rs. 200/- per month over and above the pay in the time scale of Research
Professorship. The petitioner has been responsible during the period 1962-1974 for the creation and
promotion of several new activities of respondent No. 1 in Delhi. Specialised training in National
Planning and Econometrics for M. Stat. (2nd Year) trainees of respondent No. 1 was started in Delhi
under the direction of the petitioner. In August 1974 the petitioner was designated as Head of the
Delhi Centre and was also appointed to the Institute's Committee of Administration. On 12th March
1976 he was elevated to the position of 'Distinguished Scientist' with pay of Rs. 3000/- per month
plus allowances. The petitioner has held responsible positions as Visiting Professor, Fellow,
Chairman, Consultant, Research Associate, Lecturer etc. in various Universities in India and in the
United States of America and England. He has been a member of the planning Commission,
Government of India from January 1971 to December, 1973 and he has also been a member of the
Sixth Finance Commission from July 1972 to October 1973. The petitioner's work has been
acclaimed in the international as well as national spheres. His work is rated high as evidenced by the
award of Dadabhai Nauroji Memorial Prize for Economics in 1974 and the Jawaharlal Nehru
Memorial Fellowship in 1975. In 1976 the petitioner had the distinction of presiding over the annual
conference of the Indian Society of agricultural Economics. People abroad have also conferred
recognition on the petitioner.
The petitioner's scientific output has been substantial. He has been active in research and he has
published books. Of importance on Theory of International Trade, Scheduling the operations of
Multipurpose Reservoirs, Indian Planning, Planning and the Poor etc. His contributions in the form
of articles in collaboration with Indian and foreign economists have been published in several
journals in India and abroad. One of his co authors, Prof. Arrow is a Nobel Laureate. At present the
petitioner is engaged in research on the following subjects:
1. Growth, Poverty and Basic Need, Development Policy in Sri Lanka, Kerala and
Punjab.
2. Inter-Regional Comparisons of Agricultural Growth and Development in South
Asia in the post-colonial period.
It is claimed that a comparative evaluation of the achievements of the petitioner with those of
respondent No. 4 clearly shows the superiority of the petitioner over respondent No. 4. Respondent
No. 4 had joined the Institute as Professor in the pay scale of Rs. 750-1250. He was appointed inB.S. Minhas vs Indian Statistical Institute & Ors on 19 October, 1983

Delhi and was incharge of the evening course in Introductory Statistics. He served in Delhi for about
a year and then went to Calcutta and continued as professor from 1961 to 1974. In contrast, the
petitioner had started at a higher salary of Rs. 1000 p.m. plus a special pay of Rs 50 p.m. The
petitioner had been promoted to the higher rot of Research Professor on 1st October, 1967 in the
time scale of Rs.1600-100-1900 while respondent No. 4 had been promoted to the post of Research
Professor only in 1974. At that time respondent No.4's appointment as Research professor had been
objected to as he had not published any technical paper since his joining the Institute in 1961. The
petitioner was senior to respondent No 4 as he had been appointed to the higher post of Research
Professor earlier than respondent No.4. On 12th March 1976 the petitioner was promoted to the
position of a Distinguished Scientist. The petitioner is senior to respondent No. 4 and all other
scientists of the Institute. The petitioner's elevation to the position of Distinguished Scientists came
much earlier than that of respondent No. 4. The petitioner has been holding the position of
Distinguished Scientist since 12th March 1976 while respondent No. 4 was not a Distinguished
Scientist till his impugned appointment as Director. Respondent No.4 has won no laurels in his
sphere of work and his scientific output has been negligible. Thus, from all accounts the petitioner
was more qualified and his achievements in all spheres were much higher than those of respondent
No. 4 or for the matter of that, than those of any other scientist of the Institute.
The Institute has an academic council consisting of the following members among others:
"1. All Professors, Research Professors and Distinguished Scientists.
2. ........
3. ........
4. ........
5. .........
6. ........
7. Director (as Chairman of the academic council)."
The Institute is governed by its memorandum, regulations and bye Laws in the conduct of its affairs.
Bye-law 2 provides the procedure for the appointment of a Director. It reads:
"The appointment of the Director shall be made by the Council on the
recommendation made by a Selection Committee consisting of
(i) Chairman of the Council (as Chairman),
(ii) Two experts approved by the Council.B.S. Minhas vs Indian Statistical Institute & Ors on 19 October, 1983

Before recruitment the Vacancy for Directorship should be suitably Publicised."
In the meeting of the Council, respondent No. 2, on 16th April, 1979, Shri P.N. Haksar, respondent
No. 3, the Chairman, reported about the absence of the Director and other allied matters and invited
the attention of the members' to the fact that the Director of the Institute, Prof. G. Kallianpur is
unable to devote full time to the Institute. The Council felt that since the Institute required full time
attention it was desirable that Prof. Kallianpur should be requested to continue in the post of
Director on a whole time basis. The Chairman was authorised to write to the Director conveying the
views of the members and after getting a response from Prof. KallianPur, to take further action. In
case Prof. Kallianpur resigned, the Chairman was authorised to accept his resignation and then to
set up a committee consisting of the following members to select a suitable person for the post of
Director:
1. Shri P.N. Haksar, Chairman.
2. Prof. Bhabatosh Datta.
3. Prof. S.S. Shrikhande.
4. Prof. M.S. Narasimhan.
5. Dr. R Ramanna.
Subsequently another meeting of respondent No. 2 was held on 3rd August, 1979 in which the
Chairman reported that Prof. Kallianpur had resigned from the Directorship of the Institute with
effect from 30th June, 1979 and regarding the appointment of the new Director of the Institute the
Chairman reported that the selection committee, which had been constituted by the Council in its
meeting on 16th of April, 1979 had unanimously recommended the appointment of respondent No.
4 as Director of the Institute. The Council approved the recommendation of the selection committee
and it also approved the terms and conditions of appointment of respondent No. 4 as Director. One
of the terms of appointment of respondent No. 4 was that he should be in the substantive position of
a 'Distinguished Scientist' in the Institute on a monthly salary of Rs. 3000.
When the petitioner came to know about the appointment of respondent No.4 to the post of Director
he felt aggrieved and met respondent No.3, the Chairman of the Council, Shri P.N. Haksar and
expressed his deep unhappiness at the choice of the new Director of respondent No.1. On getting no
favourable response from respondent No.3 the petitioner tried to approach the other members of
the Council to indicate his resentment at the alleged illegality and arbitrariness in the appointment
of respondent No.4. The petitioner addressed a letter to Shri N. Srinivasan, Secretary to respondent
No.2, wherein he referred to the circular dated 4th August, 1979 which he had received intimating
him about the appointment of respondent No.4 as Director of respondent No.1. By this letter the
petitioner pointed out to the Secretary that the appointing authority had not observed the rules and
regulations and bye-laws of the Institute as laid down in the memorandum of association and had
also violated the provisions of Arts. 14 and 16 of the Constitution. He also pointed out that theB.S. Minhas vs Indian Statistical Institute & Ors on 19 October, 1983

vacancy of the post of Director had not been publicised and he being the seniormost researcher
working as Distinguished Scientist of the Institute was not given an opportunity to apply for the
same. He also pointed out the arbitrary manner in which the appointment of respondent No.4 had
been made, and he urged the Institute to rectify the error failing which he might be obliged to take
legal action. The petitioner likewise addressed a letter to another member of the Council, Prof. R.P.
Bambah, who was a Professor of Mathematic in the Centre for advanced Studies, Punjab University
and was one of the two Scientists co-opted by the Council. The petitioner in his letter to Prof.
Bambah complained that with the appointment of respondent No. 4 the Directorship and his
simultaneous designation to the post of Distinguished Scientist, the council had subverted the
academic standards of the Institute and violated the rules and regulations as contained in the
memorandum of association as also the various provisions of the Constitution. Further, the
appointment was arbitrary inasmuch as it was without any regard to the claims of senior and better
known professional persons. He appealed to Prof. Bambah to upheld the academic integrity of the
Institute and initiate corrective action to rectify the wrong and rescue the Institute from
manipulations of unprincipled people. A similar letter was addressed by the petitioner to Shri S.C.
Bhattacharya. Director, Bose Institute, Calcutta, on 31st August, 1979, another member of the
Governing Council of respondent No.1, who was one of the four representatives of the Indian
National Science Academy. He also wrote to Prof. P.V. Sukhatme, Professor of Biometry in Pune,
who was also a distinguished member of the Council. He was awarded the Padma Bhushan and also
held the post of Director of Statistics Division of Food and Agriculture Organisation. A Similar letter
was addressed by him to Shri Subimal Dutt, President of respondent No. 1, reiterating the same
grievances. Similar letters dated 30th and 31st August, 1979 were addressed to Dr. K.C. Seal,
Director, Central Statistical Organisation Government of India and to Shri Kirpa Narain, Secretary,
Department of Statistics' Government of India.
It may be pointed out that the members of the selection Committee and the members of the Council
are all men of eminence and highly qualified persons.
Prof. S.C. Bhattacharya by his letter dated 5th of September, 1979 replied that the contents of the
petitioner's letter were disquieting. He also stated that respondent No.4 had been identified as a
suitable person by a group of eminent people and on the basis of advice received from them the
Council, respondent No.2, had approved the appointment of respondent No.4. the further. stated
that he was not making any further comments in the matter at this stage. He was unaware of
respondent No.4 having been designated as Distinguished Scientist by the Council in the meeting of
3rd August, 1979. Regard in appointment he further said that no report of the selection committee
had been circulated to the members of the Council but the announcement was made orally by the
Chairman. Since it was difficult to hear every word of the Chairman at the meeting he had assumed
that the terms of appointment would be those ordinarily prescribed for the post of Director.
Prof Sukhatme in his reply said that he had not realised the grave issues which such an appointment
could raise. He wanted, however, to assure that there was no intention on their part to subvert the
academic standards of the Institute. He assured the petitioner that he would be writing to the
Secretary on the Council to know what was the procedure tor appointing a person to the post of
Distinguished Scientist and whether the same should have been explained to the Council beforeB.S. Minhas vs Indian Statistical Institute & Ors on 19 October, 1983

adopting the resolution.
Prof. R.P. Bambah on 22nd September, 1979 wrote a letter to Shri P.N. Haksar submitting his
resignation presumably in protest against what had happened in regard to the appointment of
respondent No. 4 as the Director of the Institute. In his letter he stated that he had not received any
official bio-data or information regarding the scientific contribution of respondent No. 4 and other
available candidates for the post of Director to enable him to form his own judgment. He said that
he presumed that the scientific contribution of respondent No. 4 must have been high enough to
warrant his holding the post of Distinguished Scientist. He also expressed the view that since the
committee consisted of eminent scientific working under his guidance, he had presumed that all
relevant factors had been taken into consideration regarding the appointment to the post of
Director, including the quality of candidate's scientific contribution, in coming to a decision. In the
circumstances he has constrained to resign from the Council since he had not displayed due
diligence in the performance of his function as member of the Council.
The petitioner likewise received a letter from the Chairman in A which he did not deny the allegation
contained in the petitioner's letter dated 13th August, 1979 that the vacancy in the post of Director of
respondent No. 1 had not been publicised.
Another meeting of the Council was held on 19th October, 1979 and in this meeting Prof. Raja
Ramanna, Dr. S.C. Bhattacharya and Dr. P.V. Sukhatme were not present and Dr. Bambah had
resigned on 22nd September, 1979. Nonetheless, the proceedings of the meeting of 19th October,
1979 do not allude to Dr. Bambah's resignation. In this meeting the letter of the petitioner was
considered, copies of which had been circulated to the members earlier and the Council decided that
no action was necessary in the matter.
Shri V.M. Tarkunde appearing for the petitioner challenges the appointment of respondent No. 4 on
various grounds:
1. (a) Bye-law 2 expressly requires that the vacancy of the Directorship should be
suitably publicised but in the present case no publicity whatsoever was given to the
vacancy of Directorship.
(b) Even apart from the bye-law, publicity was necessary if the appointment was to be fair and free
from partiality.
(c) The petitioner and many others like him were not aware of the vacancy of the post of Director till
the actual order of appointment of respondent No. 4 was made.
2. The petitioner was eminently suitable for being appointed to the post of Director keeping in view
his various contributions in the field of his work and the active part played by him in resolving the
administrative problems of the Institute.B.S. Minhas vs Indian Statistical Institute & Ors on 19 October, 1983

3. No bio-data or information was placed before the Council which under the bye-laws was the
appointing authority of the Director to enable the members to gauge the comparative suitability of
various candidates for the post of Director. No facts relating to the other candidates were presented
before the selection committee by the Chairman. As such there was no application of mind by the
members of, the Council, since no report was circulated regarding the recommendation of the
selection committee, and the members of the Council took it for granted that all was well.
Shri R.K. Garg appearing for respondents Nos. 1 and 2 resisted the petition on the following
grounds:
(i) that the petition is not maintainable under Art. 32 of the Constitution as
respondent Nos. 1 and 2 are not 'state or other authority' within the meaning of Art.
12 of the Constitution.
(ii) (a) Even assuming, though not conceding, that there has been a violation of
bye-law 2 no writ can lie to correct the same as the alleged bye-law has no statutory
basis inasmuch as by the Indian Statistical Institute Act, 1959 Parliament only
declared the Indian Statistical Institute, respondent No. 1 as an institution of national
importance and if it has made bye-law 2 for its guidance, such bye-law cannot be said
to have any statutory force.
(b) The bye-laws not being statutory the respondents are under no obligation to
observe the procedure laid down in the bye- laws.
(iii) In any case the petitioner was duly and properly considered for selection to the
post of Director and, therefore, he could not possibly make any grievance about
violation of bye-law 2.
In view of the contentions raised by the counsel for the parties the first question that falls to be
considered is whether the writ petition is maintainable.
Article 12 of the Constitution defines 'State' for the purposes of Part III of the Constitution. It reads:
" 12. In this part, unless the content otherwise requires, "the state" includes the
Government and Parliament of India and the Government and the Legislature of
each of the States and all local or other authorities within the territory of India or
under the control of the Government of India."
The learned counsel for the petitioner, Shri Tarkunde has contended that having regard to the
provisions of the Act and the memorandum of association, the composition of respondent No. 1 is
dominated by the representatives appointed by the Central Government. The money required for
running the Institute is provided entirely by the Central Government and even if any other moneys
are to be received by the Institute it can be done only with the approval of the Central Government,
and the accounts of the Institute have also to be submitted to the Central Government for itsB.S. Minhas vs Indian Statistical Institute & Ors on 19 October, 1983

scrutiny and satisfaction. The Society has to comply with all such directions as may be issued by the
Central Government. The control of the Central Government is deep and pervasive and, there fore,
to all intents and purposes, it is an instrumentality of the Central Government and as such is an
'authority' within the meaning of Art. 12 of the Constitution. It is, therefore, subject to the
constitutional obligations under Arts. 14 and 16 of the Constitution. Reliance was placed upon Ajay
Hasia etc. v. Khalid Mujib Sehravardi & Ors. etc. The Constitution Bench in that case took, the view
that the expression 'other authorities' in Art. 12 must be given a broad and liberal interpretation,
where constitutional fundamentals vital to the maintenance of human rights are at stake and
functional realism and not facial cosmetics must be the diagnostic tool, for constitutional law must
seek the substance and not the form The Court pointed out the Government may act through the
instrumentality or agency of juridical persons to carry out its functions, since, with the advent of the
welfare State, its new tasks have increased manifold and such juridical persons acting as the
instrumentality or agency of the Government must therefore be subject to the same discipline of
fundamental rights as the State. Proceeding further the Court observed:
"It is undoubtedly true that the corporation is a distinct juristic entity with a
corporate structure of its own and it carries on its functions on business principles
with a certain amount of autonomy whish is necessary as well as useful from the
point of view of effective, business management, but behind the formal ownership
which is cast in the corporate mould, the reality is very much the deeply pervasive
presence of the Government. It is really the Government which acts through the
instrumentality or agency of the corporation and the juristic veil of corporate
personality worn for the purpose of convenience of management and administration
cannot be allowed to obliterate the true nature-of the reality behind which is the
Government. Now it is obvious that if a corporation is an instrumentality or agency of
the Government it must be subject to the same limitations in the field of
constitutional law as the Government itself, though in the eye of the law it would be a
distinct and independent legal entity. If the government acting through its officers is
subject to certain constitutional limitations, it must follow a fortiori that the
Government acting through the instrumentality or agency of a corporation should
equally be subject to the same limitations. If such a corporation were to be free from
the basic obligation to obey the Fundamental Rights, it would lead to considerable
erosion of the efficiency of the fundamental Rights, for in that event the government
would be enabled to over-ride the Fundamental Rights by adopting the stratagem of
carrying out its functions though the instrumentality or agency of a corporation,
while retaining control over it."
Having regard to this decision and in view of the facts and circumstances in the present case there
can be no doubt that respondent No.2 is an 'authority' within the meaning of Art. 12 of the
Constitution and, therefore, the writ petition filed by the petitioner is competent and maintainable
and the objection raised by Shri Garg cannot be accepted.
The next question that aries for consideration is whether the appointment of respondent No.4 as
Director of respondent No.1 is illegal because of non-compliance with bye-law 2. Bye-law 2 doesB.S. Minhas vs Indian Statistical Institute & Ors on 19 October, 1983

require that before appointment, the vacancy in the post of Director should be suitably publicised.
In the instant case, it is admitted on both sides that no publicity whatsoever was given in respect of
the vacancy. The contention of Shri Garg, however, is that the bye-law having no force of statute,
non-compliance with its requirement can not in any way affect the appointment of respondent No. 4
as Director of respondent No. 1. Shri Tarkunde, however, contended that assuming that the bye-law
is not statutory, even so respondent No. 1 was bound to comply with it. In support of his contention
he strongly relied upon Ramana Dayaram Shetty v. International Airport Authority of India. The
Court in that case held:
"It is a well settled rule of administrative law that an executive authority must be
rigorously held to the standards by which it professes its actions to be judged a and it
must scrupulously observe those standards on pain of invalidation of an act in
violation of them. This rule was enunciated by Mr. Justice Frankfurter in Viteralli v.
Seton where the learned Judge said:
"An executive agency must be rigorously held to the standards by which it professes
its action to be judged. Accordingly, if dismissal from employment is based on a
defined procedure, even though generous beyond the requirements that bind such
agency, that procedure must be scrupulously observed. This judicially evolved rule of
administrative law is now firmly established and, if I may add, rightly so. He that
takes the procedural sword shall perish with the sword.".
The aforesaid principle laid down by Mr. Justice Frankfurter in Viteralli v. Seton has been accepted
as applicable in India by this Court in A. S. Ahluwalia v. Punjab and in subsequent decision given in
Sukhdev v. Bhagatram. Mathew J. quoted the above referred observation of Mr. Justice
Frankfurther with approval.
In view of the pronouncement of this Court on the point it must be held to be obligatory on the part
of respondent No. 1 to follow the bye-laws, if the bye-laws have been framed for the conduct of its
affairs to avoid arbitrariness. Respondent No. 1 cannot, therefore, escape the liability for not
following the procedure prescribed by bye-law 2.
Compliance with this bye-law also seems to be necessary in the name of fair-play. If the vacancy in
the post of Director had been publicised as contemplated by bye-law 2, all the persons eligible for
the post may have applied and in that case, the field of consideration would have been enlarged and
the selection committee or the Council would have had a much larger field from which to choose the
best available person and that would have removed all doubt, of arbitrariness from the mind of
those eligible for the post. Of course, we do not wish to suggest for a moment that appointment to
every post must be made only after advertising or publicising the vacancy. That would not be right,
for there are quite a few posts at the top level which cannot be and should not be advertised or
publicised, because they are posts for which there should be no lobbying nor should any applications
be allowed to be entertained. Examples of such posts may be found in the post of Commander of
Armed Forces or the Chief Justice or the Judges of the Supreme Court or the High Court. But here
bye-law 2 requires that vacancy in the post of Director should be publicised and hence we areB.S. Minhas vs Indian Statistical Institute & Ors on 19 October, 1983

making they above observation in this paragraph.
The grievance of the petitioner is that he has not been considered for appointment to the post of
Director although he is far superior to respondent No. 4. If there had been due publicity as required
by bye-law 2, he and many others like him would have applied for the post. Shri Garg, however,
contends for respondent No. 1 that the petitioner can have no grievance as his case was duly
considered as stated clearly in the affidavit of respondent No. 3, Shri P.N. Haksar, Chairman of the
Council. We accept the statement of respondent No. 3 that the case of the petitioner was considered
by the selection committee but it is a little unfortunate that there is no written report by the
selection committee for consideration by the Council. No minutes of the proceedings before the
selection committee have been maintained and none were circulated amongst the members of the
Council along with the agenda of the meeting nor were any such minutes placed before the Council
meeting when the name of respondent No. 4 was approved by the Council. There is also nothing on
record to show that the Council was at any time informed as to what names had been considered by
the selection committee or that the name of the petitioner had been considered but respondent No.
4 was found superior. It is always desirable that in public bodies the minutes of the proceedings
regarding selection A should be properly maintained in order to obviate any suspicion or doubt and
such minutes along with the relevant documents should be placed before the final authority
entrusted with the task of selection for appointment.
A lot of argument has been-advanced by Shri Tarkunde that the achievements and accomplishments
of the petitioner were much higher than those of respondent No. 4. His contribution in the matter of
research had won him high praise. He ha written articles and books of great merit. On the other
hand the achievements or accomplishments of respondent No. 4 were much lower when com pared
to those of the petitioner. Be that as it may, it is not for the Court to determine who is the superior of
the two candidates and who should be selected. It is for the authorities concerned to select from
amongst the available candidates. The members of the selection committee as also the members of
the Council were eminent persons and they may be presumed to have taken into account all t
relevant considerations before coming to a conclusion. But the real difficulty is that in the absence of
publicity as contemplated by bye law 2, it cannot be said that all other qualified persons like the
petitioner were also considered by the selection committee for appointment, in the absence of any
application by them for the post or any recommendation of them by any other authority or
individual.
Shri Garg, however, contends that the office of the Director is a very high office and this honour is
conferred and not demanded and an application for this office from the candidates was not at all
necessary as in the case of Judges of the Supreme Court, High Court and other constitutional posts
of Comptroller and Auditor General of India etc. The selection committee composed of eminent
scientists of high reputation must be knowing about the reputed men in the field of statistics and it
is expected that they must have considered the; case of those persons also.
For reasons we have already indicated, we find no force in this contention. There is no provision for
publicity in case of the constitutional posts of the Judges of the Supreme Court and High Courts and
Comptroller and Auditor General of India. Rather in the very nature of things, they cannot be andB.S. Minhas vs Indian Statistical Institute & Ors on 19 October, 1983

are not publicised. But in the case of appointment of a Director, bye-law 2 clearly provides for
publicity and it can only be with the object that all concerned may know about the vacancy and
either applications or recommendations may be made for the post and the names of the eligible
candidates my be brought before the selection committee for its consideration. In the state of the
record before us it is not possible to say that the members of the Council considered the case of the
petitioner and other candidates like him before approving the appointment of respondent No. 4. It is
true that the members of the selection committee and those of the Council were experts in their
respective subjects and were eminent scientists and we must proceed on the basis that they acted in
all fairness and no oblique motive can be attributed to them. Indeed Shri Tarkunde did not allege
any mala fides against the members of the selection committee or the members of the Council.
On the admitted position, no publicity in regard to the vacancy was done at all. No information
about it was published even on the notice board kept in the various branches of respondent No. 1 at
Calcutta and other places. Nor was the information published in the journal of respondent No. 1.
There was clearly a breach of bye-law 2 in making appointment of respondent No. 4 and there was
no adequate material before the Council on the basis of which the members could apply their mind
for determining as to whether they should approve the recommendation of the selection committee
in regard to appointment of respondent No. 4.
For the foregoing reasons the writ petition must succeed. It is accordingly allowed. The order of
appointment dated 3rd August, 1979 of respondent No. 4 as the Director of respondent No. 1 is
quashed and set aside. This will however not in any way affect the validity of any action already
taken by respondent No. 4 as Director nor will it involve him in any liability to refund any excess
remuneration received by him in his capacity af Director. Before respondent No. 1 proceeds to select
a new Director, it will comply with the requirement of bye-law 2 by giving suitable publicity to the
vacancy in the office of Director. In the circumstances of the case the parties will bear their own
costs.
N.V.K.                                    Petition allowed.B.S. Minhas vs Indian Statistical Institute & Ors on 19 October, 1983

