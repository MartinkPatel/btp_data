Anand Purusothaman vs The State Rep. By on 28 April, 2018
Author: M.V.Muralidaran
Bench: M.V.Muralidaran
In the High Court of Judicature at Madras
Reserved on :     23.03.2018
Pronounced on :  28.04.2018
C O R A M
THE HONOURABLE MR. JUSTICE M.V.MURALIDARAN
Crl.R.C.No.1130 of 2017 and
Crl.M.P.No.10691 & 10692 of 2017 and
Crl.M.P.No.16688 of 2017
Anand Purusothaman                                              ...  Petitioner
Vs.
1.The State Rep. By,
   The Inspector of Police,
   Cyber Crime Cell,
   Central Crime Branch, Chennai.
2.M/s.Photon Infotech Private Limited,
   Represented by Chief Business Officer,
   Mr.Sanjiv C.Lochan
   No.7, VII Cross Street, Shastri Nagar,
   Adyar, Chennai-20.                                           ... Respondents
(R2 is impleaded as per the order of this
    Court dated 18.12.2017 made in 
    Crl.MP.No.15549/2017)
Prayer: Criminal Revision Case has been filed under Sections 397 and 401 of Cr.P.C., to call for the records pertaining to Crl.M.P.No.3911 of 2016 in C.C.No.3816 of 2016 pending on the file of the Learned XI Metropolitan Magistrate at Saidapet and to discharge the 2nd Accused/Petitioner from all charges.
For Petitioner         : Mr.J.Suresh
For Respondents    : Mr.M.Mohamed Riyaz (for R1)
                            Additional Public Prosecutor
                            Mr.R.Shunmugasundaram, Senior counselAnand Purusothaman vs The State Rep. By on 28 April, 2018

                            for M/s.Ganesh Rajan (for R2)
                            (Defacto complainant)
ORDER
The second accused in C.C.No.3816 of 2016 on the file the learned XI Metropolitan Magistrate
Court, Saidapet, Chennai is the revision petitioner before this Court as against the dismissal of his
discharge petition filed under Section 239 of Cr.P.C. in Crl.M.P.No.3911 of 2016 dated 10.07.2017.
2.The case of the prosecution is that the Defacto-complainant (i.e.) the 2nd respondent herein is
working as Assistant Manager, Administration of M/s.Photon Infotech Private Limited, filed a
complaint against the petitioner herein and 6 others alleging that the 1st accused namely Thennavan
Asaithambi, a former employee of the Defacto-complainant company, by colluding with the
petitioner/A2 involved and thereby committed the offence of data theft of the datas belong to the
defacto complainants company and illegally transferred the same to the second accused company
namely M/s.Payoda Technology Company, which is a business competitor of the defacto
complainant.
3.The accused hence involved in Criminal breach of Trust and thereby cheated the defacto
complainant company. Out of the above illegality, the defacto complainant suffered a loss to the
tune of Rs.10 Crores. Thus due to the above wrongful loss caused to the defacto complainant and
wrongful gain to the 2nd accused by the said Thennavan Asaithambi, the above complaint was
lodged.
4.It is the further case of the prosecution that the 1st accused Thennavan involved in the above
illegality while he was working as the capacity of Director of Sales in defacto complainant's
company. During the course of employment in the month of November, 2012, A-1 illegally
transferred highly confidential information stored in the form of datas relating to the business
strategies and solutions to the 2nd accused company. The said confidential information stood
developed by the complainant over the period of several man hours and with high configuration
computer equipments worth about Rs.2 to 3 Crores. A1, Thennavan Asaithambi was entrusted with
a Sony laptop bearing Serial No.275450617002795 and also provided with complainant's company
email id namely thennavan@photoninfotech.net, thennavan@photoninfotech.com,
thennavan@photon.in, for his personal use, but for the usage of the storing of the datas in respect of
the company and he was using the same with his own password till he was relieved from the post in
the month of April, 2013. While so, on scrutiny of the Laptop and Email ids provided by the defacto
complainant's company, it was found that On 11.10.2012 @ 20:20 hours (A1) Thennavan
Asaithambi had sent a mail from his email account thennavan@photoninfotech.net, to (A2) Anand
Purusothaman, MD of competitor company, to his e-mail account
anand.purusothaman@payoda.com, wherein (A-1) Thennavan Asaithambi sent vital confidential
information / computer resource in the form of paper presentation relating to Complainant's
Company. In actual, in November, 2012, a foreign firm Touch Tunes Inc had placed orders to
provide software services and based on the same, Photon Info Tech Pvt Ltd, i.e. the complainant
company, developed the said confidential data/computer resource and had also quoted the rate for
carrying out the services and the same was sent to Touch Tunes Inc. (A1) Thennavan AsaithambiAnand Purusothaman vs The State Rep. By on 28 April, 2018

was the Director of sales at the relevant point of time and he was the key sales person engaged with
the customer who was expected to maintain strict confidentiality and secrecy on business matters.
Further it is his one of the prime duties not to disclose the secret datas to any one in any mode.
However, by breaching all such norms, (A1) Thennavan Asaithambi illegally transferred the
business presentation developed for Touch Tunes through his mail I.D.
thennavan@photoninfotech.net, to the mail I.D. anand.purusothaman@payoda.com, on 10.11.2012
at 19:09 hours, enabling Payoda Technologies i.e. the competitor company to present the same
with slight modification in order to quote lesser price to Touch Tunes. A2 approached the customers
of complainant namely Touch Tunes and JKnipper based on the confidential data/computer
resource provided by A1 to snatch the business of complainant company.
5.In the meantime, JKnipper placed orders for a particular software service with the complainant
Photon Infotech Private Limited i.e. the complainant company and as per orders, this business
projects was completed and sent to the above firm, again it was seen that in similar format with
slight modification JKnipper received a proposal from M/s.Payoda Technology, who happened to be
the competitor of complainant company. Thereupon JKnipper questioned the business ethics of
M/s.Photon Infotech Private Limited, i.e. complainant company as they felt that the system of
protecting the information security was not strong enough with the complainant company.
6.The defacto complainant came to know that (A1) Thennavan Asaithambi who was in charge of
sales process with the above complainant company acted in a manner that was prejudicial to the
interest of the company, he illegally transferred the confidential business presentation developed for
JKnipper from his mail I.D. thennavan@photoninfotech.net to the mail I.D.
Anand.purusothaman@payoda.com on 15.01.2013 at 20:30 hours, subsequently JKnipper cancelled
the agreement with complainant company. This resulted in loss to the complainant to the tune of
USD1.3 million approximately Rs.8.7 crores.
7.Thereby the 2nd accused / petitioner herein has dishonestly received and retained stolen
computer resource (i.e.) confidential information from A1. Hence the 2nd respondent has filed the
above private complaint as against the petitioner and others before the Learned XI Metropolitan
Magistrate Court, Saidapet at Chennai for their unlawful theft of data and loss. The said complaint
was forwarded to Cyber Crime Cell under Section 156(3) Cr.P.C. for investigation. Thereafter, FIR
was registered against seven persons in Crime No.274 of 2013 for the offences under Sections 406,
408, 420 and 120(B) IPC and Section 63 of the Indian Copy Right Act. The petitioner was arrayed as
A2 and the said complaint was taken on file in C.C.No.3816 of 2016. After investigation, the 1st
Respondent police had filed the final report against Thennavan and Anand Purusothaman, the
petitioner herein for the alleged offences under Sections 406, 411, 420, 414 IPC r/w 66(B) of
Information Technology Act. The other five persons names were dropped from the charge sheet.
8.It is the case of the petitioner that he is an innocent and has not involved in any offence as alleged
by the prosecution and the above complaint is a sheer abuse of process of law, thereupon he filed an
application under Section 239 of Cr.P.C. in Crl.M.P.No.3911 of 2016 seeking for his discharge.
However, the Learned Judge on misconception of law and facts, has dismissed petitioners
application in Crl.M.P.No.3911 of 2016 vide an order dated 10.07.2017. Aggrieved over it, theAnand Purusothaman vs The State Rep. By on 28 April, 2018

present Criminal Revision Petition is filed.
9.I heard the arguments of Mr.J.Suresh, learned counsel for the petitioner, Mr.M.Mohamed Riyaz,
learned Additional Public Prosecutor for the 1st respondent and Mr.R.Shunmugasundaram, Senior
counsel for M/s.Ganesh Rajan, learned counsel for the 2nd respondent and perused the entire
records.
10.The Learned Counsel for the petitioner would strenuously content that the Learned Magistrate
failed to consider the fact that the petitioner was charged only for the offences under Sections 411
and 414 IPC and Section 66(B) of the Information Technology Act, 2000 and not for the offence
under Section 420 IPC. It is further contented by the Learned Counsel for the petitioner that
nothing revealed from the charge sheet as well as the documents filed along with the charge sheet to
show that the petitioner/A2 received e-mails dated 11.10.2012. It is alleged that the petitioner was in
receipt of three emails dated 10.12.2012, 11.10.2012 and 15.01.2013 which was sent by A1, but there
is no evidence on record to show that all the above said e-mails were received by the petitioner.
However, the Learned Magistrate failed to consider the above said facts, has erroneously and
mechanically dismissed the discharge petition filed by the petitioner under Section 239 of Cr.P.C.
11.It is also argued by the Learned Counsel for the petitioner that in the absence of any documents to
prove that the petitioners company has quoted lesser price along with its presentations sent to
Touch Tunes and JKnipper, no criminality can be attributed against the petitioner herein. In the
absence of any documentary evidence to suggest monitory loss to the defacto complainant, the
Learned Magistrate ought not to have accepted the version of the complainant. By dismissing the
discharge petition filed by the petitioner herein, the Learned Magistrate has erred in law in
relegating the petitioner to face the ordeal of trial without considering the important and vital issue
that by no stretch of imagination the lower court ought not to have come to the conclusion that there
is a prima facie case is made out against the petitioner.
12.The learned counsel for the petitioner would further contend that the learned Magistrate failed to
consider the scope of Section 239 of Cr.P.C. and he also place reliance upon the decision reported in
2014 (11) Supreme Court Cases 709 in support of his above contention stating the Honble Supreme
Court has elaborately considered the scope of discharge petition. The relevant portion of the above
Judgment of the Honble Apex Court is extracted hereunder:
We have bestowed our consideration to the rival submissions and the submissions
made by Mr,Ranjit Kumar commend us. True it is that at the time of consideration of
the application for discharge, the Court cannot act as a mouthpiece of the prosecution
or act as an office and may sift evidence in order to find out whether or not the
allegations made are groundless so as to pass an order of discharge. It is trite
proposition that at the stage of consideration of an application for discharge, the
Court has to proceed with an assumption that the materials brought on record by the
prosecution are true and evaluate the said materials and documents with a view to
find out whether the facts emerging there from taken at their face value disclose the
existence of all the ingredients constitution the alleged Offence. At the stage,Anand Purusothaman vs The State Rep. By on 28 April, 2018

probative value of the materials has to be gone into and the Court is not expected to
go deep into the matter and hold that the materials would not warrant a conviction.
In our opinion, what needs to be considered is whether there is a ground for
presuming that the Offence has been committed and whether a ground for conviction
of the accused might have been made out. To put it differently, if the Court thinks
that the accused might have committed the Offence on the basis of the materials on
the record on its probative value, it can frame the charge; through for conviction, the
Court has to come to the conclusion that the accused has committed the Offence. The
Law does not permit a mini trial at this stage.
Now reverting to the decisions of this Court in Sajjan Kumar and Dilaqwar Balu
Kurane, relied on by the respondents, we are of the opinion that they do not advance
their case. The aforesaid decisions consider the provision of Section 227 of the code
and make it clear that at the stage of discharge the Court cannot make a roving
enquiry into the pros and cons of the matter and weigh the evidence as if it was
conducting a trial. It is worth mentioning that the code contemplates discharge of the
accused by the Court of session under Section 227 in a case triable by it; cases
instituted upon a police report are covered by Section 239 and cases instituted
otherwise than on a police report are dealt with in Section 245. From a reading of the
aforesaid sections it is evident that they contain somewhat different provisions with
regard to discharge of an accused.
Under Section 227 of the code, the trial Court is required to discharge the accused if it
considers that there is not sufficient ground for proceeding against the accused.
However, discharge under Section 239 can be ordered when the Magistrate
considers the charge against the accused to be groundless. The power to discharge is
exercisable under Section 245(1) when, the Magistrate considers, for reasons to be
recorded that no case against the accused has been made out which, if unrebutted,
would warrant his conviction.
13.Sections 227 and 239 provide for discharge before the recording of evidence on the basis of the
police report, the documents sent along with it and examination of the accused after giving an
opportunity to the parties to be heard. However, the stage of discharge under Section 245, on the
other hand, is reached only after the evidence referred in Section 244 has been taken.
14.Thus, there is difference in the language employed in these provisions. But, in our opinion,
notwithstanding these differences, and whichever provision may be applicable, the Court is required
at this stage to see that there is a prima facie case for proceeding against the accused. Reference in
this connection can be made to a judgment of this Court in R.S.Nayak Vs. A.R.Antulay. The same
reads as follows: (SCC pp.755-56, para 43) 3.... Notwithstanding this difference in the position
there is no scope for doubt that the stage at which the Magistrate is required to consider the
question of framing of charge under Section 245 (1) is a preliminary one and the test of prima
facie case has to be applied. In spite of the difference in the language of the three sections, the legal
position is that if the trial Court is satisfied that a prima facie case is made out, charge has to beAnand Purusothaman vs The State Rep. By on 28 April, 2018

framed.
15.Per contra, the learned Additional Public Prosecutor for the 1st respondent would contend that
the reasons assigned in the discharge petition filed by the revision petitioner before the learned trial
court is dismissed rationale and the same needs no interference. Further, the learned Magistrate is
not liable to analyze or to testify the veracity of the documents furnished by the accused at the stage
of framing of charges. The settled legal position is that cognizance must be taken based on material
and documents furnished along with the final report by the Investigation Officer. So, there is no
merit to consider the case of the revision petitioner.
16.The Learned Senior Counsel for the second respondent would submit that the very same
petitioner has approached this Court twice to quash the charge sheet in C.C.No.3816 of 2016 by
filing Crl.O.P.Nos.24412 of 2016 and 27342 of 2016 and both the above Crl.O.Ps were dismissed by
this Court by order dated 07.11.2016 and 23.12.2016 respectively. Therefore, the filing of discharge
petition by invoking Section 239 of Cr.P.C. is an abuse of process of Court. There is ample evidence
to show that the involvement of this petitioner in the above crime. The investigation officer has
produced volume of documents which runs to several pages and the investigation was also done in a
proper manner after sending the e-mails for forensic analysis test. The investigation done by the
prosecution cannot be found fault. Therefore, the petitioner has not entitled to get discharged from
the charges framed against him. The report of Tamil Nadu Forensic Department would be a
conclusive proof that the petitioner herein and the first accused had conspired together and thereby
had transferred the data and computer resources developed by the defacto complainant. Therefore
necessarily the petitioner has to face the trial in the above criminal case and the question of
discharging him from the offences under Sections 411 and 414 IPC and Section 66(B) of the
Information Technology Act, 2000 does not arise at all. Hence the Learned senior Counsel prays
this Court to dismiss the above criminal revision petition.
17.Rebutting the contention of the learned senior counsel for the 2nd respondent, the learned
counsel for the petitioner would submit that the filing of quash petition to quash the final report and
its dismissal would not have any bearing in the discharge petition. The petitioner is entitled to file
discharge petition by invoking Section 239 of Cr.P.C. before the trial Court and therefore the
contention of the learned senior counsel appearing for the 2nd respondent that the petitioner/A2
having filed quash petitions cannot maintain the discharge petition cannot be countenanced and it
has no legal basis in the considered opinion of this court.
18.On the basis of the above rival contention of the parties, this court has to see whether the learned
Trial Court has properly applied its mind and weighed the materials filed in the form of final report
by the Investigation Officer and the same makes out any prima facie case against the petitioner
herein and whether the offences under Sections 411 and 414 IPC and Section 66(B) of the
Information Technology Act, 2000 are made out against the petitioner and whether the petitioner is
liable to be discharged from the above charges without facing trial?
19.Before part with to the facts and circumstances of the case this court is under the compelling
necessity to extract the definition of data as contemplated under Section 2(1)(o) of the InformationAnand Purusothaman vs The State Rep. By on 28 April, 2018

Technology Act, 2000 for the useful purpose to dispose of the instant criminal revision case.
20.Section 2(1)(o) of the said Act would read that Data means a representation of information,
knowledge, facts, concepts or instructions which are being prepared or have been prepared in a
formalized manner, and is indented to be processed, is been processed or has been processed in a
computer system or computer net work, and may be in any form (including computer print outs
magnetic or optical storage media, bunged cards, bunged tapes) or stored internally in the memory
of the computer.
21.As far as the power of revision by the High Court is prescribed under Section 401 Cr.P.C. The
power conferred upon is also include the exercise of any power conferred on a court of appeal also.
So, this Court is entitled to appreciate the genuineness of all the materials available on records.
22.It is seen from the records that M/s.Photon Infotech filed a private complaint before the learned
XI Metropolitan Magistrate on 31.05.2013 alleging that while Thennavan Asaithambi/A1 was in
employment with them, he had passed presentation proposals and price quotes of two foreign
clients (Touch Tunes and Jknipper) of M/s. Photon to the revision petitioner. It is further alleged
that the said information was passed through three alleged e-mails to the petitioners company. The
said complaint was forwarded to Cyber Crime Cell under Section 156(3) Cr.P.C. for investigation.
F.I.R. was registered against seven persons. Petitioner was arrayed as A2. All other six persons are
ex-employees of M/s.Photon Infotech.
23.It revels from the final report filed by the 1st respondent police that M/s.Payoda Technologies
obtained a report from Google which establish that the petitioner herein had not received any such
three e-mails. The said report has been annexed in the charge sheet. Even the admitted facts there
was no similarity between the presentation of M/s.Payoda Technologies and M/s.Photon Infotech.
Both presentations have been annexed in the charge sheet. Similarly the 1st respondent police has
not submitted any document to substantiate that payoda Technologies had quoted lesser price than
Photon Infotech. Hence this court is of the considered opinion that the Defacto complainants
allegation that both the proposals are similar in nature is contradictory to the fact. Further the
perusal of the records would show that the basis for the prosecution is pertaining to the transaction
of three e-mails, unfortunately those three e-mails which are the genesis of the case are not form
part of the records submitted along with the final report. In the considered opinion of this court, the
non-production of those e-mails would definitely affect the root of the prosecution case. There
cannot be any structure without proper foundation. In the case on hand would fall in the above said
category as the non-production of the three important mails through which the alleged offence said
to have taken place has not been taken up for consideration by the learned Judicial Magistrate.
24.Further, this court would able to see that there is no evidence that JKnipper has closed the
business of Photon due to insecurity. In contrary the e-mails referred in Doc.No.35 and Termination
Notice referred in Doc.No.36 establish that Photon has obtained the said order in the month of
March 2013 and had continued the same till July 2014 and the work order has been terminated for
the reason that Jknipper doesnt need any off shore team for its project. Hence the claim of the
prosecution that the work order is terminated for insecurity is baseless. The 1st respondent PoliceAnand Purusothaman vs The State Rep. By on 28 April, 2018

has failed to produce any single piece of evidence to prove that there was financial loss of Rs.8.7
crores to Photon Infotech. More so, it is pertinent to note that JKnipper was not at all customer to
the petitioners company namely Payoda company at any point of time. Apart from that the quoting
of lesser price alone would not constitute a criminal offence when there is no document to show that
the petitioner alone is the responsible person to finalize and to quote the price as alleged. In the
absence of the documents to show that the petitioner is the sole responsible person in finalizing the
price, then the criminal liability cannot be solely fixed on him. Further there is no pick and choose
formula can be adopted in criminal prosecution. Thus, this court is no option except to appreciate
the arguments advanced by the counsel for the revision petitioner.
25.The failure of the 1st respondent police to enquire JKnipper would badly affect the prosecution
case and hence the contention of the petitioner that the 1st respondent knowing fully well the
non-examination of JKnipper will go against the case of the prosecution, but willfully omitted to
examine the said JKnipper which has also have its own implication which would affect the
prosecution case.
26.There is no evidence to support the prosecution that Anand and Thennavan had conspired to
bring loss to Photon Info Tech. Further, correspondingly there is no evidence for wrongful gain by
Anand since no contract has been entered by him or his company with Jknipper and Touch Tunes.
27.It is seen that on receipt of summons from the learned Magistrate Court, the Petitioner
approached High Court seeking to quash the summons. However as the same was filed without the
entire documents of the charge sheet, the petition was dismissed as withdrawn. Hence, the
Petitioner again approached the High Court with second quash Petition with entire charge sheet.
Whereas, the Honble High Court dismissed the second quash petition as not maintainable, but
gave liberty to approach the Trial Court to agitate all points on merits and on such submissions the
same shall be considered on merits and in accordance with Law.
28.The Petitioner therefore filed the present discharge petition before the trial Court. But the trial
Court instead of considering the statements and documents available in the charge sheet went to an
extent of summoning the Defacto complainant and asked the Defacto complainant to demonstrate
the process through the laptop seized from Thennavan Asaithambi/A1. After hearing arguments on
both side, the trial Court dismissed the discharge petition filed by A2. The said order was challenged
before this Honble Court in this revision petition.
29.On appraisal of the available records and the Charge sheet, this Court is unable to find a single
piece of document in the charge sheet to show that the contracts which were originally awarded to
Defacto Complainant Company by the two foreign clients were cancelled by them due to the
presentation sent by petitioners company. Further, this court is unable to come across any
document to illustrate that the two foreign clients said to have cancelled the Work order with the
defacto complainant were examined by the investigation Officer.
30.Again there prosecution is not in a position to demonstrate one document disclosing that Anand
purusothaman had received any of the emails as alleged by the prosecution?Anand Purusothaman vs The State Rep. By on 28 April, 2018

31.The foremost objection of the Government Advocate Criminal side would be that there is no
necessity upon the learned Judicial Magistrate even to have a perusal of the records submitted by
the accused at the time of framing of charges. The said contention is unacceptable in view of the
settled legal position and at this juncture, it is relevant to point out that the revision petitioner filed
an application for discharge under Section 239 of Cr.P.C., which is extracted hereunder for better
appreciation of the case:
39.When accused shall be discharged.- If, upon considering the police report and
the documents sent with it under section 173 and making such examination, if any, of
the accused as the Magistrate thinks necessary and after giving the prosecution and
the accused an opportunity of being heard, the Magistrate considers the charge
against the accused to be groundless, he shall discharge the accused, and record his
reasons for so doing.
32.Section 239 of Cr.P.C. thus stipulate that the framing of charge is not an empty formalities but
must be based on considering the police report and the documents sent under Section 173 of Cr.P.C.,
and the learned Judicial Magistrate ought to have come to an irresistible opinion that there is
ground for presuming that the accused has committed an offence. Consequently, framing of charge
under Section 240 of Cr.P.C. would be based on the documents and the police report as
contemplated under Section 173 of Cr.P.C. In turn when, Section 173 of Cr.P.C., is testified
173(2)(1)(b) stipulates the nature of information received by the Investigation Officer. Therefore, it
is the duty of the Investigation Officer to collect all the information and to produce the same before
the learned Judicial Magistrate in order to take cognizance of the offence. Whereupon, the learned
Judicial Magistrate is empowered to discharge the accused if he considers charge against accused to
be groundless. The consideration of the learned Judicial Magistrate depends upon police report and
the documents sent with it under Section 173 of Cr.P.C. The above discussion would make it clear
that when the learned Judicial Magistrate is empowered to give opportunity to the prosecution and
the accused of being heard, the same will not be an empty formality but the same should be based on
the submissions of the prosecution and the accused.
33.Accordingly, the contention of the learned Additional Public Prosecutor that the documents
furnished along with an application under Section 239 of Cr.P.C., need not be perused is liable to be
negatived.
34.At the same time, as far as the instant case is concerned that the three e-mails have not been
identified and recovered admittedly. Besides, those three e-mails are important documents through
which the alleged occurrence said to have committed. In the considered opinion of this court, those
e-mails are ought to have been collected and their veracity ought to have been testified in view of
Section 45 of the Indian Evidence Act which reads as follows:
Opinions of Experts When the Court has to form and opinion upon a point of
foreign law or of science or art, or as to identity of handwriting or finger impressions,
the opinions upon that point of persons specially skilled in such foreign law, science
or art, or in questions as to the identity of handwriting or finger impressions areAnand Purusothaman vs The State Rep. By on 28 April, 2018

relevant facts. Such persons are called experts. In this connection the following
illustration is applicable to the facts of the instant case which is as follows:
(c) The question is, whether a certain document was written by A. Another document
is produced which is proved or admitted to have been written by A.
35.Here, the final report is filed by the prosecution by invoking Section 66(B) of the Information
Technology Act 2000, but the basis to invoke the said provision is to receipt, retain of any stolen
resource are communication device, because section 66-B of the said Act would read thus:
6(B). Punishment for dishonestly receiving stolen computer resource or
communication device. -Whoever dishonestly received or retains any stolen
computer resource or communication device knowing or having reason to believe the
same to be stolen computer resource or communication device, shall be punished
with imprisonment of either description for a term which may extend to three years
or with fine which may extend to rupees one lakh or with both.
36.But the appreciation of the materials on record would show that there is no dishonest receipt or
retention of any stolen computers resource or communication devices on the part of the revision
petitioner herein. As discussed above that in the absence of receipts of any e-mail by which the
communication said to have been shared, in the considered opinion of this court, the final report
filed under Section 66(B) of the Information Technology Act cannot be invoked. Hence, this court is
having no option except to allow the criminal revision case.
37.For the forgoing discussions, this Court is unable to appreciate the findings given by the learned
Trial Judge and the said findings are liable to be interfered with as there is no basis to sustain the
case of the prosecution.
38.In the result:
(a) this Criminal Revision Petition is allowed, by setting aside the order in
Crl.M.P.No.3911 of 2016 in C.C.No.3816 of 2016 on the file of the learned XI
Metropolitan Magistrate, Saidapet, Chennai;
(b) the petitioner, who is A2 alone is discharge from the case in C.C.No.3816 of 2016,
pending on the file of the learned XI Metropolitan Magistrate, Saidapet, Chennai.
Consequently, connected miscellaneous petitions are closed.
28.04.2018 Note:Issue order copy on 03.05.2018 vs Index: Yes Internet : Yes Speaking order To The
XI Metropolitan Magistrate, Saidapet.
M.V.MURALIDARAN.J, vs Pre-delivery order made in Crl.R.C.No.1130 of 2017 and
Crl.M.P.No.10691 & 10692 of 2017 and 28.04.2018Anand Purusothaman vs The State Rep. By on 28 April, 2018

