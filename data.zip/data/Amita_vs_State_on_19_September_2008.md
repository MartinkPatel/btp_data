Amita vs State on 19 September, 2008
Author: M.R. Shah
Bench: M.R. Shah
   Gujarat High Court Case Information System 
                   Print
CR.MA/10158/2007         21/ 21 JUDGMENT 
IN
THE HIGH COURT OF GUJARAT AT AHMEDABADAmita vs State on 19 September, 2008

CRIMINAL
MISC.APPLICATION No. 10158 of 2007
WITH
CRIMINAL
MISC.APPLICATION No. 10160 of 2007
For
Approval and Signature:  
HONOURABLE
MR.JUSTICE M.R. SHAH
=========================================================
1
Whether
                        Reporters of Local Papers may be allowed to see the judgment ?    
                                       Yes
2Amita vs State on 19 September, 2008

To
                        be referred to the Reporter or not ?  Yes
3
Whether
                        their Lordships wish to see the fair copy of the judgment ?       
                                        No
4
Whether
                        this case involves a substantial question of law as to the
                        interpretation of the constitution of India, 1950 or any order
                        made thereunder ?                             No
5Amita vs State on 19 September, 2008

Whether
                        it is to be circulated to the civil judge?                        
                                  No
========================================================
AMITA
R. PATEL & 1 - Applicant(s)
Versus
STATE
OF GUJARAT & 1 - Respondent(s)
=========================================================
Appearance : 
MR
JV MEHTA for Applicant(s) : 1 - 2.MS KRISHNA B
MEHTA for Applicant(s) : 1 - 2. 
MR M.R.MENGDEY, ADDL. PUBLIC
PROSECUTOR for Respondent(s) : 1, 
None for Respondent(s) :
2, 
=========================================================
CORAM
                        : Amita vs State on 19 September, 2008

HONOURABLE
                        MR.JUSTICE M.R. SHAH
Date
: 19/09/2008 
ORAL
JUDGMENT 
1. Rule.
Mr.M.R.Mengdey, learned APP waives service of rule on behalf of the respondent ? State.
2. Criminal Misc.Application No.10158 of 2007 is filed by the petitioner-Doctor under Section 482
of the Criminal Procedure Code ('Cr.P.C.' for short) to quash and set aside the complaint being
Criminal Case No.3251 of 2006 pending in the Court of learned 6th JMFC, Ahmedabad (Rural) for
contravention of Pre-Conception and Pre-natal Diagnostic Techniques (Prohibition of Sex Selection)
Act, 1994 hereinafter referred to as ('PNDT Act' for short).
3. Criminal Misc.Application No.10160 of 2007 is also filed by the petitioner- Doctor under section
482 of the Criminal Procedure Code to quash and set aside the complaint being criminal case
No.845 of 2006 pending in the Court of learned Metropolitan Magistrate, Court No.9, Ahmedabad
for contravention of PNDT Act more particularly under Section 4(3), 5(1) of the said Act and Rules
9(4) and 10(1)(A) framed under the said Act.
4. As common question of facts and law arise in both these application, they are being disposed of by
this common judgment.
Criminal Case No.3251 of 2006 is filed by the Dr.R.R.Vaidya, for and on behalf of the Appropriate
Authority under PNDT Act against the petitioner ? Doctor who is having maternity and nursery
home at Chandlodiya, Ahmedabad in the Court of learned 6th JMFC, Ahmedabad (Rural) alleging
inter-alia that he is functioning as Chief District Health Officer and he is declared Appropriate
Authority under the PNDT Act vide Government Notification dated 07.02.1996 under Section 2(a)
of the PNDT Act and Rules framed thereunder. It is further alleged in the said complaint that in
discharge of his duty under the PNDT Act he found that accused has failed to observe and comply
with the provisions of the Act. It is alleged that on 21.02.2006 primary inspection of the clinic of the
accused was undertaken by Dr.Shipla Patel, Block Health Officer, City. The observations and
reasons were recorded by her and on 21.02.2006 the infirmity / lapses as observed by the
Appropriate Authority was communicated to the accused and said infirmity / lapses are produced at
Annexure ? A to the said complaint. As the provisions of the Act were violated, USG machine wasAmita vs State on 19 September, 2008

sealed. That on 21.06.2006 a show cause notice was issued to the accused as to why the registration
of the accused should not be suspended / cancelled. That the accused preferred an appeal No.42 of
2006 before the State Appropriate Authority, Gandhinagar. That by order dated 16.03.2006,
Registration of the accused under the PNDT Act was suspended. That the said complaint was filed
on the following grounds:
?S1. Form-F is a statutory form and requires to be filled in completely & send before
5th of the next month to the A.A. As per the provisions of the Act/ Rules, sending of
the Form F by the 5th of the next month is mandatory.
2. Authenticity of from/s not signed by the accused can never be ascertained by any
one & in such cases the entire form is useless. This in turn flouts the requirement of
filling up of form for every patient under going USG. Accused &/or patient can
disown the contents of the very same from in future to defy probable Medical
Termination of Pregnancy ? MTP & may be suggestive of the possibility of the
accused maneuvering number of USG done & equal number of forms filled up. The
same can not be ruled out.
3. If signature of the doctor is missing on the forms, presumption can be drawn that
as the doctor has not been able to comply the declaration, the doctor has not put the
signature. Otherwise whenever there is signature put by the doctor, declaration as
envisaged by the Act is accepted. In other words non-signing the declaration means
non-observance of the same i.e. sex determination & declaration has been carried out
& is in total derogation of the statutory provisions of the Act.
4. Indication, date are missing in the forms. Even the register as required under the
Act was also not maintained. This clearly indicates the causal approach of the accused
towards the statutory provisions of the Act.
Also reflect the lack of seriousness with which the Act is being taken up. Resultant effect would
obviously be the frustration of the Act which is to curtail female feticide. This in turn, will keep on
increasing the difference between the male-female birth numbers. In other words the endeavour to
check the increasing ratio of male to female birth, owing to the female child being killed before birth,
would not be getting through. In nut shell the Act is set as Naught.
5. The indication for the Pre-Natal Diagnosis as shown by the accused is 'Routine ANC' even routine
thing is also with a specific purpose & the same is required to be mentioned otherwise data
collection, analysis of the same & consequent preventive measure to ensure the check of declining
number of the female birth cannot be effected.??
5. That it was found that all the aforesaid breach and non-compliance were not at all in the larger
public interest. It was further observed in the said complaint that not signing the report may be an
attempt to disown such reports if pressed to a corner & with a view to hide / suppress the activity
not in consonance with the provisions of the PNDT Act. It was alleged that penal provisions ofAmita vs State on 19 September, 2008

Section 23 & Section 25 are attracted for contravention of Sections, 4,5 and 6 and corresponding
rules. Further it was requested to take cognizance of the offence committed by the accused for
non-compliance / breach of the provisions of the Act & Rules and to punish the accused so as to
restrict the contravention of the provisions of the PNDT Act/ Rules and ensure the compliance
thereof to meet by the noble cause as envisaged by the PNDT Act. In the said complaint, learned
trial Court took cognizance and directed to register the complaint and issued summons upon the
accused. Being aggrieved and dissatisfied with the same, the petitioners of CRMA No.10158 of 2007
have preferred present application under Section 482 of the Cr.P.C. to quash and set aside the said
complaint / criminal case.
6. Similarly one another complaint being Criminal Case No.845 of 2006 is filed by one Dr.P.L.Dave
Epidemic Medical Officer, District Panchayat, Ahmedabad on behalf of the Appropriate Authority
under the PNDT Act and on behalf of Chief District Health Officer, Ahmedabad in the Court of
learned Metropolitan Magistrate Court No.9, Ahmedabad against the petitioner ? accused. It is
averred and alleged in the said complaint that complainant has been authorized to act on behalf of
Chief District Health Officer who is declared as Appropriate Authority under the PNDT Act by
Government Notification dated 09.11.2001. It is further alleged in the said complaint that in the
discharge of his duty under the Act, he has found that accused has failed to observe / comply with
the provisions of Sections 4(3), 5(1) and Rules 9(4) & 10(1)(A) of the Act framed thereunder. It is
alleged that he visited clinic of the accused in presence of two respectable witnesses on 01.03.2006
and on discovering the contraventions of the Act, records, search and seizure procedure was
conducted and the Sonography machine of the accused was sealed. Panchnama of the search and
seizure was prepared and copy was handed over to the accused and same was produced along with
the complaint. It was found that Form 'F' bearing Sr.No. 1 to 25 ranging from 02.12.2005 to
28.02.2006 were not filed up properly and same were seized during the search and seizure
procedure. It was found that there was no sign of Doctor in Form 'F' in form numbers 3,4,5,6, 7, 11,
12. It was further found that patient's name was not written in the declaration by the patient section
of form F. No indication for sonography is written in para No.11 of Form F in from Number 9,10 and
13. In all ?SF?? form number 14 to 25 the indication for Sonography is shown in para 10 of Form 'F'
as ?Sprevious child with congenital anomaly?? along with ?Sto rule out congenital anomaly and for
foetal well being??. It is further averred in the said complaint that Section 4(3) of the PNDT Act
specifics duty on the registration holder or the Doctor conducting Sonography at the hospital under
the Act to record in writing the reason for conducting the procedure and keep these records up to
date in the clinic as per Rule 9(4). It is further averred in the said complaint that as per Rule
10(1)(A) the Doctor and the patient have to give a written declaration to be recorded in Form F; that
in no way the procedure being done is for selection or detection of sex of foetus. Section 5 specifies a
duty on the registration holder or the Doctor conducting Sonography at the Hospital under the Act
to obtain written consent in the language which she understands. That in the said complaint Section
493), 5(1) of the PNDT Act and Rule 9(4) and Rule 10(1A) are re-produced. Therefore, it was
requested to take cognizance of the offence committed by the accused for non-compliance of the
mandatory provisions of the Act and Rules framed thereunder and thereafter, punish the accused so
as to restrict the breach of the provisions of the Act/ Rules and ensure the compliance thereof to
meet by the noble cause as envisaged by the PNDT Act. It is further alleged in the said complaint
that setting an example will go a long way in refraining the others like the accused from violation ofAmita vs State on 19 September, 2008

the provisions of the Act/Rules which in turn is required in the interest of maintaining a healthy
ratio between the human gender of Male and Female. That in the said complaint after taking
cognizance the learned trial Court has issued summons upon the accused for the offence under
Sections 4(3), 5(1) of the PNDT Act and Rule 9(4) and 10(1A) of the Rules framed thereunder. Being
aggrieved and dissatisfied with the same, the accused Dr.Ghanshaymsinh Dabhi has preferred
present CR.M.A. 10160 of 2007 under Section 482 of the Cr.P.C. to quash the said criminal case.
7. Mr.Mehta, learned Advocate appearing on behalf of the respective petitioners has vehemently
submitted that as such there are no breaches whatsoever much less technical one. It is further
submitted that all the rules are complied with more particularly the intimation to the patient that
one should not try to know sex of the foetus and various other precautions are also taken. It is
further submitted that inspite of the fact that respective petitioners have complied with all the
provisions of the Act and Rules thereunder with mala-fide intention complaints have been filed by
way of random survey and just to show that inspection is done and the officers are carrying on their
duties well. Therefore, it is requested to quash and set aside the impugned complaint by submitting
that continuous of criminal proceedings against the petitioners would be unnecessary harassment as
the petitioners are reputed doctors with good morals and ethics. Mr.Mehta, learned Advocate for the
petitioners has submitted that with respect to some other Doctors against whom similar complaints
were filed, learned Single Judge of this Court has quashed and set aside such criminal complaints by
order dated 07.02.2007. Therefore, it is requested to quash the impugned complaints.
8. Petitions are opposed by Mr.M.R.Mengdey, learned APP appearing on behalf of the
respondent-State. It is submitted that on bare reading of the impugned complaints prima-facie case
is made out after thorough investigation by the Officers and what is required to be considered at this
stage is whether on bare reading of the complaints, prima-facie case is made out for further trial or
not. It is submitted that whether the petitioners have in fact committed offence or not is required to
be considered at the time of trial on leading appropriate evidence. It is submitted that considering
the lapses found by the Appropriate Authority and the Officers under the PNDT Act and having
prima-facie found that petitioners violated the provisions of the PNDT Act and Rules thereunder,
impugned complaints have been filed with a view to punish the accused persons. It is submitted that
looking to the statement and object of the Act and Rules thereunder prima-facie case is made out,
therefore, it is requested not to exercise discretion under Section 482 of the Cr.P.C. and quash and
set aside the complaint at this stage. It is submitted that though some mala-fide are alleged, but
same are without any basis and are absolutely vague. It is further submitted that even otherwise as
held by the Hon'ble Supreme Court and this Court in catena of decisions solely on the ground of
mala-fide complaint cannot be quashed under Section 482 of the Cr.P.C. if it prima-facie discloses
cognizable offence. Therefore, it is requested to dismiss both the applications.
9. Heard the learned Advocates appearing on behalf of the respective parties.
10. At the outset it is required to be noted that denial to girl of her right to life is one of the heinous
violation of the right committed by the society; Gender bias and deep-rooted prejudice and
discrimination against the girl child and preference of male child have led to large scale female
foeticide in the last decade. Decline of sex ratio of girls and women in India is a major concern forAmita vs State on 19 September, 2008

all. In order to check female foeticide, the PNDT Act has been enacted. The PNDT Act provides for
(i) prohibition of the misuse of pre-natal diagnostic techniques for determination of sex of foetus,
leading to female foeticide; (ii) prohibition of advertisement of pre-natal diagnostic techniques for
detection or determination of sex; (iii) permission and regulation of the use of pre-natal diagnostic
techniques for the purpose of detection of specific genetic abnormalities or disorders; (iv)
permitting the use of such techniques only under certain conditions by the registered institutions;
and (v) punishment for violation of the provisions of the proposed legislation. Section 3 of the PNDT
Act provides Regulation of Genetic Counselling Centres, Genetic Laboratories and Genetic Clinics.
Section 4 of the PNDT Act provides for Regulation of Pre-natal Diagnostic Techniques. Under
Section 4 of the PNDT Act certain conditions are cast upon the person conducting Ultrasonography
on pregnant women. Section 5 of the PNDT Act provides Written consent of pregnant women and
prohibition of communicating the sex of foetus. As per Section 6 of the PNDT Act on
commencement of the Act, 1994 there is totally restriction and ban on determination of sex of
foetus. As per Section 6 of the PNDT Act, no Genetic Counselling Centre or Genetic Laboratory or
Genetic Clinic shall conduct or cause to be conducted in its Centre, Laboratory or Clinic, pre-natal
diagnostic techniques including ultrasonography, for the purpose of determining the sex of foetus.
As per Section 6(b) of the Act, no person shall conduct or cause to be conducted any pre-natal
diagnostic techniques including ultrasonography for the purpose of determining the sex of foetus. As
per Section 6(c), no person shall by whatever means, cause or allow to be caused selection of sex
before or after completion. To see that object and purpose of the PNDT Act is achieved, Rules 1996
are framed. Under Section 32 of the Act, Rule 3 provides for employees, the requirement of
equipment etc., for a Genetic Counselling Centre, Genetic Laboratory, Genetic Clinic, Ultrasound
Clinic and Imaging Centre. Rule 3A provides for sale of ultrasound machines / imaging machines.
Rule 4 provides Registration of Genetic Counselling Centre, Genetic Laboratory, Genetic Clinic,
Ultrasound Clinic and Imaging Centre. Rule 9 cast duty on every Genetic Counselling Centre,
Genetic Laboratory, Genetic Clinic, Ultrasound Clinic and Imaging Centre to maintain a register so
as to achieve ultimate object of the Act. Rule 10 provides for conditions for conducting pre-natal
diagnostic procedures. Section 10(1A) casts mandatory duty that any person conducting
ultrasonography / image scanning on a pregnant women shall give a declaration on each report on
ultrasonography / image scanning that he / she has neither detected nor disclosed the sex of foetus
of the pregnant women to any body and even the pregnant women before undergoing
ultrasonography / image scanning declare that she does not want to know the sec of her foetus. Thus
maintenance and preservation of records and conditions for conducting pre-natal diagnostic
procedures are absolutely mandatory in nature but they are to achieve goal and object of PNDT Act
and same is in larger public interest.
11. Now considering above provisions of the PNDT Act, and Rules framed thereunder and object of
the PNDT Act, present Criminal Misc.Applications are required to be considered.
12. In the respective complaints / criminal case non-compliance and breach of provisions of the Act
and Rules framed thereunder are specifically mentioned and same are on inspection by the
Appropriate Authority and/or Officers under the Act. Therefore, prima-facie averments and
allegations in the complaint discloses cognizable offence and accused are to be tried. It cannot be
said that on bare reading of the impugned complaints, no case is made out for further trial. WhetherAmita vs State on 19 September, 2008

accused will be punished or not are required to be considered at the time of trial and not at this
stage considering Section 482 of the Criminal Procedure Code.
13. As observed by the Hon'ble Supreme Court in the case of Indian Oil Corporation v/s. NEPC India
Ltd. and Ors reported in (2006) 6 SCC 736, a criminal complaint in exercise of jurisdiction under
Section 482 of the Cr.P.C., a complaint can be quashed where the allegations made in the complaint,
even if they are taken at their face value and accepted in their entirety, do not prima facie constitute
any offence or make out the case alleged against the accused. For this purpose, the complaint has to
be examined as a whole, but without examining the merits of the allegations. Neither a detailed
inquiry nor a meticulous analysis of the material nor an assessment of the reliability or genuineness
of the allegations in the complaint is warranted while examining prayer for quashing of a complaint.
It is further observed and held that the power to quash shall not, however, be used to stifle or scuttle
a legitimate prosecution. The power should be used sparingly and with abundant caution. In the
case of State of Orissa and Anr. V/s. Saroj Kumar Sahoo reported in (2005) 13 SCC 540 while
considering the nature, scope, purpose and exercise of powers under Section 482 of the Cr.P.C, the
Hon'ble Supreme Court has observed that inherent power is to be exercised sparingly and that too in
the rarest of rare cases. It is to be exercised ex debito justitiae, to do real and substantial justice and
not to stifle legitimate prosecution. It is further observed in the said decision that though no hard
and fast rule can be lad down as regards cases where such power can be exercised, but the High
Court being the highest court of a State should normally refrain from giving decision in a case in a
case where the entire facts are incomplete and hazy, more so, when the evidence has not been
collected and produced before the Court and the issues involved are of magnitude and cannot be
seen in their true perspective without sufficient material.
14. In the complaint it is provided to punish the accused so as to restrict the contravention of the
provisions of the PNDT Act/ Rules and ensure the compliance thereof to meet the noble cause as
envisaged by the PNDT Act. It was sought to be argued on behalf of the petitioners that alleged
breaches are technical one. It is true that it might be that alleged breaches may be seen to be
technical one but provisions of the Act and Rules which are mandatory are required to be complied
with strictly so as to achieve ultimate goal of the Act. As stated hereinabove, certain duties are cast
upon the persons conducting ultrasonography / image scanning on a pregnant women so as to check
female fotecide.
15. In the facts and circumstances of the case and allegations in the complaint narrated herein above
and looking to the object of the Act, no case is made out to exercise extra ordinary jurisdiction under
Section 482 of the Criminal Procedure Code to quash the impugned complaints at this stage. Now so
far as the decision of the learned Single Judge of this Court relied by the learned Advocate for the
petitioners is concerned, it is reported that decision of the learned Single Judge of this Court is
referred to Larger Bench and Larger Bench has already heard the matter. Even otherwise on facts,
prima facie case is made out against the petitioners and therefore, this Court is of the opinion that
considering the averments and allegations in the complaint, no case is made out to exercise powers
under Section 482 of the Cr.P.C. and quash the complaint at this stage.Amita vs State on 19 September, 2008

16. For the reasons stated above, both the applications fail, deserve to be dismissed and accordingly
they are dismissed. Rule discharged.
Before parting with the present judgment, this Court is tempted to observe and this Court is of the
opinion that moto of the Government and everybody is ?SSAVE GIRL??. However, it shall not be
only 'SAVE GIRL' but it should be 'WELCOME GIRL (BETI VADHAO)' and if this goal is achieved
and every man and women starts welcoming girl (Daughter) from the bottom of their heart, then
and then only it can be said that the purpose and object for which PNDT Act has been enacted is
achieved.
[M.R.Shah,J.] satish    Amita vs State on 19 September, 2008

