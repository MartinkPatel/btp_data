Aravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering
Ltd. on 12 September, 2017
Equivalent citations: AIR 2017 SUPREME COURT 4450, 2017 (15) SCC 32,
(2017) 3 GUJ LH 600, (2017) 11 SCALE 265, (2017) 4 JLJR 387, (2017) 5 CAL
HN 91, (2018) 2 CIVLJ 592, (2017) 4 RECCIVR 842, AIR 2018 SC (CIV) 166,
(2017) 5 ARBILR 226, 2018 (128) ALR SOC 43 (SC), 2018 (184) AIC (SOC) 30
(SC)
Author: Uday Umesh Lalit
Bench: Uday Umesh Lalit, Adarsh Kumar Goel
                                                                                                 1
                                                                                 REPORTABLE
                                         IN THE SUPREME COURT OF INDIA
                                          CIVIL APPELLATE JURISDICTION
                                    CIVIL APPEAL NOS. 12627-12628 OF 2017@
                            (SPECIAL LEAVE PETITION (CIVIL) NOS.25206-25207 OF 2016)
                         ARAVALI POWER COMPANY PVT. LTD.                .…...…APPELLANT(S)
                                                        VERSUS
                         M/S. ERA INFRA ENGINEERING LTD.                ..…...RESPONDENT(S)
                                                         WITH
                                   CIVIL APPEAL NOS. 12629-12630   OF 2017@
                              (SPECIAL LEAVE PETITION (CIVIL) NOS.503-504 OF 2017)
                                                     JUDGMENT
Uday Umesh Lalit, J.Aravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

1. Leave granted. These appeals challenge the common judgment and order dated 29.07.2016
passed by the High Court of Delhi at New Delhi in O.M.P. (T) (Comm.) No.13/2016 and Arbitration
Petition No.136/2016.
2. Construction work of permanent township for Indira Gandhi Super Thermal Power Project at
Jhajjar, Haryana was awarded to the Respondent- M/s Era Infra Engineering Ltd. on 20.05.2009
and contract dated 17.11.2009 signed thereafter broadly consisted of General Conditions of Contract
(GCC) and Special Conditions of Contract (SCC). Clause 56 of the GCC stipulated arbitration
between the parties in following terms:-
“56. ARBITRATION:-
Except where otherwise provided for in the contract all questions and disputes
relating to the meaning of the specifications, designs, drawings and instructions
herein before mentioned and as to the quality of workmanship or materials used on
the work or as to any other questions, claim, rights, matter or thing whatsoever in
any way arising out of or relating to the contract, design, drawing, specifications,
estimates, instructions, orders or these conditions of otherwise concerning the works,
or the executions or failures to execute the same whether arising during the progress
of the work or after the completion or abandonment thereof shall be referred to the
Sole Arbitration of the Project In-charge of the Project concerned of the owner, and if
the Project In-charge is unable or unwilling to act, to the sole arbitration of some
other persons appointed by the Chairman and Managing Director, NTPC limited
(Formerly National Thermal Power Corporation Ltd) willing to act as such Arbitrator.
There will be no objections, if the Arbitrator so appointed is an employee of NTPC
Limited (Formerly National Thermal Power Corporation Ltd), and that he had to deal
with the matters to which the contract relates and that in the course of his duties as
such he had expressed views on all or any of the matters in disputes or difference.
The Arbitrator to whom the matter is originally referred being transferred or vacating
his office or being unable to act for any reason as aforesaid at the time of such
transfer, vacations of office or inability to act, Chairman and Managing Directors,
NTPC limited (Formerly National Thermal Power Corporation Ltd.), shall appoint
another person to act as Arbitrator in accordance with the terms of the contract……”
3. According to the Appellant-Aravali Power Company Pvt. Ltd., scheduled date of completion of
work was 19.05.2011 but the progress of work was quite slow which compelled the Appellant to
cancel certain remaining works by its letters dated 18.07.2014, 24.10.2014, 30.06.2015 and
08.07.2015. By its letter dated 29.07.2015 the Respondent alleged that the delays in the project were
not attributable to the Respondent and after setting out certain grievances, the letter thereafter
sought to invoke arbitration submitting further that arbitration be through a retired Judge of the
High Court, the relevant portion of the letter being:-
“In view of the above circumstances and inaction of APCPL towards settlement of our
claims/payments, we hereby invoke Arbitration Clause of the Contract AgreementAravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

request your good self to appoint Arbitrator for settlement of our claims according to
Clause 56 of GCC of the Contract Agreement.
However, we want to draw your attention to the legal point that once the order of part
cancellation has been passed at the Highest Level of the Owner/Employer, hence, any
forum for resolution of dispute constituted by the said authority & particularly its
subordinate is of no legal consequence. It is a well settled proposition of law that
nobody can be judge in its own cause. Therefore, in light of the aforesaid settled
position of law, we seek an independent arbitration, through a retired Hon’ble Judge
of the Hon’ble High Court so as to seek vindication of our grievance as mentioned in
foregoing paras. Since the matter is utmost important, we hereby request that a panel
of independent Arbitrators may kindly be made available to us so that we can choose
from the panel. We would also be agreeable to the constitution of an Arbitral
Tribunal comprising of nominee of your company; our nominee and both the
nominee arbitrators appointing the Presiding/Umpire Arbitrator. We request that an
early action in this regard may kindly be taken, in accordance with law.”
4. In response, while refuting the allegations in the letter under reply, the Appellant
proceeded to appoint its Chief Executive Officer as the sole Arbitrator on 19.08.2015
and intimated the respondent on the same day in following terms:
“Please note that in terms of the Arbitration Clause 56 of the GCC there is no
provision for selection by you of Arbitrator from any panel of Arbitrators to be
offered by us. There is also no provision for formation of an Arbitral Tribunal as
suggested by you. Clause 56 of the GCC envisaged the appointment of the designated
officers as Arbitrator and accordingly the Chief Executives Officer APCPL on your
request, has been designated as the Sole Arbitrator. The Learned Arbitrator shall
inform you of the Arbitral proceedings in time.” By further communication dated
26.09.2015 the Appellant reiterated its stand taken in letter dated 19.08.2015.
5. In the meanwhile, the Arbitrator so appointed fixed the first hearing in arbitration
on 07.10.2015. The parties appeared on 07.10.2015 and the proceedings show that
the hearing was fixed on 09.04.2016 by which time there was to be completion of
filing of statement of response to counter claim etc. The proceedings do not show any
objection having been raised by the Respondent regarding continuation of the
arbitration proceedings. On 04.12.2015 a letter was addressed by the Respondent to
the Arbitrator seeking extension of time to file its statement of claim. It was stated,
inter alia:
“In the last-hearing held on 07.10.2015 the Claimant was given 60 days’ time to file
its Statement of Claim. In this connection it is to state that we need to collect some
more data and files from our other offices to make the Statement of Claim. For that
purpose, we need about one month further time to submit our Statement of Claim.Aravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

It is therefore, requested that the Ld. Sole Arbitrator may kindly grant one month further time to the
Claimant to file its Statement of Claim.” According to the record, the Arbitrator granted one month’s
time, as prayed for.
6. On 01.01.2016, the Arbitration and Conciliation (Amendment) Act, 2015 (hereinafter referred to
as “the Amendment Act”) was gazetted and according to Section 1(2), the Amendment Act was
deemed to have come into force on 23rd October, 2015.
7. For the first time on 12.01.2016, the Respondent sought to challenge the Arbitrator and raised
objection regarding constitution of the arbitral tribunal as under:
“In reference to the above referred communications addressed by us, we hereby state
that the constitution of the present arbitral tribunal is wholly invalid/void & against
the settled principles of law, and on account of which Era Infra Engineering Ltd. is
seeking appropriate legal remedies by approaching the Hon’ble High Court for
appointment of an Independent Arbitral Tribunal. Accordingly, we hereby request
your good self to kindly restrain yourself from assuming reference and seeking to
proceed with the present alleged proceedings, till the final outcome of the above
referred legal proceedings, sought to be immediately & urgently filed/preferred by
Era Infra Engineering Ltd.”
8. The objection was rejected by the Arbitrator on 22.01.2016 on the ground that the Respondent
had participated in the arbitral proceedings on 07.10.2015 without raising any protest. The
Respondent was then intimated to attend proceedings in arbitration scheduled to be held on
16.02.2016. The Respondent however, approached the High Court of Delhi by filing petition under
Section 14 of the Arbitration and Conciliation Act, 1996 (hereinafter referred to as “1996 Act”),
registered as OMP(T)(Comm.) No.13/2016, seeking termination of the mandate of the Arbitrator.
Grounds I, IV, VI, VII and VIII raised in the petition were:-
I It is submitted that it is a settled principle of law that nobody can be a judge in his
own cause. In other words, a party to the Agreement cannot be an arbiter in his own
cause. It is submitted that interest of justice and equity require that where a party to
the contract disputes the committing of any breach of the condition, the adjudication
should be by an independent person or body and not by the other party to the
contract.
IV That without prejudice to the above, it would also be relevant to mention herein
that the allegedly appointed Arbitrator namely, Shri S.K. Sinha, would also be
otherwise unable to perform the functions of an independent Arbitrator, in as much
as, he has himself, in his official capacity in the respondent-company, dealt with
contracts of nature similar to the contract works in question herein (including the
present contract works), on behalf of the respondent-company.Aravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

VI That it would also be worth mentioning that the Hon’ble Courts have consistently
held and observed that the policy of the Government/Statutory Authorities/Pubic
Sector undertakings, to provide/appoint for arbitration by an Employee Arbitrator is
a vexed problem which requires reconsideration, which is more so in deference to the
specific provisions of the new Act reiterating the need for an independent and
impartial Arbitrator.
VII That in furtherance of the aforementioned spirit as reiterated by the Hon’ble
Courts, the Act has also been suitably amended by the Legislature, whereby, inter
alia, it has been expressly provided that an Arbitrator who is an Employee, Manager,
Director or part of the Management or has a similar controlling influence in one of
the parties to the arbitration, is a valid ground giving rise to justifiable doubts as to
the independence or impartiality of an Arbitrator. Furthermore, it has also been
provided that an Arbitrator’s previous involvement in the case/subject matter would
also be a valid ground giving rise to justifiable doubts as to the independence or
impartiality of an Arbitrator.
VIII That in the present case, as brought out above, the alleged Arbitrator so
appointed by the respondent herein is an employee of the respondent herein itself. In
fact, the allegedly appointed individual is the Chief Executive Officer (CEO) of the
respondent herein, who on account of such position also has a controlling influence
over the respondent-company, against whom the petitioner herein seeks to assert its
claims. In such circumstances, the said allegedly appointed arbitrator would both in
law and fact be unable to perform his functions as an Arbitrator in an independent or
impartial manner.
9. On the same day, another petition being Arbitration Petition No.136 of 2016 was
filed by the Respondent under Section 11(6) of 1996 Act for appointing an
independent arbitrator for adjudicating disputes between the parties. The cause of
action, as pleaded, in the said petition was:-
“That the cause of action for filing the present petition arose on the various dates
when requests were made by the petitioner to the respondent for issuance of long
outstanding payments. The cause of action further arose on 29.07.2015 when
arbitration was invoked by the petitioner. The cause of action further arose, when the
respondent erroneously and illegally rejected the petitioner’s request for
appointment of an independent Arbitral Tribunal, which cause of action is still
subsisting and continuing since the respondent has failed to make the outstanding
payment and to so appoint an independent Arbitral Tribunal.”
10. On 01.03.2016 the High Court issued notice and stayed further proceedings in
arbitration. The matter was contested by the Appellant submitting, inter alia, that the
petition under Section 14 of 1996 Act was not maintainable; that the Arbitrator was
appointed strictly in terms of Clause 56 of the GCC; and that though the RespondentAravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

was informed about appointment of the Arbitrator on 19.08.2015, no steps to
challenge the appointment were undertaken within the time specified and in the
manner prescribed under 1996 Act.
11. The High Court by its judgment and order under Appeal set aside the
appointment of the Arbitrator and directed the Appellant to suggest names of three
panel Arbitrators from different departments to the Respondent who could thereafter
choose any one of them to be the Arbitrator in the matter. It was directed that in the
event of failure by the Appellant, the Respondent would be at liberty to revive the
petitions, in which case the Court would appoint a sole Arbitrator from the list
maintained by Delhi International Arbitration Centre. It was also observed that the
Arbitrator was CEO of the Appellant and was previously involved in cases/contract
works similar to the one involved in the present case and it could not be disputed that
the decisions of part cancellation were taken at the highest level of the Appellant. In
the circumstances, the High Court found that the apprehension entertained by the
Respondent was reasonable and not a vague or general objection. The observations of
the High Court were:-
“13. The Arbitrator, though the CEO of the respondent-Company and the Project
In-charge of the Indira Gandhi Super Thermal Power Project, P.O. Jharii, Distt.
Jhajjar, Haryana, was not the Engineer In-charge or the day-to-day In-charge of the
work, which was to be performed by the petitioner under the contract in question. In
fact, the Engineer In-charge for this project is AGM (CCD-Township) who is
supported by Group of Engineers (Dy. Managers, Managers & Sr. Managers) working
under him for execution of the work. Further, the AGM (CCD-Township) reports to
AGM (ME/CCD) who in turn reports to CEO (APCPL).
37. It is common parlance oft-quoted aphorism "Not only must Justice be done; it
must also be seen to be done." The reason is that rules are moral constructs that are
meant to serve higher value. The amendment of 2015 emphasize that the existence of
any relationship or interest of any kind is likely to give rise to justifiable doubts as to
his neutrality is to be avoided or any employee, manager, director, or has past or
present business or has a controlling influence, relationship with a party to the
dispute should not be appointed as an Arbitrator. Similarly, it is rightly mandated in
the Fifth Schedule of the Amended Act, 2015 (3 of 2016) that if the Arbitrator has
within the past three years been appointed on two or more occasions by one of the
parties and the Arbitrator has served within the three years in another arbitration on
a related issue involving one of the parties, his appointment would give rise to
justifiable doubts as to the independence or impartiality of arbitrators. No doubt, the
invocation was about three months prior to amendment. But the Court has to keep in
mind about the purpose and scope of the Act.
38. In the present case, no doubt, the invocation was on the basis of un-amended Act
but still under Section 12 of the Act would give the similar indication. The soleAravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

Arbitrator appointed by the respondent admittedly is CEO and Executive of the
respondent-Company who is also from the same office/department. In order to
maintain the neutrality, or to avoid any doubt in the mind of the petitioner and the
reasons given in the petition, it would be appropriate that independent sole
Arbitrator should be appointed as ultimately neutral person has merely to decide the
dispute between the parties. Even, the object and scope of the Act says so, that an
arbitration procedure should be fair and unbias. Thus, the appointment of Mr. S.K.
Sinha, CEO of the respondent Company is terminated and once the Arbitrator’s
appointment is terminated, the Court can consider the prayer of the petitioner.”
12. The decision of the High Court is challenged by the Appellant and Mr. Vikas
Singh, learned Senior Advocate submitted, inter alia, that as the appointment of the
Arbitrator was completely in tune with Clause 56 of the GCC there was no occasion
for the High Court to exercise any power or jurisdiction and that 1996 Act
contemplated clear and definite procedure for challenging the Arbitrator, and even if
such challenge were to fail the remedy under Section 13 was specific and of different
nature. In either case, according to him, the Respondent could not have approached
the High Court and both the petitions ought not to have been entertained.
13. To the extent the High Court had directed the Appellant to submit three names
from its panel of Arbitrators from which list the Respondent was to select the sole
Arbitrator, the Respondent challenged that part of the Judgment by filing SLP (Civil)
Nos.503-504 of 2017. Appearing for the Respondent, Mr. Manoj K. Singh, learned
Advocate relied upon some decisions of this Court and submitted that an Officer who
had either dealt with the project or was directly subordinate to the Authority whose
decision was the subject matter of dispute could not be an arbitrator in the matter.
14. At the outset, it must be stated that the invocation of arbitration in the present
case was on 29.07.2015, the Arbitrator was appointed on 19.08.2015 and the parties
appeared before the Arbitrator on 07.10.2015, well before 23.10.2015 i.e. the date on
which the Amendment Act was deemed to have come into force. The statutory
provisions that would therefore govern the present controversy are those that were in
force before the Amendment Act came into effect. We must mention here that both
the parties have addressed their submissions on this premise.
15. Before we consider the present controversy, we may quote, for facility, Sections
12, 13 and 14 of 1996 Act as they stood before the Amendment Act came into force:-
“12. Grounds for challenge.— (1) When a person is approached in connection with his
possible appointment as an arbitrator, he shall disclose in writing any circumstances
likely to give rise to justifiable doubts as to his independence or impartiality.
(2) An arbitrator, from the time of his appointment and throughout the arbitral
proceedings, shall, without delay, disclose to the parties in writing any circumstancesAravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

referred to in sub-section (1) unless they have already been informed of them by him.
(3) An arbitrator may be challenged only if—
(a) circumstances exist that give rise to justifiable doubts as to his independence or
impartiality, or
(b) he does not possess the qualifications agreed to by the parties.
(4) A party may challenge an arbitrator appointed by him, or in whose appointment
he has participated, only for reasons of which he becomes aware after the
appointment has been made.
13. Challenge procedure.— (1) Subject to sub-section (4), the parties are free to agree on a procedure
for challenging an arbitrator.
(2) Failing any agreement referred to in sub-section (1), a party who intends to challenge an
arbitrator shall, within fifteen days after becoming aware of the constitution of the arbitral tribunal
or after becoming aware of any circumstances referred to in sub-section (3) of section 12, send a
written statement of the reasons for the challenge to the arbitral tribunal. (3) Unless the arbitrator
challenged under sub-section (2) withdraws from his office or the other party agrees to the
challenge, the arbitral tribunal shall decide on the challenge. (4) If a challenge under any procedure
agreed upon by the parties or under the procedure under sub-section (2) is not successful, the
arbitral tribunal shall continue the arbitral proceedings and make an arbitral award.
(5) Where an arbitral award is made under sub-section (4), the party challenging the arbitrator may
make an application for setting aside such an arbitral award in accordance with section
34. (6) Where an arbitral award is set aside on an application made under sub-section (5), the Court
may decide as to whether the arbitrator who is challenged is entitled to any fees.
14. Failure or impossibility to act-
(1) The mandate of an arbitrator shall terminate if—
(a) he becomes de jure or de facto unable to perform his functions or for other reasons fails to act
without undue delay; and
(b) he withdraws from his office or the parties agree to the termination of his mandate.
(2) If a controversy remains concerning any of the grounds referred to in clause (a) of sub-section
(1), a party may, unless otherwise agreed by the parties, apply to the Court to decide on the
termination of the mandate.Aravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

(3) If, under this section or sub-section (3) of section 13, an arbitrator withdraws from his office or a
party agrees to the termination of the mandate of an arbitrator, it shall not imply acceptance of the
validity of any ground referred to in this section or sub-section (3) of section 12.”
16. In the present case Clause 56 of the GCC provides for arbitration by the Project In-charge of the
concerned Project, and in case such Project In-charge were to be unable or unwilling to act,
arbitration by any person appointed by the Chairman and Managing Director. It further provides
inter alia that there would be no objection even if the Arbitrator had dealt with the matters to which
the contract related in the course of his duties or had expressed views on all or any of the matters in
dispute or difference.
17. The fact that the named arbitrator happens to be an employee of one of the parties to the
Arbitration Agreement has not by itself, before the Amendment Act came into force, rendered such
appointment invalid and unenforceable. The observations of this Court in Indian Oil Corporation
Ltd. and Others v. Raja Transport Private Ltd.1 in paragraphs 28, 30, 31 and 32 are quite clear. Said
paragraphs were as under:
“28. It is contended by the respondent that in view of the em- phasis on the
independence and impartiality of an arbitrator in the new Act and having regard to
the basic principle of natural justice that no man should be judge in his own cause,
any arbi- tration agreement to the extent it nominates an officer of one of the parties
as the arbitrator, would be invalid and unenforceable.
30. We find no bar under the new Act, for an arbitration agree-
ment providing for an employee of a Government/statutory cor-
(2009) 8 SCC 520 poration/public sector undertaking (which is a party to the con- tract), acting as
an arbitrator. Section 11(8) of the Act requires the Chief Justice or his designate, in appointing an
arbitrator, to have due regard to:
“11. (8)(a) any qualifications required of the arbitrator by the agreement of the
parties; and
(b) other considerations as are likely to secure the ap-
pointment of an independent and impartial arbitrator.”
31. Section 12(1) requires an arbitrator, when approached in connection with his possible
appointment, to disclose in writing any circumstances likely to give rise to justifiable doubts as to his
independence or impartiality. Section 12(3) enables the arbi- trator being challenged if
(i) the circumstances give rise to justifiable doubts as to his independence or impartiality, orAravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

(ii) he does not possess the qualifications agreed to by the parties.
32. Section 18 requires the arbitrator to treat the parties with equality (that is to say without bias)
and give each party full op- portunity to present his case. Nothing in Sections 11, 12, 18 or other
provisions of the Act suggests that any provision in an ar- bitration agreement, naming the
arbitrator will be invalid if such named arbitrator is an employee of one of the parties to the
arbitration agreement.”
18. In the same decision, this Court in paragraphs 34 and 35 dealt with “justifiable apprehension
about the independence or impartiality” of an em- ployee arbitrator in following terms:-
“34. The fact that the named arbitrator is an employee of one of the parties is not ipso
facto a ground to raise a presumption of bias or partiality or lack of independence on
his part. There can however be a justifiable apprehension about the independence or
impartiality of an employee arbitrator, if such person was the controlling or dealing
authority in regard to the subject contract or if he is a direct subordinate (as
contrasted from an officer of an inferior rank in some other Department) to the
officer whose decision is the subject-matter of the dispute.
35. Where however the named arbitrator though a senior officer of the
Government/statutory body/government company, had nothing to do with the
execution of the subject contract, there can be no justification for anyone doubting
his independence or impartiality, in the absence of any specific evidence. Therefore,
senior officer(s) (usually Heads of Department or equivalent) of a
Government/statutory corporation/public sector undertaking, not associated with
the contract, are considered to be indepen-
dent and impartial and are not barred from functioning as arbi- trators merely because their
employer is a party to the contract.”
19. Section 12(1) as it then stood before the Amendment Act came into force, obliged the person
approached in connection with possible appoint- ment as an arbitrator, to disclose in writing any
circumstances likely to give rise to justifiable doubts as to his independence or impartiality. In the
present case, the Arbitrator undoubtedly is an employee of the Appellant but so long as there is no
justifiable apprehension about his independence or im- partiality, the appointment could not be
rendered invalid and unenforceable. As held in the case of Indian Oil Corporation Ltd. (supra) mere
fact that the arbitrator is an employee is not ipso facto a ground to raise any presumption of bias or
partiality. It is not the case that there had not been any fair and correct disclosure. All that the
Respondent alleged in its petition seeking termination of the mandate of the Arbitrator was, “…..he
has himself in his official capacity in the Respondent-Company dealt with contracts of nature
similar to the contract works in question….” The Respondent, while rely- ing on the provisions of the
Amendment Act had also submitted, “…. al- legedly appointed individual is the Chief Executive
Officer of the Respon- dent herein, who on account of such position also has the controlling influ-
ence over the Respondent-Company”. At the same time, the High Court ob- served in Paragraph 13Aravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

of the judgment under appeal that the Arbitrator was not the Engineer In-charge or the day-to-day
In-charge of the work and as a matter of fact, the Engineer In-charge was AGM (CCD-Township)
who had a team of other Engineers working under him a n d t h a t A G M ( C C D - Town s hi p) r e
por t e d t o AG M ( ME - C C D) w ho i n t ur n r e - p o r t e d t o C E O (APCPL) i.e. the Arbitrator.
The facts on record and the hierarchy as mentioned do not show that the Arbitrator in the present
matter was either the Dealing Authority in regard to the Contract or was directly sub-ordinate to the
Officer(s) whose decision is the subject matter of dispute. In fact, the decision, which could be
subject matter of dispute, was that of his subordinates. He may have dealt with contracts of nature
similar to the contract works in question but that by itself does not render the appointment invalid.
Since there is nothing on record which could raise justifiable doubts about the independence or
impartiality of the named Arbitrator, in the light of the observations of this Court in Indian Oil
Corporation Ltd. (supra) the appointment of the Arbitrator could not in any way be termed to be
illegal or unenforceable.
20. However, number of decisions of this Court were relied upon by the Respondent in support of its
submission that interference in the present case was called for. We may therefore deal with those
decisions.
A. In Northern Railway Administration, Ministry of Railway, New Delhi v. Patel Engineering
Company Ltd2., a Bench consisting of three learned Judges of this Court was called upon to consider
the apparent conflict between two Judgments of this Court in “ACE Pipeline Contracts (P) Ltd. v.
Bharat Petroleum Corpn. Ltd.3 and Union of India v. Bharat Battery Manufacturing Co. (P) Ltd.4”.
The submission made on behalf of the appellant therein as quoted in paragraph 5 was:-
“5.…………..It is, therefore, submitted that before the alternative is resorted to, agreed
procedure has to be exhausted. The agreement has to be given effect and the contract
has to be adhered to as closely as possible. Corrective measures have to be taken first
and the Court is the last resort.” (2008) 10 SCC 240 (2007) 5 SCC 304 (2007) 7 SCC
684 The discussion in paragraphs 12, 13 and 14 of the decision was as under:-
“12. A bare reading of the scheme of Section 11 shows that the emphasis is on the
terms of the agreement being adhered to and/or given effect as closely as possible. In
other words, the Court may ask to do what has not been done. The Court must first
ensure that the remedies provided for are exhausted. It is true as contended by Mr.
Desai, that it is not mandatory for the Chief Justice or any person or institution
designated by him to appoint the named arbitrator or arbitrators. But at the same
time, due regard has to be given to the qualifications required by the agreement and
other considerations.
13. The expression “due regard” means that proper attention to several circumstances
have been focused.
The expression “necessary” as a general rule can be broadly stated to be those things which are
reasonably required to be done or legally ancillary to the accomplishment of the intended act.Aravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

Necessary measures can be stated to be the reasonable steps required to be taken.
14. In all these cases at hand the High Court does not appear to have focused on the requirement to
have due regard to the qualifications required by the agreement or other considerations necessary to
secure the appointment of an independent and impartial arbitrator. It needs no reiteration that
appointment of the arbitrator or arbitrators named in the arbitration agreement is not a must, but
while making the appointment the twin requirements of sub-section (8) of Section 11 have to be kept
in view, considered and taken into account. If it is not done, the appointment becomes vulnerable.
In the circumstances, we set aside the appointment made in each case, remit the matters to the High
Court to make fresh appointments keeping in view the parameters indicated above.” B. In Union of
India v. Singh Builders Syndicate5, an arbitral tribunal consisting of three serving Officers was
constituted but no proceedings were actually undertaken. Thereafter, on an application preferred
under Section 11, the High Court appointed a Former Judge of that High Court as the sole arbitrator.
Paragraph 11 of the decision set out the question which arose for consideration and Paragraph 14
was as under:-
“14. It was further held in Northern Railway case that the Chief Justice or his
designate should first ensure that the remedies provided under the arbitration
agreement are exhausted, but at the same time also ensure that the twin
requirements of sub-section (8) of Section 11 of the Act are kept in view. This would
mean that invariably the court should first appoint the arbitrators in the manner
provided for in the arbitration agreement. But where the independence and
impartiality of the arbitrator(s) appointed/nominated in terms of the arbitration
agreement is in doubt, or where the Arbitral Tribunal appointed in the manner
provided in the arbitration agreement has not functioned and it becomes necessary to
make fresh appointment, the Chief Justice or his designate is not powerless to make
appropriate alternative arrangements to give effect to the provision for arbitration.”
C. After dealing with cases on the point including Northern Railway Administration
(supra), this Court in Indian Oil Corporation Ltd. (supra) summed up the legal
position as under:-
45. If the arbitration agreement provides for arbitration by a named arbitrator, the
courts should normally give (2009) 4 SCC 523 effect to the provisions of the
arbitration agreement. But as clarified by Northern Railway Admn., where there is
material to create a reasonable apprehension that the person mentioned in the
arbitration agreement as the arbitrator is not likely to act independently or
impartially, or if the named person is not available, then the Chief Justice or his
designate may, after recording reasons for not following the agreed procedure of
referring the dispute to the named arbitrator, appoint an independent arbitrator in
accordance with Section 11(8) of the Act. In other words, referring the disputes to the
named arbitrator shall be the rule. The Chief Justice or his designate will have to
merely reiterate the arbitration agreement by referring the parties to the named
arbitrator or named Arbitral Tribunal. Ignoring the named arbitrator/Arbitral
Tribunal and nominating an independent arbitrator shall be the exception to the rule,Aravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

to be resorted for valid reasons.
48. In the light of the above discussion, the scope of Section 11 of the Act containing the scheme of
appointment of arbitrators may be summarised thus:
(i) Where the agreement provides for arbitration with three arbitrators (each party to
appoint one arbitrator and the two appointed arbitrators to appoint a third
arbitrator), in the event of a party failing to appoint an arbitrator within 30 days from
the receipt of a request from the other party (or the two nominated arbitrators failing
to agree on the third arbitrator within 30 days from the date of the appointment), the
Chief Justice or his designate will exercise power under sub-section (4) of Section 11
of the Act.
(ii) Where the agreement provides for arbitration by a sole arbitrator and the parties
have not agreed upon any appointment procedure, the Chief Justice or his designate
will exercise power under sub-section (5) of Section 11, if the parties fail to agree on
the arbitration within thirty days from the receipt of a request by a party from the
other party.
(iii) Where the arbitration agreement specifies the appointment procedure, then
irrespective of whether the arbitration is by a sole arbitrator or by a three-member
Tribunal, the Chief Justice or his designate will exercise power under sub-section (6)
of Section 11, if a party fails to act as required under the agreed procedure (or the
parties or the two appointed arbitrators fail to reach an agreement expected of them
under the agreed procedure or any person/institution fails to perform any function
entrusted to him/it under that procedure).
(iv) While failure of the other party to act within 30 days will furnish a cause of action
to the party seeking arbitration to approach the Chief Justice or his designate in cases
falling under sub-sections (4) and (5), such a time-bound requirement is not found in
sub-section (6) of Section 11. The failure to act as per the agreed procedure within the
time-limit prescribed by the arbitration agreement, or in the absence of any
prescribed time-limit, within a reasonable time, will enable the aggrieved party to file
a petition under Section 11(6) of the Act.
(v) Where the appointment procedure has been agreed between the parties, but the
cause of action for invoking the jurisdiction of the Chief Justice or his designate
under clauses (a), (b) or (c) of sub-section (6) has not arisen, then the question of the
Chief Justice or his designate exercising power under sub-section (6) does not arise.
The condition precedent for approaching the Chief Justice or his designate for taking necessary
measures under sub-section (6) is that
(i) a party failing to act as required under the agreed appointment procedure; orAravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

(ii) the parties (or the two appointed arbitrators) failing to reach an agreement expected of them
under the agreed appointment procedure; or
(iii) a person/institution who has been entrusted with any function under the agreed appointment
procedure, failing to perform such function.
(vi) The Chief Justice or his designate while exercising power under sub-section (6) of Section 11
shall endeavour to give effect to the appointment procedure prescribed in the arbitration clause.
(vii) If circumstances exist, giving rise to justifiable doubts as to the independence and impartiality
of the person nominated, or if other circumstances warrant appointment of an independent
arbitrator by ignoring the procedure prescribed, the Chief Justice or his designate may, for reasons
to be recorded ignore the designated arbitrator and appoint someone else.” Thus, as laid down in
sub-para (v) of para 48, unless the cause of action for invoking jurisdiction under Clauses (a), (b) or
(c) of sub-section (6) of Section 11 of 1996 Act arises, there is no question of the Chief Justice or his
designate exercising power under sub-section (6) of Section 11.
D. In Denel (Proprietary) Limited v. Bharat Electronics Limited and Another6, though the
arbitration agreement provided that all disputes be referred to the Managing Director or his
nominee for (2010) 6 SCC 394 arbitration, this Court appointed retired Judge of this Court as the
sole arbitrator. The reason as is clear from paras 19 to 21 of the decision was; while invoking
arbitration the appellant therein had requested the respondent for an appointment of a mutually
agreed independent arbitrator but the respondent had plainly refused to refer the disputes to
arbitration. Para 20 of the decision is noteworthy:-
“20. In Datar Switchgears Ltd. v. Tata Finance Ltd.7 this Court while considering the
powers of the Court to appoint an arbitrator under Section 8 of the Arbitration Act,
1940, cited the decision of this Court in Bhupinder Singh Bindra v. Union of India8.
It was held in that case that:
“3. It is settled law that court cannot interpose and interdict the appointment of an
arbitrator, whom the parties have chosen under the terms of the contract unless legal
misconduct of the arbitrator, fraud, disqualification, etc. is pleaded and proved. It is
not in the power of the party at his own will or pleasure to revoke the authority of the
arbitrator appointed with his consent. There must be just and sufficient cause for
revocation.” The said principle has to abide in the normal course.” E. Similarly, in
Denel (Proprietary) Limited v. Ministry of Defence9, the relevant clause provided for
sole arbitration of the Director General, Ordnance Factory, Government of India or a
(2000) 8 SCC 151 (1995) 5 SCC 329 (2012) 2 SCC 759 Government Servant appointed
by him. It was observed that since no arbitrator was appointed in terms of the
governing clause within the stipulated period the respondent had forfeited the right
to make an appointment of an arbitrator. Paragraphs 21 and 24 of the decision were:-Aravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

“21. It is true that in normal circumstances while exercising jurisdiction under
Section 11(6), the Court would adhere to the terms of the agreement as closely as
possible. But if the circumstances warrant, the Chief Justice or the nominee of the
Chief Justice is not debarred from appointing an independent arbitrator other than
the named arbitrator.
24. It must also be remembered that even while exercising the jurisdiction under
Section 11(6), the Court is required to have due regard to the provisions contained in
Section 11(8) of the Act. The aforesaid section provides that apart from ensuring that
the arbitrator possesses the necessary qualifications required of the arbitrator by the
agreement of the parties, the Court shall have due regard to other considerations as
are likely to ensure the appointment of an independent and impartial arbitrator.
Keeping in view the aforesaid provision, this Court in Indian Oil Corpn. Ltd, whilst
emphasizing that normally the Court shall make the appointment in terms of the
agreed procedure, has observed that the Chief Justice or his designate may deviate
from the same after recording reasons for the same……..” F. In Union of India and
Others v. Uttar Pradesh State Bridge Corporation Limited10, an arbitral tribunal
consisting of three (2015) 2 SCC 52 Gazetted Railway Officers was constituted in the
year 2007 and despite four years having passed, the matter was not getting
concluded. In the circumstances, while accepting the petition for setting aside the
mandate of the tribunal the High Court had appointed a retired Chief Justice as the
sole arbitrator. While considering the grievance that such appointment was beyond
the concerned arbitration clause, this Court observed:-
“12. As is clear from the reading of Section 14, when there is a failure on the part of
the Arbitral Tribunal to act and it is unable to perform its function either de jure or
de facto, it is open to a party to the arbitration proceedings to approach the court to
decide on the termination of the mandate. Section 15 provides some more
contingencies when mandate of an arbitrator can get terminated. In the present case,
the High Court has come to a categorical finding that the Arbitral Tribunal failed to
perform its function, and rightly so. It is a clear case of inability on the part of the
members of the Tribunal to proceed in the matter as the matter lingered on for
almost four years, without any rhyme or justifiable reasons. The members did not
mend their ways even when another life was given by granting three months to them.
Virtually a peremptory order was passed by the High Court, but the Arbitral Tribunal
remained unaffected and took the directions of the High Court in a cavalier manner.
Therefore, the order of the High Court terminating the mandate of the Arbitral
Tribunal is flawless. This aspect of the impugned order is not even questioned by the
appellant at the time of hearing of the present appeal. However, the contention of the
appellant is that even if it was so, as per the provisions of Section 15 of the Act,
substitute arbitrators should have been appointed “according to the rules that were
applicable to the appointment of the arbitrator being replaced”. On this basis, it was
the submission of Mr. Mehta, learned ASG, that the High Court should have resorted
to the provision contained in Clause 64 of GCC.Aravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

13. No doubt, ordinarily that would be the position. The moot question, however, is
as to whether such a course of action has to be necessarily adopted by the High Court
in all cases, while dealing with an application under Section 11 of the Act or is there
room for play in the joints and the High Court is not divested of exercising discretion
under some circumstances? If yes, what are those circumstances? It is this very
aspect which was specifically dealt with by this Court in Tripple Engg.
Works.11 Taking note of various judgments, the Court pointed out that the notion that the High
Court was bound to appoint the arbitrator as per the contract between the parties has seen a
significant erosion in recent past. In paras 6 and 7 of the said decision, those judgments wherein
departure from the aforesaid “classical notion” has been made are taken note of……………….” G. In
Voestalpine Schienen GMBH v. Delhi Metro Rail Corporation Limited12, the relevant clause
contemplated that the disputes be settled by three arbitrators from and out of a list of five engineers
supplied by the respondent therein. The appellant had invoked arbitration on 14.06.2016 i.e. after
the amending Act. When the list of five persons comprising of serving officers was supplied by the
respondents, an objection was taken that such procedure would lead to appointment of “illegal
persons” in view of Section 12(5) read (2014) 9 SCC 288 (2017) 4 SCC 665 with Clause 1 of Schedule
7 of the Act. This Court considered that Section 12 of the Act was amended pursuant to the
recommendations by the Law Commission which specifically dealt with the issue of “neutrality of
arbitrators”, and observed that if the arbitration clause finds foul with the amended provisions, the
appointment of the Arbitrator even if apparently in conformity with the arbitration clause in the
agreement, would be illegal and thus the Court would be within its powers to appoint such
arbitrator(s) as may be permissible. Paragraph 18 sums up this aspect of the matter:-
“18. Keeping in mind the afore-quoted recommendation of the Law Commission,
with which spirit, Section 12 has been amended by the Amendment Act, 2015, it is
manifest that the main purpose for amending the provision was to provide for
neutrality of arbitrators. In order to achieve this, sub-section (5) of Section 12 lays
down that notwithstanding any prior agreement to the contrary, any person whose
relationship with the parties or counsel or the subject-matter of the dispute falls
under any of the categories specified in the Seventh Schedule, he shall be ineligible to
be appointed as an arbitrator. In such an eventuality i.e. when the arbitration clause
finds foul with the amended provisions extracted above, the appointment of an
arbitrator would be beyond pale of the arbitration agreement, empowering the court
to appoint such arbitrator(s) as may be permissible. That would be the effect of non
obstante clause contained in sub-section (5) of Section 12 and the other party cannot
insist on appointment of the arbitrator in terms of the arbitration agreement.”
21. Except the decision of this Court in Voestalpine Schienen GMBH (supra) referred
to above, all other decisions arose out of matters where invocation of arbitration was
before the Amendment Act came into force.
Voestalpine Schienen GMBH (supra) was a case where the invocation was on 14.6.2016 i.e. after the
Amendment Act and the observations in Para 18 clearly show that since “the arbitration clause findsAravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

foul with the amended provisions”, the Court was empowered to appoint such arbitrator(s) as may
be permissible. The ineligibility of the arbitrator was found in the context of amended Section 12
read with Seventh Schedule (which was brought in by Amendment Act) in a matter where
invocation for arbitration was after the Amendment Act had come into force. It is thus clear that in
pre-amendment cases, the law laid down in Northern Railway Administration (Supra), as followed
in all the aforesaid cases, must be applied, in that the terms of the agreement ought to be adhered to
and/or given effect to as closely as possible. Further, the jurisdiction of the Court under Section 11 of
1996 Act would arise only if the conditions specified in clauses (a), (b) and (c) are satisfied. The
cases referred to above show that once the conditions for exercise of jurisdiction under Section 11(6)
were satisfied, in the exercise of consequential power under Section 11(8), the Court had on certain
occasions gone beyond the scope of the concerned arbitration clauses and appointed independent
arbitrators. What is clear is, for exercise of such power under Section 11(8), the case must first be
made out for exercise of jurisdiction under Section 11(6).
22. The principles which emerge from the decisions referred to above are:-
A. In cases governed by 1996 Act as it stood before the Amendment Act came into
force:-
(i) The fact that the named arbitrator is an employee of one of the parties is not ipso
facto a ground to raise a presumption of bias or partiality or lack of independence on
his part. There can however be a justifiable apprehension about the independence or
impartiality of an employee arbitrator, if such person was the controlling or dealing
authority in regard to the subject contract or if he is a direct subordinate to the officer
whose decision is the subject-matter of the dispute.
(ii) unless the cause of action for invoking jurisdiction under Clauses (a), (b) or (c) of
sub-section (6) of Section 11 of 1996 Act arises, there is no question of the Chief
Justice or his designate exercising power under sub-section (6) of Section 11.
(iii) The Chief Justice or his designate while exercising power under sub-section (6)
of Section 11 shall endeavour to give effect to the appointment procedure prescribed
in the arbitration clause.
(iv) While exercising such power under sub section (6) of Section 11, If circumstances
exist, giving rise to justifiable doubts as to the independence and impartiality of the
person nominated, or if other circumstances warrant appointment of an independent
arbitrator by ignoring the procedure prescribed, the Chief Justice or his designate
may, for reasons to be recorded ignore the designated arbitrator and appoint
someone else.
B. In cases governed by 1996 Act after the Amendment Act has come into force:-Aravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

If the arbitration clause finds foul with the amended provisions, the appointment of
the Arbitrator even if apparently in conformity with the arbitration clause in the
agreement, would be illegal and thus the Court would be within its powers to appoint
such arbitrator(s) as may be permissible.
23. The observations of the High Court in paragraphs 37-38 as quoted above show that the exercise
was undertaken by the High Court, “in order to make neutrality or to avoid doubt in the mind of the
petitioner” and ensure that justice must not only be done and must also be seen to be done. In effect,
the High Court applied principles of neutrality and impartiality which have been expanded by way of
Amendment Act, even when no cause of action for exercise of power under Section 11(6) had arisen.
The procedure as laid down in unamended Section 12 mandated disclosure of circumstances likely
to give rise to justifiable doubts as to independence and impartiality of the arbitrator. It is not the
case of the Respondent that the provisions of Section 12 in unamended form stood violated on any
count. In any case the provision contemplated clear and precise procedure under which the
arbitrator could be challenged and the objections in that behalf under Section 13 could be raised
within prescribed time and in accordance with the procedure detailed therein. The record shows
that no such challenge was raised within the time and in terms of the procedure prescribed. As a
matter of fact, the Respondent had participated in the arbitration and by its communication dated
04.12.2015, had sought extension of time to file its statement of claim.
24. In the circumstances, the High Court was clearly in error in exercising jurisdiction in the present
case and it ought not to have interfered with the process and progress of arbitration. We therefore
accept the challenge raised by the Appellant and reject that raised by the Respondent. Consequently,
appeals arising out of Special Leave Petition (Civil) Nos.25206-25207 of 2016 are allowed while
those arising from Special Leave Petition (Civil) Nos.503-504 of 2017 stand dismissed. The
arbitration, in pursuance of the appointment of the Arbitrator on 19.08.2015, shall proceed in
accordance with law.
25. The appeals are disposed of in aforesaid terms, without any order as to costs.
…….………………….J. (Adarsh Kumar Goel) …………….………….J. (Uday Umesh Lalit) New Delhi
September 12, 2017Aravali Power Company Pvt. Ltd. vs M/S. Era Infra Engineering Ltd. on 12 September, 2017

