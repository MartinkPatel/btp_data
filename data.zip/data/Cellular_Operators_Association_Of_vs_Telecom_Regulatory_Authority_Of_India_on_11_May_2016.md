Cellular Operators Association Of ... vs Telecom Regulatory
Authority Of India ... on 11 May, 2016
Equivalent citations: AIR 2016 SUPREME COURT 2336, 2016 (4) ABR 230,
2016 (4) ADR 141, AIR 2016 SC (CIVIL) 1762, (2016) 4 MAD LJ 575, 2016 (7)
SCC 703, (2016) 5 SCALE 137, 2016 (4) KCCR SN 493 (SC)
Author: R.F. Nariman
Bench: R.F. Nariman, Kurian Joseph
                                             REPORTABLE
                        IN THE SUPREME COURT OF INDIA
                        CIVIL APPELLATE JURISDICTION
                      CIVIL APPEAL NO.  5017    OF 2016
               (ARISING OUT OF S.L.P. (CIVIL) NO.6521 OF 2016)
CELLULAR OPERATORS ASSOCIATION
OF INDIA AND OTHERS                         ..APPELLANTS
                                   VERSUS
TELECOM REGULATORY AUTHORITY
OF INDIA AND OTHERS                     ..RESPONDENTS
                                    WITH
                      CIVIL APPEAL NO.  5018    OF 2016
               (ARISING OUT OF S.L.P. (CIVIL) NO.6522 OF 2016)
                        J U D G M E N T
R.F. Nariman, J.
Leave granted.
This group of appeals before us is by various telecom operators who offer telecommunicationCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

services to the public generally. Various writ petitions were filed in the Delhi High Court challenging
the validity of the Telecom Consumers Protection (Ninth Amendment) Regulations, 2015
(hereinafter referred to as the “Impugned Regulation”), notified on 16.10.2015, (to take effect from
1.1.2016), by the Telecom Regulatory Authority of India. The aforesaid amendment was made
purportedly in the exercise of powers conferred by Section 36 read with Section 11 of the Telecom
Regulatory Authority of India Act, 1997. By the aforesaid amendment, every originating service
provider who provides cellular mobile telephone services is made liable to credit only the calling
consumer (and not the receiving consumer) with one rupee for each call drop (as defined), which
takes place within its network, upto a maximum of three call drops per day. Further, the service
provider is also to provide details of the amount credited to the calling consumer within four hours
of the occurrence of a call drop either through SMS/USSD message. In the case of a post paid
consumer, such details of amount credited in the account of the calling consumer were to be
provided in the next bill.
A brief background is necessary in order to appreciate the controversy at hand. Under an Act of
ancient vintage, namely, the Indian Telegraph Act, 1885, the Central Government or the Telegraph
Authority is the licensing authority by which persons are licenced under Section 4(1) of the said Act
for providing specified public telecommunication services. Given the fact that it is the Central
Government or the Telegraph Authority who is the licensor in all these cases, the said licensor enters
into what are described as licence agreements for the provision of Unified Access Services in the
specified service areas. Various standard terms and conditions are laid down in these licences, some
of which are described hereinbelow. Vide clause 2.1, such licences are granted to provide
telecommunication services, as defined, on a non-exclusive basis in designated service areas. It is
mandatory that the licensee provides such services of a good standard, by establishing a state of the
art digital network. Licences are usually given for a period of 20 years at a time with a 10 year
extension if the licensor so deems expedient. Under clause 5 of the aforesaid licence agreement, the
licensor reserves the right to modify, at any time, the terms and conditions of license, if in its
opinion it is necessary or expedient so to do in public interest, in the interest of security of the State,
or for the proper conduct of telegraphs. Under condition 28, which is of some relevance to
determine the question involved in these appeals, the licensee shall ensure that the quality of service
standards as prescribed either by the licensor or the Telecom Regulatory Authority of India shall be
adhered to. The licensee is made responsible for maintaining performance and quality of service
standards and is to keep a record of the number of faults and rectification reports in respect of a
particular service which is to be produced before the licensor/TRAI as and when desired. It is also
important that the licensee be responsive to complaints lodged by its subscribers and rectify the
same. Under clause 34, which deals with roll-out obligations, the licensee is to ensure that coverage
of a district headquarters/town would mean that at least 90% of the area bounded by municipal
limits should get the required street and in- building coverage. Interestingly, under clause 35,
liquidated damages are also provided for, in case the licensee does not commission the service
within 15 days of the expiry of the commissioning date and for certain other delays relatable to
commissioning of service.
It may also be noted that right from September, 2005, TRAI has been lamenting the shortage and
consequent distance of mobile towers from each other and both the Government as well as TRAICellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

have been writing to the Chief Secretaries of various State Governments to grant timely permissions
for establishing telecom towers. In this behalf, we have been shown guidelines issued by DOT to the
Chief Secretaries dated 1.8.2013. We have also been shown an amendment to the Quality of Service
Regulations dated 21.8.2014 by which TRAI has noticed practical difficulties that are faced due to
various reasons by which cable breakdowns and indoor faults take place, with the Authority
requiring the striking of a balance between the problems faced by the licensees and the need to
ensure quality of service to customers. We were also shown a letter from the Ministry of
Communications written to Chief Ministers of all the States to permit installation of towers on
Government buildings. This letter is dated 3.8.2015. Further, there is a constant tussle between cell
phone operators and municipal authorities, landing cell phone operators in court against municipal
authorities, who seek to restrict the setting up of cell phone towers, given the apprehension that
radiation from these towers has a direct causal link with cancer in human beings. It is also
important to note that by a Quality of Service Regulation dated 20.3.2009, issued under Section 11
read with Section 36 of the TRAI Act, TRAI has provided, insofar as cellular mobile phone services
are concerned, for a call drop rate of 2% averaged over a period of one month. It has also provided
for financial disincentives in case there is a failure to meet this parameter by enacting a second
amendment to the Quality of Service Regulations dated 8.11.2012 by which a service provider is
liable to pay, by way of financial disincentive, an amount not exceeding Rs.50,000/- per parameter
that is contravened as the Authority may by order direct, and in the case of second or subsequent
contravention, to pay an amount not exceeding Rs.1,00,000/- per parameter for each such
contravention as the Authority may by order direct. One day before the Impugned Regulation, i.e.,
on 15.10.2015, this financial disincentive was raised from Rs.50,000/- to Rs.1,00,000/-, and
Rs.1,00,000/- to Rs.1,50,000/- for the second consecutive contravention, and Rs.2,00,000/- for
each subsequent consecutive contravention.
It is in this background that the impugned Ninth Amendment to the Telecom Consumers Protection
Regulations of 2015 was made, on 16.10.2015. The Impugned Regulation reads as under:-
TELECOM CONSUMERS PROTECTION (NINTH AMENDMENT) REGULATIONS,
2015 (9 OF 2015) No. 301/2015-F&EA ----- In exercise of the powers conferred by
section 36, read with sub-clauses (i) and (v) of clause (b) of sub-section (1) of section
11, of the Telecom Regulatory Authority of India Act, 1997 (24 of 1997), the Telecom
Regulatory Authority of India hereby makes the following regulations further to
amend the Telecom Consumers Protection Regulations, 2012 (2 of 2012), namely:-
(1) These regulations may be called the Telecom Consumers Protection (Ninth
Amendment) Regulations, 2015.
(2) They shall come into force from the 1st January, 2016.
2. In regulation 2 of the Telecom Consumers Protection Regulations, 2012 (hereinafter referred to as
the principal regulations), after clause (ba), the following clauses shall be inserted, namely:--Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

“(bb) “call drop” means a voice call which, after being successfully established, is
interrupted prior to its normal completion; the cause of early termination is within
the network of the service provider;”;
(bc) “calling consumer” means a consumer who initiates a voice call;”;
After Chapter IV of the principal regulations, the following chapter shall be inserted, namely :-
|“CHAPTER V”                                                          |
|                                                                     |
|RELIEF TO CONSUMERS FOR CALL DROPS                                   |
|                                                                      |
|16. Measures to provide relief to consumers.- Every originating       |
|service provider providing Cellular Mobile Telephone Service shall, | |for each call drop within its
network, | |(a) credit the account of the calling consumer by one rupee:| | | |Provided that such
credit in the account of the calling consumer shall| |be limited to three dropped calls in a day
(00:00:00 hours to 23:59:59| |hours); | |(b) provide the calling consumer, through SMS/USSD
message, | |within four hours of the occurrence of call drop, the details of | |amount credited in his
account; and | |(c) in case of post-paid consumers, provide the details of | |the credit in the next
bill.” | The explanatory memorandum to the aforesaid amendment makes interesting reading. In the
first paragraph of the said memorandum, the 2009 Quality of Service Regulation referred to
hereinabove, granting an allowance of an average of 2% call drops per month, is specifically referred
to. Also, interestingly enough, the service providers have stated that they are meeting this
benchmark completely with one or two minor exceptions. Despite this, the Authority has embarked
on the Impugned Regulation, stating that consumers, at various fora, have raised the issue of call
drops, complaining that in their experience, the quality of making voice calls has deteriorated. The
Authority responded by issuing a consultation paper marked “Compensation to the Consumers in
the event of dropped calls” dated 4.9.2015. Stakeholders were given till 21.9.2015 to submit their
comments in writing with counter comments thereto being given one week thereafter, i.e., by
28.9.2015. The Authority records that written comments were received from 4 industry associations,
11 Cellular Mobile Telephone Service Providers, 2 consumer advocacy groups, 2 organizations, and
518 individual consumers. 5 counter comments were also received. The Authority notes that an open
house discussion was held on 1.10.2015 in New Delhi with the stakeholders. According to the
Authority, consumers wanted relief in the event of dropped calls under two broad heads – excess
charging and inconvenience caused to them. In paragraphs 6 and 7, the arguments of service
providers have been noted, in which service providers stated their difficulties in the matter of
sealing/closing down existing sites for towers by municipal authorities and other related issues
together with spectrum related issues. They specifically informed the Authority that a large
proportion of call drops are beyond their control. In reply thereto, consumers spoke of the
inconvenience caused to them by call drops. Some consumers also contended that the financial
disincentive levied for failing to meet the benchmark for call drop rates should be revised upwards.
(This was in fact done, as we have seen, just one day before the Impugned Regulation itself, i.e., on
15.10.2015). The Explanatory Memorandum then goes on to state:-Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

“18. Based on the above, it is clear that while all CMTSPs and the industry
associations have argued that question for compensation to the consumers on call
drops does not arise as it is neither justifiable nor practicable, most of the consumers
and consumer advocacy groups have insisted that they should be compensated by the
CMTSPs for the inconvenience caused to them.
19. After a careful analysis, the Authority has come to the conclusion that call drops
are instances of deficiency in service delivery on part of the CMTSPs which cause
inconvenience to the consumers, and hence it would be appropriate to put in place a
mechanism for compensating the consumers in the event of dropped calls. The
Authority is of the opinion that compensatory mechanism should be kept simple for
the ease of consumer understanding and its implementation by the CMTSPs. While
one may argue that amount of compensation should be commensurate to the loss/
suffering caused due to an event but in case of a dropped call it is difficult to quantity
the loss/suffering/inconvenience caused to the consumers as it may vary from one
consumer to another and also in accordance to their situations. Accordingly, the
Authority has decided to mandate originating CMTSPs to credit one Rupee for a
dropped call to the calling consumers as notional compensation. Similarly, the
Authority has decided that such credit in the account of the calling consumer shall be
limited to three dropped calls in a day (00:00:00 hours to 23:59:59 hours). The
Authority is of the view that such a mandate would compensate the consumers for the
inconvenience caused due to interruption in service by way of call drops, to a certain
extent.
20. The Authority is also aware that communication to the consumers is important
and therefore, the Authority has decided to mandate that, each originating CMTSP,
within four hours of the occurrence of call drop within its network, inform the calling
consumer, through SMS/USSD message the details of amount credited in his account
for the dropped call, if applicable.
21. The Authority is conscious of the fact that for carrying out the afore-mentioned
mandate, the CMTSPs would have to make suitable provisions in their systems,
which would require time and efforts. Accordingly, the Authority has decided that the
afore-mentioned mandate would become applicable on the CMTSPs with effect from
the 1st January, 2016.
22. The Authority shall keep a close watch on the implementation of the mandate as
well as the measures being initiated by the CMTSPs to minimize the problem of
dropped calls as given in their submissions during the consultation process and may
review after six months, if necessary.” At this stage, it is necessary to refer to a
technical paper issued by the very same Authority a few days after the Impugned
Regulation. On 13.11.2015, TRAI issued a paper called “Technical Paper on call drops
in cellular network”. TRAI noticed that the consumer base in the country is growing
very fast and that the mobile telecom infrastructure is not growing at the same pace.Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

This leads to a dip in the quality of service provided.
It is interesting to notice that TRAI specifically adverts to the fact that call drops can take place due
to a variety of reasons. It pointed out that one of the reasons is due to the consumer’s own fault, and
that 36.9% of call drops are attributable to consumer faults. It further went on to notice that the
benchmark set for call drops is 2%, and it is seen that only 3 out of 12 licensees are not adhering to
the said benchmark – 2 of them being BSNL, who is not an appellant before us, the other one being
Aircel. The Authority ultimately concluded:-
“5.27. In light of the reasons discussed above about the increase in call drops, it must
be realized that mobile towers do not have an unlimited capacity for handling the
current network load. There is an urgent need to increase the number of the towers
so as to cater to the demands of a growing subscriber base. At the same time,
problems like removal of towers from certain areas by Authorities should be
adequately addressed. This problem is particularly evident in urban areas. Moreover,
with the increase in the usage of 3G networks, the growth rate of mobile towers
supporting 2G networks has reduced. This must be addressed.
5.28. The previous sections highlighted some important countermeasures at the TSPs’ end.
Measures like Dynamic Channel Allocation, multiple call routing and optimized resource
management can be employed by the TSP’s besides usage of mobile signal boosters through the
TSPs at users’ buildings or premises. Some prioritization schemes like MBPS, CAC, Guard Channels,
Handoff Queuing and Auxiliary Stations essentially need to be incorporated by TSPs to reduce call
drops.”
8. A Writ Petition, being Writ Petition (Civil) No.11596 of 2015, was filed before the Delhi High
Court, together with various other petitions, in which the Ninth Amendment, being the Impugned
Amendment to the Regulation pointed out hereinabove, was challenged. By the impugned judgment
dated 29.2.2016, the Delhi High Court noticed the various arguments addressed on behalf of the
various appellants, together with the reply given by Shri P.S. Narasimha, learned Additional
Solicitor General of India appearing on behalf of TRAI. The High Court then went on to discuss the
validity of the Impugned Regulation under two grounds – the ground of being ultra vires the parent
Act, and the ground that the Regulation was otherwise unreasonable and manifestly arbitrary. The
High Court repelled the challenge of the appellants on both the aforesaid grounds. The High Court
first referred to BSNL v. Telecom Regulatory Authority of India, (2014) 3 SCC 222 in some detail,
and then went on to hold that the power vested in TRAI under Section 36(1) to make regulations is
wide and pervasive, and that as there can be no dispute that the Impugned Regulation has been
made to ensure quality of service extended to the consumer by the service provider, it would fall
within Section 36(1) read with Section 11(1)(b)(v). The High Court further held that the contention
that the compensation provided under the Impugned Regulation amounts to imposition of penalty
is liable to be rejected, since compensation as provided under the Impugned Regulation is only
notional compensation to consumers who have suffered as a result of call drops. The High Court
then went on to say that a transparent consultative process was followed by TRAI in making the
Impugned Regulation, and that the technical paper on call drops issued on 13.11.2015 addressed allCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

issues that were sought to be raised in the present petitions. The contention that 100% performance
is demanded under the Impugned Regulation was rejected as being factually incorrect and without
any basis. It was further added that the impossibility of identification of the reason for the call drop
was incorrect inasmuch as these reasons are network related, and that is something that has not
been disputed by telecom equipment manufacturers like M/s. Nokia and M/s. Ericsson. It was
further held that the Impugned Regulation attempted to balance the interest of consumers with the
interest of service providers by limiting call drops that are to be compensated to only 3 and also
mandating that only the calling consumer and not the receiving consumer was liable to be so
compensated. In dealing with manifest arbitrariness, the High Court held that the 2% standard
imposed by the Quality of Service Regulations is distinct and different from compensation provided
to consumers for dropped calls. The High Court sought to make a distinction between the 2%
tolerance limit as being a quality parameter for the entire network area, as against compensation
provided which specifies an individual standard. On the plea that the difficulties faced by service
providers in setting up mobile towers being something beyond their control, the High Court
declined to enter into the said controversy since the High Court does not have the expertise to
adjudicate on such rival claims. The validity of the Impugned Regulation was upheld and the Writ
Petitions were dismissed.
9. At this stage, it would be important to notice the arguments made on behalf of the various
appellants before us. We have heard learned senior advocates Shri Kapil Sibal, Dr. Abhishek Manu
Singhvi, and Shri Gopal Jain. The arguments that were made by them can fall into four neat logical
compartments. First and foremost, they argued that the Ninth Amendment to the Telecom
Consumers Protection Regulations, 2015, is ultra vires Section 36 read with Section 11 of the
Telecom Regulatory Authority of India Act, 1997. They argued that, in any event, these Regulations,
being in the nature of subordinate legislation, were manifestly arbitrary and unreasonable, and
therefore affected their fundamental rights under Article 14 and Article 19(1)(g) of the Constitution.
They further went on to state that there was no power in the TRAI to interfere with their licence
conditions which are contract conditions between the licensor and the licensee, and that the said
Regulations in seeking to impose a penalty not provided for by the licence should be struck down as
such. Fourthly, they argued that Section 11(4) of the said Act requires the Authority to be
transparent in its dealings with the various stakeholders, and it has miserably failed in this also.
10. Under the broad head “ultra vires” learned counsel have argued that Regulations can only be
made under Section 36(1) of the TRAI Act if they are consistent with and carry out the purposes of
the Act. The present Regulations having purportedly been made under Section 11(1)(b)(i) and (v) of
the Act are in fact de hors Section 11(1)(b)(i) and (v), and contrary to the Quality of Service
Regulations already made by the same Authority under the self-same provision. They argued that
the present Impugned Regulation has nothing to do with ensuring compliance of the terms and
conditions of licence inasmuch as none of such terms and conditions empowers the Authority to levy
a penalty based on No Fault Liability. They also argued that no standard of quality of service is
prescribed by the Regulation at all, and therefore the so-called protection of the consumers is
without laying down a standard of quality of service and is also directly contrary to the 2% standard
already laid down. It was argued by them that as all of them met the 2% standard laid down by the
2009 standard of quality regulation, they could not be penalized as that would then amount toCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

substituting 98% with 100% as even one call drop would lead to a payment of penalty of rupee one.
They also argued that such penalty was not authorized by either Section 36 or by Section 11, and,
unlike Section 29 of the Act, no such authority is to be found in the said Sections.
11. Under the broad head “manifestly arbitrary”, and “unreasonable restrictions” learned counsel for
the appellants argued that without there being any fault on their part, they were foisted with a penal
liability. This is not only contrary to any norm of law or justice, but directly contrary to Section 14 of
the Act which speaks of adjudication taking place between a service provider and a group of
consumers. The complaint of an individual consumer before a Consumer Disputes Redressal Forum
would be dismissed on the ground that penal damages cannot be awarded without the establishment
of fault in any adjudication for “inconvenience” as opposed to “loss caused”. To lay down by way of
subordinate legislation, a strict no fault penal liability would go contrary to the scheme of the TRAI
Act, particularly when it is contrasted with the Electricity Act, 2003. We were shown Section 57 and
certain other Sections of the said Act in which the Central and State Commissions for Electricity,
unlike the TRAI, also have adjudicatory functions. If, as a result of the adjudicatory function,
compensation for loss is decreed, the Commission under the Electricity Act could do so, but not
TRAI, as it has no adjudicatory functions but only recommendatory, administrative, and legislative
functions. It was argued by them that Sections 73 and 74 of the Contract Act were also breached as
damages by way of penalty, which are not a genuine pre-estimate of loss, have been laid down by the
Impugned Regulation, as it is admitted that no loss but only inconvenience has been caused to the
consumers. It was further argued, based on the amended Preamble to the TRAI Act, that the
Impugned Regulation only protects the interest of the consumers of the telecom sector, whereas a
balancing of the interests of service providers and consumers is required by the said Preamble.
Further, orderly growth of the telecom sector would also be directly affected if arbitrary penalties of
this nature were to be inflicted upon service providers. It was also argued that having made the
financial disincentive for a breach of the 2% benchmark even higher just one day before the
Impugned Regulation, the Impugned Regulations were wholly uncalled for. Further, one hand of
TRAI does not seem to know what the other hand is doing. A few days after the Impugned
Regulation, the TRAI’s own technical paper makes it clear that the TRAI has itself admitted that call
drops are caused in many ways, most of which are not attributable to service providers. That being
so, the impugned amendment is wholly arbitrary in that the assumption on which it is based,
namely, that the service provider is at fault every time a call drop takes place, is wholly unfounded,
as has been found by TRAI itself in the said technical paper.
12. The learned Counsel have also argued, based on Section 402 of the Companies Act, 1956 and
Section 27(d) of the Competition Act, 2002, that no power is given by the TRAI Act for interference
with licence conditions, which amount to a contract between licensor and licensee. They also
referred to Section 11(1)(b)(ii) which uses the familiar “notwithstanding anything contained in the
terms and conditions of the licence ……….” which is missing from the other provisions of the TRAI
Act. The argument, therefore, being that when the licence conditions/contract itself makes it clear
that a no fault liability for call drops cannot be made, the impugned amendment would follow the
terms and conditions of the licence between licensor and licensee and would be bad as a result.Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

13. Finally, it was argued that Section 11(4) of the Act was breached inasmuch as the transparency
mandated by the Act in the framing of the regulations was wholly missing as no reason whatsoever
has been given for negativing the objections of the service providers and laying down a no fault strict
penal liability on them.
14. The learned Attorney General, appearing on behalf of the Telecom Regulatory Authority of India,
has countered these submissions and sought to defend the High Court judgment. According to the
learned Attorney General, it is first necessary to see the Statement of Objects and Reasons of the
Telecom Regulatory Authority of India Act, 1997. Paragraph one of the said statement was referred
to in order to emphasize that the National Telecom Policy of 1994 provided for the meeting of
customer’s demands at a reasonable price, and the promotion of consumer interest by ensuring fair
competition. When read in light of the Statement of Objects and Reasons, it is clear that the
Impugned Regulation has been made bearing this object in mind. According to the learned Attorney
General, Section 36 of the Act has to be read in a wide and expansive manner, as has been done in
BSNL’s judgment, and when so read, it is clear that the Impugned Regulation conforms to Section
11(1)(b)(i) and (v) and is otherwise not ultra vires the Act. Countering the submission as to
arbitrariness and unreasonableness of the Impugned Regulation, he argued that the said Regulation
was really framed keeping the small man in mind, and told us that 96% of consumers are pre-paid
customers who recharge their account balance for an average of Rs.10/- at a time. The Impugned
Regulation seeks to provide some solace to these persons for dropped calls. He further argued that
members of the appellants have made huge profits from the aforesaid business and have pumped in
very little funds for infrastructural development. He referred to funds pumped in in China, for
example, which were ten times more than the funds in this country. He, therefore, submitted that if
the revenues of service providers were computed at a rough average of approximately Rs.96,560
crores per annum, payments that they would have to make, according to a calculation made by him,
for call drops under the Impugned Regulation, would amount to a sum of roughly only Rs.280
crores per annum, which would not therefore really affect the appellants’ right to carry on business.
He further argued that the Impugned Regulation is only an experimental measure and was liable to
be revisited in six months. This being so, the appellants should not have rushed to court, but allowed
the regulation to work, and if there were any shortfalls, these could be ironed out in the working of
the Impugned Regulation. He countered the argument made on behalf of the appellants that it is not
possible, technically speaking, to arrive at the cause of a call drop, and read manuals from some of
the service providers to show that this was, in fact, possible, and that the reason for the call drop
could ultimately be pinpointed to the service providers when they are at fault. He also refuted the
submission made on behalf of the appellants that there were four broad reasons for call drops, three
of which cannot be laid at the appellants door. He referred to the technical paper dated 13.11.2015,
in particular, and to various other documents, to show that call drops occurred basically due to two
reasons alone – those that can be said to be due to the fault of the service providers, and those that
can be said to be due to the fault of the consumers. In particular, he referred to and relied upon a
statistic showing that an average of 36.9% of call drops take place owing to the fault of the consumer
– the rest take place because of the fault of the service provider, or the fact that it has not pumped in
enough funds for technical advancements to prevent the cause for such call drops. According to him,
with the provision of equipment, including boosters, call drops need not take place inside buildings
with thick walls and/or lifts. In any case, the number of call drops that take place owing to suchCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

reasons is itself minimal. According to him, therefore, the Impugned Regulation should be read
down so that service providers are made to pay only for faults attributable to them, which would
come to a rough figure of 63% of what is charged, for amounts payable to the consumers under the
Impugned Regulation. The learned Attorney General has assured us that, in point of fact, the
authorities will administer the Impugned Regulation in such a manner that service providers would
only be made liable to pay for call drops owing to their own fault. He further argued that three
documents, if read together, would make it clear that the Impugned Regulation cannot be said to be
manifestly arbitrary or unreasonable, and that the consultation paper dated 4.9.2015, the Impugned
Regulation dated 16.10.2015, and the technical paper dated 13.11.2015, should all be read together as
being part of one joint exercise to alleviate the small consumers’ inconvenience because of call
drops. He further went on to argue that it is not correct to say that TRAI has contradicted itself in
the technical paper of 13.11.2015, when compared to the Impugned Regulation, and stated that the
Quality of Service Regulation which allowed a 2% average per month for call drops should not be
confused with the Impugned Regulation. They are, according to him, a parallel set of regulations
which have to be read separately, both having been framed by TRAI, in order to protect consumer
interest. He also added that guess work is inherent in framing a regulation of the sort that is
impugned, and further stated that three call drops per day mitigated the rigour of having to pay for
more than 3 call drops per day, and that rupee one per call drop would really be payment or
recompense for call drops which take place because the consumer has to incur an extra charge to
connect with the person whose call dropped yet again and spend more money for the second call. He
also added that only the consumer who dials the call which has dropped is paid and not the
receiving consumer, thereby again mitigating the rigour of what could amount to a double payment
for one call. He cited a number of judgments to buttress the aforesaid submissions, stating that the
said judgments would show that the Court should not substitute its wisdom for that of the wisdom
of legislative policy, and that TRAI being an active trustee for the common good has framed this
regulation acting as such. He also refuted the submission that the licence conditions were illegally
modified by the Impugned Regulation, and stated that the Explanatory Memorandum to the
Impugned Regulation would show that the transparency required under Section 11(4) of the Act was
duly and faithfully observed by TRAI.
15. In rejoinder, learned senior counsel for the appellants stoutly resisted the factual statements
made by the learned Attorney General. They pointed out that the net debt of the various telecom
operators before us, as on 31.12.2015, ran into approximately Rs.3,80,000/- crores and that this was
because huge amounts had to be borrowed from banks in order to pay for both spectrum and
infrastructure. They were at pains to point out that though service providers in India contributed to
13% of the world’s telecommunication services, the revenue earned by them was only 2.7%, and even
this was fast decreasing. According to the learned counsel, they have covered over 500,000 villages
in India contributing to 6% of India’s GDP, thus being amongst the highest contributors in foreign
direct investment in this country in the last decade. They have also made the second large private
sector investment in infrastructure amounting to Rs. 800,000/- crores despite the return on
investment being only 1%. Contrary to what the learned Attorney General had to say, a vast number
of towers have been set up – more than two lac sites in the last 15 months alone. When viewed with
the gigantic net debt and return on investment, the figure of gross revenue given by the learned
Attorney General is said to be a highly misleading figure. Also, the comparison with infrastructureCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

investment in China is wholly misplaced inasmuch as the Chinese Government has unlimited funds
to pour into its telecom companies, over 70% of their share capital being held by the Government.
Spectrum allocation to Chinese operators is at almost no cost, whereas in India, thousands of crores
of rupees have to be spent as spectrum is now auctioned to the highest bidder. Also, the revenue of
the top three Chinese telecom operators is more than six times the revenue of the top three Indian
operators. In addition, it was argued that the facts and figures reeled out by the learned Attorney
General are not based on the record of the case, and, in any case, have very little connection with the
challenge to the Impugned Regulation in the present case.
16. We have also heard learned counsel appearing for various consumer groups. They supported the
arguments of the learned Attorney General and went on to state that since the focus of the TRAI Act
and the Impugned Regulation was for the small and impoverished consumers in India, this Court
would be loathe to strike down the Impugned Regulation. They further argued that the doctrine of
public trust would apply to the Impugned Regulation, as the Regulation was part of the overall social
responsibility that the regulator TRAI has cast upon the service providers in favour of consumers.
They also cited a few judgments dealing with the vires of subordinate legislation and with
transparency in the context of the Impugned Regulation.
17. Having heard learned counsel for all the parties, it is first necessary to set out the relevant
provisions of the Telecom Regulatory Authority of India Act, 1997.
18. The Statement of Objects and Reasons for the said Act is as follows:
“1. In the context of the National Telecom Policy, 1994, which amongst other things,
stresses on achieving the universal service, bringing the quality of telecom services to
world standards, provisions of wide range of services to meet the customers demand
at reasonable price, and participation of the companies registered in India in the area
of basic as well as value added telecom services as also making arrangements for
protection and promotion of consumer interest and ensuring fair competition, there
is a felt need to separate regulatory functions from service providing functions which
will be in keeping with the general trend in the world. In the multi-operator situation
arising out of opening of basic as well as value added services in which private
operator will be competing with Government operators, there is a pressing need for
an independent telecom regulatory body for regulation of telecom services for orderly
and healthy growth of telecommunication infrastructure apart from protection of
consumer interest.” The Preamble of the Telecom Regulatory Authority Act of 1997
reads as under:
“Preamble - An act to provide for the establishment of the Telecom Regulatory
Authority of India to regulate the telecommunication services, and for matters
connected therewith or incidental thereto.” Section 11(n) read as under:-
Functions of Authority – (1) Notwithstanding anything contained in the Indian
Telegraph Act, 1885, the functions of the Authority shall be to –Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

(n) settle disputes between service providers”
19. In 2000, the Act was amended. By the Amended Act, the adjudicatory function of the TRAI was
taken away from it and was vested in an Appellate Tribunal. The relevant provisions of the Act as
amended in 2000 are as follows:-
“Preamble- An Act to provide for the establishment of the Telecom Regulatory
Authority of India and the Telecom Disputes Settlement and Appellate Tribunal to
regulate the telecommunication services, adjudicate disputes, dispose of appeals and
to protect the interests of service providers and consumers of the telecom sector, to
promote and ensure orderly growth of the telecom sector and for matters connected
therewith or incidental thereto”
11. Functions of Authority. (1) Notwithstanding anything contained in the Indian
Telegraph Act, 1885, the functions of the Authority shall be to-   
(b) discharge the following functions, namely:- 
(i) ensure compliance of terms and conditions of license;
(ii) notwithstanding anything contained in the terms and conditions of the license
granted before the commencement of the Telecom Regulatory Authority
(Amendment) Ordinance,2000, fix the terms and conditions of inter-
connectivity between the service providers;
xx
(v) lay down the standards of quality of service to be provided by the service  providers and ensure
the quality of service and conduct the periodical survey of such service provided by the service
providers so as to protect interest of the consumers of telecommunication services; 
11. (4) The Authority shall ensure transparency while exercising its powers and discharging its
functions.
12. Powers of Authority to call for information, conduct investigations, etc. — (4) The Authority shall
have the power to issue such directions to service providers as it may consider necessary for proper
functioning by service providers.
13. Power of Authority to issue directions.—The Authority may, for the discharge of its functions
under sub-section (1) of Section 11, issue such directions from time to time to the service providers,
as it may consider necessary:Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

Provided that no direction under sub-section (4) of Section 12 or under this section
shall be issued except on the matters specified in clause (b) of sub-section (1) of
Section 11.
14. Establishment of Appellate Tribunal.—The Central Government shall, by notification, establish
an Appellate Tribunal to be known as the Telecom Disputes Settlement and Appellate Tribunal to—
(a) adjudicate any dispute—
(i) between a licensor and a licensee;
(ii) between two or more service providers;
(iii) between a service provider and a group of consumers:
Provided that nothing in this clause shall apply in respect of matters relating to— (A)
the monopolistic trade practice, restrictive trade practice and unfair trade practice
which are subject to the jurisdiction of the Monopolies and Restrictive Trade
Practices Commission established under sub-section (1) of Section 5 of the
Monopolies and Restrictive Trade Practices Act, 1969 (54 of 1969);
(B) the complaint of an individual consumer maintainable before a Consumer
Disputes Redressal Forum or a Consumer Disputes Redressal Commission or the
National Consumer Redressal Commission established under Section 9 of the
Consumer Protection Act, 1986 (68 of 1986);
(C) the dispute between telegraph authority and any other person referred to in
sub-section (1) of Section 7-B of the Indian Telegraph Act, 1885 (13 of 1885);
(b) hear and dispose of appeals against any direction, decision or order of the
Authority under this Act.
15. Civil Court not to have jurisdiction.—No civil court shall have jurisdiction to entertain any suit or
proceeding in respect of any matter which the Appellate Tribunal is empowered by or under this Act
to determine and no injunction shall be granted by any court or other authority in respect of any
action taken or to be taken in pursuance of any power conferred by or under this Act.
25. Power of Central Government to issue directions.—(1) The Central Government may, from time
to time, issue to the Authority such directions as it may think necessary in the interest of the
sovereignty and integrity of India, the security of the State, friendly relations with foreign States,
public order, decency or morality.
(2) Without prejudice to the foregoing provisions, the Authority shall, in exercise of its powers or the
performance of its functions, be bound by such directions on questions of policy as the CentralCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

Government may give in writing to it from time to time:
Provided that the Authority shall, as far as practicable, be given an opportunity to
express its views before any direction is given under this sub-section.
(3) The decision of the Central Government whether a question is one of policy or not
shall be final.
29. Penalty for contravention of directions of Authority.—If a person violates directions of the
Authority, such person shall be punishable with fine which may extend to one lakh rupees and in
case of second or subsequent offence with fine which may extend to two lakh rupees and in the case
of continuing contravention with additional fine which may extend to two lakh rupees for every day
during which the default continues.
36. Power to make regulations.—(1) The Authority may, by notification, make regulations consistent
with this Act and the rules made thereunder to carry out the purposes of this Act.
(2) In particular, and without prejudice to the generality of the foregoing power, such regulations
may provide for all or any of the following matters, namely :—
(a) the times and places of meetings of the Authority and the procedure to be followed at such
meetings under sub-section (1) of Section 8, including quorum necessary for the transaction of
business;
(b) the transaction of business at the meetings of the Authority under sub- section (4) of Section 8;
(c)  ******
(d) matters in respect of which register is to be maintained by the Authority under sub-clause (vii) of
clause (b) of sub-section (1) of Section 11;
(e) levy of fee and lay down such other requirements on fulfillment of which a copy of register may
be obtained under sub-clause (viii) of clause
(b) of sub-section (1) of Section 11;
(f) levy of fees and other charges under clause (c) of sub-section (1) of Section 11.
37. Rules and regulations to be laid before Parliament.—Every rule and every regulations made
under this Act shall be paid, as soon as may be after it is made, before each House of Parliament,
while it is in session, for a total period of thirty days which may be comprised in one session or in
tow or more successive sessions, and if, before the expiry of the session immediately following the
session or the successive sessions aforesaid, both Houses agree in making any modification in the
rule or regulation or both Houses agree that the rule or regulation should not be made, the rule orCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

regulation shall thereafter have effect only in such modified form or be of no effect, as the case may
be; so, however, that any such modification or annulment shall be without prejudice to the validity
of anything previously done under that rule or regulation.” Parameters of Judicial Review of
Subordinate Legislation
20. In State of Tamil Nadu v. P. Krishnamoorthy, (2006) 4 SCC 517, this Court after adverting to the
relevant case law on the subject, laid down the parameters of judicial review of subordinate
legislation generally thus:-
“There is a presumption in favour of constitutionality or validity of a subordinate
legislation and the burden is upon him who attacks it to show that it is invalid. It is
also well recognised that a subordinate legislation can be challenged under any of the
following grounds:
(a) Lack of legislative competence to make the subordinate legislation.
(b) Violation of fundamental rights guaranteed under the Constitution of India.
(c) Violation of any provision of the Constitution of India.
(d) Failure to conform to the statute under which it is made or exceeding the limits of
authority conferred by the enabling Act.
(e) Repugnancy to the laws of the land, that is, any enactment.
(f) Manifest arbitrariness/unreasonableness (to an extent where the court might well
say that the legislature never intended to give authority to make such rules).
The court considering the validity of a subordinate legislation, will have to consider the nature,
object and scheme of the enabling Act, and also the area over which power has been delegated under
the Act and then decide whether the subordinate legislation conforms to the parent statute. Where a
rule is directly inconsistent with a mandatory provision of the statute, then, of course, the task of the
court is simple and easy.
But where the contention is that the inconsistency or non-conformity of the rule is not with
reference to any specific provision of the enabling Act, but with the object and scheme of the parent
Act, the court should proceed with caution before declaring invalidity.” [paras 15 and 16]
21. In the present case, the appellants have raised pleas under
paragraphs (b), (d) and (f) of paragraph 15 of the said judgment. We now move on to
consider their arguments.
Ultra viresCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

22. The power to make the Impugned Regulation is traceable to Section 36(1) of the Telecom
Regulatory Authority of India Act, 1997. This Court in BSNL v. Telecom Regulatory Authority of
India, (2014) 3 SCC 222, after analyzing the aforesaid provision in the backdrop of the Act held as
follows:-
“We may now advert to Section 36. Under sub-section (1) thereof TRAI can make
regulations to carry out the purposes of the TRAI Act specified in various provisions
of the TRAI Act including Sections 11, 12 and 13. The exercise of power under Section
36(1) is hedged with the condition that the regulations must be consistent with the
TRAI Act and the rules made thereunder. There is no other restriction on the power
of TRAI to make regulations. In terms of Section 37, the regulations are required to
be laid before Parliament which can either approve, modify or annul the same.
Section 36(2), which begins with the words “without prejudice to the generality of the
power under sub-section (1)” specifies various topics on which regulations can be
made by TRAI. Three of these topics relate to meetings of TRAI, the procedure to be
followed at such meetings, the transaction of business at the meetings and the
register to be maintained by TRAI. The remaining two topics specified in clauses (e)
and (f) of Section 36(2) are directly referable to Sections 11(1)(b)(viii) and 11(1)(c).
These are substantive functions of TRAI. However, there is nothing in the language of
Section 36(2) from which it can be inferred that the provisions contained therein
control the exercise of power by TRAI under Section 36(1) or that Section 36(2)
restricts the scope of Section 36(1)… Before parting with this aspect of the matter, we
may notice Sections 33 and 37. A reading of the plain language of Section 33 makes it
clear that TRAI can, by general or special order, delegate to any member or officer of
TRAI or any other person such of its powers and functions under the TRAI Act except
the power to settle disputes under Chapter IV or make regulations under Section 36.
This means that the power to make regulations under Section 36 is non-delegable.
The reason for excluding Section 36 from the purview of Section 33 is simple. The
power under Section 36 is legislative as opposed to administrative. By virtue of
Section 37, the regulations made under the TRAI Act are placed on a par with the
rules which can be framed by the Central Government under Section 35 and being in
the nature of subordinate legislations, the rules and regulations have to be laid before
both the Houses of Parliament which can annul or modify the same. Thus, the
regulations framed by TRAI can be made ineffective or modified by Parliament and
by no other body.
In view of the above discussion and the propositions laid down in the judgments
referred to in the preceding paragraphs, we hold that the power vested in TRAI under
Section 36(1) to make regulations is wide and pervasive. The exercise of this power is
only subject to the provisions of the TRAI Act and the rules framed under Section 35
thereof. There is no other limitation on the exercise of power by TRAI under Section
36(1). It is not controlled or limited by Section 36(2) or Sections 11, 12 and 13.” [paras
89, 98 – 100]Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

23. It will thus be seen that though the Regulation making power under the said Act is wide and
pervasive, and is not trammeled by the provisions of Section 11, 12(4) and 13, it is a power that is
non-delegable and, therefore, legislative in nature. The exercise of this power is hedged in with the
condition that it must be exercised consistently with the Act and the Rules thereunder in order to
carry out the purposes of the Act. Since the regulation making power has first to be consistent with
the Act, it is necessary that it not be inconsistent with Section 11 of the Act, and in particular Section
11(1)(b) thereof. This is for the reason that the functions of the Authority are laid down by this
Section, and that the Impugned Regulation itself refers to Section 11(1)(b)(i) and (v) as the source of
power under which the Impugned Regulation has been framed. Since ensuring compliance with the
terms and conditions of licence is the first thing that has been argued on behalf of the respondents,
it is important to advert to the provisions of the licence between the service provider and the
consumer. As has been mentioned above, two very important clauses of this licence refer to (i) the
power to modify the licence conditions which is contained in clause 5 and (ii) the ensuring by the
licensee that the quality of service shall be as prescribed by the licensor or TRAI by clause 28
thereof. Under clause 5, the licensor reserves the right to modify the terms and conditions of the
licence if in the opinion of the licensor it is necessary or expedient so to do in public interest or in
the interest of security of the State or for the proper conduct of telegraphs. It may be stated that no
modification of the licence has in fact been attempted or has taken place in the facts of the present
case. Therefore clause 5 need not detain us further. Clause 28 reads as follows:
“28. Quality of Performance:
28.1 The LICENSEE shall ensure the Quality of Service (QoS) as prescribed by the
LICENSOR or TRAI. The LICENSEE shall adhere to such QoS standards and provide
timely information as required therein.
28.2 The LICENSEE shall be responsible for:-
i) Maintaining the performance and quality of service standards.
ii) Maintaining the MTTR (Mean Time To Restore) within the specified limits of the
quality of service.
iii) The LICENSEE will keep a record of number of faults and rectification reports in
respect of the service, which will be produced before the LICENSOR/TRAI as and
when and in whatever form desired.
28.3 The LICENSEE shall be responsive to the complaints lodged by his subscribers. The Licensee
shall rectify the anomalies within the MTTR specified and maintain the history sheets for each
installation, statistics and analysis on the overall maintenance status.
28.4 The LICENSOR or TRAI may carry out performance tests on LICENSEE’s network and also
evaluate Quality of Service parameters in LICENSEE’s network prior to grant of permission for
commercial launch of the service after successful completion of interconnection tests and/or at anyCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

time during the currency of the License to ascertain that the network meets the specified standards
on Quality of Service (QoS). The LICENSEE shall provide ingress and other support including
instruments, equipments etc., for such tests.
28.5 The LICENSEE shall enforce and ensure QOS, as prescribed by the LICENSOR/TRAI, from the
INFRASTRUCTURE PROVIDER(s) with whom it may enter into agreement/contract for
leasing/hiring/buying or any such instrument for provision of infrastructure or provision of
bandwidth. The responsibility of ensuring QOS shall be that of LICENSEE.”
24. Under clause 28 it is a condition that the licensee shall ensure the quality of service as prescribed
by the licensor or TRAI, and shall adhere to such standards as are provided. Another important
thing to notice is that under clause 28.2 the licensee has to keep a record of the number of faults and
rectification reports in respect of its service, which will be produced before the licensor/TRAI as and
when desired. This being the case, it is clear that the Impugned Regulation cannot be said to fall
under Section 11(1)(b)(i) at all inasmuch as it does not seek to enforce any term or condition of the
licence between the service provider and the consumer. Coming to sub-para (v) of Section 11(1)(b),
the Impugned Regulation would again have no reference to the said paragraph, inasmuch as it does
not lay down any standard of quality of service to be provided by the service provider. In order that
clause (v) be attracted, not only do standards of quality of service to be provided by the service
providers have to be laid down, but standards have to be adhered to by the service providers so as to
protect the interests of the consumers. We find that the Impugned Regulation is not referable to
Section 11(1)(b)(i) and (v) of the Act inasmuch as it has not been made to ensure compliance of the
terms and conditions of the licence nor has it been made to lay down any standard of quality of
service that needs compliance. This being the case, the Impugned Regulation is de hors Section 11
but cannot be said to be inconsistent with Section 11 of the Act. This Court has categorically held in
the BSNL judgment that the power under Section 36 is not trammeled by Section 11. This being so,
the Impugned Regulation cannot be said to be inconsistent with Section 11 of the Act. However,
what has also to be seen is whether the said Regulation carries out the purpose of the Act which, as
has been pointed out hereinabove, under the amended Preamble to the Act, is to protect the
interests of service providers as well as consumers of the telecom sector so as to promote and ensure
orderly growth of the telecom sector. Under Section 36, not only does the Authority have to make
regulations consistent with the Act and the Rules made thereunder, but it also has to carry out the
purposes of the Act, as can be discerned from the Preamble to the Act. If, far from carrying out the
purposes of the Act, a Regulation is made contrary to such purposes, such Regulation cannot be said
to be consistent with the Act, for it must be consistent with both the letter of the Act and the
purposes for which the Act has been enacted. In attempting to protect the interest of the consumer
of the telecom sector at the cost of the interest of a service provider who complies with the leeway of
an average of 2% of call drops per month given to it by another Regulation, framed under Section
11(1)(b)(v), the balance that is sought to be achieved by the Act for the orderly growth of the telecom
sector has been violated. Therefore we hold that the Impugned Regulation does not carry out the
purpose of the Act and must be held to be ultra vires the Act on this score.
Violation of Fundamental RightsCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

25. We have already seen that one of the tests for challenging the constitutionality of subordinate
legislation is that subordinate legislation should not be manifestly arbitrary. Also, it is settled law
that subordinate legislation can be challenged on any of the grounds available for challenge against
plenary legislation – [See: Indian Express Newspapers v. Union of India, (1985) 1 SCC 641 at Para
75].
26. The test of “manifest arbitrariness” is well explained in two judgments of this Court. In Khoday
Distilleries Ltd. v. State of Karnataka, (1996) 10 SCC 304, this Court held:
“It is next submitted before us that the amended Rules are arbitrary, unreasonable
and cause undue hardship and, therefore, violate Article 14 of the Constitution.
Although the protection of Article 19(1)(g) may not be available to the appellants, the
rules must, undoubtedly, satisfy the test of Article 14, which is a guarantee against
arbitrary action. However, one must bear in mind that what is being challenged here
under Article 14 is not executive action but delegated legislation. The tests of
arbitrary action which apply to executive actions do not necessarily apply to
delegated legislation. In order that delegated legislation can be struck down, such
legislation must be manifestly arbitrary; a law which could not be reasonably
expected to emanate from an authority delegated with the lawmaking power. In the
case of Indian Express Newspapers (Bombay) Pvt. Ltd. and Ors. v. Union of India
and Ors. [(1985) 1 SCC 641 : 1985 SCC (Tax) 121 : (1985) 2 SCR 287], this Court said
that a piece of subordinate legislation does not carry the same degree of immunity
which is enjoyed by a statute passed by a competent legislature. A subordinate
legislation may be questioned under Article 14 on the ground that it is unreasonable;
"unreasonable not in the sense of not being reasonable, but in the sense that it is
manifestly arbitrary". Drawing a comparison between the law in England and in
India, the Court further observed that in England the Judges would say, "Parliament
never intended the authority to make such Rules; they are unreasonable and ultra
vires". In India, arbitrariness is not a separate ground since it will come within the
embargo of Article 14 of the Constitution. But subordinate legislation must be so
arbitrary that it could not be said to be in conformity with the statute or that it
offends Article 14 of the Constitution.” [para 13]
27. Also, in Sharma Transport v. Government of Andhra Pradesh, (2002) 2 SCC 188, this Court
held:
“… The tests of arbitrary action applicable to executive action do not necessarily apply
to delegated legislation. In order to strike down a delegated legislation as arbitrary it
has to be established that there is manifest arbitrariness. In order to be described as
arbitrary, it must be shown that it was not reasonable and manifestly arbitrary. The
expression "arbitrarily" means: in an unreasonable manner, as fixed or done
capriciously or at pleasure, without adequate determining principle, not founded in
the nature of things, non-rational, not done or acting according to reason orCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

judgment, depending on the will alone. …”
28. When we come to Article 19(1)(g) of the Constitution, the tests for challenge to plenary
legislation are well settled. First and foremost, a sea change took place with the 11-Judge Bench
judgment in Rustom Cavasjee Cooper (Banks Nationalisation) v. Union of India, (1970) 1 SCC 248,
in which the impact of State action upon fundamental rights was stated thus:
“We have carefully considered the weighty pronouncements of the eminent Judges
who gave shape to the concept that the extent of protection of important guarantees,
such as the liberty of person, and right to property, depends upon the form and object
of the State action, and not upon its direct operation upon the individual's freedom.
But it is not the object of the authority making the law impairing the right of a citizen,
nor the form of action taken that determines the protection he can claim: it is the
effect of the law and of the action upon the right which attracts the jurisdiction of the
Court to grant relief. If this be the true view and we think it is, in determining the
impact of State action upon constitutional guarantees which are fundamental, it
follows that the extent of protection against impairment of a fundamental right is
determined not by the object of the Legislature nor by the form of the action, but by
its direct operation upon the individual's rights.” [para 49]
29. Under Article 19(6) of the Constitution, the State has to conform to two separate and
independent tests if it is to pass constitutional muster – the restriction on the appellants’
fundamental right must first be a reasonable restriction, and secondly, it should also be in the
interest of the general public. Perhaps the best exposition of what the expression “reasonable
restriction” connotes was laid down in Chintaman Rao v. State of Madhya Pradesh, 1950 SCR 759,
as follows:-
“The phrase "reasonable restriction" connotes that the limitation imposed on a
person in enjoyment of the right should not be arbitrary or of an excessive nature,
beyond what is required in the interests of the public. The word "reasonable" implies
intelligent care and deliberation, that is, the choice of a course which reason dictates.
Legislation which arbitrarily or excessively invades the right cannot be said to contain
the quality of reasonableness and unless it strikes a proper balance between the
freedom guaranteed in article 19(1)(g) and the social control permitted by clause (6)
of article 19, it must be held to be wanting in that quality.” [at p.763]
30. It is interesting to note that the original Constitution, while enumerating various rights under
Article 19(1), when it referred to the right of freedom of speech in Article 19(1)(a), laid down in
Article 19(2) that any law abridging the right to freedom of speech could only pass constitutional
muster if it related to any of the subjects laid down in clause (2). What was conspicuous by its
absence was the phrase “reasonable restriction”, which was only brought in by the first amendment
to the Constitution.Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

31. Similarly, the first amendment to the Constitution also amended Article 19(6), with which we are
directly concerned, to provide for a State monopoly, which would not have to be tested on the
ground of reasonable restrictions. Therefore, the first amendment to the Constitution of India has
made it clear that reasonable restrictions, added in Article 19(2) and subtracted from Article 19(6)
(insofar as State monopolies are concerned), point to the fact that this test is a test separate and
distinct from the test of the law being in the interest of the general public. Why we are at pains to
point this out is because the learned Attorney General’s argument focused primarily on the
Impugned Regulation being in the public interest. He referred to Delhi Science Forum v. Union of
India, (1996) 2 SCC 405, for the proposition that TRAI, as an active trustee, has framed this
Regulation for the common good. While accepting that TRAI may have done so, yet it is important
to note that, apart from the common good in the form of consumer interest, the Regulation must
also pass a separate and independent test of not being manifestly arbitrary or unreasonable. We
cannot forget that when viewed from the angle of manifest arbitrariness or reasonable restriction,
sounding in Article 14 and Article 19(1)(g) respectively, the Regulation must, in order to pass
constitutional muster, be as a result of intelligent care and deliberation, that is, the choice of a
course which reason dictates. Any arbitrary invasion of a fundamental right cannot be said to
contain this quality. A proper balance between the freedoms guaranteed and the control permitted
under Article 19(6) must be struck in all cases before the impugned law can be said to be a
reasonable restriction in the public interest.
32. We find that it is not necessary to go in detail into many of the submissions made on either side
as to the technical difficulties which may or may not lead to call drops. This is for the reason that
even if we accept the demarcation of the cause of call drops to be what the learned Attorney General
says it is, the Impugned Regulation must be held to be manifestly arbitrary and an unreasonable
restriction on the appellants’ fundamental rights to carry on business. According to the learned
Attorney General, the cause for call drops is twofold – one owing to the fault of the consumer, and
the other owing to the fault of the service provider. And, for this dichotomy, he has referred to the
technical paper dated 13.11.2015, which shows that an average of 36.9% can be call drops owing to
the fault of the consumer. If this is so, the Impugned Regulation’s very basis is destroyed: the
Regulation is based on the fact that the service provider is 100% at fault. This becomes clear from a
reading of the text of the said Regulation together with the Explanatory Memorandum set out
hereinabove. This being the case, it is clear that the service provider is made to pay for call drops
that may not be attributable to his fault, and the consumer receives compensation for a call drop
that may be attributable to the fault of the consumer himself, and that makes the Impugned
Regulation a regulation framed without intelligent care and deliberation.
33. But it was said that the aforesaid Regulation should be read down to mean that it would apply
only when the fault is that of the service provider. We are afraid that such a course is not open to us
in law, for it is well settled that the doctrine of reading down would apply only when general words
used in a statute or regulation can be confined in a particular manner so as not to infringe a
constitutional right. This was best exemplified in one of the earliest judgments dealing with the
doctrine of reading down, namely the judgment of the Federal Court in In Re: Hindu Women's
Rights to Property Act, 1937, AIR 1941 FC 72. In that judgment, the word “property” in Section 3 of
the Hindu Women’s Rights to Property Act was read down so as not to include agricultural land,Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

which would be outside the central legislature’s powers under the Government of India Act, 1935.
This is done because it is presumed that the legislature did not intend to transgress constitutional
limitations. While so reading down the word “property”, the Federal Court held:
“If the restriction of the general words to purposes within the power of the
Legislature would be to leave an Act with nothing or next to nothing in it, or an Act
different in kind, and not merely in degree, from an Act in which the general words
were given the wider meaning, then it is plain that the Act as a whole must be held
invalid, because in such circumstances it is impossible to assert with any confidence
that the Legislature intended the general words which it has used to be construed
only in the narrower sense: Owners of SS. Kalibia v. Wilson (1910) 11 CLR 689,
Vacuum Oil Company Ltd. v. State of Queensland (1934) 51 CLR 677, R. v.
Commonwealth Court of Conciliation and Arbitration (1910) 11 CLR 1 and British
Imperial Oil Co. Ltd. v. Federal Commissioner of Taxation (1925) 35 CLR 422.”
34. This judgment was followed by a Constitution Bench of this Court in Delhi Transport Corpn. v.
D.T.C. Mazdoor Congress, 1991 Supp (1) SCC 600. In that case, a question arose as to whether a
particular regulation which conferred power on an authority to terminate the services of a
permanent and confirmed employee by issuing a notice terminating his services, or by making
payment in lieu of such notice without assigning any reasons and without any opportunity of
hearing to the employee, could be said to be violative of the appellants’ fundamental rights. Four of
the learned Judges who heard the case, the Chief Justice alone dissenting on this aspect, decided
that the regulation cannot be read down, and must, therefore, be held to be unconstitutional. In the
lead judgment on this aspect by Sawant,J., this Court stated:
“It is thus clear that the doctrine of reading down or of recasting the statute can be
applied in limited situations. It is essentially used, firstly, for saving a statute from
being struck down on account of its unconstitutionality. It is an extension of the
principle that when two interpretations are possible — one rendering it constitutional
and the other making it unconstitutional, the former should be preferred. The
unconstitutionality may spring from either the incompetence of the legislature to
enact the statute or from its violation of any of the provisions of the Constitution. The
second situation which summons its aid is where the provisions of the statute are
vague and ambiguous and it is possible to gather the intentions of the legislature
from the object of the statute, the context in which the provision occurs and the
purpose for which it is made. However, when the provision is cast in a definite and
unambiguous language and its intention is clear, it is not permissible either to mend
or bend it even if such recasting is in accord with good reason and conscience. In
such circumstances, it is not possible for the court to remake the statute. Its only duty
is to strike it down and leave it to the legislature if it so desires, to amend it. What is
further, if the remaking of the statute by the courts is to lead to its distortion that
course is to be scrupulously avoided. One of the situations further where the doctrine
can never be called into play is where the statute requires extensive additions and
deletions. Not only it is no part of the court's duty to undertake such exercise, but it isCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

beyond its jurisdiction to do so.” [para 255]
35. Applying the aforesaid test to the Impugned Regulation, it is clear that the language of the
Regulation is definite and unambiguous – every service provider has to credit the account of the
calling consumer by one rupee for every single call drop which occurs within its network. The
Explanatory Memorandum to the aforesaid Regulation further makes it clear, in paragraph 19
thereof, that the Authority has come to the conclusion that call drops are instances of deficiency in
service delivery on the part of the service provider. It is thus unambiguously clear that the Impugned
Regulation is based on the fact that the service provider is alone at fault and must pay for that fault.
In these circumstances, to read a proviso into the Regulation that it will not apply to consumers who
are at fault themselves is not to restrict general words to a particular meaning, but to add something
to the provision which does not exist, which would be nothing short of the court itself legislating.
For this reason, it is not possible to accept the learned Attorney General’s contention that the
Impugned Regulation be read down in the manner suggested by him.
36. The other string to the bow of this argument is that the Impugned Regulation would be worked
in such a manner that the service provider would be liable to pay only when it is found that it is at
fault. This again falls foul of constitutional doctrine. In Collector of Customs v. Nathella Sampathu
Chetty, (1962) 3 SCR 786, this Court held:
“The possibility of abuse of a statute otherwise valid does not impart to it any element
of invalidity. The converse must also follow that a statute which is otherwise invalid
as being unreasonable cannot be saved by its being administered in a reasonable
manner. The constitutional validity of the statute would have to be determined on the
basis of its provisions and on the ambit of its operation as reasonably construed. If so
judged it passes the test of reasonableness, possibility of the powers conferred being
improperly used is no ground for pronouncing the law itself invalid and similarly if
the law properly interpreted and tested in the light of the requirements set out in Part
III of the Constitution does not pass the test it cannot be pronounced valid merely
because it is administered in a manner which might not conflict with the
constitutional requirements.” [at pp.825 – 826]
37. This statement of the law applies on all fours to the facts of the present case, and is a complete
answer to the Attorney General’s contention that the Impugned Regulation would be administered
so that the service provider would be liable under it only when it is at fault for call drops.
38. The learned Attorney General has argued that the Impugned Regulation accords with the
Statement of Objects and Reasons of the TRAI Act, 1997. As has been pointed out by us, the original
Act was amended in the year 2000, in which its Preamble was substituted. The substitution
indicates that the policy of the 1997 Act, as amended by the 2000 Act, is to protect the interests of
service providers and consumers of the telecom sector together, so that the orderly growth of the
telecom sector is ensured thereby. We are afraid that the orderly growth of the telecom sector
cannot be ensured or promoted by a manifestly arbitrary or unreasonable regulation which makes a
service provider pay a penalty without it being necessarily at fault.Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

39. We were then told that the Impugned Regulation was framed keeping in mind the small
consumer, that is, a person who has a pre-paid SIM Card with an average balance of Rs.10/- at a
time, and that the Regulation goes a long way to compensate such person. The motive for the
Regulation may well be what the Attorney General says it is, but that does not make it immune from
Article 14 and the twin tests of Article 19(6). The Authority framing the Regulation must ensure that
its means are as pure as its ends – only then will regulations made by it pass constitutional muster.
40. We were also told that huge profits were made by the service providers, and that the amount
they would have to pay would not even be a flea bite compared to the profits they make, viewed in
the background that they are not pouring in enough funds for infrastructure development. This was
stoutly resisted by the appellants, pointing out that the so called huge profits earned is misleading,
as the figure of net debt is far greater than that of revenue earned, and that huge sums had been
pumped in for infrastructure development. Without going into the factual controversy thus
presented, there are two answers to this submission. First and foremost, whether the service
providers make profits or losses cannot be said to be relevant for determining whether the
Impugned Regulation is otherwise arbitrary or unreasonable. If the Attorney General were correct,
then the converse proposition would also be true – namely, that even if all the service providers
were suffering huge losses, then such regulation, since it makes them fork out crores of rupees and
add to their losses, would have to be held to be unconstitutional. Assuming that six out of the twelve
service providers make profits, and the other six make losses, the Impugned Regulation cannot be
held to be constitutional so far as those making a profit, and unconstitutional qua those making
losses. And what if the same service provider makes a profit in one year and a loss in the succeeding
year. Is the Impugned Regulation unconstitutional in the first year and constitutional in the
succeeding year? Obviously not. Secondly, it is always open to the Authority, with the vast powers
given to it under the TRAI Act, to ensure, in a reasonable and non-arbitrary manner, that service
providers provide the necessary funds for infrastructure development and deal with them so as to
protect the interest of the consumer. Consequently, this submission is also without substance.
41. The learned Attorney General strongly relied upon a passage from a Constitution Bench
judgment in Prag Ice & Oil Mills v. Union of India, (1978) 3 SCC 459, to the following effect:-
“The Parliament having entrusted the fixation of prices to the expert judgment of the
Government, it would be wrong for this Court, as was done by common consent
in Premier Automobiles [20 L Ed 2d 312] to examine each and every minute detail
pertaining to the Governmental decision. The Government, as was said in Permian
Basin Area Rate cases, is entitled to make pragmatic adjustments which may be
called for by particular circumstances and the price control can be declared
unconstitutional only if it is patently arbitrary, discriminatory or demonstrably
irrelevant to the policy which the legislature is free to adopt. The interest of the
producer and the investor is only one of the variables in the “constitutional calculus
of reasonableness” and courts ought not to interfere so long as the exercise of
Governmental power to fix fair prices is broadly within a “zone of reasonableness”. If
we were to embark upon an examination of the disparate contentions raised before us
on behalf of the contending parties, we have no doubt that we shall have exceededCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

our narrow and circumscribed authority.
Before closing, we would like to mention that the petitioners rushed to this Court too
precipitately on the heels of the Price Control Order. Thereby they deprived
themselves of an opportunity to show that in actual fact, the Order causes them
irreparable prejudice. Instead, they were driven through their ill-thought haste to rely
on speculative hypothesis in order to buttress their grievance that their right to
property and the right to do trade was gone or was substantially affected. A little
more patience, which could have been utilised to observe how the experiment
functioned, might have paid better dividends.” (para 71).
42. The observations made in the aforesaid judgment are wholly distinguishable. In the present
case, if the appellants had not gone to court when they did, the Regulation would have affected their
fundamental rights on and from 1.1.2016. Further, they would have been denied interim and/or
other relief on the ground that they have not moved the Court without undue delay. Also, to say that
the Impugned Regulation is only an experimental measure that would last in its present form for six
months is again wholly incorrect. The Impugned Regulation begins to tick on and from 1.1.2016, in
which case three rupees per day, for call drops made not exclusively owing to the fault of the service
provider, would have to be paid. Further, it is only the Explanatory Memorandum which says that
the Authority may review the aforesaid Regulation after working of the said Regulation after six
months, and that too only if found to be necessary. Obviously, this would not mean that the
aforesaid Regulation would necessarily be reviewed at all, even after six months. We are, therefore,
unable to subscribe to the aforesaid submission.
43. We now come to a very important part of the submissions made on behalf of the appellants. The
appellants have strongly contended that a 2% allowance of call drops on the basis of averaging call
drops per month has been allowed to them by the Quality of Service Regulations already referred to
hereinabove. This would amount to the Authority penalizing the service provider even when it
complies with another regulation made under the same source of power, and for this reason alone,
the Impugned Regulation must be held to be bad as being manifestly arbitrary. The learned
Attorney General refuted this submission in two ways. First, he argued that Quality of Service
Regulations and regulations made to benefit consumers must be viewed separately, as they are
distinct regulations in parallel streams. He also argued that the 2% average allowance for call drops
is different and distinct from paying compensation for call drops inasmuch as, conceivably, in a
given set of facts, call drops may take place extensively in a given sector but not in other sectors so
that an average of 2% per month is yet maintained, but the service provider would be penalized as it
has not been able to maintain a 3% standard laid down qua deficiency of service in individual towers
leading to call drops. However, the persons who suffer in the sector in which call drops are many
and frequent would then have no protection. We are afraid neither of these reasons avails the
Authority. First and foremost, the 2009 Quality of Service Regulation is made under Section
11(1)(b)(v), which is the very Section which is claimed to be the source of the Impugned Regulation.
Secondly, both regulations deal with the same subject matter – namely, call drops, and both
regulations are made in the interest of the consumer. If an average of 2% per month is allowable to
every service provider for call drops, and it is the admitted position that all service providers beforeCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

us, short of Aircel, and that too in a very small way, have complied with the standard, penalizing a
service provider who complies with another Regulation framed with reference to the same source of
power would itself be manifestly arbitrary and would render the Regulation to be at odds with both
Articles 14 and 19(1)(g).
44. In this regard, it would be of assistance to note what this Court held in The Lord Krishna Sugar
Mills Ltd. and Anr. v. Union of India and Anr., [1960] 1 SCR 39:
“It is, however, contended that though one can look at the surrounding
circumstances, it is not open to the Court to examine other laws on the subject, unless
those laws be incorporated by reference. In our opinion, this is a fallacious argument.
The Court in judging the reasonableness of a law, will necessarily see, not only the
surrounding circumstances but all contemporaneous legislation passed as part of a
single scheme. The reasonableness of the restriction and not of the law has to be
found out, and if restriction is under one law but countervailing advantages are
created by another law passed as part of the same legislative plan, the Court should
not refuse to take that other law into account.” [at para 56]
45. In view of the aforesaid, it is clear that the Quality of Service Regulations and the Consumer
Regulations must be read together as part of a single scheme in order to test the reasonableness
thereof. The countervailing advantage to service providers by way of the allowance of 2% average
call drops per month, which has been granted under the 2009 Quality of Service Regulations, could
not have been ignored by the Impugned Regulation so as to affect the fundamental rights of the
appellants, and having been so ignored, would render the Impugned Regulation manifestly arbitrary
and unreasonable.
46. Secondly, no facts have been shown to us which would indicate that a particular area would be
filled with call drops thanks to the fault on the part of the service providers in which consumers
would be severely inconvenienced. The mere ipse dixit of the learned Attorney General, without any
facts being pleaded to this effect, cannot possibly make an unconstitutional regulation
constitutional. We, therefore, hold that a strict penal liability laid down on the erroneous basis that
the fault is entirely with the service provider is manifestly arbitrary and unreasonable. Also, the
payment of such penalty to a consumer who may himself be at fault, and which gives an
unjustifiable windfall to such consumer, is also manifestly arbitrary and unreasonable. In the
circumstances, it is not necessary to go into the appellants’ submissions that call drops take place
because of four reasons, three of which are not attributable to the fault of the service provider, which
includes sealing and shutting down towers by municipal authorities over upon they have no control,
or whether they are attributable to only two causes, as suggested by the Attorney General, being
network related causes or user related causes. Equally, it is not necessary to determine finally as to
whether the reason for a call drop can technologically be found out and whether it is a network
related reason or a user related reason.
47. In Shree Bhagwati Steel Rolling Mills v. Commissioner of Central Excise, (2016) 3 SCC 643,
Rules 96 –ZO, ZP and ZQ of the Central Excise Rules, 1994, which consisted inter alia of penaltyCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

provisions, were struck down by this Court. One of the reasons for striking down the aforesaid Rules
is that a mandatory penalty became leviable despite the fact that fault on the part of assessee could
not be established. This Court held:
“It is also correct in saying that there may be circumstances of force majeure which
may prevent a bona fide assessee from paying the duty in time, and on certain given
factual circumstances, despite there being no fault on the part of the assessee in
making the deposit of duty in time, a mandatory penalty of an equivalent amount of
duty would be compulsorily leviable and recoverable from such assessee. This would
be extremely arbitrary and violative of Article 14 for this reason as well. Further, we
agree with the High Court in stating that this would also be violative of the appellant's
fundamental rights under Article 19(1)(g) and would not be saved by Article 19(6),
being an unreasonable restriction on the right to carry on trade or business. Clearly
the levy of penalty in these cases of a mandatory nature for even one day's delay,
which may be beyond the control of the assessee, would be arbitrary and excessive.”
[at para 35]
48. In the present case, also, a mandatory penalty is payable by the service provider for call drops
that may take place which are not due to its fault, and may be due to the fault of the recipient of the
penalty, which is violative of Articles 14 and 19(1)(g).
49. The reason given in the Explanatory Memorandum for compensating the consumer is that the
compensation given is only notional. The very notion that only notional compensation is awarded, is
also entirely without basis. A consumer may well suffer a call drop after 3 or 4 seconds in a voice
call. Whereas the consumer is charged only 4 or 5 paise for such dropped call, the service provider
has to pay a sum of rupee one to the said consumer. This cannot be called notional at all. It is also
not clear as to why the Authority decided to limit compensation to three call drops per day or how it
arrived at the figure of Re.1 to compensate inconvenience caused to the consumer. It is equally
unclear as to why the calling party alone is provided compensation because, according to the
Explanatory Memorandum, inconvenience is suffered due to the interruption of a call, and such
inconvenience is suffered both by the calling party and the person who receives the call. The
receiving party can legitimately claim that his inconvenience when a call drops, is as great as that of
the calling party. And the receiving party may need to make the second call, in which case he
receives nothing, and the calling party receives Re.1 for the additional expense made by the receiving
party. All this betrays a complete lack of intelligent care and deliberation in framing such a
regulation by the Authority, rendering the Impugned Regulation manifestly arbitrary and
unreasonable.
50. However, the learned Attorney General referred to a recent judgment being DSC-Viacon
Ventures Pvt. Ltd. (Now Known as DSC Ventures Pvt. Ltd) v. Lal Manohar Pandey and Ors., (Civil
Appeal Nos. 6781-6782 of 2015, decided on August 27, 2015). He referred to paragraph 21 in order
to show that a certain amount of guess work is unavoidable in matters of this nature.Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

51. The context in which this statement occurs in paragraph 21 is very different from the present
context. This Court held that a toll can only be collected for maintaining a road. The patches in
which the road is not properly maintained should reduce proportionately the amount of toll that is
to be paid. As there was no data in that case to indicate the extent of road length and the resultant
inconvenience to users of the road, a certain amount of guess work was said to be unavoidable. The
present is a case in which we are not informed as to how rupee one is computed, how three call
drops per day has been arrived at, or why the calling party alone is provided compensation. These
matters go out of mere guess work, and into the realm of unreasonableness, as obviously, as has
been held by us, there was no intelligent care and deliberation before any of these parameters have
been fixed.
52. We have already seen that the Impugned Regulation is dated 16.10.2015, which was to come into
force only on 1.1.2016. We have been shown a technical paper issued by the same Authority on
13.11.2015 i.e. a few days after the Impugned Regulation, in which the Authority has itself
recognised that 36.9% of call drops take place because of the fault at the consumer’s end. Instead of
having a relook at the problem in the light of the said technical paper, the Authority has gone ahead
with the Impugned Regulation, which states that the said Regulation has been brought into force
because of deficiency of service in service providers leading to call drops. The very basis of this
statement contained in the Explanatory Memorandum to the Impugned Regulation is found by the
self-same Authority to be incorrect only a few days after publishing the Impugned Regulation. This
itself shows the manifest arbitrariness on the part of the TRAI, which has not bothered to have a
relook into the said problem. For all the aforesaid reasons, we find that the Impugned Regulation is
manifestly arbitrary and therefore violative of Article 14, and is an unreasonable restriction on the
right of the appellants’ fundamental right under Article 19(1)(g) to carry on business, and is
therefore struck down as such.
53. Viewed at from a slightly different angle it is clear that if an individual consumer were to go to
the consumer forum for compensation for call drops, he would have to prove that the call drop took
place due to the fault of the service provider. He would further have to prove that he has suffered a
monetary loss for which he has to be compensated, which the Explanatory Memorandum itself says
is impossible to compute. Thus, the Impugned Regulation completely avoids the adjudicatory
process, and legislatively lays down a penal consequence to a service provider for a call drop taking
place without the consumer being able to prove that he is not himself responsible for such call drop
and without proof of any actual monetary loss. Whereas individual consumers, either before the
Consumer Forum, or in a dispute as a group with service providers before the TRAI, would fail in an
action to recover compensation for call drops, yet a statutory penalty is laid down, applicable
legislatively, and without any adjudication. This again makes the Impugned Regulation manifestly
arbitrary and unreasonable.
54. We have seen that the 2000 Amendment has taken away adjudicatory functions from the TRAI,
leaving it with administrative and legislative functions. By Section 14 of the Act, adjudicatory
functions have been vested in an Appellate Tribunal, where disputes between a group of consumers
and the service providers are to be adjudicated by the Appellate Tribunal. In stark contrast, under
the scheme of the Electricity Act, 2003, the Central Electricity Regulatory Commission and theCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

various State Electricity Regulatory Commissions have to discharge legislative, administrative, and
quasi-judicial functions. This is clear on a reading of Section 79(1)(f) and Section 86(1)(f) of the
Electricity Act, which are set out hereinbelow:-
“Section 79. Functions of Central Commission: --- (1) The Central Commission shall
discharge the following functions, namely:-
(f) to adjudicate upon disputes involving generating companies or transmission
licensee in regard to matters connected with clauses (a) to
(d) above and to refer any dispute for arbitration;
Section 86. Functions of State Commission: --- (1) The State Commission shall discharge the
following functions, namely: -
(f) adjudicate upon the disputes between the licensees, and generating companies
and to refer any dispute for arbitration.”
55. Secondly, as part of the adjudicatory process, compensation can be paid to an affected person if a
licensee fails to meet standards prescribed without prejudice to any penalty which may be imposed
or prosecution which may be initiated. This takes place under Section 57 of the said Act, which reads
as under:-
“Section 57. Consumer Protection: Standards of performance of licensee: (1) The
Appropriate Commission may, after consultation with the licensees and persons
likely to be affected, specify standards of performance of a licensee or a class of
licensees.
(2) If a licensee fails to meet the standards specified under sub-section (1), without
prejudice to any penalty which may be imposed or prosecution be initiated, he shall
be liable to pay such compensation to the person affected as may be determined by
the Appropriate Commission: Provided that before determination of compensation,
the concerned licensee shall be given a reasonable opportunity of being heard.
(3) The compensation determined under sub-section (2) shall be paid by the
concerned licensee within ninety days of such determination.”
56. Obviously, when such compensation is to be paid to a person who is affected by breach of a
standard of quality required under the Act, such compensation can only be for actual loss suffered,
and only as a result of fault of the service provider being established before a quasi judicial Tribunal.
This may be notwithstanding the fact that the service provider otherwise meets the average of 2%
call drops per month allowed to him by the 2009 Quality of Service Regulation. This is for the
reason that once fault and actual loss suffered are established before a quasi judicial Tribunal, it
would not be open to plead, on the facts of an individual case, that an overall standard ofCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

performance has been met. For this reason also, a legislatively pre determined penalty, without fault
or loss being established by evidence before a quasi judicial authority, and where the cause of a call
drop may be because of the consumer himself, renders the Impugned Regulation manifestly
arbitrary and unreasonable.
Modification of licence condition by Impugned Regulation
57. The appellants have also argued that the Impugned Regulation seeks to modify the licence
conditions, and the licence conditions being a contract between the service provider and the
consumer, such conditions can be modified only where the statute contains language by which an
Authority is empowered to disregard an agreement between the parties. It will be seen that Section
11(1)(b)(ii), which has been set out hereinabove, expressly contains such language and therefore
states that terms and conditions of interconnectivity between the service providers may be fixed
notwithstanding anything contained in the terms and conditions of the licence granted before the
commencement of the TRAI Amendment Act, 2000.
58. The same kind of language is contained in Section 402(d) of the Companies Act, 1956, which
reads as follows:-
“Section 402. POWERS OF TRIBUNAL ON APPLICATION UNDER SECTION 397
OR 398.
Without prejudice to the generality of the powers of the Tribunal under section 397
or 398, any order under either section may provide for –
(d) the termination, setting aside or modification of any agreement, howsoever
arrived at, between the company on the one hand, and any of the following persons,
on the other, namely :
(i) the managing director,
(ii) any other director,
(iii) and (iv) [***]
(v) the manager, upon such terms and conditions as may, in the opinion of the
Tribunal be just and equitable in all the circumstances of the case.”
59. The said Section is now contained in Section 242(2)(e) of the Companies Act, 2013.
“242. Powers of the Tribunal.
(2) Without prejudice to the generality of the powers under sub-section (1), an order under that
sub-section may provide for—Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

(e) the termination, setting aside or modification, of any agreement, howsoever arrived at, between
the company and the managing director, any other director or manager, upon such terms and
conditions as may, in the opinion of the Tribunal, be just and equitable in the circumstances of the
case.”
60. We were also referred to Section 27(d) of the Competition Act, 2002, in this behalf which reads
as follows:
“27. Orders by Commission after inquiry into agreements or abuse of dominant
position. Where after inquiry the Commission finds that any agreement referred to in
section 3 or action of an enterprise in a dominant position, is in contravention of
section 3 or section 4, as the case may be, it may pass all or any of the following
orders, namely:—
(d) direct that the agreements shall stand modified to the extent and in the manner as
may be specified in the order by the Commission;.”
61. In Union of India v. Assn. of Unified Telecom Service Providers of India, (2011)10 SCC 543, this
Court held:
“A Constitution Bench of this Court in State of Punjab v. Devans Modern Breweries
Ltd. [(2004) 11 SCC 26] relying on Har Shankar case [(1975) 1 SCC 737] and Panna
Lal v. State of Rajasthan [(1975) 2 SCC 633] has held in para 121 at p. 106 that
issuance of liquor licence constitutes a contract between the parties. Thus, once a
licence is issued under the proviso to sub-section (1) of Section 4 of the Telegraph
Act, the licence becomes a contract between the licensor and the licensee.” (para 40).
62. Having regard to the above, it is clear that the licence conditions, which are a contract between
the service providers and consumers, have been amended to the former’s disadvantage by making
the service provider pay a penalty for call drops despite there being no fault which can be traceable
exclusively to the service provider, and despite the service provider maintaining the necessary
standard of quality required of it – namely, adhering to the limit of an average of 2% of call drops
per month. We have already seen that condition 28 of the licence requires the licensee to ensure that
the quality of service standards, as prescribed by TRAI, are adhered to, and that the Impugned
Regulation does not lay down quality of service standards. This being so, it is clear that the laying
down of a penalty de hors condition 28, which, as we have seen, also requires establishing of fault of
the service provider when it does not conform to a quality of service standard laid down by TRAI,
would amount to interference with the licence conditions of the service providers without authority
of law. On this ground also, therefore, the Impugned Regulation deserves to be struck down.
Transparency
63. Section 11(4) of the Act requires that the Authority shall ensure transparency while exercising its
powers and discharging its functions. “Transparency” has not been defined anywhere in the Act.Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

However, we find, in a later Parliamentary Enactment, namely, the Airports Economic Regulatory
Authority of India Act, 2008, that Section 13 deals with the functions of the Airports Economic
Regulatory Authority, (which is an Authority which has legislative and administrative functions).
“Transparency” is defined, by sub-section (4), as follows:-
“THE AIRPORTS ECONOMIC REGULATORY AUTHORITY OF INDIA ACT, 2008
13. Functions of Authority.
(4) The Authority shall ensure transparency while exercising its powers and discharging its
functions, inter alia,—
(a) by holding due consultations with all stake-holders with the airport;
(b) by allowing all stake-holders to make their submissions to the authority; and
(c) by making all decisions of the authority fully documented and explained.”
64. This definition of “transparency” provides a good working test of ‘transparency’ referred to in
Section 11(4) of the TRAI Act.
65. In fact, a judgment of the Court of Appeal in England, being Regina v. North and East Devon
Health Authority, Ex parte Coughlan, [2001] QB 213, puts the meaning of “consultation” rather well
as follows:-
“It is common ground that, whether or not consultation of interested parties and the
public is a legal requirement, if it is embarked upon it must be carried out properly.
To be proper, consultation must be undertaken at a time when proposals are still at a
formative stage; it must include sufficient reasons for particular proposals to allow
those consulted to give intelligent consideration and an intelligent response;
adequate time must be given for this purpose; and the product of consultation must
be conscientiously taken into account when the ultimate decision is taken.”
66. No doubt in the facts of the present case, the Authority did hold due consultations with all
stakeholders and did allow all stakeholders to make their submissions to the Authority. However, we
find no discussion or reasoning dealing with the arguments put forward by the service providers,
that call drops take place for a variety of reasons, some of which are beyond the control of the
service provider and are because of the consumer himself. Consequently, we find that the conclusion
that service providers are alone to blame and are consequently deficient in service when it comes to
call drops is not a conclusion which a reasonable person can reasonably arrive at. We are cognizant
of the fact that ordinarily legislative functions do not require that natural justice be followed.
However, it has been recognised in some of the judgments dealing with this aspect that natural
justice need not be followed except where the statute so provides.Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

67. In Union of India v. Cynamide India Ltd., (1987) 2 SCC 720, this Court held:
“The second observation we wish to make is, legislative action, plenary or
subordinate, is not subject to rules of natural justice. In the case of Parliamentary
legislation, the proposition is self-evident. In the case of subordinate legislation, it
may happen that Parliament may itself provide for a notice and for a hearing — there
are several instances of the legislature requiring the subordinate legislating authority
to give public notice and a public hearing before say, for example, levying a municipal
rate — in which case the substantial non-observance of the statutorily prescribed
mode of observing natural justice may have the effect of invalidating the subordinate
legislation. The right here given to rate payers or others is in the nature of a
concession which is not to detract from the character of the activity as legislative and
not quasi-judicial. But, where the legislature has not chosen to provide for any notice
or hearing, no one can insist upon it and it will not be permissible to read natural
justice into such legislative activity.” [para 5]
68. Similarly, in M.R.F. Ltd. v. Inspector Kerala Govt., (1998) 8 SCC 227, this Court held:
“Learned counsel for the appellants contended that before raising the national and
festival holidays from their original number under the Parent Act to the number of
days contemplated by the Amending Act, the industries or their representatives
should have been given an opportunity of a hearing. This argument is wholly
untenable. The principles of natural justice cannot be imported in the matter of
legislative action. If the legislature in exercise of its plenary power under Article 245
of the Constitution, proceeds to enact a law, those who would be affected by that law
cannot legally raise a grievance that before the law was made, they should have been
given an opportunity of a hearing.
This principle may, in limited cases, be invoked in the case of subordinate legislation
specially where the main legislation itself lays down that before the subordinate
legislation is made, a public notice shall be given and objections shall be invited as is
usually the case, for example, in the making of municipal bye-laws. But the principle
of natural justice, including the right of hearing, cannot be invoked in the making of
law either by Parliament or by the State Legislature.” [paras 23 – 24]
69. The question of transparency raises a more fundamental question, namely, that of openness in
governance. We find that the Right to Information Act of 2005 has gone a long way to strengthen
democracy by requiring that the Government be transparent in its actions, so that an informed
citizenry is able then to contain corruption, and hold Governments and their instrumentalities
accountable to the people of India. The preamble to the said Act, in ringing terms, states:-
“WHEREAS the Constitution of India has established democratic Republic;Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

AND WHEREAS democracy requires an informed citizenry and transparency of
information which are vital to its functioning and also to contain corruption and to
hold Governments and their instrumentalities accountable to the governed;
AND WHEREAS revelation of information in actual practice is likely to conflict with
other public interests including efficient operations of the Governments, optimum
use of limited fiscal resources and the preservation of confidentiality of sensitive
information;
AND WHEREAS it is necessary to harmonise these conflicting interests while
preserving the paramountcy of the democratic ideal;
Now, THEREFORE, it is expedient to provide for furnishing certain information to
citizens who desire to have it.”
70. We find that under Section 4(1) every public authority is not only to maintain all its records duly
catalogued and indexed but is to publish, within 120 days from the enactment of the said Act, the
procedure followed by it in its decision making process, which includes channels of supervision and
accountability. Section 4(1)(b)(iii) states:
“4. Obligations of public authorities. —(1) Every public authority shall—
(b) publish within one hundred and twenty days from the enactment of this Act,—
(iii) the procedure followed in the decision making process, including channels of
supervision and accountability.”
71. Under Section 8, there is no obligation to give to any citizen information disclosure of which
would prejudicially affect the sovereignty and integrity of India, the security of the State etc. Subject,
therefore, to well-defined exceptions, openness in governance is now a legislatively established fact.
In fact, in Chief Information Commissioner v. State of Manipur, (2011) 15 SCC page 1, this Court had
occasion to deal with the aforesaid Act in the following terms:
“Before dealing with the controversy in this case, let us consider the object and
purpose of the Act and the evolving mosaic of jurisprudential thinking which virtually
led to its enactment in 2005.
As its Preamble shows, the Act was enacted to promote transparency and
accountability in the working of every public authority in order to strengthen the core
constitutional values of a democratic republic. It is clear that Parliament enacted the
said Act keeping in mind the rights of an informed citizenry in which transparency of
information is vital in curbing corruption and making the Government and its
instrumentalities accountable. The Act is meant to harmonise the conflicting
interests of the Government to preserve the confidentiality of sensitive informationCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

with the right of citizens to know the functioning of the governmental process in such
a way as to preserve the paramountcy of the democratic ideal. The Preamble would
obviously show that the Act is based on the concept of an open society.
On the emerging concept of an “open Government”, about more than three decades
ago, the Constitution Bench of this Court in State of U.P. v. Raj Narain [(1975) 4 SCC
428 : AIR 1975 SC 865] speaking through Mathew, J. held: (SCC p. 453, para 74) “74.
… The people of this country have a right to know every public act, everything that is
done in a public way, by their public functionaries. They are entitled to know the
particulars of every public transaction in all its bearing.The right to know, which is
derived from the concept of freedom of speech, though not absolute, is a factor which
should make one wary, when secrecy is claimed for transactions which can, at any
rate, have no repercussion on public security. [Ed.: See New York Times Co. v. United
States, 29 L Ed 2d 822 : 403 US 713 (1971).] To cover with veil of secrecy, the
common routine business, is not in the interest of the public. Such secrecy can
seldom be legitimately desired.” (AIR p. 884, para 74) (emphasis supplied) Another
Constitution Bench in S.P. Gupta v. Union of India [1981 Supp SCC 87 : AIR 1982 SC
149] relying on the ratio in Raj Narain [(1975) 4 SCC 428:
AIR 1975 SC 865] held: (S.P. Gupta case [1981 Supp SCC 87 : AIR 1982 SC 149] , SCC
p. 275, para 67) “67. … The concept of an open Government is the direct emanation
from the right to know which seems to be implicit in the right of free speech and
expression guaranteed under Article 19(1)(a). Therefore, disclosure of information in
regard to the functioning of Government must be the rule and secrecy an exception
justified only where the strictest requirement of public interest so demands. The
approach of the court must be to attenuate the area of secrecy as much as possible
consistently with the requirement of public interest, bearing in mind all the time that
disclosure also serves an important aspect of public interest.” (AIR p. 234, para 66)
(emphasis supplied) It is, therefore, clear from the ratio in the above decisions of the
Constitution Bench of this Court that the right to information, which is basically
founded on the right to know, is an intrinsic part of the fundamental right to free
speech and expression guaranteed under Article 19(1)(a) of the Constitution. The said
Act was, thus, enacted to consolidate the fundamental right of free speech.
In Ministry of Information & Broadcasting, Govt. of India v. Cricket Assn. of
Bengal [(1995) 2 SCC 161] this Court also held that right to acquire information and
to disseminate it is an intrinsic component of freedom of speech and expression. (See
p. 213, para 43 of the Report.) Again in Reliance Petrochemicals Ltd. v. Indian
Express Newspapers Bombay (P) Ltd. [(1988) 4 SCC 592] this Court recognised that
the right to information is a fundamental right under Article 21 of the Constitution.
This Court speaking through Sabyasachi Mukharji, J., as His Lordship then was, held: (SCC p. 613,
para 34) “34. … We must remember that the people at large have a right to know in order to be able
to take part in a participatory development in the industrial life and democracy. Right to know is aCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

basic right which citizens of a free country aspire in the broader horizon of the right to live in this
age in our land under Article 21 of our Constitution. That right has reached new dimensions and
urgency. That right puts greater responsibility upon those who take upon themselves the
responsibility to inform.” In People's Union for Civil Liberties v. Union of India [(2004) 2 SCC 476]
this Court reiterated, relying on the aforesaid judgments, that right to information is a facet of the
right to freedom of “speech and expression” as contained in Article 19(1)(a) of the Constitution of
India and also held that right to information is definitely a fundamental right. In coming to this
conclusion, this Court traced the origin of the said right from the Universal Declaration of Human
Rights, 1948 and also Article 19 of the International Covenant on Civil and Political Rights, which
was ratified by India in 1978. This Court also found a similar enunciation of principle in the
Declaration of European Convention for the Protection of Human Rights (1950) and found that the
spirit of the Universal Declaration of 1948 is echoed in Article 19(1)(a) of the Constitution. (See
paras 45, 46 and 47 at pp. 494-95 of the Report.) The exercise of judicial discretion in favour of free
speech is not only peculiar to our jurisprudence, the same is a part of the jurisprudence in all the
countries which are governed by the rule of law with an independent judiciary. In this connection, if
we may quote what Lord Acton said in one of his speeches:
“Everything secret degenerates, even the administration of justice; nothing is safe
that does not show how it can bear discussion and publicity.” It is, therefore, clear
that a society which adopts openness as a value of overarching significance not only
permits its citizens a wide range of freedom of expression, it also goes further in
actually opening up the deliberative process of the Government itself to the sunlight
of public scrutiny.
Frankfurter, J. also opined:
“The ultimate foundation of a free society is the binding tie of cohesive sentiment.
Such a sentiment is fostered by all those agencies of the mind and spirit which may
serve to gather up the traditions of a people, transmit them from generation to
generation, and thereby create that continuity of a treasured common life which
constitutes a civilisation. ‘We live by symbols.’ The flag is the symbol of our national
unity, transcending all internal differences, however large, within the framework of
the Constitution.” Actually the concept of active liberty, which is structured on free
speech, means sharing of a nation's sovereign authority among its people.
Sovereignty involves the legitimacy of governmental action. And a sharing of
sovereign authority suggests intimate correlation between the functioning of the
Government and common man's knowledge of such functioning. (Active Liberty by
Stephen Breyer, p. 15.)” [paras 5 – 16]
72. In another context also this Court has emphasized the importance of openness of governance. In
Global Energy Ltd. V. Central Electricity Regulatory Commission, (2009) 15 SCC 570 at 589, this
Court stated:Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

“The law sometimes can be written in such a subjective manner that it affects the
efficiency and transparent function of the Government. If the statute provides for
pointless discretion to agency, it is in essence demolishing the accountability strand
within the administrative process as the agency is not under obligation from an
objective norm, which can enforce accountability in decision-making process. All
law-making, be it in the context of delegated legislation or primary legislation, has to
conform to the fundamental tenets of transparency and openness on one hand and
responsiveness and accountability on the other. These are fundamental tenets
flowing from due process requirement under Article 21, equal protection clause
embodied in Article 14 and fundamental freedoms clause ingrained under Article 19.
A modern deliberative democracy cannot function without these attributes.”
73. We have been referred to the U.S. Administrative Procedure Act, Section 553 of which states as
follows:-
5 USCA § 553 § 553 - Rule making
(a)This section applies, according to the provisions thereof, except to the extent that
there is involved— (1) a military or foreign affairs function of the United States; or (2)
a matter relating to agency management or personnel or to public property, loans,
grants, benefits, or contracts.
(b)General notice of proposed rule making shall be published in the Federal Register, unless persons
subject thereto are named and either personally served or otherwise have actual notice thereof in
accordance with law. The notice shall include— (1) a statement of the time, place, and nature of
public rule making proceedings;
(2) reference to the legal authority under which the rule is proposed; and (3) either the terms or
substance of the proposed rule or a description of the subjects and issues involved.
Except when notice or hearing is required by statute, this subsection does not apply— (A) to
interpretative rules, general statements of policy, or rules of agency organization, procedure, or
practice; or (B) when the agency for good cause finds (and incorporates the finding and a brief
statement of reasons therefor in the rules issued) that notice and public procedure thereon are
impracticable, unnecessary, or contrary to the public interest.
(c) After notice required by this section, the agency shall give interested persons an opportunity to
participate in the rule making through submission of written data, views, or arguments with or
without opportunity for oral presentation. After consideration of the relevant matter presented, the
agency shall incorporate in the rules adopted a concise general statement of their basis and purpose.
When rules are required by statute to be made on the record after opportunity for an agency
hearing, sections 556  and 557 of this title apply instead of this subsection.Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

(d)The required publication or service of a substantive rule shall be made not less than 30 days
before its effective date, except— (1) a substantive rule which grants or recognizes an exemption or
relieves a restriction;
(2) interpretative rules and statements of policy; or (3) as otherwise provided by the agency for good
cause found and published with the rule.
(e) Each agency shall give an interested person the right to petition for the issuance, amendment, or
repeal of a rule.” In Corpus Juris Secundum (March 2016 Update) it is stated:
“Under the informal rulemaking requirements of the Federal Administrative
Procedure Act, after a federal administrative agency considers the relevant matter
presented, it must incorporate in the rules adopted a concise general statement of
their basis and purpose. The purpose of the requirement is to enable courts, which
have the duty to exercise review, to be aware of the legal and factual framework
underlying the agency’s actions. The requirement is a means of holding an agency
accountable for administering the laws in a responsible manner, free from arbitrary
conduct. The statement is not intended to be an abstract explanation addressed to an
imaginary complaint but is intended, rather, to respond in a reasoned manner to the
comments received, to explain how the agency resolved the significant problems
raised by the comments, and to show how that resolution led the agency to the
ultimate rule. The statement must identify what major issues of policy were
ventilated and why the agency reacted to them as it did and should enable a
reviewing court to ascertain such matters. The statement must respond to the major
comments received, explain how they affected the regulation, and, where an old
regulation is being replaced, explain why the old regulation is no longer desirable.
Agencies have a good deal of discretion in expressing the basis of a rule. The
requirement is not to be interpreted over literally, but it should not be stretched into
a mandate to refer to all specific issues raised in the comments on the proposed
regulations. Although an agency must genuinely consider comments it receives from
interested parties, there is no requirement that an agency discuss in great detail all
comments, especially those which are frivolous or repetitive. Although the agency
need not address every comment received, it must respond in a reasoned manner to
those that raise significant problems, to explain how the agency resolved any
significant problems raised by the comments, and to show how that resolution led the
agency to the ultimate rule. Conclusory statements will not fulfill the administrative
agency’s duty to incorporate in adopted rules a concise general statement of their
basis and purpose. The agency must articulate a satisfactory explanation for its
action, including a rational connection between the facts it found and the choices it
made. Under some circumstance, agencies must identify specific studies or data that
they rely upon in arriving at their decision to adopt a rule.Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

Regulations which lack a statement of basis and purpose may be upheld if the basis
and purpose and obvious. Moreover, the failure of an agency to incorporate the
statement does not render a rule ineffective as to parties to litigation who had
knowledge of the rule.
Despite the statutory language mandating that the statement of basis of purposes be
“incorporate[d] in the rules adopted,” the statement of basis and purpose does not
have to be published at precisely the same moment as the rules. Rather, the rules and
statement need only be published close enough together in time so that there is no
doubt that the statement accompanies, rather than rationalizes, the rules.”
74. We find that, subject to certain well defined exceptions, it would be a healthy functioning of our
democracy if all subordinate legislation were to be “transparent" in the manner pointed out above.
Since it is beyond the scope of this judgment to deal with subordinate legislation generally, and in
particular with statutes which provide for rule making and regulation making without any added
requirement of transparency, we would exhort Parliament to take up this issue and frame a
legislation along the lines of the U.S. Administrative Procedure Act (with certain well defined
exceptions) by which all subordinate legislation is subject to a transparent process by which due
consultations with all stakeholders are held, and the rule or regulation making power is exercised
after due consideration of all stakeholders’ submissions, together with an explanatory memorandum
which broadly takes into account what they have said and the reasons for agreeing or disagreeing
with them. Not only would such legislation reduce arbitrariness in subordinate legislation making,
but it would also conduce to openness in governance. It would also ensure the redressal, partial or
otherwise, of grievances of the concerned stakeholders prior to the making of subordinate
legislation. This would obviate, in many cases, the need for persons to approach courts to strike
down subordinate legislation on the ground of such legislation being manifestly arbitrary or
unreasonable.
75. In the present case, we find that the High Court judgment is flawed for several reasons. The
judgment is not correct when it says that there can be no dispute that the Impugned Regulation has
been made to ensure quality of service extended to consumers by service providers. As has been
pointed out hereinabove, the Impugned Regulation does not lay down any quality of service – what
it does is to penalise service providers even though they conform to the 2% standard laid down by
the Quality of Service Regulations, 2009. In holding that the Impugned Regulation therefore
conforms to Section 11(1)(b)(v), the judgment is plainly incorrect. Similarly, the finding that
notional compensation is given, and that therefore no penalty is imposed, is also wrong and set
aside for the reasons given by us hereinabove. The finding that a transparent process was followed
by TRAI in making the Impugned Regulation is only partly correct. While it is true that all
stakeholders were consulted, but unfortunately nothing is disclosed as to why service providers were
incorrect when they said that call drops were due to various reasons, some of which cannot be said
to be because of the fault of the service provider. Indeed, the Regulation, in assuming that every call
drop is a deficiency of service on the part of the service provider, is plainly incorrect. Further, the
High Court judgment, when it speaks of the technical paper of 13.11.2015, seems to have mixed it up
with the consultation paper dated 4.9.2015 referred to in the Explanatory Memorandum to theCellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

Impugned Regulation. The judgment has entirely missed the fact that the technical paper of
13.11.2015 unequivocally states that the causes for call drops are many and are often beyond the
control of service providers and attributable to the extent of 36.9% to the consumers themselves.
The judgment is also incorrect when it says that 100% performance is not demanded from service
providers when call drops are made. We have already pointed out that the 2% standard has
admittedly been met by almost all the service providers, and this being so, even if the very first call
drop and all other subsequent call drops are made within the network of a service provider and are
within the parameters of 2%, yet the penal consequence of the amended regulation must follow. The
judgment is also incorrect in stating that the Impugned Regulation has attempted to balance the
interest of service providers by limiting call drops to be compensated to only three and by limiting
compensation to only the calling and not the receiving consumer. We have already pointed out that
a penalty that is imposed without any reason either as to the number of call drops made being three,
and only to the calling consumer, far from balancing the interest of consumers and service
providers, is manifestly arbitrary, not being based on any factual data or reason. We also find that
when the service provider argued that it was being penalised despite being within the tolerance limit
of 2%, the answer given by the High Court is disingenuous, to say the least, when the High Court
says that 2% is a quality parameter for the entire network as opposed to payment of compensation
to an individual consumer. We are unable to appreciate the aforesaid reasoning. As has been held by
us above, the two sets of Regulations have to be considered together when the Impugned Regulation
is being tested on the ground of violation of fundamental rights. Also, the High Court did not advert
to a large number of other submissions made by the appellants before them and/or answer them
correctly in law. As a result, therefore, we set aside the judgment of the High Court and allow these
appeals, declaring that the Impugned Regulation is ultra vires the TRAI Act and violative of the
appellant’s fundamental rights under Articles 14 and 19(1)(g) of the Constitution.
..............................J. (Kurian Joseph) ..............................J. (R.F. Nariman) New Delhi;
May 11, 2016.Cellular Operators Association Of ... vs Telecom Regulatory Authority Of India ... on 11 May, 2016

