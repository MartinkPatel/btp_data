Centre For Pil & Anr vs Union Of India & Anr on 3 March, 2011
Equivalent citations: AIR 2011 SUPREME COURT 1267, 2011 AIR SCW 1690,
2011 LAB. I. C. 2978, (2011) 1 KER LT 973, (2011) 3 MAD LJ 355, (2011) 2 SCT
590, (2011) 2 RECCRIR 491, (2011) 3 SERVLR 390, (2011) 3 SCALE 148, (2011)
1 SERVLJ 369, (2011) 2 GUJ LH 107, (2011) 1 LAB LN 654, (2011) 48 OCR 995,
2011 (4) SCC 1, (2011) 2 JCR 124 (SC), (2011) 3 ALL WC 2177, 2011 (3) KCCR
SN 193 (SC)
Author: S. H. Kapadia
Bench: Swatanter Kumar, K.S. Panicker Radhakrishnan, S. H. Kapadia
                                                                                       1
                                                            REPORTABLE
                  IN THE SUPREME COURT OF INDIA
                       CIVIL ORIGINAL JURISDICTION
                  WRIT PETITION (C) No. 348 OF 2010
Centre for PIL & Anr.                                       ... 
Petitioner(s)
        versus
Union of India & Anr.                                       ... 
Respondent(s)
                                     with
                       Writ Petition (C) No. 355 of 2010Centre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

                              J U D G M E N T
S. H. KAPADIA, CJI Int roduction
1. The two writ petitions filed in this Court under Article 32 of the Constitution of India give rise to a
substantial question of law and of public importance as to the legality of the appointment of Shri
P.J. Thomas (respondent No. 2 in W.P.(C) No. 348 of 2010) as Central Vigilance Commissioner
under Section 4(1) of the Central Vigilance Commission Act, 2003 ("2003 Act" for short).
2. Government is not accountable to the courts in respect of policy decisions. However, they are
accountable for the legality of such decisions. While deciding this case, we must keep in mind the
difference between legality and merit as also between judicial review and merit review. On 3rd
September, 2010, the High Powered Committee ("HPC" for short), duly constituted under the
proviso to Section 4(1) of the 2003 Act, had recommended the name of Shri P.J. Thomas for
appointment to the post of Central Vigilance Commissioner. The validity of this recommendation
falls for judicial scrutiny in this case. If a duty is cast under the proviso to Section 4(1) on the HPC to
recommend to the President the name of the selected candidate, the integrity of that decision
making process is got to ensure that the powers are exercised for the purposes and in the manner
envisaged by the said Act, otherwise such recommendation will have no existence in the eye of law.
Clarification
3. At the very outset we wish to clarify that in this case our judgment is strictly confined to the
legality of the recommendation dated 3rd September, 2010 and the appointment based thereon. As
of date, Shri P.J. Thomas is Accused No. 8 in criminal case CC 6 of 2003 pending in the Court of
Special Judge, Thiruvananthapuram with respect to the offences under Section 13(2) read with
Section 13(1)(d) of the Prevention of Corruption Act, 1988 and under Section 120B of the Indian
Penal Code ("IPC" for short) [hereinafter referred to as the "Palmolein case"]. According to the
petitioners herein, Shri P.J. Thomas allegedly has played a big part in the cover-up of the 2G
spectrum allocation which matter is subjudice. Therefore, we make it clear that we do not wish to
comment in this case on the pending cases and our judgment herein should be strictly understood to
be under judicial review on the legality of the appointment of respondent No. 2 and any reference in
our judgment to the Palmolein case should not be understood as our observations on merits of that
case.
Facts
4. Shri P.J. Thomas was appointed to the Indian Administrative Service (Kerala Cadre) 1973 batch
where he served in different capacities with the State Government including as Secretary,
Department of Food and Civil Supplies, State of Kerala in the year 1991. During that period itself,
the State of Kerala decided to import 30,000 MT of palmolein. The Chief Minister of Kerala, on 5th
October, 1991, wrote a letter to the Prime Minister stating that the State was intending to import
Palmolein oil and that necessary permission should be given by the concerned Ministries. On 6th
November, 1991, the Government of India issued a scheme for direct import of edible oil for PublicCentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

Distribution System (PDS) on the condition that an ESCROW account be opened and import
clearance be granted as per the rules. Respondent No. 2 wrote letters to the Secretary, Government
of India stating that against its earlier demand for import of 30,000 MT of Palmolein oil, the
present minimum need was 15,000 MT and the same was to meet the heavy ensuing demand during
the festivals of Christmas and Sankranti, in the middle of January, 1992, therefore, the State was
proposing to immediately import the said quantity of Palmolein on obtaining requisite permission.
The price for the same was fixed on 24th January, 1992, i.e., 56 days after the execution of the
agreement. The Kerala State Civil Supplies Corporation Ltd. was to act as an agent of the State
Government for import of Palmolein. The value of the Palmolein was to be paid to the suppliers only
in Indian rupees. Further, the terms governing the ESCROW account were to be as approved by the
Ministry of Finance. This letter contained various other stipulations as well. This was responded to
by the Joint Secretary, Government of India, Ministry of Civil Supplies and Public Distribution, New
Delhi vide letter dated 26th November, 1991 wherein it was stated that it had been decided to permit
the State to import 15,000 MT of Palmolein on the terms and conditions stipulated in the Ministry's
circular of even number dated 6th November, 1991.
It was specifically stated that the service charges up to a maximum of 15% in Indian rupees may be
paid. After some further correspondence, the order of the State of Kerala is stated to have been
approved by the Cabinet on 27th November, 1991, and the State of Kerala actually imported
Palmolein by opening an ESCROW account and getting the import clearance at the rate of US $ 405
per MT in January, 1992.
5. The Comptroller and Auditor General (`CAG'), in its report dated 2nd February, 1994 for the year
ended 31st March, 1993 took exception to the procedure adopted for import of Palmolein by the
State Government. While mentioning some alleged irregularities, the CAG observed, "therefore, the
agreement entered into did not contain adequate safeguards to ensure that imported product would
satisfy all the standards laid down in Prevention of Food Adulteration Rules, 1956".
This report of the CAG was placed before the Public Undertaking Committee of the Kerala
Assembly. The 38th Report of the Kerala Legislative Assembly - Committee on Public Undertakings
dated 19th March, 1996, inter alia, referred to the alleged following irregularities:-
a. That the service fee of 15% to meet the fluctuation in exchange rate was not
negotiated and hence was excessive. Even the price of the import product ought not
to have been settled in US Dollars. b. That the concerned department of the State of
Kerala had not invited tenders and had appointed M/s. Mala Export Corporation, an
associate company of M/s. Power and Energy Pvt. Ltd., the company upon which the
import order was placed as handling agent for the import. c. That the delay in
opening of ESCROW accounts and in fixation of price, which were not in conformity
with the circular issued by the Central Government had incurred a loss of more than
Rupees 4 crores to the Exchequer.Centre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

6. The Committee also alleged that under the pretext of plea of urgency, the deal was conducted
without inviting global tenders and if the material was procured by providing ample time by inviting
global tenders, other competitors would have emerged with lesser rates for the import of the item,
which in turn, would have been more beneficial.
7. The Chief Editor of the Gulf India Times even filed a writ petition being O.P. No. 3813 of 1994 in
the Kerala High Court praying that directions be issued to the State to register an FIR on the ground
that import of Palmolein was made in violation of the Government of India Guidelines. However, it
came to be dismissed by the learned Single Judge of the Kerala High Court on 4th April, 1994. Still
another writ petition came to be filed by one Shri M. Vijay Kumar, who was MLA of the Opposition
in the Kerala Assembly praying for somewhat similar relief. This writ petition was dismissed by a
learned Single Judge of the Kerala High Court and even appeal against that order was also
dismissed by the Division Bench of that Court vide order dated 27th September, 1994.
8. Elections were held in the State of Kerala on 20th May, 1996 and the Left Democratic Front
formed the government.
An FIR was registered against Shri Karunakaran, former Chief Minister and six others in relation to
an offence under Section 13(2) read with Section 13(1) (d) of the Prevention of Corruption Act, 1988
and Section 120B of the IPC. The State of Kerala accorded its sanction to prosecute the then Chief
Minister Shri Karunakaran and various officers in the State hierarchy, who were involved in the
import of Palmolein, including respondent No. 2 on 30th November, 1999.
9. Shri Karunakaran, the then Chief Minister filed a petition before the High Court being Criminal
Miscellaneous No.1353/1997 praying for quashing of the said FIR registered against him and the
other officers. Shri P.J. Thomas herein was not a party in that petition. However, the High Court
dismissed the said writ petition declining to quash the FIR registered against the said persons. In
the meanwhile, a challan (report under Section 173 of the Code of Criminal Procedure) had also
been filed before the Court of Special Judge, Thiruvananthapuram and in this background the State
of Kerala, vide its letter dated 31st December, 1999 wrote to the Department of Personnel and
Training (DoPT) seeking sanction to prosecute the said person before the Court of competent
jurisdiction. Keeping in view the investigation of the case conducted by the agency, two other
persons including Shri P.J. Thomas were added as accused Nos. 7 and 8.
10. Shri Karunakaran challenged the order before this Court by filing a Petition for Special Leave to
Appeal, being Criminal Appeal No. 86 of 1998, which also came to be dismissed by this Court on
29th March, 2000. This Court held that "after going through the pleadings of the parties and
keeping in view the rival submissions made before us, we are of the opinion that the registration of
the FIR against the appellants and others cannot be held to be the result of mala fides or actuated by
extraneous considerations. The menace of corruption cannot be permitted to be hidden under the
carpet of the legal technicalities...". The Government Order granting sanction (Annexure R-I in that
petition) was also upheld by this Court and it was further held that "our observations with respect to
the legality of the Government Order are not conclusive regarding its constitutionality but are
restricted so far as its applicability to the registration of the FIR against the appellant is concerned.Centre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

We are, therefore, of the opinion that the aforesaid Government Order has not been shown to be in
any way illegal or unconstitutional so far as the rights of the appellants are concerned...". Granting
liberty to the parties to raise all pleas before the Trial Court, the appeal was dismissed. In the
charge-sheet filed before the Trial Court, in paragraph 7, definite role was attributed to Accused No.
8 (respondent No. 2 herein) and allegations were made against him.
11. For a period of 5 years, the matter remained pending with the Central Government and vide
letter dated 20th December, 2004, the Central Government asked the State Government to send a
copy of the report which had been filed before the Court of competent jurisdiction. After receiving
the request of the State Government, it appears that the file was processed by various authorities
and as early as on 18th January, 2001, a note was put up by the concerned Under Secretary that a
regular departmental enquiry should be held against Shri P.J. Thomas and Shri Jiji Thomson for
imposing a major penalty. According to this note, it was felt that because of lack of evidence, the
prosecution may not succeed against Shri P.J. Thomas but sanction should be accorded for
prosecution of Shri Jiji Thomson. On 18th February, 2003, the DoPT had made a reference to the
Central Vigilance Commission ("CVC" for short) on the cited subject, which was responded to by the
CVC vide their letter dated 3rd June, 2003 and it conveyed its opinion as follows: -
"Department of Personnel & Training may refer to their DO letter No.107/1
/2000-AVD.I dated 18.02.2003 on the subject cited above.
2. Keeping in view the facts and circumstances of the case, the Commission would
advise the Department of Personnel & Training to initiate major penalty proceedings
against Shri P.J. Thomas, IAS (KL:73) and Shri Jiji Thomson, IAS (KL:80) and
completion of proceedings thereof by appointing departmental IO.
3. Receipt of the Commission's advice may be acknowledged."
12. Despite receipt of the above opinion of CVC, the matter was still kept pending, though a note was
again put up on 24th February, 2004 on similar lines as that of 18th January, 2001. In the
meanwhile, the State of Kerala, vide its letter dated 24th January, 2005 wrote to the DoPT that for
reasons recorded in the letter, they wish to withdraw their request for according the sanction for
prosecution of the officers, including respondent No. 2, as made vide their letter dated 31st
December, 1999. The matter which was pending for all this period attained a quietus in view of the
letter of the State of Kerala and the PMO had been informed accordingly.
13. In its letter dated 4th November, 2005, the State took the position that the allegations made by
the Investigating Agency were invalid and the cases and request for sanction against Shri P.J.
Thomas should be withdrawn.
14. On 18th May, 2006 again, the Left Democratic Front formed the Government in the State of
Kerala with Mr. Achuthanandan as the Chief Minister. This time the Government of Kerala filed an
affidavit in this Court disassociating itself from the contents of the earlier affidavit.Centre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

15. Vide letter dated 10th October, 2006, the Chief Secretary to the Government of Kerala again
wrote a letter to the Government of India informing them that the State Government had decided to
continue the prosecution launched by it and as such it sought to withdraw its above letter dated 24th
January, 2005. In other words, it reiterated its request for grant of sanction by the Central
Government.
Vide letter dated 25th November, 2006, the Additional Secretary to the DoPT wrote to the State of
Kerala asking them for the reasons for change in stand, in response to the letter of the State of
Kerala dated 10th October, 2006. This action of the State Government reviving its sanction and
continuing prosecution against Shri Karunakaran and others, including Respondent No. 2, was
challenged by Shri Karunakaran by filing Criminal Revision Petition No. 430 of 2001 in the High
Court of Kerala on the ground that the Government Order was liable to be set aside on the ground of
mala fide and arbitrariness. This petition was dismissed by the High Court.
In its judgment, the High Court referred to the alleged role of Shri P.J. Thomas in the Palmolein
case. The action of the State Government or pendency of proceedings before the Special Judge at
Thiruvananthapuram was never challenged by Shri P.J. Thomas before any court of competent
jurisdiction. The request of the State Government for sanction by the Central Government was
considered by different persons in the Ministry and vide its noting dated 10th May, 2007, a query
was raised upon the CVC as to whether pendency of a reply to Ministry's letter, from State
Government in power, on a matter already settled by the previous State Government should come in
the way of empanelment of these officers for appointment to higher post in the Government. Rather
than rendering the advice asked for, the CVC vide its letter dated 25th June, 2007 informed the
Ministry as follows :
"Department of Personnel & Training may refer to their note dated 17.05.2007, in file
No.107/1/2000-AVD-I, on the above subject.
2. The case has been re-examined and Commission has observed that no case is made
out against S/Shri P.J. Thomas and Jiji Thomson in connection with alleged
conspiracy with other public servants and private persons in the matter of import of
Palmolein through a private firm. The abovesaid officers acted in accordance with a
legitimately taken Cabinet decision and no loss has been caused to the State
Government and most important, no case is made out that they had derived any
benefit from the transaction. (emphasis supplied)
3. In view of the above, Commission advises that the case against S/Shri P.J. Thomas
and Jiji Thomson may be dropped and matter be referred once again thereafter to the
Commission so that Vigilance Clearance as sought for now can be recorded.
4. DOPT's file No.107/1/2000-AVD-I along with the records of the case, is returned
herewith. Its receipt may be acknowledged. Action taken in pursuance of
Commission's advice may be intimated to the Commission early."Centre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

16. It may be noticed that neither in the above reply nor on the file any reasons are available as to
why CVC had changed its earlier opinion/stand as conveyed to the Ministry vide its letter dated 3rd
June, 2003. After receiving the above advice of CVC, the Ministry on 6th July, 2007 had recorded a
note in the file that as far as CVC's advice regarding dropping all proceedings is concerned, the
Ministry should await the action to be taken by the Government of Kerala and the relevant courts.
17. The legality and correctness of the order of the Kerala High Court dated 19th February, 2003 was
questioned by Shri Karunakaran by filing a petition before this Court on which leave was granted
and it came to be registered as Criminal Appeal No. 801 of 2003. This appeal was also dismissed by
this Court vide its order dated 6th December, 2006. However, the parties were given liberty to raise
the plea of mala fides before the High Court. Even on reconsideration, the High Court dismissed the
petition filed by Shri Karunakaran raising the plea of mala fides vide its order dated 6th July, 2007.
The High Court had, thus, declined to accept that action of the State Government in prosecuting the
persons stated therein was actuated by mala fides. The order of the High Court was again challenged
by Shri Karunakaran by preferring a Petition for Special Leave to Appeal before this Court. This
Court had stayed further proceedings before the Trial Court. This appeal remained pending till 23rd
December, 2010 when it abated because of unfortunate demise of Shri Karunakaran.
18. Vide order dated 18th September, 2007, the Government of Kerala appointed Shri P.J. Thomas
as the Chief Secretary. Thereafter, on 6th October, 2008 CVC accorded vigilance clearance to all
officers except Smt. Parminder M. Singh. We have perused the files submitted by the learned
Attorney General for India. From the said files we find that there are at least six notings of DoPT
between 26th June, 2000 and 2nd November, 2004 which has recommended initiation of penalty
proceedings against Shri P.J. Thomas and yet in the clearance given by CVC on 6th October, 2008
and in the Brief prepared by DoPT dated 1st September, 2010 and placed before HPC there is no
reference to the earlier notings of the then DoPT and nor any reason has been given as to why CVC
had changed its views while granting vigilance clearance on 6th October, 2008. On 23rd January,
2009, Shri P.J. Thomas was appointed as Secretary, Parliamentary Affairs to the Government of
India.
19. The DoPT empanelled three officers vide its note dated 1st September, 2010. Vide the same note
along with the Brief the matter was put up to the HPC for selecting one candidate out of the
empanelled officers for the post of Central Vigilance Commissioner. The meeting of the HPC
consisting of the Prime Minister, the Home Minister and the Leader of the Opposition was held on
3rd September, 2010. In the meeting, disagreement was recorded by the Leader of the Opposition,
despite which, name of Shri P.J. Thomas was recommended for appointment to the post of Central
Vigilance Commissioner by majority. A note was thereafter put up with the recommendation of the
HPC and placed before the Prime Minister which was approved on the same day. On 4th September,
2010, the same note was submitted to the President who also approved it on the same day.
Consequently, Shri P.J. Thomas was appointed as Central Vigilance Commissioner and he took oath
of his office.
Setting-up of CVCCentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

20. Vigilance is an integral part of all government institutions. Anti-corruption measures are the
responsibility of the Central Government. Towards this end the Government set up the following
departments :
        (i)          CBI
        (ii)         Administrative Vigilance Division in DoPT
        (iii)     Domestic   Vigilance   Units   in   the   Ministries/ 
Departments, Government companies, Government Corporations, nationalized banks and PSUs
(iv) CVC
21. Thus, CVC as an integrity institution was set up by the Government of India in 1964 vide
Government Resolution pursuant to the recommendations of Santhanam Committee.
However, it was not a statutory body at that time. According to the recommendations of the
Santhanam Committee, CVC, in its functions, was supposed to be independent of the executive. The
sole purpose behind setting up of the CVC was to improve the vigilance administration of the
country.
22. In September, 1997, the Government of India established the Independent Review Committee to
monitor the functioning of CVC and to examine the working of CBI and the Enforcement
Directorate. Independent Review Committee vide its report of December, 1997 suggested that CVC
be given a statutory status. It also recommended that the selection of Central Vigilance
Commissioner shall be made by a High Powered Committee comprising of the Prime Minister, the
Home Minister and the Leader of Opposition in Lok Sabha. It also recommended that the
appointment shall be made by the President of India on the specific recommendations made by the
HPC. That, the CVC shall be responsible for the efficient functioning of CBI; CBI shall report to CVC
about cases taken up for investigations; the appointment of CBI Director shall be by a Committee
headed by the Central Vigilance Commissioner; the Central Vigilance Commissioner shall have a
minimum fixed tenure and that a Committee headed by the Central Vigilance Commissioner shall
prepare a panel for appointment of Director of Enforcement.
23. On 18th December, 1997 the judgment in the case of Vineet Narain v. Union of India [(1998) 1
SCC 226] came to be delivered. Exercising authority under Article 32 read with Article 142, this
Court in order to implement an important constitutional principle of the rule of law ordered that
CVC shall be given a statutory status as recommended by Independent Review Committee. All theCentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

above recommendations of Independent Review Committee were ordered to be given a statutory
status.
24. The judgment in Vineet Narain's case (supra) was followed by the 1999 Ordinance under which
CVC became a multi-member Commission headed by Central Vigilance Commissioner. The 1999
Ordinance conferred statutory status on CVC. The said Ordinance incorporated the directions given
by this Court in Vineet Narain's case. Suffice it to state, that, the 1999 Ordinance stood promulgated
to improve the vigilance administration and to create a culture of integrity as far as government
administration is concerned.
25. The said 1999 Ordinance was ultimately replaced by the enactment of the 2003 Act which came
into force with effect from 11th September, 2003.
Analysis of the 2003 Act
26. The 2003 Act has been enacted to provide for the constitution of a Central Vigilance
Commission as an institution to inquire or cause inquiries to be conducted into offences alleged to
have been committed under the Prevention of Corruption Act, 1988 by certain categories of public
servants of the Central Government, corporations established by or under any Central Act,
Government companies, societies and local authorities owned or controlled by the Central
Government and for matters connected therewith or incidental thereto (see Preamble). By way of an
aside, we may point out that in Australia, US, UK and Canada there exists a concept of integrity
institutions. In Hongkong we have an Independent Commission against corruption. In Western
Australia there exists a statutory Corruption Commission. In Queensland, we have Misconduct
Commission. In New South Wales there is Police Integrity Commission. All these come within the
category of integrity institutions. In our opinion, CVC is an integrity institution. This is clear from
the scope and ambit (including the functions of the Central Vigilance Commissioner) of the 2003
Act. It is an Institution which is statutorily created under the Act. It is to supervise vigilance
administration. The 2003 Act provides for a mechanism by which the CVC retains control over CBI.
That is the reason why it is given autonomy and insulation from external influences under the 2003
Act.
27. For the purposes of deciding this case, we need to quote the relevant provisions of the 2003 Act.
3. Constitution of Central Vigilance Commission.-
(2) The Commission shall consist of--
             (a)          a   Central   Vigilance   Commissioner   -- 
                          Chairperson;
             (b)          not more than two Vigilance Commissioners 
                          -Members.Centre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

             (3)            The   Central   Vigilance   Commissioner   and 
the Vigilance Commissioners shall be appointed from amongst persons--
(a) who have been or are in an All-India Service or in any civil service of the Union or in a civil post
under the Union having knowledge and experience in the matters relating to vigilance, policy
making and administration including police administration;
4. Appointment of Central Vigilance Commissioner and Vigilance Commissioners.-
(1) The Central Vigilance Commissioner and the Vigilance Commissioners shall be appointed by the
President by warrant under his hand and seal:
Provided that every appointment under this sub- section shall be made after
obtaining the recommendation of a Committee consisting of--
(a) the Prime Minister                                   -- 
Chairperson;
(b) the Minister of Home Affairs             -- Member;
(c) the Leader of the Opposition in the 
     House of the People                     --Member.
Explanation.--For the purposes of this sub- section, "the Leader of the Opposition in
the House of the People" shall, when no such Leader has been so recognized, include
the Leader of the single largest group in opposition of the Government in the House
of the People. (2) No appointment of a Central Vigilance Commissioner or a Vigilance
Commissioner shall be invalid merely by reason of any vacancy in the Committee.
5. Terms and other conditions of service of Central Vigilance Commissioner. -
(1) Subject to the provisions of sub-sections (3) and (4), the Central Vigilance Commissioner shall
hold office for a term of four years from the date on which he enters upon his office or till he attains
the age of sixty-five years, whichever is earlier. The Central Vigilance Commissioner, on ceasing to
hold the office, shall be ineligible for reappointment in the Commission.
(3) The Central Vigilance Commissioner or a Vigilance Commissioner shall, before he enters upon
his office, make and subscribe before the President, or some other person appointed in that behalfCentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

by him, an oath or affirmation according to the form set out for the purpose in Schedule to this Act.
(6) On ceasing to hold office, the Central Vigilance Commissioner and every other Vigilance
Commissioner shall be ineligible for--
(a) any diplomatic assignment, appointment as administrator of a Union territory and such other
assignment or appointment which is required by law to be made by the President by warrant under
his hand and seal.
(b) further employment to any office of profit under the Government of India or the Government of
a State.
6. Removal of Central Vigilance Commissioner and Vigilance Commissioner.- (1) Subject to the
provisions of sub-section (3), the Central Vigilance Commissioner or any Vigilance Commissioner
shall be removed from his office only by order of the President on the ground of proved
misbehaviour or incapacity after the Supreme Court, on a reference made to it by the President, has,
on inquiry, reported that the Central Vigilance Commissioner or any Vigilance Commissioner, as the
case may be, ought on such ground be removed.
(3) Notwithstanding anything contained in sub-
section (1), the President may by order remove from office the Central Vigilance Commissioner or
any Vigilance Commissioner if the Central Vigilance Commissioner or such Vigilance
Commissioner, as the case may be,--
(a)        is adjudged an insolvent; or
(b)        has   been   convicted   of   an   offence   which, 
in the opinion of the Central Government, involves moral turpitude; or
(c) engages during his term of office in any paid employment outside the duties of his office;
or
(d) is, in the opinion of the President, unfit to continue in office by reason of infirmity of mind or
body; or
(e) has acquired such financial or other interest as is likely to affect prejudicially his functions as a
Central Vigilance Commissioner or a Vigilance Commissioner.
8. Functions and powers of Central Vigilance Commission-
(1) The functions and powers of the Commission shall be to--Centre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

(a) exercise superintendence over the functioning of the Delhi Special Police Establishment in so far
as it relates to the investigation of offences alleged to have been committed under the Prevention of
Corruption Act, 1988 or an offence with which a public servant specified in sub-section (2) may,
under the Code of Criminal Procedure, 1973, be charged at the same trial;
(b) give directions to the Delhi Special Police Establishment for the purpose of discharging the
responsibility entrusted to it under sub-section (1) of section 4 of the Delhi Special Police
Establishment Act, 1946:
(d) inquire or cause an inquiry or investigation to be made into any complaint against any official
belonging to such category of officials specified in sub-section (2) wherein it is alleged that he has
committed an offence under the Prevention of Corruption Act, 1988 and an offence with which a
public servant specified in subsection (2) may, under the Code of Criminal Procedure, 1973, be
charged at the same trial;
(e)         review   the   progress   of   investigations 
conducted        by          the         Delhi         Special         Police 
Establishment into offences alleged to have been committed under the Prevention of Corruption
Act, 1988 or the public servant may, under the Code of Criminal Procedure, 1973, be charged at the
same trial;
(f) review the progress of applications pending with the competent authorities for sanction of
prosecution under the Prevention of Corruption Act, 1988;
(h) exercise superintendence over the vigilance administration of the various Ministries of the
Central Government or corporations established by or under any Central Act, Government
companies, societies and local authorities owned or controlled by that Government:
(2) The persons referred to in clause (d) of sub-
section (1) are as follows:--
(a) members of All-India Services serving in connection with the affairs of the Union
and Group `A' officers of the Central Government;
(b) such level of officers of the corporations established by or under any Central Act,
Government companies, societies and other local authorities, owned or controlled by
the Central Government, as that Government may, by notification in the Official
Gazette, specify in this behalf:Centre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

Provided that till such time a notification is issued under this clause, all officers of the
said corporations, companies, societies and local authorities shall be deemed to be
the persons referred to in clause (d) of sub-section (1).
11. Power relating to inquiries. - The Commission shall, while conducting any inquiry
referred to in clauses (c) and (d) of sub-section (1) of section 8, have all the powers of
a civil court trying a suit under the Code of Civil Procedure, 1908 and in particular, in
respect of the following matters, namely:--
(a) summoning and enforcing the attendance of any person from any part of India
and examining him on oath;
(b) requiring the discovery and production of any document;
(c) receiving evidence on affidavits;
(d) requisitioning any public record or copy thereof from any court or office;
(e) issuing commissions for the examination of witnesses or other documents; And
(f) any other matter which may be prescribed.
THE SCHEDULE [See section 5(3)] Form of oath or affirmation to be made by the
Central Vigilance Commissioner or Vigilance Commissioner:--
"I, A. B., having been appointed Central Vigilance Commissioner (or Vigilance
Commissioner) of the Central Vigilance Commission do swear in the name of god/
solemnly affirm that I will bear true faith and allegiance to the Constitution of India
as by law established, that I will uphold the sovereignty and integrity of India, that I
will duly and faithfully and to the best of my ability, knowledge and judgment
perform the duties of my office without fear or favour, affection or ill-will and that I
will uphold the constitution and the laws.".
28. On analysis of the 2003 Act, the following are the salient features. CVC is given a statutory
status. It stands established as an Institution. CVC stands established to inquire into offences
alleged to have been committed under the Prevention of Corruption Act, 1988 by certain categories
of public servants enumerated above. Under Section 3(3)(a) the Central Vigilance Commissioner
and the Vigilance Commissioners are to be appointed from amongst persons who have been or are
in All India Service or in any civil service of the Union or who are in a civil post under the Union
having knowledge and experience in the matters relating to vigilance, policy making and
administration including police administration. The underlined words "who have been or who are"
in Section 3(3)(a) refer to the person holding office of a civil servant or who has held such office.
These underlined words came up for consideration by this Court in the case of N. Kannadasan v.
Ajoy Khose and Others [(2009) 7 SCC 1] in which it has been held that the said words indicate theCentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

eligibility criteria and further they indicate that such past or present eligible persons should be
without any blemish whatsoever and that they should not be appointed merely because they are
eligible to be considered for the post. One more aspect needs to be highlighted. The constitution of
CVC as a statutory body under Section 3 shows that CVC is an Institution. The key word is
Institution. We are emphasizing the key word for the simple reason that in the present case the
recommending authority (High Powered Committee) has gone by personal integrity of the officers
empanelled and not by institutional integrity.
29. Section 4 refers to appointment of Central Vigilance Commissioner and Vigilance
Commissioners. Under Section 4(1) they are to be appointed by the President by warrant under her
hand and seal. Section 4(1) indicates the importance of the post. Section 4(1) has a proviso. Every
appointment under Section 4(1) is to be made after obtaining the recommendation of a committee
consisting of-
       (a)          The Prime Minister                       -         
       Chairperson;
       (b)         The Minister of Home Affairs           -         Member;
       (c)         The Leader of the Opposition 
                     in the House of the People                     -
                   Member.
30. For the sake of brevity, we may refer to the Selection Committee as High Powered Committee.
The key word in the proviso is the word "recommendation". While making the recommendation, the
HPC performs a statutory duty. The impugned recommendation dated 3rd September, 2010 is in
exercise of the statutory power vested in the HPC under the proviso to Section 4(1). The post of
Central Vigilance Commissioner is a statutory post. The Commissioner performs statutory functions
as enumerated in Section 8. The word `recommendation' in the proviso stands for an informed
decision to be taken by the HPC on the basis of a consideration of relevant material keeping in mind
the purpose, object and policy of the 2003 Act. As stated, the object and purpose of the 2003 Act is
to have an integrity Institution like CVC which is in charge of vigilance administration and which
constitutes an anti-corruption mechanism. In its functions, the CVC is similar to Election
Commission, Comptroller and Auditor General, Parliamentary Committees etc. Thus, while makingCentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

the recommendations, the service conditions of the candidate being a public servant or civil servant
in the past is not the sole criteria. The HPC must also take into consideration the question of
institutional competency into account. If the selection adversely affects institutional competency
and functioning then it shall be the duty of the HPC not to recommend such a candidate. Thus, the
institutional integrity is the primary consideration which the HPC is required to consider while
making recommendation under Section 4 for appointment of Central Vigilance Commissioner. In
the present case, this vital aspect has not been taken into account by the HPC while recommending
the name of Shri P.J. Thomas for appointment as Central Vigilance Commissioner. We do not wish
to discount personal integrity of the candidate. What we are emphasizing is that institutional
integrity of an institution like CVC has got to be kept in mind while recommending the name of the
candidate.
Whether the incumbent would or would not be able to function? Whether the working of the
Institution would suffer? If so, would it not be the duty of the HPC not to recommend the person. In
this connection the HPC has also to keep in mind the object and the policy behind enactment of the
2003 Act. Under Section 5(1) the Central Vigilance Commissioner shall hold the office for a term of
4 years.
Under Section 5(3) the Central Vigilance Commissioner shall, before he enters upon his office,
makes and subscribes before the President an oath or affirmation according to the form set out in
the Schedule to the Act. Under Section 6(1) the Central Vigilance Commissioner shall be removed
from his office only by order of the President and that too on the ground of proved misbehaviour or
incapacity after the Supreme Court, on a reference made to it by the President, has on inquiry
reported that the Central Vigilance Commissioner be removed. These provisions indicate that the
office of the Central Vigilance Commissioner is not only given independence and insulation from
external influences, it also indicates that such protections are given in order to enable the Institution
of CVC to work in a free and fair environment. The prescribed form of oath under Section 5(3)
requires Central Vigilance Commissioner to uphold the sovereignty and integrity of the country and
to perform his duties without fear or favour. All these provisions indicate that CVC is an integrity
institution.
The HPC has, therefore, to take into consideration the values independence and impartiality of the
Institution. The said Committee has to consider the institutional competence. It has to take an
informed decision keeping in mind the abovementioned vital aspects indicated by the purpose and
policy of the 2003 Act.
31. Chapter III refers to functions and powers of the Central Vigilance Commission. CVC exercises
superintendence over the functioning of the Delhi Special Police Establishment insofar as it relates
to investigation of offences alleged to have been committed under the Prevention of Corruption Act,
1988, or an offence with which a public servant specified in sub-
section (2) may, under the Code of Criminal Procedure, 1973 be charged with at the trial. Thus, CVC
is empowered to exercise superintendence over the functioning of CBI. It is also empowered to give
directions to CBI. It is also empowered to review the progress of investigations conducted by CBICentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

into offences alleged to have been committed under the Prevention of Corruption Act, 1988 or under
the Code of Criminal Procedure by a public servant. CVC is also empowered to exercise
superintendence over the vigilance administration of various ministries of the Central Government,
PSUs, Government companies etc. The powers and functions discharged by CVC is the sole reason
for giving the institution the administrative autonomy, independence and insulation from external
influences.
Validity of the recommendation dated 3 rd September, 2010
32. One of the main contentions advanced on behalf of Union of India and Shri P.J. Thomas before
us was that once the CVC clearance had been granted on 6th October, 2008 and once the candidate
stood empanelled for appointment at the Centre and in fact stood appointed as Secretary,
Parliamentary Affairs and, thereafter, Secretary Telecom, it was legitimate for the HPC to proceed
on the basis that there was no impediment in the way of appointment of respondent No. 2 on the
basis of the pending case which had been found to be without any substance.
33. We find no merit in the above submissions. Judicial review seeks to ensure that the statutory
duty of the HPC to recommend under the proviso to Section 4(1) is performed keeping in mind the
policy and the purpose of the 2003 Act.
We are not sitting in appeal over the opinion of the HPC. What we have to see is whether relevant
material and vital aspects having nexus to the object of the 2003 Act were taken into account when
the decision to recommend took place on 3rd September, 2010. Appointment to the post of the
Central Vigilance Commissioner must satisfy not only the eligibility criteria of the candidate but also
the decision making process of the recommendation [see para 88 of N. Kannadasan (supra)]. The
decision to recommend has got to be an informed decision keeping in mind the fact that CVC as an
institution has to perform an important function of vigilance administration. If a statutory body like
HPC, for any reason whatsoever, fails to look into the relevant material having nexus to the object
and purpose of the 2003 Act or takes into account irrelevant circumstances then its decision would
stand vitiated on the ground of official arbitrariness [see State of Andhra Pradesh v. Nalla Raja
Reddy (1967) 3 SCR 28].
Under the proviso to Section 4(1), the HPC had to take into consideration what is good for the
institution and not what is good for the candidate [see para 93 of N. Kannadasan (supra)].
When institutional integrity is in question, the touchstone should be "public interest" which has got
to be taken into consideration by the HPC and in such cases the HPC may not insist upon proof [see
para 103 of N. Kannadasan (supra)].
We should not be understood to mean that the personal integrity is not relevant. It certainly has a
co-
relationship with institutional integrity. The point to be noted is that in the present case the entire
emphasis has been placed by the CVC, the DoPT and the HPC only on the bio-data of theCentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

empanelled candidates. None of these authorities have looked at the matter from the larger
perspective of institutional integrity including institutional competence and functioning of CVC.
Moreover, we are surprised to find that between 2000 and 2004 the notings of DoPT dated 26th
June, 2000, 18th January, 2001, 20th June, 2003, 24th February, 2004, 18th October, 2004 and
2nd November, 2004 have all observed that penalty proceedings may be initiated against Shri P.J.
Thomas. Whether State should initiate such proceedings or the Centre should initiate such
proceedings was not relevant.
What is relevant is that such notings were not considered in juxtaposition with the clearance of CVC
granted on 6th October, 2008. Even in the Brief submitted to the HPC by DoPT, there is no
reference to the said notings between the years 2000 and 2004. Even in the C.V. of Shri P.J.
Thomas, there is no reference to the earlier notings of DoPT recommending initiation of penalty
proceedings against Shri P.J. Thomas. Therefore, even on personal integrity, the HPC has not
considered the relevant material. The learned Attorney General, in his usual fairness, stated at the
Bar that only the Curriculum Vitae of each of the empanelled candidates stood annexed to the
agenda for the meeting of the HPC. The fact remains that the HPC, for whatsoever reason, has failed
to consider the relevant material keeping in mind the purpose and policy of the 2003 Act. The
system governance established by the Constitution is based on distribution of powers and functions
amongst the three organs of the State, one of them being the Executive whose duty is to enforce the
laws made by the Parliament and administer the country through various statutory bodies like CVC
which is empowered to perform the function of vigilance administration.
Thus, we are concerned with the institution and its integrity including institutional competence and
functioning and not the desirability of the candidate alone who is going to be the Central Vigilance
Commissioner, though personal integrity is an important quality. It is the independence and
impartiality of the institution like CVC which has to be maintained and preserved in larger interest
of the rule of law [see Vineet Narain (supra)]. While making recommendations, the HPC performs a
statutory duty. Its duty is to recommend. While making recommendations, the criteria of the
candidate being a public servant or a civil servant in the past is not the sole consideration. The HPC
has to look at the record and take into consideration whether the candidate would or would not be
able to function as a Central Vigilance Commissioner.
Whether the institutional competency would be adversely affected by pending proceedings and if by
that touchstone the candidate stands disqualified then it shall be the duty of the HPC not to
recommend such a candidate. In the present case apart from the pending criminal proceedings, as
stated above, between the period 2000 and 2004 various notings of DoPT recommended
disciplinary proceedings against Shri P.J. Thomas in respect of Palmolein case. Those notings have
not been considered by the HPC. As stated above, the 2003 Act confers autonomy and independence
to the institution of CVC.
Autonomy has been conferred so that the Central Vigilance Commissioner could act without fear or
favour. We may reiterate that institution is more important than an individual. This is the test laid
down in para 93 of N. Kannadasan's case (supra). In the present case, the HPC has failed to take this
test into consideration. The recommendation dated 3rd September, 2010 of HPC is entirelyCentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

premised on the blanket clearance given by CVC on 6th October, 2008 and on the fact of respondent
No. 2 being appointed as Chief Secretary of Kerala on 18th September, 2007; his appointment as
Secretary of Parliamentary Affairs and his subsequent appointment as Secretary, Telecom. In the
process, the HPC, for whatever reasons, has failed to take into consideration the pendency of
Palmolein case before the Special Judge, Thiruvananthapuram being case CC 6 of 2003;
the sanction accorded by the Government of Kerala on 30th November, 1999 under Section 197
Cr.P.C. for prosecuting inter alia Shri P.J. Thomas for having committed alleged offence under
Section 120-B IPC read with Section 13(1)(d) of the Prevention of Corruption Act; the judgment of
the Supreme Court dated 29th March, 2000 in the case of K. Karunakaran v. State of Kerala and
Another in which this Court observed that, "the registration of the FIR against Shri Karunakaran
and others cannot be held to be the result of malafides or actuated by extraneous considerations.
The menace of corruption cannot be permitted to be hidden under the carpet of legal technicalities
and in such cases probes conducted are required to be determined on facts and in accordance with
law". Further, even the judgment of the Kerala High Court in Criminal Revision Petition No. 430 of
2001 has not been considered. It may be noted that the clearance of CVC dated 6th October, 2008
was not binding on the HPC. However, the aforestated judgment of the Supreme Court dated 29th
March, 2000 in the case of K. Karunakaran vs. State of Kerala and Another in Criminal Appeal No.
86 of 1998 was certainly binding on the HPC and, in any event, required due weightage to be given
while making recommendation, particularly when the said judgment had emphasized the
importance of probity in high offices. This is what we have repeatedly emphasized in our judgment -
institution is more important than individual(s). For the above reasons, it is declared that the
recommendation made by the HPC on 3rd September, 2010 is non-est in law.
Is Writ of Quo Warranto invocable ?
34. Shri K.K. Venugopal, learned senior counsel appearing on behalf of respondent No. 2, submitted
that the present case is neither a case of infringement of the statutory provisions of the 2003 Act nor
of the appointment being contrary to any procedure or rules. According to the learned counsel, it is
well settled that a writ of quo warranto applies in a case when a person usurps an office and the
allegation is that he has no title to it or a legal authority to hold it. According to the learned counsel
for a writ of quo warranto to be issued there must be a clear infringement of the law. That, in the
instant case there has been no infringement of any law in the matter of appointment of respondent
No. 2.
35. The procedure of quo warranto confers jurisdiction and authority on the judiciary to control
executive action in the matter of making appointments to public offices against the relevant
statutory provisions. Before a citizen can claim a writ of quo warranto he must satisfy the court
inter-alia that the office in question is a public office and it is held by a person without legal
authority and that leads to the inquiry as to whether the appointment of the said person has been in
accordance with law or not. A writ of quo warranto is issued to prevent a continued exercise of
unlawful authority.Centre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

36. One more aspect needs to be mentioned. In the present petition, as rightly pointed by Shri
Prashant Bhushan, learned counsel appearing on behalf of the petitioner, a declaratory relief is also
sought besides seeking a writ of quo warranto.
37. At the outset it may be stated that in the main writ petition the petitioner has prayed for issuance
of any other writ, direction or order which this Court may deem fit and proper in the facts and
circumstances of this Case. Thus, nothing prevents this Court, if so satisfied, from issuing a writ of
declaration. Further, as held hereinabove, recommendation of the HPC and, consequently, the
appointment of Shri P.J. Thomas was in contravention of the provisions of the 2003 Act, hence, we
find no merit in the submissions advanced on behalf of respondent No. 2 on non-maintainability of
the writ petition. If public duties are to be enforced and rights and interests are to be protected, then
the court may, in furtherance of public interest, consider it necessary to inquire into the state of
affairs of the subject matter of litigation in the interest of justice [see Ashok Lanka v. Rishi Dixit
(2005) 5 SCC 598].
38. Keeping in mind the above parameters, we may now consider some of the judgments on which
reliance has been placed by the learned counsel for respondent No. 2.
39. In Ashok Kumar Yadav v. State of Haryana [(1985) 4 SCC 417], the Division Bench of the Punjab
and Haryana High Court had quashed and set aside selections made by the Haryana Public Service
Commission to the Haryana Civil Service and other Allied Services.
40. In that case some candidates who had obtained very high marks at the written examination
failed to qualify as they had obtained poor marks in the viva voce test. Consequently, they were not
selected. They were aggrieved by the selections made by Haryana Public Service Commission.
Accordingly, Civil Writ Petition 2495 of 1983 was filed in the High Court challenging the validity of
the selections and seeking a writ for quashing and setting aside the same. There were several
grounds on which the validity of the selection made by the Commission was assailed. A declaration
was also sought that they were entitled to be selected. A collateral attack was launched. It was
alleged that the Chairperson and members of Public Service Commission were not men of high
integrity, calibre and qualification and they were appointed solely as a matter of political patronage
and hence the selections made by them were invalid. This ground of challenge was sought to be
repelled on behalf of the State of Haryana who contended that not only was it not competent to the
Court on the existing set of pleadings to examine whether the Chairman and members of the
Commission were men of high integrity, calibre and qualification but also there was no material at
all on the basis of which the Court could come to the conclusion that they were men lacking in
integrity, calibre or qualification.
41. The writ petition came to be heard by a Division Bench of the High Court of Punjab and
Haryana. The Division Bench held that the Chairperson and members of the Commission had been
appointed purely on the basis of political considerations and that they did not satisfy the test of high
integrity, calibre and qualification. The Division Bench went to the length of alleging corruption
against the Chairperson and members of the Commission and observed that they were not
competent to validly wield the golden scale of viva voce test for entrance into the public service. ThisCentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

Court vide para 9 observed that it was difficult to see how the Division Bench of the High Court
could have possibly undertaken an inquiry into the question whether Chairman and members of the
Commission were men of integrity, calibre and qualification;
that such an inquiry was totally irrelevant inquiry because even if they were men lacking in integrity,
calibre and qualification, it would not make their appointments invalid so long as the constitutional
and legal requirement in regard to appointment are fulfilled. It was held that none of the
constitutional provisions, namely, Article 316 and 319 stood violated in making appointments of the
Chairperson and members of the Commission nor was any legal provision breached. Therefore, the
appointments of the Chairperson and members of the Commission were made in conformity with
the constitutional and legal requirements, and if that be so, it was beyond the jurisdiction of the
High Court to hold that such appointments were invalid on the ground that the Chairman and the
members of the Commission lacked integrity, calibre and qualification. The Supreme Court
observed that it passes their comprehension as to how the appointments of the Chairman and
members of the Commission could be regarded as suffering from infirmity merely on the ground
that in the opinion of the Division Bench of the High Court the Chairperson and the members of the
Commission were not men of integrity or calibre. In the present case, as stated hereinabove, there is
a breach/ violation of the proviso to Section 4(1) of the 2003 Act, hence, writ was maintainable.
42. In R.K. Jain v. Union of India [(1993) 4 SCC 119] Shri Harish Chandra was a Senior
Vice-President when the question of filling up the vacancy of the President came up for
consideration. He was qualified for the post under the Rules.
No challenge was made on that account. Under Rule 10(1) the Central Government was conferred
the power to appoint one of the members to be the President. The validity of the Rule was not
questioned. Thus, the Central Government was entitled to appoint Shri Harish Chandra as the
President. It was stated that the track record of Shri Harish Chandra was poor. He was hardly fit to
hold the post of the President. It was averred that Shri Harish Chandra has been in the past
proposed for appointment as a Judge of the Delhi High Court.
His appointment, however, did not materialize due to certain adverse reports. It was held by this
Court that judicial review is concerned with whether the incumbent possessed requisite qualification
for appointment and the manner in which the appointment came to be made or the procedure
adopted was fair, just and reasonable. When a candidate was found qualified and eligible and is
accordingly appointed by the executive to hold an office as a Member or Vice President or President
of a Tribunal, in judicial review the Court cannot sit over the choice of the selection. It is for the
executive to select the personnel as per law or procedure. Shri Harish Chandra was the Senior Vice
President at the relevant time. The question of comparative merit which was the key contention of
the petitioner could not be gone into in a PIL; that the writ petition was not a writ of quo warranto
and in the circumstances the writ petition came to be dismissed. It was held that even assuming for
the sake of arguments that the allegations made by the petitioner were factually accurate, still, this
Court cannot sit in judgment over the choice of the person made by the Central Government for
appointment as a President of CEGAT so long as the person chosen possesses the prescribed
qualification and is otherwise eligible for appointment. It was held that this Court cannot interfereCentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

with the appointment of Shri Harish Chandra as the President of CEGAT on the ground that his
track record was poor or because of adverse reports on which account his appointment as a High
Court Judge had not materialized.
43. In the case of Hari Bansh Lal v. Sahodar Prasad Mahto [(2010) 9 SCC 655], the appointment of
Shri Hari Bansh Lal as Chairman, Jharkhand State Electricity Board stood challenged on the ground
that the board had been constituted in an arbitrary manner; that Shri Hari Bansh Lal was a person
of doubtful integrity; that he was appointed as a Chairman without following the rules and
procedure and in the circumstances the appointment stood challenged. On the question of
maintainability, the Division Bench of this Court held that a writ of quo warranto lies only when the
appointment is contrary to a statutory provision. It was further held that "suitability" of a candidate
for appointment to a post is to be judged by the appointing authority and not by the court unless the
appointment is contrary to the statutory rules/provisions. It is important to note that this Court
went into the merits of the case and came to the conclusion that there was no adequate material to
doubt the integrity of Shri Hari Bansh Lal who was appointed as the Chairperson of Jharkhand State
Electricity Board. This Court further observed that in the writ petition there was no averment saying
that the appointment was contrary to statutory provisions.
44. As stated above, we need to keep in mind the difference between judicial review and merit
review. As stated above, in this case the judicial determination is confined to the integrity of the
decision making process undertaken by the HPC in terms of the proviso to Section 4(1) of the 2003
Act. If one carefully examines the judgment of this Court in Ashok Kumar Yadav's case (supra) the
facts indicate that the High Court had sat in appeal over the personal integrity of the Chairman and
Members of the Haryana Public Service Commission in support of the collateral attack on the
selections made by the State Public Service Commission. In that case, the High Court had failed to
keep in mind the difference between judicial and merit review. Further, this Court found that the
appointments of the Chairperson and Members of Haryana Public Service Commission was in
accordance with the provisions of the Constitution. In that case, there was no issue as to the legality
of the decision-
making process. On the contrary the last sentence of para 9 supports our above reasoning when it
says that it is always open to the Court to set aside the decision (selection) of the Haryana Public
Service Commission if such decision is vitiated by the influence of extraneous considerations or if
such selection is made in breach of the statute or the rules.
45. Even in R.K. Jain's case (supra), this Court observed vide para 73 that judicial review is
concerned with whether the incumbent possessed qualifications for the appointment and the
manner in which the appointment came to be made or whether procedure adopted was fair, just and
reasonable. We reiterate that Government is not accountable to the courts for the choice made but
Government is accountable to the courts in respect of the lawfulness/legality of its decisions when
impugned under the judicial review jurisdiction. We do not wish to multiply the authorities on this
point.
Appointment of Central Vigilance Commissioner at the President's discretionCentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

46. On behalf of respondent No. 2 it was submitted that though under Section 4(1) of the 2003 Act,
the appointment of Central Vigilance Commissioner is made on the basis of the recommendation of
a High Powered Committee, the President of India is not to act on the advice of the Council of
Ministers as is provided in Article 74 of the Constitution. In this connection, it was submitted that
the exercise of powers by the President in appointing respondent No. 2 has not been put in issue in
the PIL, nor is there any pleading in regard to the exercise of powers by the President and in the
circumstances it is not open to the petitioner to urge that the appointment is invalid.
47. Shri G.E. Vahanvati, learned Attorney General appearing on behalf of Union of India, however,
submitted that the proposal sent after obtaining and accepting the recommendations of the High
Powered Committee under Section 4(1) was binding on the President. Learned counsel submitted
that under Article 74 of the Constitution the President acts in exercise of her function on the aid and
advice of the Council of Ministers headed by the Prime Minister which advice is binding on the
President subject to the proviso to Article 74. According to the learned counsel Article 77 of the
Constitution inter alia provides for conduct of Government Business. Under Article 77(3), the
President makes rules for transaction of Government Business and for allocation of business among
the Ministers. On facts, learned Attorney General submitted that under Government of India
(Transaction of Business) Rules, 1961 the Prime Minister had taken a decision on 3rd September,
2010 to propose the name of respondent No. 2 for appointment as Central Vigilance Commissioner
after the recommendation of the High Powered Committee. It was accordingly submitted on behalf
of Union of India that this advice of the Prime Minister under Article 77(3), read with Article 74 of
the Constitution is binding on the President. That, although the recommendation of the High
Powered Committee under Section 4(1) of the 2003 Act may not be binding on the President proprio
vigore, however, if such recommendation has been accepted by the Prime Minister, who is the
concerned authority under Article 77(3), and if such recommendation is then forwarded to the
President under Article 74, then the President is bound to act in accordance with the advice
tendered. That, the intention behind Article 77(3) is that it is physically impossible that every
decision is taken by the Council of Ministers. The Constitution does not use the term "Cabinet".
Rules have been framed for convenient transaction and allocation of such business.
Under the Rules of Business, the concerned authority is the Prime Minister. The advice tendered to
the President by the Prime Minister regarding the appointment of the Central Vigilance
Commissioner would be thus binding on the President. Lastly, it was submitted that unless the
Constitution expressly permits the exercise of discretion by the President, every decision of the
President has to be on the aid and advice of Council of Ministers.
48. Shri Venugopal, learned counsel appearing on behalf of respondent No. 2 submitted that though
the President has an area of discretion in regard to exercise of certain powers under the Constitution
the Constitution is silent about the exercise of powers by the President/Governor where a Statute
confers such powers. In this connection learned counsel placed reliance on the judgment of this
Court in Bhuri Nath v.
State of J & K [(1997) 2 SCC 745]. In that case, the appellants-Baridars challenged the
constitutionality of Jammu and Kashmir Shri Mata Vaishno Devi Shrine Act, 1988 which wasCentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

enacted to provide for better management, administration and governance of Shri Mata Vaishno
Devi Shrine and its endowments including the land and buildings attached to the Shrine. By
operation of that Act the administration, management and governance of the Shrine and its Funds
stood vested in the Board. Consequently, all rights of Baridars stood extinguished from the date of
the commencement of the Act by operation of Section 19(1) of the Act. One of the questions which
came up for consideration in that case was that when the Governor discharges the functions under
the Act, is it with the aid and advice of the Council of Ministers or whether he discharges those
functions in his official capacity as the Governor. This question arose because by an order dated 16th
January, 1995, this Court had directed the Board to frame a scheme for rehabilitation of persons
engaged in the performance of Pooja at Shri Mata Vaishno Devi Shrine. When that matter came up
for hearing on 20th March, 1995, the Baridars stated that they did not want rehabilitation. Instead,
they preferred to receive compensation to be determined under Section 20 of the impugned Act
1988. This Court noticed that in the absence of guidelines for determination of the compensation by
the Tribunal to be appointed under Section 20 it was not possible to award compensation to the
Baridars.
Consequently, the Supreme Court ordered that the issue of compensation be left to the Governor to
make appropriate guidelines to determine the compensation. Pursuant thereto, guidelines were
framed by the Governor which were published in the State Gazette and placed on record on 8th
May, 1995. It is in this context that the question arose that when the legislature entrusted the
powers under the Act to the Governor whether the Governor discharges the functions under the Act
with the aid and advice of the Council of Ministers or whether he acts in his official capacity as a
Governor under the Act.
After examining the Scheme of the 1988 Act the Division Bench of this Court held that the
legislature of Jammu & Kashmir, while making the Act was aware that similar provisions in the
Endowments Act, 1966 gives power of the State Government to dissolve the Board of Trustees of
Tirupati Devasthanams and the Board of Trustees of other institutions.
Thus, it is clear that the legislature entrusted the powers under the Act to the Governor in his official
capacity. On examination of the 1988 Act this Court found that the Governor is to preside over the
meetings of the Board and in his absence his nominee, a qualified Hindu, shall preside over the
functions. That, under the 1988 Act no distinction was made between the Governor and the
Executive Government.
That, under the scheme of the 1988 Act there was nothing to indicate that the power was given to
the Council of Ministers and the Governor was to act on its advice as executive head of the State. It is
in these circumstances that this Court held that while discharging the functions under the 1988 Act
the Governor acts in his official capacity. In the same judgment this Court has also referred to the
judgment of the Full Bench of the Punjab and Haryana High Court in Hardwari Lal v.
G.D. Tapase [AIR 1982 P&H 439] in which a similar question arose as to whether the Governor in
his capacity as the Chancellor of Maharshi Dayanand University acts under the 1975 Act in his
official capacity as Chancellor or with the aid and advice of the Council of Ministers. The Full BenchCentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

of the High Court, after elaborate consideration of the provisions of the Act, observed that under the
Maharshi Dayanand University Act 1975, the State Government would not interfere in the affairs of
the University. Under that Act, the State Government is an Authority different and distinct from the
authority of the Chancellor. Under that Act the State Government was not authorized to advise the
Chancellor to act in a particular manner. Under that Act the University was a statutory body,
autonomous in character and it had been given powers exercisable by the Chancellor in his absolute
discretion. In the circumstances, under the scheme of that Act it was held that while discharging the
functions as a Chancellor, the Governor does everything in his discretion as a Chancellor and he
does not act on the aid and advice of his Council of Ministers. This judgment has no application to
the scheme of the 2003 Act. As stated hereinabove, the CVC is constituted under Section 3(1) of the
2003 Act. The Central Vigilance Commissioner is appointed under Section 4(1) of the 2003 Act by
the President by warrant under her hand and seal after obtaining the recommendation of a
Committee consisting of the Prime Minister as the Chairperson and two other Members. As
submitted by the learned Attorney General although under the 2003 Act the Central Vigilance
Commissioner is appointed after obtaining the recommendation of the High Powered Committee,
such recommendation has got to be accepted by the Prime Minister, who is the concerned authority
under Article 77(3), and if such recommendation is forwarded to the President under Article 74,
then the President is bound to act in accordance with the advice tendered. Further under the Rules
of Business the concerned authority is the Prime Minister. Therefore, the advice tendered to the
President by the Prime Minister regarding appointment of the Central Vigilance Commissioner will
be binding on the President. It may be noted that the above submissions of the Attorney General
find support even in the judgment of the Division Bench of this Court in Bhuri Nath's case (supra)
which in turn has placed reliance on the judgment of this Court in Samsher Singh v. State of Punjab
[(1974) 2 SCC 831] in which a Bench of 7 Judges of this Court held that under the Cabinet system of
Government, as embodied in our Constitution, the Governor is the formal Head of the State. He
exercises all his powers and functions conferred on him by or under the Constitution with the aid
and advice of his Council of Ministers. That, the real executive power is vested in the Council of
Ministers of the Cabinet. The same view is reiterated in R.K. Jain's case (supra). However, in Bhuri
Nath's case (supra) it has been clarified that the Governor being the constitutional head of the State,
unless he is required to perform the function under the Constitution in his individual discretion, the
performance of the executive power, which is coextensive with the legislative power, is with the aid
and advice of the Council of Ministers headed by the Chief Minister. Thus, we conclude that the
judgment in Bhuri Nath's case has no application as the scheme of the Jammu and Kashmir Shri
Mata Vaishno Devi Shrine Act, 1988 as well as the scheme of Maharshi Dayanand University Act,
1975 as well as the scheme of the various Endowment Acts is quite different from the scheme of the
2003 Act. Hence, there is no merit in the contention advanced on behalf of respondent No. 2 that in
the matter of appointment of Central Vigilance Commissioner under Section 4(1) of the 2003 Act
the President is not to act on the advice of the Council of Ministers as is provided in Article 74 of the
Constitution.
Unanimity or consensus under Section 4(2) of the 2003 Act
49. One of the arguments advanced on behalf of the petitioner before us was that the
recommendation of the High Powered Committee under the proviso to Section 4(1) has to beCentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

unanimous. It was submitted that CVC was set up under the Resolution dated 11th February, 1964.
Under that Resolution the appointment of Central Vigilance Commissioner was to be initiated by
the Cabinet Secretary and approved by the Prime Minister. However, the provision made in Section
4 of the 2003 Act was with a purpose, namely, to introduce an element of bipartisanship and
political neutrality in the process of appointment of the head of the CVC. The provision made in
Section 4 for including the Leader of Opposition in the High Powered Committee made a significant
change from the procedure obtaining before the enactment of the said Act. It was further submitted
that if unanimity is ruled out then the very purpose of inducting the Leader of Opposition in the
process of selection will stand defeated because if the recommendation of the Committee were to be
arrived at by majority it would always exclude the Leader of Opposition since the Prime Minister
and the Home Minister will always be ad idem. It was submitted that one must give a purposive
interpretation to the scheme of the Act. It was submitted that under Section 9 it has been inter alia
stated that all business of the Commission shall, as far as possible, be transacted unanimously. It
was submitted that since in Vineet Narain's case (supra) this Court had observed that CVC would be
selected by a three member Committee, including the Leader of the Opposition it was patently
obvious that the said Committee would decide by unanimity or consensus. That, it was no where
stated that the Committee would decide by majority.
50. We find no merit in these submissions. To accept the contentions advanced on behalf of the
petitioners would mean conferment of a "veto right" on one of the members of the HPC. To confer
such a power on one of the members would amount to judicial legislation. Under the proviso to
Section 4(1) Parliament has put its faith in the High Powered Committee consisting of the Prime
Minister, the minister for Home Affairs and the Leader of the Opposition in the House of the People.
It is presumed that such High Powered Committee entrusted with wide discretion to make a choice
will exercise its powers in accordance with the 2003 Act, objectively and in a fair and reasonable
manner. It is well settled that mere conferment of wide discretionary powers per se will not violate
the doctrine of reasonableness or equality. The 2003 Act is enacted with the intention that such
High Powered Committee will act in a bipartisan manner and shall perform its statutory duties
keeping in view the larger national interest. Each of the Members is presumed by the legislature to
act in public interest. On the other hand, if veto power is given to one of the three Members, the
working of the Act would become unworkable. One more aspect needs to be mentioned. Under
Section 4(2) of the 2003 Act it has been stipulated that the vacancy in the Committee shall not
invalidate the appointment. This provision militates against the argument of the petitioner that the
recommendation under Section 4 has to be unanimous. Before concluding, we would like to quote
the observations from the judgment in Grindley and Another v.
Barker, 1 Bos. & Pul. 229, which reads as under :
"I think it is now pretty well established, that where a number of persons are
entrusted with the powers not of mere private confidence, but in some respects of a
general nature and all of them are regularly assembled, the majority will conclude the
minority, and their act will be the act of the whole."
51. The Court, while explaining the raison d'etre behind the principle, observed :Centre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

"It is impossible that bodies of men should always be brought to think alike. There is
often a degree of coercion, and the majority is governed by the minority, and vice
versa, according to the strength of opinions, tempers, prejudices, and even interests.
We shall not therefore think ourselves bound in this case by the rule which holds in
that. I lay no great stress on the clause of the act which appoints a majority to act in
certain cases, because that appears to have been done for particular reasons which do
not apply to the ultimate trial: it relates only to the assembling the searchers; now
there is no doubt that all the six triers must assemble; and the only question, what
they must do when assembled? We have no light to direct us in this part, except the
argument from the nature of the subject. The leather being subject to seizure in every
stage of the manufacture, the tribunal ought to be composed of persons skilful in
every branch of the manufacture. And I cannot say there is no weight in the
argument, drawn from the necessity of persons concurring in the judgments, who are
possessed of different branches of knowledge, but standing alone it is not so
conclusive as to oblige us to break through the general rule; besides, it is very much
obviated by this consideration when all have assembled and communicated to each
other the necessary information, it is fitter that the majority should decide than that
all should be pressed to a concurrence. If this be so, then the reasons drawn from the
act and which have been supposed to demand, that the whole body should unite in
the judgment, have no sufficient avail, and consequently the general rule of law will
take place; viz. that the judgment of four out of six being the whole body to which the
authority is delegated r egularly assemble and acting, is the judgment of the all."
52. Similarly, we would like to quote Halsbury's Laws of England (4th Ed. Re-issue), on this aspect,
which states as under:
"Where a power of a public nature is committed to several persons, in the absence of
statutory provision or implication to the contrary the act of the majority is binding
upon the minority."
53. In the circumstances, we find no merit in the submission made on behalf of the petitioner on this
point that the recommendation/decision dated 3rd September, 2010 stood vitiated on the ground
that it was not unanimous.
Guidelines/Directions of this Court
54. The 2003 Act came into force on and from 11th September, 2003. In the present case we find
non-compliance of some of the provisions of the 2003 Act. Under Section 3(3), the Central Vigilance
Commissioner and the Vigilance Commissioners are to be appointed from amongst persons -
(a) who have been or who are in All-India Service or in any civil service of the Union or in a civil post
under the Union having requisite knowledge and experience as indicated in Section 3(3)(a); orCentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

(b) who have held office or are holding office in a corporation established by or under any Central
Act or a Central Government company and persons who have experience in finance including
insurance and banking, law, vigilance and investigations.
55. No reason has been given as to why in the present case the zone of consideration stood restricted
only to the civil service. We therefore direct that :
(i) In our judgment we have held that there is no prescription of unanimity or
consensus under Section 4(2) of the 2003 Act. However, the question still remains as
to what should be done in cases of difference of opinion amongst the Members of the
High Powered Committee. As in the present case, if one Member of the Committee
dissents that Member should give reasons for the dissent and if the majority
disagrees with the dissent, the majority shall give reasons for overruling the dissent.
This will bring about fairness-in-action. Since we have held that legality of the choice or selection is
open to judicial review we are of the view that if the above methodology is followed transparency
would emerge which would also maintain the integrity of the decision-
making process.
(ii) In future the zone of consideration should be in terms of Section 3(3) of the 2003 Act. It shall
not be restricted to civil servants.
(iii) All the civil servants and other persons empanelled shall be outstanding civil servants or
persons of impeccable integrity.
(iv) The empanelment shall be carried out on the basis of rational criteria, which is to be reflected by
recording of reasons and/or noting akin to reasons by the empanelling authority.
(v) The empanelment shall be carried out by a person not below the rank of Secretary to the
Government of India in the concerned Ministry.
(vi) The empanelling authority, while forwarding the names of the empanelled officers/persons,
shall enclose complete information, material and data of the concerned officer/person, whether
favourable or adverse. Nothing relevant or material should be withheld from the Selection
Committee. It will not only be useful but would also serve larger public interest and enhance public
confidence if the contemporaneous service record and acts of outstanding performance of the officer
under consideration, even with adverse remarks is specifically brought to the notice of the Selection
Committee.
(vii) The Selection Committee may adopt a fair and transparent process of consideration of the
empanelled officers.
ConclusionCentre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

56. For the above reasons, it is declared that the recommendation dated 3rd September, 2010 of the
High Powered Committee recommending the name of Shri P.J. Thomas as Central Vigilance
Commissioner under the proviso to Section 4(1) of the 2003 Act is non-est in law and, consequently,
the impugned appointment of Shri P.J. Thomas as Central Vigilance Commissioner is quashed.
57. The writ petitions are accordingly allowed with no order as to costs.
.......................................CJI (S. H. Kapadia) ...........................................J. (K.S. Panicker
Radhakrishnan) ...........................................J. (Swatanter Kumar) New Delhi;
March 3, 2011
ITEM NO.1A            COURT NO.1             SECTION PIL
            S U P R E M E   C O U R T   O F   I N D I A
                         RECORD OF PROCEEDINGS
               WRIT PETITION (CIVIL) NO.348 OF 2010
CENTRE FOR PIL & ANR.                       Petitioner(s)
                 VERSUS
UNION OF INDIA & ANR.                       Respondent(s)
With Writ Petition (C) No.355 of 2010
Date: 03/03/2011 These Matters were called on for judgement today.
For Petitioner(s) Mr. Prashant Bhushan,Adv. In WP 348/2010: Mr. Pranav Sachdeva,Adv.
In WP 355/2010: Mr. Siddharth Bhatnagar,Adv.
Mr. Prashant Kumar,Adv.
Mr. B.S. Iyenger,Adv.
for M/s. AP & J Chambers,Advs.Centre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

For Respondent(s) Ms. Indira Jaising,ASG Mr. Devadatt Kamat,Adv.
Mr. T.A. Khan,Adv.
Mr. Anoopam N. Prasad,Adv.
Mr. Nishanth Patil,Adv.
Mr. Rohit Sharma,Adv.
Ms. Naila Jung,Adv.
Ms. Anil Katiyar,Adv.
Mr. S.N. Terdal,Adv.
In WP 348/2010: Mr. K.K. Venugopal,Sr.Adv.
Mr. Gopal Sankaranarayanan,Adv.
Mr. Wills Mathews,Adv.
Mr. D.K. Tiwari,Adv.
Mr. Rajdipa Behura,Adv.
Mr. Shyam Mohan,Adv.
Mr. A. Venayagam Balan,Adv.
In WP 355/2010: Mr. K.K. Venugopal,Sr.Adv.
Mr. Wills Mathews,Adv.
....2/-
- 2 -
For Intervenor: Mr. Braj Kishore Mishra,Adv.
Ms. Aparna Jha,Adv.
Mr. Vikas Malhotra,Adv.Centre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

Mr. M.P. Sahay,Adv.
Mr. Abhishek Yadav,Adv.
Mr. Vikram,Adv.
Hon'ble the Chief Justice pronounced the judgement of the Bench comprising His Lordship, Hon'ble
Mr. Justice K.S. Panicker Radhakrishnan and Hon'ble Mr. Justice Swatanter Kumar.
The writ petitions are allowed with no order as to costs.
Application for intervention is dismissed.
          [ T.I. Rajput ]                [ Madhu Saxena ]
           A.R.-cum-P.S.                    Assistant Registrar 
[Signed reportable judgment is placed on the file.]Centre For Pil & Anr vs Union Of India & Anr on 3 March, 2011

