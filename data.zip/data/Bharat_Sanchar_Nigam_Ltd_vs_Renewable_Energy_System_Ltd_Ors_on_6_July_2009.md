Bharat Sanchar Nigam Ltd vs Renewable Energy System Ltd &
Ors on 6 July, 2009
Author: Rajiv Sahai Endlaw
Bench: Rajiv Sahai Endlaw
     *IN THE HIGH COURT OF DELHI AT NEW DELHI
+                OMP.Nos 174/2004 & 184/2004
%                                Date of decision:06.07.2009
BHARAT SANCHAR NIGAM LTD.                       ...... Petitioner
                       Through: Mr Chandan Kumar, Advocate
                               Versus
RENEWABLE ENERGY SYSTEM LTD & ORS ...... Respondents
                       Through: Mr Vikas Dutta and Mr. Manish Vaid,
                       Advocates for Respondent No.1 & Mr. Pradeep
                       Dewan, Advocate for Respondent No.2 Canara
                       Bank.
                                AND
CANARA BANK                                      ..... Petitioner
                       Through: Mr Pradeep Dewan, Advocate
                               Versus
BHARAT SANCHAR NIGAM LTD & Ors                 ...... Respondents
                       Through: Mr Chandan Kumar, Advocate for
                       Respondent No.1 and Mr. Vikas Dutta & Mr.
                       Manish Vaid, Advocates for Respondent No.2
                       Renewable Energy System Ltd.
CORAM :-
HON'BLE MR. JUSTICE RAJIV SAHAI ENDLAW
1.    Whether reporters of Local papers may
      be allowed to see the judgment?       No
2.    To be referred to the reporter or not?   NoBharat Sanchar Nigam Ltd vs Renewable Energy System Ltd & Ors on 6 July, 2009

3.    Whether the judgment should be reported
      in the Digest?                                 No
RAJIV SAHAI ENDLAW, J.
1. Both petitions under Section 34 of the Arbitration and Conciliation Act, 1996 are with respect to
the same arbitral award and are being taken up together for consideration.
2. Bharat Sanchar Nigam Ltd. (BSNL), the petitioner in OMP 174/2004 is for the present purpose,
the successor of the Department of Telecommunications (DOT) of the Government of India. M/s
Renewable Energy System Limited (RESL) which is respondent No.1 in OMP 174/2004 and the
respondent No.2 in OMP 184/2004 was the successful bidder in a tender floated by DOT for
manufacture of Solar Power Generating Systems (equipment) and for leasing the same to DOT. In
order to carry out the contract, RESL approached Canara Bank (Bank), the petitioner in OMP
184/2004 for grant of finance/credit facilities and it was inter alia agreed between the Bank and
RESL that after manufacturing the equipment, RESL shall sell the same to the Bank and the Bank
would, in turn, give them on lease to BSNL for a period of five years, on payment of lease money on
quarterly basis besides other charges. A tripartite agreement dated 19th February, 1998 between
DOT, RESL and Bank was entered into in this regard. The said agreement also contained an
arbitration clause providing for arbitration on any question, disputes or differences arising under
that agreement or in connection therewith of the Director General, DOT or his equivalent. In the
meanwhile, DOT was succeeded by BSNL as aforesaid. Disputes and differences having arisen,
RESL approached for appointment of arbitrator and the Respondent No.3 in each petition was
appointed as the sole arbitrator. The Bank also approached for appointment of arbitrator and also
filed its statement of claim in the arbitration already commenced between RESL and BSNL; the said
arbitration was clarified by BSNL to be of the claims of the Bank also. An award dated 24th
February, 2004 was published by the arbitrator.
3. The arbitrator in the said award has inter alia held:
i. that arbitration of claims of Bank against BSNL was maintainable in spite of dicta
of the Apex Court in ONGC Vs Collector of Central Excise 1995 Supp (4) SCC 541
laying down for reference of disputes between two Government bodies as Bank &
BSNL are, to the committee under the control of the Cabinet Secretary;
ii. that the arbitration agreement covered disputes not only qua the 1000 units of
equipment by then already delivered to BSNL but also qua the entire 9070 units of
equipment subject matter of the agreement;
iii. that RESL could not have offered 8070 units of equipment for testing/inspection
without BSNL issuing a purchase order having details of destination to RESL;
iv. that it was indeterminable on the information on hand, as to how much time
RESL would have needed to make the balance 8070 units of equipment afterBharat Sanchar Nigam Ltd vs Renewable Energy System Ltd & Ors on 6 July, 2009

purchase order with destination therefor had been placed by BSNL on RESL;
v. that BSNL had placed a clear lease order to supply to its destinations, whose
particulars were to be furnished by the BSNL separately, an exact and unchangeable
quantity of 9070 units of equipment under the tripartite agreement dated 19th
February, 1998 and the subsequent agreement dated 31st March/19th April, 2000
with respect to 1000 units of equipment was only a formality with respect to the 1000
units of equipment supplied/delivered and was not in supersession of the earlier
tripartite agreement dated 19th February, 1998 with respect to supply of entire 9070
units of equipment;
vi. that it was the BSNL which was at fault for non delivery of the remaining 8070
units of equipment and for this fault was liable under Section 54 of the Contract Act
to pay compensation for the losses suffered by RESL/Bank;
vii. that RESL was ready and willing to perform its part of the agreement for supply
of remaining 8070 units of equipment and was prevented from supplying the same
owing to the order dated 22nd May, 2001 of the Telecom Engineering Centre (TEC).
The arbitrator however while holding so also held that the precise extent of the
readiness of RESL could not be determined for want of evidence; viii. that the balance
8070 units of equipment could not be supplied by RESL owing to the BSNL having
failed to supply details of destination as provided in annexure II of the agreement; ix.
that the failure of the BSNL for making lease payments with respect to 1000 units of
equipment already supplied was owing to the default of the Bank in complying with
the necessary formalities in terms of the agreement in that regard and only on
compliance whereof the said payment could be released by BSNL; x. that the reasons
alleged by BSNL for not furnishing the particulars of destination for supply of
balance 8070 units of equipment were not valid;
xi. that RESL had not made any incorrect statement to BSNL, owing to which the
failure of BSNL to take delivery of balance 8070 units of equipment could be
justified. Consequently, it was held that BSNL was not justified in not taking delivery
of balance 8070 units of equipment and axiomatically the Bank and RESL had
become entitled to suitable compensation under the law from BSNL. The said finding
was, however, clarified with the observations that the precise liability of BSNL could
not be determined unless "the parties" offer satisfactory proof of losses allegedly
suffered by them and attributable directly to the default of BSNL; xii. that the balance
8070 units of equipment which RESL claimed to have kept ready for delivery to
BSNL, conformed to the technical specifications of BSNL and were obviously
end-use-specific and the likelihood of their usefulness for a different purpose and by
some user other than the BSNL could not be entirely ruled out without a technical
field survey. It was further held that this issue was quite irrelevant at that stage;Bharat Sanchar Nigam Ltd vs Renewable Energy System Ltd & Ors on 6 July, 2009

xiii. that RESL was not entitled to the relief of specific performance of directing BSNL
to take delivery of balance quantities for the reason of RESL having not proved that
the balance 8070 units of equipment actually stood manufactured by dates stipulated
in the agreement for delivery thereof and also for the reason of the relief of specific
performance being not maintainable in law for reason of monetary compensation
being an alternative remedy; xiv. that the claim of compensation of RESL could not
be determined with the available information and the award proposed the matter to
be investigated in detail by an expert committee comprising of nominees of each of
the three parties and an independent body; if such expert committee concludes that
any of the balance 8070 units of equipment were actually ready and only waiting for
destination details for inspection and dispatch as on 31st July, 1998, the liability of
BSNL for compensation be determined with respect thereto;
xv. Certain monetary claims of RESL were declined and with respect to yet other
claims it was held that unless further particulars supported by documents were
furnished by RESL, the same could not be adjudicated. Though RESL was held
entitled to costs, however, for the reason of it having not furnished all particulars and
proof of costs incurred, no award for costs of arbitration was made; privity of contract
was found between BSNL and the Bank with respect to the arrangement for leasing of
equipment but not with respect to sanction or disbursal of funds by the Bank to
RESL; though the Bank was held guilty of having failed to submit the requisite
documents for release of quarterly lease rentals with respect to 1000 units of
equipment supplied but otherwise it was held that RESL / Bank could not have taken
any other steps for mitigation of losses suffered by them;
xvi. Collusion between Bank and RESL to the detriment of the BSNL was ruled out;
xvii. An Award for Rs 266.06 lacs with respect to the quarterly lease rentals due for
1000 units of equipment supplied was passed against BSNL. However, BSNL was not
held liable for any interest or penalty for late payment for the reason of the Bank
having not complied with the necessary formalities for release of the said payment
though found to be overdue earlier. It was directed that upon compliance of
formalities, BSNL shall release the said payment within 30 days to the Bank;
xviii. The claim of the Bank on account of loss of tax benefit was held to be remote
and rejected;
xix. Cost of Rs 26,650/ incurred by the Bank towards the stamp paper for the award
only was awarded. The claim of the Bank for the remaining costs of arbitration was
rejected for want of proof; xx. The claims of the Bank against RESL were held to be
not arbitrable;
xxi. The summary of the award as given towards the end is as under:Bharat Sanchar Nigam Ltd vs Renewable Energy System Ltd & Ors on 6 July, 2009

"To sum up, the respondent DOT/BSNL is held guilty of breach of contract, and
hence liable to pay damages to the other two parties. Quantification of these damages
being not possible at present in the absence of authentic data, certain modalities to
ascertain the same have been suggested. The respondent is also liable, under the
lease agreements of 19.2.1998 and 19.4.2000, to pay the Lease Management Fee and
Quarterly Lease Rentals to the claimant Canara Bank. These have been quantified.
No costs for arbitration have been awarded, except reimbursement of expenditure on
stamp duty incurred by Canara Bank."
4. BSNL as well as the Bank having preferred these petitions, the stage for constitution of an expert
committee as suggested in the award did not arise.
5. BSNL has, in its petition, inter alia stated that due to change in government policy, procurement
of equipment with respect whereto the aforesaid tripartite agreement was entered into was stopped
and accordingly it could place destination details for supply of only 1000 units of equipment. The
challenged to the award by BSNL is limited to:
i. the arbitrator having entertained the disputes between BSNL and Bank and having
not referred the same to the committee under the control of the Cabinet Secretary;
ii. the failure of the arbitrator to give final arbitration award. iii. the suggestion in the
award of constitution of expert committee being beyond the tripartite agreement and
the terms of the reference and specially when the arbitrator had concluded that RESL
and the Bank had not proved their claims;
iv. the award being incomplete.
BSNL thus sought setting aside of the award to the aforesaid extent.
6. The challenge by the Bank to the award is limited to:
i. the finding of the arbitrator of the claims of the Bank against RESL being not
arbitrable before him;
ii. the finding of the arbitrator of the precise liability of BSNL for compensating the
Bank/ RESL being in detriminable on the basis of material on record;
iii. restricting the claim of the Bank for loss of profit only to the extent of actual
number of equipments manufactured and kept ready for delivery as on 31st July,
1998 by RESL. It is contended that the Bank having provided finance for the entire
9070 units to RESL was entitled to loss of profits from BSNL for the entire balance
quantity of 8070 units; iv. inconsistency in the award in, at page 45 holding that the
entire 8070 units could not at the relevant times be kept ready fabricated and that the
batteries had to be manufactured only 15 days prior to the submission thereof forBharat Sanchar Nigam Ltd vs Renewable Energy System Ltd & Ors on 6 July, 2009

testing and in other part of the award holding that it was for the expert committee to
decide as to how many units were kept ready by 31st July, 1998 by the RESL;
v. the finding of the Bank having defaulted in complying with the formality and in
submission of documents for release of quarterly lease rentals with respect to 1000
units of equipment supplied. It is contended that BSNL had in its reply to the
statement of claim not taken the said plea and had only taken the plea of having not
released payments owing to an order of the Calcutta High Court in a proceeding filed
by one Magma Leasing Company Ltd against RESL and had taken the said plea
subsequently as an afterthought. It is further contended that the Bank had at the
contemporaneous time also never contended that it was unable to release the
payment for the reason of any failure of the Bank to comply with the formalities. It is
further contended that the order of the Calcutta High Court had also come to an end
in the year 2001. It is also claimed that the lease rentals were due from 27th June,
1998 while the arbitrator had awarded the same w.e.f. 1st July, 1998.
7. RESL has not preferred any objections to the award. However, in the reply to both the petitions
RESL has also challenged the award to the extent, of being in determinative and negating its other
claims. However, the said replies of RESL cannot be treated to be a petition under Section 34 of the
Arbitration Act and are even not within the time prescribed in Section 34 (3) of the Act. The counsel
for the RESL during his oral submissions also has challenged the award. The counsel for RESL also
contended that the arbitrator after having held the BSNL liable for loss caused to RESL and Bank
ought to have determined the quantum of the said losses himself and urged that the matter should
be remitted for determination of the quantum of compensation. It was further contended that
without BSNL intimating the destination for delivery there could be no question of RESL keeping
the balance units ready for delivery. It was further contended that in any case the remission ought to
be only for determination of the quantum of liability of BSNL and the other findings ought not to be
disturbed. The counsel also cited judgments listed in index dated 18th September, 2008 but it is not
found relevant to deal with the same.
8. The counsel for BSNL during oral submissions pointed out it is also borne out from the record
that BSNL during the pendency of these proceedings had deposited the sum of Rs 266.06 lacs in this
court and which sum has since been ordered to be released to the Bank. The counsel for BSNL
further submitted, that the arbitrator found that RESL had not manufactured the balance 8070
units; that RESL has not challenged the award and thus the said finding in the award of RESL
having not manufactured the balance machineries has attained finality - the Bank is not competent
and has no locus to challenge the said findings. It is contended that in the aforesaid state of affairs
the challenge by BSNL is only to para 31 under issues 15-21 constituting a committee of experts. It
was further contended that the recourse, if any, of the Bank was against RESL and not against BSNL
and RESL has since been declared sick within the meaning of SICA, 1985 and it was only owing to
the sickness of RESL that the Bank was pursuing its claims against BSNL.
9. The counsel for the Bank has contended that the Bank has rendered financial assistance of over
Rs 12 crores to RESL; that the said finance was for the entire quantity of 9070 units of equipment;Bharat Sanchar Nigam Ltd vs Renewable Energy System Ltd & Ors on 6 July, 2009

that however the Bank had not received any payment in return; that the Bank does not know who is
at fault whether BSNL or RESL and had hence asked for an award against whichever of the two was
found to be at fault; that both the Bank and RESL had moved an application in the sitting held by
the arbitrator at Hyderabad for an inspection of balance quantity of equipments which were lying at
Hyderabad only but the arbitrator did not opt for the said inspection; that the arbitrator erred in not
awarding interest and penalty in terms of the agreement to the Bank against BSNL with respect to
1000 units of equipment already supplied; that there was inconsistencies in the award - while under
issue 24 it has been held that the Bank's claim for loss of profit in respect to balance 8070 units of
equipment was beyond ambit of arbitration, in para 31 under issues 15-21 direction for constitution
of expert committee had been given; that under Section 26 of the Act the arbitrator was entitled to
appoint an expert and if so desirous, ought to have first appointed an expert and thereafter
published the award; that in spite of liability of the BSNL being determined, the award did not
determine the quantum of liability. Lastly it was urged that the arbitrator erred in not adjudicating
the claims of Bank against RESL which fell within the ambit of arbitration clause in the tripartite
agreement.
10. The counsel for BSNL, in rejoinder, contended that the arbitrator is not a person steeped in law
and owing to that while holding that there was no evidence of balance 8070 units having been
manufactured and ready for delivery and which would have led to dismissal of the claims for
compensation, directed the constitution of an expert committee. It was contended that the said
direction was severable from the remaining award and on such severance the award otherwise was
valid. It was further contended that on the basis of available material neither RESL nor the Bank
was entitled to any other amount and fresh/further evidence could not be permitted to be led before
the expert committee suggested in the award.
11. A perusal of the objections of BSNL shows that BSNL has not objected to the finding in the award
insofar as holding BSNL to be in breach of the contract and holding BSNL liable for losses suffered
by RESL/Bank. The main contention of BSNL/its counsel is that the arbitrator having held
RESL/Bank not to have placed sufficient material before the arbitrator to prove the losses suffered
or the compensation to which they had become entitled, the arbitrator ought not to have given
directions for appointment of a committee and award to which extent only is sought to be set aside
by BSNL.
12. I am however unable to accept the aforesaid contention of BSNL. It is not as if the arbitrator has
gone through the evidence and held that RESL/Bank has not proved to have suffered any loss. On
the contrary, the arbitrator has left the said question undetermined. The loss to he Bank which has
released finance even for the remaining 8070 units of equipment to RESL is res upsa loquitor. The
arbitrator has also found the equipment to be specific for use of BSNL and not found RESL/Bank
guilty of not mitigating losses. The arbitrator himself has in the award noted that during the sitting
of the arbitrator at Hyderabad both RESL and the Bank had offered inspection of the remaining
8070 units which RESL was averring it had already manufactured and kept ready for delivery to
BSNL. BSNL opposed the said request. The arbitrator has not given any reason whatsoever as to
why said inspection was not undertaken. The arbitrator has not given enough weightage to the said
offer. The said offer lends one to believe that RESL was in a position to give inspection of balanceBharat Sanchar Nigam Ltd vs Renewable Energy System Ltd & Ors on 6 July, 2009

units. Moreover, I find that law does not require the goods required to be supplied to be kept in
readiness. All that that the law requires is that the party claiming compensation on account of
breach ought to prove that in the absence of the breach it was ready to perform its part of the
agreement so as to be entitled to a claim for loss of profit. All the said aspects have not been gone
into by the arbitrator and for the reason that the arbitrator did not contemplate the award to be the
culmination of the proceedings but intended a further inquiry in this respect. The award to the said
extent is found to be against law and public policy.
13. I find the aforesaid aspect to be no longer res integra. In National Highways Authority of India
Vs ITD Cementation India Ltd MANU/DE/9104/2007 (DB) the arbitral tribunal noted that
although the claimant had produced some documents, but on the basis thereof losses suffered could
not be worked out; certain other statements produced by the claimant in support of its claim were
also found to be lacking in details; the arbitrators held themselves at a loss to work out the claim and
in the circumstances declined to quantify the amount due to the claimant and granted a declaratory
award holding that the claimant was entitled to additional costs incurred by it and left the question
of quantification to be determined by National Highways Authority of India. It was contended by the
National Highways Authority of India in its objections to the said award that the award was
imperfect inasmuch as it left the question of quantification of the amount undecided. It was further
contended that the arbitrators having clearly observed that the material on record was insufficient to
enable them to determine the amount payable, the logical result which ought to have followed was a
rejection of the claim made before them and the arbitrator could not have followed the unusual
course of giving to the claimant a chance to produce material and to satisfy NHAI regarding
additional costs. The procedure adopted by the arbitrator was contended to be legally impermissible
as the arbitrators were duty bound to determine all questions in controversy and the exact amount,
if any.
14. The Division Bench of this court held that though ordinarily, failure on the part of the claimant
to substantiate its claims should result in rejection of the claim but it is not an invariable rule. It was
held that it was possible in certain situations to leave the actual quantification to be made by a party
or an agency to be appointed by the arbitrators on principles laid down by the arbitrators. The
Division Bench however in that case held that the facts thereof were not such where determination
of principle could result in quantification of the amount by a simple process of calculation. It was
held that determination of disputed questions of facts had to be at the hands of the arbitrators only
and could not be delegated to any other person or authority. It was further held that inasmuch as the
arbitrators had left the issues regarding quantification of the amount open but required the same to
be decided by NHAI which was the party to the dispute, they committed a mistake. Quantification of
the amount was held to be a major area of controversy between the parties. It was further held that
the claim could not be rejected in toto simply because the material was not sufficient and it was
necessary that the amount was quantified in spite of being left open for determination. Resultantly
the award was set aside and the matter remitted back to the arbitrators, limited to the issue of
quantification. The division Bench also gave additional opportunity to the parties to adduce
evidence on quantification before making a fresh award.Bharat Sanchar Nigam Ltd vs Renewable Energy System Ltd & Ors on 6 July, 2009

15. I am respectively bound by the aforesaid dicta of the Division Bench. Similarly, the Division
Bench of the Kerala High Court in Sulaikha Clay Mines Vs Alpha Clays AIR 2005 Kerala 3 held while
setting aside an award for procedural violation the court is empowered under Section 34(4) of the
Act to also change the arbitrator. I may add that I have also in Union of India Vs Modern
Laminators Ltd MANU/DE/1237/2008 held that the court is empowered in dealing with an
application under Section 34 of the Act to not only remit the matter back but also to modify the
award.
16. In the present case also I find that several disputed questions of fact will be entailed in
quantification of damages losses and determination thereof is in sole domain of arbitrators and
cannot be left to the committee proposed. From the findings of the arbitrator as summarized herein
above and to which there is no challenge, it cannot be said that the present is a case of no losses
having been suffered by RESL/Bank. In the aforesaid circumstances the objections of BSNL are not
found sustainable and accordingly OMP No. 174/2004 is dismissed. Consequently,
OMP.No.184/2004 insofar as seeking remission of the matter to the arbitrator is concerned has to
be allowed.
17. I may at this stage notice that though BSNL had also preferred objection qua the disputes
between the BSNL and the Bank being not arbitrable for the reason of being required to be referred
to the Committee under the control of the Cabinet Secretary, but the same was not pressed during
the arguments. Even otherwise, the award records that the said Committee was approached and
declined the request on the ground of the disputes being required to be resolved by arbitration. The
award cannot be faulted with on the said ground.
18. I also do not find any merit in the objection of BSNL of the arbitrator having found that RESL
had not manufactured the balance 8070 units and/or of the said finding having become final for the
reason of RESL having not challenged the award. Not only is the said finding of the arbitrator
inconsistent to other findings in the award, but as observed by me above, the question of
determination of compensation is to be determined irrespective of whether 8070 units were lying
ready for delivery or not. Moreover, the Bank being party to the agreement and being the real
affected party is even otherwise entitled to challenge the said finding and the failure of RESL to file
objections would not affect the rights of the Bank. The Apex Court in K.P. Poulose Vs. State of Kerala
1975 (2) SCC 236 has held that an inconsistent award is liable to be set aside by the court.
18.A The counsel for BSNL has relied upon:
i. Hind Builders Vs. U.O.I. AIR 1990 SC 1340 laying down that court cannot interfere
with possible interpretation of contract by arbitrator.
I do not find the same applicable. The arbitrator in holding in one part of award of
liability of BSNL being limited to the units of equipment kept ready or in appointing
expert committee has not interpreted any contract.Bharat Sanchar Nigam Ltd vs Renewable Energy System Ltd & Ors on 6 July, 2009

ii. MCD Vs. Jagan Nath Ashok Kumar AIR 1987 SC 2316 and UOI Vs. Santiram
Ghosh AIR 1989 SC 402, neither of which is also found relevant for the issues
involved.
19. As far as the other objections of the Bank to the award are concerned, firstly I do not find any
error apparent on the face of the award in the finding that the claims of the Bank against RESL were
not arbitrable. The interest of the Bank and RESL in the agreement containing the arbitration clause
was in unison. The purport of the arbitration agreement is of resolution of disputes by arbitration to
which BSNL is a party. It does not stand to reason as to why the officer of BSNL should be an
arbitrator in disputes between the RESL and the Bank. Moreover, it is the admitted position that
besides the agreement containing the arbitration clause, there are other documents between the
RESL and the Bank. The arbitrator himself has in the award referred to Bank having obtained an
indemnity from RESL. It is not the case of the counsel for the Bank that the said documents also
provided for arbitration by the officer of BSNL. The officer of BSNL has not given his consent to be
the arbitrator in the inter se disputes between the RESL and the Bank. In the circumstances the
arbitrator was justified in taking a view of the said inter se disputes between the Bank and RESL
being not arbitrable before him. The award also records that the counsel for the Bank had agreed
with the aforesaid stand of the arbitrator. I have perused the objections preferred by the Bank. I do
not find any statement therein that the said part has been erroneously recorded by the arbitrator or
that no such statement was given or stand taken by the counsel for the Bank before the arbitrator.
The counsel for the Bank having agreed before the arbitrator that the said inter se disputes were not
arbitrable is not entitled to now object to the same.
20. However, the objection of the Bank to the observations/finding of the arbitrator of the claim
against BSNL being limited to the extent of actual number of equipments manufactured and kept
ready is contrary to law. There is no such requirement in law. If Bank/RESL by evidence or
otherwise are able to establish before the arbitrator that but for the breach by BSNL they were in a
position to perform their part of the agreement, Bank/RESL would be entitled to compensation for
breach as also held by the arbitrator. The award to that effect is set aside.
21. However, I do not find the objection of the Bank to the award to the extent holding the Bank to
be in fault in complying with the formalities for release of the payments with respect to 1000 units
of equipment to be within the ambit of Section 34 of the Act. The said finding is factual in nature
and this court is not to sit in appeal over the award and no question of public policy is involved. The
said objection is thus dismissed. similarly no interference is called for in the finding as to the
amount due towards the said 1000 units of equipment.
22. Thus the award to the extent aforesaid is set aside and remitted back to the arbitrator. Since the
arbitrator was an officer of BSNL and may not now be in a portion to arbitrate, it is clarified that in
the event of the same arbitrator being unavailable for arbitration the arbitration be held by the
present incumbent in office. BSNL to intimate the particulars of arbitrator to other parties within 30
days of today. The arbitrator to render an award of the compensation payable by BSNL for breach of
contract. In consonance with the law laid down by the Division Bench of this court (supra) the
parties shall be entitled to adduce further evidence on the quantum to be determined by theBharat Sanchar Nigam Ltd vs Renewable Energy System Ltd & Ors on 6 July, 2009

arbitrator.
With the aforesaid directions, the petitions are disposed of leaving the parties to bear their own
costs.
RAJIV SAHAI ENDLAW (JUDGE) July 06, 2009 MBharat Sanchar Nigam Ltd vs Renewable Energy System Ltd & Ors on 6 July, 2009

