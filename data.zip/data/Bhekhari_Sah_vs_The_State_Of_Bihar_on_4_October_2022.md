Bhekhari Sah vs The State Of Bihar on 4 October, 2022
Author: Sanjay Karol
Bench: Chief Justice, S. Kumar
       IN THE HIGH COURT OF JUDICATURE AT PATNA
               Civil Writ Jurisdiction Case No.12514 of 2022
======================================================
   Sunil Kumar Son of Shyam Nandan Rai, Resident of Paharpur, Police
   Colony, Saheb Ka Ghar, P.S. - Anisabad, District- Patna.
                                                             ... ... Petitioner/s
                                      Versus
1.   The State of Bihar through the Chief Secretary, Government of Bihar, Patna.
2.   The Principal Secretary, Urban Development and Housing Department,
     Government of Bihar, Patna.
3.   The Deputy Secretary, Urban Development and Housing Department,
     Government of Bihar, Patna.
4.   The Secretary, State Election Commission, Sone Bhawan, Veer Chand Patel
     Marg, Patna.
                                                      ... ... Respondent/s
======================================================
                                    with
              Civil Writ Jurisdiction Case No. 13513 of 2022
======================================================
   Surendra Kumar Agrawal S/o Jagdish Chandra Agrawal Resident of
   Mohalla- Navratan Bazar, P.O. and P.S.- Sasaram, District- Rohtas at
   Sasaram.
                                                             ... ... Petitioner/s
                                      Versus
1.   The State of Bihar through the Chief Secretary, Government of Bihar, Patna.
2.   The Additional Chief Secretary, Urban Development and Housing
     Department, Government of Bihar, Patna.
3.   The State Election Commission, Sone Bhawan, Birchand Patel Path, Patna
     through the State Election Commissioner (Municipality).
4.   The State Election Commissioner (Municipality), The State Election
     Commission, Sone Bhawan, Birchand Patel Path, Patna.
5.   The Secretary, The State Election Commission, Sone Bhawan, Birchand
     Patel Path, Patna.
6.   The Divisional Commissioner, Patna Division, Patna.
7.   The District Magistrate-cum-District Election Officer (Municipality), Rohtas
     at Sasaram, District- Rohtas at Sasaram.
                                                    ... ... Respondent/s
======================================================Bhekhari Sah vs The State Of Bihar on 4 October, 2022

                                  with
            Civil Writ Jurisdiction Case No. 14193 of 2022
 Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
                                         2/86
    ======================================================
      Harsh Vardhan Narayan S/o Shivendra Narayan, Gram-Baksanda, Post-
      Bakdanda, Thana-Akbarpur, District-Nawada. Presently residing at Mayur
      Vihar Colony Lane-3, Near Bishop Scott School, Ward No. 3, Nagar
      Parishad-Sampatchak, P.S.-Ram Krishna Nagar, District-Patna.
                                                                 ... ... Petitioner/s
                                            Versus
  1.    The State of Bihar through the Principal Secretary, Urban Development and
        Housing Department, Bihar, Patna.
  2.    The Principal Secretary, Urban Development and Housing Department,
        Bihar, Patna.
  3.    The District Magistrate-cum-District Election Officer (Municipality), Patna.
  4.    The District Deputy Election Officer (Muncipality), Patna.
  5.    The State Election Commission through State Election Commissioner, Sone
        Bhawan, 3rd Floor, Birchand Patel Marg, Patna, Bihar.
  6.    The State Election Commissioner, Sone Bhawan, 3rd Floor, Birchand Patel
        Marg, Patna, Bihar.
  7.    The Secretary, State Election Commission, Sone Bhawan, 3rd Floor,
        Birchand Patel Marg, Patna, Bihar.
                                                           ... ... Respondent/s
   ======================================================
                                         with
                   Civil Writ Jurisdiction Case No. 14206 of 2022
   ======================================================
      Nitish Kumar Son of Mahaveer Mahto, Resident of Mohalla - Bihiya, P.S.-
      Bihiya, District - Bhojpur.
                                                                 ... ... Petitioner/s
                                            Versus
  1.    The State of Bihar through its Principal Secretary Urban Development
        Patna.
  2.    The State Election Commission through its Commissioner, Bihar, Patna.
  3.    The Secretary, State Election Commission Bihar, Patna.
  4.    The District Magistrate cum District Election Officer (Nagar Palika)
        Bhojpur.
  5.    The DCLR-cum-returning Officer, Piro, Bhojpur.
  6.    The B.D.O.-cum-Additional Returning Officer, Bihiya, Bhojpur.
                                              ... ... Respondent/sBhekhari Sah vs The State Of Bihar on 4 October, 2022

   ======================================================
                               with
 Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
                                         3/86
                  Civil Writ Jurisdiction Case No. 14207 of 2022
    ======================================================
      Suresh Prasad Son of Late Ram Das Resident of Mohalla- Kawaiya Road,
      Panchayat Nagar, P.O. and P.S.- Lakhisarai, Block- Lakhisarai, District-
      Lakhisarai.
                                                                 ... ... Petitioner/s
                                            Versus
  1.    The State of Bihar Through the Chief Secretary, Government of Bihar, Main
        Secretariat, Bailey Road, Patna- 800014.
  2.    The Chief Electoral Officer Office of Chief Electoral Office, Bihar, 7-Sardar
        Patel Marg, Mangles Road, Bihar, Patna.
  3.    The State Election Commission, Bihar Sone Bhawan, 3rd Floor, Birchand
        Patel Marg, Patna- 800001, through its Commissioner.
  4.    The District Magistrate, Lakhisarai-cum- District Election Officer
        Lakhisarai.
                                                          ... ... Respondent/s
   ======================================================
                                        with
                  Civil Writ Jurisdiction Case No. 14219 of 2022
   ======================================================
      Sanjay Kumar Kejriwal Son of Parmeshwar Lal Kejriwal Resident of
      Jawahar Lal Road, Muzaffarpur, P.O.-Head Post Office, P.S. Muzaffarpur
      Town, District-Muzaffarpur.
                                                                 ... ... Petitioner/s
                                            Versus
  1.    The State of Bihar through the Chief Secretary, Government of Bihar, Patna.
  2.    The Additional Chief Secretary, Urban Development and Housing
        Department, Government of Bihiar, Patna.
  3.    The State Election Commission (Municipality), Sone Bhawan, Birchand
        Patel Path, Patna through the State Election Commissioner.
  4.    The State Election Commissioner. The State Election Commission
        (Municipality), Sone Bhawan, Birchand Patel Path, Patna.
  5.    The Secretary, The State Election Commissioner. (Municipality), Sone
        Bhawan, Birchand Patel Path, Patna.
  6.    The Diistrict Magistrate-Cum-District Election Officer (Municipality),
        Muzaffarpur, Dstrict-Muzaffarpur.
                                                       ... ... Respondent/sBhekhari Sah vs The State Of Bihar on 4 October, 2022

   ======================================================
                                     with
               Civil Writ Jurisdiction Case No. 14234 of 2022
 Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
                                         4/86
   ======================================================
      Firoj Alam son of Anvar Ahamad Resident of Mohalla- Azad Nagar,
      Mahisaudhi, P.O. and P.S. Jamui, District- Jamui.
                                                                  ... ... Petitioner/s
                                            Versus
  1.    The State of Bihar through the Chief Secretary, Government of Bihar, Patna.
  2.    The Additional Chief Secretary, Urban Development and Housing
        Department, Government of Bihar, Patna.
  3.    The State Election Commission (Municipality), Sone Bhawan, Birchand
        Patel Path, Patna through the State Election Commissioner.
  4.    The State Election Commissioner, The State Election Commission
        (Municipality), Sone, Bhawan, Birchand Patel Path, Patna.
  5.    The Secretary, The State Election Commission (Municipality), Sone
        Bhawan, Birchand Patel Path, Patna.
  6.    The District Magistrate-cum-District Election Officer (Municipality), Jamui,
        District- Jamui.
                                                         ... ... Respondent/s
   ======================================================
                                       with
                 Civil Writ Jurisdiction Case No. 14240 of 2022
   ======================================================
      Ujjawal Kumar Son of Anil Kumar Singh Resident of Village- Shanti Bihar
      Colony, Near- Shiv Mandir, Chandli, Aurangabad, Bajauli, District-
      Aurangabad, Bihar- 824102.
                                                                  ... ... Petitioner/s
                                            Versus
  1.    State Election Commission, Bihar through the Secretary, Government of
        Bihar, at Patna.
  2.    Secretary, State Election Commission, Bihar at Patna.
  3.    Principal Secretary, Bihar Urban and Development Housing Department,
        Government of Bihar at Patna.
  4.    Under Secretary, Urban Development             and   Housing      Department,
        Government of Bihar at Patna.
  5.    Commissioner, Gaya Division, Gaya, District- Gaya.
  6.    District Magistrate-cum-District Election      Officer,    (Nagar     Parisad),
        Aurangabad, District- Aurangabad.Bhekhari Sah vs The State Of Bihar on 4 October, 2022

                                              ... ... Respondent/s
   ======================================================
                               with
 Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
                                         5/86
                  Civil Writ Jurisdiction Case No. 14241 of 2022
   ======================================================
      Gautam Kumar Son of Sri Gulab Singh, Resident of Village- Repura Sirsa,
      P.O. Baidyanathpur, P.S. Sitamarhi, District- Nawada.
                                                                ... ... Petitioner/s
                                            Versus
  1.    The State of Bihar through the Chief Secretary, Government of Bihar, Patna.
  2.    The Additional Chief Secretary, Urban Development and Housing
        Department, Government of Bihar, Patna.
  3.    The State Election Commission (Municipality), Sone Bhawan, Birchand
        Patel Path, Patna through the State Election Commissioner.
  4.    The State Election Commissioner, The State Election Commission
        (Municipality), Sone Bhawan, Birchand Patel Path, Patna.
  5.    The Secretary, The State Election Commission (Municipality), Sone
        Bhawan, Birchand Patel Path, Patna.
  6.    The District Magistrate-cum-District Election Officer (Municipality),
        Nawada, District- Nawada.
                                                          ... ... Respondent/s
  ======================================================
                                         with
                  Civil Writ Jurisdiction Case No. 14242 of 2022
======================================================
     Narayan Singh son of Jagdish Singh, Resident of Village- Sahidih, Ward
     No. 3, P.O. and P.S. Nauhatta, District- Saharsa.
                                                                ... ... Petitioner/s
                                            Versus
  1.    The State of Bihar through the Chief Secretary, Government of Bihar, Patna.
  2.    The Additional Chief Secretary, Urban Development and Housing
        Department, Government of Bihar, Patna.
  3.    The State Election Commission (Municipality), Sone Bhawan Birchand
        Patel Path, Patna through the State Election Commissioner.
  4.    The State Election Commissioner, The State Election Commission
        (Municipality), Sone Bhawan Birchand Patel Path, Patna.
  5.    The Secretary, The State Election Commission (Municipality), Sone Bhawan
        Birchand Patel Path, Patna.
  6.    The District Magistrate-cum-District Election Officer (Municipality),
        Saharsa, District- Saharsa.Bhekhari Sah vs The State Of Bihar on 4 October, 2022

                                              ... ... Respondent/s
   ======================================================
 Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
                                         6/86
                                        with
                  Civil Writ Jurisdiction Case No. 14245 of 2022
   ======================================================
      Sanjeet Kumar Singh S/o Sri Vishnu Vijay Singh Resident of Ward No.-
      33, Rajputana Muhalla, Dehri- Dalmia Nagar, Rohtas, Sasaram.
                                                                 ... ... Petitioner/s
                                            Versus
  1.    The State of Bihar Through the Chief Secretary, Government of Bihar,
        Patna.
  2.    The Principal Secretary, Urban Development and Housing Department,
        Government of Bihar, Patna.
  3.    The State Election Commission, Bihar, Sone Bhawan, Bir Chand Patel
        Marg, Patna through the State Election Commissioner, Bihar.
  4.    The District Election Officer-cum- District Magistrate, Rohtas.
                                                          ... ... Respondent/s
  ======================================================
                                        with
                  Civil Writ Jurisdiction Case No. 14246 of 2022
    ======================================================
  1. Om Prakash Singh S/o Anil Kumar Singh R/o Near Police Line Middle
       School, Shanti Lodge, P.S. Rampur, Gaya Bihar 823001.
  2.    Rajesh Kumar Singh S/o Ram Uchit Singh R/o Jethian Kothi, Lala Babu
        Road, Maharani Road, P.S.- Delha, Gaya Bihar 823002.
  3.    Akhoury Onkar Nath @ Mohan Shrivastva S/o Late Akhoury Bhola Nath
        R/o New Godown, Mode, P.S. Kotwali, District- Gaya, Bihar- 823001.
                                                                 ... ... Petitioner/s
                                            Versus
  1.    The State of Bihar through Principal Secretary, Urban Development and
        Housing Department, Government of Bihar, Patna.
  2.    The Principal Secretary, Urban Development and Housing Department,
        Government of Bihar, Patna.
  3.    The State Election Commission, Bihar, Through the State Election
        Commission, Patna Bihar- 800001.
  4.    The Gaya Municipal Corporation, Through its Municipal Commissioner,
        Gaya- 823001 (Bihar).
                                                      ... ... Respondent/sBhekhari Sah vs The State Of Bihar on 4 October, 2022

 ======================================================
                                    with
              Civil Writ Jurisdiction Case No. 14247 of 2022
======================================================
 Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
                                         7/86
       Gulfisana Daughter of Mohammad Ezahar, Resident of Village-
       Ababakarpur Kowahi, Police Station - Patepur, District - Vaishali.
                                                                 ... ... Petitioner/s
                                            Versus
  1.    The State of Bihar through the Chief Secretary, Govt. of Bihar, Patna.
  2.    The Principal Secretary, Urban Development and Hosing Department, Govt.
        of Bihar, Patna.
  3.    The Deputy Secretary Urban Development and Housing Department, Govt.
        of Bihar, Patna.
  4.    The Secretary, State Election Commission Sone Bhawan, Veerchand Patel
        Marg, Patna.
                                                        ... ... Respondent/s
======================================================
                                      with
                Civil Writ Jurisdiction Case No. 14249 of 2022
======================================================
  1. Bhekhari Sah Son of Kedar Sah, Resident of Areraj, P.O. Areraj, District
     East Champaran, Bihar 845411.
  2.    Om Prakash Sharma, Son of Bhup Sharma, Resident of Ward no. 6, Sharma
        Tola, Areraj, District East Champaran, Bihar 845411.
  3.    Deepak Kumar Tiwari, Son of Tripurari Sharan, Resident of ward no. 11,
        Barwa, Areraj, District East Champaran, Bihar 845411.
  4.    Rajnish Kumar, Son of Mohan Giri, Resident of ward no. 3, Areraj, District
        East Champaran, Bihar 845411.
                                                                 ... ... Petitioner/s
                                            Versus
  1.    The State of Bihar through the Chief Secretary, Government of Bihar, Patna.
  2.    Principal Secretary Urban Development and Housing Department,
        Government of Bihar, Patna.
  3.    The Joint Secretary, Urban Development and Housing Department
        Government of Bihar, Patna.
  4.    The Divisional Commissioner, Tirhut Division, Muzaffarpur.
  5.    The District Magistrate, East Champaran.
  6.    State Election Commission through its Secretary, 3rd floor, Sone Bhawan,
        Beerchand Patel Path, Patna.
  7.    Secretary, State Election Commission, 3rd floor, Sone Bhawan, BeerchandBhekhari Sah vs The State Of Bihar on 4 October, 2022

        Patel Path, Patna.
                                                               ... ... Respondent/s
 Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
                                         8/86
 ======================================================
                                       with
                 Civil Writ Jurisdiction Case No. 14303 of 2022
 ======================================================
  1. Mahanand Sahni Son of Jagdish Sahni, Resident of Village Madhuban, P.O.
      Chopra, Ram Nagar, P.S. Jankinagar, District Purnia, Bihar 854102
  2.    Birendra Prasad Yadav, Son of Bhuvaneshwari Yadav, Resident of Ward No.
        4, Khunt, Ramnagar Pharsahi, District- Purnia, Bihar 854102
  3.    Sudarshan Kumar, Son of Dinesh Prasad Yadav, Resident of Ward No. 4,
        Khunt, Ramnagar Pharsahi, District Purnia, Bihar 854102.
                                                                   ... ... Petitioner/s
                                            Versus
  1.    The State of Bihar through the Chief Secretary, Government of Bihar, Patna.
  2.    Principal Secretary Urban Development and Housing Department,
        Government of Bihar, Patna.
  3.    The Joint Secretary, Urban Development and Housing Department,
        Government of Bihar, Patna.
  4.    The Divisional Commissioner, Purnia Division, Purnia.
  5.    The District Magistrate, Purnia.
  6.    State Election Commission through its Secretary, 3rd Floor, Sone Bhawan,
        Beerchand Patel Path, Patna.
  7.    Secretary, State Election Commission, 3rd Floor, Sone Bhawan, Beerchand
        Patel Path, Patna.
                                              ... ... Respondent/s
   ======================================================
       Appearance :
       (In Civil Writ Jurisdiction Case No. 12514 of 2022)
       For the Petitioner/s      :       Mr. Mrigank Mauli, Sr. Advocate
                                         Mr.Rajeev Ranjan, Advocate
                                         Mr. Dayanand Singh, Advocate
                                         Mr. Nagdeo Choubey, Advocate
                                         Mr. Dhananjay Kashyap, Advocate
                                         Ms. Pallavi Trivedi, Advocate
                                         Mr. Amit Shrivastava, Sr. Advocate
                                                          (Amicus Curiae)
       For the State             :       Mr. Vikash Singh, Sr. Advocate
                                         Mr. Lalit Kishore, AG
                                         Mr. Pawan Kumar (A.C. to A.G.)
                                         Mr. Anmol Chandan, Advocate
                                         Ms. Deepika Kaha, AdvocateBhekhari Sah vs The State Of Bihar on 4 October, 2022

                                         Mr. Kumar Shanu, Advocate
       For G.M.C.                        Mr. Ravindra Kumar Priyadarshi, Advocate
       For State Election Commission: Mr. Rajendra Narain, Sr. Advocate
                                         Mr. Sanjeev Nikesh, Advocate
                                         Mr. Girish Pandey, Advocate
 Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
                                         9/86
       (In Civil Writ Jurisdiction Case No. 13513 of 2022)
       For the Petitioner/s :             Mr. S.B.K. Mangalam, Advocate
                                          Mr.Awnish Kumar, Advocate
                                          Mr. Kumar Gaurav, Advocate
                                          Mr. Amit Shrivastava, Sr. Advocate
                                                          (Amicus Curiae)
       For the Respondent/s      :         Mr.Kinkar Kumar, SC-9
                                           Mr. Sanjeev Nikesh, Advocate
       (In Civil Writ Jurisdiction Case No. 14193 of 2022)
       For the Petitioner/s              : Mr. Siddhartha Prasad, Advocate
                                           Mr.Shashi Shekhar Kumar Prasad, Advocate
                                           Mr. Prashant Kumar Sinha, Advocate
                                           Mr. Sunit Kumar, Advocate
       For the State             :         Mr. Kinkar Kumar, SC-9
       For State Election Commission: Mr. Rajendra Narain, Sr. Advocate
                                           Mr. Sanjeev Nikesh, Advocate
                                           Mr. Girish Pandey, Advocate
       (In Civil Writ Jurisdiction Case No. 14206 of 2022)
       For the Petitioner/s      :        Mr.Sunil Kumar Yadav, Advocate
                                          Mr. Rajesh Kumar, Advocate
                                          Mr. Jaishree Kumar, Advocate
       For the Respondent/s      :        Mr.Yogendra Prasad Sinha, AAG-7
                                          Mr. Sanjeev Nikesh, Advocate
       (In Civil Writ Jurisdiction Case No. 14207 of 2022)
       For the Petitioner/s              : Mr.Ajay Prasad, Advocate
                                            Mr. Kaushal Kumar, Advocate
       For the State                     : Mr.Subhash Prasad Singh, GA-3
       For State Election Commission : Mr. Rajendra Narain, Sr. Advocate
                                            Mr. Sanjeev Nikesh, Advocate
                                            Mr. Girish Pandey, Advocate
       (In Civil Writ Jurisdiction Case No. 14219 of 2022)
       For the Petitioner/s      :         Mr. S.B.K. Mangalam, Advocate
                                           Mr.Awnish Kumar, Advocate
       For the Respondent/s      :         Mr.Yogendra Pd. Sinha, AAG-7
       (In Civil Writ Jurisdiction Case No. 14234 of 2022)
       For the Petitioner/s      :        Mr. S.B.K. Mangalam, Advocate
                                          Mr.Awnish Kumar, Advocate
       For the Respondent/s      :        Mr.Kinkar Kumar, SC-9
                                          Mr. Sanjeev Nikesh, AdvocateBhekhari Sah vs The State Of Bihar on 4 October, 2022

       (In Civil Writ Jurisdiction Case No. 14240 of 2022)
       For the Petitioner/s      :       Mr. Sumeet Kumar Singh, Advocate
                                         Ms.Alka Singh, Advocate
                                         Mr. Satyendra Prasad Singh, Advocate
       For the State             :       Mr.Subhash Pd. Singh, GA-3
        For State Election Commission: Mr. Rajendra Narain, Sr. Advocate
                                         Mr. Sanjeev Nikesh, Advocate
                                         Mr. Girish Pandey, Advocate
       (In Civil Writ Jurisdiction Case No. 14241 of 2022)
       For the Petitioner/s      :       Mr. S.B.K. Mangalam, Advocate
                                         Mr.Awnish Kumar, Advocate
                                         Mr. Kumar Gaurav, Advocate
                                         Ms. Anita Kumari, Advocate
       For the Respondent/s      :       Mr.Yogendra Prasad Sinha,AAG-7
 Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
                                        10/86
                                        Mr. Sanjeev Nikesh, Advocate
       (In Civil Writ Jurisdiction Case No. 14242 of 2022)
       For the Petitioner/s      :       Mr. S.B.K. Mangalam, Advocate
                                         Mr. Krishna Chandra, Advocate
                                         Mr.Awnish Kumar, Advocate
       For the Respondent/s      :       Mr.Yogendra Pd. Sinha, AAG-7
                                         Mr. Sanjeev Nikesh, Advocate
       (In Civil Writ Jurisdiction Case No. 14245 of 2022)
       For the Petitioner/s      :       Mr. Mrigank Mouli, Sr. Advocate
                                         Mr. Avinash Kumar, Advocate
                                         Mr.Krishna Chandra, Advocate
       For the Respondent/s      :       Mr. Vikash Singh, Sr. Advocate
                                         Mr. Lalit Kishore, A.G.
                                         Mr.Yogendra Pd. Sinha, AAG-7
       For the State Election Commission: Mr. Rajendra Narain, Sr. Advocate
                                         Mr. Sanjeev Nikesh, Advocate
       (In Civil Writ Jurisdiction Case No. 14246 of 2022)
       For the Petitioner/s      :       Ms. Meenakshi Arora, Sr. Advocate
                                         Mr. Y. V. Giri, Sr. Advocate
                                         Mr. Rahul Shyam Bhandari, Advocate
                                         Mr.Dayanand Singh, Advocate
                                         Mr. Dhananjay Kashyap, Advocate
                                         Ms. Pallavi Trivedi, Advocate
                                         Mr. Nagdeo Choubey, Advocate
       For the Respondent/s      :       Mr.Subhash Pd. Singh, GA-3
                                         Mr. Rabindra Kumar Priyadarshi, Advocate
       For State Election Commission: Mr. Rajendra Narain, Sr. Advocate
                                         Mr. Sanjeev Nikesh, Advocate
                                         Mr. Girish Pandey, AdvocateBhekhari Sah vs The State Of Bihar on 4 October, 2022

       (In Civil Writ Jurisdiction Case No. 14247 of 2022)
       For the Petitioner/s      :       Mr. Manohar Prasad Singh, Advocate
                                         Mr. Samir Kumar Sinha, Advocate
                                         Mr.Prem Prakash Poddar, Advocate
       For the State             :       Mr. Lalit Kishore, AG
                                         Mr.Subhash Prasad Singh, GA-3
       (In Civil Writ Jurisdiction Case No. 14249 of 2022)
       For the Petitioner/s      :       Mr.Ravi Ranjan, Advocate
                                         Mr. Raja Kumar, Advocate
                                         Ms. Suruchi Priya, Advocate
       For the Respondent/s      :       Mr.Abbas Haider, SC-6
                                         Mr. Sanjeev Nikesh, Advocate
       (In Civil Writ Jurisdiction Case No. 14303 of 2022)
       For the Petitioner/s      :       Mr.Rajeev Kumar Singh, Advocate
                                         Mr. Prabhojot Singh, Advocate
                                         Mr. Gyanendra Kumar Diwakar, Advocate
                                         Mr. Pranab Kumar, Advocate
       For the Respondent/s      :       Mr.Yogendra Pd. Sinha, AAG-7
                                         Mr. Sanjeev Nikesh, Advocate
    ======================================================
                 Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
                                                        11/86
                       CORAM: HONOURABLE THE CHIEF JUSTICE
                               and
                               HONOURABLE MR. JUSTICE S. KUMAR
                                    CAV JUDGMENT
                       (Per: HONOURABLE THE CHIEF JUSTICE)
                         Date : 04-10-2022
                                    The short point which arises for consideration in
                        these petitions is as to whether the following three fold test,
                        as elucidated by a Bench headed by Hon'ble Dr. Justice D.Y.
                        Chandrachud vide order dated 19.09.2022 passed in Sunil
                        Kumar v. The State of Bihar & Ors.1 stands followed and
                        complied with in the conduct of election to the numerous
                        "Municipalities" in the State of Bihar or not?
                                               "(i). Having a dedicated commission to
                                     conduct an empirical inquiry into the nature andBhekhari Sah vs The State Of Bihar on 4 October, 2022

                                     implication of backwardness in relation to local bodies;
                                               (ii)      Specification of the proportion of
                                     reservation required in light of the recommendations of
                                     the Commission; and
                                               (iii) Observance of the limit of 50% on
                                     reservations."
                                    2. The test is based on the principles enunciated by
                        Hon'ble the Apex Court in Sunil Kumar1; K. Krishna
                        Murthy & Ors. v. Union of India & Ors. 2; Vikas
1
    Special Leave to Appeal (C) No(s). 16081/2022
2
    (2010)7 SCC 202
               Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
                                                      12/86
                      Kishanrao Gawali v. State of Maharashtra,3; (4) Suresh
                      Mahajan v. State of M.P.,4; Rahul Ramesh Wagh v. The
                      State of Maharashtra,5; Manmohan Nagar v. The State of
                      Madhya Pradesh,6.
                                  3. If the finding of this Court is that the triple test
                      condition is not complied with, the seats reserved for
                      OBC/EBC Category shall be declared as open category seats
                      and elections to the said seats will be carried out in that
                      effect.
                                  4. A brief background to the passing of the order
                      dated 19.09.2022 in Sunil Kumar1.
                                  5. In Bihar, with the completion of its five year
                      term, elections to all the Municipalities (various MunicipalBhekhari Sah vs The State Of Bihar on 4 October, 2022

                      Bodies) as constituted under the Bihar Municipal Act, 2007
                      (hereinafter referred to as the Municipal Act) were due to be
                      held in June 2022. Prior thereto, certain amendments were
                      brought in the Municipal Act.
                                  6. For conducting the elections, the Bihar State
                      Election Commission (hereinafter referred to as the "Election
                      Commission")         sought      certain       clarification   from   the
                      Government of Bihar (referred to as the 'Government') vide
3
  (2021) 6 SCC 73
4
  2022 SCC OnLine SC 589
5
  Special Leave to Appeal (C) No)s). 19756/2021
6
  SLP (C) No. 20734/2021
 Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
                                        13/86
        communication dated 04.01.2022 (Page 280); 24.01.2022
        (Page 281); 28.01.2022 (Page 292); 28.03.2022 (Page 303).
        Reference of direction in the cases referred supra was made
        therein.
                    7. Based on a legal opinion, consciously, the
        Government vide Communication No. 850 dated 01.04.2022
        (Page No. 66) directed the Election Commission to proceed
        with the elections. Nonetheless, later, vide communication
        dated 20.04.2022; 11.05.2022 and 16.06.2022 (Page No. 306,
        307 and 323 respectively), the position of law enunciated by
        Hon'ble the Supreme Court was reiterated by the Election
        Commission.Bhekhari Sah vs The State Of Bihar on 4 October, 2022

                    8. Well, what transpired thereafter is not clear, but,
        vide communication dated 19.08.2022 (Page 92), the Election
        Commission asked all the Divisional Commissioners and
        District       Magistrate-cum-District            Election     Officer
        (Municipality) of the State to undertake the "exercise of
        reservation      and     allotment       of    seats   for   Scheduled
        Caste/Scheduled Tribe/Other Backward Caste/Women for the
        post of Councillors in 172 newly formed/reversed/area
        expanded and in 10 previous Municipalities."
 Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
                                        14/86
                    9. Assailing the Communication No. 850 dated
        01.04.2022
(Page-66), as also praying for a writ of mandamus for the authorities to comply with the dicta laid
down by Hon'ble the Apex Court, on 26 th of August, 2022, petitioner Sunil Kumar (CWJC No.
12514 of 2022) filed the instant petition. In effect, the petitioner wanted the elections to the
Municipal Body i.e. Patna Nagar Nigam, to be conducted without providing reservation to the
Backward Class Category, for it be in breach of the three-fold test. In the absence of reservation, the
seats would be left open for General Category.
10. When the instant petition was firstly taken up on 2nd of September, 2022, notice was issued
with the direction to the Government and the Election Commission to file response within two
weeks. However, pending adjudication, on 9th of September, 2022 (Page-116) the Election
Commission issued a notification fixing the schedule for elections. In terms thereof, elections to all
the "municipalities" within the State of Bihar are scheduled to be held on 10th and 20th of October,
2022. Also, vide communication dated 8th of September, 2022, the posts of Patna High Court CWJC
No.12514 of 2022 dt.04-10-2022 Deputy Chief Councillor of Municipalities are reserved for
specified categories.
11. Inviting attention of all such fact(s), petitioner preferred a Special Leave Petition (SLP), which
was disposed of vide order dated 19.09.2022 in Sunil Kumar1 with a direction to this Court to take
up the matter in the week ending 23rd September, 2022.
12. In the intervening period, several other petitions were filed, inter alia, seeking the very same and
similar action qua other orders/notifications, dealing with other Municipal Bodies. Consequently,Bhekhari Sah vs The State Of Bihar on 4 October, 2022

on 20th of September, 2022, when this matter was taken up, parties jointly prayed for an
adjournment and, as such, all the petitions were posted for hearing on 22.09.2022, on which date
the petitioners were permitted to amend their pleadings and the State of Bihar permitted to
withdraw its affidavit filed in terms of the statement made in Sunil Kumar1 and file afresh.
13. In the original petition filed on 26.08.2022, in which we issued notice on 02.09.2022, an
amendment petition is filed in C.W.J.C. No. 12514 of 2022, titled as Sunil Kumar v. The State of
Bihar & Ors., the Government and the Election Commission have filed composite but separate Patna
High Court CWJC No.12514 of 2022 dt.04-10-2022 affidavits dealing with all the issues raised in
these batch of writ petitions.
14. All the learned counsel for the parties were heard on 28.09.2022 and on 29.09.2022, when the
judgment reserved.
       RESERVATION    FOR    OBC                              AND       ITS
       CONSTITUTIONAL STATUS
15. With the insertion of Part IX-A in the Constitution of India, by way of Constitution 74 th
Amendment Act, 1992 with effect from 1 st of June, 1993, the process of "democratic
decentralization, greater accountability between the citizens" and the "empowerment of the weaker
sections" a scheme of a hierarchical structure of elected local bodies, was initiated. For a notified
municipal area, a Municipality, be it the Nagar Panchayat for a transitional area; Municipal Council
for smaller urban areas; and a Municipal Corporation for larger urban areas, were required to be
constituted in a State.
16. To similar effect, for the Rural Area was the insertion of Part-IX of in the Constitution of India
under Constitution 73rd Amendment Act, 1992, notified with effect from 24th of April, 1993.
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
17. Article 243-D of Part-IX and Article 243-T of Part IX-A provides for reservation of seats in the
bodies for-
(a) Scheduled Castes
(b) Scheduled Tribes and
(c) Backward Class Citizens.
18. The Constitutional amendment was brought to ensure fair representation of social diversity in
the composition of elected local bodies to contribute to the empowerment of the traditionally weaker
sections in society. In so far, reservation of seats in favour of Scheduled Castes and Scheduled Tribes
candidates is concerned, it has to be based on the proportion of the population belonging to theseBhekhari Sah vs The State Of Bihar on 4 October, 2022

categories and the total population of the area in question.
19. Both Article 243-D (6) (Part-IX) and 243-T(6) (Part-IX) enable and empower the State
Legislators to reserve seats including Chairperson, in favour of "Backward Class Citizens".
20. Upholding the validity of the aforesaid amendments to the Constitution, in K. Krishna Murthy2,
the Court held that Articles 243-D and 243-T form a distinct and independent constitutional basis
for reservations in local self- government institutions. The nature and purpose are different and
distinct from the reservation policies designed to improve Patna High Court CWJC No.12514 of
2022 dt.04-10-2022 access to higher education and public employment as contemplated under
Articles 15(4) and 16(4). The principles evolved for conferring the benefits of reservation as
contemplated in the latter could not be "mechanically applied" in the context of reservations to the
former. On this issue, the opinion is extracted as under:
"51. Before addressing the contentious issues, it is necessary to examine the
overarching considerations behind the provisions for reservations in elected local
bodies. At the outset, we are in agreement with Shri Rajeev Dhavan's suggestion that
the principles that have been evolved for conferring the reservation benefits
contemplated by Articles 15(4) and 16(4) cannot be mechanically applied in the
context of reservations enabled by Article 243-D and 243-T. In this respect we
endorse the proposition that Articles 243-D and 243-T form a distinct and
independent constitutional basis for reservations in local self- government
institutions, the nature and purpose of which is different from the reservation
policies designed to improve access to higher education and public employment, as
contemplated under Articles 15(4) and 16(4) respectively."
(Emphasis supplied)
21. Further, in the domain of political participation, there cannot be any objective parameters for
determining the likelihood of being elected to represent the institutions at any level, and as such, in
Paragraph 54 of the report, it was Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
observed that: "When it comes to creating a level playing field for the purpose of elections to local
bodies, backwardness in the social and economic sense can indeed be one of the criteria for
conferring reservation benefits."
22. However, it clarified that-
(a) The objective of democratic decentralization, inter alia, was to make governance
participatory; inclusive;
and accountable to the weaker sections of the society; (Para
58)Bhekhari Sah vs The State Of Bihar on 4 October, 2022

(b) Reservation in local self Government was intended to directly benefit the community as a whole
rather the elected representative; (Para 58)
(c) Thus, negating the plea for exclusion of creamy layer in the context of political representation;
(Para 58)
(d) The State Legislatures, in its discretion, could design and confer benefits in favour of Backward
Classes. (Para 58);
(e) The identification of backward classes for the purpose of reservation, being an executive
function, was required to be carried out by a dedicated commission appointed to conduct a rigorous
empirical inquiry into Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 the nature and
implications of backwardness with such policies to be reviewed periodically, to guard against
overbreadth. (Para 61)
(f) Groups conferred the benefit of reservation in the domain of education and employment need
not necessarily require reservations in the sphere of local self- government, for "barriers to political
participation are not of the same character". (Para 63).
(g) Chairpersons in Panchayats and Municipalities are reserved as a measure of "protective
discrimination", enabling the weaker sections to assert their voice against the entrenched interests
at the local level, for the pattern of disadvantage and discrimination suffered by them are more
pervasive at the local level. (Para 74).
23. The opinion resulted in the formation of the following conclusions:-
"82. In view of the above, our conclusions are:
(i) The nature and purpose of reservations in the context of local self-government is
considerably different from that of higher education and public employment. In this
sense, Article 243-D and Article 243-T form a distinct and independent
constitutional basis for affirmative action and the principles that have been evolved
in relation to the reservation policies enabled by Articles 15(4) and 16(4) cannot be
readily Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 applied in the
context of local self-government. Even when made, they need not be for a period
corresponding to the period of reservation for the purposes of Articles 15(4) and
16(4), but can be much shorter.
(ii) Article 243-D(6) and Article 243-T(6) are constitutionally valid since they are in
the nature of provisions which merely enable the State Legislatures to reserve seats
and chairperson posts in favour of backward classes. Concerns about
disproportionate reservations should be raised by way of specific challenges against
the State legislations.Bhekhari Sah vs The State Of Bihar on 4 October, 2022

(iii) We are not in a position to examine the claims about over breadth in the
quantum of reservations provided for OBCs under the impugned State legislations
since there is no contemporaneous empirical data. The onus is on the executive to
conduct a rigorous investigation into the patterns of backwardness that act as
barriers to political participation which are indeed quite different from the patterns
of disadvantages in the matter of access to education and employment. As we have
considered and decided only the constitutional validity of Articles 243-D(6) and
243-T(6), it will be open to the petitioners or any aggrieved party to challenge any
State legislation enacted in pursuance of the said constitutional provisions before the
High Court. We are of the view that the identification of "backward classes" under
Article 243-D(6) and Article 243-T(6) should be distinct from the identification of
SEBCs for the purpose of Article 15(4) and that of backward classes for the purpose of
Article 16(4).
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
(iv) The upper ceiling of 50% vertical reservations in favour of SCs/STs/OBCs should not be
breached in the context of local self-government. Exceptions can only be made in order to safeguard
the interests of the Scheduled Tribes in the matter of their representation in panchayats located in
the Scheduled Areas.
(v) The reservation of chairperson posts in the manner contemplated by Articles 243-D(4) and
243-T(4) is constitutionally valid. These chairperson posts cannot be equated with solitary posts in
the context of public employment."
(Emphasis supplied)
24. However, in upholding the validity of the constitutional amendment, issue of specific challenge
to the State Legislation(s) was left open with liberty to raise a specific challenge thereto. In K.
Krishna Murthy2, the petitioners had also challenged the reservation policy to the OBC group as
legislated in the State of Karnataka and the State of Uttar Pradesh. But the Court did observe that in
the case of Karnataka, the empirical data was prepared at least two decades before the submission of
the report (Chennapa Reddy Commission Report), and in the case of Uttar Pradesh, the policy was
based on the 1991 census, and there is, no updation, based on contemporaneous empirical data.
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
25. Whether specific State Legislation was challenged or not is not known, nor is it a relevant fact for
adjudication of the instant lis.
26. Based on the principles enunciated in K. Krishna Murthy2, the Hon'ble Apex Court in Vikas
Kishanrao Gawali3 directed that:-
"13. Be that as it may, it is indisputable that the triple test/conditions required to be
complied with by the State before reserving seats in the local bodies for OBCs has notBhekhari Sah vs The State Of Bihar on 4 October, 2022

been done so far. To wit, (1) to set up a dedicated Commission to conduct
contemporaneous rigorous empirical inquiry into the nature and implications of the
backwardness qua local bodies, within the State; (2) to specify the proportion of
reservation required to be provisioned local body-wise in light of recommendations
of the Commission, so as not to fall foul of overbreadth; and (3) in any case such
reservation shall not exceed aggregate of 50 per cent of the total seats reserved in
favour of SCs/STs/OBCs taken together. In a given local body, the space for providing
such reservation in favour of OBCs may be available at the time of issuing election
programme (notifications). However, that could be notified only upon fulfilling the
aforementioned preconditions. Admittedly, the first step of establishing dedicated
Commission to undertake rigorous empirical inquiry itself remains a mirage. To put
it differently, it will not be open to the respondents to justify the reservation for OBCs
without fulfilling the triple test, referred to above."
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 (Emphasis supplied)
27. Reading of the said report reveals that the State of Maharashtra, (a) without constituting the
Commission; (b) carrying out any empirical study, (c) straightaway provided statutory reservations
for the OBC category, which cumulatively along with the other reserved categories, exceeded the
limit of 50%. Hence, the legislative action in providing a quantum of reservation across the
spectrum for the OBC category uniformly at 27% without conducting a contemporaneous rigorous
empirical inquiry into the nature of implications of backwardness in the local bodies was held to be
bad in law.
28. In Paragraph 9 of said report, the Court itself clarified the nature and character of the
Commission to be "an independent Commission" for ascertaining the "imperativeness of
reservation", which "cannot be a static arrangement" to be reviewed from time to time so as not to
"violate the principle of overbreadth".
29. Dealing with the provisions of the Madhya Pradesh Municipal Act, 1956, which also had
provided for reservation without fully following the principle/prong of the triple-test, the Court
directed the seats reserved for the OBC Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 to
be notified as General Category. This was Suresh Mahajan4, in which the Court observed that:-
"13. For, until the triple test formality is completed "in all respects" by the State
Government, no reservation for Other Backward Classes can be provisioned; and if
that exercise cannot be completed before the issue of election programme by the
State Election Commission, the seats (except reserved for the Scheduled Castes and
Scheduled Tribes which is a constitutional requirement), the rest of the seats must be
notified as for the General Category."
"15. We once again reiterate that the process of delimitation work and/or triple test
compliance is a continuous, complex, time consuming and more so without any
timeline (directly linked to the expiry of the term of the outgoing elected body).Bhekhari Sah vs The State Of Bihar on 4 October, 2022

Whereas, the conduct of elections for installing newly elected body to take over the
reins from the outgoing elected representative whose term had expired, is explicitly
provided for by the Constitution and the relevant enactments. Therefore, the former
need not detain the issue of election programme by the State Election Commission, in
respect of local bodies as and when it becomes due much less overdue, including
where the same is likely to become due in the near future."
"24. In other words, the exercise of collation of empirical data and after analysis
thereof, the Commission is expected to make recommendation regarding the number
of seats to be reserved for Other Patna High Court CWJC No.12514 of 2022
dt.04-10-2022 Backward Classes "local body wise". Apparently, that exercise has not
been undertaken by the Commission. The State Government can act upon only
thereafter and as per the recommendations of the Commission - which is an
independent body created to ensure that there is no over-breadth of such reservation
in the "concerned local body".
"31. We also make it clear that this order and directions given are not limited to the
Madhya Pradesh State Election Commission/State of Madhya Pradesh; and
Maharashtra State Election Commission/State of Maharashtra in terms of a similar
order passed on 04.05.2022, but to all the States/Union Territories and the
respective Election Commission to abide by the same without fail to uphold the
constitutional mandate."
(Emphasis supplied)
30. In dealing with the validity of the amendments brought in specific statutes of some municipal
areas within the State of Maharashtra, noticing the ongoing process of delimitation carried out
under the impugned amendments resulting in the breach of the constitutional provisions in the
conduct of the elections immediately with the completion of five years, the Court in Rahul Ramesh
Wagh5 by way of an interim order dated 04.05.2022 mandated the Election Commission to conduct
the elections without providing for Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
reservation in the category of Backward Classes. The operative portion of the order reads as under:-
"Be that as it may, any election notified by the Madhya Pradesh Election Commission
after 04.03.2021, ought to strictly comply with the triple test requirement predicated
in the decision of the three-Judge Bench of this Court in Vikas Kishanrao Gawali
(supra), in relation to reservation for OBC category seats. In view of the above
submission made on behalf of the State, this petition/application is disposed of as
having become infructuous."
(Emphasis supplied)
31. Finding the position to be similar in the State of Madhya Pradesh, where elections were
underway, the Court in Manmohan Nagar6 not only stayed the election process underway butBhekhari Sah vs The State Of Bihar on 4 October, 2022

directed elections to be conducted by notifying the seats reserved for OBC Category as General
Category. PROVISIONS OF THE BIHAR MUNICIPAL ACT, 2007 (MUNICIPAL ACT) AND
CORRESPONDING AMENDMENTS PROVIDING RESERVATION.
I. The Bihar Municipal Act, 2007 [Bihar Act 11, 2007] Enacted in conformity with the provisions of
the Constitution of India as amended by the Constitution (Seventy-Fourth Amendment) Act, 1992.
II. The Bihar Municipal (Amendment) Act, 2009 [Bihar Act 8 of 2009] Patna High Court CWJC
No.12514 of 2022 dt.04-10-2022
1. Amended Section 12 of the Municipal Act, which deals with the constitution of a municipality and
provides for reservation for Scheduled Castes (SC), Scheduled Tribes (ST) and Backward Classes
(BC) not exceeding 50% of the total seats in each municipality, and for women belonging to SC, ST,
and OBC.
a) Originally, the section provided that the number of seats for SC and ST would be as far as
possible, proportionate to the population in that area and that the seats would be allotted by
rotation to different constituencies in a municipality in the prescribed manner. This was amended to
include the words after two consecutive general elections, i.e., the rotation would take place in the
prescribed manner after two consecutive general elections.
b) Originally, the section also provided that after reservation of seats for SC and ST, seats to be
reserved for the BC shall be as nearly as possible but not exceeding 20% of the seats and within the
overall limit of 50%. It, once again, provided for reservation on rotation, which was amended to
include such rotation after two consecutive general elections.
c) Similar amendment was made in clause (d) of sub-
section 2 of Section 12 with the effect that seats reserved for women belonging to SC, ST, and BC
would be on rotation after two consecutive general elections.
d) Through the amendment, an explanation was added that clarified that the principle of rotation
would Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 commence from the first election
held after the commencement of the Municipal Act.
2. Amended Section 29 of the Act, which provides for reservation of office of Chief Councillor for SC,
ST and BC not exceeding 50% of the total seats of the post of Chairman in the State, and for women
belonging to SC, ST, and OBC.
a) Similar to the amendment to Section 12, here too, the words "after two consecutive general
elections" with the effect that the rotation for the seats reserved for would be in the manner
prescribed after two consecutive general elections for the seats reserved for SC, ST, and OBC, and
women belonging to such classes.Bhekhari Sah vs The State Of Bihar on 4 October, 2022

b) An explanation similar to that introduced in Section 12 was prescribed here, i.e., the principle of
rotation would commence from the first election held after the commencement of the Municipal Act.
III. The Bihar Municipal (Amendment) Act, 2016 [Bihar Act 16 of 2016]
1. Amended Section 13 of the Municipal Act, which provides for the composition of a municipality,
and categorization into a municipal corporation, municipal councils and Nagar panchayats based on
population.
a) A proviso to Section 13 was inserted stating that notwithstanding anything contained in any other
provision of the Act, until the relevant figures of the 2021 census are published, it would not be
necessary for the state to re-determine the number of wards based Patna High Court CWJC
No.12514 of 2022 dt.04-10-2022 on the population of the municipal area ascertained at 2011 census.
IV. The Bihar Municipal (Amendment) Act, 2022 [Bihar Act 6 of 2022]
1. Amended Section 2(104) of the Municipal Act, which originally defined "Board of Councillors" as
the elected body of the municipality consisting of councillors elected in a general election under
Section 12 or in a by-election of the municipality. This was amended to include Chief Councillors
and Deputy Chief Councillors in the ambit of the Board and as elected under Section 23.
2. Amended Section 11 of the Municipal Act, which originally provided that a municipality would
consist of such a number of councillors as there are wards. Now, it has been substituted with the
effect that there will be one elected Chief Councillor and Deputy Chief Councillor in each
municipality.
3. Section 12, which provides for the Constitution of Municipality and reservation for SC, ST and BC
not exceeding 50% of the total seats in each municipality, and for women belonging to SC, ST, and
OBC, has also been amended.
a) In sub-section (1), the words "all the seats in the municipalities" have been substituted by the
words "all the seats of Councillors in the municipalities".
b) In sub-section (2) (a), the words " total seats of the member" have been substituted by the words
"total seats of Councillors".
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
c) In sub-section (2) (a) and (b), the words "seats" have been substituted by the words "seats of
Councillor".
d) Sub-section (4) has been substituted by the following-
"Every member of the Municipality shall have the right to vote in the meeting".Bhekhari Sah vs The State Of Bihar on 4 October, 2022

4. Amended Section 29 of the Act, which provides for reservation of office of Chief Councillor for SC,
ST and BC not exceeding 50% of the total seats of the post of Chairman in the state, and for women
belonging to SC, ST, and OBC, to include, in addition to the post of Chief Councillor, the post of
Deputy Chief Councillor as well.
Orders/Notifications Impugned in these petitions
32. (i) Based on the legal opinion, the Government vide communication bearing No. 850 dated
01.04.2022 directed the State Election Commission to proceed with the elections, for the empirical
data could be collected in terms of Form- 7, 8 and 9. (Page- 66 of CWJC No. 12514 of 2022)
(ii) Notification bearing Communication No. 3732 dated 8.09.2022 issued by the State Election
Commission reserving the post of Deputy Chief Councillor for the election of Municipal Corporation
for Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 all categories, including OBC/EBC.
(Page-55 of CWJC No. 14240 of 2022)
(iii) Communication bearing No. 3090 dated 7.09.2022 issued by the District Magistrate-cum-
District Election Officer (Municipality) directing specific seats to be reserved for different categories
in different Nagar Parishads (six in number). (Page- 19 of CWJC No. 14193 of 2022)
(iv) Communication No. 3237 dated 19.08.2022, issued by the State Election Commission calling
upon all the Divisional Commissioners, District Magistrates-cum-District Election Officer
(Municipality) to prepare the reservation proposal (ST/SC/BC/Women) in terms of the Bihar
Municipal Election Rules, 2007 in each one of the municipalities for the post of Municipal
Councillor, on a similar basis as was carried out for conducting the election to the Municipalities in
the year 2017. (Page-92 of CWJC No. 12514 of 2022)
(v) Notification No. 3734 dated 08.09.2022 issued by the State Election Commission providing
reservation of all categories for the post of Deputy Chief Patna High Court CWJC No.12514 of 2022
dt.04-10-2022 Councillor for elections in different municipal areas of Bihar. (Page- 40 of CWJC No.
14249 of 2022)
(vi) Notification No. 3731 dated 08.09.2022 issued by the State Election Commission providing
reservation of all categories for the post of Chief Councillor for elections in different municipal areas
of Bihar. (page- 65 of CWJC No. 14245 of 2022)
(vii) Notification No. 3733 dated 08.09.2022 issued by the State Election Commission providing
reservation of all categories for the post of Chief Councillor for elections in different municipal areas
of Bihar. (Page-19 of CWJC No. 14242 of 2022)
(viii) Notification No. 2731 dated 09.09.2022 issued by the Urban Development and Housing
Department, Government of Bihar, notifying the schedule for election to be held for all the posts in
the Municipal Bodies of the State of Bihar. (Page-116 of CWJC No. 12514 of 2022) "PROGRAMS
RELATED TO THE VARIOUS STAGES OF THE ELECTION OF MUNICIPALITIES Sl. No. DetailsBhekhari Sah vs The State Of Bihar on 4 October, 2022

of Work First Phase Second Phase 1 Date of publication of 10.09.2022 16.09.2022 information in
Form 11 by the Returning Officer 2 Date of Receipt of From 10.09.2022 From Patna High Court
CWJC No.12514 of 2022 dt.04-10-2022 Nomination to 19.09.2022 16.09.2022 to 24.09.2022 3 Date
of scrutiny From 20.09.2022 From to 21.09.2022 25.09.2022 to 26.09.2022 4 Last date for
withdrawal of From 22.09.2022 From candidature to 24.09.2022 27.09.2022 to 29.09.2022 5
Finalization after withdrawal 25.09.2022 30.09.2022 of candidature, Publication of list of
candidates and allotment of symbols 6 Date of Poll 10.10.2022 20.10.2022 7 Polling Time 7 am to 5
pm 7 am to 5 pm 8 Date of Counting 12.10.2022 22.10.2022 "
SUBMISSIONS OF COUNSEL
33. Submissions made on behalf of the petitioners' counsel, more specifically, Senior
Advocates Ms. Minakshi Arora, Shri Y.V.Giri, and Shri Mrigank Mauli, and
Advocates, Shri S.B.K. Manglam, Sri Siddhartha Prasad, and Shri Vivek Ranjan, are
summarized as under:-
(1) Constitution of an independent Commission for preparing empirical data for
identifying the political backwardness is a sine qua non for reserving the post/seat in
the OBC category.
(2) In utter disregard and breach of the first two tests (principles) laid down by
Hon'ble the Supreme Court, Patna High Court CWJC No.12514 of 2022
dt.04-10-2022 the Government and the Election Commission proceeded to conduct
the elections.
(3). The Principle of reservation applied by the Government/Election Commission
has resulted in an excessive reservation.
(4). Identification of political backwardness of the persons belonging to the OBC
category was never undertaken by the State. In the absence of such an exercise, the
criteria of adopting the total population of EBC cannot be the basis for reservation.
(5). Form 7, 8 and 9 only captures the detail of the population of Reserved Category
of SC & ST. It does not account for the population of OBC/EBC much less political
backwardness of EBC.
(6). Reserving the post of Deputy Chief Councillor is in excess of the 20% cap
prescribed for the OBC category.
34. Here only, we may record that, save and except, for the challenge to Section 2(100) and
providing reservation to the post of Deputy Mayor/Councillor or other similar posts, in terms of the
Amendment Act, learned counsel for the petitioners did not press the prayers assailing other
amendments brought into the Municipal Act. Patna High Court CWJC No.12514 of 2022
dt.04-10-2022Bhekhari Sah vs The State Of Bihar on 4 October, 2022

35. Shri Vikash Singh, Senior Advocate, appeared on behalf of the State and Mr. Rajendra Narain,
Senior Advocate for the Bihar State Election Commission.
36. Opposing the petitions, Shri Vikash Singh, Senior Advocate, has made the following
submissions:
(1). The decision rendered in K. Krishna Murthy is based on a fact situation; different
and distinct from Bihar, and as such, is not applicable for the State of Bihar; The
triple test formula was laid only in the context of reservation of OBC.
(2). In Bihar, OBC cannot be considered politically backward due to their sheer
numerical strength.
Consequently, its sub-set, i.e. Extremely Backward Class (EBC), was carved out and reservations
provided thereto.
(3). Vikas Kishanrao Gawali3; Suresh Mahajan4; Rahul Ramesh Wagh5; and Manmohan Nagar6
only deal with reservations exceeding the prescribed limit of 50%, which is not the case at hand.
(4). Alternatively, and in any event, Government is not only in full compliance but way ahead of
what is mandated in the dictums;
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 (5). Post independence, by undertaking a
novel exercise, pioneering the movement of reservation for not only the OBCs but a sub-set thereof,
i.e. EBC, the Government brought in legislations for providing reservations; identifying caste by a
statutory body- the State Commission for Backward Classes; and also constituted a separate
Commission for identifying persons belonging to EBC Category. Based on their exercise, even as late
as 2015, the Government issued a notification identifying persons belonging to both OBC and EBC
Category for the purpose of conferring benefits.
(6). With the Constitution 73rd Amendment and Constitution 74th Amendment Act, 1992, suitable
amendments were brought in the respective legislations providing adequate reservation to all
categories of persons, including OBC and EBC categories, with the cap of 20%. This exercise has
withstood the test of judicial scrutiny with the passing of the Full Bench judgment of this Court
dated 19.05.2006, in Vijay Kumar Singh Vs. State of Bihar & Ors,7 wherein the action of the
reservation to the extent of 20% for the EBC Category brought in the Bihar Panchayati Raj Act, 2006
was upheld with the Hon'ble the Supreme 2006 (2) PLJR 606 Patna High Court CWJC No.12514 of
2022 dt.04-10-2022 Court putting its seal of approval vide order dated 06.03.2018 in Saran Jila
Mukhiya Sangh and another v. State of Bihar and others.8 (Page 441).
(7). Arguing that the reservation in respect of Extremely Backward Classes is carved out of OBC, the
State Legislature does not fall foul of the law, reliance is sought on the judgment dated 01.12.2016
rendered in Sanjay Kumar Vs. The State of Bihar & Ors,9 against which, even though an SLP is
pending, the ratio is still binding.Bhekhari Sah vs The State Of Bihar on 4 October, 2022

37. Shri Amit Shrivastava, learned senior counsel, Amicus Curiae, in supporting the petitioner's
submissions, has further added that bare reading of the communication dated 01.04.2022 (Page-66)
indicates the State to have taken a contradictory stand. Whereas vide communication dated
13.10.2016, the Government had acknowledged the Election commission to be a constitutional and
independent body, yet, contrary to the concern expressed by the Election Commission, by taking a
summersault, issued direction to proceed with the elections.
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
38. Certain other judicial pronouncements relied upon by the learned counsel shall be referred to
and dealt with later in our opinion.
PLEADED CASE OF THE GOVERNMENT
39. Pleaded case of the Government is as follows:-
"3. That the judgments of the Hon'ble Supreme Court in the case of K.
Krishnamurthy & Ors. v Union of India & Ors. (2010) 7 SCC 202 as also Vikas
Kishanrao Gawali Vs. State of Maharashtra (2021) 6 SCC 73 do not apply at all in
respect of the State of Bihar because Bihar has not provided reservation for OBC as a
class in its local bodies. Krihnamurthy while considering a challenge to the
constitutional validity of Part XI and XI-A of the Constitution of India amongst
others, was also considering the vires of the enabling provision in the said Part which
enabled various states to provide for reservation for OBCs in the Panchayats and
Municipalities respectively. The judgment in Krihnamurthy is only an authority for
the proposition that part XI and XI-A of the Constitution of India vide Articles 243D
and 243T only provide for an enabling provision for the respective state legislatures
to provide for reservation in Panchayats and municipal bodies respectively. While
approving the spirit of the Constitution and justifying the enabling power to provide
for reservation, the Constitution Bench of the Patna High Court CWJC No.12514 of
2022 dt.04-10-2022 Hon'ble Supreme Court discussed the concept of 'political
backwardness' on the premise that the OBCs, by their sheer numerical strength,
cannot be said to be suffering the same disadvantages, which a Backward Class
person would be suffering in the matter of employment where education and
competing in an examination are the determining factors in selection. If any State
was to further sub-divide the OBC category, like in Bihar by creating a sub-set of the
OBCs as a class which is Extremely Backward, then firstly the advantage of numerical
strength for the purpose of Political backwardness does not arise and secondly, the
Extremely backward amongst the OBC are an identified lot whose historical
sufferings in society are much greater than the other OBCs and hence they require
affirmative action in the matter of reservation in local bodies. The extremely
backward are a more disadvantaged lot of the OBCs, that too identified by the first
time by the Kaka Kalekar Commission in its report on Backward classes 1955 and the
said Most Backward Class were further specifically identified for the State of Bihar byBhekhari Sah vs The State Of Bihar on 4 October, 2022

the Mungeri Lal Commission in the year 1976. In other words, a dedicated
commission identified this Extremely Backward Class (Most Backward Class) as early
as in 1955 for the entire country and in the year 1976 for the State of Bihar and the
updation of the persons falling in the said category is being done since 1993. In fact in
the State of Bihar the updation of the Extremely Backward Class is first done by the
Extremely Backward Class Commission (which is a statutory commission constituted
by notification of the State Government) and the list so Patna High Court CWJC
No.12514 of 2022 dt.04-10-2022 prepared, is put up before the Backward Class
Commission constituted under the Bihar State Commission for Backward Classes
Act, 1993, which commission takes a holistic view of the matter and finalises the list
of the Extremely Backward Class and OBC.
It is noteworthy that one of the mandates of the Bihar State Extremely Backward
Commission is also to identify the caste which will remain in the Extremely Backward
Class so as to enjoy the benefit of reservation in the local bodies of Bihar.
ANNEXURE Accordingly in view of the above and in view of the events described
herein below, it is clear that the Krihnamurthy judgment does not apply to the state
of Bihar and accordingly Vikas Gawali judgement and subsequent orders passed
therein would not apply to the State of Bihar. In view thereof the writ petition is not
maintainable."
"18. That on 11/05/2010, a Judgment was passed by the Constitution Bench of the
Hon'ble Supreme Court in K.Krishnamurthy & Ors. v. Union of India & Ors. (2010) 7
SCC 202 dealing only with the reservation with regard to OBC. The said judgment did
not in any manner deal with reservation as provided in the State of Bihar which had
reserved seats in local bodies for Extremely Backward Classes and not for the entire
OBC identified for the State. The said judgment would apply only to such states
which had made reservation for OBC as a whole in the local bodies and the premise of
the said judgment was that mostly in states OBC as a whole because of their
numerical Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 strength cannot
be considered to be backward in the matter of political representation.
It is noteworthy that while OBC as a whole constitute almost 50% of the population of
Bihar out of the same Extremely Backward Classes would be almost 25%. Since there
is no study on the subject, averment is being made on the basis of news report
published by Indian Express."
OUR OPINION
40. Having given thoughtful consideration to the material on record, we cannot persuade ourselves
to agree with the first of the submissions made by Shri Vikash Singh, learned Senior Advocate.Bhekhari Sah vs The State Of Bihar on 4 October, 2022

41. We do not agree that the decision in K. Krishna Murthy2 would apply to states which had
provided reservations in the local bodies only for the OBC category "as a whole,". There, primarily,
the challenge dealt with was to the Constitution 73rd and 74th amendment, and the challenge to the
Municipal Law (two States), left open to be dealt with separately. Significantly, the State of Bihar
was a party to the said decision. Also, Hon'ble Supreme Court decided Saran Jila Mukhiya Sangh8
(Page 441) following K. Krishna Murthy2, by extracting relevant portion thereof. Patna High Court
CWJC No.12514 of 2022 dt.04-10-2022
42. The concept of EBC, as carved out by Bihar, at best is only a "sub-set" and not an "off-set" of
OBC. The primary reservation source, be it for OBC or EBC, flows through Article 243(6) alone,
whereby for the "OBC" category, States are enabled to provide reservations through a statutory
mechanism. This is unlike the category of SC and ST, for whom, as the Constitution provides,
reservation necessarily has to be based on population, regardless of their political backwardness.
43. In so far as other decisions are concerned (referred to in the opening part of the opinion, Para-2)
while dealing with the issue of reservation for OBC Category, the Court found the impugned
action(s) to be violative on all counts- (1) reservation in excess of the Constitutional cap, (2)
providing reservation without constituting a Commission (3) and/or conducting a study of
contemporaneous empirical data, more so, with regard to the "political backwardness"
vis-à-vis the territorial limits of the constituency.
44. Next, we proceed to examine whether the three test principles is complied with by the State of
Bihar or not? Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 FIRST TEST
45. Coming to the first test principle, i.e. "Having a dedicated Commission to conduct an empirical
inquiry into the nature and implication of backwardness in relation to local bodies", we find the
Government to have placed certain material which we now proceed to deal with.
46. The Government states that with the enactment of the Constitution, the first Backward Class
Commission, chaired by Kaka Saheb Kalelkar submitted its report in 1955; pan India, out of 2399
castes classified as Backward castes, 837 were in the Most Backward category. Concerning the State
of Bihar, the Commission listed 128 casts as Backward.
47. In 1971, the Government of Bihar appointed its own Commission headed by Mr. Mungerilal, and
the report submitted in 1976 revealed that out of these 128 castes, amongst all religions, i.e. Hindus,
Muslims or Christians, 94 were Most Backward. The conclusions arrived at fully accounted for the
parameters- (1). Socio-economic status; (2) Representation in Government Jobs; and (3) Share in
industries and business.
48. Acting on this report, the then Chief Minister Shri Karpoori Thakur introduced a concept of
reservation for Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 all categories, be it Other
Backward Classes (OBC), Most Backward Class (MBC), Scheduled Caste (SC), Scheduled Tribe (ST),
Women or Economically Backward Category (EBC). Consequently, amendments were brought intoBhekhari Sah vs The State Of Bihar on 4 October, 2022

different statutes providing reservation, in the area of service, education or elected representatives
at the grass root level.
49. The Bihar Reservation of Vacancies in Posts and Services (for Scheduled Castes, Scheduled
Tribes and Other Backward Classes) Act, 1991[hereinafter referred to as Act No. 3 of
1992/Reservation Act] was updated to necessarily provide reservation to Economically Backward
Class; Backward Class, Women of Backward Classes, including Women from Scheduled Castes;
Scheduled Tribes and EBC.
50. Bihar Panchayat Raj Act, 1993 was amended, providing reservations to both the EBC and
Backward Classes.
51. Further, under the Bihar State Commission for Backward Classes Act, 1993, the State constituted
a specific Commission for Backward Classes other than Scheduled Castes and Scheduled Tribes.
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
52. Still further, by virtue of a resolution dated 15.09.2006 issued by the Personnel and
Administrative Reforms Department, Government of Bihar, "State Commission for the Most
Backward Class" was also constituted. (Page-454)
53. Inviting attention of notification dated 11th September, 2015 (Page 456), whereby the list
contained in Bihar Act No. 3 of 1992 was amended, the existence of a mechanism complete in all
respects, of identification of the OBC/EBC and the exercise carried out by such bodies, is pointed
out. Thus, argued, meets the test of the establishment of a Commission to study empirical data.
54. It is argued that, by amending the Bihar Executive Rules, 1979 through a notification dated
20.03.2007 of the Cabinet Secretariat & Coordination Department, Backward Classes and
Extremely Backward Classes Welfare Department has been made the Nodal Department to
implement and monitor the following subjects:
(1). To provide a stipend to the Extremely Backward Classes.
(2). To provide grants for books and accessories to the Extremely Backward Class
Students. (3). To provide loans to the members of the Extremely Backward Classes
for their Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 development. (4).
Establishing and managing hostels for the Extremely Backward Classes. (5).
Formation of co-operative societies for the Extremely Backward Classes. (6). To
provide subsidiary grants to educational and cultural institutions working to benefit
the Extremely Backward Classes. (7). To provide a stipend to the Backward Classes.
(8). To provide grants for books and accessories to the Backward Classes. (9). To
provide loans to the members of the Backward Classes for their development. (10).
Opening and managing hostels for the Backward Classes. (11).Bhekhari Sah vs The State Of Bihar on 4 October, 2022

Formation of Cooperative Societies for the Backward Classes. (12). To provide subsidiary grants to
educational and cultural institutions working for the benefit of the Backward Classes. (13). Bihar
State Backward Classes Finance and Development Corporation (14). Special Home-Building
Schemes for Backward Classes and Extremely Backward Classes.
55. Also, while OBC constitutes almost 50% of the Population in Bihar, 25% belong to Extremely
Backward Classes and are provided with the benefit of reservation. Patna High Court CWJC
No.12514 of 2022 dt.04-10-2022
56. Continuous study and updation have resulted into amendments brought out in the Act No. 3 of
1992/Reservation Act in the following manner:-
"The Bihar Act 3, 1992
(a) Schedule Castes 14%
(b) Schedule Tribes 10%
(c) Extremely Backward Class 12%
(d) Backward Class 8%
(e) Economically Backward women 3%
(f) Economically Backward 3% Total 50% "
"The Bihar Act 11, 1993
(a) Schedule Castes 14%
(b) Schedule Tribes 10%
(c) Extremely Backward Class 14%
(d) Backward Class 10%
(e) Women of Backward Classes 2% (Women of SC/ST,EBC and BC) Total 50% "
"The Bihar Act 17, 2002 (After Division of Bihar in year 2000)
(a) Schedule Castes 16%
(b) Schedule Tribes 1%Bhekhari Sah vs The State Of Bihar on 4 October, 2022

(c) Extremely Backward Class 18%
(d) Backward Class 12%
(e) Women of Backward Class 3% Total 50% "
57. Examination of the provisions of Act No. 3 of 1992/Reservation Act, in our considered view,
carries the object and purpose of only providing reservation in services.
58. That apart, the criteria for delineating backwardness is "economic backwardness" and not
"political backwardness", as is evident from the Other Backward Patna High Court CWJC No.12514
of 2022 dt.04-10-2022 Classes defined therein. For ready reference, relevant provisions of the
statute are extracted hereunder:-
"2(i)"Other backward Classes" shall have reference to extremely backward and
backward class economically backward and economically back ward women";
"(j) Extremely Backward and Backward Classes" mean and includes those castes
which have been mentioned and circulated vide Department of Personnel and
Administrative Reforms, Government of Bihar. Resolution No. 11/A1-501/78-756/Ka
dated the 10th November, 1978 as amended from time to time and specified in
Schedule I and II of this Act and whose annual family income from all sources is less
than the income tax limit;
"(k) Economically Backward" mean and include those candidates whose annual
family income from all sources is less than the income-tax limit.
(l) "Economically Backward Women" mean and include those candidates whose
annual family income from all sources is less than the income-tax limit:"
"(m) Merit list" means the list of candidates arranged in order of merit prepared
according to the rules and orders issued by the State Government and adopted by
competent authority for making appointments in respect of initial recruitment or
promotion;"
"(n) "State" includes the Government, the Legislature and the Judiciary of the State
of Bihar and Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 all local or
other authorities within the State or under the control of the State Government."
(Emphasis supplied)
59. The said Act was amended vide Bihar Act 11 of 1993 (Page 403). Substituting the definition of
"other backward class" as under:Bhekhari Sah vs The State Of Bihar on 4 October, 2022

"2(ii) For clause (i), the following shall be substituted, namely:-
"(i) 'Other Backward Classes' shall have reference to Extremely Backward, Backward
Classes and Women of Backward Classes".
(iii) For clause (g) the following shall be substituted, namely:
"(j) Extremely Backward and Backward Classes' mean and include those classes
which have been specified in Schedules I and II of the Act."
(Emphasis supplied)
60. Bihar Act 6, 1996 amended Act No.3 of 1992 and the following was inserted:-
"14A. Power to add or remove Castes/Classes in Schedules I and II of the Act- The
State Government may on the recommendation of the Bihar State Commission for
Backward Classes, add or remove, as the case may be, any Caste/Class from Schedule
I or Schedule II appended to the Act by notification in the Official Gazette."
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
61. A conjoint reading of the definition clause 2(i),(j),
(k) and (l) results in an unequivocal conclusion that even with the amendment in the definition of
OBC and EBC, neither political backwardness nor representation to the local bodies is the criteria
for determining backwardness. The position remains the same.
62. We examine the issue from the point of Municipal Act.
63. Here only we extract the definition of Backward Class contained therein.
"2(100) "Backward Classes" means and includes the list of Backward Classes of
Citizens Specified in Annexure 1 of the Bihar Reservation of Vacancies in Post and
Services (for SC, ST and other Backward Classes) Act 1991 (Bihar Act, 3/92)."
64. The import of backward class is restricted to Annexure-1 of the Bihar Act 3 of 1992, which
actually is Schedule I and the list provided therein, pertaining to the EBC category.
65. When viewed with the definition of Backward Class in the Municipal Act, the Other Backward
Classes, as defined in Section 2(i) of the Reservation Act, restricted in Patna High Court CWJC
No.12514 of 2022 dt.04-10-2022 nature, confines the scope of the Act only to the EBC and not OBC
category.Bhekhari Sah vs The State Of Bihar on 4 October, 2022

66. Examining the provisions of the Bihar State Commission for Backward Classes Act,
1993(referred to as the Commission Act), (Page-406 ) we notice the scope of inquiry by the
Backward Classes Commission to be restrictive in nature, i.e. examining the "request or complaints
with regard to the inclusion of the Backward Classes in the list" as also "tender advice to the State
Government as it deems appropriate. Here also, a Backward Class, is defined as the one specified in
the Schedule appended to Act 3 of 1992, which is the Reservation Act. Certainly, the Reservation Act
does not deal with the nature or implication of Political Backwardness concerning local bodies. For
ready reference, the relevant provisions of the Commission Act are extracted as under:-
"2 (a). "Backward Classes" means, such Backward Classes other than the Scheduled
Castes and the Scheduled Tribes specified or to be specified in the Schedule
appended to Bihar Act 3 of 1992;
(b) "Commission" means the State Commission for Backward Classes constituted
under Section 3;
(c) "Lists" means lists prepared by the State Government from time to time for
purpose of making proviso for the reservation of appointments or posts in Patna
High Court CWJC No.12514 of 2022 dt.04-10-2022 favour of Backward Classes of
citizens which, in the opinion of the Government, are not adequately represented in
the services under the State Government and any local or other authority within the
State or under the control of the State Government;
9 Functions of the Commission. - (1) (a) The Commission shall examine the request for inclusion of
any class of citizens as a Backward Class in the list and hear complaints of over inclusion or under
inclusion of any Backward Class in such lists and tender such advice to the State Government as it
deems appropriate; (2) The advice of the Commission shall ordinarily be binding upon the State
Government."
(Emphasis supplied)
67. Thus, the definition clause itself clarifies the object of preparation of the list by the Commission,
i.e., providing reservations for appointments in Government Service and/or any local or other
authority within the State or under its control for the EBC.
68. The Commission Act was amended vide the Bihar Act No. 5 of 2008, titled the State Commission
for Backward Classes (Amendment) Act, 2007, (Page-453 ) with the substitution of Section 9, which
reads as under:-
"2. Amendment of Section 9 of the Bihar Act 12, 1993
- Sub-section (1) of Section-9 of the said Act shall be substituted by the following:-Bhekhari Sah vs The State Of Bihar on 4 October, 2022

Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 (1) (a) The Commission
shall examine, request for inclusion of any class of citizen as a backward class in the
list and hear complaints of over inclusion or under-
inclusion of any backward class in the list of Backward Classes (Schedule-2) and tender such advice
to the State Government as it deems appropriate;
(b) The Commission shall examine the complaints under any other law, Rules or instructions, for
the time being in force, under the Constitution and by the State Government debarring from rights
and protection and reservation admissible for Backward Classes for the entrance in public services
and educational institutions and tender appropriate advice so that the State Government may take
necessary action in this regard. (C) Execution of other works referred by the Government to the
Commission also from time to time shall be made by the Commission."
(Emphasis supplied)
69. It is thus seen that under this amendment, the power to deal with the list of Backward Classes is
confined to Schedule-II, which deals only with OBC category and not EBC category, for which there
is a separate Schedule-I. The scope of inquiry by the Commission was not expanded even by this
Amendment.
70. We add that, by adopting the legislative principle of "reference", and not "incorporation",
reference to the Schedule/List/Annexure, be it by whatever name, in the Patna High Court CWJC
No.12514 of 2022 dt.04-10-2022 statutes, is only what is provided under the Reservation Act. The
legislative action, incoherent in nature, by the delegatee has resulted into this anomalous situation.
71. Thus, the scope of inquiry under the Commission Act or Act No. 9/1992 is definitely not to
ascertain the political backwardness of persons belonging to the reserved category of OBC, including
the EBC for the purpose of representation to the Municipal Bodies.
72. Coming to the State resolution constituting the State Commission for Most Backward Class
(Page 454), we find one of the functions of the Commission is to provide suggestions for enabling
representation of the "Most Backward Class" in the three-tier levels of the Panchayats and the
problems arising out of it, vis-à-vis inclusion and removal of such castes and other matters
connected therewith.
73. The scope of the Commission is defined in Clause 3(b), which is extracted as under:-
"3. The work to be done by the Commission:-
i. To submit a detailed report every year to the State Government on the reasons for
the backwardness and the social and educational status of the most backward class
and the measures to remove them.Bhekhari Sah vs The State Of Bihar on 4 October, 2022

Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 ii. On the basis of
complaints received regarding deprivation of rights of the most backward class,
vesting in Law, Government orders, policies, ordinance order, after inquiry would
give suggestions to the State Government for taking appropriate action.
iii. The Commission may suggest for inclusion and exclusion of any caste out of the
list of the most backward castes. iv. The Commission may give suggestions with
regard to the issues of the representation of the most backward class in the three-tier
Panchayats and the problem arising out of it vis-a vis inclusion and removal of such
castes in the most backward classes and other matters connected therewith. v. To
study the problems of modernization of traditional jobs associated with extremely
backward classes and to give appropriate suggestions to the Government. vi. Any
other matter which the State Government may entrust to the Commission."
(Emphasis supplied)
74. However, it is not the pleaded case of the State that the Government had ever entrusted any
work to this Commission, undertaking the task of conducting an empirical inquiry into the nature
and implication of political backwardness of the EBC, much less of OBC category for the purpose of
the reservation to the election of municipalities, as mandated by K. Krishna Murthy2 or Vikas
Kishanrao Gawali3.
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
75. Before us, it is also not the pleaded case that this Commission has ever given any suggestions
vis-à-vis an inquiry or ever undertaken any task in terms of the scope of Clause (iv), reproduced
supra. The scope of Commission is specific and confined to EBC and not OBC as a whole, for the
former is only a subset of the latter. Also, the Commission's primary objective is to prepare a report
after examining the reasons for social, educational and economic backwardness.
76. We find the impugned actions to suffer from the vice of lack of jurisdictional error since
imperativeness of the need to establish a dedicated Commission or empowering the existing bodies
to undertake the task of empirical data collection and study thereof not to have been carried out.
77. In the backdrop mentioned above, we cannot persuade ourselves to opine the Government to
comply with the first prong of the three-fold test.
SECOND TEST
78. We shall now deal with the second test principle, i.e. "specification of the proportion of
reservation Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 required in the light of the
recommendations of the Commission".Bhekhari Sah vs The State Of Bihar on 4 October, 2022

79. As per K. Krishna Murthy2, the onus is on the executive to conduct a rigorous investigation into
the patterns of backwardness that act as barriers to political participation [Para 82 (iii)] and the
onus challenging the errors in undertaking such exercise is on the person challenge the same. (Para
62)
80. It is not the case, pleaded or stated, of the Government that post K. Krishna Murthy2 an exercise
was carried out wherein the parameters adopted for determining the backwardness in other aspects,
socio-economic or educational, were consciously adopted for the purpose of representation to the
elected bodies.
81. On record, we find that save and except for the list notified on 11th September 2015 (Page 456),
whereby amendment in the list of Act No. 3 of 1992/Reservation Act about EBC and OBC was
brought about, there is no other latest list. We notice that there have been certain deletions in the
said List-1 dealing with the Extremely Backward Class. But then the list clarifies the object of its
preparation, i.e. to enable the authorities to issue Caste Certificates (Page 457) Patna High Court
CWJC No.12514 of 2022 dt.04-10-2022 and provide reservations in Government employment (Page
460).
82. Further, the notification does not specify the list to have been amended based on the
recommendations made either by the Backward Classes Commission or the Extremely Backward
Classes Commission. Thus, in our considered view, there is total non-compliance of the mandate of
the Constitution Bench Judgment in K. Krishna Murthy2 and subsequent judgments in Sunil
Kumar1; Vikas Kishanrao Gawali3; Suresh Mahajan4; Rahul Ramesh Wagh5; and Manmohan
Nagar6.
83. The maize of incoherent statues has perhaps led to this anomalous situation which requires
clarification by a comprehensive legislation covering all aspects in the light of K. Krishna Murthy2
and other subsequent judgments.
84. This fact alone has not weighed with us in arriving at such a conclusion, for we examine the issue
differently.
85. In Indrasawhney and others v. Union of India and others,10 and Pattali Makkal Katchi v. A.
Mayilerumperumal and others,11 the concept of sub- 1992 Supp (3) SCC 217 2022 SCC OnLine SC
386 Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 classification within socially and
educationally backward classes, though in the context of Article 16(4), was accepted.
86. In State of Punjab and others v. Davinder Singh and others,12 [Five Judge Bench], the Hon'ble
Supreme Court has held as follows:-
"48. The State's obligation is to undertake the emancipation of the deprived section
of the community and eradicate inequalities. When the reservation creates
inequalities within the reserved castes itself, it is required to be taken care of by theBhekhari Sah vs The State Of Bihar on 4 October, 2022

State making sub- classification and adopting a distributive justice method so that
State largesse does not concentrate in few hands and equal justice to all is provided.
It involves redistribution and reallocation of resources and opportunities and
equitable access to all public and social goods to fulfil the very purpose of the
constitutional mandate of equal justice to all."
"49. Providing a percentage of the reservation within permissible limit is within the
powers of the State Legislatures. It cannot be deprived of its concomitant power to
make reasonable classification within the particular classes of Scheduled Castes,
Scheduled Tribes, and socially and educationally backward classes without depriving
others in the list. To achieve the real purpose of reservation, within constitutional
dynamics, needy can always be given benefit; otherwise, it would mean that
inequality is being perpetuated within the (2020) 8 SCC 1 Patna High Court CWJC
No.12514 of 2022 dt.04-10-2022 class if preferential classification is not made
ensuring benefit to all."
(Emphasis supplied)
87. The concept of carving out a subset out of a set is also accepted in Vijay Kumar Singh7.
88. In the impugned communication dated 01.04.2022 (Page No. 66), it is the Government's dictate
to the Election Commission to obtain data from the District Magistrates through Forms 7, 8 and 9 to
carry out an empirical study.
89. This takes us to the relevant enabling provisions providing for such an exercise to be
undertaken.
90. The Municipal Act defines the backwardness to mean that:-
"2(100) "Backward Classes" means and includes the list of Backward Classes of
Citizens Specified in Annexure 1 of the Bihar Reservation of Vacancies in Post and
Services (for SC,ST and other Backward Classes) Act 1991 (Bihar Act, 3/92)"
91. The Constitution of a Municipality is defined under Section 12. Sub-section (2) of the said
Section provides for reservations not exceeding 50% of the total seats of the member of the
Municipalities to be reserved for (i) Scheduled Patna High Court CWJC No.12514 of 2022
dt.04-10-2022 Castes, (ii) Scheduled Tribes and (iii) Backward Classes. As far as the SC and ST
Category is concerned, the reservation is based on their respective total population of the area. The
extent of the total number of seats to be reserved for all categories is 50%. After providing for
reservation for the SC and ST Category, the remainder, not exceeding 20% of the total seats, are to
be reserved for all other specified categories.
92. Bihar Municipal Election Rules, 2007 (referred to as the Rules) were notified on 21.04.2007.
Rules 29 and 30 prescribe Forms 7, 8 and 9. Since both are similar, for ready reference, Rule 29 isBhekhari Sah vs The State Of Bihar on 4 October, 2022

extracted as under:-
"29. Constitution and numbering of wards of a Municipality. - (1) Subject to the
provisions of Section 7 & Section 13 of the Act, wards shall be constituted and
numbered in accordance with the procedures laid down by the State Election
Commission. The list of ward of every Municipality shall be published in Form
-6 in the manner prescribed by the State Election Commission.
(2) Determination of seats for reservation in the wards.
-
(i) For election to the post of Councillors in each Municipality, reservation and allotment of wards
for the Scheduled Castes/Scheduled Tribes/ Backward Classes and Women of these categories in
admissible number Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 under Section
12(2)(a) of the Act shall be made by the District Magistrate under the direction, controls and
supervision of the State Election Commission.
(ii) First of all the number of wards to be reserved under Section 12(2) of the Act for each category
shall be calculated in Form - 7 in the manner laid down by the State Election Commission.
(iii) Wards having the highest population of Scheduled Castes and Scheduled Tribes in descending
order of population shall be reserved for and allotted to Scheduled Castes or Scheduled Tribes, as
the case may be, in admissible number.
Out of the seats so reserved for Scheduled Castes or Scheduled Tribes, as nearly as fifty per cent of
these seats but not exceeding it, shall be reserved for women of the Scheduled Castes or Scheduled
Tribes, as the case may be. Wards which come first in descending order of the Population of
Scheduled Castes or Scheduled Tribes shall be allotted to the women of these categories.
(iv) Subject to the limit of fifty per cent total reservation including Scheduled Castes/Scheduled
Tribes and Backward Classes, a maximum of twenty per cent of total seats of wards shall be reserved
for Backward Classes in each Municipality. For this the following procedure shall be followed:-
(i) All the wards in the concerned municipality shall be arranged Patna High Court
CWJC No.12514 of 2022 dt.04-10-2022
(a) showing category wise (Scheduled Castes, Scheduled Tribes, other and total)
Population in Form - 8
(b) descending order of the population showing Scheduled Castes population,
Scheduled Tribes population, other classes population and total population
(including Scheduled Castes/ Scheduled Tribes and other classes) in Form - 9Bhekhari Sah vs The State Of Bihar on 4 October, 2022

(ii) Those wards which have been reserved and allotted to Scheduled
Castes/Scheduled Tribes (including their women) shall not be reserved for the
Backward Classes.
Seat for Backward Classes shall be reserved and allotted from the remaining wards.
(iii) Those wards which have the highest total population in descending order, shall be reserved for
Backward Classes in admissible number. Out of the wards so reserved for Backward classes, those
wards shall be reserved for Backward Class women in admissible number, which come first in
descending order of total population.
(iv) Details of such reserved/unreserved wards shall be prepared in Form -10."
93. One such filled form is placed on record (Page No. 481 - 484) and sample of the forms is
extracted as under:-
"FORM 7 [See Rule 29(2)] Category wise reserved post State Name of Sub-Division
Name of Municipality Municipality's Population Total Category wise total reserved
post Scheduled Scheduled Others Total Number of Schedule Schedule Backward
Others Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 Caste Tribe Wards
Caste Tribe Class District Magistrate-cum-District Election Officer (Municipality)
(1)Counting of Reserved posts for Schedule Caste:-
(Population of Schedule Caste/Municipality's total Population) x Total Number of
wards=........Post (2)Counting of Reserved posts for Schedule Tribe:-
(Population of Schedule Tribe/Municipality's total Population) x Total Number of
wards=........Post (3)Counting for Reserved seats for Backward Class:-
a. Total Seats:-
b. 50% of Total Seats:-
c. 20% of Total Seats (1/5 of Total Seats):- d. Number of Reserved Seats for SC/ST e.
Number of Reserved Seats for Backward Classes............Seat (4) Number of
Unreserved Seats = Total Posts (d + e) =........Seat"
"FORM- 8 [See Rule 29(2)(iv)] Category wise population of Municipality's ward
State:-
Name of District:-
Name of Sub-Division:-Bhekhari Sah vs The State Of Bihar on 4 October, 2022

Name of Municipality:-
                  Serial          Ward's      Population of Ward area
                                  number/name
                                              Schedule           Other                              Schedule                    Total
                                              Tribe                                                 Caste
                                                                                    District Magistrate"
                                                      "FORM-9
                                              [See Rule 29(2)(iv)(i)(b)]
Municipality's population in descending order State:-
Name of District:-
Name of Sub-Division:-
Name of Municipality:-
Serial No.   ST's population in    Ward No.     Other's         Ward No.            ST's              Ward No.           Total            Ward No.
             descending order                   population in                       population in                        population in
                                                descending                          descending                           descending
                                                order                               order                                order
             Ward number reserved for backward class.                                  District Magistrate"
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
94. Form 7, 8 and 9 only indicate total population of the ward and population of SC/ST in the ward.
They do not indicate data of population for providing reservation, be it for SC, ST or OBC Category,
which is definitely not in consonance with the directions issued in Vikas Kishanrao Gawali3; Suresh
Mahajan4 and Rahul Ramesh Wagh5, for there being no study of political backwardness even
amongst the EBC category. Also, whether data of the population furnished is in respect to the entire
population of general category, OBC category or only EBC category, is not clear. At least, the Form
does not create any distinction. So if the seats are reserved for OBC category as a whole, then
obviously the stand of the State is incorrect, if not false. Even if it is confined only to EBC category,
then also it falls foul of the mandate of the law.Bhekhari Sah vs The State Of Bihar on 4 October, 2022

95. We may further add that the procedure and pattern adopted by the Government/Election
Commission in reserving the seats for the OBC category in all the Municipalities, be it Municipal
Corporation, Municipality or Nagar Parishad, is identical. In other words, reservation across the
board is provided without evaluating any Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
parameters, except population and also judging its overbreadth.
96. Vide communication No. 2327 dated 09.08.2022, the Election Commission issued guidelines for
effecting reservation in favour of Backward Class category in various local bodies across the State
based on population alone, uniformly at the rate of 20% across all the local bodies without enquiring
into the nature and implications of at least political backwardness. Also it does not clarify the
distinction between OBC and EBC category.
97. No point of reference to the Backward Class Commission or Extremely Backward Class
Commission for ascertaining political backwardness is placed on record. It is also not the pleaded
case that the list notified in the year 2015 was prepared with such an intent and endeavour. In fact,
it could not have been, given the Government's own stand. Identification is an ongoing process. It
cannot be static. Between the preparation of the last list, one full term of an elected body is over. The
exercise undertaken by Kalekar and Mungerilal Commissions was not from the point of political
backwardness but instead identifying socially and economic backwards castes.
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
98. Further, with the Amending Act, 2007, i.e. Bihar Act 5 of 2007, the Bihar State Commission of
Backward Class Act, 1993 Act No. 12 of 1993 stood amended.
99. A plain reading of the amended provision implies the scope of the Bihar State Backward Class
Commission to be narrowed down and limited to deal only with the issues of the castes identified in
the list contained in Schedule-II, which is of the OBC Category and not the list of caste contained in
Schedule-1 pertaining to the EBC Category.
100. If that were so, the corollary thereof is that there is no authority to examine the complaints and
issues arising from the inclusion and exclusion of castes in the list contained under Schedule-1, i.e.
in respect of the EBC Category.
101. Reservation in elections at different levels is a concept not alien to the Indian polity. The Morley
Minto Reforms, 1909; the Indian Council Act, 1909; the Constitution of India, 1950 (Part- XVI) are
evidently clear on the issue. Reservation at the grass root level, rural and urban, Patna High Court
CWJC No.12514 of 2022 dt.04-10-2022 stands constitutionally acknowledged with the enactment of
the 73rd and 74th Amendment.
102. Notwithstanding the laudable object and tremendous exercise carried out by the Government,
in ameliorating the sufferings of the deprived and the downtrodden in providing assistance and
reservation in the field of education or employment, to our mind, still, the position would remain
unchanged. For, as we notice, such an endeavour is based only on the point of social and economicBhekhari Sah vs The State Of Bihar on 4 October, 2022

backwardness and no more, unlike the mandate of K. Krishna Murthy2 set out particularly in the
following para.
"56. The objectives of democratic decentralisation are not only to bring governance
closer to the people, but also to make it more participatory, inclusive and accountable
to the weaker sections of society. In this sense, reservations in local self-government
are intended to directly benefit the community as a whole, rather than just the elected
representatives. It is for this very reason that there cannot be an exclusion of the
"creamy layer" in the context of political representation. There are bound to be
disparities in the socio-economic status of persons within the groups that are the
intended beneficiaries of reservation policies. While the exclusion of the "creamy
layer" may be feasible as well as desirable in the context of reservations for education
and employment, the same principle cannot be extended to the context of local
self-government."
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 (Emphasis supplied)
103. Equal status and opportunity, be it in social, economic or political fields, and to make unequal
equal, is a facet of equality. All the stakeholders have to ensure that the citizens are rendered justice
for achieving the goals set out in the preamble. Providing reservations without setting out the
essential parameters or ensuring compliance only perpetuates inequality. Having acquired benefits
of reservation in service, a person of means may still be backward in the political field.
104. There is no statistical data on the Population of EBC(s) within the Local Bodies, nor is there any
data relating to proportional representation of EBC in Local Self Government, particularly in the
Municipalities, meeting the requirement of the triple test. The Government, without collecting
empirical data or conducting a study, also about the political backwardness, carried out the exercise
of reserving seats purely based on population, and that too, perhaps for EBC category. The same
cannot be the solitary basis for providing reservations.
105. In Sanjay Kumar9, disposed of on 01.12.2016, the petitioner was seeking inclusion of the list
contained in Schedule II of Act 3, 1992 into the Panchayati Patna High Court CWJC No.12514 of
2022 dt.04-10-2022 Raj Act, 2006. It is against this backdrop that the Court while applying the
principle of casus omissus, dismissed the petition.
106. In the considered opinion of this Court, the issue in hand was neither raised nor dealt with
therein. Here, the issue is as to whether, for the reservation to the OBC Category, any study based on
empirical data, more so about political backwardness, was ever conducted by any Commission,
much less an independent Commission. Thus, when the Court was not dealing with the issue with
which we are concerned, reliance upon the judgment is misconceived.
107. Hence, in our considered view, the Government has failed to establish compliance of the
Second Test Principle of "Specification of the proportion of reservation required in light of the
recommendations of the Commission".Bhekhari Sah vs The State Of Bihar on 4 October, 2022

THIRD TEST
108. On the third test principle, i.e. statutory limit of reservation of 20% for the OBC category, we do
not find, save, and except for one or two solitary instances that too unsubstantiated to have been
breached. As such, we need not labour on the issue any further. In any event, no material indicates
the impugned action of providing reservation Patna High Court CWJC No.12514 of 2022
dt.04-10-2022 through various notifications/circulars/orders to be in excess of the combined upper
limit of 50 per cent for all categories/classes/persons.
DELAY IN ASSAILING THE IMPUGNED ACTION
109. It is argued that since in the last three elections of the Municipalities, none raised any objection
and that petitioners have failed to discharge the onus of the impugned action to be arbitrary, much
less manifestly arbitrary, all petitions should be dismissed.
110. In our considered view, the contention needs to be repelled, for the petitions, even though filed
belatedly, just before the commencement of the process of elections, had pointed out illegality,
which is ex facie glaring and, as such, delay in approaching the Court cannot be a ground for their
dismissal more so when K. Krishna Murthy2 was required to be complied with in the year 2010
itself. Illegality cannot be allowed to be perpetuated any further. Article 141 of the Constitution of
India mandates all, even us, to ensure compliance of dicta of Hon'ble the Supreme Court.
111. Here only we may add that the five-year term of the preceding bodies stood expired in June
2022, and Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 under sub-section 9 of Section
12, in the interregnum, the State Government appointed Administrator(s) to administer the offices
of the Municipalities, with the term ending December 2022.
112. Well, the Government and the Election Commission were aware of their duties. They failed, but
the opportunity to take remedial measures is yet not extinguished.
Role of Election Commission
113. There cannot be any disagreement on the suggestion made by the learned Amicus Curiae that
the Election Commission is an autonomous and independent body duly empowered and authorized
to take decisions under the Constitution.
114. A conjoint reading of Articles 243-K, 243-Z, 324 and Part-XV of the Constitution of India
mandates the superintendence, direction and control of the preparation of electoral rolls and the
conduct of all elections to the Municipalities to be that of the State Election Commission.
115. The Hon'ble Apex Court in Kishansingh Tomar vs Municipal Corporation Ahmedabad;13
observed (2006) 8 SCC 352 Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 that:- 1. there
should not be any delay in the Constitution of the new Municipality every five years. 2. the State
Governments must acknowledge and recognise the significance of the State Election Commission,Bhekhari Sah vs The State Of Bihar on 4 October, 2022

being a constitutional body. 3. The directions of the Commission bind the Government. 4. In the
domain of elections to the panchayats and the municipal bodies under Part IX and Part IX-A for the
conduct of the elections to these bodies, they enjoy the same status as the Election Commission of
India. 5. Further, the words "superintendence, direction and control"
and "conduct of elections" have to be held in the "broadest of terms". [Special
Reference No. 1 of 2002, In re [Special Reference No. 1 of 2002, In re, (2002) 8 SCC
237] and Mohinder Singh Gill case [Mohinder Singh Gill v. Chief Election Commr.,
(1978) 1 SCC 405]. 6. The powers of the State Election Commission in respect of the
conduct of elections are akin to that of the Election Commission of India. 7. The State
Election Commissions are to function independent of the State Governments
concerned in their powers of superintendence, direction and control of all elections
and preparation of electoral rolls for, and the conduct of, all elections to the
panchayats and municipalities.
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
116. It further added that "8. Also, for the independent and effective functioning of the State Election
Commission, where it feels that it is not receiving the cooperation of the State Government
concerned in discharging its constitutional obligation of holding the elections to the panchayats or
municipalities within the time mandated in the Constitution, it will be open to the State Election
Commission to approach the High Courts, in the first instance, and thereafter the Supreme Court for
a writ of mandamus or such other appropriate writ directing the State Government concerned to
provide all necessary cooperation and assistance to the State Election Commission to enable the
latter to fulfil the constitutional mandate."
(Emphasis supplied)
117. The position stands reiterated in State of Goa and another v. Fouziya Imtiaz Shaikh and
another.14
118. The Election Commission was fully aware of the directions issued by the Hon'ble Apex Court in
Rahul Ramesh Wagh5. In fact, vide communications dated 04.01.2022, 24.01.2022 (Page 280,281),
while annexing a copy of the judgment/order, had informed the Government of (20021) 8 SCC 401
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 its necessity to comply with the same. A
reminder to a similar effect is dated 28.01.2022 (Page 292)
119. Still, further, we find from the communication dated 28.03.2022 (Page 303) that while quoting
relevant paragraphs of the judgment in Rahul Ramesh Wagh5, Manmohan Nagar6, Vikas Kishanrao
Gawali3 and K. Krishnamurthy, the Election Commission had asked the Government to make
suitable mechanism, administrative as also legislative for complying with the directions.
120. Even after receipt of the Government's communication dated 01.04.2022 (Page 66), Election
Commission vide communication dated 11.05.2022 (PageBhekhari Sah vs The State Of Bihar on 4 October, 2022

307) and 16.06.2022 (Page 323) annexing the judgments/orders passed by the Apex Court in Suresh
Mahajan4, suggested a suitable action.
121. Hence, no plausible explanation is forthcoming from the Election Commission for initiating the
election process by providing reservation to the OBC category.
122. The only explanation that the Election Commission has furnished is its affidavit dated
20.09.2022 (Page-279), is extracted as under:-
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 "13. That the statements
made in paragraph-9 of the writ petition under reply are matter of records and in this
respect, it is stated and submitted that upon query made by the State Election
Commission, the Urban Development and Housing Department has informed the
Commission that on the basis of opinion of Law Department, there is no hurdle in
conducting the election of the Municipality and on the basis of the aforesaid letter the
Commission has taken further steps for conducting the Municipal Election
accordingly."
123. The Election Commission is definitely not subservient to the Government. It did not revise its
opinion. It did not seek any legal opinion before acting on the government's dictas. Also, it did not
seek recourse to any legal remedy. The Hon'ble Apex Court had subjected the State Election
Commission to be bound by its order. Despite all this, the Election Commission proceeded to
conduct the election. In this backdrop, we may observe that despite our suggestions vide order dated
29.09.2022, reproduced hereinunder, when the judgment was reserved, even till the date of
pronouncement, as we understand, the Election Commission, by not taking any action of
rescheduling the elections qua OBC/EBC Category, has failed to discharge its constitutional
obligation and duties.
"29.09.2022 We have heard all the learned counsel appearing for the parties.
Judgment reserved.
Petitioners have been insisting on passing an order on their applications seeking
interim relief. We are of the considered view that since the hearing is complete Patna
High Court CWJC No.12514 of 2022 dt.04-10-2022 and we propose to pronounce the
judgment in immediate future, perhaps even during the period of vacation, we deem
it appropriate not to pass any order staying the process of elections.
However, we clarify that the such process shall be undertaken subject to the outcome
of the present petitions, which fact shall be notified to all concerned. We may also
clarify that, should the State Election Commission find it prudent to defer the 1st
phase of the elections, which is scheduled to be held on 10 th of October, 2022, it
shall be open for them to do so, more so considering their view expressed vide
various communications dated 24th of January, 2022 (page-281), 28th January,Bhekhari Sah vs The State Of Bihar on 4 October, 2022

2022 (page-292), 28th of March, 2022 (Page-303), 20th of April, 2022 (page-306)
and 11th of May, 2022 (page-307) addressed to the State of Bihar."
Relevance of Full Bench Decision of this Court
124. Whether the issue in hand is covered with the decisions rendered by a Full Bench of this Court
in Vijay Kumar Singh7 or not, as is so canvassed heavily by the State, is what we now proceed to
examine. Special Leave Petition assailing the judgment was disposed of in Saran Jila Mukhiya
Sangh8 [vide order dated 06.03.2018 (page 441)] in terms of the order passed in K. Krishna
Murthy2.
125. Our opinion cannot be and does not conflict with the opinion rendered by the Full Bench.
There, the Court examined the constitutional validity of the Statute, inter alia, providing reservation
and its extent to the OBC category. In the instant case, none has challenged the extent of
reservation, similar in nature, as was provided under the Patna High Court CWJC No.12514 of 2022
dt.04-10-2022 Panchayati Raj Act, 2006. Post rendering of such decision, the local self Government
institutions under part-IX and IX-A of the Constitution are fully covered vide dicta of K. Krishna
Murthy2.
126. Significantly, the Full Bench itself noticed the earlier view expressed by this Court of the
necessity of providing reservation to those, even amongst the backward caste, who lacked power in
the political field. (Para-8 and
12). This is exactly what the authorities are now required to do.
Deputy Chief Councillor/Deputy Mayor
127. In the case of Shri Ram Krishna Dalmia & Ors. Vs. Shri Justice S.R. Tendolkar and Others, 15
Hon'ble the Supreme Court has culled out the following principles to be applied in examining the
Constitutional validity of a statute:-
"11. (a) that a law may be constitutional even though it relates to a single individual if,
on account of some special circumstances or reasons applicable to him and not
applicable to others, that single individual may be treated as a class by himself;
(b) that there is always a presumption in favour of the constitutionality of an
enactment and the burden is upon AIR 1958 SC 538 Patna High Court CWJC
No.12514 of 2022 dt.04-10-2022 him who attacks it to show that there has been a
clear transgression of the constitutional principles;
(c) that it must be presumed that the Legislature understands and correctly
appreciates the need of its own people, that its laws are directed to problems made
manifest by experience and that its discriminations large based on adequate grounds;Bhekhari Sah vs The State Of Bihar on 4 October, 2022

(d) that the Legislature is free to recognise degrees of harm and may confine its
restrictions to those cases where the need is deemed to be the clearest;
(e) that in order to sustain the presumption of constitutionality the Court may take
into consideration matters of common knowledge, matters of common report, the
history of the times and may assume every State of facts which can be conceived
existing at the time of legislation; and
(f) that while good faith and knowledge of the existing conditions on the part of a
Legislature are to be presumed, if there is nothing on the face of the law or the
surrounding circumstances brought to the notice of the Court on which the
classification may reasonably be regarded as based, the presumption of
constitutionality cannot be carried to the extent of always holding that there must be
some undisclosed and unknown reasons for subjecting certain individuals or
corporations to hostile or discriminating legislation.
The above principles will have to be constantly borne in mind by the Court when it is called upon, to
adjudge the constitutionality of any particular law attacked as discriminatory and violative of the
equal protection of the laws."
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
128. With effect from 2nd of April, 2022, Section 29 of the Bihar Municipal Act was amended so as
to introduce the office of Deputy Chief Councillor and Deputy Mayor. The Deputy Chief Councillor
and the Deputy Mayor have a limited role to play. Only if the main post falls vacant or the
incumbent is enable to exercise the powers, be it for whatever reason and period, the next in line
would take over. Till such time, the regular incumbent to the main post joins or is elected.
129. Challenge to the same, in our considered view needs to be repelled in view of the three-Judge
Bench judgment of this Court in the case of Vijay Kumar Singh7 which has attained finality in Saran
Jila Mukhiya Sangh8 (Page 441), wherein the Apex Court observed as under:-
"82 (v) The reservation of chairperson posts in the manner contemplated by Article
243-D(4) and 243-T(4) is constitutionally valid. These chairperson posts cannot be
equated with solitary posts in the context of public employment."
130. Equally, the observations of the Constitution Bench in K. Krishna Murthy2 would be of
significance, relevant part thereof is quoted hereunder:-
"74. The offices of chairpersons in panchayats and municipalities are reserved as a
measure of protective discrimination, so as to enable the weaker sections to assert
their voice against entrenched interests at the local level. Patna High Court CWJC
No.12514 of 2022 dt.04-10-2022 The patterns of disadvantage and discrimination
faced by persons belonging to the weaker sections are more pervasive at the localBhekhari Sah vs The State Of Bihar on 4 October, 2022

level..."
"80. ... The position has been eloquently explained in the respondents' submissions,
wherein it has been stated that "the asymmetries of power require that the
chairperson should belong to the disadvantaged community so that the agenda of
such panchayats is not jijacked for majoritarian reasons."
(Emphasis supplied)
131. Hence, the challenge to the reservation of posts of Deputy Mayor/Deputy Councillor/ other
similar posts is not illegal and/or unsustainable. Equally, Section 2(100) of the Bihar Municipal Act,
2007 cannot be said to be ultra vires, clarifying that the entries in the Schedule cannot be the basis
for reservation to the category of OBC for the purpose of Section- 12/13 of the Municipal Act.
132. No other points urged.
CONCLUSION
133. In the light of the arguments advanced, cases and reports referred to and, the discussion that
followed, the following are the conclusions: -
(i) The commissions formed under the Backward Classes Act and the Commission for
Extremely Backward Classes both were formed for purposes independent and
distinct from ascertaining political backwardness as required Patna High Court
CWJC No.12514 of 2022 dt.04-10-2022 by K. Krishna Murthy2; Vikas Kishanrao
Gawali3;
Suresh Mahajan4; Rahul Ramesh Wagh5; Manmohan Nagar6. The same were for the purposes of
evaluating and computing socially and economically backward castes of any character.
(ii) The Lists/Annexures/Schedule/Entries in the Schedule to the Bihar Reservation of Vacancies in
Posts and Services (for Scheduled Castes, Scheduled Tribes and Other Backward Classes) Act, 1991,
be it by whatever name, are prepared for the purposes of conferring benefit under Article 15(4) and
16(4) and not Article 243-T of the Constitution of India.
(iii) The anomalous situation presented by the instant case may be as a result of a number of
overlapping statutes, muddying the waters as opposed to facilitating smooth functioning of
providing reservations under socio- economic/ educational/ services/ elections, as the case may be.
(iv) The State of Bihar has not undertaken any exercise by which the criteria adopted for providing
reservations under socio-economic/ educational/ services have been adopted for the purposes of
ensuring electoral Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 representation of Other
Backward Classes, including Extremely Backward Classes.Bhekhari Sah vs The State Of Bihar on 4 October, 2022

134. As such, we hold that -
(i) Action of the Government as also the Election Commission in reserving the seats for the
OBC/EBC category for election to all the municipal bodies in the State of Bihar, governed under the
Bihar Municipal Act, 2007 (Act No. 11 of 2007), sans compliance of the dictum laid down by Hon'ble
the Supreme Court in Sunil Kumar1; K. Krishna Murthy2; Vikas Kishanrao Gawali3; Suresh
Mahajan4; Rahul Ramesh Wagh5; Manmohan Nagar6 to be illegal.
(ii) Statutory reservation of seats for the post of Deputy Mayor/Deputy Councillor or similar posts is
permissible in law.
135. We direct-
(i) Respondent No.4, namely The Secretary, State Election Commission, to carry out the elections
only by immediately re-notifying the seats reserved for the OBC Category treating them as general
category seats. Our direction, similar in nature, is based on the dictum of Hon'ble the Supreme
Court.
Patna High Court CWJC No.12514 of 2022 dt.04-10-2022
(ii) The impugned notifications/circulars referred to in paragraph 32 shall stand modified to the
aforesaid extent.
(iii) The Election Commission shall review its functioning as an autonomous and independent body,
not bound by the dictates of the Government of Bihar.
(iv) The State of Bihar may consider enacting a comprehensive legislation pertaining to reservations
in elections to local bodies, urban or rural, to bring the State seamlessly in line with the directions
issued by Hon'ble the Apex Court in K. Krishna Murthy2; Sunil Kumar1; Vikas Kishanrao Gawali3;
Suresh Mahajan4; Rahul Ramesh Wagh5; Manmohan Nagar6.
(v) Let a copy of this judgment be communicated to the Chief Secretary, Government of Bihar and
the State Election Commissioner for taking all consequential action.
136. We place on record our appreciation for the assistance rendered to the Court by all the learned
senior advocate(s)/advocate(s) appearing on behalf of the parties, Shri Amit Shrivastava, learned
Senior Advocate, Amicus Patna High Court CWJC No.12514 of 2022 dt.04-10-2022 Curiae, and with
special reference to Ms. Shristhi, Advocate and Mr. Ravi Ranjan, Advocate, who are young at the
Bar.
137. The petitions are allowed and disposed of in the aforesaid terms.
138. Interlocutory Application(s), if any, shall stand disposed of.Bhekhari Sah vs The State Of Bihar on 4 October, 2022

139. Shri Girish Pandey, learned counsel appearing for the State Election Commission, undertakes
to communicate this judgment to the authority concerned immediately.
                                                                    (Sanjay Karol, CJ)
                      S. Kumar, J.       I agree.
                                                                      (S. Kumar, J)
KCJha/PKP/Sujit
AFR/NAFR                AFR
CAV DATE                29.09.2022
Uploading Date          04.10.2022
Transmission DateBhekhari Sah vs The State Of Bihar on 4 October, 2022

