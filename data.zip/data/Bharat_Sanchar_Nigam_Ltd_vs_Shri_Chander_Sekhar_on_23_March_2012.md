Bharat Sanchar Nigam Ltd. vs Shri Chander Sekhar on 23
March, 2012
Author: Rajiv Sahai Endlaw
Bench: Rajiv Sahai Endlaw
          *IN THE HIGH COURT OF DELHI AT NEW DELHI
%                                      Date of decision: 23rd March, 2012
+                        LPA No. 900/2010
BHARAT SANCHAR NIGAM LTD.                     ..... Appellant
                Through: Mr. Sameer Agarwal, Advocate
                                  Versus
SHRI CHANDER SEKHAR                                        ..... Respondent
                Through:              Mr. Surinder Bir, Advocate.
CORAM :-
HON'BLE THE ACTING CHIEF JUSTICE
HON'BLE MR. JUSTICE RAJIV SAHAI ENDLAW
RAJIV SAHAI ENDLAW, J.
1. This Intra-Court appeal impugns the judgment dated 03.05.2010 of the learned Single Judge
dismissing W.P.(C) No.2946/2010 preferred by the appellant. The said writ petition was preferred
impugning the order dated 10.11.2009 of the Central Information Commission (CIC) allowing the
appeal filed by the respondent and directing the appellant to disclose the information sought.
2. The appellant had floated a tender titled „GSM Phase-VI for the installation of 93 million GSM
lines in four parts. M/s KEC International Ltd. was one of the bidders in the said tender. The
respondent, claiming to be one of the shareholders of the said KEC International Ltd., on
02.07.2009 applied under the provisions of the Right to Information Act, 2005 seeking the
following information:
"a. Copy of the complete Report of Evaluation of Tender on the Financial Bids
received from various bidders against Part 3 of Tender No. IMPCS/PHASE
VI/WZ/CGMT-MH/2008-09/1 dated 01.05.2009 opened on 28.02.2009 for West
Zone;
b. Copy of the complete Report of Evaluation of Tender on the Financial Bids
received from various bidders against Part 3 of Tender No.CTD/IMPCS/TENDER/
PHASE VI/2008-09 dated 01.05.2009 opened on 28.02.2009 for East Zone;Bharat Sanchar Nigam Ltd. vs Shri Chander Sekhar on 23 March, 2012

c. Copy of the complete Report of Evaluation of Tender on the financial Bids received
from various bidders against Part 3 of Tender No. CMTS/PB/P&D/PHASE
VI/25M/TENDER/2008-09 dated 01.05.2009 opened on 28.02.2009 for North
Zone;
d. Copy of the complete Report of Evaluation of Tender on the Financial Bids
received from various bidders against Part 3 of Tender No. TA/Cellone/SZ/2008/01
dated 01.05.2009 opened on 28.02.2009 for South Zone."
The respondent further claimed that by then the financial bids had been opened in
February, 2009 and evaluation thereof was over.
3. The CPIO of the appellant vide letter dated 30.07.2009 declined the request of the respondent for
information on the ground that the information sought was of "commercial confidence" in nature
and claiming exemption from disclosure under Section 8(1)(d) of the Act.
4. The respondent preferred first appeal contending that, the appellant was a Government of India
enterprise carrying on works in public interest, utilizing government funds; that the tenders were
open tenders; the financial bids were already read out to other bidders at the time of opening of the
bids and nothing confidential remained therein; that the bidding process having attained finality, no
issues of commercial confidence remained. The first appellate authority however vide order dated
08.09.2009 confirmed the order of the CPIO, also for the reason of the appellant having signed Non
Disclosure Agreements with all the participating vendors and the disclosure of the information
sought being in violation of the said agreement.
5. The CIC in its order dated 10.11.2009 allowing the appeal of the respondent observed / held, i)
that the evaluation process stood completed and thus the commercial position of any of the bidders
could not be adversely affected by such disclosure; ii) the exemption under Section 8(1)(d) of the Act
is not available since the information was already in public domain owing to the finalization and
completion of the bidding process and evaluation and cannot pose a threat to the competitive
position of any of the bidders; iii) it was in the larger public interest to disclose such information; iv)
that the Non Disclosure Agreements were valid only for the "Confidentiality Period" i.e. till the
opening of the bids; v) even otherwise such Non Disclosure Agreements debarring access to
information and thereby disrupting the transparency and accountability of the public authority were
in violation of the very spirit of the Act and therefore illegal to the extent they prevented disclosure
beyond what was exempted under the Act; vi) that thus the Non Disclosure Agreements if prevented
disclosure beyond the confidentiality period also, were illegal; vii) that the public interest "far
outweighs the weak contentions put up by the appellant to protect the so called private interests";
viii) that even though the tender process had been challenged in some of the High Courts but the
same also did not entitle the appellant to exemption. Accordingly, directions for disclosing the
information were issued.
6. The learned Single Judge dismissed the writ petition preferred by the appellant impugning the
order aforesaid of the CIC observing / holding,Bharat Sanchar Nigam Ltd. vs Shri Chander Sekhar on 23 March, 2012

a) that the writ petition filed by KEC International Ltd. impugning the tender process had been
finally dismissed by the Supreme Court finding no illegality in the decision making process and
declaring the party which was awarded the contract as the lowest bidder - thus the objection to
disclosure of information on the ground of the matter being sub judice did not survive;
b) that the plea of the appellant of the confidentiality period as per the Non Disclosure Agreements
being in vogue for the reason of the formal contract having not been entered into with the successful
bidder was of no avail since the bidding process was complete and the selection of the successful
bidder stood finalized; c) again for the reason of the bidding process having stood completed, the
question of the commercial interest of any of the bidders being adversely affected by the disclosure
did not arise; d) Section 22 of the Act gives effect to the provisions of the Act notwithstanding
anything inconsistent therewith contained in the Official Secrets Act, 1923 and any other law for the
time being in force or in any instrument having effect by virtue of any law other than the RTI Act -
consequently the Non Disclosure Agreements cannot be used by the appellant to defeat the right to
information under the Act; e) even otherwise the Non Disclosure Agreements cannot be said to
extend beyond the confidentiality period defined in the agreement itself as the period between the
opening of the tender and the finalization of the bids.
7. It was the contention of the appellant before this Bench that the bids in the tender aforesaid had
never been given the shape of the contract and had been cancelled. This Bench before issuing notice
of the appeal directed the filing of an affidavit in this regard by the Chairman of the appellant. An
affidavit dated 24.01.2011 has been filed informing that the bids were evaluated and L1, L2 etc.
selected for Part-III and price negotiations held with L1; that after negotiations the rates were
recommended by the Negotiation Committee to the competent authority for finalization / approval;
that since the case pertaining to GSM Phase-VI was being examined qua the allegation of
irregularity, the competent authority in its wisdom cancelled / scrapped the tender; as a result of the
scrapping, no contract came into existence and even the Advance Purchase Order was not issued;
that thus no question of giving any kind of information arose; that making public the confidential
information of the tenderers particularly in view of signing of the Non Disclosure Agreements would
certainly affect the goodwill of the appellant and would result in reduction in number of
participating vendors / tenderers in subsequent tenders floated by the appellant and which would
further result in monetary loss as due to reduction in competition there would be an increase in
prices.
8. The appellant during the hearing has placed reliance on judgment of this Court in Exmar NV Vs.
Union of India 2006 (1) RAJ 229 (DB) on the aspect of when the contract can be said to be
concluded. It has further been contended that the learned Single Judge has failed to notice Clause 18
of the Non Disclosure Agreement whereunder the obligations of confidentiality were to survive the
expiration or termination of the agreement, for a period of two years from the date the confidential
information was disclosed or the completion of business purpose, whichever is later. It is yet further
urged that the learned Single Judge has wrongly assumed that the contract stood awarded to the
successful bidder.Bharat Sanchar Nigam Ltd. vs Shri Chander Sekhar on 23 March, 2012

9. Per contra, the respondent in the reply filed to the appeal has pleaded that the appellant inspite of
numerous representations and Court cases averring irregularities, stonewalled and did not come
clean; that ultimately on representations to the Prime Ministers Office, a High Powered Committee
was constituted which found irregularities in the evaluation process and recommended the
scrapping of the tender; that the objection of the appellant to disclosure of information is not for
protection of the commercial and confidential information furnished by any of the bidders but to
safeguard its own misdeeds during the evaluation process; that the Non Disclosure Agreements
signed by the appellant with the bidders are contrary to the spirit of the Act and illegal; that the
reluctance of the appellant to disclose information relating to the tender which had already been
scrapped was incomprehensible; that the commercial confidentiality of bids is over once the
financial bids are opened and prices of all items of all the bidders including other details are
disclosed to all the bidders; that in fact in one of the writ petitions aforesaid in other High Courts
challenging the tender such information had already been brought in public domain. The counsel for
the respondent during the hearing has also relied on the judgment dated 02.07.2009 of the High
Court of Punjab & Haryana in W.P.(C) No.9474/2009 titled Nokia Siemens Networks Pvt. Ltd. Vs.
Union of India and on Canara Bank Vs. The Central Information Commission AIR 2007 Kerala 225.
He has also drawn attention to the proviso after Section 8(1)(j) of the Act laying down that the
information which cannot be denied to the Parliament or State Legislature shall not be denied to any
person. It is contended that the information aforesaid cannot be denied to the Parliament and hence
the exemptions provided in Section 8(1) of the Act would not be attracted.
10. We, at the outset, deem it appropriate to discuss the issue generally as the same is likely to arise
repeatedly. Confidentiality or secrecy is the essence of sealed bids. The same helps the contract
awarding party to have the most competitive and best rates / offer. The essential purpose of sealed
bidding is that the bids are secret bids that are intended by the vendor and expected by bidders to be
kept confidential as between rival bidders until such time as it is too late for a bidder to alter his bid.
Sealed bidding means and must be understood by all those taking part in it to mean that each bidder
must bid without actually knowing what any rival has bid. The reason for this, as every bidder must
appreciate, is that the vendor wants to avoid the bidders bidding (as they would do in open bidding
such as at an auction) by reference to other bids received and seeking merely to top those bids by the
smallest increment possible. The vendor's object is to get the bidders to bid "blind" in the hope that
then they will bid more than they would if they knew how far other bidders had gone. Additionally,
from each bidder's point of view his own bid is confidential and not to be disclosed to any other
bidder, and he makes his bid in the expectation, encouraged by the invitation to submit a sealed bid,
that his bid will not be disclosed to a rival. If, therefore, a rival has disclosed to him by the vendor
the amount of another's bid and uses that confidential information to pitch his own bid enough to
outbid the other, this is totally inconsistent with the basis on which each bidder has been invited to
bid, and the rival's bid is not a good bid; likewise if the rival adopts a formula that necessarily means
that he is making use of what should be confidential information (viz. the bid of another) in
composing his own bid. In such a case, the amount of the other's bid is being constructively divulged
to him. The process of inviting tenders has an element of secrecy − since nobody knows what would
be the bid of the competitor, every one will try to show preparedness for the best of the terms which
will be acceptable to the institution calling the tenders. This requires ensuring that the tenders are
not tampered with, the offers are not leaked to another bidder or even to the officers of theBharat Sanchar Nigam Ltd. vs Shri Chander Sekhar on 23 March, 2012

institution for which the tenders are called. Secret bids thus promote competition, guard against
favouritism, improvidence, extravagance, fraud and corruption and lead to award of contract, to
secure the best work at the lowest price practicable.
11. Over the years the secret bids are not confined to the price only, which may cease to be of any
value or lose confidentiality once the bids are opened. The bids/tenders today require the bidders to
submit in the bids a host of information which may help and be required by the tender calling
institution to evaluate the suitability and reliability of the contracting party. The bidders are often
required to, in their bids disclose information about themselves, their processes, turnover and other
factors which may help the tender calling institution to evaluate the capability of the bidder to
perform the contracted work. The secret bids/tenders are often divided into technical and financial
parts. The bidders in the technical part may reveal to the tender calling institution their technology
and processes evolved and developed by them and which technology and processes may not
otherwise be in public domain and which the bidder may not want revealed to the competitors and
which technology/processes the bidder may be using works for the other clients also and which
technology/processes if revealed to the competitors may lead to the bidder losing the competitive
edge in subsequent awards of contracts. If it were to be held that a bidder by virtue of participating
in the tender becomes entitled to all particulars in the bids of all the bidders, the possibility of
unscrupulous businessmen participating in the tender merely for acquiring such information,
cannot be ruled out. Such disclosure may lead to the competitors undercutting in future bids. We
may at this stage notice that the Freedom of Information Act prevalent in United States of America
as well as the Freedom of Information Act, 2000 in force in United Kingdom, both carve out an
exception qua trade secrets and commercial or financial information obtained from a person and
which is privileged or confidential. The tests laid down in those jurisdictions also, is of „if disclosure
of information is likely to impair governments ability to obtain necessary information in future or
to cause substantial harm to competitive position of person from whom information is obtained. It
has been held that unless persons having necessary information are assured that it will remain
confidential, they may decline to cooperate with officials and the ability of government to make
intelligent well-informed decisions will be impaired. Yet another test of whether the information
submitted with the bids is confidential or not is of „whether such information is generally available
for public perusal and of whether such information „is customarily made available to the public by
the business submitter. If it is not so customarily made available, it is treated as confidential.
12. Though the report of the appellant of evaluation of tenders, is a document of the appellant but
the evaluation therein is of the tenders of the various bidders and the report of evaluation may
contain data and other particulars from the bids and which data/particulars were intended to be
confidential. If any part of the bids is exempt from disclosure, the same cannot be supplied obliquely
through the disclosure of evaluation report.
13. What thus emerges is that a balance has to be struck between the principle of promoting honest
and open government by ensuring public access to information created by the government on the
one hand and the principle of confidentiality breach whereof is likely to cause substantial harm to
competitive position of the person from whom information is obtained and the disclosure impairing
the governments ability to obtain necessary information in future on the other hand. Also, whatBharat Sanchar Nigam Ltd. vs Shri Chander Sekhar on 23 March, 2012

has been discussed above may not apply in a proceeding challenge wherein is to the evaluation
process. It will then be up to the Court before which such challenge is made, to decide as to what
part of the evaluation process is to be disclosed to the challengers.
14. Questions also arise as to the information contained in the bids / tenders of the unsuccessful
tenderers. Often it is found that the same is sought, to know the method of working and to adversely
use the said information in future contracts. Generally there can be no other reason for seeking such
information.
15. Once we hold that the information of which disclosure is sought relates to or contains
information supplied by a third party and which the third party may claim confidential, the third
party information procedure laid down in Section 11 of the Act is attracted. The said aspect has not
been considered either by the CIC or by the learned Single Judge.
16. What we find in the present case is that the tender process has been scrapped. The information
which is being sought relates to the evaluation of the bids by the appellant. Though the Non
Disclosure Agreement extended the obligation of confidentiality beyond the date of opening of the
tenders also but only for a period of two years from the date of disclosure or to the completion of
business purpose whichever is later. The business purpose stands abandoned with the scrapping of
the tenders. More than two years have elapsed from the date when the information was submitted.
Thus the said agreement now does not come in the way of the appellant disclosing the information.
However, we are of the opinion that disclosure of such information which would be part of the
evaluation process would still require the third party information procedure under Section 11 of the
Act to be followed. As aforesaid, besides the bid price, there may still be information in the bid and
which may have been discussed in the evaluation process, of commercial confidence and containing
trade secret or intellectual property of the bidders whose bids were evaluated.
17. Though in the light of the view taken by us hereinabove, the question of validity of the agreement
need not to be adjudicated but since we have heard the counsels, we deem it our duty to adjudicate
upon the said aspect also. Section 22 of the Act relied on by the learned Single Judge though giving
overriding effect to the provisions of the Act still saves the instruments "having effect by virtue of
any law other than this Act". This Court in Vijay Prakash v. Union of India AIR 2010 Delhi 7 has
held that though Section 22 the Act overrides other laws, the opening non-obstante clause in Section
8 confers primacy to the exemptions enacted under Section 8(1). Thus, once the information is
found to be exempt under Section 8(1), reliance on Section 22 is misconceived. Whether the
information is of such nature as defined in Section 8(1)(d) of the Act, can be adjudicated only by
recourse to Section 11 of the Act.
18. We however do not deem it necessary to adjudicate on the proviso after Section 8(1)(j) of the Act
and leave the same to be adjudicated in an appropriate proceedings. We may however notice that a
Division Bench of the Bombay High Court in Surupsingh Hrya Naik Vs. State of Maharashtra AIR
2007 Bombay 121 has held that the proviso has been placed after Section 8(1)(j) and would have to
be so interpreted in that context and the proviso applies only to Section 8(1)(j) and not to other sub-
sections.Bharat Sanchar Nigam Ltd. vs Shri Chander Sekhar on 23 March, 2012

19. The appeal is therefore partly allowed. The matter is remanded back to the CIC. If the
respondent is still desirous of the information sought, the CIC shall issue notice to the parties whose
bids are evaluated in the evaluation process information qua which is sought by the respondent and
decide the request of the respondent after following the procedure under Section 11 of the Act.
No order as to costs.
RAJIV SAHAI ENDLAW, J ACTING CHIEF JUSTICE MARCH 23, 2012 „gsr..Bharat Sanchar Nigam Ltd. vs Shri Chander Sekhar on 23 March, 2012

