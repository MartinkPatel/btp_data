Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008
Author: K.G. Balakrishnan
Bench: K.G. Balakrishnan, Arijit Pasayat, C.K. Thakker, R.V. Raveendran,
Dalveer Bhandari
                                                                      REPORTABLE
                      IN THE SUPREME COURT OF INDIA
                   CIVIL    ORIGINAL    JURISDICTION
                WRIT PETITION (CIVIL) NO. 265 OF 2006
ASHOKA KUMAR THAKUR                                      ....PETITIONER
                                           Versus
UNION OF INDIA & ORS.                         ....RESPONDENTS
                                       WITH
      Writ Petition (C) No. 269/2006
Writ Petition (C) No. 598/2006
Writ Petition (C) No. 29/2007
Writ Petition (C) No. 35/2007
Writ Petition (C) No. 53/2007
Writ Petition (C) No. 336/2007
Writ Petition (C) No. 313/2007
Writ Petition (C) No. 335/2007
Writ Petition (C) No. 231/2007
Writ Petition (C) No. 425/2007Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Writ Petition (C) No. 428/2007 
Contempt Petition (Civil) No. 112/2007 in 
Writ Petition (C) No. 265/2006
                                J U D G M E N T
K.G. BALAKRISHNAN, C.J.I.
1. Reservation for admission in educational institutions or for public employment has been a matter
of challenge in various litigations in this Court as well as in the High Courts. Diverse opinions have
been expressed in regard to the need for reservation. Though several grounds have been raised to
oppose any form of reservation, few in independent India have voiced disagreement with the
proposition that the disadvantaged sections of the population deserve and need "special help". But
there has been considerable disagreement as to which category of disadvantaged sections deserve
such help, about the form this help ought to take and about the efficacy and propriety of what the
government has done in this regard.
2. Pandit Jawaharlal Nehru, who presided over the Congress Expert Committee emphasized before
the Constituent Assembly that the removal of socio-economic inequalities was the highest priority.
He believed that only this could make India a casteless and classless society, without which the
Constitution will become useless and purposeless1. The Founding Fathers of the Constitution were
thus aware of the ripples of inequality present in society, decried the notion of caste and ensured
that the Constitutional framework contained adequate safeguards that would ensure the upliftment
of 1 II Constituent Assembly Debates 317 (Wednesday, January 22, 1947) the socially and
educationally backward classes of citizens, thus creating a society of equals. The interpretation of the
term "socially and educationally backward", and its constituent classes, was left for future
generations to decide.
3. Regarding equality, Dr. Ambedkar stated in the Constituent Assembly2 :
"...We must begin by acknowledging the fact that there is complete absence of two
things in Indian Society. One of these is equality. On the social plane, we have in
India a society based on the principle of graded inequality which means elevation for
some and degradation for others. On the economic plane, we have a society in which
there are some who have immense wealth as against many who live in abject
poverty."
4. Judge Lauterpacht of the International Court of Justice, writing in 1945, described the
importance of the principle of equality in the following words:-Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"The claim to equality before the law is in substantial sense the most fundamental of
the rights of man. It occupies the first place in most written constitutions. It is the
starting point of all other liberties."3
5. Equality has also been enshrined in various international 2 XI Constituent Assembly Debates 979
(Friday, November 25, 1949) 3 Lauterpacht, An International Bill of the Rights of the Man (New
York, Columbia University Press, 1945) instruments, such as the 1948 Universal Declaration of
Human Rights. Its Preamble speaks of "the equal and inalienable rights of all members of the
human family", and of "the equal rights of men and women."4
6. Reservation is one of the many tools that are used to preserve and promote the essence of
equality, so that disadvantaged groups can be brought to the forefront of civil life. It is also the duty
of the State to promote positive measures to remove barriers of inequality and enable diverse
communities to enjoy the freedoms and share the benefits guaranteed by the Constitution. In the
context of education, any measure that promotes the sharing of knowledge, information and ideas,
and encourages and improves learning, among India's vastly diverse classes deserves
encouragement. To cope with the modern world and its complexities and turbulent problems,
education is a must and it cannot remain cloistered for the benefit of a privileged few. Reservations
provide that extra advantage to those persons who, without such support, can forever only dream of
university, education, without ever being able to realize it. This advantage is necessary. In the words
of President 4 Universal Declaration of Human Rights, pmbl., G.A. Res. 217A, U.N. GAOR, 3rd
Sess., pt. 1, at 71, U.N. Doc A/810 (1948) Lyndon Johnson, "You do not take a person who, for years,
has been hobbled by chains and liberate him, bring him up to the starting line and then say, `You
are free to compete with all the others..."5
7. Dr. Rajendra Prasad, at the concluding address of the Constituent Assembly, stated in the
following words:-
"...To all we give the assurance that it will be our endeavour to end poverty and
squalor and its companions, hunger and disease; to abolish distinction and
exploitation and to ensure decent conditions of living. We are embarking on a great
task. We hope that in this we shall have the unstinted service and co-operation of all
our people and the sympathy and support of all the communities..."6
8. It must also be borne in mind that many other democracies face similar problems and grapple
with issues of discrimination, in their own societal context. Though their social structure may be
markedly different from ours, the problem of inequality in the larger context and the tools used to
combat it may be common. As stated by Justice Ruth Bader Ginsburg at the 51st Cardozo Memorial
Lecture, in 1999 :
"In my view, comparative analysis emphatically is relevant to the task of interpreting
constitutions and enforcing human rights. We are 5 President Lyndon B. Johnson,
Howard University Commencement Address, "To Fulfill These Rights", June 4, 1965
6 V Constituent Assembly Debates 2 (Thursday, the 14th August 1947) losers if weAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

neglect what others can tell us about endeavours to eradicate bias against women,
minorities and other disadvantaged groups. For irrational prejudice and rank
discrimination are infectious in our world. In this, reality, as well as the
determination to counter it, we all share."
9. We are conscious of the fact that any reservation or preference shall not lead to reverse
discrimination. The Constitution (Ninety-
Third) Amendment Act, 2005 and the enactment of Act 5 of 2007 giving reservation to Other
Backward Classes (OBCs), Scheduled Castes (SCs) and Scheduled Tribes (STs) created mixed
reactions in the society. Though the reservation in favour of SC and ST is not opposed by the
petitioners, the reservation of 27% in favour of Other Backward Classes/Socially and educationally
backward classes is strongly opposed by various petitioners in these cases. Eminent Counsel
appeared both for the petitioners and respondents. The learned Solicitor General and Additional
Solicitor General appeared and expressed their views. We have tried to address, with utmost care
and attention, the various arguments advanced by the learned counsel and we are greatly beholden
to all of them for the manner in which they have analysed and presented the case before us which is
of great importance, affecting large sections of the community.
10. By The Constitution (Ninety-Third Amendment) Act, 2005, clause (5) was inserted in Article 15
of the Constitution which reads as under :-
"Nothing in this article or in sub-clause (g) of clause (1) of article 19 shall prevent the
State from making any special provision, by law, for the advancement of any socially
and educationally backward classes of citizens or for the Scheduled Castes or the
Scheduled Tribes in so far as such special provisions relate to their admission to the
educational institutions including private educational institutions, whether aided or
unaided by the State, other than the minority educational institutions referred to in
clause (1) of article 30."
11. In Unni Krishnan, J.P. & Ors. Vs. State of Andhra Pradesh & Ors.7, it was held that right to
establish educational institutions can neither be a trade or business nor can it be a profession within
the meaning of Article 19(1)(g). This was overruled in T.M.A. Pai Foundation & Ors. Vs. State of
Karnataka & Ors.8, wherein it was held that all citizens have the fundamental right to establish and
administer educational institutions under Article 19(1)(g) and the term "occupation" in Article
19(1)(g) comprehends the establishment and running of educational institutions and State
regulation of admissions in such institutions would not be regarded as an 7 1993 (1) SCC 645 8 2002
(8) SCC 481 unreasonable restriction on that fundamental right to carry on business under Article
19(6) of the Constitution. Education is primarily the responsibility of the State Governments. The
Union Government also has certain responsibility specified in the Constitution on matters relating
to institutions of national importance and certain other specified institutions of higher education
and promotion of educational opportunities for the weaker sections of society. The Parliament
introduced Article 15(5) by The Constitution (Ninety-Third Amendment) Act, 2005 to enable the
State to make such provision for the advancement of SC, ST and Socially and EducationallyAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Backward Classes (SEBC) of citizens in relation to a specific subject, namely, admission to
educational institutions including private educational institutions whether aided or unaided by the
State notwithstanding the provisions of Article 19(1)(g). In the Statement of Objects and Reasons of
the Constitution (Ninety-Third Amendment) Act, 2005 it has been stated that :-
"At present, the number of seats available in aided or State maintained institutions,
particularly in respect of professional education, is limited in comparison to those in
private unaided institutions.
To promote the educational advancement of the socially and educationally backward
classes of citizens, i.e., the OBCs or the Scheduled Castes ad Scheduled Tribes in
matters of admission of students belonging to these categories in unaided
educational institutions other than the minority educational institutions referred to
Clause (1) of Article 30 of the Constitution, it is proposed to amplify Article 15. The
new Clause (5) shall enable the Parliament as well as the State Legislatures to make
appropriate laws for the purposes mentioned above."
12. After the above Constitution (Ninety-Third Amendment) Act, 2005, the Parliament passed The
Central Educational Institutions (Reservation in Admission) Act, 2006 (No. 5 of 2007) (hereinafter
referred to as "the Act 5 of 2007").
13. Section 3 of Act 5 of 2007 provides for reservation of 15% seats for Scheduled Castes, 7=% seats
for Scheduled Tribes and 27% for Other Backward Classes in Central Educational Institutions. The
said section is extracted below : -
"3. The reservation of seats in admission and its extent in a Central Educational
Institution shall be provided in the following manner, namely:-
(i) out of the annual permitted strength in each branch of study or faculty, fifteen per
cent seats shall be reserved for the Scheduled Castes;
(ii) out of the annual permitted strength in each branch of study or faculty, seven and
one-half per cent seats shall be reserved for the Scheduled Tribes;
(iii) out of the annual permitted strength in each branch of study or faculty,
twenty-seven per cent seats shall be reserved for the Other Backward Classes."
14. "Central Educational Institution" has been defined under Section 2(d) of the Act as follows:
2(d) "Central Educational Institution" means -
(i) a university established or incorporated by or under a Central Act;
(ii) an institution of national importance set up by an Act of Parliament;Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(iii) an institution, declared as a deemed University under section 3 of the University
Grants Commission Act, 1956, and maintained by or receiving aid from the Central
Government;
(iv) an institution maintained by or receiving aid from the Central Government,
whether directly or indirectly, and affiliated to an institution referred to in clause (i)
or clause (ii), or a constituent unit of an institution, referred to in clause (iii);
(v) an educational institution set up by the Central Government under the Societies
Registration Act, 1860.
15. The percentage of reservation to various groups such as Scheduled Castes, Scheduled Tribes and
Other Backward Classes are with reference to the annual permitted strength of the Central
Educational Institutions and the "annual permitted strength" is defined under Section2(b) of the Act
as follows:-
2(b) "annual permitted strength" means the number of seats, in a course or
programme for teaching or instruction in each branch of study or faculty authorized
by an appropriate authority for admission of students to a Central Educational
Institution
16. Section 4 of the Act specifically says that the provisions of Section 3 shall apply to certain
institutions. Section 4 reads as under:-
4. The provisions of Section 3 of this Act shall not apply to -
(a) a Central Educational Institution established in the tribal areas referred to in the
Sixth Schedule to the Constitution;
(b) the institutions of excellence, research institutions, institutions of national and
strategic importance specified in the Schedule to this Act;
Provided that the Central Government may, as and when considered necessary, by notification in
the Official Gazette, amend the Schedule;
(c) a Minority Educational Institution as defined in this Act;
(d) a course or programme at high levels of specialization, including at the post-doctoral level,
within any branch or study or faculty, which the Central Government may, in consultation with the
appropriate authority, specify."
17. "Minority Educational Institution" is defined in Section 2(f) of the Act as follows:-Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"Minority Educational Institution" means an institution established and
administered by the minorities under clause (1) of article 30 of the Constitution and
so declared by an Act of Parliament or by the Central Government or declared as a
Minority Educational Institution under the National Commission for Minority
Educational Institutions Act, 2004"
18. Section 2(g) defines "Other Backward Classes" as under:-
"Other Backward Classes" means the class or classes of citizens who are socially and
educationally backward, and are so determined by the Central Government"
19. Clause 2(h) defines "Scheduled Castes" and clause 2(i) defines "Scheduled Tribes" as under:
"Scheduled Castes" means the Scheduled Castes notified under article 341 of the
Constitution;
"Scheduled Tribes" means the Scheduled Tribes notified under article 342 of the
Constitution.
20. Section 5 of the Act mandates the increase of seats in the Central Educational Institutions by
providing reservation to Scheduled Castes, Scheduled Tribes and Other Backward Classes. Section 5
reads as follows:-
"5.(1) Notwithstanding anything contained in clause (iii) of section 3 and in any other
law for the time being in force, every Central Educational Institution shall, with the
prior approval of the appropriate authority, increase the number of seats in a branch
of study or faculty over and above its annual permitted strength so that the number
of seats, excluding those reserved for the persons belonging to the Scheduled Castes,
the Scheduled Tribes and the Other Backward Classes, is not less than the number of
such seats available for the academic session immediately preceding the date of the
coming into force of this Act.
(2) Where, on a representation by any Central Educational Institution, the Central
Government, in consultation with the appropriate authority, is satisfied that for
reasons of financial, physical or academic limitations or in order to maintain the
standards of education, the annual permitted strength in any branch of study or
faculty of such institution cannot be increased for the academic session following the
commencement of this Act, it may permit by notification in the Official Gazette, such
institution to increase the annual permitted strength over a maximum period of three
years beginning with the academic session following the commencement of this Act;
and then, the extent of reservation for the Other Backward Classes as provided in
clause (iii) of section 3 shall be limited for that academic session in such manner that
the number of seats available to the Other Backward Classes for each academic
session are commensurate with the increase in the permitted strength for each year."Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

21. By virtue of definition of the "Central Educational Institutions"
under clause (d)(iv) of Section 2 of the Act, all institutions maintained by or receiving
aid from the Central Government whether directly or indirectly, and affiliated to any
university or deemed university or institution of national importance, in addition to
universities which are established or incorporated under a Central Act, institutions of
national importance set up by Acts of Parliament, deemed universities maintained or
receiving aid from Central Government and institutions set up by the Central
Government with the Societies Registration Act, 1960, are brought under the purview
of reservation under Section 3 of the Act. The object of the Act is to introduce in
reservation in only such institutions which are defined as "Central Educational
Institutions" and not any other private unaided institutions.
22. The Statement of Objects and Reasons for the Act gives the object of the Act thus :-
"Greater access to higher education including professional education, to a large
number of students belonging to the socially and educationally backward classes of
citizens or for the Scheduled Castes and Scheduled Tribes, has been a matter of major
concern. The reservation of seats for the Scheduled Castes, the Scheduled Tribes and
the Other Backward Classes of citizens (OBCs) in admission to educational
institutions is derived from the provisions of clause (4) of article 15. At present, the
number of seats available in aided or State maintained institutions, particularly in
respect of professional education, is limited in comparison to those in private
unaided institutions.
2. It is laid down in article 46, as a directive principle of State policy, that the State
shall promote with special care the educational and economic interests of the weaker
sections of the people and protect them from social injustice. Access to education is
important in order to ensure advancement of persons belonging to the Scheduled
Castes, the Scheduled Tribes and the socially and educationally backward classes also
referred to as the OBCs.
3. Clause (1) of article 30 provides the right to all minorities to establish and
administer educational institutions of their choice. It is essential that the rights
available to minorities are protected in regard to institutions established and
administered by them. Accordingly, institutions declared by the State to be minority
institutions under clause (1) of article 30 are omitted from the operation of the
proposal.
4. To promote the educational advancement of the socially and educationally
backward classes of citizens i.e. the OBCs or of the Scheduled Castes and Scheduled
Tribes in matters of admission of students belonging to these categories in unaided
educational institutions, other than the minority educational institutions referred to
in clause (1) of article 30 of the Constitution, it is proposed to amplify article 15. TheAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

new clause (5) shall enable the Parliament as well as the State Legislatures to make
appropriate laws for the purposes mentioned above.
5. The Bill seeks to achieve the above objects."
23. The Constitution (Ninety-Third Amendment) Act, 2005, by which Article 15(5) was inserted in
the Constitution, is challenged in these petitions, on various grounds. In some of the writ petitions
which have been filed after the passing of Act 5 of 2007, the challenge is directed against the various
provisions of the Act 5 of 2007. Initially, these writ petitions were heard by a Bench of two Judges.
Considering the constitutional importance of these questions, all these writ petitions were referred
to a Constitution Bench.
24. We have heard learned Counsel appearing for the various petitioners. The learned Senior
Counsel, Shri Harish Salve, Shri F.S. Nariman, Shri K.K. Venugopal, Shri P.P. Rao and Dr. Rajeev
Dhavan and learned Counsel Shri Sushil Kumar Jain addressed the main arguments on behalf of the
petitioners. Shri Ashok Kumar Thakur appeared in person. Supporting the Constitution
(Ninety-Third Amendment) Act, 2005 and the provisions of the said Act, learned Senior Counsel
Shri K. Parasaran, appearing for the Union of India, learned Solicitor General Shri G.E. Vahanvati
and learned Additional Solicitor General Shri Gopal Subramanium submitted arguments. We have
also heard learned Senior Counsel Shri Ram Jethmalani, Shri T.R. Andhyarujina, Ms. Indra
Jaisingh, Shri Rakesh Dwivedi and Shri Ravivarma Kumar. We also had the advantage of the written
submissions made by these Counsel.
25. The arguments advanced against the Constitution (Ninety-Third Amendment) Act, 2005 and Act
5 of 2007 can be summarized as follows.
26. It was contended by Shri Harish Salve, learned Senior Counsel, who confined his arguments to
the constitutionality of the provisions of the Act, especially sub-clause (3) of Section 3 of the Act
which deals with the reservation to the extent of 27% of the total number of seats for the "socially
and educationally backward classes of citizens". According to him, the admission to educational
institutions should be based purely on merit and to allow the State to prefer a student with lesser
merit over those who would have otherwise got admission, is ex facie discriminatory. It is submitted
that all obviously discriminatory laws are violative of the rule of equality and it is for the State to
maintain the principles of equality and to establish the need for such laws as well as their validity. It
was further argued that Article 15(5) does not protect the validity of the Act and that the provision in
the Act for preferential admission solely on the basis of caste would violate Article 29(2) of the
Constitution, as has been laid down in The State of Madras Vs. Srimathi Champakam Dorairajan9.
It was also argued that Article 15(5) could be construed as an exception to Article 15(1) and
affirmative action, if excessive, is bound to result in reverse discrimination which is not permissible.
According to the learned Senior Counsel, this is not a genuine social engineering measure but vote
bank politics and would 9 1951 SCR 525 create permanent fissures in society. It was argued that the
provisions of the Act are facially violative of Article 14 and it could only be justified on the basis of
compelling State necessity. A greater degree of compulsion is necessary to establish a compelling
State necessity than what is ordinarily required to be shown in the case of economic legislation. TheAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

learned Senior Counsel dealt in detail with the argument that the backward classes cannot be
defined solely on the basis of caste and reference was made to various decisions of this Court. The
learned Senior Counsel particularly referred to various decisions of the Supreme Court of the United
States and contended that this kind of legislation, that is, the impugned Act, attempting affirmative
action is to be treated as "suspect legislation"
and it has to undergo the tests of "strict scrutiny" and "compelling state necessity".
Finally, the learned Counsel argued that non- exclusion of creamy layer is per se
illegal and contrary to what has been laid down by this Court in Indra Sawhney Vs.
Union of India & Ors.10.
27. The validity of Constitution (Ninety-Third Amendment) Act, 2005 was seriously
challenged by arguing that the amendment is
10 1992 Supp. (3) SCC 215 destructive of basic structure of the Constitution. The learned Counsel
was of the view that both the Act as well as the Constitution (Ninety-Third Amendment) Act, 2005
have to be declared ultra vires the Constitution.
28. Dr. Rajeev Dhavan, learned Senior Counsel appearing for the petitioners in Writ Petition No.
53/2007 contended that the affirmative action scheme under Article 15(4), 15(5) and 16(4) has to
comply with the mandate of Article 14, 15(1) and 16(1) of the Constitution. It was argued that these
are only enabling provisions and not part of the fundamental rights. "Notwithstanding", as used in
Article 15(3), 15(4) and 15(5) cannot be construed as "notwithstanding the declaration of equality
principle". In view of the decision of this Court in Champakam Dorairajan (supra) admission quotas
are impermissible on any ground based solely on religion, race, caste or any one of them. It was
argued that there is a lack of criteria for identification of Other Backward Classes (OBCs) and
Socially and Educationally Backward Classes (SEBCs). The concept of creamy layer is applicable to
Article 15 and Article 16 and non-exclusion of creamy layer in the Act is illegal. Further it was argued
that quota should not be a punishment for unreserved categories and there should not be any
reverse discrimination. The learned Senior Counsel further challenged the constitutional validity of
Constitution (Ninety-Third Amendment) Act, 2005 and contended that it is against the basic
structure of the Constitution. The procedure laid down under Article 368 has not been followed. It
was contended that the proviso to Article 368 of the Constitution requires ratification of the
Constitution (Ninety-Third Amendment) Act, 2005 by one half of the States. The amendment seeks
to nationalize the private educational institutions which is unreasonable and impermissible and
reference was made in this regard to T.M.A. Pai Foundation (supra). It was argued that Act 5 of
2007 is unreasonable, arbitrary, capricious and contrary to Articles 14 and 21 of the Constitution.
He elaborated his arguments on the basis of the tests laid down in the M. Nagaraj & Ors. Vs. Union
of India & Ors.11 and I.R. Coelho (Dead) by LRS.
Vs. State of T.N.12 cases and lastly, submitted that both Act 5 of 2007 and The Constitution
(Ninety-Third Amendment) Act, 2005 are liable to be declared as ultra vires the Constitution.
11 (2006) 8 SCC 212 12 (2007) 2 SCC 1Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

29. Dr. Rajeev Dhavan elaborately argued that perusal of the history of the reservations from 1880
to 2007 for OBCs and SEBCs showed that there was no emphasis on communities by the British
regime and community based criteria was held to be illegal in Champakam Dorairajan (supra).
From 1950 to 1970, there was no proper inquiry for ascertaining the OBCs or SEBCs. The learned
Counsel emphasized that in Indra Sawhney's case (supra), caste was excluded as a criteria and the
identification of SEBCs or OBCs based on caste could not operate for both Articles 15(4) and 16(4).
According to the learned Senior Counsel, the criteria for identifying SEBCs should be based on the
atrocities inflicted on that class, discriminatory patterns followed against that class, disadvantage
suffered by that class and disempowerment in respect of the power of the State and political
non-representation. The class should also be relatively homogeneous in nature.
30. According to the learned Senior Counsel, there is a lack of criteria for fixing SEBCs or OBCs and
this case is being taken to excite vote-
banks. It was argued that the 27% of reservation under the Act of 2007 was based on criteria which
did not exist. It was contended that the creamy layer principle is applicable to OBCs and also to SCs
and STs. It was argued that historic discrimination is not a valid criteria for determining the
beneficiaries of affirmative action and the correct approach is to look at the continuing wrong and
not past discrimination and that the quotas should not be a punishment for the non-reserved
category resulting in reverse discrimination. The learned Senior Counsel contended that the
Ninety-Third Amendment is against the basic structure of the Constitution. It was argued that the
Doctrine of Equality is adversely affected by giving a wide and untrammeled enabling power to the
Union Legislature that may affect the rights of the non-OBCs, SCs and STs. It was argued that the
balance between what was referred to as the "Golden Triangle" in Minerva Mills Ltd. & Ors. Vs.
Union of India & Ors.13 has been totally nullified by the Ninety-Third Amendment. It was argued
that the legislative declarations of facts are not beyond judicial scrutiny and the court can tear the
veil to decide the real nature of the statute and decide the constitutional validity. It was argued that
the Act 5 of 2007 is subject to judicial review on the ground that its unreasonable and clear criteria
have not been laid down to identify OBCs and there was no compelling necessity other than political
patronage.
13 AIR 1980 SC 1789 = (1980) 3 SCC 625
31. Shri K.K. Venugopal, learned Senior Counsel appearing in W.P. (Civil) No. 598 of 2006
contended that Articles 15(4) and 15(5) are mutually exclusive with the former concerning
admissions to aided institutions and the latter concerning admissions to unaided institutions.
Article 15(5) expressly used the phrase "whether aided or unaided", making it clear that it is not
merely restricting itself to unaided institutions. Therefore, it is argued that from the very inception
of the Constitution, Article 15(4) was a provision and was the source of legislative power for the
purpose of making reservation for the Scheduled Castes, Scheduled Tribes as well as the Socially and
Educationally Backward Classes of citizens in aided minority educational institutions. On the other
hand, Article 15(5), which provides reservation of seats for SCs and STs as well as SEBCs in aided
educational institutions expressly excludes such reservation being made at all in minorityAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

educational institutions covered by Article 30(1) of the Constitution. According to him, it would take
away the valuable rights of OBCs, SCs and STs given by the State under Article 15(4) of the
Constitution and this would result in annulling the endeavour of the founding fathers of the
Constitution and would result in exclusion of SCs and STs from the mainstream of the society and
stall their development for centuries to come. According to the learned Counsel for the petitioners,
the argument of the Union of India that Article 15(4) and 15(5) are both enabling provisions and
both will stand together and both can be complied with is incorrect. It was argued that Article 15(4)
operates with a qualification that nothing in Article 15 or in Article 29(2) of the Constitution shall
prevent the State from making special provision for SCs and STs as well as SEBCs while Article 15(5)
operates with a qualification that "nothing in Article 15 or Article 19(1)(g)" shall prevent the State
from making such special provisions for SCs and STs as well as SEBCs.
The qualifying words in Article 15(4) do not have any real meaning or effect for the reason that both
Article 15(1) as well as Article 29(2) prohibit discrimination on grounds only of religion and/or for
caste.
Therefore, it is argued that there is a direct conflict between Article 15(4) and 15(5). As both Articles
contain an exclusionary clause excluding the operation of the rest of Article 15. It was contended
that The Constitution (Ninety-Third Amendment) Act, 2005 is violative of the basic structure as it
breaches the central character of the Constitution by placing the minority educational institutions
based on religion on a special footing and exempting it from bearing the common burden of
reservation for SCs, STs and SEBCs. It was argued that such exclusion of minority institution is not
severable from Article 15(5). As regards the validity of the Act 5 of 2007, it failed to exclude the
"creamy layer" from the caste which would render the identification of the "caste" as "backward
class" which is unconstitutional and void. Their inclusion would not result in unequals being treated
as equals and result in giving the benefit of reservation to the advanced sections in that caste. The
consequences would be that the inclusion of the caste for the benefit of reservations would be purely
on the basis of caste only thus violating Article 15(1) and Article 29(2) of the Constitution. The
doctrine of severability does not apply and therefore, the Act 5 of 2007 is unconstitutional and void
to the extent that it does not provide exclusion of `creamy layer' from the SEBCs. Therefore, it was
prayed that both The Constitution (Ninety-Third Amendment) Amendment Act, 2005 as well as the
Act 5 of 2007 be struck down as unconstitutional.
32. Shri F.S. Nariman, learned Senior Counsel appearing for the petitioners in W.P. (Civil) No. 35 of
2007, contended that the caste cannot be the sole criteria for determining the socially and
educationally backward classes under Article 15(4) and 15(5) of the Constitution and the test for
Article 15(5) has to be "occupation cum income" where caste may or may not be one of the many
considerations having a nebulous weightage, and alternatively without conceding if caste at all is
taken as one of the many considerations then it can only be those castes which satisfy the test of
similarity with Scheduled Castes/Scheduled Tribes. It was argued that the decision of this Court in
R. Chitralekha & Anr. Vs. State of Mysore & Ors.14 still occupies the field for the purpose of Article
15 and the decision in R. Chitralekha's case (supra) was affirmed by the Bench in Indra Sawhney's
case (supra). It was argued that OBCs are already educationally forward and no reservation in
higher education is justified. The learned Senior Counsel relied on the literacy rate by age groups asAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

quoted in the Sachar Committee Report. It was contended that in data given in the judgment in
Indra Sawhney's case (supra), OBCs were not taken as educationally backward. According to the
learned Senior Counsel for the petitioners, there can only be presumption of forwardness of OBCs 14
(1964) 6 SCR 368 and they are not backward. The burden is on the Government to provide that the
intended beneficiaries are really backward citizens.
The OBCs have not suffered social inequalities or oppression that had been inflicted on Scheduled
Castes and Scheduled Tribes by the society and, according to the learned Senior Counsel, the caste-
occupation nexus barely survives today and is a misleading guide.
The caste based occupation association has been rapidly disappearing from the Indian society. For
Articles 15(4) and 15(5), economic consideration has to be the dominant criterion. The non-
execution of "creamy layer" is illegal and it was intended to safeguard the really deprived and
backward people among the so-called OBCs.
It was contended that the Government has not published the list of OBCs for Article 15(5) and the
Union of India has not been able to produce the list or the criteria for determining the SEBCs. No
time frame has been fixed for such reservation. Therefore, the Act 5 of 2007 is violative of Article 14
of the Constitution of India and is thus unconstitutional.
33. Appearing for the Writ Petitioner in W.P. (Civil) No. 231/2007 filed by the Citizens for Equality,
the learned Senior Counsel Shri P.P. Rao contended that the mandate of Article 45 to provide free
and compulsory education for all children until they complete the age of 14 years has not been
complied with by the Government and therefore, there is clear violation of Article 20 of the
Constitution.
Although the Sarva Shiksha Abhiyan (SSA) Project was introduced with certain objectives, these
objectives were not fulfilled. The Constitution seeks to achieve a casteless and classless society.
Therefore, identification of socially and educationally backward classes should be based on such
criteria which facilitate the eradication of the caste system. The educational backwardness of the
backward classes and the SEBCs should be removed and once this educational backwardness is
removed, clause 4 and 5 of Article 15 will become redundant and unnecessary. It was argued that
without ensuring that every child belonging to a backward class is provided free and compulsory
education upto 10+2 level any reservation provided in higher education is discriminatory inter se
between members of the backward classes themselves and violative of Articles 14 and 15 of the
Constitution. Education upto secondary school level should be the measure for determining
educational backwardness. The social and educational backwardness referred to in Article 15(4)
requires separate identification of SEBCs. Agricultural labourers, rickshaw pullers/drivers, street
hawkers etc. may well qualify for being designated as "backward classes" According to petitioner's
learned Senior Counsel, a rational basis would be to identify backward classes through occupations
traditionally considered to be inferior, yielding low income. It was argued that that in any event, theAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"creamy layer" among the socially and educationally backward classes is liable to be excluded.
34. Shri Sushil Kumar Jain, learned Counsel appearing in W.P. (Civil) No. 598 of 2006, elaborately
argued the issues involved in this case. The main contention of the petitioner's Counsel is that the
"affirmative action" policy of the Government of India is discriminatory and against general public
interest. The policy is intended to "uplift" the so called socially and educationally backward sections
of the society by the process of positive discrimination. It was argued that the Ninety-Third
Constitutional Amendment is destructive of the basic structure of the Constitution as it destroys the
delicate balance of the various fundamental rights that the citizens of the country enjoy. The
provision of Article 15(5) was inserted as a proviso to Article 19(6) which has been held to be
unreasonable and against the constitutional scheme. Article 15(5) makes an exception for the
minority institutions covered under Article 30 and therefore treats them differently from other
private institutions. The Central Education Institution (Reservation in Admission) Act, 2007 which
has been enacted in purported exercise of the said powers, is in excess of the said powers. Since the
target beneficiaries of Article 15(5) have not been identified with a necessary degree of specificity,
the Act 5 of 2007 is illegal. There ought to be a quantitative correlation between the benefits
conferred and the extent of the "problem"
sought to be remedied, the correlation being "reasonable" and not "proportionate". The Act 5 of
2007 does not provide the manner or the principles on which the identification of OBC is to be
made.
Therefore, it lacks the necessary nexus with the ultimate objects sought to be achieved. The
reservation of seats for the "beneficiaries"
for many years to come without any provision for review gives rigidity and permanency to such
measures. This would result in excessive reservation and thereby cause reverse discrimination. The
100% quota in the additional seats that will be created in the educational institutions is facially
discriminatory. Identification of SEBCs on the basis of caste creates vested interest in backwardness.
Therefore, the measures and means chosen by the Government are therefore unethical to the
constitutional goals. Failure to exclude "creamy layer" allows conferment of benefits on undeserving
persons. The action of the State Governments lacks in the basic details of the extent of the measure.
The exact social malaise sought to be remedied is not clear.
35. The learned Counsel for the petitioner further contended that the Ninety-Third Constitutional
Amendment violates the basic structure of the Constitution. This Court clarified the rights of the
private educational institutions in terms of Article 19(1)(g) of the Constitution in T.M.A. Pai
Foundation case (supra) as explained in P.A. Inamdar & Ors. Vs. State of Maharashtra & Ors.15 It
was held in that case that fixation of quotas and reservation of seats in private educational
institutions amounts to "Nationalization of Education". The Ninety-Third Constitutional
Amendment is thus an unreasonable action of the legislature. It was argued that the impugned
amendment alters supremacy of the Constitution and there was only limited constituent power to
amend Article 368. Article 15 (2005) 6 SCC 537 15(5) would enable the State to make the law to
provide reservation to private educational institution which has been held to be an unreasonableAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

encroachment on the fundamental rights and this amendment would alter the balance between Part
III and IV of the Constitution. Reliance was placed on various decisions by the petitioner's learned
Counsel. The impugned amendment specifically excludes the application of Article 19(1)(g), whereas
the institutions governed by Article 26 and the minority institutions governed by Article 30(1) have
been left out. This, according to the petitioner's Counsel, is discriminatory and illegal and that there
was no justification to this differential treatment. The petitioner's learned Counsel also challenged
the quantum of reservations provided under the Act 5 of 2007. Any determination of the extent of
reservation without considering the future impact of the reservation would be unjust, arbitrary and
unreasonable. Caste based reservation would not be in the larger interest of the national unity and
integrity. The benefits could be given only to those communities which are not adequately
represented and not to those which are socially and educationally advanced. Reservation in the form
of quota is illegal and if some classes are to be given some benefit and to be equalized with the
general category they could be awarded some additional marks like it is being given to the women
candidates seeking admission in colleges. Many of the castes included in SEBCs are not really
backward classes and some of them were even rulers of erstwhile States for a number of years. The
benefits and privileges which are given to SCs/STs should not be extended to OBCs. The members of
the OBC communities are capable of competing with the general category candidates and the
increase in seats would entail a corresponding increase in infrastructure, and it is submitted that an
increase in infrastructure would, therefore, to be financed through tax collections and, therefore,
every member of the public (including the general category) is entitled to be considered for
admission in the said increase. The learned Counsel also strongly objected to "caste"
being taken as a means of classification and identification of SEBCs and OBCs. It is contended that it
is in complete derogation of provisions of Article 15(1) and, according to the petitioner's learned
Counsel, many of the castes which have been included in SEBCs are really not SEBCs and thus past
historical discrimination is entirely irrelevant for conferment of benefits in the present times. It was
also contended that there are no traditional occupations now. It is submitted that the identification
of castes as a "class" to justify the same as being occupations on a presumption that the persons
belonging to a particular caste continue to follow a particular occupation especially in the present
constitutional scheme which gives freedom to choose any business, occupation or profession is
entirely fallacious. The learned Counsel for the petitioner also contended that the non-exclusion of
creamy layer is illegal and relied on Indra Sawhney's case (supra) and Indra Sawhney (II) Vs. Union
of India & Others16.
36. Shri Ashoka Kumar Thakur, who appeared in person, supported all the contentions raised by
various learned Counsel and urged that the Ninety-Third Constitution Amendment as well as the
Act 5 of 2007 are unconstitutional and they are liable to be struck down.
37. On behalf of the respondents, several Senior Counsel appeared and contended that the
contentions of the petitioners challenging the Ninety-Third Constitutional Amendment and the Act
5 of 2007 are without any merit and are liable to be dismissed. The 16 (2000) 1 SCC 168, at p. 190
contentions raised by the petitioners' Counsel were refuted by the respondents' Counsel by raising
the plea that affirmative action is needed for promoting educational and economic interest of
weaker section of society. Shri K. Parasaran, learned Senior Counsel appearing for the Union ofAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

India, submitted that the Constitution is to be interpreted as an integral, logical whole, and while
construing one part, regard must be had to the provisions of the other parts, rendering no portion as
unnecessary or redundant. It was argued that when constitutional provisions are interpreted, it has
to be borne in mind that the interpretation is such as to further the object of their incorporation and
they cannot be interpreted in a manner that renders another provision redundant.
38. It was argued that the constitutional provision must not be construed in a narrow and
constricted sense but in a wide and liberal manner so as to anticipate and take into account the
changing conditions and purposes so that the constitutional provision does not get fossilized but
remains flexible enough to meet the newly emerging problems and challenges of this age. Reference
was made to various decisions rendered by this Court regarding the interpretations of constitutional
provisions. It was pointed out that when social welfare measures are sought to be implemented and
the Constitution has to be interpreted in such context, it has to be kept in mind that the Preamble is
the text which sets out the goal that is to be attained; and that Part III is the texture into which is
woven a pattern of rights.
39. Fundamental Rights and Directive Principles are both complementary and supplementary to
each other. Preamble is a part of the Constitution and the edifice of our Constitution is built upon
the concepts crystallized in the Preamble. Reference was made to the observations made by Chief
Justice Sikri in His Holiness Kesavananda Bharati Sripadagalvaru Vs. State of Kerala17, wherein it
was argued that the Constitution should be read and interpreted in the light of the grand and noble
vision expressed in the Preamble. The Preamble secures and assures to all citizens justice, social,
economic and political and it assures the equality of status and of opportunity. Education and the
economic well-being of an individual give a status in society. When a large number of OBCs, SCs and
STs get better educated and get into Parliament, legislative 17 [1973] Supp. SCR 1 = (1973) 4 SCC
225 assemblies, public employment, professions and into other walks of public life, the attitude that
they are inferior will disappear. This will promote fraternity assuring the dignity of the individual
and the unity and integrity of the nation. The single most powerful tool for the upliftment and
progress of such diverse communities is education.
40. The Fundamental Rights in Part III are not to be read in isolation.
All rights conferred in Part III of the Constitution are subject to at least other provisions of the said
Part III. The Directive Principles of State Policy in Part IV of the Constitution are equally as
important as Fundamental Rights. Part IV is made not enforceable by Court for the reason inter alia
as to financial implications and priorities.
Principles of Part IV have to be gradually transformed into fundamental rights depending upon the
economic capacity of the State. Article 45 is being transformed into a fundamental right by 86 th
Amendment of the Constitution by inserting Article 21 A. Clause 2 of Article 38 says that, "the State
shall, in particular, strive to minimize the inequalities in income and endeavour to eliminate
inequalities in status, facilities and opportunities, not only amongst individuals but also amongst
groups of people residing in different areas or engaged in different vocations". Under Article 46, "the
State shall promote with special care the educational and economic interests of the weaker sectionsAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

of the people and, in particular, of the Scheduled Castes and the Scheduled Tribes, and shall protect
them from social injustice and all forms of exploitation". It is submitted that the Ninety-
Third Constitutional Amendment was brought into force to bring about economic and social
regeneration of the teeming millions who are steeped in poverty, ignorance and social
backwardness. Shri K. Parasaran, learned Senior Counsel, contended that the concept of basic
structure is not a vague concept and it was illustrated in the judgment in Kesavananda Bharati's case
(supra). It was pointed out that the supremacy of the Constitution, republican and democratic form
of Government and sovereignty of the country, secular and federal character of the Constitution,
demarcation of power between the legislature, the executive and the judiciary, the dignity of the
individual (secured by the various freedoms and basic rights in Part III and the mandate to build a
welfare State contained in Part IV), the unity and the integrity of the nation are some of the
principles of basic structure of the Constitution. It was contended that when the constitutional
validity of a statute is considered, the cardinal rule to be followed is to look at the Preamble to the
Constitution as the guiding light and the Directive Principles of State Policy as a book of
interpretation. On a harmonious reading of the Preamble, Part III and Part IV, it is manifest that
there is a Constitutional promise to the weaker sections / SEBCs and this solemn duty has to be
fulfilled.
41. It was pointed out that the observations in Champakam Dorairajan (supra) that the Directive
Principles are subordinate to the Fundamental Rights is no longer good law after the decision of the
Kesavanda Bharati (supra) case and other decisions of this Court. It was pointed out that the de
facto inequalities which exist in the society are to be taken into account and affirmative action by
way of giving preference to the socially and economically disadvantaged persons or inflicting
handicaps on those more advantageously placed is to be made in order to bring about real equality.
It is submitted that special provision for advancement of any socially and educationally backward
citizens may be made by determining the socially and educationally backward classes on the basis of
caste. Article 15(4) neutralized the decision in Champakam Dorairajan's case (surpa).
It was enacted by the Provisional Parliament which consisted of the very same Members who
constituted the Constituent Assembly. Our Constitution is not caste blind and the Constitution
prohibits discrimination based `only on caste' and not `caste and something else'.
42. In Unni Krishnan's case (supra) it was held that Article 19(1)(g) is not attracted for establishing
and running educational institutions.
But this decision was overruled in T.M.A. Pai Foundation (supra) and it was held that establishing
and running an educational institution is an "occupation" within the meaning of Article 19(1)(g).
In P.A. Inamdar's case (supra), it was held that the private educational institutions, including
minority institutions, are free to admit students of their own choice and the State by regulatory
measures cannot control the admission. It was held that the State cannot impose reservation policy
to unaided institutions. The above ruling disabled the State to resort to its enabling power under
Article 15(4) of the Constitution. It was argued by Shri Parasaran that the above rulings necessitatedAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

the enactment of The Constitution (Ninety-Third Amendment) Act, 2005 by inserting Article 15(5)
through which enabling power was conferred on the Parliament and the State Legislatures, so that
they would have the legislative competence to pass a law providing for reservation in educational
institutions which will not be hit by Article 19(1)(g). But rights of minorities under Article 30 are not
touched by Article 15(5).
43. In Kesavananda Bharati (supra) it was held that the fundamental rights may not be abrogated
but they can be abridged. The validity of the 24th Amendment of the Constitution abridging the
fundamental rights was upheld by the Court. The right under Article 19(1)(f) has been completely
abrogated by the 44th Amendment of the Constitution which is permissible for the constituent
power to abridge the Fundamental Rights especially for reaching the goal of the Preamble of the
Constitution. It is an instance of transforming the principles of Part IV into Part III whereby it
becomes enforceable. All rights conferred in Part III of the Constitution are subject to other
provisions in the same Part. Article 15(4) introduced by the 1 st Amendment to the Constitution is a
similar instance of abridging of Fundamental Rights of the general category of citizens to ensure the
Fundamental Rights of OBCs, SCs and STs. Article 15(5) is a similar provision and is well within the
Constituent power of amendment.
Article 15(5) is an enabling provision and vests power in the Parliament and the State legislatures.
44. There is vital distinction between the vesting of a power and the exercise of power and the
manner of its exercise. It would only enable the Parliament and the State legislatures to make
special provisions by law for enforcement of any socially and educationally backward class of
citizens or for Scheduled Castes and Scheduled Tribes relating to their admission to educational
institutions including private educational institutions.
45. As regards exemption of minority educational institutions in Article 15(5), it was contended that
this was done to conform with the Constitutional mandate of additional protection for minorities
under Article 30. It was argued that Article 15(5) does not override Article 15(4). They have to be
read together as supplementary to each other and Article 15(5) being an additional provision, there
is no conflict between Article 15(4) and Article 15(5). Article 15(4), 15(5), 29(2), 30(1), and 30(2) all
together constitute a Code in relation to admission to educational institutions. They have to be
harmoniously construed in the light of the Preamble and Part IV of the Constitution.
It was also contended that the Article 15(5) does not interfere with the executive power of the State
and there is no violation of the proviso to Article 368.
46. The Ninety-Third Constitutional Amendment does not specifically or impliedly make any change
in Article 162. Article 15(5) does not seek to make any change in Article 162 either directly or
indirectly.
The field of legislation as to "education" was in Entry 11 of List II. By virtue of the 42nd Amendment
of the Constitution, "education", which was in Entry 11 in List II, was deleted and inserted as Entry
25 in List III. The executive power of the State is not touched by the present ConstitutionalAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Amendment.
47. Article 15(5) does not abrogate the fundamental right enshrined under Article 19(1)(g). If at all
there is an abridgement of Fundamental Right, it is in a limited area of admission to educational
institutions and such abridgement does not violate the basic structure of the Constitution. In any
way, Constitutional Amendments giving effect to Directive Principles of the State Policy would not
offend the basic structure of the Constitution.
48. The Right to Equality enshrined in our Constitution is not merely a formal right or a vacuous
declaration. Affirmative action though apparently discriminatory is calculated to produce equality
on a broader basis. By eliminating de facto inequalities and placing the weaker sections of the
community on a footing of equality with the stronger and more powerful sections so that each
member of the community whatever is his birth, occupation or social position may be, enjoys equal
opportunity of using to the full, his natural endowments of physique, of character and of
intelligence.
49. Shri Parasaran, learned Senior Counsel, further contended that the Act 5 of 2007 is a
constitutionally valid piece of legislation. Under Section 2(g) of Act 5 of 2007, there is no excessive
delegation. The plea of the petitioners that the Parliament itself should have determined OBCs and
that Act 5 of 2007 suffers from excessive delegation or lack of guidelines is not tenable. The
backward classes of citizens have to be identified on the materials and evidence and therefore the
Parliament necessarily has to leave it to the Executive.
The determination of OBCs is a long-drawn process which would cause enormous delay. Therefore,
it was appropriate to leave the identification to the Executive. Such determination of each class as
backward class would be open to judicial review. And the scope of judicial review would be wider if
the same is made by the Executive rather than by the Parliament.
50. It is also contended that merely because no time limit is fixed, Act 5 of 2007 cannot be rendered
invalid. The Parliament has got the power to review periodically and either make modifications in
the Act or repeal the Act. It is for the first time certain special provisions are being made in favour of
socially and educationally backward classes of citizens, SCs and STs for reservation of seats in
Central Educational Institutions after 56 years of coming into force of the Constitution. At its very
commencement, a time limit may not be anticipated and fixed. Over a period of time depending
upon the result of the measures taken and improvements in the status and educational advancement
of the SCs, STs and SEBCs, the matter could always be reviewed. The Act cannot be struck down at
the very commencement on the ground no time limit for its operation has been fixed.
51. It was also submitted that the quantum of reservation provided under the Act is valid. The ratio
of population is a relevant consideration in fixing the quantum of reservation. Reservation in favour
of OBCs is 27% and by adding the percentage of reservation for SCs and STs, the total quantum of
reservation does not exceed 50%. It is indisputable that the population of OBCs exceeds 27% and
SCs and STs constitute more than 22 =%. The quantum of reservation within 50% has been
determined by the Parliament based on facts considered by legislature and they are conclusive andAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

the Courts do not exercise the power of judicial review by examining those facts.
52. The learned Senior Counsel also contended that the contention of the Petitioners that special
provisions can only be made up to 10+2 stage is untenable. If this plea is accepted, it would result in
higher education being the privilege of the higher classes only and it would be a distortion of the
concept of social advancement of the downtrodden and the negation of the goal envisaged by the
Preamble. It was also contended that the principle of reverse discrimination is not applicable. The
Doctrine of Strict Scrutiny and Narrow Tailoring are not applicable in India as they are American
doctrines which operate under different facts and circumstances.
This court on earlier occasion had rejected these pleas, when dealing with admission to
Post-graduate Medical Courses, when 75% of seats were being reserved on the basis of institutional
preference.
53. The learned Senior Counsel further contended that the exclusion of creamy layer has no
application to SCs and STs in regard to employment and education. Articles 341, 342, 366(24) and
366(25) of the Constitution would militate against such course of action.
54. It was held in E.V. Chinnaiah Vs. State of Andhra Pradesh & Ors.18, that the SCs and STs form a
single class. The observations in Nagaraj's case (supra) cannot be construed as requiring exclusion
of creamy layer in SCs and STs. Creamy layer principle was applied for the identification of
backward classes of citizens. And it was specifically held in Indra Sawhney's case, (supra) that the
above 18 (2005) 1 SCC 394 discussion was confined to Other Backward Classes and has no relevance
in the case of Scheduled Tribes and Scheduled Castes.
The observations of the Supreme Court in Nagaraj's case (supra) should not be read as conflicting
with the decision in Indra Sawhney's case (supra). The observations in Nagaraj's case (supra) as
regards SCs and STs are obiter. In regard to SCs and STs, there can be no concept of creamy layer.
55. Once the President of India has determined the list of Scheduled Castes and Scheduled Tribes, it
is only by a law made by the Parliament that there can be exclusion from the list of Scheduled Castes
or Scheduled Tribes. As far as OBCs are concerned, the principle of exclusion of creamy lawyer is
applicable only for Article 16(4). It has no application to Article 15(4) or 15(5) as education stands on
a different footing.
56. Equality of opportunity of education is a must for every citizen and the doctrine of "creamy
layer" is inapplicable and inappropriate in the context of giving opportunity for education. In the
matter of education there cannot be any exclusion on the ground of creamy layer. Such exclusion
would only be counter productive and would retard the development and progress of the groups and
communities and their eventual integration with the rest of the society.
57. It was further argued that Article 15(4) and 15(5) are provisions of power coupled with duty. It is
the constitutional duty to apply these principles in the governance of the country and in making law
for the reason that it is a constitutional promise of social justice which has to be redeemed.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

58. It was strongly contended by the learned Senior Counsel Shri Parasaran that the validity of the
constitutional amendment and the validity of plenary legislation have to be decided purely on the
basis of constitutional law. And the submission, as it was contended that the Amendment has a vote
catching mechanism is inappropriate.
The contention that the Ninety-Third Constitutional Amendment is against the Universal
Declaration of Human Rights is also not tenable. Right to Equality of Opportunity operates at every
level and it is being provided for a particular level either by a legislative or an executive action. The
merit has to be interpreted in the context of egalitarian equality and not formal equality.
59. It was also submitted that the speeches in the Parliament, constitutional debates, text books of
authors and views expressed in articles do not normally constitute evidence before the Court to
determine the Constitutional validity of the legislations.
60. Shri G.E. Vahanvati, learned Solicitor General of India appearing on behalf of the Union of
India, submitted that the argument of Shri Harish Salve, learned Senior Counsel that the American
doctrine of "strict scrutiny" should be applied to the affirmative action envisaged under Article 15(5)
is not correct. It was argued that the impugned legislation is not ex facie discriminatory and,
therefore, it cannot be classified as a "suspect legislation". It was argued that right that from the case
of T he General Manager S outhern Railway Vs. Rangachari,19 Article 16(4) is an exception to Article
16(1) and this reasoning was followed in M.R. Balaji & Others Vs. State of Mysore20 by a five Judge
Bench. Thereafter, the same view prevailed in T. Devadasan Vs. The Union of India & Anr.21 But 19
1962 (2) SCR 586 at p. 607 20 (1963) Supp. 1 SCR 439 at 455 = AIR 1963 SC 649 21 1964 (4) SCR
680 Subba Rao. J. (as he then was) said that "the expression `nothing in this article' is a legislative
device to express its intention in a most emphatic way that the power conferred there under is not
limited in any way by the main provision but falls outside it" . The view that Articles 15(4) and 16(4)
are exceptions to Article 15(1) and 16(1) respectively was again reiterated in Triloki Nath Vs. State of
Jammu & Kashmir & Ors. (II)22 and in The State of Andhra Pradesh & Ors. Vs. U.S.V. Balram,
Etc23. The learned Solicitor General further pointed out that in State of Kerala & Anr. Vs N.M.
Thomas & Ors.24 the majority opinion held that Articles 14, 15 and 16 are parts of the scheme of
equality and that Articles 15(4) and 16(4) are not exceptions to Articles 15(1) and 16(1) respectively.
The said change in N.M. Thomas's case (supra) was noticed by Justice Chinnappa Reddy in K.C.
Vasanth Kumar & Anr. Vs. State of Karnataka25 and the same view was upheld in Indra Sawhney's
case (supra). The learned Solicitor General further contended that once it is accepted that Articles
15(4) and 16(4) are not exceptions to Articles 15(1) and 16(1) respectively, then there is no question
of 22 1969 (1) SCR 103 23 1972 (1) SCC 660 24 1976 (2) SCC 310 25 (1985) Supp SCC 714 treating
the social welfare measure as being `facially discriminatory' or "ex facie" violative of the rule of
equality. It was argued that it is not simply a matter of legal equality. De jure equality must
ultimately find its raison d'etre in de facto equality. The State must, therefore, resort to
compensatory State action for the purpose of uplifting people who are factually unequal in their
wealth, education or social environment. Relying on the observations of Subba Rao, J. in T.
Devadasan's case (supra), it was argued that centuries of calculated oppression and habitual
submission has reduced a considerable section of our community to a life of serfdom and it would be
well nigh impossible to raise their standards if the doctrine of equal opportunity was strictlyAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

enforced in their case and they would not have any change if they were made to enter the open field
of competition without adventitious aids till such time when they could stand on their own legs.
Laying reliance on the observations made in N.M. Thomas's case (supra) and also in Indra
Sawhney's case (supra), the learned Solicitor General argued that under Articles 15(4) and 16(4) the
State is obliged to remove inequalities and backwardness from society. It was further submitted that
the American doctrine of "strict scrutiny" had been expressly rejected by this Court in Saurabh
Chaudri & Ors. Vs. Union of India & Ors.26 As regards identification of backward classes, the
learned Solicitor General contended that while dealing with the aspect of identification of
backwardness for socially and educationally backward classes, it cannot be denied that there is
backwardness in this country; that large sections of the country are socially and educationally
backward;
that this problem is not new but is age old; that such backwardness arose because of certain
peculiarities of the caste system which proceeded on the assumption that the choice of occupation of
members of a caste was pre-determined in many castes; and that members of particular castes were
prohibited from engaging themselves in occupations other than those certain occupations which
were considered to be degrading and impure and considered fit only for those castes. It was pointed
out that Chief Justice Wanchoo in C.A. Rajendran Vs. Union of India & Ors.27 held that the main
criteria for inclusion in the list is social and educational backwardness of the castes based on the
occupation pursued by those castes. Reference was made to various decisions rendered by this Court
on this issue, especially Minor A. Peeriakaruppan & 26 (2003) 11 SCC 146 27 (1968) 1 SCR 721 Anr.
Vs. State of Tamil Nadu & Ors.28; U.S.V. Balram (supra); K.C. Vasanth Kumar (supra), referred to
earlier. The learned Solicitor General also pointed out that in B . Venkataramana Vs. The State of
Madras & Anr.29, the list of backward classes as mentioned in Schedule 3 to the Madras Provincial
and Subordinate Services Rule, 1942 was approved and which was also noticed in Indra Sawhney's
case (supra). Reference was also made to the debates in Parliament where Dr. Ambedkar stated that
"the backward classes are nothing but collection of certain castes". It was further contended that it is
incorrect to say that the majority in Indra Sawhney's case (supra) did not accept or approve the
Mandal Commission Report. That Report was referred to in several places in that judgment and the
criterion adopted by the Mandal Commission to classify the backward classes was more or less
accepted. The learned Solicitor General also pointed out that it is not correct to say that the State
Lists are defective and that they ought not to have been accepted by the Central Government. It is
pointed out that the Central List has been operating for 14 years for the purposes of reservations of
posts and not a single person has challenged any inclusion in the Central List 28 1971 (1) SCC 38 29
AIR 1951 SC 229 = 1951 1 MLJ 625 as being void or illegal; that the State Lists have also been
operating both for the purposes of Articles 16(4) and 15(4) and there has been no challenge at all in
any High Court or in the Supreme Court with regard to the State List and that there has not been a
single complaint made before the State Government or the National Commission with regard to
over-inclusion of any caste or community.
The learned Solicitor General pointed out that the allegations in relation to the working of the
National Commission for the Backward Classes are not true. The National Commission has framed
elaborate guidelines for consideration of request for inclusion and complaints of non-inclusion in
the Central List for other backward classes. The guidelines have been framed after studying theAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

criteria/indicators framed by the Mandal Commission and the Commissions set up in the past by
different State Governments. The National Commission held 236 public hearings at various places
since its inception. The National Commission had also prepared an elaborate questionnaire for
considering classes for inclusion in the State Lists. Detailed data was required to be submitted with
regard to social, educational and economic criteria of the communities that were considered. It is
pointed out that during the period of its functioning the National Commission recommended 297
requests for inclusion and at the same time rejected 288 requests for inclusion of main castes. It was
further pointed out that the National Commission has not mechanically allowed all applications for
inclusion in the Central List.
The National Commission while examining the applications had taken note of the ethnographic
history of the concerned castes/sub-
groups/communities and it has also taken note of the recommendations of the various State
Commissions. It was also submitted that the contention that the inclusion of the caste in OBCs was
motivated by political considerations is erroneous and the National Commission had emphatically
rejected politically dominant castes such as the Marathas from being included in the Central List
and several other castes were thus excluded from OBCs list. The learned Solicitor General also
contended that the plea that reservation under Article 15(5) with reference to Article 29(2) would
render 15(5) constitutionally violative is incorrect. Article 29(2) is a protection given by the
Constitution against denial of admission to educational institutions on the ground of religion, race,
caste, language or any of them. It does not apply if provision is made for backward classes when the
basis for classification is not solely on these grounds. It was argued further that the American
doctrines and tests relating to "strict scrutiny", "compelling State necessity" and "narrow tailoring"
are tests which are not applicable to India at all.
There is a presumption of constitutionality of the legislations passed by Parliament. The Indian
Constitution specifically provides provisions like Articles 15(4) and 16(4) which permit special
provisions for backward classes. It was also contended that it is incorrect to suggest that there have
been no efforts on the part of successive Governments to concentrate on elementary education
towards universal elementary education. "Sarva Shiksha Abhiyan"
(SSA) had been launched by the Government in 2001-2002. The learned Solicitor
General also pointed out that it is incorrect to say that there has been no proper
consideration of the Bill in Parliament, particularly in relation to Financial
Memorandum. It is pointed that debates in Parliament are not usually relevant for
construction of the provisions of an Act. The learned Solicitor General also submitted
that it cannot seriously be disputed that large sections of the population are socially
and educationally backward and it is nobody's case that the total population of OBCs
in this country is less than 27%. Even on the basis of the facts relied on by the
petitioners, namely, National Sample Survey Organisation (NSSO), the total
population of OBCs in India is around 36%. The NSSO had conducted this survey for
the preparation of its 61st Round of survey which was published in October 2006.
This survey indicated that the total number of OBCs in India is around 41%. 27%Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

reservation in relation to admission had been upheld in Indra Sawhney's case (supra)
and the Parliament has taken special care to see that this reservation does not affect
seats in the general category. The learned Solicitor General also pointed out that the
policy of reservation flows from the mandate of equality till the time the
Constitutional objective of real equality is achieved. Moreover, the policy of
reservation has been introduced for the first time after 56 years of coming into force
of the Constitution. The learned Solicitor General also pointed out that meticulous
care has been taken for the inclusion of certain castes in the OBCs list and reference
was made to cases in Rajasthan, Karnataka and Kerala.
61. Shri Gopal Subramanium, the learned Additional Solicitor General, supported the Constitution
(Ninety-Third Amendment) Act, 2005 and also the provisions of Act 5 of 2007. The learned
Additional Solicitor General submitted that the American doctrines are not applicable to India. In
this regard, the observations of this Court in A.K. Roy Vs. Union of India & Ors.30, that "we cannot
transplant, in the Indian context and conditions, principles which took birth in other soils, without a
careful examination of their relevance to the interpretation of our Constitution" were cited. It is
pointed by the learned Additional Solicitor General that prepositions enunciated in the decisions of
the United States Supreme Court in Regents of the University of California Vs. Bakke31, Grutter Vs.
Bollinger32 and Gratz Vs. Bollinger33, and Parents Involved in Community Schools Vs. Seattle
School District34, that the Court will apply the standard of strict scrutiny while reviewing legislation
involving suspect classification; that and such legislation would be effected if two conditions are
met, namely, (i) there is a compelling governmental interest in making the classification, and (ii) the
legislation has been narrowly tailored to meet that classification; that the classification based on
race is a suspect classification and that accordingly while race can be a factor in admission policies
of educational institutions, 30 1982 (1) SCC 271 31 438 US 265 (1978) 32 539 US 306 (2003) 33 539
US 244 (2003) 34 127 S.Ct. 2738 (2007) it cannot be the sole factor and it cannot lead to the
imposition of quotas, which are per se unconstitutional - each of these propositions has been
rejected in Indian law and the Indian Constitution neither admits "suspect classification" nor "strict
scrutiny". The constitutionality of quotas has been repeatedly affirmed and reliance by the
Petitioners on the United States "affirmative action" judgments is wholly misconceived. The learned
Additional Solicitor General has made special reference to various American decisions on the
doctrine of "affirmative action". The learned Additional Solicitor General has also referred to the
decisions of this Court in N.M. Thomas' case (supra) and K.C. Vasanth kumar's case (supra) and
other decisions to contend that Articles 16(4) and 15(4) are not exceptions to Articles 16(1) and 15(1)
respectively and these provisions have to be read together with the principles of governance set out
in Part IV of the Constitution and it is beyond doubt that underlying constitutional obligations are
towards socially and educationally backward classes and there is a positive obligation on the State to
take steps to eradicate their backwardness.
The learned Additional Solicitor General also refuted the contentions advanced by Shri P.P. Rao,
learned Senior Counsel, and contended that all efforts have been made by the Government to
improve primary and upper primary education in India. The learned Additional Solicitor General
also contended that the argument advanced by Dr. Rajeev Dhavan is not correct. He relied upon
Arjun Sen Gupta's Report35 wherein it is stated :-Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

".....Education can be a liberating capability but access to it is made difficult, if not
impossible, by such inherited characteristics as lower social status, rural origin,
informal work status and gender or a combination of these."
62. Shri Ram Jethmalani, learned Senior Counsel appearing for the Intervener-Rashtriya Janta Dal
Party in W.P. No. 313 of 2007 and W.P. No. 335 of 2007, contended that the attempt of the
petitioners in these writ petitions is to off-set the decision of the Nine Judges Bench in Indra
Sawhney's case (supra). It is pointed out that the equality of citizens is the basic feature of the
Indian Constitution but by "equality"
is meant not "formal or technical equality" but "real and substantial equality". The word "only" used
in Articles 15(1) and 16(2) is 35 Arjun Sen Gupta Report on "Conditions of Work and Promotion of
Livelihood in the Unorganised Sector (July 2007) decisive. Even if reservations are made for castes,
the classification will become invalid if it is only on the basis of caste and if some other additional
requirement is imposed, that case would be considered to be outside the prohibition of Article 15(1).
Reference is made to B. Venkataramana's case (supra). It was contended that a statute cannot be
declared ultra vires merely because backwardness is a complex concept and no precise definition is
possible. The Court is bound to assume that a state of facts existed at the time of the enactment of
the statute which would validate that statute and when the Constitution of the United States came
into effect it did not contain the constitutional right of equality. Even the Vth Amendment of 1971 to
the Constitution of the United States of America did not introduce this concept. The XIVth
Amendment of 1868 provided that the "State shall not deny to any person the equal protection of
the laws". Even after this injunction, the United States Supreme Court delivered the judgment in
Plessy Vs. Ferguson36, which laid down the doctrine of "Equal but Separate". This doctrine was in
force till it was reversed in 1954. The learned Senior Counsel also contended that the policy of
reservation is not destructive of merit and that the Symbiosis University is not covered by the
statute.
36 (1896) 41 L.Ed. 256
63. Shri T.R. Andhyarujina, the learned Senior Counsel appearing for the respondents in W.P.
265/2006, contended that Articles 15(4) and 16(4) operate in different fields and Article 15(4)
enables the State Government to make special provisions for backward classes, SCs and STs which
can be done both by law or by executive order. The special provision in Article 15(4) is not restricted
to advancement of SEBCs, SCs and STs in educational institutions only and enables the State to
make several kinds of positive action programmes in addition to reservations. As a condition for
giving aid, the State can make reservations for SEBCs, SCs and STs in educational institutions which
are State owned or State aided. The State, however, cannot make such reservations in private
unaided educational institutions, as held by this Court in T.M.A. Pai Foundation (supra) and P.A.
Inamdar (supra). This disability was because of T.M.A. Pai Foundation (supra) which provided that
private unaided educational institutions had a fundamental right to "occupation" of carrying on
education under Article 19(1)(g). Therefore, the Parliament introduced Article 15(5) by the
Constitution (Ninety-Third Amendment) Act to enable the State to make special provisions for the
advancement of SCs, STs and SEBCs in relation to a specific subject, namely, admission inAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

educational institutions including private educational institutions whether aided or unaided by the
State notwithstanding the provisions of Article 19(1)(g). However, Article 15(5) excluded private
educational institutions which are minority educational institutions referred to in clause (1) of
Article 30. The saving for minority educational institutions in Article 15(5) is really ex abundandi
cautela as minority educational institutions were constitutionally protected and at all times
considered different from other private educational institutions. Article 15(5) does not take away the
"basic structure" of the Constitution. The "basic structure"
of the Constitution should not be trivialized to mean other features of the
Constitution. Reference was made to the observations made by Khanna, J. in
Kesavananda Bharati's case (supra). It was also submitted that Article 15(5) does not
amend Entry 25 List III to the extent that the State can no more make laws for
reservation of seats in minority educational institutions and, therefore, it is incorrect
to say that the amendment in Article 15(5) required ratification under Article 368(2).
The State's power to legislate under Article 245 is always subject to the other
provisions of the Constitution, including fundamental rights. Article 15(4) does not
take away the power of the State to make reservations in its own institutions by an
executive action under Article 162. Right to carry on business is not a part of the basic
structure of the Constitution.
64. On behalf of the respondent/State of Bihar in Writ Petition (Civil) No. 269/2007, learned Senior
Counsel Shri Rakesh Dwivedi submitted that the use of non-obstante clauses in Article 15(3), (4)
and (5) vis-a-vis Article 15(1) shows that the prohibition against use of only caste as a ground for
discrimination qua any citizen is there in so far as making of a special provision for advancement of
prescribed categories is concerned. There is no repugnance between 15(4) and 15(5). It was
contended that in Kesavananda Bharati's case (supra), it was held that "Part III of the Constitution
could be amended subject to the basic structure doctrine". The view which was held in I.C. Golak
Nath & Ors. Vs. State of Punjab & Anrs,37 making Article 368 more restrictive, had been overruled
in Kesavananda Bharati's case (supra). The Fundamental Rights are not absolute and are designed
to suffer reasonable restrictions and classifications.
Any sort of abridgement by Constitutional Amendment is clearly 37 (1967) 2 SCR 762 permissible so
long as the invasion does not amount to total elimination or emasculation. Within the domain of
equality there is distinction between formal equality and real equality or equality in fact and both
are comprehended in Article 14 and both are part of the basic structure.
65. The learned Senior Counsel also contended that the judicial review ideas of "suspect
classification", "strict scrutiny", "compelling State interest" and "narrow tailoring" are measures
propounded by the U.S. Supreme Court are not applicable and the Supreme Court of India has
consistently taken a view that the judgments of the U.S. Supreme Court do not afford safe guidance
on account of differing structure of the provisions under the two constitutions and the social
conditions in these two countries being different.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

66. Reference was made to the various decisions of this court and it was argued that the comparison
of the 14th Amendment of the US Supreme Court read with Civil Rights Act, 1964 on the one hand
and the fascicules of equality provisions in the Constitution of India, i.e. Article 14 to 18 on the other
hand shows that the equality provisions of our Constitution are not only differently structured but it
contains provisions for making special provisions for the advancement of SEBCs & SCs/STs. It is
pointed out that our Constitution additionally enshrines Directive Principles of State Policy in
Part-IV of the Constitution requiring the State to strive to promote justice social, economic and
political and to minimize the inequalities in income and endeavour to remove inequalities in status,
facilities and opportunities (Article 38).
67. Shri Ravivarma Kumar, learned Senior Counsel appearing for Pattali Makkal Katchi, contended
that the creamy layer principle shall not be invoked for the purpose of Article 15(5). According to the
Counsel, reservation in educational institutions is not a poverty alleviation programme nor it is a
programme to eradicate unemployment. Reservation under Article 15(5) is not even a programme to
educate all the backward classes. According to the Counsel the one and only goal of the reservation
policy under Clause 4 & 5 of Article 15 of the Constitution is to bring about equality among various
castes and unless all the castes are brought to one level playing field, the caste system cannot be
eradicated. It is intended for removal of inequality between castes so that the castes will come
together. These provisions are designed to bring together the leaders of each caste and community
together and the same can be achieved only if the best teachers, the best administrators, the best
doctors, the best engineers and the best lawyers are brought together. And so long as the gap in
education persists between castes, the castes will not come together. It is only when each backward
caste is permitted to advance educationally to meet the educational level of upper castes, can there
be a real egalitarian society. According to the Counsel, it is precisely for this reason that Clause (2) of
Article 38 seeks to eliminate inequality in status, facilities and opportunities, not only among
individuals, but also among groups of people. Therefore, it is to provide for such equality in status,
facilities and opportunities, that reservation is contemplated to those castes which are socially and
educationally below other castes. If the best from the lower caste are deprived of these facilities and
opportunities in the name of "creamy layer", it will be counter productive and frustrate the very
object of reservation, namely to achieve equality in status, facilities and opportunities.
68. The Counsel also contended that the question of prescribing prior time limit for reservation
under the impugned Act is immature and should not be considered at this stage.
69. The link between "caste" and its occupation is an unbreakable bondage to which the caste
system has condemned the backward classes. Whether a backward caste man carries on his
traditional occupation or not, he continues to be socially identified with the said occupation. This
link between the caste and the occupation has not been severed for thousands of years and it cannot
be broken by arguments and theories. The ground reality is that every caste in every village is
identified by its traditional occupation. And all the service communities continue to discharge their
traditional occupation. It is pointed out that throughout the country in 6.5 lakh villages, it is the
barber communities and barber communities alone, which carry on the traditional occupation of
hair cuttings and no other community has taken up the said occupation. And they continue to labour
without any social security or whatsoever.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

70. The Counsel pointed out that the last six decennial censuses have eschewed recording of caste
particulars, the three National Commissions and scores of State Commissions have found these
Census data useless in identification of Backward Classes.
71. The learned Counsel submitted that there is no justification for not collecting details of caste
identity at the decennial census operation. According to the Counsel a massive exercise is rendered
useless for the all important work of identification of Backward Classes.
72. It is further submitted that the entire identification of backward classes has not been done on the
basis of 1931 Census data. In each State the identification of Backward Classes has been done on the
basis of criteria evolved by the State Commissions on social, educational and economic parameters.
Each State has adopted its own methodology. The identification of backward classes is essentially
done at the State level on a very objective criteria and a scientific methodology. According to the
Counsel, origin of the term "classes of citizens" may be traced to the later part of the 19th century.
Quite often classes have been interchangeably used with castes, tribes and communities. Some of
the earlier Committee reports referred to Depressed Classes. Under the 1919 Act, Governors of the
provinces give instruction to take measures for the social and industrial welfare of the people and
tending to fit all classes of population. And the Provincial Governments prepared a list of Backward
Classes with three parts namely, Depressed Classes, Aboriginal Tribes and Backward Communities.
Dr. Ambedkar demanded separate electorate for the Depresses Classes at the Round Table
Conference.
73. The Counsel also pointed out that the building of a casteless society is not the goal of the
Constitution. And that it is futile to contend that caste should not be considered for any purpose
whatsoever. In every conceivable activity of private life caste system plays an important role. There
are hundreds of communal hostels and educational institutions owned and managed by certain
communities. Some castes and communities have communal clubs, associations, cooperatives,
banks etc. Their membership and admission are confined to a particular caste or community. Even
carrying of the caste names is the guaranteed right of every citizen.
There is nothing in the Constitution to prohibit a person from discriminating on the ground only of
caste or community in matters relating to marriage, electing candidates to political position etc.
Most of the professional colleges like medical, dental and engineering colleges are established and
administered by a body of persons exclusively belonging to a class or a community. Though Dr.
Ambedkar intended to abolish caste system by abolishing all the privileges and disabilities of the
forward classes, the plea was opposed by Shri K.M. Munshi and the Draft Article 3(4) stated:
"Un-touchability is abolished and its practice thereof is punishable by the law of the
Union".
74. The Constitution never prohibits the practice of caste and casteism. Every activity in Hindu
society, from cradle to grave is carried on solely on the basis of one's caste. Even after death, a
Hindu is not allowed to be cremated in the crematorium which is maintained for the exclusive use of
the other caste or community.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Dalits are not permitted to be buried in graves or cremated in crematoriums where upper caste
people bury or cremate their dead.
Christians have their own graveyards. Muslims are not allowed to be buried in the Hindu
crematoriums and vice-versa. Thus, caste rules the roost in the life of a Hindu and even after his
death. In such circumstances, it is entirely fallacious to advance this argument on the ground that
the Constitution has prohibited the use of caste. It was argued what the Constitution aims at is
achievement of equality between the castes and not elimination of castes.
75. The learned Senior Counsel points out that it would be utopian to expect that by ignoring caste,
the castes will perish. And the Counsel contended the Constitution has not abolished the caste
system much less has it prohibited its use. The Counsel pointed out that the Constitutional
Amendment under the impugned Act in favour of backward classes is an unprecedented leap taking
the higher education in the country forward, without depriving a single seat to the forward castes.
And the advanced castes, with a population of less than 20% would still be able to get 50% of the
seats in the name of merit disproportionate to their known proportion of their population.
It is contended that without the advancement of SCs, STs and OBCs constituting over 80%
population and mainly living in rural areas, it will not be possible to take the nation forward. And
the students who are admitted under the reserved quota have performed much better than the
students admitted on the basis of merit. The learned Counsel also placed reliance on the Moily
Report - Case studies from four States.
76. The main challenge in these writ petitions is the constitutional validity of the Act 5 of 2007. This
legislation was passed by Parliament consequent upon The Constitution (Ninety-Third Amendment)
Act, 2005, by which sub-article (5) was inserted in Article 15 of the Constitution. The
constitutionality of this amendment has also been challenged in the various writ petitions filed by
the petitioners. As the Act itself is based on the Constitution (Ninety-
Third Amendment) Act, 2005, the validity of the Act depends on the fact whether the Constitution
(Ninety-Third Amendment) Act, 2005 itself is valid or not. Article 15 of the Constitution, after the
Constitution (Ninety-Third Amendment) Act, 2005, reads as follows :-
"15. Prohibition of discrimination on grounds of religion, race, caste, sex or place of
birth.--
(1) The State shall not discriminate against any citizen on grounds only of religion,
race, caste, sex, place of birth or any of them. (2) No citizen shall, on grounds only of
religion, race, caste, sex, place of birth or any of them, be subject to any disability,
liability, restriction or condition with regard to,--
(a) access to shops, public restaurants, hotels and places of public entertainment; orAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(b) the use of wells, tanks, bathing ghats, roads and places of public resort
maintained wholly or partly out of State funds or dedicated to the use of the general
public. (3) Nothing in this Article shall prevent the State from making any special
provision for women and children.
(4) Nothing in this Article or in clause (2) of Article 29 shall prevent the State from
making any special provision for the advancement of any socially and educationally
backward classes of citizens or for the Scheduled Castes and the Scheduled Tribes (5)
Nothing in this Article or sub-clause (g) of clause (1) of Article 19 shall prevent the
State from making any provision by law for the advancement of any socially and
educationally backward classes of citizens or the Scheduled Castes or the Scheduled
Tribes in so far as such special provision relate to their admission to the educational
institutions, including private educational institutions whether aided or unaided by
the State other minority educational institutions referred to in clause (1) of Article
30."
77. T.M.A. Pai Foundation (supra) held that a private unaided educational institution has the
fundamental right under Article 19(1)
(g) of the Constitution as the running of an educational institution was treated as an "occupation"
and further that the State's regulation in such institutions would not be regarded as a reasonable
restriction on that fundamental right to carry on business under Article 19(6). This decision
necessitated the Ninety-Third Amendment to the Constitution since as a result of T.M.A. Pai
Foundation (supra) the State would not be in a position to control or regulate the admission in
private educational institutions. At the outset, it may have to be stated that no educational
institution has come up to challenge the Constitution (Ninety-Third Amendment) Act, 2005. The
challenge about the constitutionality of the Constitution (Ninety-Third Amendment) Act, 2005 has
been advanced by the petitioners, who based their contentions on the equality principles enunciated
in Articles 14, 15 and 16 of the Constitution.
78. The Constitution (Ninety-Third Amendment) Act, 2005 is challenged on many grounds. The
first ground of attack is that if the Constitution (Ninety-Third Amendment) Act, 2005 is allowed to
stand it would be against the "basic structure" of the Constitution itself and this Amendment
seriously abridges the equality principles guaranteed under Article 15 and other provisions of the
Constitution. Another contention raised by the petitioners' Counsel is that the Golden Triangle of
Articles 14, 19 and 21 is not to be altered and the balance and structure of these constitutional
provisions has been ousted by the Constitution (Ninety-Third Amendment) Act, 2005. Yet another
contention urged by Shri K.K. Venugopal, learned Senior Counsel, is that Article 15(4) and 15(5) are
mutually exclusive and under Article 15(5) the minority educational institutions are excluded.
According to him, this is a clear contravention of the secular and equality principles. The learned
Senior Counsel also pointed out that minority institutions are not severable from the purview of
Article 15(5) and therefore, the whole Constitution (Ninety-Third Amendment) Act, 2005 is to be
declared illegal. Another argument advanced by the learned Senior Counsel is that there isAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

inconsistency between Article 15(4) and Article 15(5) and by virtue of the Constitution (Ninety-Third
Amendment) Act, 2005, the States are devoid of their wide power under Article 15(5) to make
reservation in minority educational institutions which are getting aid from the States and thus it is
violative of the very essence of equality. He further argued that the Constitution (Ninety-Third
Amendment) Act, 2005 could control the legislative and executive power of the State and, therefore,
it is not constitutionally valid. The learned Counsel had further challenged the validity of Act 5 of
2007, with which we will deal separately.
1. Wh ether Ninety-Third Amendment of the Constitution i s against the "basic structure" of the
Constitution?
79. The Constitution (Ninety-Third Amendment) Act, 2005, by which clause (5) was added to Article
15 of the Constitution, is an enabling provision which states that nothing in Article 15 or in
sub-clause (g) of clause (1) of article 19 shall prevent the State from making any special provision, by
law, for the advancement of any socially and educationally backward classes of citizens or for the
Scheduled Castes or the Scheduled Tribes in so far as such special provisions relate to their
admission to the educational institutions including private educational institutions, whether aided
or unaided by the State. Of course, minority educational institutions referred to in clause (1) of
Article 30 are excluded. Thus, the newly added clause (5) of Article 15 is sought to be applied to
educational institutions whether aided or unaided. In other words, this newly added constitutional
provision would enable the State to make any special provision by law for admission in private
educational institutions whether aided or unaided. In all the petitions which have been filed before
us the main challenge is against Act 5 of 2007. Act 5 of 2007 has been enacted to provide reservation
of seats for Scheduled Castes, Scheduled Tribes and SEBCs of citizens in Central Educational
Institutions. The "Central Educational Institution" has been defined under Section 2(d) of the Act.
They are institutions established or incorporated by or under the Central Act or set up by an Act of
Parliament or deemed Universities maintained by or receiving aid from the Central Government or
institutions maintained by or receiving aid from the Central Government or educational institutions
set up by the Central Government under the Societies Registration Act, 1860. Act 5 of 2007 is not
intended to provide reservation in "private unaided" educational institutions. None of the private
unaided educational institutions have filed petitions before us challenging the Ninety-Third
Constitutional Amendment. Though the learned counsel appearing for the petitioners have
challenged the Ninety-Third Constitutional Amendment on various grounds, they were vis-`-vis the
challenge to Act 5 of 2007. The counter to the challenge by the learned Solicitor General as well as
by Shri K. Parasaran, learned Senior Counsel was also in that context. We do not want to enter a
finding as to whether the Ninety-Third Constitutional Amendment is violative of the "basic
structure" of the Constitution so far as it relates to "private unaided" educational institutions. In the
absence of challenge by private unaided educational institutions, it would not be proper to
pronounce upon the constitutional validity of that part of the Constitutional Amendment.
As the main challenge in these various petitions was only regarding the provisions of Act 5 of 2007,
which related to state maintained institutions, the challenge to the Ninety-Third Constitutional
Amendment so far as it relates to private unaided educational institutions, does not strictly arise in
these proceedings. In the absence of challenge by private unaided institutions, it may not be properAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

for this Court to decide whether the Ninety-Third Constitutional Amendment is violative of the
"basic structure" of the Constitution so far as it relates to private unaided educational institutions
merely because we are considering its validity in the context of Act 5 of 2007.
We feel that such questions could be decided as the main questions that are involved in these
petitions are specific regarding Act 5 of 2007, we leave open the question as to whether the
Ninety-Third Amendment to the Constitution by which sub-clause (5) was inserted is violative of the
basic structure doctrine or not so far as it relates to "private unaided" educational institutions to be
decided in other appropriate cases. We deal only with the question of whether the Ninety-Third
Constitutional Amendment is constitutionally valid so far as it relates to the state maintained
institutions and aided educational institutions.
80. Several contentions have been advanced by the petitioners' Counsel challenging the
constitutional validity of the Constitution (Ninety-Third Amendment) Act, 2005. The main
argument was on the ground that this amendment is against the "basic structure" of the
Constitution. In order to appreciate the contention of the petitioners' Counsel, it is necessary to
understand the "basic structure" theory that has been propounded in the celebrated case of
Kesavananda Bharati (supra). This case was a decision of 13 Judge Bench of this Court. Though the
Judges were not unanimous about what the "basic structure" of the Constitution be, however, Shelat
J. (at page 280) in his judgment had indicated the following basic features of the Constitution :-
"The basic structure of the Constitution is not a vague concept and the apprehensions
expressed on behalf of the respondents that neither the citizen nor the Parliament
would be able to understand it are unfounded. If the historical background, the
Preamble, the entire scheme of the Constitution, the relevant provisions thereof
including Article 368 are kept in kind thee can be no difficulty in discerning that the
following can be regarded as the basic elements of the constitutional structure.
(These cannot be catalogued but can only be illustrated) :-
1. The supremacy of the Constitution.
2. Republican and Democratic form of Government and sovereignty of the country.
3. Secular and federal character of the Constitution.
4. Demarcation of power between the legislature, the executive and the judiciary.
5. The dignity of the individual secured by the various freedoms and basic rights in
Part III and the mandate to build a welfare State contained in Part IV.
6. The unity and the integrity of the nation."
81. Sikri, CJ (at page 165-166) held that :-Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"The true position is that every provision of the Constitution can be amended
provided in the result the basic foundation and structure of the constitution remains
the same. The basic structure may be said to consist of the following features :-
(1)     Supremacy of the Constitution.
(2)     Republication and Democratic form of Government.
(3)     Secular character of the Constitution.
(4)     Separation   of   powers   between   the   Legislature,   the   executive 
and the judiciary.
(5)     Federal character of the Constitution."
82. The power of Parliament to amend the Constitution also was dealt with in detail
and majority of the Judges held that the fundamental rights can be amended, altered
or abridged. The majority decision in Kesavananda Bharati's case (supra) overruled
the decision in I.C. Golak Nath Vs. State of Punjab, (supra). Kesavananda Bharati
indicates the extent to which amendment of the Constitution could be carried out and
lays down that the legality of an amendment is no more open to attack than the
Constitution itself. It was held that the validity of an ordinary law can be questioned
and when it is questioned it must be justified by reference to a higher law. In the case
of the Constitution the validity is inherent and lies within itself. The Constitution
generates its own validity. The validity of the Constitution lies in the social fact of its
acceptance by the community. There is a clear demarcation between an ordinary law
made in exercise of the legislative power and the constituent law made in exercise of
constitutional power. Therefore, the power to amend the Constitution is different
from the power to amend ordinary law. The distinction between the legislative power
and the constitutional power is vital in a rigid or controlled Constitution because it is
that distinction which brings in the doctrine that a law ultra vires the Constitution is
void. When the Parliament is engaged in the amending process it is not legislating, it
is exercising a particular power bestowed upon it sui generis by the amending clause
in the Constitution. Sikri, CJ, held that the expression "amendment of this
Constitution" does not enable Parliament to abrogate or take away fundamental
rights or to completely change the fundamental features of the Constitution so as to
destroy its identity. Within these limits Parliament can amend every article. Shelat &
Grover JJ. ( at p 291) concluded that :
"Though the power to amend cannot be narrowly construed and extends to all the
Articles it is not unlimited so as to include the power to abrogate or change the
identity of the Constitution or its basic features."Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

83. Hegde & Mukherjee, JJ. finally concluded (at p 355) that :
"The power to amend the Constitution under Article 368 as it stood before its
amendment empowered the Parliament by following the form and manner laid down
in that Article, to amend each and every Article and each and every Part of the
Constitution..... Though the power to amend the Constitution under Article 368 is a
very wide power, it does not yet include the power to destroy or emasculate the basic
elements or the fundamental features of the Constitution."
84. Ray J. (as he then was) (at p 461) held that :-
"...The Constitution is the supreme law. Third, an amendment of the Constitution is
an exercise of the constituent power. The majority view in Golak Nath case is with
respect wrong. Fourth, there are no express limitations to the power of amendment.
Fifth, there are no implied and inherent limitations on the power of amendment.
Neither the Preamble nor Article 13(2) is at all a limitation on the power of
amendment. Sixth, the power to amend is wide and unlimited. The power to amend
means the power to add, alter or repeal any provision of the Constitution. There can
be or is no distinction between essential and in-essential features of the Constitution
to raise any impediment to amendment of alleged essential features."
85. Palekar, J. (at p. 632) concluded that :-
"The power and the procedure for the amendment of the Constitution were contained
in the unamended Article 368. An Amendment of the Constitution in accordance
with the procedure prescribed in that Article is not a `law' within the meaning of
Article 13. An amendment of the Constitution abridging or taking away a
fundamental right conferred by Part III of the Constitution is not void as
contravening the provisions of Article 13(2). There were no implied or inherent
limitations on the amending power under the unamended Article 368 in its operation
over the fundamental rights. There can be none after its amendment."
86. Khanna, J. (at p. 758, 759) concluded that :-
"The power to amendment under Article 368 does not include power to abrogate the
Constitution nor does it include the power to alter the basic structure or framework
of the Constitution. Subject to the retention of the basic structure or framework of the
Constitution, the power of amendment is plenary and includes within itself the power
to amend the various articles of the Constitution, including those relating to
fundamental rights as well as those which may be said to relate to essential features.
No part of a fundamental right can claim immunity from amendatory process by
being described as the essence or core of that right. The power of amendment would
also include within itself the power to add, alter or repeal the various articles."Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

87. Mathew, J. (at p. 857) held that :-
"The only limitation is that the Constitution cannot be repealed or abrogated in the
exercise of the power of amendment without substituting a mechanism by which the
State is constituted and organized. That limitation flows from the language of the
article itself."
88. Beg, J. (at p. 886) held that :-
"The majority view in Golak Nath's case (supra), holding that Article 13 operated as a
limitation upon the powers of Constitutional amendment found in Article 368, was
erroneous."
He upheld the 24th Amendment and the 25th Amendment Act including addition of Article 31C.
89. Dwivedi, J finally concluded that :
"The word "amendment" in Article 368 is broad enough to authorize the varying or
abridging each and every provision of the Constitution, including Part III. There are
no inherent and implied limitations of the amendment power in Article 368"
90. Finally, Chandrachud, J. ( at p. 1000) held that :
" The power of amendment of the Constitution conferred by the then Article 368 was
wide and unfettered. It reached every part and provision of the Constitution."
91. A survey of the conclusions reached by the learned Judges in Kesavananda Bharati's case (supra)
clearly shows that the power of amendment was very wide and even the fundamental rights could be
amended or altered. It is also important to note that the decision in RE : The Berubari Union and
Exchange of Enclaves, Reference under Article 143(1) of the Constitution of India38, to the effect
that preamble to the Constitution was not part of the Constitution was disapproved in Kesavananda
Bharati's case (supra) and it was held that it is a part of the Constitution and the Preamble to the
Constitution is of extreme importance and the Constitution should be read and interpreted in the
light of the grand and noble visions envisaged in the Preamble. A close analysis of the decisions in
Kesavananda Bharati's case (supra) shows that all the provisions of the Constitution, including the
fundamental rights, could be amended or altered and the only limitation placed is that the basic
structure of the Constitution shall not be altered. The judgment in 38 (1960) 3 SCR 250
Kesavananda Bharati's case (supra) clearly indicates what is the basic structure of the Constitution.
It is not any single idea or principle like equality or any other constitutional principles that are
subject to variation, but the principles of equality cannot be completely taken away so as to leave the
citizens in this country in a state of lawlessness. But the facets of the principle of equality could
always be altered especially to carry out the Directive Principles of the State Policy envisaged in Part
IV of the Constitution. The Constitution (Ninety-Third Amendment) Act, 2005 is to be examined in
the light of the above position.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

92. The basic structure of the Constitution is to be taken as a larger principle on which the
Constitution itself is framed and some of the illustrations given as to what constitutes the basic
structure of the Constitution would show that they are not confined to the alteration or modification
of any of the Fundamental Rights alone or any of the provisions of the Constitution. Of course, if any
of the basic rights enshrined in the Constitution are completely taken out, it may be argued that it
amounts to alteration of the Basic Structure of the Constitution. For example, the federal character
of the Constitution is considered to be the basic structure of the Constitution. There are large
number of provisions in the Constitution dealing with the federal character of the Constitution. If
any one of the provisions is altered or modified, that does not amount to the alteration of the basic
structure of the Constitution. Various fundamental rights are given in the Constitution dealing with
various aspects of human life. The Constitution itself sets out principles for an expanding future and
is obligated to endure for future ages to come and consequently it has to be adapted to the various
changes that may take place in human affairs.
93. For determining whether a particular feature of the Constitution is part of the basic structure or
not, it has to be examined in each individual case keeping in mind the scheme of the Constitution,
its objects and purpose and the integrity of the Constitution as a fundamental instrument for the
country's governance. It may be noticed that it is not open to challenge the ordinary legislations on
the basis of the basic structure principle. State legislation can be challenged on the question whether
it is violative of the provisions of the Constitution. But as regards constitutional amendments, if any
challenge is made on the basis of basic structure, it has to be examined based on the basic features of
the Constitution. It may be noticed that the majority in Kesavananda Bharati's case (supra) did not
hold that all facets of Article 14 or any of the fundamental rights would form part of the basic
structure of the Constitution. The majority upheld the validity of the first part of Article 30(1)(c)
which would show that the constitutional amendment which takes away or abridges the right to
challenge the validity of an arbitrary law or violating a fundamental right under that Article would
not destroy or damage the basic structure. Equality is a multi-coloured concept incapable of a single
definition as is also the fundamental right under Article 19(1)(g). The principle of equality is a
delicate, vulnerable and supremely precious concept for our society. It is true that it has embraced a
critical and essential component of constitutional identity.
The larger principles of equality as stated in Article 14, 15 and 16 may be understood as an element
of the "basic structure" of the Constitution and may not be subject to amendment, although, these
provisions, intended to configure these rights in a particular way, may be changed within the
constraints of the broader principle. The variability of changing conditions may necessitate the
modifications in the structure and design of these rights, but the transient characters of formal
arrangements must reflect the larger purpose and principles that are the continuous and unalterable
thread of constitutional identity. It is not the introduction of significant and far-reaching change
that is objectionable, rather it is the content of this change in so far as it implicates the question of
constitutional identity.
94. The observations made by Mathew, J in Smt. Indra Gandhi Vs. Raj Narain39 are significant in
this regard:Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"To be a basic structure it must be a terrestrial concept having its habitat within the
four corners of the Constitution." What constitutes basic structure is not like "a
twinkling star up above the Constitution."
It does not consist of any abstract ideals to be found outside the provisions of the Constitution. The
Preamble no doubt enumerates great concepts embodying the ideological aspirations of the people
but these concepts are particularised and their essential features delineated in the various
provisions of the Constitution. It is these specific provisions in the body of the Constitution which
determine the type of democracy which the founders of that instrument established; the quality and
nature of justice, political, social and economic which they aimed to realize, the content of liberty of
thought and expression which they entrenched in that document and the scope of equality of status
and of opportunity which they enshrined in it. These specific provisions enacted in the Constitution
alone can determine the basic structure of the Constitution. These specific provisions, either
separately or in combination, determine the content of the great concepts set out in the Preamble. It
is impossible to spin out any concrete concept of basic structure out of the gossamer concepts set out
in the Preamble. The specific provisions of the Constitution are the stuff from which the basic 39
(1976) 2 SCR 347 : (AIR 1975 SC 2299) structure has to be woven".
95. If any Constitutional amendment is made which moderately abridges or alters the equality
principle or the principles under Article 19(1)(g), it cannot be said that it violates the basic structure
of the Constitution. If such a principle is accepted, our Constitution would not be able to adapt itself
to the changing conditions of a dynamic human society. Therefore, the plea raised by the Petitioners'
that the present Constitutional Ninety-Third Amendment Act, 2005 alters the basic structure of the
constitution is of no force. Moreover, the interpretation of the Constitution shall not be in a narrow
pedantic way. The observations made by the Constitution Bench in Nagaraj's case (supra) at page
240 are relevant:
"Constitution is not an ephermal legal document embodying a set of legal rules for
the passing hour. It sets out principles for an expanding future and is intended to
endure for ages to come and consequently to be adapted to the various crisis of
human affairs. Therefore, a purposive rather than a strict literal approach to the
interpretation should be adopted. A Constitutional provision must be construed not
in a narrow and constricted sense but in a wide and liberal manner so as to anticipate
and take account of changing conditions and purposes so that constitutional
provision does not get fossilized but remains flexible enough to meet the newly
emerging problems and challenges."
96. It has been held in many decisions that when a constitutional provision is interpreted, the
cardinal rule is to look to the Preamble to the Constitution as the guiding star and the Directive
Principles of State Policy as the `Book of Interpretation'. The Preamble embodies the hopes and
aspirations of the people and Directive Principles set out the proximate grounds in the governance
of this country.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

97. Therefore, we hold that the Ninety-Third Amendment to the Constitution does not violate the
"basic structure" of the Constitution so far as it relates to aided educational institutions. Question
whether reservation could be made for SCs, STs or SEBCs in private unaided educational
institutions on the basis of the Ninety-Third Constitutional Amendment; or whether reservation
could be given in such institutions; or whether any such legislation would be violative of Article
19(1)(g) or Article 14 of the Constitution; or whether the Ninety-Third Constitutional Amendment
which enables the State Legislatures or Parliament to make such legislation - are all questions to be
decided in a properly constituted lis between the affected parties and others who support such
legislation.
2. Whether Articles 15(4) and 15(5) are mutually contradictory, h ence Article 15(5) is to be held u
ltra vires ?
98. The next contention raised by the petitioner's Counsel is that Article 15(4) and 15(5) are
mutually exclusive and contradictory. The Counsel for the petitioner, particularly the petitioner in
Writ Petition (C) No. 598 of 2006, submitted that Article 15(4) was a provision and a source of
legislative power for the purpose of making reservation for Scheduled Castes (SCs) and Scheduled
Tribes (STs) as well as for Socially and Educationally Backward Classes (SEBCs) of citizens in aided
minority educational institutions. And Article 15(4) was inserted after the decision of this Court in
Champakam Dorairajan (supra) and Article 15(5) provides for reservation of seats for SCs, STs and
SEBCs in aided or unaided educational institutions but expressly excludes all such reservation being
made in minority educational institutions covered by Article 30(1) of the Constitution.
This, according to the Petitioner's learned Counsel, will lead to a situation where the State would not
be in a position to give reservation to SCs, STs and SEBCs even in aided minority institutions which
have got protection under Article 30(1) of the Constitution. It is argued that in view of the express
provision contained in Article 15(5), the State would no more be able to give the reservation and this
according to the petitioner's Counsel would result in annulling the endeavour of the founding
fathers and the various provisions for neutralizing the exclusion of SCs & STs from the mainstream
of society and development for centuries.
99. It is argued by petitioners' learned Counsel that Article 15(4) and 15(5) both commence with an
exclusionary clause excluding the operation of the rest of the Article 15, and hence would result in a
conflict to the extent of inconsistency. According to the petitioners', Article 15(5) is a special
provision relating to educational institutions and being a later amendment, it would prevail over
Article 15(4), thus in substance and effect resulting in an amendment of Article 15(4) of the
Constitution. According to the petitioner's Counsel, "nothing in this Article" in Article 15(5) would
include Article 15(4) also and in view of this inconsistent provision, Article 15(5) has to be held to be
inconsistent with 15(4) and thus non-operative.
100. Both Article 15(4) and 15(5) are enabling provisions. Article 15(4) was introduced when the
"Communal G.O." in the State of Madras was struck down by this Court in Champakam Dorairajan's
case (supra). In Unni Krishnan (supra), this Court held that Article 19(1)(g) is not attracted for
establishing and running educational institutions. However, in T.M.A. Pai Foundation case, (supra),Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

it was held that the right to establish and running educational institutions is an occupation within
the meaning of Article 19(1)(g).
The scope of the decision in T.M.A. Pai Foundation's case was later explained in P.A. Inamdar's
case, (supra). It was held that as regards unaided institutions, the State has no control and such
institutions are free to admit students of their own choice. The said decision necessitated the
enactment of the Constitution Ninety-Third Amendment Act, 2005. Thus, both Article 15(4) and
15(5) operate in different areas. The "nothing in this Article" [mentioned at the beginning of Article
15(5)] would only mean that the nothing in this Article which prohibit the State on grounds which
are mentioned in Article 15(1) alone be given importance. Article 15(5) does not exclude 15(4) of the
Constitution. It is a well settled principle of constitutional interpretation that while interpreting the
provisions of Constitution, effect shall be given to all the provisions of the Constitution and no
provision shall be interpreted in a manner as to make any other provision in the Constitution
inoperative or otiose. If the intention of the Parliament was to exclude Article 15(4), they could have
very well deleted Article 15(4) of the Constitution.
Minority institutions are also entitled to the exercise of fundamental rights under Article 19(1)(g) of
the Constitution, whether they be aided or unaided. But in the case of Article 15(5), the minority
educational institutions, whether aided or unaided, are excluded from the purview of Article 15(5) of
the Constitution. Both, being enabling provisions, would operate in their own field and the validity
of any legislation made on the basis of Article 15(4) or 15(5) have to be examined on the basis of
provisions contained in such legislation or the special provision that may be made under Article
15(4) or 15(5).
It may also be noticed that no educational institutions or any aggrieved party have come before us
challenging the constitutional amendment on these grounds. The challenge is made by petitioners
objecting to the reservations made under Act 5 of 2007. Therefore, the plea that Article 15(4) and
15(5) are mutually contradictory and, therefore, Article 15(5) is not constitutionally valid cannot be
accepted. As has been held in N.M. Thomas case (supra) and Indra Sawhney's case (supra), Article
15(4) and 16(4) are not exceptions to Article 15(1) and Article 16(1) but independent enabling
provision.
Article 15(5) also to be taken as an enabling provision to carry out certain constitutional mandate
and thus it is constitutionally valid and the contentions raised on these grounds are rejected.
3. Whether exclusion of minority educational institutions from Article 15(5) is violative of Article 14
of Constitution?
101. Another contention raised by the petitioner's Counsel is that the exclusion of minority
institutions under Article 15(5) itself is violative of Article 14 of the Constitution. It was contended
that the exclusion by itself is not severable from the rest of the provision. This plea also is not
tenable because the minority institutions have been given a separate treatment in view of Article 30
of Constitution. Such classification has been held to be in accordance with the provisions of the
Constitution. The exemption of minority educational institutions has been allowed to conformAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Article 15(5) with the mandate of Article 30 of the Constitution. Moreover, both Article 15(4) and
Article 15(5) are operative and the plea of non-severability is not applicable.
102. Learned Senior Counsel Dr. Rajeev Dhavan and learned Counsel Shri Sushil Kumar Jain
appearing for the petitioners contended that the Ninety-Third Constitutional Amendment would
violate the equality principles enshrined in Articles 14, 19 and 21 and thereby the "Golden Triangle"
of these three Articles could be seriously violated. The learned counsel also contended that exclusion
of minorities from the operation of Article 15(5) is also violative of Article 14 of the Constitution. We
do not find much force in this contention. It has been held that Article 15(4) and Article 16(4) are
not exceptions to Article 15(1) and Article 16(1) respectively. It may also be noted that if at all there
is any violation of Article 14 or any other equality principle, the affected educational institution
should have approached this Court to vindicate their rights. No such petition has been filed before
this Court. Therefore, we hold that the exclusion of minority educational institutions from Article
15(5) is not violative of Article 14 of the Constitution as the minority educational institutions, by
themselves, are a separate class and their rights are protected by other constitutional provisions.
4. Whether the Constitutional Amendment followed the procedure prescribed under Article 368 of
the Constitution?
103. Another contention raised by the petitioner's Counsel is that the Ninety-Third Constitutional
Amendment is invalid as it violates the proviso to Article 368 of the Constitution. According to the
petitioner's Counsel, the procedure prescribed under the proviso to Article 368 was not followed in
the case of the Ninety-Third Amendment. According to the petitioner's Counsel, Article 15(5) of the
Constitution interferes with the executive power of the States as it impliedly takes away the power of
the State Government under Article 162 of the Constitution.
104. This contention of the petitioner's Counsel has no force. The powers of the Parliament and the
State legislatures to legislate are provided for under Article 245-255 of the Constitution. Under the
proviso to Article 162, any matter with respect to which the legislature of the State and the
Parliament have power to make laws, the executive power of the State shall be subject to and limited
by the executive power expressly conferred by the Constitution or by any law made by Parliament
upon the Union authorities thereof. The Ninety-Third Constitutional Amendment does not expressly
or impliedly take away any such power conferred by Article 162. It may also be noticed that by virtue
of the 42nd Amendment to the Constitution, "education" which was previously in Entry No. 11 in
List II was deleted and inserted in List III as Entry No. 25 as the field of legislation in List III. Article
245 will operate and by reasons of proviso to Article 162, the executive power of the State be subject
to, limited by, the executive power expressly conferred by the Constitution or by any law made by
Parliament upon the Union authorities thereof. Subject to restrictions imposed under the
Constitution, it has been in existence. Such power of the State is not limited or curtailed by the
Ninety-Third Constitutional Amendment as it does not interfere with the power of the State under
Article 162.
The Ninety-Third Constitutional Amendment does not fall within the scope of proviso to Article
368. Therefore, the plea raised by the petitioner's Counsel that the Ninety-Third ConstitutionalAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Amendment did not follow the prescribed procedure of Article 368 is not correct and the plea is only
to be rejected.
5. Whether the Act 5 of 2007 is constitutionally invalid in view of definition of "Backward Class" and
whether the identification of such "Backward Class" based on "caste" is constitutionally valid?
105. The next important plea raised by the petitioner's Counsel is regarding the validity of the Act 5
of 2007. The several contentions have been raised regarding the validity of the Act 5 of 2007. The
first contention which was raised by the petitioner's Counsel that this Act is ex-facie
unconstitutional and is a suspect legislation and violative of the Article 14, 15 and 19(1)(g) of the
Constitution. The main attack against the Act was that the socially and educationally backward
classes of citizens were not properly identified and the delegation of power to identify the socially
and educationally backward classes of citizens to the Central Government itself is illegal and the
delegation of such powers by itself without laying down any guidelines is arbitrarily illegal.
Elaborate arguments were made by the petitioner's Counsel and the first and foremost contention
was that "caste" is the sole basis on which the socially and educationally backward classes of citizens
were determined. And this, according to the petitioner's Counsel, is illegal. Reference was made to a
series of decisions of this Court on this issue.
106. There is a long jurisprudential history as to whether caste can play any role in determining the
socially and educationally backward classes of citizens. In Indra Sawhney's case (supra), which is a
Nine Judge Bench decision, it was held that the "caste" could be a beginning point and a
determinative factor in identifying the socially and educationally backward classes of citizens. But
nevertheless, a brief survey of various decisions on this question would give a history of the
jurisprudential development on this subject.
107. Reference to the earlier decisions is necessary because serious doubt has been raised as to
whether "caste" could be the basis for recognizing backwardness. Some of the earlier decisions have
stated that caste should not be a basis for recognizing backwardness and gradually there was a shift
in the views and finally, in I ndra Sawhney' s case (supra), it was held that caste could be the starting
point for determining the socially and educationally backward classes of citizen..
108. In Champakam Dorairajan (supra), this Court struck down the classification made in the
Communal G.O. of the then State of Madras. The G.O. was founded on the basis of religion and
castes and was struck down on the ground that it is opposed to the Constitution and is in violation of
the fundamental rights guaranteed to the citizens. The court held that Article 46 cannot override the
provisions of Article 29 (2) because of the Directive Principles of State Policy which were then taken
subsidiary to fundamental rights.
This decision led to the first constitutional amendment by which Article 15(4) was added to the
Constitution.
109. The next important case is M.R. Balaji & Ors. Vs. State of Mysore (supra). In this case, the State
of Mysore issued an order that all the communities except the Brahmin community would fall withinAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

the definition of socially and educationally backward class and Scheduled Castes and Scheduled
Tribes and 75% of the seats in educational institutions were reserved for them. It was observed that
though caste in relation to Hindus may be a relevant factor to consider while determining social
backwardness of groups or classes of citizens, it cannot be made the sole or dominant test. It was
held that the classes of citizens who are deplorably poor automatically become socially backward.
Moreover, the occupation of citizens and the place of their habitation also result in social
backwardness. The problem of determining who are socially backward classes is undoubtedly very
complex, but the classification of socially backward citizens on the basis of their caste alone is not
permissible under Article 15 (4). Learned Senior Counsel Shri Harish Salve drew our attention to the
various passages in the judgment.
Gajendragadkar, J. speaking for the majority of the Judges, said :-
"The Problem of determining who are socially backward classes is undoubtedly very
complex. Sociological, social and economic considerations come into play in solving
the problem and evolving proper criteria for determining which classes are socially
backward is obviously a very difficult task; it will need an elaborate investigation and
collection of data and examining the said data in a rational and scientific way. That is
the function of the State which purports to act under Article 15 (4)."
110. The court drew a clear distinction between `caste' and `class' and tried to make an attempt to
find a new basis for ascertaining social and educational backwardness in place of caste and in this
decision a majority of Judges held that in a broad way, a special provision of reservation should be
less than 50%; how much less than 50% would depend upon the relevant and prevailing
circumstances in each case.
111. In R. Chitralekha's case (supra), the Government of Mysore, by an order defining backward
classes directed that 30% of the seats in professional and technical colleges and institutions shall be
reserved for them and 18% to the SCs and STs. It was laid down that classification of socially and
educationally backward classes should be made on the basis of economic condition and occupation.
Suba Rao, J. (as he then was), speaking for the majority, held that a classification of backward
classes based on economic conditions and occupations is not bad in law and does not offend Article
15 (4). The caste of a group of citizens may be a relevant circumstance in ascertaining their social
backwardness and though it is a relevant factor to determine social backwardness of a class, it
cannot be the sole or dominant test in that behalf. If, in a given situation, caste is excluded in
ascertaining a class within the meaning of Article 15 (4), it does not vitiate the classification if it
satisfies other tests. The Court observed that various provisions of the Constitution which
recognized the factual existence of backwardness in the country and which make a sincere attempt
to promote the welfare of the weaker sections thereof should be construed to effectuate that policy
and not to give weightage to progressive sections of the society under the false colour of caste to
which they happen to belong. The Court held that under no circumstance a `class' can be equated to
a `caste' though the caste of an individual or group of individuals may be a relevant factor in putting
him in a particular class.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

112. Minor P. Rajendran Vs. State of Madras & Ors.40 is another Constitution Bench decision
wherein the order of the State Government providing reservation of seats for various categories of
candidates namely Scheduled Tribes, Scheduled Castes and SEBCs was challenged on various
grounds. The main challenge was that the reservation was based entirely on consideration of caste
and therefore it violates Article 15. Justice Wanchoo, held that :-
"Now if the reservation in question had been based only on caste and had not taken
into account the social and educational backwardness of the castes in question, it
would be violative of Article 15 (1). But it must not be forgotten that a caste is also a
class of citizens and if the caste as a whole is socially and educationally backward
reservation can be made in favour of such a caste on the ground that it is a socially
and educationally backward class of citizens within the meaning of Article 15 (4).
Reference in this connection may be made to the observations of this Court in M.R.
40 (1968) 2 SCR 786 Balaji v. State of Mysore to the effect that it was not irrelevant to
consider the caste of a class of citizens in determining their social and educational
backwardness. It was further observed that though the caste of a class of citizens may
be relevant its importance should not be exaggerated; and if classification of
backward classes of citizens was based solely on the caste of the citizen, it might be
open to objection.
(emphasis supplied)
113. It may be noticed that the list prepared by the State showed certain castes, and members of
those castes according to the State were really classes of socially and educationally backward
citizens.
It was observed in that case that the petitioners therein did not make any attempt to show that any
caste mentioned in the list of educationally and socially backward classes of citizens was not
educationally and socially backward and the list based on caste was upheld by the Constitution
Bench and held to be not violative of Article 15(1).
114. In T riloki Nath Tiku Vs. State of J & K (I) 41 , 50% of the gazetted posts were to be filled up by
promotion in favour of the Muslims of Jammu & Kashmir. The Court held that inadequate
representation in State services would not be decisive for determining the backwardness of a
section. The Court accordingly 41 (1967) 2 SCR 265 gave directions for collecting further material
relevant to the subject.
And in a subsequent decision, Triloki Nath(II) (supra), the court observed that the expression
"backward class" is not used as synonymous with "backward caste".
115. In Minor A. Peerikaruppan Vs. State of Tamil Nadu & Ors.
(supra), this Court made reference to the earlier decisions especially in M.R. Balaji case (supra) and
R. Chitralekha case (supra). Hegde, J., at paragraph 29, observed :-Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"There is no gainsaying the fact that there are numerous castes in this country which
are socially and educationally backward. To ignore their existence is to ignore the
facts of life. Hence we are unable to uphold the contention that the impugned
reservation is not in accordance with Article 15 (4). But all the same the Government
should not proceed on the basis that once a class is considered as a backward class it
should continue to be backward class for all times. Such an approach would defeat
the very purpose of the reservation because once a class reaches a stage of progress
which some modern writers call as take off stage then competition is necessary for
their future progress. The Government should always keep under review the question
of reservation of seats and only the classes which are really socially and educationally
backward should be allowed to have the benefit of reservation."
116. The learned Counsel for the petitioners also made reference to State of Uttar Pradesh & Ors. Vs.
Pradip Tandon & Ors.42 wherein Chief Justice Ray observed at paragraph 14 :-
"Socially and educationally backward classes of citizens in Article 15 (4) could not be
equated with castes. In M.R. Balaji v. State of Mysore and State of A.P. v. Sagar this
Court held that classification of backwardness on the basis of castes would violate
both Articles 15 (1) and 15 (4)."
117. Another important decision is that of State of Kerala & Anr. Vs N.M. Thomas & Ors. (supra),
wherein the constitutional validity of Rule 13-AA of the Kerala State & Subordinate Services Rules
was under challenge. The Rule gave exemption of 2 years to members belonging to Scheduled Castes
and Scheduled Tribes in services, from passing the departmental test. The High Court of Kerala
struck down the Rule and in an appeal by the State the question of reservation was elaborately
considered. Mathew, J. in his concurring judgment, held that in order to give equality of opportunity
for employment to the members of Scheduled Castes and Scheduled Tribes, it is necessary to take
note of their social, educational and economic backwardness. Not only is the Directive Principle
embodied in Article 46 binding on the law-makers as ordinarily understood, but it should equally
inform and illuminate the approach of the court when it makes a decision, as the court is also 42
(1975) 1 SCC 267 a "State" within the meaning of Article 12 and makes law even though interstitially.
Existence of equality depends not merely on the absence of disabilities but on the presence of
disabilities. To achieve it, differential treatment of persons who are unequal is permissible. This is
what is styled as compensatory discrimination or affirmative action.
118. In K.C. Vasanth Kumar Vs. State of Karnataka (supra) the question of identifying socially and
educationally backward class came up for consideration. Desai, J., elaborately considered this
question in paragraph 20 and observed :-
"By its existence over thousands of years, more or less it was assumed that caste
should be the criterion for determining social and educational backwardness. In
other words, it was said, look at the caste, its traditional functions, its position in
relation to upper castes by the standard of purity and pollution, pure and not so pure
occupation, once these questions are satisfactorily answered without anything more,Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

those who belong to that caste must be labeled socially and educationally backward.
This over-simplified approach ignored a very realistic situation existing in each caste
that in every such caste whose members claim to be socially and educationally
backward, had an economically well-placed segments."
119. Chinnappa Reddy, J., also dealt with the question elaborately and observed :-
"However we look at the question of `backwardness', whether from the angle of class,
status or power, we find the economic factor at the bottom of it all and we find
poverty, the culprit-cause and the dominant characteristic. Poverty, the economic
factor brands all backwardness just as the erect posture brands the homosapiens and
distinguishes him from all other animals, in the eyes of the beholder from Mars. But,
whether his racial stock is Caucasian, Mongoloid, Negroid, etc., further investigation
will have to be made. So too the further question of social and educational
backwardness requires further scrutiny. In India, the matter is further aggravated,
complicated and pitilessly tyrannized by the ubiquitous caste system, a unique and
devastating system of gradation and degradation which has divided the entire Indian
and particularly Hindu society horizontally into such distinct layers as to be
destructive of mobility, a system which has penetrated and corrupted the mind and
soul of every Indian citizen. It is a notorious fact that there is an upper crust of rural
society consisting of the superior castes, generally the priestly, the landlord and the
merchant castes, there is a bottom strata consisting of the `out-castes' of Indian
Rural Society, namely the Scheduled Castes, and, in between the highest and the
lowest, there are large segments of population who because of the low gradation of
the caste to which they belong in the rural society hierarchy, because of the humble
occupation which they pursue, because of their poverty and ignorance are also
condemned to backwardness, social and educational, backwardness which prevents
them from competing on equal terms to catch up with the upper crust. "
120. Reference was also made to other decisions, namely, State of Andhra Pradesh & Anr. Vs. P.
Sagar43 and T. Devadasan Vs. The Union of India & Anr.44. The earlier decisions took the view that
caste shall not be a basis for determining the socially and 43 (1968) 3 SCR 595 44 (1964) 4 SCR 680
educationally backward class of citizens. But from the later decisions, we find a slight shift in the
approach of the court. If the classification of SEBCs is done exclusively on the basis of caste, it would
fly in the face of Article 15(1) of the Constitution as it expressly prohibits any discrimination on the
grounds of religion, race, caste, sex, place of birth or any of them. After a careful examination of the
various previous decisions of this Court, in Indra Sawhney (supra), while examining the validity of
the `Backward Class List' prepared by the Mandal Commisson, Jeevan Reddy. J., speaking for the
majority, held as under:-
"705. During the years 1968 to 1971, this Court had to consider the validity of
identification of backward classes made by Madras and Andhra Pradesh
Governments. P. Rajendran v. State of Madras 3 13 related to specification of socially
and educationally backward classes with reference to castes. The question wasAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

whether such an identification infringes Article 15. Wanchoo, CJ, speaking for the
Constitution Bench dealt with the contention in the following words:
(SCR p. 790-91) "The contention is that the list of socially and educationally
backward classes for whom reservation is made under Rule 5 is nothing but a list of
certain castes. Therefore, reservation in favour of certain castes based only on caste
considerations violates Article 15(1), which prohibits discrimination on the ground of
caste only. Now if the reservation in question had been based only on caste and had
not taken into account the social and educational backwardness of the caste in
question, it would be violative of Article 15(1). But it must not be forgotten that a
caste is also a class of citizens and if the caste as a whole is socially and educationally
backward reservation can be made in favour of such a caste on the ground that is a
socially and educationally backward class of citizens within the meaning of Article
15(4) .. .. It is true that in the present cases the list of socially and educationally
backward classes has been specified by caste. But that does not necessarily mean that
caste was the sole consideration and that persons belonging to these castes are also
not a class of socially and educationally backward citizens .. .. As it was found that
members of these castes as a whole were educationally and socially backward, the list
which had been coming on from as far back as 1906 was finally adopted for purposes
of Article 15(4) .. .. In view however of the explanation given by the State of Madras,
which has not been controverted by any rejoinder, it must be accepted that though
the list shows certain castes, the members of those castes are really classes of
educationally and socially backward citizens. No attempt was made on behalf of the
petitioners/appellant to show that any caste mentioned in this list was not
educationally and socially backward. In this state of the pleadings, we must come to
the conclusion that though the list is prepared caste-wise, the castes included therein
are as a whole educationally and socially backward and therefore the list is not
violative of Article 15. The challenge to Rule 5 must therefore fail."
121. In that decision it was further held that "Backward Class" in Article 16(4) cannot be read as
"Backward Caste". And under Article 340 of the Constitution, the President may by order appoint a
Commission consisting of such persons as he thinks fit to investigate the conditions of socially and
educationally backward classes of citizens within the territory of India and the difficulties under
which they labour and to make recommendations as to the steps that should be taken by the Union
or any State to remove the difficulties and to improve their condition. The object of this provision is
to empower the President to appoint a Commission to ascertain the difficulties and problems of
socially and educationally backward classes of citizens. And in Indra Sawhney's case (supra), the
majority held that the ideal and wise method would be to mark out various occupations which on
the lower level in many cases amongst Hindus would be their caste itself and find out their social
acceptability and educational standard, weigh them in the balance of economic conditions and, the
result would be backward class of citizens needing a genuine protective umbrella. And after having
adopted occupation as the starting point, the next point should be to ascertain their social
acceptability. A person carrying on scavenging becomes an untouchable whereas others who were as
law in the social strata as untouchables became depressed. The Court has cautioned that theAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

backwardness should be traditional. Mere educational or social backwardness would not have been
sufficient as it would enlarge the field thus frustrating the very purpose of the constitutional goal. It
was pointed out that after applying these tests, the economic criteria or the means-test should be
applied since poverty is the prime cause of all backwardness as it generates social and educational
backwardness.
122. The learned Counsel for the petitioner contended that caste cannot be used even as one of the
criteria for identifying the SEBCs as many persons have shifted their traditional occupations and
have become doctors, engineers and lawyers. But these are only a few cases and even such persons
continue to suffer social segregation based on caste. In P radip Tandon 's case (supra) it was held at
para 17 that:
"The expression `classes of citizens' indicates a homogenous section of the people
who are grouped together because of certain likenesses and common traits and who
are identifiable by some common attributes. The homogeneity of the class of citizens
is social and educational backwardness. Neither caste nor religion nor place of birth
will be the uniform element of common attributes to make them a class of citizens."
123. The above statement is not fully correct. Caste plays an important role in determining the
backwardness of the individual. In society, social status and standing depend upon the nature of the
occupation followed. In paragraph 779 of Indra Sawhney's case, it is stated:
"Lowlier the occupation, lowlier the social standing of the class in the graded
hierarchy. In rural India, occupation-caste nexus is true even today. A few members
may have gone to cities or even abroad but when they return - they do, barring a few
exceptions - they go into the same fold again. It does not matter if he has earned
money. He may not follow that particular occupation. Still, the label remains. His
identity is not changed for the purpose of marriage, death and all other social
functions, it is his social class - the caste - that is relevant."
124. "Caste" is often used interchangeably with "class" and can be called as the basic unit in social
stratification. The most characteristic thing about a caste group is its autonomy in caste related
matters. One of the universal codes enforced by all castes is the requirement of endogamy. Other
rules have to do with the regulations pertaining to religious purity or cleanliness. Sometimes it
restricts occupational choices as well. It is not necessary that these rules be enforced in particular
classes as well, and as such a "class"
may be distinguished from the broader realm of "caste" on these grounds. Castes were often rated,
on a purity scale, and not on a social scale.
125. The observations made by Venkataramaiah J. in K.C. Vasanth Kumar case are relevant in this
regard :Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"We are aware of the meanings of the words caste, race, or tribe or religious
minorities in India. A caste is an association of families which practise the custom of
endogamy i.e. which permits marriages amongst the members belonging to such
families only. Caste rules prohibit its members from marrying outside their caste.
There are sub-groups amongst the castes which sometimes inter-marry and
sometimes do not. A caste is based on various factors, sometimes it may be a class, a
race or a racial unit. A caste has nothing to do with wealth. The caste of a person is
governed by his birth in a family. Certain ideas of ceremonial purity are peculiar to
each caste. Sometimes caste practices even led to segregation of same castes in the
villages. Even the choice of occupation of members of castes was predetermined in
many cases, and the members of a particular caste were prohibited from engaging
themselves in other types of callings, professions or occupations. Certain occupations
were considered to be degrading or impure. A certain amount of rigidity developed in
several matters and many who belonged to castes which were lower in social order
were made to suffer many restrictions, privations and humiliations. Untouchability
was practised against members belonging to certain castes. Inter-dining was
prohibited in some cases. None of these rules governing a caste had anything to do
with either the individual merit of a person or his capacity. The wealth owned by him
would not save him from many social discriminations practised by members
belonging to higher castes. Children who grew in this caste ridden atmosphere
naturally suffered from many social disadvantages apart from the denial of
opportunity to live in the same kind of environment in which persons of higher castes
lived. Many social reformers have tried in the last two centuries to remove the stigma
of caste from which people born in lower castes were suffering. Many laws were also
passed prohibiting some of the inhuman caste practices." (p. 110)
126. Rivers, the leading anthropologist, criticizes the use of the terms "caste" and "class" as
synonyms45. However, many others, 45 W.H.R. Rivers, Social Organization (New York, 1924) p. 143
such as Lowie46 and Kimball Young47, use these terms as though they were identical.
127. Very common is the use of the word caste to indicate hereditary status. Cecil Clare North48, the
noted sociologist, accepts the point of view that degrees of rigidity mark the difference between class
and caste systems. His definition reads:
"A group in which status, occupation, and culture have become hereditary is known
as a caste. As a matter of fact, however, the distinction between a society based upon
caste and one in which open classes prevail is simply one of degree."
128. North concludes by saying that the term "caste" applies to classes that have become fixed, and
that all such classes tend to become castes.
129. MacIver49, another leading authority in the field of social class theory, also identifies caste with
hereditary status. He attempts to tie his interpretation with the situation in India, a procedure not
46 Robert H. Lowie, The Origin of the State (New York, 1927) p. 21; Lowie, An Introduction toAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Cultural Anthropology (New York, 1940) p. 268 47 Kimball Young, An Introductory Sociology (New
York, 1924) 48 Cecil Clare North, Social Differentiation (Chapel Hill, 1926) p. 254 49 R.N. MacIver,
Society: A textbook of Sociology (New York 1937) p. 171. 9 often followed by the other sociologists.
He writes thus, "Caste as unchangeable status: -- The feudal order approximated to a caste system.
When status is wholly predetermined, so that men are born to their lot in life without hope of
changing it, then class takes the extreme form of caste. This is the situation in Hindu society. `Every
Hindu necessarily belongs to the caste of his parents, and in that caste he inevitably remains. No
accumulation of wealth and no exercise of talents can alter his caste status; and marriage outside his
caste is prohibited or severely discouraged.' Caste is a complete barrier to the mobility of class."
130. Therefore, a class always enjoys certain privileges or at least certain advantages over others in
society. When it is more or less rigorously closed, or enjoys hereditary privileges, it is called a
"caste".
131. However, there are other sociologists who are of the opinion that the Caste system has a
hereditary function also.
Charles Horton Cooley50 opines that:
"if the transmission of function from father to son has become established, a caste
spirit, a sentiment in favour of such transmission and opposed to the passage from
one class to another, may arise and be shared even by the unprivileged classes. The
individual then thinks of himself and his family as identified with his caste..."
50 Charles Horton Cooley, Social Organization (New York, 1909) p. 215
132. Therefore, according to the early sociological theories, the term "caste" has been used to mean
"class", hereditary or rigid status, and hereditary occupation.
133. The M ysore C ensus of 1901 51 is quoted, in this connection, as follows:
"In any one of the linguistic divisions of India there are as many as two hundred
castes which can be grouped in classes whose gradation is largely acknowledged by
all. But the order of social precedence amongst the individual castes of any class
cannot be made definite, because not only is there no ungrudging acceptance of such
rank but also the ideas of the people on this point are very nebulous and uncertain.
The following observations vividly bring out this state of things."
...Excepting the Brahmin at one end and the admittedly degraded castes like the Holeyas at the
other, the members of a large proportion of the immediate castes think or profess to think that their
caste is better than their neighbours, and should be ranked accordingly."
134. On the other hand, it is possible that within a caste group there is a marked inequality of status,
opportunity, or social standingAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

- which then defines the "class" within that particular "caste" system.
For example, all the Brahmins are not engaged in highly respectable 51 G.S. Ghurye, Caste and Race
in India (Bombay, 1979) p. 6, Quoting from Mysore Census, 1901, p. 400 employment, nor are all
very wealthy. It may even be that some Brahmins may be servants of members of a lower caste, or it
may also be so that the personal servant of a rich Brahmin may be a poor Brahmin.
135. Hence, there is every reason to believe that within a single caste group there are some classes or
groups of people to whom good fortune or perseverance has brought more dignity, social influence
and social esteem than it has to others.
136. In India, caste, in a socio-organizational manner would mean that it is not characterized merely
by the physical or occupational characteristics of the individuals who make it up; rather, it is
characterized by its codes and its close-knit social controls. In the case of classes, however, there
may not exist such close-knit unit social controls, and there may exist great disparity in occupational
characteristics.
137. A social class is therefore a homogeneous unit, from the point of view of status and mutual
recognition; whereas a caste is a homogeneous unit from the point of view of common ancestry,
religious rites and strict organizational control. Thus the manner in which the caste is closed both in
the organizational and biological sense causes it to differ from social class. Moreover, its emphasis
upon ritual and regulations pertaining to cleanliness and purity differs radically from the secular
nature and informality of social class rules.
In a social class, the exclusiveness would be based primarily on status. Social classes divide
homogeneous populations into layers of prestige and esteem, and the members of each layer are
able to circulate freely with it.
138. In a caste, however, the social distance between members is due to the fact that they belong to
entirely different organizations. It may be said, therefore, that a caste is a horizontal division and a
class, a vertical division.
139. The Solicitor General, Mr. G.E. Vahanvati, pointed out that for the purpose of reservation under
Article 16(4) of the Constitution, the Central List has been in operation for the past 14 years and not
a single person has challenged any inclusion in the Central List as void or illegal.
140. It was pointed out that the National Commission for the Backward Classes and the State
Commission for Backward Classes have prepared a list based on elaborate guidelines and these
guidelines have been framed after studying the criteria/indicators framed by the Mandal
Commission and the Commissions set up in the past by different State Governments. Various
Commissions held public hearings at various places and the National Commission held 236 public
hearings before it finalized the list. It is also pointed out that during the period of its functioning, the
National Commission had recommended 297 requests for inclusion and at the same time rejected
288 requests for inclusion of the main castes. It is further pointed out that the Commission took intoAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

consideration detailed data with regard to social, educational and economic criteria. The
Commission has also looked into whether there has been any improvement or deterioration in the
condition of the caste or community being considered for inclusion during the past twenty years.
141. It is pointed out that an elaborate questionnaire was prepared by the Commission and the
answers in this questionnaire were considered in detail for inclusion/rejection in the list. It is clear
that the lists of socially and educationally backward classes of citizens are being prepared not solely
on the basis of the caste and if caste and other considerations are taken into account for determining
backwardness, it cannot be said that it would be violative of Article 15(1) of the Constitution.
142. We hold that the determination of SEBCs is done not solely based on caste and hence, the
identification of SEBCs is not violative of Article 15(1) of the Constitution.
6. Whether Creamy Layer is to be excluded from SEBCs?
143. The SEBCs have been identified by applying various criteria.
Though for the purpose of convenience, the list is based on caste, it cannot be said that `Backward
Class' has been identified solely on the basis of caste. All the castes which suffered the social and
educational backwardness have been included in the list. Therefore, it is not violative of Article
15(1). The only possible objection that could be agitated is that in many of the castes included in this
list, there may be an affluent section (Creamy Layer) which cannot be included in the list of SEBCs.
144. When socially and educationally backward classes are determined by giving importance to
caste, it shall not be forgotten that a segment of that caste is economically advanced and they do not
require the protection of reservation. It was argued on behalf of the petitioners that the principle of
`Creamy Layer' should be strictly applied to SEBCs while giving affirmative action and the
principles of exclusion of `Creamy Layer' applied in Indra Sawhney's case should be equally applied
to any of the legislations that may be passed as per Article 15(5) of the Constitution. The Counsel for
the petitioners submitted that SEBCs have been defined under section 2 (g) of the Act and the
Central Government has been delegated with the power to determine Other Backward Classes. The
Counsel for the petitioners have pointed out that the definition given in section 2(g) of the Act
should be judicially interpreted. That the backward class so stated therein should mean to exclude
the `Creamy Layer'. The learned Senior Counsel appearing for Pattali Makkal Katchi (PMK) stated
that exclusion of `Creamy Layer' shall not apply for reservation in educational institutions. He
pointed out that in case the `creamy layer' is excluded, the other members of the backward class
community would not be in a position to avail the benefit of reservation and the fee structure in
many of these centrally administered institutions is exorbitantly high and the ordinary citizen would
not be in a position to afford the payment of fees and thus the very purpose of the reservation would
be frustrated.
145. According to the learned Counsel for the respondents, the creamy layer elimination will only
perpetuate caste inequalities. It would enable the advanced castes to eliminate any challenge or
competition to their leadership in the professions and services and that they will gain by eliminatingAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

all possible beneficiaries of reservation in the name of creamy layer especially in the institutions of
higher learning. It was argued that the analogy of Creamy Layer applied in reservations to jobs
cannot be applied in reservations to educational institutions of higher learning. The position of a
student getting admission to an institution of higher learning is totally different and can never be
compared to that of backward class person to get a job by virtue of reservation. The study in any
educational institution of higher learning is very expensive and the non-creamy layer backward class
parent cannot afford his son or his daughter incurring such a huge expenditure. Eliminating them
from the Creamy Layer will frustrate the very object of providing reservation. Therefore, it is wholly
impracticable and highly counter productive to import the policy of Creamy Layer for reservation in
these institutions. And according to the learned Counsel there is a difference between services and
education and that under the purview of Act 5 of 2007, around 3 lakh seats would be filled up every
year. Whereas the jobs are limited and they will not become vacant every year.
146. The learned Counsel pointed out that grouping of all castes together may enable a less
backward caste among the backward classes to corner more seats than it deserves. It is also possible
that more backward classes cannot afford to compete with the less backward classes. The only way
to solve the said problem is by categorization of Backward Classes and sub classifying them so as to
ensure that under each category only similarly circumstanced castes are grouped together. The
categorization of backward class has successfully worked in State of Tamil Nadu where most
backward class is provided 20% reservation and the most backward castes and denotified tribes are
grouped together and the backward classes are provided 30% reservation. In the State of Karnataka,
backward classes are divided into 5 categories and separate reservations have been provided. And in
the State of Andhra Pradesh, Backward Classes have been divided into 4 divisions and separate
percentage of reservation has been provided.
147. As noticed earlier, determination of backward class cannot be exclusively based on caste.
Poverty, social backwardness, economic backwardness, all are criteria for determination of
backwardness. It has been noticed in Indra Sawhney's case that among the backward class, a section
of the backward class is a member of the affluent section of society. They do not deserve any sort of
reservation for further progress in life. They are socially and educationally advanced enough to
compete for the general seats along with other candidates.
148. In Indra Sawhney's case (supra) Jeevan Reddy, J., has observed :
"In our opinion, it is not a question of permissibility or desirability of such test but
one of proper and more appropriate identification of a class - a backward class. The
very concept of a class denotes a number of persons having certain common traits
which distinguish them from the others. In a backward class under clause (4) of
Article 16, if the connecting link is the social backwardness, it should broadly be the
same in a given class. If some of the members are far too advanced socially (which in
the context, necessarily means economically and, may also mean educationally) the
connecting thread between them and the remaining class snaps. They would be
misfits in the class. After excluding them alone, would the class be a compact class. In
fact, such exclusion benefits the truly backward."Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(p. 724)
149. It is to be understood that "creamy layer" principle is introduced merely to exclude a section of
a particular caste on the ground that they are economically advanced or educationally forward.
They are excluded because unless this segment of caste is excluded from that caste group, there
cannot be proper identification of the backward class. If the "Creamy Layer" principle is not applied,
it could easily be said that all the castes that have been included among the socially and
educationally backward classes have been included exclusively on the basis of caste. Identification of
SEBC for the purpose of either Article 15(4), 15(5) or 16(4) solely on the basis of caste is expressly
prohibited by various decisions of this Court and it is also against Article 15(1) and Article 16(1) of
the Constitution. To fulfil the conditions and to find out truly what is socially and educationally
backward class, the exclusion of "creamy layer" is essential.
150. It may be noted that the "creamy layer" principle is applied not as a general principle of
reservation. It is applied for the purpose of identifying the socially and educationally backward class.
One of the main criteria for determining the SEBC is poverty. If that be so, the principle of exclusion
of "creamy layer" is necessary. Moreover, the majority in Indra Sawhney's case upheld the exclusion
of "creamy layer" for the purpose of reservation in Article 16(4). Therefore, we are bound the larger
Bench decision of this Court in Indra Sawhney's case, and it cannot be said that the "creamy layer"
principle cannot be applied for identifying SEBCs. Moreover, Articles 15(4) and 15(5)
are designed to provide opportunities in education thereby raising educational, social
and economical levels of those who are lagging behind and once this progress is
achieved by this section, any legislation passed thereunder should be deemed to have
served its purpose. By excluding those who have already attained economic well
being or educational advancement, the special benefits provided under these clauses
cannot be further extended to them and, if done so, it would be unreasonable,
discriminatory or arbitrary, resulting in reverse discrimination.
151. Sawant, J. also made observation in Indra Sawhney's case to ensure removal of `creamy layer'.
He observed:-
"....at least some individuals and families in the backward classes ---- gaining
sufficient means to develop their capacities to compete with others in every field....
Legally, therefore, they are not entitled to be any longer called as part of the
backward classes whatever their original birth mark --- to continue to confer upon
such advanced sections from the backward classes the special benefits, would amount
to treating equals unequally violating the equality provisions of the Constitution.
Secondly, to rank them with the rest of the backward classes would equally violate the
right to equality of the rest in those classes, since it would amount to treating the
unequals equally.... It will lead to perverting the objectives of the special
constitutional provisions since the forwards among the backward classes will thereby
be enabled to tap up all the special benefits to the exclusion and to the cost of the restAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

in those classes, thus keeping the rest in perpetual backwardness."
152. All these reasonings are equally applicable to the reservation or any special action contemplated
under Article 15(5).
Therefore, we are unable to agree with the contention raised by the respondent's learned Counsel
that if `creamy layer' is excluded, there may be practically no representation for a particular
backward class in educational institutions because the remaining members, namely, the non-creamy
layer, may not have risen to the level or standard necessary to qualify to get admission even within
the reserved quota.
If the creamy layer is not excluded, the identification of SEBC will not be complete and any SEBC
without the exclusion of `creamy layer' may not be in accordance with Article 15(1) of the
Constitution.
7. What should be the para-meters for determining the "creamy layer" group ?
153. After the decision in Indra Sawhney's case (supra), the Government of India, Ministry of
Personnel, Public Grievances and Pensions (Department of Personnel and Training) issued an Office
Memorandum dated 08.09.1993 providing for 27% reservation for Other Backward Classes. The
Memorandum reads as follows :-
"OFFICE MEMORANDUM Subject : Reservation for Other Backward Classes in Civil
Posts and Services Under the Government of India ---regarding
-----------
The undersigned is directed to refer to this Department's OM No. 36012/31/90-Estt.
(SCT), dated the 13th August, 1990 and 25th September, 1991 regarding reservation
for Socially and Educationally Backward Classes in Civil Posts and Services under the
Government of India and to say that following the Supreme Court judgment in the
Indra Sawhney vs. Union of India (Writ Petition (Civil) No. 930 of 1990) the
Government of India appointed an Expert Committee to recommend the criteria for
exclusion of the socially advanced persons/sections from the benefits of reservations
for Other Backward Classes in Civil Posts and Services under the Government of
India.
2. Consequent to the consideration of the Expert Committee's recommendations this Department's
Office Memorandum No. 36012/31/90-Estt. (SCT), dated 13.8.1990 referred to in para (1) above is
hereby modified to provide as follows :
(a) 27% (twenty-seven per cent) of the vacancies in Civil Posts and Services under the
Government of India, to be filled through direct recruitment, shall be reserved for the
Other Backward Classes.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Detailed instructions relating to the procedure to be followed for enforcing reservation will be issued
separately.
(b) * * *
(c) (i) The aforesaid reservation shall not apply to persons/sections mentioned in Column 3 of the
Schedule to this office memorandum.
(ii) The rule of exclusion will not apply to persons working as artisans or engaged in hereditary
occupations, callings. A list of such occupations, callings will be issued separately by the Ministry of
Welfare.
(d)-(e)          *              *                 *
                 *              *                 *
3.                                       SCHEDULE
           Description of category                           To whom rule of exclusion
                                                  will apply
     I.    CONSTITUTIONAL                   Son(s) and daughter(s) of
           POSTS                            (a) President of India;
                                  (b) Vice-President of India;
                                  (c.)   Judges   of   the   Supreme   Court 
                                  and of the High Courts;
                                  (d)   Chairman   &   Members   of   UPSC 
                                  and   of   the   State   Public   Service 
                                  Commission;              Chief         Election 
                                  Commissioner;   Comptroller   and 
                                  Auditor General of India;
                                  (e)   persons   holding   constitutional Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

                                  positions of like nature.
II.    SERVICE                    Son(s) and daughter(s) of
       CATEGORY
A.     Group   A/Class   I  (a) parents, both of whom are Class 
       Officers   of   the   All  I Officers;
India Central and (b) parents, either of whom is a State Services (Direct Class I officer;
Recruits) (c.) parents, both of whom are Class I Officers, but one of them dies or suffers permanent
incapacitation;
(d) parents, either of whom is a Class I officer and such parent dies or suffers permanent
incapacitation and before such death or such incapacitation has had the benefit of employment in
any International Organisation like UN, IMF, World Bank, etc. for a period of not less than 5 years;
(e) parents, both of whom are Class I officers die or suffer permanent incapacitation and before such
death or such incapacitation of the both, either of them has had the benefit of employment in any
International Organisation like UN, IMF, World Bank, etc. for a period of not less than 5 years.
Provided that the rule of exclusion shall not apply in the following cases :
(a) Son(s) and daughter(s) of parents either of whom or both of whom are class I officers and such
parent(s) dies/die or suffer permanent incapacitation;
(b) A lady belonging to OBC category has got married to a Class I officer, and may herself like to
apply for a job.
B. Group B/Class II Son(s) and daughter(s) of officers of the Central (a) Parents both of whom are
Class and State Services II officers;
(Direct Recruitment) (b) parents of whom only the husband is a Class II officer and he get into Class
I at the age of 40 or earlier;
(c) parents, both of whom are Class II officers and one of them dies or suffers permanent
incapacitation and either one of them has had the benefit of employment in any International
Organisation like UN, IMF, World Bank etc. for a period of not less than 5 years before such death
or permanent incapacitation;Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(d) parents of whom the husband is a Class I officer (direct recruit or pre-forty promoted) and the
wife is a Class II officer and the wife dies; or suffers permanent incapacitation;
and
(e) parents, of whom the wife is a Class I officer (direct recruit or pre-
forty promoted) and the husband is a Class II officer and the husband dies or suffers permanent
incapacitation:
Provided that the rule of exclusion shall not apply in the following cases:
Son(s) and daughter(s) of
(a) parents both of whom are Class II officers and one of them dies or suffers permanent
incapacitation;
(b) parents, both of whom are Class II officers and both of them die or suffer permanent
incapacitation, even though either of them has had the benefit of employment in any International
Organisation like UN, IMF, World Bank etc. for a period of not less than 5 years before their death
or permanent incapacitation.
C. Employees in Public The criteria enumerated in A and B Sector Undertakings above in this
category will apply etc. mutatis mutandis to officers holding equivalent or comparable posts in
PSUs, Banks, Insurance Organisations, Universities, etc. and also to equivalent or comparable posts
and positions under private employment, pending the evaluation of the posts on equivalent or
comparable basis in these institutions, the criteria specified in Category VI below will apply to the
officers in these institutions.
III. ARMED FORCES Son(s) and daughter(s) of parents INCLUDING either or both of whom is or
are in PARAMILITARY the rank of Colonel and above in the FORCES (Persons Army and to
equivalent posts in the holding civil posts are Navy and the Air Force and the not included)
Paramilitary Forces:
Provided that:
                                             (i)         If   the   wife   of   an   Armed 
                                             Forces   officer   is   herself   in   the 
                                             Armed   Forces   (i.e.   the   category 
                                             under   consideration)   the   rule   of 
                                             exclusion   will   apply   only   when   she Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

                                             herself   has   reached   the   rank   of 
                                             Colonel;
                                             (ii)        The   service   ranks   below 
                                             Colonel   of   husband   and   wife   shall 
                                             not be clubbed together;
                                             (iii)       If   the   wife   of   an   officer   in 
                                             the   Armed   Forces   is   in   civil 
                                             employment,   this   will   not   be   taken 
                                             into account for applying the rule of 
                                             exclusion   unless   she   falls   in   the 
                                             service category under Item No. II in 
                                             which   case   the   criteria   and 
                                             conditions   enumerated   therein   will 
                                             apply to her independently.
IV.   PROFESSIONAL 
CLASS   AND   THOSE 
ENGAGED                              IN 
TRADE                               AND 
INDUSTRY
(i)   Persons   engaged 
in   profession   as   a 
doctor,                        lawyer,  Criteria   specified   against   Category 
chartered                                    VI will apply--
accountant,   Income 
Tax             consultant, 
financial                             or Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

management 
consultant,              dental 
surgeon,            engineer, 
architect,   computer 
specialist,   film   artists 
and         other             film 
professional,   author, 
playwright,              sports 
persons,                 sports 
professional,   media 
professional   or   any 
other vocations of like 
status.
(ii)   Persons   engaged 
in   trade,   business 
and industry.
                                       Criteria   specified   against   Category 
                                       VI will apply-
                                       Explanation:
                                       (i)          Where   the   husband   is   in 
                                       same profession and the wife is in a 
                                       Class II or lower grade employment, Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

                                       the   income/wealth   test   will   apply 
                                       only   on   the   basis   of   the   husband's 
                                       income;
                                       (ii)         If   the   wife   is   in   any 
                                       profession   and   the   husband   is   in 
                                       employment   in   a   Class   II   or   lower 
                                       rank   post,   then   the   income/wealth 
                                       criterion will apply only on the basis 
                                       of   the   wife's   income   and   the 
                                       husband's   income   will   not   be 
                                       clubbed with it. 
V.          PROPERTY 
OWNERS
A.          Agricultural  Son(s)   and   daughter(s)   of   persons 
holdings                  belonging to a family (father, mother 
                          and minor children) which owns only 
                          irrigated   land   which   is   equal   to   or 
                          more   than   85%   of   the   statutory 
                          area; or
                          (a)      both irrigated and unirrigated 
                          land, as follows :
                          (i)                 The rule of exclusion 
                          will   apply   where   the   precondition 
                          exists that the irrigated area (having 
                          been brought to a single type under Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

                          a   common   denominator)   40%   or 
                          more of the statutory ceiling limit for 
                          irrigated   land   (this   being   calculated 
                          by excluding the unirrigated portion). 
                          If   this   precondition   of   not   less   than 
                          40%   exists,   then   only   the   area   of 
                          unirrigated   land   will   be   taken   into 
                          account.     This   will   be   done   by 
                          converting   the   unirrigated   land   on 
                          the  basis  of  the  conversion  formula 
                          existing, into the irrigated type.  The 
                          irrigated   area   so   computed   from 
                          unirrigated   land   shall   be   added   to 
                          the actual area of irrigated land and 
                          if   after   such   clubbing   together   the 
                          total area in terms of irrigated land is 
                          80% or more of the statutory ceiling 
                          limit for irrigated land, then the rule 
                          of   exclusion   will   apply   and 
                          disentitlement will occur;
                          (ii)                The rule of exclusion 
                          will not apply if the land holding of a 
                          family is exclusively unirrigated.
                                       Criteria   of   income/wealth   specified 
                                       in Category VI below will applyAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

                                       Deemed as agricultural holding and 
                                       hence criteria at A above under this 
                                       category will apply.
                                       Criteria   specified   in   Category   VI 
                                       below will apply.
                                       Explanation:   Building   may   be   used 
                                       for         residential,         industrial         or 
                                       commercial   purpose   and   the   like 
                                       two or more such purposes.
B. Plantations
(i) Coffee, tea, rubber 
etc.
(ii)   Mango,   citrus, 
apple             plantations, 
etc.
C. Vacant land and/or 
buildings,   in   urban 
areas             or         urban 
agglomerations
VI.          INCOME                 /  Son(s) and daughter(s) ofAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

WEALTH TEST                            (a)            persons   having   gross 
                                       annual   income   of   Rs.   1   lakh   or 
                                   above   or   possessing   wealth   above 
                                   the exemption limit as prescribed in 
                                   the   Wealth   Tax   Act   for   a   period   of 
                                   three consecutive years;
                                   (b)          persons in Categories I, II, 
                                   III and V-A who are not disentitled to 
                                   the   benefit   of   reservation   but   have 
                                   income   from   other   sources   of 
                                   wealth   which   will   bring   them   within 
                                   the          income/wealth             criteria 
                                   mentioned in (a) above.
                                   Explanation. 
                                   (i)          Income   from   salaries   or 
                                   agricultural   land   shall   not   be 
                                   clubbed;
                                   (ii)         The   income   criteria   in 
                                   terms   of   rupee   will   be   modified 
                                   taking into account the change in its 
                                   value   every   three   years;     If   the 
                                   situation,   however,   so   demands, 
                                   the interregnum may be less.
Explanation: Wherever the expression `permanent incapacitation' occurs in this
Schedule, it shall mean incapacitation which results in putting an officer out ofAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

service."
154. We make it clear that same principle of determining the creamy layer for
providing 27% reservation for backward classes for appointment need not be strictly
followed in case of reservation envisaged under Article 15(5) of the Constitution. As
pointed by Shri Ravivarma Kumar, learned Senior Counsel, if a strict income
restriction is made for identifying the "creamy layer", those who are left in the
particular caste may not be able to have a sufficient number of candidates for getting
admission in the central institutions as per Act 5 of 2007. Government can make a
relaxation to some extent so that sufficient number of candidates may be available for
the purpose of filling up the 27% reservation. It is for the Union Government and the
State Governments to issue appropriate guidelines to identify the "creamy layer" so
that SEBC are properly determined in accordance with the guidelines given by this
Court. If, even by applying this principle, still the candidates are not available, the
State can issue appropriate guidelines to effectuate the implementation of the
reservation purposefully.
155. As noticed earlier, "backward class" defined in Section 2(g) does not exclude
"creamy layer". Therefore, we make it clear that backward class as defined in Section
2(g) of Act 5 of 2007 must be deemed to have been such backward class by applying
the principle of exclusion of "creamy layer".
8. Whether the "creamy layer" principle is applicable to Scheduled Tribes and
Scheduled Castes ?
156. Learned Senior Counsel Dr. Rajeev Dhavan submitted that "creamy layer"
principle is to be applied to SCs and STs. He drew inspiration from the observations
made by Justice Krishna Iyer in N.M. Thomas's case (supra) and also from the
observations made in Nagaraj's case and reference was made to paragraphs 80, 110
and 120 to 123 of N agaraj 's case (supra).
157. N .M. T homas `s case (supra) does not state that "creamy layer"
principle should apply to SCs and STs. In K.C. Vasanth Kumar's case (supra) the
"creamy layer" was used in the case of backward caste or class. In K.C. Vasanth
Kumar52 (supra), Desai J. quoted from N.M. Thomas (supra) as follows :-
"In the light of experience, here and elsewhere, the danger of `reservation', it seems
to me, is threefold. Its benefits, by and large, are snatched away by the top creamy
layer of the `backward' caste or class, thus keeping the weakest among the weak
always weak and leave the fortunate layers to consume the whole cake."
(N.M. Thomas (supra) p. 363, para 124) 52 (supra) p. 733Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

158. In Nagaraj's case (supra) in paragraph 80, it is stated that while "applying the `creamy layer'
test, this Court held that if roster-point promotees are given consequential seniority, it will violate
the equality principle which is part of the basic structure of the Constitution and in which even
Article 16(4-A) cannot be of any help to the reserved category candidates." This was with reference
to the observations made in Indra Sawhney's case (supra) and earlier in M.G. Badappanavar & Anr.
Vs. State of Karnataka & Ors.53; Ajit Singh & Ors. (II) vs. State of Punjab & Ors.54 and Union of
India & Ors. Vs. Virpal Singh Chauhan & Ors.55. Virpal Singh Chauhan's case (supra) dealt with
reservation of railway employees wherein it is held that once the number of posts reserved for being
filled by reserved category candidates in a cadre, category or grade (unit for application of rule of
reservation) are filled by the operation of roster, the object of the rule of reservation should be
deemed to have been achieved. Ajit Singh II's case (supra) dealt with consequential seniority on
promotion and held that roster points fixed at Level 1 are not intended to determine any seniority at
Level 1 between general candidates and the reserved candidates and the roster point merely 53
(2001) 2 SCC 666 54 (1999) 7 SCC 209 55 (1995) 6 SCC 684 becomes operative whenever a vacancy
reserved at Level 2 becomes available. Thereby holding that if promotion is obtained by way of
reservation, the consequential seniority will not be counted.
M.G. Badappanavar's case (supra) followed the cases of Ajit Singh II (supra) and Virpal Singh
(supra).
159. In none of these decisions it is stated that the "creamy layer"
principle would apply to SCs and STs. In Indra Sawhney's case (supra), it is
specifically stated that the "creamy layer" principle will not apply to STs and SCs. In
Nagaraj's case (supra) , in paragraphs 110 and 120 and finally in paragraphs 121, 122
and 123, it is only stated that when considering questions of affirmative action, the
larger principle of equality such as 50% ceiling (quantitative limitation) and "creamy
layer" (quantitative exclusion) may be kept in mind. In Nagaraj's case (supra) it has
not been discussed or decided that the creamy layer principle would be applicable to
SCs/STs. Therefore, it cannot be said that the observations made in Nagaraj's case
are contrary to the decision in Indra Sawhney's case (supra).
160. Moreover, the "creamy layer" principle is not yet applied as a principle of equality or as a
general principle to apply for all affirmative actions. The observations made by Chinnappa Reddy, J.
in K.C. Vasanth Kumar case are relevant in this regard. The learned Judge observed as under :
"One cannot quarrel with the statement that social science research and not judicial
impressionism should form the basis of examination, by courts, of the sensitive
question of reservation for backward classes. Earlier we mentioned how the
assumption that efficiency will be impaired if reservation exceeds 50%, if reservation
is extended to promotional posts or if the carry forward rule is adopted, is not based
on any scientific data. One must, however, enter a caveat to the criticism that the
benefits of reservation are often snatched away by the top creamy layer of backwardAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

class or caste. That a few of the seats and posts reserved for backward classes are
snatched away by the more fortunate among them is not to say that reservation is not
necessary. This is bound to happen in a competitive society such as ours. Are not the
unreserved seats and posts snatched away, in the same way, by the top creamy layer
of society itself? Seats reserved for the backward classes are taken away by the top
layers amongst them on the same principle of merit on which the unreserved seats
are taken away by the top layers of society." (p. 763)
161. So far, this Court has not applied the "creamy layer" principle to the general principle of
equality for the purpose of reservation. The "creamy layer" so far has been applied only to identify
the backward class, as it required certain parameters to determine the backward classes. "Creamy
layer" principle is one of the parameters to identify backward classes. Therefore, principally, the
"creamy layer" principle cannot be applied to STs and SCs, as SCs and STs are separate classes by
themselves. Ray, CJ., in an earlier decisions, stated that "Scheduled Castes and Scheduled Tribes are
not a caste within the ordinary meaning of caste". And they are so identified by virtue of the
Notification issued by the President of India under Articles 341 and 342 of the Constitution. The
President may, after consultation with the Governor, by public notification, specify the castes, races
or tribes or parts of or groups within castes, races or tribes which for the purpose of the Constitution
shall be deemed to be Scheduled Castes of Scheduled Tribes. Once the Notification is issued, they
are deemed to be the members of Scheduled Castes or Scheduled Tribes, whichever is applicable. In
E.V. Chinnaiah (supra), concurring with the majority judgment, S.B. Sinha, J. said :-
"The Scheduled Castes and Scheduled Tribes occupy a special place in our
Constitution. The President of India is the sole repository of the power to specify the
castes, races or tribes or parts of or groups within castes, races or tribes which shall
for the purposes of the Constitution be deemed to be Scheduled Castes. The
Constitution (Scheduled Castes) Order, 1950 made in terms of Article 341(1) is
exhaustive. The object of Articles 341 and 342 is to provide for grant of protection to
the backward class of citizens who are specified in the Scheduled Castes Order and
Scheduled Tribes Order having regard to the economic and education backwardness
wherefrom they suffer. Any legislation which would bring them out of the purview
thereof or tinker with the order issued by the President of India would be
unconstitutional. (Paras 52, 111 and 84) (emphasis supplied)
162. A plea was raised by the respondent-State that categorization of Scheduled
Castes could be justified by applying the "creamy layer"
test as used in Indra Sawhney's case (supra) which was specifically rejected in paragraph 96 of the
E.V. Chinnaiah's case (supra). It is observed :-
But we must state that whenever such a situation arises in respect of Scheduled
Caste, it will be Parliament alone to take the necessary legislative steps in terms of
clause (2) of Article 341 of the Constitution. The States concededly do not have the
legislative competence therefor." (p. 430)Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

163. Moreover, right from the beginning, the Scheduled Castes and Scheduled Tribes
were treated as a separate category and nobody ever disputed identification of such
classes. So long as "creamy layer" is not applied as one of the principles of equality, it
cannot be applied to Scheduled Castes and Scheduled Tribes. So far, it is applied only
to identify the socially and educationally backward classes. We make it clear that for
the purpose of reservation, the principles of "creamy layer" are not applicable for
Scheduled Castes and Scheduled Tribes.
9. Whether the principles laid down by the United States Supreme Court for
affirmative action such as "suspect legislation", "strict scrutiny" and "compelling
State necessity"
are applicable to principles of reservation or other affirmative action contemplated
under Article 15(5) of the Constitution of India ?
164. Based on the Ninety-Third Constitutional Amendment Act, Act 5 of 2007 has
been enacted. According to the petitioner's Counsel, this is a "suspect legislation" and
therefore, it is to be subjected to "strict scrutiny" as laid by the United States
Supreme Court and only by passing this test of "strict scrutiny", such legislation could
be put into practice.
165. At the outset, it must be stated that the decisions of the United States Supreme
Court were not applied in the Indian context as it was felt that the structure of the
provisions under the two Constitutions and the social conditions as well as other
factors are widely different in both the countries. Reference may be made to Bhikaji
Narain Dhakras & Ors. Vs. The State of Madhya Pradesh & Anr.56 and A.S. Krishna
Vs. State of Madras57 wherein this Court specifically held that the due process clause
in the Constitution of the United States of America is not applicable to India. While
considering the scope and applicability of Article 19(1)(g) in Kameshwar Prasad and
Others Vs. State of Bihar and Another58, it was observed "-
"As regards these decisions of the American Courts, it should be borne in mind that
though the First Amendment to the Constitution of the United States reading
"Congress shall make no law ....abridging the freedom of speech...." appears to confer
no power on the Congress to impose any restriction on the exercise of the guaranteed
right, still it has always been understood that the freedom guaranteed is subject to
the police power - the scope of which however has not been defined with precision or
uniformly. " (p. 378)
166. In K esavananda B harati 59 case also, while considering the 56 [1955] 2 SCR
589 57 [1957] SCR 399 58 1962 Supp. (3) SCR 369 59 (1973) 4 SCC 225 extent and
scope of the power of amendment under Article 368 of the Constitution of India, the
Constitution of the United States of America was extensively referred to and Ray, J.,
held :- "The American decisions which have been copiously cited before us, wereAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

rendered in the context of the history of the struggle against colonialism of the
American people, sovereignty of several States which came together to form a
Confederation, the strains and pressures which induced them to frame a Constitution
for a Federal Government and the underlying concepts of law and judicial approach
over a period of nearly 200 years, cannot be used to persuade this Court to apply
their approach in determining the cases arising under our Constitution". (p. 615)
167. It may also be noticed that there are structural differences in the Constitution of
India and the Constitution of the United States of America. Reference may be made
to the 14th Amendment to the U.S. Constitution. Some of the relevant portions
thereof are as follows: "All persons born or naturalized in the United States, and
subject to the jurisdiction thereof, are citizens of the United States and of the State
wherein they reside. No State shall make or enforce any law which shall abridge the
privileges and immunities of citizens of the United States; nor shall any State deprive
any person of life, liberty or property without due process of law nor deny to any
person within its jurisdiction the equal protection of the laws."
168. Whereas in India, Articles 14 and 18 are differently structured and contain express provisions
for special provision for the advancement of SEBCs, STs and SCs. Moreover, in our Constitution
there is a specific provision under the Directive Principles of State Policy in Part IV of the
Constitution requiring the State to strive for justice - social, economic and political - and to
minimize the inequalities of income and endeavour to eliminate inequalities in status, facilities and
opportunities (Article 38). Earlier, there was a view that Articles 16(4) and 15(5) are exceptions to
Article 16(1) and 15(1) respectively. This view was held in The General Manager Southern Railways
Vs. Rangachari60 and M.R. Balaji Vs. State of Mysore61.
169. In T. Devadasan62 (supra), Subba Rao J., gave a dissenting opinion wherein he held that
Article 16(4) was not an exception to Article 16(1). He observed:-
60 (supra) at p. 607 61 (supra) at 455 62 (supra) at 700 "...The expression `nothing
in this article' is a legislative device to express its intention in a most emphatic way
that the power conferred thereunder is not limited in any way by the main provision
but falls outside it. It has not really carved out an exception, but has preserved a
power untrammeled by the other provisions of the Article."
170. In two other subsequent decisions, i.e. in Triloki Nath (I)63 (supra) and T. Devadasan case
(supra), it was held that article 15(4) and 16(4) are exceptions to Article 15(1) and 16(1) respectively.
But a 7-Judge Bench in State of Kerala Vs. N.M. Thomas (supra) held that Article 15(4) and 16(4)
are not exceptions to Article 15(1) and 16(1) respectively. Fazal Ali J., said :
"This form of classification which is referred to as reservation, is in my opinion,
clearly covered by Article 16(4) of the Constitution which is completely exhaustive on
this point. That is to say clause (4) of Article 16 is not an exception to Article 14 in the
sense that whatever classification can be made, can be done only through clause (4)Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

of Article 16. Clause (4) of Article 16, however, is an explanation containing an
exhaustive and exclusive provision regarding reservation which is one of the forms of
classification."
171. This brought out a drastic change in the view of this Court. In K.C. Vasanth Kumar Vs. State of
Karnataka64 (supra), 63 (supra) at 104 64 (supra) at 800 Venkatramaiah J. observed:
"Article 14 of the Constitution consists of two parts. It asks the State not to deny to
any person equality before law. It also asks the State not to deny the equal protection
of the laws. Equality before law connotes absence of any discrimination in law. The
concept of equal protection required the State to mete out differential treatment to
persons in different situations in order to establish an equilibrium amongst all. This
is the basis of the rule that equals should be treated equally and unequals must be
treated unequally if the doctrine of equality which is one of the corner-stone of our
Constitution is to be duly implemented. In order to do justice amongst unequals, the
State has to resort to compensatory or protective discrimination. Article 15(4) and
Article 16(4) of the Constitution were enacted as measures of compensatory or
protective discrimination to grant relief to persons belonging to socially oppressed
castes and minorities."
172. The amendment to Article 15 by inserting Article 15(5) and the new Act (Act 5 of 2007) are to be
viewed in the background of these constitutional provisions. It may also be recalled that the
Preamble to the Constitution and the Directive Principles of State Policy give a positive mandate to
the State and the State is obliged to remove inequalities and backwardness from society. While
considering the constitutionality of a social justice legislation, it is worthwhile to note the objectives
which have been incorporated by the Constitution makers in the Preamble of the Constitution and
how they are sought to be secured by enacting fundamental rights in Part III and Directives
Principles of State Policy in Part IV of the Constitution. The Fundamental Rights represent the civil
and political rights and the Directive Principles embody social and economic rights. Together they
are intended to carry out the objectives set out in the Preamble of the Constitution. Granville Austin,
in his book65, states :
"Both types of rights have developed as a common demand, products of the national
and social revolutions, of their almost inseparable intertwining, and of the character
of Indian politics itself."
173. From the constitutional history of India, it can be seen that from the point of view of
importance and significance, no distinction can be made between the two sets of rights, namely,
Fundamental Rights which are made justiciable and the Directives Principles which are made
non-justiciable. The Directive Principles of State Policy are made non-justiciable for the reason that
the implementation of many of these rights would depend on the financial capability of the State.
Non-justiciable clause was provided for the reason that an infant 65 Granville Austin : The Indian
Constitution : Corner-stone of a Nation, p. 52 State shall not be made accountable immediately forAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

not fulfilling these obligations. Merely because the Directive Principles are non-
justiciable by the judicial process does not mean that they are of subordinate importance. In
Champakam Dorairajan's case (supra), it was observed that "the Directive Principles have to
conform to and run subsidiary to the Chapter of Fundamental Rights." But this view did not hold for
a long time and was later changed in a series of subsequent decisions. (See : In Re. Kerala Education
Bill, 195766;
Minerava Mills (supra))
174. In Minerva Mills67 (supra) Bhagwati, J observed :
"The Fundamental Rights are no doubt important and valuable in a democracy, but
there can be no real democracy without social and economic justice to the common
man and to create socio-economic conditions in which there can be social and
economic justice to every one, is the theme of the Directive Principles. It is the
Directive Principles which nourish the roots of our democracy, provide strength and
vigour to it and attempt to make it a real participatory democracy which does not
remain merely a political democracy with Fundamental Rights available to all
irrespective of their power, position or wealth. The dynamic provisions of the
Directive Principles fertilise the static provisions of the Fundamental Rights. The
object of the Fundamental Rights is to protect individual liberty, but can individual
liberty be considered in isolation from the socio-economic structure in which it is to
operate. There is a real connection between 66 1959 SCR 995 67 AIR 1980 SC 1789,
at p. 1847 individual liberty and the shape and form of the social and economic
structure of the society. Can there be any individual liberty at all for the large masses
of people who are suffering from want and privation and who are cheated out of their
individual rights by the exploitative economic system? Would their individual liberty
not come in conflict with the liberty of the socially and economically more powerful
class and in the process, get mutilated or destroyed? It is exiomatic that the real
controversies in the present day society are not between power and freedom but
between one form of liberty and another. Under the present socio-economic system,
it is the liberty of the few which is in conflict with the liberty of the many. The
Directive Principles therefore, impose an obligation on the State to take positive
action for creating socio-economic conditions in which there will be an egalitarian
social order with social and economic justice to all, so that individual liberty will
become a cherished value and the dignity of the individual a living reality, not only
for a few privileged persons but for the entire people of the country. It will thus be
seen that the Directive Principles enjoy a very high place in the constitutional scheme
and it is only in the framework of the socio- economic structure envisaged in the
Directive Principles that the Fundamental Rights are intended to operate, for it is
only then they can become meaningful and significant for the millions of our poor
and deprived people who do not have been the bare necessities of life and who are
living below the poverty level."Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

175. Article 46 enjoins upon the State to promote with special care the educational and economic
interests of the weaker sections of the people and to protect them from social injustice and all forms
of exploitation whereas under the Constitution of the United States of America, we get an entirely
different picture. Though equality was one of the solemn affirmations of the American Declaration
of Independence, slavery continued unabatedly and it was, to some extent, legally recognized. In
Dred Scott Vs. Saunders68 wherein Chief Justice Taney held that [African-Americans] were not
entitled to get citizenship. He was of the view that `once a slave always a slave', and one slave never
would become the citizen of America.
This view held by the Chief Justice Taney continued for a long time and after the Civil War, the 14th
amendment was enacted in 1868 and this amendment gave (equal protection of laws to all persons).
In Plassy Vs. Ferguson69 which involved a challenge to a Louisiana statute that provided for equal
but separate accommodations for black and white passengers in trains, the United States Supreme
Court was of the view that racial segregation was a reasonable exercise of State police power for the
promotion of the public good and upheld the law. Several affirmative actions were challenged and
the landmark decision of Brown Vs. Board of Education70 was delivered in 1954. In many cases, the
strict scrutiny doctrine was being applied to all laws of racial classifications. The learned Counsel for
the petitioner made reference to Gratz Vs. Bollinger (supra) and some of the earlier decisions of the
United States 68 60 US 393(1856) 69 163 US 537(1896) 70 347 US 483 Supreme Court. During the
past two decades, the Court has become sceptical of race-based affirmative action practiced or
ordered by the State. The Supreme Court of the US is of the view that affirmative action plans must
rest upon a sufficient showing or predicate of past discrimination which must go beyond the effects
of societal discrimination.
176. The 14th Amendment to the Constitution of the United States of America and Title VI of the
1964 Civil Rights Act, prohibit universities to discriminate on the basis of classifications such as
race, colour, national origin and the like in all their operations. In a number of decisions of the
United States Supreme Court spanning decades of jurisprudence, a heavy burden has been placed
on institutions whose affirmative action programmes are challenged before the United States
Supreme Court on grounds that have been recognized as suspect or unconstitutional. According to
the United States Supreme Court, all such programmes are inherently suspect since they rely on
suspect forms of classification (such as race). Therefore, because such forms of classification are
inherently suspect, the courts have subjected all affirmative action programmes relying on them to a
very high standard of scrutiny, wherein those practicing these affirmative action programmes have
to adhere to a very high standard of proof, which we know as the "strict scrutiny" test.
177. The case of Regents of the University of California Vs. Bakke71 provided a starting point and
from this case onwards, affirmative action programmes can be justified only on two distinct
grounds, and only these grounds have been recognized as compelling enough to so as to satisfy the
"strict scrutiny" test, as developed by the United States Supreme Court. The two grounds are as
follows:
1. Remedial Justification: All efforts aimed at remedying past injustices against
certain identified groups of people, who were unlawfully discriminated against in theAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

past, serve as adequate justifications and all affirmative action programmes that are
implemented with this aim serve the compelling institutional interest in removing all
vestiges of discrimination that occurred in the past.
In the case of City of Richmond Vs. J A Croson Co.72, the United 71 438 US 265 (1978) 72 488 U.S.
469 (1989) States Supreme Court held that if a university is able to show "some showing of prior
discrimination" in its existing affirmative action program furthering racial exclusion then the
university may take "affirmative steps to dismantle such a system". However, it is to be noted that
the US Supreme Court also attached a warning with the above observation.
While scrutinizing such programmes, it was held that the Court would make "searching judicial
inquiry into the justification for such race-based measures... [and to] identify that discrimination...
with some specificity before they may use race-conscious relief". (Croson's Case73)
2. Diversity- All affirmative action programmes aimed at bringing about racial diversity among the
scholarship of the institution(s) may be said to in furtherance of compelling institutional interest.
The starting point for this ground is Justice Powell's detailed opinion regarding the issue of diversity
in the case of Regents of the University of California Vs. Bakke74 (supra). In this case, according to
Justice Powell, "[t]he attainment of a diverse student body is clearly a constitutionally permissible
goal for an institution of higher education". He quoted from two of the Supreme Court's decisions
regarding academic freedom 73 (supra), p. 492-93 74 (supra) at 311-313 [Sweezy Vs. New
Hampshire75 and Keyishian Vs. Board of Regents76] and observed:
"[I]t is the business of a university to provide that atmosphere which is most
conducive to speculation, experiment and creation.........The atmosphere of
speculation, experiment and creation -- so essential to the quality of higher education
-- is widely believed to be promoted by a diverse student body. ... [I]t is not too much
to say that the nation's future depends upon leaders trained through wide exposure to
the ideas and mores of students as diverse as this Nation of many peoples."
178. The other part of the "strict scrutiny" test is the "narrow tailoring"
test. The University, whose affirmative action programme is in question before the
United States Supreme Court, is required to prove that its affirmative action
programme has been designed in the narrowest possible manner, in order to benefit
only those specific people who are to be benefited, thus serving the "compelling
purposes" of the affirmative action programme. The program cannot be made in a
broad manner to encompass a large group of people, and it has to serve the minimum
possible requirement, in order to achieve its goal. Otherwise, it may be possible that
the rights of other people may be infringed upon, which would make the affirmative
action programme unconstitutional. 75 (1957) 354 US 234 at 263 76 (1967) 385 US
589 at 603Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

179. Thus, the first limb of the strict scrutiny test that elucidates the "compelling institutional
interest" is focused on the objectives that affirmative action programmes are designed to achieve.
The second limb, that of "narrow tailoring", focuses on the details of specific affirmative action
programmes and on the specific people it aims to benefit.
180. The United States Supreme Court has held that race may be one of the many factors that can be
taken into account while structuring an affirmative action programme. At this stage, an analogy may
be drawn with the Indian situation wherein the Supreme Court of India, in various cases, has held
that caste may be one of the factors that can be taken into account, while providing for reservations
for the socially and educationally backward classes. However, caste cannot be the "only"
factor, just as race alone cannot be the only factor in the United States, while structuring reservation
or affirmative action programmes.
181. Furthermore, the courts, both in India as well as in the United States of America, have looked
with extreme caution and care at any legislation that aims to discriminate on the basis of race in the
US and caste in India. As the US Supreme Court elucidated in the case of Grutter Vs. Bollinger
(supra), "Because the Fourteenth Amendment "protect[s] persons, not groups," all governmental
action based on race ought to be subjected to a very detailed and careful judicial inquiry and
scrutiny so as to ensure that the personal right to equal protection of the laws has not been
infringed. (See : Adarand Constructors Inc. Vs. Peqa)77.
182. It therefore follows that the government may treat people differently because of their race but
only for those reasons that serve what is known as "compelling government interest".
183. Furthermore, for any affirmative action programme to survive the strict standard of judicial
scrutiny, the Courts want "compelling evidence", that proves without any doubt that the affirmative
action program is narrowly tailored and serves only the most compelling of interests. Thus, the bar
for the State or institution that practices affirmative action programmes based of suspect
classifications has been effectively raised. Therefore, in cases where a compelling interest is found,
race-based methods may be used only after all other methods 77 (1995) 515 US 200 at 227 have been
considered and found deficient, and that too only to that limited extent which is required to remedy
a discrimination that has been identified, and only when it has been shown that the identified
beneficiaries have suffered previously in the past, and lastly, only if all undue burdens that may
impinge upon the rights of other non-
beneficiaries are avoided.
184. The aforesaid principles applied by the Supreme Court of the United States of America cannot
be applied directly to India as the gamut of affirmative action in India is fully supported by
constitutional provisions and we have not applied the principles of "suspect legislation" and we have
been following the doctrine that every legislation passed by the Parliament is presumed to be
constitutionally valid unless otherwise proved. We have repeatedly held that the American decisions
are not strictly applicable to us and the very same principles of strict scrutiny and suspect legislationAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

were sought to be applied and this Court rejected the same in Saurabh Chaudhari Vs. Union of
India78. Speaking for the bench, V.N. Khare, CJI, said:
78 2003 (11) SCC 146 "The strict scrutiny test or the intermediate scrutiny test
applicable in the United States of America as argued by Shri Salve cannot be applied
in this case. Such a test is not applied in Indian Courts. In any event, such a test may
be applied in a case where a legislation ex facie is found to be unreasonable. Such a
test may also be applied in a case where by reason of a statute the life and liberty of a
citizen is put in jeopardy. This Court since its inception apart from a few cases where
the legislation was found to be ex facie wholly unreasonable proceeded on the
doctrine that constitutionality of a statute is to be presumed and the burden to prove
contra is on him who asserts the same."
185. Learned Counsel Shri Sushil Kumar Jain contended that the classification of OBCs was not
properly done and it is not clear as to whose benefit the legislation itself is made therefore, it is a
suspect legislation. This contention cannot be accepted. We are of the view that the challenge of Act
5 of 2007 on the ground that it does not stand the "strict scrutiny" test and there was no
"compellable State necessity" to enact this legislation cannot be accepted.
10. Whether delegation of power to the Union Government to determine as to who shall be the
backward class is constitutionally valid?
186. The learned Counsel for the petitioners contended that though "Backward Class" is defined
under Section 2(g) of Act 5 of 2007, it is not stated in the Act how the "Backward Class" would be
identified and the delegation of such power to the Union of India to determine as to who shall be the
"backward class" without their being proper guidelines is illegal as it amounts to excessive
delegation.
According to the learned Counsel for the petitioners, the Parliament itself should have laid down the
guidelines and decided that who shall be included in the backward class as defined under Section
2(g) of the Act 5 of 2007. "Backward class" is not a new word. Going by the Constitution, there are
sufficient constitutional provisions to have an idea as to what "backward class" is. Article 340 of the
Constitution specifically empowers the President of India to appoint a Commission to investigate
the conditions of the socially and educationally backward classes within the territory of India.
Socially and educationally backward classes of citizens are mentioned in Article 15(4) of the
Constitution, which formed the First Amendment to the Constitution. Backward class citizens are
also mentioned in Article 16(4) of the Constitution. It is only for the purpose of Act 5 of 2007 that
the Union of India has been entrusted with the task of determining the backward class. There is
already a National Commission and also various State Commissions dealing with the affairs of the
backward class of citizens in this country. For the purpose of enforcement of the legislation passed
under Article 16(4), the backward class of citizens have already been identified and has been in
practice since the past 14 years. It is in this background that the Union of India has been given the
task of determining the backward classes. The determination of backward classes itself is a laborious
task and the Parliament cannot do it by itself. It is incorrect to say that there are no sufficientAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

guidelines to determine the backward classes. Various parameters have been used and it may also be
noticed that if any undeserving caste or group of persons are included in the backward class, it is
open to any person to challenge the same through judicial review. Therefore, it is incorrect to say
that the Union of India has been given wide powers to determine the backward classes. The
challenge of Act 5 of 2007 on that ground fails.
11. Whether the Act is invalid as there is no time limit prescribed for its operation and no periodical
review is contemplated?
187. The learned Counsel for the petitioners contended that the reservation of 27% provided for the
backward classes in the educational institutions contemplated under the Act does not prescribe any
time limit and this is opposed to the principle of equality. According to learned Counsel for the
petitioners, this affirmative action that is to bring about equality is calculated to produce equality on
a broader basis by eliminating de facto inequalities and placing the weaker sections of the
community on a footing of equality with the stronger and more power section so that each member
of the community, whatever is his birth, occupation or social position may enjoy equal opportunity
of using to the full, his natural endowments of physique, of character and of intelligence.
This compensatory state action can be continued only for a period till that inequality is wiped off.
Therefore, the petitioners have contended that unless the period is prescribed, this affirmative
action will continue for an indefinite period and would ultimately result in reverse discrimination. It
is true that there is some force in the contention advanced by the learned Counsel for the petitioners
but that may happen in future if the reservation policy as contemplated under the Act is successfully
implemented. But at the outset, it may not be possible to fix a time limit or a period of time.
Depending upon the result of the measures and improvements that have taken place in the status
and educational advancement of the socially and educationally backward classes of citizens, the
matter could be examined by the Parliament at a future time but that cannot be a ground for striking
down a legislation. After some period, if it so happens that any section of the community gets an
undue advantage of the affirmative action, then such community can very well be excluded from
such affirmative action programme. The Parliament can certainly review the situation and even
though a specific class of citizens is in the legislation, it is the constitutional duty of the Parliament
to review such affirmative action as and when the social conditions are required. There is also the
safeguard of judicial review and the court can exercise its powers of judicial review and say that the
affirmative action has carried out its mission and is thus no longer required. In the case of
reservation of 27% for backward classes, there could be a periodic review after a period of 10 years
and the Parliament could examine whether the reservation has worked for the good of the country.
Therefore, the legislation cannot be held to be invalid on that ground but a review can be made after
a period of 10 years.
12. What shall be the educational standard to be prescribed to find out whether any class is
educationally backward?
188. Learned Senior Counsel Shri P.P. Rao contended that under Article 15(5) of the Constitution,
the reservation or any other affirmative action could be made for the advancement of only sociallyAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

and educationally backward classes of citizens or Scheduled Castes or Scheduled Tribes and the
educational standard to be assessed shall be matriculation or 10+2 and not more than that. It was
argued that many castes included in the backward class list have got a fairly good number of
members who have passed 10+2 and thus such castes are to be treated as educationally forward and
the present legislation, namely, Act 5 of 2007, is intended to give reservation to students in higher
institutions of learning and the same is not permissible under Article 15(5) of the Constitution. He
contended that the Parliament should not have made this legislation for reservation in the higher
institutions of learning as it is not part of the duty of the State under Article 46 of the Constitution.
According to the learned Counsel, education contemplated under Article 46 is only giving education
upto the standard of 10+2. The learned Counsel argued that this was the desire of the Founding
Fathers of the Constitution. The learned Counsel contended further that the State is not taking
adequate steps to improve primary education.
189. In reply to Shri P.P. Rao's arguments, learned Solicitor General Shri G. E. Vahanvati drew our
attention to various steps taken by the Union Government to improve the primary school education
and also the upper primary school education. It is incorrect to suggest that there have been no
efforts on the part of successive Governments to concentrate on level of education towards universal
elementary education. "Sarva Shiksha Abhiyanm" (SSA) had been launched by the Government in
2001-2002. The major components of SSA include opening of new schools, distribution of teaching
equipments, school grant for teachers and maintenance for schools, community participation &
training, carrying out civil works in school buildings, additional class rooms, distribution of free text
books for ST students and girls. It was pointed out that in the year 2006-2007, nearly Rs. 15,000
crores had been spent for such education. The Integrated Child Development Services (ICDS)
scheme was started in 1975. Latest figures show that progress has been made in the field of
education. It is pointed out that the primary school coverage has increased from 86.96% (2002) to
96% and that of Upper Primary School has increased from 78.11% to 85.3% with the opening of 1.34
Lakh Primary Schools and 1.01 lakh Upper Primary Schools. The gross enrolment has also increased
at the primary as well as upper primary stage. Drop out rate has fallen by 11.3%. It is also pointed
out that girls enrolment has increased from 43.7% (2001) to 46.7% (2004) at primary and from
40.9% to 44% at upper primary stage.
The Union of India has granted funds to various states for the purpose of meeting the education
requirements. The entire details were furnished to the Court and we do not think it necessary to go
into these details. Though at the time of attaining Independence, the basic idea was to improve
primary and secondary level education, but now, after a period of more than 50 years, it is idle to
contend that the backward classes shall be determined on the basis of their attaining education only
to the level of 10+2 stage. In India there are a large number of arts, science and professional colleges
and in the field of education, it is anachronistic to contend that primary education or secondary
education shall be the index for fixing backward class of citizens. We find no force in the contention
advanced by the learned Counsel for the petitioners and it is only to be rejected.
13. Whether the quantum of reservation provided for in the Act is valid and whether 27% of seats for
SEBC was required to be reserved?Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

190. The main contention of the petitioner's Counsel especially that of Shri Sushil Kumar Jain is that
the entire Act is liable to be set aside as there was no necessity to provide any reservation to socially
and educationally backward classes and according to him most of the castes included in the list
which is prepared in accordance with the Mandal Commission are educationally very much
advanced and the population of such group is not scientifically collected and the population ratio of
backward classes is projected only on the basis of the 1931 census and the entire legislation is an
attempt to please a section of the society as part of a vote catching mechanism.
191. A legislation passed by the Parliament can be challenged only on constitutionally recognized
grounds. Ordinarily, grounds of attack of a legislation is whether the legislature has legislative
competence or whether the legislation is ultra vires of the provisions of the Constitution. If any of
the provisions of the legislation violates fundamental rights or any other provisions of the
Constitution, it could certainly be a valid ground to set aside the legislation by invoking the power of
judicial review. A legislation could also be challenged as unreasonable if it violates the principles of
equality adumbrated in our Constitution or it unreasonably restricts the fundamental rights under
Article 19 of the Constitution. A legislation cannot be challenged simply on the ground of
unreasonableness because that by itself does not constitute a ground. The validity of a constitutional
amendment and the validity of plenary legislation have to be decided purely as questions of
constitutional law. This Court in State of Rajasthan & Ors. Vs. Union of India and Others79 said :
"...if a question brought before the Court is purely a politically question not involving
determination of any legal or constitutional 79 (1977) 3 SCC 592 at p. 660 right or
obligation, the court would not entertain it, since the Court is concerned only with
adjudication of legal rights and liabilities."
192. Therefore, the plea of the Petitioner that the legislation itself was intended to please a section of
the community as part of the vote catching mechanism is not a legally acceptable plea and it is only
to be rejected.
193. The quantum of reservation provided under the Act 5 of 2007 is based on the detailed facts
available with the Parliament.
Various commissions have been in operation determining as to who shall form the SEBCs. Though a
caste-wise census is not available, several other data and statistics are available. In the case of Indra
Sawhney (supra), the Mandal Commission was accepted in principle though the details and findings
of the commissions were not fully accepted by this Court. 27% of reservation in the matter of
employment was accepted by this Court. Petitioners have not produced any documents to show that
the backward class citizens are less than 27%, vis-`-vis, the total population of this country or that
there was no requirement of 27% reservation for them. The Parliament is invested with the power of
legislation and must be deemed to have taken into consideration all relevant circumstances when
passing a legislation of this nature. It is futile to contend whether Parliament was not aware of the
statistical details of the population of this country and, therefore, we do not think that 27%
reservation provided in the Act is illegal or on that account, the Act itself is liable to be struck down.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Questions:
1. Whether the Ninety-Third Amendment of the Constitution is against the "basic
structure" of the Constitution?
The Constitution (Ninety-Third Amendment) Act, 2005 does not violate the "basic structure" of the
Constitution so far as it relates to the state maintained institutions and aided educational
institutions.
Question whether the Constitution (Ninety-Third Amendment) Act, 2005 would be constitutionally
valid or not so far as "private unaided"
educational institutions are concerned, is left open to be decided in an appropriate
case. (Paragraph 79)
2. Whether Articles 15(4) and 15(5) are mutually c ontradictory, hence Article 15(5) is
to be held u ltra vires ?
Article 15(5) is constitutionally valid and Articles 15(4) and 15(5) are not mutually
contradictory. (Paragraph 100)
3. Whether exclusion of minority educational institutions from Article 15(5) is
violative of Article 14 of Constitution? Exclusion of minority educational institutions
from Article 15(5) is not violative of Article 14 of the Constitution as the minority
educational institutions, by themselves, are a separate class and their rights are
protected by other constitutional provisions.
(Paragraph 102)
4. Whether the Constitutional Amendment followed the procedure prescribed under
Article 368 of the Constitution? The Ninety-Third Amendment of the Constitution
does not affect the executive power of the State under Article 162 of the Constitution
and hence, procedure prescribed under Proviso to Article 368(2) is not required to be
followed.
(Paragraph 103)
5. Whether the Act 5 of 2007 is constitutionally invalid in view of definition of
"Backward Class" and whether the identification of such "Backward Class" based on
"caste" is constitutionally valid?
Identification of "backward class" is not done solely based on caste. Other parameters
are followed in identifying the backward class. Therefore, Act 5 of 2007 is not invalid
for this reason.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(Paragraph 142)
6. Whether "Creamy Layer" is to be excluded from SEBCs? "Creamy Layer" is to be
excluded from SEBCs. The identification of SEBCs will not be complete and without
the exclusion of "creamy layer" such identification may not be valid under Article
15(1) of the Constitution. (Paragraph 152)
7. What should be the para-meters for determining the "creamy layer" group?
The parameters contained in the Office Memorandum issued by the Government of
India, Ministry of Personnel, Public Grievances and Pensions (Department of
Personnel and Training) on 08.09.1993 may be applied. And the definition of "Other
Backward Classes"
under Section 2(g) of the Act 5 of 2007 should be deemed to mean class or classes of citizens who
are socially and educationally backward, and so determined by the Central Government; and if the
determination is with reference to caste, then the backward class shall be after excluding the creamy
layer.
(Paragraphs 153 and 155)
8. Whether the "creamy layer" principle is applicable to Scheduled Tribes and Scheduled Castes?
"Creamy Layer" principle is not applicable to Scheduled Castes and Scheduled Tribes.
(Paragraph 163)
9. Whether the principles laid down by the United States Supreme Court for affirmative action such
as "suspect legislation", "strict scrutiny" and "compelling State necessity"
are applicable to principles of reservation or other affirmative action contemplated
under Article 15(5) of the Constitution?
The principles laid down by the United States Supreme Court such as "suspect
legislation", "strict scrutiny" and "compelling State necessity" are not applicable for
challenging the validity of Act 5 of 2007 or reservations or other affirmative action
contemplated under Article 15(5) of the Constitution.
(Paragraphs 184)
10. Whether delegation of power to the Union Government to determine as to who shall be the
backward class is constitutionally valid?
The delegation of power to the Union Government to determine as to who shall be the "other
backward classes" is not excessive delegation. Such delegation is constitutionally valid.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(Paragraph 186)
11. Whether the Act is invalid as there is no time limit prescribed for its operation and no periodical
review is contemplated?
The Act 5 of 2007 is not invalid for the reason that there is no time limit prescribed for its operation,
but a review can be made after a period of 10 years. (Paragraph 187)
12. What shall be the educational standard to be prescribed to find out whether any class is
educationally backward?
The contention that educational standard of matriculation or (10+2) should be the benchmark to
find out whether any class is educationally backward is rejected. (Paragraph 189)
13. Whether the quantum of reservation provided for in the Act is valid and whether 27% of seats for
SEBC was required to be reserved?
27% of seats for other backward classes is not illegal and the Parliament must be deemed to have
taken into consideration all relevant circumstances when fixing the 27% reservation.
(Paragraph 193) These Writ Petitions are disposed off in light of the above findings, and the "Other
Backward Classes" defined in Section 2(g) of Act 5 of 2007 is to be read as "Socially and
Educationally Backward Classes"
other than Scheduled Castes and Scheduled Tribes, determined as `Other Backward
Classes' by the Central Government and if such determination is with reference to
caste, it shall exclude "Creamy Layer" from among such caste. In Contempt Petition
(Civil) No. 112/2007 in Writ Petition (C) No. 265/2006, no orders are required. It is
dismissed.
....................................C.J.I. (K.G. BALAKRISHNAN) NEW DELHI;
APRIL 10, 2008
              IN THE SUPREME COURT OF INDIA
                CIVIL ORIGINAL JURISDICTION
           WRIT PETITION (CIVIL) NO. 265 OF 2006Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Ashoka Kumar Thakur                          ....Petitioner 
                              Versus
Union of India and Ors.                      ...Respondents 
(With WP (C) Nos. 269/2006, 598/2006, 29/2007, 35/2007, 53/2007 Contempt
Petition (C)No.112/2007 in WP ) No.265/2006, 336/2007, 313/2007, 335/2007,
231/2007, 425/2007 and 428/2007) J U D G M E N T Dr. ARIJIT PASAYAT, J
1. The issues involved in the present writ petitions have far reaching consequences
and in essence pose several questions of seminal importance. In essence, they raise
questions which have no easy answers. The complexity can be gauged from the fact
that on one hand the petitioners have questioned the logic of providing
reservations/quotas for a class of people whom they described as "unidentifiable" or
"undetermined" while the respondents justify their action by labelling them as
measures taken for upliftment of vast majority of people who have suffered social
humiliation and sneer for the social backwardness. Complex questions like whether
the expressions `class' and `castes' are synonyms, whether reservations provide the
only solution for social empowerment measures, alleged lack of concern for the
economically weaker group of citizens are some of the basic issues which need to be
addressed. It has been emphatically highlighted by the petitioners that when the
ultimate objective is classless and casteless in Indian democracy, there is no question
of unendingly providing the reservation and that too without any definite data
regarding backwardness. In essence, they contend that these measures perpetuate
backwardness and do not remove them. On the epicenter of challenge is the Central
Educational Institutions (Reservation in Admission) Act 2006 (in short the `Act')
and the 93rd Amendment to the Constitution of India, 1950 (in short the
`Constitution'). Interestingly, both the petitioners and the respondents rely strongly
on certain observations made by this Court in Indra Sawhney v. Union of India 1992
(Suppl. 3) SCC 217 (commonly known as `Indra Sawhney No.1')
2. When the writ petitions were placed before a Bench of two Judges, considering the
importance of the matter they were referred to be heard by a larger bench and certain
questions which arise for consideration were formulated. That is how these cases are
before this Bench.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

3. Arguments have been advanced by both the sides as to whether Constitution
contemplates casteless society. While the respondents submit that the Constitution
really does not think of a casteless society, it prohibits untouchability in the
background of Article 17. It has to be noted that both in Articles 15 and 16 the stress is
on non-discrimination on the ground of castes. The Preamble of the Constitution also
throws light on this aspect. Ultimately if the social status of a man goes in the higher
direction because of his education, the difference in status gets obliterated. Education
is a great levellor. In that sense, the ultimate object is that every Indian citizen should
have the social status which is not inferior to another and that would be obliteration
of the difference in status. The ultimate objective is to see that no person gets
discriminated because of his caste. If that be so, it would not be right to say that the
ultimate objective is not the casteless society.
4. Various Articles of the Constitution of India and the Preamble provide an insight to
the monumental document i.e. the Constitution of India. Article 14 guarantees
equality before the law in addition to equal protection of law. Article 15(1) mandates
that there shall not be any discrimination against any citizen on the grounds of
religion, caste, sex, race, or place of birth. Article 16(1) makes the fundamental right
of equality specific relating to job opportunities. Article 16(2) significantly speaks of
government employment by providing that no citizen shall be ineligible only on the
grounds of religion, race, caste, sex, descent, place of birth or any of them or
discriminated against in respect of any employment or office under the State. Article
16(4) is an important provision which empowers the State permitting the provision
for the reservation of appointments and posts in favour of any backward class of
citizens which in the opinion of the State is not adequately represented in the services
of the State. The stress is on backwardness of the citizens and inadequate
representation in the services under the State.
5. If one takes a walk on the pathway relating to the views expressed by this Court in
the matter of reservation or quotas for the other backward classes one comes across
many milestones. Some of them were noted extensively in Indra Sawhney No.1. They
are: The State of Madras v. Sm. Champakam Dorairajan & Anr. (AIR 1951 SC 226),
Minor A Peeriakaruppan v. Sobha Joseph (1971 (1) SCC 38), The State of Andhra
Pradesh and Ors. v. U.S.V. Balram, etc. (1972 (1) SCC 660), Shri Janki Prasad
Parimoo and Ors. v. State of Jammu and Kashmir and Ors. (1973(1) SCC 420), State
of Uttar Pradesh and Ors. v. Pradip Tandon and Ors. (1975 (1) SCC 267), State of
Kerala and Anr. v. N.M. Thomas and Ors. (1976(2) SCC 310), Kumari K.S. Jayashree
and Anr. v. The State of Kerala and Anr. (1976 (3) SCC 730), K.C. Vasanth Kumar and
Anr. v. State of Karnataka (1985 (Supp) SCC 714) and Indra Sawhney v. Union of
India and Ors. (2000 (1) SCC
168) (known as Indra Sawhney No.2).Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

6. Two recent decisions have also been highlighted by the parties. They are M.
Nagaraj and Ors. v. Union of India and Ors. (2006 (8) SCC 212) and Nair Service
Society v. State of Kerala (2007 (4) SCC 1). It is to be noted that some of the
arguments which have been raised relate to broad principles of law and the
jurisprudential approach. They are the applicability of the foreign decisions, more
particularly, the decisions of the American Courts. They relate to the principles of
strict scrutiny and narrow tailoring.
7. Learned counsel for the petitioners have stressed on these decisions to show as to
what should be the approach in matters relating to social empowerment. Learned
counsel for the respondents have however submitted that the approach is to be
different because the problems before the American Courts essentially related to
individual rights while the Indian Courts are more concerned with group rights i.e.
rights of class of citizens. We shall deal with this in some length later.
8. The other issue which was hotly contested related to the exclusion of the creamy
layer.
9. One of the major challenges raised by the petitioners is based on the allegation that
there is no acceptable data for fixing the percentage of other backward classes. This
has been highlighted to show that there is no rational basis for fixing the percentage
of reservation at 27% for the other backward classes. It is pointed out that the figures
appear to have been culled out from some survey done more than seven decades back
i.e. 1931 to be precise. Thereafter, there seems to be no definite data to know the
actual percentage. It is pointed out that in Indra Sawhney No.1 (supra) this Court had
laid considerable stress on having a Commission to identify and determine the
criteria for determining the socially and educationally backward classes. Very little
appears to have been done. It is surprising, it was contended, that there has been not
even a single case of exclusion but on the other hand more than 250 new
castes/sub-castes have been added. This shows that there is really no serious attempt
to identify the other backward classes. On the other hand, there has been
over-jealous anxiety to include more number of people so that they can get the
benefits of reservations/quotas and this has been termed as "vote bank politics". It is
highlighted that even when a serious matter relating to adoption of the Act was under
consideration there was hardly any discussion and every political party was
exhibiting its anxiety to get the Statute passed. Crocodile tears were shed to show lip
sympathy for the backwardness of the people. In reality, the object was to give a
wrong impression to the people that they were concerned about the backwardness of
the people and they were the `Messiahs' of the poor and the down trodden. In reality,
in their hearts the ultimate object was to grab more votes. The lack of seriousness of
the debate exhibits that the debate was nothing but a red-herring to divert attention
from the sinister, politically motivated design masked by the "tearful" faces of the
people masquerading as champions of the poor and down trodden. It is pointed out
that contrary to what was being projected by the parties when the discussions wereAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

going on, in an impassioned speech by late Rajeev Gandhi who was the leader of
opposition at an earlier point of time, the fallacies in adopting the Mandal Report
were highlighted. It is surprising, it is submitted, that those very people who were the
champions of anti-reservation and anti-
quota as members of opposition, have done summersault and were saying just the opposite. It is
pointed out that when one member Shri P.C. Alexandar exhibited real courage and highlighted the
fallacies in the stand taken, his view appears to have been lightly brushed aside and the Statute
hustled through. It is also submitted that the objectivity and sanctity of the report submitted in the
Parliament commonly known as "Oversight Committee Report" has been lightly brushed aside.
This only indicates that there was no serious debate about the consequences. The foresight of late
Rajiv Gandhi in saying that the country will be divided on caste basis and that would lead to disaster
has been prophetically proved to be correct and it is a reality. It is submitted that the enactment has
created a sharp divide amongst the citizens of the country and it has not even an iota of good results
flowing from it. On the contrary, the country will be divided sharply leading to social unrest and
caste-wars. It is pointed out that in the recent past such caste wars have resulted in large scale loss
of life and destruction of public properties.
10. The relevance of the parliamentary debate or the speech of the Minister has been highlighted by
this Court in many cases. It is a settled position in law that there can be only limited use of the
parliamentary debate. The Courts should not normally critically analyse the proceedings of
Parliament.
This flows from a very fundamental aspect i.e. mutual respect of the Parliament and the Judiciary
for each other. Each of these great institutions in a democracy operates in different fields. It is not
expected that one wing of democracy would criticize the manner of functioning of another wing.
That would be against the basic desirability of mutual respect. Any opinion or comment or criticism
about the manner of functioning of one by the other would be not only undesirable but imperatively
avoidable. The citizens of this country expect a great deal from the Parliament and the Judiciary. It
is but natural that the people of this country would be disappointed and dis-heartened and their
hopes will be shattered if instead of showing respect for each other, there is mudslinging, unwanted
criticism or impermissible criticism about the manner of functioning or the rationale of a decision or
a view taken. In this context, it would be relevant to take note of what this Court said in Builders
Association of India v. Union of India and Ors. (1995 Supp (1) SCC 41), and K. Nagaraj and Ors. v.
State of Andhra Pradesh and Anr. (1985 (1) SCC 523).
In State of Mysore v. R.V. Bidap (1974 (3) SCC 337), it was observed as follows:
"5. Anglo-American jurisprudence, unlike other systems, has generally frowned upon
the use of parliamentary debates and press discussions as throwing light upon the
meaning of statutory provisions. Willes, J. in Miller v. Tayler, [1769] 4 Burri, 2303,
2332., stated that the sense and meaning of an Act of Parliament must be collected
from what it says when passed into law, and not from the history of changes itAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

underwent in the House where it took its rise. That history is not known to the other
House or to the Sovereign. In Assam Railways and Trading Company Ltd. v. I.R.C.,
[1935] A.C. 445 at p. 458, Lord Writ in the Privy Council said :
"It is clear that the language of a Minister of the Crown in proposing in Parliament a
measure which eventually becomes law is inadmissible and the report of
commissioners is even more removed from value as evidence of intention, because it
does not follow that their recommendations were accepted."
The rule of grammatical construction has been accepted in India before and after Independence. In
the State of Travancore-Cochin and Ors. v. Bombay Company Ltd., Alleppey, (AIR 1952 S.C. 366),
Chief Justice Patanjali Sastri delivering the judgment of the Court, said :-
"It remains only to point out that the use made by the learned Judges below of the
speeches made by the members of the Constituent Assembly in the course of the
debates on the draft Constitution is unwarranted. That this form of extrinsic aid to
the interpretation of statutes is not admissible has been generally accepted in
England, and the same rule has been observed in the construction of Indian
statutes-see Administrator-General of Bengal v. Prem Lal Mullick, 22 Ind. Appl. 107
(P.C.) at p. 118. The reason behind the rule was explained by one of us in Gopalan v.
State of Madras, (1950) S.C.R. 88 thus :
A speech made in the course of the debate on a bill could at best be indicative of the
subjective intent of the speaker, but it could not reflect the inarticulate mental
process lying behind the majority vote which carried the bill. Nor is it reasonable to
assume that the minds of all those legislators were in accord".
Or, as it is more tersely put in an American case-
"Those who did not speak may not have agreed with those who did; and those who
spoke might differ from each other-United States v. Trans-Missouri Freight
Association, (1897) 169 U.S. 290 at p. 318 (sic).
This rule of exclusion has not always been adhered to in America, and sometimes
distinction is made between using such material to ascertain the purpose of a statute
and using it for ascertaining its meaning. It would seem that the rule is adopted in
Canada and Australia-see Craies on Statute Law, 5th Edn. p. 122 (pp. 368-9)".
11. In the American jurisdiction, a more natural note has sometimes been struck. Mr. Justice
Frankfurter was of the view that-
"If the purpose of construction is the ascertainment of meaning, nothing that is
logically relevant should be excluded, and yet, the Rule of Exclusion, which is
generally followed in England, insists that, in interpreting statutes, the proceedingsAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

in the Legislatures, including speeches delivered when the statute was discussed and
adopted, cannot be cited in courts."
12. Crawford on Statutory Construction at page 388 notes that-
"The judicial opinion on this point is certainly not quite uniform and there are
American decisions to the effect that the general history of a statute and the various
steps leading up to an enactment including amendments or modifications of the
original bill and reports of Legislative Committees can be looked at for ascertaining
the intention of the legislature where it is in doubt; but they hold definitely that the
legislative history is inadmissible when there is no obscurity in the meaning of the
statute."
The Rule of Exclusion has been criticised by jurists as artificial. The trend of academic opinion and
the practice in the European system suggest that interpretation of a statute being an exercise in the
ascertainment of meaning, everything which is logically relevant should be admissible. Recently, an
eminent Indian jurist has reviewed the legal position and expressed his agreement with Julius Stone
and Justice Frankfurter. Of course, nobody suggests that such extrinsic materials should be decisive
but they must be admissible.
Authorship and interpretation must mutually illumine and interact. There is authority for the
proposition that resort may be had to these sources with great caution and only when incongruities
and ambiguities are to be resolved. A.K. Gopalan v. State of Madras (1950 SCR 88). There is a strong
case for whittling down the Rule of Exclusion followed in the British courts and for less apologetic
reference to legislative proceedings and like materials to read the meaning of the words of a statute.
Where it is plain, the language prevails, but where there is obscurity or lack of harmony with other
provisions and in other special circumstances, it may be legitimate to take external assistance such
as the object of the provisions, the mischief sought to be remedied, the social context, the words of
the authors and other allied matters. The law of statutory construction is a strategic branch of
jurisprudence which must, it may be felt, respond to the great social changes but a conclusive
pronouncement on the particular point arising here need not detain us because nothing decisive as
between the alternative interpretations flows from a reliance on the Constituent Assembly
proceedings or the broad purposes of the statutory scheme.
13. One thing however needs to be noted here that mere short length of debate cannot and does not
become a ground for invalidity of the decision and the reverse is also not true.
14. Elaborate arguments have been advanced about the applicability of the foreign decisions, more
particularly, the American Courts. It is to be noted that the American cases which have been
highlighted by the petitioners relate essentially to strict classification, strict scrutiny and narrow
tailoring. This issue is of considerable importance when so much debate is taking place about
respect being shown by courts of a country to a decision of another country. The factual scenario and
the basic issues involved in the cases sometimes throw light on the controversy. It has been rightly
contended by Mr. Vahanvati and Mr. Gopal Subramanium that there is a conceptual differenceAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

between the cases decided by the American Supreme Court and the cases at hand. In Saurabh
Chaudri and Ors. v. Union of India and Ors.
(2003 (11) SCC 146) it was held that the logic of strict classification and strict scrutiny does not have
much relevance in the cases of the nature at hand. If one looks at the different Statutes in India,
Article 14 of the Constitution is conceptually different from 14th Amendment to the American
Constitution as was noted in State of West Bengal vs. Anwar Ali Sarkar (1952 SCR 284) and State of
Bombay and Anr. v.
F.N. Balsara (1952 SCR 682). In Anwar Ali's case (supra) at pages 363 and 364 it was noted as
follows:
"I find it impossible to read these portions of the Constitution without regard to the
background out of which they arose. I cannot blot out their history and omit from
consideration the brooding spirit of the times. They are not just dull, lifeless words
static and hide- bound as in some mummified manuscript, but, living flames
intended to give life to a great nation and order its being, tongues of dynamic fire,
potent to mould the future as well as guide the present. The Constitution must, in my
judgment, be left elastic enough to meet from time to time the altering conditions of a
changing world with its shifting emphasis and differing needs. I feel therefore that in
each case judges must look straight into the heart of things and regard the facts of
each case concretely much as a jury would do; and yet, not quite as a jury, for we are
considering here a matter of law and not just one of fact; Do these "laws" which have
been called in question offend a still greater law before which even they must bow?
99. Doing that, what is the history of these provisions? They arose out of the fight for
freedom in this land and are but the endeavour to compress into a few pregnant
phrases some of the main attributes of a sovereign democratic republic as seen
through Indian eyes. There was present to the collective mind of the Constituent
Assembly, reflecting the mood of the peoples of India, the memory of grim trials by
hastily constituted tribunals with novel forms of procedure set forth in Ordinances
promulgated in haste because of what was then felt to be the urgent necessities of the
moment. Without casting the slightest reflection of the judges and the Courts so
constituted, the fact remains that when these tribunals were declared invalid and the
same persons were retired in the ordinary Courts, many were acquitted, many who
had been sentenced to death were absolved. That was not the fault of the judges but
of the imperfect tools with which they were compelled to work. The whole
proceedings were repugnant to the peoples of this land, and to my mind, article 14 is
but a reflex of this mood.
100. What I am concerned to see is not whether there is absolute equality in any
academical sense of the term but whether the collective conscience of a sovereign
democratic republic can regard the impugned law, contrasted with the ordinary law
of the land, as the sort of substantially equal treatment which men of resolute mindsAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

and unbiased views can regard as right and proper in a democracy of the kind we
have proclaimed ourselves to be. Such views must take into consideration the
practical necessities of government, the right to alter the laws and many other facts,
but in the forefront must remain the freedom of the individual from unjust and
unequal treatment, unequal in the broad sense in which a democracy would view it.
In my opinion, 'law' as used in Article 14 does not mean the "legal precepts which are
actually recognised and applied in tribunals of a given time and place"
but "the more general body of doctrine and tradition from which those precepts are chiefly drawn,
and by which we criticise, them."
15. It needs no emphasis that the formal equality concept came to be recognized in U.S.A. after
about 10 years of its inception. In the first phase of the U.S.A. Constitutional Law there was only
affirmative action but in the Indian Constitution right from the beginning affirmative action has
been provided, for example, provisions made for Scheduled Castes and Schedules Tribes. A
distinction has been noted in para 640 of Indra Sawhney No.1. Articles 38(1) and 38(2) read with
Article 46 of the Constitution make the position clear that the State is charged with the duty to
secure interests of the weaker sections of the people and minimize the inequalities in income. The
Constitution from its inception contained Article 17 which abolishes untouchability.
16. In this context the following paras need to be noted.
17. In Minerva Mills Ltd. and Ors. v. Union of India and Ors.
(1980) 3 SCC 625) in para 63 it was held as follows:
"63. The learned Attorney General argues that the State is under an obligation to take
steps for promoting the welfare of the people by bringing about a social order in
which social, economic and political justice shall inform all the institutions of the
national life. He says that the deprivation of some of the fundamental rights for the
purpose of achieving this goal cannot possibly amount to a destruction of the basic
structure of the Constitution. We are unable to accept this contention. The principles
enunciated in Part IV are not the proclaimed monopoly of democracies alone. They
are common to all polities, democratic or authoritarian. Every State is goal- oriented
and claims to strive for securing the welfare of its people. The distinction between the
different forms of Government consists in that a real democracy will endeavour to
achieve its objectives through the discipline of fundamental freedoms like those
conferred by Articles14 and 19. Those are the most elementary freedoms without
which a free democracy is impossible and which must therefore be preserved at all
costs. Besides, as observed by Brandies, J., the need to protect liberty is the greatest
when Government's purposes are beneficent. If the discipline of Article 14 is
withdrawn and if immunity from the operation of that article is conferred, not only
on laws passed by the Parliament but on laws passed by the State Legislatures also,
the political pressures exercised by numerically large groups can tear the countryAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

asunder by leaving it to the legislature to pick and choose favoured areas and
favourite classes for preferential treatment."
18. In His Holiness Kesavananda Bharati Sripadagalvaru v.
State of Kerala and Anr. (1973 (4) SCC 225) it was held as under:
"531. According to Mr. Palkhivala, the test of the true width of a power is not how
probable it is that it may be exercised but what can possibly be done under it; that the
abuse or misuse of power is entirely irrelevant; that the question of the extent of the
power cannot be mixed up with the question of its exercise and that when the real
question is as to the width of the power, expectation that it will never be used is as
wholly irrelevant as an imminent danger of its use. The court does not decide what is
the best and what is the worst. It merely decides what can possibly be done under a
power if the words conferring it are so construed as to have an unbounded and
limitless width, as claimed on behalf of the respondents.
532. It is difficult to accede to the submission on behalf of the respondents that while
considering the consequences with reference to the width of an amending power
contained in a Constitution any question of its abuse is involved. It is not for the
courts to enter into the wisdom or policy of a particular provision in a Constitution or
a statute. That is for the Constitution makers or for the parliament or the legislature.
But that the real consequences can be taken into account while judging the width of
the power is well settled. The Court cannot ignore the consequences to which a
particular construction can lead while ascertaining the limits of the provisions
granting the power. According to the learned Attorney General, the declaration in the
preamble to our Constitution about the resolve of the people of India to constitute it
into a Sovereign, Democratic Republic is only a declaration of an intention which was
made in 1947 and it is open to the amending body now under Article 368 to change
the Sovereign Democratics Republic into some other kind of polity. This by itself
shows the consequence of accepting the construction sought to be put on the material
words in that article for finding out the ambit and width of the power conferred by
it."
19. In Sajan Singh v. Maharashtra Sugar Mills Ltd. (AIR 1965 SC 845) it was held as follows:
"6. It is obvious that the fundamental rights enshrined in Part III are not included in
the proviso, and so, if Parliament intends to amend any of the provisions contained in
Articles 12 to 35 which are included in Part III, it is not necessary to take recourse to
the proviso and to satisfy the additional requirements prescribed by it. Thus far, there
is no difficulty. But in considering the scope of Art. 368, it is necessary to remember
that Art. 226, which is included in Chapter V of Part VI of the Constitution, is one of
the constitutional provisions which fall under clause (b) of the proviso; and so, it is
clear that if Parliament intends to amend the provisions of Art. 226, the billAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

proposing to make such an amendment must satisfy the requirements of the proviso.
The question which calls for our decision is : what would be the requirement about
making an amendment in a constitutional provision contained in Part III, if as a
result of the said amendment, the powers conferred on the High Courts under Art.
226 are likely to be affected? The petitioners contend that since it appears that the
powers prescribed by Art. 226 are likely to be affected by the intended amendment of
the provisions contained in Part III, the bill introduced for the purpose of making
such an amendment, must attract the proviso, and as the impugned Act has
admittedly not gone through the procedure prescribed by the proviso, it is invalid;
and that raises the question about the construction of the provisions contained in Art.
368 and the relation between the substantive part of Art. 368 with its proviso.
8. On the other hand, if the substantive part of Art. 368 is very liberally and
generously construed and it is held that even substantial modification of the
fundamental rights which may make a very serious and substantial inroad on the
powers of the High Courts under Art. 226 can be made without invoking the proviso,
it may deprive clause (b) of the proviso of its substance. In other words, in construing
both the parts of Art. 368, the rule of harmonious construction requires that if the
direct effect of the amendment of fundamental rights is to make a substantial inroad
on the High Courts' powers under Art. 226, it would become necessary to consider
whether the proviso would cover such a case or not. If the effect of the amendment
made in the fundamental rights on the powers of the High Courts prescribed by Art.
226, is indirect, incidental, or is otherwise of an insignificant order, it may be that the
proviso will not apply. The proviso would apply where the amendment in question
seeks to make any change, inter alia, in Art. 226, and the question in such a case
would be : does the amendment seek to make a change in the provisions of Art. 226?
The answer to this question would depend upon the effect of the amendment made in
the fundamental rights.
9. In dealing with constitutional questions of this character, courts generally adopt a
test which is described as the pith and substance test. In Attorney-General for
Ontario v. Reciprocal Insurers ([1924] A.C. 328), the Privy Council was called upon to
consider the validity of the Reciprocal Insurance Act, 1922 (12 & 13 Geo. 5, Ont., c.
62) and s. 508c which had been added to the Criminal Code of Canada by ss. 7 & 8
Geo. 5, c. 29 Dom. Mr. Justice Duff, who spoke for the Privy Council, observed that in
an enquiry like the one with which the Privy Council was concerned in that case, "it
has been formally laid down in judgments of this Board, that in such an inquiry the
Courts must ascertain the 'true nature and character' of the enactment : Citizens'
Insurance Co. of Canada v. Parsons ([1881] 7 AC 96); its 'pith and substance' :
Union Colliery Co. of British Columbia Ltd. v. Bryden ([1899] A.C. 580); and it is the
result of this investigation, not the form alone, which the statute may have assumed
under the hand of the draughtsman, that will determine within which of the
categories of subject matters mentioned in ss. 91 and 92 the legislation falls; and forAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

this purpose the legislation must be 'scrutinised in its entirety' : "Great West Saddlery
Co. v. The King" ([1921] 2 A.C. 91,117). It is not necessary to multiply authorities in
support of the proposition that in considering the constitutional validity of the
impugned Act, it would be relevant to inquire what the pith and substance of the
impugned Act is. This legal position can be taken to be established by the decisions of
this Court which have consistently adopted the view expressed by Justice Duff, to
which we have just referred.
14. Thus, it would be seen that the genesis of the amendments made by Parliament in
1951 by adding Articles 31A and 31B to the Constitution, clearly is to assist the State
Legislatures in this country to give effect to the economic policy in which the party in
power passionately believes to bring about much needed agrarian reform. It is with
the same object that the second amendment was made by Parliament in 1955, and as
we have just indicated, the object underlying the amendment made by the impugned
Act is also the same.
Parliament desires that agrarian reform in a broad and comprehensive sense must be introduced in
the interests of a very large section of Indian citizens who live in villages and whose financial
prospects are integrally connected with the pursuit of progressive agrarian policy. Thus, if the pith
and substance test is applied to the amendment made by the impugned Act, it would be clear that
Parliament is seeking to amend fundamental rights solely with the object of removing any possible
obstacle in the fulfilment of the socio-economic policy in which the party in power believes. If that
be so, the effect of the amendment on the area over which the High Courts' powers prescribed by
Art. 226 operate, is incidental and in the present case can be described as of an insignificant order.
The impugned Act does not purport to change the provisions of Art. 226 and it cannot be said even
to have that effect directly or in any appreciable measure. That is why we think that the argument
that the impugned Act falls under the proviso, cannot be sustained. It is an Act the object of which is
to amend the relevant Articles in Part III which confer fundamental rights on citizens and as such it
falls under the substantive part of Art. 368 and does not attract the provisions of clause (b) of the
proviso. If the effect of the amendment made in the fundamental rights on Art. 226 is direct and not
incidental and is of a very significant order, different considerations may perhaps arise. But in the
present case, there is no occasion to entertain or weigh the said considerations. Therefore the main
contention raised by the petitioners and the interveners against the validity of the impugned Act
must be rejected."
20. In Kihoto Hollohan v. Zachillhu and Ors. (1992 Supp. (2) SCC 651) it was observed as follows:
"61. The propositions that fell for consideration in Sankari Prasad Singh's and Sajjan
Singh's cases are indeed different. There the jurisdiction and power of the Courts
under Articles 136 and 226 were not sought to be taken away nor was there any
change brought about in those provisions either "in terms or in effect", since the very
rights which could be adjudicated under and enforced by the Courts were themselves
taken away by the Constitution. The result was that there was no area for the
jurisdiction of the Courts to operate upon. Matters are entirely different in theAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

context of paragraph 7. Indeed the aforesaid cases, by necessary implication support
the point urged for the petitioners. The changes in Chapter IV of Part V and Chapter
V of Part VI envisaged by the proviso need not be direct. The change could be either
"in terms of or in effect". It is not necessary to change the language of Articles 136
and 226 of the Constitution to attract the proviso. If in effect these Articles are
rendered ineffective and made inapplicable where these articles could otherwise have
been invoked or would, but for Paragraph 7, have operated there is `in effect' a
change in those provisions attracting the proviso. Indeed this position was recognised
in Sajjan Singh's case (supra) where it was observed:
"If the effect of the amendment made in the fundamental rights on Article 226 is
direct and not incidental and is of a very significant order, different considerations
may perhaps arise."
62. In the present cases, though the amendment does not bring in any change directly in the
language of Article 136, 226 and 227 of the Constitution, however, in effect paragraph 7 curtails the
operation of those Articles respecting matters falling under the Tenth Schedule. There is a change in
the effect in Article 136, 226 and 227 within the meaning of clause (b) of the proviso to Article
368(2).
Paragraph 7, therefore, attracts the proviso and ratification was necessary. Accordingly, on Point B,
we hold:
"That having regard to the background and evolution of the principles underlying the
Constitution (52nd Amendment) Act, 1985, in so far as it seeks to introduce the
Tenth Schedule in the Constitution of India, the provisions of Paragraph 7 of the
Tenth Schedule of the constitution in terms and in effect bring abouta change in the
operation and effect to Articles 136, 226 and 227 of the Constitution of India and,
therefore, the amendment would require to be ratified in accordance with the proviso
to sub-Article (2) of Article 368 of the Constitution of India."
21. In Shri Sarwan Singh and Anr. v. Shri Kasturi Lal (1977 (1) SCC 750) it was observed as follows:
"20. Speaking generally, the object and purpose of a legislation assume greater
relevance if the language of the law is obscure and ambiguous. But, it must be stated
that we have referred to the object of the provisions newly introduced into the Delhi
Rent Act in 1975 not for seeking light from it for resolving in ambiguity, for there is
none, but for a different purpose altogether. When two or more laws operate in the
same field and each contains a non obstante clause stating that its provisions will
override those of any other law, stimulating and incisive problems of interpretation
arise. Since statutory interpretation has no conventional protocol, cases of such
conflict have to be decided in reference to the object and purpose of the laws under
consideration. A piquant situation, like the one before us, arose in Shri Ram Narain v.
Simla Banking & Industrial Co. Ltd. competing statutes being the BankingAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Companies Act, 1949 as amended by Act 52 of 1953, and the Displaced Persons
(Debts Adjustment) Act, 1951. Section 45A of the Banking Companies Act, which was
introduced by the amending Act of 1953, and Section 3 of the Displaced Persons Act
1951 contained such a non obstante clause, providing that certain provisions would
have effect "notwithstanding anything inconsistent therewith contained in any other
law for the time being in force". This Court resolved the conflict by considering the
object and purpose of the two laws and giving precedence to the Banking Companies
Act by observing : "It is, therefore, desirable to determine the overriding effect of one
or the other of the relevant provisions in these two Acts, in a given case, on much
broader considerations of the purpose and policy underlying the two Acts and the
clear intendment conveyed by the language of the relevant provisions therein." (p.
615) As indicated by us, the special and specific purpose which motivated the
enactment of Section 14A and Chapter IIIA of the Delhi Rent Act would be wholly
frustrated if the provisions of the Slum Clearance Act requiring permission of the
competent authority were to prevail over them. Therefore, the newly introduced
provisions of the Delhi Rent Act must hold the field and be given full effect despite
anything to the contrary contained in the Slum Clearance Act.
21. For resolving such inter se conflicts, one other test may also be applied though the
persuasive force of such a test is but one of the factors which combine to give a, fair
meaning to the language of the law. That test is that the later enactment must prevail
over the earlier one. Section 14A and Chapter IIIA having been enacted with effect
from December 1, 1975 are later enactments in reference to Section 19 of the Slum
Clearance Act which, in Its present form, was placed on the statute book with effect
from February 28, 1965 and in reference to Section 39 of the same Act, which came
into force in 1956 when the Act itself was passed. The legislature gave overriding
effect to Section 14A and Chapter IIIA with the knowledge that Sections 19 and 39 of
the Slum Clearance Act contained non obstante clauses of equal efficacy. Therefore
the later enactment must prevail over the former. The same test was mentioned with
approval by this Court in Shri Ram Narain's case at page 615.
23. The argument of implied repeal has also no substance in it because our reason for
according priority to the provisions of the Delhi Rent Act is not that the Slum
Clearance Act stands impliedly repealed protanto. Bearing in mind the language of
the two laws, their object and purpose, and the fact that one of them is later in point
of time and was enacted with the knowledge of the non obstante clauses in the earlier
law, we have come to the conclusion that the provisions of Section 14A and Chapter
IIIA of the Rent Control Act must prevail over those contained in Sections 19 and 39
of the Slum Clearance Act.
22. In J.K. Cotton Spinning and weaving co. Ltd. v. State of U.P. and Anr. (1961 (3) SCR 185) it was
observed as under:Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"There will be complete harmony however if we hold instead that clause 5(a) will
apply in all other cases of proposed dismissal or discharge except where an inquiry is
pending within the meaning of clause 23. We reach the same result by applying
another well known rule of construction that general provisions yield to special
provisions. The learned Attorney- General seemed to suggest that while this rule of
construction is applicable to resolve the conflict between the general provision in one
Act and the special provision in another Act, the rule cannot apply in resolving a
conflict between general and special provisions in the same legislative instrument.
This suggestion does not find support in either principle or authority. The rule that
general provisions should yield to specific provisions is not an arbitrary principle
made by lawyers and judges but springs from the common understanding of men and
women that when the same person gives two directions one covering a large number
of matters in general and another to only some of them his intention is that these
latter directions should prevail as regards these while as regards all the rest the
earlier direction should have effect. In Pretty v. Solly [(1859-53 ER 1032) (quoted in
Craies on Statute Law at p. 205, 5th Edition) Romilly, M. R. mentioned the rule thus
:-
"The rule is, that whenever there is a particular enactment and a general enactment
in the same statute and the latter, taken in its most comprehensive sense, would
overrule the former, the particular enactment must be operative, and the general
enactment must be taken to affect only the other parts of the statute to which it may
properly apply". The rule has been applied as between different provisions of the
same statute in numerous cases some of which only need be mentioned : De Winton
v. Brecon [(1858) 28 L.J. Ch. 598], Churchill v. Crease [(1828) 5 Bing. 177], United
States v. Chase [(1889) 135 U.S. 255] and Carroll v. Greenwich Ins. Co. [(1905) 199
U.S. 401]."
23. In R.M.D. Chamarbaugwalla v. UOI (1957 SCR 930) it was held as under:
"The question whether a statute which is void in part is to be treated as void in toto,
or whether it is capable of enforcement as to that part which is valid is one which can
arise only with reference to laws enacted by bodies which do not possess unlimited
powers of legislation, as, for example, the legislatures in a Federal Union. The
limitation on their powers may be of two kinds: It may be with reference to the
subject- matter on which they could legislate, as, for example, the topics enumerated
in the Lists in the Seventh Schedule in the Indian Constitution, ss. 91 and 92 of the
Canadian Constitution, and s. 51 of the Australian Constitution; or it may be with
reference to the character of the legislation which they could enact in respect of
subjects assigned to them, as for example, in relation to the fundamental rights
guaranteed in Part III of the Constitution and similar constitutionally protected
rights in the American and other Constitutions. When a legislature whose authority is
subject to limitations aforesaid enacts a law which is wholly in excess of its powers, it
is entirely void and must be completely ignored. But where the legislation falls in partAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

within the area allotted to it and in part outside it, it is undoubtedly void as to the
latter; but does it on that account become necessarily void in its entirety? The answer
to this question must depend on whether what is valid could be separated from what
is invalid, and that is a question which has to be decided by the court on a
consideration of the provisions of the Act. This is a principle well established in
American Jurisprudence, Vide Cooley's Constitutional Limitations, Vol. I, Chap. VII,
Crawford on Statutory Construction, Chap. 16 and Sutherland on Statutory
Construction, 3rd Edn, Vol. 2, Chap. 24. It has also been applied by the Privy Council
in deciding on the validity of laws enacted by the legislatures of Australia and
Canada, Vide Attorney-General for the Commonwealth of Australia v. Colonial Sugar
Refining Company Limited [[1914] A.C. 237] and Attorney-General for Alberta v.
Attorney-General for Canada [L.R. [1947] A.C. 503]. It was approved by the Federal
Court in In re Hindu Women's Rights to Property Act [[1941] F.C.R. 12] and adopted
by this Court in The State of Bombay and another v. F. N. Balsara [[1951] S.C.R. 682]
and The State of Bombay v. The United Motors (India) Ltd., and others [[1953] S.C.R.
1069]. These decisions are relied on by Mr. Seervai as being decisive in his favour.
Mr. Palkhiwala disputes this position, and maintains that on the decision of the Privy
Council in Punjab Province v. Daulat Singh and others [[1946] F.C.R. 1] and of the
decisions of this Court in Romesh Thappar v. State of Madras [[1950] S.C.R. 594] and
Chintaman Rao v. State of Madhya Pradesh [[1950] S.C.R. 759], the question must be
answered in this favour. We must now examine the precise scope of these decisions.
The resulting position may thus be stated : When a statute is in part void, it will be
enforced as regards the rest, if that is severable from what is invalid. It is immaterial
for the purpose of this rule whether the invalidity of the statute arises by reason of its
subject-matter being outside the competence of the legislature or by reason of its
provisions contravening constitutional prohibitions.
That being the position in law, it is now necessary to consider whether the impugned
provisions are severable in their application to competitions of a gambling character,
assuming of course that the definition of 'prize competition' in s. 2(d) is wide enough
to include also competitions involving skill to a substantial degree. It will be useful
for the determination of this question to refer to certain rules of construction laid
down by the American Courts, where the question of severability has been the subject
of consideration in numerous authorities. They may be summarised as follows :
1. In determining whether the valid parts of a statute are separable from the invalid
parts thereof, it is the intention of the legislature that is the determining factor. The
test to be applied is whether the legislature would have enacted the valid part if it had
known that the rest of the statute was invalid.
Vide Corpus Juris Secundum, Vol. 82, p. 156; Sutherland on Statutory Construction, Vol. 2, pp.
176-177.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

2. If the valid and invalid provisions are so inextricably mixed up that they cannot be separated from
one another, then the invalidity of a portion must result in the invalidity of the Act in its entirety. On
the other hand, if they are so distinct and separate that after striking out what is invalid, what
remains is in itself a complete code independent of the rest, then it will be upheld notwithstanding
that the rest has become unenforceable. Vide Cooley's Constitutional Limitations, Vol. 1 at pp.
360-361; Crawford on Statutory Construction, pp. 217-
218.
3. Even when the provisions which are valid are distinct and separate from those which are invalid,
if they all form part of a single scheme which is intended to be operative as a whole, then also the
invalidity of a part will result in the failure of the whole. Vide Crawford on Statutory Construction,
pp. 218-219.
4. Likewise, when the valid and invalid parts of a statute are independent and do not form part of a
scheme but what is left after omitting the invalid portion is so thin and truncated as to be in
substance different from what it was when it emerged out of the legislature, then also it will be
rejected in its entirety.
5. The separability of the valid and invalid provisions of a statute does not depend on whether the
law is enacted in the same section or different sections; (Vide Cooley's Constitutional Limitations,
Vol. 1, pp. 361-362); it is not the form, but the substance of the matter that is material, and that has
to be ascertained on an examination of the Act as a whole and of the setting of the relevant
provisions therein.
6. If after the invalid portion is expunged from the statute what remains cannot be enforced without
making alterations and modifications therein, then the whole of it must be struck down as void, as
otherwise it will amount to judicial legislation. Vide Sutherland on Statutory Construction, Vol. 2, p.
194.
7. In determining the legislative intent on the question of separability, it will be legitimate to take
into account the history of the legislation, its object, the title and the preamble to it. Vide Sutherland
on Statutory Construction, Vol. 2, pp.
177-178."
24. In AIIMS Students Union v. AIIMS (2002 (1) SCC 428) in para 35 it was observed as follows:
"35. The principle of institutional continuity while seeking admission to higher levels
of study as propounded by the learned counsel for the appellants though argued at
length does not have much room available for innovative judicial zeal to play, for the
ground already stands almost occupied by a set of precedents, more so when we are
dealing with professional or technical courses of study. It would suffice to have a brief
resume thereof noticing the details wherever necessary".Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

It was again highlighted in para 44 as follows:
"44. When protective discrimination for promotion of equalisation is pleaded, the
burden is one the party who seeks to justify the ex facie deviation from equality. The
basic rule is equality of opportunity for every person in the country, which is a
constitutional guarantee. A candidate who gets more marks than another is entitled
to preference for admission. Merit must be the test when choosing the best, according
to this rule of equal chance for equal marks. This proposition has greater importance
when we reach the higher levels and education like post-graduate courses.
Reservation, as an exception, may be justified subject to discharging the burden of
proving justification in favour of the class which must be educationally
handicapped-the reservation geared up to getting over the handicap. The rationale of
reservation in the case of medical students must be removal of regional or class
inadequacy or like disadvantage. Even there the quantum of reservation should not
be excessive or societally injurious. The higher the level of the speciality the lesser the
role of reservation."
25. A bare reading of the provision goes to show that the burden is on the person who justifies
deviation from equality.
26. Even then, this doctrine was upheld by the Supreme Court of U.S.A. in Plessy v. Ferguson (163
U.S. 537(1896).
This case involved a challenge to a Louisiana statute that provided for equal but separate
accommodations for black and white passengers in trains. The Court rejected the challenge.
Justice Brown famously observed:
If one race be inferior to the other socially, the constitution of the United States
cannot put them upon the same plane. (163 U.S. at 552)
27. He held that racial segregation was a reasonable exercise of State police power for the promotion
of the public good and upheld the law.
28. Thus, even in this second phase, affirmative action was never truly initiated - the country was
still struggling to establish even a formally equal society.
29. At the same time, another very important development in its constitutional law was taking place,
which would later have a serious impact on affirmative action programmes. This was the birth of the
doctrine of strict scrutiny.
30. `Strict scrutiny' is one of the three standards for judicial review of legislative and administrative
action developed in the United States, the other being "rational basis" and "intermediate scrutiny".Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

31. The origin of this standard can be traced to the decision in United States v Carolene Products
(304 U.S. 144 (1938).
The question before the Court was whether the Filled Milk Act, 1923 which prohibited the shipment
in interstate commerce of skimmed milk compounded with any fat or oil other than milk fat, so as to
resemble milk or cream, transcended the power of Congress to regulate inter state commerce or
infringed the Fifth Amendment. Justice Harlan Stone, writing the opinion for the Court, upheld the
law, holding that the existence of facts supporting the legislative judgment was to be presumed, for
regulatory legislation affecting ordinary commercial transactions was not to be pronounced
unconstitutional unless in the light of the facts made known or generally assumed it was of such a
character as to preclude the assumption that it rested upon some rational basis within the
knowledge and experience of the legislators. However, he added what has been described as "the
most celebrated footnote in constitutional law".
"There may be narrower scope for operation of the presumption of constitutionality
when legislation appears on its face to be within a specific prohibition of the
Constitution, such as those of the first ten Amendments, which are deemed equally
specific when held to be embraced within the Fourteenth."
32. What the Court was saying was that economic legislation would be judged by a standard of
"rational basis" - so long as the law was a rational way of furthering a legitimate governmental
purpose, it was valid. However, where the legislation "on its face" appeared to be violating any of the
fundamental rights, a more exacting standard would be applied.
33. The precise term "strict scrutiny" was used by the Court for the first time in Skinner v. Oklahoma
(316 U.S. 535 (1942).
The Oklahoma Habitual Criminal Sterilisation Act provided for vasectomy to be performed on any
person convicted two or more times for crimes amounting to "felonies involving moral turpitude".
Justice Douglas, giving the opinion of the Court, described the statute as violating the right to have
offspring -
"a right which is basic to the perpetuation of a race". The question before the Court
was whether this statute violated the 14th Amendment. Holding that it did, Justice
Douglas observed:
"Strict scrutiny of the classification which a State makes in a sterilization law is
essential, lest unwittingly or otherwise invidious discriminations are made against
groups or types of individuals in violation of the constitutional guarantee of just and
equal laws."
34. In India there has to be collective commitment for upliftment of those who needed it. In that
sense, the question again comes back to the basic issue as to whether the action taken by the
Government can be upheld after making judicial scrutiny. Much assistance is not available to theAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

petitioners from the American decisions.
35. It is to be noted that the doctrine of separation as is prevalent in the American Society is not of
much consequence in the Indian scenario. It needs to be clarified that the expression `strict
scrutiny' has also been used by the Indian Courts in Narendra Kumar and Ors. v. Union of India and
Ors.
(1960 (2) SCR 375) but it appears to have been used in different context. What really appears to be
the intention for the use of the expression is "careful and deeper scrutiny" and not in the sense of
strict scrutiny of the provisions as is prevalent in the American jurisprudence. It is used in different
sense. The application appears to be in technical sense in the American Courts, for example, Regents
of University of California v. Allan Bakke (438 U.S. 265).
36. Some of the judgments of American Courts throwing light on the controversy need to be noted:
37. In Allan Bakke's case (supra) it was held as follows:
"Hence, the purpose of helping certain groups whom the faculty of the Davis Medical
School perceived as victims of "societal discrimination" does not justify a
classification that imposes disadvantages upon persons like respondent, who bear no
responsibility for whatever harm the beneficiaries of the special admissions".
"The fatal flaw in petitioner's preferential program is its disregard of individual rights
as guaranteed by the Fourteenth Amendment. Shelley v. Kraemer, 334 US, at 22, 92
L Ed 1161, 68 S Ct 836, 3 ALRd 441. Such rights are not absolute. But when a State's
distribution of benefits or imposition of burdens hinges on ancestry or the color of a
person's skin or ancestry, that individual is entitled to a demonstration that the
challenged classification is necessary to promote a substantial state interest.
Petitioner has failed to carry this burden."
38. In Grutter v. Bollinger (539 U.S. 306) it was held as follows:
[21, 22a] "We acknowledge that "there are serious problems of justice connected with
the idea of preference itself." Bakke, 438 US, at 298, 57 L Ed 2d 750, 98 S Ct 2733
(opinion of Powell, J). Narrow tailoring, therefore, requires that a race-
conscious admissions program not unduly harm members of any racial group. Even remedial
race-based governmental action generally "remains subject to continuing oversight to assure that it
will work the least harm possible to other innocent persons competing for the benefit." Id., at 308,
57 L Ed 2d 750, 98 S Ct 2733. To be narrowly tailored, a race-
conscious admissions program must not "unduly burden individuals who are not members of the
favored racial and ethnic groups." Metro Broadcasting, Inc. v. FCC, 497 Us 547, 630, 111 L Ed 2d
445, 110 S Ct 2997 (1990) (O' Connor, J., dissenting).Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

[22b, 23] We are satisfied that the Law School's admissions program does not. Because the Law
School considers "all pertinent elements of diversity," it can (and does) select non-
minority applicants who have greater potential to enhance student body diversity over
underrepresented minority applicants. See Bakke, supra, at 317, 57 L Ed 2d 750, 98 S Ct 2733
(opinion of Powell, J). As Justice Powell recognized in Bakke, so long as a race-conscious
admissions program uses race as a "plus" factor in the context of individualized consideration, a
rejected applicant "will not have been foreclosed from all consideration for that seat simply because
he was not the right color or had the wrong surname ...... His qualifications would have been
weighed fairly and competitively, and he would have no basis to complain of unequal treatment
under the Fourteenth Amendment." 438 US, at 318, 57 L Ed 2d 750, 98 S Ct 2733.
[13f, 22C] We agree that, in the context of its individualized inquiry into the possible diversity
contributions of all applicants, the Law School's race-conscious admissions program does not
unduly harm nonminority applicants.
[24, 25a, 26] We are mindful, however, that "[a] core purpose of the Fourteenth Amendment was to
do away with all governmentally imposed discrimination based on race"
Palmore v Sidoti, [539 US 342] 466 US 429, 432, 80 L Ed 2d, 421, 104 s Ct 1879
(1984). Accordingly, race-conscious admissions policies must be limited in time. This
requirement reflects that racial classifications, however, compelling their goals are
potentially so dangerous that they may be employed no more broadly than the
interest demands. Enshrining a permanent justification for racial preferences would
offend this fundamental equal protection principle. We see no reason to exempt
race-conscious admissions programs from the requirement that all governmental use
of race must have a logical end point. The Law School, too, concedes that all
"race-conscious programs must have reasonable durational limits." Brief for
Respondent Bollinger et al. 32. [25b] In the context of higher education, the
durational requirement can be met by sunset provisions in race-conscious
admissions policies and periodic reviews to determine whether racial preferences are
still necessary to achieve student body diversity. Universities in California, Florida,
and Washington State, where racial preferences in admissions are prohibited by state
law, are currently engaged in experimenting with a wide variety of alternative
approaches. Universities in other States can and should draw on the most promising
aspects of these race-neutral alternatives as they develop. Cf. United States v. Lopez,
514 US 549, 581, 131 L Ed 2d 626, 115 S Ct 1624 (1995) (Kennedy, J., concurring)
("[T] he States may perform their role as laboratories for experimentation to devise
various solutions where the best solution is far from clear"). The requirement that all
race-conscious admissions programs have a termination point "assure[s] all citizens
that the deviation from the norm of equal treatment of all racial and ethnic groups is
a temporary matter, a measure taken in the service of the goal of equality itself."
Richmond v. J.A. Croson Co., 488 US, at 510, 102 L Ed 2d 854, 109 S Ct 706
(plurality opinion); see also Nathanson & Bartnik. The Constitutionality ofAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Preferential Treatment for Minority Applicants to Professional Schools, [539 US 343]
58 Chicago Bar Rec. 282, 293 (May-June 1977) ("It would be a sad day indeed, were
America to become a quota-ridden society, with each identifiable minority assigned
proportional representation in every desirable walk of life. But that is not the
rationale for programs of preferential treatment; the acid test of their justification
will be their efficacy in eliminating the need for any racial or ethnic preferences at
all."
39. The provisions of the American Constitution in United States relating to formal equality concept
do not appear to have operated from the beginning of the American Constitution.
40. Although even under the 1919 and 1935 Government of India Acts the rights of certain class of
people like Scheduled Castes, Scheduled Tribes and the deprived classes have been recognized, in
America, the rights have been conferred on individuals and so much on the groups. The freedoms
contemplated by the Indian Constitution originally related to seven categories which presently stand
at six after the property rights were deleted. The stand of Mr. Vahanvati and Mr. Gopal
Subramanium is that the logic of strict scrutiny, compelling the Government and narrow tailoring
do not have relevance so far as the present case is concerned.
41. In Thomas's case (supra) it was clearly noticed by this Court that American conditions do not
apply adequately for the Indian scenario. Unlike U.S.A., the targeted beneficiaries are alien to our
Constitution. In India cognizance has been taken constitutionally. The victims of untouchability,
identifying social and economic backwardness have been accepted as permissible measures.
However, the question how long they can be continued is another aspect which shall be dealt with
separately. Rationality in that sense is a measure for the special provisions. But the question that
still needs to be addressed is whether these groups are really identifiable.
While formulating the policy all factors need not be specifically expressed but there must be some
criteria to identify social and educational backwardness.
42. In A.K. Roy v. Union of India (1982 (1) SCC 271) it was noted as follows:
"8. We are not, as we cannot be, unmindful of the danger to people's liberties which
comes in any community from what is called the tyranny of the majority.
Uncontrolled power in the executive is a great enemy of freedom and therefore,
eternal vigilance is necessary in the realm of liberty. But we cannot transplant, in the
Indian context and conditions, principles which took birth in other soils, without a
careful examination of their relevance to the interpretation of our Constitution. No
two Constitutions are alike, for it is not mere words that make a Constitution. It is the
history of a people which lends colour and meaning to its Constitution. We must
therefore turn inevitably to the historical origin of the ordinance making power
conferred by our Constitution and consider the scope of that power in the light of the
restraints by which that power is hedged. Neither in England nor in the United States
of America does the executive enjoy anything like the power to issue ordinances. InAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

India, that power has a historical origin and the executive, at all times, has resorted to
it freely as and when it considered it necessary to do so. One of the larger States in
India has manifested its addiction to that power by making an overgenerous use of it
- so generous indeed, that ordinances which lapsed by efflux of time were renewed
successively by a chain of kindred creatures, one after another. And, the ordinances
embrace everything under the sun, from Prince to pauper and crimes to contracts.
The Union Government too, so we are informed passed about 200 Ordinances
between 1960 and 1980, out of which 19 were passed in 1980".
43. One of the grey areas focused by learned counsel for the petitioners and the respondents is the
ever perplexing question "how long". The respondents say that so long as the problems of
backwardness exist they can be continued. The petitioners have highlighted that notwithstanding
the concerns shown in Indra Sawhney No.1 and in a large number of cases that the reservations are
not meant to be a permanent feature there is a case for concern. Admittedly, there is no deletion
from the list of other backward classes. It goes on increasing. Learned counsel for the respondents
have stated that in large number of cases where applications were made for inclusion they have been
turned down. But that is no answer to the question as to why and how there has been no exclusion.
Is it that backwardness has increased instead of decreasing. If the answer is `yes', as contended by
the respondents, then one is bound to raise eyebrows as to the effectiveness of providing
reservations or quotas.
44. The ultimate object is to bring those who are disadvantaged to a level where they no longer
continue to be dis-advantaged. It needs no emphasis that individual rights are superior to the social
rights. All fundamental rights are to be read together. The inequalities are to be removed. Yet the
fact that there has been no exclusion raises a doubt about the real concern to remove inequality.
45. The ultimate objective is to bring people to a particular level so that there can be equality of
opportunity. In that context, one has to keep in view the justice and redress principles. There should
not be mere equality in law but equality in fact.
46. The necessary ingredients of equality essentially involve equalization of unequals. Linked with
this question the problem posed by the petitioners is whether reservation is the only way to equalize
unequals? There are several methods and modes. If reservation really does not work as contended
by the petitioners, then the alternative methods can be adopted. It is the stand of the respondents
that not only reservations but other incentives like free lodging and boarding facilities have been
provided in some States.
47. Learned counsel for the respondents have stated that the measures under challenge are nothing
but a much needed leap towards attainment of the objectives. If it is true, the leap has to end
somewhere. It cannot hang in the air as there is nothing immortal in this world; much less, a
progressive measure purportedly intended to benefit the other backward classes. If after nearly six
decades the objectives have not been achieved, necessarily the need for its continuance warrants
deliberations. It is to be noted that some of the provisions were intended to be replaced after a
decade but have continued. It indirectly shows that backwardness appears to have purportedlyAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

increased and not diminished. It would therefore be rational and logical to restrict operation of the
impugned Statute for a period of 10 years from its inception.
48. At this juncture, report of the Oversight Committee throws considerable light on the
controversy. Some parts of the Report need to be noted.
This report seeks to expand the provision of Higher Education while at the same time ensuring
social inclusion and academic excellence. A society which excludes a significant section of its
population from access to higher education cannot be said to be providing equality of opportunity.
Equally, if academic excellence gets compromised in the process of expansion, it would lose its
competitive edge in the emerging knowledge society - an edge which can propel India into a position
of global leadership.
Page X and XI of the report A simpler way of implementing reservations was to steamroll our way
through, in the name of social equity, regardless of its impact on quality and excellence. We have
deliberately chosen the more difficult way which delivers equity in a manner that enhances
excellence i.e. by making concomitant investments in faculty & infrastructure and by bringing much
needed governance related reforms involving institutional, financial and administrative autonomy
and process re-engineering in our Higher Educational Governance system. It is easy to equalize by
"mindlessly leveling everyone down to lowest common-denominator". Our effort has been to create
an upward moving equalization process- where the disabilities are overcome by the erstwhile
excluded sections and the system brings out the best in them.
Besides the many out of the box innovative ideas concerning faculty and infrastructure related
issues, I believe three of our recommendations, which cut horizontally across the five groups, are
critical to the establishment of the goal of an "inclusive society, in pursuit of excellence". These four
programmes are considered by the Oversight Committee to be integral to the above vision and
should be considered to be inseverable part of our core recommendations. (page-x) We have to
acknowledge that the challenges facing us in the entire education sector are enormous and in the
Tertiary Education Sector these can be met, only if both public and private funding to educational
institutions increased several fold. The need for private participation in this mammoth task cannot
be over-emphasized but market forces themselves cannot deliver justice. The relative importance of
public vs. private funding is brought out very strongly by Joseph Stiglitz when he opined "I had
studied the failures of both markets and governments, and was not so naove to think that the
government could remedy every failure. Neither was I so foolish as to believe that markets by
themselves solved every societal problem. Inequality, unemployment, pollution: these are all
important issues in which Government has to take an importance role."
"Expansion, Inclusion and Excellence" has been our credo. They have remained the
abiding theme guiding all our deliberations. I will be failing in my duty if the
Oversight Committee does not acknowledge the source of inspiration for our
deliberations. It is the Prime Minister's speech giving the overpowering vision of the
"need to create the second wave of nation building" which has inspired us in our
thoughts and deliberations. I would also like to express my gratitude to Hon'ble HRDAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Minister, Sri Arjun Singhji for his affection and guidance right through. (Page-xi)
Treatment of the creamy Layer (Chapter IV- Report of Oversight Committee Vol.-I)
4.2 (b) The true benefit of reservations will be realized only when the high school
enrolment of OBCs, especially in rural areas, increases significantly. Attention will
need to be paid to this issue in the coming years.
Chapter VI- Estimate of Resources required for the expansion 6.1 In overall terms,
the total estimated expenditure on the expansion has now been assessed by the five
Sub-Groups in their final reports at Rs.18,197.83 crore, as compared to the amount of
Rs.16,563.34 crore, that was included by the Oversight Committee in its interim
report. The summary statement of additional student strength, faculty required and
estimates of recurring and non-recurring expenditure that have been projected by the
Groups are as at Table 6.1 and the year-wise break up is at table 6.2.
6.3 The Committee in its discussions with the individual Groups, had stressed the
need to estimate the additional infrastructure and manpower that would be required
after taking into account the slack, if any, in the existing facilities as also the scope for
using IT as a resource multiplier. While the Groups seems to have accepted this in
principle, their expenditure projections, and the norms on which they are based
seems to have just extrapolated past trends. The Committee has had some input
regarding global trends and the best practices being followed in the world's leading
institutions. Based on this, and in consultation with experts, the Committee has
developed a plan for a "Gyan Vahini" project, as has been explained in an earlier
Chapter in this report. The total expenditure on this component of the expansion and
upgradation project would be Rs.1752 crore in 5 years. Apart from significantly
enhancing the quality of instruction and learning, and brining it close to the best
levels in the world, this investment will certainly contribute to efficiency and to
reducing the conventional costs of the higher education system.
Summary Statement of Expenditure Requirements (As given in the Final Reports of
the Groups) Sector No. of Existin Annual Addl. Non Recu Total Instns g Addl. Facility
Recurrin rring Exp.
          .          Student  Studen          Require      g Ex.         Exp.        In   5 
                     Intake      t Intake     d                          (5Yrs)      Yrs.
Agricu    5          825         454          187          102.75        92.71       195.4
Centr     17         92011       49689        6609         2702.11       2455.       5158.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Univer
sities
Manag     7          1791        966          139          511.32        177.        688. 
Medic     11         993         565          N.A.         1783.98       1027.       2811.
Engin     38         29671       16440        4919         5503.83       3840.       9343.
Grand                125291      68114        11854        10603.99      7593.       1819
                                                                         84          7.83
Total
Chapter VII- The Way Forward
7.1            As indicated  earlier  in  this report,  this opportunity 
for expansion, inclusion and excellence should only be the beginning of a larger
process, which is to build a knowledge society in India and allow the country to take
its rightful place in the comity of nations. Our recent economic growth and the values
of knowledge and education carried forward by a billion diverse people, point to
India's potential future as a knowledge society. Other countries that visualize a
similar future have planned massive investments in order to enhance both the quality
and quantity of higher education and research. China, for example, has madeAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

substantial increase in its allocation of resources of higher education. In the first
phase, China has provided a grant of US $ 125 million to each of the 10 leading
universities and US $ 225 million to Beijing and Tsinghua Universities. In the second
phase, China proposes to provide additional grants to 30 universities, with the
objective of having 100 high quality universities in China in the 21st century and with
15% of the citizens in the age group 18-22 receiving tertiary education.
7.2 India has suffered in the past because of severe under investment in higher
education. This has been caused partly by the thinking that looks at primary and
higher education in an either or manner. It is very clear however that large public
investment is needed in both sectors. As Prime Minister Dr. Manmohan Singh said,
while launching the Knowledge Commission, "At the bottom of the knowledge
pyramid, the challenge is one of improving access to primary education. At the top of
the pyramid there is need to make our institutions of higher education and research
world class. The time has come for India to embark on a second wave of nation
building. Denied this investment, the youth will become a social and economic
liability.
49. It was emphasized by learned counsel for the petitioners that the massive financial burden
question finds no place in the parliamentary debate. In response, Mr. Vahanvati has submitted that
before the Parliamentary Standing Committee, the report of the Oversight Committee was available.
When the Oversight Committee's report was discussed in detail, needless to say the financial aspect
was also considered.
50. It has been highlighted by Mr. P.P. Rao that unmindful of the duty to focus on primary and
elementary education, large sums of money are intended to be used for implementation of Statute.
Various figures and datas have been highlighted to show that there is really no concern for the
primary and elementary education. Repelling these contentions Mr. Vahanvati has highlighted that
there is no laxity so far as primary and elementary education is concerned. He has referred to
voluminous details relating to Sarva Shiksha Abhiyan. It is contended that uniform policy of
elementary education and the progress made upto 31.3.2007 shows the concern of the Government
to translate into reality the constitutional objective of providing adequate education to all citizens. It
is true that there has been considerable effort in this regard. But one question still remains to be
answered.
There has to be balancing of priorities. Mr. Vahanvati has said that this balancing is prerogative of
the Government. It is true that Government has a large area of discretion in choosing its priorities.
But one factor cannot be lost sight of. The fundamental stress has to be on elementary education. If
that is done, as a consequence there would be reduction in the need for spending more money on
higher education. Stress on primary and elementary education would be a leap forward towards
higher education. There has been considerable number of drop outs in the higher classes. This is a
reality in spite of all steps which the Government claims to have adopted to ensure that every child
of a particular age group has education as warranted by the Constitution as a fundamental right.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

51. Unni Krishnan, J.P. and Ors. v. State of A.P. and Ors.
(1993 (1) SCC 645) emphasized on the importance of education in the following words:
"166. In Bandhua Mukti Morcha this Court held that the right to life guaranteed by
Article 21 does take in "educational facilities". (The relevant portion has been quoted
herein before). Having regard to the fundamental significance of education to the life
of, an individual and the nation, and adopting the reasoning and logic adopted in the
earlier decisions of this Court referred to herein before, we hold, agreeing with the
statement in Bandhua Mukti Morcha, that right to education is implicit in and flows
from the right to life guaranteed by Article 21. That the right to education has been
treated as one of transcendental importance in the life of an individual has been
recognised not only in this country since thousands of years, but all over the world. In
Mohini Jain, the impatience of education has been duly and rightly stressed. The
relevant observations have already been set out in para 7 herein before. In particular,
we agree with the observation that without education being provided to the citizens of
this country, the objectives set forth in the Preamble to the Constitution cannot be
achieved. The Constitution would fail. We do not think that the importance of
education could have been better emphasised than in the above words. The
importance of education was emphasised in the "Neethishatakam' by Bhartruhari
(First Century B.C. in the following words:
Translation:
Education is the special manifestation of man; Education is the treasure which can be
preserved without the fear of loss; Education secures material pleasure, happiness
and fame;
Education            is         the         teacher           of              the         teacher;
Education                        is                    God                           incarnate;
Education secures honour at the hands of the State, not money.
A man without education is equal to animal.
168. In Brown v. Board of Education (347 US 483 (1954) Earl Warren, C.J., speaking
for the U.S. Supreme Court emphasized the right to education in the following words:
"Today, education is perhaps the most important function of State and local
governments...It is required in the performance of our most basic responsibilities,
even service in the armed forces. It is the very foundation of good citizenship. Today
it is the principal instrument in awakening the child to cultural values, in preparing
him for later professional training, and in helping him to adjust normally to hisAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

environment. In these days, it is doubtful any child may reasonably be expected to
succeed in life if he is denied the opportunity of an education."
52. Observations of this Court in AIIMS Students' Union case (supra) highlight the importance of
higher education and the modalities to be adopted for ensuring excellence are in the following
words:
"58. The Preamble to the Constitution of India secures, as one of its objects, fraternity
assuring the dignity of the individual and the unity and integrity of the nation to 'we
he people of India'. Reservation unless protected by the constitution itself, as given to
us by the founding fathers and as adopted by the people of India, is sub-version of
fraternity, unity and integrity and dignity of the individual. While dealing with
Directive Principles of State Policy, Article 46 is taken note of often by overlooking
Articles 41 and 47. Article 41 obliges the State inter alia to make effective provision
for securing the right to work and right to education. Any reservation in favour of
one, to the extent of reservation, is an inroad on the right of others to work and to
learn. Article 47 recognises the improvement of public health as one of the primary
duties of the State. Public health can be improved by having the best of doctors,
specialists and super specialists. Under-graduate level is a primary or basic level of
education in medical sciences wherein reservation can be understood as the
fulfilment of societal obligation of the State towards the weaker segments of the
society. Beyond this, a reservation is a reversion or diversion from the performance of
primary duty of the State. Permissible reservation at the lowest or primary rung is a
step in the direction of assimilating the lesser fortunates in mainstream of society by
bringing them to the level of others which they cannot achieve unless protectively
pushed. Once that is done the protection needs to be withdrawn in the own interest of
protectees so that they develop strength and feel confident of stepping on higher
rungs on their own legs shedding the crutches. Pushing the protection of reservation
beyond the primary level betrays bigwigs' desire to keep the crippled crippled for
ever. Rabindra Nath Tagore's vision of a free India cannot be complete unless
"knowledge is free" and "tireless striving stretches its arms towards perfection".
Almost a quarter century after the people of India have given the Constitution unto
themselves, a chapter on fundamental duties came to be incorporated in the
Constitution. Fundamental duties, as defined in Article 51A, are not made
enforceable by a writ of court just as the fundamental rights are, but it cannot be lost
sight of that 'duties' in Part IVA - Article 51A are prefixed by the same word
'fundamental' which was prefixed by the founding fathers of the Constitution to
'rights' in Part III. Every citizen of India is fundamentally obliged to develop the
scientific temper and humanism. He is fundamentally duty bound to strive towards
excellence in all spheres of individual and collective activity so that the nation
constantly rises to higher levels of endeavour and achievements. State is, all the
citizens placed together and hence though Article 51A does not expressly cast any
fundamental duty on the State, the fact remains that the duty of every citizen of India
is the collective duty of the Sate. Any reservation, apart from being sustainable on theAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

constitutional anvil, must also be reasonable to be permissible. In assessing the
reasonability one of the factors to be taken into consideration would be -- whether
the character and quantum of reservation would stall or accelerate achieving the
ultimate goal of excellence enabling the nation constantly rising to higher levels. In
the era of globalisation, where the nation as a whole has to compete with other
nations of the world so as to survive, excellence cannot be given an unreasonable go
by and certainly not compromised in its entirety. Fundamental duties, though not
enforceable by a writ of the court, yet provide a valuable guide and aid to
interpretation of constitutional and legal issues. In case of doubt or choice, people's
wish as manifested through Article 51A, can serve as a guide not only for resolving the
issue but also for constructing or moulding the relief to be given by the courts.
Constitutional enactment of fundamental duties, if it has to have any meaning, must
be used by courts as a tool to tab, even a taboo, on State action drifting away from
constitutional values".
53. Respondents have vehemently contended that the concept of creamy layer may have relevance
for the purpose of Article 16(4), but is really inconsequential so far as Articles 15(4) and 15(5) are
concerned. It is submitted that Article 16(4) is relatable to inadequate representation in Government
services and in that context the well to do in the socially and educationally backward classes have to
be excluded in view of the decisions of this Court. But that logic cannot apply to the present dispute
which relates to admissions to educational institutions. Before considering the question as to the
desirability of excluding `creamy layer' the concept of creamy layer needs to be focused upon.
Observations of this Court in various cases on this concept need to be noted.
54. In N.M. Thomas's case (supra) at page 363, it was inter alia observed as follows :
"124. A word of sociological caution. In the light of experience, here and elsewhere,
the danger of "reservation", it seems to me, is threefold. Its benefits, by and large, are
snatched away by the top creamy layer of the "backward" caste or class, thus keeping
the weakest among the weak always weak and leaving the fortunate layers to
consume the whole cake. Secondly, this claim is overplayed extravagantly in
democracy by large and vocal groups whose burden of backwardness has been
substantially lightened by the march of time and measures of better education and
more opportunities of employment, but wish to wear the "weaker section" label as a
means to score over their near-equals formally categorised as the upper brackets.
Lastly, a lasting solution to the problem comes only from improvement of social
environment, added educational facilities and cross-fertilisation of castes by
inter-caste and inter-class marriages sponsored as a massive State programme, and
this solution is calculatedly hidden from view by the higher "backward" groups with a
vested interest in the plums of backwardism. But social science research, not judicial
impressionism, will alone tell the whole truth and a constant process of objective
re-evaluation of progress registered by the "underdog" categories is essential lest a
once deserving "reservation" should be degraded into "reverse discrimination".
Innovations in administrative strategy to help the really untouched, most backwardAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

classes also emerge from such socio-legal studies and audit exercises, if
dispassionately made. In fact, research conducted by the A.N. Sinha Institute of
Social Studies, Patna, has revealed a dual society among harijans, a tiny elite gobbling
up the benefits and the darker layers sleeping distances away from the special
concessions. For them, Articles 46 and 335 remain a "noble romance", the bonanza
going to the "higher" harijans. I mention this in the present case because lower
division clerks are likely to be drawn from the lowest levels of harijan humanity and
promotion prospects being accelerated by withdrawing, for a time, "test"
qualifications for this category may perhaps delve deeper. An equalitarian
breakthrough in a hierarchical structure has to use many weapons and Rule 13/AA
perhaps is one.
Xx xx xx
139. It is platitudinous constitutional law that Articles 14 to 16 are a common code of
guaranteed equality, the first laying down the broad doctrine, the other two applying
it to sensitive areas historically important and politically polemical in a climate of
communalism and jobbery.
55. In Vasant Kumar's case (supra) at page 732 the view was re-iterated in the following words :
"24. In order to appreciate the view point advanced by Mr Desai which appeals to me
both for its indepth study of the problem, and a fresh outlook on this vexed problem,
at the outset let me take a look at the futuristic view of the Indian Society as
envisaged in the Constitution. No one is left in any doubt that the future Indian
Society was to be casteless and classless. Pandit Jawaharlal Nehru the first Prime
Minister of India said that Mahatma Gandhi has shaken the foundations of caste and
the masses have been powerfully affected. But an even greater power than Gandhi is
at work, the conditions of modern life -- and it seems at last this hoary and tenacious
ralic of past times must die. Mahatma Gandhi, the Father of the Nation said, "The
caste system as we know is an anachronism. It must go if both Hinduism and India
are to live and grow from day to day". In its onward march towards realising the
constitutional goal, every attempt has to be made to destroy caste stratification.
Article 38(2) enjoins the State to strive to minimise the inequality in income and
endeavour to eliminate inequalities in status, facilities and opportunities, not only
amongst individuals but also amongst groups of people residing in different areas or
engaged in different vocations. Article 46 enjoins duty to promote with special care
the educational and economic interests of the weaker sections of the people, and in
particular of the Scheduled Castes and Scheduled Tribes, and shall protect them from
social injustice and all forms of exploitation. Continued retention of the division of
the society into various castes simultaneously introduces inequality of status. And
this inequality in status is largely responsible for retaining inequality in facilities and
opportunities, ultimately resulting in bringing into existence an economically
depressed class for transcending caste structure and caste barrier. The societyAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

therefore was to be classless casteless society. In order to set up such a society, steps
have to be taken to weaken and progressively eliminate caste structure.
Unfortunately, the movement is in the reverse gear. Caste stratification has become
more rigid to some extent, and where concessions and preferred treatment schemes
are introduced for economically disadvantaged classes, identifiable by caste label, the
caste structure unfortunately received a fresh lease of life. In fact there is a mad rush
for being recognized as belonging to a caste which by its nomenclature would be
included in the list of socially and educationally backward classes. To illustrate:
Bakshi Commission in Gujarat recognized as many as 82 castes as being socially and
educationally backward. On the publication of its report, Government of Gujarat
received representations by members of those castes who had not made any
representation to the Bakshi Commission for treating them as socially and
educationally backward. This phenomenon was noticed by Mandal Commission when
it observed: "Whereas the Commission has tried to make the State-wise lists of OBCs
as comprehensive as possible, it is quite likely that several synonymy of the castes
listed as backward have been left out. Certain castes are known by a number of
synonymy which vary from one region to the other and their complete coverage is
almost impossible". Mandal Commission found a way out by recommending that if a
particular caste has been listed as backward then all its synonyms whether mentioned
in the State lists or not should also be treated as backward. Gujarat Government was
forced to appoint a second commission known as Rane Commission. Rane
Commission took note of the fact that there was an organised effort for being
considered socially and educationally backward castes. Rane Commission recalled
the observations in Balaji case that "Social backwardness is on the ultimate analysis
the result of poverty to a very large extent". The Commission noticed that some of the
castes just for the sake of being considered as socially and educationally backward,
have degraded themselves to such an extent that, they had no hesitation in
attributing different types of vices to and associating other factors indicative of
backwardness, with their castes. The Commission noted that the malaise requires to
be remedied. The Commission therefore, devised a method for determining socially
and educationally backward classes without reference to caste, beneficial to all
sections of people irrespective of the caste to which they belong. The Commission
came to an irrefutable conclusion that amongst certain castes and communities or
class of people, only lower income groups amongst them are socially and
educationally backward. We may recall here a trite observation in case of N.M.
Thomas which reads as under
(SCC pg.363 para 124):
"A word of sociological caution. In the light of experience, here and elsewhere, the
danger of `reservation', it seems to me, is threefold. Its benefits, by and large, are
snatched away by the top creamy layer of the `backward' caste or class, thus keeping
the weakest among the weak always weak and leaving the fortunate layers to
consume the whole cake. Secondly, this claim is overplayed extravagantly inAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

democracy by large and vocal groups whose burden of backwardness has been
substantially lightened by the march of time and measures of better education and
more opportunities of employment, but wish to wear the `weaker section' label as a
means to score over their near-equals formally categorised as the upper brackets."
25. A few other aspects for rejecting caste as the basis for identifying social and educational
backwardness may be briefly noted. If State patronage for preferred treatment accepts caste as the
only insignia for determining social and educational backwardness, the danger looms large that this
approach alone would legitimise and perpetuate caste system.
It does not go well with our proclaimed secular character as enshrined in the Preamble to the
Constitution. The assumption that all members of same caste a re equally socially and educationally
backward is not well-founded. Such an approach provides an over-simplification of a complex
problem of identifying the social and educational backwardness. The Chairman of the Backward
Classes Commission, set up in 1953, after having finalised the report, concluded that "it would have
been better if we could determine the criteria of backwardness on principles other than caste".
Lastly it is recognised without dissent that the caste based reservation has been usurped by the
economically well-placed section in the same caste. To illustrate, it may be pointed that some years
ago, I came across a petition for special leave against the decision of the Punjab and Haryana High
Court in which the reservation of 2= per cent for admission to medical and engineering colleges in
favour of Majhabi Sikhs was challenged by none other than the upper crust of the members of the
Scheduled castes amongst Sikhs in Punjab, proving that the labeled weak exploits the really weaker.
Add to this, the findings of the Research Planning Scheme of sociologists assisting the Mandal
Commission when it observed: "while determining the criteria of socially and educationally
backward classes, social backwardness should be considered to be the critical element and
educational backwardness to be the linked element though not necessarily derived from the former".
The team ultimately concluded that "social backwardness refers to ascribed status, and it considered
social backwardness as the critical element and educational backwardness to be the linked though
not derived element". The attempt is to identify socially and educationally backward classes of
citizens. The caste, as is understood in Hindu Society, is unknown to Muslims, Christians, Parsis,
Jews etc. Caste criterion would not furnish a reliable yardstick to identify socially and educationally
backward group in the aforementioned communities though economic backwardness would.
28. Reservation in one or other form has been there for decades. If a survey is made with reference
to families in various castes considered to be socially and educationally backward, about the benefits
of preferred treatment, it would unmistakably show that the benefits of reservations are snatched
away by the top creamy layer of the backward castes. This has to be avoided at any cost.
56. Significantly in Indra Sawhney No.1 it was emphatically noted as follows:
"520. Society does not remain static. The industrialisation and the urbanisation
which necessarily followed in its wake, the advance on political, social and economic
fronts made particularly after the commencement of the Constitution, the social
reform movements of the last several decades, the spread of education and theAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

advantages of the special provisions including reservations secured so far, have all
undoubtedly seen at least some individuals and families in the backward classes,
however small in number, gaining sufficient means to develop their capacities to
compete with others in every field. That is an undeniable fact. Legally, therefore, they
are not entitled to be any longer called as part of the backward classes whatever their
original birthmark. It can further hardly be argued that once a backward class, always
a backward class. That would defeat the very purpose of the special provisions made
in the Constitution for the advancement of the backward classes, and for enabling
them to come to the level of and to compete with the forward classes, as equal
citizens. On the other hand, to continue to confer upon such advanced sections from
the backward classes the special benefits, would amount to treating equals unequally
violating the equality provisions of the Constitution. Secondly, to rank them with the
rest of the backward classes would equally violate the right to equality of the rest in
those classes, since it would amount to treating the unequals equally. What is more, it
will lead to perverting the objectives of the special constitutional provisions since the
forwards among the backward classes will thereby be enabled to lap up all the special
benefits to the exclusion and at the cost of the rest in those classes, thus keeping the
rest in perpetual backwardness. The object of the special constitutional provisions is
not to uplift a few individuals and families in the backward classes but to ensure the
advancement of the backward classes as a whole. Hence, taking out the forwards
from among the backward classes is not only permissible but obligatory under the
Constitution. However, it is necessary to add that just as the backwardness of the
backward groups cannot be measured in terms of the forwardness of the forward
groups, so also the forwardness of the forwards among the backward classes cannot
be measured in terms of the backwardness of the backward sections of the said
classes. It has to be judged on the basis of the social capacities gained by them to
compete with the forward classes. So long as the individuals belonging to the
backward classes do not develop sufficient capacities of their own to compete with
others, they can hardly be classified as forward.
xx xx xx
629. More backward and backward is an illusion. No constitutional exercise is called
for it. What is required is practical approach to the problem. The collectivity or the
group may be backward class but the individuals from that class may have achieved
the social status or economic affluence. Disentitle them from claiming reservation.
Therefore, while reserving posts for backward classes, the departments should make
a condition precedent that every candidate must disclose the annual income of the
parents beyond which one could not be considered to be backward. What should be
that limit can be determined by the appropriate State. Income apart, provision
should be made that wards of those backward classes of persons who have achieved a
particular status in society either political or social or economic or if their parents are
in higher services then such individuals should be precluded to avoid monopolisation
of the services reserved for backward classes by a few. Creamy layer, thus, shall standAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

eliminated. And once a group or collectivity itself is found to have achieved the
constitutional objective then it should be excluded from the list of backward class.
Therefore, (1) No reservation can be made on economic criteria. (2) It may be under
Article 16(4) if such class satisfies the test of inadequate representation.
(3) Exclusion of creamy layer is a social purpose. Any legislative or executive action to
remove such persons individually or collectively cannot be constitutionally invalid.
Xx xx xx
790. `Means-test' in this discussion signifies imposition of an income limit, for the
purpose of excluding persons (from the backward class) whose income is above the
said limit. This submission is very often referred to as the "creamy layer"
argument. Petitioners submit that some members of the designated backward classes are highly
advanced socially as well as economically and educationally. It is submitted that they constitute the
forward section of that particular backward class -- as forward as any other forward class member --
and that they are lapping up all the benefits of reservations meant for that class, without allowing
the benefits to reach the truly backward members of that class. These persons are by no means
backward and with them a class cannot be treated as backward. It is pointed out that since Jayasree
almost every decision has accepted the validity of this submission.
791. On the other hand, the learned counsel for the States of Bihar, Tamil Nadu, Kerala and other
counsel for respondents strongly oppose any such distinction. It is submitted that once a class is
identified as a backward class after applying the relevant criteria including the economic one, it is
not permissible to apply the economic criteria once again and sub-
divide a backward class into two sub-categories. Counsel for the State of Tamil Nadu submitted
further that at one stage (in July 1979) the State o f Tamil Nadu did indeed prescribe such an income
limit but had to delete it in view of the practical difficulties encountered and also in view of the
representations received. In this behalf, the learned counsel invited our attention to Chapter 7-H
(pages 60 to 62) of the Ambashankar Commission (Tamil Nadu Second Backward Classes
Commission) Report. According to the respondents the argument of `creamy layer' is but a mere
ruse, a trick, to deprive the backward classes of the benefit of reservations. It is submitted that no
member of backward class has come forward with this plea and that it ill becomes the members of
forward classes to raise this point. Strong reliance is placed upon the observations of Chinnappa
Reddy, J in Vasanth kumar to the following effect (SCC p.763, para 72) " .. .. One must, however,
enter a caveat to the criticism that the benefits of reservation are often snatched away by the top
creamy layer of backward class or caste. That a few of the seats and posts reserved for backward
classes are snatched away by the more fortunate among them is not to say that reservation is not
necessary. This is bound to happen in a competitive society such as ours. Are not the unreserved
seats and posts snatched away, in the same way, by the top creamy layer of society itself? Seats
reserved for the backward classes are taken away by the top layers amongst them on the same
principle of merit on which the unreserved seats are taken away by the top layers of society. HowAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

can it be bad if reserved seats and posts are snatched away by the creamy layer of backward classes,
if such snatching away of unreserved posts by the top creamy layer of society itself is not bad?"
792. In our opinion, it is not a question of permissibility or desirability of such test but one of proper
and more appropriate identification of a class -- a backward class. The very concept of a class
denotes a number of persons having certain common traits which distinguish them from the others.
In a backward class under clause (4) of Article 16, if the connecting link is the social backwardness,
it should broadly be the same in a given class. If some of the members are far too advanced socially
(which in the context, necessarily means economically and, may also mean educationally) the
connecting thread between them and the remaining class snaps. They would be misfits in the class.
After excluding them alone, would the class be a compact class. In fact, such exclusion benefits the
truly backward. Difficulty, however, really lies in drawing the line -- how and where to draw the
line? For, while drawing the line, it should be ensured that it does not result in taking away with one
hand what is given by the other. The basis of exclusion should not merely be economic, unless, of
course, the economic advancement is so high that it necessarily means social advancement. Let us
illustrate the point. A member of backward class, say a member of carpenter caste, goes to Middle
East and works there as a carpenter. If you take his annual income in rupees, it would be fairly high
from the Indian standard. Is he to be excluded from the Backward Class? Are his children in India to
be deprived of the benefit of Article 16(4)? Situation may, however, be different, if he rises so high
economically as to become -- say a factory owner himself. In such a situation, his social status also
rises. He himself would be in a position to provide employment to others. In such a case, his income
is merely a measure of his social status. Even otherwise there are several practical difficulties too in
imposing an income ceiling. For example, annual income of Rs.36,000 may not count for much in a
city like Bombay, Delhi or Calcutta whereas it may be a handsome income in rural India anywhere.
The line to be drawn must be a realistic one.
Another question would be, should such a line be uniform for the entire country or a given State or
should it differ from rural to urban areas and so on. Further, income from agriculture may be
difficult to assess and, therefore, in the case of agriculturists, the line may have to be drawn with
reference to the extent of holding. While the income of a person can be taken as a measure of his
social advancement, the limit to be prescribed should not be such as to result in taking away with
one hand what is given with the other. The income limit must be such as to mean and signify social
advancement. At the same time, it must be recognised that there are certain positions, the occupants
of which can be treated as socially advanced without any further enquiry. For example, if a member
of a designated backward class becomes a member of IAS or IPS or any other All India Service, his
status is society (social status) rises; he is no longer socially disadvantaged. His children get full
opportunity to realize their potential. They are in no way handicapped in the race of life.
793. Keeping in mind all these considerations, we direct the Government of India to specify the basis
of exclusion --
whether on the basis of income, extent of holding or otherwiseAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

-- of `creamy layer'. This shall be done as early as possible, but not exceeding four months. On such
specification persons falling within the net of exclusionary rule shall cease to be the members of the
Other Backward Classes (covered by the expression `backward class of citizens') for the purpose of
Article 16(4). The impugned Office Memorandums dated August 13, 1990 and September 25, 1991
shall be implemented subject only to such specification and exclusion of socially advanced persons
from the backward classes contemplated by the said O.M. In other words, after the expiry of four
months from today, the implementation of the said O.M. shall be subject to the exclusion of the
`creamy layer' in accordance with the criteria to be specified by the Government of India and not
otherwise".
57. In Indra Sawhney v. Union of India (1996) 6 SCC 506) at page 508) it was noted as follows :
"3. Thereafter the matter again came up before the Court on 20-3-1995. Finding that
the State of Kerala has not taken any steps, this Court issued notice to show cause
why action should not be taken for non-compliance of this Court's order. Again the
matter came up on 10-7-1995. Even on that date no report of compliance was
submitted to the Court; instead an affidavit sworn to by the Chief Secretary to the
State was handed over explaining the circumstances why the implementation of the
judgment was delayed.
xx xx xx
5. In the circumstances, out of sheer exhaustion and having regard to the fact that the
constitutionality of the Kerala Act 16 of 1995 is pending disposal before this Court, we
have decided to get the information ourselves regarding "creamy layer" issue through
a High Level Committee.
6. Accordingly, we request the learned Chief Justice of the Kerala High Court to
appoint a retired Judge of the High Court to be the Chairman of the High Level
Committee who will induct not more than 4 members from various walks of life to
identify the "creamy layer" among "the designated other backward classes" in Kerala
State in the light of the ruling of this Court in Mandal case and forward the report to
this Court within 3 months from the date of receipt of this order."
58. In Indra Sawhney No. 2 it was observed as follows:
"7. Our Constitution is wedded to the concept of equality and equality is a basic
feature. Under Article 15(2), there is a prohibition that the State shall not
discriminate against any citizen on the grounds only of religion, race, caste, sex and
place of birth or any of them. It is equally true that ours is a caste-ridden society. Still,
it is a constitutional mandate not to discriminate on the basis of caste alone.
Provisions can be made for the upliftment of socially and educationally backward
classes, Scheduled Castes or Scheduled Tribes or for women and children. Article
16(4) empowers the States for making any provision for reservation in appointmentsAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

or posts in favour of any backward class of citizens which, in the opinion of the State,
is not adequately represented in the services under the State. Reservation is
permissible ( i ) in favour of any backward class of citizens; and ( ii ) if it is not
adequately represented in services under the State.
8. Caste only cannot be the basis for reservation. Reservation can be for a backward
class citizen of a particular caste. Therefore, from that caste, the creamy layer and the
non- backward class of citizens are to be excluded. If the caste is to be taken into
consideration then for finding out the socially and economically backward class, the
creamy layer of the caste is to be eliminated for granting benefit of reservation,
because that creamy layer cannot be termed as socially and economically backward.
These questions are exhaustively dealt with by a nine-Judge Bench of this Court in
Indra Sawhney v. Union of India and it has been specially held that "only caste"
cannot be the basis for reservation.
9. Inclusion of castes in the list of backward classes cannot be mechanical and cannot
be done without adequate relevant data. Nor can it be done for extraneous
reasons...... Likewise, periodic examination of a backward class could lead to its
exclusion if it ceases to be socially backward or if it is adequately represented in the
services. Once backward, always backward is not acceptable. In any case, the "creamy
layer" has no place in the reservation system.
10. If forward classes are mechanically included in the list of backward classes or if
the creamy layer among backward classes is not excluded, then the benefits of
reservation will not reach the really backward among the backward classes. Most of
the benefits will then be knocked away by the forward castes and the creamy layer.
That will leave the truly backward, backward forever.
xx xx xx
13. In Indra Sawhney on the question of exclusion of the "creamy layer" from the
backward classes, there was agreement among eight out of the nine learned Judges of
this Court. There were five separate judgments in this behalf which required the
"creamy layer" to be identified and excluded.
xx xx xx
22. As appears from the judgments of six out of the eight Judges, viz. Jeevan Reddy
(for himself and three others), Sawant and Sahai, JJ. -- (i.e. six learned Judges out of
nine),
-- they specifically refer to those in higher services like IAS, IPS and All India Services
or near about as persons who have reached a higher level of social advancement and
economic status and therefore as a matter of law, such persons are declared notAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

entitled to be treated as backward. They are to be treated as creamy layer "without
further inquiry". Likewise, persons living in sufficient affluence who are able to
provide employment to others are to be treated as having reached a higher social
status on account of their affluence, and therefore outside the backward class. Those
holding higher levels of agricultural landholdings or getting income from property,
beyond a limit, have to be excluded from the backward classes. This, in our opinion,
is a judicial "
declaration " made by this Court.
Xx xx xx
27. As the "creamy layer" in the backward class is to be treated "on a par" with the forward classes
and is not entitled to benefits of reservation, it is obvious that if the "creamy layer" is not excluded,
there will be discrimination and violation of Articles 14 and 16(1) inasmuch as equals (forwards and
creamy layer of backward classes) cannot be treated unequally . Again, non-exclusion of creamy
layer will also be violative of Articles 14, 16(1) and 16(4) of the Constitution of India since unequals
(the creamy layer) cannot be treated as equals , that is to say, equal to the rest of the backward class.
These twin aspects of discrimination are specifically elucidated in the judgment of Sawant, J. where
the learned Judge stated as follows: (SCC p. 553, para 520) "To continue to confer upon such
advanced sections special benefits, would amount to treating equals unequally. Secondly, to rank
them with the rest of the backward classes would amount to treating the unequals equally."
Thus, any executive or legislative action refusing to exclude the creamy layer from the benefits of
reservation will be violative of Articles 14 and 16(1) and also of Article 16(4). We shall examine the
validity of Sections 3, 4 and 6 in the light of the above principle.
Xx xx xx
64. The Preamble to the Constitution of India emphasises the principle of equality as basic to our
Constitution. In Kesavananda Bharati v. State of Kerala it was ruled that even constitutional
amendments which offended the basic structure of the Constitution would be ultra vires the basic
structure.
Sikri, C.J. laid stress on the basic features enumerated in the Preamble to the Constitution and said
that there were other basic features too which could be gathered from the constitutional scheme
(para 506-A of SCC). Equality was one of the basic features referred to in the Preamble to our
Constitution. Shelat and Grover, JJ. also referred to the basic rights referred to in the Preamble.
They specifically referred to equality (paras 520 and 535-A of SCC). Hegde and Shelat, JJ.
also referred to the Preamble (paras 648, 652). Ray, J. (as he then was) also did so (para 886).
Jaganmohan Reddy, J. too referred to the Preamble and the equality doctrine (para 1159).Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Khanna, J. accepted this position (para 1471). Mathew, J.
referred to equality as a basic feature (para 1621). Dwivedi, J.
(paras 1882, 1883) and Chandrachud, J. (as he then was) (see para 2086) accepted this position.
65. What we mean to say is that Parliament and the legislature in this country cannot transgress the
basic feature of the Constitution, namely, the principle of equality enshrined in Article 14 of which
Article 16(1) is a facet. Whether the creamy layer is not excluded or whether forward castes get
included in the list of backward classes , the position will be the same, namely, that there will be a
breach not only of Article 14 but of the basic structure of the Constitution. The non-exclusion of the
creamy layer or the inclusion of forward castes in the list of backward classes will, therefore, be
totally illegal. Such an illegality offending the root of the Constitution of India cannot be allowed to
be perpetuated even by constitutional amendment. The Kerala Legislature is, therefore, least
competent to perpetuate such an illegal discrimination. What even Parliament cannot do, the Kerala
Legislature cannot achieve."
59. Though in M. Nagaraj's case (supra) some observations of general nature have been made so far
as the applicability of the principles to Scheduled Castes and Scheduled Tribes are concerned, really
that case did not concern with Scheduled Castes and Scheduled Tribes. Similar is the position here.
The focus on the identity test in M. Nagaraj's case (supra) is unexceptionable. At paras 80 and 110, it
was noted as follows:
"80. Before concluding, we may refer to the judgment of this Court in M.G.
Badappanavar. In that case the facts were as follows. Appellants were general
candidates. They contended that when they and the reserved candidates were
appointed at Level-1 and junior reserved candidates got promoted earlier on the basis
of roster- points to Level-2 and again by way of roster-points to Level-3, and when
the senior general candidate got promoted to Level-3, then the general candidate
would become senior to the reserved candidate at Level-3. At Level-3, the reserved
candidate should have been considered along with the senior general candidate for
promotion to Level-
4. In support of their contention, appellants relied upon the judgment of the
Constitution Bench in Ajit Singh (II). The above contentions raised by the appellants
were rejected by the tribunal. Therefore, the general candidates came to this Court in
appeal. This Court found on facts that the Service Rule concerned did not
contemplate computation of seniority in respect of roster promotions. Placing
reliance on the judgment of this Court in Ajit Singh (I) and in Virpal Singh, this Court
held that roster promotions were meant only for the limited purpose of due
representation of backward classes at various levels of service and, therefore, such
roster promotions did not confer consequential seniority to the roster-point
promotee. In Ajit Singh (II) , the circular which gave seniority to the roster-point
promotees was held to be violative of Articles 14 and 16. It was further held in M.G.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Badappanavar that equality is the basic feature of the Constitution and any treatment
of equals as unequals or any treatment of unequals as equals violated the basic
structure of the Constitution. For this proposition, this Court placed reliance on the
judgment in Indra Sawhney while holding that if creamy layer among backward
classes were given some benefits as backward classes, it will amount to equals being
treated unequals. Applying the creamy layer test, this Court held that if roster-point
promotees are given consequential seniority, it will violate the equality principle
which is part of the basic structure of the Constitution and in which event, even
Article 16(4A) cannot be of any help to the reserved category candidates. This is the
only judgment of this Court delivered by three-Judge bench saying that if
roster-point promotees are given the benefit of consequential seniority, it will result
in violation of equality principle which is part of the basic structure of the
Constitution. Accordingly, the judgment of the tribunal was set aside.
xx xx xx
110. As stated above, the boundaries of the width of the power, namely, the
ceiling-limit of 50% (the numerical benchmark), the principle of creamy layer, the
compelling reasons, namely, backwardness, inadequacy of representation and the
overall administrative efficiency are not obliterated by the impugned amendments.
At the appropriate time, we have to consider the law as enacted by various States
providing for reservation if challenged. At that time we have to see whether
limitations on the exercise of power are violated. The State is free to exercise its
discretion of providing for reservation subject to limitation, namely, that there must
exist compelling reasons of backwardness, inadequacy of representation in a class of
post(s) keeping in mind the overall administrative efficiency. It is made clear that
even if the State has reasons to make reservation, as stated above, if the impugned
law violates any of the above substantive limits on the width of the power the same
would be liable to be set aside."
60. There is an interesting article by an author dealing with Affirmative Action which reads as
follows:
"In his much referred to speech on 26 November 1949, Dr. Ambedkar said that India
was wanting in its recognition of the principle of fraternity. What does fraternity
mean? Fraternity means a sense of common brotherhood of all Indians - of India
being one people. The virtues of liberty by themselves do not create fraternity. This is
why several liberal theorists are unsure about whether or not state interventions
should be allowed for when the issue of overcoming disprivileges are concerned. The
central concern then is how to inculcate a sense of `common brotherhood' among
people with divergent histories and who occupy vastly different positions in the
economic and social structure of a society. Before we go further on discussing the
specifics of caste and reservations in India it is worth recording that liberty and
equality can sometimes be contradictorily positioned. This is why it is important forAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

democracy to redress these community-based grievances within a framework that
does not violate liberal principles. While the individual needs to be protected, there
are individuals in certain groups and communities that need safeguards and support
as well. After all it must be remembered that communities do not create citizens, but
that there are citizens within communities. Also, while it is rather risky to say that
communities have rights, there is no doubt at all that within liberal democracies,
individuals have rights. Indeed, these rights were secured historically so that
individuals did not have to be burdened by community and ascriptive pressures on
them.
The rationale behind affirmative action is that it releases suppressed talents and
expands the pool of social assets in society for the general good. If today we are
looking for a justification for affirmative action in this fashion, several decades ago it
was precisely this enlarging of the social pool of talents that recommended equal
treatment for women. As L.T. Hobhouse argued then that when women are repressed
then there is a loss of all the elements in the common stock which the free play of the
woman's mind would contribute. By increasing the sum of realized talents in society
individuals can actually gain greater inter-subjectivity in their everyday lives. As the
set of resemblances between them is now so much larger, they can practice, pace
Rawls, the moral precept of participating in one another's fate. In this process,
fraternal values of citizenship gain materiality and fulfilment. It should be recognized
that fraternity can only come about through a basic set of resemblances between
citizens. This conception of resemblances is about citizens being equally able to avail
of institutional facilities that ensure their acquisition of those skills that are
considered to be socially valuable. In other words, social opportunities exist for
individual self-expansion, and it is only individuals now who can exclude themselves.
If grinding poverty comes in the way of acquiring such socially valuable skills, then
those blocks should be met by developmental interventions such as the anti-poverty
programmes. But on no account should the removal of poverty be made synonymous
with reservations. Reservations are only meant to create a measure of confidence and
dignity among those who didn't dare dream of an alternative life. But that alone
cannot create structural conditions that address the root causes of poverty.
If quality education and the imparting of socially valuable skills are provided across
the board through reservations, then that would take care of the complaint that
affirmative action is largely about the equality of results. Rawls' principle of justice as
fairness only says that offices should be open to all. But what if people do not qualify
for these offices because their potentialities have remained unrealized on account of
inadequate qualifications arising from a history of discrimination compounded by
poverty, or, indeed, because of sub-standard education? Does it mean that, through
positive discrimination and reservations, they should be given these jobs anyway
regardless of the welfare of institutions? In this connection, Andre Beteille's warning
that affirmative action should be sensitive to institutional well-being as well needs to
be recalled. Beteille sifted between the various imperatives that differentAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

organizations are subsumed under and accordingly advised a careful calibration of
reservations such that these provisions of performance do not undermine efficiency
of performance. The resemblances that are being advocated in the context of
affirmative action should not be interpreted in terms of homogeneous `sameness'.
Sameness is what medieval religious fundamentalists aim for. On the other hand, the
set of resemblances in a constitutional democracy enhances equality and not
sameness by providing identical opportunities to all for self-expression and
development. Citizenship is not about the sameness of lifestyles or of income.
Marshall's notion of citizenship as a status that tends towards equality should be
interpreted in this light. According to Marshall, the equality that citizenship
guarantees should be the foundation on which other kinds of differences can develop.
It will no doubt be the case that differences will exist even after a minimum set of
resemblances is established. But these will no longer be outcomes of the accidents of
birth. When diversity exists outside of choice then that is not a state of affairs that a
democratic society can rejoice in. Affirmative action is instrumental in enlarging the
scope of difference and diversity, but it succeeds in doing so by first ensuring that
citizens resemble one another at a very critical level namely in their ability to acquire
socially valuable skills. Affirmative action gets somewhat complicated in India on
account of caste politics.
Undeniably, India is the most stratified society in the world. Over and above caste
differentiations there are huge income disparities, religious and community
differences that are deeply engraved into everyday social relations. No doubt, the
nature of caste and community interactions has changed over time, but
considerations along ascriptive lines still remain important markers, both at the
public and private domains. Not only are we now confronted by identity assertions of
earthy peasant castes, that were earlier ranked as lowly shudras (or menials), but
also, of those who, till recently, were called `untouchables'. Now we also know that
none of these castes had ever ideologically accepted their degraded status. Yet they
lived out their humble lives quietly for generations for fear of offending the privileged
strata.
We now know more of their origin tales that boast of the elevated positions they once
held before an unsuspected chicanery, a lost war, or a mercurial god, demoted them
to lowly rungs in popular perceptions. Today these tales are an important source of
symbolic energy for caste mobilizations and identity assertions. Now that the Mandal
recommendations are in place, reservations are not just for the Scheduled Castes and
Tribes, but for the so-called other Backward Castes as well. While there are a large
number of castes listed as Backward, the demand for reservations for this category
has been spearheaded by the class of owner- cultivators, or peasant proprietors.
Before we assess Mandal reforms it would be useful to know how these peasant castes
emerged.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

After the zamindari abolition came into effect, adult franchise and land-to-the-tiller
programme together forced the earlier landed castes slowly to cede ground in the
villages. Soon, however, traditional peasant castes such as the Ahirs, Kurmis, Koeris,
Lodhs, Rajputs and Jats began to dominate the political scape of northern India. In
the southern State of Tamil Nadu, the Vanniyars and Thevars have become assertive,
and in Karnataka control was wrested in the mid- 1950s from the traditional rural
elite within the Congress Party by the Vokkaligas and Linagayats.
xx xx xx In pursuance of Article 340 of the Constitution, the Kalelkar Commission
was set up in 1955 but it could not come to any satisfactory conclusion about who
should be legitimately considered as OBCs. The Mandal Commission came into
existence in 1980 and it promptly came up with a long list of 3,743 backward castes
on the basis of social, economic and educational backwardness. The Mandal
Commission's recommendations were implemented in 1990 by the then Prime
Minister VP Singh. This meant that a further 29 per cent of seats in educational
institutions and government jobs would now be reserved for OBCs.
The implementation of reservations for OBCs set off a furore of protests, including a
few suicides, all over the country by those who are considered to be members of
forward castes. Many felt that reservations for OBCs were not warranted for two
reasons. First, this would make India a caste society by law; and, second, because
many of those who are considered as OBCs are really quite powerful and dominant in
rural India. The obvious reference was to Jats and Yadavs. A majority of social
anthropologists wrote against reservations for OBCs primarily on these grounds.
Andre Beteille's criticism of the Mandal Commission recommendations was widely
commented upon. He distinguishes between reservations for OBCs following Mandal
recommendations and the reservations that were already granted in the Constitution
for Scheduled Castes and Tribes. While provisions for Scheduled Castes and Tribes
were with the intention of reaching towards greater equality, reservations for OBCs
were really to bring about a balance of power on the calculus of caste. The kind of
deprivations that ex-untouchables (Scheduled Castes) and Adivasis (Scheduled
Tribes) encountered for centuries can in no way be compared to the traditional
condition of the OBCs. Besides, many OBCs are quite powerful in rural India, both
economically and politically. In fact, the Mandal Commission recommendations were
actually giving in to a powerful rural lobby that did not really care for equality of
opportunities as much as it did for equality of results.
xx xx xx There are two considerations that escape many uncritical applications of
affirmative action. First, affirmative action must resist any tendency whereby its
beneficiaries become vested interests. And secondly, it must eventually seek its own
dissolution. While the second may be far away, it is by paying attention to the first
issue that it is possible for affirmative action to eventually annihilate itself.
Paradoxical as it may appear, but when this happens it is then that positive
discrimination has finally triumphed.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Affirmative action fails to reach this final destination when it is inconsistently
applied, or when its beneficiaries form vested interest bloc within a democratic
electoral system on the basis of ascriptive identity alone. The latter poses a stronger
practical and intellectual challenge to the policy of affirmative action. As long as
historical disprivileges and economic backwardness go together and the relationship
between them is statistically very strong, colour or caste membership can act as ready
reckoners for targeting beneficiaries of affirmative action. This, however, does not
mean that membership in these communities should advantage individuals in
perpetuity once they are able to develop the minimum set of resemblances.
Therefore, as and when those who belong to targeted categories for affirmative action
acquire socially useful talents and attributes, they should contribute them to the
society as a whole, and not employ them only for sectional advantages.
Consequently, those who benefit from this policy owe it to society to put their newly
acquired social talents back into the collective social pool. This would mean that they
would automatically fall outside the scope of affirmative action programme in the
future. The net would no longer cover them as they already have socially useful
assets. Indeed the society will be richer and better endowed on account of it as the
beneficiaries of affirmative action will now begin to contribute to the social pool of
talents. This would both release and add to social and material resources required for
continuing with the policy aimed at the enhancement of resemblances. As a result,
society will progressively acquire a higher strike rate with the policy of affirmative
action by reaching out to those who have thus far fallen outside its ambit. By
increasing the number of those who possess the minimum set of resemblances, the
society has now a larger wealth of talents in a variety of fields and specialities than it
had before. This is how affirmative action, which is aimed at the historically most
disadvantaged sections, ultimately improves the lot of everybody in society. If, on the
other hand, either colour or race, which are only ready reckoners, become permanent
considerations, without taking into account biographical profiles of actual and
potential beneficiaries, then that would inhibit fraternity and sow seeds of permanent
divisions in society.
Affirmative action begins by placing the assets of the better off in a collective pool,
not for redistribution, but to create the infrastructure that is needed to enhance the
minimum set of resemblances necessary for substantive citizenship. With the help of
this capital, socially valuable assets are now created in sites where there were none.
This measure has a strong practical dimension for out of this collective pooling new
assets are being created. The creation of such new assets is possible because the
initial pooling of assets of the privileged section allows the society to underwrite the
expenses incurred for the establishment of certain baseline similarities in society as a
whole. As the most important feature in this case is not one's ascriptive badge, but
the creation of socially valuable assets, it is expected that those who have been the
beneficiaries of the scheme will gradually slip out of the net. They will cease to receive
from the collective pool and instead will begin to contribute to it. As far as publicAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

policy is concerned they are no long members of certain designated castes or
communities. They are now simply citizens. In passing it is worth putting in
perspective that the difference between reservations in India and affirmative action
in America is that the former talks about extirpating caste whereas the latter is
interested primarily in representing races. If the accent is on representation then the
ascriptive factor becomes a permanent badge that can never be overcome. Again,
Americans believe in race representation, not in quotas, and in not sacrificing
standards for social justice. But the great similarity between the two forms of
preferential policy is that in both cases it is the public sector where positive
discrimination is effectively realized. In America, the State encourages private sector
units to employ people of diverse backgrounds without specifying quotas for different
races. If these enterprises can show a fair racial mix then they can get preferential
contracts from the government. The State cannot force any private sector unit to
implement affirmative action. It is a combination of goodwill and rewards that takes
affirmative action forward in the private sector of America. For example, Bob Jones
University does not receive any public money and, therefore, it refuses to accept
affirmative action, even of the most muted kind. It is only when organizations depend
on state funding, or when they want to be rewarded by the State, that policy of
affirmative action comes to life."
61. It has been rightly observed in Indra Sawhney No. 2 (supra) whether creamy layer is not
excluded or whether forward classes can be excluded in the list of backward classes, the position
would be the same and there will be breach not only of Article 14 but of the basic structure of the
Constitution. As was rightly observed in the said case, non exclusion of the creamy layer or inclusion
of forward castes in the lists of backward classes will be totally illegal. The illegality offends the roots
and foundation of the Constitution and cannot be allowed to be perpetuated.
62. In Nair Service Society's case (supra) this Court observed as follows:
"54. This Court, thus, has categorically laid down the law that determination of
creamy layer is a part of the constitutional scheme."
63. In our view, even non exclusion of the creamy layer for the purpose of admission to the
educational institutions cannot be countenanced. It is inconceivable that a person who belongs to
the creamy layer is socially and educationally backward. The backward status vanishes when
somebody becomes part of the creamy layer.
64. In Vasant Kumar's case (supra) it was aptly described that the benefits of reservation are
snatched away by the top creamy layer of the backward classes and this has to be avoided at any
cost. By inclusion of the creamy layer or in other words non inclusion thereof a fresh lease of life to
those who should have been left out is given. Their continuance would mean keeping weakest
amongst the weak always weak and leaving the fortunate ones to enjoy the benefits. If the ultimate
aim is a casteless and classless society in line with the dream of the Constitution framers that has to
be chewed out. As Father of the Nation had once said if the caste system as we know is anAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

anchronism, then it must go. There is a feeling and it cannot be said without reason that reservation
hits at the root of this belief and instead of its obliteration there is perceivable perpetuation. It is
true that obliteration cannot be done immediately or within a short span of time but that is no
answer to the lack of seriousness in seeking obliteration.
65. In Indra Sawhney No.1 (supra) the following observations on the question of giving priority over
reservation are of significance. It was held:
"293. Preference without reservation may be adopted in favour of the chosen classes
of citizens by prescribing for them a longer period for passing a test or by awarding
additional marks or granting other advantages like relaxation of age or other
minimum requirements. (See the preferential treatment in State of Kerala and Anr. v.
N.M. Thomas and Ors. (1976) 1 SCR 906). Furthermore, it would be within the
discretion of the State to provide financial assistance to such persons by way of grant,
scholarships, fee concessions etc. Such preferences or advantages are like temporary
crutches for additional support to enable the members of the backward and other
disadvantaged classes to march forward and compete with the rest of the people.
These preferences are extended to them because of their inability otherwise to
compete effectively in open selections on the basis of merits for appointment to posts
in public services and the like or for selection to academic courses. Such preferences
can be extended to all disadvantaged classes of citizens, whether or not they are
victims of prior discrimination. What qualifies persons for preference is
backwardness or disadvantage of any kind which the State has a responsibility to
ameliorate. The blind and the deaf, the dumb and the maimed, and other
handicapped persons qualify for preference. So do all other classes of citizens who are
at a comparative disadvantage for whatever reason, and whether or not they are
victims of prior discrimination. All these persons may be beneficiaries of preferences
short of reservation. Any such preference, although discriminatory on its face, may be
justified as a benign classification for affirmative action warranted by a compelling
state interest.
294. In addition to such preferences, quotas may be provided exclusively reserving
posts in public services or seats in academic institutions for backward people entitled
to such protection. Reservation is intended to redress backwardness of a higher
degree. Reservation prima facie is the very antithesis of a free and open selection. It is
a discriminatory exclusion of the disfavoured classes of meritorious candidates: M.R.
Balaji (supra). It is not a case of merely providing an advantage or a concession or
preference in favour of the backward classes and other disadvantaged groups. It is
not even a handicap to disadvantage the forward classes so as to attain a measure of
qualitative or relative equality between the two groups.
Reservation which excludes from consideration all those persons falling outside the specially
favoured groups, irrespective of merits and qualifications, is much more positive and drastic a
discrimination - albeit to achieve the same end of qualitative equality - but unless strictly andAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

narrowly tailored to a compelling constitutional mandate, it is unlikely to qualify as a benign
discrimination. Unlike in the case of other affirmative action programmes, backwardness by itself is
not sufficient to warrant reservation. What qualifies for reservation is backwardness which is the
result of identified past discrimination and which is comparable to that of the Scheduled Castes and
the Scheduled Tribes. Reservation is a remedial action specially addressed to the ill effects stemming
from historical discrimination. To ignore this vital distinction between affirmative action short of
reservation and reservation by a predetermined quota as a remedy for past inequities is to ignore the
special characteristic of the constitutional grant of power specially addressed to the constitutionally
recognised backwardness.
xx xx xx
319. Reservation should be avoided except in extreme cases of acute backwardness resulting from
prior discrimination as in the case of the Scheduled Castes and the Scheduled Tribes and other
classes of persons in comparable positions. In all other cases, preferential treatment short of
reservation can be adopted. Any such action, though in some respects discriminatory, is permissible
on the basis of a legitimate classification rationally related to the attainment of equality in all its
aspects.
       Xx                 xx                   xx
323 (16).    I
n the final analysis, poverty which is the ultimate result of inequities and which is the immediate
cause and effect of backwardness has to be eradicated not merely by reservation as aforesaid, but by
free medical aid, free elementary education, scholarships for higher education and other financial
support, free housing, self- employment and settlement schemes, effective implementation of land
reforms, strict and impartial operation of the law-enforcing machinery, industrialization,
construction of roads, bridges, culverts, canals, markets, introduction of transport, free supply of
water, electricity and other ameliorative measures particularly in areas densely populated by
backward classes of citizens.
(underlined for emphasis)
66. Following observations in M.R. Balaji v. State of Mysore (AIR 1963 SC 649) are also relevant:
"In this connection, it is necessary to remember that the reservation made by the
impugned order is in regard to admission in the seats of higher education in the
State. It is well-known that as a result of the awakening caused by political freedom,
all classes of citizens are showing a growing desire to give their children higher
university education and so, the Universities are called upon to face the challenge of
this growing demand. While it is necessary that the demand for higher education
which is thus increasing from year to year must be adequately met and properlyAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

channelised, we cannot overlook the fact that in meeting that demand standards of
higher education in Universities must not be lowered. The large demand for
education may be met by starting larger number of educational institutions
vocational schools and polytechnics. But it would be against the national interest to
exclude from the portals of our Universities qualified and competent students on the
ground that all the seats in the Universities are reserved for weaker elements in
society. As has been observed by the University Education Commission, "he indeed
must be blind who does not see that mighty as are the political changes, far deeper
are the fundamental questions which will be decided by what happens in the
universities" (p. 32). Therefore, in considering the question about the propriety of the
reservation made by the impugned order, we cannot lose sight of the fact that the
reservation is made in respect of higher university education. The demand for
technicians, scientists, doctors, economists, engineers and experts for the further
economic advancement of the country is so great that it would cause grave prejudice
to national interests if considerations of merit are completely excluded by whole-sale
reservation of seats in all Technical, Medical or Engineering colleges or institutions of
that kind. Therefore, considerations of national interest and the interests of the
community or society as a whole cannot be ignored in determining the question as to
whether the special provision contemplated by Art. 15(4) can be special provision
which excludes the rest of the society altogether. In this connection, it would be
relevant to mention that the University Education Commission which considered the
problem of the assistance to backward communities, had observed that the
percentage of reservation shall not exceed a third of the total number of seats, and it
has added that the principle of reservation may be adopted for a period of ten years.
(p. 53).
We have already noticed that the Central Government in its communication to the
State has suggested that reservation for backward classes, Scheduled Castes and
Scheduled Tribes may be up to 25% with marginal adjustments not exceeding 10% in
exceptional cases.
The learned Advocate-General has suggested that reservation of a large number of
seats for the weaker sections of the society would not affect either the depth or
efficiency of scholarship at all, and in support of this argument, he has relied on the
observations made by the Backward Classes Commission that it found no complaint
in the States of Madras, Andhra, Travancore-Cochin and Mysore where the system of
recruiting candidates from other Backward Classes to the reserve quota has been in
vogue for several decades. The Committee further observed that the representatives
of the upper classes did not complain about any lack of efficiency in the offices
recruited by reservation (p. 135). This opinion, however, is plainly inconsistent with
what is bound to be the inevitable consequence of reservation in higher university
education. If admission to professional and technical colleges is unduly liberalised it
would be idle to contend that the quality of our graduates will not suffer. That is not
to say that reservation should not be adopted; reservation should and must beAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

adopted to advance the prospects of the weaker sections of society, but in providing
for special measures in that behalf care should be taken not to exclude admission to
higher educational centres to deserving and qualified candidates of other
communities. A special provision contemplated by Art. 15(4) like reservation of posts
and appointments contemplated by Art. 16(4) must be within reasonable limits. The
interests of weaker sections of society which are a first charge on the states and the
Centres have to be adjusted with the interests of the community as a whole. The
adjustment of these competing claims is undoubtedly a difficult matter, but if under
the guise of making a special provision, a State reserves practically all the seats
available in all the colleges, that clearly would be subverting the object of Art. 15(4).
In this matter again, we are reluctant to say definitely what would be a proper
provision to make. Speaking generally and in a broad way, a special provision should
be less than 50%; how much less than 50% would depend upon the relevant
prevailing circumstances in each case. In this particular case it is remarkable that
when the State issued its order on July 10, 1961, it emphatically expressed its opinion
that the reservation of 68% recommended by the Nagan Gowda Committee would
not be in the larger interests of the State. What happened between July 10, 1961, and
July 31, 1962, does not appear on the record. But the State changed its mind and
adopted the recommendation of the Committee ignoring its earlier decision that the
said recommendation was contrary to the larger interests of the State. In our opinion,
when the State makes a special provision for the advancement of the weaker sections
of society specified in Art. 15(4) it has to approach its task objectively and in a
rational manner. Undoubtedly, it has to take reasonable and even generous steps to
help the advancement of weaker elements; the extent of the problem must be
weighted, the requirements of the community at large must be borne in mind and a
formula must be evolved which would strike a reasonable balance between the
several relevant considerations. Therefore, we are satisfied that the reservation of
68% directed by the impugned order is plainly inconsistent with Art. 15(4). The
petitioners contend that having regard to the infirmities in the impugned order,
action of the State in issuing the said order amounts to a fraud on the Constitutional
power conferred on the State by Art. 15(4). This argument is well- founded, and must
be upheld. When it is said about an executive action that it is a fraud on the
Constitution, it does not necessarily mean that the action is actuated by mala fides.
An executive action which is patently and plainly outside the limits of the
constitutional authority conferred on the State in that behalf is struck down as being
ultra vires the State's authority. If, on the other hand, the executive action does not
patently or overtly transgress the authority conferred on it by the Constitution, but
the transgression is covert or latent, the said action is struck down as being a fraud on
the relevant constitutional power. It is in this connection that courts often consider
the substance of the matter and not its form and in ascertaining the substance of the
matter, the appearance or the cloak, or the veil of the executive action is carefully
scrutinized and if it appears that notwithstanding the appearance, the cloak or the
veil of the executive action, in substance and in truth the constitutional power has
been transgressed, the impugned action is struck down as a fraud on theAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Constitution. We have already noticed that the impugned order in the present case
has categorised the Backward Classes on the sole basis of caste which, in our opinion,
is not permitted by Art. 15(4); and we have also held that the reservation of 68%
made by the impugned order is plainly inconsistent with the concept of the special
provision authorised by Art. 15(4). Therefore, it follows that the impugned order is a
fraud on the Constitutional power conferred on the State by Art. 15(4). The learned
Advocate- General has made an earnest and strong plea before us that we should not
strike down the order, but should strike down only such portions of the order which
appear to us to be unconstitutional on the doctrine of severability. He has urged that
since 1958, the State has had to make five orders to deal with the problem of
advancing the lot of the Backward Classes and the State is anxious that the
implementation of the impugned order should not be completely prohibited or
stopped. We do not see how it would be possible to sever the invalid provisions of the
impugned order. If the categorisation of the Backward Classes is invalid, this Court
cannot and would not attempt the task of enumerating the said categories; and if the
percentage of reservation is improper and outside Art. 15(4), this Court would not
attempt to lay down definitely and in an inflexible manner as to what would be the
proper percentage to reserve. In this connection, it may be relevant to refer to one
fact on which the petitioners have strongly relied. It is urged for them that the
method adopted by the Government of Maharashtra in exercising its power under
Art. 15(4) is a proper method to adopt. It appears that the Maharashtra Government
has decided to afford financial assistance, and make monetary grants to students
seeking higher education where it is shown that the annual income of their families is
below a prescribed minimum. The said scheme is not before us and we are not called
upon to express any opinion on it. However, we may observe that if any State adopts
such a measure, it may afford relief to and assist the advancement of the Backward
Classes in the State, because backwardness, social and educational, is ultimately and
primarily due to poverty. An attempt can also be made to start newer and more
educational institutions, polytechnics, vocational institutions and even rural
Universities and thereby create more opportunities for higher education. This dual
attack on the problem posed by the weakness of backward communities can claim to
proceed on a rational, broad and scientific approach which is consistent with, and
true to, the noble ideal of a secular welfare democratic State set up by the
Constitution of this country. Such an approach can be supplemented, if necessary by
providing special provision by way of reservation to aid the Backward classes and
Scheduled castes and Tribes. It may well be that there may be other ways and means
of achieving the same result. In our country where social and economic conditions
differ from State to State, it would be idle to expect absolute uniformity of approach;
but in taking executive action to implement the policy of Art. 15(4), it is necessary for
the States to remember that the policy which is intended to be implemented is the
policy which has been declared by Art. 46 and the preamble of the Constitution. It is
for the attainment of social and economic justice Art. 15(4) authorises the making of
special provisions for the advancement of the communities there contemplated even
if such provisions may be inconsistent with the fundamental rights guaranteed underAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Art. 15 or 29(2). The context, therefore, requires that the executive action taken by
the State must be based on an objective approach, free from all extraneous pressures.
The said action is intended to do social and economic justice and must be taken in a
manner that justice is and should be done.
Whilst we are dealing with this question, it would be relevant to add to that the
provisions of Art. 15(4) are similar to those of Art. 16(4) which fell to be considered in
the case of The General Manager, Southern Railway v. Rangachari (1962 (2) SCR
586). In that case, the majority decision of this Court held that the power of
reservation which is conferred on the State under Art. 16(4) can be exercised by the
State in a proper case not only by providing for reservation of appointments, but also
by providing for reservation of selection posts. This conclusion was reached on the
basis that it served to give effect to the intention of the Constitution makers to make
adequate safeguards for the advancement of Backward Classes and to secure their
adequate representation in the Services. The judgment shows that the only point
which was raised for the decision of this Court in that case was whether the
reservation made was outside Art. 16(4) and that posed the bare question about the
construction of Art. 16(4). The propriety, the reasonableness or the wisdom of the
impugned order was not questioned because it was not the respondent's case that if
the order was justified under Art. 16(4), it was a fraud on the Constitution. Even so, it
was pointed out in the judgment that the efficiency of administration is of such a
paramount importance that it would be unwise and impermissible to make any
reservation at the cost of efficiency of administration; that, it was stated, was
undoubtedly the effect of Art. 335. Therefore, what is true in regard to Art. 15(4) is
equally true in regard to Art. 16(4). There can be no doubt that the
Constitution-makers assumed, as they were entitled to, that while making adequate
reservation under Art. 16(4), care would be taken not to provide for unreasonable,
excessive or extravagant reservation, for that would, by eliminating general
competition in a large field and by creating wide-spread dissatisfaction amongst the
employees, materially affect efficiency. Therefore, like the special provision
improperly made under Art. 15(4), reservation made under Art. 16(4) beyond the
permissible and legitimate limits would be liable to be challenged as a fraud on the
Constitution. In this connection it is necessary to emphasize that Art. 15(4) is an
enabling provision; it does not impose an obligation, but merely leaves it to the
discretion of the appropriate government to take suitable action, if necessary."
67. To similar effect is the view expressed in K.C. Vasanth Kumar's case (supra) at para 150:
"At this stage it should be made clear that if on a fresh determination some castes or
communities have to go out of the list of backward classes prepared for Article 15(4)
and Article 16(4) the Government may still pursue the policy of amelioration of
weaker sections of the population amongst them in accordance with the directive
principle contained in article 46 of the Constitution. There are in all castes and
communities poor people who if they are given adequate opportunity and trainingAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

may be able to compete successfully with persons belonging to richer classes. The
Government may provide for them liberal grants of scholarships, free studentship,
free boarding and lodging facilities, free uniforms, free mid day meals etc. to make
the life of poor students comfortable. The Government may also provide extra
tutorial facilities, stationery and books free of costs and library facilities. These and
other steps should be taken in the lower classes so that by the time a student appears
for the qualifying examination he may be able to attain a high degree of proficiency in
his studies."
It has also been noted as follows:
"I wish to add that the doctrine of protective discrimination embodied in Article 15(4)
and 16(4) and the mandate of Article 29(2) cannot be stretched beyond a particular
limit. The State exists to serve its people. There are some services where expertise
and skill are of the essence. For example, a hospital run by the State serves the ailing
members of the public who need medical aid. Medical services directly affect and deal
with the health and life of the populace. Profession expertise, born of knowledge and
experience, of a high degree of technical knowledge and operation skill is required of
pilots and aviation engineers. The lives of citizens depend on such persons. There are
other similar fields of governmental activity where professional, technological,
scientific or other special skill is called for. In such services or posts under the Union
or State, we think where can be no room for reservation of posts; merit alone must be
the sole and decisive consideration for appointments."
(underlined for emphasis)
68. Lengthy arguments have been advanced as to the seriousness in identifying the backward
classes. On the basis of Indra Sawhney No.1's judgment, the Government of India issued orders in
respect of reservations of appointments or on posts under the Government of India in favour of
backward classes of citizens. It was the subject matter of challenge in Indra Sawhney No.1. In its
judgment dated 16.11.1992 this Court directed the Government to constitute a permanent body by
15.3.1993 for entertaining and examining and recommending upon requests made for inclusion or
complaints of over inclusion and under inclusion in the lists of backward classes of citizens.
69. Constituent Assembly Debates 1951 have also relevance for adjudicating the controversy. The
following portion needs to be extracted:
70. Parliamentary Standing Committee Report at paras 36, 37 and 46 read as follows:
"36. The committee notes that there is a major limitation on data about the social
economic and educational profile of our population in general and about OBCs in
particular. The last caste-based census in India was done in 1931. Accordingly there
are no periodic data available on the demographic spread of OBCs and their access to
amenities. Even the Mandal Commission had used the 1931 Census data. WhateverAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

limited data are available, pertain to surveys conducted by NSSO from 1998-99
onwards, which are only `sample surveys'.
37. The Committee found that there exists no accepted mechanism/criteria to group
the people into different categories. As a result, existing list of backward
castes/communities are termed in some cases, as inaccurate. Besides, any regular
process of review is also not in place. Such a review implies both `inclusion' and
`exclusion'. The Committee, therefore, emphasizes the need for taking urgent
measures/steps for identifying and removing all such lacunae and removing all such
lacunae and problems by putting in place scientific and objective
mechanism/benchmarks for this purpose.
xx xx xx
46. There have been suggestions/counter-suggestions on the issue of exclusion of the
'creamy layer amongst OBCs in the proposed legislation. On the one hand, it was
argued that the concept of creamy layer did not apply in the case of reservation in
admission. It was pointed out that the debate on the exclusion of the creamy layer
was misplaced as the Supreme Court's observation regarding the exclusion of the
creamy layer within the SCs and STs from the purview of reservation was only for
public employment and promotion. The other view in this regard was that the
inclusion of the creamy layer in reservation would defeat the very purpose of
providing reservation to the backward classes. It was also stated that the exclusion of
the creamy layer would ensure that the intended benefits of the reservation reach to
the really deserving among the backward classes. It was further stated that this in
itself would not suffice and should be supplemented by categorization of the
backward classes in various groups depending upon their degree of backwardness
and apportioning of appropriate percentage of reservation to each group. It was also
brought to the committee that similar experiments in States of Andhra Pradesh,
Kerala, Karnataka, Tamil Nadu, Maharashtra etc. have, in fact, stood the test of time
and yielded the desired results."
71. One of the petitioners "Youth for Equality" had filed a representation before the Parliamentary
Committee giving certain important data. Relevant portions read as follows:
"TOP WITHOUT BASE The condition of infrastructure and staff at the primary and
secondary level is of some concern and the government - especially the Ministry for
Human Resource and Development which has proposed increased reservations,
should work towards improvement in this area for "Real" affirmative action.
According to the National Institute of Educational Planning and Administration (in
2003) the state of affairs at the primary level was as under:-
(i) In 62 996 schools in country do not have school building and are operating in
tents or under the trees.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(ii) In 70,739 Primary Schools - No class room.
(iii) In 95,003 primary Schools - Single Class room.
(iv)       In 8,269 Primary Schools - No teacher
(v)             In 1,15,267 Primary schools -Single teacher
(vi)            In more than 60,000 schools the pupil : Teacher 
ratio is greater than 100 :1 while the acceptable ratio is less than 40:1.
(vii)           In 84,848 schools - No black board
(viii)          In More than 1 00 000 Schools - No electricity.
Apart from the above, according to the NCERT (In 1998), Only 34.6% of Govt.
Schools had safe Drinking water, 13.2% had urinal and 4.9% had urinals for girls and
only 6.0% had a lavatory. While the government promises a spending of about 6% of
GDP for the development of education, the reality has been to the contrary. The
Government spending in the years was as under:
2000-2001          4.1%
 2001-2002         4.3% 
2002-2004          3.8% 
2004-2005          3.5%Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

72. The National Commission for Backward Classes Act, 1993 (in short `Backward
Classes Act') was accordingly enacted. Few provisions of this Act need to be noted.
73. Section 2 (c) defines lists as follows:
"Lists means lists prepared by the Government of India from time to time for
purposes of making provisions for the reservation of appointments or posts in favour
of backward classes of citizens which, in the opinion of that Government, are not
adequately represented in the services under the Government of India and any local
or other authority within the territory of India or under the control of the
Government of India".
74. Important provisions are Sections 9 and 10 which read as follows:
"9. Functions of the Commission (1) The Commission shall examine requests for
inclusion of any class of citizens as a backward class in such lists and hear complaints
of over- inclusion or under inclusion of any backward class in such lists and tender
such advice to the Central Government as it deems appropriate.
(2) The advice of the Commission shall ordinarily be binding upon the Central
Government.
10. Powers of the Commission- The Commission shall, while performing its functions
under sub-
section (1) of Section 9, have all the powers of a civil court trying a suit and in particular, in respect
of the following matters, namely:-
(a) summoning and enforcing the attendance of any person from any part of India and examining
him on oath;
(b)                                   requiring   the   discovery   and 
production of any document;
(c)                                   receiving evidence on affidavits;
(d)                                   requisitioning any public record or 
copy thereof from any court of office;Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(e)                                   issuing   commissions   for   the 
examination of witnesses and documents; and
(f)                                   any   other   matter   which   may   be 
prescribed."
75. A periodic revision of the lists by the Central Government is a statutory mandate. Petitioners
have highlighted that there is no exclusion and on the other hand there has been inclusion. On the
question of castes enumeration it is emphasized that 1931 Census was not the basis for identification
of other backward classes. In fact the central OBC List is not drawn up on the basis of 1931 Census.
Each State has different modalities for identification. Only for the purpose of quantum the
population provides a foundation.
76. It needs no emphasis that if ultimately and indisputably the constitutional goal is the casteless
and classless society, there has to be more effective implementation of the Backward Classes Act.
The exercise required to be undertaken under Section 11 of the said Act is not intended to be a
routine exercise and also not an exercise in futility. It has to be not only effective but also result
oriented. The petitioners have highlighted the lack of seriousness of the Government in carrying out
the exercise. Voluminous datas have been brought on record in this regard. With reference to the
reports of the Commission, learned counsel for the respondents on the other hand have stressed on
the fact that the Commission has been working with all sincerity and with the object of effectively
implementing the Backward Classes Act. One thing needs to be noted here. Concrete data about the
number of backward classes in the country does not appear to be available. The survey conducted by
the National Sample Survey reveals that the percentage is not 52% as is highlighted by the
respondents.
77. Section 2(g) of the Act is relevant in this regard. It reads as follows:
"Other Backward Classes" means the class or classes of citizens who are socially and
educationally backward, and are so determined by the Central Government."
78. At this juncture, it is to be noted that the Backward Classes Act in order to be wholly functional
mandates determination by the Central Government of the backward classes for whom the Statute is
intended. Undisputedly, such determination has not been done. The plea is that for more than half a
century enough attention has not been given for the benefit of the other backward classes in the
matter of admissions to higher educational institutions. That cannot be a ground to act with hurry
and with un-determined datas. It may be as rightly contended by learned counsel for the
respondents that the percentage can certainly be not less than 27%. But that is no answer to theAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

important question as to the identity test. In the background loom the socially and economically
backward class of citizens. Poverty knows no caste. Poor has no caste. It is an unfortunate class. It is
a matter of common knowledge that the institution of caste is a peculiarity of Indian institution
when there is considerable controversy amongst the scholars as to how the caste system originated
in this country. Originally, there were four main castes known as Varnas . But gradually castes and
sub-castes multiplied as the social fabric expanded with the absorption of different groups of people
who belong to various cults and professing different religious faiths. The caste system in its earlier
stage was quite elastic but in course of time it gradually hardened into a rigid framework based upon
heredity. The inevitable result was social inequality. At some point of time occupation was the
background for determination of castes.
May be, at some point of time it depended on the income of the individual. But it appears to have
taken disastrous turn with difference of status of various castes. But passage of time shows that the
occupational label has lost much of its significance. But at the same time, the poor and down
trodden who belong to the caste of their own were the founders of poor. In Indra Sawhney No.1 this
factor was noticed.
79. It is said that one must take life in ones stride, let today embrace the past with remembrance and
the future with longing.
80. Don't look for the path far away, the path exists under your feet.
81. What is past and what cannot be prevented should not be grieved for.
82. With reference to the Office Memorandum which provides for preference in favour of "poorer
sections" over other members of the backward classes, the expression was held to be relatable to
those who are socially and economically more backward. The use of the word `poorer' in the context
was held to be a measure of the social backwardness. It is therefore unmistakenly recognized that
economic backwardness is a factor which can never be lost sight of. There are only two families in
the world; the haves and the have nots said Miquel De Cervantes Don Qutxote de ta Mancha.
Tolstoy has emphatically said "We will do anything for the poor man anything but get of his back"
(quoted in Huntington Philanthrophy and Morality).
83. William Cobbett had said "to be poor and independent is very nearly an impossibility. (See His
book `Advise to Young Men'). We cannot turn Nelson's eye to the poor, those covered by all
encompassing expression "economically backward classes".
84. Should this class of people be kept out of the mainstream of governmental priorities and policies
because they belong to a particular caste? As noted above, the poor have no caste. A person
belonging to a higher caste should not be made to suffer for what his forefathers had done several
generations back.
85. Franklin D Roosevelt in a speech in 1940 had said "It is an unfortunate human failing that a full
pocket book often groans more loudly than an empty stomach". The haves and the have nots have toAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

co-exist. If the creamy layer has to be excluded the economically backward classes have to be
included. That would be social balancing and that would be giving true meaning of the objectives of
the Constitution.
Social empowerment cannot be and is certainly not a measure for only socially and educationally
backward classes. It also has to be for the socially and economically backward classes.
Unless this balance, which is very delicate, is maintained the system inevitably will develop a crack
and this crack may after a certain point of time be difficult to be joined. Instead of lightening the
society from castes or classes it will be over burdened and a point of time may come when we shall
not be able to bear the burden any further. Timely steps in this regard will save the Indian society
and democracy from a catastrophe of collapse because of something which the Constitution wants to
obliterate.
86. On the question of time period for the reservation, it is submitted that length of the leap to be
provided depends upon the gap to be filled. It is fairly accepted by learned counsel for the
respondents that as and when castes reach a higher level it is to be excluded from the zone of
consideration.
It is further submitted that traditional occupation is being pursued by persons belonging to some
castes and the system still subsists and has not broken down. In the absence of alternative
occupation which may not be lucrative, the persons who used to previously carry on the traditional
occupation find it difficult to take up any other occupation.
87. It has been averred that consequent to several efforts, India has made enormous progress in
terms of increase in institutions, teachers and students in elementary education.
But despite all the efforts large population of the children in the country still remain out of school.
88. One of the contentions is that by passage of time prolonged reservation becomes illicit. In Motor
General Traders and Anr. v. State of Andhra Pradesh and Ors. (1984 (1) SCC 222) following
observations were made:
"16. What may be unobjectionable as a transitional or temporary measure at an initial
stage can still become discriminatory and hence violative of Article 14 of the
Constitution if it is persisted in over a long period without any justification. The trend
of decisions of this Court on the above question may be traced thus. In Bhaiyalal
Shukla v. State of Madhya Pradesh [1962] Supp. 2 S.C.R. 257 one of the contentions
urged was that the levy of sales tax in the area which was formerly known as Vindhya
Pradesh (a Part 'C' State) on building materials used in a works contract was
discriminatory after the merger of that area in the new State of Madhya Pradesh
which was formed on November 1,1956 under the States Reorganisation Act, 1956 as
the sale of building materials in a works contract was not subject to any levy of sales
tax in another part of the same new State namely the area which was formerly part ofAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

the area known as State of Madhya Pradesh (the Central Provinces and Berar area).
That contention was rejected by this Court with the following observations at pages
274-275 :
The laws in different portions of the new State of Madhya Pradesh were enacted by
different Legislatures, and under Section 119 of the States Reorganisation Act all laws
inforce are to continue until repealed or altered by the appropriate Legislature. We
have already held that the sales tax law in Vindhya Pradesh was validly enacted, and
it brought its validity with it under Section 119 of the States Reorganisation Act, when
it became a part of the State of Madhya Pradesh. Thereafter, the different laws in
different parts of Madhya Pradesh can be sustained on the ground that the
differentiation arises from historical reasons, and a geographical classification based
on historical reasons has been upheld by this Court in M.K. Prithi Rajji v. The State of
Rajasthan (Civil Appeal No. 327 of 1956 decided on November 2, 1960) and again in
The State of Madhya Pradesh v. The Gwalior Sugar Co. Ltd. (Civil Appeals Nos. 98
and 99 of 1957 decided on November 30, 1960). The latter case is important, because
the sugarcane cess levied in the former Gwalior State but not in the rest of Madhya
Bharat of which it formed a part, was challenged on the same ground as here, but was
upheld as not affected by Article14. We, therefore, reject this argument.
89. In N.M. Thomas's case (supra) the parameters of various clauses of Article 16 were highlighted
as follows:
"37. The rule of equality within Articles 14 and 16(1) will not be violated by a rule
which will ensure equality of representation in the services for unrepresented classes
after satisfying the basic needs of efficiency of administration. Article 16(2) rules out
some basis of classification including race, caste, descent, place of birth etc. Article
16(4) clarifies and explains that classification on the basis of backwardness does not
fall within Article 16(2) and is legitimate for the purposes of Article 16(1). If
preference shall be given to a particular under-represented community other than a
backward class or under-represented State in an All India Service such a rule will
contravene Article 16(2). A similar rule giving preference to an under-represented
backward community is valid and will not contravene Articles 14, 16(1) and 16(2).
Article 16(4) removes any doubt in this respect.
xx xx xx
44. Our Constitution aims at equality of status and opportunity for all citizens
including those who are socially, economically and educationally backward. The
claims of members of backward classes require adequate representation in legislative
and executive bodies. If members of Scheduled Castes and Tribes, who are said by
this Court to be backward classes, can maintain minimum necessary requirement of
administrative efficiency, not only representation but also preference may be given to
them to enforce equality and to eliminate inequality. Articles 15(4) and 16(4) bringAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

out the position of backward classes to merit equality. Special provisions are made
for the advancement of backward classes and reservations of appointments and posts
for them to secure adequate representation. These provisions will bring out the
content of equality guaranteed by Articles 14, 15(1) and 16(1). The basic concept of
equality is equality of opportunity for appointment. Preferential treatment for
members of backward classes with due regard to administrative efficiency alone can
mean equality of opportunity for all citizens. Equality under Article 16 could not have
a different content from equality under Article 14. Equality of opportunity for
unequals can only mean aggravation of inequality. Equality of opportunity admits
discrimination with reason and prohibits discrimination without reason.
Discrimination with reasons means rational classification for differential treatment
having nexus to the Constitutionally permissible object. Preferential representation
for the backward classes in services with due regard to administrative efficiency is
permissible object and backward classes are a rational classification recognised by
our Constitution. Therefore, differential treatment in standards of selection is within
the concept of equality.
xx xx xx
56. If we are all to be treated in the same manner, this must carry with it the
important requirement that none of us should be better or worse in upbringing,
education, than any one else which is an unattainable ideal for human beings of
anything like the sort we now see. Some people maintain that the concept of equality
of opportunity is an unsatisfactory concept For, a complete formulation of it renders
it incompatible with any form of human society. Take for instance, the case of
equality of opportunity for education. This equality cannot start in schools and hence
requires uniform treatment in families which is an evident impossibility. To remedy
this, all children might be brought up in state nurseries, but, to achieve the purpose,
the nurseries would have to be run on vigorously uniform lines. Could we guarantee
equality of opportunity to the young even in those circumstances? The idea is well
expressed by Laski:
`Equality means, in the second place, that adequate opportunities are laid open to all.
By adequate opportunities we cannot imply equal opportunities in a sense that
implies identity of original chance. The native endowments of men are by no means
equal. Children who are brought up in an atmosphere where things of the mind are
accounted highly are bound to start the race of life with advantages no legislation can
secure. Parental character will inevitably affect profoundly the equality of the
children whom it touches. So long, therefore, as the family endures - and there seems
little reason to anticipate or to desire its disappearance - the varying environments it
will create make the notion of equal opportunities a fantastic one'.
xx xx xxAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

60. Bernard A.O. Williams, in his article 'The Idea of Equality"
(supra) gives an illustration of the working of the principle of equality of opportunity:
`Suppose that in a certain society great prestige is attached to membership of a
warrior class, the duties of which require great physical strength. This class has in the
past been recruited from certain wealthy families only, but egalitarian reformers
achieve a change in the rules, by which warriors are recruited from all sections of the
society, on the result of a suitable competition. The effect of this, however, is that the
wealthy families still provide virtually all the warriors, because the rest of the
populace is so undernourished by reason of poverty that their physical strength is
inferior to that of the wealthy and well nourished. The reformers protest that equality
of opportunity has not really been achieved; the wealthy reply that in fact it has, and
that the poor now have the opportunity of becoming warriors - it is just bad luck that
their characteristics are such that they do not pass the test-
"We are not", they might say, "excluding anyone for being poor; we exclude people
for being weak, and it is unfortunate that those who are poor are also weak'.
xx xx xx
67. Today, the political theory which acknowledges the obligation of government
under Part IV of the Constitution to provide jobs, medical care, old age pension, etc.,
extends to human rights and imposes an affirmative obligation to promote equality
and liberty. The force of the idea of a state with obligation to help the weaker sections
of its members seems to have increasing influence in Constitutional law. The idea
finds expression in a number of cases in America involving social discrimination and
also in the decisions requiring the state to offset the effects of poverty by providing
counsel, transcript of appeal, expert witnesses, etc. Today, the sense that government
has affirmative responsibility for elimination of inequalities, social, economic or
otherwise, is one of the dominant forces in Constitutional law. While special
concessions for the under-privileged have been easily permitted, they have not
traditionally been required. Decisions in the areas of criminal procedure, voting
rights and education in America suggest that the traditional approach may not be
completely adequate. In these areas, the inquiry whether equality has been achieved
no longer ends with numerical equality; rather the equality clause has been held to
require resort to a standard of proportional equality which requires the state, in
framing legislation, to take into account the private inequalities of wealth, of
education and other circumstances.
xx xx xx
89. The ultimate reason for the demand of equality for the members of backward
classes is a moral perspective which affirms the intrinsic value of all human beingsAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

and calls for a society which provides these conditions of life which men need for
development of their varying capacities. It is an assertion of human equality in the
sense that it manifests an equal concern for the well being of all men. On the one
hand it involves a demand for the removal of those obstacles and impediments which
stand in the way of the development of human capacities, that is, it is a call for the
abolition of unjustifiable inequalities. On the other hand, the demand itself gets its
sense and moral driving force from the recognition that "the poorest he that is in
England hath a life to live, as the greatest he".
90. `Equality' and `excellence' are two conflicting claims difficult to be reconciled. The Constitution,
in order to ensure true equality provides for special treatment to socially and educationally
backward classes of citizens which is obviously desirable for providing social justice, though at the
cost of merit. However, the Constitution does not provide at all for `institutional reservation.'
Therefore, it's constitutionality is to be judged on the touchstone of Article 14. A large number of
cases cropped up in this area concerning the institutional preference for admission into
postgraduate medical education and super specialties. The judiciary came forward and laid down
detailed principles covering the need of such preference and to limit the extent of such reservation
in view of the importance of merit in the context of national interest and international importance of
universal excellence in super specialties.
91. It is to be noted that the foundation for fixing 27% appears to be the view that 52% of the
population belong to OBC. There is no supportable data for this proposition. In fact, different
Commissions at different points of time have different figures. It is the stand of the respondents that
no Commission has fixed the percentage below 52% and, therefore, there is nothing wrong in fixing
the percentage at 27%. This is not the correct approach. It may be that in no case the percentage of
persons belonging to OBC is less than 27% but supposing in a given case considering the fact that
the actual percentage is 40% a figure less than 27% should have been fixed. The Commission set out
pursuant to the directions of this Court seems to have somewhat acted on the petitions filed by the
people claiming exclusion or inclusion. That was not the real purpose of this Court's decision to
direct appointment of Commission. The very purpose was to identify the classes.
This was the exercise which was to be undertaken apart from considering the applications for
inclusion or exclusion as the case may be. As has been conceded at the beginning of the case
affirmative action is not under challenge. Affirmative action is nothing but a crucial component of
social justice in the constitutional dispensation but at the same time it has to be kept in view that the
same does not infringe the principles of equality of which it is a part and/or unreasonably restraint
or restrict other fundamental freedoms and that it does not violate the basic structure of the
Constitution.
92. It needs no emphasis that Articles 15(4), 15(5) and 16(4) have to comply with the requirements
of Article 14 and the discipline imposed in several other provisions like Articles 15(4)(a) and
15(4)(b), though, they form a part of the equality concept, each of which is so found in our
Constitution.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

93. It is a well settled principle in law that the Court cannot read anything into a statutory provision
which is plain and unambiguous. A statute is an edict of the Legislature. The language employed in a
statute is the determinative factor of legislative intent.
94. Words and phrases are symbols that stimulate mental references to referents. The object of
interpreting a statute is to ascertain the intention of the Legislature enacting it. (See Institute of
Chartered Accountants of India v. M/s Price Waterhouse and Anr. (AIR 1998 SC 74). The intention
of the Legislature is primarily to be gathered from the language used, which means that attention
should be paid to what has been said as also to what has not been said. As a consequence, a
construction which requires for its support, addition or substitution of words or which results in
rejection of words as meaningless has to be avoided. As observed in Crawford v.
Spooner (1846 (6) Moore PC 1 ), Courts, cannot aid the Legislatures' defective phrasing of an Act, we
cannot add or mend, and by construction make up deficiencies which are left there. (See The State of
Gujarat and Ors. v. Dilipbhai Nathjibhai Patel and Anr. (JT 1998 (2) SC 253). It is contrary to all
rules of construction to read words into an Act unless it is absolutely necessary to do so. (See Stock
v. Frank Jones (Tiptan) Ltd. (1978 1 All ER 948 (HL). Rules of interpretation do not permit Courts
to do so, unless the provision as it stands is meaningless or of doubtful meaning. Courts are not
entitled to read words into an Act of Parliament unless clear reason for it is to be found within the
four corners of the Act itself. (Per Lord Loreburn L.C. in Vickers Sons and Maxim Ltd.
v. Evans (1910) AC 445 (HL), quoted in Jamma Masjid, Mercara v. Kodimaniandra Deviah and
Ors.(AIR 1962 SC 847).
95. The question is not what may be supposed and has been intended but what has been said.
"Statutes should be construed not as theorems of Euclid". Judge Learned Hand said, "but words
must be construed with some imagination of the purposes which lie behind them". (See Lenigh
Valley Coal Co. v. Yensavage 218 FR 547). The view was re-iterated in Union of India and Ors. v.
Filip Tiago De Gama of Vedem Vasco De Gama (AIR 1990 SC 981).
96. In D.R. Venkatchalam and Ors. etc. v. Dy. Transport Commissioner and Ors. etc. (AIR 1977 SC
842), it was observed that Courts must avoid the danger of a priori determination of the meaning of
a provision based on their own pre-conceived notions of ideological structure or scheme into which
the provision to be interpreted is somewhat fitted.
They are not entitled to usurp legislative function under the disguise of interpretation.
97. While interpreting a provision the Court only interprets the law and cannot legislate it. If a
provision of law is misused and subjected to the abuse of process of law, it is for the legislature to
amend, modify or repeal it, if deemed necessary.
(See Commissioner of Sales Tax, M.P. v. Popular Trading Company, Ujjain (2000 (5) SCC 511). The
legislative casus omissus cannot be supplied by judicial interpretative process.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

98. Two principles of construction - one relating to casus omissus and the other in regard to reading
the statute as a whole - appear to be well settled. Under the first principle a casus omissus cannot be
supplied by the Court except in the case of clear necessity and when reason for it is found in the four
corners of the statute itself but at the same time a casus omissus should not be readily inferred and
for that purpose all the parts of a statute or section must be construed together and every clause of a
section should be construed with reference to the context and other clauses thereof so that the
construction to be put on a particular provision makes a consistent enactment of the whole statute.
This would be more so if literal construction of a particular clause leads to manifestly absurd or
anomalous results which could not have been intended by the Legislature. "An intention to produce
an unreasonable result", said Danackwerts, L.J. in Artemiou v.
Procopiou (1966 1 QB 878), "is not to be imputed to a statute if there is some other construction
available". Where to apply words literally would "defeat the obvious intention of the legislature and
produce a wholly unreasonable result" we must "do some violence to the words" and so achieve that
obvious intention and produce a rational construction. (Per Lord Reid in Luke v. IRC (1963 AC 557)
where at p. 577 he also observed: "this is not a new problem, though our standard of drafting is such
that it rarely emerges".
99. It is then true that, "when the words of a law extend not to an inconvenience rarely happening,
but due to those which often happen, it is good reason not to strain the words further than they
reach, by saying it is casus omissus, and that the law intended quae frequentius accidunt." "But," on
the other hand, "it is no reason, when the words of a law do enough extend to an inconvenience
seldom happening, that they should not extend to it as well as if it happened more frequently,
because it happens but seldom" (See Fenton v.
Hampton (1858) XI Moore, P.C. 347). A casus omissus ought not to be created by interpretation,
save in some case of strong necessity. Where, however, a casus omissus does really occur, either
through the inadvertence of the legislature, or on the principle quod semel aut bis existit praeterunt
legislatores (legislators says pass over that which happens only once or twice), the rule is that the
particular case, thus left unprovided for, must be disposed of according to the law as it existed
before such statute - Casus omissus et oblivioni datus dispositioni communis juris relinquitur; "a
casus omissus,"
observed Buller, J. in Jones v. Smart (1 T.R. 52), "can in no case be supplied by a
court of law, for that would be to make laws."
100. The golden rule for construing wills, statutes, and, in fact, all written instruments has been thus
stated: "The grammatical and ordinary sense of the words is to be adhered to unless that would lead
to some absurdity or some repugnance or inconsistency with the rest of the instrument, in which
case the grammatical and ordinary sense of the words may be modified, so as to avoid that absurdity
and inconsistency, but no further" (See Grey v. Pearson (1857 (6) H.L. Cas. 61). The latter part of
this "golden rule" must, however, be applied with much caution. "if," remarked Jervis, C.J., "the
precise words used are plain and unambiguous in our judgment, we are bound to construe them in
their ordinary sense, even though it lead, in our view of the case, to an absurdity or manifestAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

injustice. Words may be modified or varied where their import is doubtful or obscure. But we
assume the functions of legislators when we depart from the ordinary meaning of the precise words
used, merely because we see, or fancy we see, an absurdity or manifest injustice from an adherence
to their literal meaning" (See Abley v. Dale 11, C.B. 378).
101. Classifications on the basis of castes in the long run has tendency of inherently becoming
pernicious. Therefore, the test of reasonableness has to apply. When the object is elimination of
castes and not perpetuation to achieve the goal of casteless society and a society free from
discrimination of castes judicial review within the permissible limits is not ruled out. But at the
same time compelling State interest can be considered while assessing backwardness. The impact of
poverty on backwardness cannot be lost sight of. Economic liberation and freedom are also
important. In Nagaraj's case (supra) it was inter alia observed as follows:
"44. The above three concepts are independent variable concepts. The application of
these concepts in public employment depends upon quantifiable data in each case.
Equality in law is different from equality in fact. When we construe Article 16(4), it is
equality in fact which plays the dominant role. Backward Classes seek justice.
General class in public employment seeks equity. The difficulty comes in when the
third variable comes in, namely, efficiency in service. In the issue of reservation, we
are being asked to find a stable equilibrium between justice to the backwards, equity
for the forwards and efficiency for the entire system. Equity and justice in the above
context are hard concepts. However, if you add efficiency to equity and justice, the
problem arises in the context of the reservation. This problem has to be examined,
therefore, on the facts of each case. Therefore, Article 16(4) has to be construed in the
light of Article 335 of the Constitution. Inadequacy in representation and
backwardness of the Scheduled Castes and Scheduled Tribes are circumstances which
enable the State Government to act under Article 16(4) of the Constitution. However,
as held by this Court the limitations on the discretion of the Government in the
matter of reservation under Article 16(4) as well as Article 16(4-A) come in the form
of Article 335 of the Constitution.
xx xx xx
46. The point which we are emphasising is that ultimately the present controversy is
regarding the exercise of the power by the State Government depending upon the fact
situation in each case. Therefore, "vesting of the power" by an enabling provision may
be constitutionally valid and yet "exercise of the power" by the State in a given case
may be arbitrary, particularly, if the State fails to identify and measure backwardness
and inadequacy keeping in mind the efficiency of service as required under Article
335.
xx xx xxAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

48. It is the equality "in fact" which has to be decided looking at the ground reality.
Balancing comes in where the question concerns the extent of reservation. If the
extent of reservation goes beyond cut-off point then it results in reverse
discrimination. Anti-discrimination legislation has a tendency of pushing towards de
facto reservation. Therefore, a numerical benchmark is the surest immunity against
charges of discrimination.
49. Reservation is necessary for transcending caste and not for perpetuating it.
Reservation has to be used in a limited sense otherwise it will perpetuate casteism in
the country. Reservation is underwritten by a special justification. Equality in Article
16(1) is individual-specific whereas reservation in Article 16(4) and Article 16(4-A) is
enabling. The discretion of the State is, however, subject to the existence of
"backwardness" and "inadequacy of representation" in public employment.
Backwardness has to be based on objective factors whereas inadequacy has to
factually exist. This is where judicial review comes in. However, whether reservation
in a given case is desirable or not, as a policy, is not for us to decide as long as the
parameters mentioned in Articles 16(4) and 16(4-A) are maintained. As stated above,
equity, justice and merit (Article 335)/efficiency are variables which can only be
identified and measured by the State. Therefore, in each case, a contextual case has to
be made out depending upon different circumstances which may exist State-wise.
xx xx xx
102. In the matter of application of the principle of basic structure, twin tests have to
be satisfied, namely, the "width test" and the test of "identity". As stated hereinabove,
the concept of the "catch-up" rule and "consequential seniority"
are not constitutional requirements. They are not implicit in clauses (1) and (4) of Article 16. They
are not constitutional limitations. They are concepts derived from service jurisprudence. They are
not constitutional principles. They are not axioms like, secularism, federalism, etc. Obliteration of
these concepts or insertion of these concepts does not change the equality code indicated by Articles
14, 15 and 16 of the Constitution. Clause (1) of Article 16 cannot prevent the State from taking
cognizance of the compelling interests of Backward Classes in the society. Clauses (1) and (4) of
Article 16 are restatements of the principle of equality under Article
14. Clause (4) of Article 16 refers to affirmative action by way of reservation. Clause (4) of Article 16,
however, states that the appropriate Government is free to provide for reservation in cases where it
is satisfied on the basis of quantifiable data that Backward Class is inadequately represented in the
services. Therefore, in every case where the State decides to provide for reservation there must exist
two circumstances, namely, "backwardness" and "inadequacy of representation".
As stated above, equity, justice and efficiency are variable factors. These factors are context-specific.
There is no fixed yardstick to identify and measure these three factors, it will depend on the facts
and circumstances of each case. These are the limitations on the mode of the exercise of power byAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

the State. None of these limitations have been removed by the impugned amendments. If the State
concerned fails to identify and measure backwardness, inadequacy and overall administrative
efficiency then in that event the provision for reservation would be invalid. These amendments do
not alter the structure of Articles 14, 15 and 16 (equity code). The parameters mentioned in Article
16(4) are retained. Clause (4- A) is derived from clause (4) of Article 16. Clause (4-A) is confined to
SCs and STs alone. Therefore, the present case does not change the identity of the Constitution. The
word "amendment" connotes change. The question is--whether the impugned amendments discard
the original Constitution. It was vehemently urged on behalf of the petitioners that the Statement of
Objects and Reasons indicates that the impugned amendments have been promulgated by
Parliament to overrule the decisions of this Court. We do not find any merit in this argument. Under
Article 141 of the Constitution the pronouncement of this Court is the law of the land. The
judgments of this Court in Virpal Singh, Ajit Singh (I), Ajit Singh (II) and Indra Sawhney were
judgments delivered by this Court which enunciated the law of the land. It is that law which is
sought to be changed by the impugned constitutional amendments. The impugned constitutional
amendments are enabling in nature. They leave it to the States to provide for reservation. It is well
settled that Parliament while enacting a law does not provide content to the "right". The content is
provided by the judgments of the Supreme Court. If the appropriate Government enacts a law
providing for reservation without keeping in mind the parameters in Article 16(4) and Article 335
then this Court will certainly set aside and strike down such legislation. Applying the "width test",
we do not find obliteration of any of the constitutional limitations.
Applying the test of "identity", we do not find any alteration in the existing structure of the equality
code. As stated above, none of the axioms like secularism, federalism, etc. which are overarching
principles have been violated by the impugned constitutional amendments. Equality has two facets--
"formal equality" and "proportional equality". Proportional equality is equality "in fact" whereas
formal equality is equality "in law".
Formal equality exists in the rule of law. In the case of proportional equality the State is expected to
take affirmative steps in favour of disadvantaged sections of the society within the framework of
liberal democracy. Egalitarian equality is proportional equality.
xx xx xx
107. It is important to bear in mind the nature of constitutional amendments. They are curative by
nature.
Article 16(4) provides for reservation for Backward Classes in cases of inadequate representation in
public employment.
Article 16(4) is enacted as a remedy for the past historical discriminations against a social class. The
object in enacting the enabling provisions like Articles 16(4), 16(4-A) and 16(4-B) is that the State is
empowered to identify and recognise the compelling interests. If the State has quantifiable data to
show backwardness and inadequacy then the State can make reservations in promotions keeping in
mind maintenance of efficiency which is held to be a constitutional limitation on the discretion ofAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

the State in making reservation as indicated by Article 335. As stated above, the concepts of
efficiency, backwardness, inadequacy of representation are required to be identified and measured.
That exercise depends on availability of data. That exercise depends on numerous factors. It is for
this reason that enabling provisions are required to be made because each competing claim seeks to
achieve certain goals. How best one should optimise these conflicting claims can only be done by the
administration in the context of local prevailing conditions in public employment. This is amply
demonstrated by the various decisions of this Court discussed hereinabove. Therefore, there is a
basic difference between "equality in law" and "equality in fact" (see Affirmative Action by William
Darity). If Articles 16(4- A) and 16(4-B) flow from Article 16(4) and if Article 16(4) is an enabling
provision then Articles 16(4-A) and 16(4-B) are also enabling provisions. As long as the boundaries
mentioned in Article 16(4), namely, backwardness, inadequacy and efficiency of administration are
retained in Articles 16(4-A) and 16(4-B) as controlling factors, we cannot attribute constitutional
invalidity to these enabling provisions. However, when the State fails to identify and implement the
controlling factors then excessiveness comes in, which is to be decided on the facts of each case. In a
given case, where excessiveness results in reverse discrimination, this Court has to examine
individual cases and decide the matter in accordance with law.
This is the theory of "guided power". We may once again repeat that equality is not violated by mere
conferment of power but it is breached by arbitrary exercise of the power conferred".
102. In Minerva Mills Ltd. v. Union of India (1980) 3 SCC
625) it was observed as follows:
"57. This is not mere semantics. The edifice of our Constitution is built upon the
concepts crystallised in the preamble. We resolved to constitute ourselves into a
Socialist State which carried with it the obligation to secure to our people justice --
social, economic and political. We, therefore, put Part IV into our Constitution
containing directive principles of State policy which specify the socialistic goal to be
achieved. We promised to our people a democratic polity which carries with it the
obligation of securing to the people liberty of thought, expression, belief, faith and
worship; equality of status and of opportunity and the assurance that the dignity of
the individual will at all costs be preserved. We, therefore, put Part III in our
Constitution conferring those rights on the people. Those rights are not an end in
themselves but are the means to an end. The end is specified in Part IV. Therefore,
the rights conferred by Part III are subject to reasonable restrictions and the
Constitution provides that enforcement of some of them may, in stated uncommon
circumstances, be suspended. But just as the rights conferred by Part III would be
without a radar and a compass if they were not geared to an ideal, in the same
manner the attainment of the ideals set out in Part IV would become a pretence for
tyranny if the price to be paid for achieving that ideal is human freedoms. One of the
faiths of our founding fathers was the purity of means. Indeed, under our law, even a
dacoit who has committed a murder cannot be put to death in the exercise of right of
self-defence after he has made good his escape. So great is the insistence of civilisedAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

laws on the purity of means. The goals set out in Part IV have, therefore, to be
achieved without the abrogation of the means provided for by Part III. It is in this
sense that Parts III and IV together constitute the core of our Constitution and,
combine to form its conscience. Anything that destroys the balance between the two
parts will ipso facto destroy an essential element of the basic structure of our
Constitution".
103. The view was affirmed in T.M.A. Pai Foundation and Ors.
v. State of Karnataka and Ors. (2002 (8) SCC 481)
104. It has been highlighted that Articles 15(4) and 15(5) are irreconcilable. It is pointed out that
Article 30 is not intended to pamper any class of people, but is intended to assure minorities
regarding the right to establish. In that sense, Article 19(1)(g) is applicable. The said right is an
inalienable and sacrosanct right. According to Mr. Venugopal, Article 15(5) carved out an area from
Article 15(4). Article 29(2) has to be read into Article 15(5) as Articles 15(4) and 15(5) operated side
by side. As a result of Article 15(5) by special provision minorities unaided rights are excluded.
Article 30 does not relate to any special right for protection against majority and it cannot be termed
to be any higher right and, therefore, Article 19(1)(g) restriction is not there. The object is not to
create inequality.
105. It is pointed out that both Articles 15(4) and 15(5) begin with non obstante provision. Article
15(5) is a later introduction. It is stated that Article 15(1) has to prevail over Article 15(4) and the
right given to certain class of people in Article 15(4) gets eliminated because of Article 15(5).
106. Provisions of the Constitution have to be read harmoniously and no part can be treated to be
redundant. In our considered view both the provisions operate in different areas though there may
be some amount of overlapping but that does not in any way lead to the conclusion that Article 15(5)
takes away what is provided in Article 15(4).
107. A construction which reduces the statute to a futility has to be avoided. A statute or any
enacting provision therein must be so construed as to make it effective and operative on the
principle expressed in the maxim ut res magis valeat quam pereat i.e. a liberal construction should
be put upon written instruments, so as to uphold them, if possible, and carry into effect the
intention of the parties. [See Broom's Legal Maxims (10th Edn.), p. 361, Craies on Statutes (7th
Edn.), p. 95 and Maxwell on Statutes (11th Edn.).
108. A statute is designed to be workable and the interpretation thereof by a court should be to
secure that object unless crucial omission or clear direction makes that end unattainable. (See
Whitney v. IRC (1926 AC 37) at p. 52 referred to in CIT v. S. Teja Singh (AIR 1959 SC 352) and
Gursahai Saigal v. CIT (AIR 1963 SC 1062).
109. The courts will have to reject that construction which will defeat the plain intention of the
legislature even though there may be some inexactitude in the language used.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(See Salmon v. Duncombe (1886) 11AC 627 at p.634, Curtis v.
Stovin (1889) 22 QBD 513) referred to in S. Teja Singh case .)
110. If the choice is between two interpretations, the narrower of which would fail to achieve the
manifest purpose of the legislation, we should avoid a construction which would reduce the
legislation to futility, and should rather accept the bolder construction, based on the view that
Parliament would legislate only for the purpose of bringing about an effective result. (See Nokes v.
Doncaster Amalgamated Collieries (1940 (3) All ER 549) referred to in Pye v. Minister for Lands for
NSW (1954) 3 All ER 514. The principles indicated in the said cases were reiterated by this Court in
Mohan Kumar Singhania v.
Union of India (1992 Supp (1) SCC 594).
111. The statute must be read as a whole and one provision of the Act should be construed with
reference to other provisions in the same Act so as to make a consistent enactment of the whole
statute.
112. The court must ascertain the intention of the legislature by directing its attention not merely to
the clauses to be construed but to the entire statute; it must compare the clause with other parts of
the law and the setting in which the clause to be interpreted occurs. (See R.S. Raghunath v. State of
Karnataka (1992) 1 SCC 335) Such a construction has the merit of avoiding any inconsistency or
repugnancy either within a section or between two different sections or provisions of the same
statute. It is the duty of the court to avoid a head-
on clash between two sections of the same Act. (See Sultana Begum v. Prem Chand Jain 1997 (1)
SCC 373.)
113. Whenever it is possible to do so, it must be done to construe the provisions which appear to
conflict so that they harmonise. It should not be lightly assumed that Parliament had given with one
hand what it took away with the other.
114. The provisions of one section of the statute cannot be used to defeat those of another unless it is
impossible to effect reconciliation between them. Thus a construction that reduces one of the
provisions to a "useless lumber" or "dead letter" is not a harmonized construction. To harmonise is
not to destroy.
115. The Constitution of India is not intended to be static. It is by its very nature dynamic. It is a
living and organic thing. It is an instrument which has greatest value to be construed. "Ut Res Valeat
Potius Quam Pereat" (the construction should be preferred which makes the machinery workable).
Our Constitution reflects the beliefs and political aspirations of those who had framed it. It is
therefore desirable that while considering the question as to whether 27% fixed for the other
backward classes to be maintained without definite data the rights of those who belong to the
unfortunate categories of other economic backward classes deserve to be concerned, else there shallAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

be no definite determination of number of other backward classes. While fixing the measure for
creamy layer it would not be difficult also to fix the norms for the socially and economically
backward classes rather the latter exercise would be easier to undertake.
116. In Indra Sawhney's No.1 the desirability of excluding some posts from the zone of reservation
was highlighted. It was also emphasized that periodic review of policy of reservation was imperative.
It was inter-alia observed as follows:
"838. While on Article 335, we are of the opinion that there are certain services and
positions where either on account of the nature of duties attached to them or the level
(in the hierarchy) at which they obtain, merit as explained hereinabove, alone counts.
In such situations, it may not be advisable to provide for reservations. For example
technical posts in research and development organizations/departments/institutions,
in specialties and super-specialties in medicine, Engineering and other such courses
in physical sciences and mathematics in defence services and in the establishment
connected therewith. Similarly, in the case of posts at the higher echelons e.g.
Professors (in Education), Pilots in Indian Airlines and Air India, Scientists and
Technicians in Nuclear and Space application, provision for reservation would not be
advisable.
xx xx xx
840. We may point out that the services/posts enumerated above, on account of their
nature and duties attached, are such as call for highest level of intelligence, skill and
excellence. Some of them are second level and third level posts in the ascending
order. Hence, they form a category apart. Reservation therein may not be consistent
with "efficiency of administration" contemplated by Article 335.
xx xx xx
859. "We may summarise our answers to the various questions dealt with and
answered hereinabove; (1) (a) It is not necessary that the `provision' under Article
16(4) should necessarily be made by the Parliament/Legislature. Such a provision can
be made by the Executive also. Local bodies, statutory Corporations and other
instrumentalities of the State falling under Article 12 of the Constitution are
themselves competent to make such a provision, if so advised.
(b) An executive order making a provision under Article 16(4) is enforceable the
moment it is made and issued.
(2) (a) Clause (4) of Article 16 is not an exception to clause (1). It is an instance and
an illustration of the classification inherent in clause (1).Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(b) Article 16(4) is exhaustive of the subject of reservation in favour of backward class
of citizens, as explained in this judgment.
(c) Reservations can also be provided under clause (1) of Article 16. It is not confined
to extending of preferences, concessions or exemptions alone. These reservations, if
any, made under clause (1) have to be so adjusted and implemented as not to exceed
the level of representation prescribed for `backward class of citizens' - as explained in
this judgment.
3. (a) A caste can be and quite often is a social class in India. If it is backward socially, it would be a
backward class for the purposes of Article 16(4). Among non-Hindus, there are several occupational
groups, sets and denominations, which for historical reasons are socially backward. They too
represent backward, social collectivities for the purposes of Article 16(4).
(b) Neither the Constitution nor the law prescribes the procedure or method of identification of
backward classes. Nor is it possible or advisable for the court to lay down any such procedure or
method. It must be left to the authority appointed to identify. It can adopt such method/procedure
as it thinks convenient and so long as its survey covers the entire populace, no objection can be
taken to it. Identification of the backward classes can certainly be done with reference to castes
among, and alongwith, other occupational groups, classes and sections of people. One can start the
process either with occupational groups or with castes or with some other groups. Thus one can
start the process with castes, wherever they are found, apply the criteria (evolved for determining
backwardness) and find out whether it satisfy the criteria. If it does-what emerges is a "backward
class of citizens" within the meaning of and for the purposes of Article 16(4). Similar process can be
adopted in the case of other occupational groups, communities and classes so as to cover the entire
populace. The central idea and overall objective should be to consider all available groups, sections
and classes in society. Since caste represents an existing, identifiable social group/class
encompassing an overwhelming minority of the country's population, one can well begin with it and
then go to other groups, sections and classes.
(c) It is not correct to say that the backward class of citizens contemplated in Article 16(4) is the
same as the socially and educationally backward classes referred to in Article 15(4). It is much wider.
The accent in Article 16(4) is on social backwardness. Of course, social, educational and economic
backwardness are closely inter-twined in the Indian context.
(d) `Creamy layer' can be, and must be excluded.
(e) It is not necessary for a class to be designated as a backward class that it is situated similarly to
the Scheduled Castes/Scheduled Tribes.
f) The adequacy of representation of a particular class in the services under the State is a matter
within the subjective satisfaction of the appropriate Government. The judicial scrutiny in that behalf
is the same as in other matters within the subjective satisfaction of an authority.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(4) (a) A backward class of citizens cannot be identified only and exclusively with reference to
economic criteria.
(b) It is, of course, permissible for the Government or other authority to identify a backward class of
citizens on the basis of occupation cum income, without reference to caste, if it is so advised.
5. There is no constitutional bar to classify the backward classes of citizens into backward and more
backward categories.
6. (a) and (b) The reservations contemplated in clause (4) of Article 16 should not exceed 50%.
While 50% shall be the rule, it is necessary not to put out of consideration certain extra ordinary
situation inherent in the great diversity of this country and the people.
117. In Vasanth Kumar's case (supra) at para 2(4), it was observed as follows:
"2(4). The policy of reservations in employment, education and legislative
institutions should be reviewed every five years or so. That will at once afford an
opportunity (i) to the State to rectify distortions arising out of particular facets of the
reservation policy and (ii) to the people, both backward and non-backward, to
ventilate their views in a public debate on the practical impact of the policy of
reservations."
118. In State of A.P. & Anr. v. P. Sagar (1968 (3) SCR 595) at para 15, it was observed as follows:
"Article 15 guarantees by the first clause a fundamental right of far-reaching
importance to the public generally. Within certain defined limits an exception has
been engrafted upon the guarantee of the freedom in cl. (1), but being in the nature of
an exception, the conditions which justify departure must be strictly shown to exist.
When a dispute is raised before a Court that a particular law which is inconsistent
with the guarantee against discrimination is valid on the plea that it is permitted
under clause (4) of Art. 15 the assertion by the State that the officers of the State had
taken into consideration the criteria which had been adopted by the Courts for
determining who the socially and educationally backward classes of the Society are,
or that the authorities had acted in good faith in determining the socially and
educationally backward classes of citizens, would not be sufficient to sustain the
validity of the claim. The Courts of the country are invested with the power to
determine the validity of the law which infringes the fundamental rights of citizens
and others and when a question arises whether a law which prima facie infringes a
guaranteed fundamental right is within an exception, the validity of that law has to be
determined by the Courts on materials placed before them. By merely asserting that
the law was made after full consideration of the relevant evidence and criteria which
have a bearing thereon, and was within the exception, the jurisdiction of the Courts to
determine whether by making the law a fundamental right has been infringed is not
excluded."Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

119. Significant observations were made in Kumari K.S. Jayasree and Anr. v. The State of Kerala and
Anr. (1976 (3) SCC 730 ). At para 22 it was noted as follows:
."The problem of determining who are socially and educationally backward classes is
undoubtedly not simple. Sociological and economic considerations come into play in
evolving proper criteria for its determination. This is the function of the State. The
Court's jurisdiction is to decide whether the tests applied are valid. If it appears that
tests applied are proper and valid the classification of socially and educationally
backward classes based on the tests will have to be consistent with the requirements
of Article 15(4). The Commission has found on applying the relevant tests that the
lower income group of the communities named in Appendix VIII of the Report
constitute the socially and educationally backward classes. In dealing with the
question as to whether any class of citizens is socially backward or not, it may not be
irrelevant to consider the caste of the said group of citizens. It is necessary to
remember that special provision is contemplated for classes of citizens and not for
individual citizens as such, and so though the caste of the group of citizen may be
relevant, its importance should not be exaggerated. If the classification is based solely
on caste of the citizen, it may not be logical. Social backwardness is the result of
poverty to a very large extent. Caste and poverty are both relevant for determining
the backwardness. But neither caste alone nor poverty alone will be the determining
tests. When the Commission has determined a class to be socially and educationally
backward it is not on the basis of income alone, and the determination is based on
the relevant criteria laid down by the Court. Evidence and material are placed before
the Commission. Article 15(4) which speaks of backwardness of classes of citizens
indicates that the accent is on classes of citizens. Article 15(4) also speaks of
Scheduled Castes and Scheduled Tribes. Therefore, socially and educationally
backward classes of citizens in Article 15(4) cannot be equated with castes. In R.
Chitralekha and Anr. v. State of Mysore and Ors. ( 1964 (6) SCR 368 ) this Court said
that the classification of backward classes based on economic conditions and
occupations does not offend Article 15(4)."
120. Further, in Minor A. Peeriakaruppan, Sobha Joseph v.
State of Tamil Nadu and Ors. (1971 (1) SCC 38) at para 29 it was observed as follows:
"Rajendran's case (1968 (2) SCR 786) is an authority for the proposition that the
classification of backward classes on the basis of castes is within the purview of
Article 15(4) if those castes are shown to be socially and educationally backward. No
further material has been placed before us to show that the reservation for backward
classes with which we are herein concerned is not in accordance with Article 15(4).
There is no gainsaying the fact the there are numerous castes in this country which
are socially and educationally backward. To ignore their existence is to ignore the
facts of life. Hence we are unable to uphold the contention that impugned reservation
is not in accordance with Article 15(4). But all the same the Government should notAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

proceed on the basis that once a class is considered as a backward class it should
continue to be backward class for all times. Such an approach would defeat the very
purpose of the reservation because once a class reaches a stage of progress which
some modern writers call as take off stage then competition is necessary for their
future progress. The Government should always keep under review the question of
reservation of seats and only the classes which are really socially and educationally
backward should be allowed to have the benefit of reservation. Reservation of seats
should not be allowed to become a vested interest. The fact that candidates of
backward classes have secured about 50% of the seats in the general pool does show
that the time has come for a de novo comprehensive examination of the question. It
must be remembered that the Government's decision in this regard is open to judicial
review."
121. It has been highlighted that the Act has been made applicable to Central Educational
Institutions established, maintained or aided by the Central Government. Central Educational
Institutions have been defined in Section 2(d) as follows:
"2(d) Central Educational Institution" means-
(i) a university established or incorporated by or under a Central Act;
(ii) an institution of national importance set up by an Act of Parliament;
(iii) an institution, declared as a deemed University under Section 3 of the University
Grants Commission Act, 1956 and maintained by or receiving aid from the Central
Government;
(iv) an institution maintained by or receiving aid from the Central Government,
whether directly or indirectly, and affiliated to an institution referred to in clause
(i) or clause (ii), or a constituent unit of an institution referred to in clause (iii);
(v) an educational institution set up by the Central Government under the Societies
Registration Act, 1860."
122. It is pointed out that there cannot be any reservations in respect of super specialities and
institutions imparting education of highly complex subjects. The example of All India Institute of
Medical Sciences has been given. It has been pointed out that its status as an institution for super
speciality has been judicially recognized. It needs to be noted that in terms of Section 4(b) of the Act
certain educational institutions have been excluded from the operation of the Act.
123. The Act has been made inapplicable to them. It is to be noted that in the said provision,
institutions of research, institutions of excellence, institutions of national and strategic importance
have been specified in the Schedule to the Act.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

The proviso permits the Central Government as and when considered necessary to amend the
Schedule. In other words, on an appropriate case being presented and established before the Central
Government that the Institution is of excellence and/or a research institute and/or an institution of
national and strategic importance, the Central Government can amend the Schedule and include
such institution in the Schedule. In other words, it is permissible for the petitioners and anybody
else to highlight to the Government about the desirability to include an Institution in the Schedule of
the Act.
124. One of the major issues highlighted by Mr. P.P. Rao was that in several cases the matriculation
standard of education was considered to be the measure for measuring backwardness. It is,
therefore, submitted that when at least half of the persons belonging to a particular caste have
reached the matriculation level of education, they cannot be considered to be educationally
backward any longer. It is therefore submitted that if that be taken as a yardstick for measuring
backwardness then the reservation of seats for technical education or in higher studies cannot be
sustained.
It has also been highlighted that the shift of emphasis from primary and basic education to higher
education is against the constitutional mandate making education compulsory in terms of Article
21-A of the Constitution. It is not correct to contend that in fixing the priorities the Government is
the best Judge as contended by the respondents. It may be correct in matters relating to simple
policy decisions but when the constitutional mandate is under consideration the underlying object
has also to be kept in view. In this context reference is made to Article 46 of the Constitution. It is in
that background pointed out by learned counsel for the petitioners that what cannot be lost sight of
is the fact that is the foundation for basic, elementary and primary education. The educational
backwardness can be obliterated when at least half of the persons belonging to a particular caste
come up to a matriculation level.
125. There is substance in this plea. It is not merely the existence of schemes but the effective
implementation of the schemes that is important. It is to be noted that financial constraint cannot
be a ground to deny fundamental rights and the provision for the schemes and the utilization of the
funds are also relevant factors. It appears that better coordination between the funds provider and
the utiliser is necessary. It is suggested that putting stress on cut off limit by shifting from
matriculation to Class XII level education as a benchmark of gauging educational backwardness will
be a step in the right direction. Though as rightly contended by Mr. P.P. Rao that in several
decisions, for example, M.R. Balaji's case (supra), Balram's case (supra) and Kumari K.S. Jayasree's
case (supra) the secondary education was taken to be the benchmark, ground reality cannot be lost
sight of that with the limited availability of jobs and the spiraling increase in population, secondary
or matriculation examination can no longer be considered to be an appropriate bench mark. It has
to be at the most graduation. But the question arises whether technical education can be included
while considering educational backwardness. A delicate balancing has to be done in this regard.
While technical education cannot be the sole criteria for gauging educational backwardness it
definitely will form part of 50 per cent norms fixed by this Court. Slightly variable plus or minus
would be the appropriate standard to gauge educational backwardness.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

126. One of the grey areas which have been highlighted by learned counsel for the petitioners is that
caste is not a substitute for class and nevertheless the two terms are not synonyms. Much of the
argument in this regard is centred round the paragraphs 782 and 783 of Indra Sawhney No.1
(supra). The same read as under:
"782. Coming back to the question of identification, the fact remains that one has to
begin somewhere -- with some group, class or section. There is no set or recognised
method. There is no law or other statutory instrument prescribing the methodology.
The ultimate idea is to survey the entire populace. If so, one can well begin with
castes, which represent explicit identifiable social classes/groupings, more
particularly when Article 16(4) seeks to ameliorate social backwardness. What is
unconstitutional with it, more so when caste, occupation poverty and social
backwardness are so closely intertwined in our society? [Individual survey is out of
question, since Article 16(4) speaks of class protection and not individual protection].
This does not mean that one can wind up the process of identification with the castes.
Besides castes (whether found among Hindus or others) there may be other
communities, groups, classes and denominations which may qualify as backward
class of citizens. For example, in a particular State, Muslim community as a whole
may be found socially backward. (As a matter of fact, they are so treated in the State
of Karnataka as well as in the State of Kerala by their respective State Governments).
Similarly, certain sections and denominations among Christians in Kerala who were
included among backward communities notified in the former princely State of
Travancore as far back as in 1935 may also be surveyed and so on and so forth. Any
authority entrusted with the task of identifying backward classes may well start with
the castes. It can take caste `A', apply the criteria of backwardness evolved by it to
that caste and determine whether it qualifies as a backward class or not. If it does
qualify, what emerges is a backward class, for the purposes of clause (4) of Article 16.
The concept of `caste' in this behalf is not confined to castes among Hindus. It
extends to castes, wherever they obtain as a fact, irrespective of religious sanction for
such practice. Having exhausted the castes or simultaneously with it, the authority
may take up for consideration other occupational groups, communities and classes.
For example, it may take up the Muslim community (after excluding those sections,
castes and groups, if any, who have already been considered) and find out whether it
can be characterised as a backward class in that State or region, as the case may be.
The approach may differ from State to State since the conditions in each State may
differ from State to State since the conditions in each State may differ. Nay, even
within a State, conditions may differ from region to region. Similarly, Christians may
also be considered. If in a given place, like Kerala, there are several denominations,
sections or divisions, each of these groups may separately be considered. In this
manner, all the classes among the populace will be covered and that is the central
idea. The effort should be to consider all the available groups, sections and classes of
society in whichever order one proceeds. Since caste represents an existing,
identifiable, social group spread over an over whelming majority of the country's
population, we say one may well begin with castes, if one so chooses, and then go toAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

other groups, sections and classes. We may say, at this stage, that we broadly
commend the approach and methodology adopted by the Justice O. Chinnappa
Reddy Commission in this respect.
783. We do not mean to suggest -- we may reiterate -- that the procedure indicated
hereinabove is the only procedure or method/approach to be adopted. Indeed, there
is no such thing as a standard or model procedure/approach. It is for the authority
(appointed to identify) to adopt such approach and procedure as it thinks
appropriate, and so long as the approach adopted by it is fair and adequate, the court
has no say in the matter. The only object of the discussion in the preceding para is to
emphasise that if a Commission/Authority begins its process of identification with
castes (among Hindus) and occupational groupings among others, it cannot by that
reason alone be said to be constitutionally or legally bad. We must also say that there
is no rule of law that a test to be applied for identifying backward classes should be
only one and/or uniform. In a vast country like India, it is simply not practicable. If
the real object is to discover and locate backwardness, and if such backwardness is
found in a caste, it can be treated as backward; if it is found in any other group,
section or class, they too can be treated as backward."
127. On a closer reading of the paragraphs it appears that this Court took note of the fact that several
religions do not have any caste. Therefore, the first sentence of para`782 lays emphasis to begin
somewhere - with some group, class or section. It also states that there is no set or recognized
method and there is no law or other statutory instrument prescribing the methodology. In this
context, it has also been stated that one can well begin with castes which represent explicit
identifiable social classes or groupings. Therefore, the emphasis was on beginning with castes which
represent as explicit identifiable social classes or grouping. Again in paragraph 783, it has been
stated that in a vast country like India it is simply not practicable to fix the test for identifying
backward classes. In that background it was held that if the real objective is to discover and locate
the real backwardness and if such backwardness is found in a caste it can be considered as
backwardness. Similarly if it is found in any other group, section or class they too can be treated as
backward. The intention therefore is clear that if caste is found to be backward it can certainly be
treated as backward.
To give any other meaning would be adding or subtracting to what has been specifically stated in the
decision.
128. It is also relevant to take note of certain earlier decisions referred to in Indra Sawhney No.1 case
(supra) which throw beacon light on the issue. They are as under:
1. M.R. Balaji v. State of Mysore,1963 Supp (1) SCR "Article 15(4) authorises the State
to make a special provision for the advancement of any socially and educationally
backward classes of citizens, as distinguished from the Scheduled Castes and
Scheduled Tribes. No doubt, special provision can be made for both categories of
citizens, but in specifying the categories, the first category is distinguished from theAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

second. Sub-clauses (24) and (25) of Article 366 define Scheduled Castes and
Scheduled Tribes respectively, but there is no clause defining socially and
educationally backward classes of citizens, and so, in determining the question as to
whether a particular provision has been validly made under Article 15(4) or not, the
first question which falls to be determined is whether the State has validly
determined who should be included in these Backward Classes. It seems fairly clear
that the backward classes of citizens for whom special provision is authorised to be
made are, by Article 15(4) itself, treated as being similar to the Scheduled Castes and
Scheduled Tribes. Scheduled Castes and Scheduled Tribes which have been defined
were known to be backward and the Constitution-makers felt no doubt that special
provision had to be made for their advancement. It was realised that in the Indian
Society there were other classes of citizens who were equally, or may be somewhat
less, backward than the Scheduled Castes and Tribes and it was thought that some
special provision ought to be made even for them.
Let us take the question of social backwardness first. By what test should it be decided whether a
particular class is socially backward or not? The group of citizens to whom Article 15(4) applies are
described as "classes of citizens", not as castes of citizens. A class, according to the dictionary
meaning, shows division of society according to status, rank or caste. In the Hindu social structure,
caste unfortunately plays an important part in determining the status of the citizen. Though
according to sociologists and vedic scholars, the caste system may have originally begun on
occupational or functional basis, in course of time, it became rigid and inflexible. The history of the
growth of caste system shows that its original functional and occupational basis was later
over-burdened with considerations of purity based on ritual concepts, and that led to its
ramifications which introduced inflexibility and rigidity.
This artificial growth inevitably tended to create a feeling of superiority and inferiority, and to foster
narrow caste loyalties.
Therefore, in dealing with the question as to whether any class of citizens is socially backward or
not, it may not be irrelevant to consider the caste of the said group of citizens. In this connection it
is, however, necessary to bear in mind that the special provision is contemplated for classes of
citizens and not for individual citizens as such, and so, though the caste of the group of citizens may
be relevant, its importance should not be exaggerated. If the classification of backward classes of
citizens was based solely on the caste of the citizen, it may not always be logical and may perhaps
contain the vice of perpetuating the castes themselves.
xx xx xx Besides, if the caste of the group of citizens was made the sole basis for determining the
social backwardness of the said group, that test would inevitably break down in relation to many
sections of Indian society which do not recognise castes in the conventional sense known to Hindu
society. How is one going to decide whether Muslims, Christians or Jains, or even Lingayats are
socially backward or not? The test of castes would be inapplicable to those groups, but that would
hardly justify the exclusion of these groups in toto from the operation of Article 15(4). It is not
unlikely that in some States some Muslims or Christians or Jains forming groups may be sociallyAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

backward. That is why we think that though castes in relation to Hindus may be a relevant factor to
consider in determining the social backwardness of groups or classes of citizens, it cannot be made
the sole or the dominant test in that behalf.
Social backwardness is on the ultimate analysis the result of poverty to a very large extent. The
classes of citizens who are deplorably poor automatically become socially backward. They do not
enjoy a status in society and have, therefore, to be content to take a backward seat. It is true that
social backwardness which results from poverty is likely to be aggravated by considerations of caste
to which the poor citizens may belong, but that only shows the relevance of both caste and poverty
in determining the backwardness of citizens.
2. R. Chitralekha v State of Mysore AIR 1964 SC 1823 Justice Subba Rao referred to the
observations in M.R. Balaji v. State of Mysore and observed:
"15. Two principles stand out prominently from the said observations, namely, (i) the
caste of a group of citizens may be a relevant circumstance in ascertaining their social
backwardness; and (ii) though it is a relevant factor to determine the social
backwardness of a class of citizens, it cannot be the dole or dominant test in that
behalf. The observations extracted in the judgment of the High Court appear to be in
conduct with the observations of this Court. While this Court said that caste is only a
relevant circumstance and that it cannot be the dominant test in ascertaining the
backwardness of a class of citizens, the High Court said that it is an important basis
in determining the class of backward Hindus and that the Government should have
adopted caste as one of the tests. As the said observations made by the High Court
may lead to some confusion in the mind of the authority concerned who may be
entrusted with the duty of prescribing the rules for ascertaining the backwardness of
classes of citizens within the meaning of Art. 15(4) of the Constitution, we would
hasten to make it clear that caste is only a relevant circumstance in ascertaining the
backwardness of a class and there is nothing in the judgment of this Court which
precludes the authority concerned from determining the social backwardness of a
group of citizens if it can do so without reference to caste. While this Court has not
excluded caste from ascertaining the backwardness of a class of citizens, it has not
made it one of the compelling circumstances affording a basis for the ascertainment
of backwardness of a class. To put it differently, the authority concerned may take
caste into consideration in ascertaining the backwardness of a group of persons; but,
if it does not, its order will not be bad on that account, if it can ascertain the
backwardness of a group of persons on the basis of other relevant criteria.
19......The important factor to be noticed in Art. 15(4) is that it does not speak of
castes, but only speaks of classes. If the makers of the Constitution intended to take
castes also as units of social and educational backwardness, they would have said so
as they have said in the case of the Scheduled Castes and the Scheduled Tribes.
Though it may be suggested that the wider expression "classes" is used in clause (4)
of Art. 15 as there are communities without castes, if the intention was to equateAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

classes with castes, nothing prevented the makers of the Constitution from using the
expression "backward classes or castes". The juxtaposition of the expression
"backward classes" and "Scheduled Castes" in Art. 15(4) also leads to a reasonable
inference that the expression "classes" is not synonymous with castes. It may be that
for ascertaining whether a particular citizen or a group of citizens belong to a
backward class or not, his or their caste may have some relevance, but it cannot be
either the sole or the dominant criterion for ascertaining the class to which he or they
belong.
20. This interpretation will carry out the intention of the Constitution expressed in
the aforesaid Articles. It helps the really backward classes instead of promoting the
interests of individuals or groups who, though they belong to a particular caste a
majority whereof is socially and educationally backward, really belong to a class
which is socially and educationally advanced. To illustrate, take a caste in a State
which is numerically the largest therein. It may be that though a majority of the
people in that caste are socially and educationally backward, an effective minority
may be socially and educationally far more advanced than another small sub- caste
the total number of which is far less than the said minority. If we interpret the
expression "classes" as "castes", the object of the Constitution will be frustrated and
the people who do not deserve any adventitious aid may get it to the exclusion of
those who really deserve. This anomaly will not arise if, without equating caste with
class, caste is taken as only one of the considerations to ascertain whether a person
belongs to a backward class or not. On the other hand, if the entire sub-caste, by and
large, is backward, it may be included in the Scheduled Castes by following the
appropriate procedure laid down by the Constitution.
21. We do not intend to lay down any inflexible rule for the Government to follow.
The laying down of criteria for ascertainment of social and educational backwardness
of a class is a complex problem depending upon many circumstances which may vary
from State to State and even from place to place in a State. But what we intend to
emphasize is that under no circumstances a "class" can be equated to a "caste",
though the caste of an individual or a group of individual may be considered along
with other relevant factors in putting him in a particular class. We would also like to
make it clear that if in a given situation caste is excluded in ascertaining a class
within the meaning of Art. 15(4) of the Constitution, it does not vitiate the
classification if it satisfied other tests.
3. Minor P. Rajendran v State of Madras (1968 (2) SCR
787) "The first challenge is to r. 5 on the ground that it violates Art.
15 of the Constitution. Article 15 forbids discrimination against any citizen on the grounds only of
religion, race, caste, sex, place of birth or any of them. At the same time Art. 15(4) inter alia permits
the State to make any special provision for the advancement of any socially and educationallyAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

backward classes of citizens. The contention is that the list of socially and educationally backward
classes for whom reservation is made under r. 5 is nothing but a list of certain castes.
Therefore, reservation in favour of certain castes based only on caste considerations violates Art.
15(1), which prohibits discrimination on the ground o caste only. Now if the reservation in question
had been based only on caste and had not taken into account the social and educational
backwardness of the caste in question, it would be violative of Art. 15(1). But it must not be forgotten
that a caste is also a class of citizens and if the caste as a whole is socially and educationally
backward reservation can be made in favour of such a caste on the ground that it is a socially and
educationally backward class of citizens within the meaning of Art. 15(4). Reference in this
connection may be made to the observations of this Court in M. R. Balaji v. State of Mysore ([1963]
Supp. 1 S.C.R. 439 at p. 459-460) to the effect that it was not irrelevant to consider the caste of a
class of citizens in determining their social and educational backwardness. It was further observed
that though the caste of a class of citizens may be relevant its importance should not be exaggerated;
and if classification of backward classes of citizens was based solely on the caste of the citizen, it
might be open to objection.
It is true that in the present cases the list of socially and educationally backward classes has been
specified by caste.
But that does not necessarily mean that caste was the sole consideration and that persons belonging
to these castes are also not a class of socially and educationally backward citizens. In its reply, the
State of Madras has given the history as to how this list of backward classes was made, starting from
the year 1906 and how the list has been kept upto date and necessary amendments made therein. It
has also been stated that the main criterion for inclusion in the list was the social and educational
backwardness of the caste based on occupations pursued by these castes. Because the members of
the caste as a whole were found to be socially and educationally backward, they were put in the list.
The matter was finally examined after the Constitution came into force in the light of the provisions
contained in Art. 15(4). As it was found that members of these castes as a whole were educationally
and socially backward, the list which had been coming on from as far back as 1906 was finally
adopted for purposes of Art. 15(4). In short the case of the State of Madras is that the castes included
in the list are only a compendious indication of the class of people in those castes and these classes
of people had been put in the list for the purpose of Art. 15(4) because they had been found to be
socially and educationally backward.
This is the position as explained in the Affidavit filed on behalf of the State of Madras. On the other
hand the only thing stated in the petitions is that as the list is based on caste alone it is violative of
Art. 15(1). In view however of the explanation given by the State of Madras, which has not been
controverted by any rejoinder, it must be accepted that though the list shows certain castes, the
members of those castes are really classes of educationally and socially backward citizens.
No attempt was made on behalf of the petitioners/appellant to show that any caste mentioned in
this list was not educationally and socially backward. No such averment was made in the affidavit in
support of their cases, nor was any attempt made to traverse the case put forward on behalf of theAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

State of Madras by filing a rejoinder affidavit to show that even one of the castes included in the list
was not educationally and socially backward. In this state of the pleadings, we must come to the
conclusion that though the list is prepared caste-
wise, the castes included therein are as a whole educationally and socially backward and therefore
the list is not violate of Art. 15. The challenge to r. 5 must therefore fail.
4) State of Andhra Pradesh v P. Sagar (1968 (3) SCR 595) "In the context in which it occurs the
expression "class" means a homogeneous section of the people grouped together because of certain
likenesses or common traits and who are identifiable by some common attributes such as status,
rank, occupation, residence in a locality, race, religion and the like.
In determining whether a particular section forms a class, caste cannot be excluded altogether. But
in the determination of a class a test solely based upon the caste or community cannot also be
accepted. By cl. (1) Art. 15 prohibits the State from discriminating against any citizen on grounds
only of religion, race, caste, sex, place of birth or any of them. By cl.
(3) of Art. 15 the State is, notwithstanding the provision contained in cl. (1), permitted to make
special provision for women and children. By cl. (4) a special provision for the advancement of any
socially and educationally backward classes of citizens or for the Scheduled Castes and Scheduled
Tribes is outside the purview of cl. (1). But cl. (4) is an exception to cl. (1). Being an exception, it
cannot be extended so as in effect to destroy the guarantee of cl. (1). The Parliament has by enacting
cl. (4) attempted to balance as against the right of equality of citizens the special necessities of the
weaker sections of the people by allowing a provision to be made for their advancement. In order
that effect may be given to cl. (4), it must appear that the beneficiaries of the special provision are
classes which are backward socially and educationally and they are other that the Scheduled Castes
and Scheduled Tribes, and that the provision made is for their advancement."
5. Minor A. Peeriakaruppan (Minor) v. State of T.N., (1971) 1 SCC 38 :
"25. A caste has always been recognized as a class. In construing the expression
"classes of His Majesty's subject"
found in Section 153-A of the Indian Penal Code, Wassoodew, J., observed in Narayan Vasudev v.
Emperor AIR 1940 Bomb "In my opinion, the expression `classes of His Majesty's subjects' in
Section 153-A of the Code is used in restrictive sense as denoting a collection of individuals or
groups bearing a common and exclusive designation and also possessing common and exclusive
characteristics which may be associated with their origin, race or religion, and that the term `class'
within that section carries with it the idea of numerical strength so large as could be grouped in a
single homogeneous community."
26. In para 10, Chapter V of the Backward Classes Commission's Report, it is observed:Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"We tried to avoid caste but we find it difficult to ignore caste in the present
prevailing conditions. We wish it were easy to dissociate caste from social
backwardness at the present juncture. In modern time anybody can take to any
profession. The Brahman taking to tailoring, does not become a tailor by caste, nor is
his social status lowered as a Brahman. A Brahman may be a seller of boots and
shoes, and yet his social status is not lowered thereby. Social backwardness,
therefore, is not today due to the particular profession of a person, but we cannot
escape caste in considering the social backwardness in India.
In para 11 of that Report it is stated:
"It is not wrong to assume that social backwardness has largely contributed to the
educational backwardness of a large number of social groups."
27. Finally in para 13, the committee concludes with following observations:
"All this goes to prove that social backwardness is mainly based on racial, tribal, caste
and denominational differences."
28. The validity of the impugned list of backward classes came up for consideration before this
Court in Rajendran case and this is what this Court observed therein:
"The contention is that the list of socially and educationally backward classes for
whom reservation is made under Rule 5 nothing but a list of certain castes.
Therefore, reservation in favour of certain castes based only on caste considerations
violates Article 15(1), which prohibits discrimination on the ground of caste only.
Now if the reservation in question had been based only on caste and had not taken
into account the social and educational backwardness of the justice in question, it
would be violative of Article 15(1). But it must not be forgotten that a caste is also a
class of citizens and if the caste as a whole is socially and educationally backward,
reservation can be made in favour of such a caste on the ground that it is a socially
and educationally backward class of citizens within the meaning of Article 15(4)."
29. Rajendran case is an authority for the proposition that the classification of backward classes on
the basis of castes is within the purview of Article 15(4) if those castes are shown to be socially and
educationally backward. No further material has been placed before us to show that the reservation
for backward classes with which we are herein concerned is not in accordance with Article 15(4).
There is no gainsaying the fact that there are numerous castes in this country which are socially and
educationally backward. To ignore their existence is to ignore the facts of life. Hence we are unable
to uphold the contention that the impugned reservation is not in accordance with Article 15(4). But
all the same the Government should not proceed on the basis that once a class is considered as a
backward class it should continue to be backward class for all times. Such an approach would defeat
the very purpose of the reservation because once a class reaches a stage of progress which some
modern writers call as take off stage then competition is necessary for their future progress. TheAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Government should always keep under review the question of reservation of seats and only the
classes which are really socially and educationally backward should be allowed to have the benefit of
reservation. Reservation of seats should not be allowed to become a vested interest. The fact that
candidates of backward classes have secured about 50% of the seats in the general pool does show
that the time has come for a de novo comprehensive examination of the question. It must be
remembered that the Government's decision in this regard is open to judicial review."
6. State of A.P. v. U.S.V. Balram, (1972) 1 SCC 660, at page 685 :
"82......In the determination of a class to be grouped as backward, a test solely based
upon caste or community cannot be accepted as valid. But, in our opinion, though
Directive Principles contained in Article 46 cannot be enforced by courts. Article
15(4) will have to be given effect to in order to assist the weaker sections of the
citizens, as the State has been charged with such a duty. No doubt, we are aware that
any provision made under this clause must be within the well defined limits and
should not be on the basis of caste alone. But it should not also be missed that a caste
is also a class of citizens and that a caste as such may be socially and educationally
backward. If after collecting the necessary data, it is found that the caste as a whole is
socially and educationally backward, in our opinion, the reservation made of such
persons will have to be upheld notwithstanding the fact that a few individuals in that
group may be both socially and educationally above the general average. There is no
gainsaying the fact that there are numerous castes in the country, which are socially
and educationally backward and therefore a suitable provision will have to be made
by the State, as charged in Article 15(4) to safeguard their interest".
xx xx xx
94. To conclude, though prima facie the list of Backward Classes which is under
attack before us may be considered to be on the basis of caste, a closer examination
will clearly show that it is only a description of the group following the particular
occupations or professions, exhaustively referred to by the Commission. Even on the
assumption that the list is based exclusively on caste, it is clear from the materials
before the Commission and the reasons given by it in its report that the entire caste is
socially and educationally backward and therefore their inclusion in the list of
Backward Classes is warranted by Article 15(4). The groups mentioned therein have
been included in the list of Backward Classes as they satisfy the various tests, which
have been laid down by this Court for ascertaining the social and educational
backwardness of a class."
7. Janki Prasad Parimoo v. State of J&K, (1973) 1 SCC 420, at page 432 :
"22. Article 15(4) speaks about "socially and educationally backward classes of
citizens" while Article 16(4) speaks only of "any backward class citizens". However, it
is now settled that the expression "backward class of citizens" in Article 16(4) meansAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

the same thing as the expression "any socially and educationally backward class of
citizens" in Article 15(4). In order to qualify for being called a "backward class citizen"
he must be a member of a socially and educationally backward class. It is social and
educational backwardness of a class which is material for the purposes of both
Articles 15(4) and 16(4)."
xx xx xx
24. It is not merely the educational backwardness or the social backwardness which
makes a class of citizens backward; the class identified as a class as above must be
both educationally and socially backward. In India social and educational
backwardness is further associated with economic backwardness and it is observed in
Balaji case referred to above that backwardness, socially and educationally, is
ultimately and primarily due to proverty. But if proverty is the exclusive test, a very
large proportion of the population in India would have to be regarded as socially and
educationally backward, and if reservations are made only on the ground of economic
considerations, an untenable situation may arise. Even in sectors which are
recognised as socially and educationally advanced there are large pockets of poverty.
In this country except for a small percentage of the population the people are
generally poor -- some being more poor, others less poor. Therefore, when a social
investigator tries to identify socially and educationally backward classes, he may do it
with confidence that they are bound to be poor. His chief concern is, therefore, to
determine whether the class or group is socially and educationally backward. Though
the two words "socially" and "educationally" are used cumulatively for the purpose of
describing the backward class, one may find that if a class as a whole is educationally
advanced it is generally also socially advanced because of the reformative effect of
education on that class. The words "advanced" and "backward" are only relative
terms -- there being several layers or strata of classes, hovering between "advanced"
and "backward", and the difficult task is which class can be recognised out of these
several layers as been socially and educationally backward."
25.....Indeed all sectors in the rural areas deserve encouragement but whereas the former by their
enthusiasm for education can get on without special treatment, the latter require to be goaded into
the social stream by positive efforts by the State. That accounts for the raison-d'etre of the principle
explained in Balaji case which pointed out that backward classes for whose improvement special
provision was contemplated by Article 15(4) must be comparable to Scheduled Castes and
Scheduled Tribes who are standing examples of backwardness socially and educationally. If those
examples are steadily kept before the mind the difficulty in determining which other classes should
be ranked as backward classes will be considerably eased."
8. State of Kerala v. N.M. Thomas, (1976) 2 SCC 310, at page 367 :
"135. We may clear the clog of Article 16(2) as it stems from a confusion about caste
in the terminology of scheduled castes and scheduled tribes. This latter expressionAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

has been defined in Articles 341 and 342. A bare reading brings out the quintessential
concept that they (sic there) are no castes in the Hindu fold but an amalgam of castes,
races, groups, tribes, communities or parts thereof found on investigation to be the
lowliest and in need of massive State aid and notified as such by the President. To
confuse this backwardmost social composition with castes is to commit a
constitutional error, misled by a compendious appellation. So that, to protect
harijans is not to prejudice any caste but to promote citizen solidarity. Article 16(2) is
out of the way and to extend protective discrimination to this mixed bag of tribes,
races, groups, communities and non-castes outside the four-fold Hindu division is
not to compromise with the acceleration of castelessness enshrined in the sub-article.
The discerning sense of the Indian Corpus Juris has generally regarded scheduled
castes and scheduled tribes, not as caste but as a large backward group deserving of
societal compassion......"
9. State of U.P. v. Pradip Tandon, (1975) 1 SCC 267, at page 273 :
"14. Article 15(4) speaks of socially and educationally backward classes of citizens.
The State described the rural, hill and Uttrakhand areas as socially and educationally
backward areas. The Constitution does not enable the State to bring socially and
educationally backward areas within the protection of Article 15(4). The
Attorney-General however submitted that the affidavit evidence established the rural,
hill and Uttrakhand areas to have socially and educationally backward classes of
citizens. The backwardness contemplated under Article 15(4) is both social and
educational. Article 15(4) speaks of backwardness of classes of citizens. The accent is
on classes of citizens. Article 15(4) also speaks of Scheduled Castes and Scheduled
Tribes. Therefore, socially and educationally backward classes of citizens in Article
15(4) could not be equated with castes. In M.R. Balaji v. State of Mysore and State of
A.P. v. Sagar this Court held that classification of backwardness on the basis of castes
would violate both Articles 15(1) and 15(4).
15. Broadly stated, neither caste nor race nor religion can be made the basis of
classification for the purposes of determining social and educational backwardness
within the meaning of Article 15(4). When Article 15(1) forbids discrimination on
grounds only of religion, race, caste, caste cannot be made one of the criteria for
determining social and educational backwardness. If caste or religion is recognised as
a criterion of social and educational backwardness Article 15(4) will stultify Article
15(1). It is true that Article 15(1) forbids discrimination only on the ground of religion,
race, caste, but when a classification takes recourse to caste as one of the criteria in
determining socially and educationally backward classes the expression "classes" in
that case violates the rule of expressio unius est exclusio alterius. The socially and
educationally backward classes of citizens are groups other than groups based on
caste.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

16. The expression "socially and educationally backward classes" in Article 15(4) was
explained in Balaji case to be comparable to Scheduled Castes and Scheduled Tribes.
The reason is that the Scheduled Castes and Scheduled Tribes illustrated social and
educational backwardness. It is difficult to define the expression "socially and
educationally backward classes of citizens". The traditional unchanging occupations
of citizens may contribute to social and educational backwardness. The place of
habitation and its environment is also a determining factor in judging the social and
educational backwardness.
17. The expression "classes of citizens" indicates a homogeneous section of the people
who are grouped together because of certain likenesses and common traits and who
are identifiable by some common attributes. The homogeneity of the class of citizens
is social and educational backwardness. Neither caste nor religion nor place of birth
will be the uniform element of common attributes to make them a class of citizens."
10. K.S. Jayasree (Kumari) v. State of Kerala, (1976) 3 SCC 730, at page 733 :
"13. Backward classes for whose improvement special provisions are contemplated by
Article 15(4) are in the matter of their backwardness comparable to scheduled castes
and scheduled tribes. This Court has emphasised in decisions that the backwardness
under Article 15(4) must be both social and educational. In ascertaining social
backwardness of a class of citizens, the caste of a citizen cannot be the sole or
dominant test. Just as caste is not the sole or dominant test, similarly poverty is not
the decisive and determining factor of social backwardness.
xx xx xx
21. In ascertaining social backwardness of a class of citizens it may not be irrelevant
to consider the caste of the group of citizens. Caste cannot however be made the sole
or dominant test. Social backwardness is in the ultimate analysis the result of poverty
to a large extent. Social backwardness which results from poverty is likely to be
aggravated by considerations of their caste. This shows the relevance of both caste
and poverty in determining the backwardness of citizens. Poverty by itself is not the
determining factor of social backwardness. Poverty is relevant in the context of social
backwardness. The commission found that the lower income group constitutes
socially and educationally backward classes. The basis of the reservation is not
income but social and educational backwardness determined on the basis of relevant
criteria. If any classification of backward classes of citizens is based solely on the
caste of the citizen it will perpetuate the vice of caste system. Again, if the
classification is based solely on poverty it will not be logical. The society is taking
steps for uplift of the people. In such a task groups or classes who are socially and
educationally backward are helped by the society. That is the philosophy of our
Constitution. It is in this context that social backwardness which results from poverty
is likely to be magnified by caste considerations. Occupations, place of habitationAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

may also be relevant factors in determining who are socially and educationally
backward classes. Social and economic considerations come into operation in solving
the problem and evolving the proper criteria of determining which classes are socially
and educationally backward. That is why our Constitution provided for special
consideration of socially and educationally backward classes of citizens as also
scheduled castes and tribes. It is only by directing the society and the State to offer
them all facilities for social and educational uplift that the problem is solved. It is in
that context that the commission in the present case found that income of the classes
of citizens mentioned in Appendix VIII was a relevant factor in determining their
social and educational backwardness."
129. In Chitrelekha's case (supra) it was stated that the caste is the starting point. This is subject of
course to the parameters that if the caste itself satisfies the test of backwardness which is implicit
and inherent as noted in para 782 of Indra Sawhney No.1 (supra). In that case caste becomes the
relevant factor. The view expressed in Chitralekha's case (supra) was not dissented from in Indra
Sawhney No.1 (supra). In fact Justice Jeevan Reddy in the majority judgment in Indra Sawhney
No.1 (supra) referred to Chitrelekha's case (supra) at para 704. As noted above in para 782 of Indra
Sawhney No.1 (supra) it has not been held that caste is class. In the said paragraph it has been stated
that individual survey is out of question since Article 16(4) speaks of class protection and not
individual protection. In that context also it has been said that it does not mean that one can wind
up the process of identification for the castes. It has also been emphasized in the said paragraph that
having exhausted the castes or simultaneously with it, the authority may take up for consideration
other occupational groups, communities and classes. If caste is a substitute for class, the question of
any simultaneous consideration of others does not arise. Therefore, the Court observed that one may
well begin with castes if one chooses and then go to other groups, sections and classes. If the Court
meant to substitute the word caste with class the question of going to other classes would not arise.
130. Reference may also be made to Akhil Bharatiya Soshit Ka ramchari Sangh (Railway) v. Union of
India (UOI) and Ors.
(1981(1) SCC 246) where at para 22 it was noted as follows:
"This is not mere harmonious statutory construction of Article 16(1) and (4) but
insightful perception of our constitutional culture, reflecting the current of resurgent
India bent on making, out of a sick and stratified society of inequality and poverty, a
brave new Bharat. If freedom, justice and equal opportunity to unfold one's own
personality, belong alike to bhangi and brahmin, prince and pauper, if the panchama
proletariat is to feel the social transformation Article 16(4) promises, the State must
apply equalising techniques which will enlarge their opportunities and thereby
progressively diminish the need for props. The success of State action under Article
16(4) consists in the speed with which result-oriented reservation withers away as, no
longer a need, not in the everwidening and everlasting operation of an exception
[Article 16(4)] as if it were a super-fundamental right to continue backward all the
time. To lend immortality to the reservation policy is to defeat its raison de'etre; toAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

politicise this provision for communal support and Party ends is to subvert the
solemn undertaking of Article16(1), to casteify 'reservation' even beyond the dismal
groups of backward-most people, euphemistically described as SC & ST, is to run a
grave constitutional risk. Caste, ipso facto, is not class in a secular State."
131. Much emphasis has been laid on the use of the word `only'. It is to be noted that while the
respondents contend that where it is demonstrated that caste is not the only consideration the
permissible provision will operate.
Reference was made to Venkataraman's case (supra). As has been rightly contended by learned
counsel for the petitioners the true effect of the word `only' has been clarified in the decision itself.
132. It is unnecessary to decide as it has been contended by learned counsel for the petitioners
whether the concept of strict scrutiny is a measure of judicial scrutiny as highlighted by the
conditions in India. It is submitted that label is not relevant.
133. The ultimate object is the eradication of castes and that is the foundation for reservation. While
considering the method adopted for eradication by adopting the process of reservation indirectly the
facet of strict scrutiny comes in. The strict scrutiny test was applied in the background of Article 19
vis-`-vis compelling State needs. The principle was recognized in Chintaman Rao v. The State of
Madhya Pradesh (1950 SCR
759). It was inter-alia quoted as follows:
"The question for decision is whether the statute under the guise of protecting public
interests arbitrarily interferes with private business and imposes unreasonable and
unnecessarily restrictive regulations upon lawful occupation; in other words, whether
the total prohibition of carrying on the business of manufacture of bidis within the
agricultural season amounts to a reasonable restriction on the fundamental rights
mentioned in article 19 (1)(g) of the Constitution. Unless it is shown that there is a
reasonable relation of the provisions of the Act to the purpose in view, the right of
freedom of occupation and business cannot be curtailed by it.
The phrase "reasonable restriction" connotes that the limitation imposed on a person
in enjoyment of the right should not be arbitrary or of an excessive nature, beyond
what is required in the interests of the public. The word "reasonable" implies
intelligent care and deliberation, that is, the choice of a course which reason dictates.
Legislation which arbitrarily or excessively invades the right cannot be said to contain
the quality of reasonableness and unless it strikes a proper balance between the
freedom guaranteed in Article 19(1)(g) and the social control permitted by clause (6)
of Article19, it must be held to be wanting in that quality".
134. Again in State of Madras v. V.G. Row (AIR 1952 SC 196) it was observed as follows:Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"13. Before proceeding to consider this question we think it right to point out, what is
sometimes overlooked, that our Constitution contains express provisions for judicial
review of legislation as to its conformity with the constitution unlike as in America
where the Supreme Court has assumed extensive power of reviewing legislative acts
under cover of the widely interpreted "due process" clause in the Fifth and
Fourteenth Amendments. If, then, the courts in this country face up to such
important and none too easy task, it is not out of any desire to tilt at legislative
authority in a crusader's spirit, but in discharge of a duty plainly laid upon them by
the Constitution. This is especially true as regards the "fundamental rights" as to
which this Court has been assigned the role of a sentinel on the qui vive. While the
Court naturally attaches great weight to the legislative judgment, it cannot dessert its
own duty to determine finally the constitutionality of an impugned statute. We have
ventured on these obvious remarks because it appears to have been suggested in
some quarters that the courts in the new set up are out to seek clashes with the
legislatures in the country".
135. At the outset, it may be pointed out that the stand of petitioners is that the primary
consideration in selection of candidates for admission to the higher educational institutions must be
merit. The object of any rules, which may be made for regulating admissions to such institutions
therefore, must be to secure the best and most meritorious students. The national interest and the
demand of universal excellence may even override the interests of the weaker sections. In this
context, Krishna Iyer J aptly observed:
"To sympathise mawkishly with the weaker sections by selecting substandard
candidates, is to punish society as a whole by denying the prospect of excellence, say,
in hospital service. Even the poorest, when stricken by critical illness, needs the
attention of super-skilled specialists not humdrum second rates".
136. Thus, the interest of no person, class or region can be higher than that of the nation. The
philosophy and pragmatism of universal excellence through equality of opportunity for education
and advancement across the nation is part of the constitutional creed. It is, therefore, the best and
most meritorious students that must be selected for admission to technical institutions and medical
colleges and no citizen can be regarded as outsider in the constitutional set-up without serious
detriment to the `unity and integrity' of the nation. The Supreme Court has laid down that so far as
admissions to post graduate course such as MS, MD and the like are concerned, it would be
imminently desirable not to provide for any reservation based on residence or institutional
preference. However, a certain percentage of seats are allowed to be reserved on the ground of
institutional preference. But even in this regard, so far as super specialties such as neurosurgery and
cardiology are concerned there should be no reservation at all even on the basis of institutional
preference and admissions should be granted purely on all-India basis.
Further, classification made on the basis of super-specialties may serve the interests of the nation
better, though interests of individual states may to a small extent, be affected.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

137. The need of a region or institution cannot prevail at the highest scale of specialty where the best
skill or talent must be hand-picked by selecting them according to capability. At the level of Ph.D.,
M.D. or levels of higher proficiency where international measure of talent is made, where losing one
great scientist or technologist in the making is a national loss, the considerations we have expanded
upon as important, lose their potency.
138. The inevitable conclusion is that the impugned Statute can be operative only after excluding the
creamy layer from identifiable OBCs. There has to be periodic review of the classes who can be
covered by the Statute. The periodicity should be five years. To strike constitutional balance there is
need for making provision for suitable percentage for socially and economically backward classes in
the 27% fixed.
I
139. To sum up, the conclusions are as follows:
(1) For implementation of the impugned Statute creamy layer must be excluded.
(2) There must be periodic review as to the desirability of continuing operation of the
Statute. This shall be done once in every five years.
(3) The Central Government shall examine as to the desirability of fixing a cut off
marks in respect of the candidates belonging to the Other Backward Classes (OBCs).
By way of illustration it can be indicated that five marks grace can be extended to such candidates
below the minimum eligibility marks fixed for general categories of students. This would ensure
quality and merit would not suffer. If any seats remain vacant after adopting such norms they shall
be filled up by candidates from general categories.
(4) So far as determination of backward classes is concerned, a Notification should be issued by the
Union of India. This can be done only after exclusion of the creamy layer for which necessary data
must be obtained by the Central Government from the State Governments and Union Territories.
Such Notification is open to challenge on the ground of wrongful exclusion or inclusion. Norms
must be fixed keeping in view the peculiar features in different States and Union Territories.
(5) There has to be proper identification of Other Backward Classes (OBCs.). For identifying
backward classes, the Commission set up pursuant to the directions of this Court in Indra Sawhney
No.1 has to work more effectively and not merely decide applications for inclusion or exclusion of
castes.
While determining backwardness, graduation (not technical graduation) or professional shall be the
standard test yardstick for measuring backwardness.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(6) To strike the constitutional balance it is necessary and desirable to ear-mark certain percentage
of seats out of permissible limit of 27% for socially and economically backward classes.
(7) In the Constitution for the purposes of both Articles 15 and 16, caste is not synonyms with class
and this is clear from the paragraphs 782 and 783 of Indra Sawhney No.1.
However, when creamy layer is excluded from the caste, the same becomes an identifiable class for
the purpose of Articles 15 and 16.
(8) Stress has to be on primary and secondary education so that proper foundation for higher
education can be effectively laid.
(9) So far as the constitutional amendments are concerned:
(i) Articles 16(1) and 16(4) have to be harmoniously construed. The one is not an
exception to the other.
(ii) Articles 15(4) and 15(5) operate in different fields.
Article 15(5) does not render Article 15(4) inactive or inoperative.
(10) While interpreting the constitutional provisions, foreign decisions do not have great
determinative value. They may provide materials for deciding the question regarding
constitutionality. In that sense, the strict scrutiny test is not applicable and indepth scrutiny has to
be made to decide the constitutionality or otherwise, of a statute.
(11) If material is shown to the Central Government that the Institution deserves to be included in
the Schedule, the Central Government must take an appropriate decision on the basis of materials
placed and on examining the concerned issues as to whether Institution deserves to be included in
the Schedule.
(12) Challenge relating to private un-aided educational institutions has not been examined because
no such institution has laid any challenge. It is to be noted that the petitioners have made
submissions in the background of Article 19(6) of the Constitution. Since none of the affected
institutions have made any challenge we do not propose to consider it necessary to express any
opinion or decide on the question.
140. In view of the above-said conclusions, the writ petitions and the Contempt Petition (Civil)
No.112/2007 in W.P. (C) No.265/2006 are disposed of.
..............................J. (Dr. ARIJIT PASAYAT) ..............................J. (C.K. THAKKER) New Delhi, April
10, 2008 IN THE SUPREME COURT OF INDIA CIVIL ORIGINAL JURISDICTION WRIT
PETITION (CIVIL) NO.265 OF 2006 Ashoka Kumar Thakur ....... Petitioner Versus Union of India &
Ors. ...... Respondents WITH Writ Petition (C) No.269/2006 Writ Petition (C) No.598/2006 WritAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Petition (C) No.313/2007 Writ Petition (C) No.335/2007 Writ Petition (C) No.231/2007 Writ
Petition (C) No.425/2007 Writ Petition (C) No.428/2007 Contempt Petition (C) No.112/2007 in
Writ Petition (C) No.265/2006 J U D G M E N T R. V. Raveendran J.
It has been my privilege to read the drafts of the Judgments proposed by the learned Chief Justice,
learned brothers Pasayat J. and Bhandari J. I respectfully agree with them as indicated below :
A. Validity of 93rd Amendment to the Constitution of India. I agree with the learned
Chief Justice and Pasayat, J. that clause (5) of Article 15 is valid with reference to
state maintained educational institutions and aided educational institutions; and that
the question whether Article 15(5) would be unconstitutional on the ground that it
violates the basic structure of the Constitution by imposing reservation in respect of
private unaided educational institutions is left open. I have indicated an additional
reason for rejecting the challenge to Article 15(5) on the ground that it renders Article
15(4) inoperative/ineffective . B. Validity of Central Educational Institutions
(Reservation in Admissions) Act, 2006 - Act No.5 of 2007 :
I agree with the learned Chief Justice and Pasayat J. that (i) identification of other
backward classes solely on the basis of caste will be unconstitutional; (ii) failure to
exclude the `creamy layer' from the benefits of reservation would render the
reservation for other backward classes under Act 5 of 2007 unconstitutional; and (iii)
Act 5 of 2007 providing for reservation for other backward classes will however be
valid if the definition of `other backward classes' is clarified to the effect that if the
identification of other backward classes is with reference to any caste considered as
socially and economically backward, `creamy layer' of such caste should be excluded.
I have indicated briefly my reasons for the same.
I agree with the decision of learned Chief Justice that the Act is not invalid merely
because no time limit is prescribed for caste based reservation, but preferably there
should be a review after ten years by change of circumstances. A genuine measure of
social reservation may not be open to challenge when made. But during a period of
time, if the reservation is continued in spite of achieving the object of reservation, the
law which was valid when made, may become invalid. (C). What should be
parameters for determining the creamy layer in respect of OBCs?
I agree with the learned Chief Justice that OM dated 8.9.1993 of the Government of India can be
applied for such determination.
(D) Whether reservation to an extent of 27% in regard to other backward class under Act 5 of 2007
is valid?
I agree with the decision of learned Chief Justice that reservation of 27% for other backward classes
is not illegal.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

I would however leave open the question whether members belonging to other backward classes
who get selected in the open competition field on the basis of their own merit should be counted
against the 27% quota reserved for other backward classes under an enactment enabled by Article
15(5) of the Constitution.
2. Let me now briefly add a few words on two aspects as indicated above.
Whether Article 15(5) renders Article 15(4) are in conflict with each other?
3. This Court has held that clause (4) of Article 15 is neither an exception nor a proviso to clause (1)
of Article 15. Clause (4) has been considered to be an instance of classification inherent in clause (1)
and an emphatic restatement of the principle implicit in clause (1) of Article 15 (see : State of Kerala
v. N.M. Thomas - 1976 (2) SCC 310, K.C. Vasanth Kumar v. State of Karnataka - 1985 Supp. SCC 714
and Indra Sawhney v. Union of India - 1992 Supp. (3) SCC 217). Clauses (1) and (2) of Article 15 bars
discrimination. Clause (1) contains a prohibition that State shall not discriminate against any citizen
on grounds only on religion, caste, creed, sex or birth. Clause (2) declares that no citizen shall, on
grounds only of religion, race, caste, sex, place of birth or any of them be subject to any disability,
liability, restriction or condition with regard to access to shops, public restaurants, hotels and places
of public entertainment, or the use of wells, tanks, bathing ghats, roads and places of public resort
maintained wholly or partly out of State funds or dedicated to the use of the general public. Clauses
(3) to (5) enable the State to make special provisions in specified areas. The words `Nothing in this
article' occurring in clauses (3), (4) and (5) therefore refer to clauses (1) and (2) of Art. 15. When
clause (4) starts with those words, it does not obviously refer to clause (3). Similarly when clause (5)
starts with those words, it does not refer to clauses (3) and (4). Clauses (3) (4) and (5) of Article 15
are not to be read as being in conflict with each other, or prevailing over each other. Nor does an
exception made under clause (5) operate as an exception under clause (4).
While clauses (4) and (5) may operate independently, they have to be read harmoniously.
The need for exclusion of creamy layer.
4. Section 3 of Act 5 of 2007 mandates reservation of seats in central educational institutions for
other backward classes to an extent of 27%. The term `other backward classes' is defined as
meaning the class or classes of citizens who are socially and economically backward, and are so
determined by the central Government. The Act does not define the term `socially and educationally
backward classes', nor does it contain any norms or guidelines as to how the central Government
should determine any class or classes as socially and educationally backward, so as to entitle them to
the benefit of reservation under the Act. The petitioners contend that the Act vests unguided power
in the executive to pick and choose arbitrarily certain classes for the benefit of reservation. The
Central Government however intends to proceed on the basis that castes which have been identified
for the benefit of reservations under Article 16(4) by the Mandal Commission with the additions
thereto made by the National Commission for Backward Classes, from time to time, will constitute
the socially and educationally backward classes for the purpose of availing the benefit of 27%
reservation under the Act. This again is challenged by the petitioners on the ground thatAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

identification of any class of citizens as `backward', for the purpose of Article 16(4), cannot be
considered as identification of `socially and educationally backward classes of citizens' under Article
15(5). It is pointed out that the term `backward classes' in Article 16(4) is much wider than `socially
and educationally backward classes of citizens' occurring in Article 15(4) and (5).
5. Article 15(4) provides that nothing in that Article or in clause (2) of Article 29 shall prevent the
State from making any special provision for the advancement of any socially and educationally
backward class of citizens or for Scheduled Castes and Scheduled Tribes. Article 29(2) provides that
no citizen shall be denied admission into any educational institution managed by the State or
receiving aid out of State funds, on grounds only of religion, race, caste, language or any of them. On
the other hand, clause (5) of Article 15 provides that notwithstanding anything contained in that
Article or in Article 19(1)(g), State may make a special provision for advancement of socially and
educationally backward class of citizens or for Scheduled Castes and Scheduled Tribes by providing
for reservation relating to admission in any educational institution either aided or unaided by the
State, other than the minority educational institutions referred to in Article 30(1).
While clause (4) excluded the application of Article 29(2), clause (5) does not exclude Article 29(2).
It is therefore contended that in regard to a law made in exercise of power under Article 15(5), the
bar Article 29(2) will apply, and if so, there cannot be any affirmative action by way of reservation
on the ground of caste alone.
6. It is submitted on behalf of the petitioners that the Constitution prohibits any kind of special
provision including reservation, merely on the ground of caste. The object of the Constitution is to
achieve an egalitarian society and any attempt to divide the citizens or the society on the ground of
race, religion or caste should be straightaway rejected. It is submitted that the Constitution nowhere
recognizes or refers to `caste' (except Scheduled Castes and Tribes) as a criterion for conferment of
any right or benefit; that both clauses (4) and (5) of Article 15 refer to socially and educationally
backward `classes' and not `castes'; that Constitution has always referred to caste in a negative
sense, that is to prohibit any discrimination or affirmative action on the basis of `caste' - [Vide
Article 15(1) and (2), 16(2) and 29(2)];
that when Constitution discourages caste, it is paradoxical that caste is sought to be made the
criterion by the State for purposes of making a special provision for socially and educationally
backward classes. It is submitted that there cannot be any special provision for any group of citizens
merely on the ground that they belong to a particular caste or community (except Scheduled Castes
and Tribes who are separately mentioned in Articles 15(4), 15(5), 16(4), 335, 340, 346 etc).
7. This Court in a series of decisions commencing from M.R. Balaji v.
State of Mysore [1963 Supp. (1) SCR 439], R.Chitralekha v. State of Mysore [1964 (6) SCR 368],
Minor P.Rajendran v. State of Madras [1968 (2) SCR 786], State of Andhra Pradesh v. P.Sagar [1968
(3) SCR 595], Janki Prasad Parimoo v. State of Jammu & Kashmir [1973 (1) SCC 420], State of
Kerala v. N.M.Thomas [1976 (2) SCC 310] and K.C.Vasanth Kumar v. State of Karnataka [1985
Supp. SCC 714] has explained what is social and educational backwardness. All these decisions haveAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

laid down the principle that caste cannot be made the sole or dominant test to determine
backwardness, and any classification determining backwardness only with reference to caste will be
invalid. These decisions recognized the fact that caste is not equated to class and all backwardness,
either social or educational, is ultimately and primarily due to poverty or economic conditions.
8. However, in Rajendran (supra), it was held that if a caste, as a whole, is socially and educationally
backward then reservation can be made in favour of such a caste on the ground that it is a socially
and educationally backward class within the meaning of Article 15(4). The decision followed Balaji
and therefore proceeded on the basis that where the extent of social and educational backwardness
of the caste in question is virtually the same as the social and educational backwardness of
Scheduled Castes and Scheduled Tribes, reservation can be made on the basis of caste itself. In that
case, it was found as a question of fact that members of certain castes as a whole, were socially and
educationally backward, and therefore it was held that the reservation the basis of caste was
permissible in respect of those castes.
9. In A.Peeriakaruppan v. Sobha Joseph [1971 (1) SCC 38], this Court referred to the cases starting
from Balaji to Rajendran. It reiterated the principle stated in Rajendran that if a caste as a whole is
socially and educationally backward, reservation can be made in favour of such a caste on the
ground that it is a socially and educationally backward class of citizens within the meaning of Article
15(4). It also cautioned that the Government should not proceed on the basis that once a class is
considered as a backward class, it will continue to be backward class for all times.
10. Therefore neither Rajendran nor Periakaruppam really departed from or diluted the principle
laid down in Balaji. On the other hand, the principle laid down in Balaji was reiterated. Rajendran
and Periakaruppam only show that in extreme cases where it is found that the caste under
consideration was, as a whole, socially and educationally backward, and therefore akin to a
Scheduled Caste, reservation could be made only on the basis of caste alone.
11. Vasanth Kumar (supra) held that only a caste comparable to the Scheduled Castes and Scheduled
Tribes in the matter of backwardness, could be considered to be a socially and educationally
backward class in favour of which reservation could be made merely on the basis of caste.
Vasanth Kumar therefore, reiterated Balaji. Then came to the decision of nine Judges in Indra
Sawhney v. Union of India [1992 Supp. (3) SCC 217].
This Court held that the use of the word 'class' in Article 16(4) refers to social class, and that
reservation under Article 16(4) is in favour of a backward class and not a caste. It held that `
backward class of citizens' contemplated in Article 16(4) is not the same as `socially and
educationally backward classes' referred to in Article 15(4), but much wider. It held that there was
no reason to qualify or restrict the meaning of the expression 'backward class of citizens' by saying
that it means only those other backward classes who are situated similarly to Scheduled Castes
and/or Scheduled Tribes (para 795). This Court held :Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"If any group of class is situated similarly to the Scheduled Castes, they may have a
case for inclusion in that class but there seems to be no basis either in fact or in
principle for holding that other classes/groups must be situated similarly to them for
qualifying as backward classes. There is no warrant to import any such a priori
notions into the concept of Other Backward Classes. At the same time, we think it
appropriate to clarify that backwardness, being a relative term, must in the context be
judged by the general level of advancement of the entire population of the country or
the State, as the case may be. More than this, it is difficult to say."
In the context of Article 16(4) this Court also observed that a caste can be and quite often is a social
class in India (as in the case of Scheduled Castes) and if it is backward socially, it would be a
`backward class' for the purposes of Article 16(4). It held that the accent in Article 16(4) is on social
backwardness, whereas the accent in Article 15(4) is on `social and educational backwardness'.
Ultimately, this Court held :
" Neither the Constitution nor the law prescribes the procedure or method of
identification of backward classes. Nor is it possible or advisable for the court to lay
down any such procedure or method. It must be left to the authority appointed to
identify. It can adopt such method/procedure as it thinks convenient and so long as
its survey covers the entire populace, no objection can be taken to it. Identification of
the backward classes can certainly be done with reference to castes among, and along
with, other occupational groups, classes and sections of people. The Court however
made it clear that a caste can be the starting point for determining a backward class;
and that if a caste or class should be designated as `a backward class' then the creamy
layer from such class or caste should be excluded. This Court observed :
"In a backward class under clause (4) of Article 16, if the connecting link is the social
backwardness, it should broadly be the same in a given class. If some of the members
are far too advanced socially (which in the context, necessarily means economically
and, may also mean educationally) the connecting thread between them and the
remaining class snaps. They would be misfits in the class. After excluding them alone,
would the class be a compact class.
12. It is thus seen that Indra Sawhney certainly went a step further than Balaji and other cases in
holding that a caste can be the starting point for determination of backwardness -- social and
economic. But it is clear from the decision that caste itself is not the final destination, that is, a caste
by itself, cannot be determinative of social and educational backwardness. A caste can be identified
to be socially and economically backward, only when the creamy layer is removed from the caste and
a compact class emerges which can be identified as a socially and educationally backward class.
Thus the determination is not by first identifying a caste as a socially and educationally backward
class and, thereafter, remove or exclude the creamy layer for the purpose of enjoying the benefits
flowing to such class. On the other hand, until and unless, the creamy layer is removed from a caste,
there is no compact class which can be termed as socially and educationally backward class at all.
Thus, while the process of identifying socially and educationally backward class can convenientlyAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

start with a socially and educationally backward caste, remove the creamy layer therefrom results in
the emergence of compact class which can be termed as a socially and educationally backward class.
In this sense, it can be said that Indra Sawhney is only a development of the principles laid down in
Balaji, R.Chitralekha, Parimoo, Pradip Tandon, N.M.Thomas N.M. and Vasanth Kumar, which
pointed out that the advanced section of a backward caste constituting the creamy layer is virtually
the same as forward class. If the creamy layer is not excluded the benefit of reservation will be
appropriated by such advanced sections. Referring to this aspect, Indra Sawhney (supra) said :
"To continue to confer upon such advanced sections, special benefits, would amount
to treating equals unequally. Secondly, to rank them with the rest of the backward
classes would amount to treating the unequals equally."
This Court directed that a permanent mechanism in the nature of a Commission to be created to
examine the requests for inclusion, and complaints of over-inclusion and under-inclusion in the lists
of OBCs of citizens, and to advise the Government and such advice should normally be binding upon
the Government. There is therefore, no doubt that only when a caste identified or perceived as a
socially and educationally backward caste sheds its creamy layer, it becomes a socially and
educationally backward class. The need for exclusion of creamy layer is also evident from the
subsequent decision in Ashoka Kumar Thakur v. State of Bihar - 1995 (5) SCC 403, Indra Sawhney
v. Union of India (II) - 1996 (6) SCC 506, M.Nagaraj v. Union of India - 2006 (8) SCC 212. When
Indra Sawhney has held that creamy layer should be excluded for purposes of Article 16(4), dealing
with `backward class' which is much wider than `socially and educationally backward classes
occurring in Article 15(4) and (5), it goes without saying that without the removal of creamy layer
there cannot be a socially and educationally backward class.
13. Caste has divided this country for ages. It has hampered its growth.
To have a casteless society will be realization of a noble dream. To start with, the effect of
reservation may appear to perpetuate caste. The immediate effect of caste based reservation has
been rather unfortunate. In the pre-reservation era people wanted to get rid of the backward tag --
either social or economical, and were keen to be known as forward. But post reservation, every one,
including those who are considered `forward' fight for `backward' tag, in the hope of enjoying the
benefits of reservations.
When more and more people aspire for `backwardness' instead of `forwardness' the country itself
stagnates. Reservation as an affirmative action is required only for a limited period to bring forward
the socially and educationally backward classes by giving them a gentle supportive push.
But if there is no review after a reasonable gap and there is any tendency to continue reservations
indefinitely, the country will become a caste divided society permanently. Instead of developing into
an united society with diversity, we will end up as a fractured society for ever suspicious of each
other. While affirmative discrimination is a road to equality, care should be taken that the road does
not become a rut in which the vehicle of progress gets entrenched and stuck. Any provision for
reservation should not become crutches which themselves create a permanent disability. TheyAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

should merely be temporary aid to achieve normalcy. Though the constitutional goal is a casteless
society, Constitution advisedly does not specifically prescribe a casteless society nor try to abolish
caste. But by barring discrimination in the name of caste and by providing for affirmative action
Constitution seeks to remove the difference in status on the basis of caste.
When the differences in status among castes are removed, all castes will become equal and gradually
lose their importance. A beginning will thus be made for a casteless egalitarian society.
14. I agree that the petitions shall stand disposed of in the manner stated by the learned Chief
Justice.
...........................J (R. V. Raveendran) New Delhi;
10th April, 2008  
                IN THE SUPREME COURT OF INDIA
                   CIVIL ORIGINAL JURISDICTION
             WRIT PETITION (CIVIL) NO.265 OF 2006
Ashoka Kumar Thakur                               ......         Petitioner
             Versus
Union of India & Others                           ......         Respondents
                                     WITH
Writ Petition (Civil) Nos.269 AND 598 of 2006, Writ Petition (Civil) Nos.29, 35, 53, 336, 313, 335,
231, 425, 428 of 2007 AND Contempt Petition (C) No.112 of 2007 in Writ Petition (C) No.265 of
2006.
* * * * * J U D G M E N T D alveer Bhandari, J.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

1. The 93rd Amendment to the Constitution directly or indirectly affects millions of citizens of this
country. It has been challenged in a number of writ petitions. This Court heard these petitions
intermittently over the course of several months. Appearing on behalf of petitioners and
respondents, the country's finest legal minds assisted us.
2. The fundamental question that arises in these writ petitions is: Whether Article 15(5), inserted by
the 93rd Amendment, is consistent with the other provisions of the Constitution or whether its
impact runs contrary to the Constitutional aim of achieving a casteless and classless society?
3. On behalf of the petitioners, Senior Advocate Mr. F.S. Nariman, eloquently argued that if Article
15(5) is permitted to remain in force, then, instead of achieving the goal of a casteless and classless
society, India would be converted into a caste-ridden society. The country would forever remain
divided on caste lines. The Government has sought to repudiate this argument. Petitioners'
argument, however, echoes the grave concern of our Constitution's original Framers.
4. On careful analysis of the Constituent Assembly and the Parliamentary Debates, one thing is
crystal clear: our leaders have always and unanimously proclaimed with one voice that our
constitutional goal is to establish a casteless and classless society. Mahatma Gandhi said: "The caste
system as we know is an anachronism. It must go if both Hinduism and India are to live and grow
from day to day." The first Prime Minister, Pt. Jawahar Lal Nehru, said that "no one should be left in
any doubt that the future Indian Society was to be casteless and classless". Dr. B. R. Ambedkar
called caste "anti-national".
5. After almost four decades of independence, while participating in the Parliamentary Debate on
the Mandal issue, then Prime Minister Shri Rajiv Gandhi on 6th September, 1990 again reiterated
the same sentiments: "I think, nobody in this House will say that the removal of casteism is not part
of the national goal, therefore, it would be in the larger interest of the nation to get rid of the castes
as early as possible". It is our bounden duty and obligation to examine the validity of the 93rd
Amendment in the background of the Preamble and the ultimate goal that runs through the pages of
the Constitution.
6. To attain an egalitarian society, we have to urgently remove socio-economic inequalities. All
learned counsel for the petitioners asserted that we must deliver the benefits of reservation to only
those who really deserve it. This can only be done if we remove the creamy layer. Learned counsel
for the Union of India and other respondents opposed this assertion. The principle of creamy layer
emanates from the broad doctrine of equality itself. Unless the creamy layer is removed from
admissions and service reservation, the benefits would not reach the group in whose name the
impugned legislation was passed - the poorest of the poor. Therefore, including the creamy layer
would be inherently unjust.
7. Creamy layer exclusion, however, is just one of the many issues raised by the parties. I need to
examine various facets of this case in order to decide the validity of the 93rd Amendment and the
Central Educational Institutions (Reservation in Admission) Bill, 2006 (passed as Act 5 of 2007)
(hereinafter called the "Reservation Act"). I shall focus my analysis on the following issues:Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

1A. Whether the creamy layer be excluded from the 93rd Amendment (Reservation
Act)?
1B. What are the parameters for creamy layer exclusion? 1C. Is creamy layer
exclusion applicable to SC/ST?
2. Can the Fundamental Right under Article 21A be accomplished without great
emphasis on primary education?
3. Does the 93rd Amendment violate the Basic Structure of the Constitution by
imposing reservation on unaided institutions?
4. Whether the use of caste to identify SEBCs runs afoul of the casteless/classless
society, in violation of Secularism.
5. Are Articles 15(4) and 15(5) mutually contradictory, such that 15(5) is
unconstitutional?
6. Does Article 15(5)'s exemption of minority institutions from the purview of
reservation violate Article 14 of the Constitution?
7. Are the standards of review laid down by the U.S. Supreme Court applicable to our
review of affirmative action under Art 15(5) and similar provisions?
8. With respect to OBC identification, was the Reservation Act's delegation of power
to the Union Government excessive?
9. Is the impugned legislation invalid as it fails to set a time-limit for caste-based
reservation?
10. At what point is a student no longer Educationally Backward and thus no longer
eligible for special provisions under 15(5)?
11. Would it be reasonable to balance OBC reservation with societal interests by
instituting OBC cut-off marks that are slightly lower than that of the general
category?
8. I have carefully examined the pleadings and written submissions submitted at length. Admittedly,
the provisions of the Constitution and the Preamble lead to the irresistible conclusion that the
Nation has always wanted to achieve a casteless and classless society. If we permit this impugned
legislation to be implemented, I am afraid, instead of a casteless and classless India, we would be left
with a caste-
ridden society.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

9. The first place where caste can be eradicated is the classroom. It all starts with education. In other
words, if you belong to a lower caste but are well qualified, hardly anyone would care about your
caste. Free and compulsory education is now a fundamental right under Article 21A. The State is
duty bound to implement this Article on a priority basis.
There has been grave laxity in its implementation. This laxity adversely affects almost every walk of
life. In my opinion, nothing is more important for the Union of India than to implement this critical
Article.
10. I direct the Union of India to set a time-limit within which this Article is going to be completely
implemented. This time-
limit must be set within six months. In case the Union of India fails to fix the time-limit, then
perhaps this work will also have to be done by the Court.
11. The Union of India should appreciate in proper prospective that the root cause of social and
educational backwardness is poverty. All efforts have to be made to eradicate this fundamental
problem. Unless the creamy layer is removed, the benefit would not reach those who are in need.
Reservation sends the wrong message. Everybody is keen to get the benefit of backward class status.
If we want to really help the socially, educationally and economically backward classes, we need to
earnestly focus on implementing Article 21A. We must provide educational opportunity from day
one.
Only then will the casteless/classless society be within our grasp. Once children are of college-going
age, it is too late for reservation to have much of an effect. The problem with the Reservation Act is
that most of the beneficiaries will belong to the creamy layer, a group for which no benefits are
necessary.
Only non-creamy layer OBCs can avail of reservations in college admissions, and once they graduate
from college they should no longer be eligible for post-graduate reservation.
27% is the upper limit for OBC reservation. The Government need not always provide the maximum
limit. Reasonable cut off marks should be set so that standards of excellence are not greatly affected.
The unfilled seats should revert to the general category.
12. These issues first arise out of the text of the impugned Amendment. Reservation for Socially and
Educationally Backward Classes of Citizens (SEBCs) was introduced by the 93rd Amendment.
Article 15(5) states:
"Nothing in this article or in sub-clause (g) of clause (1) of article 19 shall prevent the
State from making any special provision, by law, for the advancement of any socially
and educationally backward classes of citizens or for the Scheduled Castes or the
Scheduled Tribes in so far as such special provisions relate to their admission toAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

educational institutions including private educational institutions, whether aided or
unaided by the State, other than minority educational institutions referred to in
clause (1) of article 30."
7 E xcluding the Creamy Layer from receiving special benefits:
13. Affirmative action is employed to eliminate substantive social and economic
inequality by providing opportunities to those who may not otherwise gain admission
or employment.
Articles 14, 15 and 16 allow for affirmative action. To promote Article 14 egalitarian equality, the
State may classify citizens into groups, giving preferential treatment to one over another.
When it classifies, the State must keep those who are unequal out of the same batch to achieve
constitutional goal of egalitarian society.
7 A rguments of the Union of India in regard to t he creamy layer:
14. Mr. G.E. Vahanvati, learned Solicitor General and Mr K. Parasaran, Senior
Advocate appearing for the Government contend that creamy layer exclusion is a bad
policy. They argue that if you exclude the creamy layer, there would be a shortage of
candidates who can afford to pay for higher education. This argument harms rather
than helps the Government. It cannot be seriously disputed that most of the
college-going OBCs belong to the creamy layer for whom reservations are
unnecessary; they have the money to attend good schools, tuitions and coaching
courses for entrance exams. Naturally, these advantages result in higher test scores
vis-`-vis the non-creamy layer OBCs. The result is that creamy OBCs would fill the
bulk of the OBC quota, leaving the non-creamy no better off than before. If the
creamy get most of the benefit, why have reservations in the first place? Learned
Senior Counsel for petitioners, Mr. Harish Salve, is justified in arguing that before
carrying out Constitutional Amendments the Union of India must clearly target its
beneficiaries. He rightly submitted that we should not make law first and thereafter
target the law's beneficiaries. Failure to exclude the creamy layer is but one example
of this problem.
15. The Government further submitted that the creamy layer should be included to
ensure that enough qualified candidates fill 27% of the seats reserved to OBCs. The
Oversight Committee disagreed. The Committee relied on data from Karnataka to
disprove the contention that seats go unfilled when the creamy is excluded: "... the
apprehension that seats will not be filled up if the creamy layer is excluded has been
comprehensively shown to be unfounded." [See: Oversight Committee, Vol. 1, Sept.
2006, p. 69, para 1.7.] We shall later review the Oversight Committee opinion in
greater detail. 7 Th e reasons for which the creamy layer should be excluded:Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

16. At the outset, I note that the Parliament rejected the Hindi version of the
Reservation Act. The Hindi version of the Reservation Act would have expressly
excluded the creamy layer. [See: Prof. Rasa Singh Rawat's comments in the
Parliamentary Debate on the Reservation Act, 14 December 2006]
17. The Parliament eventually passed the English version in which the creamy layer is
not mentioned, making its intention clear. It wanted to include the creamy layer. For
all practical purposes, it did so. Therefore, I will treat it as included.
Counsel for the Union of India argued that it is still theoretically possible for the executive to
exclude the creamy layer. Much is possible in theory. Given the executive's failure to take action
since the time the Act was passed, I find this argument unavailing.
18. With the Parliament's intention in view, I will deal in some detail with the reasons as to why the
creamy layer should be excluded from reservation. I do so because I want to emphasize that the
creamy layer must never be included in any affirmative action legislation. It also becomes
imperative to gather the original Framers' and the Framers' intention. At the outset, we recognise a
distinction between the original Framers and the Framers, i.e., Members of the First Parliament.
Members of the Constituent Assembly and the First Parliament were one in the same. But the
distinction is necessary to the extent that the First Parliament deviated from its constitutional
philosophy. By examining the debate on Article 15(4), I may ascertain whether the Framers wanted
to exclude the creamy layer.
19. The First Parliament believed that "economic" was included in the "social" portion of "socially
and educationally backward." Prime Minister Nehru said as much:
"One of the main amendments or ideas put forward is in regard to the addition of the
word "economical". Frankly, the argument put forward, with slight variation, I would
accept, but my difficult is this that when we chose those particular words there, "for
the advancement of any socially and educationally backward classes", we chose them
because they occur in article 340 and we wanted to bring them bodily from there.
Otherwise I would have had not the slightest objection to add "economically". But if I
added "economically" I would at the same time not make it a kind of cumulative thing
but would say that a person who is lacking in any of these things should be helped.
"Socially" is a much wider word including many things and certainly including
economically. Therefore, I felt that "socially and educationally" really cover the
ground and at the same time you bring out a phrase used in another part of the
Constitution in a slightly similar context." (See: the Parliamentary Debates on First
Amendment Bill, 1 June 1951, p. 9830.) Had it not been for a desire to achieve
symmetry in drafting, "economically" would have been included. Had this been done,
the creamy layer would have been excluded ab initio.
20. In the 15(4) debate, Shri M.A. Ayyangar's wanted to add "economic" to ensure that the rich
SEBCs would not receive special provisions.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"I thought "economic" might be added so that rich men may not take advantage of
this provision. In my part of the country there are the Nattukkottai Chettiars who do
not care to have English education, but they are the richest of the lot ... should there
be special reservation for them?" (See: The Parliamentary Debates on First
Amendment Bill, 1 June 1951, p. 9817.) (emphasis added).
This hesitation aside, Shri M.A. Ayyangar was satisfied that the term "economic" was
included in the term "social." The Framers were worried about creamy layer
inclusion, albeit under a different name. They wanted to ensure that the "richest of
the [backward] lot" would not benefit from special provisions. With their sentiment
on our side, we are even more confident that we should strike out in the direction
that strikes down laws that include the creamy layer. 7 In cluding the creamy layer
means unequals are treated as equals in violation of the right to equality under
Articles 14, 15 and 16.
21. In the present case, Dr. Rajeev Dhavan, the learned Senior Counsel and Mr. S.K. Jain, the
learned counsel vehemently argued on behalf of petitioners that it is precisely because equality is at
issue that the creamy layer must be removed. The creamy layer has been the subject matter of a
number of celebrated judgments of this Court. In a seven Judge Bench in State of Kerala & Another
v. N. M. Thomas & Others (1976) 2 SCC 310, Justice Mathew, in his concurring judgment, dealt with
the right to equality in the following words:
"66. The guarantee of equality before the law or the equal opportunity in matters of
employment is a guarantee of something more than what is required by formal
equality. It implies differential treatment of persons who are unequal. Egalitarian
principle has therefore enhanced the growing belief that Government has an
affirmative duty to eliminate inequalities and to provide opportunities for the
exercise of human rights and claims. ........."
(emphasis added)
22. In Indra Sawhney & Others v. Union of India & Others (1992) Supp (3) SCC 217, (hereinafter
referred to as Sawhney I), this Court has aptly observed that reservation is given to backward classes
until they cease to be backward, and not indefinitely. This Court in para 520 (Sawant, J.) has stated
as under:
"Society does not remain static. The industrialisation and the urbanisation which
necessarily followed in its wake, the advance on political, social and economic fronts
made particularly after the commencement of the Constitution, the social reform
movements of the last several decades, the spread of education and the advantages of
the special provisions including reservations secured so far, have all undoubtedly
seen at least some individuals and families in the backward classes, however small in
number, gaining sufficient means to develop their capacities to compete with others
in every field. That is an undeniable fact. Legally, therefore, they are not entitled to beAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

any longer called as part of the backward classes whatever their original birthmark. It
can further hardly be argued that once a backward class, always a backward class.
That would defeat the very purpose of the special provisions made in the Constitution
for the advancement of the backward classes, and for enabling them to come to the
level of and to compete with the forward classes, as equal citizens."
(emphasis supplied).
23. For our purposes, creamy layer OBCs and non-creamy layer OBCs are not equals when it comes
to moving up the socio-economic ladder by means of educational opportunity.
Failing to remove the creamy layer treats creamy layer OBCs and non-creamy layer OBCs as equals.
In the same paragraph, Justice Sawant stated that "... to rank [the creamy layer] with the rest of the
backward classes would ... amount to treating the unequals equally..." violating the equality
provisions of the Constitution.
24. According to the Kerala Legislature, there was no creamy layer in Kerala. The legislation was
challenged in Indra Sawhney v. Union of India & Others (2000) 1 SCC 168, (hereinafter referred to
as Sawhney II). The Court struck the two provisions that barred creamy layer exclusion, concluding
that non-inclusion of the creamy-layer and inclusion of forward castes in reservation violates the
right to equality under Article 14 and the basic structure.
25. In Sawhney II at para 65, the Court had gone to the extent of observing that not even the
Parliament, by constitutional amendment, could dismantle the basic structure by including the
creamy layer in reservation:
"What we mean to say is that the Parliament and the legislature in this country
cannot transgress the basic feature of the Constitution, namely, the principle of
equality enshrined in Article 14 of which Article 16(1) is a facet. Whether the creamy
layer is not excluded or whether forward castes get included in the list of backward
classes, the position will be the same, namely, that there will be a breach not only of
Article 14 but of the basic structure of the Constitution. The non- exclusion of the
creamy layer or the inclusion of forward castes in the list of backward classes will,
therefore, be totally illegal. Such an illegality offending the root of the Constitution of
India cannot be allowed to be perpetuated even by constitutional amendment."
26. By definition, the creamy and non-creamy are unequal when it comes to schooling. Relative to
their non-creamy counterparts, the creamy have a distinct advantage in gaining admission. While
the creamy and non-creamy are given equal opportunity to gain admission in the reserved category,
this equality exists in name only. Will the OBC daughter of a Minister, IAS officer or affluent
business owner attend better schools than her non-creamy counterpart? Yes. Will she go to private
tuitions unaffordable to her non-creamy counterpart?Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Certainly. And where will she cram for the all-decisive entrance exams? In a coaching center? Of
course. Will she come home from school to find a family member waiting?
Probably. And when she seeks help from her parents, are they educated and able to give superior
assistance with schoolwork? Most likely.
27. I take judicial notice of these anecdotes, for they flesh out a simple fact: she has all the resources
that her non-creamy counterpart lacks. It is no surprise that she will outperform the non-creamy.
On average, her lot will take the reserved seats.
28. I cannot consider the OBC Minister's daughter and the non-creamy OBC as equals in terms of
their chances at earning a university seat; nor can I allow them to be treated equally. To lump them
in the same category is an unreasonable classification. Putting them in head-to-head competition for
the same seats violates the right to equality in Articles 14, 15 and 16.
29. In its conclusion at para 122, M. Nagaraj & Others v.
Union of India & Others (2006) 8 SCC 212, a Constitution Bench of this Court while dealing with
Article 16(4A) and 16(4B) with regard to SC and ST observed as under:-
"We reiterate that the ceiling limit of 50%, the concept of creamy layer and the
compelling reasons, namely, backwardness, inadequacy of representation and overall
administrative efficiency are all constitutional requirements without which the
structure of equality of opportunity in Article 16 would collapse."
It was contended that Nagraj is obiter in regard to creamy layer exclusion. According to Nagraj,
reservation in promotion for SC/ST is contingent on exclusion of the creamy layer.
(paras 122, 123 and 124). The contention of the Union of India cannot be accepted. The discussion
regarding creamy layer is far from obiter in Nagraj. If the State fails to exclude the SC/ST creamy
layer, the reservation must fall. Placing this contingency in the conclusion makes the discussion of
creamy layer part of the ratio.
30. In sum, creamy layer inclusion violates the right to equality. That is, non-exclusion of creamy
layer and inclusion of forward castes in reservation violates the right to equality in Articles 14, 15
and 16 as well as the basic structure of the Constitution.
7 If you belong to the creamy layer, you are not SEBC.
31. One of the prominent questions raised in the writ petitions is whether creamy layer OBCs should
be considered socially and educationally backward under the provisions of Article 15(5). While
interpreting this provision, a basic syllogism must govern our decision. If you belong to the creamy
layer, you are socially advanced and cannot be given the benefit of reservation. (See: Sawhney I).Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

32. Once one is socially advanced, he cannot be socially and educationally backward. He who is
socially forward is likely to be educationally forward as well. If either condition (social or
educational) goes unmet, one cannot qualify for the benefit of reservation as SEBC. Being socially
advanced, the creamy layer is not socially backward pursuant to Articles 15(4) and 15(5) of the
Constitution.
33. Even the text of Articles 15(4) and 15(5) provides for creamy layer exclusion. In this sense, one
could say that the term "creamy layer" is synonymous with "non-SEBC".
34. Similar interpretation is given to "backward classes"
under Article 16(4). The Parliament could not reasonably make reservation for
non-backwards. Such a Bill on the face of it would violate the Constitution. In
Sawhney I, the Government of India issued an O.M. on 13 August 1990, reserving
27% of Government posts to SEBCs. Writing for the majority, at para 792 of page
724, Justice Reddy explained that the creamy layer was not SEBC.
"The very concept of a class denotes a number of persons having certain common
traits which distinguish them from the others. In a backward class under Clause (4)
of Article 16, if the connecting link is the social backwardness, it should broadly be
the same in a given class. If some of the members are far too advanced socially (which
in the context, necessarily means economically and, may also mean educationally)
the connecting thread between them and the remaining class snaps. They would be
misfits in the class. After excluding them alone, would the class be a compact class. In
fact, such exclusion benefits the truly backward"
Even though the O.M. was silent on the issue of creamy layer, Justice Reddy excluded the creamy
layer at para 859(3)(d).
The O.M. could not go into effect until the creamy layer was excluded. [para 861(b)]. Exclusion was
only in regard to OBC;
SC/ST were not touched. (para 792). In Sawhney I, the entire discussion was confined only to Other
Backward Classes. Similarly, in the instant case, the entire discussion was confined only to Other
Backward Classes. Therefore, I express no opinion with regard to the applicability of exclusion of
creamy layer to the Scheduled Castes and Scheduled Tribes.
7 C reamy Layer OBCs are not educationally backward
35. In addition to social backwardness, the text of 15(5) demands that recipients are also
educationally backward.
Even though the creamy layer's status as socially advanced is sufficient to disqualify them for
preferential treatment, the creamy layer from any community is usually educated and will want theAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

same for its children. They know that education is the key to success. For most, it made them.
People belonging to this group do not require reservation.
7 Creamy Layer Inclusion Robs the Poor and Gives to the Rich:
36. In a number of judgments, the view has been taken that the creamy layer's
inclusion takes from the poor and gives to the rich.
37. Our Courts in following cases had taken the same view.
[See: N.M Thomas (supra), para 124 (seven-Judge Bench);
K.C. Vasanth Kumar & Another v. State of Karnataka, 1985 (Supp) SCC 714, paras 2, 24 and 28
(five-Judge Bench);
Sawhney I., paras 520, 793 and 859(3)(d) (nine-Judge Bench); Ashoka Kumar Thakur v. State of
Bihar & Others (1995) 5 SCC 403, paras 3, 17 and 18 (two-Judge Bench);
Sawhney II, paras 8-10, 27, 48 and 65-66 (three-Judge Bench); Nagaraj (supra), paras, 120-124
(five-Judge Bench);
Nair Service Society v. State of Kerala, (2007) 4 SCC 1;
paras 31 and 49-54 (two-Judge Bench)].
38. In Akhil Bharatiya Soshit Karamchari Sangh (Railway) v. Union of India & Others (1981) 1 SCC
246, Justice Iyer had this to say about the creamy layer:
"92. ... Maybe, some of the forward lines of the backward classes have the best of both
the worlds and their electoral muscle qua caste scares away even radical parties from
talking secularism to them. We are not concerned with that dubious brand. In the
long run, the recipe for backwardness is not creating a vested interest in backward
castes but liquidation of handicaps, social and economic, by constructive projects. All
this is in another street and we need not walk that way now.
94. ... Nor does the specious plea that because a few harijans are better off, therefore,
the bulk at the bottom deserves no jack-up provisions merit scrutiny. A swallow does
not make a summer. Maybe, the State may, when social conditions warrant,
justifiably restrict harijan benefits to the harijans among the harijans and forbid the
higher harijans from robbing the lowlier brethren."
39. Creamy layer inclusion was not enough to strike an entire provision in this case. He suggests that
creamy layer exclusion is an issue to be dealt with at a later time.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"98. The argument that there are rich and influential harijans who rob all the
privileges leaving the serf-level sufferers as suppressed as ever. The Administration
may well innovate and classify to weed out the creamy layer of SCs/STs but the court
cannot force the State in that behalf."
Thus, Justice Iyer does not mandate creamy layer exclusion;
rather, he leaves the question to the State.
40. Apart from judicial pronouncements, the Oversight Committee suggested that failure to exclude
the creamy layer would lead to unfair results. The Committee was cautious to reach a conclusion.
41. In its Report, it stated that "... the decision taken was to leave the matter to the Government of
India, keeping in mind the fact that the `creamy layer' is not covered in the Reservation Act, 2006."
(See: Oversight Committee, Vol. 1, p.
33 and 4.2.)
42. Before "leaving" the matter to the Government, the Committee nevertheless made its
recommendation: "In case it is decided not to exclude the `creamy layer', the poorest among the
OBCs will be placed at a disadvantage." (emphasis added).
(See: Oversight Committee at Appendix I in its Report at p. 70, para 1.13). At page 69 of Vol. I of its
Report, the Committee offered data to support this conclusion:
"1.6: Appendix-2 examines in detail the status of the socio- economic development of
OBCs in respect of such parameters as relate to poverty, health, education,
unemployment, workforce participation, land ownership etc. The analysis of the NSS
data clearly brings out that inclusion of the creamy layer will result in reserved seats
getting pre-empted by the OBCs from the top two deciles at the cost of the poorer
income deciles of the OBCs. Thus almost all rural OBCs as well as Urban OBCs from
the Northern, Central and Eastern regions of India will be deprived of the intended
benefits of reservation.
[emphasis added] 1.7: On the other hand, it was argued that if the creamy layer of
OBCs is denied access to reservation in education pari- passau with the principle
applied in the case of employment, the reserved seats may not get filled up, again
defeating the purpose of bringing in reservation for the OBCs. In a case study from
Karnataka (included in Annexure X), it has been clearly shown that the OBC quotas
have been utilized without any compromise with academic excellence in a situation
where the creamy layer has been excluded. The apprehension that seats will not be
filled up if the creamy layer is excluded has been comprehensively shown to be
unfounded. The case study shows that the performance of students from below the
creamy layer is outstanding and much better than general category students."Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

43. The Committee could have played it safe. Despite some opposition, the Committee included its
opinion on the matter.
And that opinion is unequivocal: the creamy must be excluded.
44. What is allegedly for the poor goes to the rich. Is that reasonable? Trumpeted by the Parliament
as a "...boost to the morale of the downtrodden" and "... in the right direction of ensuring social
justice to other backward classes ..." and "ensuring social justice to those weaker sections ...", Article
15(5) dupes those who actually need preferential treatment.
(See: Prof. Basudeb Barman, M.P., the Parliamentary Debates, p. 531, December 21, 2005; Prof. M.
Ramadass, M.P., at p.
510; and Shri C.K. Chandrappan, M.P., at p. 494 respectively).
For the poorest of the poor, reservation in college is an empty promise. Few of the financially poor
OBCs attend high school, let alone college. Instead of rewarding those that complete Plus 2, the 93rd
Amendment (Art 15(5)) poses another barrier: they will have to compete with the creamy layer for
reserved seats.
45. As explained, the poor lack the resources to compete with the creamy, who "snatch away" those
seats. {N. M. Thomas (supra), para 124 (Iyer, J.)}. With the creamy excluded, poor OBCs would
compete with poor OBCs - the playing field levelled. As it stands, the Amendment and Act serve one
purpose: they provide a windfall of seats to the rich and powerful amongst the OBCs. It is
unreasonable to classify rich and poor OBCs as a single entity. As noted, this violates the Article 14
right to equality.
46. Unless the creamy layer is removed, OBCs cannot exercise their group rights. The Union of India
and other respondents argued that creamy layer exclusion is wrong because the text of the 93rd
Amendment bestows a benefit on "classes", not individuals. While it is a group right, the group must
contain only those individuals that belong to the group. I first take the entire lot of creamy and non
creamy layer OBCs.
I then remove the creamy layer on an individual basis based on their income, property holdings,
occupation, etc. What is left is a group that meets constitutional muster. It is a group right that must
also belong to individuals, if the right is to have any meaning. If one OBC candidate is denied special
provisions that he should have received by law, it is not the group's responsibility to bring a claim.
He would be the one to do so. He has a right of action to challenge the ruling that excluded him from
the special provisions afforded to OBCs. In this sense, he has an individual right. Group and
individual rights need not be mutually exclusive. In this case, it is not one or the other but both that
apply to the impugned legislation.
7 Whether the Creamy Layer exists outside India?:Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

47. An interesting question arises: does the concept of creamy layer exist outside
India? A 2003 study carried out in the United States suggests that it does. The study
by William Bowen, former president of Princeton University, found that when you
look at students with the same Scholastic Aptitude Test (SAT) scores, certain groups
have a better chance of being admitted to college. "The New Affirmative Action," by
David Leonhardt, New York Times, 30 September 2007, p. 3. All things being equal,
one's chance of gaining admission is augmented by belonging to one of the preferred
groups.
Individuals belonging to these groups are given preferential treatment over those who do not.
48. The study demonstrated that Black, Latino and Native-
Americans with the same SAT scores as White or Asian students had a 28% better chance than the
White or Asian students at gaining admission; those whose parents attended the college had a 20%
advantage over those whose parents did not; and the poor received no advantage whatsoever over
the rich. (See: New York Times article, p. 3.)
49. The statistics indicate that the failure to exclude the creamy layer ultimately leads to a situation
in which deserving students are excluded. When we revert to the Indian scenario, as long as the
Government gives handouts to certain groups, the creamy layer therein will "lap" them up. A scheme
in which the poor receive no advantage can be remedied by excluding the creamy layer.
50. Even the Mandal Commission, which was established in 1979 with a mandate to identify the
socially and educationally backward, admitted that the creamy layer was robbing fellow OBCs of
reservation. In reference to Tamil Nadu, it said: "In actual operation, the benefits of reservation
have gone primarily to the relatively more advanced castes amongst the notified backward classes."
(See: P.37, 8.13 of the Report of the Backward Classes Commission, First Part, Vols. 1-2, 1980). It
also stated that: "it is no doubt true that the major benefits of reservation.....will be cornered by the
more advanced sections....." but reasoned that this was acceptable because reform is presumably
slow and should start with the more advanced of the backward. (See: Page 62, para 13.7
(recommendations)).
51. In N. M. Thomas & Others case (supra), Krishna Iyer, J. in his concurring judgment in para 124
noted that the research conducted by the A.N. Sinha Institute of Social Studies, Patna, had revealed
a dual society among harijans in which a tiny elite gobbles up the benefits.
7 Severing the Creamy Layer
52. Technically speaking, I am severing the implied inclusion of the creamy layer. It is severable for
two reasons. First, a nine-Judge Bench in Sawhney I severed a similar provision wherein the creamy
layer was not expressly included, upholding the rest of the O.M.'s reservation scheme. Second,
because the Parliament must have known that Sawhney I had excluded the creamy layer, it seems
likely that the Parliament also realized that this Court may do the same. A cursory review of theAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Parliamentary Debates regarding Article 15(5) clearly reveals that the Parliament discussed the
Sawhney I judgment in detail. (See: for example, comments made by Shri Mohan Singh, p.474 and
Shri Devendra Prasad, pages 478-479 on 21 December 2005). Had the Parliament insisted on
creamy layer inclusion, it could have said as much in the text of 15(5). Instead, the Parliament left
the text of 15(5) silent on the issue, delegating the issue of OBC identification to the executive in
Section 2(g) of the Reservation Act.
53. The test for severability asks a subjective question: had the Parliament known its provision
would be struck would it still have passed the rest of the legislation? (See: R.M.D. Chamarbaugwalla
& Another v. Union of India & Another, AIR 1957 SC 628 at page 637 at para 23). It is never easy to
say what the Parliament would have done had it known that part of its amendment would be
severed.
Nevertheless, I find it hard to imagine that the Parliament would have said, "if the creamy is
excluded, the rest of the OBCs should be denied reservation in education." It seems unlikely that it
would have been an all-or-nothing proposition for the Parliament, when the very goal of the
impugned legislation of promoting OBC educational advancement does not depend on creamy layer
inclusion. For these reasons, I sever or exclude the implied inclusion of the creamy layer.
7 Identification of Creamy Layer
54. Income as the criterion for creamy layer exclusion is insufficient and runs afoul of Sawhney I.
(See: page 724 at para 792). Identification of the creamy layer has been and should be left to the
Government, subject to judicial direction.
For a valid method of creamy layer exclusion, the Government may use its post-Sawhney I criteria
as a template. (See: O.M. of 8-9-1993, para 2(c)/Column 3, approved by this Court in Ashoka Kumar
Thakur (supra), para 10). This schedule is a comprehensive attempt to exclude the creamy layer in
which income, Government posts, occupation and land holdings are taken into account. The Office
Memorandum is reproduced hereunder:
"No. 36012/22/93- Estt (SCT) Government of India Ministry of Personnel, Public
Grievances & Pension (Department of Personnel & Training) New Delhi, the 8th
September, 1993 OFFICE MEMORANDUM Subject: Reservation for Other Backward
Classes in Civil Posts and Services under the Government of India - Regarding.
The undersigned is directed to refer to this Department's O.M.
No.36012/31/90-Estt(SCT) dated 13th August, 1990 and 25th September, 1991
regarding reservation for Socially and Economically Backward Classes in Civil Posts
and Services under the Government of India and to say that following the Supreme
Court judgment in Indra Sawhney v. Union of India & Others (Writ Petition (Civil)
No.930 of 1990) the Government of India appointed an Expert Committee to
recommend the criteria for exclusion of the socially advanced persons/sections from
the benefits of reservation for Other Backward Classes in civil posts and servicesAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

under Government of India.
2. Consequent to the consideration of the Expert Committee's recommendation this
Department's Office Memorandum No.36012/31/90-Estt. (SCT), dated 13.8.1990
referred to in para (1) above is hereby modified to provide as follows:-
(a) 27% (Twenty seven percent) of the vacancies in civil posts and services under the
Government of India, to be filled through direct recruitment, shall be reserved for the
Other Backward Classes. Detailed instructions relating to the procedure to be
followed for enforcing reservation will be issued separately.
(b) Candidates belonging to OBCs recruited on the basis of merit in an open
competition on the same standards prescribed for the general candidates shall not be
adjusted against the reservation quota of 27%.
(c) (i) The aforesaid reservation shall not apply to persons/sections mentioned in
column 3 of the Schedule to this Office Memorandum.
(ii) The rule of exclusion will not apply to persons working as artisans or engaged in
hereditary occupations, callings. A list of such occupations, callings will be issued
separately by the Ministry of Welfare.
(d) The OBCs for the purpose of the aforesaid reservation would comprise, in the first
phase, the castes and communities which are common to both the lists in the report
of the Mandal Commission and the State Government's Lists.
A list of such castes and communities is being issued separately by the Ministry of Welfare.
(e) The aforesaid reservation shall take immediate effect.
However, this will not apply in vacancies where the recruitment process has already been initiated
prior to the issue of this order.
3. Similar instructions in respect of public sector undertakings and financial institutions including
public sector banks will be issued by the Department of Public Enterprises and by the Ministry of
Finance respectively from the date of this Office Memorandum.
SCHEDULE Description of To whom rule of exclusion will Category apply.
Son(s) and daughter(s) of CONSTITUTIONAL I. POSTS (a) President of India;
(b) Vice President of India;
(c) Judges of the Supreme Court and of the High Courts;Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(d) Chairman & Members of UPSC and of the State Public Service Commission; Chief Election
Commissioner;
Comptroller & Auditor General of India;
(e) Persons holding Constitutional positions of like nature.
SERVICE CATEGORY Son(s) and daughter(s) of II. A. Group A/Class 1 (a) parents, both of whom
are officers of the All India Class I officers;
Central and State Services (Direct (b) parents, either of whom is a Recruits) Class I officer;
(c) parents, both of whom are Class I officers, but one of them dies or suffers permanent
incapacitation.
(d) parents, either of whom is a Class I officer and such parent dies or suffers permanent
incapacitation and before such death or such incapacitation has had the benefit of employment in
any International Organisation like UN, IMF, World Bank, etc. for a period of not less than 5 years.
(e) parents, both of whom are class I officers die or suffer permanent incapacitation and before such
death or such incapacitation of the both, either of them has had the benefit of employment in any
International Organisation like UN, IMF, World Bank, etc. for a period of not less than 5 years.
(f) Provided that the rule of exclusion shall not apply in the following cases :-
(a) Sons and daughters of parents either of whom or both of whom are Class-I officers and such
parent(s) dies / die or suffer permanent incapacitation.
(b) A lady belonging to OBC category has got married to a Class-I officer, and may herself like to
apply for a job.
Group B/Class II Son(s) and daughter(s) of officers of the Central & (a) parents both of whom are
State Services (Direct Class II officers.
Recruitment)
(b) parents of whom only the husband is a Class II officer and he gets into Class I at the age of 40 or
earlier.
(c) parents, both of whom are Class II officers and one of them dies or suffers permanent
incapacitation and either one of them has had the benefit of employment in any International
Organisation like UN, IMF, World Bank, etc. for a period of not less than 5 years before such death
or permanent incapacitation;Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(d) parents, of whom the husband is a Class I officer (direct recruit or pre-forty promoted) and the
wife is a Class II officer and the wife dies; or suffers permanent incapacitation; and
(e) parents, of whom the wife is a Class I officer (Direct Recruit or pre-forty promoted) and the
husband is a Class II officer and the husband dies or suffers permanent incapacitation.
Provided that the rule of exclusion shall not apply in the following cases:
Sons and daughters of
(a) Parents both of whom are Class II officers and one of them dies or suffers permanent
incapacitation.
(b) Parents, both of whom are Class II officers and both of them die or suffer permanent
incapacitation, even though either of them has had the benefit of employment in any International
Organisation like UN, IMF, World Bank, etc. for a period of not less than 5 years before their death
or permanent incapacitation.
C. Employees in Public The criteria enumerated in A & B Sector Undertakings above in this Category
will apply etc. mutatis mutandi to officers holding equivalent or comparable posts in PSUs, banks,
Insurance Organisations, Universities, etc. and also to equivalent or comparable posts and positions
under private employment, Pending the evaluation of the posts on equivalent or comparable basis in
these institutions, the criteria specified in Category VI below will apply to the officers in these
Institutions.
        ARMED           FORCES  Son(s) and daughter(s) of parents 
        INCLUDING                  either   or   both   of   whom   is   or   are 
III.    PARAMILITARY               in the rank of Colonel and above 
        FORCES                     in   the   Army   and   to   equivalent 
                                   posts   in   the   Navy   and   the   Air 
(Persons holding civil Force and the Para Military posts are not included) Forces;
Provided that:-
(i) if the wife of an Armed Forces Officer is herself in the Armed Forces (i.e., the
category under consideration) the rule of exclusion will apply only when she herself
has reached the rank of Colonel;Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(ii) the services ranks below Colonel of husband and wife shall not be clubbed
together:
(iii) if the wife of an officer in the Armed Forces is in civil employment, this will not
be taken into account for applying the rule of exclusion unless the falls in the service
category under item No.II in which case the criteria and conditions enumerated
therein will apply to her independently.
PROFESSIONAL CLASS AND THOSE ENGANGED IN TRADE IV. AND INDUSTRY (I) Persons
engaged in Criteria specified against profession as a doctor, Category VI will apply:
       lawyer,                         Chartered 
       Accountant,                               Income-
       Tax                        Consultant, 
       financial                                           or 
       management 
       consultant,                                dental 
       surgeon,                             engineer, 
       architect,                           computer 
       specialist,   film   artists 
       and              other                            film 
       professional,                             author, 
       playwright,                                sports 
       person,                                         sports 
       professional,                                   media 
       professional   or   any 
       other   vocations   of   like 
       status.                                   Criteria 
       specified                                 against 
       Category VI will apply:Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

       (II)   Persons   engaged   in  Criteria                                     specified         against  
       trade,   business   and  Category VI will apply:
       industry
                                  Explanation:
                                  (i) Where the husband is in some 
                                  profession   and   the   wife   is   in   a 
                                  Class                   II         or               lower                    grade 
                                  employment, the income / wealth 
                                  test   will   apply   only   on   the   basis 
                                  of the husband's income.
                                  (ii) If the wife is in any profession 
                                  and               the              husband                         is                   in 
                                  employment in a Class II or lower 
                                  rank                     post,                       then                              the 
                                  income/wealth                                      criterion                      will 
                                  apply   only   on   the   basis   of   the 
                                  wife's   income   and   the   husband's 
                                  income   will   not   be   clubbed   with 
                                  it.
      PROPERTY OWNERS             Son(s) and daughter(s) of persons 
                                  belonging   to   a   family   (father, 
V.    A. Agricultural holdings    mother   and   minor   children) 
                                  which ownsAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

                                  (a)   only   irrigated   land   which   is 
                                  equal to or more than 85% of the 
                                  statutory ceiling area, or
                                  (b) both irrigated and unirrigated 
                                  land, as follows:
                                  (i)                    The   rule  of  exclusion   will 
                                  apply   where   the   pre-condition 
                                  exists   that   the   irrigated   area 
                                  (having   been   brought   to   a   single 
                                  type                    under                       a              common 
                                  denominator) 40% or more of the 
                             statutory                ceiling,              limit          for 
                             irrigated               land             (this          being, 
                             calculated   by   excluding   the 
                             unirrigated   portion).   If   this   pre-
                             condition   of   not   less   than   40% 
                             exists,   then   only   the   area   of 
                             unirrigated   land   will   be   taken 
                             into account. This will be done by 
                             converting   the   unirrigated   land 
                             on   the   basis   of   the   conversion 
                             formula                 existing,              into           the 
                             irrigated   type.   The   irrigated   area Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

                             so   computed   from   unirrigated 
                             land shall be added to the actual 
                             area of irrigated land and if after 
                             such   clubbing   together   the   total 
                             area in   terms of  irrigated  land  is 
                             80%   or   more   of   the   statutory 
                             ceiling   limit   for   irrigated   land, 
                             then   the   rule   of   exclusion   will 
                             apply   and   dis-entitlement   will 
                             occur.
                             (ii)        The   rule  of  exclusion   will 
                             not apply if the land holding of a 
                             family is exclusively unirrigated.
B. Plantations
(i) Coffee, tea, rubber,     Criteria                 of              income/wealth 
etc.                         specified in Category VI below will 
                             apply.
(ii) Mango, citrus, apple Deemed as agricultural holding plantations etc. and hence criteria at A
above under this Category will apply.
C. Vacant land and/or Criteria specified in Category VI buildings in urban below will apply.
areas or urban agglomerations Explanation: Building may be used for residential, industrial or
commercial purpose and the like two or more such purposes.
VI. INCOME/WEALTH Son(s) and daughter(s) of TESTAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(a) Persons having gross income of Rs.1 lakh or above or possessing wealth above the exemption
limit as prescribed in the Wealth Tax Act for a period of three years.
(b) Persons in Categories I, II, III and VA who are not disentitled to the benefit of reservation but
have income from other sources of wealth which will bring them within the income/wealth criteria
mentioned in (a) above.
Explanation:
(i) Income from salaries or agricultural land shall not be clubbed;
(ii) The income criteria in terms of rupee will be modified taking into account the change in its value
every three years. If the situation, however, so demands, the interregnum may be less.
Explanation: Wherever the expression "permanent incapacitation" occur in this schedule, it shall
mean incapacitation which results in putting an officer out of service.
Smt. Sarita Prasad Joint Secretary to the Government of India."
55. In sum, the schedule excludes the children of those who hold constitutional posts, e.g., the
children of the President of India, Supreme Court Judges, Chairman and Members of UPSC and
others are excluded. Class 1 Officers' children are not eligible for OBC perks either. When both
parents are Class-II Officers, their children are excluded. The same criteria that apply to Class-I and
II officers apply to children of parents who work at high levels within the private sector.
Agricultural owners are excluded when their irrigated holdings are more than or equal to 85% of the
statutory ceiling. The O.M. further excludes persons having a gross annual income of Rs.2.5 lakh or
more. The Government raised the income limit from Rs.1 to Rs.2.5 lakh on 09.03.2004 vide O.M.
36033/3/2004.
56. The creamy layer schedule of the O.M. dated 8.9.93, in my opinion, is not comprehensive. This
should be revised periodically - preferably once in every 5 years, in order to ensure that creamy layer
criteria take changing circumstances into account.
57. Apart from the people who have been excluded vide the office memo, I urge the Government to
make it more comprehensive. The Government should consider excluding the children of sitting and
former Members of Parliament (MP) and Members of Legislative Assemblies (MLA) from special
benefits. If constitutional authorities have been excluded from benefits because of their status or
resources, the same should apply to children of former and sitting MPs and MLAs. I hope the
judiciary will not have to involve itself in this matter.
2. Applying Article 21A to the Reservation ActAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

58. On 18 December 2006, in the Rajya Sabha Debate on the Reservation Act, Member of
Parliament and former Governor, Dr. P.C. Alexander summed up what would become one of
Petitioners' arguments. Should Rs.17,000 crores be spent on implementing the Reservation Act for
higher education when primary/secondary schooling is in such bad shape? Dr. Alexander stated:
"Sir, this spending Rs.17,000 crores or whatever amount is needed for adding seats in
the Engineering colleges, IIMs and IITs is reversing our priorities. If you have the
money for education, spend it on schools. Spend it on the rural areas for primary
schools; spend it on the schools, which are poorly starved in the urban areas. Instead
of doing that, you spend it by adding to the numbers because you want to appease the
so-called poorer sections in the higher castes. So, we have taken care of you and you
tell the backward classes we are taking care of all of you. This is where we land
ourselves in trouble. We have cash resources. They should be spent where priorities
are fixed clearly in our eyes and we don't want to do that."
Spending on higher at the expense of lower education raises the specter of conflict with Article 21A.
By the 86th Amendment, Article 21A was inserted in our Constitution.
Article 21A reads as follows:
"The State shall provide free and compulsory education to all children of the age of
six to fourteen years in such manner as the State may, by law, determine."
59. Under Article 21A, it is a mandatory obligation of the State to provide free and compulsory
education to all children aged six to fourteen. In order to achieve this constitutional mandate, the
State has to place much greater emphasis on allocating more funds for primary and secondary
education.
There is no corresponding constitutional right to higher education. The entire Nation's progress
virtually depends upon the proper and effective implementation of Article 21A.
60. This Court in Unni Krishnan, J.P. & Others v. State of Andhra Pradesh & Others (1993) 1 SCC
645 para 166 held as under:
"... right to education is implicit in and flows from the right to life guaranteed by
Article 21. That the right to education has been treated as one of transcendental
importance in the life of an individual [and] has been recognized not only in this
country since thousands of years, but all over the world. ... without education being
provided to citizens of this country, the objectives set forth in the Preamble to the
Constitution cannot be achieved. The Constitution would fail."
This observation encouraged the Parliament to insert Article 21A into the Constitution.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

61. In Unni Krishnan (supra), Justice Reddy observed that the quality of education in Government
schools was extremely poor and that the schools were woefully inadequate to the needs of the
children. He noted that many countries spend 6% to 8% of Gross Domestic Product on education.
Our expenditure on education is just 4% of GDP.
62. Though an improvement over past performance, the overall education picture leaves much to be
desired. The bad news is really bad. Even where we have seen improvement, there is still failure. A
survey by Pratham, an NGO, fleshes out the acute problems found in rural schools. (See: ASER 2007
- Rural Annual Status of Education Report for 2007, published on January 16, 2008). The survey
covered 16,000 villages. As Pratham indicates, there are an estimated 140 million children in the
age group 6 to 14 years in primary schools. Of these 30 million cannot read, 40 million can
recognize a few alphabets, 40 million can read some words, and 30 million can read paragraphs.
Over 55 million of these children will not complete four years of school, eventually adding to the
illiterate population of India. The national literacy rate is 65%.
63. 24 districts with more than 50,000 out of school children means we have failed 24 times over. 71
districts in which there are 60 students per teacher is just as bad, if not worse.
According to Pratham (and in line with the Ministry of HRD's six-month review), the number of out
of school children has hovered around 7,50,000. [page 6]. Moreover, it goes without saying that
children need proper facilities. Today, just 59% of schools can boast of a useable toilet. [page 49].
64. The quality of education is equally troubling. For standards I and II, only 78.3% of students
surveyed could recognize letters and read words or more in their own language. [page 47]. In 2006,
it was even worse - only 73.1% could do so. It is disheartening to peruse the statistics for standards
III to V, where only 66.4% could read Standard I text or more in their own language in 2007. [page
47]. As Pratham stated at page 7:
"What should be more worrying though, is the fact that in class 2, only 9 percent
children can read the text appropriate to them, and 60 percent cannot even recognise
numbers between 10 and 99."
65. In the third to fifth standards, 40% of students surveyed could not subtract. The latest figures
indicate that 58.3% children in the fifth standard read at the level appropriate for second Standard
students. [page 32]. In both 2005 and 2007, only 74.1% of enrolled children were in attendance.
[page 49].
66. The learned Solicitor General, Mr Vahanvati, submitted that the Government has now placed
sufficient emphasis on primary education. In 2001-2002, the Government launched Sarva Shiksha
Abhiyan (SSA). This national programme's goal is to universalize elementary education. It
supplements Governmental spending on education. As the Solicitor General explained, it was
founded on the idea that education for those between the ages of six to fourteen is a fundamental
right. In this way, SSA seeks to fulfill the Government's obligation under Article 21A to provide free
and compulsory education to this age group. Some of the SSA's accomplishments merit mention.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

67. By March 2007, 2,03,577 toilets had been constructed or were under construction, covering 87%
of the goal; more than six crore free textbooks had been supplied - 96% of the goal;
1,93,220 new schools had been completed or were under construction, i.e., 80% of the desired mark.
The learned Solicitor General further provided that enrolment for all districts in 2004-05 for classes
I-V was 11,82,96,540. In 2005-06, the number increased to 12,46,15,546. A similar increase was
seen in Classes VI-VII/VIII: from 3,77,17,490 to 4,36,67,786. The total number of teachers
increased from 36,67,637 in 2003-04 to 46,90,176 in 2005-06.
68. It is the learned Solicitor General's contention that SSA was responsible for many of the gains
cited above. This includes the improved statistics on the student-teacher ratio, out of school children
and enrollment rate for girls.
69. While the Government is on the right track with regard to improving the infrastructure of our
system, books and buildings only go so far. They are necessary but not sufficient for achieving the
ultimate goals of (1) keeping children in school, (2) ensuring that they learn how to think critically
and (3) ensuring that they learn skills that will help them secure gainful employment. The quality of
education provided in the majority of primary schools is woeful. That is why I find it necessary to
review Government spending on education -
especially at the primary/secondary level.
70. Undoubtedly, the Government has allocated more funds of late for education, but we need to
have far more allocation of funds and much greater emphasis on free and compulsory education.
Anything less would flout Article 21A's mandate.
According to H.R.D. Annual Reports read with the Union of India Budget 2008-09, we spend
roughly seven times as much on the individual college student than the individual primary or
secondary student.
Spending per Student: Comparing that which is spent on each primary/secondary student versus
each higher education student Year & Level of Estimated # of Total Rs. Allocated** Expenditure per
Schooling Enrolled Students* student in Rs.
School Education/ 
        Literacy
       2006-2007          11777296            69120900000                   5868
Tertiary Education
       2007-2008              219083879               231913500000                  1059Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

 School Education/
        Literacy
       2007-2008              11777296                63973600000                   5432
Tertiary Education
       2008-2009              219083879               278500000000                  1271
 School Education/
        Literacy
       2008-2009              11777296                108528700000                  9215
Tertiary Education
* = Estimated number of students for primary/secondary level is taken from 2004-2005 Annual
Report, p. 250 at http://www.education.nic.in/AR/AR0607-en.pdf. In the same Annual Report,
11777296 students were enrolled in higher education in 2004- 2005. For consistency's sake, I have
used the 2004-2005 estimates. I have found no information that suggests that enrolment for one
has significantly outpaced the other.
** = Government of India, Expenditure Budget Vol. 1, 2008-2009, p. 6, Total Expenditure of
Ministries/Departments (school education/literacy and higher education have been added).
71. In a country where only 18% of those in the relevant age group make it to higher education, this
is incredible. See NSSO 1999-2000. It is not suggested that higher education needs to be neglected
or that higher education should not receive more funds, but there has to be much greater emphasis
on the primary education. Our priorities have to be changed. Nothing is really more important than
to ensure total compliance with Article 21A. How can a sizeable portion of the population be
precluded from realizing the benefits of development when almost everyone acknowledges that the
children are our future?
1. Education for children up to the age of fourteen years should be free. This has also been suggested
in the recommendations of the Kothari Commission on Education in 1966. Taking the country's
rampant poverty into account, free education up to the age 14 years is absolutely imperative.
There is no other way for the poor to climb their way out of this predicament.
2. Mr. P.P. Rao, learned Senior Advocate, rightly submitted that when you lack a school building,
teachers, books and proper facilities, your schooling might be "free" but it is not an "education" in
any proper sense. Adequate number of schools must be established with proper infrastructure
without further delay. In order to achieve the constitutional goal of free and compulsory education,Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

we have to appreciate the reality on the ground. A sizeable section of the country is still so poor that
many parents are compelled to send their children to work. The State must carve out innovative
policies to ensure that parents send their children to school. The Mid-Day Meal Scheme will go a
long way in achieving this goal. But, apart from Mid-Day Meals, the Government should provide
financial help to extremely poor parents.
74. In addition to free education and/or other financial assistance, they should also be given books,
uniforms and any other necessary benefits so that the object of Article 21A is achieved. Time and
again, this Court, in a number of judgments, has observed that the State cannot avoid its
constitutional obligation on the ground of financial inabilities.
(See: Hussainara Khatoon & Others (III) v. Home Secretary, State of Bihar, Patna (1980) 1 SCC 98,
107 at para 10).
75. In Vasanth Kumar (supra) at para 150, Justice Venkataramiah suggested that the State provide
preferential treatment such as tuition, scholarships, free boarding and lodging, etc. According to
UNESCO's Education for All, Global Monitoring Report (2008) at page 115, at least fourteen
countries have cash-transfer programmes that target poor households with school-age children. The
largest programme is in Brazil, where 46 million people receive an education transfer of up to $44
USD monthly per household in extreme poverty with children below age 16. According to the
Report, the programme has reduced drop-out rates by up to 75% among beneficiaries in its more
recent stage.
76. Such a programme is not foreign to India. According to UNICEF, the State of Gujarat put the
idea of financial incentives for youth into action:
"Figures indicate that the school enrolment drive of the state Government supported
by incentives like Vidyalaxmi bond of Rs.1,000 given to each girl who completes
primary education and 60 kg of wheat for tribal girls attending school, has met with
significant success. In addition to the various incentives by the Government, many a
corporate houses and community have also come forward to motivate parents and
children by donating school bags, uniforms, stationery, etc. As a result, the drop-out
rate has come down from 35.31 % in 1997-1998 to 3.24% in 2006-2007 in class 1-5.
In girls, this rate has dropped from 38.95% to 5.97 in the same time period."
77. In January 2008, Haryana Chief Minister Mr. Bhupinder Singh Hooda unfurled an incentive
scheme for SC students in which students would receive a one-time payment in addition to a
monthly stipend for attending school. (See: "Incentives announced to curb dropout rate", The
Tribune, 5 Jan. 2008).
The relevant portion is mentioned hereinbelow:
"Secretary, education, Rajan Gupta said a one-time allowance of Rs.740 to Rs.1,450
would be given to SC students from class I to XII. ... Under the monthly incentiveAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

scheme, boys and girls studying in class I to V would be given Rs100 and Rs.150,
respectively, per month and boys and girls of class VI to VIII Rs.150 and Rs.200.
Similarly, boys and girls of class IX to XII would be given Rs.200 and Rs.300,
respectively, and boys and girls studying science subjects in class XI and XII Rs.300
and Rs.400, respectively. ... This monthly incentive to the students would be
deposited in their bank accounts to maintain transparency in the scheme, he added."
78. In the name of transparency, students' attendance records could be made available to
administrators and parents. Students would be paid to attend school. They would receive a sum for
each day of school that they attended.
If you only attend 7 out of 10 school days, you would only receive 70% of the stipend.
79. Ultimately, this is the most important aspect of implementing Article 21A, incentives should be
provided to parents so that they are persuaded to send their children to school. More than
punishment, creative incentive programmes will go a long way in the implementation of the
fundamental right enshrined under Article 21A.
7 Historical Perspective on Compulsory Education:
80. Almost two centuries ago, Clause 43 of The Charter Act of 1813 made education a
State responsibility. [See: "Free and Compulsory Education: Genesis and Execution
of Constitutional Philosophy", Dr. P.L. Mehta and Rakhi Poonga, Deep and Deep
Publications, New Delhi (1997)]. [pages 42-47].
The Hunter Commission (1882-83) was the first to recommend universal education in India.
Thereafter, the Patel Bill, 1917 was the first compulsory education legislation. It proposed to make
education compulsory from ages 6 to 11.
81. The Government of India Act, 1935 provided that "education should be made free and
compulsory for both boys and girls." Free and compulsory education got a further boost when the
Zakir Hussain Commission recommended that the State should provide it. The 1944 Sargent Report
strongly recommended free and compulsory education for children aged six to fourteen. By 1947,
primary education had been made compulsory in 152 urban areas and 4995 rural areas.
82. The State has been making some endeavour to provide free and compulsory education since
1813 in one form or the other. When the original Framers gathered at the Constituent Assembly,
their desire to provide free and compulsory education was well established. The real question in the
Debate was whether the original Framers would make free and compulsory education justiciable or
not. They oscillated between the options, first placing it in the fundamental rights and later moving
it to the directive principles of State policies under Article 45 of the Constitution.
83. Over 50 years later, the Parliament revisited the subject.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

The Parliamentary debate on Article 21A offers a glimpse into the history of compulsory education
in other countries. The then Minister of Human Resource Development, Dr. M.M. Joshi, referred to
the speech of Shri Gopal Krishna Gokhale on compulsory education. While debating a bill in the
imperial legislative council in 1911, Shri Gokhale said that in most countries:
"...elementary education is both compulsory and free, and in a few, though the
principle of compulsion is not strictly enforced or has not been introduced it is either
wholly or for the most part gratitutious, in India alone it is neither compulsory nor
free. Thus in Great Britain and Ireland, France, Germany, Switzerland, Austria,
Hungary, Italy, Belguim, Norway, Sweden, the United States of America, Canada,
Australia and Japan it is compulsory and free. .... In Spain, Portugal, Greece,
Bulgaria, Servia and Rumania, it is free, and in theory, compulsory, though
compulsion is not strictly enforced." [Lok Sabha Debates, 28 November, 2001,
Vol.20, page 476].
84. In 1948, the United Nations made its own pronouncement on compulsory education. Article
26(1) of the Universal Declaration of Human Rights made free and compulsory education a lofty if
not enforceable goal. While many states consider it an authoritative interpretation of the United
Nations Charter, the Declaration is not a treaty and is not intended to be legally binding. Article
26(1) states:
"Everyone has the right to education. Education shall be free, at least in the
elementary and fundamental stages. Elementary education shall be compulsory.
Technical and professional education shall be made generally available and higher
education shall be equally accessible to all on the basis of merit."
85. Our original Framers put a similar emphasis on the matter, placing free and compulsory
education in the Directive Principles. The un-amended Article 45 provided that:
"The State shall endeavour to provide, within a period of ten years from the
commencement of this Constitution, for free and compulsory education for all
children until they complete the age of fourteen years."
86. At this juncture, I deem it appropriate to refer to the Parliamentary Debate on the aspect of free
and compulsory education. In the Lok Sabha debate of 28 November 2001 at Vol. 20, Shri M.V.V.S.
Murthi, at page 499, stated:
"Unless the Government makes primary education compulsory, no village can
develop. If I say what they are doing in Andhra Pradesh, some Members may again
cry foul. In Andhra Pradesh, we are having Education Committees. If there are any
dropouts, the Committee will go to the village and find out the reason as to why they
have dropped out. It is very important."Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

87. The Report of the Kothari Commission, 1964-1966, headed by Prof. D. S. Kothari, provided
important recommendations on compulsory education. Nevertheless, the circumstances of the day
compelled it to soften its suggestions. The Nation was relatively poor and could not afford drastic
increases in education spending. Some excerpts of this report are reproduced as under:
"5.01. ...But in any given society and at a given time, the decisions regarding the type,
quantity and quality of educational facilities depend partly upon the resources
available and partly upon the social and political philosophy of the people. Poor and
traditional societies are unable to develop even a programme of universal primary
education. But rich and industrialized societies provide universal secondary
education and expanding and broad-based programmes of higher and adult
education. Feudal and aristocratic societies emphasize education for a few. But
democratic and socialistic societies emphasize mass education and equalization of
educational opportunities. The principal problem to be faced in the development of
human resources, therefore, is precisely this: How can available resources be best
deployed to secure the most beneficial form of educational development? How much
education, of what type or level of quality, should society strive to provide and for
whom?
5.03 Increasing the Educational Level of Citizens. In the next two decades the highest
priority must be given to programmes aimed at raising the educational level of the
average citizen. Such programmes are essential on grounds of social justice, for
making democracy viable and for improving the productivity of the average worker in
agriculture and industry. The most crucial of these programmes is to provide, as
directed by Article 45 of the Constitution, free and compulsory education of good
quality to all children up to the age of 14 years. In view of the immense human and
physical resources needed, however, the implementation of this programme will have
to be phased over a period of time."
88. When Article 21A was introduced, some Members of Parliament argued that financially poor
parents who fail to send their children to school should not be punished and that the word
"compulsion" in this Article should be understood to apply exclusively to the State.
89. Let me examine this argument. The 86th Amendment made three changes to the Constitution. It
added Articles 21A and 51A(k) and amended Article 45. I turn my focus to Article 51A(k). In addition
to rejecting an amendment that would have neutered compulsory education, the Parliament made a
positive gesture. Though it never passed legislation seeking to implement compulsory education, it
had not completely ignored the subject. From Article 51A(k), it becomes clear that parents would be
responsible for sending their children to school. Article 51A read with 51A(k) is reproduced as
under:
"It shall be the duty of every citizen of India - who is a parent or guardian to provide
opportunities for education to his child or, as the case may be, ward between the age
of six and fourteen years."Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

90. Just as Article 51A(a) does not penalize disrespect of the National Flag, Article 51A(k) does not
penalize parents/guardian for failing to send children to school. There is, of course, legislation that
gives teeth to Article 51A(a). (See:
The Prevention of Insults to National Honour Act, 1971, Section 3A).
91. Article 51A(k) indicates that it is parents, not the State, who are responsible for making sure
children wake up on time and reach school. Thus, Article 21A read with Article 51A(k) distributes an
obligation amongst the State and parents: the State is concerned with free education, parents with
compulsory. Notwithstanding parental duty, the State also has a role to play in ensuring that
compulsory education is feasible - a topic I will cover below.
92. The Central Government has made some effort to fulfill its obligation under Article 21A with
regard to "free education."
Sarva Shiksha Abhiyan is one such example. When it comes to "compulsory education," the Central
Government has made no such effort. The Parliament has not passed any legislation.
The executive has not issued any order. What we have is a patchwork of different State and Union
Territory laws. These States/UTs (and NCR) include:
Assam, Andhra Pradesh, Bihar, Chhatisgarh, Goa, Gujarat, Haryana, Himachal
Pradesh, Jammu & Kashmir, Karnataka, Kerala, Madhya Pradesh, Maharashtra,
Orissa, Punjab, Rajasthan, Sikkim, Tamil Nadu, Uttar Pradesh, West Bengal, Delhi,
Andaman & Nicobar Islands.
93. The majority of the States and Union Territories levy very small fines on parents. I note that
these laws do not go into effect with one unexcused absence. Notice is given to the parents, giving
them time to remedy the problem. Of course, enforcement is almost always a different story.
94. In contrast to the relatively light aforementioned sentences, the Compulsory Education Bill,
2006 introduced in the Rajya Sabha would provide six months imprisonment as a penalty for those
who preclude children from going to school.
If this Bill becomes law, Section 7 would dictate the following:
"If any person including parents of children prevents any boy or girl child from going
to school or causes hindrance or obstruction in any way, he shall be punishable with
imprisonment, which may extend to six months."
95. It seems that the Bill simultaneously targets employers and parents. Employers would be
punished when they hire a child to work too much or during school hours. Similarly, parents would
also be punished for allowing this to happen.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

The Bill would also provide for scholarships, free hostel facilities and other incentives, "whenever
necessary" and "as may be prescribed".
96. In Bandhua Mukti Morcha v. Union of India & Others, (1997) 10 SCC 549 at page 557 at para 11,
the Court explained why education should be compulsory. In essence, a citizen is only free when he
can make a meaningful challenge to his fellow citizens or Government's attempt to curtail his
natural freedom. For this to happen, he needs a certain degree of education. This is why Article 21A
may be the most important fundamental right. Without it, a citizen may never come to know of his
other rights; nor would he have the resources to adequately enforce them. The relevant passage at
para 11 reads as under:-
"A free educated citizen could meaningfully exercise his political rights, discharge
social responsibilities satisfactorily and develop a spirit of tolerance and reform.
Therefore, education is compulsory. Primary education to the children, in particular,
to the child from poor, weaker sections, Dalits and Tribes and minorities is
mandatory. The basic education and employment-oriented vocational education
should be imparted so as to empower the children within these segments of the
society to retrieve them from poverty and, thus, develop basic abilities ... to live a
meaningful life ... Compulsory education, therefore, to these children is one of the
principal means and primary duty of the State for stability of the democracy, social
integration and to eliminate social tensions."
97. In contrast to Article 51A(k), State and Union Territory laws and Parliamentary intent with
regard to Article 21A, the Court in Mukti Morcha was inclined to suggest, not hold, that the State
was exclusively responsible for compulsory education. It went on to reaffirm M.C. Mehta v. State of
Tamil Nadu & Others (child labour matter) (1996) 6 SCC
756. In that case, the Court took up the issue of child labour in hazardous fields when it learnt of an
accident in a cracker factory in Sivakasi.
98. The said case at para 28 identified poverty as the root cause of child labour:
"Of the aforesaid causes, it seems to us that ... poverty is basic reason which compels
parents of a child, despite their unwillingness, to get it employed. The Survey Report
of the Ministry of Labour (supra) had also stated so. Otherwise, no parents, specially
no mother, would like that a tender-aged child should toil in a factory in a difficult
condition, instead of its enjoying its childhood at home under the paternal gaze."
99. In other words, parents send children to work because parents have no other choice. Food comes
first. If the State does not provide extra income so as to remove the incentive to send children to
work, it is wasting its time on mere gesture.
The Court in para 29 concluded that action must be taken:Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"It may be that [child labour] would be taken care of to some extent by insisting on
compulsory education. Indeed, Neera [Burns] thinks that if there is at all a blueprint
for tackling the problem of child labour, it is education. Even if it were to be so, the
child of a poor parent would not receive education, if per force it has to earn to make
the family meet both the ends. Therefore, unless the family is assured of income
aliunde, problem of child labour would hardly get solved; and it is this vital question
which has remained almost unattended. We are, however, of the view that till an
alternative income is assured to the family, the question of abolition of child labour
would really remain will-o'-the-wisp." (emphasis added).
100. It is interesting to note that compulsory education has been introduced in one form or the other
in various countries.
From the historical experience of these nations, we learn that the legislation pertaining to
compulsory education has played an important role in improving educational outcomes.
7 Compulsory education's roots in the United States
101. Compulsory education has had a long history outside of India. In 1852, the State of
Massachusetts enacted the first compulsory attendance law in the United States; though compulsory
education laws existed much earlier in many states, the first dating back to 1642 in Massachusetts.
"Were Compulsory Attendance and Child Labor Laws Effective? (See:
An analysis from 1915 to 1939." (2001) at p. 2. Prof. Adriana Lleras-Muney of Princeton University.)
7 Reasons from abroad for implementing compulsory education:
102. Prof. Lleras-Muney explains that those who advocated for compulsory education
believed that universal education was necessary to promote democracy and
guarantee a common American culture. (Page 11). Given the influx of immigrants,
some of whom came from undemocratic countries, many supporters of legislation
viewed compulsory education as an instrument for assimilation.
103. Other reasons cited by compulsory education proponents in the United States
included the reduction of crime, racism and inequality. Prof. Oreopoulos of the
University of Toronto cites to sources that make it appear as though the reasons for
adopting compulsory education in Canada mirrored those cited in the United States:
the emphasis was on good citizenship and economic development:
"Archibald Macallum, an Ontario teacher, summarized the latter argument
vigorously in an 1875 report favouring the introduction of compulsory schooling in
Canada: `Society has suffered so cruelly from ignorance, that its riddance is a matter
of necessity, and by the universal diffusion of knowledge alone can ignorance and
crime be banished from our midst; in no other way can the best interests of society be
conserved and improved than by this one remedy - the compulsory enforcement ofAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

this great boon - the right of every Canadian child to receive that education that will
make him a good, loyal subject, prepared to serve his country in the various social
functions which he may be called on to fill during his life; and prepare him, through
grace, for the life to come' (Annual Report of the Ontario Teachers' Association, 1875,
as cited in Prentice and Houston 1975, 175-6). (See: The Canadian Journal of
Economics, Vol. 39, No.1, February (2006) "The compelling effects of compulsory
schooling: the evidence from Canada," Prof. Oreopoulos, at page 23)."
7 Empirical data indicating that compulsory education has a positive effect:
104. Prof. Oreopoulos provides data that show the fruits of imposing education on
citizens. Crime may be lowered, health improved and civic activity increased.
Compulsory education may also lead to a substantial increase in income for
individuals. Moreover, compulsory education, if it does not cause, may at least
contribute to an increase in bilingualism and employment and a reduction in poverty.
The relevant portion is reproduced hereunder:
"(Page 24). Other papers find evidence of social returns, but for non-pecuniary
outcomes. Lochner and Moretti (2002), for example, find that compulsory schooling
lowers crime, while Lleras-Muney (2002) finds a correlation with improved health.
In studies of the United States and United Kingdom, Dee (2003) and Milligan,
Moretti, and Oreopoulos (2003) estimate that tighter restrictions on leaving school
early correspond to increased levels of civic activity (like voting and discussing
politics). ... My analysis suggests that students compelled to complete an extra grade
of school have historically experienced an average increase of 9-15% in annual
income.
(Page 48). I find that the introduction of tighter provincial restrictions on leaving school between
1920 and 1990 raised average grade attainment and incomes. Students compelled to attend an extra
year of school experienced an average increase in annual income of about 12%. I also find that
compulsory schooling is associated with significant benefits in terms of other socio-economic
outcome measures ranging from bilingualism, employment, and poverty status. These results hold
up against many specifications checks and are entirely consistent with previous studies."
105. In addition to increased income, Prof. Lleras-Muney found that legally requiring a child to
attend school for one more year increased educational attainment by roughly five percentage points.
(Page 8). Educational attainment refers to time spent in school.
7 Example of compulsory education statutes
106. The causes of low enrolment, high drop-out rates and frequent truancy in the U.S. and India
differ, but the consequences thereof do not. In either case, citizens who lack education are at an
extreme disadvantage. In India, poverty has been identified as the ultimate cause of lackluster
enrolment and attendance rates. Children are compelled to work. In developed countries like theAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

United States or Canada, children rarely fail to attend school because of economic constraints.
Instead, a number of different factors may contribute to truancy. High school students may drop out
"... because they detest school, lack motivation, or anticipate little reward from graduation." (See:
The Canadian Journal of Economics, "The compelling effects of compulsory schooling: the evidence
from Canada," Prof. Oreopoulos, p. 23, (quoting from Eckstein, Zvi, and Kenneth I. Wolpin (1999)
"Why youths drop out of high school: the impact of preferences, opportunities, and abilities,"
Econometrica 67, 1295-339).
107. As I detail below, students and parents in the United States often face the same fines when
students fail to attend school. Fines for students make more sense when low self-
control is the reason for which they fail to attend school. At the same time, punishing Indian
students who have no choice but to work would make no sense. Such a punishment should not be
borrowed from the United States.
108. In many jurisdictions in the United States, the attendance officer is responsible for enforcing
compulsory attendance laws for his area or school. Given the overwhelming problem of sub-par
enrolment and attendance in India, we doubt that one school official could sufficiently do the work
of inspecting places of employment for children who have violated attendance laws.
109. Indeed, existing legislation in India already envisages the employment of attendance officers.
The Delhi Primary Education Act, 1960, Sec. 7. Yet, there is nothing to suggest that these employees
have adequately dealt with truancy. As mentioned, this is, in part, due to the economic conditions in
which many parents find themselves. Financial assistance or incentives must be given. Only then,
may the Government actively enforce compulsory attendance legislation.
110. We must also remember that it is not only the child who fails to attend but also the child who
fails to enroll that has violated an attendance law.
111. Before taking issue with State/Union Territory compulsory education statutes, I note that
education has traditionally been reserved for the States. Only in 1976, vide the 42nd Amendment of
the Constitution, did education become a part of Concurrent List of Schedule 7. In its 165th Report,
the Law Commission of India has also recommended enactment of Central Legislation in this
respect. Putting education in the Concurrent List turns out to be a positive development, given the
States' failure to provide effective legislation.
112. The States' laws fail on two accounts. First, they are too lenient to have a deterrent effect.
Second, the legislation is not adequately enforced, in part, because it does not require police officers
to do the job. If we analyze the legislation passed by different States, another conclusion becomes
obvious: no State has provided for an adequate punishment whose effect would be to deter citizens
from committing a violation.
113. It is necessary to reproduce some of the various compulsory education laws of the States.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

114. Under Section 7 of The Tamil Nadu Compulsory Elementary Education Act, 1994:
"Every parent or guardian of a child of school age who fails to discharge his duty
under section 4 [duty of parent to cause child to attend elementary school] shall be
punishable with fine which may extend to one hundred rupees."
115. Section 18(1) of The Delhi Primary Education Act, 1960 states:
"If any parent fails to comply with an attendance order passed under Section 13, he
shall be punishable with fine not exceeding two rupees, and, in the case of continuing
contravention, with an additional fine not exceeding fifty naye paise for every day
during which such contravention continues after conviction for the first of such
contraventions. Provided that the amount of fine payable by any one person in
respect of any child in any one year shall not exceed fifty rupees."
116. Analysis of these State laws reveals that they are weak in character and perhaps have never been
implemented. If we compare these laws with their sister statutes in United States, we realize that the
U.S. laws are far stronger.
117. In Wisconsin, parents who fail to send their children to school may have to pay a fine of not
more than $500 or face imprisonment for not more than 30 days or both. [Wisconsin Statute
Sections 118.15(1)(a) and 118.15(5)(a)1.a]. For a second or subsequent offense, they may face a fine
of not more than $1,000 or imprisonment for not more than 90 days or both. [Wisconsin Statute
Sections 118.15(1)(a) and 118.15(5)
(a)1.b]. Alternatively, they may be sentenced to perform community service. [Wisconsin Statute
Sections 118.15(1)(a) and 118.15(5)(a)2] .
Unlike Wisconsin, Tamil Nadu and Delhi's laws have no teeth.
118. The other main problem is implementation of these laws.
Neither the State Governments nor their police agencies are at all serious about implementing these
compulsory laws. There are hardly any cases where even fines have been imposed.
Some form of compulsory education has been on the statute books since 1917. We have seen
Western countries enforce these laws. Most Western countries enjoy almost universal literacy while
35% of our population is illiterate. While a robust financial incentive programme may not have been
possible in 1917, it is today. If we wish to develop further, we must educate each and every citizen
aged six to fourteen.
119. In order to give effect to the constitutional right under Article 21A, it is imperative that the
Central Government pass suitable legislation. The fine should be suitably increased.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Imprisonment should be a sentencing option as well. The current patchwork of State/UT legislation
on compulsory education is insufficient. Small monetary fines do not go far enough to ensure the
implementation of Article 21A.
120. A disclaimer is attached to these recommendations.
The recommendations for the enforcement of compulsory education are contingent upon the
implementation of a financial incentive program that would make education viable for the poor. The
carrot must come before the stick. If there is no financial incentive program in place, the
Government cannot expect the poorest of the poor to send their children to school.
121. The Parliament should criminally penalize those parents who receive financial benefits and,
despite such payments, send their children to work and penalize those employers who preclude
children from attending school or completing homework. It has become necessary that the
Government set a realistic target within which it must fully implement Article 21A regarding free
and compulsory education for the entire country. The Government should suitably revise budget
allocations for education. The priorities have to be set correctly. The most important fundamental
right may be Article 21A, which, in the larger interest of the nation, must be fully implemented.
Without Article 21A, the other fundamental rights are effectively rendered meaningless. Education
stands above other rights, as one's ability to enforce one's fundamental rights flows from one's
education. This is ultimately why the judiciary must oversee Government spending on free and
compulsory education.
122. At the same time, spending is an area in which the judiciary must not overstep its constitutional
mandate. The power of the purse is found in Part V, Chapter II of the Constitution, which is
dedicated to the Parliament. (See:
Articles 109 and 117 for "Money Bills.") Nevertheless, it remains within the judiciary's scope to
ensure that the fundamental right under Article 21A of Part III is upheld. In M.C. Mehta v. Union of
India (vehicular pollution) (1998) 6 SCC 63, this Court did not ignore the Article 21 right to life
when deadly levels of pollution put the right at stake. Nor will this Court ignore the Article 21A right
to education, when a dearth of quality schooling put it in jeopardy. The Government's education
programmes and expenditures, wanting in many respects, are an improvement over past
performance. They nearly fall short of the constitutional mark. Lackluster performance in
primary/secondary schools is caused in part because Government places college students on a
higher pedestal. Money will not solve all our education woes, but a correction of priorities in step
with the Constitution's mandate will go a long way.
7 Opposition to Compulsory Education
123. "Compulsory" connotes enforcement. The Parliament rejected an amendment that would have
saved parents from penal penalties. If education were not compulsory, who checks in with parents
who have sent their children to work? If no authorities inquire, the message is clear: We, the State,
do not care if your child goes to school. Taking the opposing view, Shri G.M. Banatwalla wanted toAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

make sure parents were not punished:
"...this word `compulsion' needs to be properly defined. The word, `compulsion' is
not to be related to the student or the parents. Parents cannot be penalized for being
too poor to send their children to school. The word, `compulsion' has to be
understood in relation to the State and the obligation of the State to provide for free
education. p. 523." (See: The Parliamentary Debates on Article 21A, p. 523, 28
November 2001 at Vol. 20, No. 6-10)
124. The Parliament had the opportunity to accept such a definition of "compulsory." But they chose
otherwise.
Amendment number four, moved by Shri G.M. Banatwalla at p. 548, stated that:
"Provided that in making any law to provide for free and compulsory education under
this article, the State shall not...
(b) enforce any penal sanctions on a parent or guardian."
1. Of paramount importance, this Amendment was "negatived." [See p. 548]. Those who wanted a
safe-haven from penal sanction for parents lost. From this vote, we know that the Parliament
intended to allow for future legislation that would impose penal sanctions for violations of
legislation under Article 21A.
7 Conclusion on Free and Compulsory Education
2. Given that so many children drop out of, or are absent from, school before they turn fourteen,
"free education" alone cannot solve the problem. The current patchwork of laws on compulsory
education is insufficient. Monetary fines do not go far enough to ensure that Article 21A is upheld.
3. A carrot-and-stick approach appears to be the best way to implement Article 21A. Financial
incentive programmes have worked well in other countries. We should follow their lead. Once that is
done, the Government should strictly enforce effective compulsory education laws. Such a policy is
bound to pay off.
In sum, the Central Government should enact legislation that:
(a) provides low-income parents/guardians with financial incentives such that they
may afford to send their children to school;
(b) criminally penalizes those who receive financial incentives and despite such
payment send their children to work;Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(c) penalizes employers who preclude children from attending school or completing
homework;
(d) the penalty should include imprisonment; the aforementioned Bill would serve as
an example. The State is obligated under Article 21A to implement free and
compulsory education in toto;
(e) Until we have achieved the object of free and compulsory education, the
Government should continue to increase the education budget;
(f) the Parliament should set a deadline by which time free and compulsory education
will have reached every child. This must be done within six months.
128. With regard to (a), the state cannot cite budgetary constraints or lack of resources as an excuse
for failing to provide financial assistance/incentives to poor parents. See Hussainara Khatoon
(supra), at page 107, para 10.
129. Article 21A's reference to "education" must mean something. This conclusion is bolstered by the
Parliament's Statement of Objects and Reasons for Article 21A:
"The Constitution of India in a Directive Principle contained in article 45, has made a
provision for free and compulsory education for all children up to the age of fourteen
years within ten years of promulgation of the Constitution. We could not achieve this
goal even after 50 years of adoption of this provision. The task of providing education
to all children in this age group gained momentum after the National Policy of
Education (NPE) was announced in 1986. The Government of India, in partnership
with the State Governments, has made strenuous efforts to fulfill this mandate and,
though significant improvements were seen in various educational indicators, the
ultimate goal of providing universal and quality education still remains unfulfilled. In
order to fulfill this goal, it is felt that an explicit provision should be made in the Part
relating to Fundamental Rights of the Constitution.
1. With a view to making right to free and compulsory education a fundamental right,
the Constitution (Eighty-third Amendment) Bill, 1997 was introduced in the
Parliament to insert a new article, namely, article 21A conferring on all children in
the age group of 6 to 14 years the right to free and compulsory education. The said
Bill was scrutinized by the Parliament Standing Committee on Human Resource
Development and the subject was also dealt with in its 165th Report by the Law
Commission of India.
2. After taking into consideration the report of the Law Commission of India and the
recommendations of the Standing Committee of the Parliament, the proposed
amendments in Part III, Part IV and Part IVA of the Constitution are being made
which are as follows ...Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

3. The Bill seeks to achieve the above objects"
130. The Article seeks to usher in "the ultimate goal of providing universal and quality education."
(emphasis supplied). Implied within "education" is the idea that it will be quality in nature. Current
performance indicates that much improvement needs to be made before we qualify "education"
with "quality." Of course, for children who are out school, even the best education would be
irrelevant. It goes without saying that all children aged six to fourteen must attend school and
education must be quality in nature. Only upon accomplishing both of these goals, can we say that
we have achieved total compliance with Article 21A.
131. Though progress has been made, the Parliament's observation upon passing Art 21A still
applies: the goal of providing universal and quality education "... still remains unfulfilled."
3. D oes the 93 rd Amendment violate the Basic Structure of the Constitution by imposing
reservation on unaided institutions?
132. Imposing reservation on unaided institutions violates the basic structure by obliterating
citizens' 19(1)(g) right to carry on an occupation. Unaided entities, whether they are educational
institutions or private corporations, cannot be regulated out of existence when they are providing a
public service like education. That is what reservation would do.
That is an unreasonable restriction. When you do not take a single paisa of public money, you
cannot be subjected to such restriction. The 93rd Amendment's reference to unaided institutions
must be severed.
133. No unaided institution filed a writ petition in this case.
Had either this Court or respondents had an objection, they could have raised it at any time during
the proceedings. We listened to the parties for months. We received voluminous written
submissions from the parties, yet no objection was made with regard to the fact that no unaided
institution had filed a writ petition. While we would usually implead a party if we felt their presence
was necessary to the resolution of the dispute, the facts of this case are peculiar. The best lawyers in
the country argued the case for both sides, and a brief from an unaided institution would not have
added much if anything to the substance of the arguments. The Government will likely target
unaided institutions in the future. At that time, this Court will have to go through this entire exercise
de novo to determine if unaided institutions should be subject to reservation. Such an exercise
would unnecessarily cause further delay. The fate of lakhs of students and thousands of institutions
would remain up in the air. (See: Minerva Mills Ltd. & Others v. Union of India & Others (1980) 3
SCC
625). Therefore, looking to the extraordinary facts, I have decided to proceed with this aspect of the
matter in the larger public interest.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

134. Amendments by their very nature are often enabling provisions. If they clear the way for future
legislation that would in fact violate the basic structure, the Court need not wait for a potential
violation to become an actual one. It can strike the entire amendment ab initio. The question of
potential width was resolved in Minerva Mills (supra), paras 38-39. The Court acknowledged that it
generally does not anticipate constitutional issues before they arise, but it held that circumstances
required it to act before unconstitutional provisions could be passed under the authority of an
unconstitutional amendment.
"38. But, we find it difficult to uphold the preliminary objection because, the question
raised by the petitioners as regards constitutionality of Sections 4 and 55 of the 42nd
Amendment is not an academic or a hypothetical question. Th e 42 nd Amendment is
there for anyone to see and by its Sections 4 and 55 amendments have been made to
Articles 31-C and 368 of the Constitution. An order has been passed against the
petitioners under Section 18-A of the Industries (Development and Regulation) Act,
1951, by which the petitioners are aggrieved."
"39. Besides there are two other relevant considerations which must be taken into
account while dealing with the preliminary objection. There is no constitutional or
statutory inhibition against the decision of questions before they actually arise for
consideration. In view of the importance of the question raised and in view of the fact
that the question has been raised in many a petition, it is expedient in the interest of
justice to settle the true position. Secondly, what we are dealing with is not an
ordinary law which may or may not be passed so that it could be said that our
jurisdiction is being invoked on the hypothetical consideration that a law may be
passed in future which will injure the rights of the petitioners. We are dealing with a
constitutional amendment which has been brought into operation which, of its own
force, permits the violation of certain freedoms through laws passed for certain
purposes. We, therefore, overrule the preliminary objection and proceed to
determine the point raised by the petitioners."
[emphasis added] There is not one precise definition of the width test, however.
The test asks if an amendment is so wide that in effect (actual or potential), it goes beyond the
Parliament's amending power.
Kesavananda, paras 531-532: "But that the real consequences can be taken into account while
judging the width of the power is settled. The Court cannot ignore the consequences to which a
particular construction can lead ..."
To make such a determination, it follows that the Court should ask whether an amendment infringes
constitutional limitations as opposed to those evolved from mere common law. (See: Nagaraj, para
103).Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

135. As a preliminary matter, I turn to the cases by which the basic structure doctrine has been
established. It has been stated that, "Kesavananda had propounded the doctrine, the Indira Gandhi
Election case had upheld it, and Minerva engraved it on stone." (See: Granville Austin, "Working a
Democratic Constitution", at page 506].
136. Kesavananda and its progeny provide that an amendment to the Constitution must not alter the
Constitution's basic structure. To reach a conclusion regarding a basic structure challenge, I employ
the following general standard: an amendment alters the basic structure if its actual or potential
effect would be to damage a facet of the basic structure to such an extent that the facet's original
identity is compromised.
137. To determine if legislation infringes constitutional limitations and is thus invalid, we use the
two-step effect test (also known as the impact or rights test). Step One requires us to first ask if
legislation affects a facet of the basic structure.
If it does, then at Step Two we ask if the effect on the facet of the structure is to such an extent that
the facet's original identity has been altered. Applying the effect test is another way of saying that
the form of an amendment is irrelevant; it is the consequence thereof that matters. (See: Kesavanda
at para 532 and I.R. Coelho v. State of Tamilnadu (2007) 2 SCC 1 at Conclusion (ii) at page 111).
138. The terms "abridge" and "abrogate" have been employed by this Court to distinguish between
acceptable and unacceptable legislation. Whether legislation abridges or abrogates is a question of
degree. Using these terms is another way of asking whether the legislation had such an effect that it
changed the basic structure of the Constitution.
If legislation merely abridges the basic structure, the structure's identity remains. The legislation is
upheld. In this sense, the Parliament may take away or destroy fundamental rights by amending the
Constitution, provided that the basic structure is not altered.
139. If it abrogates the basic structure, the structure and thus the Constitution lose their identities.
The legislation must be struck down. This is determined on a case-by-case basis by applying the
effect test (impact/rights tests). (See: Coehlo). I further note that a total deprivation of fundamental
rights, even in one limited area, may amount to an abrogation of the basic structure. (See: Minerva
Mills, para 59).
7 Step One: Does Article 15(5) affect a facet of the basic structure?
140. In the instant case, Article 15(5) expressly precludes the application of Article 19(1)(g).
Whenever reservations are implemented under Article 15(5), citizens are stripped of their
fundamental rights under Article 19(1)(g). By excluding Article 19(1)(g), Article 15(5) obviously
affects Article 19(1)(g), a facet of the basic structure of the Constitution. Step One is therefore
cleared. What is more, Article 19(1)(g) belongs to the Golden Triangle - Articles 14, 19 and 21 are the
three fundamental rights that stand above the rest. Writing for the majority in Minerva Mills,
Justice Chandrachud provides an eloquent justification for shielding the Golden Triangle fromAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

attack. To achieve a more egalitarian society, individual liberty must be protected:
"Para 74 of Minerva Mills: Three Articles of our Constitution, and only three, stand
between the heaven of freedom into which Tagore wanted his country to awake and
the abyss of unrestrained power. They are Articles 14, 19 and 21. Article 31C has
removed two sides of that golden triangle which affords to the people of this country
an assurance that the promise held forth by the Preamble will be performed by
ushering an egalitarian era through the discipline of fundamental rights, that is,
without emasculation of the rights to liberty and equality which alone can help
preserve the dignity of the individual."
141. The Golden Triangle's significance becomes clear when we consider that Government may
suspend Article 14 and 19 rights in order to implement an emergency. (See: Articles 358 and 359)
(prior to the 44th Amendment, all Part III rights could be curtailed during emergency; this
Amendment precludes the State from denying Articles 20 and 21 to citizens during emergency). In a
sense, democracy is only restored when the Triangle is returned to the citizens. Without the
Triangle, democracy is impossible:
"para 63... Every State is goal-oriented and claims to strive for securing the welfare of
its people. The distinction between the different forms of Government consists in that
a real democracy will endeavour to achieve its objectives through the discipline of
fundamental freedoms like those conferred by Articles 14 and 19. Those are the most
elementary freedoms without which a free democracy is impossible and which must
therefore be preserved at all costs. Besides, as observed by Brandies, J., the need to
protect liberty is the greatest when Government's purposes are beneficent. If the
discipline of Article 14 is withdrawn and if immunity from the operation of that
article is conferred, not only on laws passed by the Parliament but on laws passed by
the State Legislatures also, the political pressures exercised by numerically large
groups can tear the country asunder by leaving it to the legislature to pick and choose
favoured areas and favourite classes for preferential treatment."
142. United States Supreme Court Justice Brandeis' word of caution is relevant to today's dispute
wherein the Government trumpets reservation in higher education as an answer to our age-old
problems of poverty and caste. At first blush, it sounds as if reservation in higher education would
help the backward help themselves. The road out of poverty is paved with education. However, the
"devil is the details." With elementary freedom on the line, I must carefully scrutinize those details.
143. The right to freedom under Article 19 has been long recognized as a natural and inalienable
right that belongs to all citizens. Indeed, what would Independence mean without it? Chief Justice
Sikri cites the following passage in Kesavananda at para 300:
"That article (Article 19) enumerates certain freedoms under the caption "right to
freedom" and deals with those great and basic rights which are recognised and
guaranteed as the natural rights inherent in the status of a citizen of a free country."Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(Per Patanjali Sastri, C.J., in State of West Bengal v. Subodh Gopal Bose [1954] S.C.R.
587, 596)."
144. With fundamental rights in jeopardy, I shall review the cases in which the basic structure
doctrine has been implemented to invalidate constitutional amendments. By looking at these cases
synoptically, we get a sense as to how much damage the basic structure can withstand before
crumbling. In Kesavananda, the second part of Article 31C precluded courts from reviewing whether
a law under Article 39(b) or (c) promoted the policy for which it was enacted. This violated the basic
structure. Article 31C was introduced by the 25th Amendment.
145. In Indira Nehru Gandhi v. Raj Narain & Another (1975) Supp SCC 1, the Court struck Article
329A(4) as violative of the basic structure. This provision appropriated the Court's power to
adjudicate election laws, encroaching on the judiciary in violation of separation of powers. See
Justice Matthew's opinion at para 325. It was introduced by the 39th Amendment. In Minerva Mills,
the Court held sections 4 and 55 of the 42nd Amendment in violation of the basic structure.
Section 4 sought to expand 31C such that all laws giving effect to Directive Principles, not just those
intended to promote Article 39(b) or (c), would be immune to an Article 14 or 19 challenge. Section
55 would have barred judicial review of constitutional amendments.
146. In P. Sambamurthy v. State of A.P. (1987) 1 SCC 362, the Court invalidated Article 371-D(5),
finding that the Parliament had violated the rule of law and consequently the basic structure, by
removing judicial review from the High Court and placing it in the hands of one of the parties - the
State Government. In L. Chandra Kumar v. Union of India (1997) 3 SCC 261, the Court held that
Articles 323A-2D and 323B-3D violated the basic structure in that they removed judicial review of
the High Courts and Supreme Court under Articles 226/227 and 32, respectively. These articles
were introduced by the 42nd Amendment to empower the Parliament or the State Legislatures to
establish Tribunals for various substantive areas of law: tax, labour, criminal, etc.
147. Two broad themes surface from these cases. When judicial review is barred, democracy
evaporates. And when Fundamental Rights are at stake, they must be harmonized with, not made
subject to, the Directive Principles. Sections 4 and 55 of the 42nd Amendment were especially
egregious violations of the basic structure. Had Section 4 been upheld, citizens' fundamental rights
would have been at the mercy of one organ of Government. "If Governments always could be
trusted, there would have been no need for Fundamental rights." Mr Palkhivala in oral arguments in
Kesavananda, quoting from the learned Mr H.M. Seervai, who was opposing counsel in that case. Mr
Palkhivala was reading from Seervai, H.M., "Fundamental Rights: A Basic Issue," published in three
installments in the Times of India, 14, 15, 16 February 1955.
(See: Granville Austin at pages 263-264 in "Working a Democratic Constitution")
148. Government cannot be trusted; that is precisely why we divide its powers into separate organs.
If it could be trusted, there would be no need for co-equal branches in which power is shared.
Separation of powers is an axiom of democracy.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

149. Had Section 55 of the 42nd Amendment been upheld, the basic structure of the Constitution
could have been destroyed by a single slash. Future constitutional amendments would not have been
reviewed. The impugned Amendment looks rather mild in comparison to the damage that would
have been wrought by the 42nd Amendment. The impugned legislation limits one fundamental right
in one limited circumstance. Yet an amendment need not be as invidious as the 42nd Amendment
for us to invalidate it. If the standard were that high, amendments could destroy the basic structure
or the essence of the Constitution by a thousand slashes.
150. Since Kesavananda's time, many amendments have been passed and many challenges under
the basic structure have been made. This Court has used caution and has refrained from using the
doctrine, even when it may have been justified. For example, there were grounds for striking the
entire 10th Schedule as violative of the basic structure in Kihoto Hollohan v Zachillhu & Others 1992
Supp (2) SCC
651. Rather than resort to the basic structure, this Court made a narrow ruling on procedural
grounds. (See: S.P. Sathe, Judicial Activism in India: Transgressing Borders and Enforcing Limits,
2nd Edn., 2002 (Oxford University Press) pages 92-93). The Court upheld the 10th Schedule, only
severing a paragraph from the same. I agree that an abundance of caution ought to be taken before
employing the basic structure doctrine. The violation must truly abrogate the basic structure.
Anything short of this standard must be upheld - the will of the people, through their elected
representatives, heard.
151. Before making such a determination, it is prudent to briefly revisit the rulings of two landmark
cases: P.A. Inamdar & Others v. State of Maharashtra & Others, (2005) 6 SCC 537; T.M.A. Pai
Foundation & Others v. State of Karnataka & Others (2002) 8 SCC 481. In Inamdar (supra), paras
26-27 (seven-Judge Bench), unaided (minority and non-minority) professional institutions filed
petitions to determine, inter alia, whether the State could impose quotas on unaided (minority and
non-minority) institutions. A seven-
Judge Bench was constituted such that Islamic Academy's clarification of Pai could be reviewed.
Islamic Academy was a five-Judge Bench. Given that Pai was an eleven-Judge Bench, Inamdar could
clarify but not overrule Pai.
152. At para 124, Inamdar held that the State cannot impose quotas on unaided (minority and
non-minority) institutions.
To do so would nationalize seats, contrary to Pai. (See:
Inamdar at para 125). In dictum, Pai suggested that the State could compel unaided institutions to
admit a reasonable percentage of students via reservation. (Pai, para 68).
Inamdar clarified this point, stating that Pai should be read to mean that the State and unaided
institutions may enter into consensual agreement regarding reservation. (See:Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Inamdar at para 126). Unaided institutions (minority and non-minority) can admit as they choose,
provided their process is fair, transparent, non-exploitative and merit-based.
Inamdar stated:
"124: So far as appropriation of quota by the State and enforcement of its reservation
policy is concerned, we do not see much of difference between non-minority and
minority unaided educational institutions. We find great force in the submission
made on behalf of the petitioners that the States have no power to insist on seat
sharing in the unaided private professional educational institutions by fixing a quota
of seats between the management and the State. The State cannot insist on private
educational institutions which receive no aid from the State to implement State's
policy on reservation for granting admission on lesser percentage of marks, i.e. on
any criterion except merit.
125. As per our understanding, neither in the judgment of Pai Foundation nor in the
Constitution Bench decision in Kerala Education Bill, which was approved by Pai
Foundation, there is anything which would allow the State to regulate or control
admissions in the unaided professional educational institutions so as to compel them
to give up a share of the available seats to the candidates chosen by the State, as if it
was filling the seats available to be filled up at its discretion in such private
institutions. This would amount to nationalization of seats which has been
specifically disapproved in Pai Foundation. Such imposition of quota of State seats or
enforcing reservation policy of the State on available seats in unaided professional
institutions are acts constituting serious encroachment on the right and autonomy of
private professional educational institutions.
Such appropriation of seats can also not be held to be a regulatory measure in the
interest of minority within the m eaning of Article 3 0(1) or a reasonable restriction
within t he meaning of Article 1 9(6) of the Constitution . Merely because the
resources of the State in providing professional education are limited, private
educational institutions, which intend to provide better professional education,
cannot be forced by the State to make admissions available on the basis of reservation
policy to less meritorious candidate. Unaided institutions, as they are not deriving
any aid from State funds, can have their own admissions if fair, transparent,
non-exploitative and based on merit."
To the extent that Islamic Academy had approved of quotas in unaided institutions, a scheme in
which the States could fix quota for seat sharing between management and the State, Islamic was
overruled. [Inamdar at para 130]
153. In T.M.A. Pai Foundation (supra) para 2 (eleven- Judge Bench), private educational
institutions, aided and unaided, filed writ petitions to challenge regulations that impeded their
rights. They wanted to establish and administer educational institutions, unfettered by GovernmentAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

interference. [para 2].
Reading Article 29(2) and 30(1) harmoniously, the six-Justice majority held that (1) unaided
institutions could admit students free of Government interference, as long as their admission
process was transparent and merit-based; (2) minority aided institutions may still admit their own
students, contingent upon admitting a reasonable number of non-
minority students per the percentage provided by the State Government.
154. For our purposes, it is important to note that education falls within the meaning of
"occupation" under 19(1)(g). This is so because a large number of persons are employed as teachers
and administrative staff. For them, education is an occupation. Pai stated:
"20: "Article 19(1)(g) employs four expressions, viz., profession, occupation, trade
and business. Their fields may overlap, but each of them does have a content of its
own. Education is per se regarded as an activity that is charitable in nature [See The
State of Bombay v. R.M.D. Chamarbaugwala, ... Education has so far not been
regarded as a trade or business where profit is the motive. Even if there is any doubt
about whether education is a profession or not, it does appear that education will fall
within the meaning of the expression "occupation".
A rticle 1 9(1)(g) uses the four expressions so as to cover all activities of a citizen in respect of which
income or profit is generated, and which can consequently be regulated under A rticle 1 9(6) .
25 The establishment and running of an educational institution where a large number of persons are
employed as teachers or administrative staff, and an activity is carried on that results in the
imparting of knowledge to the students, must necessarily be regarded as an occupation, even if there
is no element of profit generation. It is difficult to comprehended that education, per se, will not fall
under any of the four expressions in Article 19(1)(g). "Occupation" would be an activity of a person
undertaken as a means of livelihood or a mission in life. ..."
[emphasis added]
155. Stripping private unaided institutions of their right to select students would be unreasonable:
"para 40: Any system of student selection would be unreasonable if it deprives the
private unaided institution of the right of rational selection, which it devised for itself,
subject to the minimum qualification that may be prescribed and to some system of
computing the equivalence between different kinds of qualifications, like a common
entrance test. Such a system of selection can involve both written and oral tests for
selection, based on principle of fairness."
156. Like Article 15(5) in the instant case, Unni Krishnan effectively nationalized education. Pai
overturned Unni Krishnan. (See: para 45).Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"38:    Th
             e   scheme   in   U
                                nni   Krishnan's    case   has   the   effect   of  
nationalizing education in respect of important features, viz., the right of a private unaided
institution to give admission and to fix the fee. By framing this scheme, which has led to the State
Governments legislating in conformity with the scheme the private institutions are
undistinguishable from the Government institutions; curtailing all the essential features of the right
of administration of a private unaided educational institution can neither be called fair or
reasonable."
157. Pai traces the autonomy of institutions back to Chitralekha and Rajendran. The proposition is
simple: he who funds or runs the institution holds the power to select students. The State cannot ask
these institutions to abridge this right in exchange for affiliation/recognition. The relevant
paragraphs are reproduced hereunder:
"36: The private unaided educational institutions impart education, and that cannot
be the reason to take away their choice in matters, inter alia, of selection of students
and fixation of fees. Affiliation and recognition has to be available to every institution
that fulfills the conditions for grant of such affiliation and recognition. The private
institutions are right in submitting that it is not open to the Court to insist that
statutory authorities should impose the terms of the scheme as a condition for grant
of affiliation or recognition; this completely destroys the institutional autonomy and
the very objective of establishment of the institution.
42. In R. Chitralekha and Anr. v. State of Mysore and Ors. [citation omitted], while
considering the validity of a viva-voce test for admission to a Government medical
college, it was observed at page 380 that colleges run by the Government, having
regard to financial commitments and other relevant considerations, would only
admit a specific number of students. It had devised a method for screening the
applicants for admission. While upholding the order so issued, it was observed that
"once it is conceded, and it is not disputed before us, that the State Government can
run medical and engineering colleges, it cannot be denied the power to admit such
qualified students as pass the reasonable tests laid down by it. This is a power which
every private owner of a College will have, and the Government which runs its own
Colleges cannot be denied that power." (italics added by Pai; underscore is mine).
43. Again, in Minor P. Rajendran v. State of Madras and Ors ... , it was observed at
page 795 that "so far as admission is concerned, it has to be made by those who are in
control of the Colleges, and in this case the Government, because the medical colleges
are Government colleges affiliated to the University. In these circumstances, the
Government was entitled to frame rules for admission to medical colleges controlled
by it subject to the rules of the university as to eligibility and qualifications. "Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

The aforesaid observations clearly underscore the right of the colleges to frame rules for admission
and to admit students.
The only requirement or control is that the rules for admission must be subject to the rules of the
university as to eligibility and qualifications. The Court did not say that the university could provide
the manner in which the students were to be selected.
61. In the case of unaided private schools, maximum autonomy has to be with the management with
regard to administration, including the right of appointment, disciplinary powers, admission of
students and the fees to be charged."
158. Unaided institutions may admit students of their choice, subject to an objective and rational
procedure of selection.
They might admit a small percentage of students belonging to the weaker sections of the society by
granting those sections freeships or scholarships, if not granted by the Government.
[See: Pai at para 53]. Given a transparent and reasonable selection process, it is up to the institution
to define "merit"
according to its own values. Pai stated:
"65. The reputation of an educational institution is established by the quality of its
faculty and students, and the educational and other facilities that the colleges has to
offer. The private educational institutions have a personality of their own, and in
order to maintain their atmosphere and traditions, it is but necessary that they must
have the right to choose and select the students who can be admitted to their courses
of studies. If is for this reason that in the St. Stephen's College case, this Court upheld
the scheme whereby a cut-off percentage was fixed for admission, after which the
students were interviewed and thereafter selected. While an educational institution
cannot grant admission on its whims and fancies, and must follow some identifiable
or reasonable methodology of admitting the students, any scheme, rule or regulation
that does not give the institution the right to reject candidates who might otherwise
be qualified according to say their performance in an entrance test, would be an
unreasonable restriction under Article 19(6), though appropriate
guidelines/modalities can be prescribed for holding the entrance test a fair manner.
Even when students are required to be selected on the basis of merit, the ultimate
decision to grant admission to the students who have otherwise qualified for the
grant of admission must be left with the educational institution concerned. However,
when the institution rejects such students, such rejection must not be whimsical or
for extraneous reasons."
159. The Court distinguishes between reasonable and unreasonable regulations by asking which
functions lie at the heart of an institution's autonomy. Regulations that strike at the core ofAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

autonomy are unreasonable. For example, prescribing minimum qualifications for teachers is a
reasonable regulation; actually selecting the teachers is not.
"55. But the essence of a private educational institution is the autonomy that the
institution must have in its management and administration. There, necessarily, has
to be a difference in the administration of private unaided institutions and the
Government-aided institutions. Whereas in the latter case, the Government will have
greater say in the administration, including admissions and fixing of fees, in the case
of private unaided institutions, maximum autonomy in the day-to-day administration
has to be with the private unaided institutions. Bureaucratic or Governmental
interference in the administration of such an institution will undermine its
independence. While an educational institution is not a business, in order to examine
the degree of independence that can be given to a recognized educational institution,
like any private entity that does not seek aid or assistance from the Government, and
that exists by virtue of the funds generated by it, including its loans or borrowings, it
is important to note that the essential ingredients of the management of the private
institution include the recruiting students and staff, and the quantum of fee that is to
be charged."
160. The same argument was framed in similar terms in St. Stephen's College v. University of Delhi,
1992 (1) SCC 558.
In that case, the Court distinguished regulations based on whether they directly or indirectly
affected management.
Those that indirectly affected management were reasonable;
those that directly affected the management of the institution were not. [Pai at para 125].
161. In St. Stephen's, this Court referred to the earlier decisions, and with regard to Article 30(1)
observed at page 596, paragraph 54, as follows:
"... But the standards of education are not a part of the management as such. The
standard concerns the body politic and is governed by considerations of the
advancement of the country and its people. Such regulations do not bear directly
upon management although they may indirectly affect it. The State, therefore has the
right to regulate the standard of education and allied matters."
162. Once a private institution (non-minority) takes aid, it is subject to (1) reservation and (2)
regulation of administration and maintenance of the institution. Pai stated:
"71: "While giving aid to professional institutions, it would be permissible for the
authority giving aid to prescribe by rules or regulations, the conditions on the basis of
which admission will be granted to different aided colleges by virtue of merit, coupledAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

with the reservation policy of the state. ... 72: "Once aid is granted to a private
professional educational institution, the Government or the state agency, as a
condition of the grant of aid, can put fetters on the freedom in the matter of
administration and management of the institution. The state, which gives aid to an
educational institution, can impose such conditions as are necessary for the proper
maintenance of the high standards of education as the financial burden is shared by
the state. ..."
163. I now query if the Parliament may subject Article 19(1)(g) to Article 15(5), when this Court has
held that reservation in unaided institutions is an unreasonable restriction that cannot be saved by
Article 19(6).
164. I answer this question in the affirmative. The structure of our Constitution permits
fundamental rights, and even the Golden Triangle of Articles 14, 19 and 21, to be abridged in limited
circumstances. To say that subjecting Articles 19(1)(g) to 15(5) violates the basic structure per se is
to ignore the examples in which the most fundamental of rights is limited.
Article 16(4) expressly limits the right to formal equality in 16(1), a specific facet of Article 14. In this
light, Article 16(4) impliedly limits the general right to formal equality in Article 14 .
The right to equality is expressed in the negative in 15(1): the State shall not discriminate based on
religion, race, caste, etc. In other words, the State shall treat citizens of different religions, races and
castes equally. Like Article 16(4), Article 15(4) limits 15(1) -- another facet of Article 14 formal
equality
-- such that egalitarian equality may be pursued. Generally speaking, Articles 15(3) and (4) and
16(4) allow the State to impose affirmative action programs on the public sector. Such provisions
necessarily limit the right to formal equality. If the right to equality, considered by some as a basic
postulate of the Constitution, has been limited, a fortiori Article 19(1)(g) can be too.
165. Along these lines, I could turn to Articles 31A, 31B and 31C for further support. Those Articles
exclude challenges under Articles 14 and 19. In agreement with Dr. Dhavan's submission, I decline
to rely on Articles 31A, 31B and 31C for support. As explained in Minerva Mills, the Court had
previously upheld Article 31A out of concern for stare decisis.
The Court never approved of the exclusion of Articles 14 and 19 on a principled basis. Nor did it
make a ruling as to whether the exclusion violated the basic structure. (See: para 71-72 of Minerva
Mills. See also para 43 of Waman Rao, (1981) 2 SCC 362).
166. A basic structure challenge becomes an issue of institutional competence. Is it for the
legislature to decide what is a reasonable restriction under 19(1)(g) read with 19(6)?
Or is it for the judiciary? It is well established that the Parliament, expressing the will of the people,
may enact amendments to overrule a judgment of this Court. The First Parliament added ArticleAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

15(4) to the Constitution to overrule State of Madras v. Champakam Dorairajan, AIR 1951 SC
226. Other examples include the 77th Amendment, which overruled Sawhney I by adding Article
16(4-A); the 81st Amendment further overruled Sawhney I by adding Art 16 (4-B); the 82nd
Amendment overruled S. Vinod Kumar & Another v. Union of India & Another (1996) 6 SCC 580 by
amending Article 335; and the 85th Amendment overruled Virpal Singh Chauhann and Ajit Singh I
by amending Article 16(4-A), (1995) 6 SCC 684 and (1996) 2 SCC 715, respectively. Nevertheless, the
duty to interpret the content of our fundamental rights has been left to the Courts. "The important
point to be noted is that the content of a right is defined by the Courts. The final word on the content
of the right is of this Court." (Nagaraj at para 21). (emphasis added).
While the Parliament may amend the Constitution, it cannot alter the Constitution's basic structure.
(See: Kesavananda, Indira Nehru Gandhi (Election Case), Minerva Mills, Sambamurthy, L. Chandra
Kumar and Coelho).
7 Step Two: Does Article 15(5) affect Article 19(1)(g) to such an extent that Article 19(1)(g)'s original
identity has been altered?
167. In other words, does Art 15(5) in effect merely abridge or completely abrogate Article 19(1)(g). If
the former, 15(5) stands. If the latter, it falls. As noted above, Coelho directs me to apply the
impact/rights test to determine whether the basic structure has been violated. [See Coehlo at
Conclusion
(ii) at page 111]. Thus, my query is whether to consider the impact on the entire constitutional
framework, or to examine the effect on citizens engaged in unaided education as an occupation. I
think it is the latter. I am not concerned here with those engaged in education in aided institutions.
One is naturally subject to greater regulation when one relies on Government funding. (See:
Pai/Inamdar). Individual liberty and freedom, as protected by the Golden Triangle, must carry
greater weight for those who set off on their own and refuse Government money.
168. This brings me to the question as to how large I should draw the circle when I ask who is
affected by reservation in unaided institutions. Justice Chandrachud provides that "[a] total
deprivation of fundamental rights, even in a limited area, can amount to abrogation of fundamental
right just as a partial deprivation in every area can." (See: Minerva Mills, para 59).
169. Freedom under Article 19 belongs to individual citizens.
Article 19(1)(g) provides that "all citizens shall have the right to practice any profession, or to carry
on any occupation, trade or business." The reference to "all citizens" means that each and every
individual citizen possesses Article 19 rights. For the impugned legislation to fall, it need not touch
every sphere of society. If even one individual's freedom has been curtailed, this Court is duty bound
to entertain his or her claim. It is he or she who possesses the Article 19(1)(g) right to carry on an
occupation.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

170. If 15(5) were implemented, the educator in unaided institutions would still have students to
educate. I use "educator" in the broadest sense of the term and include teachers, professors,
lecturers, faculty, staff, administrators and those who finance institutions. Without one of the
aforementioned, the institution cannot function properly.
171. Though affected by reservation, the educator still has a job. His occupation remains intact.
Students will come.
Classes will commence. Marks will be distributed. The greatest impact on the educator is that
neither he nor his institution will choose whom to teach.
172. Almost half of the time (49.5%), the State would decide for them. Selecting students or
employees goes to the heart of an organization's autonomy. The essence of an unaided educational
institution is the freedom to manage its affairs, according to Pai at paragraph 55. That is, "... the
essential ingredients of the management of the private institution include the recruiting [of]
students and staff ... ." The same argument was framed in similar terms (at para 54) in St. Stephen's
College (regulations imposing standards of education upheld, because they "... do not bear directly
upon management although they may indirectly affect it ..."). This Court has stated in Pai as clarified
by Inamdar that subjecting unaided institutions is an unreasonable restriction.
As noted, Article 19(6) provides no safe haven for reservations.
173. The Government-imposed selection of students in turn has wide-ranging consequences for
unaided institutions and their educators. I am required to examine the effect of the impugned
Amendment. At least four problems will likely arise:
(1)     academic standards suffer; 
(2)     attracting   and   retaining   good   faculty   becomes   more 
difficult; 
(3)     the incentive to establish a first rate unaided institution 
is diminished; 
(4)     and   ultimately   the   global   reputation   of   our   unaided 
institutions is severely compromised.  Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

174. First, once the State tells them whom to teach, standards of excellence will suffer. This is
because those institutions will no longer be able to admit the highest-scoring students. As good as
some of our institutions are, they do not teach blank slates. The best universities are the best, in
part, because they attract the best students. The same can be said for almost any organization. In the
case of higher education, the universities that admit the best will likely churn out the best.
The precise extent to which the university made the best so good cannot be qualified. The point is
that universities alone cannot produce qualified job candidates. Forced to admit students with lower
marks, the university's final product will not be as strong. Once the creamy is excluded, cut-off
marks would likely drop considerably in order to fill the 27% quota for non creamy layer OBCs.
When the creamy layer is not removed, as in the case of Tamil Nadu, the difference in cut off marks
for the general and backward categories may be insignificant. (See para 408 of Sawhney I). Of
course, the extent to which standards of excellence would suffer would vary by institution. As I
mention below, I urge the Government to set OBC cut off marks no lower than 10 marks below that
of the general category. This is only a recommendation, however. It may never be adopted.
175. Second, reservations weaken the incentive to establish unaided institutions: if the State usurps
the right to select students, would one still spend the time and money to establish an unaided
institution? The question is all the more relevant today. Counsel for petitioners posit that
tomorrow's knowledge economy requires a well-educated populace. "Well-
educated" does not imply a string of degrees from less than taxing institutions. Rather, it means that
one will possess the skills, knowledge and creativity to compete globally. Our unaided institutions
must remain places where these traits are refined.
176. Third, those inclined to teach the brightest students have even less of a reason to leave private
sector jobs for the teaching profession or to join the profession in the first place.
"Brightest" would come with an asterisk. They would be the brightest available under
the Government's reservation scheme. These potential teachers may ask themselves:
how will I teach a class in which half the students are advanced relative to the other
half? In many institutions, the shortage of top-rate faculty will only get worse.
Fourth, reservations may have a negative impact on students seeking employment in
the burgeoning knowledge economy. Recruiters have begun to trickle into campuses.
They hail from domestic as well as international entities, and they too may take note
of reservations in unaided institutions. The effect on educators, from the top down,
would be felt. For them, little more than a semblance of occupation would remain.
177. Given the dramatic effect that reservations would have on educators, the unaided institutions in
which they teach and, consequently, society as a whole, Article 19(1)(g) has been more than
abridged. When education is effectively nationalized, freedom stands obliterated. The identity of the
Constitution is altered when unreasonable restrictions make a fundamental right meaningless. TheAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

93rd Amendment's imposition of reservation on unaided institutions has abrogated Article 19(1)(g),
a basic feature of the Constitution, in violation of our Constitution's basic structure. Therefore, I
sever the 93rd Amendment's reference to "unaided" institutions as ultra vires of the Constitution.
178. The case law on severability asks the following question:
had the Parliament known its provision would be severed would it still have passed
the rest of the legislation? (See: R.M.D. Chamarbaugwalla (supra)).
179. At page 943 of R.M.D. Chamarbaugwalla (supra), the Court relied in part on The State of
Bombay & Another v.
F.N. Balsara (1951) SCR 682, where the question at issue was whether the Bombay Prohibition Act
was valid:
Sections 12 and 13 of the Act imposed restrictions on the possession, consumption
and sale of liquor, which had been defined in s. 2(24) of the Act as including "(a)
spirits of wine, methylated spirits, wine, beer, toddy and all liquids consisting of or
containing alcohol, and (b) any other intoxicating substance which the Provincial
Government may, by notification in the Official Gazette, declare to be liquor for the
purposes of this Act". Certain medicinal and toilet preparations had been declared
liquor by notification issued by the Government under s. 2(24)(b). The Act was
attacked in its entirety as violative of the rights protected by Art. 19(1)(f). But this
Court held that the impugned provisions were unreasonable and therefore void in so
far as medicinal and toilet preparations were concerned, but valid as to the rest.
Then, the contention was raised that "as the law purports to authorise the imposition
of a restriction on a fundamental right in language wide enough to cover restrictions
both within and without the limits of constitutionally permissible legislative action
affecting such right, it is not possible to uphold it even so far as it may be applied
within the constitutional limits, as it is not severable". In rejecting this contention,
the Court observed:
`These items being thus treated separately by the legislature itself and being
severable, and it is not being contended, in view of the directive principles of State
policy regarding prohibition, that the restrictions imposed upon the right to possess
or sell or buy or consume or use those categories of properties are unreasonable, the
impugned sections must be held valid so far as these categories are concerned.' This
decision is clear authority that the principle of severability is applicable even when
Act's invalidity arises by reason of its contravention of constitutional limitations."
180. At page 944, the court in R.M.D. Chamarbaugwalla sought guidance from American case law
on severability:Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"In discussing the effect of a severability clause, Brandies, J. observed in Dorchy v.
State of Kansas (1924) 264 US 286 that it "provides a rule of construction, which may
sometimes aid in determining that intent. But it is an aid merely; not an inexorable
command". The weight to be attached to a classification of subjects made in the
statute itself cannot, in our opinion, be greater than that of a severability clause."
181. The court in R.M.D Chambarbaugwalla went on to cite Patanjali Sastri, C.J., in The State of
Bombay & Another v.
The United Motors (India) Ltd. & Others (1953) SCR 1069:
"dealing with the contention that a law authorizing the imposition of a tax on sales
must be declared to be wholly void because it was bad in part as transgressing
constitutional limits observed:
`It is a sound rule to extend severability to include separability in enforcement in
such cases, and we are of opinion that the principle should be applied in dealing with
taxing statutes in this country.'"
182. Here, I believe the Parliament would have gone forward without unaided institutions. While
some Members of Parliament sought to overrule Pai and Inamdar, the Parliament's actions speak
louder than its words. Once it had passed Article 15(5), it limited itself to imposing greater
reservations on aided institutions. Had unaided institutions been the Parliament's priority, it could
have included them in the Reservation Act. It seems that the Parliament's intent is to pass as much
reservation as possible. That would explain why it has gone forward with 27% reservation for OBCs
without confirming that at least 27% of the population is OBC. For these reasons, I conclude that
had the Parliament known that unaided institutions were going to be severed, it would have
nevertheless carried out its reservation scheme for aided institutions.
1. Th e Casteless and Classless Society versus Caste-based Reservation:
183. The caste system is peculiar to this country. Perhaps the entire society has been
divided on the basis of caste. This social problem can be compared to some extent
with that of American society. In the U.S., the problem of racial discrimination has
existed for centuries. The cases of affirmative action decided in the United States are
relevant.
They show us how that society has dealt with the problem of racial discrimination. At the outset, I
would like to make it clear that decisions of foreign countries are not binding on Indian courts.
Indian Courts have not adopted American standards of review. But the judgments delivered by U.S.
courts on affirmative action have great persuasive value and they may provide broad guidelines as to
how we should tackle our prevailing condition. A large number of English laws have been inherited
by India and America. English and American cases are frequently cited by our courts. We need to
keep our window open and permit the light of knowledge to enter from any source. In this light, IAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

shall refer to some US decisions.
7 Affirmative Action cases and standards of review from the United States:
184. In 1978, Regents of the University of California v.
Bakke put an end to reservation ("quotas") in education (reserving 16 out of 100 seats for minorities
in medical school deemed unconstitutional). (438 U.S. 265). Justice Powell's concurring judgment is
considered the key opinion in the case.
185. Justice Powell concluded that diversity was a compelling State interest that could withstand
strict scrutiny. Relying on Bakke, the court later reaffirmed preferential treatment in college
admissions as a means to ensure diversity in the classroom - racial diversity being just one among
many types of diversity ("overcoming personal adversity and family hardship" was another form of
diversity), (See: Grutter v.
Bollinger, 539 U. S. 306, 338 (2003)). The Grutter Case insisted that universities make an
individualized evaluation of a student seeking admission, rather than one that mechanically
accepted or rejected students on the basis of race. (Grutter at 337). Such an evaluation would ensure
that race was only considered as one type of diversity, rather than a pretext for achieving racial
balance. Quotas could not be covertly installed in the name of diversity. This reasoning led the court
to strike down an admission scheme that automatically assigned more points to minority students
than to residents of the State or to athletes, for example. (Gratz v.
Bollinger, 539 U.S. 244, 270).
186. Justice O'Conner for the majority in Grutter came to a very significant conclusion. She
suggested that there was time limit on preferential treatment for certain races as a means of
promoting diversity. Justice O'Connor stated: "we expect that 25 years from now, the use of racial
preferences will no longer be necessary to further the interest approved today."
187. In Parents Involved in Community Schools v. Seattle School District No.1 et al, reported in 168
Lawyers Ed. 2d 508 & 517 (2007), school districts used a student's race to assign that student to a
particular school within the district.
In Seattle, this was done to achieve racial balance amongst the district's schools. One school should
not be overwhelmingly white, another all non-white. Unlike the system approved in Grutter, race
was not just one among many types of diversity that was considered by the district in assigning
students.
Seattle at 525. Instead, it was, at times, the decisive factor.
The court held the programmes unconstitutional. Chief Justice Roberts summed up the plurality's
view on racial classifications: "the way to stop discrimination on the basis of race is to stopAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

discriminating on the basis of race."
188. This was far from a complete victory for the plurality. In his concurring opinion, Justice
Kennedy found the programmes unconstitutional. However, he would not go so far as to treat all
racial balancing as per se unconstitutional.
He considered the plurality opinion to represent "... an all-too-
unyielding insistence that race cannot be a factor in instances, when, in [his] view, it may be taken
into account." (Seattle at
565).
189. Justice Kennedy found that schools have a compelling interest to prevent racial isolation or
achieve a diverse student population. (Seattle at 572). Like Justice Powell's concurring opinion in
Bakke, Justice Kennedy's concurring opinion leaves the door open for further use of racial
classification for so-called benign purposes in school admissions.
190. More important than any one case are the standards by which the court scrutinized
discriminatory legislation. Of course, Indian courts have not accepted the principles of narrow
tailoring and strict scrutiny. Nevertheless, we should seek guidance from any corner and permit the
light from any quarter.
191. Whenever legislation is challenged as unconstitutional, courts must ask themselves how much
deference they will give to the legislature. The answer is that it depends on the nature of the
impugned legislation. The United States Supreme Court has evolved three standards of review for
Government action that treats different people differently. The first is the rational basis standard.
When the classification is rationally related to any legitimate Government purpose, the court defers
to the State and upholds the classification. This is the most deferential of the three standards. The
second standard is intermediate scrutiny, which is less deferential to Government.
Here, the court asks whether the classification is substantially related to any important Government
purpose. The third and highest level of review is known as strict scrutiny, whereby the court requires
that the classification are narrowly tailored to a compelling state interest. Strict scrutiny test is the
least deferential to Government.
192. Of the classifications on which there is case law, the one that most closely resembles caste is
race. This is because both are immutable traits. They are used by the powerful, or those seeking
power, to justify oppression. Racism and casteism have long haunted both Nations. In the United
States, race raises red flags. It is often, though not always, reviewed under strict scrutiny:
"Government action dividing people by race is inherently suspect because such classifications
promote `notions of racial inferiority and lead to a politics of racial hostility,' (Croson at 102 L. Ed.
2d 854) and "racial classifications are simply too pernicious to permit any but the most exact
connection between the justification and the classification." (Gratz v. Bollinger, 539 U.S. 244, 270Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(quoting J. Stevens' dissent in Fullilove v. Klutznick, 448 U.S. 448, 537)).
193. Legislation whose text does not classify based on race is considered facially neutral. When
facially neutral legislation has a disproportionate impact on a particular race, American courts ask
whether it was passed with an intention to discriminate. If no intention is found, the rational basis
test applies. [See: Hernandez v New York, 500 U.S. 352 (1991) (quoting from Arlington Heights v.
Metropolitan Housing Development Corp., 429 U.S. 252, 264-265 (1977)]:
"A court addressing this issue must keep in mind the fundamental principle that
"official action will not be held unconstitutional solely because it results in a racially
disproportionate impact. . . . Proof of racially discriminatory intent or purpose is
required to show a violation of the Equal Protection Clause."
See also Washington v. Davis, 426 U.S. 229, 239 (1976). The exception to this rule is Yick Wo v.
Hopkins, 118 U.S. 356 (1886), where extreme disproportionate impact warranted greater scrutiny.
Where there is disproportionate impact and discriminatory intention, then even facially neutral
legislation triggers strict scrutiny. However, in this framework, affirmative action classifies on the
face of legislation and automatically gets strict scrutiny treatment.
194. As I have observed, American courts carefully review racial classifications. Given that the 93rd
Amendment on its face discriminates against general category students, we should give it careful
scrutiny. The Article 14 right to formal equality deserves as much. If 49.5% caste-based reservation
was upheld in Sawhney I for Government employment, it follows that 49.5% caste-based reservation
is permitted in aided educational institutions. While I compelled by Sawhney I to hold that the
impugned legislation passes careful scrutiny with respect to reservation in aided institutions, its
implementation is contingent upon the directions given in this opinion.
7 The Framers' ultimate goal: the Classless and Casteless society:
195. Did the original Framers intend to provide caste-based reservation in education
to the lower classes? No, the original Framers did not. Soon after the Constitution
was adopted, the very same Framers acted quickly to permit reservation for
SC/ST/SEBCs in education by adding Art 15(4), vide the First Amendment, to the
Constitution. In doing so, they deviated from their own goal - the casteless society
would have to wait.
In Sawhney I, the Court upheld this decision and bound us to a certain degree on this point. I have
no choice but to uphold the impugned legislation by which the Government may still identify SEBCs,
in part, by using caste.
196. Caste-based reservation was initially a temporary measure that was to only last for ten years.
The original Framers considered caste-based reservation a necessary evil.
Thus, they limited it in time. Extending this time limit has only exacerbated casteism.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

197. The Parliamentary Debates clearly reflect that the ultimate aim of reservation was a casteless
and classless society for India. To this end, reservation should only be given for a specific period of
time. If these reservations or benefits have to continue perpetually, then the basic goal of achieving
casteless and classless society would never be accomplished.
198. The need for caste-based reservation has "worn out" over time. Evidence for the proposition
that caste is no longer a valid determinant of one's ability to move up in society is strong. More than
the way society judges you based on caste, the relevant question is whether caste precludes you from
rising. If caste doesn't, then what does? The answer is simple: money.
199. Income is a much better determinant of educational achievement than caste. The table below
was derived from the Reproductive Child and Health Survey, 2002-2004 (600,000 households
surveyed).
Average years of schooling:
                              SC       OBC           Upper caste Hindu
Poorest Rural Quintile     1.6         1.7         2.2  
Richest Rural Quintile     5.1         5.5         6.1  
For   the   upper   caste,   caste   barely   helps.     These   numbers 
indicate that it is one's income, not caste, that makes a real difference in determining how much
schooling one completes.
Therefore, if income be the bar to education, economic criteria should be the means by which we
identify beneficiaries of special provisions under Article 15(5).
7 No original intent to provide caste-based quotas in education:
200. As drafters, the original Framers were prolific. They made our Constitution the
world's longest - removing as many doubts as possible and in that way limiting the
Court's role.
The Constitution contains a number of Articles that reserve seats for various groups. The original
Framers, however, imposed various limitations on reservation. These limitations provide insight
into the original Framers' compromise between formal and substantial/egalitarian equality.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

201. Reservation is only provided for certain groups (SC, ST and backward classes) in certain areas
of the public sector.
(See: Article 16(4) (reservation of posts in Government service for backward classes), Article 330
(reservation of seats for SC and ST in the Lok Sabha) and Article 332 (reservation of seats for SC and
ST in Legislative Assemblies of the States)).
202. Dr Ambedkar stated that "the report of the Minorities Committee provided that all minorities
should have two benefits or privileges, namely representation in the legislatures and representation
in the services." (emphasis added) (See:
CAD, 26 August 1949, vol. 9, p. 702). Given this limitation, we must take extra caution when
reviewing the constitutionality of adding additional benefits.
203. Article 334 fixed a 10-year time limit on the legislative reservations provided in Articles 330
and 332. In the discussion regarding draft Article 292, Sardar Hukam Singh said, "we are accepting
this reservation of seats [in legislative bodies] as an unavoidable evil for the present, thought it is
only for the Scheduled Castes and scheduled tribes." ( See: p.
645, Constituent Assembly Debates, Vol. 9, 24 August 1949).
204. Shri Singh's comment sums up the limitations on legislative reservation. OBC/SEBCs were
excluded, and reservations were limited in time. Unlike the legislative reservations, Article 16(4)
contains no fixed time limit. It does, however, preclude the State from making reservations in
Government service if the backward classes are adequately represented. The idea is that, at some
point in time, the backward classes would no longer need reservations.
205. In discussing draft Article 10 (Article 16(4) of the Constitution), Pandit Hirday Nath Kunzru
stated:
"We are all aware that when the Report of the Minorities Committee was considered
by the House, the entire House was anxious that reservations of whatever kind
should be done away with as quickly as possible. ... whatever protection might be
considered necessary now, should be granted temporarily only, so that the population
of the county might become fully integrated, and no community or class might be
tempted to claim special advantage for itself." (CAD Vol.7 dated 30th November
1948, p. 681)"
(emphasis supplied) Instead of moving to remove reservations, the Parliament has gone the other
way by extending time limits and adding beneficiaries. Article 15(5) is just the latest example.
206. While the original Framers went out of their way to put SC/ST in the Parliament and State
Assemblies and SC/ST/backward classes in Government service, they did not reserve a single
classroom seat. Instead, Article 29(2) prohibited caste-based discrimination in admissions, andAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

Article 15(2) prohibited caste-based discrimination in general.
Education was to remain reservation-free.
207. When preferential treatment was given in regard to education, it was limited to educational
grants. There was no question of doling out reservations for special groups. Article 337 provided
educational grants to Anglo-Indian schools for the benefit of that community. In the spirit of
conciliation, the original Framers allowed the grants that were already going to those schools to
continue for 10 years. (See: p 936-941 of Constituent Assembly Debates, Vol. 8 1949).
208. Rather than advocate for reservation, the original Framers preferred free/compulsory
education and scholarships. In the debate on Draft Article 294, Shri Brajeshwar Prasad stated that
reservation in legislative bodies would fail to uplift SC/ST. Instead, he suggested that:
"it should be laid down clearly in express terms that ... free education shall be
imparted to them. ... [and] for the tribals and Harijans provision must be made in the
constitution that free agricultural lands should be given to them. If we cannot give
any one of these, I am quite clear in my own mind that by giving them a few seats
here and there, their economic condition and their educational level will in no way be
improved. (CAD, Vol. 9, 24 August 1948, pages 663-664)"
(emphasis supplied)
209. Shri Prasad's comments are relevant because he recognizes the limited effect of reservation.
Rather than reserve seats for a few, he advocated for free education for all.
210. In the debate regarding Article 15 of the Constitution, Syed Abdur Rouf summed up the essence
of the provision:
"The intention of this article is to prohibit discrimination against citizens." (See: p.
650 of CAD, Vol.7, 29 Nov 1948). This intention was only qualified for women and
children. In fact, the original Framers rejected an amendment that would have
watered down Article 15's prohibition against discrimination. Prof. K. T. Shah sought
special protection for SC/ST. He wanted to ensure that Article 15 would allow SC/ST
to benefit from affirmative action. To this end, he introduced an amendment that
would have altered 15(3) to read as follows: "Nothing in this article shall prevent the
State from making any special provision for women and children or for the Scheduled
Castes or backward tribes, for their advantage, safeguard or betterment." (Shah
amendment in italics). Prof. Shah proposed the amendment:
"... so that any special discrimination in favour of them may not be regarded as
violating the basic principles of equality for all classes of citizens in the country. They
need and must be given for some time to come at any rate, special treatment in r
egard to e ducation , in regard to opportunity for employment, and in many otherAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

cases where their present inequality, the present backwardness is only a hindrance to
the rapid development of the country. ... equality is not to be equality of name only or
on paper only, but equality of fact. [pages 655- 656 CAD, Vol. 7, 29 November 1948]."
(emphasis supplied)
211. Relevant to the instant case, he explains that his amendment would allow the State to provide
SC/ST special treatment in regard to education. In other words, Prof. Shah effectively wanted the
equivalent to 15(4) and 15(5) but did not get it. His amendment was negated. (p. 664 of Constituent
Assembly Debates, Vol. 7, 29 November, 1948).
212. Dr. Ambedkar disagreed with Prof. Shah on the limited ground that it would have given States
the green light to segregate SC/ST from general category students:
"The object which all of us have in mind is that the Scheduled Castes and Scheduled
tribes should not be segregated from the general public. For instance, none of us, I
think, would like that a separate school should be established for the Scheduled
Castes ... If these words are added, it will probably give a handle for a State to say,
`Well, we are making special provision for the Scheduled Castes.' To my mind they
can safely say so by taking shelter under the article if it is amended in the manner the
Professor wants it." [page 661, CAD, Vol. 7, 29 November 1948].
213. Dr Ambedkar did not reject the Shah amendment because it would have allowed the States to
implement affirmative action for SC/ST in education. He was concerned that special provisions
would lead to negative discriminatory action in the guise of affirmative action. Whether or not this
would have happened is unclear, but his concern seems well placed. A similar problem arises today,
when the general category looks down upon or questions the qualifications of SC/ST/OBC
professionals. Though the individual may have earned admission on marks alone, others may
presume that reservation was a factor. Such a belief, regardless of veracity, cannot bode well for the
career prospects of SC/ST/SEBCs.
Irrespective of the reason for which the Shah amendment was rejected, the original Framers
contemplated special provisions for SC/ST that would have included education. At the end of the
day, they decided that only women and children should benefit from discriminatory provisions.
214. Article 15(4) and the Shah amendment only differ in that Article 15(4) provides special
provisions to SC/ST and SEBC, while Shah only gave the same to SC/ST. Of course, if the original
Framers rejected special provisions for SC/ST, they would have done the same with respect to
SEBC/SC/ST. In sum, by limiting Article 15(3) to women and children and rejecting an amendment
equivalent to Article 15(4), the original Framers' intent was clear: no special provisions for backward
classes (SEBC/SC/ST) in education were to dilute Article 15(1)'s prohibition against discrimination
based on caste.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

215. In the instant case, the Union of India argued that Article 15(4), the First Amendment to the
Constitution, reflects the intent of the original Framers because it was passed by the same members
that drafted the original Constitution. In the Parliamentary debates in 1951, Prime Minister Nehru
argued in favour amending the Constitution. He and other Framers, as distinguished from the
original Framers who had drafted the original Constitution, did not hide their disapproval of
Champakam Dorairajan (supra). Article 15(4) was to overturn that judgment. To justify Article
15(4), which represented a dramatic departure from equality as envisaged in Articles 15(2), (3) and
29(2), Pandit Nehru said that Article 15(4) would give effect to "what ... was really intended or
should be intended." Yet, the original Framers, as explained above, had no intention of providing
special provisions for SC/ST in education (and a fortiori if not for them, nor for SEBC). What
"should be intended" is a far cry from what they specifically enacted and specifically rejected. It
follows that Article 15(4) deviated from the original Framers' original intent.
7 Limitations on Reservation must be seen in the light of providing a casteless society:
216. Seeking to remove the blight created by caste, the original Framers were social
reformers. "The social revolution meant `to get (India) out of the medievalism based
on birth, religion, custom, and community and reconstruct her social structure on
modern foundations of law, individual merit, and secular education'." (See: Granville
Austin, Indian Constitution:
Cornerstone of a Nation at page 26, 1st Ed, 1972, Oxford University press: (quoting
from: K. Santhanam (an Assembly member) in Magazine Section, The Hindustan
Times New Delhi, 8 September 1946).
217. India's first President Rajendra Prasad assured the Nation that the assembly and
the Government's aim was to "end poverty and squalor ... to abolish distinction and
exploitation and to ensure decent conditions of living".
[Cornerstone at page 27, fn. 5 (quoting from Prasad in CAD V, I, 2)]. The original Framers took
steps to abolish caste-based distinction. For example, they outlawed untouchability in Article 17,
promised all equal treatment before the law in Article 14, prohibited discrimination based on caste
in 15(1) and 29(2) and selected joint over separate electorates. The legislative reservations for SC/ST
were an exception to overarching goal of creating a casteless society; that is why they were set to
expire in 1960. With respect to electorates, Granville Austin explains:
"Desiring above all to promote national unity, members of the Constitutional
Assembly rejected these devices by substituting direct elections for indirect in lower
houses, by rejecting separate electorates in favour of joint electorates and by
abolishing ... except for Scheduled Castes and Tribes ... reserved seats. The Assembly
believed, in Jenning's words, that `to recognize communal claims . . . is to strengthen
communalism'. [see: Austin, p. 323 of Cornerstone.]"Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(emphasis added) The same can be said today. Reservation based on caste strengthens
communalism. Non-SEBCs naturally seek SEBC status so that they may capture SEBC benefits.
Upper castes, denied a seat, harbor ill will against lower castes who gain admission (whether it was
by merit or not).
218. These feelings are the basis for discriminatory action. On 16 September 2006, The Hindu
reported: "While medical students at the All India Institute of Medical Sciences (AIIMS) have
complained of caste discrimination, now doctors from the reserved category at the Guru Teg
Bahadur Hospital (GTBH) too have written about `biased attitude towards reserved category junior
residents'."
219. Discrimination is not the only problem exacerbated by reservation. Given that reserved
category students gain admission with lower marks, it also stands to reason that they would exhibit
less confidence in their studies when pitted against the general category. In her work on the
unintended consequences of preferential treatment for minorities in college admissions in the
United States, Marie Gryphon, a policy analyst for the Cato Institute (Washington, D.C.), writes:
"...recent research shows that affirmative action impedes academic achievement by
undermining minority students' confidence. ...
Preferences harm students' self-images, and this harm has practical costs in terms of
grades and graduation rates. Both studies build on earlier work by Stanford
University sociologist Claude Steele, who coined the term "stereotype threat" to refer
to the decline in performance suffered by members of groups who become afraid of
confirming negative group stereotypes. Steele tested his theory by giving
standardized exams to groups of white and African-American undergraduates at
Stanford University.
Testers told some groups that the exam evaluated psychological factors related to
testing, and that it was not a measure of ability. They told other groups that the exam
measured their intellectual abilities, and in some instances had them indicate their
race on the exam. The African- American students who had been implicitly
"threatened" with the stereotype of minority academic inferiority did markedly worse
on the exam than black students in the other groups. ...
Even minority students who do not need preferences respond to an environment
characterized by the relative academic weakness of minorities by worrying about
confirming a negative stereotype. [Researchers] also determined that vulnerability to
Claude Steel's stereotype threat is related to lower grades earned by minority
students." (See: p. 9-10 (internal citations omitted), Executive Summary, No. 540,
April 6, 2005, "The Affirmative Action Myth.") The point is that affirmative action
produces consequences that may outweigh its supposed benefits.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

220. To rid ourselves of reservation and its unintended consequences like casteism, we must focus
our efforts on strengthening education at the primary and secondary level.
Only then will we achieve the casteless/classless society the original Framers envisaged. And only
then will there be reason to scrap reservation altogether.
221. In his speeches to the Parliament regarding 15(4), Prime Minister Nehru could not have been
clearer: "After all the whole purpose of the Constitution, as proclaimed in the Directive Principles is
to move towards what I may say a casteless and classless society" ... and in an attempt to achieve an
egalitarian society, "... we want to put an end to all those infinite divisions that have arisen in our
social life; I am referring to the caste system and other religious divisions, call them by whatever
name you like." (emphasis added).
[Parliamentary Debates on 13 June, 1951 and 29 May, 1951 respectively].
7 If reservation is allowed, then how can a casteless society still be realized?
222. This raises the issue of how beneficiaries of special provisions are to be classified. As mentioned
above, Mr Salve and other learned counsel for petitioners pleaded that the Government cannot go
forward with the Reservation Act when it has yet to identify its beneficiaries. No one can say with
certainty what percentage of the population is OBC, yet the Government is content with giving OBCs
27% of the seats in universities. We do not know what proportion of the population is OBC because
the census does not count OBCs.
It has been Central Government policy practically since Independence to avoid the question.
Eminent American Professor Mark Galanter writes that the absence of caste data was the deliberate
policy of Sardar Patel, the Home Minister until 1950. Mr. Patel rejected caste tabulation as a device
to confirm the British theory that India was a caste-ridden country and as an expedient "to meet the
needs of administrative measures dependent on caste division" (See:
Professor Marc Galanter, (1978)"Who are the OBCs?" An Introduction to a Constitutional Puzzle. 13
Economic and Political Weekly 1812 at page 1824 at footnote 78 (quoting from Mr. Patel's 1950
address to the census conference).
Taking an OBC census is horrifying because it encourages Government to enact policy on the basis
of caste. Doing so only furthers the caste-divide, contrary to our constitutional aim. This has been
recognized since 1950. If the Central Governments have consistently rejected an OBC census
because it would promote casteism, how can this Central Government make reservation on the same
ground? It is one thing to ask a citizen his caste, it is even worse to grant or reject his college
application on that ground. The Government is between a rock and a hard place. The only way out is
to use exclusively economic criteria. This would negate the need for a caste-based census while
ensuring that reservation go to the poor, the group for which the Reservation Act was purportedly
passed. The Parliament eventually settled on enabling States to provide provisions for "socially and
educationally backward classes." Article 15(4). This Court has interpreted "backward classes" toAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

include caste as one of the criteria of classification under Article 16(4). Sahwney I, para 859(3)(b). In
other words, caste falls under class according to Sawheny I, para 859(3)(a).
7 Economic criteria allows for reservation on grounds other than caste:
223. Despite the goal of a casteless society, the Parliament allowed for caste-based
reservation and, consequently, caste-
based discrimination. Ultimately, they subjected Articles 29(2) and Article 15 to Article 15(4). Dr.
Ambedkar saw no choice but to discriminate based on caste, stating that "if you make a reservation
in favour of what are called backward classes which are nothing else but collection of certain castes,
those who are excluded are persons who belong to certain castes.
Therefore, in the circumstances of this country, it is impossible to avoid reservation without
excluding some people who have got a caste."
224. In draft article 10, Dr. Ambedkar tried to reconcile the view of those who were in favour of
equality of opportunity with the demand of certain communities who remained neglected and who
wanted to have a share in the administration. In doing so, he was clear that the concept of equality,
which is the very basis of democracy, should not be violated. Part of his compromise meant that
reservation had to remain reasonable. Explaining his views on the matter, he said:
"Supposing, for instance, we were to concede in full the demand of those
communities who have not been so far employed in the public services to the fullest
extent, what would really happen is, we shall be completely destroying the first
proposition upon which we are all agreed, namely, that there shall be an equality of
opportunity. Let me give an illustration. Supposing, for instance, reservations were
made for a community or a collection of communities, the total of which came to
something like 70 per cent of the total posts under the State and only 30 per cent are
retained as the unreserved. Could anybody say that the reservation of 30 per cent as
open to general competition would be satisfactory from the point of view of giving
effect to the first principle, namely, that there shall be equality of opportunity? It
cannot be in my judgment. Therefore the seats to be reserved, if reservation is to be
consistent with sub-clause (1) of Article 10, must be confined to a minority of seats.
(see CAD, Vol.7, 30th November, 1948 pp 701-02)."
225. On 17th November, 1949, the Constituent Assembly began the third reading of the Constitution
Bill. While replying to the debate, Dr. Ambedkar stated:
"This anxiety is deepened by the realization of the fact that in addition to our old
enemies in the form of castes and creeds we are going to have many political parties
with diverse and opposing political creeds. Will Indians place the country above their
creed or will they place creed above country? I do not know. But this much is certain
that if the parties place creed above country, our independence will be put inAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

jeopardy a second time and probably be lost forever. This eventuality we must all
resolutely guard against. We must be determined to defend our independence with
the last drop of our blood. (See: CAD on 25th November, 1949 pp 977-978)"
(emphasis supplied).
226. Exhibiting tunnel vision, our First Parliament failed to look beyond caste. Another option was
available, an option that adhered to the original Framers' ideals. Contrary to Dr Ambedkar's view, it
was possible to provide reservation to backward classes without discriminating based on caste.
Economic criteria target the poorest of the poor, irrespective of caste. As noted, these criteria also
simultaneously remove the creamy layer.
227. One of the other prominent advocates of reservation later realised that the policy did more
harm than good. Prime Minister Nehru wrote the following letter to the Chief Ministers on June
27th, 1961:
"I have referred above to efficiency and to our getting out of our traditional ruts. This
necessitates our getting out of the old habit of reservations and particular privileges
being given to this caste or that group. The recent meeting we held here, at which the
chief ministers were present, to consider national integration, laid down that help
should be given on economic considerations and not on caste. It is true that we are
tied up with certain rules and conventions about helping Scheduled Castes and
Tribes. They deserve help but, even so, I dislike any kind of reservation, more
particularly in service. I react strongly against anything which leads to inefficiency
and second-rate standards. I want my country to be a first class country in
everything. The moment we encourage the second- rate, we are lost.
The only real way to help a backward group is to give opportunities for good
education. This includes technical education, which is becoming more and more
important. Everything else is provision of some kind of crutches which do not add to
the strength or health of the body. We have made recently two decisions which are
very important: one is, universal free elementary education, that is the base; and the
second is scholarships on a very wide scale at every grade of education to bright boys
and girls, and this applies not merely to literary education, but, much more so, to
technical, scientific and medical training. I lay stress on bright and able boys and
girls. I have no doubt that there is a vast reservoir of potential talent in this country if
only we can give it opportunity.
But if we go in for reservations on communal and caste basis, we swamp the bright
and able people and remain second-rate or third-rate. I am grieved to learn of how
far this business of reservation has gone based on communal consideration. It has
amazed me to learn that even promotions are based sometimes on communal and
caste considerations. This way lies not only folly, but disaster. Let's help theAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

backward groups by all means, but never at the cost of efficiency. How are we going
to build our public sector or indeed any sector with second-rate people?"
7 Upon expiry of the time limit, the criteria for identifying OBCs should only be economic in nature
because our ultimate aim is to establish a casteless and classless society
228. I am not the first to propose economic criteria as the exclusive means of identifying SEBCs. In
Vasanth Kumar's case, counsel sought an opinion from the Court regarding reservations in
employment and education for SC/STs and OBCs. The opinion would guide the Karnataka
Government in implementing reservation. [para 1]. It serves our purposes to review their thorough
analysis of the identification issue.
229. The Court in Vasanth Kumar observed as under:
"24. ... No one is left in any doubt that the future Indian Society was to be casteless
and classless. Pandit Jawaharlal Nehru the first Prime Minister of India said that
Mahatma Gandhi has shaken the foundations of caste and the masses have been
powerfully affected. But an even greater power than Gandhi is at work, the conditions
of modern life -- and it seems at last this hoary and tenacious ralic of past times must
die. (Discovery of India by Pandit Nehru, Ch VI, p 234) Mahatma Gandhi, the Father
of the Nation said, "The caste system as we know is an anachronism. It must go if
both Hinduism and India are to live and grow from day to day ". In its onward march
towards realising the constitutional goal, every attempt has to be made to destroy
caste stratification. Article 38(2) enjoins the State to strive to minimise the inequality
in income and endeavour to eliminate inequalities in status, facilities and
opportunities, not only amongst individuals but also amongst groups of people
residing in different areas or engaged in different vocations. Article 46 enjoins duty to
promote with special care the educational and economic interests of the weaker
sections of the people, and in particular, of the Scheduled Castes and Scheduled
Tribes, and shall protect them from social injustice and all forms of exploitation.
Continued retention of the division of the society into various castes simultaneously
introduces inequality of status. And this inequality in status is largely responsible for
retaining inequality in facilities and opportunities, ultimately resulting in bringing
into existence an economically depressed class far transcending caste structure and
caste barrier. The society therefore, was to be classless casteless society. In order to
set up such a society, steps have to be taken to weaken and progressively eliminate
caste structure. Unfortunately, the movement is in the reverse gear. Caste
stratification has become more rigid to some extent, and where concessions and
preferred treatment schemes are introduced for economically disadvantaged classes,
identifiable by caste label, the caste structure unfortunately received a fresh lease of
life. In fact there is a mad rush for being recognised as belonging to a caste which by
its nomenclature would be included in the list of socially and educationally backward
classes. ... Rane Commission took note of the fact that there was an organised effort
for being considered socially and educationally backward castes. Rane CommissionAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

recalled the observations in Balaji case [(1963) Supp (1) SCR 439] that "Social
backwardness is on the ultimate analysis the result of poverty to a very large extent".
... The Commission came to an irrefutable conclusion that amongst certain castes and
communities or class of people, only lower income groups amongst them are socially
and educationally backward. ..."
230. In this judgment, this Court further observed that if State patronage for preferred treatment
accepts caste as the only insignia for determining social and educational backwardness, the danger
looms large that this approach alone would legitimize and perpetuate the caste system. Caste-based
reservation does not go well with our secular character as enshrined in the Preamble to the
Constitution.
231. That said, the majority in Sawhney I later sided with Justice Chinnappa Reddy's view: caste can
be a factor in identifying SEBCs. This view should not hold the day forever.
Eventually, the words of Justice Desai should be revived.
232. Justice Desai wanted to achieve two goals with one fell swoop of the pen. Had his opinion
prevailed (1) the creamy layer would have been removed ensuring that the truly deserving get the
benefit and (2) the casteless society would have been furthered. To these ends, he would have
applied economic criteria to remove the creamy layer and simultaneously rid reservation of caste.
233. He explained that poverty is the bane of Indian society.
Given rampant poverty, it comes as no surprise that "... the bank balance, the property holding and
the money power determine the social status of the individual and guarantee the opportunities to
rise to the top echelon." [Vasanth Kumar at para 27]. As a result, the way "...wealth is acquired has
lost significance." And "upper caste does not enjoy the status or respect ... any more even in rural
areas what to speak of highly westernised urban society." Finally, his Lordship recognized that
creamy layer exclusion is inherently linked with identification based on economic criteria, i.e.,
"occupation, income and land holdings":
"30. ... If economic criterion for compensatory discrimination or affirmative action is
accepted, it would strike at the root cause of social and educational backwardness,
and simultaneously take a vital step in the direction of destruction of caste structure
which in turn would advance the secular character of the Nation. This approach seeks
to translate into reality the twin constitutional goals: one, to strike at the
perpetuation of the caste stratification of the Indian Society so as to arrest
progressive movement and to take a firm step towards establishing a casteless
society; and two, to progressively eliminate poverty by giving an opportunity to the
disadvantaged sections of the society to raise their position and be part of the
mainstream of life which means eradication of poverty."Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

234. Economic criteria must include occupation and land holdings because income alone is
insufficient. To decrease the likelihood that the undeserving evade identification, it is wise to employ
more than one criterion.
235. In Vasanth Kumar, Justice Chinnappa Reddy departs from Justice Desai's use of economic
criteria as the sole means of identification. Nevertheless, he recognizes that " ...
attainment of economic equality is the final and only solution to the besetting problems." In Justice
Chinnappa Reddy's opinion, it is easier to classify based on caste than economic criteria:
"80: Class poverty, not individual poverty, is therefore the primary test. Other
ancillary tests are the way of life, the standard of living, the place in the social
hierarchy, the habits and customs, etc. etc. Despite individual exceptions, it may be
possible and easy to identify socially backwardness with reference to caste, with
reference to residence, with reference to occupation or some other dominant feature.
Notwithstanding our antipathy to caste and sub-regionalism, these are facts of life
which cannot be wished away. If they reflect poverty which is the primary source of
social and educational backwardness, they must be recognised for what they are
along with other less primary sources."
It all depends on how one defines "class." Once economic criteria remove the relatively wealthy
families (from all castes and communities), a "class" will remain. This "class" is known as "the poor."
The class would share the same characteristic, irrespective of caste. They would all lack money.
236. In a number of judgments, this Court has spelt out our constitutional philosophy regarding
caste. On numerous occasions, this Court has proclaimed that the cherished goal of the Nation is to
realise a casteless society. In Shri V. V. Giri v. Dippala Suri Dora & Others (1960) 1 SCR 426 at 442,
the Court observed as under:-
"........The history of social reform for the last century and more has shown how
difficult it is to break or even to relax the rigour of the inflexible and exclusive
character of the caste system. It is to be hoped that this position will change, and in
course of time the cherished ideal of casteless society truly based on social equality
will be attained under the powerful impact of the doctrine of social justice and
equality proclaimed by the Constitution and sought to be implemented by the
relevant statutes and as a result of the spread of secular education and the growth of
a rational outlook and of proper sense of social values; but at present it would be
unrealistic and utopian to ignore the difficulties which a member of the depressed
tribe or caste has to face in claiming a higher status amongst his co-religionists. It is
in the light of this background that the alternative plea of the appellant must be
considered."
237. In N M. Thomas (supra), a seven Judge Bench observed as under:Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"This consummation is accomplished only when the utterly depressed groups can
claim a fair share in public life and economic activity, including employment under
the State, or when a classless and casteless society blossoms as a result of positive
State action."
238. In his dissenting opinion, in Sawhney I Justice Kuldip Singh observed as under:
"339. Secularism is the basic feature of the Indian Constitution. It envisages a
cohesive, unified and casteless society. ... The prohibition on the ground of caste is
total, the mandate is that never again in this country caste shall raise its head. Even
access to shops on the ground of caste is prohibited. The progress of India has been
from casteism and egalitarianism from feudalism to freedom.
340. The caste system which has been put in the grave by the framers of the
Constitution is trying to raise its ugly head in various forms. Caste poses a serious
threat to the secularism and as a consequence to the integrity of the country. Those
who do not learn from the events of history are doomed to suffer again."
239. In Akhil Bhartiya Soshit Karamchari Sangh (Railway) (supra), it was observed as under::
"14. These forces nurtured the roots of our constitutional values among which must
be found the fighting faith in a casteless society, not by obliterating the label but by
advancement of the backward ...
240. Returning to Vasanth Kumar, one of Justice Reddy's arguments deals with the level of effort
required to identify the poor compared to the effort expended on identifying caste. In the current
context, a number of factors, including economic, are measured to determine SEBC status. (See: the
National Commission of Backward Classes' Guidelines for considerations of Requests for inclusion
and complaints of under-inclusion in the Central List of Other Backward Classes).
241. The National Commission for Backward Classes aside, I have set out to eventually install a
system that only takes cognizance of economic criteria. Using purely economic criteria would lighten
the identification load, as ascertaining caste would no longer be required. Respondents and others
level a common criticism against the exclusive use of economic criteria. Most of the country is poor.
242. Thus, too many people would be eligible for the benefit.
This is only a problem if you hand out reservations based on the group's proportion of the total
population. Such a reservation would be excessively unreasonable and would likely violate the Balaji
cap of 50% [see M.R. Balaji & Ors. v.
State of Mysore [(1963) Supp (1) SCR 439]. If economic reservation were limited to a reasonable
number, it could be upheld.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

243. In addition to the problem of extending the benefit to too many, Reddy, J. cannot contemplate
the idea of bestowing reservation on an economically poor Brahmin. "The idea that poor Brahmins
may also be eligible for the benefits of Articles 15(4) and 16(4) is too grotesque even to be
considered." He says that they are not "socially backward", thus they should not receive the benefit.
But can one call a Brahmin sweeper, poor by occupation, socially forward? To do so would be a
stretch.
244. The majority in Sawhney I reiterates Justice Chinnappa Reddy's message in Vasanth Kumar.
They rejected the sole use of economic criteria to exclude the creamy layer, deeming it to be just one
measure of advancement. Justice Jeevan Reddy qualified that sentiment to an extent. If income
were extremely high, it could be the sole factor. In such a case, income alone would ensure that one
were socially forward.
Justice Jeevan Reddy was convinced that caste mattered more than money - especially in rural
areas. He makes his point by way of example at para 792:
"A member of backward class, say a member of carpenter caste, goes to Middle East
and works there as a carpenter. If you take his annual income in rupees, it would be
fairly high from the Indian standard. Is he to be excluded from the Backward Class?
Are his children in India to be deprived of the benefit of Article 16(4)?"
245. Unless the carpenter became a factory owner, where his income would be a reflection of his
status, Justice Reddy would answer his own question in the negative. This is where we part ways.
Today, the NRI carpenter's children will have likely attended the best schools, tuitions and coaching
classes that money can buy. These children do not need special provisions. That is why I am
removing the creamy layer, calling for a time-limit on caste-based reservation and urging the
Government to use exclusively economic criteria to identify OBCs who may avail of special
provisions.
246. The United States Supreme Court has taken a similar position with regard to setting a
time-limit on race-based affirmative action. As mentioned above, Justice Sandra Day O'Connor
opined that there may be a time-limit to promoting diversity via preferential treatment for certain
races: "We expect that 25 years from now, the use of racial preferences will no longer be necessary to
further the interest approved today." (See: Grutter at 343).
247. In our context, one need not look past the Parliament's affinity with extending time-limits on
reservation to see that only the judiciary can put a stop to caste-based reservation.
Article 334 originally said that reservation for SC/ST/Anglo-
Indians in the Lok Sabha and State Legislative Assemblies would expire on the Constitution's tenth
birthday. The Parliament later substituted "ten" for "thirty years" vide the 45th Amendment. When
that was to expire, the Parliament extended it for another ten years vide the 62nd Amendment.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

When that was to expire, it extended it for another ten years vide the 79th Amendment. History has
shown that it is not politically feasible for the Parliament to say "no" to reservation
- especially when caste is involved.
248. Nevertheless, I have noted that Sawhney I rejects purely economic criteria
(occupation/income/property holdings/or similar measures of economic power) with respect to
classification under 16(4). [para 859, 4(a)]. Sawhney I's nine-Judge holding precludes us from
striking the impugned legislation to the extent that it has not yet ruled out the use of caste-based
criteria for identifying SEBC status. It also precludes us from forcing the Government to wean itself
off caste-based reservation by a certain date. In order to achieve a casteless and classless society,
after a lapse of ten years, special preference or reservation should be granted only on the basis of
economic criteria as long as grave disparity and inequality persist.
7 Secularism is Part of the Basic Structure
249. To be clear, there is no claim arising out of the goal to promote a casteless society. No right of
action exists. The right of action is found in secularism. Though not explicitly found in the
un-amended Constitution, the original Framers made it clear that India was to be a secular
democracy.
Discrimination based on religion is prohibited by Articles 14, 15(1) and 15(2), 16(1) and 16(2), 29(2)
and 325. The original Framers went out of their way to ensure that minorities would be able to
maintain their identity. (See: Articles 28, 29 and
30). Article 27 precludes the state from adopting a state religion, whereas Article 25 grants citizens
the right to profess, practice and propagate religion. With rights come responsibilities. One of them
is found at Article 51A(3), which instructs citizens "... to promote harmony and spirit of brotherhood
amongst all people ... transcending religious ...
diversities."
250. Relying on these provisions, Bommai (1994) 3 SCC 1 at para 304 declared secularism "....a
constitutional goal and a basic feature of the Constitution as affirmed in Kesavananda Bharati and
Indira N. Gandhi v. Raj Narain. Any step inconsistent with this constitutional policy is, in plain
words, unconstitutional." The Court reasoned that the original Framers adopted Articles 25, 26 and
27 so as to further secularism. (See: Bommai at para 28 (Ahmadi, J.)).
Secularism was very much embedded in their constitutional philosophy. [para 29]. During the
Constituent Assembly Debates, Pandit Laxmikantha Mitra stated (as quoted at para 28 of Bommai):
"By secular State, as I understand it, it is meant that the State is not going to make
any discrimination whatsoever on the ground of religion or community against any
person professing any particular form of religious faith. ... no citizen ... will have anyAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

preferential treatment ... simply on the ground that he professed a particular form of
religion."
This is relevant today because quotas are state-sponsored discrimination against those who are not
deemed SEBCs -
caste being a by-product of religion. Though affirmative action is allowed, there is a point at which it
violates secularism.
Finally, I note that the 42nd Amendment, which formally inserted secularism into the Preamble,
merely made what was already implicit explicit. (See Bommai at para 29).
7 Conclusion on the Casteless Society
251. In conclusion, the First Parliament, by enacting Article 15(5), deviated from the original
Framers' intent. They passed an amendment that strengthens, rather than weakens casteism. If
caste-based quotas in education are to stay, they should adhere to a basic tenet of secularism: they
should not take caste into account. Instead, exclusively economic criteria should be used. For a
period of ten years, other factors such as income, occupation and property holdings etc. including
caste, may be taken into consideration and thereafter only economic criteria should prevail.
Sawhney I has tied our hands. I nevertheless believe that caste matters and will continue to matter
as long as we divide society along caste-
lines. Caste-based discrimination remains. Violence between castes occurs. Caste politics rages on.
Where casteism is present, the goal of achieving a casteless society must never be forgotten. Any
legislation to the contrary should be discarded.
5. Are Articles 15(4) and 15(5) mutually contradictory, such that 15(5) is unconstitutional?
252. While contradictory, I am able to read them harmoniously. Learned senior counsel for
petitioners, Mr. K.K. Venugopal, argued that Articles 15(5) and 15(4) are inconsistent to the extent
that 15(5) exempts minority institutions from reservation and 15(4) incorporates aided minority
institutions in the reservation scheme. Because both provisions contain "non-obstante clauses", they
render each other void. He further submitted that the Court is in the position of having to choose
between them in regard to this inconsistency. He provided three tests of statutory interpretation
that give us guidance in resolving such a conflict.
253. First, if the Court cannot harmonize the two provisions, it must invalidate the one that
completely destroys the other's purpose. Sarwan Singh & Another v. Kasturi Lal (1977) 1 SCC 750,
pages 760-761, at para 20). In the instant case, one of the express purposes of 15(5) was to exempt
minority institutions and thus avoid conflict with Article 30(1). This is found in the text of Article
15(5) itself.
254. With nothing in the text of 15(4) to guide us, we turn to its Statement of Objects and Reasons:Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

"......The Act also amplifies Article 15(3) so as to ensure that any special provisions
that the State may make for the educational, economic or social advancement of any
backward class citizens may not be challenged on the ground of being discriminatory.
"
255. Thus, Article 15(4) was not passed with an express intention to include minority institutions;
nor did it arise out of a case in which minority institutions were a party. Then again, it was open to
the First Parliament to exclude minority institutions from the beginning. Articles 15(4) and 15(5)'s
purposes do not necessarily conflict. I find the first test inconclusive and thus turn to the other ones.
The second test asks which provision came into effect at a later date (i.e., was "later in time?")? That
which is later shall prevail. Here, 15(5) was enacted later in time. In J.K. Cotton Spinning and
Weaving Mills Co. Ltd. v. State of Uttar Pradesh & Others AIR 1961 SC 1170 at page 1174, para 9, I
find the third test; it provides that the specific clause must trump the general.
Article 15(5) is specific in that it refers to special provisions that relate to admission in educational
institutions, whereas 15(4) makes no such reference to the type of entity at which special provisions
are to be enjoyed.
256. Because 15(5) is later in time and specific to the question presented, it must neutralize 15(4) in
regard to reservation in education. Mr K. Parasaran, learned senior counsel for the respondents,
correctly pointed out that constitutional articles are to be read harmoniously, not in isolation. (See:
T.M.A. Pai (supra) at page 582, para 148). Our interpretation is harmonious because Article 15(4)
still applies to other areas in which reservation may be passed.
6. Does Article 15(5)'s exemption of minority institutions from the purview of reservation violate
Article 14 of the Constitution?
257. Given the inherent tension between Articles 29(2) and 30(1), I find that the overriding
constitutional goal of realizing a casteless/classless society should serve as a tie-breaker.
We will take a step in the wrong direction if we subject minority institutions (even those that are
aided) to reservation.
258. Minority aided institutions were subject to a limited form of reservation. In order to preserve
the minority character of the institution, reservation could only be imposed to a reasonable extent.
Minority aided institutions could select their own students, contingent upon admitting a reasonable
number of non-minority students per the percentage provided by the State Government. This
conclusion was derived from two conflicting constitutional articles. Of course, I am only concerned
with minority aided institutions because I have already determined that the State shall not impose
reservation on unaided institutions (minority or non-minority).
259. Article 30(1) provides that "all minorities, whether based on religion or language, shall have the
right to establish and administer educational institutions of their choice." Article 29(2) states that
"no citizen shall be denied admission into any educational institution maintained by the State orAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

receiving aid out of State funds on grounds only of religion, race, caste, language or any of them."
260. In other words, 30(1) by itself would allow minority aided institutions to reject all non-minority
candidates, and 29(2) by itself would preclude the same as discrimination based solely on religion.
Yet neither provision exists by itself. Rather than disturb the Constitution, this Court struck a
compromise and diluted each provision in order to uphold both. Reading Articles 30(1) and 29(2)
harmoniously, Kerala Education Bill provided that once minority institutions receive aid, a
sprinkling of outsiders must be admitted.
261. "Sprinkling" ensured that the minority character of the institution would not be lost. In regard
to the "sprinkled"
seats, minority institutions cannot discriminate based on religion in violation of Article 29(2). At the
same time, if the State compelled aided minority institutions to take too many non-minority
students, the institution would be "minority" in name only. But what does "too many" mean? Can
"sprinkling"
be quantified? Clearing up the ambiguity, St. Stephen's held that minority institutions must make
50% of their seats available to outsiders and that admission for the other 50% (its own community)
must be done on merit. Pai later rejected the rigidity attached to this fixed percentage. Along these
lines, Pai returned to a more flexible standard, one akin to "sprinkling" in Kerala Education Bill: the
moment a minority institution takes aid, it has to admit non-minority students to a reasonable
extent, whereby the character of the institution was maintained and yet citizens' Article 29(2) rights
were not subverted. (Also see: Pai at para 149).
Thus, two admission pools were created for aided minority institutions: minority and non-minority.
In the minority pool, merit was to be observed. From the non-minority pool, reservations for the
weaker sections may be made while the remaining seats, if any, would be distributed based on merit
to non-minority students.
"... It would be open to the state authorities to insist on allocating a certain
percentage of seats to those belonging to weaker sections of society, from amongst
the non-minority seats." [Pai at para 152].
262. With regard to the percentage of reservation, the State Governments were to determine the
percentage of non-
minority seats according to the needs of that State. As a compliment to reservation, aided minority
institutions were also subject to regulation of administration and management.
Pai declared at para 72 as noted above that:
"Once aid is granted to a private professional educational institution, the
Government or the state agency, as a condition of the grant of aid, can put fetters onAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

the freedom in the matter of administration and management of the institution. The
state, which gives aid to an educational institution, can impose such conditions as are
necessary for the proper maintenance of the high standards of education as the
financial burden is shared by the state. ..."
263. In addition to the general power to impose conditions that seek to maintain high standards or
"excellence in education," the State could implement the same under a related but different
rationale. That is, said regulations could be upheld in the name of national interest. [Pai at para
107].
Yet the Government could not destroy the minority character of an institution. [para 107]. Nor could
it obliterate the establishment or administration of a minority institution.
[para 107]. A balance was to be struck between (a) maintaining academic quality and (b) preserving
the minority right to establish/administer educational institutions.
Regulations that embraced these two objectives were considered reasonable. [Pai at para 122].
264. A question of great import is whether Article 30 was designed to put minorities on equal or
higher footing than non-minorities. This question played out in detail in a debate between Khare,
C.J. and Justice Sinha in Islamic Academy.
Writing for the majority, Chief Justice Khare takes issue with Pai. The Chief Justice says that Pai has
wrongly categorized minority rights as equal to those of the non-minority. He has a point. Minorities
can establish and administer institutions for their communities per Article 30; non-minorities
cannot.
His Lordship observed: (para 9 page 723) "...We do not read these paragraphs to mean that non-
minority educational institutions would have the same rights as those conferred on minority
educational institutions by Article 30 of the Constitution of India. Non-minority educational
institutions do not have the protection of Article
30. Thus, in certain matters they cannot and do not stand on a similar footing as minority
educational institutions. Even though the principle behind Article 30 is to ensure that the minorities
are protected and are given an equal treatment yet the special right given under Article 30 does give
them certain advantages..."
Relying on St. Xavier's case (1975) 1 SCR 173, Pai concluded that the object of Article 30 was to
ensure minorities of equal treatment and nothing more.
265. It was observed in St. Xaviers College case, at page 192, that "the whole object of conferring the
right on minorities under Article 30 is to ensure that there will be equality between the majority and
the minority. If the minorities do not have such special protection, they will be denied equality." TheAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

minority institutions must be allowed to do what the non-
minority institutions are permitted to do. [Pai at para 138].
266. In contrast to the majority in Islamic, Justice Sinha concludes that Article 30(1) raises
minorities to an equal platform and no higher. Relevant portion is reproduced hereinbelow:
"The statement of law contained in paras 138 and 139 is absolutely clear and
unambiguous and no exception can be taken thereto. The doubt, if any, that the
minorities have a higher right in terms of Article 30(1) of the Constitution of India
may be dispelled in clearest terms inasmuch as the right of the minorities and
non-minorities is equal. Only certain a dditional protection has been conferred under
Article 3 0(1) of the 'Constitution of India to bring the minorities on the same
platform as that of non-minorities as regards the right to establish and administer an
educational institution for the purpose of imparting education to members of their
own community whether based on religion or language. [see: Islamic Academy at
para 105]."
267. Justice Sinha considers it constitutionally immoral to discriminate against non-minorities in
the guise of protecting the constitutional rights of minorities. [See: Islamic Academy at para 118].
Even in the face of Articles that provide preferential treatment to minority or weaker sections, e.g.,
30(1), 15(4) and 16(4), the right to equality must mean something.
268. Justice Khare, as he then was, concludes that original Framers conferred Article 30(1) on
minorities in order to instill in them a sense of confidence and security. [Pai at page 615 at para
229]. Their right to establish and administer educational institutions could not be usurped by mere
legislation. Khare, J. stated at para 229 p.615:-
"Thus, while maintaining the rule of non-discrimination envisaged by Article 29(2),
the minorities should have also right to give preference to the students of their own
community in the matter of admission in their own institution. Otherwise, there
would be no meaningful purpose of Article 30(1) in the Constitution. True, the receipt
of State aid makes it obligatory on the minority educational institution to keep the
institution open to non-minority students without discrimination on the specified
grounds. But, to hold that the receipt of State aid completely disentitles the
management of minority educational institutions from admitting students of their
community to any extent will be to denude the essence of Article 30 of the
Constitution. It is, therefore, necessary that the minority be given preferential rights
to admit students of their own community in their own institutions in a reasonable
measure otherwise there would be no meaningful purpose of Article 30 in the
Constitution."
269. Minorities possess one right or privilege that non-Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

minorities do not: establishing and administering institutions for their community. The right to
admit your own students in aided minority institutions was subject to admitting a reasonable
number of outsiders. In the instant case, aided minority institutions stand to benefit from the
Reservation Act:
instead of having to admit a reasonable number of outsiders they would be exempted
from reservation. However, their non- minority counterparts would not. Does this
elevate their status? While it does to a certain extent, however, we must also keep our
constitutional goal and philosophy in mind. Given the ultimate goal of furthering a
classless/casteless society, there is no need to go out on a limb and rewrite them into
the Amendment. Such a ruling would subject even more institutions to caste-based
reservation. This would be a step back for the Nation, furthering the caste divide. I
refuse to go in that direction.
7) Are the standards of review laid down by the U.S. Supreme Court applicable to our
review of affirmative action under Article 15(5) and similar provisions?
270. As noted above, U.S. law is, of course, not binding but does have great persuasive value. This is
because their problem of race is akin to our problem of caste. Where others have reviewed similar
issues in great detail, it behooves us to learn from their mistakes as well as accomplishments.
Mr. R. Venkataraman, former President of India in a foreword to a book of eminent constitutional
expert Dr. L.M. Singhvi "Democracy And Rule of Law : Foundation And Frontiers", has aptly
observed which reads as under:
"Society progresses only by exchange of thoughts and ideas. Imagine what a sorry
state the world would have been in had not thoughts and ideas spread to all corners
of the globe. Throughout history, philosophers, reformers, thinkers, and scholars
have recorded their thoughts, regardless of whether they were accepted or not in
their times, and thus contributed towards progress of humankind. India was the first
to encapsulate this seminal global thought. The Rig Veda says:
Ano bhadrah Krtavo yantu Viswatah Let noble thought come to us from every side."
8) With respect to OBC identification, was the Reservation Act's delegation of power to the Union
Government excessive?
271. It is not an excessive delegation. I agree with the Chief Justice's reasoning at para 185 of his
judgment.
9) Is the impugned legislation invalid as it fails to set a time-limit for caste-based reservation?
272. It is not invalid because it fails to set a time-limit. Given the Parliament's history of extending
time-limits on other reservation schemes, there is much force to the argument that the ParliamentAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

will forever continue to extend reservations. As noted above, it is consistent with our constitutional
goal of achieving a classless/casteless society that a time-limit be set.
But I am bound by Sawhney I and believe that only a larger bench could make such a ruling. A larger
bench could certainly hold that only economic criteria could be used to identify SEBCs and that it
should be done by a certain date.
10) At what point is a student no longer Educationally Backward and thus no longer eligible for
special provisions under 15(5)?
273. Once a candidate graduates from a university, he must be considered educationally forward.
Senior counsel for petitioners, Mr. P.P. Rao, contended that those who have completed Plus 2
should be considered educationally forward.
In other words, they would no longer be eligible for reservation in university or post-graduate
studies. There is some force in this argument where only 18% in the relevant age-group have
completed Plus 2. From this vantage point, this means that they are educationally elite. But the
answer to most questions in law is not so simple. The answer often depends on the circumstances
surrounding the issue. In the marketplace, a candidate who has completed higher secondary
education cannot be considered "forward". The real value of the higher secondary degree is that it is
a prerequisite for college admissions. The general quality of education imparted upto Plus 2 is of
extremely indifferent quality and apart from that, today some entry-level Government positions only
accept college graduates. One is educationally backward until the candidate has graduated from a
university. Once he has, he shall no longer enjoy the benefits of reservation. He is then deemed
educationally forward. For admission into Master's programmes, such as, Master of Engineering,
Master of Laws, Master of Arts etc., none will be a fortiori eligible for special benefits for admission
into post graduation or any further studies thereafter.
11. Would it be reasonable to balance OBC reservation with societal interests by instituting OBC
cut-off marks that are slightly lower than that of the general category?
274. Balaji (supra) concluded that reservation must be reasonable. The Oversight Committee has
made a recommendation that will ensure the same. At page 34 of Volume I of its Report, the
Oversight Committee recommended that institutions of excellence set their own cut off marks such
that quality is not completely compromised. Cut offs or admission thresholds as suggested by the
Oversight Committee are reproduced:
"4.4.2 The Committee recognizes that those institutions of higher learning which
have established a global reputation (e.g. IITs, IIMs, IISc, AIIMS and other such
exceptional quality institutions), can only maintain that if the highest quality in both
faculty and students is ensured. Therefore, the committee recommends that the
threshold for admission should be determined by the respective institutions alone, as
is done today, so that the level of its excellence is not compromised at all.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

4.4.3 As regards `cut-offs' in institutions other than those mentioned in para 7, these
may be placed somewhere midway between those for SC/ST and the unreserved
category, carefully, calibrated so that the principles of both equity and excellence can
be maintained.
4.4.4 The Committee strongly feels that the students who currently tend to get
excluded must be given every single opportunity to raise their own levels of
attainment, so that they can reach their true potential. The Government should invest
heavily in creating powerful, well designed and executed remedial preparatory
measures to achieve this objective fully."
275. Standards of excellence however should not be limited to the best aided institutions. The
Nation requires that its citizens have access to quality education. Society as a whole stands to benefit
from a rational reservation scheme.
276. Finding 68% reservation in educational institutions excessive, Balaji at pages 470-471 (supra)
admonished States that reservation must be reasonable and balanced against other societal
interests. States have "... to take reasonable and even generous steps to help the advancement of
weaker elements; the extent of the problem must be weighted, the requirements of the community
at large must be borne in mind and a formula must be evolved which would strike a reasonable
balance between the several relevant considerations." To strike such a balance, Balaji slashed the
impugned reservation from 68 to less than 50%.
277. Balaji thus serves as an example in which this Court sought to ensure that reservation would
remain reasonable.
We heed this example. There should be no case in which the gap of cut off marks between OBC and
general category students is too large. To preclude such a situation, cut off marks for OBCs should
be set no lower than 10 marks below the general category.
278. To this end, the Government shall set up a committee to look into the question of setting the
OBC cut off at nor more than 10 marks below that of the general category. Under such a scheme,
whenever the non-creamy layer OBCs fail to fill the 27% reservation, the remaining seats would
revert to general category students.
SUMMARY OF FINDINGS 1A. Whether the creamy layer be excluded from the 3 rd Amendment
(Reservation Act) ?
Yes, it must. The 93rd amendment would be ultra vires and invalid if the creamy layer is not
excluded.
See paras 22, 25, 27, 30, 34, 35, 43, 44.
1B. What are the parameters for creamy layer exclusion?Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

For a valid method of creamy layer exclusion, the Government may use its post-Sawhney I criteria
as a template. (See: Office Memorandum dated 8-9-1993, para 2(c)/Column 3). I urge the
Government to periodically revise the O.M. so that changing circumstances can be taken into
consideration while keeping our constitutional goal in view.
I further urge the Government to exclude the children of former and present Members of the
Parliament and Members of Legislative Assemblies and the said O.M. be amended accordingly.
See paras 55-57.
1C. Is creamy layer exclusion applicable to SC/ST?
In Indra Sawhney-I, creamy layer exclusion was only in regard to OBC. Justice Reddy speaking for
the majority at para 792 stated that "this discussion is confined to Other Backward Classes only and
has no relevance in the case of Scheduled Tribes and Scheduled Castes". Similarly, in the instant
case, the entire discussion was confined only to Other Backward Classes. Therefore, I express no
opinion with regard to the applicability of exclusion of creamy layer to the Scheduled Castes and
Scheduled Tribes.
See para 34.
2. Can the Fundamental Right under Article 21A be accomplished without great emphasis on
primary education?
No, it cannot.
An inversion in priorities between higher and primary/secondary education would make compliance
with Article 21A extremely difficult. It is not suggested that higher education needs no
encouragement or that higher education should not receive more funds, but there has to be much
greater emphasis on primary education. Our priorities have to be changed. Nothing is really more
important than to ensure total compliance of Article 21A. Total compliance means good quality
education is imparted and all children aged six to fourteen regularly attend schools. I urge the
Government to implement the following:
The current patchwork of laws on compulsory education is insufficient. Monetary
fines do not go far enough to ensure that Article 21A is implemented. The Central
Government should enact legislation that:
(a) provides low-income parents/guardians with financial incentives such that they
may afford to send their children to schools;
(b) criminally penalizes those who receive financial incentives and despite such
payment send their children to work;Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

(c) penalizes employers who preclude children from attending schools;
(d) the penalty should include imprisonment; the aforementioned Bill would serve as
an example. The State is obligated under Article 21A to implement free and
compulsory education in toto.
(e) until we have accomplished for children from six to fourteen years the object of
free and compulsory education, the Government should continue to increase the
education budget and make earnest efforts to ensure that children go to schools and
receive quality education;
(f) The Parliament should fix a deadline by which time free and compulsory
education will have reached every child. This must be done within six months, as the
right to free and compulsory education is perhaps the most important of all the
fundamental rights. For without education, it becomes extremely difficult to exercise
other fundamental rights.
See paras 126-131.
D oes the 93 rd Amendment violate the Basic
3. Structure of the Constitution by imposing reservation on unaided institutions?
Yes, it does. Imposing reservation on unaided institutions violates the Basic Structure by stripping
citizens of their fundamental right under Article 19(1)(g) to carry on an occupation. T.M.A. Pai and
Inamdar affirmed that the establishment and running of an educational institution falls under the
right to an occupation. The right to select students on the basis of merit is an essential feature of the
right to establish and run an unaided institution. Reservation is an unreasonable restriction that
infringes this right by destroying the autonomy and essence of an unaided institution. The effect of
the 93rd Amendment is such that Article 19 is abrogated, leaving the Basic Structure altered. To
restore the Basic Structure, I sever the 93rd Amendment's reference to "unaided" institutions.
See paras 132-182.
4. W hether the use of caste to identify SEBCs runs afoul of the casteless/classless society, in v
iolation of Secularism.
Sawhney I compels me to conclude that use of caste is valid.
It is said that if reservation in education is to stay, it should adhere to a basic tenet of Secularism: it
should not take caste into account. As long as caste is a criterion, we will never achieve a casteless
society. Exclusively economic criteria should be used. I urge the Government that for a period of ten
years caste and other factors such as occupation/income/property holdings or similar measures of
economic power may be taken into consideration and thereafter only economic criteria shouldAshoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

prevail; otherwise we would not be able to achieve our constitutional goal of casteless and classless
India.
See paras 194, 195, 231, 248, 251.
5. Are Articles 15(4) and 15(5) mutually contradictory, such that 15(5) is unconstitutional?
I am able to read them harmoniously.
See paras 252-256.
6. Does Article 15(5)'s exemption of minority institutions from the purview of reservation violate
Article 14 of the Constitution?
Given the inherent tension between Articles 29(2) and 30(1), I find that the overriding
constitutional goal of realizing a casteless/classless society should serve as a tie-breaker.
We will take a step in the wrong direction if minority institutions (even those that are aided) are
subject to reservation.
See paras 268-269.
7) Are the standards of review laid down by the U.S. Supreme Court applicable to our review of
affirmative action under Art 15(5) and similar provisions?
The principles enunciated by the American Supreme Court, such as, "Suspect Legislation" "Narrow
Tailoring" "Strict Scrutiny" and "Compelling State necessity" are not strictly applicable for
challenging the impugned legislation.
Cases decided by other countries are not binding but do have great persuasive value. Let the path to
our constitutional goals be enlightened by experience, learning, knowledge and wisdom from any
quarter. In the words of Rigveda, let noble thoughts come to us from every side.
See para 183.
8) With respect to OBC identification, was the Reservation Act's delegation of power to the Union
Government excessive?
It is not an excessive delegation. With respect to this issue, I agree with the reasoning of the Chief
Justice in his judgment.
9) Is the impugned legislation invalid as it fails to set a time-limit for caste-based reservation?
It is not invalid because it fails to set a time-limit.Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

See para 272.
10) At what point is a student no longer Educationally Backward and thus no longer eligible for
special provisions under 15(5)?
Once a candidate graduates from a university, the said candidate is educationally forward and is
ineligible for special benefits under Article 15(5) of the Constitution for post graduate and any
further studies thereafter.
See para 273.
11. Would it be reasonable to balance OBC reservation with societal interests by instituting OBC
cut-off marks that are slightly lower than that of the general category?
It is reasonable to balance reservation with other societal interests. To maintain standards of
excellence, cut off marks for OBCs should be set not more than 10 marks out of 100 below that of the
general category.
See paras 274-278.
These Writ Petitions and Contempt Petition are accordingly disposed of. In the facts and
circumstances, the parties are to bear their own costs.
..................................J. (Dalveer Bhandari) New Delhi;
April 10, 2008Ashoka Kumar Thakur vs Union Of India & Ors on 10 April, 2008

