Discussion On The Information Technology Bill, 1999. (Not
Concluded) on 15 May, 2000
Title: Discussion on the Information Technology Bill, 1999. (Not concluded) MR. SPEAKER: Now
the House will take up Item No.17, Information Technology Bill, 1999. The time recommended by
the BAC is four hours.
THE MINISTER OF PARLIAMENTARY AFFAIRS AND MINISTER OF INFORMATION
TECHNOLOGY (SHRI PRAMOD MAHAJAN): Sir, I beg to move:
"That the Bill to provide legal recognition for transactions carried out by means of
electronic data interchange and other means of electronic communication, commonly
referred to as "electronic commerce", which involve the use of alternatives to
paper-based methods of communication and storage of information, to facilitate
electronic filing of documents with the Government agencies and further to amend
the Indian Penal Code, the Indian Evidence Act, 1872, the Banker’s Book Evidence
Act, 1891 and the Reserve Bank of India Act, 1934 and for matters connected
therewith or incidental thereto, be taken into consideration. "
Sir, the Information Technology Bill, 1999 was introduced with a view to facilitate transactions
carried out by means of electronic data interchange. Transactions carried out using the media of
electronic communication are known as "electronic commerce" which is now used by organisations,
business consumers, both in private and public sector. It is, thus, necessary that this alternative to
paper-based method of communication receives a legal sanction. This Bill also provides for legal
recognition to the digital signatures and documents filed electronically. The enactment of this Bill
would enable finalisation of contracts and creation of rights and obligations through electronic
media.
       
The Bill also provides for the appointment of a controller to supervise the certifying authorities,
which would issue digital signature certificates. To prevent misuse of transactions in the electronic
medium the proposed legislation envisages appropriate punishment for the contravention of the
provisions.
Further, the Bill has suitable clauses to deal with tampering of computer source documents,
publishing information which is obscene in nature and issues relating to damage to computers,
computer systems through a system of appropriate penalties and punishment. The Bill also
facilitates electronic governance and enable the user acceptance of electronic records and digital
signatures in government offices. The Bill was introduced in the Lok Sabha on the 16th of December.
It was referred to the Standing Committee on Science and Technology, Environment and Forests. I
am grateful to the Chairman and Members of the Standing Committee because, they had several
sittings, and they examined the Bill and gave us very valuable suggestions. We have accepted almostDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

all the suggestions of the Standing Committee barring two and I will take only a minute or two to
explain about the suggestions which we did not accept.
The Standing Committee suggested that a Website or a portal should have a registration. We
thought that having a Website and a portal is done even by a ten year old kid these days and the
number goes into lakhs; the registering authority for that will unnecessarily create a hurdle for the
public at large. So, we did not accept this suggestion.
The second suggestion was that in an ordinary computer cyber café, a crime could be committed
through cyber café. So, any visitor who goes through the cyber café should be registered or what he
does should be registered. We thought that the intention was very right to stop this crime. But even
criminals can use an STD booth. But we do not have people going through a register whether he has
made a call, what he did, and so on. Similarly, there any many places where such crimes against
people are committed. But we do not keep a register. So, we thought we should trace out the crimes.
But such an action of keeping a register will create problems for the people. Because this cyber café
is a place where a person who cannot own a personal computer wants to take advantage of this
information technology; he should be able to use it.
These are the two areas where respectfully we disagreed with the Standing Committee’s
recommendations and the rest of all the suggestions have been incorporated in the form of
amendments.
Lastly, I would like to say only one thing. Information Technology for some people is some kind of a
scientific revolution. Information Technology for some is a means to get money which is very easy to
earn. Information Technology for India is a way to become a super power in the next l0 years. But if
you ask me as a lay man to define what is Information Technology, I can only say that Information
Technology is the fourth generation of human communication. When the human society came on
the earth the first way of communication between people was through gestures. When somebody
smiled we thought that he was happy. Second, the human race had brought up a spoken language.
Then we come to written language. Now we have reached towards digital language which is the
fourth generation of human communication. It is the faster one. The fastest fifth generation of
human communication is mind to mind communication and its intellectual property rights are with
the Almighty God; and nobody else has this communication. So, digital communication is the fourth
generation. So, when we moved from a spoken language to a written language, thousands of
text-books were written. We re-wrote everything. Similarly when we are moving from a written
language to a digital language we will have to re-write almost every piece of legislation in this
country.
I would like to recall, if you remember, on the very first day of the Budget session, the Government
wanted to submit the Subrahmanyam Committee Report on a CD-Rom.
It is because we did not have 2,000 pages copied into 800. But the Secretariat rightly so refused
because in Lok Sabha, we can only lay papers on the Table of the House and not electronically we
can lay things. So, accepting the electronic mail, everything, I do not want to go into all details, butDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

this being the fourth generation of communication, we have brought up the Information Technology
Bill. It is not that we have brought it up in a hurry. We have tried for one year. As I said in the
morning, we have redrafted it for 150 times. Then, we gave it to Parliament; we gave it to the people.
There was a debate in the public. Every debate was submitted to the Standing Committee. The
Standing Committee thought about it. Now, I think, it has become really very late, if we do not pass
it. The whole world is waiting for India to become a super power. That needs a legal framework.
I will request the House to discuss it fully as long as they want, but pass it and make the cyber laws
true after this Session.
Sir, with these few words, I would request the House to pass this Bill unanimously.
MR. SPEAKER: Motion moved:
"That the Bill to provide legal recognition for transactions carried out by means of
electronic data interchange and other means of electronic communication, commonly
referred to as "electronic commerce", which involve the use of alternatives to
paper-based methods of communication and storage of information, to facilitate
electronic filing of documents with the Government agencies and further to amend
the Indian Penal Code, the Indian Evidence Act, 1872, the Banker’s Book Evidence
Act, 1891, and the Reserve Bank of India Act, 1934 and for matters connected
therewith or incidental thereto, be taken into consideration."
SHRI SHIVRAJ V. PATIL (LATUR): Sir, the present century is going to be dominated by electronics,
genetics and informatics. We are all trying to have offices which need not use papers and
communication which would not have the instruments having chords or wires. Wireless
communication and paperless offices is the objective which the 21st century has fixed for itself. In
order to achieve these objectives, two things are needed to be done. One is the development of the
technology itself. But it is not sufficient to develop the technology. As is said by the hon. Minister,
we need a legal framework to use the technology, especially for governance, commerce and trade
and industry and in other areas also, we need a legal framework. Without legal framework, it may
not be possible for us to use the technology available.
The Government is trying to create the legal framework. This is the first step in that direction. In
this Act itself, they are touching the Indian Penal Code, the Indian Evidence Act, to some extent, the
Civil Procedure Code, Criminal Procedure Code and laws relating to banking and other areas. They
have also provided that many rules will be framed and many regulations will be made. They will be
used to see that this modern technology can be used in the Government offices and in E-Commerce.
I would like to submit that nobody can have objection to this kind of move. It has to be welcomed.
We have seen the Members speaking from different benches in the House and supporting the move
of the Government. But what they were saying was that this is a very important law and it should not
be passed in a hurry. If you wait for one or two months, it is not going to affect our entry into the
21st Century with this modern technology. Anything done in a hurry may create problems ratherDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

than facilitate using the new technology.
That is the kind of argument the Members were advancing from this side and from the other side
also.
It is true that the Bill was referred to the Standing Committee and the Standing Committee has
given the report. My understanding is that the reports of the Standing Committee are not brushed
aside, they are respectfully accepted and, to the extent possible, Government tries to implement the
recommendations made by the Standing Committee. In this case also, the Bill was referred to the
Standing Committee and it has come back from the Standing Committee to the Parliament and is
available to the Members. But the law is so complicated and is going to have long term implications.
The desire of the Members is to have a law which is without any defects or with as few defects as is
possible for human ingenuity to have a kind of law. That is why this suggestion was made here.
I know when the Delhi Rent Control Bill was passed in this House, what happened. At that time, I
had said, sitting in that Chair where you are sitting, Sir, that do not pass that law in a hurry, and it
was said on the floor of the House by the leaders of all parties, without any exception, that the law
could be passed because there was understanding between the parties and that Bill was acceptable
to all the parties. Then the Delhi Rent Control Bill was passed. It was passed in Rajya Sabha, it was
assented to by the President and up to this time, that law is not implemented. They have not issued
the notification to implement the law, to enforce the law. And why was it not done? Because there
are some provisions in the law to which certain sections of the society objected later or they
demonstrated. To my surprise, in one Session that law was passed within fifteen minutes in this
august House and in the second Session itself, on the first day, a proposal came that the law should
be scrapped and a new law should be made. That happened with respect to the Delhi Rent Control
Act. The Delhi Rent Control Act is applicable only to the city of Delhi. It is applicable to the owners
of the land and tenants of the land. It is not applicable to the citizens living in other parts of the
country or to the citizens or persons living outside the country. Here is a law which we are going to
pass which is going to be applicable to the entire country as such. Here is something which is being
done for the first time. There was the Rent Control Act in Delhi but we do not have any law of this
nature and yet we are trying to expedite it. I appreciate the enthusiasm and the desire of the hon.
Minister and the Government and of those who have faith and confidence in science and technology
to see that this is done without any loss of time. I appreciate it. For that, they should be respected.
But then we shall have to be visionary enough to pause for a minute and see what kind of
implications we are going to have with respect to this Bill. There are articles appearing in the
newspapers supporting this Bill and opposing this Bill. There are people in the country and outside
the country also who say that if you have a law of this kind, it is going to facilitate your using the
electronic media for governance and for commerce in the country and outside the country. But there
are people who are cautioning but they say that it is the most sophisticated technology and it can be
used. Anything which is very powerful can be used and misused. The use can be very beneficial and
misuse can be very dangerous also. That is why they are cautioning not to have a law which will
create problems.Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

Do not have a law which will limit the liberty available to the citizens in the country. These are two
contrary suggestions given and then we have to strike a balance between these two suggestions. On
the one hand it should be a facilitative law and on the other hand it should be a law which will
provide security to the transactions entered into by the Government and others outside. There is a
responsibility cast on the Members of this august House to look at it very carefully, in detail, in a
balanced manner and pass a law which can really help us for the next century to come.
Now, this is the kind of thing which is there and that is why we shall have to look at this law in a
careful manner. That is why a suggestion was made. I am repeating that. I understand, I appreciate
and I congratulate those who are responsible for trying to bring this kind of law here. At the same
time I want to caution that in hurry, you may not commit a mistake. If you commit a mistake, it
cannot be easily corrected. For the Government of India to wait for two days, two months or even for
two years is not dangerous; but to commit a mistake is dangerous because once you commit a
mistake, you cannot easily remove the impact of this mistake on the entire country as such. That is
why delay is acceptable in formulating a policy of this nature rather than committing a mistake
while formulating a policy for this kind of a thing. That is exactly why the Members have been saying
that : ‘Wait, pause and consider and apply your mind and then come to the House’.
This Bill is very important. The hon. Minister has, very rightly, said that the Government wanted to
lay the CD-ROM on Kargil Report on the Table of the House and it could not be done. This Bill is
going to be relevant for the Parliament also. Is there anything in the Bill which will facilitate
Parliament’s using the electronic equipment for facilitating the working in the Parliament? I am
sorry to say that I do not find anything in it. You shall have to do something more, probably you
shall have to write some rules if not the legal provision in consultation with the Parliament to
provide this kind of a facility. This is going to be applicable to the Judiciary. Many of the documents
will be produced in the courts of law and they have to attach legal importance to those documents.
This is certainly going to be useful to the Executive. This is a law which is relevant for the working of
the Executive, the Legislature and the Judiciary.
We have to understand the ambit of this law. It is relevant to the Executive, the Legislature and the
Judiciary. It is not only relevant to the Government but it is also relevant to the people outside also.
It is going to be relevant to those in commerce, in trade, in industry and in many other areas. That is
exactly why we shall have to see that this law is made in a proper manner.
The hon. Minister has explained as to what this law is intending to do. Firstly, they have given the
definition of the words and then they have created the law which can recognise the digital signature.
They have created the offences for which those - who tinker with the electronic transactions,
signature, contents and all those things – can be penalised. They have provided the machinery to
take cognizance, to investigate and to penalise those persons who are responsible for that. There is a
provision for adjudication also.
Now, look at the ambit of the law. Is it relevant to the Indian Penal Code, the Evidence Act, the
Criminal Procedure Code etc.? Is it relevant to the Executive, the Legislature and the Judiciary? Is it
relevant to commerce, trade or science? This is going to have an impact in all these areas also. ThatDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

is why we shall have to be very careful in framing this law.
Sir, Now I come to the Bill itself. My first objection is to the Title of the Bill itself. What does the
Title say? It says `The Information Technology Bill’. What is the Information Technology Bill? Is it
relevant to the development of the technology? Is it relevant to the distribution of the technology? Is
it relevant to using the technology or information technology? In fact, this Bill is relevant to using
the information technology in governance and commerce, but it has nothing to do with the
development of the technology as such. They are not providing the funds. They are not giving the
responsibility for development. They are not giving responsibility for distribution of this technology
to the users and things like that. But the Title gives a wrong connotation and I am misled when I
read the Title `The Information Technology Bill’. It could have been a different Title. It could have
conveyed that this Bill is trying to facilitate using the information technology. The Title itself of the
Bill is giving a wrong impression. Should we not have a different kind of Title? Should we stand on
prestige on the question of Title because this Bill is going to be there maybe for one hundred or more
than one hundred years? If the Title itself is conveying a wrong meaning to the reader of the Bill,
then, well, we shall have to look into it.
Sir, this Bill, in my opinion, is not comprehensive. My first objection to this Bill is that it is not
comprehensive because as is explained by the Minister and by myself also, it is not going to
facilitate, as it stands, in using this Bill for legislative purposes. It is not comprehensive. It is not
covering the Legislature. If it covers the Executive and the Judiciary, it could have covered the
Legislature also. It is not comprehensive and it has many lacunae. As far as private transactions are
concerned, it is not comprehensive. I am reading from page number 2. The relevant portion of
Clause 4 reads:
"Nothing in this Act shall apply to,- …..
(e) to any contract for the sale or conveyance of immovable property or any interest
in such property."
Now, you are allowing the moveable property to be covered by this Bill. This Bill will be relevant to
the transaction with respect to the moveable property, but it is not relevant to the immovable
property. You can have the electronic agreement in the computer about a car costing say Rs. 50,000
or, if it is a Mercedes car, Rs. 30 lakh, and that agreement can be made on the computer, but you are
not allowing the contract for the sale or conveyance of immovable property or any interest in such
property. It is applicable to the moveable property, but it is not applicable to the immovable
property. Why should it not cover immovable property? Supposing certain more provisions have to
be provided in the Act to cover the immovable property also, it could not have been beyond the
intelligence of all of us here to provide some provisions in the Act for this purpose also. But it is not.
That is why, I have said that it does not cover the Legislature, it does not cover the private activity
and so, it is not comprehensive. We are going with the impression that this Bill itself is not going to
be sufficient and we shall have to have many other laws made for this purpose. I do agree. I am not
disputing this fact. It is not possible to cover everything in one Bill, but, at least, the Bill should be
such that it covers the most important areas and then, it becomes as comprehensive as is possible,Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

but this Bill is not comprehensive.
I have shown as to how it is relevant to movable property, and as to how it is not relevant to
immovable property.
My second objection to this is that this Bill has some redundant provisions. There is an
apprehension in the minds of those who have framed this Bill `that it is necessary to provide certain
things in the Bill. Without providing those things in the Bill, there would be confusion and, that is
why, let us have those provisions in the Bill. Even though they look redundant, unnecessary, and yet,
you should have those things in the Bill." Now, this is a wrong kind of drafting and a wrong kind of
making the laws also. If there are accepted principles in the jurisprudence followed by India, if there
are certain decisions taken by the courts in India, it is not necessary for us always to have those
kinds of things. So, there are some redundancies, unnecessary things here. You can provide
redundancies to meet the accidents, but you cannot provide the redundancies in order to have a
usual working also. That kind of a thing is not necessary. Where are all those redundancies? I will
just read out only one Clause, which will indicate that it is redundant. Clause 57 (2) says:
"No appeal shall lie to the Cyber Appellate Tribunal from an order made by an
adjudicating officer with the consent of the parties."
Is it necessary to have this kind of a provision in the law? This is an established principle. If there is
a decision given by the judge of a court on the agreement between the parties, now there is no scope
for going against that kind of a decision unless a fraud is pleaded or something of that nature is
pleaded. But here, the law provides this thing. I do not know as to why this has been provided in this
Bill.
Then there are some confusing provisions in the Bill, and you have to clear those confusions. Which
are those confusing provisions? I will read Clause 58 (1). It says:
"The Cyber Appellate Tribunal shall not be bound by the procedure laid down by the
Code of Civil Procedure, 1908 but shall be guided by the principles of natural
justice…"
It seems as if the Code of Civil Procedure is not based on the principles of natural justice. In fact, it
provides a bigger area, and yet it is said here:
"…and, subject to the other provisions of this Act and of any rules, the Cyber
Appellate Tribunal shall have powers to regulate its own procedure including the
place at which it shall have its sittings."
Now, there are three things, that is, Code of Civil Procedure, then principles of natural justice, and
then the tribunals are allowed to have their own procedure.Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

I think, this is not happily worded; this is not a good enactment; this is not a good law. Then, Clause
58 (2) says:
"The Cyber Appellate Tribunal shall have, for the purposes of discharging their
functions under this Act, the same powers as are vested in a civil court under the
Code of Civil Procedure, 1908…"
At one place, it is not applicable; at another place, it is applicable. Then it says the same thing here
again.
"…while trying a suit, in respect of the following matters, namely:-"
I am not going into those details. Then, the Limitation Act provides the limitation, and it says:
"The provisions of the Limitation Act, 1963, shall, as far as may be, apply to an appeal
made to the Cyber Appellate Tribunal."
     
These are the provisions that are likely to create confusion. The law should simplify rather than
complicate the proceedings in the courts and practice outside the courts also. However, it appears
that this would be creating confusion. Using the words and phrases contrary to each other in one
section is likely to create confusion in the minds of people.
The intention of the Government appears to be that since we are in the 21st century things should
move faster; we should not waste even one day or even one month in decision-making; and if
decisions have to be given they should be given without any delay. However, the levels of authority
that have been created for adjudicating matters and giving decisions are likely to create delays. On
the one hand there is an authority to give the certificate; then there is a tribunal which can sit in
appeal against that decision; and that decision can then go to the High Court and to the Supreme
Court also. There are three appeals provided in total. Generally two appeals are provided, but here
three appeals are provided. If you provide three appeals, naturally there would be some people in
the society who would be interested in making use of this provision for delaying the implementation
of decisions taken by the authorities. I think it was not necessary to have these many levels. Well, I
can understand that the Government is trying to see that adjudication is done in a proper manner.
But this difficulty is there and we cannot overlook it also.
This Bill has one or two provisions that really go against the accepted principles of criminal
jurisprudence in the country. I am not a practising lawyer, Shri Jetley is there and probably he
would be able to shed better light on this provision. I say this on the basis of what I have studied and
understood. I am not saying that my friend is wrong and I am correct. But I do feel in my bones that
what I am thinking is not far off the mark principle wise, practically and from the viewpoint of
criminal jurisprudence also. What is it to which I am objecting? It is Clause 76. On page 21, Clause
76 reads, "No penalty imposed, or confiscation made under this Act shall prevent the imposition ofDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

any other punishment to which the person affected thereby is liable under any other law for the time
being in force." A person committing an offence will anyway be penalised under this law. This
section says that he can be penalised under some other law also. Is this not double jeopardy? Is this
allowed under the Constitution? A person can be punished only once for one offence. He cannot be
punished two times under this Act as well as under any other Act. This is my understanding of this
provision. Some friends have tried to explain to me that the Government may probably be correct. I
am not taking a very rigid stand on this. They have tried to tell me that if action `one’ is there and if
there is a law providing for a case against that action, action can be taken under some other law also.
Under the Indian Penal Code also action can be taken. If that is so, if that is the principle, why
should we have this kind of a provision? I do feel that for one action a person cannot be punished
twice. If he has to be punished under two laws, he can be punished in one court under the two laws.
It is not necessary that a case should be field against him under another law and he should be
punished a second time.
15.54 hours (Dr. Raghuvansh Prasad Singh in the Chair ) Why should he be punished a second time?
Even if technically this can be done, it should not be done. Let a man who has to be punished be
punished under all current laws in one go. He need not undergo the whole process two times. He
need not be asked to face two cases or more cases under different laws at different times. If there are
four or five different laws under which cases can be filed against a man, should we file one case
under one law, a second case under a second law later, and a third case under a third law after that,
and so on?
I have the strongest objection to this kind of provision. It is not facilitating but it is complicating. It
is not providing the liberty to the users of this new technology but they are going to create some
scare in the minds of the users of this technology. If they have committed the offence, let them be
punished once. Whatever punishment you want to impose, you impose that punishment but you
cannot impose the punishment in different courts under different laws at different times. Now, this
should not be done.
I have my objection to this. But let it be examined by the legal experts and let them come to the
conclusion.
Some people have criticised this law. They have said that ‘this is draconian’. Some people have given
the interview on television. Some people have written articles and all those things. Sir, I would not
go to the extent of saying that ‘it is draconian.’ But certain provisions of this law appear to be more
severe than they need be. And, if it is possible for us, on the one hand, our duty is to see that this
new technology is not misused and on the other hand, our duty is to see that new technology
utilisation is facilitated by this law rather than differences created.
I am referring to Clause 84 on page 22. This is an omnibus provision. It says:
" Where a person committing a contravention of any of the provisions of this Act or of
any rule, direction or order made thereunder is a company, every person who, at the
time the contravention was committed, was in charge of, and was responsible to, theDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

company for the conduct of business of the company as well as the company, shall be
( for the conduct of the business of the company and as well as the company) guilty of
the contravention and shall be liable to be proceeded against and punished
accordingly.’ And, the provision says:
‘Provided that nothing contained in this sub-section shall render any such person
liable to punishment if he proves that the contravention took place without his
knowledge or that he exercised all due diligence to prevent such contravention.’ "
Now, you are allowing the net to be spread so wide that anybody who is working in the company can
be covered. If the company has its head office here and the sub-offices at Bombay, Calcutta and
Bangalore and they are working, and if it is supposed that they are working under the guidance and
the supervision of the person sitting in Delhi and if any offence is committed there, you would be
easily able to catch that person who is sitting here and hold him responsible and proceed against
him. This provision says:
"But he has a right to prove that he was not in the know of what is happening there
and it was not done with his consent."
The onus is shifted from the prosecution to the guilty person.
Now, in my opinion, this is not happily worded. You can achieve the objective of not allowing a
person sitting at a distance and yet guiding this kind of activities are being too negligent in this
respect and yet you cannot have a provision of the law which can easily allow the investigator, the
police officer or any other offices for that matter, to catch hold of him and proceed against him and
prosecute him.
Now, this is going to create difficulties. Those who are in the business have already started saying
‘Why are you doing this?’ I saw one interview on television. Shri Arun Jaitley was there. He said:
‘Well, this provision is there in the Criminal Procedure Code. If it is here, why do you bother about
it?’ Well, if the Criminal Procedure Code is there, then why do you have it here? One sentence saying
that the Criminal Procedure Code will apply to it, it is enough. But you are doing it, ‘every person
responsible for the company, for the conduct of the business of the company as well as company.’
Now, these are the words which create some apprehensions in the minds of those who are in the
business.
16.00 hrs. Rather than facilitating, they are going to create scare in the minds of the people, again
utilising this kind of provision.
I would simply request that let it be carefully examined and if you think it could be there, you can
take a decision. But in my understanding, it is a little more severe even than what is required to be in
the law and it need not be there. We can dispense with it or you can word in such a fashion that the
severity of this law is removed.Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

There are many provisions here which go to indicate that because this is a new area, and because the
Government is entering into the area and taking the country also into a new area and they feel that
there are many unchartered areas where caution is required, they have retained the discretion to
change the laws as and when it is necessary or to give interpretation of the law. That is provided in
clause 85:
"If any difficulty arises in giving effect to the provisions of this Act, the Central
Government may, by order published in the Official Gazette, make such provisions
not inconsistent with the provisions of this Act as appear to it to be necessary or
expedient for removing the difficulty."
Probably by having this provision, the executive is trying to take the authority to change what is
legislative. It is an enabling provision. In some laws, this kind of provision is there. Even in the
Constitution, sometimes this kind of provision is there. But what does it indicate? It indicates that it
is a new area. It indicates that there are likely to be situations in which it would be necessary for the
Government to issue notifications to give explanations as to how this law can be implemented. That
is what we find in other provisions also. The rule-making provision, clause 87 (3) reads as follows:
"Every notification by the Central Government under Clause (f) of sub-Section (4) of
Section 1 and every rule shall be placed as soon as it may be after it is made, before
each House of Parliament, while it is in Session, for a total period of 30 days which
may be comprised in one Session or in two or more successive Sessions and if before
the expiry of the Session , immediately following the Session or the successive
Sessions aforesaid, both Houses agree in making any modification in the regulation
or both the Houses agree that the regulation should not be made, the regulation shall
thereafter have effect only in such modified form or be of no effect, as the case may
be; so, however, that any such modification or annulment shall be without prejudice
to the validity of anything previously done under that regulation. "
The same kind of provision is given in Clause 88 (3) also. There are three places where the framers
of the Bill are indicating that there are areas in which they shall have to keep on looking at these
provisions and interpret the law in a different fashion. This caution is good because this is new area,
but at the same time, if you are so cautious with respect to the rule, should we not to be cautious
with respect to the legislation or the statute itself? Naturally the details are given in the rules and
probably there is scope for changing the details given in the rules. But the law is more important and
any rule which goes against the law itself cannot mend that situation.
That is why we shall have to be very careful with respect to this.
I am one of those persons who had the good fortune of being in the company of the scientists and
being in the Ministry of Science and Technology for the longest period of time, they say. I appreciate
the efforts done to modernise in every respect – administration, production, creation of knowledge
and coping up with the futuristic things. We appreciate that. But at the same time when we are
dealing with these kinds of areas, it would be better to delay rather than commit a mistake. TheDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

Indian Penal Code and the Indian Evidence Act are there. They are the products of the thinking of
centuries. They are drafted in such a fashion. Even the Constitution of India is very happily drafted
and very clearly drafted that there is very little ambiguity in reading the provisions of the
Constitution. The Indian Penal Code and the Indian Evidence Act and even the Civil Procedure Code
and the Criminal Procedure Code are all happily drafted. My objection is – and it should not be
taken amiss – to the shape and to the lack of elegance. The law is not elegant. The law is not happily
worded. The law is creating confusion. It is not comprehensive. It is at places ambiguous. That is
why I am requesting that though this should be done, it should be done in an elegant manner. Let it
be done but let it be done in a manner that this would continue for years to come, at least in
substance if not in all the great details. At least in substance, it should remain there and it is not
going to be removed from the statute book very easily. Let it be done in a manner that would show
that we are entering a new century and a new area of activity in an elegant manner. My objection is
to that and not to the substance.
My objection is not to the motive or the intention with which this Bill has been brought. My
objection is to the form in which it has been brought than to the substance. That is why, if you are
doing such a big thing, to which when everybody is agreeing and if it has very wide implications that
would be valid for years, why do you not do it a little more carefully, a little more slowly and a little
more correctly? That is my submission.
.   () :  ,           
   ¡ ¢ £ ¢   ⁄  ¥ƒ §¤     
'    £“ ¥    ¡§ £   ¥« ¢,  
‹     § ¢,  ›‹ﬁ §ﬁ    ﬂﬁ °
    ¢,  '– †  ° §  ⁄   ¢¤  
°  – ¢,  ‡-› ¢,  ‡-¢ ¢,         ¢ 
  · °     ¢   ¡   – ¢¤   
  ¢    µ·  ﬂ  '   ¢,    ¢¤
    ·  ﬂ    ¢,   ¡ ¢,   ﬂ
¢, ¥    ¢    ¢   ¢,    - ﬁ
¢,         ¡ ¢, ¥   ¶ ¡‡ ¢¤
      ‡.ﬁ.  –  ¢,   –  ¢ , ¢ ,
 –   ¢¤  ¶  ﬁﬁ       ¡ •· ¡ ¢¤
ﬁﬁ      ¢    «  ¢, ¥  ° £
‹   °  ƒ  ¢¤     «, ‚',
  ¢,   ¶    ¢, ›    ¡ 
⁄·   ¡‡ ¢,   „    ¡¤   ¡   '  ﬁ 
°  ‡ ¢, ¥ ﬂ¢ﬁ ﬁ   ¡ ﬂ ¢ £ ” ' ¢     
  ¡  »     – ¢ ⁄ £“  ¡ 
'– †      ¢¤    ¢   '  ¢
¢,       ¢ £     ‹›'      ¢ £
  †‹¢'     ¢    – ¢¤  ›‹ﬁ
ﬂﬁ ¢,  ›§ﬁ     ¢ £   ﬁ¡ ,Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

‹'¡   ﬁ    ¢      ¢¤  
¢    ⁄  '    ¢, °  ¡     ¡ 
¡,     ¥ · ¢¤ ¢     '  § 
¥ '› ‡ ¢¤     •   –  ¢  ¢   ﬁ¢ 
     ‡ ¶   ¢¤ »     – ¢¤   
  –ﬂ ⁄¤ ¢  – §  ‡  ‹›ﬂ  ¤ It is liable to change
and it is liable to get amended.  ﬂ      ﬂ' ﬁ ¡, ¥ ‡
  ﬂ¡¤  ¡ ¢       ﬂ¡, ¥ °ﬁ
¡, ¥  '…  ﬂ¡¤      ¡ ﬁ¢ ¥ƒ ¢, 
›    ¢   –ﬂ¤      , '    
 £ '   ›ﬂ ﬁ ¢,   · §„   ¢,   
  ⁄ ¢,     §„     ¢, ¥ 
     ¢¤  ‹¢'    ¡'   ¢,   ›
ﬂ   ¡¡¤ '– †   · › ' ¢  °
 · §„ ¶‡  ¢ £ °¡ • •§ﬁ¡  ¡      ‹  
 ¢, °ﬁ   ¢¤  – ¢      ¡ ¢,  ,
«, '        £  ﬂ       
¶ ¢,    ¡  ¢ £     ›    ¢ﬁ ¢, 
°·–, « ¢, ¥ §”    ¡¤
  «        ﬂ ⁄,     ¡  ⁄, ¥ §
  ﬂ ' ¡¤  « ﬁ ¥     ¢¤ 
– ¢    «  «     ﬂ¤     «  
'     ¢,  § ¢ £ '– †    «   
  ' ¡ ‰“¡¤  ‹ﬁ¢     ¶     ¢ -
 ﬁ, ﬁ £   ¾¤          ¶ ¶ ¢
£ '    ¡  ¢¤      ¡, ¥  '  ﬂ °–•
¡, „ ¡¤
  '  ⁄ ¢ °    ﬂ,   '  §      
«    ¤
SHRI RUPCHAND PAL (HOOGLY): Sir, this long overdue Bill has come before us. While
supporting this Bill, I cannot but make two observations even at the outset. Why is this Government
in a hurry to bring this legal framework which has far-reaching consequences for our country in
several areas? It would have consequences in every activity of the Indian society. I wonder what
could be the reason for this hurry. More time could have been given to go into the nitty-gritty of the
Bill. This Bill would ultimately make many of our existing laws, like Indian Evidence Act, RBI Act,
Banking Regulations Act etc., cyber oriented. Till today, if I am not wrong, only ten countries have
come out with IT laws. Of them, only three have come out with comprehensive legislation. The
current Bill is based on the Malaysian model. Countries like, the US, Canada and the European
Union have brought out necessary amendments in the existing laws. Some countries have prepared
a core legal framework which will go on adjusting itself with the development of the technology. This
is because Information Technology is radically different from other technologies. There is a raceDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

between the development of legislative process and the Information Technology. On many an
occasion, we found that Information Technology has out paced the legislative process. The pace is so
fast and radical that it is becoming difficult for many countries to cope with the situation.
Many provisions are there. For example, the digital signatures. It is one of the key elements in the
Bill that will radically change the overall situation in all business, banking and commercial
transactions for all time to come. The digital technology is a technology based on applied
mathematics. To put things simply, it is an Asymmetric Eneryption System with a private key and a
public key. The private key will be known to the owner only. It will be his or her own secret and the
public key will be known to others so that by the public key, they can authenticate the original
signatures. Here, a point has come, and that is being practised the world over. We are today using
the digital technology for the identification, authentication and verification of the signatures and to
ensure security to the signatures. It may be that with the development of technology, the countries
concerned will have to redefine the definition of digital signatures. This is a suggestion which I think
has been made by NASSCOM also that we can have a Core-legal framework and let it be left there so
that it can go on adjusting itself with the development of the technology.
I am coming to the other part of Net use. In e-Commerce, the major concern is the security concern.
I find that there are people in India who till today do not have enough faith in the security of the
system. The world over, there are systems which can intrude at their will into any communication
system. Let me refer to one such system by which it is said that the fixing of matches and the
identification of cell phone call was done. This is an old technology. Editorials have come in the
background of Sankhya vahini. The technology is called as the Echelon technology. The emerging
material on interception capability of the United States makes it clear what the future might hold.
The recently exposed project Echelon for example allows the US to copy almost every piece of
electronic communication – FAX transmission, E-mail message, Mobile phone call or other kind of
telephone conversation -world wide. It so happened that, the United States targeted France to have
some commercial secret in their own interest. The subject of growing controversy reveals that
Echelon was used by the US for commercial espionage directed at its North Atlantic Treaty
Organisation allies, notably France. What did they do? They collected all information and picked up
through the Echelon system whatever they required. So, there is nothing foolproof in e-Commerce
in the Internet system. That is the paradox of the situation. It has come out after the Love Bug.
Philippines have identified some lady teacher who has submitted the thesis, alongwith student they
had put certain things. Since these students and these people could not afford to have enough hours
in the Internet because of financial constraints, they wanted to enter into other Internet account and
inadvertently, unintentionally they had been damaging the system. The latest damage might have
caused - in different systems in different ways – taken together to the tune of 10 billion dollars. So,
there is nothing like anti-virus system, fire-walling, whatever you call it, which can ensure complete
security in any transaction worth the name.
A suggestion has come about the certifying authority in the digital signatures.
Who will certify the certifier? It has happened that the certifier’s authority has also been
impersonified. The identity of the certifier itself has been camouflaged. There is a provision here butDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

I do not think it is adequate. If you go into different Clauses, Sections the inadequacies, the
infirmities can be noticed in the proposed law. Let me tell you about the issue of convergence.
Today, in the post-PC era - the computer, the Internet, the Broadcasting system, the Telecom system
– the convergence of technology is the most noticeable feature. But, here in our Government, you
will find one Minister for Information and Technology, another Minister for Information and
Broadcasting and yet another for Communications, having their own areas of operation.
THE MINISTER OF PARLIAMENTARY AFFAIRS AND MINISTER OF INFORMATION
TECHNOLOGY (SHRI PRAMOD MAHAJAN): But all are on the same bench.
SHRI RUPCHAND PAL : Yes, on one bench but not with one mind.
SHRI PRAMOD MAHAJAN: Yes, we are.
SHRI RUPCHAND PAL : I will talk about that later on.
Even at Delhi, in a Cell phone with wireless application protocol, the individual can act through his
own computer. Convergence is such that, cable TVs which are larger in number than PCs in the
country, can provide more Internet connections; from basic to cell phone, mobile to basic and so on
telephone connections are available. In such a way, there is one authority in view of convergence of
technologies in the developed countries of the world, Federal Commission in the United States and
OFTEL in UK. In our country, even after this fast convergence of technology, we have miserably
failed to take into account this element of convergence. I know, the Minister will reply saying that a
Sub-group has been set up which will go into the details of the Indian Telegraph Act, 1885 and also
the proposed Broadcasting Bill.
I know, the Minister will say that DTH aspect or the DTH potential will be taken care of by the
Broadcasting Bill. I know it will be said that the Indian Telegraphs Act 1885 will be appropriately
amended to take cognizance of this particular situation. But my query is, when this unique feature of
IT is contributing to every aspect of human development, human society, why are you failing to have
a comprehensive view of the whole situation?
Why are you failing to have a comprehensive view of the situation? Of course even then it will be
tentative legislation. There is nothing like finality in the fast emerging situation. So, many developed
countries of the world are building up a Core Legal Framework and adjusting the developments as
and when situations are arising like that.
May I ask the hon. Minister about the definition of information? Does it contain voice? Sound is
included. I know the Minister will say that it will take care of the element of "voice" as information
as a part of the definition. A Committee has been set up under the leadership of the eminent jurist
Shri Nariman who is looking into it. It may be true. But questions are being asked. I am not asking
this question. You are so liberal in many things. Why internet telephones are not being allowed? You
know about the Echelon Technology. You know what harm the Sankhya Vahini can cause to ourDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

security. You know in the Kargil war how we had to behave, how Pakistan intercepted our signals,
how we had to change our language and tackle the coding-decoding problem.
Even in the Harshad Mehta"s case what happened? Sir, you also have raised this issue. The decoding
of Harshad Mehta"s floopy dises took several months. It happened long back. Now things have
changed. Even in India cases are coming and we are not in a position to control the situation. Even
after we set up the officer Controller, even after we set up the authority to authenticate and certify
digital signatures, even after we set up the infrastructure proposed to take care of the security
concerns, I do not think this particular Bill is providing adequate safeguards to what may happen.
Moreover, the Government is in a hurry. Now our e-Commerce is earning to the tune of Rs.300
crores. Maybe, after a rough calculation we may go up to Rs.10,000 crore by 2002. We are waxing
eloquent about e-Commerce and new economy. But our hon. Finance Minister himself is saying that
in the Indian situation do not talk too much about Mouse-and Click. The Brick and Mortar is equally
important. Rather, the Plough and Bull in the Indian situation are more important than
Mouse-Click. We have seen that. The latest Report of the Group set up by the Prime Minister led by
the great friends of the Finance Minister and the Government, Shri Rahul Bajaj and Shri Sanjeev
Goenka have come up with a Report about the importance of the Manufacturing sector in the Indian
situation. The information Technology by itself cannot contribute to the growth of our Economy and
the uncertainties involved in this New Economy is being witnessed by every one. Can we mark what
is happening? What goes by the name of Infotech, Communication and Entertainment - the latest
coinage by the journalists is ICE in the share market ?
It is being said that when Nasdaq catches cold, Bombay Stock Exchange sneezes. We have become
so dependent. American President Bill Clinton is giving us a certificate that 40 per cent of the Silicon
Valley is accounted for by the Indians. The Chief Minister of Andhra Pradesh is very happy that he
has got a certificate from the American President and that the American President can be given a
driving licence from the internet. What is not possible? What is the position of India in the internet
use index in the world? It is miserable. Sweden is number-one. We are just one step above Pakistan.
This is very natural in a country with so much of poverty and with so much of illiteracy. It is not
possible that we bring in internet and people will rush for it. Only some upper-class people, upper
middle-class people and the elite will have access to internet facilities.
Technology can build a nation and contribute to the human development where we are miserably
lacking. We are distressed to know that Pakistan is boasting that it is above us in human
development and our External Affairs Ministry has to admit it. Are you not ashamed of it? In terms
of literacy figure, infant mortality figure, food availability figure, per capita income figure and GNP
figure, Pakistan is boasting that it has surpassed us. Sri Lanka is boasting that in many areas it has
surpassed us.
Computer can be used for the welfare of the Indian society and for human development. This was
the recommendation made by the Information Technology Action Plan.
 Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

What does it say? It says that computer network will ipso facto include networks such as careers in
distance learning - satellite based, optical fibre cable based and other mechanism based - or
Education-To-Home, instead of Direct-To- Home. I am just addressing Shri Arun Jaitley. Instead of
showing so much enthusiasm about Direct-To-Home, why not show enthusiasm about your own
recommendation about ETH service or Education-To-Community-Centres, ETCC? You are ignoring
it. You are more concerned about digital signature. I do not say that it is not necessary. I do not say
this in the days of globalisation - technological globalisation, commercial globalisation and
globalisation of trade. But how much do we account for in global trade? It is less than half a per cent.
They say they are pressurising that in e-Commerce you should not impose any duty. It is not just
pressure from the strong partners of WTO. This is the claim being made by the Indian
entrepreneurs also. Even the CVC Chairman Shri N. Vittal has advocated that no tax should be
imposed on e-Commerce for ten years. In this age of digital revolution, everyday the technology is
breaking the barriers to a borderless State and a paperless society. The IT has become the chief
determinant to economic, social and educational progress. The society is coming to be known as
knowledge-based. We have to think seriously as to how India can use this technology in its favour.
Someone has said that we can become an IT power. Someone else has said that we do have the skill
to dominate the world information technology. That is true. At the same time, we shall have to take
care as to how this information technology can be integrated to the human development and to our
existing manufacturing sector. How can we contribute to the overall growth of the economy by this
unique instrument of information technology? We are lagging behind there.
There are certain provisions of the Bill which are of a very very serious nature.
I am making a mention of only a few of them. For example, there is a provision that the Police can
search any house, any person or any household without a warrant.
You know from the history of several Acts in this country how the Police has misused not only in the
case of TADA and MISA, but also in several such cases under the Code of Criminal Procedure or the
IPC. I think that Clause 79 is a serious clause. It is a disturbing one and agitating the mind of every
peace-loving citizen, every Indian who is interested in the growth and developemnt of this country,
and in the progress of this country. This is what is written there:
"A Police officer may enter any public place and search and arrest without warrant
any person found therein who is reasonably suspect."
It is on the basis of suspicion only. This should be changed. I have given an amendment.
About Clause 78, there is a serious reservation of the performing artistes of several music bodies and
others that under Clause 78, the Network Service Providers will not be liable in certain cases. If it is
within his knowledge, the NSP will be liable. If it is outside his knowledge, then what happens in
other parts of the world?Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

SHRI PRAMOD MAHAJAN: Sir, I am grateful to Shri Rupchand Pal that he has yielded. There is
much talk about Clause 79 that this law has become draconian and that you are giving a Police
officer some right which was never given in this country under any law. So, I would like to draw the
attention to Clause 165 of the Code of Criminal Procedure, 1973 – search by a Police officer. I do not
want to read the entire Clause. I can only say that Clauses 165 and 79 are almost identical. So, today,
the law exists in this country to go into anybody’s house. We are objecting it under this law. The
difference between the two is that under Clause 165, even a constable can enter into anybody’s house
in this country. But under Clause 79, we have raised the level because we think that this is a cyber
crime. When somebody has to search something like a cyber crime, it cannot be at a lower level of a
constable or a Police officer.
Actually, the Police Department which represented before the Standing Committee insisted that
they should be given the right because in every law they have given this kind of a right to search if
they suspect some kind of a crime is likely to happen.
I am grateful to the Standing committee. They rejected this demand of policing the people and
harassing them. It is a unanimous recommendation. They have said that there is nothing wrong in
Clause 79. On the contrary, in Clause 79, we have raised the level of a search officer to the level of a
Deputy Superintendent of Police. If you see the FERA, it has a similar provision to the extent of
hundred per cent. So, for an ordinary citizen, a constable can go into a house and create a problem.
That is the law of the country. Now, these people have computers. So, we have put them at a higher
pedestal of a DSP. Still if they are not satisfied with the DSP, I really do not know whether they
mean that an Inspector-General should go to their home and make a search. So, we think that it is a
cyber crime. In the next century, the crimes are likely to be committed at a very high level. I think,
there is nothing draconian in what we have provided for.
I cannot even describe what the criminal procedure is. I do not want to score a political point,
otherwise, I would have said that the West Bengal Government can amend the Criminal Procedure
Code and ban the police officers for going and searching the houses. But we never do this. This is a
canard which is spread by the Press that we are bringing something draconian. It is not true. On the
contrary, we have raised the level of a search officer to that of a DSP, because we thought that a
Constable, with a Danda, may not understand what Cyber crime is. We hope that a DSP level officer
must be a computer-savvy person and I do not think, there is anything wrong or harassing in this
column as far as this is concerned.
SHRI J.S. BRAR (FARIDKOT): Sir, the point is that a person should be properly trained. It is not a
question of a DSP or SP, it is the question of training. Even if a Sub-Inspector is trained and if he has
knowledge of a computer, then he can also do that job. What is important is training and not the
level of an officer.
SHRI PRAMOD MAHAJAN: I totally agree. I think, Shri Shivraj Patil has already said about the
elegance of drafting. If I draft that `a police officer who knows computers will search", then
everybody would say what kind of drafting it is? So, we presume that a DSP level officer will be
computer savvy and the Standing Committee has already recommended that the officers in policeDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

should be trained, but I cannot put a precondition that a person who knows computer will go,
because it will create more problems than solving it. But I entirely agree with the sentiments that the
hon. Member has expressed.
SHRI RUPCHAND PAL : Sir, here lies the problem. This is the very reason for which we had said
that this important Bill needs further and deep consideration and some more time is required. So,
heavens will not fall if this Bill is taken up in the Monsoon Session. Sir, here the very nature of the
crimes is different, without a warrant, one can enter into someone"s house. What is the nature of the
crime? I am not going into what happened in the `Chernobyl Virus" and the latest `I Love You"
Virus and all these things. Will a police officer be able to identify the tampering of computer source
documents by entering the premises? Will he use his own computer at his home for committing
electronic forgery? And what will you do? You will seize that hardware physically along with that
person. Sir, there lies the difficulty.
Sir, there is a miserable failure to understand the nature of the crime, the technology and how these
are being taken care of by even the developed countries of the world. I am not going into the uses of
hacking. I could have raised that. Even the most powerful countries of the world are posing that they
are helpless in such situations.
So, this tampering, breach of confidentiality, publishing forged digitally produced certificates,
incidence of forged electronic records, alteration of records, frauds, forgery, falsification, etc. are
various prevalent crimes. I can go on naming them. Sir, Trojan Horse, Trap Doors, Logic Bombs,
Data Diddling, Scavenging Impersonation, Wire Tapping, Data Leakage, Salami Techniques, I.P.
Pooling, Simulation, Modelling, etc. are the names of some such crimes which have been detected.
These crimes are of such nature and we know from our experience that this is not, at all, going to
control or contain the Cyber Crime. It will only be another draconian handle at the hands of the
Police.
So, my demand is that, as I have given the amendment, it should be rewritten and `Without
warrant" should be removed because of the nature of technology and some sub-Clause should be
added. This was a suggestion given by very important quarters, as far as I could understand, before
the Standing Committee.
 
SHRI PRAMOD MAHAJAN: The Cyber crime is the fastest crime a person can commit than a
normal crime. It takes little time to stab somebody, but it takes a second to create cyber crime which
will not be traced in thirty countries where it will fly.
If you go to the court and ask for a warrant, by that time everything will be over, and the crime will
be passed on to 125 countries, which will never be able to deal with them. That is why, actually we
need it in other countries.Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

SHRI RUPCHAND PAL : One Clause can be added. This is not my suggestion. This was the
suggestion given by an important person before the Standing Committee. The suggestion was that
because of the very nature of this technology, in case of its misuse, there should be a suitable
punishment to the offending officer.
I am coming to Clause 78. Clause 78 says that the network service provider will not be liable if some
offence is not committed within his knowledge. There lies the difference. In the US, there is one
Clause, suitably amended clause, that is DMCA. In the European Union, there is a directive that the
offensive materials should be instantly removed even before, whether it is within his knowledge or
without his knowledge, as soon as it comes to his knowledge.
Now, Sir, here there is a very important thing. Suppose someone has committed an offence under
violation of Section 51 of the Copyright Act or the Intellectual Property Right, and if that offender
takes shelter under this particular Clause 78, then what will happen? So, there is a demand that this
Clause should be suitably changed, amended, and re-drafted to ensure protection of the performing
artists and their products.
Sir, I have some more suggestions to make. One is about the Tribunal. The Tribunal is proposed to
be set up. There is no time-frame. They take their own time and go on discussing things taking their
own time. My suggestion is that in the case of the Tribunal, there should be a time-frame by which
time they must give their opinion or judgement or whatever you call it. The qualifications,
experience, and Terms and Conditions of the Service of the Controller, Deputy-Controller, and
Assistant Controller are given under Section 17. Now, there are suggestions made by the Standing
Committee. Some of them have been accepted by the hon. Minister, which can be seen. I believe that
the Appellate Tribunal is being made a single member body on the lines of SEBI. It is stated that he
should be a judge of the High Court, he should be a member of the Indian Legal Service but there
must be a provision that he should be such a person with knowledge of information technology --
that should be mentioned here -- so that the Presiding Officer can take care of it.
Sir, this Bill is inadequate and suffers from a large number of infirmities. It is not comprehensive. It
is not going to help us in a big way. In a developing situation, the information technology could be
used by us and our interest should be protected by a comprehensive measure, which has not been
done. So many issues have not at all been addressed to.
MR. CHAIRMAN : Please conclude now.
SHRI RUPCHAND PAL : Sir, I am concluding. My last point is that this Ministry should be merged.
There should be one authority. There should be one body to take care of it.
That is the suggestion given by a very important leader of the ruling NDA which is being practised
elsewhere and that too to just accommodate some individuals… (Interruptions)
MR. CHAIRMAN : Are you not concluding?Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

SHRI RUPCHAND PAL : Sir, I am concluding.
I am supporting the Bill. I am supporting the Bill with serious reservation that this should go to the
Select Committee for further discussion and for enriching several provisions of the Bill.
 
SHRI M.V.V.S. MURTHI (VISAKHAPATNAM): Mr. Chairman, Sir, this Information Technology
Bill is a Bill of speed. It is a Bill for high wire transfer of business.
SHRI ALI MOHD. NAIK (ANANTNAG): Do you want to take the speed out of it?
SHRI M.V.V.S. MURTHI : The Information Technology Bill 1999 was introduced in December,
1999. Is this time not sufficient to go through the Bill and suggest certain things which are needed, if
need be, in this Act? It is not right or proper to say that heavens are not going to fall if this Bill is not
made into an Act in this Session. It is not true. The world is moving at a very high speed. As far back
as in 1996, the United Nations had recommended to its member States that the model law that has
been suggested is to be passed by all the member countries at the earliest. Four years have gone.
India has not moved. We look as if we are moving. Still, in certain ways we are putting a brake. It is
not that everybody is not interested. Everybody in this House is interested in the passing of this Bill
at the earliest so as to catch up with the rest of the world. It is not that the Bill has been only
partially accepted as Shri Rupchand Pal has said that the developed nations only have incorporated
this. A country like Ghana has also moved in this direction and passed the Bill. Malaysia and Ghana
are also developing nations. They are passing these laws in the best interests of their countries, and
they are looking forward to merge with other countries’ trade and commerce.
Our country, at the earliest, also has to make electronic arrangement to do e-commerce with World
Trade Organization which is creating multi-trade deals. Unless we move at the earliest to move with
the other countries of the World Trade Organization, we will be failing in our deals. It is our duty to
pass this Information Technology Bill at the earliest, make it into an Act, and recognise the laws of
electronic records and digital signatures.
As accepted by everybody, these cyber laws are pro-business laws. They accelerate the business. The
e-Commerce will accelerate the business. The business is done at the speed of the thought. Business
done through information technology is at the speed of the thought. The business has to be done
online. Singapore is moving in this direction. From 2001 onwards, that country would be making all
the Government tenders on e-Commerce, online.
17.00 hrs. Unless you also move with these electronic transactions you will be left behind. Our
country has contributed so many electronic experts, e-commerce experts, and there are many people
who constitute many experts around the world now; there are many Indian electronic graduates.
You take out any electronic graduate working in any country, one in two is an Indian and one in four
is from Andhra Pradesh. Among those who are going from this country, Andhra Pradesh is also
moving forward in this direction to put up a network or to organise all the villages in theDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

developmental work in the digital records. So, unless this Bill is passed we cannot officialise. In our
country we cannot recognise any transaction through a computer unless this Bill is passed. We will
be left behind if another three months time is taken.
And somebody has stated that there are certain inaccuracies, inconsistencies in this Bill. But they
are not of a very major nature, if at all there may be. We can amend the Act, if need be. So many Acts
we are amending. We have passed the Ninetieth Amendment to our Constitution recently. Why is
not any amendment in this Act, if required? We can take action in the next Session or the next one
because it is a developing business. The rest of the world should not think that India is lagging
behind. We can boast that our scientists and scientific personnel are the best in the world, next to
the USA, there are sufficient people to handle the whole system. In other countries Indians are
handling this. Why should we be afraid of? Absolutely, there is no fear that it is going to punish very
harshly.
In other cases as rightly said, even a Police constable can take you to the Police station and question.
But any officer not less than the rank of a Deputy Superintendent of Police can question you. This is
a sufficient safeguard. He is a responsible man. In the society also he is a responsible Police Officer.
A Dy.S.P. has power under Section 79. This is a conservative law, I should say, when compared to
the other laws. Several leading advocates are also here.
SHRI ALI MOHD. NAIK : The Policeman can take one away.
SHRI M.V.V.S. MURTHI : There are punitive laws as I can see, laws of reasonable nature and
reasonable protections are there. Those who are using these computer systems, have e-commerce
and digital signatures.
Andhra Pradesh today has moved ahead in getting all the villages, the schools and the transfer of
technology to various markets. These things we have to incorporate with other systems in other
countries. Unless we pass this Bill we cannot incorporate. The others will not be in a position to
supply the required information. So, this is a very urgent matter of a developing nature for
development-oriented governments.
We should pass this Bill without hesitation so that our country also can move along with other
countries and prosper in the field of E-Commerce. Otherwise, we will be left behind and we will be
rated as not progressive and our country may not be in a position to participate in the world trade.
Sir, with these few words, I support this Bill. This Bill should be passed in this Session.
------------
 
17.06 hrs. INFORMATION TECHNOLOGY BILL - Contd.Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

1706 hours SHRI P.H. PANDIYAN (TIRUNELVELI): Mr. Chairman, Sir, I thank you for giving me
this opportunity to express my views on the Information Technology Bill, 1999.
Sir, I heard the suggestions of my colleagues here. By these cyber laws you have manufactured many
crimes. Crime is the product of law. Shri Arun Jaitely may know about it. If there are more laws,
more crimes will be there; if there are fewer laws, less crimes will be there. Here Sections 167, 172,
173, 175, 192, 204, 463, 464, 466, 468, 469, 470, 476, 477(a) of the Criminal Procedure Code up to
falsification of records are important. The different classes of persons who are adapted to these
clauses or are likely to be adapted to these cyber laws are going to be entangled in these crimes.
Clause 79 says:
"The police also may enter into a public place and search and arrest without warrant
any person found therein who is reasonably suspected or having committed or of
committing or of being about to commit any offence under this Act. "
When an attempt is also made an offence, without specifying it as an offence, Section 511 of the
Indian Penal Code is already there to cover it. Then, I divide it into two parts – crimes and trial. You
have defined crimes under so many sections. Cyber Law Tribunal, the Appellate Tribunal where you
have stated, ` a person shall not be qualified for an appointment as a Presiding Officer of a Cyber
Appellate Tribunal unless he has been qualified to be a High Court Judge. It goes 180 degrees
opposite to clause 62. Any aggrieved person of any decision or order of Cyber Appellate Tribunal
might file an appeal to the High Court. If you appoint the High Court Judge, he has to file an appeal
to another High Court judge. It may be that in a recent judgment in the State Administrative
Tribunal wherein the High Court has jurisdiction was recently pronounced. Prior to that, High Court
judge was appointed to preside over the Special Administrative Tribunal where an appeal lies to the
Supreme Court. Now, by virtue of judicial pronouncements, an appeal is lying to the local High
Court, but here clause 50 is diametrically opposite to clause 62.
Then, they have taken away the Civil Court jurisdiction where they have said that the Civil
Procedure Code shall apply. By incorporating Clause 61, they cannot take away the jurisdiction.
Article 226 is already there. Even if they take away the jurisdiction by an Act of Parliament, article
226 cannot be stopped. Article 226 is a basic feature. They cannot tie it up. The Minister should
know it. In every Act, there will be a provision for the jurisdiction of the Civil Court. Do they mean to
say that we cannot approach the court during a writ petition?
Then I come to offences. Clause 65 says:
"Whoever knowingly or intentionally conceals, or destroys or alters intentionally or
knowingly causes another to conceal, destroy or alter any computer source code" –
this computer source code is available to everybody - "used for a computer, computer
programme, computer system, or computer network, when the computer source code
is required to be kept or maintained by law for the time being in force, shall be
punishable with imprisonment up to three years."Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

Where did you get this? This is not under Clauses 161, 165 or 171. This is a new innovation. We, the
Members of Parliament, have been given computers. If it is attached to a website and if somebody
interferes, they have said "knowingly or intentionally". We have to prove that we have no intention
of tampering with the computer programme and network. So, why should there be this provision of
clause 65? Is it not incriminatory? Will anybody follow the Cyber law then?
Then, I come to Clause 45 which talks about Cyber Tribunal. Clause 45 says:
"Whoever contravenes any rules or regulations made under this Act, for the
contravention of which no penalty has been separately provided, shall be liable to pay
a compensation not exceeding twenty-five thousand rupees to the person affected by
such contravention."
This Clause 45 should be read along with clause 76, which says:
"No penalty imposed or confiscation made under this Act shall prevent the
imposition of any other punishment which the person affected thereby is liable under
any other law for the time being in force."
 
Are these two Clauses, 45 and 76, not contradictory?
Then, I would reiterate Clause 76. As far as my legal knowledge goes, anybody can be prosecuted
under various provisions of law on the same subject matter. Suppose a person accumulates wealth
disproportionate to his known sources of income, he may be charged with the violation of
Income-tax Act and, at the same time, under the Prevention of Corruption Act. So, this Clause 76 is
all right, but what about Clause 45? Will it not be counter to Clause 76?
Clause 47 says:
"While adjudging the quantum of compensation under this Chapter, the adjudicating
officer shall have due regard to the following factors:
the amount of gain of unfair advantage, wherever quantifiable, made as a result of the
default;
the amount of loss caused to any person as a result of the default."
How will you estimate that? It is a computer crime. It is a Computer Network Cyber law violation.
How will you estimate the quantum of compensation, what is the methodology you are going to
adopt, what is the guideline you are going to supply to the Tribunal members? The High Court
Judge is not going to be well-versed with Computer Science. Maybe, as a High Court Judge, he can
read law. If a Software Engineer or an expert in software is sitting over the judgement in thisDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

Appellate Tribunal, he can decide the case. It is not a criminal case to be decided by a Judge. So, the
composition of the Appellate Tribunal needs revision by this Government.
Then comes the procedure of the cyber law and the Appellate Tribunal and the recovery of penalty.
At one point of time you said that the Civil Procedure Code would apply on the question of natural
justice and at some other point you have said that the Criminal Procedure Code will apply. You said
both in the same law. Is the constitution of this Cyber Law Tribunal under a separate law or under
the Civil Court Tribunal?
You have the Motor Accidents Claims Tribunal to look into the question of compensation. You have
the criminal court to look into or to find out whether the driver was rash and negligent. The two
cases cannot be clubbed and tried by the same judge. How did you incorporate the Sections 345 and
346 of the Criminal Procedure Code, 1973 here?
Mr. Chairman, Sir, this is too technical a thing and that is why I am reading it line by line. Either the
Civil Procedure Code may apply or the Criminal Procedure Code may apply but both the Codes
cannot apply. You cannot be a civil court and at the same time you cannot be a criminal court. You
say that under provision that you can award compensation. In another provision you say that they
are going to impose punishment. It needs a lot of revision.
I appeal to the Government to reconsider it again on the question of jurisdiction. The Civil court’s
jurisdiction is different and the Criminal court’s jurisdiction is different. If there is a civil injury,
there will be compensation and if there is a criminal offence, there will be punishment. A single
judge cannot be vested with the powers of the civil court and at the same time those of the criminal
court.
Then comes the offences by companies. Clause 84 of the Bill says:
"Where a person committing a contravention of any of the provisions of this Act or of
any rule, direction or order made thereunder is a company, every person who, at the
time the contravention was committed, was in charge of, and was responsible to, the
company for the conduct of business of the company as well as the company, shall be
guilty of the contravention and shall be liable to be proceeded against and punished
accordingly."
It is not well-defined. It is not self-explanatory. The offences by the companies should be arranged
seriatim. The law is not arranged in seriatim. The judge has to see one page to find out whether
there is an offence and he has to see another page whether there is a claim for compensation and he
has to see another page to see whether he can impose punishment. It is a blanket law. We are in a
computer age. There is no doubt about it. We read this Bill. But, at the same time, it should be
properly done now.
Young children, officers, adolescent children and the womenfolk at home are playing with
computers. They also operate the websites. If it is an offence, if it is treated a criminal thing at first,Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

then nobody will buy these computers and nobody will operate the websites. I do not want
Parliament’s computer or the website. I do not want it. We have not yet started. In the beginning
itself you are threatening with punishment. Then, how will the people try to understand the website
or the computer science or the computer network?
So, I would say that this Bill needs a revision. Let there be another study. The Standing Committee
has studied it in detail. We now have doubts. There are doubts in the minds of Parliamentarians. A
doubt has arisen in our minds.
SHRI M.V.V.S. MURTHI : It always happens when it is a new Act.
SHRI P.H. PANDIYAN : Yes, it is a new Act. It should stand the test of law later. It can be challenged
in the court of law after it is passed. So, a fresh Committee may look afresh into the Information
Technology Bill and protect the interests and rights of the people. It is an invasion of Fundamental
Rights of individuals dealing with computer network. Public place is a different thing. The private
buildings also include, at certain places, the public place.
Mr. Chairman Sir, this Bill is too technical. It is very difficult to understand. There were debates in
the Press. There were debates in the television. Yesterday, our Minister in charge of Department of
Disinvestment, Shri Arun Jaitley said on television that entry into the premises by the police is a
common thing. It cannot be. If a police officer arrests an ordinary man, that is different. This cyber
law is not going to be handled ordinarily by ordinary individuals; people of high pedestal and people
with high qualifications will handle it. So, I think, the hon. Minister, Shri Pramod Mahajan will
understand it. Otherwise, we are afraid of handling these websites. Supposing, somebody comes in
and knocks, I cannot just lock it. It may so happen in quarters allotted by Lok Sabha also. Nobody
should come and charge us. So, I would say that the Government should revise this Bill.
I support the contents of the Bill, but I do not support the way in which it is drafted, the way in
which it is going to be handled by the Government and the way in which it is going to be executed. I
say, the law must bend to the needs of the society; otherwise the society will break the law. It is not
so easy to make society bend to the law. With these words, I support the contents of the Bill. …
(Interruptions) I support the intention and contention of the Bill and also appeal to the Government
to revise it and have a fresh look at the Bill.
'   ﬁ (°) :  , ¢      
¶ ¡ﬂ  ‹' ﬁ¢›  «   ⁄    ﬂ ¶¿ 
§¤      '§   „ ﬁ    ⁄        
     –ﬂ¤           ¡ ﬂ¡, °¡ 
   ¡¤ ¢   '    §¤  – ¢    '
 £     ,    «, ' °ﬁ 
       ⁄  '   "  £  "   ¡, 
   '  " À"   § ¢¤Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

 ,   `´    '  §– £   «   ⁄· 
°   ⁄  • `´    ˆ    ˜    « 
°   ¢¤   «   ¯´´˘  ˘˙   ﬂ¡, ¨   ¢¤
 , ﬂ ¡'   ﬂ ¡ ‰“  § ¢¤ ﬂ  ¢ 
°¡ ¡  ¡ §       ﬁ ¢   ¥ ‹  ¢¤
     '          ﬁ   ¢, 
   ¢   ¥  ﬁ  §  ﬂ,    ¢  ‹  
 ﬂ,    ¥ƒﬂ¡,  '     § ¢¤
         ¢   …  … ¡¤     ' 
      ° ¢ £ ° ﬁ  ‡-      ‹
‡ ¢¤          ¢¤   ¢ '  ﬂ  ‡ ˆ
  £ –†·‡  ˆ   ¢, §– £   «  §–   •
 § ¢¤   «  ¨ ﬂ§'  ‰– •  § ¢   
 –– §– £    '     ‰“-–‰“ '  ¤
 ,        '  ¡ £ ¡  § ¡¤  
        ‚ «  ¤     ¡ ¶
¢ ¢À    ‹  †   ,     °
«  †'      ¢¤   '  ° 
¢    ‰“-¶  –      ° «  †'
    ¢¤     -   ¢ ¥ „  
¥  – ¥«   ¢¤    ,ﬁ  ¡¢ £ ° 
    «§ –  ¢,     ¢¤  '     ¢  °¡
 ––   '    « £ ° ¥« ¡   – §ﬁ
   , ﬁ       ¡    ,
 ° £  ¡¢  ‹  ¶¡,  ° «-†'    
˜– ¥ƒ  ¡ﬂ¡¤
    «    – ¡,    ﬁ ‚ﬂﬁ ¡¤  
  «     ﬁ  ﬁƒ    ¡   
   ° › '…    ¡,     °-ﬁ§-ﬁ
· ¥« ¡¤
   ¶  ‹ﬁ  '  ¶  ¢.     ﬂ – 
¢, ¥ ‚  ¡§  , ¥       ‹ 
,    ﬁ   ﬁ¢›  «  ﬁ-¢   ﬂ¡¤ 
¢⁄           °   ¢¤  ⁄ ‡
  «   ¢¤  –  ¶¤ ¥   ›‹ﬁ     
 ¥ ? –  °  ° ﬁ› £ »¢ﬁ    
 ⁄   `˘   °  «      ? 
ﬁ ﬁ  ‹' £ ﬁ¢›  ﬂ °  ¶  ¢  
¢  '      ¶  †  ﬁ   ¢?  Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

ﬁ¢›  «    ¢ '   '  – ¢¤
  :  É  ¡„ ¤  °  „   ¤ ° « …ﬁ
 –– '   ¢¤
----------------
18.00 hrs. INFORMATION TECHNOLOGY BILL - contd.
'   ﬁ (°) : ¢   ⁄   `˚ °¡, `¸ˆ˙   ﬂ¤
…( «)
' „ ' ° (‡) :  ,    ¶ ¶ 
ﬂ   ¶  ¢?
'   ﬁ :   ⁄     ' «  '– ¥ 
 ¤   ‹†' ﬂ ﬁ¢†  «    °   ¶·
 …( «)
  : •:  – ¢¤     ,  ‹†' ﬂ ﬁ¢† 
§„ ¢,  ﬂ      ¶¤
'  ' (¡) :  ,   – ¢    
  ,  ¡¤
'  – () :   – ¢        
¡¤
SHRI SONTOSH MOHAN DEV (SILCHAR): Sir, the Prime Minister himself told that you take as
much time as you want. He was not present in the House. Let it be discussed tomorrow. If
necessary, we will sit late night tomorrow and pass it… (Interruptions)
   ⁄ §– †¡  ('  ) :    –
…ﬁ ¶ ¡ﬂ ¢     ¶    ⁄¤
SHRI PRIYA RANJAN DASMUNSI : Sir, I think the hon. Minister was not present in the House
today when all the leaders expressed their views including the ex-Prime Minister, Shri
Chandrashkher. At that time, the hon. Prime Minister himself stood up and intervened that this Bill
is really complex in many ways and he desires that as many hours as Members want, they can
continue the discussion. So, the limit of four hours was overruled by the Leader of the House.
SHRI PRAMOD MAHAJAN: I have no objection. You speak for even more than four hours. The
Prime Minister never said that it will be discussed tomorrow. But you can discuss it for as manyDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

hours as you want today. We have no objection. We are ready to sit and we would like the House to
be extended.
Sir, every time the Opposition comes with a discussion under Rule 193 and we accept it for
tomorrow or day-after-tomorrow… (Interruptions)
SHRI PRIYA RANJAN DASMUNSI : This is not under Rule 193. This is a very important Bill.
SHRI PRAMOD MAHAJAN: I know it is a very important Bill. That is why, I am pressing for it.
SHRI PRIYA RANJAN DASMUNSI : This Bill is not opposed by any quarter of the House. None of
us are opposing the Bill. We are all in favour of the Bill. Sir, almost all the Parties expressed the view
that this Bill requires… (Interruptions)
SHRI PRAMOD MAHAJAN: Not almost all the Parties.
SHRI PRIYA RANJAN DASMUNSI : All right. I would say that not the ruling parties. But the hon.
Prime Minister who is our hon. Leader of the House responded to our apprehensions and said that
the discussion should not be barred. You discuss it for as many hours as you want. If I may recall
you also said before you left the House that let the discussion start and we can take up the other
matters later.
18.02 hours (Mr. Speaker in the Chair ) MR. SPEAKER: Shri Dasmunsi, the Business Advisory
Committee allotted four hours. So, let the discussion continue.
SHRI PRIYA RANJAN DASMUNSI : Mr. Speaker, Sir, if you want to get every business to be
disposed of in this way by totally disregarding the sentiments and feelings expressed by the
Members, then what is the point of our intervening? We want to support the Bill and we want to
accommodate the Government… (Interruptions)
SHRI PRAMOD MAHAJAN: Sir, all the discussions under Rule 193 are for two hours. But never
even one discussion under Rule 193 was continued for two hours only. We always sat here for six
hours to eight hours… (Interruptions)
SHRI SONTOSH MOHAN DEV : You are not the first Minister of Parliamentary Affairs who has
done this. The other Ministers of Parliamentary Affairs have also done this. You have not done any
favour… (Interruptions) The Prime Minister is being over-ruled here. He is being devalued. He is
trying to be super Prime Minister. What we have understood is that the Prime Minister said that it
can continue tomorrow. If you want to pass it without us, you can pass it. If you do like that, it will
be stopped in Rajya Sabha.
MR. SPEAKER: There are many speakers.
SHRI SONTOSH MOHAN DEV : If it is passed here, it will be stopped in Rajya Sabha.Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

MAJ. GEN. (RETD.) B.C. KHANDURI (GARHWAL): We have discussed in the BAC today that this
item of business would be finished today itself. Based on this only, the Business for tomorrow and
day after tomorrow has been fixed.… (Interruptions)
MR. SPEAKER: Let him complete his speech.
… (Interruptions)
SHRI BASU DEB ACHARIA : If the discussion is continued tomorrow, what is wrong in that? …
(Interruptions)
SHRI PRAMOD MAHAJAN: I have to get it passed in the Rajya Sabha also. I need one day’s gap to
take it up to the Rajya Sabha with the President’s sanction.… (Interruptions)
SHRI MANI SHANKAR AIYAR : What is the urgency in it?
SHRI PRIYA RANJAN DASMUNSI : Mr. Speaker, Sir, I would appeal to you to consider what the
senior leaders were saying. I only leave it to you. You have studied the mind and the mood of the
leaders in the morning. You must appreciate the sentiments expressed by the hon. Prime Minister in
response to the sentiments expressed by the leaders on this issue. (Interruptions) If they are
resolved to get it done today itself, let them do it. It seems that they do not need our presence. Let
them discuss it in any manner they like. Is this the way of doing things?… (Interruptions)
MR. SPEAKER: Let him complete it.
MAJ. GEN. (RETD.) B.C. KHANDURI : Mr. Speaker, Sir, all the senior leaders were present in the
meeting. Whatever is discussed in the BAC is not adhered here. … (Interruptions)
SHRI PRIYA RANJAN DASMUNSI : Do not blame us. I have already communicated to the hon.
Speaker about this.… (Interruptions)
'   ﬁ : °« , ¢   ⁄    `˚ °¡, `¸ˆ˙  
ﬂ £   ⁄-⁄     ' «  '– °   
°¤ …( «)
SHRI RASHID ALVI (AMROHA): Mr. Speaker, Sir, without extending the time of the House, how
can the House continue? It is already 6.05 p.m.… (Interruptions)
'   ﬁ :    ‹' ﬁ¢  ° °   ˜
¶·       ° ¢ ' ¥  ¢¤ °¡  ' 
°  ‡ ¨   › °      '     
 ¤        ¢            ¢ 
  °    ¤       ° °, ﬁ, ,
, ‹ £  •ﬁ-•ﬁ ﬂ' ﬁ¾ ¢ …, ¡   Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

°¤     °  ‹' ﬁ¢  °¡  ˚´´ 
‡     ¢, ¥   ¯´˘   ¢,   
  ° •‡ ‡ ¢¤         ¢, ¥ ° 
…( «)
MR. SPEAKER: Shri Kataria, please resume your seat for a minute. If the House agrees, we can
continue the discussion up to Seven of the Clock today.
SHRI PRAMOD MAHAJAN: We cannot do that. We want that this item of business should be
finished today .
SHRI PRIYA RANJAN DASMUNSI : If the Parliamentary Affairs Minister insists that this item of
business should be finished today itself, he can do it with this party Members. We are going out.…
(Interruptions) This is the attitude of the Government. At least, I did not expect it from the hon.
Parliamentary Affairs Minister. What is this? The hon. Speaker is supreme.… (Interruptions)
MAJ. GEN. (RETD.) B.C. KHANDURI : We have prepared the programme for tomorrow and day
after tomorrow based on the agreement that this Bill would be passed today itself.… (Interruptions)
SHRI SHIVRAJ V. PATIL : I would like to submit very humbly that in the morning, the hon.
Members wanted that this should not be taken up in this Session. There was a suggestion that there
should be a Special Session for this. But the hon. Prime Minister said that we could discuss it for as
much time as we need to discuss it and almost all the Members including Shri Basu Deb Achaira and
Shri Priya Ranjan Dasmunsi, said that this Bill would be passed.
I think, in view of this kind of a statement, it should not be tried to see that it is passed when these
people are not there because it creates difficulties for passing the Bill in the other House also. May I
say that let us accommodate each other rather than saying that it should be done? If he is not doing
it then he should not forget that he needs cooperation in the other House also.
'   :     ¢, ¢ ‹   – §, ⁄ ·  
 – §, °«   ⁄, «   ﬂ  ﬁ  ﬁ¡ ‡
⁄¤ ¥   ¡ ⁄  °¡ ‹     ––  – ¢, 
        –• ¶ ¢¤    É –– ‡ ⁄¤ ¥ °
…ﬁ  ﬂ, ¥ °   ﬂ     §  ¢, ¡  
§  ¢ £ «   §  ¢¤  °–     ¢¤ •: 
    ·   ¢¤ ¥  '   ﬂ¡,     ⁄¤
   †     ¢¤        •:     ¢ƒ
¢,   –   ¢¤    ¢         – ¢¤
      ⁄¤ °¡      ⁄  ¥ ¥    
 £    ¢    §,  ”  ° ¢¤    ⁄,
      ⁄¤  ¶  ¢, ﬁ ¢,  ¥  °¥ ¤
°      ¥   §  ¡¤Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

' ' . ﬁ (ﬁ§) : ¨  ¢¤
'   :      ¢     § ¤ ¢  
⁄   §¤
' ' . ﬁ :   §„ ¢,    ¢ £    
– ¢¤   ¢    ¡   ¢    ¢,    ¡
  ¢¤ –  ﬂ«       ¢¤ ﬂ     ¢¤ 
  ¢ƒ ﬂ ¢,     ¢,   « ¢ƒ ﬂ ¢,   ¢¤
       ﬂ¡ £       ﬂ¡¤    
¢ƒ¡,     «  ¡   ¢ƒ –,  ⁄·   ¢ƒ ﬂ¡¤
¨   ¢,  ﬂ        ¢¤  ﬂ   ¢ﬁ  '§
 ﬂ¤     ¢     ¢ƒ, ¥    ﬂ¡ £   
ﬂ¡¤
SHRI PRAMOD MAHAJAN: Sir, we are not taking up Sankhya Vahini tomorrow and we will be
completing this Business. Then we have a discussion under Rule 193 also. Sir, we always have a new
schedule in the house instead of what is decided in the BAC.
SHRI PRIYA RANJAN DASMUNSI : Mr. Speaker Sir, I have always held the view that we should
never dishonour the decision of the BAC. I entirely agree with it. The tradition of this House is that
even if the BAC decides something and if something extraordinary comes, then we must react in the
House.
Sir, before the hon. Minister of Parliamentary Affairs likes to submit to you, in the Business
Advisory Committee meeting, it was decided that on the Friday Afternoon if the report of the
Standing Committee comes, we shall take it up on Monday for four hours. Till that time, we did
know what are the amendments of the Standing Committee that the Government is accommodating.
All those things have come only by Sunday. Obviously, in the morning today, when we all assemble,
each party, at least from the Opposition did explain through all their whips that we had to go into
detail and give our views on all such amendments because they wanted to pass this Bill and it might
take more time.
MR. SPEAKER: We have discussed all these things in the morning and again you are raising this.
SHRI PRIYA RANJAN DASMUNSI : Sir, that is the point that I am talking about. When we
discussed that, you know what was the mood of the House in the morning and what did the hon.
Prime Minister say.
MR. SPEAKER: No, please. We will sit up to 7 o"clock.
SHRI PRAMOD MAHAJAN: What have we decided, Sir?
MR. SPEAKER: We are extending the time of the House up to 7 o"clock.Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

SHRI SHIVRAJ V. PATIL : All right.
SHRI PRAMOD MAHAJAN: No, Sir, but what is the fate of the Bill? What will happen tomorrow?
Shall we be going to the original agenda of BAC?
SHRI SHIVRAJ V. PATIL : We will pass it tomorrow. We are saying this on the floor of the House.
SHRI PRAMOD MAHAJAN: Hon. Shri Shivraj Patil is saying that tomorrow he will pass it. All right.
SHRI SHIVRAJ V. PATIL : No, I am not saying that. I am saying that everybody is agreeing to it.
SHRI PRAMOD MAHAJAN: But they will allow me to pass this Bill tomorrow.
'   ﬁ : ¢   §    §¤ ° , ¢      
'  ﬂ   –§¡    '  °  ›   ﬁ
¢,    ¶ °  ¡    ¢ £    ¶ ¢    °
'  ...    «  ‰“ – ¢,  ¯´´˘   ˘˙   
¶ ¢, ¥ ﬂ '  ° ¯´´˘  ¯.¯    ›   ﬁ 
ﬁ¡  ·¡¤
`˘.`Ì  ('  – ƒ ﬂ)  '  ﬂ  ‹›' ﬂ
ﬁ¢›  ¡    ¥ƒ  § ¢   
'  ⁄ ﬁ'   ¢,    ·† '  –  ¢,   ¶ 
  `˘ ¶      ¢ £ –   °  ﬁ¢ﬁ    ‰“
¢   ¯´´´  °   ˝.˘ ¶  ¡    ﬁ¢ﬁ « ¡,  ﬂ
¢     ⁄  ﬂ     –§¡      ﬁ    
  ,      ‹›' ﬂ ﬁ¢›  °  
'    ⁄ ⁄       ° '   ¢
 ‚  ¤   ⁄  ¢  - «  §   ”  
 ¤
 
SHRI K.P. SINGH DEO (DHENKANAL): Mr. Chairman, Sir, first of all I would like to congratulate
the hon. Minister for having brought this very important legislation on the 16th of December. For
such an important legislation, we have to wait for five months and we are now in a hurry to have it
passed even without detailed discussions.
Sir, in the Statement of Objects and Reasons--they are very noble indeed-- one is on e-Governance
and the other one is on e-Commerce. Whereas it has gone into detail of e-Commerce in the
Statement of Objects and Reasons, on e-Governance, it says:
"With a view to facilitate Electronic Governance, it is proposed to provide for the use
and acceptance of electronic records and digital signatures in the Government officesDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

and its agencies. This will make the citizens" interaction with the Government offices
hassle free. "
But it is not necessarily transparent.
Sir, if one goes through the Annual Report of the Ministry of Information and Technology, it has
been mentioned that in the history of civilisation, no work of science has so comprehensively been
impacted on the course of human development as information technology. So, Sir, I am more likely
to agree with Prof. Rupchand Pal. Although the Annual Report enunciates that it has an impact on
the human development, this Bill, which has been introduced, has nothing to offer for human
development at all excepting e-Commerce.
Sir, I did have a stint in the Ministry now being occupied by Shri Arun Jaitley about half a decade
back. My distinguished predecessor, Shri Upendra and myself had felt at that time that there should
be a convergence of broadcasting, communication, micro-chip, electronics and space because it has
a direct impact on every single Indian. Anyway, Sir, it is better late than never.
   
Today there is a talk of convergence. Also there is talk on human development through the great
revolution, the information revolution, known as information technology. That time we had
information super highway by a flick of a switch. One could use the television as a telephone, as a
telex, as a fax as well as internetting throughout the world. But today it has been overtaken within a
half decade by the multimedia information highway of which information technology is the
manifestation. Today we find that the Government has broad-based, although it has identified in the
Annual Report and had thought it fit to appoint three task forces. One for software, one for
hardware and one –it claims to have it – for rural development, manpower training and education
which is totally missing from this Bill which has been brought.
Then the Annual Report also talks about international gateways and also by 2008, it will be
information for all. This is belied by this Bill. That is why, my predecessor, Shri Shivraj Patil while
speaking first on this Bill, has said that it is not a comprehensive Bill at all. That is one of our
apprehensions that it is totally narrow and it is only confined to commerce. This information super
highway is another way of the Americans dominating commerce through this speed of receiving as
well as retrieving data, and having an overall lead in the commercial world. So, if one goes by the
track record of the Telecom Regulatory Authority of India which being a service provider became a
regulator, today the entire IT industry is crying because of the role of the Telecom Regulatory
Authority of India as well as the Telecom Ministry.
Shri Arun Jaitley, there was an exercise in the I&B Ministry which had brought out the flaws then
when the Telecom Regulatory Authority was being set up. It was brought to the notice of the
Government. They did not have consultation with any of the Departments including Defence,
Electronics, or Space and they enunciated something. It was accepted by the then Government
rightly or wrongly. But today the entire IT industry is crying that out of 22 IT service providers, 18Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

have gone to the red. I mean they are at loss and only four are surviving in this entire atmosphere.
India wants to be a super-power, a global power in information technology. It is not by butchering
our own people, by our own laws or by our own Regulatory Authorities. Nowhere is a service
provider, the Judge, the Jury and the accused. Here it was the case. It being a regulator, it was also a
service provider.
Now, with infrastructure not having developed, this information technology will only be a pious
hope to dupe Parliament and to dupe the people of making claims of giving a million people jobs by
information technology per year. That means, if this Government exists, in five years, five million
jobs. That means, 50 lakh jobs will be provided.
Apart from that, we have given computers and Internet facilities to our Members of Parliament only
recently, not even a month back. When hon. Members of Parliament discuss in various fora, there is
so much dissatisfaction that there is so much delay in the Internet. There is so much delay in
processing the computer that it has remained a dead letter than being utilised to make a Member of
Parliament more effective, more useful to Parliament and to the country. We are depending on this
infrastructure which is totally letting us down at the most crucial points.
So, human development would mean, education, health, agriculture, environment, distance
education, sports, culture and right to information which we hear everyone is talking about but we
have been hearing this for the last few years because without the establishment of the proper type of
infrastructure, none of this is going to happen.
This has had no mention in the Bill. There is a mention in the Annual Report but there is no
mention in the Bill. If the hon. Minister could clarify in his reply we would be most happy. That
would look transparent also.
I congratulate the hon. Minister for trying to implement the vision for the North-East of the Prime
Minister by having inter-connectivity with every single block of the North-East. The implementation
lies with the hon. Minister for Information Technology. I had got so enthused that I shot off a letter
to him also asking him why should he not take up Orissa along with the cyclone-affected area, or
why not portions of Bengal, Bihar, Madhya Pradesh, portion of Andhra Pradesh, the Agency area.
We are also equally at a disadvantage just as the North-Eastern sector as far as digital
communication is concerned,. And communication is a good medium to empower our people where
literacy is needed, where ordinary communication is needed or communication and where
educational facilities are not available and Information Technology can be a multiplier effect.
So, I would request , through you, that the hon. Minister could shed some light about what is this
North-East programme, what is this vision in North-East and it can be replicated in some areas of
Ladakh, may be the portions of Andaman or Lakshwadweep Islands and also in those areas ravaged
by weather related phenomena like floods and cyclones and where communications get cut off.
In Information Technology we could come across cyber crime and very recently Shri Fali Nariman
had also drawn the attention of the Government to Web-casting’. It is not included in the proposedDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

Broadcast Bill before the llth Lok Sabha which is now being formulated. I hope so and also the
Tele-Communication Ministry has certain laws which are not in consonance, which are being
brought in this particular Information Technology Bill.
Therefore, there are some lacunae, there are certain aberrations, dichotomies, there are differences
in the various Ministries having different different laws; so I think that a comprehensive legislation
will be brought by the Minister sooner or later, after six months or may be in the next Session,
because this is not a comprehensive legislation. This is basically meant for commerce and this is
raising the hopes of the entire nation.
I would like to draw the attention of the House to an interesting article called "JACK THE
HACKER’. It is from the Telegraph dated the 20th February. Our LARRDIS has given a cutting. I
quote.
"As a potential information technology power, India should take warning from
hacker attacks. Cyber attacks are increasing in number and sophistication every
year."
This was February 2000, i.e. it was in December, some two months ago a United States Judge freed
Mr. Kevin Mitnick, the great criminal hacker of the Eighties, from jail. Even the great Federal
Bureau of Investigation could not do much for 20 years and I do not know which agency under this
law where a Police Constable or an Assistant Commissioner or Deputy Commissioner is going to
catch hold of these hackers. Who is a hacker? It says :
"Mr. Mitnick is the type who `hacks’ into computer systems and takes control from
inside and zombe attacks are crude, the digital equivalent of human wave attacks."
Now, it can have implications of national security; it can have implications of internal security; and
it can paralyse the Government machinery. I think, through Information Technology, you are going
to have these community centres; you are going to do e-Governance. So, all these implications must
be studied in depth. Since the hon. Minister has said that he has to get it passed in the Rajya Sabha,
knowing his intentions, I can only hope – being a very dynamic person, I know he has been into the
Ministries of Defence, and Information and Broadcasting where I was there, and is a
forward-looking young man, who is a good wicket keeper of Parliament also, he will bring an
amendment in the near future so that we can tackle all the impressions which have been put by the
media as well as the apprehensions in our mind based on the experience of the United States, Japan
and some of the leading countries of the world who have had a head start over us.
We have a habit of aping the West. We try to accept something very quickly, without going into the
depth of the implications, which they suffered after eight to ten years. Today, the entire privacy of
human being is affected. That is why, the Information Super-highways, which was the brainchild of
Mr. Al Gore as well as Mr. Bill Clinton, had to be shelved in the nineties.Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

Now, we are going in for this Information Technology with the multi-media Information Highway.
What is the social impact it is going to have on the human-mind, on our children and the manner in
which video piracy and all these things are happening, the vulgarity which is coming in for which the
hon. Minister used to take me to task in the other House? I just want to remind him that these are
the things which we have to safeguard.
Sir, with these few words, I would like to thank you for giving me an opportunity to participate in
the discussion.
   
THE MINISTER OF STATE OF THE MINISTRY OF INFORMATION AND BROADCASTING AND
MINISTER OF STATE OF THE DEPARTMENT OF DISINVESTMENT (SHRI ARUN JAITLEY):
Mr. Chairman, Sir, I am extremely grateful to you for giving me this opportunity to support the
legislation which has been introduced by the Minister of Information Technology, Shri Pramod
Mahajan. It also gives me an opportunity to respond to some of the issues which have been raised by
some of the very senior and distinguished Members of this House.
A question which has repeatedly arisen today is as to what is the urgency in passing this Bill. The
second question which has been raised, particularly by Shri K.P. Singh Deo and Shri Rupchand Pal
is this. Should the law not be comprehensive enough to take into account the impact of convergence
of technologies? Shri Shivraj V. Patil has listed several issues which he feels will have to be
considered before this Bill can be eventually passed. He says: "Do not legislate in a hurry because
some contradictions may emerge later on".
The purpose of this Bill is two-fold. The first aspect of this law is e-Documentation, e-Commerce,
and e-Communication which have become a reality. They already face us and our existing laws have
so far lagged behind in not giving a legal sanction to those documents.
The second purpose is that with the emergence of this new technology, new crimes have come into
existence. Therefore, any delay in the passing of this Bill is really going to enable either a
non-recognition of what is the reality in terms of e-mail, e-documentation and also allowing those
who committed these offences to get away till such time that this law has been passed.
Sir, I will illustrate it by two small illustrations. Today contracts, international trade, even domestic
trade do not take place by two individuals physically meeting, interacting, discussing and then
signing a written document. It is a harsh reality that these are going on by e-Mail; these are going on
through various electronic documentations. Our courts still will not recognise any one of these
because these documents are not documents, are not recognised within the meaning of our
traditional laws.
Therefore, if somebody were to resile out of these contracts, these documents will not be worth the
paper they are written on because there is no legal recognition of it. How long can we wait and see?
The United Nations adopted the model law in 1997. Nation after nation have been adopting theseDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

laws. There is now an international model of this legislation which has emerged and I feel that it is
about time that we pass this law which gives recognition to the entire documentation which takes
place through e-Documentation so that it can facilitate e-Trade in this country. Just last week we
had the ‘Love Bug’ which destroyed a large number of computers. I was wondering to myself, when I
read newspaper reports, that under which law in India would this kind of an exercise be an offence.
Somebody can actually come and hack computers, steal information, destroy information and still
go scot free because we have already been too late in legislating in this regard. So, when you say, Sir,
what is the urgency, the urgency is that we have already been too late in this regard and, therefore,
the Legislature has to live up to these changing realities and enact a law which not only gives
recognition to this documentation but which also starts recognising these new realities which are
also a reality today.
Keeping pace with technology for any legislative exercise, Shri Patil is right, is a difficult exercise.
Technology moves faster than legislation. You always get educated by experience in this line and,
therefore, you may well have to change your legislation from time to time to keep pace with this
legislation. The best evidence is what was provided by Shri Pal and Shri K.P. Singh Deo when they
said, what about a larger convergence law? These are all areas which are not conceived of years ago.
Convergence is a reality, but let me just say this on convergence that in law-making, you do not mix
one branch of law with another. This law is limited for the purpose of creating these new Cyber
offences, providing remedies against those offences, compensation with regard to those offences and
punishment with regard to those offences. This law seeks to recognise e-Documentation as a reality
in law. The impact of convergence between Internet, telecommunication and broadcasting is an
entirely different branch which, as has been rightly pointed out, is a fact that the Government is
certainly concerned with and we are working in this area.
Several questions were raised with regard to the proposed Bill and I shall deal broadly with each of
the important ones which have been raised. Shri Patil wanted to know as to why contracts for sale of
immovable property have been left out of e-Commerce. Leaving them out is a reality because there is
a separate legislation - the Registration Act – which deals with recognising each immovable property
transaction after it has been registered. You have offices of Sub-Registrars all over the country and
you have offices of Registrars all over the country. Unless those offices also tune themselves to the
changing technologies which, I have no doubt, in due course of time they would. Today, to say that
every contract of immovable property will come under this, may not be possible. We will have
perhaps to wait for some time when the reality of documentation also penetrates and reaches those
areas.
There were several questions which have been raised. For instance, it was pointed out that under
Clause 57, why do we provide for an appeal not being there. Clause 57(2), Shri Patil objected, is a
superfluous provision. No appeal shall lie against a Tribunal by an order made with the consent of
parties. Much that it may appear to be a superfluous provision, when two parties before the
Adjudicating Officer agree for a particular amount of compensation, normally no Tribunal is going
to entertain an appeal against that. But practical experience is to the contrary. People have filed
appeals even after agreeing against consent orders and, therefore, we have amended a series of our
laws. In fact, I was just going through the Civil Procedure Code which contains now an identicalDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

provision in Section 96 that against the consent order passed by a court, an appeal is to be
specifically barred. Otherwise an abuse was going on. You go and agree before one authority and still
you seek to challenge that order before another authority.
So, it is a matter of precaution that various laws have been amended. This is not the only law that
has this provision. Various laws have been amended to have this kind of a provision introduced in
these laws.
Section 58 says that the Tribunal is not bound by the Code of Civil Procedure, but it is bound to
comply with the principles of natural justice. And, thereafter, in Section 58(2), hon. Member, Shri
Shivraj Patil saw a contradiction when it was mentioned. But some powers of the C.P.C. are still
given to the Tribunal. Section 58 is a standard provision which is contained in all legislations where
Special Tribunals are created. The object of Special Tribunals is that you must have an expeditious
remedy and the cumbersome procedure mentioned in law should not apply, should not be a
long-winded remedy, but still there must be fairness in the procedure. And fairness in the procedure
requires that the persons who are concerned with this must be given a fair hearing. Therefore, even
though you are not bound by the Civil Procedure Code, you are bound to observe the principles of
natural justice. Every adjudicating law which provides for an adjudicating authority has this power.
But some specific powers of the C.P.C. are given, because if those powers were not given, how would
the adjudicating authority summon witnesses; how would he confer an oath to them; how would he
allow oral evidence or affidavit evidence? So, only some selective powers are given and the
generality of the procedure code does not apply. Now, this is there in various Acts which provide for
adjudicating authorities which have been created.
In fact, I was drawing parallels in other laws – in the SEBI law, in the FERA law, in the
Administrative Tribunals Act where an almost identical provision of this kind does exist. So, there is
nothing extraordinary that in this particular law, a provision has been put in.
An issue was raised that Section 62 provides for an appeal to the High Court. Are we creating a
system of three appeals? The answer is ‘No’. There is an adjudicating authority. His order on facts
and law is appealable to the Tribunal. So, on facts only one appeal is provided, namely appeal to the
Tribunal. A second appeal is provided to the High Court in para materia with our civil law, not on
facts but only on a question of law. No further appeal is provided. On facts, there is only one appeal.
On a question of law, you can go to the High Court which is there in the normal civil law of the land.
This law is in para materia with that law.
And thereafter, an appeal to the Supreme Court, by Special Leave, under Article 136 is there which is
never a statutory right. It is a highly discretionary remedy which is never considered an appellate
right of any particular person. So, there is one appeal on facts and two appeals, as far as the question
of law is concerned and there is no other appeal.
Regarding Section 76, though Shri P.H. Pandiyan expressed the contrary view, Shri Shivraj Patil has
suggested that Section 76 is really violating the principle of double jeopardy. Because Section 76 says
: "No penalty under this act shall prevent imposition of punishment under any other law…."Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

Shri Pandiyan had responded to that by giving a very correct illustration by saying that you may
have disproportionate assets; you may also be equally liable under another law to pay tax on the
assets you have acquired even if they are illegally acquired. The Act may be the same. But the
offences are different. Therefore, the principle of article 20 which brings in double jeopardy applies
as far as different offences are concerned that no person shall be punished twice for the same
offence. If the offences are different, one, under the Prevention of Corruption Act and the other
under the Income-tax Act, as Shri Pandiyan has rightly said, two remedies are permissible in law.
The mandate of Article 20 does not come in.
Regarding Section 79, as a large number of hon. Members also pointed out this morning, it is a
provision which has come for extensive comment even in the media. The provision says that
‘Notwithstanding anything in the criminal law, an officer not below the rank of a Deputy
Superintendent of Police is entitled to enter a public place, search the public place and even arrest
the person without a warrant’. Now, it has been commented that such a provision is draconian in
character.
Hon. Minister, Shri Pramod Mahajan while intervening earlier, had clarified that. On the surface,
this argument appears to be attractive. But how are you going to give this power to a police officer to
search a premises?.
But is this the first law where this power is there? This power has a very strong rationale. In Section
41 and Section 165 of the Criminal Procedure code, this power is there. In FERA, this power is there
in Section 45. In fact, Section 45 of FERA is identically reproduced in clause 79 of the present Bill.
This power is there under Section 105 of the Customs Act.
SHRI RUPCHAND PAL (HOOGLY): Is there no such judgement by the higher courts against arrest
without warrant?
SHRI ARUN JAITLEY: I am afraid, these provisions which are time-tested provisions have been
upheld and none of these provisions has been struck down.
I will just explain the rationale to you. Let us not go in for what a populist impression may be. Why
is this power there in the Cr.P.C? A Police Officer is informed that there are arms lying in some place
and some terrorist is using arms. Is he supposed to wait for three days, go to some authority, seek
his permission and then search it? By the time he comes there, the arms are removed. A Customs
Officer is told that there are smuggled goods lying in a particular place, in a vessel or in an aeroplane
and some smuggling is going to take place, and he wants to search it. Is he to go to some other
authority and ask for permission? And it takes him 15 days to get that permission. Then, he comes
back and searches the property. Suddenness, taking the criminal by surprise, is the essence of
investigation. Let us, in the name of populism, not create a situation where the criminal who is
already ahead of the law, by such approaches, is benefited a little further.
Today, in the changing times when this new technology has come, cyber crimes have become the
rule of the day. Shri Pramod Mahajan rightly mentioned that there are cyber crimes. Let us takeDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

moneylaundering though it is not covered in this Act and is a subject matter of another legislation.
The problem is being faced world over that through Internet banking, money can be laundered into
hundred countries in one day. The principle behind it is to immediately go and freeze the evidence
and seize the evidence. Are we to create cumbersome procedures by which we tie down the hands of
our police officers or customs officers and the criminal is enabled because while legislating we
thought of a popular argument that why we give such powers to the police.
If there is a foreign exchange transaction which is illegal, which is going on, the Enforcement Officer
has to go and seize the property. If you take away this power of seizure and search then and there,
you are crippling every criminal investigation. If there is any cyber offence taking place, the officer
in charge - and in this Bill, it has rightly been an officer of the level of DSP and above – has the right
to go there, go to the computer head, seize the software or the hardware through which the offence is
taking place. If you say that this power should be denied to him, then, in the name of liberalising the
law, we will be creating an institutional mechanism in which only the law breaker is going to benefit
and the investigating authorities are going to be crippled.
Shri Shivraj Patil mentioned offences by companies. Now, there is nothing unusual about this Bill
that this provision is there. In a large number of commercial and economic legislations, the business
activity is done by a company, but there is some person who is in charge of and responsible for the
affairs of the company. So, when a company commits an offence, the company, being a legal entity
but not a physical entity, is incapable of being put to trial and being sent to jail. At best, there can be
a penalty or a fine on a company. Therefore, the principle of vicarious liability is introduced into
criminal law that when you put on the mask of a company, do business and then commit an offence,
the law will remove the mask and see who is the person behind the company responsible for the
functions of the company so that that person can be taken to task. Now, this is not the first time that
this provision has been introduced. In all laws providing for economic offences, this provision is
identically there. This provision is there in Section 26 of the SEBI Act. It is there under Section 68 of
FERA. It is there under Section 140 of the Customs Act. So, this provision is there in every case
because if this provision was not there, it will be a haven for criminals. All that they have to do is,
instead of committing the offence themselves, have a company being formed, customs business will
be done in the name of the company, foreign exchange violations will take place in the name of the
company and then he can say that you cannot send the company to jail and he is also not liable.
Therefore, law removes the veil of a company, brings out the person behind the company and then
takes him to task and hold him accountable to law. Therefore, there is really no objection with
regard to Section 84. It is a common provision which has been introduced almost in every
legislation.
Clause 85, removal of doubts, is also important in this legislation. As I mentioned earlier, removal of
doubts takes place where law is competing with changing and developing technologies. Shri Patil is
very right when he says, "No clarification can be issued which conflicts with the Act." An executive
clarification by the Government cannot override the mandate of law, but insofar as it is only
clarificatory in nature and can coexist with the Act. In all laws which have to lay down the vision of
the future, a clarificatory power has to be there with the Government that if there is a doubt, clarify
the doubt because new technologies will emerge, new situations will arise which cannot be foreseenDiscussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

by us today. So, the general power, which is not used to violate the Act but to clarify the provisions
of the Act in such legislations, is always there.
Two very relevant points were raised by Shri Pandiyan. Under Clause 50, when you appoint a
Tribunal, the Tribunal could be headed by a sitting or a retired judge of a High Court, you feared
that it will be an appeal from that Tribunal to the High Court itself. If I may phrase it differently, "Is
it an appeal from the same authority to a similar authority, or as they call it in law, an appeal from
Caesar to Caesar?" It is not so. A large number of Tribunals are headed by judges of the High Court;
Commissions of Inquiry are headed by judges of the High Court; all Tribunals under the Unlawful
Organisations Act, where organisations are banned, are headed by a sitting High Court judge. An
appeal against that order is provided to the High Court because when a High Court judge goes and
heads a Tribunal, he is a person who has been designated, but he is not the High Court. When a
High Court judge heads a Tribunal, he does not, while heading the Tribunal, have the writ powers of
a High Court. He is only a person who was the judge of the High Court. That is a qualification. He is
heading a Tribunal; his orders are made appealable even under several laws to the High Court itself
because sitting there, it is the same person but his jurisdiction is much narrower; it is not the larger
jurisdiction of a High Court. Therefore, this really may not be sustained.
Section 61 has been repeatedly construed and you should have no fear when it says, "No Court will
have the power to entertain issues which are before the Tribunal." When such laws use the words
`no court", the fear expressed was that how can this legislation take away the power of a High Court
under article 226. Shri Pandiyan is absolutely right. Under Section 61, when the words `no court"
are used, they only refer to the jurisdiction of courts as civil courts. This has been repeatedly
clarified. For instance, in the Tenth Schedule of the Constitution which deals with the powers of the
Speaker under the Anti-Defection Law, there is a similar provision: "No Court shall entertain issues
which are within the jurisdiction of the hon. Speaker." But the Constitution Bench said, "This cannot
cut down the writ jurisdiction of a High Court because it is a part of the basic structure." But this can
only take away the powers of a civil court. Therefore, when there is an issue which is pending before
an adjudicating authority or it is pending before the Tribunal, you cannot go to a civil court. As far as
the writ power is concerned, there is almost unanimity of view that it is part of a basic structure.
Even a Constitution amendment cannot take it away. So, the words `no court has the power" are
only relevant, as far as the civil courts are concerned.
Shri Pandiyan wanted to know whether there is a conflict between Clauses 45 and 76. Well, my
reading of the law is that the two operate entirely in different directions. Section 45 only deals with
compensation. So, if you cause injury to somebody through a cyber act and that is not otherwise
provided for in this law, it is a general power which says that you can get compensation up to Rs.
25,000. Clause 45 is the power relating to compensation; Clause 76 is the power, as Shri Patil had
given a possible view that it is a power where the provisions of this Act will not come in the way of
punishing a person, if he has committed an offence under another Act. Section 76, therefore, deals
with an offence committed under another Act. The two are operating entirely in different
jurisdictions, in different areas. So, one really cannot have a conflict with the other.Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

The issues that have been raised are certainly issues of concern but some of these provisions have
not been brought into this law for the first time. These have existed in time-tested legislations in
different laws. It is on a larger international model that this law is being brought. The purpose of
this law itself underlines the urgency for its enactment. When Shri K.P. Singh Deo was reading an
article regarding a hacker, I asked myself the question as to what offence in today’s law had that
hacker committed. You can hack, you can steal somebody’s information, you can destroy
somebody’s information and still go scot-free because our criminal law has not treated it as an
offence. That itself is the ground for utmost urgency. So, my appeal to Members on all sides would
be that this law requires to be passed with utmost urgency. There will be occasions where technology
overtakes us and we may have to add to this law. But adding would be an exercise of strengthening
this law. The purpose of this law is to recognise the reality. We are already behind in this exercise. I
am sure, keeping this in view, Members from all sides would certainly support this legislation to
come into force at its earliest.
 
›. …'   (¢'):  , °–•  ¢,     
ﬁ    ¢, ¥   ﬁ      ¤   §–  
«     ¢  '        ¡‡ £ ' 
  – ¡ ¢¤       ⁄    ¥¡
« ¢¤   ¡‡  •   § ¢¤  ﬂ     
 –ﬂ¤       «      «   
ﬂ ¢ £  ¢    «       ¢,  ¢ ¥  §•
– §     «         ⁄,      
 ﬂ,     °    ﬂ?
 ,         «    ﬂ ⁄ £ 
     ⁄   «  ﬂ ⁄,  ‹  •:   
    ¢ƒ  £   §      ‡, ¥ ﬂ §
† ¢?  -    «     « ﬁ ﬂ¡ £ · °⁄
 ﬂ¡,  °      «    ﬂ £ °     ﬂ ¢,
 ¥ ﬂ    ƒ ﬂ?
 ,                 ﬂ ¢ £
¥ﬁ  « £ «  ¥ﬁ     ¢,  ƒ  ¢¤     
   ¤ ¢ §• – §     '  ¡  §–  
°«   ¢,    §     ‹ ¢¤   §–   °«
  ¢,  §–  §       ¢?
 ,   ƒ      · § ¢, 
‡ · ¢   ﬂ '  ﬂ ﬁ  '    °« ﬂ  ¢, 
 °–•  ¢   §    ¢¤  ¥ §   §–
  §   ﬂ       ¥  °«  °-
  ⁄¤ ¢ §    §• – §  ¥ §     Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

¶ ¢¤    ‹' ﬁ¢††  §     ﬂ   –¢ ¢ £
        °⁄  ﬂ¡,   §–   °«  «
§        ¢?
 ,   ƒ ¢  §–      ' ‹   
¢,  –   • ¢¤    ﬂ „ ¢     , ¢À,
 , §ﬁ  , ‹ﬁ  £      
‹   ¢¤  ﬂ     ¢ £ ¥ ¡  ¶  '
––  ˜–   ¢,   '     ¢À 
°         ¢¤  ﬂ   §   ¢¤
1 9.00 hrs.       ¢      ¡ ⁄  ¡ ¡¢
 · ¶  ⁄  ¥ﬁ-ﬁ  ¥ §  ⁄, ° ¥ §ﬁ    ¶ 
¡      ¡¤  ƒ  ¢¤      ¢ﬁ
„ £  ¢ﬁ '  É‰“    « ﬁ ¢¤ ¢
§• – §       ‹' ﬁ›  •  ¡,  ¡
‰“¡? ” ¡ ¢        • £ «  · ¤  «  
   ¢,  ¡ ‰“ ¡  °    «   ¥ 
– ¢¤   «   ¥¡ ¢?   §  –ﬂ ⁄  
  °      ‡? ﬂ  ¶    ¢   ¢ﬁ
§  °' §– '   ¢¤   ¡ ¢   ﬁﬁ ,
§ﬁ  • °ﬁ'ﬁ ¡ ¶-¶ ‹   ¢¤
  : …' ,   ¡ ¢¤
…( «)
   ⁄ §– †¡  ('  ) :  ,
  – ¶  ﬂ¤
MR. CHAIRMAN: Still eight more speakers are there to participate.
SHRI PRAMOD MAHAJAN: I am not saying about the rest of the speakers. I am saying about his
speech. Let him conclude his speech today, and the rest of the speeches can be made tomorrow.…
(Interruptions)
MR. CHAIRMAN: There are eight more speakers to speak. If the House agrees, we can finish the
discussion today and have the reply tomorrow.
SOME HON. MEMBERS: No, Sir.
SHRI SATYAVRAT CHATURVEDI (KHAJURAHO): Let him finish his speech today. Till then, we
are here.Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

MR. CHAIRMAN: All right.
So, the time of the sitting of the House is extended till his speech is over.   ¶ ﬂ¤
' …'   : ¢ §    §¤
  :  §   ¡‡ ¢¤    ﬂ¤
' …'   :  , °¡ ¢    §¡  ¥ ﬂ ” ﬂ
…ﬁ –ﬂ¤ …( «)  §  ¢,  ¢   §¤  ﬂ  ‹'
ﬁ›    ' ¢        ¢,     
   ¥”  ¡¤   ¥  ¡ ' ¢¤  ¢    ¶§ •§ﬁ
¢¤   •§ﬁ  , °« ƒ   ¢  ¡¡   ¢,  
 £  ¡¡  ¡  – ¡¤  §ﬁ ƒ  ¡, 
ƒ ¡ £  ¡·· ¡   ¡,        ¢?  ﬂ 
¡ '  ¢      °«       ¥ ¡ 
¡¤  ....  ﬁ‹‡  ¡  ƒ ¢   °«   ¢ 
  ·  °« ¢¤   £  ¥ ¡   °« ¢¤ ¥ –
  ¥ ¡   •§ﬁ   ,   ¡  ' ⁄  ﬂ  
⁄        –ﬂ   « ‰  – ,   ° 
£ • ¡··   '' ¤
  ¢  §–  -        ¢¤  ƒ 
¢  ﬁ›    ¢¤    §–  ‹  ⁄¤ 
§  «   ⁄    ¥ «   „   ⁄  †
   ¢, †   ¢ ¤          ⁄¤ °
 ‹' ﬁ›  °  ﬂ ¢¤ §    ¢¤  
¢  ¥ « …ﬁ ¡ ¢¤  §   –   ¢¤  ‹' ﬁ›
    ¶   ¢, ¥ ¡   •    ¢¤    ¡
  ° ‰“ ¡, ¥ ‰“¡?
 ‹†' ﬁ¢†   ¥ ‰“¡¤   • ¥ ‰“ 
 ¢¤    • ¶  ﬂ¡? •  ¡¤  ﬂ   ¢ 
° –  ¢¤
…( «)         ¢¤    ¢ ¶
¤   §ﬁ    ¢¤   ¶ ¢ -      
    ¢,   §ﬁ  ,  ‹   – «
–    „  ¢ﬁ §   ¡¤ ¡ ¶ ¢ -
 ¢ﬁ „ £  ¢ﬁ ',      ﬂ  ‹†' ﬂ
ﬁ¢†   ¢¤   „   ‰“ £  ¡  
¡¤Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

 ¢ﬁ '  …·      «   ﬂ ¶
    °ﬂ¤   ¥'  ¶ ¢¤ ¡   
¢ - °ﬁ  «  «  ﬁ ¡
§.ﬂ..‡.ﬁ..ﬂ.ﬂ.  `¸¸Ì   ¤    ‹ ¢   –
   ¤ ‹ ¯˙ , `¸¸˙   ¶ ˚`Ì¯       
  « ﬂ, ¥   ' «  «  ¶¤    ¢ 
 ﬂ¤  °      ¢¤ §.ﬁ.‚.   ¯´´˝ 
'  ˙`˚    ¢¤      ¡§  ¤    '  °
 ¥–  ¢¤ '  ¡ƒ   ¢ﬁ „  « 
     É      °   
 ﬂ  ¢ ﬂ    ¢¤
`¸.´˘ (°«  ƒ ﬂ)    ‹†' ﬂ ﬁ¢†  
§   § ¢¤ °      ¢,  ¢  
¢¤  ﬂ  §„ «  §   ¡,  ¶   
  ¢¤  ¥' £ „ ¶    ﬁ  ¢    «
 '  •    ¢¤ '     ¢,  ' ¢     
 ¥ «  ¶·  ﬂ¤  ﬂ   – ¢¤…( «) §.ﬁ.‚. 
   '  ¡ ¶'  ﬂ¡,  ﬂ  ¢¤  ﬂ  …  ¢¤
     ¢,  °      §    ¢  
  –    ¥ ﬂ  § ¢¤  –  ⁄   •
¡     ¢¤   '    ﬂ¤  ﬂ   ‚ 
–   § ¢¤ ¨ ‡ §    '  ° , ¥” , Éﬁ
, ƒ‡ , ¡  ' ‰“¤ ¥  ¡‡  –   § ¢, : –
  § ¢¤   '  ⁄ ¢ °    §¤
MR. SPEAKER: Shri Sontosh Mohan Dev, will you speak now?
SHRI SONTOSH MOHAN DEV (SILCHAR): No. I will speak tomorrow.
MR. SPEAKER: The House stands adjourned to meet tomorrow, the 16th May, 2000 at 11.00 a.m.
19.09 hours The Lok Sabha then adjourned till Eleven of the Clock on Tuesday, May 16,
2000/Vaisakha 26, 1922 (Saka).
-----------
 Discussion On The Information Technology Bill, 1999. (Not Concluded) on 15 May, 2000

