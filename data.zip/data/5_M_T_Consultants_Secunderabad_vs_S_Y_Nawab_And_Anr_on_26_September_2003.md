5 M & T Consultants, Secunderabad vs S.Y. Nawab And Anr on
26 September, 2003
Equivalent citations: AIR 2004 SUPREME COURT 4942, 2003 (8) SCC 100,
2003 (8) SCALE 229, 2004 (1) ALL CJ 156, 2003 (7) SLT 496, 2003 (10) SRJ
232, (2003) 11 INDLD 868, (2004) 3 MAD LW 129, (2003) 6 ANDHLD 99, (2003) 7
SUPREME 166, (2003) 8 SCALE 229, (2004) 1 ANDH LT 29
Bench: Doraiswamy Raju, Arijit Pasayat
           CASE NO.:
Appeal (civil)  8103 of 2002
PETITIONER:
5 M & T CONSULTANTS, SECUNDERABAD
RESPONDENT:
S.Y. NAWAB AND ANR.
DATE OF JUDGMENT: 26/09/2003
BENCH:
DORAISWAMY RAJU & ARIJIT PASAYAT
JUDGMENT:
JUDGMENT 2003 Supp(4) SCR 187 The Judgment of the Court was delivered by RAJU, J. : 1.
Special leave granted.
2. The appellant, who was arrayed as second respondent in Writ Petition No. 22227 of 1994 before
the High Court of Andhra Pradesh, filed by the first respondent in this Court, though succeeded
before the learned Single Judge, lost before the Division Bench in Writ Appeal No. 712 of 1995,
resulting in this appeal. The Writ Petition before the High Court was filed seeking for a writ of
certiorari to call for the records of the Municipal Corporation of Hyderabad relating to the
permission granted by the Corporation to the appellant to erect or display any advertisement/street
signs/direction boards/arches on the public roads/colonies etc. within the twin cities of Hyderabad
and Secunderabad and the permission granted for display thereon to the second respondent or to
any other person and declare the same to be ultra-vires the provisions of the Hyderabad Municipal
Corporation Act and Article 14 of the Constitution of India. The learned Single Judge dismissed the
writ petition on the ground that the writ petitioner was not able to establish any illegality as alleged
in the transaction. The learned Judge also adverted to the salient features of the transaction and the
circumstances under which the work came to be entrusted to the appellant as well as the further fact
that only two circles were taken up for putting up the boards and the other circles are always
available for the petitioner or anyone else interested to approach the Corporation and undertake
such work. It was also observed therein that the assignment entrusted to the appellant was not5 M & T Consultants, Secunderabad vs S.Y. Nawab And Anr on 26 September, 2003

shown to be of any grant of largesse, as it did not involve exploitation of any property. Aggrieved, the
writ petitioner moved the Division Bench and the Division Bench on 26.9.95 seems to have passed
on order recording the willingness of parties as hereunder :
"After hearing the learned counsel for the parties, we wanted to know from the
learned counsel for the Corporation if on similar terms and conditions the
Corporation is prepared to award the contract to the Writ Appellant as was done
earlier. Learned counsel submitted that 80% of the work is still remained to be
completed and the Corporation will have no objection to grant to the Writ Appellant
as well. Learned Counsel for the writ appellant also show the willingness of the writ
appellant to take the contract on similar terms and conditions on which the second
respondent in this writ appeal was granted contract. For setting the terms and the
extent of the work to be entrusted to the writ appellant, in pursuance of the mutual
agreement expressed before us by the learned counsel for the parties, both of them
wanted some time. Accordingly time till 12.10.95 is granted. Put up on 13.10.95."
3. Notwithstanding, the writ petitioner appears to have even thereafter without availing of the said
order, pursued the litigation, as if on a public interest litigation and the Division Bench of the High
Court by its order under challenge in this appeal allowed the appeal, as prayed for and directed
termination of the contract and proceed to make an exercise afresh for the purpose. Certain relevant
factual details have to be noticed for a proper appreciation of the respective contentions of the
parties and the legal principles that should be really applied in adjudging the same.
4. The Corporation, though a metropolitan city, seems to have had no road names display anywhere
and there appears to have been also no proper house numbering and the one in vogue was of a
confusing pattern. The appellant appears to have volunteered to take up the rationalisation of house
numbering in the twin cities by assigning house numbers in continuous series in each locality as
house number, street number, locality, and also erect street sign boards indicating the name of the
locality, street number, details of house numbers etc. The Corporation seems to have also had an
idea of erecting for the use and benefit of public road direction boards on various thoroughfares of
twin cities. Though all these were said to have been on the agenda of the Corporation for long,
financial constraints seem to have stood in the way of its realization, due to requirement of
substantial sums of money to implement the same. Only at this stage, the appellant was said to have
approached in September, 1973 the Corporation with a proposal formulated by them, on an in depth
study. in the form of a Scheme and project and expressed their willingness to undertake a fresh
survey if the Corporation desired to take up the project. The appellant was asked to show various
designs formulated by them and display one of them for sample and it appears to have been done at
a place near Bakers inn on the existing electrical pole showing the direction towards Raj Bhawan
Road. The then Commissioner and other officials who inspected the work in November, 1993 were
said to have been not impressed and wanted the appellant to change the same by doing it without
using the electrical pole. After going through the various revised designs submitted by them, one
among them appears to have been chosen and the appellants were asked to execute a sample board
during the second week of November, 1993 which was considered to be satisfactory to the concerned
Authorities of the Corporation. A detailed project report was said to have been submitted by the5 M & T Consultants, Secunderabad vs S.Y. Nawab And Anr on 26 September, 2003

appellant on 25.11.93 after conducting a survey and the sample street signboards and direction
boards were executed, to ascertain the utility of them. As a test venture, the appellant was said to
have been asked to find out sponsors for meeting the cost of street sign boards and take up the work
in Circle No. 3 and Secunderabad Division by a letter dated 30.3.94. Subsequently, also for further
ascertaining the satisfactory nature of the system, the Corporation was said to have asked for the
erection of 3 sample boards at West Marredpally for inspection and on such inspection by the
commissioner, Additional Commissioner (Project) Officer-in-Special Duty, and thereafter further
suggestions were said to have been also given as to increasing the height of the board and after
effecting alterations, modifications and corrections, the Corporation seems to have finally asked the
appellant to erect street signboards at Marredpally. Secunderabad Division in Gagan Mahal area in
Circle No. 3 duly specifying the dimensions, height, shape of board and space to be left for sponsor,
in the communication dated 23.6.94 of the Commissioner of the Corporation. Thereupon it appears
to appellant submitted a proposal on 7.9.94 in respect of road direction boards for erection on main
through fares of twin cities along with a design and model which was said to have been agreed to on
principle by the Corporation and asked the appellant to erect a sample of it at Patni Junction,
Secunderabad in the communication dated 16.8.94 of the Director of House Numbering Cell. The
appellant thereupon appears to have commenced the work as per the discussions held with the
various authorities during the course of the progress of work, who from time to time, have been
inspecting and checking upon the execution whereof.
5. Since the project in question to be implemented by the Corporation, was thought to be first of its
kind and after an analysis and consideration of all the factors of the project for about an year as
noticed above, a decision seems to have been taken to undertake the work as a pilot project, on
experimental basis. Accordingly permission appears to have been granted to the appellant for
erection of street signboards in Circle No. 3 and Secunderabad Division by a communication dated
12.9.94/14.9.94 of the Commissioner of the Corporation with following terms and conditions duly
specifying at the same time that the work should be completed by 31.12.94 :
"1. Location of the Street Sign Boards shall be strictly as per the directions of the
Director (HNC), MCH.
2. On erection of Street Signs in each locality, a nominal charge of Rs. 5 (Rupees Five
only) shall be paid to MCH as cost of erection borne by your organization.
3. You are exempted from the advertisement fee and ground rent, as you are
displaying Street Sign Board along with your board at your own expenses. However,
the MCH will reserve the right to impose the advertisement fee and ground rent if at
any point of time, if it is observed and substantiated by any impartial survey that the
maintenance is poor and/or the advertising space in more than stipulated in the
agreement, and/or any other terms and conditions are violated.
4. The advertisement space should not be used for any political or religious matters
i.e. message or slogans of whatsoever nature.5 M & T Consultants, Secunderabad vs S.Y. Nawab And Anr on 26 September, 2003

5. Periodical maintenance should be done, and boards are kept neat and clean by the
sponsor.
6. The sizes of Street Sign Boards should be as follows :
_________________________________________________________________________
SI. No. Description of the Board Height from Ground Level Dimension of Board
Sponsor 1 Main Road Board 9' x 0' 4'3" x 2' 3" 3' 3"xl' 6"
2 Street Sign Boards 8' x 6"
Lane Boards : 7'-10" 3' 0" x I1 6" 22" DIA
__________________________________________________________________________
7. You will meet the entire cost including civil works, fabrication, erection, painting,
lettering, maintenance and MCH will not incur any money for this purpose.
8. You can let out space provide for advertising purpose to any of your clients at your
own terms and conditions for 15 years from the date of this letter, after which the
same may be extended on mutually agreed terms and conditions.
9. You must complete the erection of Street Sign Boards with complete information
within (15) days from the date of receiving all relevant details/data locality-wise from
the Director, House Numbering Cell, MCH.
10. M/s. 5 M & T Consultants shall execute an agreement on twenty rupees
non-judicial stamp paper for due performance of the contractual obligations under
this order.
11. M/s. M & T Consultants shall alter and align the road direction/Street Boards
depending on the road widening as and when required."
6. Further, a similar order was said to have been issued for erection of direction boards also at 27
locations, in a communication dated 12.9.94/ 14.9.94 subject to the following conditions, duly
specifying that the work shall be completed before 2.10.94 :
"1. Location of the Direction Boards shall be strictly as per the direction of the
Director (HNC). MCH.
2. On erection of each Direction Board, a fee of Rs. 100 (Rupees One Hundred only)
shall be paid by Ms. 5 M & T Consultants to the MCH as the entire cost of erection is
borne by your organization.5 M & T Consultants, Secunderabad vs S.Y. Nawab And Anr on 26 September, 2003

3. You are exempted from the advertisement fee and ground rent, as you are
displaying direction boards along with board with your board at own expenses.
However, the MCH will reserve the right to impose the advertisement fee and ground
rent if at any point of time, it is observed and substantiated by any Impartial survey
that the maintenance is poor and/or the advertising space is more than stipulated in
the agreement and/or any other terms and conditions are violated.
4. The Advertisement space should not be used for any political or religious matters
i.e. message or slogans of whatsoever nature.
5. Periodical maintenance should be done, and boards are kept neat and clean by the
sponsor.
6. In space provided for indicating direction to the localities should be strictly
followed as given below:
___________________________________________________________________________
S. No. Area of Display Size
1. Right & Left Direction Boards (8'-0" x 6'-6") both sides
2. Along the road direction Board (30'-0" x 2'-9") both sides 3 The Advertising Board
(3'-9") Ht at Centre (4-'/2' on either side)
4. Minimum clear height from road level (18-0")
5. Lettering of Direction Board (Radium Letters)
___________________________________________________________________________
_____
7. You will meet the entire cost including civil works, fabrication, erection, painting,
lettering, maintenance and MCH will not incur any money for this purpose.
8. You can let out space provided for advertising purpose to any of your client at your
own terms and conditions for (15) years from the date of this letter, after which the
same may be extended on mutually agreed terms and conditions."
It appears that though the appellant sought for 20 years period from the date of the completion for
work for realisation for their investment and other expenditure incurred by them on this project and
the maintenance to be undertaken the currency of the period, the Corporation decided to accord it
for a period of 15 years only, to the appellant.
7. Simultaneously, the Corporation seems to have issued a press notification on 21.11.94 by
publishing it in the daily newspapers of Telugu, English and Urdu on 23.11.94 in Eenadu, Newstime5 M & T Consultants, Secunderabad vs S.Y. Nawab And Anr on 26 September, 2003

and Siasat respectively, in the following terms:
"The MCH has taken up the rationalization of House Numbering in twin cities of
Hyderabad and Secunderabad. The present system of Wards, Block, House Number
is very confusing and causing a lot of confusion and to common man, visitors, as well
as to use departments in their day-to-day Urban Administration. Instead, the MCH
proposes to assign House Numbers in continuance series in each locality as House
Number Street No., Locality. It is proposed to erect boards indicating the name of the
locality, street number, house number from - to and each board depending upon its
location. The Boards are designed such that there is space for private advertisement,
which the sponsor can utilize. The MCH invites the private-advertise to come forward
and participate in the program and avail the opportunity. A meeting is being
convened at MCH office at 11.00 A.M. on 25.11.1994 for this purpose, advertising
agencies may participate. The area available for allotment ward wise is circle No.l, 2,
4, 5 and 6 of MCH."
It could be seen from the above that a very object was to mainly erect street signboard by giving top
priority to the said work, and that the project entrusted with the appellant was on a trial basis being
a pilot project. So far as other areas are concerned, the Corporation invited advertising agencies to
participate in the areas indicated.
8. It is necessary at this stage to refer to the role of the writ petitioner and his attitude and approach
to the issue before the Court as also his move towards the project undertaken by the Corporation, for
a proper understanding of the nature of the proceedings instituted, his sole aim as well as the merit
of his claims. In the Writ Petition, the claim made was that he was carrying on business in publicity
and advertising; that the displays by such advertisers in such manner are regulated by sections 421
and 422 of the H.M.C. Act; that he approached Corporation on several occasions for granting
permission and offered that he was prepared to erect arches on main roads and junction at his own
cost and he be permitted to display thereon as per rules but the Corporation allegedly claimed to
have informed him that there is no such policy to accord any such permission. It should be noticed
at this stage, except self-serving statements like them which were seriously disputed by the
Corporation, there is nothing on record/writing to prove any such fancy claims. In the last week
prior to the filing of the Writ Petition in December 1994, it is claimed that he came to know that the
Corporation as granted permission to the appellant to erect the arches and display thereon at M.G.
Road, Secunderabad, near Telegraph Office asserting at the same time vaguely that the grant was
opposed to public duties cast on the Corporation, besides being opposed to the principles of law and
Article 14 of the Constitution of India, the same being, according to the Writ Petitioner, arbitrary,
unjust and opposed to the principles of natural justice, fair play and equal opportunity to all. It was
the further case of the writ petitioner that on coming to know that a Circular dated 24.10.94 was
issued to select a few advertisers without calling for any invitation from the general public, he made
representation on 6.12.94 complaining about the grant of permission to the appellant claiming at
the same time for sanction of 200 arches/street sign boards across the roads and 1000 direction
boards inside various housing colonies, informing that they can undertake the work at the same
terms and conditions as offered by appellants. Such hollow and cryptic claims without details of any5 M & T Consultants, Secunderabad vs S.Y. Nawab And Anr on 26 September, 2003

of his project/plans, models or scheme and how he propose to execute them would belie the
hollowness as well no half hearted nature of the attempts of the writ petitioner. A grievance was
sought to be made that no response was received for the same and left with no further scope, he
claims to have approached the High Court with the Writ Petition. The counter affidavit filed by the
Corporation before the High Court categorically denied such claims having been made at any point
of time by the writ petitioner except writing the said letter. It was also stated for the Corporation
that he never entered into any dialogue with the authorities of the Corporation or sought for any
such direction. After the release of the Press Notification on 21.11.94 through local Newspapers as
indicated already inviting proposals for private advertisers for erection of boards in Circles 1,2,4,5
and 6 of the Corporation, a Meeting was said to have been convened on 26.11.94 in the Conference
Hall when about thirty private advertisers seem to have attended.
9. Though the writ petitioner did not attend the Meeting, instead he addressed a letter dated 6.12.94
to the Corporation requesting for sanction of 200 arches street signs and 1000 Directions Boards,
without having any relative concept of his capacity to erect so many boards running to
approximately to several crosses of rupees, or in what manner he purports to execute such works.
The other thirty private advertisers including the appellant, who participated in the deliberations.
Were said to have been informed that the street sign boards project and the erection of Direction
Boards have to go hand in hand and, therefore, the participants were asked to give their concrete
proposals immediately in order to complete the revision of House Numbering System. The further
claim of the Corporation appeared to be that all Ad Agencies, who were present in the Meeting, were
asking for work relating to only direction boards but not street signs boards or house numbering
and no private advertiser has evinced any interest to give concrete proposal much less the writ
petitioner, who never cared to attend the Meeting. The entrustment of erection of street sign boards
and direction boards to the appellants was said to be a pilot project in Circle No. 3 at Secunderabad
and in certain junctions was not thrown as a surprise and instead seem to and also claimed to have
culminated after a prolonged transaction involving innovative proposals made by the appellants
after much deliberations with the Corporation authorities, who, from time to time, seem to have
suggested certain improvements and changes to make it not only acceptable but appreciable and at
the same time ensure that no financial commitment strain or involvement was made for the
Corporation. It was affirmed before the High Court by the Corporation that the work was
appreciated by several high dignitaries from different States in the country. The Corporation in the
counter affidavit also stoutly denied vague allegations made against the authorities as well as the
appellants. That apart, it appears that when the Division Board passed a consent order to give a
chance to the writ petitioner also the same could not be allotted to the writ petitioner due to lack of
ability on his part to execute such works for want of either the technical expertise or the financial
ability to perform the work of erecting directions boards and sign boards and of maintaining them.
After the order of the Division Bench noticed above, the writ petitioner claims to have sent a
communication dated 4.10.95 merely disclosing the list of locations, which he desired to take up by
vaguely stating that they are willing to take up the work on same terms as was given to the
appellants and followed the same by another letter dated 9.10.95 merely reiterating the request
relating to road direction and street sign boards on same terms and conditions as laid down by the
Corporation in the case of the appellants, but even without submitting any plans or models of his
proposed execution. The Corporation, therefore, seems to have replied on 8.12.95 that the request5 M & T Consultants, Secunderabad vs S.Y. Nawab And Anr on 26 September, 2003

for grant of permission was examined and his request could not be considered at that stage since all
the work for erection of street sign boards was by then being done by the Corporation itself
departmentally and no new works are being erected anywhere in the twin cities either
departmentally or otherwise, and if in future any private agency participation is felt necessary, he
will be intimated and given an equal opportunity.
10. Reference may now be made to some of the case law cited on either side. In M/s. Kasturi Lal
Lakshmi Reddy v. State of Jammu & Kashmir & Another, [1980] 4 SCC I, this Court, while dealing
with the validity of a contract awarded for tapping of 10 to 12 lacs blazes annually for extraction of
resin from the inaccessible chir forests in the State for a period of 10 years, observed that in a given
situation, when a private party comes before the State and offers to set up an industry, the State
would not be committing breach of any constitutional or legal principle or obligation if it negotiates
with him and agrees to provide opportunities/ resources. It was also observed therein that unless
the terms and conditions of the contract or the surrounding circumstances show that the State has
acted malafide or out of improper or corrupt motive or in order to promote private interests of
someone at the cost of the State, the Court will not interfere, merely because no advertisement was
given or publicity made or tenders invited. In State of M.P. & Ors. v. Nandlal Jaiswal & Ors., [1986]
4 SCC 566. It was observed that grant of licenses by private negotiations without inviting tenders
cannot by itself be held to be arbitrary or unreasonable having regard to the circumstances,
exigencies and purpose of such grant, and all the more so when scope was left open to others also to
apply for similar grants and obtain it. In G.B. Mahajan & Ors. v. Jalgaon Municipal Council & Ors.,
[1991] 3 SCC 91, dealing with the case of a Municipal Council entering into contract with private
developer or builder for construction of a commercial complex involving its execution on self
financing basis subject to handing over it to the Municipality the complex free of cost and allotting
some shops at a fixed rate / free of cost to certain specified persons while having right to dispose of
the remaining accommodation at one's own discretion to allottees with occupancy rights therein for
50 years and retain the premia received by way of reimbursement of the financial outlays of the
developer plus profits, it was observed that a project, otherwise legal, does not become any the less
permissible by the mere reason that the local authority had entered into an agreement directly with
a developer for its financing and execution. A distinction between proper use and improper abuse of
power was considered to be relevant in adjudging the reasonableness of the exercise of power and
liberty to adopt appropriate techniques of management of projects with concomitant economic
expediencies which really pertain to matters of economic policy, was conserved in the authority
concerned, unless there was any violation of constitutional or legal limits of exercise of such powers
itself.
11. In Sterling Computers Limited v. M/s. M & N Publications Limited & Ors., [1993] 1 SCC 445, it
was observed that so-called executive necessities alone be no justification to flout the principles and
precepts that have to be followed in pubic interest and deprecated the grant being made to one who
was a proven defaulter affecting public interest and justified interference when the grant was found
to be vitiated on account of irrelevant and extraneous considerations weighing with the decision to
make such grant. In Tata Cellular v. Union of India, [1994] 6 SCC 651, it was observed that judicial
review of administrative action relating to award of contracts is limited to a review of the decision
making process and not the merits of the decision itself and that what is to be seen is whether the5 M & T Consultants, Secunderabad vs S.Y. Nawab And Anr on 26 September, 2003

action is vitiated by arbitrariness, unfairness, illegality, irrationality or 'Wednesbury
unreasonableness', i.e. when decision is such as no reasonable person on proper application of mind
could take or vitiated by procedural impropriety. In G.D. Zalani & Another v. Union of India & Ors.,
[1995] Supp. 2 SCC 512, it was observed that while selling public property or granting lease, though
the normal method is auction or calling for tenders, there may be exceptional situations where
adopting of such a course may not be insisted upon. Adverting to the peculiar nature of the case
therein, it was also observed that the case before Court was not a simple case of granting of lease of a
Government company but one where the Government company was trying its best to obtain the best
possible technology to advance its interests and what is to be seen in such cases is only whether the
action was fair and what has been done is the best available arrangement in the circumstances. In
Delhi Science Forum & Others v. Union of India & Another, [1996] 2 SCC 405, it was observed that
parting with privilege exclusively vested with the Government must be reasonably rational and in
public interest besides conforming to law governing the same and the decision pertaining to the
same can be questioned only on grounds of bad faith, based on 'irrational or irrelevant
considerations non-compliance with prescribed procedure or violation of any constitutional or
statutory provision and the onus in respect of establishing the same not only heavily rests on the
person alleging it but it is not satisfied by merely raising a doubt in the mind of Court as to the
validity of the decision.
12. In M.P. Oil Extraction & Another, etc. v. State of M.P. & Others. [1997] 7 SCC 592, while dealing
with a case where an agreement was entered into by the State with selected industrial units which
were commissioned on invitation of State to undertake oil extraction operation for assured supply of
sal seeds at concessional rates to them, it was observed that though open tender or public auction
was preferable, negotiation in certain cases was equally permissible, and Court's interference would
not be called for, if relevant considerations relating to the grant was duly considered before such
grant.
13. In Air India Ltd. Etc. v. Cochin International Airport Ltd. & Others, [2000] 2 SCC 617, it was
observed that in awarding contracts the State can choose its own method, and as long as it complied
with the norms, standard and procedure, no interference by courts is warranted unless the decision-
making process was found to be vitiated on ground of malafides, unreasonableness or arbitrariness.
In W.B. State Electricity Board v. Patel Engineering Co. Ltd. & Others, [2001] 2 SCC 451, it was
observed that rule of law and constitutional values must be adhered to by public authorities when
awarding contract and that it was always open to the authority concerned to negotiate with the next
lowest bidder for awarding the contract on economically-viable price bid. In Onkar Lal Bajaj &
Others v. Union of India & Another, [2003] 2 SCC 673, while dealing with mass scale and blanket
cancellation of allotments made in respect of retail outlets of petroleum products, LPG
distributorships and SKO-LDO dealerships during the entire period commencing from January,
2000 till date of orders of cancellation by one stroke, it was observed that treating all grants on
equal basis for cancellation irrespective of the fact whether an individual grant is otherwise
meritorious or deserving one, would be bad and that a grant, which is otherwise found vitiated,
could not be justified merely on the plea that huge investments have been made, after such
allotment and serious loss will be caused if cancellations are to be effected thereafter. Reference
made to decisions of English Courts are found to be not relevant for the case on hand and it would5 M & T Consultants, Secunderabad vs S.Y. Nawab And Anr on 26 September, 2003

be unnecessary to advert to them when innumerable decisions of this court itself are available on the
legal principles governing an adjudication of the issues raised.
14. In Subhash Kumar v. State of Bihar & Others, [1991] 1 SCC 598, it was observed that Public
Interest Litigations should not be encouraged when it is evident from the facts on record that the
primary purpose/object of the litigation is not to serve any public interest but only to further ones
own self interest, and the so-called public interest is merely a garb to cover up vested interests. In
Raunaq International Ltd. v. I. V.R. Construction Ltd. & Others, [1999] 1 SCC 492, it was observed
that the professed public interest litigation should be genuine, bona fide and really for public good
and not merely a cloak for attaining private ends.
15. The facts averred in the writ Petition and the stand pursued before this Court also would bring
out the real object, i.e., vindication of his own personal interests and there is nothing in the matter
involving any great public interest, which can justify any public outcry through a public interest
litigation. The desperateness of the writ petitioner is betrayed by the liberally invented incorrect
averments about his alleged approach to the authorities prior to the filing of writ petition, when the
fact remains that notwithstanding public notice for selection of agents for similar work in other
areas, he did not respond like others and merely approached the court feigning ignorance of all that
happened. The manner in which the writ petitioner was attempting to make bald claims after certain
orders were passed by the Division Bench pending final disposal of the appeal, to explore
possibilities of grant of work in his favour without disclosing for that purpose concrete plans or
models to convince the authorities of the genuineness of his moves also demonstrate, mere by his
attempts to ventilate personal vendetta and exhibit revengeful attitude rather than any of his sincere
endeavours to really seek relief even for him. The writ petition itself deserved summary dismissal
and the Division Bench committed a grave error in interfering in the matter. The well-merited order
of the learned Single Judge ought not to have disturbed by the Division Bench of the High Court.
16. The materials on record substantiated the absolute need and necessity to undertake works of the
nature executed by the appellant, in furtherance of great public interest and for larger public and
common good. The admitted dire financial position of the Corporation and their inability to
undertake such a project at the cost of the Corporation and the fact that the venture was long over
due apparently made the Corporation authorities to avail of the project as unfolded and volunteered
by the appellant, subject, of course, to further revisions, modifications and suggestions in the best
interests of the Corporation. When it was undertaken as a pilot project on a trial basis there might
not have been much certainty about the profitability of the scheme as a business venture for the
private party concerned and the appellants were prepared to undertake the said risk and executed
the works to the satisfaction of the authorities and appreciation of public as well. The risk involved is
not only in recoupling the investments to be made for installations and constructions but to
maintain them in good, proper and working condition without also sacrificing the beauty of the
installations throughout the duration of 15 years. Conditions imposed on the appellants involve
great responsibilities and obligations and necessarily certain concessions had to be shown to keep
the project working and maintain them in good shape. Not only the Municipal Corporation had no
financial commitments in getting such works by any expenditure therefor, which were to be
executed by the appellant only on self-financing basis generating the required funds for installation5 M & T Consultants, Secunderabad vs S.Y. Nawab And Anr on 26 September, 2003

and continued maintenance and their upkeep from sponsors by collecting premiums for giving them
the privilege to avail of the space permitted by the Corporation for advertisements but ultimately the
whole works have to be left with the Corporation and it is not to be removed by the appellants. As
rightly observed by the learned Single Judge the venture cannot be considered to be the grant of a
largesse or lease or contract in the conventional sense. The provisions in the Municipal Corporation
Act cannot be said to envisage situations of the nature, when enacted. This appears to be a project
more akin to the one considered by this Court in G.B. Mahajan's case (supra). The fact that no other
private advertising agencies, including the writ petitioner could offer to undertake such a venture in
the other available areas when their participation was sought for belies the tall claims of the writ
petitioner now made, after finding the project to have become successful and apparently fruitful -
more perhaps then it could have been thought of, initially by everyone. Perhaps irked by this only
the interest of the writ petitioner seem to have gained momentum, to try in desperateness for the
'Shylocks' pound of flesh', to ruin the very project, unmindful of any concern for the Corporation,
public good and the appellant.
17. A careful and dispassionate assessment and consideration of the materials placed on record does
not leave any reasonable impression, on the peculiar facts and circumstances of this case, that
anything obnoxious which require either public criticism or condemnation by courts of law had
taken place. It is by now well settled that non-floating of tenders or absence of public auction or
invitation alone is no sufficient reason to castigate the move or an action of a public authority as
either arbitrary or unreasonable or amounted to malafide or improper exercise or improper abuse of
power by the authority concerned. Courts have always leaned in favour of sufficient latitude being
left with the authorities to adopt its own techniques of management of projects with concomitant
economic expediencies depending upon the exigencies of a situation guided by appropriate financial
policy in the best interests of the authority motivated by public interest, as well as undertaking such
ventures. Though now, an attempt is sought to made by the writ petitioner and surprisingly even by
the Corporation too, attempting a somersault and claiming non- compliance with certain statutory
formalities, we find that such a move is not only a pure after thought, but really unwarranted and
not based upon a firm or sufficient ground or basis. The very applicability of the regulations
contained in Sections 126, 129A, 148, 420 or 421 of the Act to the case on hand would itself be
seriously doubtful. On the face of it they involve transactions envisaged therein, when granted in
favour of third parties, to be executed with the Corp 'ration funds and involving financial
commitments or parting with the property or rights and privileges of the Corporation for
value/consideration, and not to a self-financing scheme to be implemented and maintained without
any financial commitments or expenditure to the Corporation. Section 124 seems to enable the
Commissioner to undertake such ventures even without going before the Committee, as is now
sought to be claimed. The provisions relating to Section 420/421 would also have relevance only
when any such installations are to be made for the benefit' utility of private person/licensee, who
executes it and not to a peculiar case like the one wherein the installations are such which are to be
normally made and maintained by the Corporation for public good, but instead being permitted to
be made on its behalf and at its behest by a private property for the use and benefit of public at
large, which ultimately have to be left as the property of the Corporation only, and that too when
executed on a self-financial basis. The Commissioner or other authorities of the Corporation, who
seem to have undertaken this at a point of time when there is no concrete scheme/project or5 M & T Consultants, Secunderabad vs S.Y. Nawab And Anr on 26 September, 2003

sufficient funds with the Corporation, appear to have embarked upon this venture in good faith,
keeping in view not only the public good but also in an earnest endeavour to secure such a novel
project executed without any financial commitments or expenditure whatsoever either for the
installations or subsequent upkeep and maintenance for at least 15 years. Merely because as an
ultimate outcome in the long range, the appellant is able to make some more profit than what was
envisaged itself could not render the exercise undertaken or scheme executed vulnerable for being
challenged to be either as one in improper abuse of powers or by means of any
reprehensible/condemnable conduct, calling for interference in the hands of Court of Law.
18. The Division Bench, except cataloguing the catena of decisions, has not chosen to objectively
consider the extent of their applicability, relevance or otherwise of the principle befitting the merits
of the peculiar facts of the case. The case on hand does not constitute or at any rate can by no means
said to be the outcome of any unreasonable or arbitrary exercise of power so as to warrant
interference under Article 226 of the Constitution of India. The appeal is allowed, the order of the
Division Bench is set aside and the order of the learned Single Judge dismissing the writ petition
filed before the High Court shall stand restored. No costs.5 M & T Consultants, Secunderabad vs S.Y. Nawab And Anr on 26 September, 2003

