Firm Bhagwandas Shobhalal Jain, A ... vs State Of Madhya
Pradesh on 29 April, 1964
Equivalent citations: AIR1966MP95, AIR 1966 MADHYA PRADESH 95, 1965
MPLJ 809 1965 JABLJ 719, 1965 JABLJ 719
JUDGMENT
  Naik, J.  
1. This is a first appeal by the plaintiff, whose suit for damages for a breach of contract assessed by
him at Rs. 1,80,000/-against the State of Madhya Pradesh has been dismissed by the Additional
District Judge, Rewa.
2. The suit of the plaintiff was inter alia, based on the following allegations: that the plaintiff was a
registered partnership firm with Bhagwandas and Shobhalal as its managing partners, carrying on
business of manufacture and sale of bidis at Mohalla Chameli Chauk, Sagar; that the plaintiffs were
a lessee of the then Charkhari State for collecting tendu leaves from its Isanagar Pargana for the
period ending 30-9-1949; that after Independence, the State of Charkhari merged with the
neighbouring States of Bundelkhand and Baghel-khand to form a United State of Vindhya Pradesh
under a popular Government; that on 4-12-1948 the plaintiffs applied to the Minister for Commerce
and Industries for extension of the period of the aforesaid lease by another five years on a
consideration of Rs. 1,000/- per annum; that on 11-12-1948, a lease was sanctioned in their favour
as prayed for by them under the signature of Shri Mohanlal, Secretary, Commerce and Industries
Department, Government of Vindhya Pradesh; and on 14-12-1948, on their paying Rs. 1,000/- in
advance, a lease was executed in their favour by the Conservator of Forests, in respect of the
Isanagar Pargana of the old Charkhari State for the period 1-10-1949 to 30-9-1954; that on
26-9-1949, the Government of the United State of Vindhya Pradesh unilaterally cancelled the lease
on the ground that it had been granted 'without proper authority' and 'in contravention of past
practice;' that an application dated 8-10-1949 to the Chief Minister of United State of Vindhya
Pradesh protesting against the aforesaid cancellation was rejected by him; that the area comprising
the forests of Isanagar Pargana of the old Charkhari State was redistributed into various forest
circles which were then reauc-tioned on 19-11-1949 for the year 1949-50; that their civil suit against
the then State Government of Vindhya Pradesh for injunction and damages was dismissed by the
Judicial Commissioner, holding, inter alia, that though the lease in favour of the plaintiffs was valid,
they had not been able to prove damages sustained by them; that of Die re-grouped circles, some
were reauctioned on 23-11-1950 for the year 1950-51, and thereafter again for three years on
22-10-1951, which the plaintiffs themselves purchased for a total consideration of Rs. 59,004/-; that
of the rest of the circles, they were wrongfully deprived of the theka and the profits arising
therefrom; and that though the total loss thus suffered by them was very much more, they claimed
only Rs. 1,80,000/- from the State of Vindhya Pradesh towards damages.Firm Bhagwandas Shobhalal Jain, A ... vs State Of Madhya Pradesh on 29 April, 1964

3. The defendant, Government of Vindhya Pradesh contested the claim, inter alia, contending that
the lease in favour of the plaintiffs for the period 1-10-1949 to 30-9-1954 was validly cancelled; that
the suit was barred by Rule 2 of Order II of the Code of Civil Procedure; that the suit was also barred
by time; and that the amount of damages claimed could not be said to relate only to the Isanagar
Pargana of the old Charkhari State. The amount of damages claimed was, therefore, denied. It was
further contended that the Government of Vindhya Pradesh could not be held liable for the
cancellation of the lease done by the then United State of Vindhya Pradesh.
4. On the coming into existence of the new State of Madhya Pradesh, its name was substituted as
defendant in place of the 'Union of India', Part C State of Vindhya Pradesh.
5. The trial Court dismissed the suit, inter alia, holding-
"(1) The cancellation of the lease by the then Government of Vindhya Pradesh was
unauthorized, and consequently the defendant would be liable as on a breach of
contract.
(2) The cancellation of the lease could not be called an act of State, and it could,
therefore, be challenged in a Court of law.
(3) The suit was barred under Rule 2 of Order II of the Code of Civil Procedure, as the
cause of action for the suit as well as for the earlier suit of 1950 being one and the
same, the plaintiff ought to have claimed all the reliefs flowing from it in the former
suit.
(4) The suit was barred by time under Article 115 of the Limitation Act, as it was filed
more than three years after the date on which the contract had been cancelled by the
then United State of Vindhya Pradesh.
(5) If the plaintiff could be held entitled to damages, then the amount of damages
proved, to which they would be entitled, would be Rs. 87,170/-.
6. The first question that arises for consideration in this appeal is whether the State of Madhya
Pradesh could be held liable in damages for a breach of contract which admittedly was committed by
the then United State of Vindhya Pradesh. This point, though raised in the written statement, was
not properly appreciated by the learned trial Judge, because, it may be, that on account of a clerical
mistake in paragraph 11 of the written statement, where this point was raised, its importance was
not fully appreciated.
7. The objection, in short, may be stated as follows. The contract of lease in question was entered
into on or about 14-12-1948 by the plaintiffs with the Government of the United States of Vindhya
Pradesh. Its cancellation was also done by the United States of Vindhya Pradesh on or about
26-9-1949. Thereafter, ' on 26-12-1949, the United States of Vindhya Pradesh was dissolved with the
merger of the integrating Slates with the Union of India; and on 26-1-1950, a new State called theFirm Bhagwandas Shobhalal Jain, A ... vs State Of Madhya Pradesh on 29 April, 1964

State of Vindhya Pradesh, a centrally administered area as a Part C State under the Constitution of
India, came into being. The Government never by legislation, agreement, or otherwise, expressly or
impliedly, recognized the rights of the plaintiffs in the lease in question: and consequently no
liability in respect of its breach could be fastened on it by this suit. The Part C State of Vindhya
Pradesh was succeeded by the new State of Madhya Pradesh which also did not expressly or by
implication recognize any such rights as could fasten on it any responsibility in respect of any breach
by the then Government of the United States of Vindhya Pradesh.
8. In Umaid Mills Ltd. v. Union of India AIR 1963 SC 953 at pp. 960 and 961, their Lordships of the
Supreme Court said:
"It is now well settled by a number of decisions of this Court that an act of State is the
taking over of sovereign powers by a State in respect of territory which was not till
then a part of it, by conquest, treaty, cession or otherwise, and the municipal courts
recognized by the new Sovereign have the power and jurisdiction to investigate and
ascertain only such rights as the new sovereign has chosen to recognize or
acknowledge by legislation, agreement or otherwise; and that such a recognition may
be express or may be implied from circumstances. The right which the appellant
claims stems from the agreement entered into by the Ruler of Jodhpur. The first
question is, did the succeeding Sovereign, the United State of Rajasthan, recognize
the right? .. .. .. The United State of Ra.jasthan had in no way affirmed the
agreement.. . ..So far as the Part B State of Ra.jasthan is concerned, there is nothing
in the record to show that it had affirmed the agreement. .. .. ,. ..Neither the United
State of Rajasthan nor the State of Rajasthan affirmed the agreement .. .. ..What then
is the position? If the new Sovereign, namely, the United State of Rajasthan or the
Part B State of Rajasthan, did not affirm the agreement so far as exemption from the
excise duty or income-tax was concerned, the appellant is clearly out of court."
9. What is an act of State has now been settled by a string of authorities, as also the effect of an act of
State on the contractual rights of a person, with the ex-sovereign State.
10. Defining the expression 'act of State,' the Supreme Court in D.D. Cement Co. Ltd. v. Income-tax
Commissioner, AIR 1958 SC 815 at pp. 822 and 823 said:
"The expression 'act of State' is, it is scarcely necessary to say, not limited to hostile
action between rulers resulting in the occupation of territories. It includes all
acquisitions of territory by a sovereign State for the first time, whether it be by
conquest or cession. Vide Vajesinghji Joravar Singhji v. Secretary of State, 51 Ind App
357 at p. 360: (AIR 1924 PC 216 at p. 217) and Thakur Amar Singhji v. State of
Rajasthan, 1955-2 SCR 303 at p. 335 :( (S) AIR 1955 SC 504 at p. 523). And on
principle, it makes no difference as to the nature of the act, whether it is acquisition
of new territory by an existing State or, as in the present case, formation of a new
State out of territories belonging to quondam States. In either case, there is
establishment of new sovereignty over the territory in question, and that is an act ofFirm Bhagwandas Shobhalal Jain, A ... vs State Of Madhya Pradesh on 29 April, 1964

State.. .. .. When the sovereign of a State ----meaning by that expression, the
authority in which the sovereignty of the State is vested, enacts a law which creates,
declares, or recognizes rights in the subjects, any infraction of those rights would be
actionable in the Courts of that State even when that infraction is by the State acting
through its officers. It would be no defence to that action that the act complained of is
an act of State, because as between the sovereign and his subjects there is no such
thing as an act of State, and it is incumbent on his officers to show that their action
which is under challenge is within the authority conferred on them by law. Altogether
different considerations arise when the act of the sovereign has reference not to the
rights of his subjects but to acquisition of territories belonging to another sovereign.
That is a matter between independent sovereigns and any dispute arising therefrom
must be settled by recourse not to municipal law of either State but to diplomatic
action, and that failing, to force. That is an act of State pure and simple, and that is its
character until the process of acquisition is completed by conquest or cession. Now,
the status of the residents of the territories which are thus acquired is that until
acquisition is completed as aforesaid they are the subjects of the ex-sovereign of
those territories and thereafter they become the subjects of the new sovereign. It is
also well established that in the new set-up these residents do not carry with them the
rights which they possessed as subjects of the ex-sovereign, and that as subjects of
the new sovereign, they have only such rights as are granted or recognized by him.
Vide Secretary of State v. Bai Rajbai, 42 Ind App 229 : "(AIR 1951 PC 59), 51 Ind App
357 : (AIR 1924 PC 216) (supra), Secretary of State v. Rustam Khan 68 Ind App 109
:(AIR 1941 PC 64) and Asrar Ahmed v. Durgah Committee, Ajmer, AIR 1947 PC 1."
Their Lordships also quote with approval the observations of Lord Dunedin in 51 Ind
App 357: (AIR 1924 PC 216) (supra):
"When a territory is acquired by a sovereign State for the first time that is an act of
State. It matters not how the acquisition has been brought about. It may be by
conquest, it may be by cession following on treaty, it may be by occupation of
territory hitherto unoccupied by a recognized ruler. In all cases the result is the same.
Any inhabitant of the territory can make good in the municipal Courts established by
the new sovereign only such rights as that sovereign has, through his officers,
recognized. Such rights as he had under the rule of predecessors avail him nothing.
Nay more, even if in a treaty of cession it is stipulated that certain inhabitants should
enjoy certain rights, that does not give a title to those inhabitants to enforce these
stipulations in the municipal Courts. The right to enforce remains only with the high
contracting parties."
11. It is important to note that the aforesaid observations were made while repelling the contention
that rights to properties which were granted to persons by ex-sovereigns by leases, jagirs or the like,
could not be interfered with by the new sovereign, because these were guaranteed to them under the
treaty entered into between the ex-sovereign and the new sovereign. In that case, the appellant had
held certain lands from the Scindia of Gwalior under a grant. After the territory, where the lands
were situate, had been ceded to the British Government by a treaty which provided for theFirm Bhagwandas Shobhalal Jain, A ... vs State Of Madhya Pradesh on 29 April, 1964

recognition by the new sovereign of rights of the residents under existing leases, jagirs and the like,
the British Government in violation of those rights proposed to lease the lands to them which was
objected to by them on the ground that their rights could not be interfered with in the manner
proposed to be done.
12. In Cook v. Sprigg, 1899 AC 572, which was also cited with approval by the Supreme Court, the
facts were that the ruler Pondoland in Africa had granted certain concessions in favour of the
appellants and subsequently ceded those territories to the British Government; and the latter having
declined to recognize those concessions, the appellants sued for a declaration of their rights
thereunder. Negativing the claim, the Lord Chancellor said:
"The taking possession by Her Majesty, whether by cession or by any other means by
which sovereignty can be acquired, was an act of State and treating Sigcau as an
independent sovereign----which the appellants are compelled to do in deriving title
from him. It is a well-established principle of law that the transactions of
independent States between each other are governed by other laws than those which
municipal courts administer."
"It is no answer to say that by the ordinary principles of international law private
property is respected by the sovereign which accepts the cession and assumes the
duties and legal obligations of the former sovereign with respect to such private
property within the ceded territory. All that can be properly meant by such a
proposition is that according to the well-understood rules of international law a
change of sovereignty by cession ought not to affect private property, but no
municipal tribunal has authority to enforce such an obligation. And if there is either
an express or a well-understood bargain between the ceding potentate and the
Government to which the cession is made that private property shall be respected,
that is only a bargain which can be enforced by sovereign against sovereign in the
ordinary course of diplomatic pressure."
13. In State of Saurashtra v. Memon Haji Ismail AIR 1959 SC 1383, Hidayatullah, J., speaking for
the Court, borrowing the phrase of Fletcher Moulton, L. J. in Salaman v. Secretary of State (1906) 1
KB 613 called an 'act of State', 'a catastrophic change constituting a new departure', which was a
'sovereign act' which was 'neither grounded in law' nor did it 'pretend to be so'. He then examined
the principles laid down in Secretary of State v. Kamachee Boye Sahaba, 13 Moo PC 22 (PC) Ex-Raja
of Coorg v. East ' India Co. (1860) 54 ER 642 ; Sirdar Bhagwan Singh v. Secretary of State 2 Ind App
38 (PC) and 68 Ind App 109: (AIR 1941 PC 64) wherein it had been held that the transactions of
Independent States between each other were governed by other laws than those which Municipal
Courts administer, as such Courts have neither the means nor the power of enforcing any decision
which they make, and said:
"The principle of these cases has been extended to all new territories whether
acquired by conquest, or annexation or cession or otherwise and also to rights,
contracts, concessions, immunities and privileges erected by the previous paramountFirm Bhagwandas Shobhalal Jain, A ... vs State Of Madhya Pradesh on 29 April, 1964

power. These are held to be not binding on the succeeding power even though before
annexation it was agreed between the two powers, that they would be respected. "
14. In Jagannath Agarwala v. State of Orissa AIR 1961 SC 1361 the appellant sought to enforce a
claim for money against the State of Orissa based on a breach of contract entered into by the State of
Mayurbhanj and its Ruler prior to the merger of the State with the State of Orissa. The claim was
investigated by a Claims Officer; but ultimately the appellant was informed by the State Government
that it had been rejected as it was barred by limitation. In an appeal from an order of the Orissa
High Court under Article 226 of the Constitution, it was contended for the State of Orissa that the
rejection of the claim was an act of State and that the new Sovereign State could not be compelled by
a process of Municipal Courts to accept a liability of the old Ruler. Upholding the contention, the
Court said:
"What is an act of State and when it ceases to apply between a new Sovereign and the
subjects of a State conquered, acquired or ceded to the new Sovereign, has been the
subject of several decisions of this Court. In 1959 SCR 729 : (AIR 1958 SC 816) and
1960-1 SCR 537 : (AIR 1959 SC 1383) it has been held that unless the new Sovereign,
either expressly or impliedly, admits the claim, the municipal courts have no
jurisdiction in the matter. The question to consider is whether such a stage had been
'reached in the enquiry which had been commenced. No doubt, the plea that this was
a part of an act of State was not specifically raised before the High ourt; but, as
pointed out by the Judicial Committee in 51 Ind App 357 : (AIR 1924 PC 216) no plea
is really needed .. .. .. .. It is the acceptance of the claim which would have bound the
new Sovereign State and the act of State would then have come to an end. But short
of an acceptance, either express or implied, the time for the exercise of the Sovereign
right to reject a claim was still open.: .. .. .. In short, till there was an acceptance by
the Government or some officer of the Government, who could be said to bind the
Government, the act of State was still open, and, in our opinion, it was so exercised in
this case."
15. In this connection, it is interesting to note that Bose, J., who recorded a separate, opinion in D.
D. Cement Co.'s case AIR 1958 SC 816 (supra) and doubted whether the English view which had
been followed in India so far, viz., that all rights to property, including those in real estate, are lost
when a new Sovereign takes over, except in so far as the new Sovereign chooses to recognize them or
confer new rights in them, was correct in view of the fact that it was contrary to the trend of modern
international thought and certain American decisions. But, even so, he held that that view did not
extend to personal rights such as those based on contract, nor, in any event, did the new Sovereign
assume any obligations of the old State in the absence of express agreement. He further held that for
our country that should be the law so far as personal rights were concerned.
16. Examining the facts of our case in the light of the principles enunciated above, we find that the
alleged contract in question was a contract for the sale and purchase of tendu leaves from the
Isanagar pargana of the old Charkhari State, which was originally entered into between the plaintiffs
and the then United State of Vindhya Pradesh. Its breach was also committed by the latter whenFirm Bhagwandas Shobhalal Jain, A ... vs State Of Madhya Pradesh on 29 April, 1964

they unilaterally rescinded it by their letter dated 26-9-1949. Whatever rights such a breach gave to
the plaintiffs were no better than personal rights based on contract enforceable against the party in
breach, viz., the United State of Vindhya Pradesh.
17. As from 26-12-1949, by the agreement of integration or merger, the then Ruler of Charkhari
State, as also all the other Rulers of the States forming the United State of Vindhya Pradesh, ceded
the governance of their territories to the Government of India. There was thus a change in the
sovereignty over the territory in question by the disintegration of the United State and the
acquisition by cession of that territory by the Government of India. On 26-1-1950, on the coming
into existence of the Constitution, a new State was formed out of the territories of the old United
State of Vindhya Pradesh, called the State of Vindhya Pradesh, a part C State under the Constitution.
This cession of the territories of the old Charkhari State by its Ruler, as also by the United State of
Vindhya Pradesh, and the consequent relinquishment of their sovereignty over them as from the
date of the agreement of merger, the Government of India's acceptance of sovereignty over the new
territories and their subsequent formation of a new State under the Constitution called Vindhya
Pradesh, Part C State, out of the territories belonging to the quondam States, was an 'act of State'.
18. When there is an 'act of State' the new Sovereign does not ipso facto assume any obligations of
the old State. The municipal Courts of the new Sovereign have the power and jurisdiction to
investigate and ascertain only such rights in respect of the old Sovereign as the new Sovereign has
chosen to recognize or acknowledge by legislation, agreement, or otherwise; and that such a
recognition may be express or may be implied from circumstances.
19. The right, which the plaintiffs claim, is a personal right which stems from the agreement entered
into by them with the United State of Vindhya Pradesh. This right, or contract, or obligation, was
never expressly or impliedly acknowledged or recognized by the new Sovereign, viz., the
Government of India. Consequently, neither the contract in suit nor the obligations arising
therefrom were binding on the Part C State of Vindhya Pradesh, nor could any such rights or
obligations bei enforced in the municipal Courts of the new' Sovereign.
20. The obligation, being of the ex-sovereign, the fact that it was being enforced by the subject of the
new Sovereign makes no difference, because the municipal Courts of the new Sovereign have
jurisdiction and power to investigate and ascertain only such rights as the new sovereign has chosen
to recognize or acknowledge, expressly or impliedly and all rights not so acknowledged or
recognized, they have no power to adjudicate upon.
21. The fact that, in the instrument of accession or merger, a stipulation had been made that as from
the date of merger the United State of Vindhya Pradesh shall cease to exist and all the property,
assets and liabilities of that State as well as its rights, duties and obligations shall be those of the
Government of India, cannot entitle the appellants-plaintiffs to enforce that stipulation in the
municipal Courts of the new Sovereign. The right to enforce it remains only in the high contracting
parties.Firm Bhagwandas Shobhalal Jain, A ... vs State Of Madhya Pradesh on 29 April, 1964

22. In the instant case, however, even the high contracting party, whose obligation it is said to be,
had repudiated it for the reason that it was 'without proper authority' and 'in contravention of past
practice'. It is further significant that even if it had not been so repudiated, the contract, even if
subsisting on the date of merger between the plaintiffs and the United State of Vindhya Pradesh,
was not binding on the Part C State of Vindhya Pradesh, in view of the 'act of State' and in view of
the fact that it had not expressly or impli-edly recognized or acknowledged the obligation.
Consequently, if the contract in question, if any, was not legally binding on the new Sovereign, viz.,
Part C State of Vindhya Pradesh after merger, and could have been vali-dly repudiated by it without
incurring any obligation thereunder, it could also not furnish any cause of action to the
plaintiffs-appellants when the contract had already been repudiated by the United State of Vindhya
Pradesh itself prior to the merger, unless the new Sovereign chose to recognize or acknowledge it, of
which there was no evidence in the case.
23. On a parity of reasoning, the new State of Madhya Pradesh was in the same position as the Part
C State of Vindhya Pradesh if not better ; and that consequently the suit of the plaintiffs claiming
damages in respect of a breach of contract committed by the United State of Vindhya Pradesh, even
if there was such a breach, did not lie in the municipal Courts of the new State.
24. We are, therefore, of opinion that the objection raised as to maintainability of the suit on the
ground of an 'act of State' was well founded and shall have to be upheld.
25. The decision on the aforesaid point completely disposes of the appeal; but in order to complete
the judgment, we shall briefly consider a few other questions which were also argued at the Bar.
26. The first question is what the quantum of damages would be to which the plaintiffs may be
entitled, if the defendant were to be held liable for breach of the contract in suit.
27. The plaintiffs had claimed damages amounting to Rs. 1,80,000/-. The defendant had denied the
damages altogether; while the trial Court has assessed them at Rs. 87,170/-.
28. The plaintiffs had claimed damages on the following basis: The total area of Isanagar Pargana of
the old Charkhari State was 89,985 acres. Out of this, after re-grouping of the forest circles, 60,891
acres was included in the Pahargaon forest circle, and the rest 29.094 acres in Alipura and
Chhatarpur forest circles. Pahargaon circle was purchased by the plaintiffs in auctions for the year
1950-1951 for a consideration of Rs. 12.600/- and for the years 1951 to 1954 for a consideration of
Rs. 45,000/- per annum. The total area of Pahargaon circle was 1,52,320 acres, and consequently,
for an area of 60,891 acres which was from out of the old Isanagar Pargana the proportionate
premium payable would be Rs. 59,004/-. The loss due to excess premium paid in respect of this area
was thus, broadly speaking, Rs. 59,004--4,000 i.e. Rs. 55.004/-.
29. Now, for the rest of the area of 29,094, the claim has been based not on the loss due to excess
payment of consideration but on the loss of profits, which the plaintiffs would have earned but for
the wrongful cancellation of the theka. This loss of profits has been calculated on the basis of profits
earned in Isanagar area included in the Pahargaon circle for an equivalent area. The total loss ofFirm Bhagwandas Shobhalal Jain, A ... vs State Of Madhya Pradesh on 29 April, 1964

profits calculated on the aforesaid basis has been worked out as under:
Year Acres No. of Gaddies of leaves.
No. of Bhakkas.
Rate per Bhakka.
Price of yield.
Expenditure incurred.
Profits for the year.
1950-51 29,094 11,67,833 Rs. 21.
55,608 21,184/-
34,424/-
1951-52 29,094 19,90,611 Rs. 24.
94,800 32,894/-
62,706/-
1952-53 29,094 10,39,964 Rs. 16.
51,424 23,569/-
27,855/-
1953-54 29,094 7,55,281 Rs. 22.
47,212 16,453/-
30,759/-
The total loss of profits for this area thus works out at Rs. 1,55,744/-. Giving up the
rest of the claim, only Rs. 1,20,996/r has been claimed on this account. The total loss
of profits for the whole area thus claimed comes to Rs. 55,004 + Rs. 1,20,996 = Rs.
1,76,000.Firm Bhagwandas Shobhalal Jain, A ... vs State Of Madhya Pradesh on 29 April, 1964

30. The trial Court has calculated damages on the basis of loss due to excess premium paid. It has,
on the basis of total premium paid for four years for Pahargaon circle of 238 Sq. Miles, calculated
the proportionate premium payable for an area of 147 Sq. miles, which was the area of the old
Isanagar Pargana, and deducting from it the premium payable in terms of his contract of lease, has
worked out the excess premium paid which, according to it, was the loss suffered by the plaintiffs on
account of breach of the contract. On computation, the loss of premium suffered by the plaintiffs
due to wrongful cancellation of the contract comes to Rs. 87,170/- which he has held to be the
damages suffered.
31. In our opinion, both the methods are not wholly correct. The plaintiffs are entitled to such
damages as they may have suffered because of the wrongful cancellation of the contract of lease, i.e.,
the law should endeavour to place them in the same position in which they would be but for the
aforesaid wrongful cancellation. The contract was for earning profits by the collection and sale of
tendu leaves from the Isanagar Pargana of the old Charkhari State for the years 1950 to 1954. Now,
the Isanagar Pargana of the old Charkhari State has been re-grouped into two areas one in the
Pahargaon circle and the other in the Alipura and Chhattarpur circles. Of this, the area in Pahargaon
circle, along with some other areas in that circle, was taken by the plaintiffs on lease for the whole
period of the contract in suit by bidding at the open auctions for a total consideration of Rs.
1,47,600/- (Rs. 12,600/- for the year 1950-51 + Rs. 45,000/- per annum for the next three years).
Consequently, they had earned all the profits that they would have earned from that area if the
contract had been honoured, except that they were required to pay towards the premium, a sum
which was very much in excess of the premium payable under their contract. This excess premium,
which the plaintiffs were required to pay in respect of the portion of the Isanagar Pargana in their
possession, can be taken to be proportional to its area. As the total area of the Pahargaon circle was
1,52,320 acres and that of the old Isanagar Pargana included in it 60,891 acres, the proportionate
premium payable would be 60891 x 1,47,600 1,52,320 i.e., Rs. 59,004/- and deducting from it the
proportionate premium payable in respect of this area in terms of their contract, i.e., 60891 x 4000
89,985 the loss of profits suffered by them in respect of this area by payment of excess premium
works out at Rs. 59,004--Rs. 2706 (to the nearest rupee) i.e.. Rs. 5629S/-.
32. Now remains the area of 29,094 acres which has been included in the new grouped Alipura and
Chhatarpur circles. We do not know if these were auctioned; and. if so, for how much. We also do
not know if they contained tendu leaves proportionate to that area as compared to the area in the
Pahargaon circle. It is common knowledge that all areas need not contain an even distribution of
leaves, so that it cannot, with any reasonable degree of certainty, be said that net profits for the area
of 29,094 acres would be equivalent to the net profits of an equal area of the Isanagar Pargana
included in the Pahargaon circle. It may be that the plaintiffs have chosen areas with prolific growth
of leaves and consequently may not answer any law of averages. It is pertinent to note that the
plaintiffs were the lessees of this area --also for the previous four years and could, therefore, have
given the net yield of tendu leaves in those years. They admittedly keep account books on which they
have relied for proving their profits. Consequently, there is no reason why they did not disclose their
profits from this area of 29,094 acres for the previous four years. In our opinion, that would have
been a far more reliable and satisfactory method of computing net profits for this area of 29.094
acres than the method adopted by the plaintiffs, which, in our opinion, cannot possibly give any ideaFirm Bhagwandas Shobhalal Jain, A ... vs State Of Madhya Pradesh on 29 April, 1964

of the loss ci profits for that area. As the plaintiffs had, within their power to give, better and more
satisfactory data for the computation of damages in respect of this area of 29,094 acres and they
have not cared to give it, but have relied on a very hypothetical and misleading data, we hold that
the damages for this area have not been proved. The plaintiffs would thus be entitled to Rs. 56298/-
only as proved damages. The rest of their claim shall have to be dismissed, even if it were held that
they were entitled to damages as on a breach of contract.
33. It has also to be remembered that the law imposes a duty upon the plaintiffs to take all
reasonable steps to mitigate the loss caused by a breach of contract and debars him from claiming
compensation for any part of the damages which is due to his neglect to do so: British Westing
House Electric and Manufacturing Co. Ltd. v. Underground Electric Railways Co. of London Ltd.
1912 AC 673 at p. 689. It may, therefore, well be that this taking of the contract by the plaintiff for
the collection and removal of tendu leaves from the Pahargaon circle was a step in this direction and
consequently the area from which they had purchased the right being more than the area of the
Isanagar Pargana, they could not yet claim the loss in profits due to their being deprived of
possession of 29,094 acres out of the area which was then included in Alipura and Chhatarpur
circles. It has also not been shown that contract of the Isanagar Pargana was only a part of their
requirements, and that consequently they were not minimising damages when they were taking the
contract of the Pahargaon circle. On the other hand, the fact that they claimed only the loss of profits
due to excess premium paid in respect of that part of the area in Pahargaon circle which was
formerly included in the Isanagar Pargana of the old Charkhari State, showed that they had taken
the contract of Pahargaon circle to mitigate their damages. The claim for loss of profits in respect of
29,094 acres can thus not be allowed on the aforesaid ground also.
34. The second question is whether the suit was barred by time.
35. The suit was filed on 30-8-1954 claiming compensation from the defendant for a breach of
contract to pluck and remove tendu leaves from the Isanagar Pargana of the old Charkhari State for
the period 1-10-1949 to 30-9-1954. The contract was entered into by the United State of Vindhya
Pradesh on or about 14-12-1948 and was repudiated by it on 26-9-1949 before it had become
operative.
36. The contract was for the sale and purchase of tendu leaves which can be likened to an annual
crop which begins to sprout in December and January and is gathered by June. The agreement to
sale was thus of 'future goods' within the meaning of Section 2, Clause (6), of the Indian Sale of
Goods Act. It is possible for a person to agree to sell goods which are not in existence on the date of
the contract of sale, if it be the natural product of something to which the seller has a present right.
The distinction between 'a sale' and 'an agreement to sell' has been well brought out in Section 4 of
the Sale of Goods Act. Where the property in the goods is transferred in praesenti to the buyer, the
transaction is a 'sale'. But. if the property in the goods is to be transferred at a future time, the
transaction is an 'agreement to sell'. As the tendu leaves, the subject-matter of the contract in suit,
were not in existence on the date of the contract, the contract was a contract to sell or an agreement
to sell, and not a sale.Firm Bhagwandas Shobhalal Jain, A ... vs State Of Madhya Pradesh on 29 April, 1964

37. Whether a contract to sell is a single indivisible unit or comprises several 'severable' units is a
question of fact in each case depending on the intention of the parties, viz., whether they intended to
create a single indivisible contract or a bundle of separate contracts. In the instant case, the
plaintiffs had applied for and obtained an extension of the contract for five years for a consideration
of Rs. 5,000/- payable in five equal instalments of Rs. 1000/- each on the 1st February of every year
of contract beginning from 1-2-1950: (see Exs. P-26 andP-27).A contract is said to be severable
when the parties intend that there shall be a number of separate promises supported by separate
considerations, as for example, where goods are to be delivered and paid for by instalments, and
each instalment is to be regarded as a distinct undertaking: (see Jackson v. Rotex Motor and Cycle
Co., 1910-2 KB 937). But, here there is a single promise for a single consideration. The contract is for
a unit period of five years and for a single consideration of Rs. 5,000/- for the whole period. It is
true that the consideration is payable in five instalments of Rs. 1,000/-per year each; but from this
alone, it cannot be suggested that each year's crop was severally agreed to be sold for Rs. 1,000/-
and that the contract in question was a composite contract of five distinct undertakings, each
supported by a separate specific consideration. On the other hand, the contract provides that the
duration of its effectiveness was from 1-10-1949 to 30-9-1954 within which period the plaintiffs
could remove the forest produce agreed to be purchased by them and that they could do so only
within that period. To us it appears that the^ total consideration of Rs. 5,000 as well as the total
period of five years were integral parts of the consideration, and the whole contract was a single
indivisible unit; and the parties had not agreed to enter into five contracts to sell, each for one year
on a severable consideration of Rs. 1,000/- per annum.
38. Ordinarily, a contract cannot be terminated unilaterally.
"Consequently, if one party commits a breach sufficiently serious to constitute a
discharge, it does not automatically abrogate the mutual obligations, but merely gives
the other party an option either to ignore the breach and to insist upon performance
when due, or to accept the repudiation and treat himself as free from further liability.
If he adopts the latter course, he can sue for damages forthwith, whether the time for
performance is due or not; but if he refuses to regard the contract as discharged, he
presents the guilty party with an opportunity to reconsider his attitude." (See
Cheshire and Fifoot's The Law of Contract', Fifth Edition, p. 491).
In the instant case, we have no doubt that though the termination of the contract by
the United State of Vindhya Pradesh was unilateral, it was very specific and definite.
It could have left no doubt that so far as the United State of Vindhya Pradtsh was
concerned, the contract had been as unequivocally rescinded as possible. On receipt
of the letter of rescission, the plaintiffs had made a representation to the Chief
Minister of the State on or about 8-10-1949 (Ex. P-30), but that had also been
rejected by him. Thereafter, the Isanagar Pargana, in respect of which they had been
granted the right was broken up and re-distributed in three circles, viz., Pahargaon,
Alipura and Chhatar-pur, so that it must have been clear to the plaintiffs that any
reconsideration of the question on the part of the United State of Vindhya Pradesh
was out of question. We have also no doubt that the plaintiffs had also accepted theFirm Bhagwandas Shobhalal Jain, A ... vs State Of Madhya Pradesh on 29 April, 1964

repudiation and treated themselves as free from further liability. There is no evidence
that they performed any of their obligations under the contract thereafter, nor that
they continued to offer the consideration on due dates. On the other hand, they filed
a suit, for injunction and damages against the State of Vindhya Pradesh, Part C State,
basing their cause of action on the illegal repudiation of the contract by the United
State of Vindhya Pradesh. The case was thus squarely governed by the provisions of
Article 115 of the Indian Limitation Act, and the period of limitation started from the
date of breach of the contract, which occurred in the instant case on 26-9-1949. The
contract, having been rescinded by the United State of Vindhya Pradesh and the
rescission having been accepted by the plaintiffs, no question of successive breaches
arises, nor can it be said to be a case of continuing breach. Consequently, the trial
Court rightly held that the claim of the plaintiffs was barred by time.
39. On the third question also, if we are right in holding that the repudiation of the contract had
been accepted by the plaintiffs who had thereafter considered themselves free from any obligation
arising thereunder, the suit was barred under Rule 2 of Order II of the Code of Civil Procedure as
well, as all the reliefs flowing from the same cause of action should have been claimed in one suit,
and not split up as the plaintiffs claim to do. Under that rule, 'where a plaintiff omits to sue in
respect of, or intentionally relinquishes, any portion of his claim, he shall not afterwards sue in
respect of the portion so omitted or relinquished'. The rule is a corollary to Rule 1, which says that
'every suit shall include the whole of the claim which the plaintiff is entitled to make in respect of the
cause of action; but a plaintiff may relinquish any portion of his claim in order to bring the suit
within the jurisdiction of any Court'. 'Cause of action' means all the essential bundle of facts which a
plaintiff must allege and prove in order to entitle him to the reliefs claimed. According to the
Judicial Committee of the Privy Council in Rajah of Pittapur v. Sri Rajah Venkata Mahipatisurya 12
Ind App 116 (PC), 'cause of action' in Order II, means 'the cause of action for which the suit is
brought'. Now, the civil suit of the plaintiffs filed by them in 1950 was based on the allegation that
there was a contract with United State of Vindhya Pradesh, that the United State of Vindhya
Pradesh had committed breach of that contract by illegally rescinding it, and that the breach had
caused damages to them for which they were suing. It was also alleged that the first season for leaf
collection began in 1950; but before that could happen, the State Government had auctioned the
forests, first for one year (1949-50), then again for one year (1950-51) and thereafter for three years
(1951-1954). They, therefore, filed the suit claiming Rs. 1,00,000 as damages for the year 1950 only.
It would be noticed that the contract alleged is one of which the breach had been complained on
account of its illegal repudiation by the State Government giving the plaintiffs right to damages.
There was nothing to prevent them from claiming all the damages, to which were entitled on
account of the breach. Where there is a breach of one and the same contract, the reliefs cannot be
allowed to be spill up : (See Duncan Brothers & Co. v. Jeet-mull, ILR 19 Cal 372 (FB) ). The matter
may be different where there are several contracts contained in the same instrument, in which case
the causes of action would be different for every one of them. Thus, where it is expressly provided by
an indent that each monthly shipment and item should be treated as a separate contract, the
plaintiff is entitled to bring a separate suit for damages in respect of each shipment: (see Volkart v.
Sabju Sahib, ILR 19 Mad 304 and Mandal and Co. v. Fazul Ellahie, ILR 41 Cal 825: (AIR 1915 Cal
126)). In the instant case, however, the contract is one and indivisible, the breach is also one, andFirm Bhagwandas Shobhalal Jain, A ... vs State Of Madhya Pradesh on 29 April, 1964

consequently the plaintiffs had only one cause of action which could not be split up in the manner
sought to be done. The lower Court was, thus, right in holding that the suit was barred under Rule 2
of Order 2 of the Code of Civil Procedure.
40. The appeal, therefore, fails and is dismissed with costs.Firm Bhagwandas Shobhalal Jain, A ... vs State Of Madhya Pradesh on 29 April, 1964

