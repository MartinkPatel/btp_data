Centre For Public Interest Litigation vs U.O.I on 23 February,
2018
Author: Adarsh Kumar Goel
Bench: Uday Umesh Lalit, Adarsh Kumar Goel
                                                                                       1
                                                                               REPORTABLE
                                           IN THE SUPREME COURT OF INDIA
                                       CIVIL APPELLATE/ORIGINAL JURISDICTION
                                           CIVIL APPEAL NO. 2422 OF 2018
                              (ARISING OUT OF SPECIAL LEAVE PETITION (CIVIL) NO.1808 OF
                                                        2016)
                         S. SUKUMAR                                       …APPELLANT
                                                       VERSUS
                         THE SECRETARY, INSTITUTE OF CHARTERED
                         ACCOUNTANTS OF INDIA & ORS.                      ...RESPONDENTS
                                                         WITH
                                        WRIT PETITION (CIVIL) NO. 991 OF 2013
                         CENTRE FOR PUBLIC INTEREST LITIGATION              …PETITIONER
                                                       VERSUS
                         UNION OF INDIA & ORS.                              ...RESPONDENTS
                                                   JUDGMENT
ADARSH KUMAR GOEL, J.
1. Leave granted in SLP (Civil) No.1808 of 2016 filed against the order dated 3rd August, 2015 of the
High Court of Karnataka in Writ Petition No.17959 of 2012. The petition before the High CourtCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

sought direction for exercise of power under Section 21 of the Chartered Accountants Act, 1949 (‘CA
Act’) to initiate investigation against Multi-National Accounting Firms (MAFs) and Indian
Chartered Accountancy Firms (ICAFs) having arrangement with such MAFs for breach of Code of
Professional Conduct under the CA Act and also to take penal action by way of cancellation of
permission granted to them by the Institute of Chartered Accountants of India (ICAI). Since the
issue raised in Writ Petition (Civil) No.991 of 2013 is identical, both the matters have been heard
together. In the Writ Petition, some other connected issues have also been raised to which reference
will be made in due course.
The Issue
2. The issue raised in the appeal arising out of Karnataka High Court Judgment and the Writ
Petition filed directly in this Court is:
Whether the MAFs are operating in India in violation of law in force in a clandestine
manner, and no effective steps are being taken to enforce the said law. If so, what
orders are required to be passed to enforce the said law.
The Pleadings
3. Briefly, the averments in the High Court writ petition are: The MAFs are illegally operating in
India and providing Accounting, Auditing, Book Keeping and Taxation Services. They are operating
with the help of ICAFs illegally. Operations of such entities are, inter alia, in violation of Section 224
of the Companies Act, 1956, Sections 25 and 29 of the CA Act, the Code of Conduct laid down by the
ICAI. Reference has been made to the Report dated 15 th September, 2003 of Study Group of the
ICAI on the subject (hereinafter referred to as ‘Study Group Report’). The Study Group was
constituted by the Council of the ICAI in July, 1994 to examine attempts of MAFs to operate in India
without formal registration with the ICAI and without being subject to any discipline and control.
This was in the wake of liberalization policy and signing of GATT by India. It was noted that the
bodies corporate formed for management consultancy services were being used as a vehicle for
procuring professional work for sister firms of Chartered Accountants (CAs). Members of ICAI were
associating with such bodies as Directors, Managers etc. to provide escape route to MAFs. CA
functions must be discharged by animate persons and not in anim bodies.
4. The concerns of various segments of CAs noted by the Study Group are :
“(a) Sharing fees with non-members;
(b) Networking and consolidation of Indian firms;
(c) Need to review the advertisement aspect;
(d) Multi disciplinary firms with other professionals;Centre For Public Interest Litigation vs U.O.I on 23 February, 2018

(e) Commercial presence of multi-national accounting firms;
(f) Impact of similarity of names between accountancy firms and MAFs/Corporates
engaged in MSC-Scope for reform and regulation;
(g) Strengthening knowledge base and skills;
(h) Facilitating growth of Indian CA firms & Indian CAs internationality;
(i) Perspective of the Government, corporate world and regulatory bodies and role of
ICAI in shaping the view;
          (j)    Introduction of joint audit system;
          (k)    Recognition of qualifications under Clause (4) of
Part I of the First Schedule to the Chartered Accountants Act, 1949 for the purpose of
promoting partnership with any persons other than the CA in practice within India or
abroad;
(l) Review the concept of exclusive areas for the keeping in view the larger public
interest involved so as to include internal audit within it;
          (m)      Conditionalities prescribed by certain financial
                 institutions/Governmental     agencies    insisting
                 appointment       of   select   few    firms     as
auditors/concurrent auditors/consultants for their borrowers.”
5. The Study Group considered whether goal should be to focus on ethics or growth of the profession
with Code of Ethics being guiding points and not barriers. Further issues were what should be the
regulatory regime; whether networking could be allowed to benefit Indian CAs; whether MAFs may
be required to furnish particulars about their ownership, persons responsible and other financial
particulars. It was noted that the Code of Ethics under First Schedule to the CA Act prohibits sharing
of fee with persons other than members of the ICAI. Only cost for obtaining assistance/advice to
international affiliates could be given. Indian Firms with International Affiliates (IFIA) may be
required to adhere to bench mark in regard to audit procedures, quality standards etc. Decision
making and real control should be with Indian firms. Number of audits qua each partner should be
fixed. Mentioning of affiliation with any person not member of ICAI may amount to advertising
which was not permissible. It could be permitted if entities were registered with ICAI. It was also
suggested that concept of Multi disciplinary firms was required to be explored for rendering
integrated service with suitable safeguards. Steps to upgrade knowledge were also suggested.
However, it was suggested that commercial presence of MAFs should not be allowed de facto or de
jure. Reference was made to Surbanes Oxley Act, 2002 in USA making a foreign public accountingCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

firm preparing audit report to be accountable to the Public Company Accounting Oversight Board
and the Securities and Exchange Commission. Thus, MAFs could not be allowed without
registration with ICAI. Non Indian CAs should not authenticate any financial statement of any
Indian entity. MAFs’ claim to provide audit services through affiliates amounts to indirect entry in
India without requisite reciprocity for Indian accountancy firms. It was suggested that even where
MAFs affiliate with Indian CA, same brand should not be allowed as in other services. Use of name
identical to MAFs was brand building exercise which gave impression that Indian CA firm was not
independent. Separation of identity was a must. Use of statutory visiting cards etc. must display
separation of identity. Under collective label of management consultancy services, CA services
should not be allowed as Code of Ethics for auditors cannot be enforced in this manner. Audit
cannot be done in non professional way. Advertisement and publicity was harmful to the cause of
the profession so that user relies only on real worth of services. It is further noted that though the
CAs are not allowed to share fees or profits with anyone other than a member of the institute, some
of the members were lending their names to the MAFs who are non-members and enabling them to
illegally operate in the field of Chartered Accountancy and sharing fees and profits with them.
Indian CAs have not been provided reciprocity in the countries to which the MAFs belong as per
Section 29 of the CA Act.
6. Reference has also been made to a report on operations of MAFs in India dated 29th July, 2011
submitted by Expert Group of the ICAI (for short Expert Group Report) in the wake of the ‘Satyam
Scam’, and decisions of the ICAI laying down the Code of Conduct. The Expert Group Report noted
that the MAFs are rendering services which are rendered by the CAs in terms of Section 2(2) of the
CA Act such as accountancy, auditing, professional services about matters of accounting procedure,
presentation or certification of financial facts or data. The MAFs are corporates/juridical persons.
They solicit professional work in international brand name. They have registered Indian CA firms
with ICAI with the same brand names which are their integral part. There is no regulatory regime
for their accountability. Thus, the principle of reciprocity under Section 29 of the CA Act, Section 25
prohibiting corporates from chartered accountancy practice and Code of Ethics prohibiting
advertisement and fee sharing are flouted. The MAFs also violate FDI policy in the field of
accounting, auditing, book keeping, taxation and legal services. Detailed reference to the said report
will be made in the later part of the judgment.
7. The stand of the ICAI in the form of a status report filed before the High Court is that 161 out of
171 firms were examined by the High Powered Committee in pursuance of report of the Expert
Group dated 29th July, 2011 with regard to alleged violations and some of the cases were referred to
the Director (Discipline) for further action. Remaining 10 firms were in the process of being
examined. Thus, the ICAI has already taken action on its part.
8. The High Court observed that in view of the stand of the ICAI, no further action was necessary
and disposed of the writ petition.
9. In the writ petition filed directly in this Court, apart from the averments noted above, it has been
stated that PricewaterhouseCoopers Private Limited (PwCPL) and their network audit firms
operating in India, apart from other violations, have indulged in violation of Foreign DirectCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

Investment (FDI) policy, Reserve Bank of India Act (RBI)/Foreign Exchange Management Act
(FEMA) which requires investigation. Firms operating under the brand name of PwCPL received
huge sums from abroad in violation of law and applicable policies but the concerned authorities
have failed to take appropriate action. M/s. Pricewater House, Bangalore was the Auditor of the
erstwhile Satyam Computer Services Limited (Satyam) for more than eight years but failed to
discover the biggest accounting scandal which came to light only on confession of its Chairman in
January, 2009. The said scandal attracted penalty of US Dollars 7.5 Million (approx. Rs.38 crores)
from the US Regulators apart from other sanctions. Since certification by Auditors is of great
importance in the matter of payment of subsidies, export incentives, grants, share of government
revenue and taxes, sharing of costs and profits in PPP (Public Private Partnership) contracts etc.,
oversight of professionals engaged in such certification has to be as per law of the land. Accordingly,
even though investigation was sought by the petitioner vide letter dated 1 st July, 2013, no
satisfactory investigation has been done.
10. PwCPL is the brand under which member firms of PricewaterhouseCoopers International
Limited, U.K. (PwCIL), an English private company provides professional services in respect of
audit, tax and advisory services. ‘PwC India’ firms are network member firms of the PwCIL. There
are 10 Audit Firms namely Price Waterhouse (PW), Lovelock and Lewes (LL), Price Waterhouse
Bangalore, Price Waterhouse & Co. Bangalore, Price Waterhouse & Co. Kolkata, Price Waterhouse
Delhi, Price Waterhouse & Co. Delhi, Price Waterhouse & Co. Chennai, Dalal & Shah Mumbai and
Dalal & Shah Ahmedabad, besides a private limited company, namely PwCPL, who are collectively
referred to as “PwC India” firms and who operate from various metros including Delhi. Their clients
include Government departments, Public Sector organizations, ministries for which huge payments
are made to them. They are engaged in auditing/certifying statutory compliances. They have
violated Foreign Direct Investment (FDI) Policy, RBI master circulars, FEMA Act and Rules.
According to Notification dated May 3, 2000, under Section 47(2)(h) of FEMA Act, no person
resident outside India can make investment by way of contribution to the capital of a firm or a
proprietary concern or any association of persons in India without permission of the RBI. In
violation of the said provision, PwC India entities received Rs.240 crores in Financial Year
2010-2011. The Chairman of PwC India confirmed the receipt of funds from Global Network.
Receipt of Rs.22.90 crores in the Financial Year ended March, 2010 is reflected in the balance sheet
and profit and loss account of the PwCPL. Receipt of Rs.7.97 crores is reflected in the balance sheet
and profit and loss account of Dalal & Shah, Mumbai. This apart, approximately Rs.210 crores was
received by PwCPL, Price Waterhouse (PW) and Lovelock and Lewes (LL). However, no action was
taken for receipt of these sums in violation of law. A sum of Rs.41 crores was received by Price
Waterhouse & Company, Kolkata to acquire another audit firm, Dalal & Shah, Mumbai through a
circuitous route by giving interest free loans to its four partners to enable them to invest the said
amount in Dalal & Shah, Mumbai in violations of the RBI Guidelines, FEMA policy and ICAI
Regulations.
11. There is also violation of Companies Act. Insurance premium has been paid by three firms of
PwC for benefit of other member firms which is illegal. Lovelock and Lewes (LL), a member firm of
PwC India failed to point out the high level of NPAs, in its audit report, resulting in Global Trust
Bank (GTB) being forced to merge with Oriental Bank of Commerce in 2004. This happened due toCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

accumulated losses of GTB. LL was also found guilty of manipulating share prices and falsification
of accounts by Serious Fraud Investigation Office (SFIO). PwC has been found guilty of accounting
scandals outside India.
12. After making the above averments, the petition suggests that falsification of accounts should be
made a non-bailable offence to ensure effective governance and to avoid potential loss of revenue to
the public exchequer. An independent regulator should be appointed for the auditors. Prayer has
been made for investigation into the above allegations against the PwCPL and their network Audit
Firms operating in India sharing the brand name of PwC.
13. To sum up, the case of the petitioners is:
(i) The MAFs violate provisions of Sections 25 and 29 of the CA Act, the Code of
Conduct laid down by the ICAI, Companies Act, the FDI Policy as highlighted in
report of the Study Group of the ICAI dated 15th September, 2003 and the report of
the Expert Group of the ICAI dated 29th July, 2011. Regulatory framework was
required to be re-visited to cover the gap in the existing regulatory framework and
challenge on account of operations of MAFs as noted in the said reports. Audit
functions were required to be separated with a separate oversight body.
(ii) PwC Services BV, Netherlands in violation of law, made investment of Rs.41.42
crores through PwC, Kolkata to acquire Dalal & Shah, Mumbai which is an audit firm
through a circuitous route by giving interest free loans to its partners allowing them
to invest the said amount with Dalal & Shah, Mumbai.
This is clear offence under the Benami Transactions (Prohibition) Act. It is also an offence under the
FEMA, the Chartered Accountants Act, and RBI Master Circulars.
(iii) The PwC Services, BV Netherlands remitted Rs.240 crores to various PwC entities in India for
‘enhancement of skills’. Payment of Income Tax on the said amounts does not legalise the
remittance. The remittance shows that the foreign company has control over Indian Firms and is
thus indirectly running chartered accountancy business in India and also getting its return on the
said amount.
(iv) There is falsification of accounts with regard to insurance premium for a 280 crore policy by
PwC firms in India in violation of Companies Act, 1956.
(v)    PwC is responsible for the violations by
       Satyam scam, failure of the Global Trust
       Bank   (GTB)    and      UB   Group    (KingfisherCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

Airlines) for which action ought to be taken.
(vi) SFIO and CBI have found PwC guilty. Still, the PwC firms have not been prosecuted and have
been awarded Government contracts such as GST Suvidha Provider for GST Network, consultancy
contract by the Kerala Government for preparing master plan to connect Kochi with industrial
corridor of south India.
14. The prayers of the petitioners on above basis are:
(a) ICAI must take immediate action for deregistration of these firms in terms of their own report of
2011 which they had themselves accepted.
(b) These audit firms ought to be prosecuted for offences under the Chartered Accountants Act,
1949.
(c) PwC firms ought to be prosecuted under FEMA, 1999 regarding the payment of Rs.240 crores
and Rs.42 crores by the ED.
(d) PwC Kolkata firm and partners need to be prosecuted under the Benami Transactions
(Prohibition) Act.
(e) Investigation and action on part of ICAI and Ministry of Corporate Affairs with regard to the
falsification of accounts and wrong accounting of the insurance policy of Rs.280 crores that was
utilized by PwC Bangalore without paying any premium.
(f) A CBI investigation into the receipt of Rs.240 crores so that the real purpose of such receipts is
known and necessary action may be taken.
High Powered Committee Expert Group Report dated 29 th July, 2011
15. In its report dated 29th July, 2011 on Operation of Multinational Network Accounting Firms
(MAFs) in India, the expert group constituted by the ICAI examined the issues concerning operation
of MAFs in India. The group was constituted in the context of corporate fraud of high magnitude
revealed by the statement of Chairman of Satyam. The ICAI sought curbing of undesirable
activities/operations of MAFs. The Ministry held a meeting with the representatives of the ICAI to
identify the issues. Thereafter, the following issues were referred to the Expert Group by the High
Powered Committee of the ICAI:
“(a) Manner in which certain Indian CA firms, hold out to public that they are
actually MAFs in India, the manner in which assignments are allotted, determination
of nexus/linkage. The representatives of certain Indian CA firms carry two visiting
cards one of Indian CA firm and another of a multinational entity. They represent the
multinational entity and seek work for Indian CA firm.Centre For Public Interest Litigation vs U.O.I on 23 February, 2018

(b) Name used by auditor in/his report – The basic question was whether the
auditors of M/s. Satyam had correctly mentioned the name of their firm in the audit
report.
(c) Terms and conditions and cost payable for use of international brand name – No
international firm will allow its name to be used by all and sundry. The question is
what is the consideration whether it is determined as a percentage of fee or profits
and whether it is within the framework of Chartered Accountants Act, 1949,
Regulations framed, thereunder Code of Conduct and Ethics.
(d) Nature of extra benefits accrued to the Indian CA firms having foreign affiliation.
(e) How the MAFs placed their foot in India – Long back in a meeting with RBI it was
informed that the MAFs entered in India to set up representative offices. No
documents are available as regards the terms and conditions set out while granting
them permission to operate in India.
      However,     the   RBI    vide   its    letter
      No.Ref.DBS.ARS.No.744/08:91:008        (ICAI)/
      2003-2004 dated 23rd March, 2004 inter
alia, mentioned that “RBI has not permitted any foreign audit firm to set up office or
to carry out any activity in India under the current exchange control regulations.”
(f) Contravention of permission originally granted by Government – What was the
original permission given for these firms to enter into India and subsequently
whether they are adhering to the terms and conditions of that permission? If
contravention was found to take up with Government/FIPB – for approaching
Government or FIPB, ICAI must have information as to the nature of permission
given. As already mentioned, no documents are available indicating the nature of
permission granted. What is the current position of international trade in accounting
and related services? The opening up of accounting and related services, can be
linked to reciprocal opening up by developed countries.
(g) Additional powers required by ICAI to curb the malpractices – If under the
existing legislation, ICAI does not have enough powers to curb this practice, whether
they would need more powers. A separate proposal for amendment of Chartered
Accountants Act, 1949 has been sent by the Council to the Government seeking
additional powers.”
16. It was noted that some of the MAFs are active in India and are rendering services which are
provided by CAs without registration with the Institute. Certain MAFs are corporate or juridical
persons with significant commercial presence in India and are rendering assurance services. They
solicit professional work including audit work by including international brand name in their name.
With the same brand names certain Indian CA firms were registered with the ICAI. They hold out toCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

public that they are actually MAFs in India, whereas to the ICAI they hold out that they are purely
Indian CA firms having no relationship with foreign entities. The government, regulators and the
ICAI must ensure that such wrong impression is not permitted. Entities other than CAs in practice
should be prohibited from providing auditing and assurance services in absence of their regulation
under a law. Indian CAs are not getting mutual treatment in other countries, while the MAFs
continue to operate in India through the Indian CA firms. Entities having similar name as that of
MAFs, which entered through automatic/FIPB route, are rendering Chartered Accountancy services
contrary to the policy of not permitting Foreign Direct Investment (FDI) in the field of accounting,
auditing and book keeping services, taxation services and legal services. The Institute requested the
Department of Company Affairs to take the following action:
“(i) for reviewing the existing situation for ensuring reciprocal advantage in favour of
the Indian accounting profession;
           (ii)    to take appropriate action against MAFs if
                   found     to  be   in  violation  including
                   cancellation/revoking/   withdrawal     the
permission already granted to such foreign entities;
(iii) to ensure that the non-compliance of the terms & conditions of the permission
granted by the Government to such MAFs is dealt with effectively;
(iv) to prohibit the MAFs/consultancy firms which have set up commercial presence
either as a corporate entity or otherwise from defying the restrictions in terms of the
Government policy both in letter & spirit;
and
(v) to ensure that the names of the companies which are same or similar to the names of MAFs
should not be allowed to continue to operate in India.”
17. The Institute called for information from the Indian CA firms perceived to be having
international affiliations to examine whether they are functioning within the framework of CA
profession. The exercise resulted in finding out 171 names of firms but the said firms were reluctant
to submit copies of agreements with foreign entities and their tax returns. Certain CA firms
submitted the documents by masking certain portions contained in their agreements, partnership
deeds and assessment orders/income tax returns claiming confidentiality and commercially
sensitive nature of the documents. Some of the firms did not give the details.
18. The group considered network groups as ‘A’ to ‘D’. With regard to ‘A’, it was observed that the
multinational entity had permitted the participating firms in the network to use the brand name.
The relationship between members and firms and how these are governed from the same offices
under common management and control was not disclosed. The linkage was clear from the dataCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

disclosed on the website. Firms received financial grants from non-CA firms contrary to the
prohibition for the members of the Institute to receive any part of profits from non-member of the
Institute. The networking firms have made remittances to a multinational entity, sharing their
revenue purportedly towards subscription fees, technology cost and administration cost etc.
However, the break-ups of costs were not furnished. The cost excluded marketing, publicity and
advertising which was not allowed as per the CA Act. The data was not furnished to support the
claim that remittances are only in respect of such matters and not related to the volume of business
generated through the efforts of the multinational entities. A total and full disclosure was not made
in spite of repeated directions. The domain name used by all the firms in the network was identical
to the name of the multinational entity which supports the view that they hold out that these firms
were part of international network. Some of the firms operate from the same premises from where
their international affiliate also operates. They share the same telephone and fax numbers. They
share human resources with other firms. Articled Assistants are also shared without following the
restrictions imposed by the ICAI.
19. With regard to group ‘B’, the multinational entity had executed sub-licence agreements with the
Indian firms. They stated that they are not sharing their fees or profits with any multinational entity
but reimbursement of costs relating to certain central facilities and levies are made annually. The CA
firms used name of the international entity in their E-mail IDs. The E-mail ID and the domain name
resembled the name of the multinational entity. Thus, in the same manner, as in respect of network
‘A’ the CA firms in network ‘B’ hold out that they are part of the international network. They share
same premises, same telephone and fax number. They made remittances annually to the
multinational entity sharing their revenue with multinational entity which they have claimed to be
towards reimbursement of cost towards central facilities and levies. They do not provide break-up
which may show that the cost included marketing, publicity and advertising.
20. The firms in the Network ‘C’ are also using the MAF’s name as part of domain name in their
E-mail IDs, which is displayed in the visiting cards of the partners of the firms.
21. Similar was the position with regard to Network ‘D’. The firms in Network ‘D’ also used the name
of multinational entity as domain name.
22. The Council has prescribed maximum limit for statutory audit and tax audit which a member in
practice can undertake in a year. But, by sub-contracting the work to other firms, the firms are
undertaking more than the prescribed work leading to deterioration of quality of performance.
23. The member firms are required to refer the work among themselves. In respect of some firms,
referral fee is payable and receivable. Agreements also provided for use of name and logo.
Payment/receipt of referral fee is prohibited as per code of conduct applicable to CAs.
24. The group noted that firms have names identical to the names of MAFs operating in India but in
absence of complete data, a conclusive finding could not be recorded as to violation of the CA Act
with regard to sharing of fees or profits with non-members, securing business through
solicitation/publicity. International affiliations with entities which do not follow the same Code ofCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

Ethics as applicable to Indian CA firms vitiate the level playing field with other Indian CA firms.
Control of the Indian CA firm is effectively placed in the hands of non-members/companies and
foreign entities.
25. Some of the observations in the report are:
“4.2 The Council of ICAI has deliberated that some of the MAFs are active in India
and are rendering services such as assurance services, taxation services, etc. normally
provided by Chartered Accountants, without registration with the Institute and,
without being subject to any disciplinary and regulatory control on the ethical and
independent issues. Certain MAFs either as corporate and other juridical persons
with the Institute brand name were given permission by the other
regulators/Government for doing consultancy business in India. These entities have
established significant commercial presence in India and are rendering assurance
services. These private limited companies in certain cases solicit professional work
including audits by using the international brand name and projecting large
experience, infrastructure and international database including turnover, manpower
size, technical expertise and experience in other countries. These private limited
companies work under the name and style/trade name/brand name of well known
MAFs and in certain cases also co-brand multinational name with certain Indian CA
including by making presentations and organizing mega public programmes. In fact
these firms and individuals employ with them as Directors or partners or in other
capacity and hold out to the public that they are MAFs. In view of their well known
brand and presence internationally the corporate sector, the Government and the
society at large and sometimes even the regulators carry a wrong impression as if
these private limited companies are in fact MAFs and the services being provided by
these private limited companies are actually services being provided by such MAFs.
4.3 Certain Indian CA firms and private limited companies associated with them hold
out to public that they are actually MAFs in India whereas to the ICAI/regulators,
they hold out that they are purely Indian CA firms having no relationship with
foreign entities.
4.4 It is important for the Government, regulators and the ICAI to ensure that such
wrong impression is not permitted and all entities other than Chartered Accountants
in practice and CA firms should be actually prohibited directly or indirectly from
providing auditing and assurance services, as these are required to be regulated in
the public interest.
The very objective of having the profession relating to accountancy under specific Act of Parliament,
incorporating therein a strict disciplinary and ethical code was to ensure that there is no dilution of
the professional standards and services are provided in a regulated manner.Centre For Public Interest Litigation vs U.O.I on 23 February, 2018

4.5 In certain cases, joint venture agreements, MOUs, foreign collaboration agreements,
shareholders agreements, private equity participations and side letters are exchanged between
parties mandating appointment auditors as prescribed by international parent. In certain cases
public sector undertakings, Government departments/Central and State Governments advertise for
various professional services wherein the basic eligibility requirement tends to favour Multinational
Network Accounting firms or other corporate entities. It has also been observed that auditors have
been replaced by Indian CA firms networked with Multinational Network Accounting firms
apparently for no professional reasons.
4.6 The ICAI has been pursuing with the accounting bodies in different countries for recognition of
its qualification and relaxation for its members for entry level requirements like appearance in
certain papers such as accounting, auditing as well as training requirements giving due credit to the
ICAI’s educational and training curriculum. In addition, the Indian Chartered Accountants face
various invisible/non-professional barriers like visa, citizenship and residency requirements,
procedural impediments to provide services in such countries. While the Institute has been pursuing
vigorously for recognition of its qualification-for ensuring level playing field for Indian Chartered
Accountants whereas the countries concerned are not showing a sense of seriousness and urgency
which these matters deserve. Indian Chartered Accountants are not getting a fair, reasonable and
mutual treatment which they deserve. Since MAFs, in corporate or other form, are already
commercially present and operating in India on the basis of holding out as MAFs/the Indian CA
Firms and private limited companies may be de jure owned and managed to Indian Chartered
Accountants, whereas de facto these are fully governed MAFs having headquarters in developed
countries, who are denying a level playing field to Indian Chartered Accountants in their country by
the restrictions as explained herein. As a result the negotiating capacity of India accounting services
favouring the Indian accountants has been significantly reduced. In fact, this has also adversely
affected the bargaining capacity of the Government of India for Indian accounting profession under
the ongoing negotiations under the WTO/General Agreement of Trade in Services (GATS).
xxxx 4.8 However, it has been noticed that the entities having similar name as that of MAFs, which
entered through automatic/FIPB route for rendering management consultancy services (as defined
in CPC
865), are transgressing the permission so granted and are rendering taxation services (CPC 863),
auditing, accounting and book keeping services (CPC 862) and legal services (CPC 861). Instances
brought to the notice of the Study Team constituted by the Council in April, 1995 and the Study
Group constituted by the Council in February, 2002 are placed at Annexure-III. Extracts taken from
the website pages of some of the MAFs are given at Annexure-IV.
4.9 It is noted that as per the policy of the Government of India, Foreign Direct Investment (FDI) is
not permitted in the field of accounting, auditing and book keeping services, taxation services and
legal services and no commitment had been made by India for opening of such services under the
WTO/GATS. However, some entities were not only providing services through their own
establishment (signifying their commercial presence i.e., Mode-3) in India but also through service
providers in India particularly for those services like auditing which cannot be rendered by themCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

under the relevant laws of the country.
xxx 4.16 The 171 firms from whom documents/details were called for by and large furnished the
documents that were called for. However, certain CA firms have submitted the documents by
masking certain portions contained in their agreements, partnership deeds and assessment
orders/income tax returns claiming confidentiality and commercially sensitive nature of the
documents. The financial details were asked with a view to confirm compliance of these firms with
the code of ethics in regard to sharing of fees, inward and outward remittances, nature of expenses,
financial dealing with non-members, nature of payment, nature of revenue sharing of fees belonging
to non-members and to identify activities not permitted within the framework of the Chartered
Accountants Act, 1949, other laws including Foreign Exchange Management Act, 1999 and Foreign
Contribution (Regulation) Act, 1976, Code of Ethics and Conduct. Masking/omission of certain
portions was construed as non-compliance with the directions of the Institute, and such firms which
had masked certain portions were asked to additionally submit copies of their financial statements
i.e. Income & Expenditure Account and Balance Sheets or Statement of Affairs including tax audit
reports for the last 3 years. However, these firms, instead of submitting unmasked and complete
information, had been questioning the logic/reasoning behind asking such data, which according to
the firms are commercially sensitive/confidential. Despite reminders, some of the firms had not
submitted unmasked/complete details.
xxx 5A.8 Observations :
(i) The multinational entity has granted permission to the participating firms in the
network to use the brand name. This is notwithstanding the fact whether the firms
have signed the License Agreement with the entity or not. The relationship between
members and firms how these are governed from same offices under common
management and control is not disclosed. The data disclosed on the website,
however, clearly brings out the linkage.
(ii) Though some of the participating firms in the Network ‘A’ have not signed, the
Verein document of Name License Agreement yet while making remittances to the
multinational entity, the revenue of the entire network is taken into account.
(iii) The Verein document makes a mention of Supplemental Regulation but while
submitting documents to the Institute the firms in Network ‘A’ have not submitted a
copy thereof.
(iv) The networking firms in Network ‘A’ have received financial grants from a
non-CA firm. A member of the Institute is prohibited from receiving any part of
profits from a non-member of the Institute. Such an act on the part of a member/firm
seems to be in violation of Item (3) of Part I of the First Schedule to the Chartered
Accountants Act 1949.Centre For Public Interest Litigation vs U.O.I on 23 February, 2018

(v) The networking firms in Network ‘A’ have made remittances to the multinational
entity, sharing their revenue with multinational entity, which they have claimed to be
towards subscription fees, technology cost including cost of licenses – obtained for
software, budgeted expenses, cost of administration etc. However, the firms have not
provided break-up/computation and whether the cost includes cost towards
marketing, publicity and advertising the products and services in India as well as
abroad and any other cost which is not allowed as per the Chartered Accountants Act,
1949, Regulations framed thereunder and Code of Ethics. The firms in Network ‘A’
have also not furnished any data in support of their claim that the money remitted by
them to the multinational entity is in respect of above matters only and that the same
in no way relates to the volume of business generated through the efforts of the
multinational entity and through use of brand name. A total and full disclosure in
this regard has not been made in spite of repeated directions by the High Powered
Committee/Group on the basis of directions of the Council.
(vi) The Verein document lay an obligation on the member firms in Network A “to
make every reasonable effort to refer clients to other member firms”. A member of
the Institute is prohibited from securing any professional business by means which
are not open to a Chartered Accountant. However, they are required to follow the
networking guidelines of the Institute. Such an act on the part of a member/firm
seems to be in violation of Item (S) 1 of Part I of the First Schedule to the Chartered
Accountants Act, 1949.
(vii) The networking firms in Network A and all their personnel are using the domain
name identical to the name of the multinational entity in their email IDs and the
same is displayed in their visiting cards.
This clearly supports holding out by these firms in Network A that they are part of the international
Network A of MAFs. Some of these firms operate from the same premises from where their
international affiliate also operates. They share the same telephone and fax nos. thus establishing
that they are one and the same. The Indian firms in Network A and MAFs are de facto the same
entities providing assurance, management and related services and as such their operations seem to
circumvent the provisions of the Chartered Accountants Act, 1949 and Regulations framed
thereunder. A member of the Institute is prohibited from disclosing the affiliation with any
international entity. In this regard, the Council, at its 172nd meeting held in January, 1995, while
agreeing with the recommendation of the then Committee on Ethical Standards and Unjustified
Removal of Auditors that the use of expression/words, “In Association with ….”, Associates of ……..”,
Correspondents of ……” etc. on the stationery, letter-heads, visiting cards and professional
documents of the firm of CAs was not permissible in view of the provisions of Item (7) of Part I of
the First Schedule to the Chartered Accountants Act,1949, decided that it should not be permitted
irrespective of whether the name sought to be used is the name of an Indian firm or a foreign firm.
(viii) The networking firms in Network A are sharing their human resources with other firms in the
network. However, it has been possible to ascertain whether the articled assistances are also beingCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

rotated among the firms. It may be mentioned that articled assistants are assigned to a member,
whose obligation is to train them. As such, the articled assistances cannot be allowed to be utilized
by any other member. However, to address this issue, there exists a provision under Regulation 54
of the Chartered Accountants, Regulations, 1988 enabling secondment of articled assistances with a
view to provide the articled assistants the opportunity of gaining practical experience in areas where
the principal may not be in a position to provide the same. Such secondment is allowed under the
Regulations with certain restrictions and conditionalities and the same is required to be sent to the
Institute for records within thirty days from the date of commencement of training on secondment.
xxxx 5B.7 Observations :
(i) The CA firms in Network B and all their personnel are using the domain name
identical to the name of the multinational entity in their email IDs, and the same is
displayed in the visiting cards. This clearly supports holding out by these firms in
Network C that they are part of the international Network C of MAFs.
Some of these firms operate from the same premises from where their international affiliate also
operate. They share the same telephone and fax nos. thus establishing that they are one and the
same. The Indian firms in Network B and MAFs are de facto the same entities providing assurance,
management and related services and as such their operations seem to circumvent the provisions of
the Chartered Accountants Act, 1949 and Regulations framed thereunder. A member of the Institute
is prohibited from disclosing his affiliation with any international entity. In this regard, the Council,
at its 172 nd meeting held in January, 1995, while agreeing with the recommendation of the then
Committee on Ethical Standards and Unjustified Removal of Auditors that the use of
expression/words, “In Association with ……..”, “Associates of …………..”, Correspondents of …………”
etc. on the stationery, letter-heads, visiting cards and professional documents of the firm of CAs.,
was not permissible in view of the provisions of Item (7) of Part I of the First Schedule to the
Chartered Accountants Act, 1949, decided that it should not be permitted irrespective of whether the
name ought to be used is the name of an Indian firm or a foreign firm.
(ii) The CA firms in Network B have made remittances annually to the multinational entity sharing
their revenue with multinational entity which they have claimed to be towards reimbursement of
cost towards central facilities and levies. However, the firms have not provided
break-up/computation and whether the cost includes cost towards marketing/publicity and
advertising the products and services in India as well as abroad and any other cost which is not
allowed as per the Chartered Accountants Act, 1949, Regulations framed thereunder and the Code of
Ethics. The firms in Network B have also not furnished any data in support of their claim that the
money remitted by them to the multinational is in respect of above matters only and that the same
in no way relates to the vote of business generated through the efforts of the multinational entity
and through use of brand name. A total and full disclosure in this regard has not been made in spite
of repeated directions by the High Powered Committee/Group on the basis of directions of the
Council.
(iii) The networking firms in Network A are sharing their human resources with other firms in the
network. However, it has not been possible to ascertain whether the articled assistants are alsoCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

being rotated among the firms. It may be mentioned that articled assistants are assigned to a
member, whose obligation is to train them. As such, the articled assistants cannot be allowed to be
utilized by any other member. However, to address this issue, there exists a provision under
Regulation, 1988 enabling secondment of articled assistants with a view to provide the articled
assistants the opportunity of gaining practical experience in areas where the principal may not be in
a position to provide the same. Such secondment is allowed under the Regulations with certain
restrictions and conditionalities and the same is required to be sent to the Institute for records
within thirty days from the date of commencement of training on secondment.
(iv) The obligations set out in respect of the CA firms in Network B as per the sub-licensee
agreement give a clear indication that the CA firms are under the management and supervision of a
non-CA firm for matters such as admission of partners, merger, purchase of assets, etc. xxxx 5C.4
Observations :
(i) The CA firms in Network C have amounts to the multinational entity, which they
claim to be on account of actual and allocable cost for activities and services
provided, however, the firms have not provided break up/computation and whether
the cost includes cost towards marketing, publicity and advertising of the products
and services in India as well as abroad and any other cost which is not allowed as per
the Chartered Accountants Act, 1949, Regulations framed thereunder and Code of
Ethics.
The firms in Network C have also not furnished any data in support of their claim that the money
remitted by them to the multinational entity is in respect of above matters only and that the same in
no way relates to the volume of business generated through the efforts of the multinational entity
and through use of brand name. A total and full disclosure in this regard has not been made in spite
of repeated directions by the High Powered Committee/Group on the basis of directions of the
Council.
(ii) The firms in Network C have admitted that the global network identifies broad market
opportunities, develops strategies, strengthens network’s internal products and promotes
international brand. The member firms in India also gain access to brand and marketing materials
developed by their overseas affiliate. This amounts to indirectly soliciting professional work and
securing professional business by means which are not open to a Chartered Accountant.
(iii) The firms in Network C have mentioned that they have joined the network and formed different
firms in different cities to overcome the limitation on number of partners.
(iv) The network C firms have entered into an agreement for sharing of resources. Sharing of human
resources includes articled assistants also, as confirmed by one of their then partners, in a statement
given by him to the members of the Committee. It may be mentioned that articled assistants are
assigned to a member, whose obligation is to train them. As such the articled assistants cannot be
allowed to be utilized by any other member. However, to address this issue, there exists a provision
under Regulation 54 of the Chartered Accountants Regulations, 1988 enabling secondment ofCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

articled assistants with a view to provide the articled assistants the opportunity of gaining practical
experience in areas where the principal may not be in a position to provide the same. Such
secondment is allowed under the Regulations with certain restrictions and conditionalities and the
same is required to be sent to the Institute for records within thirty days from the date of
commencement of training on secondment.
(v) The firms in the Network C and all its personnel are using the MAFs name as part of domain
name in their email IDs, which is displayed in the visiting cards of the partners of these firms as well
as the CA employees. This clearly supports holding out by these firms in Network C that they are
part of the International Network C of MAFs. Some of these firms operate from the same premises
from where their international affiliate also operates. They share the same telephone and fax nos.
thus establishing that they are one and the same. The Indian firms and MAFs are de facto the same
entities providing assurance/management and related services and as such their operations seem to
circumvent the provisions of the Chartered Accountant Act, 1949 and Regulations framed
thereunder. A member of the Institute is prohibited from disclosing his affiliation with any
International entity. In this regard, the Council, at its 172nd meeting held in January, 1995, while
agreeing with the recommendation of then Committee on Ethical Standards and Unjustified
Removal of Auditors that the use of expression/words, “In Association with ……..”, “Associates of
…………”, Correspondents of ………” etc. on the stationery, letter-heads, visiting cards and
professional documents of the firm of CAs, was not permissible in view of the provisions of Item (7)
of Part I of the First Schedule to the Chartered Accountants Act, 1949, decided that it should not be
permitted irrespective of whether the name sought to be used is the name of an Indian firm or a
foreign firm.
(vi) As per the Name License Agreement, the CA firm in Network C shall be liable for and will
indemnify the Business Trust against any and availability, loss, damage, cost, legal cost and other
expenses of any nature suffered, or incurred by the Business Trust arising out of any dispute against
the Business Trust by a third party.
(vii) The service as defined in the agreement with the Trust granting license for use of name,
prescribes the services which will be covered by the said Trust and rendered by the CA firm. This
includes audit, assurance as well as tax advisory services.
(viii) The letterheads and the visiting cards furnished by the firm in Network C do not mention
anywhere that it is a firm of Chartered Accountants. 5D.6 Observations :
(i) The firms in Network D have a management services agreement, technical services
agreements, regulations and name license agreements with other entities, copies of
which have not been furnished by the firms.
(ii) The firms in Network D and all their personnel have been using the name of
multinational entity as domain name in their email IDs, which is displayed in the
visiting cards used by the partners of these firms as well as their CA employees. This
clearly supports holding out by these firms that they are part of the internationalCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

Network D of MAFs. Some of these firms operate from the same premises from
where their international affiliate also operates. They share the same telephone and
fax nos. thus indicating that they are one and the same. The Indian firms and MAFs
are de facto the same entities providing assurance, management and related services
and as such their operations seem to circumvent the provisions of the Chartered
Accountants Act, 1949 and Regulations framed thereunder. A member of the
Institute is prohibited from disclosing his affiliation with any international entity. In
this regard, the Council at its 172nd meeting held in January, 1995, while agreeing
with the recommendation of the then Committee on Ethical Standards and
Unjustified Removal of Auditors that the use of expression/words, “In Association
with ……….”, “Associates of …………”, Correspondents of ………” etc. on the stationery,
letter-heads, visiting cards and professional documents of the firm of CAs, was not
permissible in view of the provisions of Item (7) of Part I of the First Schedule to the
Chartered Accountants Act, 1949, decided that it should not be permitted irrespective
of whether the name sought to be used is the name of an Indian firm or a foreign
firm.
(iii) The firms in the Network D have signed an agreement for sharing of human
resources; however, it has not been possible to ascertain whether the articled
assistants are assigned to a member, whose obligation is to train them. As such, the
articled assistants cannot be allowed to be utilized by any other member. However, to
address this issue/there exists a provision under Regulation 54 of the Chartered
Accountants Regulations, 1988 enabling secondment assistants with a view to
provide the articled assistants the opportunity of gaining practical experience in areas
where the principal may not be in a position to provide the same. Such secondment is
allowed under the Regulations with certain restrictions and conditionalities and the
same is required to be sent to the Institute for records within thirty days from the
date of commencement of training on secondment.
(iv) One of the network firms in Network D, though is yet to sign the agreement with
the multinational entity, but has already been operating as part of the multinational
entity’s network and complies with the obligations.
(v) The amount of remittance made by firms in Network D to the multinational entity
(exceeding Rs.XXXX million in a year) has been disclosed.
However, the firms in Network D have not provided break up computation and whether the cost
includes cost towards marketing, publicity and advertising the products and services in India as well
as abroad and any other cost which is not allowed as per the Chartered Accountants Act, 1949,
Regulations framed thereunder and Code of Ethics. The firms have also not furnished any data in
support of their claim that the money remitted by them to the multinational entity is in respect of
above matters only and the same in no way relates to the volume of business generated through the
efforts of the multinational entity and through use of brand name. A total and full disclosure in this
regard has not been made in spite of repeated directions by the High Powered Committee/Group onCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

the basis of directions of the Council.
xxx
6. Findings 6.1 The Committee/Group with a view to ascertain compliance with the various aspects
of Code of Ethics had received documents/details listed in para 4.13 hereinabove, from 171 firms.
Based on information received, it was found absence of affiliation etc. to
135. Of these, nearly firms submitted data in entirety. Other firms submitted most of the data, such
as financial that for various reasons the number of firms actually 73% of the firms submitted the
data masking of withholding most of the important data, such as financial figures, profit sharing,
capital contribution etc. primarily on the grounds of commercial sensitiveness/confidentiality of the
data. 6.2 In the absence of complete set of documents such as complete copy of agreements between
some of the Indian CA firms and their international affiliates/network along with annexures
referred thereto, networking agreement, internal regulations, service agreements, statute of
international affiliate etc. it was not possible to draw conclusive inference as to violation of the
Chartered Accountants Act, 1949 with reference to sharing of fees or profits with non-members,
sharing profits of non-members, securing business through means not open to Chartered
Accountants, solicitation, direct or indirect publicity etc. This shall require proper examination
under the relevant provisions of Sections 21, 22 and Schedules framed thereunder.
6.3 Most of these networks are created/established outside India and are functioning under
different set of ethical and regulatory guidelines. The India CA firms having international affiliations
are subject to regulatory jurisdiction of ICAI and are required to follow the Code of Ethics applicable
to Chartered Accountants in India. However, due to the dichotomy of other entities operating in
close association with the Indian CA firms, often permitting common brand name/using of logos,
coupled with leveraging on international resources etc., is vitiating the level playing field with other
Indian CA firms.
6.4 Most of these firms have a name license agreement to use International brand name. One of the
terms of such agreement is that apart from common professional standards etc., the Indian affiliates
shall harmonize their policies etc. with the global policies of the network. In this manner, matters
such as selection and appointment of partners, acquisition of assets, investment in capital etc. are
regulated through the means of such agreements and at time even the representative voting is held
by an aligned private limited company rather than the CA firms themselves. As a consequence of
this, the control of the Indian CA firms is effectively placed in the hands of
non-members/companies foreign entities. The desirability of such a practice from the point of view
of independence needs to be examined in the light of Code of Ethics and Schedules to the Chartered
Accountants Act, 1949 and Sections 21 and 22 thereof.
6.5 In respect of some firms with names approved by Institute e.g. “XYZ & Co., Patna”, the
partnership deeds sent by the said firm revealed that the name of the firm is given as “XYZ & Co.”
and not as “XYZ & Co. Patna” which is the name registered by the Institute. This means that the firm
has submitted to the Institute the partnership deed of a firm by the name “XYZ & Co.”, whereas theCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

partnership deed supposed to have been submitted should be that of “XYZ & Co., Patna”. Letters
were written to such firms requesting them to submit the appropriate partnership deed. The first
have replied that it was an inadvertent mistake on their part and on the part of the Institute which
had approved a trade/firm name with city name as the suffix.
6.6 The firms, M/s WZ, Patna and M/s XYZ & Co. Patna, vide form No.117 sought approval of the
Council of the Institute for the firm name, ‘XYZ, Patna’ and ‘XYZ & Co., Patna’ respectively. The
subsequent forms 18 filed by the firm, for change in the constitution, also mention the firm name as
such. However, the partners of the firm, while affixing their signatures on the audit reports, mention
the name of the firm as ‘XYZ’ and ‘XYZ & Co.’ respectively. The audit reports of companies, which
were audited by them, have been signed on behalf of ‘M/s XYZ’ and not ‘M/s XYZ Patna’ and by
‘M/s. XYZ & Co.’ and not ‘M/s. XYZ & Co. Patna’. It is an accepted fact that M/s XYZ, Patna and M/s
XYZ & Co. Patna have carried out audits of certain companies whose shareholders have appointed
M/s XYZ as the auditors. M/s XYZ and M/s XYZ & Co., by allowing the partners of M/s XYZ, Patna
and M/s XYZ & Co. Patna respectively to audit the accounts of clients have rendered the audited
accounts invalid ab-initio.
6.7 It is noted that Item (1) of Part I of the Second Schedule to the Chartered Accountants Act, 1949,
which deals with professional misconduct in relation to Chartered Accountants in practice,
mentions that a chartered accountant in practice shall be deemed to be guilty of professional
misconduct, if he discloses information acquired in the course of his professional engagement to any
person other than his client so engaging him, without the consent of his client or otherwise than as
required by any law for the time being in force. The auditors, by allowing the audit to be conducted
by an unauthorized firm, without the consent of the client, which was not appointed as the statutory
auditors, may have allowed all information relating to the audit being passed on to the said firm,
thus breaching the aforesaid Item, for which both the firms which were appointed and the one
which carried out the audit, may be in violation of the Code of Ethics.
6.8 In response to Institute’s letter, some firms have furnished details/documents after masking or
eliminating certain portion such as financial figures, profit sharing ratio, capital contribution etc.
The Institute has sent numerous letters to these CA firms for providing the information particularly,
copies of agreements/contracts they have with their international affiliates/networks with complete
annexures, partnership deed with complete annexures and schedules mentioned therein,
assessment orders and/or tax returns, financial statements i.e. income and expenditure statement,
balance sheet or statement of affairs including tax audit reports. As stated earlier, most of the firms
have submitted copies of agreements/contracts, partnership deeds, assessment orders or
income-tax returns but around 27% of firms have not furnished the information and have
masked/blackened/not provided the important information. It may be further stated that some of
the firms instead of complying with the directions of the Institute, have questioned the
logic/reasoning behind seeking copies of income-tax returns, which according to them are
commercially sensitive/confidential. One group of firms belonging to one network has cited two
legal opinions that they have obtained in this regard and have declined to submit unmasked details.
However, they have sought personal hearing. As mentioned earlier, the Group considered this
matter and noted that documents have been called in pursuance of the directions given by theCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

Council and that detailed reasoning for calling of documents has also been given to the firms.
Hence, the Group felt that it would not be within its powers to override directions of the Council and
grant any concession to certain firms.
6.9 Section 2(2) of the Chartered Accountants Act, 1949 defines the term ‘to be in practice’. Pursuant
to Section 2(2) above, the Council of the Institute has passed a resolution permitting Chartered
Accountants in practice to render entire range of management consultancy and other services. The
members of the Institute are governed by a Code of Ethics which is mandatory for every member of
the Institute. The services rendered by the multinational entities in India are also to the nature of
management consultancy (including financial services, valuation, audit and assurance services etc.)
and other related services which are carried on through the medium of private limited companies
which are carried using the internationally known accounting firm’s name. Since these entities
employ Chartered Accountants as well as non-Chartered Accountants for discharging various
responsibilities, a misleading Impression is created that the services rendered by the private limited
companies are in fact rendered by a Multinational Accounting Firm. In fact, this is not so as the
company rendering such services is neither registered with ICAI nor is governed by any ethical code
or regulatory framework.”
26. Accordingly, the recommendations were made to the effect that the Council should consider
action against the firms which had not given the full information; consider action against the firms
who are sharing revenue with multinational entity/consulting entity in India which may include cost
of marketing, publicity and advertising as against the ethics of CAs; action should be considered
against the firms who had received financial grant from the multinational entities in spite of
prohibition against the CA firms. A member is not allowed to accept any share, commission or
brokerage from a non-member unless such non-member is a member of a professional body with
prescribed qualifications. Further recommendation is that action be taken against the audit firms
distributing its work to other firms and allowing them access to all confidential information without
the consent of the client; require the CA firms to maintain necessary data about the remittances
made and received on account of networking arrangement or sharing of fee; consider action against
firms being paid or offered referral fee; it should be made mandatory for all firms who enter into any
kind of affiliation/arrangement with any foreign entity to disclose their international
affiliation/arrangement every year to the Institute; Council should consider action against the firms
using name and logo of international networks; action should also be considered for securing
professional business by means which are not open to CAs in India. The Council should also issue
public statement that without specific approval of the Council, by a notification under Section 29(2)
of the CA Act, no MAF can directly or indirectly operate in India through any agreement or
arrangement with any Indian entity/firm of CAs. No international firm or entity should be
permitted to hold out to public that they are operating in India as a MAF as part of their network.
No Indian CA firm should be permitted to pay any part of their profit or fee or other receipts to any
person other than a member of ICAI or a firm owned by them by way of cost or percentage except
payment for specific professional fee. The Council may request the Ministry of Corporate Affairs,
Reserve Bank of India and other relevant Ministries/Departments to take appropriate action so that
the recommendations can be implemented to engage the services of accounting firms registered
with ICAI. Only CAs and CA firms registered with ICAI should be permitted to provide audit andCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

assurance services. Wherever MAFs are operating in India, directly or indirectly, they should not
engage in any audit and assurance services without ‘No Objection’ and permission from ICAI and
RBI. Instructions may be issued that any joint venture agreement, MOU, foreign collaboration
agreement, stakeholders agreement, private equity fund condition, venture capital fund condition or
side letters prescribing for appointment of a specific Chartered Accountant or a CA Firm or any
other entity are illegal and against public interest.
Stand of the ICAI
27. ICAI in its response submitted that the function of the institute was to regulate the profession of
chartered accountancy and to take action against misconduct of its members under The Chartered
Accountants (Procedure of Investigations of Professional and Other Misconduct and Conduct of
Cases) Rules, 2007. The accounting professionals had significant role in the economy of the country.
The economy of India had witnessed two major securities scams in 1992 and 2001. The CA Act was
amended on the recommendation of the Joint Parliamentary Committee which enquired into the
stock market scams including the high level committee on the ‘Corporate Audit and Governance’
under the chairmanship of Shri Naresh Chandra which examined the Auditor-Company relationship
and disciplinary mechanism for the Auditors. Amendment was proposed by the Council of the
Institute to establish a Disciplinary Directorate headed by Director (Discipline).
28. In response to the grievance that no action was taken against PwCPL and their network audit
firms in India, the ICAI submitted that its Disciplinary Directorate had already taken cognizance of
the information in the Article dated 17 th January, 2012 in the Times of India “Sundry Income
cushions PwC India”. Letter dated 9 th March, 2012 was written to PwC, New Delhi, Chennai,
Bangalore, PwC, Kolkata, LL, Kolkata. A letter was also written to RBI. The stand of the PwC firms,
was that news item did not make any reference to their firms and no clarification was necessary.
PwC, Kolkata submitted that it was member of PwC network of firms around the world (‘PwC
Network’). To maintain the quality standards of all members, a grant of Rs.65 crores was given to
them by the PricewaterhouseCoopers Services BV during the financial year ended 31st March, 2011
as an outright, non refundable grant. The same was included in the “Sundry Income” in their annual
accounts. The stand of LL, Kolkata, was that it was a member of PwC Network of Firms around the
world. It received grant of Rs.28.97 crores for maintaining quality standards from PwC Services BV
during the financial year ended 31 st March, 2011 as an outright, non-refundable grant. The
Disciplinary Directorate sent a reminder to the RBI and sent a letter to the Commissioner of Income
Tax, Kolkata and Joint Secretary (Revenue), Ministry of Finance. The Deputy Commissioner of
Income Tax, Kolkata stated that scrutiny proceedings on issue of transfer pricing were pending for
the assessment year 2010-2011 and 2011-2012 in respect of PwCPL. With regard to the failure of
PwC, Bangalore to discover the scandal of ‘Satyam’, it was stated that the US Regulators, i.e.,
Securities and Exchange Commission (SEC) and PCAOB had taken action but in India the
proceedings were getting prolonged. As regards failure of LL to point out high level of NPAs of GTB,
it was submitted that no formal complaint was filed against PwCPL. The same is not registered and
the Institute could not take any action against them under the CA Act as amended in 2006 and 2007
Rules. Action was taken against the members of LL, Shri S. Gopalakrishnan, Shri P. Rama Krishna
and Shri Manish Agarwal. Action was also taken against Shri Kersi H. Vachha and Shri AmalCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

Ganguli. In 2002-2003 action was taken against Shri Partha Ghosh and Shri D.V.P. Rao of M/s.
PwC. PwC Bangalore were the auditors of ‘Satyam’ for which action was taken against CA S.
Gopalakrishnan (For the period 1.4.2000 to 31.3.2007), CA S. Talluri (For the period 1.4.2007 to
30.9.2008), CA Pulavarthi Siva Prasad (for the period 1.4.2001 to 31.3.2005), CA Chintapatla
Ravindernath (for the period 1.4.2005 to 30.9.2008). Action was also taken against V. Srinivasu, the
then CFO of the Satyam, V.S. Prabhakara Gupta, the then head of Internal Audit Cell of Satyam. The
Joint Director, SFIO filed a complaint dated 3rd March, 2009 in respect of DSQ Softwares Limited
against CA Naresh Kumar Tharad of M/s. N.K. Tharad & Co., Chartered Accountants, Kolkata. It
was revealed that company had made preferential allotment of shares to various entities in a
fraudulent manner. Stand of the Respondent-Firms
29. In its written submissions, Respondent No.5 M/s. Deloitte Haskins & Sells submitted that there
is no allegation against it in the SLP. All the partners of Respondent No.5 were Indians and the firm
was also registered with the ICAI. An expert group was constituted by the Ministry of Corporate
Affairs which gave its report dated January 31, 2017 to the effect that Big six firms (MAFs) were not
operating directly. Their network partners were rendering audit services. Indian network firms pay
global network charges to their parent organization towards sharing common global costs of human
resources and other infrastructure, technology cost. This is a standard practice across jurisdictions.
It does not make MAFs subject to the control by the global parent. MAFs cannot be considered as
multinational entities as there is no foreign control through ownership or management. Network
partners are run, controlled and managed by Indian nationals. It was submitted the writ petition
was not maintainable.
30. Reference has also been made to letter dated 3 rd July, 2017 addressed to the Secretary, Ministry
of Corporate Affairs from the PMO, with reference to the said expert group incorporating the
conclusions of the expert group as follows:
“a) The accounting and auditing standards and practices followed in India should be
aligned to international standards and practices with customization to the extent
necessary.
b) The small size of majority of India audit firms being a constraint in facing global
competition, consolidation through merger and networking of India audit firms
should be encouraged through policy measures.
c) With audit becoming a multi disciplinary function, formation of multi disciplinary
audit firms with participation by professionals from other relevant professions
should be promoted.
d) It should be ensured that the recommendations of Quality Review Board
conducting technical evaluations of India audit firms are implemented.
e) If and when audit and assurance are opened to global competition, the principle of
reciprocity should be followed and the interests of India audit firms should be givenCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

due consideration.”
31. The stand of the PwC Network (Respondents 6 to 11) is that PwC or PW is the brand owned by
PwCIL registered under the laws of England limited by guarantee. PwCIL acts as a coordinating
company within the PwC network and does not provide any business or audit services. Respondent
Nos.6 to 11 are member entities of the PwC Network which consists of companies and firms around
the world all of which are separate legal entities. PwCIL allows desirous entities to become members
of the PwC network if they follow global standards to provide quality services for clients in respect of
audit/non audit services. Uniform and consistent delivery is important. PwC network is not a global
partnership. The network activities are to develop and implement policies and initiatives for a
common and coordinated approach to maintain quality and standards of service. PwC brand name
is based on name licence agreement to exercise cooperation amongst member firms. All the
members (in 177 countries) have to pay a licence fees. PwC Services BV (Services BV) is
incorporated in Netherlands to operationalize global standards of services. Services BV coordinates
efforts of various firms across the globe to develop superior global common standard. Services BV
does not do any client related work but develop standards. It pools money by charging the network
entities a percentage of their revenue which is used to meet the expenses to develop standards. Firm
Service Agreements are signed by network entities. Services BV works on no profit no loss basis.
Network charges are paid by all member entities including the Indian member entities. The network
felt the need of enhancing the standards and capacity of Indian network entities for which non
refundable grants were provided. The grants are not in the nature of investment. These are current
account transactions and not capital account transactions. For FY 2009-10, the grants were taxed
but network charges paid to Services BV were disallowed as deduction. For FY 2010-11 assessment
order has been passed on 29th September, 2016 against which appeal was pending.
32. The Enforcement Directorate (ED) sought information in respect of funds received from outside
India. In March and August, 2016, ED issued summons. In July, 2017, ED again issued summons
under Section 37 of FEMA seeking details of inward/outward remittances. In August, 2017, the
Chief Financial Officer (CFO) was issued summons by the ED to provide information about the
remittances.
33. The Registrar of Companies issued notices to show cause why prosecution should not be
launched against the Directors and Company Secretary of the PwCPL in January, 2013. Company
Law Board allowed compounding of the offences on payment of composition amount of
Rs.8,31,000/-.
34. Auditing services are being carried by firms belonging to PwC Group as follows :
i) Price Waterhouse [FRN-310002E] – 66 Indian Partners (Respondent No.7)
ii) Lovelock & Lewes [FRN-301056E] – 66 Indian Partners (Respondent No.8)
iii) Price Waterhouse & Co. [FRN-050032S] – 19 Indian Partners (Respondent No.9)Centre For Public Interest Litigation vs U.O.I on 23 February, 2018

iv) Price Waterhouse, Bangalore [FRN-007568S] – 18 Indian Partners (Respondent
No.10)
v) Dalal & Shah LLP [FRN-102021W/W100110] – 16 Indian Partners (Respondent
NO.11)
35. There are other LLPs which are members of PwC Network in India. All the partners are Indian
by nationality and registered with ICAI. Directors are not partners. Indian Chartered Accountant
member firms of PwC Network operate as independent entities.
36. Guidelines of the ICAI dated 27th September, 2011 apply to a network if the network has
common ownership, control or management, common quality control policies and procedures,
common business strategy, use of a common brand name or a significant part of professional
resources.
37. The Expert Group Report of the ICAI recommended the following:
“No person or entity and specially Chartered Accountants can hold out to public that
they are operating in India as or on behalf or in their trade name and in any other
manner so as to represent them being part of or authorized by MAFs to operate on
their behalf in India or they are actually representing MAFs or they are MAFs
office/representatives in India, except those registered with ICAI in terms of Clause
(Hi) as a network, in accordance with network guidelines as notified by the ICAI from
time to time.” [(Clause 7.12 (v) of the Report at pg.152 of SLP No.1808 of 2016].”
38. The guidelines allow registration of a network and the PwC firms have filed their declaration in
accordance with the above guidelines and are registered in India as per Regulations of the ICAI.
Merely because the PwC audit firms are part of global PwC Network does not by itself violate any
applicable law. As regards the grants received in Financial Years 2008-09, 2009-10 and 2010-11,
amounting to Rs.142.9, tax has been paid as per assessment and proceedings are pending. The
Network has furnished all the information to the ICAI.
39. Since all the partners are Indians and are registered with ICAI, they are personally accountable
to the ICAI for any professional misconduct. Services BV does not have any stake in the partnership
or profits of the firms. Thus, there is no violation of Section 25 of the CA Act.
Stand of Central Board of Direct Taxes (CBDT)/ED
40. Stand taken by the CBDT is that on receipt of letter dated 1 st July, 2013 from the Advocate for
the petitioner, investigation was conducted by the Director General of Income Tax (Investigation)
(DGIT) with regard to the income tax implications. It was found that 11 entities belonging to the
PwC Group are operating in India. Four entities have received grants of Rs.477.64 crores from PwC
Services BV during the period 2009 to 2013. The grants are of two types – professional capacity
building and business expansion. Rs.416.39 crores are offered for tax which were taxed forCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

professional capacity building as “sundry income”. The balance was claimed as capital receipt for
expansion of business. The Assessing Officer made assessment of tax and proceedings were pending.
According to ED, investigation in the matter is pending, though number of witnesses have been
examined.
Stand of the Registrar of Companies (ROC)
41. The stand of the ROC, Kolkata is that prosecution was initiated against the auditors of the
Company, who compounded the offences. Certain proceedings are still pending against the auditors
of the Company.
Stand of the RBI
42. The stand of the RBI is that it only issues circulars and frames Regulations under the FEMA but
does not conduct any investigation for compliance thereof. Regulation 3 of the Foreign Exchange
Management (Investment in Firm or Proprietary concern in India) Regulations, 2000 is that a
person resident outside India cannot invest in a firm or proprietary concern without permission of
the RBI. As per para 3.3.2 of the FDI Policy, investment without prior approval of the RBI is not
permitted.
The statutory provisions
43. Sections 2(2), 25 and 29 of the CA Act are reproduced below :
“2 (2) A member of the Institute shall be deemed “to be in practice”, when
individually or in partnership with chartered accountants [in practice], he, in
consideration of remuneration received or to be received— (i) engages himself in the
practice of accountancy; or (ii) offers to perform or performs services involving the
auditing or verification of financial transactions, books, accounts or records, or the
preparation, verification or certification of financial accounting and related
statements or holds himself out to the public as an accountant; or (iii) renders
professional services or assistance in or about matters of principle or detail relating
to accounting procedure or the recording, presentation or certification of financial
facts or data; or] (iv) renders such other services as, in the opinion of the Council, are
or may be rendered by a chartered accountant [in practice]; and the words “to be in
practice” with their grammatical variations and cognate expressions shall be
construed accordingly. 3 Explanation:— An associate or a fellow of the Institute who
is a salaried employee of a chartered accountant [in practice] or [a firm, of such
chartered accountants] shall, notwithstanding such employment, be deemed to be in
practice for the limited purpose of the [training of articled [assistants]].
25. Companies not to engage in accountancy. (1) No company, whether incorporated
in India or elsewhere, shall practise as chartered accountants. (2) If any company
contravenes the provisions of sub-section (1), then, without prejudice to any otherCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

proceedings which may be taken against the company, every director, manager,
secretary and any other officer thereof who is knowingly a party to such
contravention shall be punishable with fine which may extend on first conviction to
one thousand rupees, and on any subsequent conviction to five thousand rupees.
29. Reciprocity. (1) Where any country, specified by the Central Government in this
behalf by notification in the official Gazette, prevents persons of Indian domicile
from becoming members of any institution similar to the Institute of Chartered
Accountants of India or from practising the profession of accountancy or subjects
them to unfair discrimination in that country, no subject of any such country shall be
entitled to become a member of the Institute or practise the profession of
accountancy in India.
(2) Subject to the provisions of sub-section (1), the Council may prescribe the conditions, if any,
subject to which foreign qualifications relating to accountancy shall be recognised for the purposes
of entry in the Register. [29A. Power of Central Government to make rules. (1) The Central
Government may, by notification, make rules to carry out the provisions of this Act. (2) In particular
and without prejudice to the generality of the foregoing powers, such rules may provide for all or
any of the following matters, namely:- (a) the manner of election and nomination in respect of
members to the Council under sub-section (2) of section 9; (b) the terms and conditions of service of
the Presiding Officer and Members of the tribunal, place of meetings and allowances to be paid to
them under sub-section (3) of section 10B; (c) the procedure of investigation under sub-section (4)
of section 21; (d) the procedure while considering the cases by the Disciplinary Committee under
sub-section (2), and the fixation of allowances of the nominated members under sub-section (4) of
section 21B; (e) the allowances and terms and conditions of service of the Chairperson and members
of the Authority and the manner of meeting expenditure by the Council under section 22C; (f) the
procedure to be followed by the Board in its meetings under section 28C; and (g) the terms and
conditions of service of the Chairperson and members of the Board under sub-section (1) of section
28D.]” First and Second Schedule of the CA Act :
[THE FIRST SCHEDULE] [See Sections 21(3), 21A(3) and 22] PART I Professional
misconduct in relation to chartered accountants in practice A chartered accountant in
practice shall be deemed to be guilty of professional misconduct, if he — (1) allows
any person to practice in his name as a chartered accountant unless such person is
also a chartered accountant in practice and is in partnership with or employed by
him;
(2) pays or allows or agrees to pay or allow, directly or indirectly, any share,
commission or brokerage in the fees or profits of his professional business, to any
person other than a member of the Institute or a partner or a retired partner or the
legal representative of a deceased partner, or a member of any other professional
body or with such other persons having such qualifications as may be prescribed, for
the purpose of rendering such professional services from time to time in or outside
India.Centre For Public Interest Litigation vs U.O.I on 23 February, 2018

Explanation. - In this item, “partner” includes a person residing outside India with whom a
chartered accountant in practice has entered into partnership which is not in contravention of item
(4) of this Part; (3) accepts or agrees to accept any part of the profits of the professional work of a
person who is not a member of the Institute:
Provided that nothing herein contained shall be construed as prohibiting a member
from entering into profit sharing or other similar arrangements, including receiving
any share commission or brokerage in the fees, with a member of such professional
body or other person having qualifications, as is referred to in item (2) of this Part;
(4) enters into partnership, in or outside India, with any person other than a
chartered accountant in practice or such other person who is a member of any other
professional body having such qualifications as may be prescribed, including a
resident who but for his residence abroad would be entitled to be registered as a
member under clause (v) of sub-section (1) of section 4 or whose qualifications are
recognised by the Central Government or the Council for the purpose of permitting
such partnerships;
(5) secures, either through the services of a person who is not an employee of such
chartered accountant or who is not his partner or by means which are not open to a
chartered accountant, any professional business:
Provided that nothing herein contained shall be construed as prohibiting any
arrangement permitted in terms of items (2), (3) and (4) of this Part; (6) solicits
clients or professional work either directly or indirectly by circular, advertisement,
personal communication or interview or by any other means:
Provided that nothing herein contained shall be construed as preventing or
prohibiting –
(i) any chartered accountant from applying or requesting for or inviting or securing
professional work from another chartered accountant in practice ; or
(ii) a member from responding to tenders or enquiries issued by various users of
professional services or organisations from time to time and securing professional
work as a consequence;
(7) advertises his professional attainments or services, or uses any designation or
expressions other than chartered accountant on professional documents, visiting
cards, letter heads or sign boards, unless it be a degree of a University established by
law in India or recognised by the Central Government or a title indicating
membership of the Institute of Chartered Accountants of India or of any other
institution that has been recognised by the Central Government or may be recognised
by the Council:Centre For Public Interest Litigation vs U.O.I on 23 February, 2018

Provided that a member in practice may advertise through a write up setting out the
services provided by him or his firm and particulars of his firm subject to such
guidelines as may be issued by the Council; (8) accepts a position as auditor
previously held by another chartered accountant or a certified auditor who has been
issued certificate under the Restricted Certificate Rules, 1932 without first
communicating with him in writing;
(9) accepts an appointment as auditor of a company without first ascertaining from it
whether the requirements of section 225 of the Companies Act, 1956 9 1 of 1956] in
respect of such appointment have been duly complied with;
(10) charges or offers to charge, accepts or offers to accept in respect of any
professional employment, fees which are based on a percentage of profits or which
are contingent upon the findings, or results of such employment, except as permitted
under any regulation made under this Act;
(11) engages in any business or occupation other than the profession of chartered
accountant unless permitted by the Council so to engage:
Provided that nothing contained herein shall disentitle a chartered accountant from
being a director of a company (not being a managing director or a whole time
director) unless he or any of his partners is interested in such company as an auditor;
(12) allows a person not being a member of the Institute in practice, or a member not
being his partner to sign on his behalf or on behalf of his firm, any balance-sheet,
profit and loss account, report or financial statements.
PART II Professional misconduct in relation to members of the Institute in service A member of the
Institute (other than a member in practice) shall be deemed to be guilty of professional misconduct,
if he being an employee of any company, firm or person – (1) pays or allows or agrees to pay directly
or indirectly to any person any share in the emoluments of the employment undertaken by him;
(2) accepts or agrees to accept any part of fees, profits or gains from a lawyer, a chartered
accountant or broker engaged by such company, firm or person or agent or customer of such
company, firm or person by way of commission or gratification.
PART III Professional misconduct in relation to members of the Institute generally A member of the
Institute, whether in practice or not, shall be deemed to be guilty of professional misconduct, if he –
(1) not being a fellow of the Institute, acts as a fellow of the Institute;
(2) does not supply the information called for, or does not comply with the requirements asked for,
by the Institute, Council or any of its Committees, Director (Discipline), Board of Discipline,
Disciplinary Committee, Quality Review Board or the Appellate Authority;Centre For Public Interest Litigation vs U.O.I on 23 February, 2018

(3) while inviting professional work from another chartered accountant or while responding to
tenders or enquiries or while advertising through a write up, or anything as provided for in items (6)
and (7) of Part I of this Schedule, gives information knowing it to be false.
PART IV Other misconduct in relation to members of the Institute generally A member of the
Institute, whether in practice or not, shall be deemed to be guilty of other misconduct, if he — (1) is
held guilty by any civil or criminal court for an offence which is punishable with imprisonment for a
term not exceeding six months;
(2) in the opinion of the Council, brings disrepute to the profession or the Institute as a result of his
action whether or not related to his professional work.] THE SECOND SCHEDULE [See sections
21(3), 21B(3) and 22 ] PART I Professional misconduct in relation to chartered accountants in
practice A chartered accountant in practice shall be deemed to be guilty of professional misconduct,
if he – (1) discloses information acquired in the course of his professional engagement to any person
other than his client so engaging him, without the consent of his client or otherwise than as required
by any law for the time being in force;
(2) certifies or submits in his name, or in the name of his firm, a report of an examination of
financial statements unless the examination of such statements and the related records has been
made by him or by a partner or an employee in his firm or by another chartered accountant in
practice;
(3) permits his name or the name of his firm to be used in connection with an estimate of earnings
contingent upon future transactions in a manner which may lead to the belief that he vouches for
the accuracy of the forecast;
(4) expresses his opinion on financial statements of any business or enterprise in which he, his firm,
or a partner in his firm has a substantial interest; (5) fails to disclose a material fact known to him
which is not disclosed in a financial statement, but disclosure of which is necessary in making such
financial statement where he is concerned with that financial statement in a professional capacity;
(6) fails to report a material misstatement known to him to appear in a financial statement with
which he is concerned in a professional capacity;
(7) does not exercise due diligence, or is grossly negligent in the conduct of his professional duties;
(8) fails to obtain sufficient information which is necessary for expression of an opinion or its
exceptions are sufficiently material to negate the expression of an opinion;
(9) fails to invite attention to any material departure from the generally accepted procedure of audit
applicable to the circumstances;
(10) fails to keep moneys of his client other than fees or remuneration or money meant to be
expended in a separate banking account or to use such moneys for purposes for which they are
intended within a reasonable time.Centre For Public Interest Litigation vs U.O.I on 23 February, 2018

PART II Professional misconduct in relation to members of the Institute generally A member of the
Institute, whether in practice or not, shall be deemed to be guilty of professional misconduct, if he—
(1) contravenes any of the provisions of this Act or the regulations made thereunder or any
guidelines issued by the Council;
(2) being an employee of any company, firm or person, discloses confidential information acquired
in the course of his employment except as and when required by any law for the time being in force
or except as permitted by the employer;
(3) includes in any information, statement, return or form to be submitted to the Institute, Council
or any of its Committees, Director (Discipline), Board of Discipline, Disciplinary Committee, Quality
Review Board or the Appellate Authority any particulars knowing them to be false;
(4) defalcates or embezzles moneys received in his professional capacity.
PART III Other misconduct in relation to members of the Institute generally A member of the
Institute, whether in practice or not, shall be deemed to be guilty of other misconduct, if he is held
guilty by any civil or criminal court for an offence which is punishable with imprisonment for a term
exceeding six months.
Regulation 3 of the Foreign Exchange Management (Investment in Firm or Proprietory concern in
India) Regulations, 2000 “3. Restrictions on investment in a firm or a proprietary concern in India
by a person resident outside India Save as otherwise provided in the Act or rules or regulations
made or directions or orders issued thereunder, no person resident outside India shall make any
investment by way of contribution to the capital of a firm or a proprietary concern or any association
of persons in india;
Provided that the Reserve Bank may, on an application made to it, permit a person resident outside
India subject to such terms and conditions as may be considered necessary to make an investment
by way of contribution to the capital of a firm or a proprietary concern or any association of persons
in India.” Clause 3.3.2 (III) of the Circular 2 of 2010 of the Consolidated FDI (CFDI) Policy :
“3.3.2 FDI in Partnership Firm / Proprietary Concern:
(iii)Investment by non-residents other than NRIs/PIO: A person resident outside
India other than NRIs/PIO may make an application and seek prior approval of
Reserve Bank for making investment by way of contribution to the capital of a firm or
a proprietorship concern or any association of persons in India. The application will
be decided in consultation with the Government of India. “ Consideration of the Issue
44. The above resume of facts and pleadings shows the following:
i) There is a bar under CA Act to practice as CAs for a company which includes a
limited liability common partnership which has company as its partners.Centre For Public Interest Litigation vs U.O.I on 23 February, 2018

ii) Code of Conduct for the CAs prohibits fee sharing, advertisements but the MAFs
by using international brands and mixing other services with the services to be
provided as part of practice of chartered accountancy violate the said Code of
Conduct for which there is no regulatory regime as the MAFs do not register
themselves with ICAI. Indian firms using similar brand names are registered with the
ICAI but the real entities being MAFs, ICAI is unable to take requisite action for
violation of Code of Ethics by the MAFs. Thus, revisit of existing legal framework may
become necessary so as to have an oversight mechanism to regulate MAFs on the
touchstone of Code of Ethics.
iii) Need for amendment of law to separate regulatory regime for auditing services on
the pattern of Sarbanse Oxley Act enacted in US making a foreign public accounting
firm preparing audit reports to be accountable to the Public Company Accounting.
Similar oversight body may need to be considered in India.
iv) Section 29 of the CA Act provides that if a specified country, prohibits persons of
Indian domicile from becoming members of any institution similar to ICAI or
practicing the profession of accountancy or subjects them to unfair discrimination in
that country, no subject of any such country shall be entitled to become a member of
the Institute or practice the profession of accountancy in India.
v) FDI Policy and the RBI Guidelines framed under the FEMA prohibit the
investment by a person outside India to make investment by way of contribution to
the capital of a firm or a proprietary concern without permission of the RBI
vi) PwC Services BV Netherlands has made investments in Indian firms. According to
the petitioners, the investment is also intended to acquire an audit firm through a
circuitous route of giving interest free loans and further investments are in the form
of grants for enhancement of skills. Profit sharing is in the form of licence
fees/network charges. According to the network, the partners are all Indian partners
and use of common brand name is only for uniform standard and giving of grants is
for maintaining the said standard. There was no investment by an entity outside
India. Nor it amounts to profit sharing by the Indian accountancy firms with an
entity outside India.
45. It is an undisputed fact that there are remittances from outside India. The same could be termed
as investment even though the remittances are claimed to be interest free loans to partners. The
amount could also be for taking over an Indian chartered accountancy firm. Relationship of
partnership firms, though having Indian partners, operating under a common brand name from
same infrastructure, with foreign entity is not ruled out. It is not possible to rule out violation of FDI
policies, FEMA Regulations and the CA Act. Thus, appropriate action may have to be taken in
pending proceedings or initiated at appropriate forum.Centre For Public Interest Litigation vs U.O.I on 23 February, 2018

46. The investigation so far carried out cannot be held to be complete in all respects. The
investigation by income tax authorities is only for assessment of income tax. Action by the ROC also
does not cover the issue raised herein. The investigation by the ED is said to be still pending, though
several persons are said to have been examined and documents collected, which are under scrutiny.
The said investigation relates to FEMA violations. The ICAI has initiated action with regard to
foreign remittances and is said to have written a letter dated 19 th March, 2012 to the RBI to enquire
whether investigation was conducted by the RBI. However, according to ICAI, its investigation can
only be in respect of members, registered with it, for the misconduct conducted by them. The ICAI
does not claim to have conducted complete investigation for want of complete information into the
issue whether the chartered accountancy firms by receiving remittances from outside India or
remitting licence fee/network charges outside India have allowed participation of a company or a
foreign entity in the accountancy business in violation of Section 25 of the CA Act and whether use
of common brand name by the network firms is in violation of reciprocity stipulated under Section
29 of the CA Act. The ICAI should have taken the matter to logical end, by drawing adverse
inference, if information was withheld by the concerned groups.
47. No doubt, the report of the committee of experts of ICAI dated 29th July, 2011 does not
specifically name the MAFs involved, groups A,B,C,D are mentioned. The ICAI ought to constitute
an expert panel to update its enquiry. Being an expert body, it should examine the matter further to
uphold the law and give a report to concerned authorities for appropriate action. Though the
Committee analysed available facts and found that MAFs were involved in violating ethics and law,
it took hyper technical view that non availability of complete information and the groups as such
were not amenable to its disciplinary jurisdiction in absence of registration. A premier professionals
body cannot limit its oversight functions on technicalities and is expected to play proactive role for
upholding ethics and values of the profession by going into all connected and incidental issues.
48. Thus, a case is made out for examination not only by ED and further examination by the ICAI
but also by the Central Government having regard to the issues of violation of RBI/FDI policies and
the CA Act by secret arrangements.
49. It can hardly be disputed that profession of auditing is of great importance for the economy.
Financial statements audited by qualified auditors are acted upon and failures of the auditors have
resulted into scandals in the past. The auditing profession requires proper oversight. Such oversight
mechanism needs to be revisited from time to time. It has been pointed out that post Enron
Anderson Scandal, in the year 2000, Sarbanse Oxley Act was enacted in U.S. requiring corporate
leaders to personally certify the accuracy of their company’s financials. The Act also lays down rules
for functioning of audit companies with a view to prevent the corporate analysts from benefitting at
the cost of public interest. The audit companies were also prohibited from providing non audit
services to companies whose audits were conducted by such auditors. Needless to say that absence
of adequate oversight mechanism has the potential of infringing public interest and rule of law
which are part of fundamental rights under Articles 14 and 21. It appears necessary to realise that
auditing business is required to be separated from the consultancy business to ensure independence
of auditors. The accounting firms could not be left to self regulate themselves.Centre For Public Interest Litigation vs U.O.I on 23 February, 2018

50. While we appreciate that it is for the policy makers to take a call on the issue of extent to which
globalization could be allowed in a particular field and conditions subject to which the same can be
allowed. Safeguards in the society and economy of the country in the process are of paramount
importance. This Court may not involve itself with the policy making but the policy framework can
certainly be looked at to find out whether safeguards for enforcement of fundamental rights have
been duly maintained. In the present context, having regard to the statutory framework under the
CA Act, current FDI Policy and the RBI Circulars, it may prima facie appear that there is violation of
statutory provisions and policy framework effective enforcement of which has to be ensured.
Statutory regulatory provisions intended to advance the object of law have to be enforced
meaningfully. No vested interest can flout the same by manifesting compliance only in form.
Compliance has to be in substance. The law enforcing agencies are expected to see the real situation.
As found by the Expert Committee in its report, there is a compliance by MAFs only in form and not
in substance, by having got registered partnership firms with the Indian partners, the real
beneficiaries of transacting the business of chartered accountancy remain the companies of the
foreign entities. The partnership firms are merely a face to defy the law. The principle of lifting the
corporate veil has to apply when the law is sought to be circumvented. In expanding horizons of
modern jurisprudence, it is certainly permissible. Its frontiers are unlimited. The horizon of the
doctrine is expanding. While the company is a separate entity, the Court has come to recognize
several exceptions to this rule. One exception is where corporate personality is used as a cloak for
fraud or improper conduct or for violation of law. Protection of public interest being of paramount
importance, if the corporate personality is to be used to evade obligations imposed by law, the real
state of affairs needs to be seen 1. The same principle applies while overseeing the compliance of
applicable ethics of not permitting profit sharing or complying with the ceiling limit for the business
1 State of Rajasthan vs. Gotan Lime Stone Khanji Udyog Pvt. Ltd. (2016) 4 SCC 469, paras 24 to 28;
State of Karnataka vs. Selvi J. Jayalalitha (2017) 6 SCC 263, paras 205 to 211 which is violated by
using the technique of sub contracts for outsourcing. If the premises are same, phone number/fax
number is same, brand name is same, the controlling entity is same, human resources are same, it
will be difficult to expect that there is full compliance on mere separate registration of a firm. The
prohibition under Section 25 of the CA Act can be held to be defeated. It is perhaps for this reason
that the network firms avoided giving the information sought by the Committee. The issue of
separate oversight body for auditing work and updating existing legal framework appear to be
necessary.
51. The other aspect is of investment in CA firms, in violation of prohibition of FDI policy, by using a
circuitous route of interest free loans to partners. The fact that the income tax authorities have taken
the grants received as revenue receipts and taxed the same as such is not conclusive to hold that the
receipt is not an investment which is impermissible. If investment is not permitted, the policy of law
cannot be defeated by terming such investment as grant for quality control specially when the grant
has been used to acquire a chartered accountancy firm.
52. Absence of revisiting and restructuring oversight mechanism as discussed above may have
adverse effect on the existing chartered accountancy profession as a whole on the one hand and
unchecked auditing bodies can adversely affect the economy of the country on the other. Moreover,
companies doing chartered accountancy business will not have personal or individual accountabilityCentre For Public Interest Litigation vs U.O.I on 23 February, 2018

which is required. Persons who are the face may be insignificant and real owners or beneficiary of
prohibited activity may go scot free. As already noted, the Reports of the Study Group and Expert
Group show that enforcement mechanism is not adequate and effective. This aspect needs to be
looked into by experts in the Government. It may consider whether on the pattern of the Sarbanse
Oxley Act corporate leaders be required to personally certify the accuracy of the financial
statements. Further, how to prevent corporate analysts from benefitting from the conflict of
interests, how to check audit companies from providing non audit services and how to lay down
protocol for auditors. It has also been brought to our notice that another law in US ‘Dodd-Frank
Wall Street Reform and Consumer Protection Act, 2010’ to ensure more transparency and
accountability of financial institutions to decrease the risk of investing needs consideration. It sets
up an oversight body called the Financial Stability Oversight Council (FSOC).
53. Accordingly, we issue the following directions:
(i) The Union of India may constitute a three member Committee of experts to look
into the question whether and to what extent the statutory framework to enforce the
letter and spirit of Sections 25 and 29 of the CA Act and the statutory Code of
Conduct for the CAs requires revisit so as to appropriately discipline and regulate
MAFs. The Committee may also consider the need for an appropriate legislation on
the pattern of Sarbanes Oxley Act, 2002 and Dodd Frank Wall Street Reform and
Consumer Protection Act, 2010 in US or any other appropriate mechanism for
oversight of profession of the auditors. Question whether on account of conflict of
interest of auditors with consultants, the auditors’ profession may need an exclusive
oversight body may be examined. The Committee may examine the Study Group and
the Expert Group Reports referred to above, apart from any other material. It may
also consider steps for effective enforcement of the provisions of the FDI policy and
the FEMA Regulations referred to above.
It may identify the remedial measures which may then be considered by appropriate authorities.
The Committee may call for suggestions from all concerned. Such Committee may be constituted
within two months. Report of the Committee may be submitted within three months thereafter. The
UOI may take further action after due consideration of such report.
(ii) The ED may complete the pending investigation within three months;
(iiI) ICAI may further examine all the related issues at appropriate level as far as possible within
three months and take such further steps as may be considered necessary.
The matters stand disposed of accordingly.
…………………………….J. [ADARSH KUMAR GOEL] …………………………..J. [UDAY UMESH LALIT]
NEW DELHI;
23rd FEBRUARY, 2018.Centre For Public Interest Litigation vs U.O.I on 23 February, 2018

