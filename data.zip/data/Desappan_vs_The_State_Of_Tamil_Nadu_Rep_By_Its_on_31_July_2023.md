Desappan vs The State Of Tamil Nadu Rep. By Its on 31 July,
2023
Author: M.Sundar
Bench: M.Sundar
    2023:MHC:3534
                                                                                   H.C.P.No.524 of 2023
                                     IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                   DATED: 31.07.2023
                                                          Coram
                                       THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                       and
                                      THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                  H.C.P.No.524 of 2023
                     Desappan                                                         .. Petitioner
                                                            vs
                     1.The State of Tamil Nadu rep. By its
                       Additional Chief Secretary to Government,
                       Home, Department of Prohibition & Excise,
                       Secretariat, Fort St.George, Chennai – 600 009.
                     2.The Commissioner of Police,
                       Chennai City Police, Greater Chennai,
                       Commissioner Office, Vepery,
                       Chennai – 7.
                     3.The Inspector of Police,
                       N-4 Fishing Harbour Police Station,
                       Chennai.
                     4.The Superintendent of Prison,
                       Central Prison II, Puzhal, Chennai.                    ..    Respondents
                                  Petition filed under Article 226 of the Constitution of India
                     praying for issuance of a writ of habeas corpus to call for the
                     records in No.18/BCDFGISSSV/2023 dated 12.01.2023 on the fileDesappan vs The State Of Tamil Nadu Rep. By Its on 31 July, 2023

                     of the second respondent herein and set aside the same as illegal
                     and produce the detenu Gugan @ Bhuvan @ Bhuvaneswaran, son
                     of Desappan, aged 31 years, now confined at Central Prison,
                     Puzhal, Chennai before this Court and set him at liberty.
https://www.mhc.tn.gov.in/judis
                     1/9
                                                                                       H.C.P.No.524 of 2023
                                  For Petitioner            :      Mr.Ilayaraja Kandasamy
                                  For Respondents           :      Mr.E.Raj Thilak,
                                                                   Additional Public Prosecutor
                                                          ORDER
[Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus Petition'
(hereinafter 'HCP' for the sake of convenience and clarity) was listed in the Admission Board on
06.04.2023, this Court made the following order:
' Captioned Habeas Corpus Petition has been filed in this Court on 29.03.2023 inter
alia assailing a detention order dated 12.01.2023 bearing reference
No.18/BCDFGISSSV/2022 made by 'second respondent' [hereinafter 'Detaining
Authority' for the sake of convenience and clarity]. To be noted, third respondent is
the Sponsoring Authority.
2. Father of the detenu is the petitioner.
3. Learned counsel for petitioner submits that ground case qua the detenu is for an alleged offence
under Section 174 of 'The Code of Criminal Procedure, 1973 (2 of 1974)' [hereinafter 'Cr.PC' for the
sake of convenience and clarity] and subsequently, altered into Section 302 of 'The Indian Penal
Code (45 of 1860)' [hereinafter 'IPC' for the sake of convenience and clarity] in Crime No.340 of
2022 on the file of N4 Fishing Harbour Police Station.
4. The aforementioned detention order has been made on the premise that the detenu is a 'Goonda'
under Section 2(f) of 'The Tamil Nadu Prevention of Dangerous Activities of Bootleggers, Cyber law
offenders, Drug-offenders, Forest- offenders, Goondas, Immoral traffic offenders, Sand- offenders,
Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)'
[hereinafter 'Act https://www.mhc.tn.gov.in/judis 14 of 1982' for the sake of convenience and
clarity].
5. The detention order has been assailed inter alia on the ground that several documents in the
grounds of booklet furnished to the detenu are only in English version which prevented the detenu
to make an effective representation.Desappan vs The State Of Tamil Nadu Rep. By Its on 31 July, 2023

6. Prima facie case made out for admission. Admit. Issue Rule nisi returnable by four weeks.
7. Mr.R.Muniyapparaj, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice for
all respondents. List the captioned Habeas Corpus Petition accordingly.'
2. The aforementioned order made in the 06.04.2023 Admission listing shall be read as an integral
part and parcel of this order which means that the short forms, short references and abbreviations
used in the order in the Admission listing shall be used in the instant order also.
3. There are two adverse cases. The ground case which constitutes substantial part of substratum of
the impugned preventive detention order is Crime No.340 of 2022 on the file of N4 Fishing Habour
Police Station under Section 174 Cr.P.C.
Subsequently altered into one under Section 302 IPC. Owing to the nature of the challenge to the
impugned preventive detention order, it is not necessary to delve more into the factual matrix or be
detained further by facts.
https://www.mhc.tn.gov.in/judis
4. Mr.Ilayaraja Kandasamy, learned counsel on record for petitioner and Mr.E.Raj Thilak, learned
State Additional Public Prosecutor for all respondents are before us.
5. As would be evident from the aforementioned 06.04.2023 order (more particularly paragraph 5
thereat) at the time of admission, learned counsel projected the point that several documents in the
grounds booklet furnished to the detenu are only in English, which prevented the detenu from
making an effective representation, however, in the final hearing today, learned counsel for
petitioner predicated his campaign against the impugned preventive detention order on one point
which turns on subjective satisfaction arrived at by the Detaining Authority qua imminent
possibility of the detenu being enlarged on bail.
Elaborating on this submission, learned counsel drew our attention to a portion of paragraph 4 of
the grounds of impugned preventive detention order which reads as follows:
'4......In a similar case registered u/s 147, 148, 449, 324, 302 IPC in R3 Ashok Nagar
Police Station Cr.No.59/2021, the bail was granted by the learned Principal Sessions
Court, Chennai in Crl.M.P.No.10485/2021. Hence, I infer that there is a real
possibility of his coming out on bail by filing bail application in N4 Fishing Harbour
Police Station in https://www.mhc.tn.gov.in/judis Cr.No.340/2022 before the
appropriate court, since in a similar case, the bail was granted by the court after a
lapse of time......'
6. Learned counsel submitted that such subjective satisfaction has been arrived at by the Detaining
Authority by relying on Balaji's case bail order being bail order dated 26.05.2021 in Crime No.59 of
2021 on the file of R-3 Ashok Nagar Police Station. A careful perusal of Balaji's case bail order, moreDesappan vs The State Of Tamil Nadu Rep. By Its on 31 July, 2023

particularly paragraph 5 thereat brings to light that the then prevailing Covid-19 situation had
weighed in the minds of the learned Sessions Judge in granting bail. Paragraph 5 of Balaji's case bail
order reads as follows:
'5.The petitioners have been in custody for the past 75 days. No previous case is
reported as against the petitioners. Considering the duration of custody and stage of
the case and existing Covid-19 situation, this Court is inclined to grant bail to the
petitioners subject to condition.'
7. Covid - 19 situation in legal parlance is from 15.03.2020 to 28.02.2022 vide orders
of Hon'ble Supreme Court in Suo Motu Writ Petition (C) No.3 of 2020 wherein
limitation across the Board was extended and therefore, Balaji's case would not apply
to the https://www.mhc.tn.gov.in/judis case on hand as the impugned preventive
detention order has been made on 12.01.2023, which means that the impugned
preventive detention order deserves to be dislodged.
8. Ergo, the sequitur is, captioned HCP is allowed. Impugned detention order dated
12.01.2023 bearing reference No.18/BCDFGISSSV/2023 made by the second
respondent is set aside and the detenu Thiru.Gugan @ Bhuvan @ Bhuvaneswaran,
aged 31 years, son of Thiru.Desappan, is directed to be set at liberty forthwith, if not
required in connection with any other case / cases. There shall be no order as to
costs.
(M.S.,J.) (R.S.V.,J.) 31.07.2023 Index : Yes Neutral Citation : Yes mmi P.S: Registry
to forthwith communicate this order to Jail authorities in Central Prison, Puzhal,
Chennai.
To
1.The Additional Chief Secretary to Government, Home, Department of Prohibition & Excise,
Secretariat, Fort St.George, Chennai – 600 009.
2.The Commissioner of Police, Chennai City Police, Greater Chennai, Commissioner Office, Vepery,
Chennai – 7.
https://www.mhc.tn.gov.in/judis
3.The Inspector of Police, N-4 Fishing Harbour Police Station, Chennai.
4.The Superintendent of Prison, Central Prison II, Puzhal, Chennai.
5.The Public Prosecutor, High Court, Madras.Desappan vs The State Of Tamil Nadu Rep. By Its on 31 July, 2023

https://www.mhc.tn.gov.in/judis https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and
R.SAKTHIVEL , J., mmi 31.07.2023 https://www.mhc.tn.gov.in/judisDesappan vs The State Of Tamil Nadu Rep. By Its on 31 July, 2023

