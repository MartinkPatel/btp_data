Chhattisgarh State Electricity Supply Code, 2005
CHHATTISGARH
India
Chhattisgarh State Electricity Supply Code, 2005
Rule
CHHATTISGARH-STATE-ELECTRICITY-SUPPLY-CODE-2005 of
2005
Published on 14 September 2005• 
Commenced on 14 September 2005• 
[This is the version of this document from 14 September 2005.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Chhattisgarh State Electricity Supply Code, 2005Published vide Notification No. 11/CSERC/2005,
dated 14.09.2005Last Updated 2nd November, 2019Notification No. 11/CSERC/2005 dated the
14th September, 2005. - In exercise of powers conferred by Section 43 (1) read with Section 181 (t),
Section 44, Section 46 read with Section 181(1), Section 47(1) read with Section 181 (v), Section 47
(4) read with Section 181 (w), Section 47 (2), (3) and (5), Section 48 (b) and Section 50 read with
Section 181 (x) and Section 56 of the Electricity Act, 2003 (No. 36 of 2003) and the Electricity
(Removal of Difficulties) Order, 2005 issued by the Ministry of Power, Government of India on
8-6-2005, the Chhattisgarh State Electricity Regulatory Commission hereby makes the following
Code to be known as "Chhattisgarh State Electricity Supply Code-2005" to govern distribution and
supply of electricity and the procedures thereof, such as the systems of billing, modality of payment
of bills, the powers, functions and obligations of the distribution licensees and the rights and
obligations of consumers, etc.
Chapter 1
Short Title, Commencement and Review Process
1.
1.
This Code may be called the "Chhattisgarh State Electricity Supply Code, 2005"1.2This shall come
into force from the date of its publication in the Chhattisgarh Rajpatra.1.3It shall extend to the
whole of the State of Chhattisgarh.1.4It shall apply to all persons engaged in the business of
distribution of electricity as distribution licensees including the Chhattisgarh State Electricity BoardChhattisgarh State Electricity Supply Code, 2005

and its agents under the Electricity Act, 2003 and to the consumers of electricity. It shall also apply
to all persons exempted from distribution licence under sec. 13 of the Act.1.5Copies of this Code
[***] [Deleted 'and Guidelines for Redressal of Consumer Grievance,' by Notification No.
19/CSERC/2007, dated 16.4.2007.] as duly amended from time to time, shall be kept in the
registered offices, regional offices, circle offices, division offices, centres of the licensees and such
other offices as may be specified by the licensees or by the Commission.Mechanism for review of
Electricity Supply Code1.6The Commission shall constitute an Electricity Supply Code Review Panel
(Review Panel) to review this Code [***] [Deleted 'along with and Guidelines for Redressal of
Consumer Grievance' by Notification No. 19/CSERC/2007, dated 16.4.2007.] on regular basis. The
Review Panel shall consist of such number of persons, as the Commission may consider necessary
and adequate, to be appointed by the Commission, including persons representing the following
:(a)Each Distribution Licensee of the State;(b)State Transmission Utility (STU) or Transmission
licensees;(c)LT consumers, HT consumers, EHT consumers, their associations and any consumer
groups; and(d)Any other interest group including, NGO as the Commission may think fit.
1. [7 The commission shall appoint the Chairman from among the
representatives of the licensees and an officer of the Commission as Member
Secretary of the Committee. The licensee whose representative is appointed
Chairman of the Committee, shall provide all the required support,
administrative and otherwise, to the panel as may be required for the
discharge of its functions. All members of the review panel shall be
appointed for period of two years.] [Substituted by Notification No.
19/CSERC/2007, dated 16.4.2007.]
1.8The Review Panel shall meet at least once every six (6) months.1.9The Member Secretary of the
Review Panel shall send the proceedings of the meetings of the Panel to the Commission within 15
days of the meetings.1.10The Commission may amend the Electricity Supply Code suo motu or on
the recommendations of the said panel. However, before any amendment is made in the Code,
comments on the proposed changes shall be obtained from all the Distribution licensees, STU,
Transmission licensees and the public.1.11A notice of the gist of amendment made in the Electricity
Supply Code shall be published by the licensee in at least two newspapers having wide circulation in
the area of supply stating that copies of the amended Electricity Supply Code are available for
purchase in the offices mentioned in clause 1.5.
Chapter 2
Definition
2.Chhattisgarh State Electricity Supply Code, 2005

1.
In this Code, unless it is repugnant to the context(a)'Act' means the Electricity Act, 2003 (No. 36 of
2003) as amended from time to time;(b)'Agreement' with its grammatical variations and cognate
expressions means an agreement entered into between the licensee and the consumer under this
Code;(c)'Apparatus' means electrical apparatus and includes all machines, fittings, accessories and
appliances in which conductors are used;(d)'Area of supply' means the geographic area within which
a licensee is authorized by his license to supply electricity;(e)'Average Power Factor' means the
monthly power factor and shall be the ratio expressed as a percentage of the total kilowatt hours to
the total kilovolt ampere hours supplied during the month; the ratio being rounded off to two
decimal figures, 5 or above in the third place of decimal being rounded off to the next higher place in
the second. In case KWh or KVAh reading is not available, then power factor shall be calculated on
the basis of KVARh reading, if the meter has KVARh recording feature.(f)'Billing Month' means a
period of about 30 days or between the two consecutive meter readings for the purpose of
billing;(g)'Breakdown' means an occurrence relating to the equipment of the electric energy supply
system including electrical line that prevents its normal functioning;(h)'Code' means the
Chhattisgarh State Electricity Supply Code, as in force from time to time;(i)'Commission' means the
Chhattisgarh State Electricity Regulatory Commission;(j)'Conductor' means any wire, cable, bar,
tube, rail or plate used for conducting electrical energy and so arranged as to be electrically
connected to a system;(k)'Connected load' means aggregate of the manufacturer's rating of all
energy consuming devices, in the consumer's premises, which can be simultaneously used. This
shall be expressed in KW, KVA or HP units and shall be determined as per the procedure laid down
in clauses 6.37 to 6.42 on 'Rating of Installations' in this Code;(l)'Consumer' means any person who
is supplied electricity by a licensee and includes any person whose premises are for the time being
connected for the purpose of receiving electricity from the licensee, persons who have applied for an
electricity connection, persons whose supply is not yet connected even after due notice to avail
connection or whose electricity supply has been disconnected. A consumer is -(i)'Low Tension
Consumer (LT Consumer)' if he obtains supply from the licensee at low or medium voltage;(ii)'High
Tension Consumer (HT Consumer)' if he obtains supply from the licensee at high voltage;
and(iii)'Extra High Tension Consumer (EHT Consumer)' if he obtains supply from the licensee at
extra high voltage;(m)'Consumer's installation' means any composite electrical unit including
electric wires, fittings, motors and apparatus, portable and stationary, erected and wired by or on
behalf of the consumer at the consumer's premises;(n)'Contract demand' means the maximum load
in KW, KVA or HP, as the case may be, agreed to be supplied by the licensee and contracted by the
consumer and mentioned in the agreement;(o)'Cut-out' means any appliance for automatically
interrupting the transmission of energy through any conductor when the current rises above a
predetermined quantum, and shall also include fusible cut-out;(p)'Date of commencement of
supply' means the day immediately following the date of expiry of a period of one month for in case
of LT connections and three months in case of HT and EHT connections from the date of intimation
to an intending consumer of the availability of power or the date of actual availing of supply by such
consumer, whichever is earlier;(q)'Demand charge' for a billing period means a charge levied on the
consumer based on the contract demand or maximum demand and shall be calculated as per the
procedure provided in the tariff order, passed by the Commission, under part VII of the Act;(r)[
'Distribution system' means the system of wires and associated facilities between the delivery pointsChhattisgarh State Electricity Supply Code, 2005

on the transmission lines or generating station connection and the point of connection to the
installation of the consumer. It shall also include electric line, sub-station and electrical plant that
are primarily maintained for the purpose of distributing electricity in the area of supply of such
distribution licensee notwithstanding that such line, sub-station or electrical plant are high pressure
cables or overhead lines or associated with such high pressure cables or overhead lines; or used
incidentally for the purpose of transmitting electricity for others.] [Substituted by Notification No.
19/CSERC/2007, dated 16.4.2007.](s)'Earthed' or 'connected with earth' means connected with the
general mass of earth in such manner as to ensure at all times an immediate discharge of energy
without danger;(t)'Energy' means electrical energy;(i)generated, transmitted or supplied, for any
purpose, or(ii)used for any purpose except the transmission of a message;(u)'Energy charge' refers
to a charge levied on the consumer based on the quantity of electricity (units in KWh or KVAh as per
tariff) supplied;(v)'Extra High Voltage' means the voltage, which exceeds 33,000 volts subject,
however, to the percentage variation allowed under the Indian Electricity Rules,
1956;(w)'Harmonics' means a component of a periodic wave having frequency that is an integral
multiple of the fundamental power line frequency of 50 Hz causing distortion to pure sinusoidal
waveform of voltage or current, and as governed by IEEE STD 519-1992, namely "IEEE
Recommended Practices and Requirements for Harmonic Control in Electrical Power Systems" and
corresponding standard as may be specified in accordance with clause (c) of sub-section (2) of
Section 185 of the Act;(x)'High Voltage (HV)' means the voltage higher than 650 volts but which
does not exceed 33,000 volts under normal conditions subject to the percentage variation allowed
under the Indian Electricity Rules, 1956;(y)'Initial period of agreement' means the period of two
years starting from the date of commencement of supply or expiry of notice to avail supply. The
initial period of agreement shall continue till the end of the month, on which the end date of the two
year period expires;(z)'Installation' means any composite electrical unit used for the purpose of
generating, transforming, transmitting, converting, distributing or utilizing energy;(aa)'Licensed
Electrical Contractor' means a contractor licensed under rule 45 of the Indian Electricity Rules,
1956;(bb)'Licensee' means a distribution licensee, unless the context otherwise requires.(cc)'Load
Factor' means the ratio of the total number of units consumed during a given period to the total
number of units which may have been consumed had the contract demand/sanctioned load been
maintained throughout the same period, and shall usually be expressed as a percentage; (dd) 'Low
Voltage (LV)' means the voltage, which does not exceed 250 volts under normal conditions subject,
however to the percentage variation allowed under the Indian Electricity Rules, 1956;(ee)'Maximum
demand' for a category of consumer shall be calculated as per the procedure provided in the tariff
order passed by the Commission;(ff)'Medium voltage' means the voltage higher than 250 volts but
which does not exceed 650 volts under normal; conditions subject, however, to the percentage
variation allowed under the Indian Electricity Rules, 1956;(gg)'Meter' means a set of integrating
instruments and equipments used to measure and/or record and/or store the electrical quantities
like energy in KWh or KVAh, maximum demand in KW or KVA, reactive energy in KVARh etc. in a
given time, which include whole current meter and metering equipment such as Current
Transformers (CT), Capacitor Voltage Transformer (CVT), Potential Transformers (PT) with cable,
wiring, where used in conjunction with such meter or its accessories and any devices like switches or
MCB/load limiter or fuses used for protection and testing purposes and any enclosure used for
housing or fixing such meter or its accessories; and(hh)'Month' means a calendar month.2.2All
other expressions used herein but not specifically defined, but defined in the Act, shall have theChhattisgarh State Electricity Supply Code, 2005

meaning assigned them in the Act. The other expressions used herein but not specifically defined in
this Code or in the Act but defined under any law passed by the Parliament applicable to electricity
industry in the state or stated in the tariff order passed by the Commission, under section 62 of the
Act shall have the meaning assigned to them in such law. Subject to the above, the expressions used
herein but not specifically defined in this Code or in the Act or any law passed by the Parliament
shall have the meaning as is generally assigned to them in the electricity supply industry.
Chapter 3
System of Supply and Classification of Consumers
3.
1. System of Supply.
- The declared frequency of the alternating current (AC) shall be 50 cycles per second.3.2The
declared voltage of the AC supply is as follows :(a)Low Tension(i)Single Phase : 230 volts between
phase and neutral;(ii)Three Phase : 400 volts between phases;(b)High Tension (HT) - Three Phase :
11 KV or 33 KV between phases; and(c)Extra High Tension (EHT) - Three Phase : 132 KV or 200 KV
between phases. For Railway traction two-phase supply may be given.3.3The licensee shall design
and operate a distribution system in conjunction with the transmission systems. The licensee shall
not permit the voltage at the point of supply to the consumer to vary from the declared voltage
which is :(a)In the case of low or medium voltage, by more than 6%; or(b)In the case of high voltage,
by more than 6% on the higher side or by more than 9% on the lower side; or(c)In the case of extra
high voltage, by more than 10% on the higher side or by more than 12.5% on the lower side.Any
exception to the above will only be allowed with the written consent of the consumer or with prior
approval of the Commission.3.4Voltage of Supply to Consumers The supply voltage for different
contract demands shall normally be as follows :
Supply Voltage Minimum Contract Demand Maximum Contract Demand
230 volts  2 KW
400 volts Above 2 KW 100 HP or 75 KW
11 KV 60 KVA 300 KVA
33 KV 60 KVA 10000 KVA
132 KV 4000 KVA 40000 KVA
220 KV 15000 KVA 150000 KVA
The connected load of a consumer availing supply at low tension shall not exceed 150 HP:Provided
that depending on system availability or condition, the licensee at its discretion, may release supply
at any other voltage in consultation with the Commission. Particularly in case of Railways, the
maximum and minimum limits of contract demand on the various voltage levels indicated in the
above table may be relaxed by the licensee on mutual agreement depending on the actual
requirement and feasibility.3.5Classification of Consumers The classification of consumers, tariff
and conditions of supply applicable to each category shall be as fixed by Commission from time toChhattisgarh State Electricity Supply Code, 2005

time in the tariff order passed under section 62 of the Act or otherwise. The licensee may classify or
reclassify consumers into various categories from time to time as per classifications fixed by the
Commission.
Chapter 4
New Power Supply
4.
1. Licensee's Obligation to Supply.
- The licensee shall, on an application by the owner or occupier of any premises located in his area of
supply, give supply of electricity to such premises within the time specified in this Code (refer clause
4.77), provided(a)the supply of power is technically feasible,(b)the consumer has observed the
procedure specified in this Code, and(c)the consumer agrees to bear the cost of supply and services
as specified.Licensee's obligation to extend the distribution system and consumer's share in the
cost4.2The licensee shall meet the cost for strengthening/upgradation of the system to meet the
demand of the existing consumers though its annual revenues or funds arranged by the licensee and
this cost shall be recovered from the consumers through tariff. A part of such expenses shall be met
by [supply arranging charges] [Substituted 'system strengthening charges' by Notification No.
19/CSERC/2007, dated 16.4.2007.] as prescribed by the Commission from time to time.4.3The cost
of extension of distribution mains and extension/upgradation of the system upto the point of supply
for meeting demand of new consumers shall be payable by the consumer, or any collective body of
consumers or otherwise as may be directed by the Commission keeping in view the provisions of
section 46 of the Act.4.4In all cases of new connections the consumer shall bear the actual cost of
extension and service connection charges.4.5The service connection charges shall be as approved by
the Commission from time to time. In cases where the charges are not approved, the consumer shall
bear the actual cost of extension of the service connection4.6Apart from the charges as payable
under clause 4.4, the supply affording charges, as approved by the Commission, will be payable by
all the three phase consumers except agriculture consumers and flour mills in rural area.4.7In case
the connected/contracted load of any new connection is projected to be 50 KW or more, a separate
transformer of adequate capacity shall be installed at consumer's cost. The land/room with easy
access required for housing the transformer sub-station, switch gears, meters and panels shall be
provided by the consumer, free of cost, for which rent or premium shall not be payable by the
licensee.4.8The service connection/extension of distribution mains, notwithstanding that it has
been paid for by the consumer, shall be the property of the licensee. The licensee shall maintain it at
his cost and shall also have the right to use the same service connection/extension for supply of
energy to any other person, but such extension or service connection should not adversely affect
supply to the consumer who has paid for the extension of the distribution supply network.4.9When
the licensee is ready to give supply, he shall serve a notice on the consumer to take power supply
within one month in case of LT consumers and three months in case of HT or EHT consumers. If the
consumer fails to avail supply within the notice period, he shall be liable to pay any charges due
thereon as per the provisions of the supply agreement from me day following the end of the noticeChhattisgarh State Electricity Supply Code, 2005

period.4.10Service connection/extension work got done by consumers The consumer can get the
work of drawing of service line from the licensee's distribution mains up to his premises as per the
estimates and layout approved by the licensee through a 'C' or higher-class licensed electrical
contractor, and the work of extension of EHT and HT line, distribution or HT sub-station and LT
line through an 'A' class contractor as per the estimates and layout approved by the licensee. In such
case the consumer himself shall procure the materials. The material should, conform to relevant BIS
specification or its equivalent and should bear ISI mark wherever applicable. The licensee may ask
for documentary evidence to verify the quality of materials used. The consumer shall be required to
pay the supervision charges as approved by the Commission in the Schedule of Miscellaneous
Charges on the cost of works as per the estimates approved by the licensee. The rates of the
materials shall be available in the ready reckoner.4.11The consumer shall get the work done within
the time frame as provided in clause 4.77, failing which the licensee may, on giving fifteen days
notice treat the requisition for supply as cancelled.
4. [12 Application for Supply Application for new supply and subsequent
additional supply of electrical energy shall be made in duplicate in the
appropriate prescribed form, copies of which shall be available at a nominal
cost at the local office of the licensee. The format of the application forms is
provided in Annexure 1 and Annexure 2. Acknowledgement for the
application shall be issued forthwith on presentation of the application.
Photocopies of blank forms or form downloaded from the website of the
licensee may also be used by the consumer and shall be accepted by the
licensee.] [Substituted by Notification No. 19/CSERC/2007, dated 16.4.2007.]
4.13The occupier of the premises, for which supply is required, shall make the application and shall
indicate his full name and address with telephone number (if available) where the supply is required
and also the name and address of the licensed electrical contractor through whom the wiring will be
carried out; but it would not be necessary to make the requisition through the licensed electrical
contractor. Any assistance or information required in filling up the form should be given to the
consumer at the local office of the licensee.4.14The consumer shall furnish, along with the
application form, copies of the following documents. The licensee may ask for the original
documents, from the consumer, for verification.(a)Proof of legal ownership of the premises in the
form of registered sale deed or partition deed or succession or heirship certificate or deed of last
will, orProof of occupancy such as valid power of attorney or latest rent receipt or valid lease deed or
rent agreement or copy of allotment order issued by the owner of the property, orIn case of supply
for agriculture/irrigation pump set, the copy of the current Khasra giving the 'khasra' number of the
field within which the supply is required and water availability certificate from competent
government authority.(b)Approval/permission of the local/statutory authority, if required under
any law/statute. This shall be required for the industrial and large non-domestic connections.(c)In
case of a partnership firm, partnership deed, authorization in the name of the applicant for signing
the application form and agreement.(d)In case of a Public or Private Limited Company, the
Memorandum and Articles of Association and Certificate of incorporation together with anChhattisgarh State Electricity Supply Code, 2005

authorization in the name of the applicant for signing the application form and
agreement.(e)Permission from Environment Conservation Department in case of industry falls
under the purview of environmental clearance.(f)SSI registration in case of small and medium
industries.(g)In case of applications for power supply to stone crushers, stone polishing and hot-mix
plants, the following additional information shall also be furnished.:(i)Documentary evidence from
the department concerned to show that he will be able to take requisitioned quantum of power
supply for at least two years; and(ii)His permanent address.(h)The consumer shall also intimate
whether the service line and extensions, if any, shall be laid by the consumer or the
licensee.(i)Processing fee, as fixed by the Commission, shall also be payable at the time of
submission of application.4.15In case of a new connection for domestic or single-phase
non-domestic category, the applicant is unable to provide the proof of legal occupation of the
premises, the officer in charge of the concerned distribution circle may wave such requirement and
record, in writing, the reasons thereof. But in such cases, the applicant shall execute an indemnity
bond, indemnifying the licensee against any damages payable on account of any dispute arising out
of supply of power to the premises. However, in such cases, the security deposit to be paid by the
consumers shall be equal to the cost of ninety day's of average consumption to be determined by the
licensee's local office. The serving of connection to such premises shall not be used as a proof of legal
rights on the premises or for any other legal use.4.16If the consumer, in respect of an earlier
agreement executed in his name or in the name of a firm or company with which he was associated
either as a partner, director or managing director, has any arrears of electricity dues or other dues
on the premises for which the new connection is applied and such dues are payable to the licensee,
the requisition for supply may not be entertained by the licensee until the dues are paid in full. In
case of a person occupying a new property, it will be the obligation of that person to check the bills
for the previous months or, in case of disconnected supply the amount due as per the licensee's
records immediately before his occupation and ensure that all outstanding electricity dues as
specified in the bills are duly paid up and discharged. The licensee shall be obliged to issue a
certificate of the amount outstanding from the connection that was installed or is installed in such
premises on request made by such person. The licensee may refuse to supply electricity to the
premises through the already existing connection or refuse to give a new connection to the premises
till such outstanding dues are cleared.
4. [17 (i) Electricity will be supplied to a consumer at a single point for the
entire premises. For the purpose of these terms and conditions of supply,
premises shall be deemed to be separate.
(a)it owned by different persons or taken on lease by different persons, the terms of lease being valid
for a period of at least two years at the time of connection;(b)for the domestic category, households
having relevant document from local authorities, identifying the premises as separate;(c)for
domestic premises part of which is used for non-domestic purposes; and(d)industrial
establishments manufacturing different products, not as part of single manufacturing process, their
physical location being different and distinct.(ii)Each separate premises will be given separate point
of supply.]Supply to different categories of consumers(A)Supply at LT4.18The licensee shall verify
the application and the enclosed documents at the time of receipt of application. A written
acknowledgment Shall be issued on the spot if the application is complete. If the application isChhattisgarh State Electricity Supply Code, 2005

incomplete, or otherwise the entries are defective, the shortcomings shall be intimated to the
applicant in writing within 5 working days. After the complete application is received from the
consumers, the licensee shall issue a written acknowledgement to the consumer immediately.
Within 3 working days of receipt of the completed application form, the licensee shall intimate the
consumer the proposed date of inspection which should be within the next 2 working days in urban
areas and 5 working days in rural areas.4.19The applicant along with the licensed contractor or his
representative shall be present during the inspection. During the inspection, the licensee shall:(a)Fix
the point of supply at a mutually agreed place where meter and cut-out/MCB shall be fixed.(b)Fix
the layout of the proposed lines and sub-station and estimate the distance between the point of
supply and the nearest distribution mains from where supply could be given.(c)Determine if the
supply line is to go over any property belonging to a third party.(d)Verify other particulars
mentioned in the application form, as required.4.20When the consumer's premises has no frontage
on a street and the service line from the licensee's mains has to go upon, over or under the adjoining
premises of any other person (whether or not the adjoining premises be owned jointly by the
consumer and such other person), or in any other case, the consumer shall bring at his own
expenses any necessary way-leave, license or sanction for extension of distribution mains and
service line and furnish to the licensee. The licensee shall not arrange supply of power until the
way-leave, license or sanction is received. Any extra expense incurred in placing the supply line in
accordance with the terms of the way-leave, license or sanction shall be born by the consumer. In
the event of the way-leave, license or sanction being cancelled or withdrawn, the consumer shall, at
his own cost arrange for, or in case the work is carried out by the licensee at the consumer's request,
pay full cost of, any diversion of the service line or the provision of any new service line thus
rendered necessary.4.21It shall not be incumbent on the licensee to ascertain the validity or
adequacy of way-leave, license or sanction obtained by the consumer.4.22In case it is possible to
extend supply from the existing mains, the licensee will forward to the consumer, within 10 working
day in urban areas and 15 working days in rural areas, an advice for the charges for laying the
service line, the amount of security deposit and any other charges as applicable. The amount shall be
payable in full within 15 working days, after which only any work for laying the service line will be
taken up. The licensee will also intimate to the consumer to execute the agreement.4.23In case it is
necessary to extend distribution mains for giving supply to the consumer, the licensee will forward
to the consumer, within 10 days in urban areas and within 15 days in rural areas, an advice
containing the charges for extension of the distribution main, laying the service line, the amount of
security deposit, any other charges as applicable and will also intimate additional formalities
required, if any, to be carried out by the consumer. In cases where the consumer has to lay the
service line and extension of mains, the consumer shall pay the supervision charges on cost of
extension of the distribution mains and laying the service line in addition to payment of other
charges as may be applicable. The amount shall be payable in full within 15 working days along with
completion of other formalities, after which only the work for laying the distribution mains and
service line can be taken up. The licensee will also intimate the consumer to furnish test report in
the prescribed form.4.24In case the consumer fails to complete the formalities within 15 days, the
licensee shall give him notice to complete the formalities within the next 15 days failing which, his
application for supply shall be cancelled. Thereafter the consumer shall have to apply afresh for
supply or additional supply as the case may be.4.25On deposit of charges as indicated above by the
consumer, execution of the agreement and receipt of test report and intimation that the service lineChhattisgarh State Electricity Supply Code, 2005

and extension work have been completed, the licensee shall intimate the consumer, within 3 days,
the date of testing of the consumer's installation. The consumer shall ensure that the licensed
electrical contractor, who has carried out the wiring, should remain present during the
testing.4.26On testing the consumer's installation, if the licensee is satisfied with the test results, the
licensee shall arrange to install the meter with the cut-out or MCB, seal the meter in presence of the
consumer and provide supply within the stipulated time specified in this Code. If the licensee is not
satisfied, he shall intimate the consumer the shortcomings in the wiring, in writing. The applicant
shall be required to get the defects rectified. On payment of the prescribed fee, testing shall again be
conducted.4.27All works shall be completed within the time frame specified in clause 4.77.
4. [27A If any developer/builder/housing society/group of consumers wants
to lay HT/LT line through underground cable, he shall be allowed to do so
subject to the condition that the relevant Indian Standards are followed and
the followed and the laying of cable is through trench only, This is applicable
to multi-consumer complexes and housing colonies.
4.27BIf any developer/builder/housing society/group of consumers wishes to provide transformer
of rating more than 315 KVA at 11/04 KV voltage with special type of equipment (with ISI mark),
such consumer shall have to install an extra unit as standby : This will be applicable to
multi-consumer complexes and housing colonies.] [Substituted by Notification No.
19/CSERC/2007, dated 16.4.2007.](B)LT Supply to Multi-Consumer Complex [***] [Substituted
'including Commercial Complexes' by Notification No. 19/CSERC/2007, dated 16.4.2007.] :4.28For
the purpose of providing new power supply to a building or a group of buildings requiring more than
one connection and a total load of 50 KW or more, the building shall be considered as a
multi-consumer complex. [Multi-consumer complex shall include both residential, non-residential
complexes, such as commercial complexes, office complexes and educational institutions.
Educational institutions shall be provided a single connection.] [Added by Notification No.
19/CSERC/2007, dated 16.4.2007.]4.29The supply to a multi-consumer complex shall be arranged
through a separate distribution transformer of adequate capacity but not less than 100 KVA. The
cost of extension including H.T. line, distribution transformer and LT. lines/cables shall be borne by
the developer/builder/society/consumer.4.30The developer/builder/society/consumer shall also
pay [supply arranging charges] [Substituted 'system strengthening charges' by Notification No.
19/CSERC/2007, dated 16.4.2007.]. The system strengthening charge is the charge recoverable
from consumers for strengthening the licensees network.The developer/builder/society/consumer
may be any agency of the State Government, a local body or a private person who constructs the
multi-consumer complex.4.31In case it is not possible to give supply to the multi-consumer complex
by augmentation of the capacity of existing 33/11 KV sub-station or the load of the housing colony
exceeds 2150 KW, the developer/builder/society/consumer shall bear the cost of the 33 KV line and
33/11 KV sub-station of required capacity. In such cases [supply arranging charges] [Substituted
'system strengthening charges' by Notification No. 19/CSERC/2007, dated 16.4.2007.], if any, shall
not be payable as per the Schedule of Miscellaneous Charges approved by the Commission.4.32In
case the total load of the multi consumer complex including all phases exceeds 1000 KW, the
developer/builder/society/consumers shall provide necessary land measuring not less than 40x30Chhattisgarh State Electricity Supply Code, 2005

meters at a token premium of Re. 1, for construction of 33/11 KV sub-station by the licensee. The
location of the same shall be selected by the Executive Engineer in-charge of the area according to
the load centre.
4. [33 Meters shall be provided at one place normally in the pillar box as may
be decided by the licensee in accordance with the procedure laid down in
chapter 8 on meters.] [Substituted by Notification No. 19/CSERC/2007, dated
16.4.2007.]
4.34The land/room required for housing the transformer sub-station and meters shall be provided
by the developer/builder/society/consumer free of cost for which rent or premium shall not be paid
by the licensee. Transformers should preferably be placed in open areas. In case installation of
transformer in a room or closed area is unavoidable, all safety measures as per prevailing rules and
regulations should be taken.4.35Connections for common facilities like lift, water pumps etc. shall
be given in the name of the builder/developer/society. If requisitions for supply to individual flats
are not received from the flat owners, connections may be given in the name of the
builder/developer/society. Such connections may subsequently be transferred to the individual
owner/occupier of the flat after completing the necessary formalities prescribed in this regard. The
agreement for such individual connection shall be executed accordingly.4.36In case the original
approved plan is for a multi-consumer complex, but the builder/developer/society/consumer
desires to avail connection for a portion of it, the connections shall be provided treating it as
multi-consumer complex.4.37Due to additional construction or additional requirement of load, if a
building comes under the category of multi-consumer complex and if a separate distribution
transformer of sufficient capacity, for giving supply to such building was not provided earlier, it will
be provided at the cost of the builder/developer/society/ consumer. Alternatively, the
builder/developer/society/consumer shall arrange to suitably augment the capacity of the existing
sub-station, if found feasible by the licensee. However, the [supply arranging charges] [Substituted
'system strengthening charges' by Notification No. 19/CSERC/2007, dated 16.4.2007.], if any, shall
be payable for the new connections or additional load only.4.38For the purpose of considering the
criteria of a multi-consumer complex, for development of infrastructure for extension of distribution
mains and for calculating the [supply arranging charges] [Substituted 'system strengthening
charges' by Notification No. 19/CSERC/2007, dated 16.4.2007.], the load of the multi-complex shall
be calculated on the following basis (area represents built-up area of individual unit):
 [Built up Area [Substituted by Notification No. 19/CSERC/2007, dated 16.4.2007.] Load
(i) For residential complexes  
(a) Upto 400 sq. ft.1.5
KW
(b) Above 400 sq. ft. & upto 700 sq. ft.2.0
KW
(c) Above 700 sq. ft. & upto 1000 sq. ft.3.0
KWChhattisgarh State Electricity Supply Code, 2005

(d) Above 1000 sq. ft. & upto 1300 sq. ft.4.0
KW
(e) Above 1300 sq. ft. & upto 1600 sq. ft.5.0
KW
(f) Above 1600 sq. ft. & upto 2000 sq. ft.7.0
KW
(g) Above 2000 sq. ft. & upto 2500 sq. ft.10
KW
(h)For every additional 500 sq. ft. or part thereofover 2500 sq. ft. of built up area, 1 KW
of load should be added to 10 KW.
(ii) For non-residential complexes  
 For each 100 sq. ft. built up area1
KW]
Note.-The load of the common facilities like lift, water pump, parking lights etc. shall be
taken as declared by the developer/builder/society/consumer. The aforesaid
procedure for estimation of load is for the purpose of bringing about uniformity in the
assessment of the load of multi-consumer complexes. However, Security deposit etc.
shall be worked out on the basis of the load as declared by the consumer and
supported by the test report at the time of providing connection to individual
consumers.For the Purpose of computation of load, the built up area of individual
consumers shall be taken in the case of residential multi-consumer complexes, where
as in the case of educational institutions and non-residential multi-consumer
complexes the entire built up area of the complex shall be taken.]
The above criterion is for residential purposes, for commercial complexes, load will be assessed on
the basis of 1 KW for each built up 100 sq. ft. area.The load of the common facilities like lift, water
pump, parking lights etc. shall be taken as declared by the developer/builder/society/consumer.The
aforesaid procedure for estimation of load is for the purpose of bringing about uniformity in the
assessment of the load of the multi-consumer complex. However, security deposit etc. shall be
worked out on the basis of the load as declared by the consumer and supported by the test report at
the time of providing connection to individual consumer.4.39On receipt of application from the
builder/developer/society/consumer for supply of electricity to multi-consumer or [***]
[Substituted 'including Commercial Complexes' by Notification No. 19/CSERC/2007, dated
16.4.2007.], the licensee shall take action for extending the supply as per procedure given in clauses
4.18 to 4.27 as applicable.(C)LT Supply to housing colonies :4.40The developer/builder/society
consumers of a housing colony shall bear the cost of extension including the cost of 11 KV line,
distribution transformer and LT lines/ LT cables. The developer/builder shall also pay [supply
arranging charges] [Substituted 'system strengthening charges' by Notification No.
19/CSERC/2007, dated 16.4.2007.].In case it is not possible to give supply to a housing colony by
augmentation of the capacity of existing 33/11 KV sub-station or the load of the housing colony
exceeds 2150 KW, the developer/builder/society/consumer shall bear the cost of 33 KV line and
33/11 KV sub-station of required capacity. In such cases [supply arranging charges] [Substituted
'system strengthening charges' by Notification No. 19/CSERC/2007, dated 16.4.2007.], if any, shall
not be payable as per the Schedule of Miscellaneous Charges approved by the Commission.4.41ForChhattisgarh State Electricity Supply Code, 2005

the development of infrastructure for extension of distribution mains and calculating the [supply
arranging charges] [Substituted 'system strengthening charges' by Notification No.
19/CSERC/2007, dated 16.4.2007.], if any, the load of the housing colony shall be calculated on the
following basis (area represents plot area):
 Area Load
(a) Upto 500 sq. ft.1.0
KW
(b) Above 500 sq. ft. & upto 1000 sq. ft.2.0
KW
(c) Above 1000 sq. ft. & upto 1500 sq. ft.3.0
KW
(d) Above 1500 sq. ft. & upto 2000 sq. ft.4.0
KW
(e) Above 2000 sq. ft. & upto 2400 sq. ft.5.0
KW
(f) Above 2400 sq. ft. & upto 3000 sq. ft.7.0
KW
(g) Above 3000 sq. ft. & upto 3500 sq. ft.10.0
KW
(h) Plot or house for EWS1.0
KW
(i) [ [Added by Notification No.
19/CSERC/2007, dated 16.4.2007.]for every additional area of 500 sq.ft. or part thereof
over and above 3500 sq.ft of plot area, 1KW of load
should be added to 10 KW.] 
The load of the common facilities like lift, water pump, parking lights, street lights etc. may be taken
as declared by the developer/builder/society/consumer. If, subsequently, the
developer/builder/society/consumer constructs houses or buildings for sale, instead of sale of plots,
the load will be reassessed on the basis of the guideline given in clause 4.38. The
developer/builder/society/consumer shall be liable to pay the additional amount payable, if any, as
per the new assessment. The developer/builder/society/consumer will also be required to pay the
cost of the additional infrastructure required for the purpose.The aforesaid procedure for estimation
of load is for the purpose of calculation of charges and also for deciding the number and capacity of
distribution transformers and the length of HT/LT line required. However, the service connection
charges, security deposit etc. shall be worked out on the basis of the load as declared by the
consumer and supported by the test report at the time of serving connection to individual
consumer.4.42On receipt of application from the builder/developer/society/consumer for supply to
housing colony, the licensee shall take action for extending the supply as given in clause 4.18 to 4.27
as applicable.(D)LT Supply to illegal colonies/multi consumer complex :4.43In case of such
colonies/multi-consumer complexes which do not have requisite sanction/permission of the State
Government/local authorities under the laws and rules applicable to them and hence are treated as
illegal colonies, may be electrified provided the Commissioner of the concerned Municipal
Corporation/ Municipality certifies with the approval of the State Government that it is in publicChhattisgarh State Electricity Supply Code, 2005

interest to provide electric connections to such colony/multi-consumer complex.4.44In case the
total load of a housing colony, including all phases, assessed on the basis as given in clause 4.41
above exceeds 1000 KW, the developer/builder/ society/consumers shall provide necessary land
measuring not less than 40 x 30 meters at a token premium of Re. 1 for construction of 33/11 KV
sub-station by the license. The location of the same shall be selected by the Executive Engineer
in-charge of the area according to load centre.4.45Load projection of such colony/complex will be
done as per the provisions in clause 4.38 or 4.41, as the case may be.4.46Since no
developer/builder/agency is likely to come forward for external electrification of such colonies, the
connections may be served to individual consumers on payment of proportionate cost of external
electrification of complete colony/complex and [supply arranging charges] [Substituted 'system
strengthening charges' by Notification No. 19/CSERC/2007, dated 16.4.2007.].(E)LT Supply for
agriculture/irrigation pump sets :4.47The procedure laid down in clause 4.18 to 4.27, as applicable,
shall be followed for giving supply to agriculture/irrigation pump sets where extension of
distributing mains and/or augmentation of distribution transformer is not required.4.48Supply for
agriculture/irrigation pump set, at one point, may also be given to a registered co-operative society
or to a group of farmers recognized by the licensee.4.49If on inspection of the premises it is found
that extension of distributing mains and/or augmentation of distribution transformer capacity is
required, the possibility of taking up the work from financial assistance available from the
Government or financial institution like Rural Electrification Corporation etc. shall be examined.
Within 10 days of inspection, if no extension of line is required, and within 30 days of inspection if
extension of line is required, the consumer shall be intimated whether the licensee can take up the
work with its own funds or whether the work can be taken up only after the full cost of the works is
deposited by the consumer. In case the work can be taken up only after the consumer deposits the
estimated expenses, the licensee shall inform the consumers accordingly and also intimate the exact
amount required to be deposited. The work of electrification of such pump set(s), for which the full
cost of the work is deposited by the consumer(s) will be taken up and completed within the period as
mentioned in clause 4.77, of depositing the amount by the consumer(s) if extension work is
involved. In case of a waiting list for connection, work on new connection shall be taken up on the
broad principle of first-come first serve basis. Within 7 working days of completion of work, the
licensee shall issue one month's notice of availability of supply and request the consumer(s) to
furnish the test report. On receipt of test report from the consumer, the licensee shall inspect the
installation within 3 days. In case he is satisfied with the test report and the wiring in the premises
of the consumer, the connection shall be served within 3 working days after the inspection.(F)LT
Supply to Public Street Lighting :4.50Requisition for power supply to new or additional public street
lights shall be submitted in the prescribed form (Annexure-1) to the local office of the licensee by the
Municipal Corporation or Municipality or Nagar Panchayat or Gram Panchayat or local body or the
Government Department or any other organization made responsible by the Government to
maintain public street lights (which shall hereinafter be called by the generic term 'local
body')4.51The requisition for public lights shall be accompanied by resolution of the local body and
the sketch indicating the number of poles, existing or new, where streetlights are required. Except
otherwise directed by the Commission, the licensee may not provide a new street light connection if
the local body, applying for new street light connection, has any electricity dues against it.4.52The
fittings, brackets or any special fittings shall be in accordance with the relevant BIS specifications or
its equivalent and shall maintain required clearances as per prevailing rules and regulations. TheChhattisgarh State Electricity Supply Code, 2005

local body shall bear the full cost of arranging of power supply to public streetlights including
complete fittings and brackets. In case, any special fittings are to be provided, the local body shall
arrange for it.4.53The licensee shall intimate the cost of extension in writing, within 15 days in
urban areas and within 30 days in rural areas from the date of application. The work shall be taken
up only after deposit of the amount and execution of agreement by the local body.4.54A suitable
double compartment weather proof metal box to house the energy meter and streetlight
switch/M.C.B./timers shall be provided by the licensee.4.55The licensee shall arrange to switch on
fifteen minutes before sunset and switch off the streetlights fifteen minutes after sunrise as per local
sunset/sunrise timings. The licensee shall also carry out replacement 6f fixtures/bulbs (of same
wattage) etc. on the poles on the request of the streetlight consumers. The fixtures, bulbs etc. shall
be supplied by the consumers and replaced by the licensee within 7 days of receipt. All such services
shall be chargeable. Such maintenance charges shall be included in the schedule of miscellaneous
charges.(G)Temporary Power Supply4.56Any person requiring power supply for a purpose that is
temporary in nature, for a period of less than one year, may apply for temporary power supply in the
prescribed form (Annexure 1 or 2). Release of temporary connections is not a matter of right. It can
be given only when it is technically feasible and subject to following of safety requirements as
specified in rules 29 and 30 of the Indian Electricity Rules, 1956. Requisition for temporary supply
shall normally given 7 days before the day when supply is required for loads up to 10 KW and 30
days before, for higher loads.4.57In case temporary supply is required for construction purposes
where permanent connection will he required subsequently, feasibility of permanent connection
shall first be examined prior to sanction of temporary connection. The position in respect of
feasibility of permanent connection shall be informed to the applicant before serving temporary
connection.4.58A temporary connection can also be provided to a consumer who requires
temporary supply for a short period for overhauling of his generator set or requires power in an
emergency.4.59The applicant shall also furnish the proof of occupation or permission from the local
authority or from the owner of the premises, as the case may be, where temporary connection is
required, as stated in clause 4.14. In case temporary supply is required in premises/place where 100
or more persons are likely to assemble, the consumers shall comply with the provisions of section 54
of the Act.4.60If supply is feasible, the licensee shall intimate to the applicant the charges to be paid
for the cost of laying and dismantling the extension work, service line, meter, cut-out/MCB etc,
together with the charges for the estimated consumption during the period of supply applied for and
the rental of equipment and material. All the charges shall be payable in advance. If available, the
licensee shall provide prepaid meters.The consumer shall have the option either to receive the
material used for temporary connection or receive credit, in the final bill, as per prevailing rules, for
materials dismantled and returned to stores, in good condition, after disconnection of supply.4.61In
case temporary supply is required for a period more than 90 days, the licensee may permit the
consumer to pay charges for estimated consumption for 90 days and serve the bills for monthly
consumption. In case the consumer fails to pay the bills in time and the advance with the licensee
does not cover the charges for the balance period, the supply is liable for disconnection.4.62If an
agricultural consumer so wishes, he may seek temporary connections for agricultural use. In such
case the consumer shall pay the entire amount of bill charges payable for the period of proposed
connection, in advance. All charges and other conditions as applicable to temporary connections
shall also be applicable. In case a consumer defaults in clearing any dues under this provision, he
shall not be provided new connection till previous dues are cleared. The licensee shall have the rightChhattisgarh State Electricity Supply Code, 2005

to remove any equipment specifically installed for providing supply under this provision, after the
period of supply is over.4.63The licensee shall release the supply within 3 days of payment of
charges and compliance of other requirements by the consumer for loads upto 10 KW and within 15
days in other cases where extension of distribution mains is not required. Where extension of
distribution mains is required, the supply shall be released within 60 days in case of LT consumers,
90 days for HT consumers and 180 days for EHT consumers.4.64The readings of the meter may be
taken during the period of the temporary connection to ensure that the charges for actual
consumption does not exceed the advance payment received.4.65After the period of temporary
supply is over and supply has been disconnected, the licensee shall prepare the final bill and send it
to the consumer within 30 days from the date of disconnection of supply and return the balance
amount, if any, within 30 days of surrender of original money receipt or submission of indemnity
bond by the consumer. On any delay beyond the said time limit, the licensee will be liable to pay an
interest @ 1% per month on the amount of refund outstanding for the number of days beyond the
last date of payment, as specified above.4.66The licensee shall have in place a procedure of
reporting and checks to see that provisions made herein are properly observed and no connections
are given without realizing dues.(H)Supply at H.T.4.67On receipt of an application for supply of
energy at H.T. in the prescribed form (Annexure-2), the licensee shall inform the consumer in
writing the date of inspection of the site to examine the feasibility of the connection applied for. The
licensee shall intimate the feasibility of supply or otherwise within 15 days of receipt of the
application. The consumer or his authorized representative shall remain present at the time of
inspection. The licensee shall check the feasibility of supply and if found feasible, shall fix the point
of entry of the supplier's line, the position of meter, metering equipment and other equipments of
the supplier. The consumer may with the written permission of the licensee house his own HT
switchgear and other apparatus connected with supply of energy to him under the agreement signed
between the consumer and the licensee and these must necessarily be placed therein; but such
enclosure shall not be used for any other purpose. The licensee may insist on use of 'Ariel Bunched
Cable', wherever considered appropriate, for the last span. The difference of cost of the last span on
account of laying of 'Ariel Bunched Cable' in place of overhead bare conductor shall be borne by the
licensee. The licensee will insist on the consumer to provide cubicle in case of HT
installation.4.68Supply to HT industrial consumers shall normally be given through HT feeder
exclusively meant for industries. It may be preferable to extend supply through a separate feeder
from the nearest 33/11 KV or EHT sub-station in case of consumers with continuous process
industry(ies) or load of 3 MVA or more.4.69Supply to new HT consumer (both at 11 KV or 33 KV)
shall normally not be extended from a rural feeder. It due to the prohibitive cost of extension of
separate feeder from the nearest 33/11 KV or EHT sub-station, or for any other reason, supply is
given from a rural feeder, the consumer shall be informed that the supply shall be restricted and
regulated in accordance with the restrictions imposed on the rural feeders as per grid conditions.
Such consumer may be required to furnish a declaration to the licensee indemnifying the licensee
for the restrictions in supply.4.70Within 30 days of intimating the feasibility, the licensee shall
intimate the consumer the charges required to be paid for the cost of extension, if any, and the
amount of security deposit and other charges, if any. Copy of the draft agreement shall also be
forwarded simultaneously.4.71After the payment of charges including security deposit, and
execution of the agreement, the licensee shall take up the work of extension of mains. If the
consumer wishes, he may execute the job on his own after payment of due supervision charges toChhattisgarh State Electricity Supply Code, 2005

the licensee. The work shall be completed within 90 days if extension work is required. The licensee
shall inform the consumer of the availability of supply, after completion of extension of mains upto
the consumer's premises, including installation of proper metering arrangement. After completion
of the installation, the consumer shall furnish to the licensee the test report and the permission from
the Electrical Inspector to energize the installation. In case of mines, the permission from the
Inspector of Mines shall also have to be furnished. Where applicable, the permission from statutory
authorities like Water and Pollution Control Board shall also have to be furnished. On receipt of the
reports, the licensee shall intimate the consumer in writing the date of inspection and testing of the
consumer's installation. In case the consumer's installation is found in order, the licensee shall seal
the meter in the presence of the consumer and serve the connection.(I)Supply at E.H.T.:4.72On
receipt of an application in the prescribed form (Annexure-2) for supply of energy at E.H.T., the
licensee shall inform the consumer in writing the date of inspection to check the feasibility of supply.
The licensee and the Transmission Licensee shall carry out the inspection jointly. The consumer or
his authorized representative shall remain present at the time of inspection. The two licensees shall
check the feasibility of supply and if found feasible shall fix the point of entry of the supplier's line,
the position of meter, metering equipment and other equipments of the supplier. Normally the EHV
line shall not be tapped. The Licensee shall intimate the feasibility of supply within 30 days of
receipt of the application.4.73Within 60 days of intimating the feasibility, the licensee shall inform
the consumer the charges required to be paid for the cost of extension, if any, and the amount of
security deposit and other charges, if any, Copy of the draft agreement shall also be forwarded
simultaneously.4.74After the payment of charges including security deposit and execution of the
agreement, the licensee shall request the Transmission licensee to take up the work of extension
required to give supply. If the consumer wishes he may execute the job through licensed contractor
on payment of due supervision charges to the licensee. The work shall be completed within 180
days.4.75After the consumer executes his internal electrical works, he shall furnish to the licensee
the test report and the permission from the Electrical Inspector to energize the installation (refer
rule 47 of the Indian Electricity Rules, 1956). In case of mines, the permission from the Inspector of
Mines shall also have to be furnished. Where applicable, the permission from statutory authorities
like Water and Pollution Control Board shall also have to be furnished. On receipt of the reports, the
licensee shall intimate the consumer in writing the date of inspection and testing of the consumer's
installation. If the consumer's installation is found in order, the licensee shall seal the meter in the
presence of the consumer and serve the connection.4.76Nothing contained in this chapter shall be
taken as requiring a licensee to give supply of electricity to any premises if he is prevented from
doing so due to force majeure conditions provided in clause 12.1.4.77The following table gives the
target period of completion of various activities :
S.No. Type of ServiceTime Limit for Rendering
the Service
1 LT connection  
(a) Notice of inspection on receipt of completeapplication 3 working days
(b) Inspection after sending notice  
 (a) Urban areas 2 working days
 (b) Rural areas 5 working days
(c) i.  Chhattisgarh State Electricity Supply Code, 2005

Issue of demand note to the applicant forpayment of
estimated charges (if extension work is not requiredand the
connection is to be given from the existing network)
 (a) Urban areas 5 working days
 (b) Rural areas 7 working days
ii.Issue of demand note to the applicant forpayment of
estimated charges (if the extension work orenhancement of
transformer capacity is required) 
 (a) Urban areas 10 working days
 (b) Rural areas 22 days
(d)Serving of power availability notice forcommencement of
supply/Commencement of supply in area wherelicensee's
distribution system exists 
i.After payment of necessary charges (if theconnection is
required to be given from existing network) 
 (a) Urban areas 15 working days
 (b) Rural areas 15 working days
ii.After payment of necessary charges (ifextension work or
enhancement in transformer capacity isrequired) 
 (a) All connections excluding agriculture 60 days
 (b) Agricultural connection during season whenclear access
to fields is available90 days
 (c) Agricultural connection during season whenno clear
access is available180 days from the date
access is made available
2. High Tension Connection  
 (a) Informing feasibility after receipt of theapplication 15 working days
 (b) Issue of demand note of estimated charges(after issue of
notice of feasibility)30 days
 (c) Serving of power availability notice forcommencement of
supply/release of connection after receipt ofestimated
charges subject to receipt of clearance fromElectrical
Inspector 
 i. If no extension work is involved 30 days
 ii. If extension work is involved 90 days
3. Extra High Tension Connection  
 (a) Informing feasibility after receipt of theapplication 30 working days
 (b) Issue of demand note of estimated chargesafter issue of
notice of feasibility60 days
 (c) Serving of power availability notice forcommencement of
supply/release of connection after receipt ofestimated180 days (Since it will
involve extension ofline)Chhattisgarh State Electricity Supply Code, 2005

charges (subject to receipt of
clearance from
ElectricalInspector)
4.78The licensee shall maintain a priority register where the type of connection will be categorised
in the following categories(a)Where no extension of distribution mains is required(b)Where
extension of distribution mains upto two poles is required(c)Where extension of distribution mains
of more than two poles is required4.79The Commission may for reasons to be recorded, direct
deviations from the above clause 4.1 to 4.78 if in the opinion of the Commission the circumstances
warrant such deviation. The Commission may issue such direction by an order to the licensee.
Chapter 5
Point of Supply and Licensee's Equipment in Premises
5.
1. Point of Supply.
- Unless otherwise agreed to, the point of supply shall be at the out-going terminals of the licensee's
:(a)cut-outs in the case of LT consumers; and(b)control switchgear that may be installed in the
licensee's or consumer's premises as agreed to mutually in the case of HT or EHT
consumers.5.2Supply shall be given at a single point in the premises [***] [Deleted '(refer clause
4.17)' by Notification No. 19/CSERC/2007, dated 16.4.2007.] at the incoming terminals of the
licensee's cut-outs/MCB/control switchgear. However in case of coal mines the licensee may provide
supply at more than one point in the installation of the consumer having regard to the physical
layout of the installation and the requirements of the consumer. [One of the connections of an
existing consumer who has two different connections for supply in his premises, shall be
discontinued on expiry of their present agreement.] [Substituted by Notification No.
19/CSERC/2007, dated 16.4.2007.]5.3Dedicated Feeder Consumers desirous of getting power
supply from dedicated feeders may request for such facility to the licensee. The dedicated feeder
may be extended from the power sub-station to the consumer's point of supply. In such cases the
consumers shall be liable to pay the cost of bay and all protection switchgears and its accessories
provided at the power sub-station for this feeder in addition to the cost of the feeder. On receipt of
such request, the licensee will check the feasibility based on merit of providing a dedicated feeder to
the consumer's premises. Such dedicated feeder shall be the property of the licensee and shall be
maintained by the licensee. Such feeder shall not be used to extend supply to any other consumer
within the initial period of two years from the date of commissioning.5.4Licensee's Equipment on
Consumer's Premises The consumer shall provide free of cost to the licensee necessary land
belonging to the consumer and afford all reasonable facilities for bringing in not only the direct
cables or overhead lines from the licensee's system for servicing the consumer, but also cables or
overhead lines connecting licensee's other consumers and shall permit the licensee to install all
requisite switchgears and connections thereto on the above premises and to extend supply to such
other consumers through the cables and terminals situated on the consumer's premises, provided
supply to the consumer in the opinion of the licensee is not thereby unduly affected.5.5The meter,Chhattisgarh State Electricity Supply Code, 2005

cut-out/MCB, service mains and other equipment belonging to the licensee/provided by the
consumer must on no account be handled or removed by any one who is not an authorized
employee/representative of the licensee. The seals, which are fixed on the meters/metering
equipments, load limiters and the licensee's apparatus, must on no account be tampered, damaged
and broken. The responsibility for the safe custody of licensee's equipments and seals on the
meters/metering equipments within the consumer's premises shall be on the consumer.5.6In the
event of any damage caused to the licensee's equipments in the consumer's premises by reason of
any act, neglect or default of the consumer or his employees/representatives, the cost thereof as
claimed by the licensee shall be payable by the consumer. If the consumer fails to do so on demand,
it shall be treated as a contravention of the terms and conditions of supply agreement and the supply
shall be liable to be disconnected after due notice. The consumer shall however be liable to pay the
charges as per the provisions in clause 7.20 of this Code.5.7The licensee is responsible for
maintaining the meters and equipments, installed at consumer's premises from where electricity is
supplied to the consumer.5.8Failure of fuse/supply : The licensee's service fuse or fuses fail at any
time, complaint thereof should be sent to the licensee's local office as specified in the "Internal
Grievance Redressal Mechanism" approved by the Commission. Only authorized employees
possessing the photo-identity card of the licensee are permitted to replace these fuses in the
licensee's cut-outs. Consumers are not allowed to replace these fuses. The licensee should not allow
its employees to carry out any repairs in the consumer's installations.5.9The licensee shall take all
reasonable precautions to ensure continuity of supply of electrical energy to the consumer but shall
not be responsible for or liable to the consumer for any loss to him or damage to his plant and
equipment due to interruptions in supply of electrical energy due to force majeure conditions
provided in clause 12.15.10The licensee shall always be entitled for the purpose connected with the
working of its supply system to temporarily discontinue the supply for such period as may be
necessary, subject to reasonable advance notice being given in this behalf, with the object of causing
minimum inconvenience to the consumer.
Chapter 6
Wiring and Apparatus in Consumer Premises
6.
1. Wiring and installation of equipments and apparatus in consumer's
premises.
- For the protection of the consumer and the public in general, it is necessary that the wiring on the
consumer's premises should conform to the Indian Electricity Rules, 1956, and the rules of the Fire
Insurance Company in terms of which the building is insured and be carried out by a licensed
electrical contractor. The materials used for wiring shall conform to the relevant specifications of the
Bureau of Indian Standards or its equivalent. Wherever applicable the materials used shall bear ISI
mark. As soon as the consumer's installation is completed in all respects and tested by the
consumer's contractor, the consumer should submit to the licensee, the contractor's test report. The
test report form (Annexure-4) for this purpose shall be submitted to the local office of the licensee.Chhattisgarh State Electricity Supply Code, 2005

It is important that the conditions stated therein are fully complied with, as otherwise there may be
a delay in obtaining the supply.6.2As required by rule 45 of the Indian Electricity Rules, 1956, no
electrical installation work, including addition, alteration, repair and adjustment to existing
installation except the replacement of lamps, fans, fuses, switches and other component parts of the
installations - which in no way alter the capacity or character of the installation, shall be carried out
in the premises on behalf of any consumer or owner for the purpose of supply of energy to such
consumer or owner, except by an electrical contractor licensed by the State Government in this
behalf and under the direct supervision of a person holding a certificate of competency or by a
person holding a permit issued or recognized by the State Government.6.3Any breach of rule 45
shall render a person liable to punishment under rule 139 of the Indian Electricity Rules,
1956.6.4Provisions of rule 32 of the Indian Electricity Rules, 1956 should be complied with in
respect of consumer's installation. No cut-out, link or switch other than a linked switch arranged to
operate the earthed and live conductors simultaneously, shall be inserted in the conductor of the
consumer's installation to be connected to the neutral conductor of the licensee's system.6.5The
consumer's mains shall, in all cases, be brought back to the licensee's point of supply and sufficient
cable shall be provided for connecting up with the licensee's apparatus.General Wiring Conditions
:Mains :6.6Switches and Fuses : The consumer shall provide proper linked quick-make and break
main switches of requisite capacity to carry and break current in each conductor near the point of
commencement of supply. The switches in the consumer's premises shall be on the live wire and the
neutral conductor shall be marked for identification where it leaves the consumer's main switch for
connecting upto the meter. No single pole switch or cut-out should remain inserted in any neutral
conductor.6.7Balancing of load : The consumer taking three-phase supply shall balance his load
between the phases as per the IE Rules, 1956 Annexure VI, clause 22 (c).6.8Earthing: Gas and water
pipes shall on no account be used for earthing purposes. All wiring shall be kept as far as possible
away from gas and water pipes.6.9Domestic appliances : For the safety of the wiring at the
consumer's premises, separate circuit for heaters, geysers, air-conditioners and for cooking
apparatus like oven, micro wave oven shall be run with adequate size of wire from the main
distribution board of the consumer. Wall plugs on the circuits for domestic appliances shall be of the
three-pin type, the third pin being connected to "earth". Two pin plugs shall not be allowed. All
appliances used in bathroom for heating or washing purposes or in any damp location must be
effectively earthed.6.10Plugs : All plugs shall be provided with switches on the live wire and not on
the neutral (IE Rules, 1956 Annexure VI, clause 22 (h)).6.11Apparatus interfering with licensee's
system The licensee may discontinue the supply giving reasons if the consumer installs any
instrument, apparatus that are likely to affect adversely, the supply to other consumers. Supply shall
be restored on taking appropriate remedial action to the satisfaction of the licensee.A. C. Motor
installations :6.12The motor shall be provided with control gear so that the starting current of
consumer's installation does not in any case exceed the limit given in the following schedule :
Nature of
SupplySize of Installation Limit of starting current
Single Phase. Upto and including 1 BHP Six times full load current.
Three phase.Above 1 BHP and upto and including 10
BHPThree times full load current.Chhattisgarh State Electricity Supply Code, 2005

 Above 10 BHP and upto and including 15
BHPTwice full load current.
 Above 15 BHPOne and a half times full load
current.
Failure to comply with these regulations will render the consumer liable for
disconnection.6.13Consumer's Apparatus The apparatus/appliances/gadgets used by consumers
should conform to the standards and specifications prescribed by the Bureau of Indian Standards or
equivalent.Power Factor of Apparatus :6.14Welding Transformers : All LT installations where the
connected load of welding transformers exceeds 25% of the total connected load will be required to
have suitable capacitor(s) installed so as to ensure power factor of not less than 85%. Consumers
shall be liable to pay penalty specified by the Commission, from time to time, on account of poor
power factor.6.15Low Tension Shunt Capacitor : Every LT. consumer, including irrigation pump set
consumer, whose connected load includes induction motor/s of capacity of 3 BHP and above, shall
arrange to install low tension shunt capacitors of appropriate capacity at his cost across the
terminals of his motor/s. The following table indicates the details of ratings of capacitor vis-a-vis
capacity of induction motor as a general guideline, however, the consumer shall ensure that the
capacitors installed by him are property matched with the actual requirement of the motors so as to
ensure power factor of 85% and above. Where the meters capable of recording power factor have
been installed, the average monthly power factor of connection shall be worked out on the basis of
actual recording, irrespective of the capacitors ratings mentioned in the table below.
Sr. No. Rating of Individual Induction Motor KVARRating of LT Capacitors
1. 3 BHP andabove upto 5 BHP 1
2. Above 5 BHPupto 7.5 BHP 2
3. Above 7.5 BHPupto 10 BHP 3
4. Above 10 BHPupto 15 BHP 4
5. Above 15 BHPupto 20 BHP 5
6. Above 20 BHPupto 30 BHP 6
7. Above 30 BHPupto 40 BHP 7
8. Above 40 BHPupto 50 BHP 8
9. Above 50 BHPupto 100 BHP 9
Supply to LT installations with induction motor/s of capacity of 3 BHP and above will not be given
unless suitable capacitors to improve power factor are installed.6.16All LT consumers, other than
consumers covered in clause 6.15, with load of 50 KW or above, shall install capacitor of appropriate
capacity so as to ensure power factor of 85% and above. Consumers shall be liable to pay penalty as
may be specified by the Commission, from time to time, on account of poor power factor.6.17Any LT
consumer, who fails to provide LT capacitors as specified hereinbefore, or does not keep them in
proper working order, would be liable to pay a surcharge as may be specified in the tariff from time
to time. However, if meter capable of recording power factor indicates power factor of 0.85 or above,
the power factor surcharge shall not be levied even if capacitors of ratings given in above table
(clause 6.15) are not installed/available. Levy of power factor surcharge as indicated in the approved
tariff, shall be without prejudice to the right of the licensee to disconnect the consumer's installation
till steps are taken to improve the power factor by installing suitable shunt capacitors.6.18TheChhattisgarh State Electricity Supply Code, 2005

licensee may discontinue supply, after a notice of 15 days, to any installation where the average
power factor is less than 70% without prejudice to the right of the licensee to levy
demand/minimum charges as applicable during the period of disconnection.6.19High Tension
Consumers : The following controls shall be installed (refer rule 50 of IE Rules)(a)A linked switch
with fuse(s) or a circuit breaker for consumers having aggregate installed transformer/apparatus
capacity upto 1000 KVA if supplied at voltage of 11 KV and 2500 KVA if supplied at a voltage of 33
KV.(b)A circuit breaker along with linked switch for consumers having an aggregate installed
transformer/apparatus capacity above 1000 KVA if supplied at 11 KV and above 2500 KVA if
supplied at 33 KV.(c)In either case, suitable automatic circuit breakers shall be installed on the
low-tension side of each transformer or on each feeder.6.20Extra-High Tension Consumer
Extra-High Tension consumer shall install a circuit breaker on HV side of the transformer (refer
rule 50 of IE Rules).6.21HT/EHT Consumers All transformers, switch-gears and other electrical
equipments in the installation of the consumer and also those directly connected to the feeders or
lines of the licensee shall be of suitable design and be maintained by the consumer to the satisfaction
of the licensee. The setting of fuses and relays on the consumer's control gear, as well as the
rupturing capacity of any of his circuit breakers, shall be subject to the approval of the
licensee.6.22Notwithstanding the provisions under clause 6.19, it is necessary that the consumer
should obtain prior approval of the Electrical Inspector about the suitability of protective devices or
circuit breakers in accordance with the provisions of the prevailing laws, rules and
regulations.6.23The consumers shall maintain a power factor of 90% and above. Consumers shall be
liable to pay penalty or receive incentive as may be specified by the Commission, from time to time,
on account of variation from specified power factor. The licensee may discontinue supply, after due
notice of 15 days, to any installation where the average power factor is less than 70% without
prejudice to the right of the licensee to levy demand/minimum charges as applicable during the
period of disconnection.6.24Inspection and Testing of Consumer's Installation Before any wiring or
apparatus in the case of low-tension consumer, and any transformer, switchgear or other electrical
equipment in the case of high-tension consumer is connected to the system, it shall be subject to
inspection and approval of the licensee and no connection shall be made without the licensee's
approval. In addition, all high-tension installations will have to be approved by the Electrical
Inspector and all electrical installations in mines will have to be approved by the Inspector of
Mines.6.25Upon receipt of the test report, the licensee will notify to the consumer the time and day
when the licensee proposes to inspect and test the installation. The consumer shall ensure that the
licensed electrical contractor or his representative, technically qualified, employed by him is present
at the time of inspection to furnish to the licensee any information concerning the installation
required by him. The licensee shall provide a copy of the inspection report to the consumer and
obtain the acknowledgement of the consumer.6.26Manufacturer's test certificate in respect of all
H.T. apparatus shall be produced, if required.6.27The licensee shall not connect the conductors and
fittings on the consumer's premises with its works unless it is reasonably satisfied that the
connection will not at the time of making connection cause a leakage from the installation or
apparatus of a magnitude detrimental to safety. The value of the insulation resistance should be as
provided in rule 48 of I.E. Rules, 1956.6.28If the consumer's installation is found to be not safe for
connection, the licensee shall advise the consumer in writing specifying the defects to be rectified.
On receipt of intimation of rectification of defects, the licensee shall retest the installation.6.29The
licensee shall levy no charge for the first test. Subsequent tests, necessitated due to faults found atChhattisgarh State Electricity Supply Code, 2005

the initial test shall be charged for in accordance with the rates approved by the Commission. The
licensee will not accept any responsibility with regard to the maintenance or testing of wiring on the
consumer's premises.6.30Extensions and Alterations : No electrical installation work, including
additions, alterations, repairs and adjustments to existing installations, except such replacement of
lamps, fans, fuses, switches, low voltage domestic appliances and fittings as in no way alters its
capacity or character, shall be carried out upon the premises of or on behalf of any consumer, for the
purpose of supply to such consumer except by an electrical contractor licensed in this behalf and
under the direct supervision of a person holding a certificate of competency. Extension or alteration
of load to all high-tension installations will have to be approved by the Electrical Inspector and
similarly for all extensions and alterations of electrical installation in mines will have to be approved
by Inspector of Mines.6.31If as a result of such proposed extensions and alterations, there is
possibility of an increase in connected load or contract demand over the sanctioned connected load
or contract demand, the consumer shall take steps to submit requisition for additional supply.
Failure to regularize the increase in connected load or contract demand may not only result in
billing at the penal rates, as provided for under the rules, but may also result in disconnection of
supply after due notice.6.32Access to Consumer's Premises for inspection of Consumer's Installation
The authorized persons of the licensee are entitled, at any reasonable time and on informing the
occupier of their intention, may enter the premises of the consumer to which energy is supplied, for
the purpose of inspecting and reading meters on the consumer's premises, for disconnecting supply,
for removing the licensee's apparatus, for testing, repairs, replacing, altering and maintenance of its
property or for doing all things necessary or incidental to proper continuance and maintenance of
supply to the consumer. All such persons visiting consumer's premises must carry photo-identity
cards issued by the licensee and shall produce the same to the consumer or the occupier before
entering the premises. The consumer should immediately check with the licensee if the credentials
of representatives are in question.6.33The licensee or his authorized person shall be entitled to enter
the premises immediately after informing the consumer, for checking unauthorised use of energy,
unauthorized additions and alterations to equipment, theft and misappropriation of energy,
diversion of power, by-passing or tampering of the meter, or for general inspection and testing. On
detection of unauthorised use of energy, unauthorised additions and alterations to equipment, theft
and misappropriation of energy, diversion of power or bypassing or tampering of the meter the
licensee may take actions as per the provisions of the Act.6.34Inspection, testing or checking of any
domestic place or domestic premises however shall not be carried out between sunset and sunrise
except in the presence of an adult male member occupying such premises.6.35If the consumer does
not provide reasonable facility to the licensee to enter the premises for the purposes stated in clause
6.32 and clause 6.33, the licensee may give 24 hours' notice in writing to the consumer, of its
intention to discontinue the supply. If the consumer still does not provide access, the licensee shall
be entitled to discontinue supply to the consumer.6.36If the insulation resistance of the consumer's
installation is found to be so low as to prevent safe use of energy, the licensee or his authorized
representative after giving 48 hours notice shall, without prejudice to other actions as per law,
disconnect the supply of power to the premises till the defects are removed, in accordance with rule
49 of Indian Electricity Rules, 1956.6.37Rating of Installations : The connected load [refer clause 2.1
(k)] of domestic category of consumers shall be determined as per the procedure give in Annexure 3.
Normally survey of load shall be carried out once in two years. The licensee may also carryout
verification of load in selected areas periodically. However, if the licensee has reasons to believe thatChhattisgarh State Electricity Supply Code, 2005

a particular domestic connection or a group of domestic connections might be involved in
unauthorised abstraction of power, the officer in-charge may conduct a survey of the consumer's
premises.6.38The licensee shall send forms of 'self declaration of connected load' to all consumers
once in an year. The consumers may fill-up the form, if his actual current connected load is at a
variance from the recorded connected load. The domestic consumers may also declare enhanced
connected load of their premises, any time during the year, by completing the form given in
Annexure-3 and submitting the same to the licensee alongwith an application for change in
connected load.The licensee may arrange to conduct a survey of the premises of the consumer to
determine the load of the premises. In case such a survey is not carried out within thirty days from
the date of submission and the load applied for is higher than the recorded load of the consumer, the
load declared by the consumer shall be deemed lo have been accepted. The licensee shall issue the
demand note for additional charges, if any, immediately.6.39The connected load of all categories
other than domestic category of consumers shall be the aggregate of the manufacturer's rating of all
energy consuming devices, in the consumer's premises, which can be used simultaneously. This
shall be expressed in KW, KVA or HP. During the process of determination of connected load, if the
manufacturer's rating is not available or doubtful the licensee may use suitable apparatus to
determine the load of the item. If, both air-conditioner and room heater are found in the same
premises, the load of the item with higher rating shall be taken into account. Items stocked for the
purpose of sale/repair or as genuine spare shall not be considered for the purpose of determination
of connected load. The licensee shall carry out periodic survey of streetlights and record the type of
lamps being used alongwith their load.6.40All installations other than those of domestic category
are subject to rating/re-rating by the licensee at its discretion. If the consumer is not satisfied with
the rating determined by the licensee, he may get his apparatus rated by one of the engineering
institutes approved by the licensee for determination of load of apparatus. Both the consumer and
the licensee may depute their respective representatives to be present during the process of
determination of load at the institute. The final report issued by the institute shall be accompanied
with the details of test(s) conducted. The rating determined by the said institute shall be final and
acceptable to both the consumer and the licensee.6.41Where for any reason, it is not possible to
determine the maximum demand, power factor or any other electrical quantity in respect of an
installation, the licensee shall determine such quantities periodically by rating/re-rating, which shall
be binding on the consumer. For arriving at conclusion on re-rating the licensee shall be at liberty to
install a meter having facility to record maximum demand, power factor, etc.6.42If a consumer
applies to the licensee for re-rating his installation due to additions or alternations in the
installation, the procedure as stated in clause 7.3 to clause 7.14 shall apply.6.43Generator in the
Consumer's Installation and Parallel Operating with the Supply System of the Licensee Operations
of a generator in the consumer's installation to run in parallel with the licensee's system is
permissible only with the written consent of the licensee.6.44Where no such consent has been given,
the consumer shall arrange the plant, machinery and apparatus of his generating units, including an
extension of or addition to the same, to operate in an isolated mode and the generator, in no case,
should get connected to the licensee's system. The licensee, on intimating the consumer, can enter
the premises and inspect the arrangement to ensure that at no time the generator gets connected to
its system.6.45Where consent has been given for parallel operation, the consumer shall arrange his
installation to be protected from disturbances in the licensee's system. The consumer should also
ensure that his supply does not get incorrectly connected to the licensee's system. The licensee shallChhattisgarh State Electricity Supply Code, 2005

not be liable for any damage caused to the consumer's plant, machinery and apparatus on account of
such parallel operation, or any adverse consequence arising thereof. For parallel operation with the
grid, the consumer shall have to follow the provisions of the relevant Grid Code and other
regulations and payment of charges as approved by the Commission. The actual operations shall be
carried out in coordination with both the State Transmission Utility and the licensee. -6.46In case
the consumer's supply gets extended to the licensee's system from a generator or inverter or from
any other source, without appropriate approval from the licensee, causing damage to the licensee's
apparatus or to human life, the consumer shall be liable for the same and shall duly compensate the
licensee for all losses caused to the licensee or to the licensee's other consumers.6.47Harmonics If
the licensee detects and proves to the consumer that the consumer's system is generating harmonics
above acceptable limits, the licensee may ask the consumer to install appropriate harmonic filter
within a reasonable period of time. The tolerance limits of harmonic injections are as follows : -
EHT-THD -3%
HT -4%
LT -6%
Chapter 7
Contract Demand, Agreement, Security Deposit
Contract DemandLT Consumers without Maximum Demand (MD) based (two part) tariff
7.
1.
The Contract Demand for LT consumers without MD based (two part) tariff will be the connected
load of the premises as per the agreement entered into between the consumer and the
licensee.7.2LT Consumers with MD based tariff and all HT and EHT consumers The Contract
Demand shall be as per the agreement entered into between the consumer and the licensee and
having regard to the requirement of the consumer's installation.
7. [3 Procedure for Enhancement of Contract Demand/connected Load]
[Substituted by Notification No. 19/CSERC/2007, dated 16.4.2007.]
Applications for enhancement of load shall be submitted in duplicate to the
licensee in the prescribed form (Annexure 1 and 2).
7.4The licensee shall examine the feasibility of supply of the enhanced load within thirty days and
inform the consumer.(a)whether the additional power can be supplied at the existing voltage or at a
higher voltage;(b)addition or alterations, if any, required to be made to the system and the cost to be
borne by the consumer;(c)amount of additional security deposit, cost of additional infrastructure
and the supply arranging charges, if any, to be deposited; and(d)change in the classification of
consumer, if required.7.5The application for enhancement of the contract demand will not be
accepted if the consumer is in arrears of payment of the licensee's dues. However, the applicationChhattisgarh State Electricity Supply Code, 2005

may be accepted if the payment of arrears due from the consumer has been stayed by a court of law,
or by the Commission or an authority appointed by the Commission or facility has been granted by
the licensee for payment of arrears in instalments.7.6If the supply of enhanced load is feasible, the
consumer shall:(a)furnish work completion certificate of consumer's installation and test report
from a licensed electrical contractor where alteration of installation is involved.(b)furnish letter of
approval for the electrical installation of the consumer from the Electrical Inspector, and other
statutory clearance as required under other regulations in force, if required. Similarly, approval
from' Inspector of Mines shall be provided for additional load to be provided for electrical
installation for mines.(c)pay additional security deposit, cost of addition or alteration required to be
made to the system, if any, and the supply arranging charges, if applicable.(d)execute a
supplementary agreement.7.7If no addition or alteration to the system including new/alternate
metering arrangement is required, the enhanced load will be released from a date as stated in the
new agreement after completion of the requisite formalities. If the system needs any alteration or
addition, the procedure as given for a new connection shall be followed.7.8In case of Railways
traction, the consumer may be provided such additional supply in excess of contract demand as may
be agreed between the licensee and the consumer after the latter has given due notice of six weeks in
writing of his desire to have the contract demand altered.
7. [8A If a consumer who has reduced his connected load/contracted demand
due to any reason, desires to restore the load within one year of such
reduction, upto the sanctioned load prior to the reduction, he shall be liable
to pay only the actual expenditure incurred in restoration of load applied for.
If such restoration of load involves a load which is more than the load
sanctioned earlier, supply arranging charges shall be payable on the
difference between the load applied for and the load sanctioned earlier.
Restoration of load after a period of one year shall attract supply arranging
charges as fixed by the Commission from time to time. Such restoration shall
be subject to the condition that reduction of load/demand shall not be
permitted again within the next one year of supplementary agreement.]
[Inserted by Notification No. 19/CSERC/2007, dated 16.4.2007.]
7.9Procedure for Reduction of Contract Demand Generally no application for reduction of contract
demand/connected load shall be entertained by the licensee within the-initial period of agreement,
which is two years from the date of commencement of contract. However, if the consumer is able to
satisfy the licensee of the compelling reasons for reduction in contract demand/connected load,
reduction to the extent of 50 percent of the contract demand/connected load shall be permitted once
during the period of agreement.In case of domestic light and fan consumers, the agreement can be
terminated after giving one month's notice on either side at any time, even within the initial period
of agreement.7.10Applications for reduction of load, after the expiry of initial period of agreement,
shall be filed in duplicate with the licensee in the prescribed form alongwith the following
documents:(a)Details of alteration/modification/removal of the electrical installation with work
completion certificate and test report from a licensed electrical contractor where alteration ofChhattisgarh State Electricity Supply Code, 2005

installation is involved.(b)Any other reason for reduction of contract demand.(c)Details of
generators, if any, installed by the consumer along with copies of the safety clearance certificate
issued by the competent authority for installation of the generators.7.11On receipt of the application
for reduction of load, the licensee shall take the following steps :(a)The licensee shall consider the
grounds stated in the application, verify the same and decide the application within a period of 60
days by a reasoned speaking order. If the consumer is not satisfied with the decision of the licensee,
an appeal can be made to the Electricity Grievance Redressal Forum set up by the licensee under
Section 42 (5) of the Act and then to the Electricity Ombudsman as appointed or designated by the
Commission under Section 42 (6) of the Act whose decision shall be final subject to such remedy as
may be available under any statute.(b)If the application is not decided by the licensee within the
above-mentioned period of 60 days, the applicant may, by a written notice to the licensee, draw its
attention to the matter and if no decision is still communicated to him within the period of further
30 days, the permission of reduction of contract demand shall be deemed to have been granted.(c)[
The reduction of contract demand shall take effect from 30 days of the date of application or from
the first day of the billing month following the billing month in which the application for reduction
is received, whichever is later.] [Substituted by Notification No. 19/CSERC/2007, dated
16.4.2007.]7.12After expiry of the initial period of agreement, the consumer may apply for reduction
of his contract demand upto any extent. The above reduction is subject to permissible minimum
contract demand specified in clause 3.4. In case the consumer reduces the contract demand with the
utility and sources power from another supplier, he shall be liable to pay additional surcharge as
provided in Section 42(4) of the Act.7.13In all existing agreements executed prior to this Code
coming into effect, if there is any provision regarding restriction on reduction of contract demand,
the same shall be deemed to have been modified to the extent of the provisions made in this Code.
7. [14 When reduction of contract demand is agreed to, the consumer shall
execute a supplementary agreement. The licensee shall recalculate the
security deposit and the excess security deposit left with the licensee, if any
shall be adjusted in three succeeding bills against the bills security in five
succeeding bills against the bill amount. However, after adjustment in three
Bills, if there is may balance, the same shall be refunded to the consumer
within a period of one month.] [Substituted by Notification No.
19/CSERC/2007, dated 16.4.2007.]
7.15Agreement An agreement, in the standard form, shall be executed by the applicant on the stamp
paper of a prescribed value, for getting a new connection and for change in the agreed parameters
like contract demand. In case of any special circumstances, special clauses may be added to the
agreement, if agreed to between the licensee and the consumer, provided such clauses do not
contravene the provisions of the Act, this Code, and other rules and regulations in force. These
special clauses shall form a part of the agreement. A copy of the agreement shall be given to the
consumer after execution. The maps submitted, agreed upon and signed by both the consumer and
the licensee shall form a part of the agreement.7.16The licensee shall modify the structure of the
agreement form presently in use and to bring it in conformity with the provisions of this Code.7.17If
there is a need to modify/amend the agreement signed between the licensee and consumer, it mayChhattisgarh State Electricity Supply Code, 2005

be done by a supplementary agreement.7.18Any amendments for the purpose of change of name,
shifting of premises or change in connected load shall be done if both the consumer and the licensee
agree to these amendments and the same shall be incorporated in the agreement by execution of a
supplementary agreement.7.19Termination of Agreement If power supply to a consumer remains
disconnected for a period of sixty days for non-payment of charges or dues or non-compliance of
any direction issued under this Code, the licensee shall issue a show cause notice, to be replied
within seven days, to the consumer for termination of the agreement. In case no effective steps are
taken by the consumer for removing the cause of disconnection and for restoration of power supply,
the agreement of the licensee with the consumer for power supply shall be terminated on expiry of
the period of seven days, provided the initial period of the agreement is over. During the period of
temporary disconnection the consumer shall be liable to pay the demand charges or minimum
charges.7.20Domestic and single-phase non-domestic category of consumers may terminate the
agreement after giving one month's notice. All consumers other than domestic and single-phase
non-domestic category can terminate the agreement after the expiry of the initial period of two years
on giving one month's notice. However, if the agreement is to be terminated for reasons whatsoever,
for categories other than domestic and single phase non-domestic, before expiry of the initial period
of agreement, the consumer shall be liable to pay charges as per tariff for the balance period of the
said two years. The licensee shall arrange for special meter reading, at a mutually acceptable date, to
facilitate preparation of the final bill of the consumer. The agreement shall be terminated on the last
day of the month and the licensee shall raise the final bill accordingly.7.21On termination of the
agreement, the licensee shall be entitled to remove the service line and his other equipment from the
premises of the consumer for supply of power. After permanent disconnection, if the consumer
wishes to revive the connection, his application for the same would be treated as an application for
new connection and would be entertained only after all outstanding dues have been
cleared.7.22Miscellaneous No consumer shall sell electrical energy supplied to him by the licensee to
any other person.7.23In case of breakdowns in electricity supply system of the licensee, the supply
of electricity to the consumer may be curtailed, staggered or cut-off as may be warranted according
to the situation. The licensee may also curtail, stagger or cutoff electricity supply to consumers on
account of periodical maintenance of electricity supply system, after giving due notice to the
consumers.7.24The licensee may resort to regulation of supply (planned load-shedding) to the
consumers, after due notice, if the Commission orders accordingly as per the provisions of Section
23 of the Act.7.25The electrical energy supplied to the consumer shall not be utilized by the
consumer in any manner prejudicial to the licensee and all usage must be in accordance with the
provisions of the agreement and the Acts as applicable.7.26No consumer shall divert the use of
energy to any other purpose, other than that mentioned in the agreement or extend the line beyond
its premises other than that for which it was sanctioned by the licensee, until and unless prior
sanction of the licensee is obtained for such diversion or extension.7.27Where the consumer's
installation is disconnected from the licensee's supply as per direction of the Government, the
Electrical Inspector or other appropriate authority, the supply shall be reconnected on payment of
prescribed reconnection fee with the approval of the Government or the Electrical Inspector or other
appropriate authority, as necessary. During the period of temporary disconnection the consumer
shall be liable to pay the demand/minimum charges.[Security Deposit shall be payable according to
the [Substituted 'Security Deposit' by Notification No. 19/CSERC/2007, dated 16.4.2007.]
Provisions or Section 47 (1) and (4) of the Act and CSERC (Security Deposit) Regulations, 2005.]Chhattisgarh State Electricity Supply Code, 2005

[Substituted by Notification No. 19/CSERC/2007, dated 16.4.2007.].7.28Initial Security Deposit
The licensee may take a security deposit from the consumers for consumption equivalent to the
estimated consumption of specific number of days as indicated in the following table.
Sr.
No.Nature of ConsumerNo. of
DaysRemarks
1. Agricultural 90Annual average to be
estimated/considered
2. Stone crushers, hot-mix plants 90Annual average to be
estimated/considered
3.Consumers unable to provide proof of
legaloccupation90Annual average to be
estimated/considered
4. Other consumers 45Annual average to be
estimated/considered
7.29Consumer shall have the option to make advance payment and in such event security amount
shall be proportionately fixed. The procedure for determination of security deposit, for different
categories of consumers, shall be determined by the licensee and approved by the Commission. The
deposit shall be accepted in the form of cash or draft in case of LT consumers and in the form of only
draft or banker's cheque in case of HT consumers. Cheques may be accepted subject to the condition
that supply will commence only on realisation of the cheque. On termination of the agreement, the
security deposit will be refunded to the consumer after adjustment of the amount, if any remaining
payable by him.7.30Additional Security Deposit The amount of the security deposit obtained from
the consumer will be reviewed by the licensee, annually on the basis of consumption during the
previous 12 months for LT consumers, and half-yearly on the basis of the consumption during the
previous six months for HT consumers. The consumer shall be required to pay an additional
security deposit/shall be refunded the amount if one and half times the amount of monthly bill
based on his average consumption during the period concerned and the tariff applicable etc.
exceeds/is lower than the amount of the security deposit held by the licensee, by 20%.7.31In case, a
consumer defaults in payment of monthly bills for more than three times in a financial year, it shall
be open to the licensee to increase his security deposit from 45 days' consumption revel to 90 days'
consumption level.7.32In the case of consumers who are sanctioned additional load, the additional
security deposit shall be calculated for the additional load as if it is a new service.7.33The licensee
may allow the consumer on his request, the facility to pay additional security deposit in three
installments.7.34The licensee shall serve a notice of atleast one month to deposit the additional
security. If the consumer fails to pay the additional security deposit as per the notice, the licensee is
entitled to refuse or discontinue the supply of electricity so long as such failure continue. The
consumer will be liable to pay surcharge if he delays payment of security deposit.7.35The licensee
shall pay interest at the bank rate on such security deposits taken from the consumer as per the
provisions of CSERC (Security Deposit) Regulations, 2005.7.36The security deposit shall be
returned to consumer, upon termination of the agreement and after adjustment of all dues, within
60 days of completion of formalities. In case of delay beyond 60 days period, interest at the rate of
1% per month in part thereof shall be payable to the consumer.Chhattisgarh State Electricity Supply Code, 2005

Chapter 8
Meters
8.
1. Requirement of Meters.
- No new connection shall be given without a meter and cut-out or a Miniature Circuit Breaker
(MCB) or Circuit Breaker (CB) of appropriate specification from the date of issue of this Code.8.2All
consumers shall have to accept the installation of an appropriate metering device, load-limiter,
tamper proof boxes or other apparatus when the licensee approaches them to install one, and the
consumer shall be required to provide appropriate and suitable site for placement of meter and
related equipments to the satisfaction of the licensee.8.3In case of HT supply, if HT metering cannot
be readily provided, LT metering may be provided on the LT side of the consumer's transformer. In
such cases, electrical quantities for billing purposes shall be computed by adding three percent to
the quantities registered by the LT meter towards transformation loss. This arrangement shall not
continue for more than three months and the licensee shall arrange to install a meter on the HT side
of the transformer within the said period.8.4If supply to an HT or EHT consumer is given on an
independent feeder for his exclusive use, the metering arrangement may be installed either at the
consumer's premises or, if mutually agreed, at the licensee's sub-station.8.5The licensee is
authorised to review the status of the meters already installed. If better meters are available because
of technology up-gradation, those be introduced subject to suitability of the site where meter is
placed in the consumer's premises. The licensee may install remote metering device in the consumer
premises as per the technical requirements of the specific device and in such cases the consumers
shall provide access to the meter through his telephone line. The licensee may also install maximum
demand (MD) meter having MD recording feature and ToD features or such additional features in
the consumer's premises. The licensee may also install 'check meter' at a consumer's location or for
a group of consumers. In case the difference in consumption recorded by the 'check meter' and the
'billing meter' is found to be more than permissible limits, the licensee shall be free to install the
billing meter on electricity pole or pillar boxes after giving due intimation in writing to the
consumer.8.6Supply and Installation of Meters and Cut-outs/MCBs/CBs The licensee shall supply
the meter and metering equipments, cut-out/MCB/CB/ load limiter to consumers at the time of
serving new service connection or at any other time as required. The licensee shall keep the meter in
proper working condition and the consumer shall pay the monthly rent, if any, for the meter and
metering equipments at the rate approved by the Commission. If the licensee fails to keep the meter
or metering equipment in proper working condition, the consumer shall not be liable to pay the
meter rent for the period the meter remains defective.Any consumer, if he so deserves, can purchase
and provide his own meter/metering device of the standard approved by the licensee. In such cause
the consumer shall maintain the meter in accurate working condition. Scheduled testing of
meter/metering device will be conducted by licensee on payment of approved testing fees. Such
consumers shall not be Required to pay the monthly meter rent.8.7Meter should ordinarily be fixed
outside the premises in such a manner that it is protected from the elements (weather etc.) and can
be read from outside without the need of meter reader to get the premises unlocked or opened forChhattisgarh State Electricity Supply Code, 2005

this purpose. In special situation, the licensee may permit the meter to be fixed at a place different
from the one indicated above and this permission shall be accorded by the officer not below the rank
of Assistant Engineer and shall be in writing. The consumer shall run his wiring from such point of
supply. The meter box shall normally be mounted at such a height that meter reading
counter/display window is at eye level. In case of LT consumers meter and the cut-out/MCB or, in
case of HT/EHT consumers, meter, circuit breakers and its associated equipment including cables
shall be installed by the licensee at the point(s) of supply within the protected premises of the
consumer near to main entry gate.8.8All new meters should be installed in a tamper-proof meter
box. The licensee shall prepare and implement a phased-plan to install tamper-proof metering boxes
for all the meters, which are at present installed without meter boxes.8.9In case of semi-permanent
(kuchha) houses the licensee shall ensure that the meter is properly fixed on a wall and is accessible
to the meter reader. In case the consumer does not provide good quality wall for fixing the meter,
the licensee shall be free to fix the meter on the electricity pole or in a pillar-box to be provided by
the licensee. The licensee shall also ensure that the earthing of the installation is proper.8.10In case
meter is installed inside the premises the meter and other equipments of the licensee shall be placed
very near to the point of entry of supplier's line, so that the metering unit is visible from outside the
premises and independent/unobstructed entry to the meter or metering cubical can be provided.
Wherever required the consumer shall provide and maintain at his expense a locked and
weatherproof enclosure of a design to be approved by the licensee for the purpose of housing the
licensee's terminal high tension switchgear and equipment.8.11Whenever new meter/metering
equipment is installed (as a replacement or for a new connection), the meter shall be properly sealed
on behalf of and in the presence of representatives of both the parties. Both the representatives,
witness to the sealing shall affix their signatures on the specified documents mentioning their full
name. The seal, name plates and distinguishing numbers or marks affixed on the meter and
metering equipment shall not be broken, erased, altered or in any way interfered with by either
party except in the presence of a duly authorised representative of the other party.8.12(i)The
consumer shall be responsible for safe custody of meter(s), cut- outs/MCB/CB etc., except in cases
where such meter(s), cut-outs/MCB/CB etc. are installed in the premises of the licensee.(ii)In case a
meter is lost or stolen from the premises of the consumer, the consumer shall report such matter in
the police station and the supply shall be restored by the licensee after installation of a new meter at
the cost of the consumer.8.13Testing of Meters It shall be the responsibility of the licensee to satisfy
himself regarding the accuracy of the meter before it is installed and may test it for this
purpose.8.14The licensee shall also conduct periodical inspection/testing of the meters as per the
following schedule:
(a)Single phase meters :once every five years
(b)LT 3 phase meters :once every 3 years
(c)HT meters including MDI :once a year.
CT and PT shall also be tested alongwith meters.Records of these test results shall be maintained in
accordance with rule 57 of Indian Electricity Rules, 1956.In case, the licensee requires to remove the
existing meter, the representatives of the licensee must produce an authenticated notice to this
effect and sign the document, mentioning his full name and designation, as a receipt, before
removing the meter. The consumer shall not object to such removal.8.15Defective Meters The
licensee shall have the right to test any meter and related apparatus if there is a reasonable doubtChhattisgarh State Electricity Supply Code, 2005

about the accuracy of the meter, and the consumer shall provide the licensee necessary assistance in
conduct of the test. The consumer shall be allowed to be present during the testing.8.16A consumer
may request the licensee to test the meter, if he doubts its accuracy, by applying to the licensee
alongwith the requisite testing fee. The licensee shall test the meter within 30 days of the receipt of
the application. Preliminary testing of electronic meters can be carried out in the premises of the
consumers through electronic testing equipment.8.17In all cases of testing of a meter in the
laboratory, the consumer shall be informed of the proposed date of testing atleast 7 days in advance,
so that he may be present at the time of testing, personally or through an authorized representative.
The signature of the consumer or his authorized representative, if present, shall be obtained on the
Test Result Sheet.8.18If a consumer disputes the results of testing, he may make a representation to
the Electrical Inspector within one month from date of conveying the test result by the licensee who
may decide as per the provisions of the Annexure VI, clause 18 of the Indian Electricity Rules,
1956.8.19Meter (Including Maximum Demand Indicator) Not Recording The consumer is expected
to intimate the licensee in writing, as soon as he notices that meter has stopped/is not recording if
the situation comes to his notice. The licensee shall acknowledge the intimation given by the
consumer.8.20If during periodic or other inspection by the licensee, any meter is found to be not
recording, or a consumer makes a complaint in this regard, the licensee shall arrange to test the
meter within 7 days. In case LT consumer's meter is found defective, it should be repaired/replaced
within 15 days in urban areas, and within 30 days in rural areas. In case of HT consumers, meter
should be repaired/replaced within 15 days.8.21If the meter stops working and the check meter,
wherever provided by the licensee, is functioning, the consumer shall pay the electricity charges on
the basis of the check meter.8.22In case of burnt meter, the licensee shall be entitled to recover the
price of the meter.[Application of CEA Regulations [Added by Notification No. 19/CSERC/2007,
dated 16.4.2007.]8.23The Provisions of the regulations framed by CEA under Section 55 (1), 73(e)
and 177(2)(c) of the Electricity Act, 2003 as amended from time to time and the orders/guidelines of
the Commission in this regard shall be applicable with regard to installation and operation of
meters.]
Chapter 9
Billing
9.
1. Meter Reading, Bill Generation and Bill Distribution.
- The periodicity of the meter reading for various categories of consumers is given below. The
licensee may however, improve upon the schedule if he finds it necessary or useful.
Consumer Category Meter Reading
Domestic - Rural Once in three months
Domestic - Urban (only under Municipal Corporation,
Raipur,Bilaspur, Durg and Bhilai)MonthlyChhattisgarh State Electricity Supply Code, 2005

Other Domestic Urban Once in two months
Non-Domestic<10KW - Rural Once in two months
Non-Domestic - Others (Urban & Rural) Monthly
LT Industrial Monthly
Agriculture - Rural Once in three months
Agriculture - Urban Once in two months
Street light, Waterworks, X-Ray Plants, Electric
CrematoriumMonthly
HTMonthly (as far as practicable on the
same day of the month)
In respect of domestic consumers meter should be read only during daylight hours.
9. [2 The meter reader/inspecting officer shall have with him the photo
identity card provided by the licensee and shall wear it in such a manner that
it is visible during the matter reading.] [Substituted by Notification No.
19/CSERC/2007, dated 16.4.2007.]
9.3Arrangements shall be made by the licensee to display the meter reading and payment status of
high value consumers on the Internet.9.4The consumers may retain the electricity bills in their
record as the bills display the readings taken during preceding meter-reading cycles. Wherever the
bills do not display these details, the consumer may bring it to the notice of the local office of the
licensee.9.5The licensee may use hand held instruments, meter reading instrument (MRI) or
wireless equipment for recording meter readings and for the generation of bills on the spot. If bills
are prepared on the basis of MRI downloads or if meter reading is taken on the basis of remote
meter-reading and the consumer wishes to have a record of the reading taken, he shall be allowed to
do so by the official taking the meter reading.9.6In case, during spot billing procedure, the licensee's
representative could not take meter reading due to the absence of the consumer, the representative
may leave a note and request the consumer to inform the meter reading over telephone. T he
consumer may thereafter take the delivery of the bill on any convenient date. However this
procedure of receiving meter reading over telephone shall not extend beyond one meter reading
cycle at a stretch.9.7It shall be the licensee's obligation to assign a unique consumer number for
each consumer and communicate the same to the concerned consumer. The unique consumer
number may include pole number, transformer number, 11KV feeder number, distribution centre
number and division number.9.8It shall be open to the licensee to adopt a scheme for prepayment
of energy charges for such consumers who are getting unmetered supply and the details of such
prepayment scheme shall be got approved by the licensee from the Commission and shall be
implemented after ensuring adequate publicity.9.9Bills shall be prepared for each category on the
basis of the information provided in the prevailing tariff order of the Commission.9.10When supply
to a new consumer is commenced in the middle of a month, the demand charges, minimum charges
and/or any other similar fixed charges shall be levied on prorata basis for the number of days for
which supply is given. T he units to be charged under various blocks or slabs shall also be
accordingly prorated. For the purpose of this sub-clause, a month shall be computed as 30Chhattisgarh State Electricity Supply Code, 2005

days.9.11The licensee shall inform the consumer, in the beginning of the financial year, of the(a)date
on which bill will be issued by the licensee every month to the consumer(b)date by which bill will be
delivered to the consumer, and(c)due date for payment of his bills.These will normally be the due
dates for all billing cycles for that consumer during that financial year. T he licensee shall arrange to
get the name of the bill distributor rubber-stamped and the bill distributor shall write down the
delivery date of the bill on the body of the bill before it is handed over to the consumer.9.12Separate
bills shall be issued for audit recovery and other recoveries except demand for additional security
deposit. Such bills should be accompanied by the written details of basis of billing, period of billing
etc.9.13The licensee shall endeavour to take monthly meter reading instrument (MRI) download for
all connections where meters with MRI download facility are installed.9.14If for any reason, meter is
not accessible for reading, the licensee shall send a notice in writing to the consumer to keep the
meter available for reading at the time and date given in the notice. If after the notice, the consumer
does not given access to the meter for reading, the licensee shall be free to send a provisional bill
together with a surcharge. The rate of surcharge shall be as provided in the Schedule of
Miscellaneous Charges. The provisional bill shall be prepared on the basis of average monthly
consumption of the previous financial year.9.15The amount thus billed shall be adjusted against the
bill raised on the basis of actual meter reading during subsequent billing cycle, such provisional
billing shall not continue for more than two meter reading cycles at a stretch. If the meter remains
inaccessible even for the next cycle, the consumer will be served with a notice to open his premises
for reading of the meter at a fixed time and date. If the meter is not accessible at the time fixed in the
notice, the supply will be liable to be disconnected after serving a 24 hour notice under section 163
(3) of the Act.9.16It is the responsibility of the meter reader to note down the details of every
stopped/defective meter and to file a report at the end of each working day in prescribed proforma
to the officer in charge of the distribution centre in case of LT consumers and officer in charge of the
circle office in case of HT consumers, who shall be responsible to take immediate steps to replace or
repair the stopped/defective meter. In addition to the entry made in the meter-reading book, a
separate monthly report shall be required to be given by the officer in charge of the distribution
centre to the officer in charge of the sub division and division offices, in respect of all stopped meters
and the action taken to replace them.9.17In order to recover the energy charges for the duration
when the meter remains dysfunctional, average monthly consumption of previous three meter
reading cycles shall be the basis of billing. In case a check-meter is available, the readings of the
meter may also be used for assessment of consumption. In case of HT consumers if during the
period when the main meter is defective, the check meter is not installed or is also found defective,
the quantity of electricity supplied shall be determined as stated above; provided that if in the
opinion of the licensee, the conditions in the consumer's installation during the month in question
were such as to render billing on such average consumption not equitable either to the consumer or
to the licensee, the electricity supplied during such period shall be determined by the incharge of the
local area circle of the licensee. In the event of the consumer not being satisfied with such
determination, he may appeal to the incharge of the local Region of the licensee.9.18For low tension
consumers, the defective meter shall be replaced within a period of thirty days, from the date of
reporting of the fault. In case of HT consumers, meter should be replaced within fifteen days of
detection of fault.9.19The meter reader shall furnish a list of connections where the meter reading
could not be recorded or the meter has not recorded any consumption of electricity, to the officer in
charge (OIC) of the District Centre. The OIC shall prepare a list of such consumers where meterChhattisgarh State Electricity Supply Code, 2005

reading could not be taken or the defective meter could not be replaced (refer clause 8.20) within
thirty days and report the same to the Assistant Engineer and Executive Engineer. The licensee shall
develop and have in place a detailed document describing systems, procedure and accountability
regarding replacement of defective meters.9.20Senior officers of the licensee shall carry out the
sample checking of meter readings as per the Schedule drawn out by the officer in charge of the
distribution circle of the area. It should be the endeavour of the licensee that meter readings in case
of atleast 10% of LT meters are checked in a year by the team of officers, not below the rank of
Junior Engineer.9.21The licensee may send bills to consumers by hand or by post (also see clause
9.11 - regarding the date of delivery of bill). In case of hand delivery of bills proof of service of bill
shall be maintained at the concerned office of the licensee. On a written request from a consumer
the licensee shall send it by registered post and the expenses of such delivery of bill shall be
recoverable from the consumer.9.22The licensee shall ensure distribution of bills to consumers not
less than seven days before the due date for payment in cash.9.23Special Reading of Meters in cases
of Change of Occupancy/Vacation of Premises for Domestic Consumers It shall be the responsibility
of the owner of the connection to get a special reading done by the licensee at the time of change of
occupancy or on the premises falling vacant.9.24The owner/user of the connection may request the
licensee in writing for special reading atleast 7 days in advance of the said vacancy of the premises
by the existing user or change of the occupancy, as the case may be.9.25The licensee shall arrange a
special reading to be done and deliver the final bill, including all arrears till the date of billing, on
the request of consumer.9.26The licensee may charge reasonable fee for the above service as per the
miscellaneous charges approved by the Commission.9.27Contents of the Energy Bill The bill for
metered connections shall have the following details :(a)Service Connection Number(b)Bill
number(c)Period of bill(d)Name and address of the consumer(e)Pole Number from which
connection is served(f)Name, address and telephone number of the distribution centre(g)Date of
issue of bill(h)Tariff category(i)Tariff, rate of electricity duty and cess
applicable(j)Contracted/Connected load/demand(k)Single phase or three phase
connection(l)Identification details of the meter(m)Reading date - past and present(n)Meter reading
- past and present(o)Units assessed(p)Credit(q)Basis of bill.(r)Meter rental(s)Current months'
charge - Energy Charges, fixed/demand charge, Minimum Charges, Variable Cost Adjustment (VCA)
Charges, Electricity Duty, Cess meter rent, welding/capacitor surcharge, security deposit instalment,
Rebate allowed, others if any(t)Arrear of Electricity Charges, Delayed Payment Surcharge
arrears.(u)Bill delivery charges if applicable(v)Total charges(w)Delayed payment surcharge(x)Due
dates of payment - for payment through cheque and cash(y)Authority in whose favour cheque/Bank
draft is to be issued. (To be printed on reverse of the bill).(z)Security deposit held and
required.9.28The following information would also need to be provided to the consumer as an
attachment to the bill or printed/stamped on the bill : -(a)The names(s)/address(es) of collection
centres(b)Working hours for collection of bills.(c)Designation and address of the authority with
whom grievance pertaining to bills, meter, meter reading etc. can be lodged.(d)Any other message
that the Licensee may like to give e.g. requesting the consumer to indicate their phone number, if
available, on the portion of the bill retained by the licensee on receipt of payment. This information
can be used for better communication with consumers.9.29The bill may contain additional
information, if any, as desired by the licensee.9.30The licensee shall make arrangements to provide
guidance and information to any consumer on telephone and for this purpose shall set-up call centre
or centres according to the directives given by the Commission in this regard. All urban areas mayChhattisgarh State Electricity Supply Code, 2005

be brought under this facility in the first phase and rural areas may be included thereafter. Details of
payment status, arrear status, authorised load, contract demand etc. may be provided to the
consumer if he discloses his connection number and address. The licensee shall also develop and
implement, within a reasonable time as directed by the Commission, a bill details display system on
internet for division headquarter towns to being with and later to be extended to cover all district
headquarter towns. Access to this information display may be controlled through password system.
Chapter 10
Payment and Disconnection
10.
1. Payment.
- Consumers are expected to make payment for the energy used by them every month.10.2The
licensee shall ensure adequate publicity of the addresses/locations and working hours of the
collection centres including those of banks where consumers can make payments. The licensee shall
provide a choice of maximum alternative modes of payment to the consumers like payment through
cash, local cheque, bank draft, banker's cheque, Electronic Clearing System (ECS), credit/debit card
etc. and a consumer shall be allowed to make payment through cheque for amounts above Rs.
100/-.10.3During the days when there is rush at the collection window, separate queueing
arrangement should be made for senior citizens, women and physically challenged persons and they
should be attended on priority.10.4The collection centres should have the facility of receiving
payment from consumers/representatives of consumers who wish to make payments on behalf of a
number of consumers. Separate counters should be provided for this purpose so that the waiting
time for other consumers is not increased.10.5In order to reduce the workload of the collection
counter, all payments of bills above Rupees five thousand should be made through cheque/banker's
cheque/ demand draft payable at local branch of the bank concerned.10.6The licensee should make
arrangements to receive payment though drop boxes where the consumer may drop his cheque
(crossed account payee). The licensee should keep the drop boxes at the collection centres and at
other locations as notification from time to time to facilitate the payment without the need for
standing in the queue. Cheques should be drawn in favour of the CSEB/licensee. The service
connection number, bill month, consumer name and address including telephone number if any
should be clearly written on the back of the cheque. In case the bank levies any clearance charge, the
same amount shall be recoverable from the consumer in the subsequent bill.10.7The due date of
payment of all consumers shall normally be fifteen days from the date of issue of bill. If due date of
payment mentioned in the bill is a public holiday, the succeeding working day shall be treated as the
due date.
10. [8 In the event of non-realisation of cheque, the licensee shall have the
right to increase the security deposit from the consumer. The licensee shall
also have the right to levy cheque dishonour charges besides delayedChhattisgarh State Electricity Supply Code, 2005

payment surcharge and also take other actions as per law. The licensee may
also insist on future payment by demand draft or by cash.] [Substituted by
Notification No. 19/CSERC/2007, dated 16.4.2007.]
10.9In case of non-receipt of bill within the specified date of receipt of bill (as stated in clause 9.11
(b), the consumer may contact the bill issuing office to collect the duplicate bill and arrange
payment of the bill. In case the licensee is not in a position to provide duplicate bill, the consumer
shall pay on the basis of past average bill amount. The licensee shall investigate the cause of
non-receipt of bill and take suitable steps to ensure that the consumer receives his electricity bills
promptly thereafter.10.10Every consumer shall be issued a receipt in token of payment having been
received.10.11The consumer may also be allowed to make advance payment of future bills, which
shall be adjusted in the succeeding months. However, only the regular bill amount shall be adjusted
from the advance payment. Before adjusting any other amount, the consent of the consumer shall be
sought. The licensee will also consider suitable rebate in case of advance payment.10.12All
consumers who default in the payment of the billed amount shall be liable to pay delayed payment
surcharge, on the amount outstanding, at rates as approved by the Commission from time to
time.While accepting payment after the due date, the surcharge payable, shall be calculated and
additional amount payable shall be collected along with the normal billed amount.10.13All
payments made by the consumer will be adjusted in the following order of priority :(a)Electricity
Duty and Cess on the current consumption(b)Arrears of Electricity Duty plus arrears of Cess, if
any(c)Delayed payment surcharge(d)Balance of arrears, if any(e)Current bill
amount10.14Instalment facilities : The licensee will lay down a policy for grant of instalment facility
for the purpose of recover) of dues subject to the approval of the Commission. The said policy shall
also designate the officer(s) authorized to grant instalment facility.10.15Disputed/Erroneous Bills
(a) In the event of any objection to the billed amount, the consumer may lodge a complaint before
the designated officer as mentioned in the energy bill. The supply of electricity shall not be cut off if
such person deposits, under protest,(i)an amount equal to the sum claimed from him, or(ii)the
electricity charges due from him for each month calculated on the basis of average charge for
electricity paid by him during the preceding six months,whichever is less, pending disposal of any
dispute between him and the licensee.(b)A complaint may be lodged with the designated officer in
the complaint form available at the licensee's complaint receiving office. In case such form is not
available in the office, complaint may be lodged on plain paper along with the following details
:(i)Name and address of the consumer along with telephone number, if any(ii)Service connection
number(iii)Category of connection(iv)Complaint in briefThe designated officer shall resolve the
dispute within a maximum period of seven days from the date of receipt of written complaint and
shall send a report to the officer in charge of the division giving reasons for the discrepancy if
any.(c)If on investigation, the licensee finds the bill to be erroneous, a revised corrected bill shall be
furnished to the consumer indicating the revised due date not less than seven days of the date of
delivery of revised bill. Excess amount paid by the consumer, if any, shall be adjusted in the
subsequent bill(s).(d)In case it is established that the meter reading recorded was incorrect,
responsibility may be fixed and the licensee may take suitable action against the erring
employee.(e)In the event it is established that the original bill was correct, the consumer shall be
informed accordingly and notified to pay the balance, if any, with surcharge as applicable within 7
days.(f)In case the consumer is not satisfied with the decision on the dispute, he may take furtherChhattisgarh State Electricity Supply Code, 2005

action as provided in the Guidelines for Redressal of Consumer Grievance.10.16In case of death of a
consumer, the legal heir shall be liable to pay the dues of such consumer. The legal heir should also
lake steps to get the connection changed in his name within a period of three
months.10.17Disconnection It shall be the responsibility of the licensee to ensure that no default in
payment is continued beyond a reasonable period subject to a maximum of three months without
action for temporary disconnection. The authorised official of the licensee will ensure that all the
cases pertaining to default in payment are monitored regularly and timely action is initiated as per
prescribed procedure for temporary or permanent disconnection.10.18If a consumer fails in
payment of any bill in full, without the approval of the authorised officer, by the due date, the service
connection of the consumer will be liable to be disconnected on temporary basis. Before
disconnection of a consumer's installation, the licensee would serve a written notice of fifteen clear
days. Effort should be made that before disconnecting a domestic connection; an adult member of
the family should be informed. If the proof of removal of the cause for disconnection is produced to
the satisfaction of the Licensee's employee deputed for the purpose, the supply shall not be
disconnected. In this regard, the licensee shall strictly follow provisions of section 56 of the
Act.10.19No sum due from any consumer shall be recoverable after the period of two years from the
date when such sum became first due unless such sum has been shown continuously as recoverable
as arrear of charges for electricity supplied and the licensee shall not cut off the supply of the
electricity.10.20After temporary disconnection, the supply shall be restored only after the consumer
pays the outstanding charges/dues/amount of instalment fixed along with
disconnection-reconnection charges.10.21A consumer shall be required to make a written request to
the office of the licensee if the consumer wishes to get his connection temporarily disconnected for a
period upto six months. For duration of temporary disconnection the consumer shall be liable to pay
in advance all the monthly charges that are fixed in nature like demand charge, minimum charge,
meter rent etc. The consumer shall also be liable to pay disconnection/reconnection charges to avail
the facility of temporary disconnection. T he period of 'disconnection on request' can be extended on
receipt of a request in writing and on necessary charges being deposited in advance.
Chapter 11
Prejudicial use of Supply
11. [1 [Substituted by Notification No. 19/CSERC/2007, dated 16.4.2007.]
The licensee shall take all necessary measures to prevent theft or unauthorized use of electricity or
tempering, distress or damage to electrical plants, electric lines, equipments or meters.11.2The
consumer shall not make such use of supply given to him by the licensee which is prejudicial to the
interest of the licensee.(A)Unauthorised use of electricity:11.3Section 126 of the Act deals with
assessment of unauthorized use of electricity. The Chhattishgarh State Electricity Rules, 2006 as
notified by the State Government on 22-3-06 (Rules, for short) contain elaborate provisions to deal
with such cases. The provisions of these Rules are to be followed by all concerned.11.4Unauthorized
use of electricity shall mean the usage of electricity(i)by any artificial means; or(ii)by a means not
authorised by the concerned person or authority or licensee; or(iii)through a tampered meter ;
or(iv)for a purpose other than for which the usage of electricity has been authorized; or(v)by use ofChhattisgarh State Electricity Supply Code, 2005

phase-splitting device to facilitate working of three-phase motors/appliances during the period of
single phase supply; or(vi)through increase in connected load by LT consumers in excess of the load
as per the agreement. This, however, will not be applicable to domestic consumers; or(vii)extension
of power supply beyond the area of use as authorised in the agreement; or(viii)shifting of location of
meter; or(ix)unauthorized alterations in electrical installations; or(x)disconnection of neutral;
or(xi)through a meter or equipment associated with metering, which has been accidentally
damaged.11.5If on inspection of any place or premises, the licensee comes to the conclusion that any
perse i is indulging in unauthorized use of electricity in that place or premises, the licensee may
disconnect supply of electricity to such person forthwith. Intimation for such action shall be sent to
the person within 24 hours of such disconnection, as per the procedure laid down in the
Rules.11.6The assessing/authorised officer shall prepare the bill for unathorized use of electricity,
presuming that such unauthorised use continued for a period of three months immediately
preceding the date of inspection in case of domestic and agricultural connections, and for a period of
six months immediately preceding the date of inspection in case of all other categories of
connections, unless proof is produced to the contrary by the person accused of unauthorized use.In
cases where the period of connection is less than the period as mentioned above, the period for
assessment will be from the date of connection till the date of inspection.However, in case an
electronic meter is installed in the premises, data shall be analyzed to ascertain the exact period
during which unauthorised use of electricity continued and such period shall be taken for
assessment purposes.11.7Assessment shall be made at a rate equal to one-and-half times (1 */2
times) the tariff applicable for the relevant category.11.8The methodology for assessment of
consumption by way of unauthorised use of electricity shall be as follows :(a)In respect of LT
consumers :Units assessed per month = L x D x H, where L is load found connected at the time of
inspection in KW;D is number of days per month which shall be taken as 30, during which
unauthorised use of electricity is suspected; andH is hours per day, which shall be taken as 8 hours
for all consumers except industrial consumers in respect of whom the hours of use shall be as per
the hours the industry generally operates in a day which in any case shall not be less than 8
hours.(b)In respect of HT consumers :Assessment shall be based on the data obtained from the
electronic meter through MRI and shall be the average consumption for three months prior to the
date from which unauthorised use has commenced. In the absence of MRI data the normal
consumption pattern of the consumer as that of similar industries may be taken for the purpose of
billing.11.9The order or provisional assessment shall be served upon the person in occupation or
possession or in charge of the place or premises within a period of 3 days from the date of inspection
in the manner as prescribed in the Rules by registered post or by hand and the acknowledgment
shall be obtained :Provided that if the amount of provisional assessment is accepted and the
assessed amount is deposited within seven days of service of provisional bill, such person shall not
be subjected to any further liability or any action by any authority whatsoever.11.10The licensee
shall reconnect the supply on receipt of full amount of provisional assessment. The licensee may also
reconnect the supply on receipt of one-third of the provisional assessment amount pending final
assessment as per clause 11.12 below.11.11Any person, who has been served notice under clause 11.9.
may file objections, if any, within 7 days from the date of receipt of the provisional bill, to the
assessing officer, as designated by the State Government in the Rules, who may, after affording a
reasonable opportunity of hearing to such person, pass final order of assessment of electricity
charges within one month of the date of the provisional assessment.11.12Any person aggrieved byChhattisgarh State Electricity Supply Code, 2005

the final order may prefer an appeal within 30 days of the final order to an appellate authority as
designated by the State Government in the Rules, provided that one-third of the assessed amount is
deposited with the licensee and documentary evidence of such deposit has been enclosed with the
appeal.11.13The form of appeal and the manner in which the appeal may be filed shall be as per the
CSERC (Procedure for Filing Appeal Before the Appellate Authority) Regulations, 2005 notified on
5-12-05 by the Commission, as amended from time to time.11.14The order of the appellate authority
shall be final.11.15When a person defaults in making payment of assessed amount, he shall be liable
to pay, in addition to the assessed amount, on the expiry of thirty days from the date of order of
assessment, an amount of interest at the rate of sixteen percent per annum compounded every six
months as provided in Section 127 (6) of the Act.(B)Theft of Electricity11.16Section 135 of the Act
deals with theft of electricity. The State Electricity Rules contain detailed provision to deal with theft
cases, which have to be strictly followed by all concerned.11.17Whoever, dishonestlya. taps, makes or
causes to be made any connection with overhead underground or underwater lines or cables, or
service wires or service facilities of a licensee; orb. tampers a meter, installs or uses a tampered
meter, current reversing transformer, loop connection or any other device or method, which
interferes with accurate or proper registration, calibration or metering of electric current or
otherwise results in a manner whereby electricity is stolen or wasted; orc. damages or destroys an
electric meter, apparatus, equipment, or wire or causes or allows any of them to be so damaged or
destroyed as to interfere with proper or accurate metering of electricity, so as to abstract or consume
or use electricity, shall be punishable under the provisions of Section 135 of the Act and the
Rules.11.18Entry, search and seizure for the purpose of detection of theft as per subsection (2) of
Section 135 of the Act shall be undertaken by an officer authorised by the State Government in the
Rules and such entry, search and seizure shall be carried out as per the procedure laid down
therein.11.19In case theft of electricity is detected in the premises which do not have regular
electricity connection, the licensee shall forthwith disconnect the supply to such premises and shall
remove the cause of theft immediately by removing the line/cable/plant or illegal meter up to the
distribution main and other apparatus which are found being used for the purposes of theft of
electricity as per the provisions of the Act and the procedure laid down in the Rules. The licensee
may subsequently remove or divert or convert the line, cable or electrical plant to prevent further
theft of electricity provided that such action shall not result in any inconvenience or disruption of
supply to other consumers.11.20In case where the person has a regular electricity connection from
the licensee and where the theft of electr'city is detected by bypassing the meter or metering
equipment and the electrical load, fully or partially, or the connection is found connected directly
with the lines, cables or electrical plant; or the meter is found tampered with a dishonest intention,
the electric supply to such premises shall be disconnected forthwith by the licensee.11.21Where it is
established that there is a case of theft of energy, the officer authorised in this behalf by the State
Government in the Rules shall prepare the bill of theft of electricity as provided in Section 154 (5) of
the Act, pending adjudication by the special court, as per the Electricity (Removal of Difficulties)
Order dated 8-6-05 [S.O. 790 (E)].11.22The assessment shall be an amount equivalent to
two-and-half times the rates as per applicable tariff for the relevant category for a period of twelve
months preceding the date of detection of theft of energy or the exact period of theft if determined,
whichever is less. A bill shall be served upon on the person under proper receipt.11.23The
methodology for assessment of consumption due to theft of electricity shall be as follows :(a)In
respect of LT consumers :Units assessed per month = L x D x H, where L is load found connected atChhattisgarh State Electricity Supply Code, 2005

the time of inspection in KW;D is number of days per month which shall be taken as 30, during
which unauthorised use of electricity is suspected; andH is hours per day, which shall be taken as 8
hours for all consumers except industrial consumers in respect of whom the hours of use shall be as
per the hours the industry generally operates in a day which in any case shall not be less than 8
hours.(b)In respect of HT consumers:Assessment shall be based on the data obtained from the
electronic meter through MRI and shall be the average consumption for three months prior to the
date from which unauthorised use has commenced. In the absence of MRI data the normal
consumption pattern of the consumer as that of similar industries may be taken for the purpose of
billing.11.24In making such assessment the authorized officer shall also take into account the
representation of the person submitted within 48 hours of the detection of theft or any other
evidence he considers relevant. The authorized officer shall record reasons for the assessment made.
Charges, if any, paid by the person during the period for which the assessment is done, shall be duly
credited if necessary, to avoid duplication of billing for such period.11.25The authorized officer shall
serve an order for charges against the theft of electricity committed by the person within 3 (three)
days in the manner as provided in the Rules and the person shaii make payment within 30
days.11.26The supply shall be restored to the consumer within 48 hours after removal of the cause of
theft, provided that the assessed amount is deposited in full. The licensee shall take all measures to
avoid recurrence of theft in the same premises before restoration of supply.11.27The above action
shall be without prejudice to the filing criminal proceedings by the licensee in the special court
constituted under chapter XV of the Act against the person involved in theft of
electricity.Compounding of offences11.28Compounding of offences shall be as per the provision of
Section 152 of the Act. In compounding offences the authorised officer shall act in accordance with
the procedure laid down in the Rules.11.29A person or consumer in custody, in connection with the
offence of theft of electricity, shall be set at liberty on payment of sum of money in accordance with
the Sub-Section (1) of Section 152 of the Act or the amount as may be specified by the-State
Government from time to time. No proceeding shall be instituted or continued against such
consumer or person in any criminal court as per Section 152 (2) of the Act.11.30The compounding of
an offence under Section 152 of the Act shall be allowed only once for any person or
consumer.(C)Prevention measures11.31The Electricity (Removal of Difficulties) Order 2005 [S. O.
790 (E) dated 8th June, 2005] notified by Ministry of Power, Govt, of India mandates adoption of
measures to control theft.11.32In order to reduce and prevent diversion, theft or unauthorized use of
electricity or tampering, distress or damage to electrical plant, electric lines or meter, necessary
preventive measures shall be taken by the distribution licensee.11.33The licensee shall arrange to
provide tamper proof meter boxes on meters of at least 20% connections every year so as to ensure
that within next 5 years meters installed at all the premises have tamper proof meter boxes. The
licensee shall simultaneously review the status of the service lines to ensure that it is proper and
wherever required, it should be replaced to prevent theft/bypassing of meter.11.34The licensee shall
undertake regular inspection of premises of consumers and keep up necessary vigilance to ensure
prevention of theft or unauthorized used of electricity or tampering, distress or damage to electrical
plant, electric lines or meter.Priority shall be given in inspection/vigilance to theft-prone
areas.11.35The licensee shall evolve a system and put in place such a system within 6 months, for
regular monthly monitoring of consumption of high value consumers, which shall include all the HT
connections and LT connections having contract demand/connected load of 25 HP and above. Wide
variations in consumption hall be carefully analyzed. The licensee shall arrange prompt inspectionChhattisgarh State Electricity Supply Code, 2005

in doubtful cases.11.36The licensee shall arrange to ensure that 33 KV & 11 KV feeder-wise losses are
worked out for identified cities and district headquarter towns of the State in phases and thereafter
for other areas. The licensee shall take suitable steps for reduction of losses in the pockets of high
loss identified by working out losses in the above manner.11.37The licensee shall install meters on
all distribution transformers and carry out energy audit so as to identify high loss pockets and take
further suitable action for reduction of losses in such pockets.11.38The licensee shall endeavour to
install remote metering devices on all HT connections on priority for the purpose of monitoring of
consumption and prevention of theft of electricity. The licensee shall further endeavour to install
remote metering devices on high value LT connection.11.39The licensee shall arrange to give due
publicity through the media, TV and newspapers to bring awareness about the level of commercial
losses, its implications on honest consumers and seek their co-operation in prevention and
detection of theft or unauthorized use of electricity or tampering, distress or damage to electrical
plant, electric lines or meter. The licensee shall also install display boards containing the
information about the above at its consumer service related offices.11.40The licensee may, as early
as possible, arrange to suitably display in its website region wise, circle wise, devision wise,
sub-station wise and feeder wise losses, efforts made for prevention of diversion of electricity, theft
or unathorized use of electricity or tampering, distress or damage to electrical plant, electric lines or
meter and results obtained. The website may be updated every quarter.11.41The licensee shall
arrange to provide requisite security force to the authorised officers for their safety. Such security
squads shall invariably accompany the authorised officers during raids in order to ensure their
safety.11.42The licensee may replace overhead bare conductors with cables in theft-prone areas to
prevent theft by direct hooking of the licensees lines.11.43The licensee shall provide HV
distribution system (LT less system) in theft-prone areas using small capacity distribution
transformer, wherever necessary.11.44The licensee is authorized to relocate the meters of existing
consumers to an appropriate location so that it is clearly visible and reading can be taken 4 from
outside the premises but within the boundary wall and easily accessible for reading, inspection,
testing and other related works. In case of doubtful cases where continuous vigil is not possible, the
licensee may install check meters on its poles/feeder pillars. In case of repeated theft of electricity
the licensee may install billing meters for such connections on iis poles/feeder
pillars.11.45Expenditure on account of prevention of theft shall be a pass-through in the ARR of the
licensee in determination of tariff.11.46A list of cases where theft of electricity has been detected
shall be maintained by the licensee. The licensee shall also maintain list of cases to clearly identify
where second offence and subsequent offence (s) of theft have been detected and take action as per
ti e provisions of the Act.]
Chapter 12
Miscellaneous
12.Chhattisgarh State Electricity Supply Code, 2005

1. Force Majeure.
- The licensee or the consumer shall not be liable for any claim for loss, damage or compensation
whatsoever arising out of failure of supply when such failure of supply is due, either directly or
indirectly, to war, mutiny, civil commotion, riot, terrorist attack, flood, fire, strike (subject to
certification by Labour Commissioner), lockout (subject to certification by Labour Commissioner),
cyclone, tempest, lightning, earthquake or any act of God.12.2If at any time during the continuance
of the agreement between the licensee and the consumer, the plant or premises of the consumer is
destroyed or damaged due to force majeure conditions mentioned in clause 12.1. rendering the plant
or premises wholly or substantially unfit for occupation or use. the consumer may. on giving 7 days
notice in writing to the licensee, about such a situation, take a reduced supply of power as may be
necessary and feasible. In all cases where the consumer claims Force majeure conditions, the
licensee's authorised representative shall verify the same. Such a facility shall be available to the
consumer only if the period of reduced supply is for a minimum period of 60 days and upto a
maximum of six months. The aforesaid period of reduced supply shall not be counted towards the
initial period specified in the agreement and the period of agreement shall be extended for a further
period equal to the period of reduced supply.12.3In case the licensee is unable to supply power to a
consumer who is not otherwise a defaulter, disconnected or unconnected, for a period of 10 days
(each day shall consist of power cut from 00 hours to 24 hours) or more in a calendar month, the
licensee shall levy charges on the consumer in the following manner.(a)Energy charges shall be on
the basis of actual meter reading recorded in the energy meter.(b)Other charges (excluding
electricity duty and cess) shall be prorated on the basis of the number of days power was provided to
the consumer.This facility will be provided to consumers with metered connections
only.12.4Tampering, distress or damage to electrical plant, lines or meter If the electrical plant, lines
or meter or any other equipment, of the licensee placed in the consumer premises is found
tampered, distressed/damaged, the licensee shall be entitled to recover the expenses incurred for
restoration of such plant, line, meter or equipment, without prejudice to his right to take action
under appropriate provisions of the Act, including disconnection of supply for non-payment of the
cost for replacement/rectification, and action for theft or assessment for unauthorized use, as the
case may be.12.5Authorisation of Franchisees A licensee may authorise a franchisee to distribute
electricity on its behalf in a particular area within the former's area of supply as per the provisions of
the Act.12.6Other Codes and Regulations Consumers shall ensure that new buildings, structures,
additions, modifications and any other construction projects keep the minimum clearances required
from existing supply lines of the licensee. These minimum clearances are specified in the Indian
Electricity Rules, 1956 [***] [Deleted 'and Distribution Code and Safety Code as may be notified by
the Commission' by Notification No. 19/CSERC/2007, dated 16.4.2007.].12.7Service of Notice Any
letter, order or document addressed by the licensee to the consumer shall be deemed to be duly
given, if served in writing and delivered by hand at, or sent by post/courier, to the address specified
in the consumer's application or in the agreement with the consumer if entered into or as
subsequently notified to the licensee. In case there is no person on the premises to whom the notice
can with reasonable diligence be delivered, the notice may be served by affixing it on some
conspicuous part of the premises.12.8The licensee may serve any general notice like message
regarding load regulatory measures, applicability of new tariff or change in due date of payment etc.
in a widely circulated local newspaper.12.9All communications to the licensee shall be addressed toChhattisgarh State Electricity Supply Code, 2005

:(a)The Secretary of licensee's Company at the Corporate Office of the licensee or to any other officer
authorised or designated in this behalf in case of H.T. consumers.(b)The licensee's Executive
Engineer or person holding an equivalent post of the area or his authorised representative in the
case of L.T. consumers.12.10Unforeseen Circumstances If any circumstances not envisaged in the
provisions of the Electricity Supply Code, should arise, the licensee shall, to the extent reasonably
practicable in the circumstances, consult promptly and in good faith all affected parties in an effort
to reach an agreement as to what should be done. If an agreement between the licensee and those
parties cannot be reached in the time available, the licensee shall determine it in the manner best to
its ability.12.11Wherever the licensee makes such a determination, it shall do so having regard
wherever possible, to the views expressed by the affected parties and, in any event, to what is
reasonable in the circumstances. Each party shall comply with all instructions given to it by the
licensee following such a determination, provided that the instructions are 'consistent with the
prevailing Codes and Regulations. The licensee shall promptly refer all such unforeseen
circumstances, and any such determination to the Commission.12.12Interpretation : These
conditions shall be read and construed as being subject, in all respects, to the provisions of the
Electricity Act, 2003, the Indian Electricity Rules, 1956 and as amended from lime to time and the
Rules made therein and to the provisions of any other law relating to the supply of electricity for the
time being in force; and nothing contained in this Code shall abridge or prejudice the rights of the
licensee and the consumer under any Central Act or State Act or Rules made thereunder.12.13In
case of any dispute regarding the meaning or scope or interpretation of this Code, the interpretation
of the Commission shall be final and binding on all concerned.12.14With the issue of this Supply
Code, the "General conditions for Supply of Electrical Energy and Scale of Miscellaneous and
General Charges" issued by erstwhile M.P. Electricity Board/Chhattisgarh State Electricity Board,
shall cease to operate from the date of its publication in the Chhattisgarh Rajpatra.12.15Power to
remove difficulties : If any difficult) arises in giving effect to any of the provisions of this Code. the
matter may be referred to the Commission who after consulting the parties affected, where
considered necessary, may pass any general or special order, not inconsistent with the provisions of
the Act or any other enactment relating to supply of electricity for the time being in force, which
appears necessary or expedient, for the purpose of removing the difficulty.12.16Jurisdiction of Court
: All proceedings arising out of this Code and the agreement made thereunder shall be filed only in
the Court under whose jurisdiction the agreement was executed.12.17Savings Nothing in this Code
shall be deemed to limit or otherwise affect the inherent power of the Commission to make such
orders as may be necessary to meet the ends of justice or to prevent abuses of the process of the
Commission.12.18Nothing in this Code shall bar the Commission from adopting in conformity with
the provisions of the Act, a procedure, which is at variance with any of the provisions of this Code, if
the Commission, in view of the special circumstances of a matter or class of matters and for reasons
to be recorded in writing, deems it necessary or expedient for dealing with such a matter or class of
matters.12.19Nothing in this Code shall, expressly or implidely, bar the Commission dealing with
any matter or exercising any power under the Act for which no Codes have been framed, and the
Commission may deal with such matters, powers and functions in a manner it thinks fit.Note. - In
case of any difference in the interpretation or understanding of the provisions of the Hindi version
of this Supply Code with that of the English version (the original version), the latter will prevail and
in case of any dispute in this regard, the decision of the Commission shall be final and
binding.AnnexureThe licensee is authorised to modify the structure of the formats provided in thisChhattisgarh State Electricity Supply Code, 2005

annexure in order to meet any requirement that may arise as a consequence of the provisions of this
Code so that the formats are consistent with prevailing Rules, Regulations and the provisions of this
Code.Annexure 1Application form - Low Tension Service ConnectionNew Connection/Shifting of
Premises/Change in Contract Demand/Change of Tariff Category/Change of Name of
Consumer(Please strike-off the purpose that is not applicable)To,..........................................Sir,I/We
request you to supply electricity to my/our premises. The requisite information is furnished below :
1. Consumer
(a)Name of the person/organization : ............................................(b)Name of
father/husband/Director/Partner/Trustee : ............................(c)Category :
General/SC/ST/OBC/Others(Please strike-off category not applicable and tick the category
applicable)(d)Address of the premises where a new connection is hereby applied for/the existing
connection is proposed to be shifted :
Premise No. :..............................................................................
Street :..............................................................................
Area/Colony :..............................................................................
Town :.............................................................................
District :.............................................................................
PIN :..............................................................................
Telephone No. :..............................................................................
E-mail :..............................................................................
Bank A/C No. (optional) :.............................................................................
2. Nearest Pole Number from where connection is expected : ..........................
3. Built-up area of the premises/plot area : ................................sq. feet
4. Category of supply : .............................................................
(Categories as provided in the list attached)
5. Purpose of supply : ..............................................................
(Sub-categories as provided in the list attached)
6. Type of supply : Permanent/Temporary
(Please strike-off type not applicable and tick the type applicable)If temporary specify period - From
: ....................... To :....................Chhattisgarh State Electricity Supply Code, 2005

7. Proposed Connected Load
(a)For domestic connection : ............................................... WattsPlease fill-up and attach format for
determination of connected load.(b)For other categories please fill up the following (Attach duly
signed separate list if required)
Item Load per item (Watts) No. Total load (Watts)
    
    
    
    
    
    
    
    
8. Distance from the nearest distribution mains to the expected point of
connection:.............................................................................Meters
(The above information provided by the consumer will only be treated as indicative. During
feasibility study the licensee will determine the point of distribution mains and the route through
which the cable/service connection will be drawn)
9. Any electricity dues outstanding in licensee's area of operation in
consumer's name: Yes/No.
10. Any electricity dues outstanding for the premises for which connection
applied for: Yes/No.
11. Any electricity dues outstanding with the licensee against any firm with
which the consumer is associated as an Owner, Partner, Director or
Managing Director: Yes/No.
(For serials 9, 10 & 11 if the answer is 'Yes' in any case please provide details)
12. I/We hereby declare that
(a)The information provided in this application is true to my knowledge.(b)I/We have read the
Chhattisgarh Electricity Supply Code and agree to abide by the conditions mentioned
therein.(c)I/We will deposit electricity dues, every month, as per the applicable electricity tariff and
other charges.(d)I/We will own the responsibility of security and safety of the meter, cut-out and theChhattisgarh State Electricity Supply Code, 2005

installation thereafter.
Date : Signature of the consumer/Authorised Signatory
Place : Name.....................................................................
 Designation (ifany)..............................................
Note. - The following documents shall be attached with the application form
1. Proof of legal occupation of the premises alongwith the copy map of the
premises/land, indicating proposed point of supply, duly approved by the
local authority. In case of street lights the location of street light poles shall
be indicated in the map.
2. Approval/permission of the local authority, if required under any
law/statute.
3. In case of partnership firm, partnership deed.
4. In case of a Limited Company, Memorandum and Articles of Association
and Certificate of Incorporation.
5. In case of industries, copy of certificate of registration with Industries
Department.
6. Proof of permanent residential address the consumer and PAN Number, if
any. If there is any change at a later date, the same shall be intimated by the
consumer to the Licensee immediately.
7. In case of industries permission of Environment Conservation Department.
[Acknowledgment] [Added by Notification No. 19/CSERC/2007, dated 16.4.2007.](To be given to
the applicant)Application form received from................on...................(date) has beenentered in the
Register at No.........in the licensees office situated at.......Signature of the authorised Official of the
licenseewith Name, Seal and DateNote. - In case of any difference in the interpretation or
understanding of the provisions of the Hindi version of these Regulations with those of the English
version (the original version), the later will prevail and in case of any dispute in this regard, the
decision of the Commission shall be final.Annexure 2Application form - High Tension/EHT Service
ConnectionNew Connection/Shifting of Premises/Change in Contract Demand/Change of Tariff
Category/Change of Name of Consumer(Please strike-off the purpose that is not
applicable)To,.....................................................................Sir,I/We request you to supply electricity to
my/our premises. The requisite information is furnished below :Chhattisgarh State Electricity Supply Code, 2005

1. Consumer
(a)Name of the person/organization : .............................................(b)Name of
father/husband/Director/Partner/Trustee : ............................(c)Full Address of the premises where
a new connection is hereby applied for/the existing connection is proposed to be shifted :
................................................................................................................................Pin :
...............Telephone No.:Factory/Premises: ...............Registered Office: ..............Residence:
...................E-mail: .......................................Bank A/C No. (optional): .............................
2. Voltage at which supply is required (kV):
11 kV 33 kV 132 kV 220 kV
(Please strike-off category not applicable and tick the category applicable)
3. Type of supply : Permanent/Temporary
(Please strike-off type not applicable and tick the type applicable)If temporary , specify period -
From :............................ To..............:.............
4. Steps taken by the consumer so far to set-up the installation
(a).............................................................................(b).............................................................................(c).............................................................................(d).............................................................................
5. Basis of projection of Contract Demand required
(a)Diversity factor assumed: ..................................................(b)Total Connected Load:
......................................................
6. Phasing of contract demand (CD):
Sl. No. CD required (kVA) Tentative Date from which required Remarks
    
    
    
    
7. Purpose of installation : ...................................
8. Category of tariff opted for : ............................................Chhattisgarh State Electricity Supply Code, 2005

9. Production capacity : ............................................
10. Category of Industry : SSI/MSI/LSI
(Please strike-off category not applicable and tick the category applicable)
11. Status of land acquisition : .............................................
12. Expected date by which finance would be available : ..................................
13. Whether the requisite consent/NOC (where applicable according to the
list of Pollution Control Board) has been obtained from C.G. Environment
Conservation Board, Raipur as per statutory requirements (If yes, a copy
should be furnished) : ...........................................
14. Any electricity dues outstanding in licensee's area of operation in the
consumer's name : Yes/No.
15. Any electricity dues outstanding for the premises for which connection
applied for: Yes/No.
16. Any electricity dues outstanding with the licensee against any firm with
which the consumer is associated with any firm as an Owner, Partner,
Director or Managing Director: Yes/No
(for serial 15, 16 & 17 if answer is 'Yes' in any case please provide details)
17. I/We hereby declare that :
(a)The information provided in the form above is true to my knowledge.(b)I/We have read the
Chhattisgarh Electricity Supply Code and agree to abide by the conditions mentioned
therein.(c)I/We will deposit electricity dues, every month, as per the applicable electricity tariff and
other charges.(d)I/We will own the responsibility of security and safety of the meter, cut-out and the
installation thereafter.Signature of the consumer/authorised signatoryDate
:................Place:................Note. - The following documents shall be attached with the application
form
1. Proof of ownership of the premises.Chhattisgarh State Electricity Supply Code, 2005

2. A map indicating therein the proposed location of the plant/office and the
point where supply is required. The map should normally be of the scale of
1cm representing 1200cm.
3. Licence/NOC from statutory authority, if required or a declaration by the
applicant that his connection does not fall under the requirement of NOC
under any statute.
4. In case of a proprietary firm, an affidavit to be submitted slating that the
applicant is the sole proprietor of the firm.
5. In case of partnership firm, partnership deed.
6. In case of Limited Company, Memorandum and Articles of Association and
Certificate of Incorporation.
7. Proof of permanent residential address of the consumer and PAN Number,
if any. If there is any change at a later date, the same shall be intimated by
the consumer to the Licensee immediately.
8. Letter of intent for production/enhancement in production may be
furnished.
9. List of equipments proposed to be installed along with the expected load.
10. Resolution for authorised signatory.
11. Registration from Industries Department.
12. Extract of project report relevant to power and process requirements (in
case of industries).
13. Copy of the relevant section of the current tariff order that provides
details of the tariff category opted by the consumer and duly signed by him.
This will be appended with the agreement after completion of formalities.
[Acknowledgment] [Added by Notification No. 19/CSERC/2007, dated 16.4.2007.](To be given to
the applicant)Application form received from................on...................(date) has beenentered in the
Register at No.........in the licensees office situated at.......Signature of the authorised Official of theChhattisgarh State Electricity Supply Code, 2005

licenseewith Name, Seal and DateNote. - In case of any difference in the interpretation or
understanding of the provisions of the Hindi version of these Regulations with those of the English
version (the original version), the later will prevail and in case of any dispute in this regard, the
decision of the Commission shall be final.Annexure 3Determination of Connected LoadDomestic
Connection
1. Name of the consumer : ........................................................
2. Address : ......................................................................
3. Consumer Number (for existing connections) :
.......................................................
4. Electrical equipments proposed to be put to use :(Please fill-up the
following table to enable determination of the connected load. Normally the
actual load of each item will he considered to determine the connected load
at the premises. In case of non-availability of the rated capacity of any item,
the load shown he low shall he considered.)
Item Load per item (Watts) No. Total load (Watts)
1 2 3 4 = 2 x 3
Bulb 60   
Tube light 50   
Fan 60   
Tape-recorder/Music system 100   
Television 90   
Mixer/Grinder 375   
Electronic iron 750   
Fridge 150   
Cooler 250   
Heater (for cooking and water heating) 1000   
Washing machine 750   
Geyser 2000   
Microwave oven 2000   
Air Conditioner (1 ton) 1500   
Air Conditioner (1.5 Ton) 2250   
Computer 100   
Printer 150   
Pump-set 375   Chhattisgarh State Electricity Supply Code, 2005

    
 Total  
(a)Spare socket points/holders shall not be counted towards connected load.(b)In some domestic
connections Geyser, Room Heater and Air-conditioner (without heater) are installed. If both
Geyser(s) and Room Heater(s) are present, the load of these two types of items shall be added and
compared with the load of air-conditioner(s). The higher load between the two (that is load of
Geyser(s) plus Room Heater(s) vis-a-vis load of Air-conditioner(s)) shall be considered for
determination of connected load.
Signature of the Consumer Signature of the licensee's representative
Date :.......................... Date:........................................................
Place :........................... Place:......................................................
Annexure 4Test ReportTo be filled up by licensed Electrical Contractor
Book No.____________ Form No._______________
To be filled up by the licenseeThis is being issued for providing electrical connection at the premises
of Mr./Mrs./ Ms._______________________________. The address of the premises is
_________________________ The name and address of the licensed electrical contractor is
____________________________ The date of issue of this report
is___________________________To be filled up by the licensed electrical contractor
5. I hereby declare that -
(a)I have _________________________class license valid
till_____________________________ The license number
is________________________(b)I have completed this work for Mr./Mrs./Ms.
___________________________________ for his
_________________________________________Details of Job
Sl. No. Item 220/230 Volts 440/400 Volts
Red Phase Green Phase Blue Phase No. Total Watts
No. Total Watts No. Total Watts No. Total Watts
1          
2          
3          
4          
5          
6          
7          
(c)(i)The particulars of the employees who executed the job are tabulated below.
Sl. No. Name of the Wireman/Trainee Designation Period
   From ToChhattisgarh State Electricity Supply Code, 2005

     
     
     
     
     
     
(ii)The work was carried out under the supervision of____________________________
(Supervisor Wireman) whose certificate number is________________________. He is
responsible for work carried out during the period_______________________.(d)This
installation specifications adhere to all the provisions of Indian Electricity Rules, 1956.
6. I also declare/certify the following :
(a)The installed switches are of correct ratings : Yes/No
(b)All the switches and wiring are permanent and ofcorrect specifications Yes/No
(c)All plugs are of three pin type and controlledby separate switches Yes/No
(d)All the Single Pole switches connected to thephase Yes/No
(e)Required permanent mark is provided on the mainswitch board for Neutral point Yes/No
(f)Arrangement for earthing is according to Rule 61of Indian Electricity Rules, 1956 Yes/No
(g)In case of three phase installation Yes/No
 (i) Danger board, fire extinguisher withbuckets, shock chart and first aid kit have been
provided forYes/No
 (ii) The installation specifications of theswitch board is as per Rule 15 of Indian
Electricity Rules, 1956Yes/No
7. Test results
 Date of testing__________________
 Insulation of Earth Insulation between conductors
Phase 1   
Phase 2   
Phase 3   
Earth Resistance Date of testing
  
Electrode No. 1 Electrode No. 2
  Chhattisgarh State Electricity Supply Code, 2005

8. The date of registration according to Form 'L' of Madhya Pradesh
Licensing Board (Electricity) is as follows :
Sl. No. ...............Date..................Signature of the Licensed Electrical ContractorCertificate from
Supervisor wiremanIt is hereby certified that the aforesaid work has been undertaken by
.............................. who has a wireman permit number of...................that is valid till......It is also
certified that testing of the installation has been undertaken by ..................who has a permit number
of.............that is valid till...
Signature of the wireman Signature ofSupervisor, wireman
ReceiptThe test report form number........................ for the installation at the premises of
.................prepared by...............has been received on.......Signature of Officer in
ChargeNameDesignationDateChhattisgarh State Electricity Supply Code, 2005

