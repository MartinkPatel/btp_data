Accused X vs The State Of Maharashtra on 12 April, 2019
Equivalent citations: AIR 2019 SUPREME COURT 3031, AIRONLINE 2019 SC
2222, 2019 CRI LJ 4147, (2019) 108 ALLCRIC 259, (2019) 199 ALLINDCAS 223,
(2019) 2 ALD(CRL) 428, (2019) 2 ALLCRILR 949, (2019) 2 BOMCR(CRI) 609,
(2019) 2 CRIMES 175, (2019) 2 KER LJ 704, (2019) 2 KER LT 527, (2019) 2 PAT
LJR 397, 2019 (3) ABR(CRI) 34, (2019) 3 ALLCRIR 2621, 2019 (3) KCCR SN 188
(SC), (2019) 3 RECCRIR 18, 2019 (3) SCC (CRI) 10, (2019) 6 SCALE 407, (2019)
74 OCR 757, 2019 (7) SCC 1, AIR 2019 SC( CRI) 1234
Author: N. V. Ramana
Bench: Mohan M. Shantanagoudar, N.V. Ramana
                                                                   REPORTABLE
                               IN THE SUPREME COURT OF INDIA
                              CRIMINAL APPELLATE JURISDICTION
                          REVIEW PETITION (CRIMINAL) NO. 301 OF 2008
                                              IN
                               CRIMINAL APPEAL NO. 680 OF 2007
           ACCUSED ‘X’                                      …PETITIONER
                                            VERSUS
           STATE OF MAHARASHTRA                              ...RESPONDENT
                                      J U D G M E N T
N. V. RAMANA, J.
1. The instant proceedings pertain to the reopening of Review Petition (Crl.) No. 301 of 2008 to
review the final Judgment and Order dated 16.05.2008 passed by this Court in Criminal Appeal No.
680 of 2007 dismissing the appeal filed by the Review Petitioner (hereinafter “the Petitioner”) and
confirming his conviction under Sections 201, 363, 376 and 302 of the Indian Penal Code (in short,
“the IPC”). Vide the impugned judgment, this Court upheld the sentence of 2 years’ rigorous
imprisonment each under Sections 201 and 363, 10 years’ rigorous imprisonment under Section 376
and the death sentence under Section 302, IPC imposed upon the Petitioner.Accused X vs The State Of Maharashtra on 12 April, 2019

2. This petition raises complex questions concerning the relationship between mental illness and
crime. How can culpability be assessed for sentencing those with mental illness? Is treatment better
suited than punishment? These are some of the questions we need to reflect upon in this case at
hand.
3. In line with Section 23 (1) of the Mental Healthcare Act, 2017, (Act 10 of 2017) and the right to
privacy of the accused herein, while taking further action on this judgment, we direct the Registry to
not disclose the actual name of the accused and other pertinent information which could lead to his
identification as it concerns confidential information. In this context we shall address the accused
herein as ‘accused x’.
4. Brief facts giving rise to the present petition are as follows; the two deceased, viz. victim−1
(studying in the 4 th standard) and victim−2 (studying in the 1st standard) were cousins staying at
Gulumb, Maharashtra, in a locality of homeless people (Beghar Vasti) at the house of Ramdas
Jadhav (PW−13, victim−1’s father). The Petitioner lived in the adjacent house with his family. On
13.12.1999, at about 6 p.m., the Petitioner had gone to the grocery shop run by Sunil (PW−6), with
his daughter, Reshma (PW−8), where he met the two deceased girls, and on the pretext of offering
sweets, he led the girls to accompany him. Thereafter, he committed the rape and murder of both
girls, and threw victim−2’s body in a well situated in the field of the father of Sakharam Bhiku Yadav
(PW−11), and concealed the body of victim−1 in a “kalkache bet” (place where bamboo trees and
shrubs grow together thickly).
5. The Petitioner was apprehended by the villagers on the next day, i.e. 14.12.1999, before whom he
made an extra judicial confession about the murder of victim−2. The same day, he also led the police
to the recovery of the bodies of the deceased as well as the discovery of the spot of commission of
rape, from where bloodstained earth and plants, half−burnt bidis and broken bangles were
recovered. The blood−stained clothes worn by the Petitioner at the time of arrest were also seized.
The clothes of the deceased were recovered at his instance on 25.12.1999. The FIR came to be lodged
by Jaysing Dinkar Jadhav, PW10, the brother of the grandfather of the deceased.
6. The Trial Court in Sessions Case No. 142 of 2000 convicted the Petitioner for the offences stated
supra on the basis of the ‘last seen’ evidence; motive of the accused; seizure of blood−stained clothes
worn by the accused; the Chemical Analysis Report showing that “A” group blood was found on the
shirt and pant of the Petitioner as well as in his nail clippings, which was the blood group of both the
deceased; recovery of the bodies of the deceased at the instance of the accused; discovery of the spot
of commission of rape of the two deceased wherefrom blood−stained earth and other incriminating
articles were seized; extra−judicial confession of the Petitioner; recovery of frocks at his instance;
and the false explanation given by the Petitioner. The Trial Court found that all these circumstances
formed a complete chain pointing to the guilt of the Petitioner.
7. The High Court in Criminal Appeal No. 652 of 2001 and Confirmation Case No.3 of 2001,
confirmed the conviction and sentence as awarded by the Trial Court, including the sentence of
death, relying upon all the aforementioned circumstances except for the alleged extra−judicial
confession. This Court, in appeal, being Criminal Appeal No. 680 of 2007, confirmed the same,Accused X vs The State Of Maharashtra on 12 April, 2019

holding that the case at hand falls into the category of the rarest of rare cases warranting
punishment with death. Review Petition (Crl.) No. 301 of 2008 filed by the Petitioner against the
above Judgment and Order of this Court was dismissed vide order dated 19.11.2008 by the same
three−Judge Bench which had rendered the Judgment in appeal, who after considering the matter
by way of circulation held that there was no merit in the petition.
8. A criminal miscellaneous petition being Crl. M.P. No. 5584 of 2015 was filed by the Petitioner
seeking reopening of this review petition, placing reliance on the decision of this Court dated
02.09.2014 in W.P. (Crl.) No. 77 of 2014 in Mohd. Arif @ Ashfaq v. The Registrar, Supreme Court of
India, (2014) 9 SCC 737, which held that in light of Article 21 of the Indian Constitution, review
petitions in death sentence cases were required to be heard orally by a three−Judge Bench, and
specifically permitted the reopening of review petitions in all cases where review petitions had been
dismissed by circulation.
9. In light of the above decision, this Court has heard the review petition filed by the Petitioner
orally in the open Court.
10. Learned counsel for the Petitioner, Ms. Nitya Ramakrishnan, did not raise any argument
concerning the merits of the case, however raised only the following two arguments:− firstly, that
the Trial Court had not given the Petitioner a separate hearing while awarding the sentence, in
direct contravention of Section 235(2) of the Code of Criminal Procedure (in short, “CrPC”), which
provides for the right of pre−sentencing hearing as affirmed by this Court in Bachan Singh v. State
of Punjab, (1980) 2 SCC 684 and a plethora of other decisions; and secondly, that the award of the
death sentence to the Petitioner is contrary to the ratio of the three−Judge Bench decision of this
Court in Shatrughan Chauhan v. Union of India, (2014) 3 SCC 1, followed in a four−Judge Bench
decision of this Court in Navneet Kaur v. State (NCT of Delhi), (2014) 7 SCC 264, which held that
the execution of persons suffering from mental illness or insanity violates Article 21 of the Indian
Constitution and that such mental illness or insanity would be a supervening circumstance meriting
commutation of the death sentence to life imprisonment.
11. Learned counsel for the Respondent, i.e. the State of Maharashtra, Mr. Nishant Ramakantrao
Katneshwarkar, on the other hand, highlighted that the pre−sentencing hearing as envisaged under
Section 235(2) of the Cr.P.C need not be conducted on a separate date, and the sentence awarded by
the Trial Court does not stand vitiated merely because the sentence with respect to hearing was not
conducted on a separate date. To that end, the counsel relied on the three−Judge Bench decision of
this Court in Vasanta Sampat Dupare v. State of Maharashtra, (2017) 6 SCC 631. He also submitted
that the Petitioner is not suffering from any mental illness so as to warrant commutation of the
death sentence, and to that effect submitted certain medical reports.
12. On hearing this petition, this Court was of the opinion that there was no merit in the Petitioner’s
submissions against the order of conviction, and it was therefore decided that this Court would hear
only on the aspects of sentencing pertaining to two issues.Accused X vs The State Of Maharashtra on 12 April, 2019

13. The first relates to the implications of non−compliance of Section 235 (2) of CrPC during the
sentencing process before the Trial Court. The second issue concerns the mental illness of ‘accused
x’, which was raised for the first time in this Review Petition, after the judgment of this Court in the
earlier round.
14. On the first issue, the learned counsel on behalf of the Petitioner contended that considering the
fact that the procedural right of Pre−Sentence Hearing, as envisaged under Section 235 (2) of CrPC,
was never provided to the accused, this mandated a fresh hearing before the trial court on the
sentencing aspect. In the instant case before us, the principle argument advanced by the counsel for
the Petitioner was that, since the order of conviction and the order of sentence in the present case
were passed on the same day, no opportunity was awarded to the Petitioner with regard to the
sentence imposed upon him. Therefore, the counsel contended that the order of sentence passed in
the present case is in violation of Section 235 (2) of the CrPC, which is an illegality vitiating the
entire sentence. The counsel vehemently argued that a holistic reading of Section 235 (2) of the
CrPC would indicate that the accused should be given ample opportunity to produce materials in his
favour so as to place on record the mitigating circumstances which mandate the imposition of lesser
penalty.
15. It is pertinent at this point of time to note that countries following the common law tradition,
prosecution historically did not play any part in the sentencing process and that it was mostly left for
the judge to decide. In India, under the old Code, no opportunity was provided, post−conviction, for
the accused to place relevant facts before the court. It was only after the introduction of the present
Code in 1973 that such a hearing was provided for in accordance with modern penological practices.
At this stage it may be necessary to quote Section 235 of CrPC, which provides for Pre−Sentence
Hearing, among other things.
235. Judgment of acquittal or conviction.
… (2) If the accused is convicted, the Judge shall, unless he proceeds in accordance with the
provisions of section 360, hear the accused on the question of sentence, and then pass sentence on
him according to law.
Section 235 (2) of CrPC implies that once the judgment of conviction is pronounced, the Court will
hear the accused on the question of sentence and at that stage, it is open to the accused to produce
such material on record as is available to show the mitigating circumstances in his favor. In other
words, the accused at this stage argues for imposition of lesser sentence based on such mitigating
circumstances as brought to the notice of the Court by him.
16. Section 235 (2) of CrPC mandates Pre−Sentence Hearing for the accused and imbibes a cardinal
principle that the sentence should be based on ‘reliable, comprehensive information relevant to
what the Court seeks to do’. In the case at hand, the accused argues that his right to fair trial stands
extinguished as he was not provided a separate hearing for sentencing. This issue can be resolved
directly by relying on the interpretation of Section 235 (2) of CrPC and this Court’s jurisprudence
built around Pre− Sentence Hearing.Accused X vs The State Of Maharashtra on 12 April, 2019

17. As also highlighted by the Petitioner, this requirement has also been affirmed by the five−Judge
Bench of this Court in Bachan Singh v. State of Punjab (supra), wherein it was also held that at the
stage of Pre−Sentence Hearing, the accused can bring on record material or evidence, which may
not be strictly relevant to or connected with the particular crime under inquiry, but nevertheless,
may have a bearing on the choice of sentence.
18. The first case on this point is Santa Singh v. The State of Punjab, (1976) 4 SCC 190, which was
decided by a Division Bench of this Court presided by Justice Bhagwati (as His Lordship then was)
and Justice Fazal Ali. This case revolved on the fact that an accused in a double murder case was
sentenced to death without providing an opportunity of ‘hearing’ under Section 235 (2) of CrPC,
which was the only ground of appeal before the Supreme Court. This Court, by two concurrent
opinions, remanded the matter back to the trial court for fresh consideration on sentencing after
giving an opportunity of ‘hearing’ to the accused. Justice Bhagwati interpreted Section 235 (2) of
CrPC in the following manner− “This material may be placed before the court by means of affidavits,
but if either party disputes the correctness or veracity of the material sought to be produced by the
other, an opportunity would have to be given to the party concerned to lead evidence for the purpose
of bringing such material on record. The hearing on the question of sentence, would be rendered
devoid of all meaning and content and it would become an idle formality, if it were confined merely
to hearing oral submissions without any opportunity being given to the parties and particularly to
the accused, to produce material in regard to various factors bearing on the question of sentence,
and if necessary, to lead evidence for the purpose of placing such material before the court.
… We are therefore of the view that the hearing contemplated by section 235 (2) is not confined
merely to hearing oral submissions, but it is also intended to give an opportunity to the prosecution
and the accused to place before the court facts and material relating to various factors bearing on the
question of sentence and if they are contested by either side, then to produce evidence for the
purpose of establishing the same. Of course, care would have to be taken by the court to see that this
hearing on the question of sentence is not abused and turned into an instrument for unduly
protracting the proceedings.” (emphasis supplied) Justice Fazal Ali, agreed with the aforesaid
conclusion, and made observations along the same lines.
19. The aforesaid ruling came to be questioned in Dagdu and others v. State of Maharashtra, (1977)
3 SCC 68, wherein a similar question came before this Court. This Court, while repelling the
submission of the counsel for the accused therein, who argued that the ratio in Santa Singh Case
(supra) mandated compulsory remand of the case to the trial court, held as under− “But we are
unable to read the judgment in Santa Singh (supra) as laying down that the failure on the part of the
Court, which convicts an accused, to 'hear him on the question of sentence must necessarily entail a
remand to that Court in order to afford to the accused an opportunity to. be heard on the question of
sentence. The Court, on convicting an accused, must unquestionably hear him on the question of
sentence. But if, for any reason, it omits to do so and the accused makes a grievance of it in the
higher court, it would be open to that Court to remedy the breach by giving a hearing to the accused
on the question of sentence. That opportunity has to be real and effective, which means that the
accused must be permitted to adduce before the Court all the data which he desires to adduce on the
question of sentence. The accused may exercise that right either by instructing his counsel to makeAccused X vs The State Of Maharashtra on 12 April, 2019

oral submissions to the Court or he may, on affidavit or otherwise, place in writing before the Court
whatever he desires to place before it on the question of sentence. The Court may, in appropriate
cases, have to adjourn the matter in order to give to the accused sufficient time to produce the
necessary data and to make his contentions on the question of sentence. That, perhaps, must
inevitably happen where the conviction is recorded for the first time by a higher court. Bhagwati J.
has observed in his judgment that care ought to be taken to ensure that the opportunity of a hearing
on the question of sentence is not abused and turned into an instrument for unduly protracting the
proceedings.” (emphasis supplied)
20. In Rajendra Prasad v. State of Uttar Pradesh, AIR 1979 SC 916, the Supreme Court expressed its
concern that the mandatory Pre−Sentence Hearing had become nothing more than a repetition of
the facts of the case. The Bench hoped that “the Bar will assist the Bench in fully using the resources
of the new provision to ensure socio−personal justice, instead of ritualising the submissions on
sentencing by reference only to materials brought on record for proof or disproof of guilt”.
21. In the case of Muniappan v. State of Tamil Nadu, (1981) 3 SCC 11, the Supreme Court noted that
the trial court had sentenced the accused to death stating that when the accused was asked to speak
on the question of sentence, he did not say anything. In such a case the Supreme Court noted that
the requirement of Section 235(2) was not discharged by merely putting a formal question to the
accused, and the court should undertake genuine efforts. The Court observed therein that, “it is the
bounden duty of the judge to cast aside the formalities of the court scene and approach the question
of sentence from a broad, sociological point of view”.
22. The question of providing sufficient time for Pre−Sentence Hearing was dealt with by the Court
in Allauddin Mian v. State of Bihar, (1989) 3 SCC 5. The Supreme Court observed that the trial court
had not provided sufficient time to the accused for hearing on sentencing. Relevant factors, such as,
the antecedents of the accused, their socio−economic conditions, and the impact of their crime on
the community had not come on record, and in the absence of such information deciding on
punishment was difficult. The Supreme Court therefore recommended that, “as a general rule the
trial courts should after recording the conviction adjourn the matter to a future date and call upon
both the prosecution as well as the defence to place the relevant material bearing on the question of
sentence before it and thereafter pronounce the sentence to be imposed on the offender”. The
aforesaid proposition was also reiterated in Malkiat Singh v. State of Punjab, (1991) 4 SCC 341.
23. On the other hand, in Sevaka Perumal v. State of Tamil Nadu, AIR 1991 SC 1463, this Court
upheld the death sentence even though it was argued that no time had been given to raise grounds
on sentencing by the trial court. This Court observed that, during the appeal, the defence counsel
had been unable to provide any additional grounds on sentence and therefore no prejudice had been
caused to the accused.
24. In State of Maharashtra v. Sukhdev Singh, (1992) 3 SCC 700, the Supreme Court clarified that
while Section 309 of the CrPC prescribed no power for adjournment of sentencing hearings, these
should be provided where the accused sought to produce materials in capital cases. In Jai Kumar v.
State of Madhya Pradesh, AIR 1999 SC 1860, this Court observed that the trial court had given anAccused X vs The State Of Maharashtra on 12 April, 2019

opportunity to the defence to produce materials, which they chose not to do, and had considered the
mitigating circumstances raised by them. This Court opined that, in such circumstances, it was not a
miscarriage of justice that the judge did not adjourn the hearing.
25. In Anshad v. State of Karnataka, (1994) 4 SCC 381, this Court disapprovingly noted that the trial
judge had dealt with sentencing cryptically in one paragraph and this defeated the very object of
Section 235(2) of CrPC, exposing a “lack of sensitiveness on his part while dealing with the question
of sentence”. Commuting the sentences of the appellants, the Supreme Court observed that both the
lower courts did not appreciate the aggravating and mitigating circumstances and therefore their
entire approach to sentencing was incorrect.
26. The aforesaid principle was further elucidated in the case of B.A. Umesh v. Registrar General,
High Court of Karnataka, (2017) 4 SCC 124, wherein it was held that a review petition cannot be
allowed merely because no separate date was given for hearing on the sentence. This Court held that
Section 235(2) of CrPC does not mandate separate date for the hearing of the sentence, rather, it is
dependent on the facts and circumstances of the case, for instance, if parties insist to be heard on
separate dates.
27. As per the order dated 03.02.2017 in Mukesh v. State (NCT of Delhi), (2017) 3 SCC 717, this
Court, having found that there was no compliance of Section 235 (2) of CrPC by the court’s below,
observed as under− “Having considered all the authorities, we find that there are two modes, one is
to remand the matter or to direct the accused persons to produce necessary data and advance the
contention on the question of sentence.
Regard being had to the nature of the case, we think it appropriate to adopt the second mode. To
elaborate, we would like to give opportunity before conclusion of the hearing to the accused persons
to file affidavits along with documents stating about the mitigating circumstances. Needless to say,
for the said purpose, it is necessary that the learned Counsel, Mr. M.L. Sharma and his associate Ms.
Suman and Mr. A.P. Singh and his associate Mr. V.P. Singh should be allowed to visit the jail and
communicate with the accused persons and file the requisite affidavits and materials.” (emphasis
supplied)
28. In the final order of Mukesh v. State (NCT of Delhi), (2017) 6 SCC 1, this Court held that in the
event the procedural requirements under Section 235 (2) of the CrPC are not met, the appellate
court can either remit the case back to the trial court or adjourn the matter before the appellate
forum for hearing on sentence after giving an opportunity to adduce evidence. On the other hand,
the court also noted that any deficiency in non− compliance of Section 235 (2) of CrPC can be cured
by providing the opportunity at the appellate stage itself so as to curtail the delay in the proceedings.
In that case, this Court had allowed the accused to file an affidavit listing the mitigating
circumstance, noticing that no pre−hearing on sentence was ever carried out.
29. Two recent three−Judge Bench decisions of this Court on this aspect merit our consideration.
Firstly, in the decision dated 28.11.2018 in Chhannu Lal Verma v. State of Chhattisgarh (Criminal
Appeal Nos. 1482−1483 of 2018), this Court observed that not having a separate hearing at the stageAccused X vs The State Of Maharashtra on 12 April, 2019

of trial was a procedural impropriety. Noting that a bifurcated hearing for conviction and sentencing
was a necessary condition laid down in Santosh Kumar Satishbhushan Bariyar, (2009) 6 SCC 498,
the Court held that by conducting the hearing for sentencing on the same day, the Trial Court failed
to provide necessary time to the appellant therein to furnish evidence relevant to sentencing and
mitigation. We find that this cannot be taken to mean that this Court intended to lay down, as a
proposition of law, that hearing the accused for sentencing on the same day as for conviction would
vitiate the trial. On the contrary, in the said case, it was found on facts that the same was a
procedural impropriety because the accused was not given sufficient time to furnish evidence
relevant to sentencing and mitigation.
30. Secondly, in the decision dated 12.12.2018 in Rajendra Prahladrao Wasnik v. State of
Maharashtra, (Review Petition (Crl.) Nos. 306−307 of 2013), this Court made a general observation
that in cases where the death penalty may be awarded, the Trial Court should give an opportunity to
the accused after conviction which is adequate for the production of relevant material on the
question of the propriety of the death sentence. This is evidently at best directory in nature and
cannot be taken to mean that a pre−sentence hearing on a separate date is mandatory.
31. It may also be noted that in the older three−Judge Bench decision of this Court in Malkiat Singh
Case (supra), the Court observed that keeping in mind the two−Judge Bench decisions in Allauddin
Mian Case (supra) and Anguswamy v. State of Tamil Nadu, (1989) 3 SCC 33, wherein it had been
laid down that a sentence awarded on the same day as the finding of guilt is not in accordance with
law, the normal course of action in case of violation of such procedure would be remand for further
evidence. However, on a perusal of these two decisions we find that their import has not been
correctly appreciated in Malkiat Singh Case (supra), since the observations in Allauddin Mian Case
(supra), as relied upon in Anguswamy Case (supra), regarding conduct of hearings on separate
dates, were only directory. Be that as it may, it must be noted that the effect of Malkiat Singh Case
(supra) has already been considered by this Court in Vasanta Sampat Dupare Case (supra), wherein
it was already noted that the mere non−conduct of the pre−sentence hearing on a separate date
would not per se vitiate the trial if the accused has been afforded sufficient time to place relevant
material on record.
32. It may not be out of context to note that in case the minimum sentence is proposed to be
imposed upon the accused, the question of providing an opportunity under Section 235(2) would
not arise. (See Tarlok Singh v. State of Punjab, (1977) 3 SCC 218; Ramdeo Chauhan v. State of
Assam, (2001) 5 SCC 714).
33. There cannot be any doubt that at the stage of hearing on sentence, generally, the accused argues
based on the mitigating circumstances in his favour for imposition of lesser sentence. On the other
hand, the State/the complainant would argue based on the aggravating circumstances against the
accused to support the contention relating to imposition of higher sentence. The object of Section
235 (2) of the Cr.P.C is to provide an opportunity for accused to adduce mitigating circumstances.
This does not mean, however, that the Trial Court can fulfil the requirements of Section 235(2) of
the Cr.P.C. only by adjourning the matter for one or two days to hear the parties on sentence. If the
accused is ready to submit his arguments on this aspect on the very day of pronouncement of theAccused X vs The State Of Maharashtra on 12 April, 2019

judgment of conviction, it is open for the Trial Court to hear the parties on sentence on the same day
after passing the judgment of conviction. In a given case, based on facts and circumstances, the Trial
Court may choose to hear the parties on the next day or after two days as well.
34. In light of the above discussion, we are of the opinion that as long as the spirit and purpose of
Section 235(2) is met, inasmuch as the accused is afforded a real and effective opportunity to plead
his case with respect to sentencing, whether simply by way of oral submissions or by also bringing
pertinent material on record, there is no bar on the pre−sentencing hearing taking place on the same
day as the pre−conviction hearing. Depending on the facts and circumstances, a separate date may
be required for hearing on sentence, but it is equally permissible to argue on the question of
sentence on the same day if the parties wish to do so.
35. Now we need to consider the impact of non−compliance of procedure provided under Section
235 (2) of CrPC by the trial court. Even assuming that a procedural irregularity is committed by the
trial court to a certain extent on the question of hearing on sentence, the violation can be remedied
by the appellate Court by providing sufficient opportunity of being heard on sentence. It must be
kept in mind that Section 465 of the CrPC mandates that no finding, sentence or order passed by the
Court of competent jurisdiction shall be reversed or altered by the Court of appeal on account of any
error, omission or irregularity in the order, judgment and other proceedings before or during trial
unless such error, omission or irregularity results in a failure of justice. Such non−compliance can
be remedied by the appellate Court by either remanding the matter in appropriate cases or by itself
giving an effective opportunity to the accused.
36. The narrative provided by numerous cases on this aspect portrays a picture of the appellate
Court trying to balance two important rights, viz., right to fair trial and right to speedy trial. On one
side, is the procedural right granted to the accused under Section 235 (2) of CrPC, and on the other
side is the possibility of misuse to delay the trial. The experienced judges in India have enough
expertise to distinguish, between the schemes for protracting trials from that of genuine causes in
order to protect rights of the accused.
37. This brings us to the role of appellate courts under our Criminal Justice System. There is no
dispute that under our chosen system, that the highest discretion is provided to trial courts.
Sometimes appellate courts, in order to preserve the competing factors in play, provides discretion
for the trial court to operate. However, appellate court must adopt a ‘cautionary approach’ when
providing such indulgence, which must be restricted and balanced against competing interests. 1
The narration of various court dicta, which are cited above, provide for a cautionary tale right from
Santa Singh Case onwards, as the choice of solution for remedying non−compliance of Section 235
(2) of CrPC provides for selection of at least two different modes. 1 Dame Sian Elias, Fairness in
Criminal Justice (golden threads and pragmatic patches), Hamlyn Lectures (2018)
38. As noted above, many cases have grappled with the question as to the choice between the two.
The approach of this Court needs to be rationalized and understood in the light of cautionary
approach discussed above. From the aforesaid discussion, following dicta emerge− i. That the term
‘hearing’ occurring under Section 235 (2) requires the accused and prosecution at their option, to beAccused X vs The State Of Maharashtra on 12 April, 2019

given a meaningful opportunity.
ii. Meaningful hearing under Section 235 (2) of CrPC, in the usual course, is not conditional upon
time or number of days granted for the same. It is to be measured qualitatively and not
quantitatively.
iii. The trial court need to comply with the mandate of Section 235 (2) of CrPC with best efforts.
iv. Non−compliance can be rectified at the appellate stage as well, by providing meaningful
opportunity. v. If such an opportunity is not provided by the trial court, the appellate court needs to
balance various considerations and either afford an opportunity before itself or remand back to trial
court, in appropriate case, for fresh consideration.
vi. However, the accused need to satisfy the appellate courts, inter alia by pleading on the grounds as
to existence of mitigating circumstances, for its further consideration. vii. Being aware of certain
harsh realities such as long protracted delays or jail appeals through legal aid etc., wherein the
appellate court, in appropriate cases, may take recourse of independent enquiries on relevant facts
ordered by the court itself.
viii. If no such grounds are brought by the accused before the appellate courts, then it is not
obligated to take recourse under Section 235 (2) of CrPC.
39. Having discussed the law on pre−sentence hearing, it would be appropriate at this juncture to
revisit the decisions of the Courts, leading to this review in order to ascertain whether the Petitioner
was given an effective opportunity to place material on record relevant to the quantum of sentence,
in this instant case.
40. The Trial Court heard the Petitioner on the aspect of imposition of sentence separately, which is
amply clear from paragraphs 79− 87 of the judgment of the Trial Court. Hence, based on the
material on record we are satisfied that the Trial Court has fully complied with the requirement of
Section 235(2) of the CrPC, While coming to its conclusion, the Court held that the aggravating
circumstances of the crime, i.e. the magnitude and manner of commission of the crime in the form
of the kidnapping, rape and murder of two minor girls, outweighed the mitigating circumstances of
the accused, i.e. the dependency of his aged mother on him, and his young age. The Court also gave
weightage to the prior convictions of the accused for the same kind of offence, i.e. for the offence of
rape of a nine−year−old girl child under Sections 376 and 506 of the IPC and Section 57 of the
Bombay Children Act, as well as for the kidnapping and rape of a seven−year−old girl child under
Sections 363 and 366 of the IPC. It may be noted here itself that in light of his two prior convictions,
the Trial Court also gave him an opportunity to be heard on the question of Section 75 of the IPC,
which pertains to enhance punishment for certain offences under Chapter XII or XVII of the IPC
after previous conviction, but the factum of these convictions was also not contested by the
Petitioner.Accused X vs The State Of Maharashtra on 12 April, 2019

41. Before the High Court as well, further material was brought on record by the Petitioner
regarding his discharge in one case related to offences of the same nature, which the Court found to
not be in the nature of a mitigating circumstance. The High Court was of the opinion that the
dependency of aged parents could also not be considered as a mitigating circumstance to begin with,
and that the accused was not young enough for his age to be considered as a mitigating
circumstance. The High Court noted the absence of any extreme mental or emotional disturbance
leading to the commission of the offence, and observed that given the past offending history of the
accused, there was no hope of his reform or rehabilitation. The Court also noted the barbaric nature
of the offence, inasmuch as the Petitioner had cold−bloodedly raped and murdered two innocent
and defenceless girls by abusing the faith that they had reposed in him as their neighbour, and
concluded that he would pose a threat to society even if released for the smallest period of time, and
might commit similar acts in the future. On this basis, the High Court affirmed the death penalty
awarded to the accused.
42. The Supreme Court, in appeal, being Criminal Appeal No. 680 of 2007, also determined the case
to fall into the category of the rarest of rare cases.
43. The record in the instant matter therefore clearly shows that the accused was accorded a real
and effective opportunity at the trial stage itself. It may further be stated that the opportunity
granted to the Petitioner by the High Court to adduce further material on this aspect was above and
beyond the requirement of Section 235(2). The Courts had taken all the attendant circumstances
into account before reaching the conclusion of awarding the death penalty. It is also not the case
that the accused made a request for hearing on sentencing on a separate date and the same was
refused. In such circumstances, we reject the contention that the procedure envisaged in Section
235(2) of the CrPC was not complied with in the present case.
44. Now we need to consider the second issue concerning post− conviction mental illness as a
mitigating factor for converting a death sentence to life imprisonment.
45. It is pertinent for us to understand the phenomenon of post− conviction mental illness. As the
phrase itself suggests, it is only after being proven guilty, that the convict has developed such illness.
It is well acknowledged fact throughout the world that, prisons are difficult places to be in. The
World Health Organisation and the International Red Cross, identify multiple circumstances such
as overcrowding, various forms of violence, enforced solitude, lack of privacy, inadequate health
care facilities, concerns about family etc, can take a toll on the mental health of the prisoners. Due to
the prevailing lack of awareness about such issues, the prisoners have no recourse and their mental
health keeps on degrading day by day. The prevailing argument in favour of such prisoners is that;
whether the imposition of death penalty upon such prisoners is justified, who have clearly impaired
their abilities to even understand the nature and purpose of such punishment and the reasons for
such imposition? The aforesaid issues will be dealt at length at the later stage.
46. The accused has now pleaded an entirely new ground of post− conviction mental illness for the
first time herein, which obliges us to go into the aspect of sentencing afresh. It is also brought to our
notice that the appellant has been a death row convict for almost 17 years, mandating us to resolveAccused X vs The State Of Maharashtra on 12 April, 2019

the issue of sentencing herein. Before we consider the appropriate punishment for the accused
herein, a reference needs to be made to the background principles concerning sentencing policy
considering that the present Petitioner is pleading a mitigating factor which has arisen post−
conviction.
47. Sentencing is appropriate allocation of criminal sanctions, which is mostly given by the judicial
branch. 2 This process occurring at the end of a trial still has a large impact on the efficacy of a
Criminal Justice System. It is established that sentencing is a 2 Nicola Padfield, Rod Morgan and
Mike Maguire, ‘Out of Court, out of sight? Criminal sanctions and no−judicial decision making’, The
Oxford Handbook of Criminology (5th Ed.). socio−legal process, wherein a judge finds an
appropriate punishment for the accused considering factual circumstances and equities. In light of
the fact that the legislature provided for discretion to the judges to give punishment, it becomes
important to exercise the same in a principled manner. We need to appreciate that a strict fixed
punishment approach in sentencing cannot be acceptable, as the judge needs to have sufficient
discretion as well.
48. Before analyzing this case, we need to address the issue of the impact of reasoning in the
sentencing process. The reasoning of the trial court acts as a link between the general level of
sentence for the offence committed and to the facts and circumstances. The trial court is obligated to
give reasons for the imposition of sentence, as firstly, it is a fundamental principle of natural justice
that the adjudicators must provide reasons for reaching the decision and secondly, the reasons
assume more importance as the liberty of the accused is subject to the aforesaid reasoning. Further,
the appellate court is better enabled to assess the correctness of the quantum of punishment
challenged, if the trial court has justified the same with reasons. The aforesaid principle is fortified
not only by the statute under Section 235 (2) of CrPC but also by judicial interpretation. Any
increase or decrease in the quantum of punishment than the usual levels need to be reasoned by the
trial court. However, any reasoning dependent on moral and personal opinion/notion of a Judge
about an offence needs to be avoided at all costs.
49. Sentencing in India, is a midway between judicial intuition and strict application of rule of law.
As much as we value the rule of law, the process of sentencing needs to preserve principled
discretion for a judge. In India, sentencing is mostly led by ‘guideline judgments’ in the death
penalty context, while many other countries like United Kingdom and United States of America,
provide a basic framework in sentencing guidelines.
50. Although at the outset, it is clarified that this Court may not laydown a ‘definitive sentencing
policy’, which is rather a legislative function, however, the Courts in India have addressed this
problem in a principled manner having regards to judicial standards and principles. These judicially
set−principles not only serve as instructive guidelines, but also preserve the required discretion of
the trial judges while sentencing. Such an effort has already been initiated by the Supreme Court, in
Sunil Dutt Sharma Case, (2014) 4 SCC 375, when the sentencing guidelines evolved in the context of
death penalty were applied to a lesser sentence as well. However, achieving sentencing uniformity
may not only require judicial efforts, but even the legislature may be required to step in.Accused X vs The State Of Maharashtra on 12 April, 2019

51. Moreover, our attention is also drawn to the Malimath Committee Report on Reforms in the
Criminal Justice System, which recommended creation of a statutory body for prescribing
sentencing guidelines. Before concluding the aforementioned observations highlighting the dangers
of sentencing discretion, we are reminded of the words of Justice Krishna Iyer, who held that
“Guided missiles with lethal potential, in unguided hands, even judicial, is a grave risk where the
peril is mortal though tempered by the appellate process.” [refer Rajendra Prasad v. State of Uttar
Pradesh (1979) 3 SCC 646]
52. In any case, considering that a large part of the exercise of sentencing discretion is principled, a
Judge in India needs to keep in mind broad purposes of punishment, which are deterrence,
incapacitation, rehabilitation, retribution and reparation (wherever applicable), unless particularly
specified by the legislature as to the choice. The purposes identified above, marks a shift in law from
crime−oriented sentencing to a holistic approach wherein the crime, criminal and victim have to be
taken into consideration collectively.
53. Having observed some of the general aspects of sentencing, it is necessary to consider the aspect
of post−conviction mental illness as mitigating factor in the analysis of ‘rarest of the rare’ doctrine
which has come into force post Bachan Singh Case (supra).
54. As a starting point we need to refer to Piare Dusadh v. King Emperor, AIR 1944 FC 1, has already
recognized post−conviction mental illness as a mitigating factor in the following manner− Case No.
47−The appellant in this case was convicted by a Special Judge of the offence of murder and was
sentenced to death on 30th September 1942. His appeal to the Allahabad High Court was dismissed
and the sentence of death was confirmed. The appellant is a young man of 25 who has been twice
widowed. His victim was his aunt, 30 years of age, whose husband (Kanchan) had about six years
previously murdered his own brother, appellant's father. Kanchan was sentenced to death for the
murder, but lost his reason while awaiting the execution of the death sentence, and is now detained
as a lunatic. The evidence in this case leaves no room for doubt that the appellant was rightly
convicted of murder. There is some confusion as to the exact motive for the undoubtedly brutal
assault of which the appellant made his aunt the victim. The prosecution alleged that the appellant
being a widower was chagrined by the refusal of his aunt to become his mistress. In his statement
before, the Special Judge he said that another uncle (P.W. 7) who according to the appellant was
behind the prosecution was on terms of improper intimacy with the deceased and resented even
small acts of kindness on the part of the deceased towards the appellant. In the appeal preferred by
him through the jail authorities to the High Court, the appellant stated that his aunt was a woman of
loose character and was pursuing him with unwelcome attentions. The previous history of this
family indicates that the appellant probably suffers from an unbalanced mind. The nature and
ferocity of the assault upon his aunt appear to confirm this.
In committing the offence the appellant must have been actuated by jealousy or by indignation
either of which would tend further to disturb the balance of his mind. He has besides been awaiting
the execution of his death sentence for over a year. We think that in this case a sentence of
transportation for life would be more appropriate than the sentence of death.Accused X vs The State Of Maharashtra on 12 April, 2019

We accordingly reduce the sentence of death to one of transportation for life and subject to this
modification dismiss the appeal.
(emphasis supplied) However, this case does not provide any guidelines or the threshold for
evaluating what kind of mental illness needs to be taken into consideration by the Courts.
55. We note that, usually, mitigating factors are associated with the criminal and aggravating factors
are relatable to commission of the crime. These mitigating factors include considerations such as the
accused’s age, socio−economic condition etc. We note that the ground claimed by ‘accused x’ is
arising after a long−time gap after crime and conviction. Therefore, the justification to include the
same as a mitigating factor does not tie in with the equities of the case, rather the normative
justification is founded in the Constitution as well as the jurisprudence of the ‘rarest of the rare’
doctrine. It is now settled that the death penalty can only be imposed in the rarest of the rare case
which requires a consideration of the totality of circumstances. In this light, we have to assess the
inclusion of post−conviction mental illness as a determining factor to disqualify as a ‘rarest of the
rare’ case.
56. Sentencing generally involves curtailment of liberty and freedom for the accused. Under Article
21 of the Constitution, right to life and liberty cannot be impaired unless taken by jus laws. In this
case we are concerned with the death penalty, which inevitably affects right to life, and is subjected
to a various substantive and procedural protections under our criminal justice system. An
irreducible core of right to life is ‘dignity’. [refer Navtej Singh Johar v. Union of India, AIR 2018 SC
4321]. Right to human dignity comes in different shades and colours. [refer Common Cause v.
Union of India, AIR 2018 SC 1665]. For our purposes, the dignity of human being inheres a capacity
for understanding, rational choice, and free will inherent in human nature, etc. The right to dignity
of an accused does not dry out with the judges’ ink, rather, it subsists well beyond the prison gates
and operates until his last breath. In the context of mentally ill prisoners it is pertinent to mention
that Section 20 (1) of the Mental Health Care Act, 2017, Act No. 10 of 2017, explicitly provides that
‘every person with mental illness shall have a right to live with dignity’.
57. All human beings possess the capacities inherent in their nature even though, because of infancy,
disability, or senility, they may not yet, not now, or no longer have the ability to exercise them.
When such disability occurs, a person may not be in a position to understand the implications of his
actions and the consequence it entails. In this situation, the execution of such a person would lower
the majesty of law.
58. Article 20 (1) of the Indian Constitution imbibes the idea communication/knowledge for the
accused about the crime and its punishment. It is this communicative element, which is ingrained in
the sentence (death penalty), that gives meaning to the punishments in a criminal proceeding. The
notion of death penalty and the sufferance it brings along, causes incapacitation and is idealized to
invoke a sense of deterrence. If the accused is not able to understand the impact and purpose of his
execution, because of his disability, then the raison d’être for the execution itself collapses.Accused X vs The State Of Maharashtra on 12 April, 2019

59. It may not be out of context to refer Atkins v. Virginia, 536 U.S. 304 (2002), wherein the United
States Supreme Court, while dealing with the question ‘whether the execution of mentally retarded
persons "cruel and unusual punishment" prohibited by the Eighth Amendment?’ The Court noted
that hanging mentally disabled or retarded neither increases the deterrence effect of death penalty
nor does the non−execution of the mentally disabled will measurably impede the goal of deterrence.
60. Moreover, Article 20 of the Constitution guarantees individuals the right not to be subjected to
excessive criminal penalty. The right flows from the basic tenet of proportionality. By protecting
even those convicted of heinous crimes, this right reaffirm the duty to respect the dignity of all
persons. Therefore, our Constitution embodies broad and idealistic concepts of dignity, civilized
standards, humanity, and decency against which penal measures have to be evaluated. In
recognizing these civilized standards, we may refer to the aspirations of India in being a signatory to
the Convention on Rights of Persons with Disabilities, which endorse ‘prohibition of cruel, inhuman
or degrading punishments’ with respect to disabled persons. Additionally, when the death penalty
existed in England, there was a common law right barring execution of lunatic prisoners. 3 3 Hale's
Pleas of the Crown Vol. I − p. 33; Coke's Institutes, Vol. III, pg. 6; Black−stone's Commentaries on
the Laws of England Vol. IV, pages 18 and 19; , "An Introduction to Criminal Law", by Rupert Cross,
(1959), p. 67. Additionally, there is a strong international consensus against the execution of
individuals with mental illness.4
61. We may note that various prison rules in India also recognizes that generally the Government
has the duty to pass appropriate orders on execution, if a person is found to be lunatic. Andhra
Pradesh Prison Rules, 1979, Rule 796; Gujarat Prisons (Lunatics) Rules, 1983; Delhi Prison Rules,
2018, Rule 824; Tamil Nadu Prison Rules, 1983, Rule 923; Maharashtra Prison Manual, 1979,
Chapter XLII (Government Notification, Home department, No. RJM−1058 (XLVI)/12,495−XVI,
dated 18.01.1971); Model Prison Manual by Ministry of Home Affairs (2016), Rule 12.36 are some of
the examples of legal instruments in India which have already recognized post−conviction mental
illness as a relevant factor for Government to consider under its clemency jurisdiction.
62. Having understood the normative basis for recognition of post− conviction mental illness as a
mitigating factor in a death penalty case, we must mention that Shatrughan Chauhan Case (supra)
had identified the same and holds as under:
4 Commission on Human Rights Resolution 2000/65 The question of the death
penalty, UN Commission on Human Rights (Apr. 27, 2000); G.A. Res. 69/186, ¶ 5(d)
(Feb. 4, 2015);
“86. The above materials, particularly, the directions of the United Nations international
conventions, of which India is a party, clearly show that insanity/mental illness/schizophrenia is a
crucial supervening circumstance, which should be considered by this Court in deciding whether in
the facts and circumstances of the case death sentence could be commuted to life imprisonment. To
put it clear, “insanity” is a relevant supervening factor for consideration by this Court.”Accused X vs The State Of Maharashtra on 12 April, 2019

63. Now we need to consider the test for recognizing an accused eligible for such mitigating factor. It
must be recognized that insanity recognized under IPC and the mental illness we are considering in
the present case arise at a different stage and time. Under IPC, Section 84 recognizes the plea of
legal insanity as a defence against criminal prosecution. [refer Surendra Mishra v. State of
Jharkhand, (2011) 3 SCC (Cri.) 232]. This defence is restricted in its application and is made
relatable to the moment when the crime is committed. Therefore, Section 84 of IPC relates to the
mens rea at the time of commission of the crime, whereas the plea of post−conviction mental illness
is based on appreciation of punishment and right to dignity. [refer Amrit Bhushan Gupta v. Union of
India, AIR 1977 SC 608] The different normative standards underpinning the above consequently
mean different threshold standards as well.
64. On the other hand, considering the fact that the case is at the fag end of the process and the
mitigating factors so discussed above were not emergent at the time of commission of the crime,
therefore this ground needs to be utilized only in extreme cases of mental illness considering the
element of marginal retribution which survives. In any case, considering that India has taken an
obligation at an international forum to not punish mental patients with cruel and unusual
punishments, it would be necessary for this Court to provide for a test wherein only extreme cases of
convicts being mentally ill are not executed. Moreover, this Court cautions against utilization of this
dicta as a ruse to escape the gallows by pleading such defense even if such aliment is not of grave
severity.
65. Before we analyse this case at hand, a brief survey of classification of mental illness and its
impact on death penalty needs to be considered. The Diagnostic and Statistical Manual of Mental
Disorders (DSM), is one of the most well−known classification and diagnostic guides for mental
disorders in America. Its fifth edition (DSM−5), published in 2013, defines mental disorder as
follows: − A mental disorder is a syndrome characterized by clinically significant disturbance in an
individual’s cognition, emotion regulation, or behaviour that reflects a dysfunction in the
psychological, biological, or developmental processes underlying mental functioning. Mental
disorders are usually associated with significant distress in social, occupational, or other important
activities. An expectable or culturally approved response to a common stressor or loss, such as the
death of a loved one, is not a mental disorder. Socially deviant behavior (e.g., political, religious, or
sexual) and conflicts that are primarily between the individual and society are not mental disorders
unless the deviance or conflict results from a dysfunction in the individual, as described above.
66. ‘Severe Mental Illness’ under the ‘International Classification of Diseases (ICD)’, which is
accepted under Section 3 of the Mental Health Care Act, 2017, generally include−
1. schizophrenic and delusional disorders
2. mood (affective) disorders, including depressive, manic and bipolar forms
3. neuroses, including phobic, panic and obsessive– compulsive disorders
4. behavioural disorders, including eating, sleep and stress disordersAccused X vs The State Of Maharashtra on 12 April, 2019

5. personality disorders of different kinds.
67. American Bar Association, by its Resolution 122A passed on August 2006, notes as under−
(a) Grounds for Precluding Execution. A sentence of death should not be carried out if the prisoner
has a mental disorder or disability that significantly impairs his or her capacity (i) to make a rational
decision to forgo or terminate post−conviction proceedings available to challenge the validity of the
conviction or sentence; (ii) to understand or communicate pertinent information, or otherwise assist
counsel, in relation to specific claims bearing on the validity of the conviction or sentence that
cannot be fairly resolved without the prisoner's participation; or (iii) to understand the nature and
purpose of the punishment, or to appreciate the reason for its imposition in the prisoner's own case.
68. In line with the above discussion, we note that there appear to be no set disorders/disabilities
for evaluating the ‘severe mental illness’, however a ‘test of severity’ can be a guiding factor for
recognizing those mental illness which qualify for an exemption. Therefore, the test envisaged
herein predicates that the offender needs to have a severe mental illness or disability, which simply
means that a medical professional would objectively consider the illness to be most serious so that
he cannot understand or comprehend the nature and purpose behind the imposition of such
punishment. These disorders generally include schizophrenia, other serious psychotic disorders,
and dissociative disorders−with schizophrenia.
69. Following directions need to be followed in the future cases in light of the above discussion− a.
That the post−conviction severe mental illness will be a mitigating factor that the appellate Court, in
appropriate cases, needs to consider while sentencing an accused to death penalty.
b. The assessment of such disability should be conducted by a multi−disciplinary team of qualified
professionals (experienced medical practitioners, criminologists etc), including professional with
expertise in accused’s particular mental illness.
c. The burden is on the accused to prove by a preponderance of clear evidence that he is suffering
with severe mental illness. The accused has to demonstrate active, residual or prodromal symptoms,
that the severe mental disability was manifesting. d. The State may offer evidence to rebut such
claim. e. Court in appropriate cases could setup a panel to submit an expert report.
f. ‘Test of severity’ envisaged herein predicates that the offender needs to have a severe mental
illness or disability, which simply means that objectively the illness needs to be most serious that the
accused cannot understand or comprehend the nature and purpose behind the imposition of such
punishment.
70. Having said so, it needs to be considered that the accused has submitted a report of the Class−I
Psychiatrist, Yerawada Central Prison, indicating that he was suffering from some sort of mental
illness without providing any objective factors for such assessment. We may reproduce the aforesaid
report dated 25.09.2014, in the following manner− Clinical impression:− no delusions, no
hallucinations, sleep and appetite are normal.Accused X vs The State Of Maharashtra on 12 April, 2019

Remark:−Taking regular medication and maintaining improvement. He is under OPD under
Psychiatric treatment since 21.12.1994 and since then taking regular treatment.
Currently he is on anti−psychotic drugs… The doctor further opined that ‘he is maintaining good
improvement on medication, good diet. He is having psychological disturbance and symptoms like
irritability emerges when the dosage is decreased.
71. Moreover, the expert opinion offered by a Psychiatrist registered with the Maharashtra Medical
Council working as a coordinator of the Centre for Mental Health Law and Policy, Indian Law
Society, Pune, does not provide any further clarity. We may extract the conclusion reached by the
aforesaid report as well− While no definite opinion can be given relating to the mental health
condition of Accused ‘X’ and the treatment being administered to him, considering that he appears
to be under treatment for a severe mental illness such as schizophrenia or some type of psychosis,
there appears to be a need to review Accused x’s medical records and to clinically examine him to
assess his current psychiatric status.
(emphasis supplied).
72. Even though we are not satisfied with such statements made by the doctors as the assessment
seems to be incomplete. However, it is to be noted that the present accused has been reeling under
bouts of some form of mental irritability since 1994, as apparent from the records placed before us.
Moreover, he has suffered long incarceration as well as a death row convict. In the totality of
circumstances, we do not consider it be appropriate to constitute a panel for re−assessment of his
mental condition, in the facts and circumstances of this case.
73. At the same time, we cannot lose sight of the fact that a sentence of life imprisonment simpliciter
would be grossly inadequate in the instant case. Given the barbaric and brutal manner of
commission of the crime, the gravity of the offence itself, the abuse of the victims’ trust by the
Petitioner, and his tendency to commit such offences as is evident from his past conduct, it is
extremely clear that the Petitioner poses such a grave threat to society that he cannot be allowed to
roam free at any point whatsoever. In this view of the matter, we deem it fit to direct that the
Petitioner shall remain in prison for the remainder of his life. It need not be stated that this Court
has in a plethora of decisions held such an approach to be perfectly within its power to adopt, and
that it acts as a useful via media between the imposition of the death penalty and life imprisonment
simpliciter (which usually works out to 14 years in prison upon remission). (See for instance Swamy
Shraddananda (2) v. State of Karnataka, (2008) 13 SCC 767; Union of India v. V. Sriharan, (2016) 7
SCC 1; Tattu Lodhi v. State of Madhya Pradesh, (2016) 9 SCC 675).
74. In light of the above discussion, the petition is allowed to the extent that the sentence of death
awarded to the Petitioner is commuted to imprisonment for the remainder of his life sans any right
to remission.
75. Further, it is this state of ‘accused x’ that obliges the State to act as parens patriae. In this state
‘accused x’ cannot be ignored and left to rot away, rather, he requires care and treatment. Generally,Accused X vs The State Of Maharashtra on 12 April, 2019

it needs to be understood that prisoners tend to have increased affinity to mental illness.5 Moreover,
due to legal constraints on the recognition of broad−spectrum mental illness within the Criminal
Justice System, prisons inevitably become home for a greater number of mentally−ill prisoners of
various degrees. There is no overlooking of the fact that the realities within the prison walls may well
compound and complicate these problems.6
76. In order to address the same, the Mental Healthcare Act, 2017 was brought into force. The
aspiration of the Act was to provide mental health care facility for those who are in need including
prisoners. The State Governments are obliged under Section 103 of the Act to setup a mental health
establishment in the medical wing of at least one prison in each State and Union Territory, and
prisoners with mental illness may ordinarily be referred to and cared for in the said mental health
establishment. 5 Although statistics on the same are not available for all of Indian prisons, but we
were able to compare sample studies within some Indian prisons and literature on psychiatric
morbidity concurs as well.
6 Liebling, Maruna and McAra et al., The Oxford Handbook of Criminology (6th Ed. (2017)).
77. Therefore, we direct the State Government to consider the case of ‘accused x’ under the
appropriate provisions of the Mental Healthcare Act, 2017 and if found entitled, provide for his
rights under that enactment.
78. In light of the above discussion, this review petition stands partly allowed in the aforesaid terms
and pending applications, if any, shall also stand disposed of.
..…………………………..……..J. [N.V. Ramana] ..…………………………..……..J. [Mohan M.
Shantanagoudar] ..…..……………………..
……..J. [Indira Banerjee] NEW DELHI;
APRIL 12, 2019Accused X vs The State Of Maharashtra on 12 April, 2019

