Cmc Ltd vs Unit Trust Of India on 6 February, 2015
Equivalent citations: AIR 2015 (NOC) 650 (BOM.), 2015 (2) ABR 472
Author: R.D. Dhanuka
Bench: R.D. Dhanuka
    ppn                                1                              arbp-275.12 (j).doc
          IN THE HIGH COURT OF JUDICATURE AT BOMBAY
              ORDINARY ORIGINAL CIVIL JURISDICTION
                 ARBITRATION PETITION NO.275 OF 2012
    CMC Limited                            )
    A company registered under the         )
Companies Act, 1956 having its         )
    registered office at CMC Centre,       )
    Old Mumbai Highway, Gachibowli,        )
    Hyderabad - 500 032 and                )
    Regional office at CMC House, C-18     )
    Bandra Kurla Complex,                  )
    Bandra (East), Mumbai 400 051.
                            ig             )        ..         Petitioner
                                                          (original Respondent)
          Vs.
    Unit Trust of India                    )
    through the Administrator of the       )Cmc Ltd vs Unit Trust Of India on 6 February, 2015

    specified Undertaking of the Unit      )
    Trust of India, having its office at   )
    UTI Tower, Gn. Block,                  )
    Bandra Kurla Complex,                  )
    Bandra (East), Mumbai 400 051.         )      ..         Respondent
                                                          (original Claimant)
                 ---
    Ms.Alpana Ghone a/w Mr. Mayur Khandeparkar a/w Ms.Bhairavi Pathak
    a/w Ms. J.Shah i/by M/s. I.R. Joshi & Co. for the petitioner.
    Mr.J.P. Sen, Senior Advocate a/w Mr. Mohit Arora a/w Ms. Pinky Patel
    i/by M/s. Desai & Diwanji for the respondent.
                 ---
                            CORAM                : R.D. DHANUKA, J.
                                RESERVED ON       :  13th January, 2015
                                PRONOUNCED ON :   6th  February, 2015 
    JUDGMENT :
-
. By this petition filed under Section 34 of the Arbitration and Conciliation Act, 1996 (for short 'the
said Act'), the petitioner has ppn 2 arbp-275.12 (j).doc impugned the arbitral awards rendered by
the arbitral tribunal on 7 th February 2008 and 3rd November 2009 allowing some of the claims
made by the respondent and rejecting the counter claims made by the petitioner. Some of the
relevant facts for the purpose of deciding this petition are as under :
2. The petitioner was the original respondent in the statement of claim and was
claimant to the counter claim before the arbitral tribunal. The respondent herein was
the original claimant to the statement of claim and original respondent to the counter
claim before the arbitral tribunal.
3. On or about 23rd October 1992, the petitioner and the respondent entered into an
agreement by which the respondent awarded job of its 'Information TechnologyCmc Ltd vs Unit Trust Of India on 6 February, 2015

Upgrade Project' comprising of (i) Project Management, (ii) Software Development
and Implementation,
(iii)Networking Services, and (iv) Training and Implementation Support (for short
'the said Technology Upgrade Project') for the consideration and on the terms and
conditions contained in the Agreement dated 23 rd October 1992.
4. It is the case of the petitioner that as per Agreement dated 23rd October 1992, the
parties met along with their consultants to discuss the SRS of the Application Groups.
Thereafter, the petitioner sent the SRS for the modules AG-1 to AG-5. By its letter
dated 19 th April 1994, the respondent confirmed the receipt and acceptance of SRS
of the modules AG-1A,AG-1B, AG-2, AG-3, Ag-5 and requested that any observations
put forth during the design review by the external ppn 3 arbp-275.12 (j).doc experts
should be taken congnizance of by the petitioner in the Application Software.
5. The petitioner started work on the AG-2 module and sought to complete the
project in terms of the said Agreement. By its letter dated 29th March 1995, the
petitioner raised various bills on the respondent for the implemented milestones
completed in the AG-2 and AG-3 projects for Rs.37,25,961.72.
6. It is the case of the petitioner that the petitioner by its letter dated 10th January
1996 requested for release of payment of bills raised on 29th March 1995 for the
project AG-2. The petitioner claimed the balance amounts which were not paid by the
respondent in respect of AG-2 were pending. It is the case of the petitioner that the
respondent confirmed its Agreement to pay a sum of Rs.22,12,500/- and requested
the petitioner to raise the bill for the said amount by letter dated 15 th April 1996.
There was a meeting held on 22nd May 1996 wherein it was agreed that the
respondent would release the payment of pending bills of the petitioner by 31st May
1996.
7. The respondent by its letter dated 19th June 1996 referred to the Development of
the 18 new reports prepared by the petitioner for AG-2 project and requested the
petitioner to raise a bill of Rs.3 lacs for the said work. It is the case of the petitioner
that the said letter itself would indicate that the respondent was already using certain
applications of AG-2 module successfully and had requested for further development
of 18 applications. The petitioner accordingly raised a bill for Rs.3 lacs for software
development charges for the additional 18 reports prepared ppn 4 arbp-275.12 (j).doc
for AG-2 module.
8. By letter dated 1st August 1996, the petitioner wrote to the respondent requesting
it to freeze the scope of AG-2 software. There was no response from the respondent to
the said letter. The petitioner completed the software with the specifications
mentioned in that letter. It is the case of the petitioner that in the meeting held on 24
th December 1996, the progress of AG-2 software was discussed. The respondent atCmc Ltd vs Unit Trust Of India on 6 February, 2015

this meeting extended the date of completion of AG-2 software to 1 st April 1997 from
the earlier date of 31 st December 1996. The petitioner by its letter dated 27th
December 1996 informed the respondent that the implementation and completion of
AG-2 project would be the joint and collective responsibility of both the parties.
9. It is the case of the petitioner that though the respondent extended the completion
date and despite realising the complexities of the development of the software,
suddenly and arbitrarily decided to abandon the project and informed the petitioner
of the same by its letter dated 14th January 1997 unilaterally abandoning the AG-2
project.
According to the petitioner, the petitioner had completed various milestones in respect of the said
AG-2 project before the decision of the respondent to abandon the said AG-2 project.
10. By letter dated 29th August 1997, the respondent informed the petitioner that they wanted
refund of all the amounts that have been paid by them to the petitioner for the work that was done
on the AG-2 project. In response to the said letter, the petitioner by its letter dated 16th October
1997 refuted the allegations, assertions and claims contained ppn 5 arbp-275.12 (j).doc in its letters
dated 14th January 1997 and 29th August 1997 on various grounds.
11. The petitioner by its letter dated 10th December 1998 requested the respondent to pay the
outstanding dues of Rs.9,15,300/- that was payable by the respondent to the petitioner as per the
said letter. On or about 13th February 2002, the respondent issued a notice to the petitioner
demanding a refund of Rs.99.404 lacs with additional interest @ 13.5% p.a. with effect from 14 th
January 1997 till the actual date of payment within 30 days from the receipt of the said notice failing
which the respondent threatened to take necessary legal action.
12. By its letter dated 4th March 2002, the petitioner reiterated the said demand and alleged that
the petitioner had incurred cost and time overruns of more than 200 person months for which the
respondent owed the petitioner an amount of Rs.150 lacs. The petitioner also sent a reminder to the
respondent that the bills for an amount of Rs.10.75 lacs and Rs.19.25 lacs were also pending. The
petitioner demanded the said amounts from the respondent.
13. On 16th May 2002, the respondent issued a Notice of arbitration to the petitioner and appointed
Mr.D.S. Phaterphekar, Advocate as its nominee arbitrator. It is the case of the petitioner that the
petitioner did not take any cognizance of the said purported notice and to act thereon alleging that
the said notice was not in accordance with the ICA Rules. The respondent thereafter filed an
application under Section 11 of the said Act. The arbitral tribunal was ultimately constituted.
ppn 6 arbp-275.12 (j).doc
14. The respondent filed Statement of Claim on 31 st July 2007 before the arbitral tribunal against
the petitioner inter alia praying for a declaration that the petitioner was liable to refund the amounts
already received by it from the respondent for the development of applications/ modules formingCmc Ltd vs Unit Trust Of India on 6 February, 2015

part of AG-2. The respondent also prayed for an award against the petitioner for an amount of
Rs.83.455 lacs as and by way of refund of the amounts paid by the respondent to the petitioner for
the development of applications/modules forming part of AG-2 with interest @13.50% p.a. with
effect from 14th August 1997. The respondent also prayed for damages against the petitioner
amounting to Rs.15.959 lacs with interest @13.50 % p.a. with effect from 14th August 1997 till
payment and demanded cost of Arbitration. There was no averment made in the Statement of Claim
as to whether the claims made by the respondent were within time and not barred by law of
limitation.
15. The petitioner filed detailed written statement and counter claim to the said claims filed by the
respondent before the arbitral tribunal. The said counter claim was resisted by the respondent on
various grounds including limitation and arbitrability.
16. By a separate order passed by the arbitral tribunal on 7 th February 2008, it is held that the
arbitral tribunal has the jurisdiction to adjudicate upon the respondent's counter claims prayed in
prayers 'A', 'B', 'C', 'D', 'E' and 'H' of the counter claim and had no jurisdiction to adjudicate upon the
respondent's counter claim prayed in prayers 'F' and 'G' of the counter claim. The said order was
passed under Section 16 of the said Act which was filed by the respondent before the arbitral ppn 7
arbp-275.12 (j).doc tribunal. The petitioner did not file any appeal against the said order dated 7th
February 2008. The petitioner, however, challenged the said order dated 7th February 2008 along
with final award dated 3 rd November 2009 in this petition. The respondent raised a preliminary
objection about maintainability of the arbitration petition in so far as the order dated 7 th February
2008 passed by the arbitral tribunal rejecting prayers 'F' and 'G' are concerned.
17. Learned counsel for the petitioner fairly admitted that the arbitration petition under Section 34
of the said Act for impugning the order dated 7th February 2008 passed under Section 16 of the said
Act in respect of rejection of claim 'F' and 'G' is not maintainable. The arbitral tribunal framed eight
points for determination.
18. The respondent led oral evidence of Mr.Sanjivan Shirke, Manager, Department of Accounts/
Information Technology Cell of the respondent who was cross-examination by the counsel
representing the petitioner. The petitioner examined Mr. Jayant Shridhar Rawalgaonkar, a retired
Executive Director of the petitioner and Mrs.Mona Marathe, Delivery Centre Co-ordinator who were
cross-examined by the respondent through its counsel.
19. By the impugned award dated 3rd November 2009, the arbitral tribunal rejected the plea of
limitation raised by the petitioner in respect of the claims made by the respondent. The arbitral
tribunal did not decide the plea of limitation raised by the respondent regarding counter claims
made by the petitioner. By the said impugned award ppn 8 arbp-275.12 (j).doc dated 3rd November
2009, the arbitral tribunal directed the petitioner to pay to the respondent the sum of
Rs.83,45,500/- together with interest @9% p.a. with effect from 31st July 2007 till payment or
realization and also awarded the arbitration cost in favour of the respondent at Rs.9,30,000/-. The
arbitral tribunal rejected the counter claims made by the petitioner. The said award has been
impugned by the petitioner in this petition under Section 34 of the said Act on various grounds.Cmc Ltd vs Unit Trust Of India on 6 February, 2015

20. Learned counsel for the petitioner invited my attention to various provisions of the Agreement
dated 23rd October 1992 entered into between the petitioner and the respondent and more
particularly Clauses 1.5 i.e. definition of 'Application Group', 1.9 i.e. 'Implementation Milestones',
2.2.6 i.e. 'Application Group Acceptance', 2.2.7 i.e.'Defect Liability Period for Application Groups',
2.2.8 i.e. 'Application Systems Implementation Support', Clause 3 i.e. Charges, Clause 6 which
provides for 'Payment Schedule' under each of the heads mentioned therein against the milestones
defined thereunder, Clause 11 i.e. 'Time Schedule', Clause 16 i.e. 'Rights of Property', Clause 2 of
Annexure-II i.e. 'Application Group 1', Clause 3 i.e. 'Application Group 2' and Annexure-V at page
90 of the contract which provides for separate milestones in respect of each application.
21. Relying upon these provisions of the contract, it is submitted by the learned counsel that there
being a separate amount earmarked for each module, separate system of billing, separate amount
fixed for application AG-2, separate provision for testing of each application, separate acceptance
certificate, separate defect liability period and separate payment for each group would clearly
indicate that the contract ppn 9 arbp-275.12 (j).doc awarded to the petitioner was not an indivisible
contract and application AG-2 or other applications forming part of the said contract were not
dependent on each other applications. It is submitted that the applications of group 3 and 5 are
provided together under the contract. Abandonment of application AG-2 has not affected work of
the other modules. The respondent had abandoned the other two modules also.
22. The petitioner had issued a separate bill in respect of application AG-2 in accordance with the
separate milestone provided under the Agreement. The respondent had made substantial part of the
bill raised by the petitioner in accordance with the milestones achieved. It is submitted that
respondent had not disputed that even when the application AG-2 was abandoned by the
respondent, the respondent had released the payment in favour of the petitioner for the other
groups in respect of the works carried out subsequently. Works of other groups were continued by
the petitioner and accepted by the respondent. It is submitted that the works of other groups
continued even after abandonment of the application AG-2 and thus it is clear that the other
applications were separate and could be continued even without the application AG-2.
23. It is submitted that the findings of the arbitral tribunal that the contract awarded to the
petitioner was an indivisible contract and thus even if the application AG-2 was abandoned by the
respondent, cause of action had not arisen for making a claim in view of the work of other
applications going on which was part of such alleged indivisible contract is contrary to the terms of
the contract, contrary to the pleadings ppn 10 arbp-275.12 (j).doc of the respondent and shows
patent illegality on the face of the award.
24. It is submitted that the respondent could not dispute before the arbitral tribunal that out of five
applications, the respondent had abandoned three applications. The respondent could not
demonstrate before the arbitral tribunal that the work in respect of other three applications which
were abandoned by the respondent was completed by the respondent itself or by any other agency
and the entire project could be commissioned only after the work of all the applications under the
contract was over. It is submitted that the finding of the arbitral tribunal that the contract in respect
of AG-1 and AG-3 comprised in execution of the said project was completed in mid 2000, the causeCmc Ltd vs Unit Trust Of India on 6 February, 2015

of action in favour of the respondent herein to claim the compensation arose in June 2000 and thus
the claim was not barred by limitation is totally perverse and even contrary to the submission made
by the respondent.
25. It is submitted by the learned counsel that it was not the case of the respondent in the pleadings
or in the evidence that unless and until all the application groups dealt with different aspects of the
execution of the project were placed at one place together before the system could operate for
successful execution and operation of the said project, each application was inter-linked or related
with the other application group, the respondent could not have asserted the damage suffered, if
any, by the respondent. It is submitted that it was not the case of the respondent that all the
application groups were placed at one place together and were put in operation in mid 2000 and
only thereafter ppn 11 arbp-275.12 (j).doc the respondent could ascertain the actual loss suffered by
the respondent.
The learned arbitrator has considered the submission alleged to have been advanced across the bar
contrary to the pleadings and evidence on the issue of limitation and came to a conclusion that since
the contract was an indivisible contract, cause of action had not commenced till all the applications
were placed together for operation and execution. The arbitral tribunal has decided not in
accordance with what was submitted to the learned arbitrator by the parties.
26. Learned counsel for the petitioner submits that admittedly in this case, the respondent had
abandoned the application AG-2 on 14 th January 1997. The petitioner vide its letter dated 3rd
February 1997 had placed on record that the reasons for the delay could not be attributed to the
petitioner alone. The petitioner also placed on record that lot of development efforts would be
wasted due to decision of abandonment taken by the respondent.
27. It is submitted that the petitioner had incurred lot more expenses than originally contracted due
to the constantly changing requirements by the respondent. The petitioner placed on record that
inability of the respondent to use the software inspite of incorporation by the petitioner, the
necessary changes seem to be main reason for abandonment of the project. The petitioner also
placed on record that various bills raised by the petitioner on AG-2 Software Developmental Work
had remained unpaid by the respondent which bills were raised against approval from time to time
from the respondent based on achievement of agreed milestones. The petitioner contended that it
was necessary for the respondent to compensate the petitioner for the effort ppn 12 arbp-275.12
(j).doc put in by the petitioner for the development of AG-2 software. The petitioner requested the
respondent to depute people from its side for finalisation of the same to enable the petitioner to
raise total bills for that part of the project. Learned counsel also invited my attention to the report
on AG-2 forming part of the record which was Annexure to the said letter dated 16th October 1997.
28. There was no response to the said letter dated 16 th October 1997. The respondent by its notice
dated 13th February 2002 alleged that although AG-1 and AG-3 were implemented and completed
by the petitioner, AG-2 and AG-4 remained incomplete and were not implemented to the
satisfaction of the respondent. The petitioner did not commence implementation of AG-5 and AG-6
as AG-4 was left incomplete and unimplemented.Cmc Ltd vs Unit Trust Of India on 6 February, 2015

29. It is submitted that the notice invoking the arbitration agreement was issued admittedly on 13 th
February 2002 that is much after expiry of 3 years from the date of accrual of cause of action and
claims were thus ex facie barred by law of limitation. It is submitted that since the learned arbitrator
has allowed the time barred claim, the award is in conflict with the public policy. Under Section 43
of the Arbitration and Conciliation Act, 1996, all provisions of the Limitation Act, 1963 were
applicable to the arbitration proceedings also. The respondent itself had contended before the
learned arbitrator that its claim for refund the amount paid to the petitioner was in the nature of
claim for damages and would fall under Article 55 of the Schedule to the Limitation Act, 1963. It is
submitted that the alleged breach, if any, was thus committed much prior to the date of
abandonment of said application ppn 13 arbp-275.12 (j).doc of AG-2 by the respondent alleging
breaches. There was no further work of whatsoever nature carried out or required to be carried out
by the petitioner in so far as the application AG-2 was concerned. The cause of action for making a
claim for compensation arose when the alleged breaches had been committed by the petitioner that
is much prior to the date of abandonment. Limitation did not stop. Neither there was any part
payment made by the petitioner to the respondent nor any liability was acknowledged by the
petitioner. On the contrary, the petitioner had denied the said claim made by the respondent
immediately when the demand was made by the respondent.
30. It is submitted by the learned counsel that the finding of the learned arbitrator that the contract
was not terminated is also patently illegal and contrary to the evidence on record. The learned
counsel invited my attention to the deposition of the witness examined by the petitioner and in
particular his reply to the question no.108 when the respondent had put a suggestion to the witness
examined by the petitioner that the contract was terminated to which suggestion the witness
examined by the petitioner answered in affirmative but did not agree with the reasons of
termination. It is submitted that there was no provision for abandonment in the contract entered
into between the parties. The respondent had deliberately terminated the contract to deprive the
petitioner of the payment required to be made by the respondent under Clause 13.4 of the contract
for the work already carried out by the petitioner.
31. It is submitted by the learned counsel that the admitted fact that two other groups/applications
were also abandoned by the ppn 14 arbp-275.12 (j).doc respondent would also show that the
application AG-2 was a separate group/application by itself and there was no indivisible contract as
erroneously held by the learned arbitrator. It is submitted that the admitted fact that the payments
were made by the respondent for other groups subsequently and that work of the other groups was
continued though the work under application AG-2 was abandoned would also clearly indicate that
the contract awarded to the petitioner was not an indivisible contract.
32. It is submitted by the learned counsel that in so far as the counter claims made by the petitioner
were concerned, the learned arbitrator has rejected the entire counter claims without rendering any
reason. The findings rendered by the learned arbitrator are contrary to Clause 13.4 of the contract.
The claim nos.A and B made by the petitioner in the counter claims were for the work done. The
learned arbitrator could not have rejected the said counter claims made by the petitioner.Cmc Ltd vs Unit Trust Of India on 6 February, 2015

33. It is submitted that on one hand the learned arbitrator had rendered a finding that the time was
not an essence of the contract and on the other hand, had rendered an inconsistent finding that the
petitioner was allegedly responsible for the delay and allowed the claim for compensation made by
the respondent on that ground. The award shows inconsistency and contractions on the face of the
award.
34. The learned counsel submits that the payment of Rs.3,00,000/- made to the petitioner by the
respondent was for extra ppn 15 arbp-275.12 (j).doc work for preparing 18 reports and not for any
alleged changes in scope of work as erroneously held by the learned arbitrator which finding is
contrary to the deposition of Mr. Rawalgaonkar, witness examined by the petitioner.
35. The learned counsel for the petitioner also invited my attention to the plea raised by the
respondent in the written statement to the counter claims which was filed by the petitioner before
the learned arbitrator. It is submitted that even in such written statement to the counter claims,
while raising the plea of limitation, it was the case of the respondent itself that the said claims were
barred by law of limitation on the ground that the original cause of action in respect of each of the
claims were not a continuing cause of action. It is alleged in the written statement that all the
counter claims were claims for money in respect of the work and claims for recovery of damages on
account of alleged breaches by the respondent herein under the terms of the Agreement dated 23rd
October 1992 in respect of which the cause of action had arisen on a specific date and on a
happening of specific event.
36. My attention is also invited to paragraphs 4 and 13 of the written statement to the counter claims
in which the respondent had alleged that the counter claim of the petitioner herein was in respect of
application AG-2 which was altogether different application than AG1 and AG-3. It is alleged in the
written statement that application AG-2 was for investment and back office accounting whereas
AG-1 and AG-3 were different applications for sales and after sales services of the respondent
herein. It is submitted by the learned counsel that the ppn 16 arbp-275.12 (j).doc respondent itself
having accepted the application AG-2 as different altogether than AG-1 and AG-3, the respondent
could not have taken an inconsistent plea before the learned arbitrator that the contract awarded to
the petitioner was an indivisible contract and unless the work under application AG-2 would have
been completed and the work under other applications would have been also completed, the work
could not have been treated as completed and the system could not have been set up and
implemented. It is submitted that the learned arbitrator completely ignored this inconsistent and
contradictory stand taken by the respondent placed in the written statement to the counter claims
and argued across the bar before the learned arbitrator.
37. Learned counsel placed reliance on the judgment of the Supreme Court in the case of Hindustan
Zinc Ltd. Vs. Friends Coal Carbonisation, reported in (2006) 4 Supreme Court Cases 445 and would
submit that since the award is contrary to the terms of the contract and is patently illegal, it is
opposed and in conflict with public policy of India and thus this Court has an ample power under
Section 34 of the said Act for setting aside the impugned award. Reliance is placed on paragraphs 13,
14 and 24 of the said judgment which read thus :-Cmc Ltd vs Unit Trust Of India on 6 February, 2015

"13. This Court in Oil & Natural Gas Corporation Ltd. v.
Saw Pipes Ltd. [2003 (5) SCC 705] held that an award contrary to substantive
provisions of law or the provisions of the Arbitration and Conciliation Act, 1996 or
against the terms of the contract, would be patently illegal, and if it affects the rights
of the parties, open to interference by court under Section 34(2) of the Act. This
Court observed :
"The question, therefore, which requires consideration is whether the award could be
set aside, if the Arbitral ppn 17 arbp-275.12 (j).doc Tribunal has not followed the
mandatory procedure prescribed under Sections 24, 28 or 31(3), which affects the
rights of the parties. Under sub-section (1)(a) of Section 28 there is a mandate to the
Arbitral Tribunal to decide the dispute in accordance with the substantive law for the
time being in force in India. Admittedly, substantive law would include the Indian
Contract Act, the Transfer of Property Act and other such laws in force.
Suppose, if the award is passed in violation of the provisions of the Transfer of
Property Act or in violation of the Indian Contract Act, the question would be
whether such award could be set aside. Similarly, under sub-section (3), the Arbitral
Tribunal is directed to decide the dispute in accordance with the terms of the contract
and also after taking into account the usage of the trade applicable to the transaction.
If the Arbitral Tribunal ignores the terms of the contract or usage of the trade
applicable to the transaction, whether the said award could be interfered. Similarly, if
the award is a non- speaking one and is in violation of Section 31(3), can such award
be set aside? In our view, reading Section 34 conjointly with other provisions of the
Act, it appears that the legislative intent could not be that if the award is in
contravention of the provisions of the Act, still however, it couldn't be set aside by the
court. If it is held that such award could not be interfered, it would be contrary to the
basic concept of justice. If the Arbitral Tribunal has not followed the mandatory
procedure prescribed under the Act, it would mean that it has acted beyond its
jurisdiction and thereby the award would be patently illegal which could be set aside
under Section 34."
"31. .... in our view, the phrase "public policy of India"
used in Section 34 in context is required to be given a wider meaning. It can be stated that the
concept of public policy connotes some matter which concerns public good and the public interest.
What is for public good or in public interest or what would be injurious or harmful to the public
good or public interest has varied from time to time. However, the award which is, on the face of it,
patently in violation of statutory provisions cannot be said to be in public interest. Such
award/judgment/ ppn 18 arbp-275.12 (j).doc decision is likely to adversely affect the administration
of justice. Hence, in our view in addition to narrower meaning given to the term "public policy" in
Renusagar case it is required to be held that the award could be set aside if it is patently illegal. The
result would be award could be set aside if it is contrary to:Cmc Ltd vs Unit Trust Of India on 6 February, 2015

(a) fundamental policy of Indian law; or
(b) the interest of India; or
(c) justice or morality, or
(d) in addition, if it is patently illegal.
Illegality must go to the root of the matter and if the illegality is of trivial nature it cannot be held
that award is against the public policy. Award could also be set aside if it is so unfair and
unreasonable that it shocks the conscience of the court. Such award is opposed to public policy and
is required to be adjudged void."
14. The High Court did not have the benefit of the principles laid down in Saw Pipes (supra), and
had proceeded on the assumption that award cannot be interfered, even if it was contrary to the
terms of the contract. It went to the extent of holding that contract terms cannot even be looked into
for examining the correctness of the award. This Court in Saw Pipes (supra), has made it clear that it
is open to the court to consider whether the award is against the specific terms of contract and if so,
interfere with it on the ground that it is patently illegal and opposed to the public policy of India.
24. The appellant has given calculation fully and correctly which shows that the escalation was only
11,42,203.90. This was what was awarded by the trial court and this amount had been paid with
interest of Rs.12,75,442 in all Rs.24,17,646 on 6.2.1999. In spite of our directions on 21.3.2006, the
respondent has not given the actual calculations but has furnished only the final figure of claim. The
respondent's memo makes it clear that the respondent wants the escalation to be calculated for
supplies from 14.7.1992 with reference to the base price of washery grade II coal and not with
reference to washery grade I coal. This is impermissible. The order of the Division Bench is ppn 19
arbp-275.12 (j).doc unsustainable as it failed to interfere with the portion of the award which is
opposed to the specific terms of the contract. On the other hand, trial court had correctly decided
the matter."
38. The learned counsel for the petitioner also placed reliance on the judgment of the Division
Bench of this Court in the case of Hindustan Petroleum Corporation Ltd., Mumbai Vs. Batliboi
Environmental Engineers Ltd., Mumbai & Anr., reported in 2008 (2) Mh.L.J. 542 and in particular
paragraphs 9,13,14,15 and 18 which read thus :-
"9. Arbitrator is creation of the contract between the parties and he gets jurisdiction
under the terms of contract. He is expected to interpret and apply provisions of the
contract and pass an award accordingly. While passing the award he has to bear in
mind the provisions of Section 28 of the Act, which clearly provides that in case of
domestic arbitration in India, the Arbitral Tribunal shall decide the dispute in
accordance with substantive law for the time in force in India. If the Arbitrator
ignores the substantive law in force in India and passes an award, it is bound to cause
injustice Page 2449 and is liable to be set aside. For example law requires that theCmc Ltd vs Unit Trust Of India on 6 February, 2015

claim should be within limitation. If the award is passed on a claim, which is clearly
barred by the limitation, that will be against the provisions of law and the award can
not be sustained. In the present case, it is the contention of the petitioner that the
learned Arbitrator ignored the terms of the contract, relevant documents as well as
the provisions of Section 55 of the Contract Act and, therefore, the award is liable to
be set aside. It will be necessary to examine the record to find out in the light of this
contention.
13. On perusal of the record, it becomes clear that while the period of contract was to
expire on 26-3-1993, the contractor sought extension of time by letter dated
3-7-1993. Paragraph 1 of that letter is material which reads as follows:
"1. You are aware of the difficult period that we had gone through in the month of
December 1992, January 1993 and March 1993 due to riots. This difficult period ppn
20 arbp-275.12 (j).doc was followed by a labour strike in HPCL in the month of April
1993. A very good working period was lost due to force majeure conditions."
From this it is clear that delay was not on account of any latches on the part of petitioner. The
contractor himself accepted that very good working period was lost due to the force majeure
conditions and this was one of the grounds on which the time could be extended under the contract
and in such circumstances, no compensation could be claimed by the contractor merely because of
delay. Admittedly, as per this request, the petitioner extended time. Thereafter by letter dated 25th
August, 1994, the contractor sought further extension of time, explaining the difficulties and
circumstances. On this request, the petitioner extended time by further period of ten months by
letter dated 20th September, 1994. Admittedly, the contractor stopped the work on 31st March,
1996. However, on 4th July, 1996 the contractor addressed a letter to the petitioner pointing out the
causes of delay and by this letter for the first time, the contractor made a claim of Rs.
3,41,24,558/-on different heads including the loss of profits, overheads, expenditure on machinery,
etc. and thereafter on request of the contractor. The dispute was referred to the Arbitrator. From the
above record, it is clear that the contractor sought extension of time twice. First time, he clearly
contended that due to the force majeure conditions, work could not be done, while second time he
expressed certain difficulties faced and also sought time. In none of the letters seeking extension of
time, the contractor indicated that he would claim compensation for delay as required under Section
55 of the Contract Act. He had accepted the extension of time and carried out work upto 31st March,
1996 and admittedly, by that time 80% of the work was completed. It means he had carried on that
work and, that too, much beyond the agreed period of the contract without giving any notice or
indication that he would work beyond the agreed period of time only if he would be compensated for
the delay. As he has not given such indication, he could not claim any compensation on account of
delays.
14. The learned Single Judge noted that the petitioner had accepted the findings of the arbitrator
that delay was on ppn 21 arbp-275.12 (j).doc account of petitioner. However, the learned Counsel for
the petitioner rightly pointed out that in ground (iv) in the petition, the petitioner had contended
that the arbitrator had failed Page 2452 to note the correspondence, which would clearly establishCmc Ltd vs Unit Trust Of India on 6 February, 2015

that the respondent No. 1, i.e., the contractor was responsible for the delay and was therefore, liable
for liquidated damages. The learned Counsel also pointed out that in ground (tt) of the memo appeal
the petitioner/appellant have stated that the learned Single Judge erred in stating that the
appellants have not challenged the findings as to delay. We find substance in this contention of the
petitioner. The petitioner had consistently taken stand that the delay was caused by the contractor
while the contractor contended that the delay was on account of the petitioner. At least this was
raised by the contractor in the second letter seeking extension of time for completion of work.
Taking into consideration the correspondence between the parties, it is difficult to hold that the
delay was caused by the petitioner. At the same time it is also difficult to come to conclusion that the
delay was caused by the contractor alone. First letter of the contractor clearly shows that delay was
on account of force majeure, which was beyond the control of both the parties. In view of the terms
of the contract, the contractor could not claim any compensation on account of delay, which could
not be attributed to the petitioner and particularly he could not claim this compensation when he
had carried on the work beyond the period of contract without indicating that he would proceed
with the work beyond the period of contract only if he is compensated for delay. It is material to note
that the contractor himself sought extension of time for carrying on the work, therefore, in our
considered opinion, the contractor could not claim any compensation on account of loss of profits or
loss of overheads due to delays.
15. It is material to note that total cost of the work was Rs. 474 lakhs and 80% of the work was
admittedly completed for which the payment was also made. Thus, when the work was stopped or
abandoned by the contractor, only 20% of the work was remaining and the cost of the 20% work was
only Rs. 114.80 lakhs. If the contractor would have completed the work, he would be entitled to
receive Rs. 114.80 lakhs and according to his own contention and as per the assessment made by the
arbitrator, he would be getting 10% on account of overheads ppn 22 arbp-275.12 (j).doc and 10% on
account of profits. Thus, the gain of the contractor would be 20% of the said amount, which would
be only Rs.
22.96 lakhs. Against this the Arbitrator awarded Rs. 1,57,37,666/- which is much more than 20% of
even the total contract money and, therefore, it can be said that compensation awarded by the
arbitrator was infact arbitrary against the terms of the contract and perverse and, therefore, it may
be held that he acted beyond his jurisdiction. It can not be termed as a mere error within
jurisdiction.
18. Taking into consideration the terms of the contract, legal provisions and the award passed by the
learned Arbitrator, it is clear that the award is clearly against the terms of the contract, provisions of
law and infact, it is perverse and can not stand judicial scrutiny. In our considered opinion, the
award is liable to be set aside. At the same time, we may also note that the petitioner is also not
entitled to any counter claim on account of any delays on the part of the contractor as the petitioner
had extended time on request of the contractor and that too without indicating that the petitioner
would claim any compensation as required under Section 55 of the Contract Act. Though there was
provision in terms of the contract for liquidated damages, in fact as pointed out above, the petitioner
also could not establish that delay was only on account of the contractor. In view of the above, the
appeal deserves to be allowed and the impugned judgment and the award are liable to be set aside."Cmc Ltd vs Unit Trust Of India on 6 February, 2015

39. Mr.Sen, learned senior counsel for the respondent on the other hand submits that the question
whether the contract awarded to the petitioner was indivisible contract or not is a mixed question of
fact and law. The learned arbitrator has rendered a finding of fact after considering the evidence on
record and on interpretation of the terms of the contract and thus this court cannot interfere with
such finding of fact and cannot substitute a possible interpretation of the terms of the contract by
the learned arbitrator with another interpretation. It is submitted that the application AG-1, AG-2,
AG-3 and AG-5 forming part of the contract ppn 23 arbp-275.12 (j).doc awarded to the petitioner
were interlinked and all four links were must for system to work. In support of this submission,
learned senior counsel submitted a chart and submits that there was organic connection between all
the four applications and unless the work under all the four applications were complete, the system
would not work. It is submitted that since application AG-2 was abandoned by the respondent for
the reasons attributable to the petitioner, the entire system could not work without completion of
the application AG-2. It is submitted that merely because respondent ultimately took the application
AG-2 from outside or completed the same departmentally, it would not make any difference on the
issue whether the contract awarded to the petitioner was indivisible contract or not.
40. Learned senior counsel placed reliance on the judgment of Supreme Court in case of
G.Ramachandra Reddy and Company vs. Union of India and another (2009) 6 SCC 414 and in
particular paragraph 19 and submits that the award containing reasons cannot be interfered with
unless the reasons are found to be perverse or based on a wrong proposition of law and if two views
are possible, it is trite, the Court will refrain itself from interfering. Paragraph 19 of the said
judgment in case of G.Ramachandra Reddy and Company (supra) reads thus :-
"19. We may, at the outset, notice the legal principles gov- erning the dispute between
the parties. Interpretation of a contract may fall within the realm of the arbitrator.
The Court while dealing with an award would not reappreciate the evidence. An
award containing reasons also may not be interfered with unless they are found to be
perverse or based on a wrong proposition of law. If two views are possible, it ppn 24
arbp-275.12 (j).doc is trite, the Court will refrain itself from interfering. (See State of
U.P. v. Allied Constructions.)"
41. It is submitted by the learned senior counsel that the work of applications AG-1 and AG-3 was
completed by the petitioner. The work under AG-4 and AG-5 was abandoned by the respondent.
There was no dispute about such abandonment of AG-4 and AG-5. The work under AG-2 was also
subsequently abandoned which is subject matter of this dispute.
42. Learned senior counsel submits that since the contract awarded to the petitioner was indivisible
contract, merely because the work under AG-2 was abandoned in 1997, it was not mandatory for the
respondent to make the claim of refund of the amount within three years from the date of such
abandonment but since the work under other applications was going on, the respondent could wait
for filing arbitration proceedings till the other work was over and the system was commissioned. It
is submitted that the learned arbitrator has thus rightly held that merely because payment in respect
of application AG-2 was made by the respondent to the petitioner and the said work was incomplete
and/or having found defective, since other work were pending, the respondent was not bound toCmc Ltd vs Unit Trust Of India on 6 February, 2015

invoke arbitration clause when the dispute arose only in respect of part of the work. It is submitted
that the finding of the learned arbitrator that the work was completed in the middle of 2000 and
thus application for appointment of arbitrator having been made on 16th January, 2012 is within
time is a finding of fact and no interference is warranted. In support of this submission, learned
counsel strongly placed reliance on the following judgments :-
1. Judgment of Lahore High Court in case of Goenka Cotton ppn 25 arbp-275.12
(j).doc Spinning and Weaving Mills Ltd. vs. Messrs. Duncan Stratton and Co., AIR
1938 Lahore 277;
2. Judgment of Lahore High Court in case of Basheshar Lal-Bansi Dhar vs.Bhik Raj
and others, Indian Law Reports 1930 XII 254;
3. Judgment of Lahore High Court in case of Chhote Lal Ambay Prasad vs. Nathu Mal
Miri Mal, AIR 1930 Lahore 193(2); and
4. Judgment of Lahore High Court in case of Ganesh Das-Ishar Das vs. Ram Nath
and others, 1927 Indian Law Reports IX 148.
43. It is submitted by the learned senior counsel that though the respondent had raised a plea of
limitation in respect of counter-claim of the petitioner on the ground that the application AG-2 was
different than the other applications and the counter claims made by the petitioner herein were
barred by law of limitation as the cause of action in respect of the said claims for work done and for
damages occurred on a particular date, no reliance on such plea raised in the written statement to
the counter claims can be made by the petitioner since the said plea was not pursued before the
learned arbitrator by the respondent. It is submitted that the learned arbitrator has not rejected the
counter claims on the ground of limitation and thus no cognizance of such plea though raised in the
written statement to the counter claims can be taken by this Court or can be relied upon by the
petitioner in this petition.
44. In so far as the submission of the learned counsel that there was no provision for claiming any
refund under the contract awarded to the petitioner is concerned, it is submitted by the learned
senior counsel that the respondent had not terminated the contract and had made the ppn 26
arbp-275.12 (j).doc claim for refund of the amount paid to the petitioner for application AG-2, since
the work done by the petitioner for such application was of no use to the respondent and being not
in accordance with the specifications provided under the terms of the contract. It is submitted that
the said claim was permissible under Section 55 read with Section 73 of the Indian Contract Act,
1872. It is submitted that Clause 13.4 of the contract would not apply and thus claim for
compensation made by the respondent herein was not contrary to Clause 13.4 of the contract. It is
submitted that since the application AG-2 was tested and was found unworkable and not as per the
specifications and the petitioner had committed breach of its obligation under the contract, the
respondent was entitled to recover the amount paid by the respondent to the petitioner for such
incomplete and defective work. It is submitted that in any event, in view of the learned arbitrator
having rendered a possible view, no interference under Section 34 of the said Act is permissible.Cmc Ltd vs Unit Trust Of India on 6 February, 2015

45. In so far as the oral evidence relied upon by the learned counsel for the petitioner to show that
even according to the respondent, there was a termination of the contract is concerned, it is
submitted by the learned senior counsel that the findings of the learned arbitrator on this issue are
express and clear that there was no termination of AG-2 which finding is rendered after considering
the oral evidence led by the parties and thus no interference with such findings of facts is
permissible under Section 34 of the said Act.
46. There is no ground raised by the petitioner under Section 34 in this petition or raised any issue
before the learned arbitrator about the plea raised by the respondent in the written statement to the
counter ppn 27 arbp-275.12 (j).doc claims or that such plea was inconsistent with the submission
made by the respondent before the learned arbitrator.
47. In so far as the period for which interest awarded to the respondent is concerned, it is submitted
by the learned senior counsel that though the respondent had claimed interest with effect from 1997,
the learned arbitrator has awarded interest from 31 st July 2007 and thus that part of the award
would not indicate that the claims made by the respondent with effect from 1997 were barred by law
of limitation.
48. In so far as the limitation under Article 55 of the Schedule to the Limitation Act, 1963 is
concerned, learned senior counsel submits that the old Article i.e. Article 115 which was in pari
materia with Article 55 of the Limitation Act, 1963 has already been considered by the Lahore High
Court in the judgments referred to and relied upon by the respondent and followed by the learned
arbitrator. It is submitted that the judgments of the Lahore High Court are applicable to the facts of
this case and shall be considered by this Court.
49. In the rejoinder, Ms.Ghone, learned counsel for the petitioner submits that in the counter claims
of the petitioner, though the petitioner had alleged that there was a termination of the contract
specifically, the respondent has not denied the plea of termination in the written statement to the
counter claims. It is submitted that though the learned arbitrator has awarded interest with effect
from 31 st July 2007, the fact remains that in the notice dated 13th February 2002 issued by the
respondent invoking arbitration agreement, the respondent had demanded ppn 28 arbp-275.12
(j).doc interest with effect from 14th January 1997 which itself would indicate that the cause of
action had arisen on 14th January 1997.
50. It is submitted by the learned counsel that since the so called interpretation of the learned
arbitrator on the terms of the contract is an impossible interpretation and the findings rendered by
the learned arbitrator are perverse, this Court has an ample power under Section 34 of the said Act
to interfere with such award to set aside the same on the ground of the award being in conflict with
the public policy.
51. The arbitral tribunal framed eight points for consideration, including the issue whether claims
made by the respondent (original claimant) and counter claims made by the petitioner (original
respondent) were barred by law of limitation and have answered the same in the impugned award in
accordance with law. While holding that the claims made by the respondent herein were barred byCmc Ltd vs Unit Trust Of India on 6 February, 2015

law of limitation, the arbitral tribunal rendered a finding that the contract entered into between the
parties was indivisible contract. I shall first decide whether the finding rendered by the arbitral
tribunal that the contract awarded to the petitioner was indivisible is contrary to the terms of the
contract or not. I shall first refer to some of the relevant provisions of the contract entered into
between the parties which are relied upon by parties.
52. The petitioner was awarded the job of "Technology Upgrade Project of UTI" of the respondent
comprising of project management software development, networking, training and implementation
support on the terms and conditions recorded in the said agreement. Under clause ppn 29
arbp-275.12 (j).doc 1.5 of the contract, "Application Group" has been defined. According to the said
definition, the application group shall mean each individual system as described under Annexure -
II to be developed by the petitioner relating to four groups. Insofar as the dispute which is the
subject matter of these proceedings are concerned, it relates to application group 2 (AG-2). Under
the heading "Application Group 2" it is provided as under :-
"Dept of Market Operations, Dept of Investments, Dept of Accounts and Resource
Management."
Under clause 1.9, it is provided that implementation milestones shall mean the schedule of dates of
completion of preconceived activities, relating to the project, and as described in Annexure - V.
Annexure - V provides for a format for individual activities under each application group in Phase-I.
Various activities of each application group required to be completed in each phase is also provided
under the contract. Insofar as AG-2 is concerned, in phase-I, it is provided that the said application
would be ported on systems at corporate office only in phase-I.
53. Clause 2.2.5 of the contract provides for acceptance test procedure for application groups. Under
clause 2.2.6, it is provided that upon completion of development including testing of each
application group, the petitioner shall intimate the respondent in writing that the said application
group is ready for acceptance testing. The respondent shall carry out the acceptance test with the
help of the petitioner to demonstrate and confirm that the application group has been completed
and was capable of performing in substantial conformity with the approved SRS.
ppn 30 arbp-275.12 (j).doc On successful completion of the above testing of the application group,
the said application group will be construed to be delivered to the respondent. It is provided that
subsequent to the acceptance of the application group, the petitioner shall install the respective
application group on the equipment of the respondent. Upon such installation , the respondent shall
test each application group in a manner specified in this SAP within three calender weeks. On
completion of the testing and substantial conformity of the test results with the SRS, the application
group will be construed as accepted and UTI shall issue a certificate of acceptance.
54. Clause 2.2.7 provides for defect liability period for application groups. Clause 3 provides for
charges payable by the respondent to the petitioner for services provided under phase-I of the
project as per the schedule described in clause 6 of the said agreement.Cmc Ltd vs Unit Trust Of India on 6 February, 2015

The amount agreed to be paid by the respondent to the petitioner for the services provided under
phase-I was at Rs.325 lakhs.
55. Under clause 6 of the contract, the respondent has provided the break up of the payment
schedule for separate activities under phase- I. It is provided that the charges for phases - II, III and
IV would be submitted later and will form part of the said agreement. All advances shall be adjusted
on a pro-rata basis at each milestones mentioned above.
56. Clause 11 of the contract provides for time schedule in respect of various activities covered under
the said agreement. Clause 13 of the contract provides for termination, which is extracted as under :-
     ppn                                     31                         arbp-275.12 (j).doc
                   "TERMINATION
13.1 Either party shall have the right to terminate this agreement upon 30 days written notice to the
other upon :
i. violation or breach by the other or its employees or agents, of any provision of this
agreement. ii. in the event no agreement is reached between CMC and UTI as to the
SRS', or any problems in or relating to SRS' are not resolved to their mutual
satisfaction within 30 days of such problems being identified.
iii. any disputes, that cannot be resolved, arising which prevents the other from
fulfilling its obligations.
13.2 On mutual agreement or convenience.
13.3 In the above circumstances, this agreement shall be terminated as provided in
such with no additional obligations or liabilities.
13.4 In the event of termination UTI shall be liable to pay to CMC the charges for the
work completed by CMC,as per the rates mentioned in Clause 3.0. CMC shall return
all the documents / materials received from UTI for development of Application
Groups."
Clause 16.1 provided that the application groups development will be owned jointly by the petitioner
and the respondent with the petitioner having marketing rights to it. Clause 20 of the contract
provides for arbitration.Cmc Ltd vs Unit Trust Of India on 6 February, 2015

57. Annexure - II provides for scope of the application groups development which states that the
scope of the application software has been categorized into six groups which were to be referred as
application groups 1 to 6. Insofar as the application group 2 is concerned, the scope of that
application is provided in clause 3 , at pages 75 to 77 of the ppn 32 arbp-275.12 (j).doc contract.
Clause 3 which is relevant for the purpose of deciding this arbitration petition is extracted as under
:-
"APPLICATION GROUP 2 :
3. This group addresses the functions of Funds Management, namely, Dept. of
Market Operations, Dept. of Investments, and Dept. of Accounts and Resource
Management. The applications will be ported on systems at corporate office only in
the Phase I."
58. Similarly the scope of the work of other application groups required to be carried out in the first
place is provided therein. It is not in dispute that the respondents themselves had abandoned the
development job application groups 4 and 5 also forming part of the said project awarded to the
petitioner much earlier. It is also not in dispute that the petitioner had completed the development
to AG-1 and AG-3 which was also forming part of the scope of the work under the contract awarded
to the petitioner.
59. It is not in dispute that there were number of letters exchanged between the parties in respect of
AG-2. It was the case of the respondents that the petitioner had not carried out AG-2 work in
accordance with the milestones provided under the contract and the petitioner was granted
extension for completing the said application group. Various minutes of the meetings were drawn by
the parties which were recording the discussions only in respect of the work carried out under AG-2.
The respondents had carried out the test and allegedly found that the AG-2 developed by the
petitioners was not in accordance with the specifications of the contract and accordingly took a
decision to ppn 33 arbp-275.12 (j).doc abandon the said AG-2. The respondents relied upon such
minutes of the meetings before the arbitral tribunal to indicate that the test was carried out prior to
14th January, 1997 and alleged that based on such test, it was found that AG-2 provided for the
petitioner was not in accordance with the specifications and other provisions of the contract.
60. It is also not in dispute that in accordance with the provisions of the contract, the petitioner had
raised the separate invoices in respect of the work carried out under AG-2 and which were released
separately by the respondents. It is also not in dispute that though AG-2 was treated as abandoned
by the respondents by a letter dated 14 th January, 1997, the work under AG-1 and AG-3 continued
by the petitioner and various payments in respect thereof were made by the respondents to the
petitioner. It is also not in dispute that though the respondents themselves had abandoned the work
under AG-4 and AG-5, the project of the respondents continued and such abandonment of AG-4 and
AG-5 did not affect the entire work. Even when AG-2 was abandoned by the respondent on 14th
January, 1997, the work of AG-1 and AG-3 continued till the middle of 2000.Cmc Ltd vs Unit Trust Of India on 6 February, 2015

61. I will deal with some of the pleadings and evidence to consider whether it was the stand of the
respondents at any point of time that the entire work awarded to the petitioner was under an
indivisible contract or whether the scope of AG-2 which is the subject matter of these proceedings
was an independent scope of the work and had nothing to do with and/or other part of the work and
completion of the other application group could be dependent only on successful completion of
AG-2 or not.
ppn 34 arbp-275.12 (j).doc
62. In the statement of claim filed by the respondents before the learned arbitrator, it is averred by
the respondents that the claim was filed for recovery of moneys paid by the respondents to the
petitioner and for further damages on account of losses suffered by the respondents as a result of
repudiatory and fundamental breach of the terms and conditions of the said agreement. It has been
alleged that the application of AG-2 and AG-3 delivered by the petitioner to the respondents were
not as per the specifications required by the respondents and had serious technical software and
drastic defects. It was averred that the agreement was divided into various phases and each phase
provided for completion of certain predetermined work as contemplated by the agreement.
63. In paragraph 26 of the statement of claim, it was averred that although as per the initial agreed
time schedule, AG-2 development that was part of phase-I had to be installed at the corporate office
by October, 1993, until the middle of 1996, AG-2 applications were not developed and as a result of
the time overrun, the respondents convened various internal meeting to ascertain the status of the
AG-2 applications, which meetings in fact recognized that one of the reasons for the delay was the
respondents inexperience with finance and frequent change of hands.
64. It is also averred that the claims of the petitioner that the money market operations module of
AG-2 had been in operation since February, 1995 were falsified by the tests/reviews carried out by
the Systems Department of the respondents which results were documented ppn 35 arbp-275.12
(j).doc in the minutes of meeting dated 18th October, 1996 which clearly indicated that even in
relation to the single module of money market operations only 49 out of 109 functions /
sub-modules were working as per the requirements, and a substantial part of the functions / sub-
modules were not working at all. It was urged that on 24 th October, 1996, the system department of
the respondents carried out a review of the development of the primary market operations of
module of AG-2 and the reports also indicate that only 8 out of 58 of the functions / sub-
modules were developed in compliance with the requirements of the respondents.
65. It was urged that on 13th November, 1996, a detailed status report was prepared by the
respondent pursuant to an exhaustive test of the money market operations applications / modules
of AG-2 and it was found that the said applications were woefully flawed, erroneous and incomplete
in their development. It was found that out of 17 functionalities which were earlier found to be non
usable, 8 of them continued to remain unacceptable. It was alleged that the respondent had never
been able to use the AG-2 successfully and the respondents have not used AG-2 for development or
usage of any other software application of whatsoever nature.Cmc Ltd vs Unit Trust Of India on 6 February, 2015

66. In paragraph 37 of the statement of claim, it was alleged that after presentation / discussions
took place, the petitioner had addressed a letter to the respondents stating that it was not possible to
commence the parallel run / user test of AG-2 in its entirety by 1 st April, 1997. It was ppn 36
arbp-275.12 (j).doc averred that in view of the same and in conjunction with the results of the earlier
tests, the results of which establish inadequacy and non- usability of AG-2 applications, the
respondents at the end of December, took an internal decision not to go ahead with the said AG-2
development with the petitioner. It was also averred that the other applications covered by the said
agreement were continued to be developed by the petitioner and thus decision not to proceed with
the development of AG-2 did not amount to a termination of the agreement as the other aspects of
work covered under (AG-1 and AG-3) were to be continued with by the petitioner.
67. On 14th January, 1997, the respondents had addressed an important letter to the petitioner
setting out the defaults committed by the petitioner in the development of AG-2 and conveyed that
the respondent was forced for the situation of abandoning the project due to the non-
delivery of the working software. It was averred that the project abandoned by the said letter was
not the entire IT upgrade project, covered by the said agreement, but only AG-2 module, which was
a discrete part of the larger agreement. The other aspects of software development under the larger
agreement continued despite the failure of the petitioner to complete and deliver AG-2 module. The
respondents by a letter dated 29th August, 1997 called upon the petitioner to refund the fees paid to
it for development of AG-2 as the same was abandoned. It is not in dispute that the petitioner
denied the said claim and demanded the payment for the work done by the petitioner under the said
AG-2 and also claimed compensation for the year 1997 itself.
ppn 37 arbp-275.12 (j).doc
68. In the affidavit in lieu of examination in chief of Mr.Sanjeevan Shirke, examined by the
respondent, the witness deposed that as per the time schedule stated in Annexure - V, AG-2
development that was part of phase - I, had to be installed in the corporate office by October, 1993,
which was grossly violated by the petitioner and there was enormous delay in actual implementation
of AG-2. It is also deposed that the software developed by the petitioner as AG-2 was defective and
failed on many counts as was ascertained in the per-installation, checks run by the respondents. The
forms / programs, which were tested by the respondents were unable to provide desired out-put,
there was serious discrepancy in the test out-put data.
69. It was deposed by the said witness that the total consideration to be paid by the respondents to
the petitioner for the work done under phase-I was Rs.3.25 crores. Of the amount that was paid
towards phase-I, the amount of Rs.83.455 lakhs was paid towards the development of modules
forming part of AG-2, of which a refund was being sought by the respondent due to complete
non-conforming nature of the said products in breach of specification requirements under the
agreement and understanding between the parties. In paragraph 13 of the said affidavit, it was
deposed that since the petitioner did not adhere to the time schedule agreed as per the said
agreement for the development of AG-2 that was part of phase-I, which had to be installed in the
corporate office of the respondents by October, 1993 and since the same was not developed untilCmc Ltd vs Unit Trust Of India on 6 February, 2015

middle of 1996, the said inordinate delay in implementation of the project resulted in tremendous
financial loss to the respondents and the entire purpose of the project was almost defeated.
ppn 38 arbp-275.12 (j).doc
70. In paragraph 25 of the said affidavit, the witness deposed that in conjunction with the results of
the earlier tests, which established the inadequacy and non-usability of AG-2 applications, it was
decided by the respondents not to go ahead with the said AG-2 development with the petitioner
which decision was restricted to AG-2 alone and the said agreements were continued to be
developed / supported by the petitioner and the decision not to proceed with the development of
AG-2 did not amount to termination of the whole agreement as the other aspects of the work
covered by the agreement (AG-1 and AG-3) were to be continued by the petitioner. In paragraph 27
of the affidavit, it was deposed that the project that was abandoned by the letter dated 14th January,
1997, was not the entire IT upgrade project, covered by the said agreement, but only the AG-2
module, which was a discrete part of the larger agreement. The other aspects of the software
development / supported under the larger agreement (in particular AG-1 and AG-3) were continued
despite failure of the petitioner to complete and deliver the AG-2 module which development and
implementation of AG-1 and AG-3 was completed in the middle of the year 2000.
71. In paragraph 30 of the said affidavit, the witness deposed that by a letter dated 16th October,
1997, the petitioner had falsely and wrongly asserted that they had developed AG-2 as per the
specifications of the respondents and called upon the respondents to pay the alleged unpaid bills so
as to compensate the petitioner for their development of AG-2. In paragraph 36 of the affidavit, it
has been deposed that the respondents had suffered substantial and direct losses as a result of ppn
39 arbp-275.12 (j).doc various breaches committed by the petitioner.
72. The petitioner had also filed a counter claim before the arbitral tribunal inter-alia praying for
various amounts, including for the work done under AG-2 and not paid by the respondents and also
for loss of profit, loss of reputation etc. In paragraph 21 of the counter claim, the petitioner had
averred that the cause of action had arisen on 14 th January, 1997 which continued when the
petitioner in good faith tried to settle the dispute between the parties amicably between 1999 and
2000. It was averred that the cause of action being continuous one and continued day to day till the
petitioner received all the amounts due and payable by the respondents to the petitioner, the claims
made by the petitioner were within time.
73. The respondents filed a written statement to the counter claim before the arbitral tribunal. In
paragraph 4 of the written statement to the counter claim, the respondents denied the averments
and submissions made by the petitioner in paragraph 21 of the counter claim on the issue of
limitation, including the averment that the original cause of action in respect of each of the claims
was continuing cause of action. In the said paragraph, the respondents averred that all the counter
claims made by the petitioner were claims for money in respect of the work and the claims for
recovery of damages on account of the alleged breaches by the respondents under the terms of the
agreement. It is contended by the respondents that in respect of each of those claims, as was
apparent from the averments made in the counter claim itself, the cause of action had ppn 40Cmc Ltd vs Unit Trust Of India on 6 February, 2015

arbp-275.12 (j).doc arisen on a specific date and on happening of specific event and accordingly the
period of limitation must be determined. In paragraph 13 of the said written statement, the
respondents contended that the claim of the respondents was in respect of AG-2 which was
altogether different application than AG-1 and AG-3. AG-2 application was for investment and back
office accounting, whereas AG-1 and AG-3 were different applications for sales and after sales
services of the respondent.
74. In paragraph 28 of the written statement, the respondents contended that the letter dated 15th
April, 1996, which was addressed by the respondents to the petitioner was addressed at a time
before which the respondent was aware of the serious defects and breaches committed by the
petitioner in respect of its obligations in implementing the software programme developed by it in
the business system of the respondents.
75. In the counter claim, the petitioner had also alleged that the said AG-2 was terminated by the
respondents. However, the said averment of the petitioner has not been denied by the respondents
in the said written statement.
76. A perusal of the provisions of the contract entered into between the parties thus clearly indicates
that the scope of the work awarded to the petitioner by the respondents was in parts and covered by
separate application groups and were to be completed phase-wise in accordance with the separate
milestones stipulated under the contract. The contract provided for separate payment in respect of
each application ppn 41 arbp-275.12 (j).doc group in accordance with the milestones provided. It is
common ground that the petitioner issued separate bills in respect of each application group carried
out by the petitioner and were paid separately by the respondents. It is also common ground that
the respondents had already abandoned the work under AG-4 and AG-5 much earlier which was
also part of the contract awarded to the petitioner. It is not in dispute that there was a separate
correspondence and minutes of the meeting recorded by the respondents alleging various delays on
the part of the petitioner in completion of AG-2 in accordance with the milestones provided under
the contract and also alleging the defective work of the petitioner of the said AG-2 and not being in
accordance with the specification provided under the contract.
77. The respondents had carried the tests from time to time in accordance with the said provisions of
the contract and had come to the conclusion that the said AG-2 carried out by the petitioner was not
in accordance with the specification of the contract and was not completed within the milestones
agreed and was of no use to the respondents. All such tests and discussions had already taken place
much prior to 14 th January, 1997 when the respondents took a final decision to address a letter to
the petitioner purporting to abandon the work under AG-2. It is not in dispute that after addressing
a letter on 14 th January, 1997, the respondents did not carry out other tests in respect of the work
carried out by the petitioner under AG-2 after completion of other application group i.e. AG-1 and
AG-3. It is also not in dispute that though the work under AG-2 was purported to have been
abandoned by the respondents, the respondents themselves permitted the petitioner to continue the
work ppn 42 arbp-275.12 (j).doc under AG-1 and AG-3 considering the same as an independent and
separate work not interconnected with the work under AG-2 and/or not dependent on the successful
completion of AG-2.Cmc Ltd vs Unit Trust Of India on 6 February, 2015

78. The respondents themselves had raised a demand for recovery of the amount paid to the
petitioner for AG-2 immediately after the letter dated 14th January, 1997 and did not wait for raising
such demand till completion of work under other two application groups i.e. AG-1 and AG-3 in the
middle of 2000.
79. The statement of claim, affidavit in lieu of examination filed by the witness examined by the
respondents and also the written statement filed by the respondents to the counter claim made by
the petitioner clearly indicates that it was the stand of the respondents all though out that the work
under AG-2 was a part of the entire contract and even though the same was abandoned, the other
work under AG-1 and AG-3 could be continued independently. The respondents itself while
opposing the impugned claims made by the petitioner had taken a stand that the work under AG-2
was altogether different than AG-1 and AG-3.
It was the case of the respondents themselves that AG-2 application was for investment and back
office accounting, whereas AG-1 and AG-3 were different applications for sales and after sales
services of the respondent.
It was the case of the respondents itself that the work under AG-2 was to be installed at different
places and was to be completed only in phase-I. Inspite of all these clear stand of the respondents in
the pleadings as well as the evidence led by the respondents, the arbitral tribunal has not only
permitted the respondents to take a different and contradictory stand than what was pleaded and
deposed in the evidence to the effect that the entire ppn 43 arbp-275.12 (j).doc contract awarded to
the petitioner, including AG-2 was indivisible contract and successful completion of the entire
project was dependent upon the successful completion of AG-2 but has accepted such inconsistent
and contradictory stand of the respondents.
80. A perusal of the impugned award indicates that the learned arbitral tribunal has rendered a
finding contrary to the pleadings and evidence of the respondents themselves and has held that the
said contract was indivisible contract and unless all the application groups dealing with the different
types of execution of the project had been placed at one place altogether before the system could
operate, the respondents could not have ascertained whether there was any damages suffered by the
respondents or not. In my view the learned arbitral tribunal has not decided in accordance with
what is submitted by the parties before the learned arbitral tribunal and has taken a decision
contrary to and overlooking the stand of the respondents. The impugned award thus being contrary
to the terms of the contract and overlooking the evidence led by the parties and is in conflict with
the public policy.
81. The question that now arises for consideration is whether the view of the arbitral tribunal
holding that the contract was indivisible contract and consequently the claims made by the
respondents were within time holding that the cause of action would have arisen only when the
other application groups i.e. AG-1 and AG-3 were completed in the middle of the year 2000 is
patently illegal or not. In my view, since the finding of the arbitral tribunal that the contract was
indivisible contract itself being patently illegal and contrary to the terms of the contract, ppn 44
arbp-275.12 (j).doc consequently the finding of the learned arbitral tribunal that the cause of actionCmc Ltd vs Unit Trust Of India on 6 February, 2015

would arise only on completion of AG-1 and AG-3 in the middle of the year 2000 is also patently
illegal and contrary to law.
82. On the issue of limitation, the arbitral tribunal has held that the cause of action began to run at
the end of the completion of the contract i.e. middle of June, 2000 and thus the notice invoking the
arbitration issued in the year 2002 was within time and not barred by law of limitation. The arbitral
tribunal has overlooked the correspondence exchanged between the parties, including the letter of
demand of the respondents asking the petitioner to refund the amounts paid by the respondents to
the petitioner under AG-2, which was by a letter dated 29 th August, 1997 and denied by the
petitioner immediately. The arbitral tribunal did not render any finding as to how the cause of
action which had already commenced in the year 1997 was postponed till 2002. The arbitral tribunal
also overlooked the stand of the respondents themselves opposing the counter claim made by the
petitioner on the ground that the cause of action was not continuing cause of action. The averments
made by the petitioner in paragraph 21 of the counter claim in respect of limitation was denied by
the respondents in toto. The arbitral tribunal, in my view, could not have overlooked and ignored
the contentions / submissions made by the respondents themselves on the plea of limitation. The
award shows patent illegality on the face of the award on the issue of limitation and the issue
whether the contract was indivisible or not is concerned.
83. Though the arbitral tribunal had framed a point for determination that 'whether the counter
claims made by the petitioner ppn 45 arbp-275.12 (j).doc were within time or not', in the entire
award, the arbitral tribunal has not dealt with the issue of limitation in respect of the counter claims
made by the petitioner.
84. The arbitral tribunal while rejecting the plea of limitation raised by the petitioner in respect of
the claims made by the respondents referred to and relied upon by the Lahore High Court in the
impugned award.
85. The relevant parts of the judgment of the Lahore High Court, which are relied upon by the
respondents and followed by the learned arbitral tribunal are extracted as under, for the purpose of
considering whether those documents are at all relevant to the facts of this case or not :
1) Goenka Cotton Spinning & Weaving Mills Ltd vs. M/s.Duncan Stratton & Co. AIR
1938, Lahore 277 -
"The first point argued was limitation. Admittedly the Article applicable is 115 of the
Limitation Act and the period three years from the date of the breach. The Senior
Subordinate Judge held that the plaintiffs' order was an order for separate pieces of
machinery and time would run with regard to each machine as and when it was
delivered. Nearly all the machinery was delivered in Bombay more than three years
before the institution of the suit, and if it were held that time ran from delivery at
Delhi, there was no evidence on that point. The suit regarding the engine and the
mangle was also barred by time; only the claim for accounts was within time.Cmc Ltd vs Unit Trust Of India on 6 February, 2015

Mr. Mehr Chand Mahajan for the appellants argued that the suit was within time
because the order for the machinery was single and indivisible and because there was
also unity of object. The dealings began by the plaintiffs, on 2nd December ppn 46
arbp-275.12 (j).doc 1919, (V. 3) informing the defendants that they wished to erect a
weaving shed for three hundred looms and asking them to send a complete
specification for the same. The replies are the specifications of 12th and 13th January
1920, printed at pp. 4 to 15 of Vol. V. and covered by a single letter of 13th January
1920 (V. 15, 16). The first estimate is for an engine, Lancashire boiler, fire service
pumps, humidifier pump and articles for the mechanic's shop. The second estimate
was for saturating machine, kiers, chemicking machine, water mangle and starch
mangle. The third estimate was for a calendar and the baling press. The covering
letter gave the total price of these as £18,026-16-6 and laid down that the plaintiffs
should "pay one-third in advance with the order, and will hand us within the next ten
days a sterling demand draft for £6000." The clause about payment seems to me to
show conclusively that the order was regarded as a single whole and that time would
run only from the date of the last delivery. Admittedly, part of the engine was
delivered within three years of the suit and the suit is therefore within time."
2) Basheshar Lal-Bansi Dhar vs. Bhik Raj & Ors, Indian Law Reports, Vol. XII, 254 :
"The question whether a contract is an entire or divisible one is often a difficult one to
decide. Each case has to be decided on a consideration of all the circumstances and
hence the rulings cited are not of much assistance in deciding the point. In the
present instance, after considering the terms of the contract and the conduct of the
parties in dealing with it, I am of opinion that the contract was an entire one. No
definite instalments were fixed by the contract, or was any period specified for the
delivery of any instalment. In fact, the contract does not even say distinctly that the
goods of each shipment were to be delivered separately and in point of fact, goods of
more than one shipment were at times delivered together. The quantities of the
different shipments were also not equal and appear to have been arbitrarily fixed by
the sellers. All these facts seem to indicate that the intention of the parties was to
contract for the delivery of the entire lot of 90 cases. The oral evidence of the parties
is to the same effect. It ppn 47 arbp-275.12 (j).doc is true that goods of certain
specified "shipments" were to be delivered, but this appears to have been stipulated
merely for the sake of convenience in the matter of delivery and payment. I therefore
hold that the contract in the present instance was an entire one.
On the above finding, the cause of action for the breach of the contract could not arise
till the expiry of the period for the delivery of the goods of the last shipment. In this
aspect of the case, the claim with respect to the nondelivery of the seven bales of the
December-January shipments was not time barred and this fact was conceded by the
learned Counsel for the respondents."
3) Chhote Lal vs. Nathu Miri Lal, AIR 1930 Lahore, 193(2).Cmc Ltd vs Unit Trust Of India on 6 February, 2015

"The first point which arises for consideration is as to the nature of the contract, and
there is no doubt that the view taken by both the lower Courts as to the goods being
deliverable in three instalments is wrong. The term "December shipment, three lots,
two months' grace" does not imply that the contract goods are to be delivered in three
instalments, but merely that they are to be shipped in three lots commencing with
December, i.e., the first lot in December the second in January and the third in
February allowing two months' grace. According to the terms of the contract each lot
had to be shipped respectively by the end of February, March and April.
According to the learned District Judge the transit period was 3 1/2 months and the
last lot of goods should have reached Delhi by the middle of August but, in my
opinion this period is insufficient for the goods to have reached Delhi. In the cases
cited below a transit period of four months from England to Karachi was allowed and
ten to fourteen days from Karachi to Delhi. This would give a total period of about 4
1/2 months. The due date of the third lot would therefore be between the middle of
August and middle of September.
The view that the contract was an indivisible one and the due date was the arrival of
the last lot at Delhi is ppn 48 arbp-275.12 (j).doc supported by the decision of a
Division Bench of this Court Ganesh Das Ishar Das v. Ram Nath which was a
precisely similar case to the one under appeal. The decision in Ganesh Das Ishar Das
v. Ram Nath followed three other cases of this Court:
Phul Chand Fateh Chand v. Chhote Lal Ambay Parshad, Chhota Lal Ambay Parshad
v. Basdev Mal Hira Lal and Amba Parshad Gopi Nath v. Jawala Dat Ram Kanwar in
each of which it was held that a contract of the same nature as the one in the present
suit was an indivisible one and the due date was the arrival of the last shipment. It
follows, therefore, that, as the arrival of the last shipment or third lot in the present
case did not take place till within three years of filing the suit, the claim is within time
in respect of all he ten bales. In these circumstances it is unnecessary to discuss
Cooverjee Bhoja v. Rajendra Nath Mukerji and Jagmohandas Vurjiwan Das v.
Nusserwanji Jahangir relied on by Mr. Kishan Dayal, the learned Counsel for the
defendants respondents. Both these decisions were discussed and distinguished in
Ganesh Das Ishar Das v. Ram Nath."
4) Ganesh Das-Ishar Das vs. Ram Nath & Ors, Indian Law Reports, Vol. IX, 148.
"The case was argued at considerable length by the learned Counsel for the parties. A
number of pleas were taken in the memorandum of appeal, but it is not necessary to
discuss them at any length. On behalf of the appellants it was urged that barring two
bales only, the rest of the claim was time barred. The argument is based upon the
various due dates as worked out by Mr. Sardha Ram, the learned Counsel for the
defendants-appellants, in the light of a certain memorandum described as statement
A which is printed at p. 8 of the supplementary paper book. He says that theCmc Ltd vs Unit Trust Of India on 6 February, 2015

December shipment reached Karachi on the 8th April 1917, and that allowing four
days for the journey between Karachi and Delhi the date of arrival in Delhi was the
12th April 1917. In the same way, about the January shipment the date of arrival at
Delhi according to him would be the 21st May 1917, and ppn 49 arbp-275.12 (j).doc as
to the February shipment the date of arrival in Delhi would be the 1st May 1917. It is
only as regards the March shipment consisting of two bales only which reached Delhi
on the 12th September 1917, that, according to Mr. Sardha Ram, the claim was within
time, since the present suit was brought on the 19th July 1920. It may be mentioned
that the statement A deals with Mulls Nos. 35255 only, because Messrs. Ralli
Brothers, whose agent prepared the said statement A, are the sole importers of Mulls
No. 35255 and not of Mulls No. 36556. Mr. Sardha Ram's argument on this part of
the case is that every date of the arrival of a particular instalment of goods at Delhi
constituted the due date and default on the part of the defendants on such due date
gave a separate cause of action to the plaintiffs and as the plaintiffs brought the
present suit more than 'three years after the dates, worked out as above, the suit was
time barred in respect of all the instalments with the exception of the two bales of the
March shipment. The point in controversy is not free from difficulty, because the
appellants' contention finds some support from the reasoning contained in two cases
at least. Jagmohandas Vurjiwan Das v. Nusserwanji Jehangir was quoted on behalf of
the appellants. In this case the defendants sold to the plaintiffs 1,000 tons of coal,
shipment January to May, at the rate of 200 tons monthly. There was a breach, and
the buyers sued the sellers for damages. It was held that the contract was for delivery
in monthly shipments and as the coal took about four weeks to arrive at Bombay after
shipment, the dates for delivery under the contract would be February to June, and
damages should be assessed in respect of each default and on the basis of the
stipulated instalments. Cooverjee Bhoja v. Rajendra Nath Mukerjee was also cited on
behalf of the appellants. Here the contract was to deliver 5,000 tons of manganese
ore, 500 tons before the 31st October 1906, 1,000 tons before the 30th November
1906, 1,500 tons before the 31st December 1906, and the remaining 2,000 tons to be
completed and delivered before the 15th February 1907. It was held that the contract
was in fact a set of distinct contracts and on each period, when no delivery was made,
there was a cause of action for damages for each breach.
It may be mentioned that in none of these two cases ppn 50 arbp-275.12 (j).doc there
was any question of limitation involved and the Courts treated each default as a
distinct breach of contract for the purpose of assessing damages.
On behalf of the respondents at least three cases of the Lahore High Court have been
quoted which seem to support their contention.
In Phul Chand Fateh Chand v. Chhote Lal Amba Parshad a suit for damages was
brought by the buyer for the breach of contract by non-delivery of goods against the
defendant, seller. The defendant pleaded that qua certain bales the suit was time
barred. It was held that the contract was an indivisible one and as the arrival of theCmc Ltd vs Unit Trust Of India on 6 February, 2015

last shipment under the contract did not take place till within three years of filing the
suit, the claim was within time as to all the bales.
This case was followed in Firm Amba Parshad Gopi Nath v. Firm Jawala Dat Ram
Kanwar . In this case also the buyer brought a suit against the seller for damages for
breach of contract by non-delivery. The contract was for eleven bales of Mulls,
November (1916) shipment, four lots, sixty days grace, delivery of goods to be taken
against payment on arrival of the railway receipt. November shipment, four lots,
meant that the goods were to be shipped in four monthly lots commencing from
November 1916, allowing two months grace and four months for transit from
England to Karachi and one month for their conveyance from Karachi to Lahore. The
due date for the first lot was calculated to be somewhere at the end of June 1917. The
suit was brought on the 15th July 1920. The lower appellate Court held that the suit
was time barred as regards the first lot of goods. It was held on the authority of Phul
Chand Fateh Chand v. Chhote Lal Amba Parshad that the Contract was an indivisible
one and that the due date did not arrive until the last shipment under the contract
reached Karachi.
Firm Chhota Lal-Amba Parshad v. Firm Basdeo Mal Hira Lal was decided by a
learned Judge of this Court sitting singly. This was also a suit by a buyer against a
seller for damages for non-delivery of goods. The contract was for five bales of white
mulls, December shipment, three lots, 60 days grace, payment against railway receipt
and invoices. The ppn 51 arbp-275.12 (j).doc lower appellate Court held that the suit
as regards the first shipment was time barred as the due date of December shipment
expired on the 30th June 1917, and the suit was instituted on the 20th July 1920. It
was held that a contract such as the present was not an instalment contract, that the
defendants could have delivered goods under it up to the last day of arrival of the last
shipment and that the plaintiffs could not sue for damages for breach of contract
until that date had expired. It may be noted that in this case also, March shipments
were arriving until September, so that the defendants could have shipped the goods
up to March 1917 at the latest. To me the Lahore cases seem to be more in point
because they all deal with the question of limitation and the terms of the contract in
the last two cases seem to bear a family resemblance to the terms of the contract Ex.
P-1(a) which forms the basis of the present suit. Following these cases I hold that the
suit was within time and that no portion of 1. the claim is barred by limitation."
86. A perusal of the aforesaid four judgments referred to and relied upon by the arbitral tribunal
clearly indicates that Lahore High Court in the aforesaid four judgments however, dealing with the
case where a party to the contract had agreed to deliver the goods in installments under a single
contract. The contract provided for a lump-
sum payment for the entire consignment to be delivered in installment. Considering those facts, the
Lahore High Court took a view that the question whether the contract was entire or indivisible one is
often a difficult one to decide. Each case has to be decided on a consideration of circumstances. InCmc Ltd vs Unit Trust Of India on 6 February, 2015

the case of Basheshar Lal-Bansi Dhar vs. Bhik Raj & Ors. (supra) the Court recorded that the
defendant had conceded that the claims were not time barred.
87. In my view, none of these judgments relied upon by the ppn 52 arbp-275.12 (j).doc respondents
and followed by the arbitral tribunal were in any manner applicable to the facts of these case at all.
Admittedly under the contract awarded to the petitioner by the respondents work was to be carried
out phase-wise. Separate milestone and separate payment was provided under the contract for each
application group. Two application groups were already abandoned by the respondents themselves.
The work under AG-1 and AG-3 was allowed to be performed even though the work under AG-2 was
abandoned. The respondents themselves had raised a demand for refund of the payment as and by
way of damages from the petitioner immediately after issuance of the said letter dated 14 th
January, 1997 purporting to abandon the contract considering the same as separate cause of action.
In my view, the facts of all four matters before the Lahore High Court were totally different. The
respondents themselves in their pleadings as well as the evidence had taken a stand before the
arbitral tribunal that the work under AG-2 was different than the work under other applications and
was liable to be carried out at different places. Reliance placed by the respondents on the said
judgments was totally misplaced. The arbitral tribunal without considering the fact that the facts in
these cases and more particularly without considering the stand of the respondents themselves and
the evidence led by them have applied the judgments of Lahore High Court to the facts of this case,
which shows total non-application of mind on the part of the arbitral tribunal.
88. The arbitral tribunal totally failed to appreciate that once the cause of action has commenced
when the breaches were alleged to have been committed by the petitioner even according to the
respondents ppn 53 arbp-275.12 (j).doc much prior to 14th January, 1997 did not stop. There was no
part payment made by the petitioner admittedly to the respondents arising out of such demand by
the respondents in the year 1997, nor the petitioner acknowledged any liability to pay the said
amount during the period between 1997 and 2000. The impugned award is contrary to section 9 of
the Limitation Act and over looking the fact that the cause of action even according to the
respondents had commenced for recovery of compensation / damages prior to 14th January, 1997
when the breach of contract was alleged to have been committed by the petitioner. In my view, since
the arbitral tribunal has allowed the time barred claims, the award is in conflict with the public
policy and deserves to be set-aside on this ground also.
89. I am not inclined to accept the submissions made by Mr.Sen, the learned senior counsel for the
respondents that though plea of limitation was raised by the respondents while opposing the
counter claim in the written statement, the said plea was not persuaded by the respondents before
the arbitral tribunal and thus no cognizance thereof could have been taken by the arbitral tribunal
while deciding the claim or counter claim. In my view, the respondents having raised the plea of
limitation in respect of the counter claims made by the petitioner contending that the cause of action
was not continuing cause of action and the claims ought to have been made as and when the
breaches had been alleged to have been committed could not be permitted to oppose the plea of
limitation rendered by the petitioner on the similar ground. In my view the cause of action in favour
of the petitioner and in favour of the respondents in respect of their respective claims in respect of
AG-2, ppn 54 arbp-275.12 (j).doc which was abandoned / terminated on 14th January, 1997 arose atCmc Ltd vs Unit Trust Of India on 6 February, 2015

the same time. The claim for damages made by the respondents and the claim for work done by the
petitioner and for compensation both arose when the work was abandoned / terminated in the year
1997. The arbitral tribunal however, completely overlooked the provisions of the Limitation Act,
1963 which were applicable to and were binding on the arbitral tribunal and rendered an impossible
finding on the issue of limitation, which deserves to be set-aside.
90. Insofar as the submission of Mr.Sen, the learned senior counsel that the finding of the arbitral
tribunal on the issue whether the contract was indivisible or not or whether the claims made by the
respondents were barred by law of limitation or not are the finding of facts and no interference with
the finding of fact is permissible under section 34 of the said Act is concerned, in my view since both
the findings rendered by the learned arbitral tribunal are perverse, patently illegal and contrary to
the terms of the contract and contrary to law, this court has ample power under section 34 of the
said Act to render such impossible finding set-aside, having been rendered in conflict with the
public policy.
91. So far as the judgment of the Supreme Court in G. Ramchandra Reddy & Co.vs. Union of India &
Anr. (2009) 6 SCC 414, relied upon by Mr.Sen, the learned senior counsel for the respondents is
concerned, there is no dispute about the proposition laid down by the Supreme Court in the said
judgment. Since this court has come to the conclusion that the interpretation of the terms of the
contract is ppn 55 arbp-275.12 (j).doc impossible interpretation and the findings rendered by the
arbitral tribunal are perverse, the said judgment of the Supreme Court relied upon by the learned
senior counsel for the respondents in my view does not assist the respondents.
92. A perusal of the record indicates that though the petitioner had raised a plea that the contract
was illegally terminated by the respondents, the said pleading had not been denied by the
respondents. A perusal of the oral evidence led by the petitioner also indicates that it was suggestion
by the respondents itself to the witness of the petitioner that the contract was terminated by the
respondents which suggestion was accepted by the petitioner, the arbitral tribunal has rendered an
erroneous finding that it was not the case of the petitioner that the contract was terminated. Both
the parties had pleaded and proceeded on the premise that the contract was terminated. In my view,
once the contract was terminated by the respondents, the consequences provided under the contract
13.4 for payment to the contractor for the work done would stand attracted. The question of
awarding any claim for damages in favour of the respondents therefore, was totally unwarranted
and contrary to the terms of the contract. Admittedly, there was no provision under the contract for
refund of the amount already paid for the work done.
93. A perusal of the provisions of the contract clearly indicates that the respondents were liable to
make payment for the work done in accordance with the milestone used which payments were
already been made by the respondents to the petitioner for part of the work done. Even if such claim
for refund was considered as a claim under section 55 read with section 73 of the Contract Act, the
respondents were liable to prove ppn 56 arbp-275.12 (j).doc the breach alleged to have been
committed by the petitioner and the loss suffered by the respondents in view of such breach
committed by the petitioner. The respondents, in my view, have totally failed to prove the breach
alleged to have been committed by the petitioner and also the losses, if any, suffered by theCmc Ltd vs Unit Trust Of India on 6 February, 2015

respondents due to such alleged breach committed by the petitioner. The respondents did not
produce any material on record before the arbitral tribunal that due to abandonment / termination
of AG-2, the other two application groups which were admittedly completed by the petitioner were
not successfully commissioned or that any loss was suffered by the respondents due to the
petitioner's not completing the work under AG-2. The arbitral tribunal on this ground also could not
have awarded any claim for damages in favour of the respondents.
94. Insofar as submission of Mr.Sen, the learned senior counsel for the respondent that there was no
plea raised by the petitioner in this petition or raised before the learned arbitral tribunal that the
respondent could not have been allowed to urge across the bar the stand taken on the plea of
limitation is concerned, it is not in dispute that such plea raised by the respondents in the written
statement to the counter claim was already on record before the learned arbitral tribunal. In spite of
such plea, the arbitral tribunal permitted the respondents to raise such inconsistent submission
across the bar. In my view the submissions made by the learned senior counsel is devoid of any
merits and is accordingly rejected.
95. In so far the submission of the learned senior counsel that ppn 57 arbp-275.12 (j).doc though the
respondents had claimed interest with effect from 14 th January, 1997, the learned arbitral tribunal
has awarded interest from 31 st July, 2007 and thus mere making a claim for interest with effect
from 14 th January, 2007 would not indicate that the cause of action had arisen on 14th January,
1997 is concerned, in my view since the respondents had already made demand for refund of the
amount paid under AG-2 based on a letter dated 14th January, 1997 and had made the claim for
interest with effect from 14th January, 1997, the respondents had proceed on the premise that the
cause of action had arisen with effect from 14 th January, 1997. In my view the submission of
Ms.Ghone, the learned counsel for the petitioner that the cause of action had arisen on 14 th
January, 1997 deserves acceptance. The respondent cannot be allowed to blow hot and cold at the
same time.
96. In my view the entire award shows patent illegality on the face of the award and being contrary
to the terms of the contract, contrary to law laid down by the Supreme Court and this court, the
provisions of the Limitation Act, 1963 and also being contrary to and overlooking the pleadings and
the evidence filed by both the parties, the impugned award deserves to be set-aside and is
accordingly set-aside.
97. I therefore, pass the following order :-
a) The arbitration petition is made absolute in terms of prayer clause (a) insofar as
the impugned award dated 3 rd November, 2009 is concerned.
ppn 58 arbp-275.12 (j).doc
b) The impugned award dated 3rd November, 2009 is set aside.
c) There shall be no order as to costs.Cmc Ltd vs Unit Trust Of India on 6 February, 2015

(R.D. DHANUKA, J.)Cmc Ltd vs Unit Trust Of India on 6 February, 2015

