Bihar Inland Vessels Rules, 2013
BIHAR
India
Bihar Inland Vessels Rules, 2013
Rule BIHAR-INLAND-VESSELS-RULES-2013 of 2013
Published on 23 September 2013• 
Commenced on 23 September 2013• 
[This is the version of this document from 23 September 2013.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Bihar Inland Vessels Rules, 2013Published vide Notification No. S-1/WT-403/2010 T Part-4712,
dated 23.09.2013Last Updated 11th February, 2020No. S-1/WT-403/2010 T Part-4712. - In exercise
of the powers conferred in sections 19, 19R, 29, 30, 30A, 52, 53, 54 and 67 of the Inland Vessels Act,
1917 (Act, No. 1 of 1917) read with section 21 of the General Act, 1897 (Act No. 10 of 1897) and in
supersession of the rules defining the procedure to be adopted for the survey and registration of
Inland Motor Vessels in Bihar State publication for survey in government Notification No. 2057
VIS-I-Com dated May, 21, 1935 in Bihar and Orissa Gazette, dated May, 29, 1935 and in
Government notification No. 4058-VIS-5-Com dated September, 23, 1936 in the Bihar Gazette,
dated September 30, 1936, Bihar Inland Steam Vessels Survey Rules 1935 and its amendment rule
1936 and Bihar Inland Steam Vessels Registration Rule 1951 for registration published in
Government Notification No. IVS-4-1025/51L-190 dated October 1, 1951 in the Bihar Gazette, dated
October 15, 1951, the Governor of Bihar is pleased to make the following rules for their previous
publication as required under section 74 of the said Act:-Chapter - 1.0 Preliminary
1. Short title and Commencement.
(1)These rules may be called Bihar Inland Vessels Rules, 2013(2)It shall come into force with effect
from the date of their publication in the official Gazette and shall apply on Inland Vessels plying in
whole State of Bihar except as otherwise provided in these Rules.(3)(a)An inland vessel shall not
proceed on any voyage, or be used for any service unless she has a certificate of survey in force and
applicable to such voyage or service.(b)Nothing in this para shall apply to any Inland vessel
proceeding on a voyage during the interval between the time at which her certificate of survey
expires and the time at which it is first practicable to have the certificate renewed.
2. Definitions.
- In these rules, unless there is anything repugnant in the subject or context:-(a)"Act" means the
Inland Vessels Act, 1917;(b)"Builder" means the person in overall control of design, construction,Bihar Inland Vessels Rules, 2013

fitting and delivery of Vessels and includes a person who has engine for fitting on hull or shell, or
who has constructed super structure on hull or shell, and also includes his re
presentative;(c)"Candidate" means a candidate desirous of obtaining a certificate of competency
under the I.V. Act 1917;(d)"Cargo" includes livestock;(e)"Central Rules" means rules made by the
Central Government under the Act or the Inland Waterways Authority of India Act,
1985;(f)"Certificate of Competency" means a certificate of competency granted under these rules to
act as an engineer, master, or engine driver, serang on board of inland Mechanically Propelled
Vessel;(g)"District Magistrate" includes the Additional District magistrate, and if specially
authorized in this behalf by the District Magistrate, includes any other Executive
Magistrate;(h)"Dumb barge" means a vessels under Act without mechanical propulsion or
pressure-oriented propulsion but towed by a vessel so powered;(i)"Examiner" means an Examiner
appointed as such by the State Government under section 20 of the Act. National Inland Navigation
Institute, Patna shall be as deemed examiner from the date of coming in force of these
rules.(j)"Chief Examiner under section 21 of the act, means State Transport Commissioner, Bihar or
any other officer authorized by the State Government.(k)"Form" means a form appended to these
Rules;(l)"National Waterway" means a waterway, or part thereof, notified as such by the Inland
Waterways Authority of India;(m)"Schedule" "Registering Authority" means an officer appointed as
such under clause (b) of sub-section (1) of section 19B of the Act who may be Director, Deputy
Director or any officer authorized by the Government;(n)"Schedule" means a Schedule appended to
these Rules;(o)"Director Inland Water Transport" means the Director, State Transport
Commissioner Dy. Director, Chief Surveyor, Bihar, Patna or any other person authorized in this
behalf by the Director Inland water transport or Secretary Transport.(p)"Chief Surveyor" means the
State Transport Commissioner, Bihar or any other officer authorized by State Government
appointed under sub-section 4 of section 9 of the Act for issuing the survey certificate of the
vessels.(q)"Approved Consultant" means a naval architect or a marine engineer qualified to certify
the safe construction of hull/machinery of the vessel for the purpose of survey and dully approved
by the competent authority.(r)"Approved classification society" means a classification society duly
approved by Government or is a member/associate member of International Association of
Classification Society (IACS)(s)"Convoy" means a group of vessels, floating equipment or raft towed
or pushed by a mechanically propelled vessel(t)"Dangerous goods" shall have the meaning as
provided in the merchant shipping act, 1958.(u)"mechanically propelled vessel" means every
description of vessel propelled wholly or in part by electricity, steam or other mechanical power
including dumb vessel towed by the mechanically propelled vessel and vessel propelled by outboard
motor;(v)"Surveyor" means any such person or member of agency such as
1. Indian Register of Shipping (IRS),
2. international classification Society,
3. Institute of Marine Engineers (Patna Chapter), or Company of Master
Mariner of India (Patna Chapter), andBihar Inland Vessels Rules, 2013

4. Surveyor appointed by Principal National Inland Navigation Institute, Patna
and appointed as per rule 4(a) by chief surveyor at such place as he
considers necessary for the purposes of these rules.
(w)"Inland Vessels" or "inland mechanically propelled vessel" means a mechanically propelled
vessel which ordinarily plies on any inland water,classified intoCategory ACategory BAs per rule
3(x)"inland water" means any canal, river, lake or other navigable water(y)"passenger" includes any
person carried in a mechanically propelled vessel other than the master, crew, the owner, his family
and servants;(z)"state" means state of Bihar and "Government" means the Government of
Bihar.Chapter - 2.0 Survey of Inland Vessels
3.
(1)Categorization of Vessels. - For the purpose of survey, inland vessels are categorized in to two
groupsCategory- A(a)Vessels driven with more than 300 HP on board engine.(b)Vessel with upper
deck(c)Vessel with FRP hull having passenger capacity of more than 25(d)Vessels with more than
15m length.(e)Hover Craft and Hydrofoils.Category- B(a)All mechanically vessels not included in
Category A.(b)Non motorized barge/ vessels towed by mechanized vessels not included in category
A.(c)All vessels driven with more than 25 HP engine but less than 300HP. (Except vessels as
mentioned in rule no.-106 of this rule.)(2)Procedure of Survey & Construction(a)Category-A vessels
are required to be built under the class survey of a Classification Society.(b)Category-B vessels are
required to be built under inspection of Chief Surveyor who will be assisted by certified Naval
Architects/ Marine Engineers holding 1st class certificate of competency for approval of drawing,
survey and classification etc throughout all stages of construction and other occasions of
survey.(3)Every application for survey of an inland vessel shall be made by owner or master of the
vessel in Form-I along with a fee specified in rule 9 directly to the authorized surveyor or at any
other such place notified by the IWT directorate within a period of fifteen days before from the date
of taking delivery of such vessels, excluding the period of journey, who shall forward the application
for survey to the concerned Chief Surveyor/ Dy. Director IWT(4)Upon receipt of an application
under sub-rule (3), the surveyor shall fix the date and time at which the survey shall commence, and
shall give a notice in Form-2 to the owner or master of inland vessels informing him the date and
time so fixed and requiring him to make all necessary preparations for the survey. The notice shall
be given at least seven days before the date fixed for the survey. A survey shall be made on any day
except Sunday and holidays. On request of the owner or master of an Inland Vessel, survey may be
made on Sunday or holidays on payment of additional fees as specified in this behalf in rule
12.(5)Place of survey will be Patna or any such place that may be notified in the Gazette by the State
Government under clause (a) of sub-section (1) of section 4 of Inland Vessel Act, 1917. A surveyor's
fees of Rs2000/- per day/visit, or any rate fixed by Director IWT from time to time, plus
conveyance, boarding and lodging expenses of the surveyor for making survey shall be borne by the
owner or master of the inland vessel.(6)If every part of the inland vessels is not ready for survey at
the appointed date and time or if requisite preparation has not been made for the survey by the
owner or master of the inland vessel, the surveyor may, for reasons to be recorded, fix some other
date and time for survey.(7)If due to unavoidable reason the Surveyor is unable to remain presentBihar Inland Vessels Rules, 2013

on the date and time fixed for survey, he shall send the earliest possible information to the owner or
master of the inland vessel and shall fix some other date and time for the survey.(8)The owner or
master of the inland vessel shall be liable to pay a penalty at the rate of rupees hundred per day if
the application for survey is not made within the period specified in sub-rule (3):Provided that, the
Director Inland Water Transport may for valid and sufficient reasons to be recorded by him reduce
such fine to a maximum of fifty per cent, thereof.(9)The survey of Inland Vessels shall be completed
within one month from the date of the receipt of application for survey.(10)Where the survey cannot
be completed within one month from the date of the receipt of application owing to no fault of the
owner or master of the Inland Vessel, sufficient valid reasons for such delay shall be shown by the
surveyor to the Chief Surveyor.(11)If it is proved that survey was delayed due to willful negligence of
the owner or master of the Inland Vessel or his authorized representative a penalty equal to double
of the survey fee for each completed month or part thereof shall be payable by such owner or master,
as the case may be.
4. The surveyor should have following minimum qualifications.
(a)Should be a Marine/ Mechanical/ Electrical Engineer having minimum 5 years of sailing
experience after first certificate of competency and having obtained minimum Second class Motor/
Steam MOT Certificate, issued by Director General of Shipping, Government of India or equivalent
international certificate, with minimum 2 years sailing experience after having obtained such a
certificate or master mariner with 5 years of experience after having obtained master's certificate
issued by Director General of Shipping, Government of India or equivalent international certificate.
In case of surveyor being an agency, the concerned agency shall have personnel with above
qualification on their panel/role.(b)The Surveyor shall survey the engine, boiler, all machineries,
hull, equipments, passenger's accommodation, fire fighting and life saving equipment and
determine the number of passengers and the nature and quantum of cargo which the vessel is fit to
carry. The Surveyor shall also examine the certificate of the master, serangs, the engineer and
engine driver and electrical operator on vessels or vessels having electrical machineries operating on
400 volt and above to ensure that the same are in accordance with the provisions of the Act and
these rules. The surveyor shall also inspect the light and sound signals to ascertain that the light and
sound signals are in good condition to prevent collision on waterways.
5.
(1)The declaration of surveyor shall be given in Form-3 which shall be duly filled and signed by the
Surveyor. It shall be sent within fourteen (14) days by the ship owner to such officer as notified the
state Government under sub-section (1) of section 8 of the Act; else a charge as prescribed in form 5
for delay shall be levied.(2)(a)If the surveyor finds any defect in the hull, machinery or equipment of
the Inland Vessels, he shall, before refusing to give the declaration under section 7 of the Act
intimate in Form-4 to the owner or master of the Inland Vessels or his authorized representative
pointing out the defects and require him to make necessary repairs to make good the defects.(b)If
the Owner/Master of a mechanically propelled vessel is dissatisfied with the survey report of first
surveyor, an application from the Owner/ Master and payment of fees which shall be double of
previous survey, the Director of Inland Transport/Chief Surveyor shall appoint two surveyors. AnyBihar Inland Vessels Rules, 2013

declaration given by them or refusal to give declaration shall be final.
6.
(1)A notice under clause (b) of sub-section (1) of section 9 of the Act shall be given in Form-5.(2)A
Certificate of Survey under section 9 of the Act shall be granted in Form-6 for category A vessels or
Form-7 for Category B vessels as the case may be. The owner or master of the mechanically
propelled vessel, for which a certificate of survey has been granted, shall forthwith, on the receipt of
the certificate, cause one of the duplicates thereof to be affixed and kept affixed so long as it remains
in force and the [mechanically propelled vessel] is in use, on some conspicuous part of the
[mechanically propelled vessel] where it may be easily read by all persons on board.(3)The
certificate of survey shall not be in force:(a)after the expiry of one year from the date thereof;
or(b)after the expiry of the period (if less than one year) for which the hull, boiler, engines or other
machinery, or any of the equipments of the mechanically propelled vessel to which the certificate
relates have been stated in the certificate to be sufficient; or(c)after notice has been given by the
Government of Bihar to the owner or master of the mechanically propelled vessel that the
Government has cancelled or suspended it.(4)The certificate of survey shall not be in force in any
State by virtue of any endorsement in respect of that State, after notice has been given by the State
Government of Bihar to the owner or master of a mechanically propelled vessel that Government
has cancelled or suspended the endorsement.(5)The certificate of survey or any endorsement
thereon made under section 10A may be suspended or cancelled by the Government of Bihar if the
Government has reason to believe :-(a)that the declaration by the surveyor of the sufficiency and
good condition of the hull, boilers, engines or other machinery or of any of the equipments of the
mechanically propelled vessel has been fraudulently or erroneously made; or(b)that the certificate
has otherwise been granted upon false or erroneous information; or(c)that since the making of the
declaration the hull, boilers, engines or other machinery, or any of the equipments of the
mechanically propelled vessel have sustained any material injury, or have otherwise become
insufficient.(6)On suspension or cancellation of endorsement made under section 10A on a
certificate of survey, the Chief surveyor or the Director. IWT shall report the fact of suspension or
cancellation, together with the reasons therefore, to the State Government which (or whose
delegate) granted the certificate.(7)Under Section 54(c) of the Inland Vessel Act 1917 if vessel is not
insured, the vessel cannot be used for cargo and/or passenger service.
7.
(1)On the application made by the owner or his authorized representative or master of an Inland
Vessels, as per procedure laid down in rule-3, the validity of a certificate of survey may be extended
up to three months in Form-8 on the exigencies of the situation and if the surveyor recommends for
the grant of the certificate for that period.(2)Dry docking period may be revalidated beyond four
years or three years (for carriers of petroleum products) docking period, as the case may, be on
exigencies of the situation and on application by the owner, or his authorized representative or
master of an Inland Vessels as per rule 3 on deposit of full survey fees. The extension of validity of
the docking period shall not exceed one year provided the surveyor recommends the grant of
validity for that period and the Inland Vessel is surveyed by him.(3)If the vessels has been fullyBihar Inland Vessels Rules, 2013

surveyed, but in the opinion of the surveyor the hull, equipment or machinery of the Inland Vessel
are declared to be sufficient only for a specific period being less than one year, the full annual fees
for survey shall be payable.
8.
(1)Every Vessel to which these rules apply shall be subjected to the survey as specified
below:-(a)before a new vessel is put in service (Initial Survey);(b)periodical survey once every twelve
months including survey of hull, machinery and equipment.(c)four years dry docking survey, will
include dry docking and detailed check on machinery wear and tear followed by satisfactory running
trials;(d)additional surveys as and when necessary.(2)(a)The survey before the Inland Vessel is put
in service shall include a complete inspection of the hull, machinery and equipments. The survey
shall be such as to ensure that arrangements, materials, scantlings of hull, boilers and their
appurtenances, fire appliances and other equipments fully comply with the provisions of these rules.
The survey shall also be such as to ensure that the workmanship of all parts of the vessel and
equipments are in all respects satisfactory.Provided that the bottom of the vessel which has been
surveyed during the construction need not be examined by a surveyor before the vessel is launched
unless the surveyor has special reasons for considering it necessary.(b)The periodical survey shall
include an inspection of the whole of the hull, boilers, machinery and equipments including the
outside of the vessel's bottom in dry dock. The survey shall be such as to ensure that hull, machinery
and equipments is in satisfactory condition and fit for the service for which the vessel is intended
and that it complies with the requirements of these rules.(c)A survey either general or partial,
according to circumstances, shall be made-(i)every time an accident occurs or a defect is discovered
which affects the safety of the vessel;(ii)its efficiency or completeness of its equipment or whenever
any important repair or renewal are made;(iii)whenever a request for extensions of certificates of
survey is being considered.(d)The survey shall be such as to ensure that the necessary repairs or
renewals have been effectively made and the material and workmanship of such repairs or renewals
are in all respects satisfactory and the Inland Vessel is fit for the service for which it is intended. (3)
After the survey of the Inland Vessel has been completed, no change shall be made without approval
of surveying authority.
9.
For the purpose of a survey under these rules, the fee shall be payable by the owner or master of the
vessel at the rates given in schedule IV.Chapter - 3.0 Registration of Inland Vessels
10.
(1)An inland vessel shall not proceed on any voyage or be used for any service unless it has a
certificate of registration in force in respect thereof and granted under the Inland Vessel Act. Every
application for registration of an Inland Vessel shall be made by the owner or master of the vessel to
the Registering Authority in Form No.10.(2)When registration is required to be made at a place
other than the place where the owner resides or carries business or if the owner is a company, at a
place other than the place where the registered office of the company is situated, the application forBihar Inland Vessels Rules, 2013

registration shall be accompanied by a copy of the letter conveying the approval of registration from
the State Government in which the owner resides or carries on business or the company has its
registered office.(3)Every application for registration of an Inland Vessel shall be accompanied by a
treasury Challan/Bank draft/ E-payment receipt showing the deposit of registration fees as
mentioned in schedule 1.(4)While applying for registration of an Inland Vessel, the owner or master
of the vessel shall furnish-(a)In the case of a newly built vessel, the builder's certificate and
inspection certificate issued by the surveyor along with approved drawing of the vessel, documents
relating to purchase of the vessel and document of its ownership.(b)In the case of renovated vessels,
builder's certificate and inspection certificate issued by the surveyor along with approved drawing of
the vessel and document of its ownership.(c)Copy of insurance certificate as per Chapter VI A,
Section 54C of the Act.
11.
Registration of an Inland Vessel shall be made after survey of the vessel according to provisions of
the Act and the rules and after production of certificate of survey.
12.
(1)On receipt of an application for registration of an inland vessel, the Registering Authority shall
give a notice in Form No. 11 to the owner or master of the vessel informing him the date and time for
inspection of the vessel(2)It shall be the duty of the owner or master of the inland vessel to furnish
such other information as may be required by the registering authority.
13.
Every inland vessel shall be marked permanently and conspicuously to the satisfaction of the
registering authority as follows:-(1)Inland Vessel name shall be marked on each of its bows or at a
suitable place on the superstructure and the inland vessels name and the name of its place of
registration shall be marked on its stern on a dark background in white letters or on a white
background in black letter which shall not be less than 15 centimeter in height and 2 centimeter in
breadth.(2)Inland Vessels registration mark and the number denoting its registered tonnage shall be
cut in on its main beam or any permanent bulkhead at a prominent place. The letters and figures of
the registration marks shall not be less than 15cm. X. 10 cm.(3)Scale of draught marks shall be cut
or welded in meters and decimeters, forward and rear of Inland vessels on both the port and the
starboard side.(4)Inland vessels load line shall be cut or welded 300cm. long and 35mm. wide and
shall coincide with maximum draught level of the inland vessel in fair weather conditions.(5)The
maximum drought level mark line will be below deck level not less than 62 cm. The space as per
requirement will be taken space all around the vessel on deck level.
14.
(1)The registering authority shall after satisfying itself grant a certificate of registration in Form No.Bihar Inland Vessels Rules, 2013

12. It shall be the duty of the owner or master of the inland vessel to produce it on demand by
authority engaged in the enforcement of Act and rules. The certificate may also be in electronic form
like smart card, in place of Form 12.(2)In special circumstances and for reason to be recorded in
writing, the registering authority may grant a temporary pass to an inland vessel to enable it to ply
during the period of the preparation of certificate of registration. The pass shall be in Form No. 13
and for the time and within the limit therein mentioned. The said pass shall be valid for 30 days and
shall have the same effect as a certificate of registration subject to the conditions laid down in the
pass.
15.
A book of registration shall be maintained by the registering authority in Form No.14 separately for
each vessel registered and shall contain inter alia of the particulars given in the certificate of
registration. It should be bound volumes with machined numbered pages. It can be in electronic
form also.
16.
(1)When the registered of inland vessel is altered so as not to correspond with the particulars
relating to its tonnage and or description as shown in the book of registration, the onus of having the
alteration recorded by the registering authority shall be on the owner or master of the inland vessel.
The inland vessel shall be required to be registered if the registering authority so directs for reasons
to be stated for such direction. The registering authority in deciding whether alteration will be
recorded or whether the inland vessel should be registered a new shall be guided by the following
considerations:-(a)Whenever any material alteration is made in the hull affecting the length or
breadth or depth of the inland vessel or wherever there is alteration in the means of propulsion
including addition or removal of an auxiliary engine the vessel shall require new
registration.(b)Where the alteration consists merely of a change in the dimensions of close in space,
the addition or removal of poop or deckhouse etc. or an allowance or disallowance or crew space of
other similar change or an alteration from motor or steam crew to another motor or steam crew or
reverse, the registering authority may allow such alteration to be recorded provided the stability of
the vessel is not endangered thereby.(2)The owner shall report in Form No.15 to the registering
authority of such alteration within one month of the alteration taking place mentioning therein the
place where the vessel is registered and giving complete particulars regarding alteration
made.(3)Fee as specified in the schedule-I shall be payable along with such application. The
registration certificate of the inland vessel shall be surrendered by the owner along with other
supporting documents for recording the alterations made or for registration if the registering
authority so directs.(4)The registering authority shall, after satisfying itself that the inland vessels is
not defective in hull, machinery or equipment and is river worthy, either issue a fresh certificate of
registration or make such alteration in the certificate of registration in force as he may deem
necessary. If the registering authority is of the view that a fresh survey should be conducted before
issue of fresh certificate of registration, he shall direct the owner to apply for survey. Such survey
shall be completed within one month.(5)In case the registering authority directs that the vessel be
registered a new, the registering authority shall provisionally endorse the particulars of theBihar Inland Vessels Rules, 2013

alteration on the existing certificates.
17.
The owner or master of an inland vessel may apply for transfer of registration of his vessel in Form
No.16. The application for such transfer shall be made to the registering authority where the inland
vessel is registered along with fees as specified in schedule-I paid through treasury Challan/Bank
draft/ E-payment receipt and a certificate of registration in respect of the vessel. If the transfer is to
be made to another state, an authenticated copy of approval of the Central or State Government to
such transfer shall be attached with the application. The registering authority on receipt of such
application and on satisfying himself that there is no ground of objection for such transfer, forward
the same to the registering authority of the intended place of registration and shall return the
certificate of registration to the applicant after making necessary entries in his book or registration
and on the certificate.
18.
The application of transferring registration should be accompanied by a treasury Challan/Bank
draft/ E-payment receipt showing that the fees as specified in the schedule-I. Such transfer of
ownership shall be executed in Form No. 17. The deed of sale shall bear stamped fee as applicable.
Every such deed of sale being duly executed shall be produced before the registering authority of the
place where the inland vessel is registered and the registering authority shall thereupon enter in the
registration book, the name of the transferee as owner/co-sharer of the inland vessel and shall
endorse on the deed of sale that such entry has been made together with date and time. Within 30
days of transfer of ownership of the inland vessel/ entry of one of co-sharer, the transferor and
transferee shall jointly make a report of the transfer to the registering authority within the local
limits of whose jurisdiction the transferee resides or carries on business together with deed of sale
and the treasury Challan/Bank draft/ E-payment receipt showing fees as specified in the schedule-1
have been paid. The registering authority on satisfaction that the documents are in order and that
the inland vessel is not defective shall enter the particulars of the transfer of ownership of the vessel
in the certificate of registration. The application for transfer of ownership shall be made in Form
No.18 along with fees in treasury Challan/Bank draft/ Epayment receipt as specified in the
Schedule-1.
19.
(1)If at any time a certificate of registration is lost, the owner shall forthwith intimate the fact in
writing to the registering authority by whom the certificate was issued and shall apply in Form
No.19 to the said authority for issue of duplicate certificate. The application for duplicate certificate
shall be accompanied by treasury Challan/Bank draft/ Epayment receipt indicating payment of fee
at the rate specified in schedue-1. The mutilated certificate where a duplicate is sought because of
mutilation shall also be deposited along with the application.(2)On receipt of such application, the
registering authority shall issue a duplicate certificate with the word duplicate certificate and
stamped boldly in red ink thereon.(3)If a duplicate certificate of registration has been issued uponBihar Inland Vessels Rules, 2013

the original having been lost and the original is subsequently found by the holder of the duplicate
certificate, the original certificate shall be deposited forthwith by him to the registering authority.
20.
(1)Any person preferring an appeal against the orders of the registering authority in respect of any
matter relating to the registration of vessels shall do so in writing to the secretary to the state
Government in Transport Department in the Performa in triplicate within thirty days from the
receipt of the order of the registering authority accompanied by a certified copy of the order and
treasury Challan/Bank draft/ E-payment receipt after depositing the fee mentioned in
schedule-1(2)Upon receipt of memorandum of appeal in accordance with sub-rule (1), the appellate
authority shall fix the time and place for hearing and shall not give less than fifteen days notice to
the appellant, the registering authority and any other person interested in the appeal.
21.
(1)The registering authority or any officer authorized by the State Government in this behalf may go
on board, detain, or inspect any vessel at any hour for the purpose of satisfying himself that the
provision of the Act, are being complied with. It shall be the duty and responsibility of the owner or
master of the inland vessel to give all reasonable assistance to the inspecting officer in carrying out
the inspection and to comply with any lawful directions that he may give.(2)In case any inland
vessel is detained, a report of the circumstances in which the detention is ordered shall be sent to
the registering authority and the Director of Inland Water Transport within forty eight hours.(3)The
registering authority at any time, if satisfied that the vessel is in a condition not fit to ply in the
Inland water, suspend the registration of the vessel and require the owner thereof to surrender forth
with certificates of survey and registration in respect of that vessel. Before cancellation, the owner of
the vessel should be given an opportunity to be heard. A registering authority may also
suspend/cancel a certificate of registration if the vessel has been destroyed or rendered permanently
unfit for service.(4)No certificate shall be suspended under section 19N of the Act without giving
owner a reasonable opportunity of being heard in respect of the grounds on which the suspension of
the certificate is proposed.Chapter - 4.0 Certificate of Competency to Engineer and Engine Drivers
of Inland Vessels
22. Minimum Crew/Manning.
- The manning requirement under section 25,26,27 of the Act, requirement of the Master, Engineer,
Engine Driver, crew, lascars, greasers for various categories of vessels to ensure safety of the
passengers/cargo shall be prescribed by the authority/surveyor with due consideration of the
operating conditions. No person who in the opinion of the surveyor/competent officer is not fully
qualified or is inefficient shall be employed in any capacity in a vessel.Every vessel registered under
these rules shall have on board minimum following crew when in operation.(1)For vessels having
inboard engine of 565BHP or more(a)one master with first class master's certificate(b)one engineer
with engineer certificate(c)Two lascar(d)One greaser(2)For vessels having inboard engine of
226BHP but less than 565BHP(a)one master with second class master's certificate(b)one engineerBihar Inland Vessels Rules, 2013

with 1st class engine driver certificate(c)one lascar(d)one greaser(3)For vessels having inboard
engine less than 226BHP .(a)one master with Serang certificate(b)one engineer with 2nd class
engine driver certificate(c)one lascars(d)One greaser
23.
(1)Examination for the grant of certificate of competency as inland vessel engineer, First class
engine driver, second class engine driver, shall be held by the examiner at such place on such dates
as may be published by examiner/ chief examiner.(2)Every application for examination shall be
filled and submitted in Form No-20 appended to these rules. The application so filled shall be
received at the examination centre, before the date fixed for examination and shall be accompanied
by-(a)attested copy of all the testimonials of both practical and theoretical experience of the
candidate;(b)testimonials of good character from the employer,(c)receipt or challan showing that
the amount of fee prescribed hereunder for such examination at which the candidate wishes to
appear has been paid;(d)any certificate granted to the applicant under these rules;(e)two copies of
recent bust photograph bearing the signature or thumb impression of the application on the
back;(f)authentic proof of age;(3)No candidate shall be granted competency certificate unless he
produces a medical certificate from a Registered Medical Officer that he is medically fit to carry out
jobs and board inland vessels port crafts etc. and is not colour blind.(4)All candidates who, desires
to appear for the examination of Competency as Engine Drivers and Engineers on Inland Vessels
should have completed the four basic safety courses from National Inland Navigation Institute
(NINI), Patna or from any other institute recognized by Transport Department Or approved by DG
Shipping namely:(i)Elementary First Aid (EFA)(ii)Proficiency in survival techniques
(PST)(iii)Personal safety and social responsibility (PSSR)(iv)Fire Prevention and Fire fighting
(FPFF)(5)No candidate shall be granted Certificate of Competency as Engine Drivers and Engineers
on Inland Vessels without passing the relevant examination of Competency specified
hereunder.(6)A candidate who has served as an engineer of a vessel of the Coast Guard, Indian Navy
or regular Army for a period of 5 years may be granted a Certificate of Service as Engine Drivers and
Engineers on Inland Vessels, depending on the size of vessel served and on successful completion of
relevant preparatory course including the four basic safety courses from National Inland Navigation
Institute (NINI), Patna or from any other institute recognized by Transport Department or
approved by DG Shipping.(7)A certificate of service so granted as per para (6) above shall have the
same effect as a certificate of competency granted under these Rules. A certificate of Service so
issued shall be issued in Form No. 30.(8)The Chief Examiner may if he thinks fit grant a license
authorizing a person to act as master or engineer, as the case may be of any inland mechanically
propelled vessels having engines of one hundred and seventy nominal horse-power or of such less
nominal horse power as he may deem fit who is in possession of a first-class, engine-driver's
certificate granted under these rules or an engine-driver's certificate granted or deemed to be
granted under the Merchant Shipping Act, 1958, and has, by virtue of such certificate, served as an
engine driver of an inland mechanically propelled vessels having engines of not less than seventy
nominal horse-power for five years, for not less than two and a half years of which period he has
been the engine-driver of such vessel.(9)Any license granted under para (8) above shall remain in
force only for such time as the person holding the same is in the possession of engine-driver's
certificate of the nature referred to in para (8) above. Provided that the State Government may if itBihar Inland Vessels Rules, 2013

thinks fit, suspend, cancel or vary the conditions of any such licenses.(10)Every certificate of
competency or service and every license granted under these rules shall be made in duplicate, and
one copy shall be delivered to the person entitled to the certificate, or licence and the other shall be
kept and recorded in the prescribed manner.Qualifications for Certificate of Competency as Second
Class Engine Driver of Inland Motor Vessels
24.
A candidate shall not be admitted to the examination unless he:-(i)is a citizen of India;(ii)has
obtained 21 years of age on the date of examination;(iii)is able to read and write Hindi in Devnagri
Script.
25. Qualifications.
(1)Such candidate shall have minimum qualification of eighth Class pass in English or Hindi from
recognized and knowledge of regional language.(2)Such candidate other than for armed forces and
paramilitary persons who desires to appear for examination of Competency as Second Class Engine
Driver of inland vessel should have undergone Induction Training for Rating (Engine) at NINI or
from any other institute recognized by Transport Department.If the first service is after
promulgation of these rules the training period of the respective course shall be considered as a
service for the purpose of computing the total qualifying service.(3)Candidates should have attended
preparatory Course for Second Class Engine Driver at NINI or at any institute recognized by
Transport Department.(4)Such candidate should have served:-(a)for a period of not less than four
years in the engine room of a motor vessel of not less than 226 brake horse power, of which period
not less than one year must have been served as Assistant Driver or total of four years service as GP
rating or rating (engine) of which at least six month shall be on Inland vessel plying in the
Port/Inland Rivers of the State/candidate is appearing for the examination of 2nd Class Engine
Driver; or(b)for period of not less than five years in the engine room of motor vessel having engines
of not less than 85 brake horse power, or six years in the engine-room of a vessel having engines of
not less than 40 brake horse power of which period not less than one year should have been as
assistant driver or oilman. or(c)such candidate who has passed Matric Examination from recognized
school board must have three years of service at or on Inland Waters, one year of which service must
be as an Oilman or as an Assistant Driver and should have performed at least six months service on
board the vessel plying in the Port/Inland Rivers of the State/candidate is appearing for the
examination of 2nd Class Engine Driver.(d)Such candidates who have passed class X ( Matric)
examination from recognized board and undergone one year Inland Vessel Cadets Training at
National Inland Navigation Institute (NINI), Patna shall have two years of services at sea or on
Inland waters, if the total service has been performed as Inland Vessel cadet apprentice with
onboard vessel Structured Training Program verified in record book and approved or conducted by
NINI and should have performed at least six months watch keeping service under qualified second
class engine driver or First class engine driver or Inland vessel Engineer on board the vessel plying
in the port/Inland Rivers of the Stated where the candidate is appearing for the examination of
second class engine driver.Bihar Inland Vessels Rules, 2013

26. Knowledge required.
- Such candidate shall:-(a)Satisfactorily pass an examination on the working of the various types of
internal combustion engine and be able to name the principal parts of the machinery;(b)be required
to know what attention is required by various part of the machinery, understand the use and
management of the different valves, forks, pipes and connections and be familiar with the various
methods of supplying air and fuel to the cylinder.(c)be required to be able to describe the chief
causes which may make the engine difficult to start and explain how he would proceed to remedy
any defects connected therewith; he shall be able to show that he understands the mechanism of the
starting and reversing arrangements and that he is competent to deal with defects therein;(d)be
required to be able to overhaul an engine, to adjust the working parts and to put the engine together
again in good working condition. He shall be required to understand how to make good the result of
ordinary wear and tear to the machinery and how to correct defects from accidents.(e)be required to
be familiar with the nature and properties of the various fuel oils used in internal combustion
engines. He must understand what is meant by flash point and(f)be required to know the dangers
resulting from leakage from the fuel oil tanks and must understand the precautions to be taken
against explosion. He shall also able to take the necessary precautions to guard against the escape of
inflammable vapour from the vapouriser when the engines are stopped. He must know how to deal
with fire if it break out.(g)Practical test.- The candidate shall also be able, if required to show his
practical knowledge by actually working the engine of a motor vessel in the presence of the
Examiner.Qualification for Certificate of Competency as a First Class Engine Drivers of Inland
Motor Vessels
27.
A candidate for a Certificate of Competency as First Class Engine Driver of an inland motor vessel
shall be not less than 21 years of age, and have following minimum qualifications:-(1)Such
candidates should possess Certificate of Competency/service as 2nd Class Engine Driver.(2)Such
candidate, who desire to appear for examination of Competency as First Class Engine Driver of an
Inland motor vessel should undergo Preparatory Course for 1st class engine driver in NINI or from
any other institute recognized by Transport Department.The training period of the respective course
shall be considered as a service of the purpose of computing the total qualifying service.(3)Such
candidate should have served:-(a)for a period not less than one year as Assistant Engine driver on
regular watch on the main engines of a motor vessel of not less than 565 break horse power, while
holding a Second Class Engine Driver's Certificate for a motor vessel; or(b)for a period of not less
than 24 months as Assistant Engine Driver/Oil man with a Second Class Engine Driver's
Certificated of motor vessel in change of a watch on the main engine of a motor vessel of not less
than 226 brake horse power; or(c)for a period of not less than three years in the engine room of a
motor vessel of not less than 226 brake horse power of which period not less than one year should
have been served as an assistant driver or oilman whilst holding a Second Class Engine Driver's
Certificate for motor vessels; or(d)for a period of not less than 18 months with a Second Class
Engine driver's certificate for motor vessels as driver in charge of the engine of a motor vessel of not
less than 113 brake horse power.Bihar Inland Vessels Rules, 2013

28. Additional qualification.
(1)Such a candidate shall pass examination similar to that required by rule 26 for a Second Class
Engine Driver's Certificate but of a more advanced stage.(2)Such candidate who desire to appear for
examination of Competency of First Class Engine Driver should be able to overhaul an engine, to
adjust the working parts and to put the engine together again in good working condition. He shall
also be required to understand how to make good the result of ordinary wear and tear to the
machinery and how to correct defects for accidents. He should know valve setting and injector
setting of marine engine and be able to replace lines and head of engines with appropriate
knowledge of torque and head of engine with appropriate knowledge for trouble shooting of
engines.Qualifications for Certificate of Competency as Inland Engineers of Inland Motor Vessels.
29. Age.
- A candidate for a Certificate of Competency as Inland engineers of an inland motor vessel shall not
be less that 21 years of age.
30. Qualifications. - (1) Such candidates who desire to appear for
examination of Competency of Inland Motor Vessel should undergo
Preparatory course for Inland Engineer in NINI or from any other institute
recognized by Transport Department.
The training period of the respective course shall be considered as service for the purpose of
computing the total qualifying service.(2)(a)He should hold 1st Class Engine Driver Competency
Service Certificated under the Inland Vessels Act, 1917 (I.V.Act 1 of 1917)(b)He should have worked
for 18 months on a vessel having engines more than 226 BHP or he has to work more than 27
months on a vessel having less than 226 BHP while holding 1st class engine driver certificate issue
under the Inland Vessel Act, 1917 (I.V. Act 1 of 1917).(3)Knowledge required: - Such candidate
should:-(a)be able to write a legible hand and have a good knowledge of arithmetic up to and
including vulgar and decimal fractions and square root. He shall also be able to work out questions
relating to spring or level loaded safety and relief valve, consumption of oils and stores capacities of
tanks to bunkers, speed of vessels and other similar problem and be to calculate suitable working
pressures for air received of given dimensions and the stress per square inch on crank and tunnel
shafts and other parts of the machinery when the necessary data are furnished;(b)be able to give a
clear explanation of the principles on which oil, gas or other internal combustion of the principles
on which oil, gas or other internal combustion engine works, including the methods of ignition, to
point out the difference between them and to show by means of illustrative sketches and otherwise,
that he understands the details of the constructions of those in general use.(c)be familiar with the
various methods if supplying air and fuel to the cylinders in the different types of engines, the
constructions of the apparatus for carbureting, atomizing or gasifying the fuel, and the means for
cooling the cylinders, pistons, etc.(d)have satisfactory knowledge of the process employed in the
construction of internal combustion engines in the workshop and of the methods used in fitting the
machinery on board a ship.(e)Know what attention is required by the various parts of the machineryBihar Inland Vessels Rules, 2013

and understand the use and management of the deferent valves, cocks, pipes and connections.(f)be
able to state and describe the chief cause which may make the engine difficult to start and explain
how he would proceed to remedy any defects arising there from. He shall also be able to show that
he understands the mechanism of the starting and reversing arrangements and is competent to deal
with defects therein.(g)understand how to make good the result of ordinary wear and tear to the
machinery, how to test the fairness of shafting, etc. and how temporary or permanent repair could
be affected in case of derangement or total breakdown.(h)understand the construction of the
pressure gauge, barometer, thermometer and other instruments used in the engine room and the
principle on which they work.(i)understand the construction and working knowledge of centrifugal
bucket and plunger pumps and the principles on which the work.(j)the provisions of the I.V. rules
for Life Saving, Fire Appliances and general discipline.Chapter - 4.1 Certificate of Competency to
Masters and Serangs of Inland Vessels
30.
(1)Examination for the grant of certificate of competency as inland vessel Master Class I , Master
Class II and Serang shall be held by the examiner at such place on such dates as may be published by
the examination centre..(2)Every application for examination shall be filled and submitted in Form
No-20 appended to these rules. The application so filled shall be received at the examination centre
before the date fixed for examination and shall be accompanied by-(a)attested copy of all the
testimonials of both practical and theoretical experience of the candidate;(b)Testimonials of Good
Character from the Employer.(c)receipt or challan showing that the amount of fee prescribed
hereunder for such examination at which the candidate wishes to appear has been paid;(d)any
certificate granted to the applicant under these rules;(e)two copies of recent bust photograph
bearing the signature or thumb impression of the application on the back;(f)authentic proof of
age;(3)All candidates who, desires to appear for the examination of Competency as Serang, Second
Class Master and First Class Master should have completed the four basic safety courses From
National Inland Navigation Institute (NINI), Patna or from any other institute recognized by
Transport Department or approved by DG Shipping namely:(i)Elementary First Aid
(EFA)(ii)Proficiency in survival techniques (PST)(iii)Personal safety and social responsibility
(PSSR)(iv)Fire Prevention and Fire fighting (FPFF)(4)No candidate shall be granted competency
certificate unless he produces a medical certificate from a Government Medical Officer that he is
medically fit to carry out jobs and board inland vessels port crafts etc. and normal colour vision and
6/6 vision in each eye, and is not colour blind.(5)No candidate shall be granted Certificate of
Competency as Serang, Second Class Master and First Class Master without passing the relevant
examination of Competency specified hereunder.(6)A candidate who has served as a master, or as
an engineer of a vessel of the Coast Guard, Indian Navy or regular Army for a period of 5 years may
be granted a certificate of service as a first-class master, second-class master or serang, depending
on the size of vessel served and on successful completion of relevant preparatory course including
the four basic safety courses from from National Inland Navigation Institute, Patna or from any
other institute recognized by Transport Department or approved by DG Shipping.(7)A certificate of
service granted as per Para (6) shall have the same effect as a certificate of competency granted
under these Rules. A certificate of Service so issued shall be issued in Form No. 30.(8)The Chief
Examiner may if he thinks fit grant a license authorizing a person to act as master or engineer, asBihar Inland Vessels Rules, 2013

the case may be of any inland mechanically propelled vessels having engines of one hundred and
seventy nominal horse-power or of such less nominal horse power as he may deem fit who is in
possession of a second-class master's certificate granted as per these rules and has, by virtue of such
certificate, acted as master of an inland mechanically propelled vessels having engines of forty or
more nominal horse-power for a period of not less than five years.(9)Any license granted under para
(8) above shall remain in force only for such time as the person holding the same is in the
possession of engine-driver's certificate of the nature referred to in para (8) above. Provided that the
State Government may if it thinks fit, suspend, cancel or vary the conditions of any such
licenses.(10)Every certificate of competency or service and every license granted under these rules
shall be made in duplicate, and one copy shall be delivered to the person entitled to the certificate,
or licence and the other; shall be kept and recorded in the prescribed manner.
31. Qualification for Certificate of Competency as a Serang.
(1)A candidate shall not be admitted to the examination, unless he-(i)is a citizen of India;(ii)has
obtained 21 years of age on the date of examination;(iii)is able to read and write Hindi in Devnagri
Script.(2)Qualifications. - A candidate for a Certificates of Competency as Serang shall have
minimum qualification of eighth standard passed in English or Hindi or a regional
language.(3)Candidates who, desires to appear for the examination of Competency as Serang should
produce the Certificate of Preparatory Training Course from from National Inland Navigation
Institute, Patna or from any other institute recognized by Transport Department.The training period
of the respective course shall be considered as a service for the purpose of computing the total
qualifying service.(4)Candidates other than for armed forces and paramilitary persons ,who desires
to appear for the examination of Competency as Serang should have undergone Rating Induction
Training if the date of beginning of first qualifying service is after these rules comes in effect. The
training period of the course shall be considered as a service for the purpose of computing the total
qualifying service.(5)Such candidates should have four years of service at sea or on Inland Waters
vessels having engine not less than 226BHP or for a period of five years on vessels having engine not
less than 85BHP or for a period of six years of vessel having engine not less than 40BHP, , one year
of which service shall be as helmsman or an Assistant Master (Deck) or Sukani and should have
performed of at least six months service on board the vessel plying in the port/Inland Rivers of the
State where the Candidate is appearing for the examination of Serangs or(6)Such candidates who
have passed Matric examination from recognized board and have three years of services at sea or on
Inland waters, one year of the service shall be helmsman or as Assistant Master or Sukani and
should have performed at least six months service on board the vessel plying in the port/Inland
Rivers of the State where the candidate is appearing for the examination of Serang. Or(7)Such
candidates who have passed class X ( Matric) examination from recognized board and undergone
one year Inland Vessel Cadets Training at National Inland Navigation Institute (NINI), Patna shall
have two years of services at sea or on Inland waters, if the total service has been performed as
Inland Vessel cadet apprentice with onboard vessel Structured Training Program verified in record
book and approved or conducted by NINI and should have performed at least six months watch
keeping service under qualified serang or First Class Master or Second Class Master on board the
vessel plying in the port/Inland Rivers of the State in which he is appearing for examination of
serang. Or(8)Such candidates who have served in flood or water transport company of police, P.A.C.Bihar Inland Vessels Rules, 2013

or other Paramilitary forces for 5 years or more.(9)The candidate appearing for the examination of
Serang and shall be examined in the following subject:-(a)the rules of the road as regards both
sailing vessels and mechanically propelled vessels, their regulation, lights, fog and sound
signals:(b)the marking and use of the lead line and knowledge of the compass;(c)Management of a
boat under oars or sail;(d)Steps to be taken in the event of vessel grounding;(e)Management of
inland vessels under all conditions;(f)Management of inland vessels under tow or when
towed(g)Partial questions on carriage of iron ore, coal, ODC, Petroleum Products;(h)the provisions
of the I.V. rules for Life Saving, Fire Appliances, collision avoidance and general discipline.(i)The
provisions of the rules with regards to carriage of passengers.
32. Qualification for Certificate of Competency as a Second Class Maste.
-
1. Age. - A candidate for a Certificate of Competency as Second Class Master
of an Inland Vessel shall not be less than 21 years of age.
2. Qualifications. - (1) A candidate for Certificate of Competency as Second
Class Master should hold certificate of Competency as Serang.
(3)Such candidates who desire to appear for the examination of Competency as 2nd Class Master
should undergo Preparatory Course of II Class Master at National Inland navigation Institute,
Patna. or from any other institute recognized by Transport Department.The training period of the
respective course shall be considered as a service for the purpose of computing the total qualifying
service.(4)Such candidates should have two years service as Helsman Sukani of inland vessel having
not less than 282 BHP or three years service as Serang of an Inland Motor vessel having less than
282 BHP. A candidate for certificate of Competency as Second Class Master shall be examined in the
following subjects:-(a)Management of inland vessels under all conditions;(b)Knowledge of storm
and distress signals;(c)Knowledge of the compass;(d)Knowledge of inland waters of NW-1, its
anchorages, shoals, buoyage, beacons, lights and other such matters.(e)The rules of the road as
regards to both, sailing vessels and mechanically propelled vessels, their regulation, lights, fog and
sound signals:(f)The marking and use of the lead line;(g)Steps to be taken in the event of vessel
grounding;(h)Management of inland vessels under tow or when towed or pushing(i)Questions on
carriage of iron ore, coal, ODC, Petroleum Products, cement, fly ash, containers;(j)The provisions of
the rules made by IWAI in respect of Life Saving and Fire Appliances and Conduct of Vessels.(k)The
provisions of the rules with regards to carriage of passengers.(l)Knowledge of Loading Marks and
Stability of Inland vessels.(m)Knowledge of Inland Vessel act and Relevant DG notices.(n)Use of
GPS, DGPS, VHF, Radar, ARPA and Echo sounder for safe navigation of vessel to be demonstrated
in Simulator.Bihar Inland Vessels Rules, 2013

6. No refund of fee permitted. - The fee which the candidate has paid shall not
be refunded to him and on presenting himself, when entitled so to do, for
re-examination for the higher grade of certificate, he shall be required to pay
the full fee again.
33. Qualification for Certificate of Competency as a First Class Maste.
- 1. Age. - A candidate for a Certificate of Competency as First Class Master of an inland vessel shall
not be less than 21 years of age.
2. Qualifications. - (1) A candidate for Certificate of Competency as First
class Master should hold Certificate of Competency as Second Class Master;
(2)Such candidate who desires to appear for the examination of Competency as 1st Class Master
should undergo Preparatory Course for 1st Class Master in at national Inland Navigation Institute or
from any other institute recognized by Transport Department.The training period of the respective
course shall be considered as service for the purpose of computing the total qualifying
services;(3)Such candidate should have served:-(a)as Master of a Motor vessel of not less than
226BHP for a period not less than 27 months, while holding a Certificate of Competency as Second
Class Master.Or(b)as Assistant Master of a vessel of not less than 565 BHP while holding a
Certificate of Competency as Second Class Master for a period of not less than 18
months.(4)Additional knowledge. - In addition to the knowledge required for the grades of Serang
and Second Class Master, a candidate for certificated of Competency as First Class Master shall be
examined in each of the following subjects:-(a)Knowledge of tide-tables and effect of
currents;(b)Knowledge of hydrographic charts of National Waterway- 1;(c)Knowledge of handling
twin screw vessels.(d)Writing of log books,(e)Knowledge of weather and waves.(f)Knowledge to be
able to make use of weather reports issue for the areas;(g)Seasons and general weather of the area
through out the year;(h)Knowledge of loading, Stowing, Securing, Carrying and Unloading of
different types of cargoes.(i)Knowledge of Stability of vessels and effects on
Grounding.(j)Knowledge of fire fighting appliances, light and sound signals, life saving appliances
and their uses;(k)Knowledge of the provisions of the Inland Vessels Act, 1917 (Central Act 1 of 1917),
and the rules framed there under;(l)Knowledge of IWAI rules pertaining to terminals and
ports.(m)Knowledge of Kolkotta Port Rules and also Customs Regulations in so far as they are
applicable to inland mechanical propelled vessels;(n)Signaling, recognition of alphabet and
numbers through the international Code of Flags, Morse and use of ensign flag;(o)Knowledge of use
of Mariner's Compass and Gyro Compass and find and apply the errors on the
Compasses.(p)Knowledge of the rules with regards to Prevention and Control of Pollution and
protection of Inland waters and Coastal Areas.(q)The provisions of the I.V. rules for Life Saving, Fire
Appliances, collision avoidance and general discipline.(r)Knowledge of the provisions of section 134,
Chapters X, XI and XII of the Motor Vehicles Act, 1988 (59 of 1988) as applicable to the Inland
Vessels.(5)The candidate shall have successfully completed Inland Vessel Maneuvering Simulator
course at National Inland Navigation Institute, Patna or from any other institute recognized by
Transport Department.(6)Every candidate shall pay the following examination fees to theBihar Inland Vessels Rules, 2013

examination centre for appearing at the examination as required under rule 30, which shall not be
returnable -(1)First Class Master/ Inland Vessel Engineer Rs. 2000-00(2)Second Class Master/First
Class Engine Driver Rs. 1600-00(3)Serang/ Second Class Engine Driver Rs. 1000-00Above fee can
be revised by the Transport Department from time to time.(7)A certificate of competency of 1st Class
Master, 2nd Class Master and Serang of inland vessel shall be issued in prescribed
Form.(8)Duplicate of all certificates granted under these rules shall be recorded in the office of the
Inland water transport, Patna.
34. Grant of Certificate.
- 1. A person who has served as a master or engineer on a vessel of the Coast Guard, Indian Navy or
Army for a period of 3 years shall be granted certificate of competency as serang, first class or
Second class master or Inland vessel engineer, first class or second class engine driver subject to the
following:(1)Satisfactory completion of relevant preparatory course at NINI or from any other
institute recognized by Transport Department.(2)Satisfactory completion of four basic courses
2. A person who has served in flood or water transport company of police,
P.A.C. or other Paramilitary forces for 3 years or more shall be granted
license as boat handler subject to the following:
(1)Satisfactory completion of Boat Handler Course at NINI or from any other institute recognized by
Transport Department.(2)Satisfactory completion of four basic courses.(3)A license, certificate of
competency or service granted by the state government to a master or engineer shall be valid
throughout India.
4. Form and Validity of Certificate of competency
(1)Certificate of Competency shall be issued in the appropriate forms
a.Inland Vessel Engineer Form 21
b.First Class Engine Driver Form 22
c.Second Class Engine Driver Form 23
d.First Class Master Form 24
e.Second Class Master Form 25
f.Serang Form 26
(2)The validity of all competency certificates issued for the first time to the candidates who pass the
Masters, Serangs, Engineers, Engine Drivers or Lascar's examination shall be for period of of five
years.(3)Master's, Engineer's, Engine Driver's, Searng's certificate of competency shall be renewed
for five years at a time on expiry of their validity.(4)Application for renewal shall be made to the, at
any examination centre with appropriate fees.(5)Any certificate not so renewed shall lapse, A lapsed
certificate if not more than three years, shall be renewed after paying one extra fees and giving
satisfactory reason for the same. After three years the certificate shall be renewed after undergoingBihar Inland Vessels Rules, 2013

oral examination and if found satisfactory the examiner may recommend for renewal of the license
after paying one extra fees.(6)Whenever a master or serang, or an engineer or engine-driver, proves,
to the satisfaction of the Chief Examiner that he has, without fault on his part, lost or been deprived
of it, a copy of the certificate or license to which according to the record kept hereunder he appears
to be entitled shall be granted to him and shall have the same effect as the original.(7)Any certificate
granted or any endorsement made under this chapter may be suspended or cancelled by the
Government of Bihar in the following cases, namely:-(a)if, on any investigation made under the IV
Act, the Court reports that the wreck or abandonment of or loss or damage to, any vessel, or loss of
life has been caused by the wrongful act or default of the holder of such certificate, or that the holder
of such certificate is incompetent, or has been guilty or any gross act of drunkenness, tyranny or
other misconduct, or(b)if the holder of such certificate is proved to have been convicted of any
nonbailable offence, or(c)if the holder of such certificate is proved to have deserted his vessel or has
absented himself, without leave and without sufficient reason, from his vessel or from his duty;
or(d)if, in the case of a person holding a certificate of competency or service and second-class
master or serang, or as engine-driver, such person is or has become, in the opinion of the State
Government, unfit to act as a second-class master or serang or an engine-driver, as the case may
be;(8)Every person whose certificate is suspended or cancelled under this Chapter shall deliver it to
the Chief Examiner.(9)State Government of Bihar or Chief Examiner may revoke any order of
suspension or cancellation which it may have made under this Chapter to grant new certificate, or
grant, without examination to any person whose certificate it has so cancelled a new certificate. A
certificate so granted shall have the same effect as a certificate of competency granted under this Act
after examination.Chapter - 5.0 Protection of and Carriage of Passengers Inland Vessel
35.
The master or any employee authorized in this behalf by the owner or master of any inland vessel,
may refuse to admit any person on the Inland Vessel as a passenger,-(a)if he has not paid his fare;
or(b)if he is insane; or(c)if he is suffering from an infectious or contagious disease; or(d)if he is
drunk and incapable of taking care of himself; or(e)if he is disorderly, or if he is otherwise in such a
state or is conducting himself in such a manner, as to cause or likely to cause annoyance to other
passengers; or(f)when the Inland vessel, or the part thereof to which such person seeks admission,
already contains the maximum number of passengers which may lawfully be carried therein.
36.
(1)No passenger shall,-(a)travel, or attempt to travel in an inland vessel without having previously
paid his fare; or(b)travel, or attempt to travel in accommodation of a higher class than that for
which his fare has been paid, or(c)travel beyond the place to which his fare has been paid without
previously paying the additional fare in respect of the additional distance; or(d)use, or attempt to
use ticket on any day for which such ticket is not available; or(e)take, or attempt to take luggage with
him without having previously paid the freight, if any; payable in respect thereof.(2)Every passenger
of an inland vessel shall, when required by the master or any person authorized in this behalf by the
master or owner-(i)pay his fare, if not already paid,(ii)present his ticket for examination,(iii)deliver
such ticket at or near the end of the journey.(3)No passenger shall alter or deface his ticket so as toBihar Inland Vessels Rules, 2013

render illegible the date or number or any other material portion thereof.
37.
(1)No passenger shall take with him or keep on board an inland vessel:(a)any decayed meat, fish or
vegetable, or any such other offensive article.(b)Any dangerous and explosive material.(2)No
passenger on an inland vessel shall,-(a)obstruct or impede the master or any other officer of the
Inland vessel in the discharge of his duties;(b)in any way obstruct or interfere with the loading or
unloading of luggage or cargo;(c)damage, or attempt to damage the Inland vessel or any article on
board thereof;(d)enter or leave to attempt to enter or leave, any inland vessel when such Inland
vessel is in motion;(e)without lawful excuse, enter a compartment or place reserved for the use of
another passenger or refuse to leave it when required to do so by the master or any other officer of
the Inland vessel;(f)smoke or be in possession of a fire or light, in any part of the Inland vessel
where smoking or the possession of a fire or light is not permitted by the master thereof;(g)be drunk
and disorderly, or drunk and incapable of taking care of himself;(h)commit any nuisance or act of
indecency or use obscene or abusive language;(i)without lawful excuse, molest or interfere with the
comfort of any other passenger.(3)No male passenger on an inland vessel, knowing that a
compartment or place has been reserved for the exclusive use of females, shall enter such
compartment or place without lawful excuse, or having entered it, shall remain therein after being
required by the master, or any other officer of the Inland vessel to leave it.
38.
The master or owner or any employee authorized in this behalf by the owner or master, of any
inland vessel may make the following passengers leave the Inland vessel, namely:-(a)insane
passengers, and their attendants (if any), if they have embarked without the special permission of
the master, or of the authorized employee;(b)passengers suffering from an infectious or contagious
disease, when they have embarked without the special permission of the master or owner or of the
authorized employee;(c)passengers who are drunk and incapable of taking care of
themselves;(d)passengers who are disorderly, or are otherwise in such a state, or are conducting
themselves in such a manner, as to cause or likely to cause annoyance to other passengers;(e)any
passengers who have embarked in excess of the maximum number of passengers which may lawfully
be carried in the Inland vessel or in the part of the inland vessel thereof in which they propose to
travel; and(f)passengers who have not paid their fare.
39.
A person who has been refused permission to an inland vessel under rule 35 shall not embark
thereon; and a person who is required under rule 38 to leave an inland vessel shall leave at such
convenient time and place as the master/ owner or authorized employee may direct:Provided that
any person who is refused admission under clause (e) of rule 38 to leave shall be entitled to have his
fare refunded to him.Bihar Inland Vessels Rules, 2013

40.
Any passenger who, with intent to defraud, commits any breach of rule 36, and any person who
commits any breach of rule 37, shall be punished with fine of rupees One thousand.
41.
(1)Whenever any case of plague, cholera or other dangerous epidemic disease occurs on board in
Inland Vessel, the master or serang, shall immediately:-(a)remove the patient, together with his
bedding, drinking utensils and food, to a part of the deck at the extreme stern of the Inland Vessel,
where he shall be segregated from the rest of the passengers by a purdah. In the case of plague, the
clothing, bedding, and if considered necessary the baggage of the patient shall be disinfected
immediately;(b)cause all excreta, vomit and urine which may have been discharged on to the dock
by the patient, to be cleaned away with a solution of cyllin: and(c)report the case to the
Sub-divisional or District Magistrate within whose jurisdiction the nearest ghat lies, and also to the
Chief Medical Officer of the district.(2)Where such ghat is not at the headquarters of a sub-division
or district, the report mentioned in sub-clause ( c) of Sub-rule (1) shall be sent by the master or
serang, as the case may be, by the most expeditious means available, to the next headquarters of a
sub-division or district which the Inland vessel will touch.(3)If, when the case occurs, the Inland
Vessel is lying at a ghat at the headquarters of a sub-division or district, or otherwise, when the
Inland Vessel has reached the nearest ghat which is at such headquarters, the master or serang shall
not move the Inland Vessel there from until permission has been given by the District Magistrate or
Sub-divisional Magistrate as the case may be.(4)(a)On receipt of the report mentioned in sub-rule
(1) the Magistrate shall at once depute a Medical Officer to inspect and disinfect the Inland
Vessel.(b)Such Medical Officer shall visit the Inland Vessel and if a suitable hospital is available, or
if other satisfactory arrangements can be made for the patients treatment and segregation, shall
bring the patient to land.(5)Where no such hospital is available, and no such arrangement can be
made, the patient shall not be allowed to land, but the Medical Officer deputed under sub-rule (4)
shall take steps to ensure the proper segregation of the patient on the Inland Vessel, and to satisfy
himself that every possible precaution has been taken to prevent the spread of the disease.(6)The
Medical Officer deputed under sub-rule (4) shall, in all cases, cause the deck cabins, latrines and any
other part of the Inland Vessel, while the patient has been, to be thoroughly washed down with a
strong solution of cyllin, and all utensils which has been used by the patient, to be
disinfected.(7)(a)In case of death, the body of the patient shall be wrapped in a cloth soaked in a
strong solution of cyllin, and made over to his relatives, friends, or where he is without relatives/
friends, to the police, who shall arrange for its disposal.(b)If they have not already been disinfected
in accordance with the provisions of clause (a) of sub-rule (1) of rule 41 the clothes of the deceased
(except those in the baggage), his bedding and all food in his possession shall be burnt, unless
orders to the contrary are passed by the Medical Officer.(8)The Medical Officer deputed under
sub-rule (4) shall ascertain the names and addresses of all members of the party accompanying the
patient, and shall report them through the Sub-Divisional Magistrate to the District Magistrate of
the district to which they are proceeding.(9)When the orders contained in these rules have been
complied with, and the Medical Officer deputed under sub-rule(4) is satisfied that there is no reason
further to detain the inland vessel, he may give permission to the master or serang to proceed on theBihar Inland Vessels Rules, 2013

journey.(10)The owner of every inland vessel shall be bound to keep on board each inland vessel,
five liters of cyllin.(11)The patient may be permitted to land on the expiry of a period to be fixed by
the Medical Officer deputed under sub-rule (4).(12)Any person committing a breach of any of the
above rules shall be punished with fine which may extend upto rupees one thousand.
42.
(1)Before an inland vessel proceeds on a voyage, its cargo and that of any float or floats which are
intended to be towed, shall be safely towed away, and hay or any other inflammable material shall
be properly stowed with tarpaulins or other sufficient protection.(2)Provisions of Section 50 and
section 51 of the Act shall be displayed in some prominent place on an inland vessel.(3)Every person
who takes any dangerous goods with him on board of an inland vessel shall, if required to do so,
hand over the same to the master or owner or an authorized person by the master or owner of the
inland vessel for safe custody.(4)No person shall use naked lights of any description in the hold or
on the cargo deck of any inland vessel; and no closed light shall be used unless it is in the charge of
an officer of inland vessel.(5)Fire stations at the inland vessel shall be assigned to the officers and
crews.(6)No gunpowder or other explosive shall be carried unless it is in a suitably constructed
magazine compartment; and no fire shall be permitted on board of Inland Vessel while gunpowder
is being taken in or discharged.(7)Nothing in sub-rule (2) as to the delivery of dangerous goods to
the master, or in sub-rule-(6) as to the carriage of gunpowder or other explosive in a magazine
compartment, shall apply to the carriage of samples of explosive in the charge of an inspector of
explosives.(8)It shall be the duty of the master or owner of every inland vessel to give affect to, and
observe the above rules, and he or an other person committing a breach of these rules shall be
punished with imprisonment for a term which may extend to six months, or with fine which may
extend up to twenty thousand rupees or with both.
43.
Loading of cargo in Inland Vessel carrying passengers shall be regulated as follows:-(1)Stern wheel
inland vessel with a length of hull of less than 36 meters when carrying cargo on deck or passengers,
shall be fitted with :-(a)Shifting boards amid ships in a fore and aft direction in way of, and height at
least level with, the cargo;(b)a substantial wire net or similar light division on the upper deck
amidships in fore and aft direction at least 1.8 meter high.(2)In all other inland vessels carrying both
passengers and cargo, all cargo, carried on deck shall be efficiently stowed to prevent it from
shifting.(3)A space of at least 75 centimeters wide on each side of the cargo, and within the
bulwarks, shall be kept clear as fore and aft passage way.(4)Any owner or master committing a
breach of these rules shall be punished with imprisonment for a term which may extend to six
months or with fine which may extend to twenty thousand rupees or with both.
44. Freeboard.
(1)In case of passenger vessel when it is loaded with weight representing the full number of
passengers and crew at 65 kg for each person and when all necessary fuel is on board the clear
height of the side above water at the lowest point in not less than 38 cms for vessels 6 m in length orBihar Inland Vessels Rules, 2013

less and 76 cms for vessels 18 m in length and over. For lengths between 6m and 18 m in height shall
be in proportion. The length shall be measured from the forward side of the stem to the after side of
stem post and the clear side shall be measured to the top of the covering board if however a half
deck is fitted the clear side shall be measured to the top of the side at side or to the top of gunwale
whichever measurement gives the smaller free board. In decked boats the free boat shall be
measured from the top of the deck at side.(2)Vessels permitted to ply during foul season shall be
required to have freeboard 1.5 times as of that calculated in sub rule (1).
45.
(1)In all cases in which an inland vessel has sustained damage from any accident, or other cause,
affecting its efficiency, in any part of hull equipment, or machinery, the surveyor of the port where
the inland vessel may be, shall go on board and ascertain the extent of the damage. In doing so, he
will take care not to make any change in the position or condition of things on the board.(2)The
accidental inland vessel shall be surveyed, and a report thereof shall be sent to the Registering
Authority as early as possible.
46.
(1)in cases of collision, the surveyor should examine the lights and screens of the Inland Vessel, and
if the Inland Vessel, with which it has been in collision is within his district he should examine the
lights of the Inland Vessel also, should forward to the Registering Authority examine in a separate
report, a statement in respect of the size, condition, and place of its lamp and screens and whether
in his opinion they are deficient.(2)The surveyors should be very careful in wording their report as
to lights and screens as they may be used in evidence in case taken into Court.(3)If, in consequence
of any accident to an Inland Vessel, or any other reason, the surveyor considers it necessary to
require the vessel to be taken into dock for the purpose of surveying the hull thereof, he may do so,
but he is to be cautious never to exercise this power unless the circumstances of the case actually
require it.(4)Unless directions to the contrary are given by the Registering Authority, the surveyor is
to hold the certificate of the Inland Vessel during the time it is under repair, and for this purpose he
is to require it of the master, unless the damage is such that in the surveyors opinions the certificate
should be cancelled, in which case he should forward it to the Registering Authority with his report.
In all cases of serious damage the certificates should be returned to the Registering Authority to be
cancelled.(5)If the master or owner decline to give up the certificate the surveyor shall inform
immediately to the Registering Authority, and the Director Inland water transport.(6)When the
vessel is in every respect rendered efficient both in hull and machinery to the entire satisfaction of
the surveyor, he is to put an endorsement on the back of the certificate if they have not been
previously cancelled, to the effect that the damage has been made good so as to last for the period
for which the certificate was granted, and return the certificate to the master or owner, or his agent,
and allow the inland vessel to proceed. He is then to send to the Registering Authority a statement to
the extent of repair that was necessary, and endorsement made on the certificate.Bihar Inland Vessels Rules, 2013

47.
In all cases in which a surveyor is directed by the Registering Authority to obtain from an owner or
master a certificate that has expired, or has been cancelled or revoked, he is to apply for it without
delay, and in the event of his application not being attended to, he is at once to report the case. A
fine of two hundred rupees may be imposed on any owner or master who neglects or refuses to
deliver such certificate when required to do so by the Registering Authority.
48.
Notwithstanding anything contained in these rules, the Director Inland Water Transport, by a
general or a specific order, may direct the vessel owners, vessel builders or persons / passengers
involved in any manner with vessel operation to add/ delete / amend certain technical specifications
of vessels or of its operational aspects in order to enhance safety of vessel, monitoring of movement,
passengers comfort and general regulation of the Inland Transport Sector.Chapter - 6.0 Life Saving
Appliances to be Carried on Board Inland Vessels
49. Classification of vessel.
(1)For the purposes of this Rule the inland vessels shall be classified as namely:(a)Class I -
Passenger vessels and Ferry launches boats(b)Class II - Cargo vessels and vessels other than those
falling under Class I, Class III, and IV.(c)Class III - Non-propelled vessels (Barges)(d)Class IV -
Pleasure crafts adventure vessels(2)Required of vessels of Class I(a)Sufficient number of life rafts or
buoyant apparatus to accommodate at least 50% number of passengers and crew on board.(b)One
life jacket for 50% of passengers and crew on board.(c)Life jacket for child, for 10% of total number
of persons certified to carry. For the purpose of this section, child means person below 30kgs.(d)At
least four life buoys for vessels up to 25 meter length, six life buoys for vessel 25-45 meter length
and life buoys more than 45 meter length. At least two of the life buoys shall be with self igniting
light if the vessels navigate at night(e)Every vessels of Class I passenger capacity 150 shall have at
least one life boat with minimum passenger capacity of ten persons. The boat shall be provided with
necessary arrangement for launching. Boats are to be stowed on either side of the vessels if more
than one boat provided.(f)Life boats plus Life rafts plus life jacket together to accommodate 100% of
the passengers and crew on board.(g)All crew boat should posses sufficient training in rescue
working addition to artificial respiration and first aid.(h)All boats have headlights search lights hand
torches and emergency lanterns.(i)Boats should be sturdy and should maintenance standards rigid.
The under water material should be sound, strong and river worthy. In small vessels one pair of ores
should be kept in readiness for use in event of power failure.(3)Requirement for Vessels of Class
II(a)Every vessel of Class II shall be provided with:(i)At least one life raft to accommodate all crew
for vessel over 10 meters.(ii)One life jacket for each crew or persons on board.(iii)At least two life
buoys for vessels upto 25 meter length and four life buoys for above 25 meter of which one shall be
equipped with self igniting light if vessels navigate at night.(b)Life raft plus life jacket plus life buoys
to accommodate 100% of the crew.(4)Requirement for vessels for Class IIIEvery manned vessel of
class III shall be provided with,(a)At least two life buoys, one of which shall be equipped with self
switching light if the vessels navigate at night.(b)One life jacket for every crew onBihar Inland Vessels Rules, 2013

board.(5)Requirement for Vessels of Class IV(a)Every vessel of class IV up to 10 meter in length
shall carry life jacket for each person. Vessel above 10 meter shall carry sufficient life raft for all
persons on board. For small vessels where buoyant apparatus could not be accommodated 100%
buoyancy by way of life jackets and lifebuoys.(b)However all vessels of class IV shall carry at least 2
life buoys of which one shall be of self lighting type if the vessels navigate at night. For small vessels
the buoyant apparatus could not be accommodated 100% buoyancy by way of life jackets and life
buoys.
50. Technical Requirement.
- Every life saving appliances provided as per provisions of these rules shall be of approved type and
have proper stowage as per the satisfaction of the surveyor
51. Display of usage.
- On every vessel of Class I the list of saving appliances and instruction of their use shall be
displayed at conspicuous places.
52. Exemption.
- Vessels or class of vessels whose keel of which is at the corresponding stages of construction before
coming into force of these rules may be exempted from compliance there with of the provision for
carriage of life boats until one year after the date of commencement of these rules provided that
adequate life raft in lieu are provided on board.Chapter - 7.0 Inland Vessels and Firefighing
Equipments
53. This rule should apply to all vessels excepting
(1)Vessels above 500 tons gross. These vessels shall be required to comply with requirements of
Merchant Shipping (Fire Alliances) rule 1969 as applicable to ships on coastal
voyages.(2)Hovercrafts: Requirements in respect of hovercrafts shall be specially considered by the
competent officer.(3)Provided that these rules do not apply to the existing vessels for a period of 6
months from the date of publication of these rules or till their next annual survey whichever is early.
54. Appliances to be carried.
- All inland vessels should be provided with the following type of fire appliances(1)Power Driven
Fire Pump: In every vessel above 150 tons gross at least one.(2)Hand Operated Fire Pump: In every
vessel exceeding 21 meters in length at least one.(3)Water services pipes, Hydrants, Fire houses: In
every vessel required to carry a fire pump with water services pipe hydrants and fire houses so
arranged that at least one powerful jet of water may be directed to any part of the vessel. Hoses shall
not be less than 32mm in dia.(4)Plain Nozzles: One for every fire hose carried in accordance with
these rules(5)Spray Nozzles: One for every fire hose carried in accordance with theseBihar Inland Vessels Rules, 2013

rules.(6)Portable Soda Ash/ water type of fire extinguishers: One in each of the passengers spaces
above the upper deck and with at least two such extinguishers in each of the crew spaces and of the
passenger space below the deck. Provided vessels less than 15 meters in length need carry one such
extinguisher.(7)Portable type of Fire Extinguishers: Atleast two in every machinery
space.(8)Portable Dry Power Type Fire Extinguishers: Having atleast one in every vessel having a
large electrical installation.(9)Fire Axe: At least one in every vessel exceeding 15 meters in
length(10)Fire Buckets: Atleast one for each number of the crew with the minimum of two. Fifty
percent of those buckets are to be fitted with lanyards. No vessels need carry more than 20
buckets.(11)Sand Box with scoop: In every vessel at least one in machinery and boiler spaces.
Quantity of sand shall not be less than 0.075 cubic meters.(12)Non Portable Foam Type Fire
extinguishers. In case of motor vessels exceeding 30 meter length at least one. Capacity of such
extinguishers shall not be less than 45 liters.(13)Smothering Arrangement. All fixed installation in
all vessels having areas containing fuel oil installation shall be covered by smothering arrangements.
55. Approval by Competent Authority.
- If in any case the inland vessel is unable to comply fully with the requirements set out as above, an
all cases of vessel exceeding 45m in length, Or 150 ton gross, the appliances to be provided are to be
referred to the competent officer for approval.
56. Responsibility of Master/Owner.
(1)The master of all inland vessels shall ensure that the vessel is provided with appliances and
equipment for fire fighting and for protection from danger or explosion in accordance with theses
rules and that the crew of the vessel are well conversant with the use of theses appliances.(2)If in
any case an inland vessel is unable to comply fully with the requirements set out in these rules and
in all cases of vessel exceeding 45 meter in length the Fire Appliances to be provided are to be
referred to the component officer for approval.
57. Penalties.
- Any breach of provisions in these rules shall be punishable with Imprisonment for a term which
may extend to 6 months or fine which may extent to 500 rupees or both.Chapter - 8.0 Passenger
Accommodation[Application-This part shall apply to all vessels]
58. Passenger Accommodation.
(1)Area of each part of passenger space and the length of seats therein shall be measured and the
lesser of the numbers given by area and by seating shall be the allowable number during fair season
provided that in open vessels the allowable number of passengers is not to exceed two per 0.3 metre
of length of the vessel and in no case to exceed 100.(2)Total number of passengers permitted to be
carried during the foul season shall not exceed two third the total number allowed for fair season
provided that vessels operating in sheltered waters such as creeks may be permitted to carry sameBihar Inland Vessels Rules, 2013

number of passengers throughout the year.(3)Open Launches:(a)The forward extremity of the space
available for the passenger accommodation is to be determined by the Surveyor, with due regard to
accommodation is to be determined by the Surveyor, with due regard to the proper stowage of the
anchor and cable and to any other necessary equipment in the bow of the vessel, and the length shall
be measured from this point to the foreside of the bulkhead separating the machinery space from
the passenger space.(b)If the machinery is placed amidships, and additional space is available for
passengers between the after bulkhead of the machinery space and a position near the stem of the
vessels, to be determined by the Surveyor as suitable having due regard to the steering
arrangements and fuel tank space, such shall also be considered for accommodating passengers. The
breadths are to be measured at suitable intervals to the back of the side benches or to the inside of
gunwale or to the inside of the half deck( where fitted) whichever measurement is least.(c)The space
abreast of the machinery space may be included in the passenger measurements if the engine is
enclosed by a casting of longitudinal bulkheads and if the distance between the sides of the casing or
bulkheads and the back seats is at least 0.9m.(d)The number of passenger allowable by area shall be
found by dividing by 0.36 the area in square meters of the clear space measured as above. Allowance
shall be made for the crew and baggage in the area measurements (15%). The number allowable by
seating shall be found by dividing the length in meter of each continuous fixed seat by
0.45.(e)Seating on buoyant apparatus shall be computed separately.(4)Decked Launches(a)The
forward extremity of the space available of the space for the passenger accommodation shall be
determined for passenger accommodation shall be determined as above for above foe open for open
launches, and the clear area of this space is to be obtained by deducting all encumbrances such as
skylights, companions, machinery casings, navigating spaces, life boats and ventilator.(b)The
maximum number of passengers that may be allowed shall be ascertained by using the divisor 0.56
for the area of deck in square meter of the saloon or cabin floor below deck. Only one saloon or cabin
floor below deck. Only one saloon below deck shall be included in passenger measurement, except
that where the vessel has an appropriate standard, except that case more than 250 passengers shall
be allowed.(1)In all vessels the seating must be so arranged that there will be no serious obstacle to
prevent a person from passing forward and aft quickly in case of emergency.(2)No space within
0.5m of entrance to any ladder way, wash place or lavatory shall be included in the space measured
for passengers.(3)Vessels engaged in carrying large number of passengers shall have a strong barrier
constructed on each deck.(5)The provision regarding freeboard shall take precedents with regard to
calculation or asserting of any issue/ matter related to overloading of the vessel.Chapter - 9.0
Stability[Application- This part shall apply to all vessels.]
59. Stability.
(1)An inclining experiment shall be carried out to determine the elements of stability. Unless
particulars of position to transverse met centre at various drafts are available the experiment shall
be carried out with the vessel loaded with weights to represent the fully laden
condition.(2)Calculation showing the transverse met acentric height and the angle of heel which
would occur with two third of passengers distributed on one side of heel which would occur with two
third of the passengers distributed on one side of the vessel and one third on the other side requires
approval of the surveying authority. Each passenger shall be represented by a weight of 65kgs.(3)In
decked vessels the passengers shall be taken as congregated at 0.27 sq meter each on upper mostBihar Inland Vessels Rules, 2013

deck or decks to which they have access and the center of gravity of the passenger at 0.75 meter
above the deck.(4)In open vessels the center of gravity of passengers shall be taken at 0.3 meter
above the seat.(5)In no case shall the surveyor certify a vessel for any number of passengers unless
he is satisfied with the vessel has sufficient stability and free board to carry that number
safely.(6)Stability of hovercrafts shall be specially considered.(7)Initial GM must be least 0.15
meter.Chapter - 10.0 Anchors and cablesApplication- This part shall apply to all vessels.
60. Anchors and cable.
(1)Every inland vessel of less than 15m in length shall be provided with at least one anchor and chain
cables.(2)Every inland vessel of 15m and more in length shall be provided with at least two anchors
and chain cables.(3)Every vessel exceeding 100 tons shall be provided with anchors and cables as
specified by the Surveying Authority in each case. Provided that the anchors and cables complying
with Classification Society requirements will ordinarily be accepted.
61. Echo sounder.
(1)Every vessel over 100 ton shall be provided with an echo sounder. and every vessel shall be
provided with at least one hand lead line 15 fathoms in length with lead of at least 3.2 kg weight
provided that small vessel plying in shallow waters shall be provided with a depth measuring pole or
rod suitably marked.(2)Every open vessel shall be provided with at least three oars three row locks
and two efficient boat hooks.(3)Every vessel shall be provided with atleast two heaving lines.Chapter
- 11.0 Navigation and Communication EquipmentsApplication- This part shall apply to all vessels
62. Lights and Shape.
- Every vessel shall be provided with navigation lights and means of making sound signals etc in
accordance with Prevention of Collision on National Waterways Regulations, 2002. Vessel shall also
be provided with search lights from the bridge.
63.
Communication equipment like compass binoculars wheel indicator bridge engine control PA
system mobile shall be provided.
64. Penalties.
- A breach of any of the rules by the owner master or driver of the vessel shall be punishable with
imprisonment for a term which may extend to six months or with fine which may extent to 500
rupees or with both.Chapter - 12.0 Lights, Sound Signals and Prevention of Collision Steering and
SailingPart-A 65. Look-Out.- Every vessel shall at all times maintain a proper look-out by sight and
hearing as well as by all available means appropriate in the prevailing circumstances and conditions
so as to make a full appraisal of the situation and of the risk of collision. Vessels shall make use ofBihar Inland Vessels Rules, 2013

searchlights to locate luminous marks used for channel marking.
66. Safe Speed.
(1)Every vessel shall at all times proceed at a safe speed so that she can take proper and effective
action to avoid collision and grounding, and be stopped within a distance appropriate to the
prevailing circumstances and conditions.(2)In determining a safe speed the following factors shall
be among those taken into account.(a)The state of visibility:(b)The traffic density including
concentrations of fishing vessel or other vessels.(c)The manoeuvrability of the vessel with special
reference to stopping distance and turning ability in the prevailing conditions.(d)The state of the
river, wind, current and the proximity of navigational hazards;(e)State and availability of shore
navigational aids and channel marking by day and night;(f)Speed restrictions imposed by the
waterway authority;(g)The draught of the vessel in relation to available depth of water; and(h)At
nights, the presence of background light such as from the shore lights or from the back scatter other
own lights.
67. Risk of collision.
(1)Every vessel shall use all available means appropriate to the prevailing circumstance and
conditions to determine if risk of collision exists. If there is any doubt, such risk shall be deemed to
exist.(2)In determining if risk of collision exists the following consideration shall be among those
taken into account:-(a)Such risk shall be deemed to exist if a compass bearing of an approaching
vessel does not appreciably change and apparent distance from own vessel decreases;(b)Such risk
may sometimes exist even when an appreciable bearing change is evident, particularly when
approaching a very large vessel or a tow or when approaching a vessel at close range; and(c)For
vessel not fitted with a compass, if the relative position remains unchanged.
68. Action to avoid collision.
(1)Any action taken to avoid collision shall, if the circumstances of the case admit be positive, made
in ample time and with due regard to the observance of good seamanship.(2)Any alteration of
course or speed to avoid collision shall, if the circumstances of the case admit be large enough to be
readily apparent to another vessel. A succession of small alterations of course and / or speed should
be avoided.(3)If there is sufficient room, alteration of course alone may be the most effective action
to avoid a close quarters situation provided that it is made in good time, is substantial and does not
result in another close quarters situation.(4)Action taken to avoid collision with another vessel shall
be such as to result in passing at a safe distance the effectiveness of the action shall be carefully
checked until the other vessel is finally passed and clear.(5)If necessary to avoid collision or allow
more time to assess the situation, a vessel shall slacken her speed or take the way off by stopping or
reversing her means of propulsionBihar Inland Vessels Rules, 2013

69. Narrow channels.
(1)A vessel proceeding along the course of a narrow channel shall keep as near to the outer limit of
the channel which lies on her starboard side as is safe and practicable. A vessel of less than 10
meters in length or a sailing vessel shall not impede the passage of a vessel which can safely navigate
only within the marked channel.(2)A vessel engaged in fishing shall not impede the passage of any
other vessel in the navigable channel;(3)A vessel shall not cross a navigable channel if such crossing
impedes the passage of vessel proceeding upstream or downstream along the navigable
channel;(4)A vessel nearing a bend or an area of a narrow channel where other vessels may be
obscured by an intervening obstruction shall navigate with particular alertness and caution and
shall sound the appropriate signal ;(5)Every vessel shall, if the circumstances of the case admit,
avoid anchoring in a narrow channel.When single lane traffic is in force, vessels shall join the lane
only when the traffic signal permits to do so. While in the lane, the vessels shall proceed with
maximum permissible speed and clear the channels as quickly as possible. Vessels shall not stop or
anchor in a traffic lane and shall exercise caution while joining or leaving the single lane to avoid
collision with waiting vessels at anchor.Part- B Conduct of vessels in sight of one another
70. Sailing vessels.
- When two sailing vessels are in sight of one another or approaching one another so as to involve
risk of collision, one of them shall keep out of the way of the other as follows:-(1)In a non tidal river
when one vessel is proceeding upstream and the other vessel proceeding downstream the vessel
proceeding upstream shall keep out of the way of the other;(2)When both are proceeding, upstream
or downstream and in a tidal lagoon the vessel which is to windward shall keep out of the way of the
vessel which is to leeward;(3)A vessel which is running free shall keep out of the way of a vessel
which is close-hauled; and(4)A vessel which is close-hauled on the port tack shall keep out of the
way a vessel which is close-hauled on the starboard tack.(5)For the purpose of these rules,
"upstream" shall be deemed the direction against current and downstream the direction with the
current. "Wind ward" side shall be deemed to be the side opposite to that of which the main sail or
the largest fore and after sail is carried.
71. Overtaking.
(1)Notwithstanding anything contained in these rules any vessel overtaking any other shall keep out
of the way of the vessel being overtaken;(2)A vessel shall be deemed to be overtaking when coming
up with another vessel from a direction more than 22.5 degrees abaft her beam. That is, in such a
position with reference to the vessel she is overtaking, that at night she would be able to see only the
stern light / towing light of that vessel but neither of her sidelights; and(3)Any subsequent alteration
or bearing between two vessels shall not make the overtaking vessel a crossing vessel within the
meaning of these rules or relieve her duty of keeping clear of the overtaken vessel until she is finally
passed and cleared.Bihar Inland Vessels Rules, 2013

72. Head-on situation.
- When two mechanically propelled vessels are meeting on reciprocal or nearly reciprocal courses so
as to involve risk of collision each shall alter her course to starboard so that each shall pass on the
port side of the other.
73. Crossing situation.
- When two mechanically propelled vessels are crossing so as to involve risk of collision, the vessel
which has the other on her own starboard side shall keep out of the way and shall, if the
circumstances of the case admit avoid crossing ahead of the vessel.
74. Action by give-way vessel.
- Every vessel which is directed by these rules to keep out of the way of another vessel shall, so far as
possible take early and substantial action to keep well clear.
75. Action by stand-on vessel.
(1)(a)Where by any of these rules one of two vessels is to keep out of the way, the other shall keep
her course and speed.(b)The latter vessel may however take action to avoid collision by her
maneuver alone, as soon as it becomes apparent to her that the vessel required to keep out of the
way is not taking appropriate action as required by these rules.(2)When from any cause, the vessel
required to keep her course and speed finds herself so close that collision cannot be avoided by the
action of the give-way vessels alone, she shall take such action as will best aid to avoid collision;(3)A
vessel which takes action in a crossing situation in accordance with sub paragraph 1 (b) of this rule
to avoid collision with another vessel, shall if the circumstances of the case admit, not alter course to
port for a vessel on her own port side; and(4)These rules do not relieve the give-way vessel of her
obligation to keep out of the way.
76. Responsibilities of (between) vessels.
(1)A mechanically propelled vessel underway shall keep out of the way of;(a)a vessel is not under
command;(b)a vessel restricted in her ability to maneuver;(c)a vessel engaged in fishing;(d)a sailing
vessel, vessel under oars or country boat; and(e)a vessel proceeding downstream by a vessel
proceeding upstream, it the prevailing circumstances permit.(2)A sailing vessel under way shall
keep out of the way of:-(a)a vessel not under command;(b)a vessel restricted in her ability to
maneuver; and(c)a vessel engaged in fishing.(3)A vessel engaged in fishing when underway shall, so
far as possible, keep out of the way of :-(a)a vessel not under command; and(b)a vessel restricted in
her ability to maneuver.Part- C 77. Conduct of vessels in restricted visibility.(1)This rule applies to
vessels not in sight of one another when navigation in or near an area of restricted visibility;(2)Every
vessel shall make appropriate sound signals in accordance with Rules and exhibit lights while
navigating in restricted visibility.(3)Every vessel shall proceed at a safe speed adapted to theBihar Inland Vessels Rules, 2013

prevailing circumstances and conditions of restricted visibility. A mechanically propelled vessel shall
have her engines ready for immediate maneuver.(4)Every vessel shall have due regards to the
prevailing circumstances and conditions of restricted visibility when complying with the rule of this
part.(5)Except where it has been determined that risk of collision does not exist every vessel which
hears apparently forward her bean the fog signal at another vessel or which cannot avoid a
close-quarters situation which another vessel forward of her beam, shall reduce her speed, she shall
if necessary take all her way off and in any event navigable with extreme caution until danger of
collision is over.
78. Lights & Shapes.
(1)Provisions in this Rule shall be complied with in all weathers.(2)The rules concerning lights shall
be complied with from sunset to sunrise, and during such times no other lights shall be exhibited,
except such, lights as cannot be mistaken for the lights specified in these rules, do not impair their
visibility or distinctive character, or interfere with the keeping of a proper look- out(3)The lights
prescribed by these rules shall, if carried, also be exhibited from sunrise to sunset in restricted
visibility and may be exhibited in all other circumstances when it is deemed necessary.(4)The rule
concerning shapes shall be complied with by day.(5)The lights and shapes unless otherwise specified
in these rules shall comply with the positioning and technical details as per the provisions of
Annex-1 to International Regulations for prevention of collision at sea (1972).
79. Different Lights used in vessels.
(1)"Mast head light" a white light placed over the fore and aft centerline of the vessel showing an
unbroken light over an arc of the horizon of 225 degree and so fixed as to show the light from right
ahead to 22.5 degrees abaft the beam on either side of the vessel. This light shall be placed as far as
practicable at height above the hull of not less than 3 meters for vessels of 20 meters or more in
length and 2 meters for vessels of less than 20 meters in length.(2)"Sidelights" a green light on the
starboard side and a red light on the port side each showing an unbroken light over an arc of the
horizon of 112.5 degrees and so fixed as to show the light from right ahead to 22 degrees abaft the
bean on its respective side. In a vessel of less than 20 meters in length the sidelights may be
combined in one lantern carried the fore and aft centerline of the vessel. Side lights shall be placed
not less than 1 meter below the mast head light.(3)"Stern light" a white light placed as nearly as
practicable at the stern showing an unbroken light over an arc of the horizon of 135 degree arid so
fixed as to show the light 67.5 degrees from light aft on each side of the vessel.(4)"Towing light" an
yellow light having the same characters as "Stern light' mentioned in sub section (3) of this
rule.(5)"All-round light" a light showing an unbroken light over an arc of the horizon of 360
degrees.(6)"Flashing light" a light flashing at regular intervals.
80. Visibility of Lights.
- The lights prescribed in these rules shall be visible at the following minimum ranges:-(1)A vessel of
20 meters or more in length, mast head light, 3 miles, Side lights 2 miles, Stern light 2 miles, Towing
light 2 miles, all-round light 1mile.(2)A vessel less than 20 meters in length, a mast head light 2Bihar Inland Vessels Rules, 2013

miles side light one mile. Stern light 1 mile, white, red, green or yellow all-round light 1 mile. Lights
to be exhibited by vessels.
81. Lights to be exhibited by mechanically propelled vessel under-way. -
(1)A mechanically propelled vessel under-way shall exhibit:-(a)a mast head light forward.(b)side
lights.(c)a stern light.(2)A mechanically propelled vessel of less than 10 meters in length in-lieu of
the lights prescribed in paragraph (1) may exhibit an all-round white light, and shall if practicable
also exhibit side lights or a combined lantern.
82. Lights to be exhibited by towing & pushing vessels.
(1)A mechanically propelled vessel when towing or pushing shall exhibit :-(a)two mast head lights
forward in a vertical line when the length of the two exceeds 200 meters; There such light in a
vertical line. These lights will be in-lieu of light prescribed in rule 81 (1) (a). The lights shall be
placed not less than 1 meter apart and the lowest light placed at a height not less than two meters
above the hull.(b)side lights.(c)a stern light.(d)A towing light in a vertical line above the stern
light.(2)When a pushing vessel and a vessel being pushed ahead are connected in a composite unit,
they shall be regarded as a mechanically propelled vessel and exhibit the lights prescribed in
rule-106.(3)A vessel or object being towed shall exhibit:-(a)side lights(b)a stern light.Provided that
any number of vessels being towed or pushed in a group shall be lighted as one vessel.(4)A vessel
being pushed ahead, not being part of a composite unit, shall exhibit at the forward end, side
lights.(5)A vessel being towed aside exhibit a stern light at the forward end side lights.(6)Where
from any sufficient cause, it is impracticable for vessel or object being towed to exhibit the lights
prescribed in this rule, all possible measures shall be taken to light the vessel or the object towed at
least to indicate the presence of unlighted vessel or object.
83. Lights to be exhibited by sailing vessel and vessels under oars.
(1)A sailing vessel shall exhibit:-(a)side lights.(b)a stern lights.(2)In a sailing vessel of less than 20
meters in length the lights prescribed in paragraph (1) may be combined in one lantern carried at or
near the top of the mast where it can be seen.(3)A sailing vessel underway may in addition to the
lights prescribed in paragraph (1) of this rule, exhibit at or near the top of the mast where they can
best be seen two all-round lights in a vertical line, the upper being red and lower be green.(4)A
sailing vessel less than 10 meters in light, a vessel under oars may exhibit lights prescribed in this
rule, but if she does not, she shall have ready at hand an electric torch or lighted lantern showing
white light which shall be exhibited in sufficient time to prevent collision.
84. Lights to be exhibited by fishing vessels.
(1)A vessel engaged in fishing shall exhibit:-(a)two all-round lights in a vertical line the upper being
red and the lower white and during a shape consisting of two cones with their apexes together in a
vertical line or a basket.(b)when making way through the water in addition to the lights prescribedBihar Inland Vessels Rules, 2013

in (a), side lights, and a stern light.(2)A vessel less than 10m in length, a vessel under oars may
exhibit lantern and shall have ready at hand an electric torch which shall be exhibited in sufficient
time to prevent collision.
85. Lights to be exhibited by vessels not under command or restricted in
their ability to maneuver.
(1)A vessel not under command shall exhibit:-(a)two all-round red lights in a vertical where they can
best be seen by night.(b)two balls or similar shapes in a vertical line by day.(c)When making way
through the water; side lights and a stem light addition to the lights prescribed in (a).(2)A vessel
restricted in her ability to maneuver shall exhibit;(a)three all- round lights in a vertical line, the
highest and lowest of these shall be red and the middle light shall be white.(b)Three shapes in a
vertical line, the highest and lowest shapes SI be balls and the middle one a diamond.(c)when
making way through the water, mast head lights, side lights and stern light in addition to the lights
prescribed in (a)(d)when at anchor, in addition to the lights and shapes prescribed in (a) and (b)
above, lights and shapes prescribed in rule 82 for anchored vessels shall also be exhibited.
86. Lights to be exhibited by vessels engaged in dredging.
- A vessel engaged in dredging, in addition to the lights in Rule 107 (2) shall exhibit; two all - round
red lights or two balls in a vertical line to indicate the side on which obstruction exists.
87. Lights to be exhibited by pilot vessels.
- A vessel engaged on pilotage duty shall exhibit:-(1)at or near the mast head two all - round lights in
vertical line, the upper one white and the lower one red.(2)when under way, in addition side lights
and stern light.
88. Lights to be exhibited by anchored vessels and vessels aground.
(1)A vessel at an anchor shall exhibit:-(a)in the fore part an all-round white light or one ball by
day.(b)At or near the stern and at a lower level than the light in (a), an all round white light.(2)A
vessel of less than 20 m in length may exhibit one all-round white light where it can best be
seen.(3)A vessel aground shall exhibit in addition to the lights prescribed in para (1) or (2), where
they can best be seen.(a)two all-round red lights in a vertical line,(b)three balls in a vertical line by
day.(4)A vessel less than 10m in length, a vessel under oars may exhibit lantern and shall have ready
at hand an electric torch which shall be exhibited in sufficient time to prevent collision.
89. Lights to be exhibited by hydrofoils & mechanized country crafts.
- Where it is impracticable for a mechanized country craft or a hydrofoil to exhibit lights and shapes
of the characteristics or in positions prescribed in the Rules she shall exhibit lights and shapes as
closely similar in characteristics and position as is possible.Bihar Inland Vessels Rules, 2013

90. Sound Signals.
- The sound signal appliances unless otherwise specified in the Rules shall comply with the technical
requirements as per the provisions of Annexure-III of the International Regulations for prevention
of collision at sea (1972).
91. Equipment for sound signals.
- A vessel of 20 meters or more in length shall be provided with a whistle and a bell and a vessel of
100 meters or more in length, in addition shall be provided with a gong.
92. Maneuvering and warning signals.
(1)Single vessel when vessels are in-sight of one another a mechanically propelled vessel underway,
when maneuvering as authorized or required by these regulations, shall indicate her intentions by
the following signals on her whistle.(a)One short blast (a blast of about 1 second duration) to
indicate."I am altering my course to starboard"(b)Two short blasts to indicate " I am altering course
to port"(c)Three short blasts to indicate "I am operating stern propulsion."(2)Overtaking
vessels(a)Two prolonged blasts (blast of about 4 to 6 seconds duration each) followed by one short
blast to indicate " I intend to over take you on your starboard side."(b)Two prolonged blasts
followed by two short blasts to indicate "I intend to over take you on your port side."(c)A vessel
being overtaken shall indicate her agreement by the following signals or her whistle; one prolonged,
one short, one prolonged, one short blast, on that order, if in doubt she may sound signals
prescribed in paragraph (3)(3)When in doubt - When vessels in sight of one another are
approaching each other and from any cause either vessel fails to understand the intentions or
actions of the other or is in doubt whether sufficient action is being taken by the other to avoid
collision, the vessel in doubt shall immediately indicate such doubt by giving at least 5 short and
rapid blasts on the whistle, the signal may be supplemented by a light signal of at least 5 short and
rapid flashes.(4)At bends - A vessel nearing bend or an area of a channel where other vessels may be
obscured, shall sound one prolonged blast, such signal shall be answered with a prolonged blast by
any approaching vessel.
93. Sound signals in restricted visibility.
- In or near an area of restricted visibility, where by day or night, signals prescribed in this rules
shall be used as follows:-(1)A mechanically propelled vessel making way through the water shall
sound at intervals of not more than 2 minutes one prolonged blast.(2)A mechanically propelled
vessel underway but stopped and making no way through the water shall sound at intervals of not
more than 2 minutes two prolonged blasts in succession with an interval of about 2 seconds between
them.(3)A vessel not under command, a vessel restricted in her ability to maneuver, a vessel
constrained by her draught, vessel engaged in towing, fishing or pushing another vessel, shall at
intervals of not more than 2 minutes three blasts in succession namely one prolonged followed by
two short blasts.(4)A vessel at anchor shall at intervals of not more than one minute ring the bellBihar Inland Vessels Rules, 2013

rapidly for about 5 seconds. A vessel at anchor may in addition sound three blasts in succession
namely one short, one prolonged and one short blast to give warning on her position, and possibility
of collision to any approaching vessels. A vessel aground shall give three separate and distinct
strokes on the bell immediately before and after the rapid ringing of the bell.(5)A vessel of less than
10 meters in length shall not be obliged to give the above mentioned signals but shall make some
other effective sound signal at intervals of not more than 2 minutes.
94. Distress signals.
- When a vessel is in distress and requires assistance from other vessels or from shore, the following
shall be the signals to be used or displayed by her either together or separately.(1)a continuous
sounding of any sound signal apparatus.(2)A flag or a light waved in a circle to draw
attention.(3)Flares on the deck.(4)"May day" transmitted by radio telephony.(5)International code
of signal N.C. hoisted on the vessel.
95. Exemptions.
- Any vessel (or class of vessels) whose keel of which is at corresponding stage of construction before
the entry into force of these rules may be exempted from compliance therewith of the following
provisions until one year after the date of entry into force of these rules.(1)The installation of lights
with colour specifications and intensity as prescribed in Rule 75 (5).(2)Repositioning of masthead
lights and side lights on vessels resulting from prescriptions of Rule 76.(3)The installation of lights
with ranges prescribed in Rule 77.
96. Application of the provision of Port rules and National Waterway
regulations.
- Notwithstanding anything mentioned above, the provision of the Port Rules and Prevention of
Collision Regulations, 2002 for National Waterways shall also apply mutatis mutandis, to the
mechanically propelled vessels while making voyages within the port limits and National
waterways.Chapter - 13.0 Safety Measures on Water Wyas
97. Carriage of Dangerous Goods.
- No dangerous goods are to be carried on board on transported in the waterways without the
specific approval and safety clearance from the competent officer. Provisions of the Merchant
Shipping Act 1958 with respect to transporting of dangerous cargo shall be applicable in all classes.
98. Prevention of Explosions or Fire.
- No explosives shall be brought on board, stored or carried in a vessel without their prior approval
and safety clearances from the competent authority and clearances from the Controller of Explosives
as required under the provisions of the Indian Explosive Act 1884.Bihar Inland Vessels Rules, 2013

99. Prevention and containment of pollution of harbors, ports and waterway
by oil / chemical / hazardous cargo etc.
- The provisions of the Merchant Shipping Act 1958, as amended from time to time shall be the
guiding criteria from inland vessels and shall be applicable as if under these rules.
100. Passage through Bridges.
- When a vessel is passing under a bridge, the height of the mast or the height of the collapsed mast
and that of the wheelhouse / super structure should be less than that between waterway level and
the height of the road bridge. Speed of such vessel should be regulated with reference to prevailing
weather conditions and the currents likely to be experienced.
101. Reduction of speed in certain circumstances.
(1)every vessel shall regulate their speed to avoid creating excessive wash or suction likely to cause
damage to stationary or other moving vessels or structures and bank.(2)In particular the vessel shall
reduce speed in good time, but without loosing the steering way required for safety.(a)out side port
entrances;(b)near vessels made fast to the bank or to a landing stage loading or discharging
cargo;(c)near vessels lying at normal stopping places.
102. Drifting of a vessel.
- Drifting of vessel in the inland waterways, unless authorized by the competent Officer, is
prohibited.
103. Crossing of navigable channel.
- While crossing the navigable channel, a ferry vessel shall keep at such distance from vessels or
rafts moving along the navigable channel, so that the latter are not obliged to change their course or
reduce speed.Provided that ferry vessels, under special circumstances may be granted priority of
passage across the navigable channel by the Competent Officer and such vessel shall exhibit a green
all-round light by night and a green flag by day and shall have right of way as the circumstances
permit.
104. Stationary Vessels.
- All stationary vessels, rafts and floating equipment must be anchored or made fast securely enough
to withstand the current in such a way that they can adjust to the changes in water level.Bihar Inland Vessels Rules, 2013

105. Instructions to the Master / Owner.
(1)Every vessel shall be in charge of a Master who shall be qualified and hold a certificate to that
effect under the Rule. The Master shall be severally and conjointly with the Owner shall be
responsible for any or all breaches of the rules. Responsibilities of the Master/Owner inter alia
include;(a)Take all precautions required to exercise vigilance and to avoid damage to the vessel,
installations in the waterways and avoid causing obstructions to shipping and navigation;(b)To
avoid imminent danger, take all steps required by the situation (according to the general practice of
seamanship) even if this entails departing from these regulations;(c)Be responsible for compliance
with the rules or regulations applicable to his vessel and his crew and to the vessels in tow, while his
vessel is engaged in towing of other vessels;(d)The master/owner shall be responsible for ensuring
that the vessel has a valid certificate of survey applicable for the voyage or service in this zone of
operation.(e)The master/owner shall ensure that the vessel has a valid certificate of registration and
that the certificate of registration granted in respect of any vessel shall be used only for the lawful
navigation of that vessel;(f)The master/owner shall ensure that the crew is sufficient for the type of
vessel and type and area of operation as required by the rules.(g)The master/owner shall ensure that
the crew has valid certificate of competency/service,(h)the master/owner shall ensure that
dangerous goods or explosive materials are carried on board only as authorized by Competent
Authority and procedures and safety precautions as per the Explosives Rules, 1983 are taken for
carrying of such goods or material onboard;(i)The master shall maintain Ship's Article/crew list,
Ships log and Engine Log.(j)The master shall ensure that at no time the vessel is overloaded or more
than the number of passengers it is certified to carry are taken onboard.(k)The owner shall ensure
no unauthorized alterations are made to the vessel.(l)The master/owner shall ensure that the vessel
is adequately equipped to fight any fire and to rescue the passengers and that the crew adequately
trained to meet emergent situations.(m)The owner/master shall ensure that Life saving devices like
life buoys, life jackets, life raft etc as required as per the Rules are provided in each vessel and they
are kept in such a position for quick deployment in case of emergency.(n)The owner shall ensure
insurance of the vessel against third of the vessel against third party risks.(o)The owner/master
shall display the details showing the date of manufacture of the vessel, date of survey, expiry date of
survey, passengers and cargo capacity and such other details as required by law.(p)To ensure timely
and quality maintenance work.(q)To ensure that at no time the vessel discharges in the waterway
except at places designated by the Competent Officer, raw sewage, oily substances, garbage
etc.(2)The master or the person in charge of the vessel shall make immediate report to the nearest
competent officer / Police on-(a)any vessel has been wrecked, abandoned or materially
damaged;(b)accidents/ causality involving, death, grievous hurt;(c)sighting of any other vessel in
distress;(d)outbreak of fire or flooding in his vessel;(e)damage caused to any waterway installations
or permanent structures;(f)any vessel has caused loss or material damage to any other
vesselOR(g)Observing uncharted obstruction or failure of navigational aid;(h)falling over board of
any object which may become an obstruction or danger to navigation;(i)spillage of oil into the
waterway;(j)piracy or theft on board.(4)The master shall;(a)On sighting a vessel or raft which has
suffered an accident endangering persons or the vessel or threatening to obstruct the channel, give
immediate assistance to such vessels without endangering safety of his own vessel;(b)In case of any
marine casualty, give warning to the approaching vessels to enable them to take necessary action in
good time steer clear of the channel when in danger of sinking or goes out of control.(5)All the crewBihar Inland Vessels Rules, 2013

employed on board a vessel shall be under the control and orders of the master of such vessel, who
shall see that proper discipline and good conduct is maintained by them. The crew shall on no
account interfere with passengers or behave rudely towards them.(6)When the master of a vessel is
temporarily absent during a voyage, the Serang on board the vessel shall be held to be in charge with
powers and responsibilities of the Master. If such absence of he Master exceeds a day a duly
qualified Master shall be appointed immediately and the fact communicated forthwith to the
competent authority.(7)Master or persons in charge of a vessel shall give the competent officer or
any person authorized by him all necessary facilities for verifying compliance with these
regulations.Chapter - 14.0 Miscellaneous
106. Exemptions.
- Notwithstanding anything contained in these Rules, the traditional country boats engaged in
carriage of non dangerous goods/ cargo in bulk irrespective of its length and horse power are
exempted from the provision of these Rules and shall be governed by Bihar Model Boat Rules- 2011.
107. Power for State Government to modify application of rule to certain
inland mechanically propelled vessels.
- The State Government may, by notification in the official Gazette, declare that all or any of the
provisions of these rules shall not apply in the case of any specified class of mechanically propelled
vessels or shall apply to them with such modification as may be specified in the notification.
108.
All fees payable as per these rules can be revised by State Government from time to time.Chapter -
15.0 Insurance & PenaltiesThe insurance for mechanically propelled vessels the Chapter VIA of the
ACT and for Penalties, the Chapter VII of the act shall be applicable.
I
[Rule 10(3)](The State government may by notification change the fees specified in the
Schedule)Fees Payable Under Chapter III(In Rs.)
(a) On initial registration, the scale of feespayable will be as follows:-  
 (i) Vessels up to and including 50 M.T.G.R.T. 1000.00
 (ii) Vessels exceeding 50 M.T. up to 100M.T.G.R.T. 2000.00
 (iii) Vessels exceeding 100 M.T. up to 200M.T.G.R.T. 4000.00
 (iv) For every additional 100 M.T.G.R.T. or Parttheir of 2000.00
(b)For registering any Inland Vessel which has beenregistered under
the Merchant Shipping Act, 1958.2000.00
(c) Registration a new as directed by theRegistering AuthorityBihar Inland Vessels Rules, 2013

Full amount of the rates
indicated against
(a)above
(d) Registration of alteration to a Vessel 1000.00
(e) Issue of duplicate certificate 500.00
(f)Registration as a result of transfer ofownership within the same or
different state.Full amount of the rates
indicated against
(a)above
(g) Appeal against the decision of RegisteringAuthority 1000.00
(h) Supervision fees  
 (i) Upto Estimated amount cost Rs. 10 lakhs-1%minimum
10000.0010000.00
 (ii) Upto estimated cost amount Rs. 10 lakhs to40 lakhs (Rs.10000
+ 0.5% on amount above Rs. 10 lakhs)(Rs.10000 + 0.5% on
amount above Rs. 10
lakhs)
 (iii) Above Rs. 40 lakhs estimated amount(Rs.25000 + 0.25% on
amount above Rs. 40 lakhs)(Rs.25000 + 0.25% on
amount above Rs. 40
lakhs)
II
[See Rule 27]Syllabus for Examination of First Class Engine DriversThe written examination shall
consist of one paper of three hours duration consisting of the following subjects. Candidate securing
forty per cent of the total marks will be deemed to have passed the written test.
1.Elementary Mathematics: 20 Marks.
(a)Addition, Subtraction, Multiplication, Division, Decimals and Vulgar Fraction.(b)Power and
roots of numbers, Ratio and proportion, Percentages, Direct and Inverse Variation,
Averages.(c)Areas and perimeters of a rectangle, triangle and circle, Volumes and Surface areas of
box shaped bodies, cylinders pyramids, cones and spheres, Simpson''s first and second rules,. to find
out the area of water planes and displacement of boats and different droughts in sea/ river/ canal
water by Simpson''s rules as well as by using area co-efficient and prismatic co-efficient.(d)Solutions
of simple equation, involving use of given formulae, rearrangement of given formulae.(e)To
calculate the T.P.I. (Total Pressure Index) in sea water and fresh water.(f)To find out the carrying
capacity of the boat.
2.Engineering Knowledge: 20 Marks.
Section-A(General)(i)Fundamental Units, (ii) Density and specific density, (iii) Parallologram of
forces, (iv) The Triangle of Forces, (v) Moments and levers, (vi) Parallel forces, (vii) Centre of
gravity, (viii) Stress and strain, (ix) Friction, (x) Work, (xi) Temperature scales, (xii) Quantity of heat
and specific heat, (xiii) Quantity of Electricity and Farada''s Laws of Electrolysis, (xiv) Resistivity,
(xv) Ohm''s Law, (xvi) The measurement of Resistance by the Ammeter/ Voltmeter method.
Section-B: Marine Engineering: 40 Marks.Bihar Inland Vessels Rules, 2013

(i)Working principle of Marine engine.(ii)Difference in between Internal Combustion Engine and
External combustion Engine.(iii)Name of Principal parts of machinery's.(iv)Knowledge of what
attention is required by the various parts of the machinery, use and maintenance of valves, cocks
pipes and connections, and familiar with the various methods of supplying air and fuel to the
cylinders;(v)Cause of defects and their rectification.(vi)Complete overhauling of the Marine
Engines.(vii)nature of the properties of the various fuel used in internal combustion
engines;(viii)Precautions against fire and explosions due to oil vapour or gas, flash point. The
danger of oil leakage, precautions while bunkering.(ix)Construction, operation and maintenance of
fire fighting appliances.(x)Lay out and working of electric light installation and battery
installations.(xi)Dry docking including repairs to the propeller, tail shaft rudder and sea
connections, stern tubes, shaft brackets.(xii)Alignment of Shaft.(xiii)Calculations pertaining to
speed, consumption of fuel and fresh water for a given voyage.(xiv)Arrangements for pumping out
bilges.(xv)Preparation of defect list.(xvi)Utilisation and maintenance of life saving
appliances.(xvii)Able to draw free hand sketches or machine and engine parts.(xviii)Maintaining
procedure or engine log book.
3.Engineering Drawing: 20 Marks.
Use of drawing instruments, reading of blue prints and able to draw the sketches or various parts of
the engine.
III
[See Rule 30(3)]Syllabus for Examination of Inland Vessel EngineersThe written examination shall
consist of one paper of three hours duration consisting of the following subjects. Candidate securing
forty per cent of the total marks will be deemed to have passed the written test.
1.Elementary Mathematics: 20 Marks.
(a)Addition, Subtraction, Multiplication, Division, Decimals and Vulgar Fraction.(b)Power and
roots of numbers, Ratio and proportion, Percentages, Direct and Inverse Variation,
Averages.(c)Areas and perimeters of a rectangle, triangle and circle, Volumes and Surface areas of
box shaped bodies, cylinders pyramids, cones and spheres, Simpson's first and second rules,
practical applications involving use of the above. To find out the area of water planes and
displacement of boats at different droughts in sea water and fresh water by Simpson's rules as well
as by using area co-efficient and prismatic co-efficient.(d)Solutions of simple equation, involving use
of given formulae, rearrangement of given formulae.(e)To calculate the T.P.I. in sea water and fresh
water.(f)Difference of droughts when boat moves from sea water to fresh water or vice-versa.(g)To
find out the carrying capacity of the boat.
2.Engineering Knowledge: 20 Marks.
Section-A(General)(i)Fundamental Units, (ii) Density and specific density, (iii) Parallologram of
forces, (iv) The Triangle of Forces, (v) Momentas and levers, (vi) Parallel forces, (vii) Centre of
gravity, (viii) Stress and strain, (ix) Friction,(x) Work, (xi) Temperature scales, (xii) Quantity of heat
and specific heats (xiii) Quantity of Electricity and Farad's Laws of Electrolysis, (xiv) Resistivity, (xv)
a. Ohm's Law,b. The measurement of resistance by the Ammeter/Voltmeter Method.
Section-B: Marine Engineering: 40 Marks.Bihar Inland Vessels Rules, 2013

(i)Principal of working construction operation and maintenance of two stroke and four stroke
internal combustion engines (Supercharged and naturally aspirated) used on board ship. with
particular reference to starting and reversing arrangements and safety devices.(ii)General used and
application of various materials used in machinery on board of Inland Vessels.(iii)The construction,
use and principles involved in the action of pressure gauge, thermometer, pyrometer and other
measuring instruments commonly used on boards ships.(iv)Construction, operation and
maintenance of centrifugal bucket and gear type pumps.(v)Lay-out and creation of bilge, ballast and
fuel systems.(vi)Construction, operation and maintenance of steering gears.(vii)Lay out and working
of electric light and electric power installation with particular reference to safety
devices.(viii)Construction and care of staring air vessels including mountings.(ix)Construction and
operation of refrigerating plant.(x)Estimation and fuel, lubricating oil and water consumption for
given voyage.(xi)Work related to dry docking, including propeller, tail, shaft, rudder, sea
connections, stern tube, shaft bracket.(xii)Elements of boat construction.(xiii)Precautions against
fire and explosions due to oil vapour or gas, flash point. The danger of oil leakage precautions while
bunkering.(xiv)Explosion in crank cases and starting air systems.(xv)Construction, operation and
maintenance of fire fighting appliances.(xvi)Knowledge of statutory requirements concerning
safety.(xvii)Candidates will be expected to draw free hand sketches of machine and engine
parts.(xviii)Preparation of defect list and procedure of maintaining engine log book.(xix)Use and
maintenance of life saving appliances.
3.Engineering Drawing: 20 Marks.
Use of drawing instruments, reading of blue prints, production of working drawing of machine and
engine parts
IV
(Rule 9)(The State government may by notification change the fees specified in the Schedule)
Sl.
N.Gross Tonnage of Inland Vessels and otherdescriptionsFees payable in
Rupees
1 Preliminary General Survey Required Fees  
(a) Upto 10 tons 500.00
(b) Exceeding 10 tons but does not exceed 25 tons 750.00
(c) Exceeding 25 tons but does not exceed 50 tons 1000.00
(d) Exceeding 50 tons but does not exceed 75 tons 1500.00
(e) Exceeding 75 tons but does not exceed 100 tons 2000.00
(f) Exceeding 100 tons but does not exceed 300 tons 4000.00
(g) Exceeding 300 tons but does not exceed 600 tons 6000.00
(h) Exceeding 600 tons for every 300 tons or parttheir of 1000.00 extra
(2)Fee payable for intermediate survey and duringvalidity of survey certificate or
extra survey/inspection- as pertonnage in item no. 1 aboveone extra fee
3Fee payable for survey on Sunday and otherholidays in additional to ordinary
fee chargeable.one extra feeBihar Inland Vessels Rules, 2013

4An extra fee chargeable if survey is called uponto undertake survey after 5.30
p.m. but before 9.00.a.m.one extra fee
5For change of name of the owner or master orengine driver for the vessel on
the certificate of survey orlicense certificate or Authorisation of any person.500.00
6 For extension of survey validity -As per itemno.1 one extra fee
7 For registration or enlistment of Builder orrepairer 500.00
8 Issue of second copy of certificate or certifiedcopy of certificate 500.00
9An appeal against the survey certificate ororder or determination of the
surveyor.1000.00
10 Fee for dry dock survey - As per tonnage in itemNo.-1 aboveThree times
fee
11 The time of the enforcement of survey fees one year
12For approval of drawing/ plans duringalterations/ repair- 0.05 % of estimated
cost minimum Rs. 1000.001000.00 each
13For examination and consideration of designplans/drawing/layout as
requested- 0.05 % of tender cost amount.minimum Rs. 2000.002000.00 each
14For witnessing tests of fire extinguishers, lifebuys, chains and anchors etc. as
requested per visit.1000.00
Form-I[See Rule-3(3)]Application for Survey of an Inland Vessel Under the Inland Vessel Act,
1917To,The Director/Chief Surveyor,Bihar Patna.I hereby apply to you to make necessary
arrangement for the survey of the Inland Vessel whose details are given below on the stated date and
place. I have paid to the officer appointed under section 6 of the Inland Vessel Act, 1917 a fee of
Rs......... in respect of the survey and additional fee of Rs......... in respect of the expense of the
journey of the surveyor.
1. Name of Vessel......
2. Port of Registry................... Official
No...............
3. Hull where built and when.......
4. Dimension of hull................
5. Tonnage (i) Registered ........................
(ii)Gross ............................Bihar Inland Vessels Rules, 2013

6. Previous survey if any Where/when
7. Nature of Survey
8. Date and time of proposed visit of surveyor.................
9. Place where the vessel will be lying...........
10. Class of certificate required....................
Station...............Date................Signature of owner/Master.Note. - (1) at least three clear day's notice
shall be given in all cases.(2)in the case of vessels not previously surveyed, the tonnage may be
stated approximately by the applicant and will be determined accurately on survey, fees being levied
accordingly.(3)No certificate shall be grated till all fees are paid.Form-2[See Rule-3(4)]Appointment
of Date and Time of Inspection of the Inland VesselsTo,The owner or master of Inland
Vessel______________________________________________________________________________________________________________________________________________Sir,I
have to acknowledge receipt of your application for survey of the above Inland Vessel under the
Inland Vessels Act, 1917 (1of 1917) and to acquaint you that I will proceed and board the vessel
at............O'clock on.................. day of .......... 20............
2. I subjoin a list of the requisite preparation for the surveys, which I request
may be made before the day and hour above mentioned, so as to prevent
loss of my time. Otherwise it will be necessary for me to postpone the survey
to some other day.
3. I beg to call attention to the provision of sub-section (2) of section-5 of the
Inland Vessel Act, 1917 which is follows:-
"The owner, master and officers of the Inland Vessel shall afford to the surveyor all reasonable
facilities for a survey, and all such information respecting the Inland Vessel and her machinery or
any part thereof, and all equipment and articles on boards, as he may require for the purposes of a
survey."Yours Sincerely,Surveyor.List of the requisite preparation for the survey of an Inland Vessel
:-(1)Last survey certificate, if any.(2)Master's certificate.(3)Engineer or engine driver's
certificate(4)Last passenger certificate(5)Pumps to be rigged in their places.(6)Spare tiller to be
shipped in its place.(7)Side lamps, lamp for the mast head light, and lamp for the anchor light to be
on deck ready to be put into their places, if necessary.(8)Life-buoys to be in readiness.(9)Leads and
lines to be on deck.(10)Fire-hose to be connected and coupled and stretched along the deck. The
conductor to be connected.(11)Decks, cabins, streerages and all other passenger spaces to be clean
and clear and in a fit state for measurement.(12)Chain Cables (or a portion thereof) to be on
deck.(13)A safe and proper ladder for going up and down the holds.(14)All pistons sides, pumps etc.
to be opened for inspections.(15)Fire extinguishers and fire buckets.(16)Engine certificate.(17)Last
insurance certificate.(18)Registration certificate if any.(19)Line Diagram or drawing ofBihar Inland Vessels Rules, 2013

vessel.Form-3[See Rule 5(1)]Surveyor's Declaration Under Section 7 of the Inland Vessel Act, 1917
1. Name of Inland Vessel and official number-
2. Name and address of owner-
3. Tonnage----------- Gross/ registered.
4. When and where build and material-
5. Power nominal (Horsepower)-
6. Description of engines and age
Number of cylinder- Diameter of Cylinders Stroke of cylinder
7. Condition of hull-
8. General equipment-
Number of fire buckets-
Number of fire extinguishers- where fitted.
Number of hand pumps -Number of crew-
9. (a) Name of master-
(b)Certificate (Class and no.)
10. (a) Name of Engine driver-
(b)Certificate (class and no.)
11. When and where last examined in dry dock-
12. Limits (if any) beyond which the vessel is not fit to ply-
13. Time, if less than one year for which the hull, boilers, engines or any of
the equipments will be sufficient.
for the year ending........................ day of...................Bihar Inland Vessels Rules, 2013

14. Dimension of boats, if any-
Lengh Breath Depth Cubic Capacity
(1)     
(2)     
(3)     
15. Number of life buoys.
16. Capacity for carrying passenger----
(a)Fist class(b)Second class(c)Intermediate
Deck passengers A B CSecond Cabin
PassengersSaloon
Passengers
When plying by night
(smooth and
partiallysmooth
water)When plying by
day (smooth and
partiallysmooth
water)When plying by day on
voyages which do notlast
more than six hours
(smooth water only)
(i) between decks      
(ii) main decks      
(iii) upper or bridge      
Total      
Grand Total      
      
I hereby declare as follows:-(1)That on the ............... day of ............ 20..........................I inspected the
machinery of the Inland Vessel named in the Space marked columns in this form and all the safety
valves and fire-hose on board the same.(2)That the machinery of the said Inland Vessel is sufficient
for the service intended and is in good condition.(3)That the said machinery will in my judgment, be
sufficient until the --------------------------day--------------of---------------------(4)That the safety
valves and fire applications are such and in such conditions as required by the rules under the Act, 1
of 1917.(5)That the said vessel as regards to machinery is, in my judgment, fit to ply on the Inland
waters of --------------------------Dated--------------------the------------------day of
------------------20-------------I further declare as follows viz:-(1)That on the ................... day
of...............20.................. I inspected the hull on the said Inland Vessel and boats, life buoys , lights,
signals and other equipments on boards the same, and the certificate of master;(2)That the hull of
the said Inland Vessel is sufficient for the service intended, and is in good condition;(3)That the
boats, life buoys, lights and signals and signals on boards the said Inland Vessel and the certificate
of the master are such and in such condition required by Act 1 of 1917 and the rules in force on the
subject;(4)That the hull of the said Inland Vessel and the equipments before named will, in my
judgment, be sufficient until the ............ day of................(5)That the said vessel is, in my judgment,
fit to ply as an Inland Vessel with the number of passengers stated in the space marked, colmun-16.Bihar Inland Vessels Rules, 2013

In this form, when there is no encumbrance of the space measured for the passenger
accommodation, but is not fit to ply with a greater number of passenger.(6)That the certificate of the
engine driver or engineer is such and in such condition as required by aforesaid Act of
1917.Surveyor.Form-4[See Rule- 5(2)]No.The....... of........20.The Owner Master of the Inland
Vessel....................................................................Having surveyed the Inland Vessel in accordance
with Inland Vessel Act, 1917, I find the following to be the repairs & required to make good the
defects:-Equipments :-Engines :-Others :-Surveyor of Inland VesselsForm-5[See Rule-6 (1)]Survey
of Inland VesselNo.The....... of........20.The Owner or Master of the Inland
Vessel.......................................................................................................................................................................................................Sir,I
hereby give you notice that the Certificate of survey of the above Inland Vessel applied for
by........................ is ready for delivery, and it will be delivered at the office of the Inland Water
Transport at any time during office hours on application and payment of the following sum viz
:-Forfeiture under section 8 (2) of the Inland Vessel Act, 1917 for delay Rs. P. in excess of fourteen
days in sending in the declaration, being at the rate of Rs. 510/- per day for
days.:-------------------Total :--------------------Yours faithfully,Director/Chief Surveyor, Bihar,
PatnaNotes. - These words to be inserted only when any sum is due under Section 8(2) of the said
actForm-6[See Rule 6(2)]Certificate of Survey-ATo Remain in Force Only until the ............... Day
of................20The Inland Vessel.............................. official no. Bihar................. Port of
Registry.Certificate of Registry No.........Certificate of Survey No..A/-Owner, Managing owner, or
Agent.......................
Port of Survey Register Tonnage Gross Tonnage Name of master and number of his Certificate
Plying Limits:-Limits beyond which this Vessel is not to
ply...................................................................................................................................Number of
PassengersThis Inland Vessel is, according to the declaration of the Surveyor, fit to carry, when
there is no Encumbrance of Passenger Accommodation.
Deck passengers A B CSecond Cabin
PassengersSaloon
Passengers
When plying by night
(smooth and
partiallysmooth
water)When plying by
day (smooth and
partiallysmooth
water)When plying by day on
voyages which do notlast
more than six hours
(smooth water only)
(i) between decks      
(ii) main decks      
(iii) upper or bridge      
Total      
Grand Total      
Two Children under 12 years of age to be reckoned as one passenger.Encumerance:-The space
measured for passenger accommodation is occupied by cattle, or by cargo, or other articles.
A.      
When plying by night
(Smooth and
partiallysmooth water) Then for every 9 superficial feet of
such spaceso occupied on the deck or
in the cabins One
PassengerIs to be deducted
from the numbers
abovestated.Bihar Inland Vessels Rules, 2013

B.      
When plying by day
(Smooth and partially
smoothwater) Then for every 6 superficial feet of
such spaceso occupied on the upper
or main deck, and for every
9superficial feet of such space so
occupied in the between decksor in
the cabins. One
PassengerIs to be deducted
from the numbers
abovestated.
C.      
When plying by day on
voyages which do not
lastmore than 6 hours
(smooth water only) Then for every 3 superficial feet of
such spaceso occupied on the upper
or main deck, and every 9
superficialfeet of such space so
occupied in the between deck or in
thecabins. One
PassengerIs to be deducted
from the numbers
abovestated.
The freeboard of _______________mm was assigned and loading marks placed on the vessel's
side, the same is equivalent to the carriage of a maximum load comprising ........tonnes of cargo
and/or1....... passengersBoats, Life Buyos, and EquipmentsRequired to be carried by this vessel.
BoatsLife-buoys and
Equipment's
Boatof the aggregate
capacity ofcubic
feetA Fire-Hose capable of being connected with theengine,
and of sufficient length to be used in any part of
thevessel approved fire extinguishers.
   (a) Compass(b) Life-Buyos©© BuoyantApparatus(d)
Bilge and HoldPump(e) Fire bucket.Fit and
ready for
use
This is to Certify that the provisions of the law with respect to the survey of the above mentioned
Inland Vessel and the Transmission of declaration in respect thereof, have been complied
with.Examined and registered.Signed by Chief Surveyor,Inland Vessel, Bihar, Patna.This Certificate,
unless previously cancelled or revoked, to be in force until the........ day of ........20.....If the vessel is
out of place of survey, it must be surveyed and have a new Certificate before it first begins to ply and
after its return or subsequent return to place of survey.Either this Certificate, or the Duplicate
thereof, and copy in the vernacular is to be put up in a conspicuous place or part of the vessel where
it will be visible to all persons on board the same.If the number of passengers carried exceeds the
number stated in this Certificate, the Master and Owner shall for every passenger over and above
that number be each liable to a fine which may extend to twenty rupees.In case of any accident
occasioning loss of life, or any material damage affecting the seaworthiness or efficiency or the
vessel to be either in the hull or in part of the machinery a report by letter, signed by the Owner or
Master is to be forwarded to the authorised engineer and ship surveyor. Office at the Inland Water
Transport, within 24 hours after the happening of the accident, or as soon thereafter as
possible.N.B.- Any communication address to the above mentioned officer relative to this vessel
should state the name, port of place of survey of the vessel and the number of this
certificate.Form-7[See rule 6(2)]Certificate of Survey-BIssued under the Inland Vessel Act 1 of 1917
by the Government of Bihar, for an Inland Vessel Authorised to Ply by Night or Day withoutBihar Inland Vessels Rules, 2013

Passengers.To remain in force only until the day of 20....
The Inland Vessel Official No. Bihar...... port of Registry........
 Certificate of Registry No.......  
 Certificate of Survey No..B/-  
Owner, Managing Owner, or Agent............................
Port of Survey Gross Tonnage Name of Master and Number of his Certificate
   
Boats, Life-Buoys andEquipment Requiredto be Carried by thisShip/vessel
Boats (if any)   Life-Buoys
and
Equipment,
etc
-Boats of the aggregate
capacity of cubic meterA fire-Hose capable of being connected with theengine,
and of sufficient length to be used in any part of thevessel
approved fire Extinguishers.
 Compass, Life-Buoys Buoys apparatus Bilge andhold
Pump Fire bucket. Fit and ready
for use
This is to Certify that the provisions of the law with respect to the survey of the above mentioned
Vessel and the transmission of declaration in respect thereof, have been complied with.Signed
byExamined and RegisteredChief Surveyor, Inland Vessel,Bihar, PatnaThis Certificate, unless
previously cancelled or revoked, to be in force until the ............ day of ...............20.............. If the
Vessel is out of a place of survey, it must be surveyed and have a new certificate before it first begins
to ply after its next subsequent return to a place of survey, either this Certificate or the duplicate
thereof, furnished is to be put up in conspicuous part of the vessel, where it will be visible to all
persons on board the same.Case of any accident occasioning lost of life or any material damage
affecting the sea worthiness or efficiency of the Vessel, either in the hull or in any part of the
machinery, a report by letter, signed by the Owner or Master, is to be forwarded to the engineer and
Ship Surveyor, office of the Inland Water Transport, within 24 hours after the happening of the
accident.N.B. : Any communication addressed to the above mentioned office relative to this vessel
should state the name, port of Survey of the Vessel and the number of this Certificate.Forms-8[See
Rule-7(1)]Temporary Authorisation Office of the Inland Water Transport, Bihar Patna
No- /WT Date:___________20
Certificate Valid Uptoin Lieu of Certificate of
SurveyMV_____________________________G.T.____________________________________
on Bihar_________________________ is hereby authorised to ply. It is manned by the
following Masters/ Serang and Driver. *Other conditions are a provided in the proceeding years
certificate of
survey.Master/Serang______________________________________________
________ Class________________Certificate
No____________________________date________
Emgineer/Driver______________________________________________
__Class____________________________Certificate/Licence No_______________
Date___________________________This motor vessels is fit to carry:When plying byBihar Inland Vessels Rules, 2013

datePassengersWhen plying by NightPassengersChief Surveyor, Inland Vessel,Bihar,
Patna.Forms-9(See Rule-9)Application for Registration of Builder/repairer of Inland VesselsTo,The
DirectorInland Water Transport,Bihar, Patna
1. Name of Applicant (in full)
_______________________________________________________________________
___________________________________________________ (details of
registration, partners, proprietor to be furnished)
2. Full Address of Applicant
___________________________________________________
3. Full address of workshop/dockyard where manufacturing/repairing is to be
carried out
_______________________________________________________________________
___________________________________________________
4. Full particulars of dockyard area docking facilities
available_________________________
5. Full particulars of fabrication workshop and machineries/equipment
available
6. Particulars of
(a)qualified personnel/experts
_____________________________________________________________
_____________________________________________________________(b)Total
work force in the roll _________________________________________________
7. Fabrication capacity per month in M/T
_______________________________________________________________________
___________________________________________________
8. Previous Manufacturing/repairing work done ( in terms of M/T and cost)
_______________Bihar Inland Vessels Rules, 2013

9. Type of vessels manufactured/repaired (Steel, Wood, GRP/FRP)
______________________
10. Solvency particulars
_________________________________________________________
11. Annual turnover during last three years
__________________________________________
Signature of the ApplicantForms-10[(See Rule-10 (1)]Application for Registration of Inland Vessels
Under Section 19d of the Inland Vessels Act, 1917To,The Registering Authority,I/We
_________________________________________ of
_______________________________________________being the owner of an Inland
Vessel called ___________ hereby request that the said vessel be registered at the port of
__________________ under the name:I agree to pay such fees as may be leviable under the
Rules, Particulars in respect of the said vessels are as under :-
1. Owners's Name and address (in Full)
_______________________________________________________________________
___________________________________________________
2. Occupation
_____________________________________________________________
3. Name of Master and his certificate No.
_____________________________________________________________
4. Name of the Port of Registry and No. if previously registered
_____________________________________________________________
5. Where, when and how the vessels was secured
_____________________________________________________________
6. Kind of vessels, Name and address of the Engine Makers with Horse
Power and year of make
Particulars of EngineBihar Inland Vessels Rules, 2013

9. State of vessel
10. Name and address of the Builders with place and year of build
_____________________________________________________________
11. Workshop Owned, if so, Particulars
_____________________________________________________________
12. Whether owners Adult or Minor
_____________________________________________________________
Place : _____________________Date : _____________________(Signature of
Owners)Declaration of OwnershipI/ We
____________________________________________________________
__________________________________________________ subject to the state of
________________ residing permanently at
___________________________________________________________ having
original place of business at _________________________________________________
do hereby declare that
____________________________________________________________ (name) was
built at ____________________________________________________________ __
in the year ___________and was prepared by me on ___________________ for rupees
_______ and wish to have the same registered in my name at the port of _______________ and
that I am the sole owner of the same . I further declare that the vessel is intended to ply in the port
of ____ ________________________(Signature of Owner)
6. Made and subscribed the _______________
7. day of _______________20, by the
8. above named _________________________
9. in the presence of ______________________
Magistrate/Justice of Peace/(Signature of Registering Authority)Note. - The Declaration must be
Made before a Registering Authority/a Magistrate or Justice of Peace.Forms-11[(See
Rule-12(1)]To,The Owner/Master on the Inland VesselSir/Madam,In acknowledging receipt of your
application for registration of the vessel named above under Inland Vessel Act, 1917 (1 of 1917) this
to state that Registering Authority/ Surveyor shall proceed on board the vessel at
__________________________ __________________hours on __________________
day of _________________, 20You are requested to afford to the Registering
Authority/Surveyor all reasonable facilities for the registration of the Inland Vessel and all suchBihar Inland Vessels Rules, 2013

information respecting the vessel as he may require for the purpose of registration.Yours
faithfullyRegistering Authority.Inland Vessel, Bihar.Form - 12[(See Rule-14(1)](Certificate of
Registration)of Inland Vessel under Section 19-F of the Inland Vessel Act, 1917 (1 of 1917) Official
No_________________No. Year and Port of Registry________
__________________________________________________________________________
______________ This is to Certify that ________________ of
_________________________ _____________________________ has declared that
___________________ subject of the State of _____ and the sole owner of
__________________called _______________________________ and that the
________________________ said _______________ was built at ________ __by
_____________________ of ___________________________ in the year
_____________________ The said _____________ had been duly registered at the port of
__________under the Inland Steam Vessel Act, 1917.Certified under my hand this the ______
day of _______________ 20
_______________________________________________________________Description
of EnginesName and address of makers________________________________________
When made _________________________ No. of sets of engines ___________ No. of
Shafts _______________________________________N.H.P. ___________
B.H.P._____________ I.H.P.____________Type of Engine Estimated speed of ship/Vessel
___________________________________________________Reciprocating engines :
No. and diameter of cylinders in each set _________________Length of stroke:Rotary Engine:-
No. of cylinders in each set ___________________________
Particulars of Vessels and Tonnage
Metre/centemeter  
Category  
Extreme Length No of
 Decks
Length No of
 Bulkheads
Breadth
__________________________________________________________Build and Material
___________________________
DepthStem
______________________________
 Description
Gross Tonnes  
Registered Tonnes  
 Registering Authority
Foot note. -Bihar Inland Vessels Rules, 2013

1. This certificate of registration to be produced for inspection on demand by
any authorised by the State Government.
2. This certificate must be surrendered to the Registering Authority if so
required by him.
3. While the certificate is in force, the vessel''s name and registration mark as
painted or otherwise marked in position approved by the government of
Bihar must not be removed or denied.
4. In case of any accident occasioning loss of the life, or efficiency of the
vessel, either in the hull OR in any part of machinery, a report by letter
signed by the owner or master, is to be forwarded to the
Registering Authority, Port of ___________________________ within 24 hours after the
happening of the accident or as soon thereafter as possible.Form-13[(See Rule-14(2)](Temporary
Registration Pass)(In Lieu of Certificate of Registration)To Remain in Force only Until
the_____________________ Day of______20At his is to certify that
Sri/Smt__________________________________ of
________________________________________ is / are the owner/owners of the Inland
Vessel official No. _______________________________________ having principal
dimension__________________ length___________ Breadth _________ depth
__________ and GRT
________________________________________________________________The
registration certificate of the said vessel is under preparation in the port of__________ as per
Inland Vessel Act, 1917.Registering AuthorityForm-14(See Rule-15)(Book of
Registration)Registration Mark
_______________________________________________________No. Year and Port
of Registry
________________________________________________________________Name
of Vessel
________________________________________________________________Name
of the Owner
________________________________________________________________Address
of owner
________________________________________________________________Description
of Inland VesselPassenger of Non passenger
________________________________________________________________Bihar Inland Vessels Rules, 2013

1. (a) Category
________________________________________________________________
(b)Gross Tonnage
______________________________________________________________(c)Registered
Tonnage
______________________________________________________________Particular
of Vessels
2.
(a)Length overall
________________________________________________________________(b)Breadth
Extreme
________________________________________________________________(c)Depth
of underside of deck amid ships, at
side_________________________________________________(d)Builder Name and
Address
________________________________________________________________(e)Year
of Built
________________________________________________________________(f)Hull
is of wood, steel etc.
________________________________________________________________(g)No.
of decks
________________________________________________________________(h)Description
_____________________________________________________________(i)No. of
Bulkheads
__________________________________________________________________________
______________________________________________________Transaction
Name of person from whom title is derivedRegistry No. of Shares affected Date of and hour of
Engine No.
3.
(a)Internal combustion engine
________________________________________________________________(b)Description
________________________________________________________________(c)No.
of sets
________________________________________________________________(d)Made
by
_______________________________________________________________(e)Year
of MakeBihar Inland Vessels Rules, 2013

________________________________________________________________(f)Surface,
jet or Non condensing
________________________________________________________________(g)No.
of cylinders per set
________________________________________________________________(h)Diameter
of cylinder in inches
________________________________________________________________(i)Stroke
in inches
________________________________________________________________(j)N.H.P.________________________B.H.P.___________________
I.H.P.______________Propulsion
4. Single, twin screw, side quarter or stem peddle
etc._____________________ Revolution per minute
__________________propulsion geared or direct driven ____________ speed
of vessel ______________
Registering AuthorityDate _____________________Subsequent to RegistrationNature & Date
of transactionName, Residence and occupationNumber of transaction of Transferee Mortgagee or
other person acquiring title or powerForm-15[(See Rule-16(2)]Application for Registration or
Alteration/issue of a Fresh Certificate of Reg. Under Sub-Section(2) of Section 9-J of the Inland
Vessel Act,1917.To,The Registering Authority,Sir,I
_____________________________________________________________________
_Being the owner of so inland vessel________________________________________
(name) bearing no. _________________ hereby beg to report that the following alterations have
been carried out on the vessel no. ____________ . I therefore, apply for registering the
alterations/for the issue of a fresh Registration Certificate. I enclose herewith a duplicate copy of
treasury challan showing the deposit of the necessary fees. I also enclose herewith the original
certificate of Registration.Date _____________(Signature of the Owner)Engine Name of vessel
_______________________ Type of Engine __________________No. of sets of
Engine_____________________Year of Make __________________________Name and
address of Builder
____________________________________________________________No. of Shafts
________________________________________________________________No. of
Cylinders
________________________________________________________________Diameter
of Cylinders (in Inches)
_______________________________________________________________B.H.P./N.H.P.
________________________________________________________________Surface,
Jet or Non-condensing
________________________________________________________________Revolution
per minute
________________________________________________________________I
hereby certify that the above particulars are true as per official records.DateBihar Inland Vessels Rules, 2013

______________(Signature of the Owner)Form-16(See Rule-17)Application for Transfer of
RegistryTo,Registering AuthorityI, _________________________ of
_______________________________ being the owner of an Inland Vessel No.
________________hereby request that the registry of the said vessel may kindly be transferred
from your register to the register of the Registering Authority of _________________
________________________ in the state of _____________________ . The certificate of
registration is enclosed here with/The certificate of registration will be forwarded to the Registering
Authority of____________ on demand.Treasury Challan for Rs. _________________ is also
enclosed.Place __________________Date __________________(Signature of
Owner)Form-17(See Rule-18)Deed of SaleI/We _______________________________ of
_____________________ in consideration as the sum of Rupees ____________________
paid to me/us by _________________ of ___________________ the receipt whereof is
hereby acknowledged, transfer the ownership of the Inland Vessel particularly described below and
in more details in the certificate of registration and the Registration Book together with
appurtenances to the said Inland/Vessel ________________________.Name of the Inland
Vessel ____________________________________Official
Number___________________________ Port of registry_________________ How
propelled____________________________________________________ Length
__________________Breadth__________Depth __________________ Gross
Tonnes________________________Registered Tonnes
____________________Description of engine_________________________
2. Further, I/We ________________________________ hereby declare that the
said Inland Vessel is free from/has the following encumbrances:
____________________________________________________________ In witness
where of I/We have here up to subscribed my/our name this ______________ _________day
of __________________________ executed by_______In the presence
of_______________________________________
________________________________________________________________Note. -
The deed must be executed before a Registering Authority and shall bear an adhesive of impressed
stamp of not less than the amount prescribed in Schedule I to the Indian Stamp Act,
1899.Form-18(See Rule- 19)Application for Transfer of OwnershipTo,The Registering Authority.I/
We................................ forwarded herewith the certificate of Registration of Inland Vessel
name.....................No. H.P.................................... the ownership of which has been transferred to
me/us by........................... and hereby request that the said Inland Vessel may be registered in
my/our name and the Certificate of Registration amended accordingly. The order of the government
of .........................sanctioning the transfer is also enclosed.Dated: -............(Signature of
Transferee)I/ We ................................... hereby certify that I/ We have transferred the ownership of
the above mentionedVessel, to
.......................................................................................................................
.......................................................................................................................(Signature of
Transferee)Form-19[See Rule 19 (1)]Intimation of Loss, Destruction or Mutilation of the Certificate
of Registry and Application for DuplicateTo,The Registering Authority,The Certificate ofBihar Inland Vessels Rules, 2013

Registration of my Inland Vessel, the............................ registration mark of which is
................................. has been lost/ destroyed/ mutilated/ in the following
circumstances......................................................The mutilated certificate is attached hereto.I hereby
declare that to my knowledge the registration of the vessel has not been either suspended or
cancelled under any of the provisions of the Act or Rules made thereunder and I herewith deposit
the fee of Rs. ......................... and apply for the issue of a duplicate Certificate of Registration.Date
........(Signature of Applicant)Address......Form-20[See Rule 23(2)]Application for Certificate of
Competency to Act as Engineer/ Engine Driver/ Serang/ Master of an Inland Mechanically
Propelled Vessel Plying in the State of BiharNote. - The applicant shall submit this form duly filled
in along with the necessary certificates for permission to appear at the examination to the
examination Centre, Bihar, Patna.Part-APersonal particulars
(1) Name in full :-(2) Surname :-(3) Nationality :-(4) Permanent
Address :- Passport sizephotographof
the 
(5)Date of birth :-(6)Place of birth :-Part-BParticulars of all previous certificate (if any)(1)Number
:-(2)Competency of service :-(3)Grade :-(4)Where issued :-(5)Date of issue :-(6)If at any time
suspended or cancelled by court or authority...........................
.....................................................(7)Date. :-(8)Cause :-Part-CCertificate now required(1)Grade
:-(2)Competency :-Part-DHave Your Appeared for this Examination Earlier?Yes/No.If Yes mention
year.Part-EDeclaration to be made by applicant:N.B. Any person who make, procures to be made or
assists in making any false representation for the purpose of obtaining for himself, or any other
person, a certificate either or competency or service, is for each offence liable to be punished for
cheating under Section 420 of the Indian Penal Code and also for knowingly giving false information
to the public servant under section 182 of the Indian Penal Code, of 1860.DeclarationI do hereby
declare that the particulars contained in Part A,B,C,D & E of this form are correct and true to the
best of my knowledge and belief, and that the papers enumerated in Part-G and send with this form
are true and genuine documents, given and signed by the persons whose names appear on them, I
further declare that the statement in Part-G contains a true and correct account of the whole of my
services without exception.And I make this declaration conscientiously believing the same to be
true, signed in the Presence of the Director/ Chief Examination, Bihar, Patna.Date........Signature of
the ApplicantPresent Address...............................................................Part-FCertificate of the Inland
Water Transport Bihar, Patna.The declaration under Part-E above was signed in my presence and
the fee of Rs......... received.
Date: - Director Inland Transport
Bihar, Patna.  
Part-G List of Testimonials and Statement of Service on Rivers or Shore or Sea
1. If served on board ship
(i)No. of testimonials/ certificates (if any :-(ii)Name of ship where employed :-(iii)Horse power of
the engine on which worked :-(iv)Port of registry and official no. of the ship :-Bihar Inland Vessels Rules, 2013

2. Service particulars of the Applicant :
(i)Capacity :-(ii)Date of appointment(iii)Date of termination/leaving(iv)State if continuing(v)Total
period served(a)Years :(b)Months:©© Days :(vi)Total service(vii)Total service on
shore/river:(viii)Period served for which certificates are now produced:-(ix)Period served for which
no certificates are produced :-Part-H Certificate of the ExaminerNote. - The examiner should fill up
Part-H and I and forward this form to the Director Inland Water Transport along with the
testimonials and other certificates, if any, with this form, the new certificates and the testimonials of
the applicant shall be delivered to him at the office of the Inland Water Transport Bihar, Patna.
1. Date and place of examination
2. Insert passed or failed against each item below:
(i)In working out the questions:(ii)In the viva examination:
3. Rank for which passed:
Part-I Personal Description of Applicant
1.Height:  
 Meters Centimeters
2.Complexion:  
3.Personal marks or peculiarities, if any,  
4.Colour of (a) Hair:-
  (b) Eyes :-
I hereby certify that the particulars contained in Part-H and Part-I are
correct.Date......Place......Name and signature of examinerForm-21(See Rule 34)Certificate of
Competency to Act as an Engineer of an Inland Vessel.To,Whereas it has been recommended by the
examiner appointed under Section 21 of the Inland Vessel Act, 1917 that you have been found, after
examination, duly qualified to act as Inland Vessel Engineer of an Inland mechanically propelled
vessel under the said Act, I do hereby, in pursuance of Section 21 of the said Act, grant you this
certificate of competency to act as an ENGINEER of an Inland Vessel.Given under my hand and
SealDirector Inland Transport,Bihar, Patna.The............. day of...............No. of certificate.............. . .
................Address of Certificate holder........ . . .. . . . . . . ... . . . . . . . . .Date and place of birth
..................................Signature............................................Issue at................. on the ..............
date.......Valid till.....Registered................Inland Water TransportBihar Patna.Note. - (1) Any
Engineer of an Inland Vessel who fails to handover the certificate which has been cancelled or
suspended is liable to penalty upto Rs. 1000/- (Rupees one thousand).(2)Any person other than the
certificate holder who comes in possession of this certificate is required to transmit it forthwith to
the Inland Water Transport, Bihar, Patna.Form-22(See Rules 34)Certificate of Competency to Act as
First Class Engine Driver of an InlandBihar Inland Vessels Rules, 2013

Vessel.To,____________________________________________________________________________________________________________________________________________Whereas
it has been recommended by the examiner appointed under Section 21 of the Inland Vessel Act, 1917
that you have been found, after examination, duly qualify, to Act as first class engine/ driver of an
Inland Mechanical propelled vessel. I do hereby, in pursuance of Section 21 of the said Act, grant
you this certificate of competency to act as First Class Engine Driver of an Inland Vessel.Director
Inland Water Transport,Bihar, Patna.The...................... day of.......................No. of
certificate............................................................................................. as First Class Engine Driver of
an Inland Vessel bearer....................................................... son of .......................
..........................................................................Date and place of birth(showing village, thane and
district)...................Residence (showing village, thane and district)........................................Personal
description stating particularly permanent marks or scares.........................Height.............................
date of examination..................................Number of Register
Ticket......................................Signature......................Issued at................. on the................. date
of..............Valid till....Registered..............Inland Water Transport,Bihar, Patna.Note. - (1) Any First
Class Engine Driver of an Inland Vessel who fails to handover the certificate which has been
cancelled or suspended is liable to penalty upto Rs. 1000/- (Rupees one thousand).(2)Any person
other than the holder of this certificate who comes in possession of this certificate is required to
transmit it forthwith to the Inland Water Transport, Bihar, Patna.Form-23(See Rule 34)Certificate
of Competency as Second Class Engine Driver of an Inland Vessel Under Act 1 of
1917To,____________________________________________________________________________________________________________________________________________Whereas
it has been recommended by the examiner appointed under Section 21 of the Inland Vessel Act, 1917
that you have been found, after examination, duly qualify, to Act as Second Class Engine Driver of
an Inland Mechanical propelled vessel. I do hereby, in pursuance of Section 21 of the said Act, grant
you this certificate of competency as Second Class Engine Driver of an Inland Vessel.Given under
my hand and seal.Inland Water TransportBihar, Patna.The...................... day of....................... No......
of certificate......................... as Second Class Engine Driver of an inland vessel bearer.....................
son of.................... .. ...........................date and place of birth (showing village, thane and
district).............. ................................................................................. Residence (showing village,
thane and district)..................................Personal description stating particularly and permanent
marks or scares...................... Height........................................ date of examination.............................
Number of Register ticket................................Signature...................Issued at...................... on
the............... date of .............Valid till....Registered................Inland Water TransportBihar,
Patna.Note. - (1) Any Second Class Engine Driver of an Inland Vessel who fails to handover the
certificate which has been cancelled or suspended is liable to penalty upto Rs. 1000/- (Rupees one
thousand).(2)Any person other than the holder of this certificate who comes in possession of this
certificate is required to transmit it forthwith to the Inland Water Transport Bihar,
Patna.Form-24(See Rule 34)Certificate of Competency to Act as First Class Master of an Inland
Vessel.To,____________________________________________________________________________________________________________________________________________Whereas
it has been recommended by the examiner appointed under Section 20 of the Inland Vessel Act,
1917 that you have been found, after examination, duly qualified to act as 1st class master of an
Inland mechanically propelled vessel under the said Act, I do hereby, in pursuance of Section 21 of
the said Act, grant you this certificate of competency to act as an First Class Master of an Inland
Vessel.Given under my hand and SealInland Water Transport,Bihar, Patna.The............. day
of...............No. of certificate.............. . . ................Address of Certificate holder........ . . .. . . . . . . ... . . .Bihar Inland Vessels Rules, 2013

. . . . . .Date and place of birth ..................................Signature............................................Issue
at................. on the .............. date.......Valid till....Registered................Inland Water Transport,Bihar
Patna.Note. - (1) Any 1st class master of an Inland Vessel who fails to handover the certificate which
has been cancelled or suspended is liable to penalty upto Rs. 1000/- (Rupees one thousand).(2)Any
person other than the certificate holder who comes in possession of this certificate is required to
transmit it forthwith to the Inland Water Transport, Bihar, Patna.Form-25(See Rules 34)Certificate
of Competency to Act as Second Class Master of an Inland
Vessel.To,____________________________________________________________________________________________________________________________________________Whereas
it has been recommended by the examiner appointed under Section 21 of the Inland Vessel Act, 1917
that you have been found, after examination, duly qualify, to Act as second class master of an Inland
Mechanical propelled vessel. I do hereby, in pursuance of Section 21 of the said Act, grant you this
certificate of competency to act as second class master of an Inland Vessel..Inland Water
Transport,Bihar, Patna.The...................... day of.......................No. of
certificate............................................................................................. as Second Class Master of an
Inland Vessel bearer......................................... son of .......................
..........................................................................Date and place of birth(showing village, thane and
district)...................Residence (showing village, thane and district)........................................Personal
description stating particularly permanent marks or scares...................Height............................. date
of examination..................................Number of Register
Ticket......................................Signature......................Issued at................. on the................. date
of..............Valid till....Registered...........Inland Water Transport,Bihar, Patna.Note. - (1) Any Second
Class Master of an Inland Vessel who fails to handover the certificate which has been cancelled or
suspended is liable to penalty upto Rs. 1000/- (Rupees one thousand).(2)Any person other than the
holder of this certificate who comes in possession of this certificate is required to transmit it
forthwith to the Inland Water Transport, Bihar, Patna.Form-26(See Rule 34)Certificate of
Competency as Serang of an Inland Vessel Under Act 1 of
1917To,____________________________________________________________________________________________________________________________________________Whereas
it has been recommended by the examiner appointed under Section 21 of the Inland Vessel Act, 1917
that you have been found, after examination, duly qualify, to Act as Serang/ B of an Inland
Mechanical propelled vessel having engines of less than 226 Brake Horse Power (226 B.H.P.) I do
hereby, in pursuance of Section 21 of the said Act, grant you this certificate of competency as Serang
of an Inland Vessel to ply in the State of Bihar. Given under my hand and seal.Inland Water
TransportBihar, Patna.The...................... day of.......................No...... of certificate......................... as
Serang of an inland vessel bearer..................... son of.................... ... by caste ...........................date
and place of birth (showing village, thane and district)..............
................................................................................. Residence (showing village, thane and
district).................................. Personal description stating particularly and permanent marks or
scares.................... Height................. date of examination............................. Number of Register
ticket......................Signature...................Issued at...................... on the............... date of .............Valid
till....Registered................Inland Water TransportBihar, Patna.Note. - (1) Any Serang of an Inland
Vessel who fails to handover the certificate which has been cancelled or suspended is liable to
penalty upto Rs. 1000/- (Rupees one thousand).(2)Any person other than the holder of this
certificate who comes in possession of this certificate is required to transmit it forthwith to the
Inland Water Transport, Bihar, Patna.Bihar Inland Vessels Rules, 2013

