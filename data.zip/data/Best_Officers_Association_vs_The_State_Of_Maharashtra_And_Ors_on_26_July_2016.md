Best Officers Association vs The State Of Maharashtra And Ors
on 26 July, 2016
Author: Anoop V. Mohta
Bench: Anoop V. Mohta, A. A. Sayed
    dgm                             1    wp-2797-15 judgment-25-7-16.sxw
                           WP/2797/2015 RESERVATION MATTERS
                                              INDEX
    Sr.No. Subject/heading/title                                           Para Nos.
    1         Introduction of controversy                                  2 to 7
    2         Prospect   in   Public   employment   to   all   the  8 to 9
              social group
    3         The basic constitutional amendments for SC  10 to 11
              and STs
    4         The   other   interlinked   constitutional  12 to 16
              Reservation provisions 
    5         Maharashtra Scheduled List of SC & ST, OBC,  17
              SBC, DT and NT
    6         The   State   Historical   reports   and  18 to 24
              recommendations
    7         The Reservation Act reflects the intention of  25
              the State Legislation Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

    8         Basic provisions of the Reservation Act                      26
    9         Impugned promotion circular                                  27
    10        Historical   background   of   the   promotion  28
              circular 
    11        The Other promotion rules                                    29
    12        Respondent's (Claimant) short submissions                    30 to 31
    13        Citations referred in the impugned judgment  32 to 33
              of MAT
    14        Basic principles relied by all - judgments cited  34 to 36
    15        The   State   submissions   and   the   cited  37
              judgments.
    16        Set of circumstances of the State.                           38 to 47
    17        The   relevant   circumstances   of   Other  48 to 49
              Backward Classes (OBC)
                                                                                            1/193
          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:12 :::
     dgm                             2    wp-2797-15 judgment-25-7-16.sxw
    18        OBC Historical background                                    50 to 51
    19        The specific case of OBC                                     52 to 57
    20        The averments against the Reservation Act                    58
    21        The case proceedings in High Court                           59 to 61Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

    22        Specific issues before the Tribunal (MAT)                    62
    23        Essential   reasons   for   the   conclusions   of   the  63
              matters
    24        Reservations on the base of 1931 Census and  64 to 70
              the natural growth of populations.  
    25        The scope and power of Court in setting up  71 to 74
              and   fixing   the   percentage   of   respective 
              caste/tribe 
    26
              The   affirmation   of   the   State   to   have  75 to 76
              quantifiable   adequate   data   of   SC,   ST   and 
              OBC
    27        State Committees, Commissions reports about  77 to 79
              "quantifiable data" and its Merit and Demerit. 
    28        Reference is made to the Cabinet Note dated  80
              30/11/1994 about the caste
    29        Specific Treatment to OBC - VJ/NT                            81
    30        The   State   Quantifiable   Data   and   updated  82 to 84
              contemporary   data,   though   not   precise   but 
              sufficient,  is available
    31        The   MAT   misread   historical   value   of   the  85 to 90
              reservation and the base for such reservation 
    32        Enthusiasm   of   increase   and/or   decrease   of  91 to 92
              respective reservation percentage 
    33        No   special   challenge   to   the   inclusion   and  93 to 94Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

              exclusion in State Caste/Tribe Lists
    34        The State empowered to make reservation in  95 to 96
              State   employment   recruitment   and/or 
              promotion 
              Mandamus   to   order   Reservation   or   De-
              reservation. 
                                                                                            2/193
          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:12 :::
     dgm                             3    wp-2797-15 judgment-25-7-16.sxw
    35        Provisions for Promotion                                     97
    36        Wisdom of State Legislation - to continue the  98
              existing   reservation   policy   -  for  both  stages 
              for all. 
    37        Existing   recognised   Constitutional  99
              Reservation   for   SC/ST   at   the   recruitment 
              level and or at promotional level is settled.  
    38        Last Caste  Census 1931 and natural growth  100
              binds   all   until   new   similar   Caste   Census   is 
              published   and   made   effective   for   all   the 
              communities.  
    39        No   prescribed   method   to   identify   Backward  101 to 109
              Class - Other Backward Class 
    40
              "Proper   Representation"   as   contemplated  110
              under Article 16(1)(4) for OBC permissible
    41        Judicial   Review   of   the   Listing   &   the  111Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

              "Quantifiable   &   Qualitative   Data   of   specific 
              Class/Group".
    42        The   Court   cannot   direct   or   restrict   the  112
              collection of upgrowing data. 
    43        The  excess  2%  (above  50%) reservation  for  113 to 116
              recruitment stage is permissible if the data is 
              available. 
    44        No   data   of   effecting   efficiency   in  117 to 118
              administration
    45        The State's bonafide action.                                 119 to 120
    46        A preliminary objectiion by the State                        121 to 125
    47        The power and jurisdiction of the tribunal -  126
              MAT
    48        Locus Standi of the contesting Respondents                   127 to 128
    49        The   tribunal   jurisdiction   to   declare  129 to 131
              Reservation Act ultra vires. 
    50        The impugned Judgment of MAT                                 132 to 133
                                                                                            3/193
          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:12 :::
     dgm                             4    wp-2797-15 judgment-25-7-16.sxw
    51        Abrupt   discontinuation   of   Earlier   Circular's  134 to 136
              and   existing   reservation   policy   incorporated 
              in the Reservation Act and the Circulars.  
    52        Nagraj's principle discussed by the Tribunal                 137Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

    53        The   State   under   continuous   obligation   to  138  to 139
              collect   data   for   modification   of   Reservation 
              policy 
    54        The   State   Promotion   policy   as   per   the   law  140 to 142
              and service rules only. 
    55        The   Reservation   in   promotion   through  143
              Circular since long. 
    56        The Statute need not be declared ultra-vires  144 to 145
              for the Academic purposes.
    57        "Catch Up Rules" vis-a-vis "interse seniority"  146
              & "Roster Point" 
    58         "creamy layer" applies to OBC & others                      147 to 148
    59        MAT's finding about the Creamy Layer                         149 to 152
    60        Wrong use of the Doctrine of Severability                    153
    61        The wrong shifting of Burden                                 154  to 155
    62        The Tribunal's wrong findings                                156 to 157
    63        Subject   to  the   data,  any  such reservation  is  158 to 166 
              permissible for all the classes - No total bar.
    64        Appointments   and   promotions   pending   the  167
              issues need protection
    65        Conclusions                                                  168 to 182
    66        Order                                                        183Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

                                                                                            4/193
          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:12 :::
     dgm                             5    wp-2797-15 judgment-25-7-16.sxw
               IN THE HIGH COURT OF JUDICATURE AT BOMBAY
                             CIVIL APPELLATE JURISDICTION
                              Writ Petition NO. 2797 OF 2015
    1      The State Of Maharashtra 
           Through The Chief Secretary 
           Government of Maharashtra,
           Mantralaya, Mumbai - 32
    2      The Principal Secretary to Government,
           General Administration Department,
           Mantralaya, Mumbai - 32                ..    Petitioner(s)
                                                  (Org. Respondents)
           Versus
    1      Shri Vijay Ghogre, Age: Adult
           Executive Engineer, Maharashtra
           Krishna Valley DevelopmentBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

           Corporation,  Bhosale Nagar Corner,
           Pune - 411 007
    2      Bapusaheb Rangnath Pawar,
           Executive Engineer, Maharashtra
           Krishna Valley Development
           Corporation, Chaskaman Project,
           Division, A2/2 Bhosari Paradise
           Raje Hills Road, Shivaji Nagar,
           Pune -20.
    3      Rajendra Ramchandra Pawar,
           Superintending Engineer, Konkan
           Irrigation Development Corporation,
           Dist. Thane
    4      Shivaji Maruti Upase,
                                                                                            5/193
          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:12 :::
     dgm                             6    wp-2797-15 judgment-25-7-16.sxw
           Superintending Engineer, 
           Executive Engineer, Maharashtra
           Krishna Valley Development
           Corporation, R/at: A/5, Swapnashilpa
           Housing Society, Near Gandhidam,Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

           Erandavan, pune -411004
    5      The Executive Director, 
           Maharashtra Krishna Valley Development
           Corporation, Sinchan Bhavan, Pune
    6      The Executive Engineer, 
           Konkan Irrigation Development
           Corporation, Dist : Thane
    7
           Dr. Babasaheb Ambedkar National
           Association, Flat No.103,
           Building No.4, MHADA Colony,
           Pratiksha Nagar, Sion, Mumbai-400 022
    8      Maharashtra Officers Forum,
           Through its Secretary, Shri S.V. Sute,
           4, Kotawalnagar, Nagpur
    9      Maharashtra Samanta Parishad,
           Through its President,
           Shri R.N. Kondhare,
           74, Mahatma Phule Peth, Pune-411 042
    10     All India Confederation of SC/ST
           Organisation, through the President,
           Anita Chambers, Near GPO, TrimbakBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

           Road, Nashik.
    11     Hemant Salvi,
           Employed as Awal Karkoon, Tahasildar, 
           Ratnagiri.
    12     Anant Shamrao Bundale,
           Employed as Awal Karkoon,Collector's Office,
                                                                                            6/193
          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:12 :::
     dgm                             7    wp-2797-15 judgment-25-7-16.sxw
           Ratnagiri,Supply Branch.
    13     Milind Shashikant Sawant
           Employed as Clerk, Tahasildar Office,
           Ratnagiri.
    14     Nandkumar Gajanan Mahakal,
           Employed as Clerk, with the Office of Ratnagiri,
           Maharashtra
    15     Bhaidas Dongardas Nikumbh
           [Sub Divisional Engineer]
           Residing at Harklal Nagar, Taloda,
           Dist. Nandurbar Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

    16
           Vimukta Jati Nomadic Tribes and
           Special Backward Classes Karmachari
           45, Sahyog,  Opp. GPO, Fort,
           Mumbai 400 001
    17     Karansingh Premsingh Patil,
           Residing at Diary Quarters,
           No. B-15, A.G. Khan Road,
           Worli, Mumbai 400 018
    18     Shri Bramha Laman Pawar,
           R/at : B-273, Government Colony,
           Bandra (E), Mumbai-51
    19     Shri Madhav Kundlik Avhad,
           Mangesh Dham No.2,
           Beturkarpada, Kalyan (West),
           Dist. Thane.
    20     Shri Surendra Arjun Pachpol,
           A/A-2, A-410, Parijat, Lokvatika
           Co-op. Housing Society Ltd. Netivali,
           New Panvel, Dist. Raigad. 
    21     Shri Vinayak Vishwanath Lavate,
                                                                                            7/193
          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:12 :::
     dgm                             8    wp-2797-15 judgment-25-7-16.sxw
           Keda Co-op. Housing Society Ltd.,Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

           Sec.-5, Plot No.11, Room No. 101,
           New Panvel, Dist : Raigad
    22     Rakesh Yeldap Vitkar,
           A-6, Kunal Icon, Pimple Sandagaon,
           Pimpri, Pune - 27.
    23     Panjabrao Narayanrao Naik,
           Hon. Secretary, Maharani Abhilyadevi
           Pratisthan, 301, Sangli Bhavan,
           Sector - 4, Charkhop, Kandivli(W),
           Mumbai 400 087
    24     Akhil Bharatiya Maratha Mahasangh,
           Shree Madhav Maharaj Shinde Hall,
           5, Navalkar Lane, Mumbai 400 087
    25     All India Confederation of SC/ST
           Organiation, 5, Pusa Road,
           Karoad Baug, New Delhi.
    26     Yuvraj Mahalu Bhave,
           Yeshwa Mandir, Kaushalya Nagar,
           Namvadi, Panchavati, Nashik-3.
    27     Hanmant V. Gunale,Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

           Age 49, Occ. Govt. Service
           Add: Yash Sankul,
           Vidya Nagar, Karad,
           Dist. Satara
    28     Rajan R. Shah,
           Age 39 years, Executive Engineer,
           Maharashtra Krishna Valley Development
           Corporation, Dhom Colony, Wai,
           Dist. Satara                ...          ...Respondent(s)
                                       (Nos. 1 to 4-org.Petnrs.
                                         Nos. 5 to 26-orig.Respondt.
                                         Nos. 3 to 24. 
                                                                                            8/193
          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:12 :::
     dgm                             9    wp-2797-15 judgment-25-7-16.sxw
                                            WITH
                              Writ Petition NO. 3009 OF 2015
    1      Vimukta Jatis, Nomadic Tribes 
           And Special Backward Class 
           Employees And Officers Association,  
           Mumbai, Mumbai, 49, Sahyog,
           Vth Floor, Opp. G.P.O., Fort,
           Mumbai - 1, Through its President
           Shri Rajaram G. Jadhav, age 50 years,
           Joint Secretary, Higher Tech. Dept.,Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

           Mantralaya, Mumbai-25,
           R/at : Y-6/86, Government Colony,
           Bandra (E), Mumbai-51
    2      Shri Karansingh Premsingh Patil,
           Section Officer, GAD Department,
           Mantralaya, Mumbai-25
           R/at : Dairy Quarters No. B-15,
           A. G. Khan Road, Worli, Mumbai-18
    3      Shri Madhav Kundlik Avhad,
           Section Officer, Finance Department,
           Mantralaya, Mumbai-25,
           R/at : Mangesh Dham No.2,
           Beturkarpada, Kalyan (West),
           Dist. Thane.                                 ...Petitioners
                                        (Org. Respondents 14, 15, 17)
           Versus
    1      Vijay Ghogre, Age: Adult
           Executive Engineer, Maharashtra
           Krishna Valley Development
           Corporation,  Bhosalenagar Corner,
           Pune - 411 007
                                                                                            9/193
          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:12 :::
     dgm                             10   wp-2797-15 judgment-25-7-16.sxwBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

    2      Bapusaheb Rangnath Pawar,
           Executive Engineer, Maharashtra
           Krishna Valley Development
           Corporation, Chaskamuti Project,
           Division, A2/2 Bhosari Paradise
           Raje Hills Road, Shivaji Nagar,
           Pune -20.
    3      Rajendra Ramchandra Pawar,
           Superintending Engineer, Konkan
           Irrigation Development Corporation,
           Dist. Thane
    4      Shivaji Maruti Upase,   
           Superintending Engineer, 
           Executive Engineer, Maharashtra
           Krishna Valley Development
           Corporation, R/at: A/5, Swapnashilpa
           Housing Society, Near Gandhidam,
           Erandavan, Pune -411004                            ...(Org. Petitioners)
    5      The State of Maharashtra,
           Through Chief Secretary,
           Government of Maharashtra,
           Mantralaya, Mumbai 32.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

    6      The Principal Secretary,
           General Administration  Department, 
           Mantralaya, Mumbai-32
    7      The Executive Director, 
           Maharashtra Krishna Valley Development
           Corporation, Sinchan Bhavan, Pune
    8      The Executive Engineer, Maharashtra
           Krishna Valley Development
           Corporation, Dist : Thane
    9      Dr. Babasaheb Ambedkar National
                                                                                           10/193
          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:12 :::
     dgm                             11   wp-2797-15 judgment-25-7-16.sxw
           Association, Flat No.103,
           Building No.4, MHADA Colony,
           Pratiksha Nagar, Sion, Mumbai-22
    10     Maharashtra Officers Forum,
           Through its Secretary, Shri S.V. Sute,
           4, Kotawalnagar, Nagpur
    11     Maharashtra Samanta Parishad,
           Through its President,
           Shri R.N. Kondhare,Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

           74, Mahatma Phule Peth, Pune-42
    12     All India Confederation of SC/ST
           Organisation, through the President,
           Anita Chambers, Near GPO, Trimbak
           Road, Nashik.
    13     Hemant Salvi,
           AwalKarkoon, Tahasildar Office,
           Ratnagiri.
    14     Anant Shamrao Bundale,
           AwalKarkoon,Collector's Office,
           Supply Branch, Ratnagiri.
    15     Milind Shashikant Sawant
           Clerk, Tahasildar Office,
           Ratnagiri.
    16     Nandkumar Gajanan Mahakal,
           Clerk, Office of Ratnagiri,
           Maharashtra
    17     Bhaidas Dongardas Nikumbh
           Sub Divisional Engineer,
           Harklal Nagar, Taloda,
           Dist. Nandurbar                              ...     Org. Resp 1-13
    18     Shri Bramha Laman Pawar,
                                                                                           11/193Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:13 :::
     dgm                             12   wp-2797-15 judgment-25-7-16.sxw
           Assistant, Rural Development &
           Water Conservation Department,
           Mantralaya, Mumbai-25.
           R/at : B-273, Government Colony,
           Bandra (E), Mumbai-51            ....                Org. Resp 16
    19     Shri Surendra Arjun Pachpol,
           Stenographer, Tourism & Cultural
           Department, Mantralaya, Mumbai-25
           R/at: A/A-2, A-410, Parijat, Lokvatika
           Co-op. Housing Society Ltd. Netivali,
           Kalyan (E), Dist: Thane
    20     Shri Vinayak Vishwanath Lavate,
           Assistant, School Education & Sports
           Department, Mantralaya, Mumbai-25
           R/at : Keda Co-op. Housing Society Ltd.,
           Sec.-5, Plot No.11, Room No. 101,
           New Panvel, Dist : Raigad                ...   Orig.Resp 18, 19
    21     Rakesh Yeldap Vitkar,
           A-6, Kunal Icon, Pimple Saudagar,
           Pimpri, Pune - 27.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

    22     Panjabrao Narayanrao Naik,
           Hon. Secretary, Maharani Abhilyadevi
           Pratisthan, 301, Sangli Bhavan,
           Sector - 4, Charkhop, Kandivli(W),
           Mumbai 400 087
    23     Akhil Bharatiya Maratha Mahasangh,
           Shree Madhav Maharaj Shinde Hall,
           5, Navalkar Lane, Mumbai 400 087
    24     All India Confederation of SC/ST
           Organiation, 5, Pusa Road,
           Karol Baug, New Delhi.
    25     Yuvraj Mahalu Bhave,
           Yeshwa Mandir, Kaushalya Nagar,
                                                                                           12/193
          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:13 :::
     dgm                             13   wp-2797-15 judgment-25-7-16.sxw
           Namvadi, Panchavati, Nashik-3.               ...     (Or Resp 20-24)
                                                        ....    Respondents 
               IN THE HIGH COURT OF JUDICATURE AT BOMBAY
                     ORDINARY ORIGINAL CIVIL JURISDICTION
                           WRIT PETITION NO. 1590 OF 2015Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

    1      Dr. Vyankatesh T. Anchinmane 
           Age - Adult, Occ: Medical Teacher,
           Residing at, Government Colony,
           Building No.2, Flat No.29,
           K. K. Marg, Haji Ali,
           Mumbai 400 034
    2      Dr. Satin Kalidas Meshram,
           Age - Adult, Occ: Medical Teacher,
           Residing at Plot No.75,
           V. K. Bhawan, Jagrut Nagar,
           Nagpur 440 014
    3      Shri Pramod Hirman More,
           Age : 38 Years,
           Occ : X ray Technician,
           G. T. Hospital, Mumbai,
           Residing at : 902, 9th Floor,
           High Rise Building,
           G. T. Hospital Compound,
           Mumbai 400 001                                     ...        Petitioners
           vs.
    1      State of Maharashtra 
           (Summons to be served on the 
           Learned Government Pleader appearing
           for State of Maharashtra underBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

                                                                                           13/193
          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:13 :::
     dgm                             14   wp-2797-15 judgment-25-7-16.sxw
           Order XXVII, Rule 4, of the Code of Civil
           Procedure, 1908)
    2      The Secretary,
           Law and Judiciary Department,
           Government of Maharashtra,
           Mantralaya, Mumbai 400 032.
           (Summons to be served on the 
           Learned Government Pleader appearing
           for State of Maharashtra under
           Order XXVII, Rule 4, of the Code of Civil
           Procedure, 1908)
    3      Mumbai Municipal Corporation
           Mumbai, Mahapalika Bhavan,
           (Summons to be served on the 
           Municipal Commissioner,
           Mumbai).
    4      Shri Vijay Ghogare,
           Executive Engineer,
           Maharashtra Krishna Valley
           Development Corporation,
           Bhosale Nagar Corner,Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

           Pune 411 007
    5      Shri Bapusaheb Rangnath Pawar,
           Executive Engineer,
           Maharashtra Krishna Valley
           Development Corporation,
           Chaskaman Project Division, A2/2,
           Bhosari Paradise, Raj Hills Road,
           Shivaji Nagar, Pune 411 020
    6      Shri Rajendra Ramchandra Pawar,
           Superintendent Engineer,
           Kokan Irrigation Development Corporation,
           Thane.
    7      Shri Shivaji Maruti Upase,
                                                                                           14/193
          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:13 :::
     dgm                             15   wp-2797-15 judgment-25-7-16.sxw
           Superintendent Engineer,
           Maharashtra Krishna Valley
           Development Corporation,
           Residing at A/5,
           Swapna Shilpa Housing Society,Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

           Near Gandhidham, Erandavan,
           Pune 411 004.
    8      Shri Hanumant V. Gunale,
           Executive Engineer,
           Maharashtra Krishna Valley
           Development Corporation,
           Yashsankul, Vidyanagar,
           Karad, District - Satara
    9      Shri Rajan R. Shah,
           Executive Engineer,
           Maharashtra Krishna Valley
           Development Corporation,
           Dhoom Colony,
           Wai, District - Satara
    10     Principal Secretary,
           General Administration Department,
           Mantralaya, Mumbai
    11     Executive Director,
           Maharashtra Krishna Valley
           Development Corporation,
           Sinchan Bhavan, Pune
    12     Executive Engineer,Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

           Konkan Irrigation,
           Development Corporation,
           Thane.
    13     Principal Secretary,
           Water Resources Department,
           Government of Maharashtra,
           Mantralaya, Mumbai                                 ...        Respondents
                                                                                           15/193
          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:13 :::
     dgm                             16   wp-2797-15 judgment-25-7-16.sxw
                                                 (Ori. Applicants No. 1 to 4
                                                 Respondent Nos. 4 to 7 before
                                                 Hon'ble MAT) 
                                       WITH
                           WRIT PETITION NO. 3287 OF 2004
    Best Officers Association,
    Through its Chairman,
    Shri Atul G. Patil, having its
    office at BEST House, P.O. Box No.192,
    Mumbai 400 001                                            ...Petitioner(s)
           Versus
    1      The State Of Maharashtra,Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

           through : Chief Secretary,
           Government of Maharashtra,
           Mantralaya, Mumbai
    2      The Principal Secretary,
           General Administration Department,
           Mantralaya, Mumbai.
    3      The Municipal Corporation of
           Greater Mumbai, through its
           Commissioner, having its address
           at Mahapalika Bhavan,
           Mahapalika Marg,
           Mumbai 400 001
    4      The Brihanmumbai Electric 
           Supply & Transport Undertaking,
           through its General Manager,
           having its address at BEST
           Bhavan, Electric House,
           Mumbai 400 001                                     ...Respondent(s)
                                                                                           16/193
          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:13 :::
     dgm                             17   wp-2797-15 judgment-25-7-16.sxw
    Mr.Rafiq Dada, Senior Advocate/Spl. Counsel, a/w Mr. Abhinandan B. 
    Vagyani,   Govt.   Pleader,   a/w   Mr.   C.P.   Yadav,   AGP,   a/w   Mr.   Vishal   B. 
    Thadani,   AGP   and   Ms.   Tintina   Hazarika,   for   the   Petitioners/State Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

    Government in WP/2797/2015. 
    Mr. A.Y. Sakhare, Senior Advocate, a/w Mr. Amit A. Karande, for the 
    Petitioners in WP 3009/15 and for Respondents No. 16, 17, 19 and 21 
    in WP 2797/15.
    Mr.   Rajeev   Dhawan,   Senior   Advocate   with   Mr.   Atul   Chitale,   Senior 
    Advocate, a/w Mr. C.T. Chandratre, for Respondents No. 1 to 4 in WP 
    2797/15.
    Mr. C.T. Chandratre, for Applicant in CAW 2531/15 in WP 2797/15.
    Mr.   Nitin   Deshpande,   for   the   Applicant   in   CAW   161/16   in   WP 
    2797/15.
    Mr.   Ashok   N.   Katangale,   with   Mr.   Arun   D.   Nagarjun   i/b   Mr.   A.K. 
    Saxena, for Respondent No. 7 in WP 2797/15.
    Mr. S.C. Naidu, with Mr. Rahul Tanwani and a/w Mr. Aniketh Poojari 
    i/b   Mr.   C.T.   Chandratre,   for   Respondents   No.   27   and   28   in   WP 
    2797/15.
    Mr. P.V. Suryawanshi, a/w Ms. Savitri I. Gajakosh, for the Applicant in 
    CAW 2301/15 in WP 2797/15.
    Mr.   A.V.   Anturkar,   Senior   Advocate,   i/b   Mr.   S.B.   Deshmukh   for   the 
    Petitioner in OS WP 1590/15.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

    Mr. G.K. Masand i/by Mr. Ajeet Manwani, for the Petitioner in OS WP 
    3287/04.
    None for other respondents. 
                                                                                           17/193
          ::: Uploaded on - 28/07/2016                        ::: Downloaded on - 28/07/2016 23:58:13 :::
     dgm                             18   wp-2797-15 judgment-25-7-16.sxw
                                     CORAM:    ANOOP V. MOHTA AND 
                                               A. A. SAYED,  JJ. 
    CLOSED FOR JUDGMENT ON:     May 04,   2016 
    PRONOUNCED ON           :  July 26, 2016
    JUDGMENT (Per Anoop V. Mohta, J.) 
1 All the writ petitions are heard by consent as assigned expressly. The issues are common and,
therefore, this concluding common decision.
Introduction of the controversy 2 The constitutional reservation policy always put the respective
State Government in imbroglio. It is going to last long, as no one in the present scenario or
otherwise is in frame of mind to compromise. Having once granted the constitutionally recognized
reservation in diverse areas including in the state employment, it's total abolition is unwarrantable
and without a solution. The legitimate rights once created and settled, since so many years, just
cannot be taken away by a stroke of pen. It is not the case of grant of the reservation in service for
the first time but question is of its continuance or discontinuance in part or full. Therefore, the crux
of the matter is whether existing reservation policy, in the State dgm 19 wp-2797-15Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

judgment-25-7-16.sxw employment, can be taken away by declaring such Reservation Statute and
the Promotion Circulars, ultra vires or illegal. To understand such situation and the dilemma of all
the concerned, we have to see the constitutional provisions and the existing Reservation Policy.
3 The constitutional validity of Maharashtra State Public Services (Reservations for Scheduled
Castes, Scheduled Tribes, De-
notified Tribes (Vimukta Jatis), Nomadic Tribes, Special Backward Category and Other Backward
Classes) Act, 2001 (the Reservation Act) and Government circular ,( GR No. BCC 2001/1887/PR.
KR.
640/01/16B dated 25.05.2004) (The Promotion Circular) issued by the State of Maharashtra (The
State) has been the focus of the writ petitions.
4 The Maharashtra Administrative Tribunal (MAT) by judgment and order dated 28 November
2014 in Transfer Application Nos. 1 & 2 of 2014, (transferred Writ Petition No. 8452/2004 on 18
June 2013), has declared the Reservation Act and the Promotion Circular violative of Article 16(4)
and 16(4-A) of the Constitution of dgm 20 wp-2797-15 judgment-25-7-16.sxw India and of the
judgment of Supreme Court in M. Nagaraj and others v. Union of India and others1.
5 The operative part of the impugned judgment is :
"OPERATIVE ORDER 134 Thus, for the reasons separately set out, we concur in the
conclusion that the impugned Act being Maharashtra State Public Services
(Reservations for Scheduled Castes, Scheduled Tribes, De-notified Tribes (Vimukta
Jatis), Nomadic Tribes, Special Backward Category and Other Backward Classes) Act,
2001, is ultravires the Constitution and the law laid down by Hon'ble Supreme Court
in the matter of M. Nagaraj and others Vs. Union of India and others (2006) 8 SCC
212. It will have to be and is hereby struck down.
The impugned G.R. No. BCC-2001 / 1887/pr.kr.640/01/16-B, dated 25th May, 2004
is also struck down. But we do realize that this judgment will be applicable only to the
Maharashtra State 1 (2006) 8 SCC 212 dgm 21 wp-2797-15 judgment-25-7-16.sxw
Government employees and as mentioned at the outset, the Writ Petitions filed by
the employees of other employers outside the jurisdiction of this Tribunal are still
pending before the Hon'ble Bombay High Court. It is almost certain that this
judgment will be challenged before the Hon'ble High Court or may be Hon'ble
Supreme Court. Therefore, in order to save all concerned from rushing in to the next
step, we think the effectuation hereof should be put on hold. In other words, the
operation hereof, should be stayed. We are so disposed in the set of the facts and
circumstances to stay this order for a period of one year. The parties will be free in
the meanwhile to move the Hon'ble Court before whom this order will be challenged
for any direction about this period also. However, as already noted there are interim
orders made by the Hon'ble High Court. The said orders are in force. They willBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

continue to govern all concerned notwithstanding this judgment and the stay granted
by us to our own judgment. We cannot and do not interfere therewith.
dgm 22 wp-2797-15 judgment-25-7-16.sxw 135 The impugned Act being Maharashtra
State Public Services (Reservations for Scheduled Castes, Scheduled Tribes,
De-notified Tribes (Vimukta Jatis), Nomadic Tribes, Special Backward Category and
Other Backward Classes) Act, 2001 and impugned G.R. No. BCC-2001 /
1887/pr.kr.640/01/16-B, dated 25 th May, 2004 stand hereby struck down as
ultravires the Constitution and ultravires the law laid down by the Hon'ble Supreme
Court inter-alia in M. Nagaraj and others Vs. Union of India and others (2006) 8 SCC
212. The operation hereof is stayed for a period of one year from today during which
period the interim stay granted by the Hon'ble High Court shall continue to govern
all concerned. Both these Transfer Applications are allowed in the above terms with
no order as to costs."
6 The State, being aggrieved and affected by the judgment and order has filed Writ Petition No.
2797/2015. Another Writ Petition No.3009/2015 is filed by Vimukta Jatis, Nomadic Tribes And
dgm 23 wp-2797-15 judgment-25-7-16.sxw Special Backward Class Employees And Officers
Association being the party to the impugned judgment. Writ Petition No.3287/2004 is filed by Best
Officers Association, opposing the reservation policy, will be considered on it's fact based merits
separately. In W.P/1590/2015, the Petitioners support the reservation policy.
7 The parties have filed their affidavits, reply, rejoinder, sur-
rejoinder, in support of their respective submissions. The State affidavits are supported by the data,
charts and the documents. The earlier statutes and the circulars are noted to deal with the center of
attention.
Prospect in Public employment to all the social group.
8 The historical provisions of law of reservation policy of Central and the State Government are
important. The relevant clauses of Article 16 of the Constitution of India read and referred by the
counsel appearing for the parties from their respective points of view.
"16. Equality of opportunity in matters of public employment.--(1) There shall be
equality of opportunity for all citizens in matters relating to employment or
appointment to any office under the State.
(2) No citizen shall, on grounds only of religion, dgm 24 wp-2797-15
judgment-25-7-16.sxw race, caste, sex, descent, place of birth, residence or any of
them, be ineligible for, or discriminated against in respect of, any employment or
office under the State.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

(3) Nothing in this article shall prevent Parliament from making any law prescribing,
in regard to a class or classes of employment or appointment to an office under the
Government of, or any local or other authority within, a State or Union territory, any
requirement as to residence within that State or Union territory prior to such
employment or appointment.
(4) Nothing in this article shall prevent the State from making any provision for the
reservation of appointments or posts in favor of any backward class of citizens which,
in the opinion of the State, is not adequately represented in the services under the
State.
(4A) Nothing in this article shall prevent the State from making any provision for
reservation in matters of promotion, with consequential seniority, to any class or
classes of posts in the services under the State in favor of the Scheduled Castes and
the Scheduled Tribes which, in the opinion of the State, are not adequately
represented in the services under the State.
(4B) Nothing in this article shall prevent the State from considering any unfilled
vacancies of a year which are reserved for being filled up in that year in accordance
with any provision for reservation made under clause (4) or clause (4A) as a separate
class of vacancies to be filled up in any succeeding year or years and such class of
vacancies shall not be considered together with the vacancies of the year in which
they are being filled up for determining the ceiling of fifty per cent.
dgm 25 wp-2797-15 judgment-25-7-16.sxw reservation on total number of vacancies
of that year.
(5) Nothing in this article shall affect the operation of any law which provides that the
incumbent of an office in connection with the affairs of any religious or
denominational institution or any member of the governing body thereof shall be a
person professing a particular religion or belonging to a particular denomination."
9 The conclusion in M. Nagaraj (supra) is :-
"121 The impugned constitutional amendments by which Articles 16(4A) and 16(4B)
have been inserted flow from Article 16(4). They do not alter the structure of Article
16(4). They retain the controlling factors or the compelling reasons, namely,
backwardness and inadequacy of representation which enables the States to provide
for reservation keeping in mind the overall efficiency of the State administration
under Article
335. These impugned amendments are confined only to SCs and STs. They do not
obliterate any of the constitutional requirements, namely, ceiling- limit of 50%
(quantitative limitation), the concept of creamy layer (qualitative exclusion), the sub-Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

classification between OBC on one hand and SCs and STs on the other hand as held
in Indra Sawhney, the concept of post-based Roster with in-built concept of
replacement as held in R.K. Sabharwal.
122 We reiterate that the ceiling-limit of 50%, the concept of creamy layer and the
compelling reasons, namely, backwardness, inadequacy of representation and overall
administrative efficiency are all constitutional dgm 26 wp-2797-15
judgment-25-7-16.sxw requirements without which the structure of equality of
opportunity in Article 16 would collapse.
123 However, in this case, as stated, the main issue concerns the "extent of
reservation". In this regard the concerned State will have to show in each case the
existence of the compelling reasons, namely, backwardness, inadequacy of
representation and overall administrative efficiency before making provision for
reservation. As stated above, the impugned provision is an enabling provision. The
State is not bound to make reservation for SC/ST in matter of promotions. However
if they wish to exercise their discretion and make such provision, the State has to
collect quantifiable data showing backwardness of the class and inadequacy of
representation of that class in public employment in addition to compliance of Article
335. It is made clear that even if the State has compelling reasons, as stated above,
the State will have to see that its reservation provision does not lead to excessiveness
so as to breach the ceiling-limit of 50% or obliterate the creamy layer or extend the
reservation indefinitely.
124 Subject to the above, we uphold the constitutional validity of the Constitution
(Seventy-seventh Amendment) Act, 1995; the Constitution (Eight-first Amendment)
Act, 2000;
the Constitution (Eighty-second Amendment) Act, 2000 and the Constitution
(Eighty-fifth Amendment) Act, 2001.
125 We have not examined the validity of individual enactments of appropriate States
and that question will be gone into in individual writ petition by the appropriate
bench in accordance dgm 27 wp-2797-15 judgment-25-7-16.sxw with law laid down
by us in the present case."
The basic Constitutional Amendments for Scheduled Castes (SC) and Scheduled Tribes (STs) :
10 In the Constitution of India, on 17 June 1995, a new clause (4A) in Article 16, has been introduced
to provide for reservation in promotion for the SC and ST. The Constitution (Eighty First
Amendment) Act, 2000 enabled the State to restore the position as was prevalent before 29 August
1997, thereby recognition was given to the concept "Backlog vacancies" by treating it as a class of
vacancies. The Constitution (Eighty Second Amendment) Act, 2000 dated 8 September 2000, thus a
proviso to Article 335 of the Constitution has been inserted and restored the relaxations in mattersBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

of reservation in promotion.
11 The Constitution (Eighty-Fifth Amendment) Act, 2001 (dated 4.1.2002) in the interest of the
Government Servant belonging to the SC and ST categories in matters of seniority on promotion to
the next higher grade, an amendment is made to Article 16(4A) thereby "in matter of promotion
with consequential seniority to any class" has been substituted in place of words "in matters of dgm
28 wp-2797-15 judgment-25-7-16.sxw promotion to any class". This amendment has been given
retrospective effect i.e. 17 June 1995, the date on which Article 16 (4A) itself was brought into force.
The other interlinked constitutional Reservation Provisions.
12 We have to read following Articles of the Constitution of India, "subject to " other connected
provisions.
Art.14           Equality before law
Art.15           Prohibition   of   discrimination   on   grounds   of   religion, 
                       race, caste, sex or place of birth
Art.40           Organisation of village panchayats
Art.330          Reservation of seats for Scheduled Castes and Scheduled 
                       Tribes in the House of the People
Art.332          Reservation of seats for Scheduled Castes and Scheduled 
Tribes in the Legislative Assemblies of the States Art.334 Reservation of seats and special
representation to cease after seventy years Art.335 Claims of Scheduled Castes and Scheduled Tribes
to services and posts Art.338 National Commission for Scheduled Castes Art.338A National
Commission for Scheduled Tribes Art.339 Control of the Union over the administration of
Scheduled Areas and the welfare of Scheduled Tribes Art.340 Appointment of a Commission to
investigate the conditions of backward classes Art.341 Scheduled Castes dgm 29 wp-2797-15
judgment-25-7-16.sxw Art.342 Scheduled Tribes Art.366 Definitions 13 All these Articles reflect the
purpose of reservation for Scheduled Tribe, Scheduled Caste and for Other Backward Class and
provisions for collecting the information and the material/data for various constitutional provisions.
Articles 330, 332 and 334 apportion the seats for Scheduled Caste and Scheduled Tribes in the
House of the People and Legislative Assembly, on the population basis. The expression "population"
means "the population as ascertained at the last preceding census of which the relevant figures have
been published". The report of 2001 is has been used for such purposes by all concerned.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

14 It is stated through Article 334 that the reservations of seats and special representation ceases to
effect on an expiration of a period of 70 years from the commencement of the Constitution. This is
in view of Constitution 95th Amendment Act 2009 with effect from 25/01/2010, whereby the words
"sixty years" are substituted by "seventy years". This will retain the position up to year 2020.
     dgm                             30   wp-2797-15 judgment-25-7-16.sxw
    15              Article   335   empowers   the   respective   State   or   Union   by 
    keeping  in   mind   the   "efficiency  of  administration"   to  consider     the 
claims of members of Scheduled Castes and Scheduled Tribes before an appointment to Union/State
services and posts. This includes the power of relaxing qualifying marks in any examination and/or
lowering the standards of evaluation, even for the reservation in the matter of promotion to any
class or classes of services or posts in connection with the affairs of the Union and State. These
provisions bind the State while enacting the Reservation Act.
16 Admittedly, National Commission for Scheduled Castes and Scheduled Tribes has been
constituted in view of Articles 338 and 338A. All the concerned are working on every aspect of the
castes to evaluate the progress of it's development. They annually report the recommendations in
the interest of all. The Reservation Act and so also the promotion circulars cannot be in
contravention of any of these reports or recommendations submitted by the commissions.
Article 340 provides for appointment of commission to investigate the condition of socially and
educationally backward classes within the territory of India and to make recommendations to
improve their dgm 31 wp-2797-15 judgment-25-7-16.sxw condition, to provide the grants etc.
Articles 341 and 342 specifically deal with Scheduled Castes and Scheduled Tribes in compliance of
constitutional provisions. This includes the power of Parliament and/or the State, with the
consultation of Governor, to include and to exclude from the specified list the particular
caste/group/community, through the notification by the President, from time to time.
Maharashtra Scheduled List of SC & ST, OBC, SBC, DT AND NT 17 The lists of Scheduled Castes and
Scheduled Tribes, Other Backward Classes, Special Backward Category, De-notified Tribes and
Nomadic Tribes in Maharashtra, published and have been modified from time to time. Similar are
the lists under the Constitution (Scheduled Castes) Order 1950 and the Constitution (Scheduled
Tribes) Order 1950 (as amended from time to time). This includes even the Central List of Other
Backward Classes referring to the Judgments of the Supreme Court relating to the reservation of
27% vacancies in civil posts and services, under the Government of India.
The constitution of Expert Committee on "Creamy Layer" headed by Justice R.M.Prasad has
prepared the common list covering the list of OBC for the purpose of reservation in State services,Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

which includes apart from other 14 dgm 32 wp-2797-15 judgment-25-7-16.sxw States, the State of
Maharashtra as well. The Central list for the State has been amended and modified regularly
covering the castes and communities belonged to even of OBC, apart from SC and ST so recorded
above. Rarely, the castes and communities once added are deleted. There is a State list of Other
Backward Classes published, modified and amended from time to time, The entries are also
transferred to other list because of interpretation by the Courts. The crux is, the Central and the
State Government, based upon the material available with them add and/or delete and/or bring in
or out, the caste or community in the list for extending the various constitutional concession and the
benefits. The process has been going on since long. It is ultimately the Central/State Government
would decide, in view of enabling provision and power, to include the caste and community in the
beneficiary list to provide further benefits in accordance with law. The State, therefore, required to
consider the data, material collected by them to amend the list under the recognized mechanism. All
the interested are entitled to claim benefits, concession in every province of the society. This
definitely includes the reservation so declared in advance, before treating them in service, at the
time of appointment/post and/or in promotion if so dgm 33 wp-2797-15 judgment-25-7-16.sxw
required. The reservation process does not commence only at the time of appointment and/or
granting concession to the class or categories and/or for promotion, but even prior to the same.
The State Historical reports and recommendations.
    A)              THADE COMMITTEE REPORT 1961
    18              The Thade Committee constituted by the State in the year 
1960. The report was given referring to the data of population of Vimukta Jati, Nomadic Tribes and
Semi-Nomadic Tribes within the State. However, there was no specific recommendation, regarding
these communities, made at that time, is the opponent's argument.
    B)              B. D. DESHMUKH REPORT, 1964  
    19              The   report   has  dealt  with  the  Government   decision  and 
statistical data so provided and recorded in recruitment of VJ NT community and it's low percentage
in reservation. The basis of backwardness is also recorded including the genesis and origin of
reservation. Ultimately, the recommendations have been provided to grant reservation as VJ/NT
need special consideration and, therefore, recorded that the reservation in promotion is also
necessary for VJ/NT.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

     dgm                             34   wp-2797-15 judgment-25-7-16.sxw
    C)     EDATE COMMITTEE REPORT, 1999 :
    20              The   recommendation   so   provided   based   upon   the 
population of VJNT as per 1931 Census. It is recognised mode for assessing the percentage of
population and percentage of reservation in proportion. After due survey, it is observed that there
was inadequacy of representation. The percentage of population of VJ-A, NT-B, NT-C, NT-D are
also provided for giving proper representation and the percentage of reservation.
21 The National Commission for Backward Classes Act, 1993 (for short, NCBC Act) was promulgated
on 2 April 1993. The National Commission for Backward Classes has been constituted accordingly.
The relevant definition of "backward classes" and "Lists"
are reproduced as under:
"2(a) "backward classes" means such backward classes of citizens other than the
Scheduled Castes and the Scheduled Tribes as may be specified by the Central
Government in the lists;
2(c) "lists" means lists prepared by the Government of India from time to time for
purposes of making provision for the reservation of appointments or posts in favour
of backward classes of citizens which, in the opinion of that Government, are not
adequately dgm 35 wp-2797-15 judgment-25-7-16.sxw represented in the services
under the Government of India and any local or other authority within the territory
of India or under the control of the Government of India."
22 The function and power that the Commission is required to consider the representation/request
for inclusion of any classes of citizen as backward class in the list. It also includes to consider the
complaints of over-inclusion or under-inclusion of any backward classes. It is stated that the advice
of the Commission shall normally be binding upon the Central Government. It is also provided to
have a periodic revision of list after every succeeding period of ten years to add or delete the list of
those who have seized to be backward classes.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

    D)     State Backward Class Commission Reports - 
    23              As directed by the Supreme Court to constitute Backward 
Class Commission, the Standing Committee was appointed. Later on converted into State Backward
Class Commission under the Chairmanship of Shri Justice Khatri. As decided, adopted the process
for preparing the report. The criterion prepared by The Mandal Commission was also noted. The
material and information so collected, after holding detailed inquiry by submitting even the separate
Reports.
dgm 36 wp-2797-15 judgment-25-7-16.sxw The detailed report/data, survey, material are also part
of record. The Commission has dealt with about 147 representations of various communities. The
proposals of 59 communities have been studied so also 95 representations were considered.
Ultimately, recommendations have been made referring to inclusion and rejection. All the related
issues have been considered accordingly.
24 The State has separate Backward Class Cell (General Administration Department) which has the
data of inadequacy of recommendation of the backward class. It collects and updates annual data
regarding representation of backward class in service.
The Reservation Act reflects the intention of the State Legislation.
25 Any Legislation reflects the intention of the Legislators -
Parliamentarians. The Reservation Act, as enacted, in view of the
judgments/directions/observations of the Supreme Court. An interpretation of any such statues
needs to be, by keeping in mind, the constitutional provisions and related laws and mainly including
Articles 14, 15, 16, 330, 335, 341, 342 to 354 - and also 1950 Orders
- and scheduled list and related State Scheduled List as amended. All these constitutional provisions
are interlinked and inter-dependent to dgm 37 wp-2797-15 judgment-25-7-16.sxw decide the
reservation policy in India.
Basic Provisions of the Reservation Act 26 The clauses of the Reservation Act read and referred by
the learned counsel appearing for the parties :
Section 2. In this Act, unless the context otherwise requires,-
(a) "appointing authority" in relation to public services and posts means the authority
empowered to make appointment to such services or posts;Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

(b) "De-notified Tribes (Vimukta Jatis)" means the Tribes declared as such by the
Government from time to time;
(c) "establishment" means any office of the Government or of a local authority or
statutory authority constituted under any Act of the State Legislature for the time
being in force, or a University or a Company, a Corporation or a Co-operative Society
in which share capital is held by the Government or any Government aided
Institutions.
Explanation.-For the purposes of this clause the expression "Government aided institutions" shall
also include institutions or industries which have been given either prior to coming into force of this
Act or thereafter, aid in the form of Government land at concessional rates or any other monetary
concessions by Government, or is recognised, licenced, supervised or controlled by Government;
(d) "Government" means the Government of Maharashtra;
(e) "Group 'A', 'B', 'C' or 'D' means the posts falling within the dgm 38 wp-2797-15
judgment-25-7-16.sxw Group 'A', 'B', 'C' or 'D', as the case may be, as classified by Government by
issuing general or special orders issued in this behalf, from time to time;
(f) "Nomadic Tribes" means the Tribes wandering from place to place in search of their livelihood as
declared by Government from time to time;
(g) "Other Backward Classes" means any socially and educationally backward classes of citizens as
declared by the Government and includes Other Backward Classes declared by the Government of
India in relation to the State of Maharashtra;
(h) "prescribed" means prescribed by rules framed by the Government under this Act;
(i) "public services and posts" means the services and posts in connection with the affairs of the
State and includes services and posts in-
(i) a local authority;
(ii) a co-operative society established under the Maharashtra Co-operative Societies Act, 1960, in
which Government is a shareholder;
(iii) a Board or a Corporation or a statutory body established by or under a Central or a State Act
which is owned and controlled by the Government, or a Government Company as defined in section
617 of the Companies Act, 1956;
(iv) an educational institution owned and controlled by the Government, which receives grant-in-aid
from the dgm 39 wp-2797-15 judgment-25-7-16.sxw Government including a university established
by or under a Maharashtra Act;Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

(v) any establishment; and
(vi) respect of which reservation was applicable by government orders on the date of
commencement of this Act and which are not covered under sub-clauses (i) to (v);
(j) "recruitment year" means the English calendar year during which the recruitment is actually
made;
(k) "reservation" means the reservation of post in the services for the members of Scheduled Castes,
Scheduled Tribes, De- notified Tribes (Vimukta Jatis), Nomadic Tribes, Special Backward Category
and Other Backward Classes;
(l) "Scheduled Castes" and "Scheduled Tribes" shall have the meanings, respectively assigned to
them in the clauses (24) and (25) of Article 366 of the Constitution of India;
(m) "Special Backward Category" means socially and educationally backward classes of citizens
declared as a Special Backward Category by the Government."
Section 4. (1) Unless otherwise provided by or under this Act, the posts reserved for the Scheduled
Castes, Scheduled Tribes, De-notified Tribes (Vimukta Jatis), Nomadic Tribes, Special Backward
Category and Other Backward Classes shall not be filled in by the candidates not belonging to that
caste, tribe, category or class for which the posts are reserved.
(2) Subject to other provisions of this Act, there shall be posts reserved for the persons belonging to
the Scheduled Castes, Scheduled Tribes, De-notified Tribes (Vimukta Jatis), Nomadic Tribes, dgm
40 wp-2797-15 judgment-25-7-16.sxw Special Backward Category and Other Backward Classes, at
the stage of direct recruitment in public services and posts specified under clause (j) of section 2, as
provided below :-
    Description                                          of  Percentage of vacancies 
    Caste/Tribe/Category/Class                               or seats to be reserved
    (1) Scheduled Castes                                    13 per cent
    (2)  Scheduled Tribes                                   7 per cent
    (3)  De-notified Tribes (A)                             3 per cent
    (4)  Nomadic Tribes (B)                                 2.5 per cent
    (5)  Nomadic Tribes (C )                                3.5 per centBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

    (6)  Nomadic Tribes (D)                                 2 per cent
    (7)  Special Backward Category  ig                      2 per cent
    (8)  Other Backward Classes                             19 per cent
    Total:                                                  52 per cent :
Provided that, Government may, by an order in the Official Gazette, provide that the percentage of
reservation for Scheduled Castes, Scheduled Tribes, De-notified Tribes (Vimukta Jatis), Nomadic
Tribes, Special Backward Categories and Other Backward Classes, in all posts, shall be on the basis
of latest census record of population of the , -
(i) State, in the case of State cadre posts, and
(ii) concerned district, in the case of district cadre posts:
Provided further that, the principle of "Creamy Layer" shall be applicable to all
categories mentioned above except Scheduled Castes and Scheduled Tribes.
Provided also that, if on the date of coming into force of this Act, if any additional
reservation is in force for the Scheduled Tribes in Thane, Nashik, Dhule, Nandurbar,
Raigad, Yavatmal, Chandrapur and Gadchiroli districts for direct recruitment in
Groups C and D posts, dgm 41 wp-2797-15 judgment-25-7-16.sxw under any
Government orders, such reservation shall continue to be in force till such orders are
modified or revoked.
(3) The reservation specified for the categories mentioned at serial numbers (3) to (6)
(both inclusive) in the table under sub-
section (2) shall be inter transferable. If suitable candidates for the posts reserved for any of the said
categories are not available in the same recruitment year, the posts shall be filled by appointing
suitable candidates from any of the other said categories.
(4) In all posts at the divisional level or district level the percentage of reservation occurring in a
recruitment year in such categories of Group-C and Group-D posts as may be notified by the
Government in this behalf, shall be maintained at such divisional or district level only.
Section 5 : (1) The reservation in promotion shall be at all stages of promotions.
(2) On the date of coming into force of this Act, if any Government orders providing for reservation
for any posts to be filled by promotion, are in force, the same shall continue to be in force unless
modified or revoked, by Government.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

Section 6 : (1) If in respect of any recruitment year, any vacancy reserved for any category of persons
under sub-section (2) of section 4 remains unfilled, such vacancy shall be carried forward upto five
years in case of direct recruitment and three years in case of promotion:
Provided that, on the date of commencement of this Act, if any Government order
regarding filling up the posts, in case of non availability of Backward Class candidates
are in force, such Government orders shall continue to be in force unless modified or
revoked, by Government.
Section 10 : (1) The Government may, by order, provide for nomination of officers
belonging to Scheduled Castes, Scheduled Tribes and Other Backward Classes in the
selections, screening and departmental promotion committee for the purpose of
selecting persons for appointment or promotions, as the case may be, to public dgm
42 wp-2797-15 judgment-25-7-16.sxw services and posts.
(2) The Government may, by order, grant such concession in respect of fees for any
competitive examination or such other similar examinations or interviews, and
relaxation in upper age limit as it may be considered necessary in favour of the
categories of persons specified in sub-section (2) of section 4.
(3) The Government orders, in force on the date of the commencement of this Act, in
respect of concessions and relaxation including concession in fees for any competitive
examinations or such other similar examinations or interview and relaxation in the
upper age limit shall continue to be applicable, unless modified or revoked, by
Government."
Impugned Promotion Circular 27 The relevant clauses of Government Notification for promotion
dated 25 May 2004 (The Circular) are :-
"2 At present, Government, vide column No. 5 of the Reservation Act No. 8 published
in the Govt. of Maharashtra Gazette, dated 29th January, 2004, made the following
provisions:
(A) Section 5, sub section (1) :- The reservation in promotion shall be at all stages of
promotions.
(B) According to Sub Section (2), on the date of coming into force of this Act, if any
Government orders providing dgm 43 wp-2797-15 judgment-25-7-16.sxw for
reservation for any posts to be filled by promotion are, are in force, the same shall
continue to be in force unless modified or revoked, by Government.
3 In supersession of the orders dated 23rd May, 1974, 20th January 1975 and 23rd January 1991,
the following revised orders are being issued in view of provision under Sub-Section (1) and (2) of
Section 5 of the Act which has been brought into force newly.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

Government Resolution for promotion:-
(A) As per the Sub Section (1) of Section 5 of the Maharashtra Act No. 8 (Reservation
Act), the principle of reservation shall be applicable to those posts which are filled up
by promotions. In view of this, principle of reservation in promotion shall be
applicable in respect of all posts, including those posts also for which proportion of
direct recruitment is more than 75%. The provisions under the Govt. Resolution
dated 23.1.1991 stand cancelled.
(B) The reservation in promotions will be as follows:
             (1)     Scheduled Castes             -      13%
     dgm                               44   wp-2797-15 judgment-25-7-16.sxw
             (2)     Scheduled Tribes                -       07%
             (3)     De-Notified Tribes (A) -                3%
             (4)     Nomadic Tribes (B)              -       2.5%
             (5)     Nomadic Tribes (C )             -       3.5%
             (6)     Nomadic Tribes (D)              -       2%
             (7)     Special Backward Classes                2%
                        -----------Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

                                                  Total:         33%
             (C )             The principle of reservation shall be applicable 
from 29/1/2004 onwards at all stages of promotions on posts for which there is
provision of giving promotion in the Recruitment Rules and the principle of
reservation was not applicable earlier.
(D) Those Backward Class of employees who have been promoted, prior to
29/1/2004, on the post above the first stage of class I posts shall be considered as
having been promoted as per the seniority and merit.
(E) Posts to be filled up as per above provisions of the Act shall be filled up step by
step in accordance with the dgm 45 wp-2797-15 judgment-25-7-16.sxw availability of
vacant posts.
(F) The orders issued under G.R. No. BCC-1097/C.R. 63/97/16-B, dated 18.10.1997
shall be applicable for such cadres / posts to which principle of reservation in
promotions is being made applicable newly. However, for calculating number of
reserved posts, total number of sanctioned posts should not be taken into
consideration.
The number of vacant posts in that cadre which become available after 29/1/2004 should be taken
into consideration to decide number of reserved posts as per the percentage of reservation
prescribed for various backward class categories.
(G) The provisions of reservation of the Act will not be applicable in respect of the process of
selection started prior to 29.1.2004 for giving promotions on posts above the first stage of class I
posts and on such posts for which reservation in promotion was not previously applicable.
However, for the process of selection for giving promotion to be started after 29/1/2004 the
principle of reservation as per the provisions of the Act shall be applicable."
dgm 46 wp-2797-15 judgment-25-7-16.sxw Historical background of the Promotion Circular 28 The
Reservation Act came into force from 25 May 2004.
The State Reservation Policy even before the Reservation Act, based upon the last Caste Census of
1931 and the natural growth of the population including the Population Census of 2001. There were
various State Notifications/circulars published and implemented from time to time in this regard. ig
• 7 January 1961 : Resolution expressing sympathy for the predicament of the BSC and requiring
returns to be filed on their representation in various departments. Pre 1974 :Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

Reservations introduced at entry point in various services of the State. 23 May 1974 :
Reservations in promotional posts made for (13% SC, 7% ST and 4% Denotified
Tribes and Nomadic Tribes) to all posts. 28 January 1975 : Reservation in matters of
promotion up to Class I (level 1 : entry point) posts recruited on the basis of positive
merit. 31 July 1976 : No reservations in promotional posts where direct recruit
reservations 66.6% or more. 23 January 1991 : No reservations in promotional posts
dgm 47 wp-2797-15 judgment-25-7-16.sxw where direct recruitment reservation is
75% or more. 16 November 1992 : Mandal judgment of Supreme Court (Indra
Sawhney (1992) Supp. 3 SCC 217 at prs. 827-8 p. 745-7 that reservations in matters of
promotion are contrary to equality.
17 June 1995 : Constitution (77th Amendment) Act permitting promotions
reservation in or SC and ST are inadequately represented. No change was made in
favour of the OBCs. 18 October 1997: Resolution implementing R.K. Sabharwal's case
(1997) 2 SCC 945 to ensure that percentages do not cross over the prescribed limits.
13 December 1999: Indira Sawhney II (2000) 1 SCC 168 at pr. 65 that equality is part
of the basic structure of the Constitution. Note also the decision in M. G.
Badappanavar (2001) 2 SCC 666 at pr. 13 reiterating that equality is part of the basic
structure. 9 June 2000 :
Constitution (81st Amendment) Act 2000 permitting carryover of vacancies to
subsequent years. 2001 : Constitution (85 th Amendment) Act 2001 seeking to grant
consequential seniority for reservation promotees. 22 January 2004 : Maharashtra
State Public Service (Reservation for Scheduled Castes, Scheduled Tribes, De-notified
Tribes (Vimukta Jatis), Nomadic dgm 48 wp-2797-15 judgment-25-7-16.sxw Tribes,
Special Backward Category and Other Backward Classes Act 2004 (Act of 2004). 25
May 2004 : Resolution purporting to implement the Act of 2004.
The other Promotion Rules
29 Some earlier service rules relating to seniority and promotion are :-
• 28th Jan. 1975 : Promotions upto Class I (Level I) on seniority subject to fitness and
in Class I on basis of "positive merit". Where seniority and fitness rule was applied,
sympathetic consideration to be given to BCs.
• 7 April 1983 : Rules under Article 309 for Engineering cadres fixing cadre wise
seniority.
• 16 September 1990 : Ajit Singh (II) (1999) 7 SCC 209 stating that to be consistent
with equality, seniority would be cadre based to recognize entry point seniority. • 25
May 2004 : Clause (D) of the Notification of 25 May 2004 suggests that all persons
promoted up to 29 January 2004 have presumed merit.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

• 4 February 2005 : Separate Notifications for (i) Chief Engineers
(ii) Secretary, Executive Director/ Director General that appointment shall be strictly
on the basis of "merit and strict selection."
All these circulars and the rules have been acted upon by all at least till the State statutes.
                         Respondent's (Claimant) short submissions 
    (i)      An examination of the rules in respect of reservations, seniority 
     dgm                              49   wp-2797-15 judgment-25-7-16.sxw
and promotions show a haphazard reversal of earlier policies by the Promotion Circular to a manner
and extent inconsistent with the requirements of the Mandal decision: Indira Sawhney (supra) and
M. Nagaraj (supra).
(ii) The Reservation Act fails to disaggregate permissible reservations in promotions (for SC and ST)
under Article 16 (4A) and (B) and impermissible reservations for others (OBC and other
beneficiaries). This runs through the entire Act in ways that defy severability.
(iii) In any event, the Reservation Act is also invalid on other grounds on the basis of the definition
of the institutions and posts the fixing of percentage and quota without examining the need for
`adequate representation', the over-barred carry over provisions, the inter-transferability of
beneficiaries and ambiguous provisions on the creamy layer and other provisions.
(iv) The Promotion Circular is arbitrary, shows non-application of mind and is inconsistent with the
Mandal Judgment (1992) and Article 16 (4A) and (4B) even if the constitutional amendments
enacting article 16(4A) and 16(4B) are treated as valid.
    (v)     The Apex Court has in M. Nagaraj, (supra);  Suraj Bhan Meena Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

     dgm                              50   wp-2797-15 judgment-25-7-16.sxw
v. State of Rajasthan; Uttar Pradesh Power Corporation Ltd v. Rajesh Kumar; S. Panneer Selvam v.
Government of Tamil Nadu (2015) 9 SCALE 350 reiterate that the impugned Constitutional
Amendments are valid because they are enabling. But any legislation or action under them must,
satisfy the following requirements: compelling necessity, 50% reservation limit, inadequacy of
representation, creamy layer restriction and lack of excessiveness on the basis of relevant
quantifiable data.
(vi) No relevant quantified data exists to support the Reservation Act and the Promotion Circular.
31 The Respondents' gist of challenge to the respective Sections of the Reservation Act and the
Promotion Circular are :
i) Preamble to the Reservation Act does not provide for special justification for
reservation of Scheduled Castes, Scheduled Tribes, De-notified Tribes (Vimukta
Jatis), Nomadic Tribes, Special Backward Category and Other Backward Classes.
ii) Section 5 of the Reservation Act and the Promotion Circular to the extent it is
contrary to Article 16 (4A), has been correctly struck down by the MAT.
dgm 51 wp-2797-15 judgment-25-7-16.sxw
iii)Sections 4 and 5 of the Reservation Act are not compliant with the requirements
provided in Nagaraj (supra) and in breach of the 50% rule as laid down in Indra
Sawhney, R.K. Sabharwal and M. Nagaraj.
iv)The State failed to exclude the "creamy layer" both at the stage of direct
recruitment and promotions for Scheduled Castes and Scheduled Tribes and
therefore reservation for Scheduled Caste and Scheduled Tribes, both at the stage of
direct recruitment and promotions are required to be quashed and set aside on this
ground alone.
v) The Reservation Act also fails to satisfy the criterion of Nagaraj as regards
inadequacy of representation on basis of quantifiable data and overall administrative
efficiency has been correctly struck down by the MAT.
vi)The Reservation Act is also invalid on the ground that the definition of
"institutions and posts" is too wide. The over-broad carry over provisions, theBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

inter-transferability of beneficiaries and ambiguous provisions on the creamy layer
and other provisions makes the provisions of the statute unworkable.
      vii)          The unworkable provisions of the Reservation Act are not 
     dgm                              52   wp-2797-15 judgment-25-7-16.sxw
severable and therefore the entire Reservation Act was rightly struck down by the
MAT.
viii) This Court has considered the law laid down by the Supreme Court as well as the
Division Bench of this High Court and held that MAT had the jurisdiction to decide
the constitutional challenge to the Reservation Act and that the Respondents - as
Original Petitioners had the locus to maintain the said challenge.
(ix)The judicial review of impugned order passed by a statutory Tribunal under
Article 226 of the Constitution of India is limited;
(x) The Tribunal has power to decide the constitutional validity of the Act and/or the
Circular. The State's preliminary objection, is unsustainable about the Locus standi of
original Petitioner.
32 Citations referred in the impugned judgment of MAT M. Nagraj and ors (supra), RK Sabharwal
(supra), Ajit Singh Januja & ors v. State of Punjab2, Kalyan Darhah's, Gopal Krishnaji Ketkar v.
    2   (1996) 7 SCC 209
     dgm                             53   wp-2797-15 judgment-25-7-16.sxw
Mohammed Haji Latif & ors3, General Manager, Southern Railway v.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

Rangachari Gurbus Das4,Indira Sawhney (supra), Union of India (supra), State of Kerala (supra),
Akhil Bhartiya Sushikshit Karamchari Sangh (Railway) (supra), Barium Chemicals Ltd vs. Company
Law Board5,Uttar Pradesh State Power Corporation vs. Rajesh Kumar6, Reservation M. R. Balaji
(supra), Shri Sanjeet Shukla v. State of Maharashtra [ Petition(L) No.2053 of 2014); PH Advani vs.
Harpal Singh7,Keshavananda Bharti Case8, Virpal Singh Chauhan, (supra), Minerva Mills Ltd
(supra), Suraj Bhan Meena (supra) and also relied upon judgment of Madhra Pradesh High Court in
Writ Petition No.1942/2011-R. B. Rai v. State of Madhya Pradesh along with connected matters
dated 30.04.2016.
33 The following Judgments have been read/referred and distinguished in addition.
a) Surajbhan Meena Vs. State of Rajasthan (supra) 3 AIR 1962 SC 1416 4 AIR 1962 SC 36 5 1966
Supp. SCR 311 6 (2012) 7 SCC 1 7 AIR 1975 Bom 120 8 (1973) 4 SCC 225 dgm 54 wp-2797-15
judgment-25-7-16.sxw
b) U.P. Power Corporation Vs. Rajesh Kumar & Ors.
c)    Salauddin Ahmed Vs. Samata Andolan
d)    S.V. Joshi Vs. State of Karnataka
e)    Himachal   Pradesh   Schedule   Tribes   Employees   Federation  
                 Vs. Himachal Pradesh S.V.K.K. & Ors.
f)    S. Panneer Selvam Vs. The General Manager
           g)    Sushil Kumar Singh & Ors. Vs. State of Bihar & Ors. (CAJ  
                 Case No. 19114 of 2012) (HC Patna)
           h)    Jayanta Chakraborty & Ors. Vs. State of Tripura & Ors.  
                 (WP(C) 189 of 2011)-HC (Tripura)
           i)    Sanjit   Shukla   Vs.   State   of   Maharashtra,   2015(2)   BCR  Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

                 267- 
                           Basic principles have been relied by all.
    34               For   their   respective   submissions,   the   learned   senior
counsel appearing for the parties have read and referred the Supreme Court judgments in the matter
of such reservation and all related specific doctrines/principles from their respective points of views:
(i) Reservation Quota limits (e.g. 50% )(Quantifiable data) "Quantitative limits" M. R.
Balaji9 M. Nagraj (supra)
(ii) Treating reservation as an instance of equality and not an exception to it. N. M.
Thomas,10
9 (1963) Supp. 1 SCR 439 10 (1976) 2 SCC 310 dgm 55 wp-2797-15 judgment-25-7-16.sxw
(iii) The `carry over' principle. Devadassan,11Indra Sawhney12
(iv) "Lowering standards", N. M. Thomas, 13 Akhil Bharatiya,14 Vinod Kumar15
(v) "Non-division of SC/ST on basis of further backwardness"
E. V. Chinnaiah16
(vi) "Denial of reservation in promotions", Indra Sawhney,
(vii) "Stopping roster" , R. K. Sabharwal17
(viii) "Accelerated seniority" and "catch-up rule", Virpal Singh Chauhan,18 Ajit Singh
(I),19 M. Nagaraj (supra)
(ix) "Creamy layer", Indra Sawhney, Indra Sawhney (II),20 Thakur,21 M. Nagaraj
(supra) Ashok
(x) "Aspects of Efficiency", (Article 335) Indra Sawhney(supra) Vinod Kumar22 35
All these Supreme Court judgments on law, need no discussion. It binds all. We have
to apply the law on facts andBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

11 (1964) 4SCR 680 12 (1992) Supp. (3) SCC 217 13 (1976) 2 SCC 310 14 (1981) 1 SCC 246 15 (1996) 6
SCC 580 16 (2005) 1 SCC 394 17 (1995) 6 SCC 684 : (1995) 2 SCC 745 18 (1995) 6 SCC 684 19 (1996)
2 SCC 715 20 (2000) (1) SCC 168 21 (2008) 6 SCC 1 22 (1996) 6 SCC 580 dgm 56 wp-2797-15
judgment-25-7-16.sxw circumstances of the case in hand. Most of above principles have been taken
note of while deciding the points so discussed.
36 The counsel for the State and the other Petitioners in support of Reservation Act and the
Promotion Circulars have referred :
a) Census Data on caste as available in 1931, but its natural grown data
b) The B. D. Deshmukh report is 1964,
c) The Thade Committee 1961,
d) The Edate Committee 1999 and
e) Population Census reports and the judgments
f) Various data/material/stated to be quantifiable data.
37 The State submissions & the cited judgments (1) General Manager, S. Rly. v. Rangachari, (1962) 2
SCR 586, (paras 23, 26).
(2) State of Kerala v. N.M. Thomas, (1976) 2 SCC 310 (Paras 21, 24, 29, 75, 184, 186, 191 ).
(3) Akhil Bharatiya Soshit Karamchari Sangh (Railway) v.
Union of  India, (1981) 1 SCC 246  (Paras 34, 36 )
         (4)        Indra Sawhney (supra)  (paras 796, 797, 798, 809, 810,
     dgm                             57   wp-2797-15 judgment-25-7-16.sxw
                    860)  - verify
         (5)        M. Nagaraj (supra)    Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

         (6)        Commissioner of Commercial Taxes, A.P. Hyderabad vs. G. 
                    Sethumadhava Rao, 1996 (7)  SCC 512 (para 10)
         (7)        Union of India v. Rakesh Kumar, (2010) 4 SCC 50 (paras 
                    41, 42, 43) 
         (8)        K. Krishna Murthy v. Union of India, (2010) 7 SCC 202  
                    (paras  65, 66, 67) 
         (9)        Suraj Bhan Meena and ors v. State of Rajasthan, 2011 (1) 
                    SCC 467. (paras 65, 66 )  
         (10)       Uttar Pradesh Power Corporation Limited v. Rajesh Kumar, 
                    2012 (7) SCC 1 (para 36) 
         (11)       S.V. Joshi v. State of Karnataka, (2012) 7 SCC 41 (paras 9 
                    to 13)   
      Set  of circumstances of the State
    38              The Reservation Act came into force on 29 January 2004.
It was implemented by Government Resolution dated 25 May 2004.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

By writ petition No. 8452 of 2004 filed on 11 October 2004, in the Bombay High Court, the
constitutional validity of it and the legality of the Promotional was challenged.
     dgm                             58   wp-2797-15 judgment-25-7-16.sxw
    39              On   behalf   of   the   State,     Mr.   Dinkar   Dhondu   Tiwrekar, 
Under Secretary, GAD, filed an affidavit and contended that, (i) There is a presumption of validity in
favour of the Act, unless proven otherwise; (ii) the challenge to the Constitutional validity of
Amendment to Article 16(4A) was pending before the Supreme Court and therefore, the Supreme
Court was seized off the matter; (iii) by way of 77 constitutional Amendment 16(4A) was added to
Article 16(4) providing for reservation in promotion and therefore the law laid down in R.K.
Sabharwal's case was not applicable; (iv) Creamy Layer concept was not applicable to SC and ST; (v)
85 th Amendment of the Constitution to Article 335 empowers the State to make provision in favour
of members of SC and ST; (vi) the High Court passed an order directing the parties to maintain
status quo. Same was the position of other Petitions.
40 On 30 March 2005, a detailed affidavit-in-reply was filed by Mr. R.G. Pawar, Depurty Secretary,
GAD pointing out the law laid down by the Supreme Court in Indra Sawhney's case. Development
after Indra Sawhney's case and subsequent amendment to Article dgm 59 wp-2797-15
judgment-25-7-16.sxw 16(4A) providing for Reservation in promotion. Brief history as to why
VJ/NT are treated as Backward Class. Detailed discussions have been made on the backwardness of
some classes who have been termed as depressed classes and also regarding some nomadic tribes
who indulged in criminal activities and were called criminal tribes.
The findings of Thade Committee Report, B.D. Deshmukh Committee Report were discussed and
findings therein have been given.
Government Resolution gave classification of backward classes. The state Resolution dated 9 April
1965 gave the percentages of reservation against each caste as classified. GAD Resolution dated 23
May 1974 provided for reservation for promotions till first stage of class. GAD resolution of 4 August
1992 included Dhangar Community along with its sub caste in the list of VJ/NT. Order in Writ
Petition No. 1142 of 1986 as well as order in Appeal No. 924 of 1986 dated 24 July 1992 were
pointed out. Order dated 24 July 1992, held that until such time as the representation were made
and decided Banjara and Vanjari community should be treated as synonyms of each other and
confidential circular 5 March 1986 not to be acted upon. SLP against order dated 24 July 1994
dismissed by the Supreme Court.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

Order dated 9 June 1992 passed by MAT in O.A. No. 77/91 in Writ dgm 60 wp-2797-15
judgment-25-7-16.sxw Petition No. 855 of 1990 directed the State Government to appoint a
Committee to decide whether Banjara and Vanjari are synonyms.
Committee Appointed under chairmanship of Dr. D.G. Wadhwa on 31 July 1992. On 9 August 1993,
Wadhwa Committee submitted its report that Banjara and Vanjari were not synonyms of the same
group.
Banjari Community came to be included in the list of VJ/NT.
Constitution of Khatri Committee and its report have been discussed.
Action taken by the Government on the basis of the Khatri Committee modifying the list of VJ/NT
and OBC and also gave details of the extent of Backlog of each category. Detailed discussion on why
VJ/NT have been provided with reservation in promotion and why creamy layer has been excluded.
41 On 20 April 2005, High Court granted Rule in Writ Petition and refused to modify the interim
order of stay dated 22 February 2005 of the Promotion Circular. On 5 August 2005, the Supreme
Court refused to interfere with the said order of stay.
42 On 17 August 2006, the High Court allowed Civil Application No. 1783 of 2006 filed on 6 July
2006 in Writ Petition No. dgm 61 wp-2797-15 judgment-25-7-16.sxw 8452 of 2004 pointing out the
difficulties being faced in the matter of promotions in view of the order dated 22 February 2005 as
huge number of posts were vacant. The High Court by its order dated 17 August 2006, permitted the
State Government to grant promotion to SC/ST only subject to outcome of the Petition. The State by
Resolution dated 24 August 2006, implemented the provisions of GR dated 25 May 2004 as per
order dated 17 August 2006. In the month of September 2006, Civil Application No. 2283 of 2006
was filed by the Respondent for modification of interim order dated 17 August 2006 and to stay to
Government Resolution dated 24 August 2006.
On 19 September 2006, the High Court passed an order whereby held that promotion given after 18
August 2006 shall be subject to final decision in Civil Application No. 2283 of 2006. On 25
September 2006, SLP No. 16485 of 2006 was filed by the Respondent in Supreme Court to
challenge orders dated 17 August 2006 and 19 September 2006 passed by the High Court. On 27
September 2006, Supreme Court stayed the above orders passed by Bombay High Court.
43 An additional Affidavit-in-reply was filed challenging the maintainability of Civil Application No.
2283/2006 on various dgm 62 wp-2797-15 judgment-25-7-16.sxw grounds including the ground
that by the Civil Application the Respondent (original Petitioner No.1) for seeking a Review of order
dated 17 August 2006 passed by the High Court in Civil Application No. 1783 of 2006.
44 On 19 October 2006, the Constitutional Bench of the Supreme Court decided the matter of M.
Nagaraj Vs. Union of India (Supra). On 10 November 2006, the State filed an affidavit in SLP
No.16485 of 2006. On 6 November 2006, the Supreme Court by order directed the Bombay HighBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

Court to consider Civil Application Nos. 1783 of 2006 and 2283 of 2006 de novo in the light of M.
Nagaraj case. On 15 December 2006, the State filed Civil Application No. 3130 of 2006 in Writ
Petition No. 8452 of 2004 in this Court and prayed to permit to fill in the promotional posts. On 26
December 2006, Respondent (Original Petitioner) filed Civil Application No. 134 of 2007 in Writ
Petition No. 8452 of 2004 and prayed to stay the operation of the Promotion Circular and the policy
of reservation in promotions. On 9 March 2007, this Court considered Civil Application Nos. 3130 of
2006, 1783 of 2006, 2283 of 2006 and by dismissing Civil Application No. 134 of 2006 passed the
order dgm 63 wp-2797-15 judgment-25-7-16.sxw allowing the State to fill promotional posts to the
extent of 67% from open category, 13% from SC, 7% from ST and remaining 13% from VJNT/SBC to
remain vacant till final disposal of Writ Petition No. 8452 of 2004. On 13 March 2007, the
Respondent (Original Petitioner) has challenged the order of this Court in the Supreme Court by
filing SLP No. 4984 of 2007. On 9 April 2007, the State has filed an affidavit in the SLP. On 4 May
2007, the State filed Review Application (Stamp) No. 11463 of 2007 in Writ Petition No. 8452 of
2004 to vacate above order dated 9 March 2007. On 13 July 2007, this Court rejected the Review
Petition. On 16 July 2007, the State pursuant to order dated 9 March 2007 passed by this Court gave
promotion excluding persons belonging to VJNT/SBC. On 5 September 2007, order dated 9 March
2007 of this Court was challenged by the State in the Supreme Court vide SLP No. 18534- 18537 of
2007. On 28 March 2008, the Supreme Court i modified order dated 9 March 2007 and permitted
the State to fill 13% posts of VJNT and SBC subject to final decision in Writ Petition.
45 On 27 December 2010, an additional Affidavit was filed by S.N. Rankhambe, Deputy Secretary,
GAD in reply to the amendment dgm 64 wp-2797-15 judgment-25-7-16.sxw carried out by the
Respondent (Original Petition ) in Writ Petition No. 8452 of 2004. The main contention raised in
the said affidavit was that conjoint reading of Articles 14, 15(4), 46 of the Constitution of India gives
ample power to the State to take steps and measures for the advancement of socially and
economically weaker sections of the Society. Reliance was placed on Thade Committee Report,
Deshmukh Committee Report, Khatri Committee Report, Indra Sawhney decision.
It was pointed out that the decision to provide for Reservation was taken in the basis of data
collected from various departments of the State and reading backlog pertaining to different
categories of backward classes. It was pointed out that save and except making allegations the
Respondent (Original Petitioner) has not been able to show any cogent evidence that there was no
satisfaction on the part of the State in respect of Backwardness of the categories covered, inadequacy
of the representation, maintenance of the administrative efficiency and concept of creamy layer. On
19 July 2010, the Supreme Court disposed off the SLP No. 4984 of 2007 in terms of its order dated
28 March 2008. The State had made the promotions accordingly.
     dgm                             65   wp-2797-15 judgment-25-7-16.sxw
    46              On 17 February 2011, an additional Affidavit-in-reply was 
filed by S.N. Rankhambe, Deputy Secretary, GAD in Writ Petition No. 8452 of 2004. It was pointed
out that history of reservation dates back to early 1880s till date and that the concept of Reservation
was not new. Reliance was placed on Justice Khatri Committee Report in the light of Indra SawhneyBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

case. Reliance was placed on Deshmukh Committee Report, pursuant to which policy decision was
taken to provide reservation in promotion up to class I category. It was pointed out that an analysis
of data from census of India from the year 1951 to 2001 regarding literacy and dropouts for SC and
ST, it was pointed that there was a wide group in literacy between SC and ST as compared to the
general category.
47 On 21 February 2012, Respondent (Original Petitioner) filed Additional Affidavit-in-reply in Writ
Petition No. 8452 of 2004. It was contended that the State has violated provisions of Article 16(4A)
as the mandatory three tests have not been complied with. The mandatory three tests i.e.
backwardness, inadequacy of representation and reservation in promotion shall not disturb the
efficiency of administration. That section 5 of the impugned Act is contrary to the dgm 66
wp-2797-15 judgment-25-7-16.sxw mandate laid down by the Supreme Court in the case of M.
Nagaraj and other subsequent judgments. That according to the directions given in Indra Sawhney
case the reservation in promotion was 33% upto first stage of Class I in service group A. Accordingly
to the ratio laid down in the Judgment the reservation was to be only for a period of five years for SC
and ST. However, the impugned Reservation Act was enacted providing for reservation in
promotion in all stages thereby violating the mandatory requirements of Article 16 and 16(4A).
The relevant circumstances of Other Backward Classes (OBC) 48 There are various Circulars which
are placed on record, whereby the community belongs to OBC have been provided with the various
concession and reservation. Government Resolution dated 23 May 1974 whereby the reservation to
all classes in promotion upto Class I was challenged [ 1988 (Supp.) Bom. C.R. 923 (Full Bench) -
Gopalirishna Ramchandra Chavan & ors v. State of Maharashtra, but was dismissed. The Apex
Court , by order dated 6.1.1998 [ 1998 (9) SCC 48 after Indira Sawhney's judgment (supra)
dismissed the Appeal thereby maintained the G.R. By observing that if implemented the policy of
reservation the quota is exceeded, it would be open to the dgm 67 wp-2797-15
judgment-25-7-16.sxw Petitioner to approach the Court. However, by Eighty-First Constitutional
amendment, Article 16(4)(B) with effect from 9.6.2000 by which unfilled vacancies were considered
as a separate class of vacancies, to be filled and not to consider together with the vacancies of which
succeeding year for determining the ceiling of 50% as observed.
49 Certain historical background and the related proceedings which we have noted, and as
submitted by the learned senior counsel appearing for the Petitioner, for OBC/VJ/NT are
reproduced:
OBC Historical background
50 The demand for reservation of government jobs was made as early as 1891 with an agitation in
the princely State of Travancore against the recruitment of non-natives into public service
overlooking qualified native people. In 1901, Reservations were introduced in Maharashtra in the
Princely State of Kolhapur by Chhatrapati Shahu Maharaj. Reservations in the princely states of
Baroda and Mysore were already in force. In 1908, reservations were introduced in favour of a
number of castes and communities that had little share in the administration by the British. ABest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

delegation of Muslim nawabs, dgm 68 wp-2797-15 judgment-25-7-16.sxw landlords, and prominent
persons led by Agha Khan, leader of the Ismaili Sect, presented a memorandum demanding a share
in the administration in proportion to their population. The viceroy gave it sympathetic
consideration and provisions were made in the government of India Acts of 1909 and 1919 granting
the Muslims due share and other facilities.
51 On 30/11/1948, The present Art 16(4) was discussed in the constituent assembly. Members like
Shri. M. Ananthasayanam Ayyangar, Shri. P. Kakkan have stated that the protection of reservations
for backward classes is needed even at the stage of promotions as well and the members intended
that Art 16 (4) shall include reservations in promotions as well. On 26/01/1950, The Constitution of
India came in force. On 1/5/1960, State of Maharashtra was formed. Prior to1961, Nomadic Tribes
i.e. wandering tribes were included in depressed classes. The Nomadic tribes identified by different
names in different part of India are included in schedule caste and scheduled tribes. On 21/11/1961,
As per the Thade Report the Govt under Government Resolution, Education and Social Welfare
Department No. CBC - 1361/4, dated dgm 69 wp-2797-15 judgment-25-7-16.sxw 21st November
1961 declared the communities indicated in schedule to the resolution as belonging to the Vimukta
Jatis and Nomadic tribes in the state of Maharashtra. On 11/01/1964, B G Deshmukh committee
submitted its report to the state government and proposed that the backward classes should be
grouped into Schedules Castes, Scheduled Tribes, Denotified & Nomadic Tribes and Other
Backward Classes. He stated that the DTNT are similarly situated with SC and ST and are most
backward. On 09/04/1965, based on the recommendations of Shri B. D. Deshmukh Committee
percentage of reservation for VJ/NT was fixed at 4%. On 23/05/1974, under GAD resolution No.
BCC - 1072-J reservations for promotions were introduced for VJ/NT as they were similarly situated
with SC & ST and did not have adequate representation in the State Services. The Nomadic or
wandering Shepherd Class i.e. Dhangar Community came to be included in the list of VJ/NT under
Govt in Social Welfare Dept Resolution No. CBC - 1089/ (203)/MVK5 dated 25 th May 1990. On
4/8/1992, the percentage of VJNT was increased to 6% for appointments i.e. including recruitment
and promotions. On 16/11/1992, the Constitution Bench of the Hon'ble Supreme Court In Indira
Sawhney Vs. Union Of India held that Art 16(4) does not dgm 70 wp-2797-15 judgment-25-7-16.sxw
include reservations in promotions. However, the bench held that the state might provide
reservation by direct recruitment at all stages to give adequate representation at all stages. On
23/3/1994. Vanjara Community included in the list of VJNT. VJNT increased to 11%. On 19/5/1995,
The State Backward Class Commission (Khatri Commission) was formed. On 17/06/1995,
Parliament by 77 th Constitutional amendment inserted Art 16(4) (A) permitting reservation in
promotions to the Schedule Castes and Schedule Tribes.
The object of the amendment was to overcome the Judgment in Indira Sahwney Case which held
that reservation of appointments or posts under Art 16(4) of the Constitution is confined to initial
appointment and cannot extent to reservation in the matter of promotion. It aimed to protect the
interests of Scheduled Castes and Scheduled Tribes as their representation in services in the States
have not reached the required level. Later it was further amended to include consequential seniority
by 85th amendment. On 01/03/1996, in the case of Ajit Singh Januja held that the SC and though
backward class candidates entitled to reservation in promotion - but open category senior
candidates, though promoted later than reserved category candidate, become senior to earlierBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

promoted backward class candidate, for dgm 71 wp-2797-15 judgment-25-7-16.sxw further
promotion. On 12/11/1998, as per the recommendations of Mutatkar Commission and Khatri
Commission list of VJNT and OBC's was modified. In 1999, Dr. Edate committee on the study of
VJNT submitted its report after making a detailed and in depth study of every aspect and also taking
into consideration the research made by Dr. Babasaheb Ambedkar Research institute Pune. The
final list of VJNT was published by the Government of Maharashtra in 1999. On 9/6/2000, the
Constitution 81st Amendment Act, 2000 inserted Art 16(4)(B) to create a distinct group of Backlog
vacancies to exclude them from the ceiling limit of 50% reservations. The amendment gave
legislative assent to the Judgment of R. K. Sabharwal.. In 2000, The Constitution 82nd Amendment
Act, 2000 inserted a proviso at the end of Art 335 of the Constitution for relaxing qualifying marks
and standards of evaluation in matters of reservations in promotions. This was to surmount the
Judgment of S. Vinod Kumar (1996 (6) SCC
580). In 2001, Constitution 85 th amendment act, 2001 [with retrospective effect from 17.6.1995]
was issued amending Art. 16(4) (A) granting a consequential seniority to reserved category
employees in their accelerated promoted posts - roaster point promotes to get accelerated seniority.
This amendment negated the effect of Virpal dgm 72 wp-2797-15 judgment-25-7-16.sxw Singh
Chauhans Case (1995 AIR SCW 4309) and Ajit Singh Januja (I) Case (1996 AIR SCW 1196). On
31/03/2002, The National Commission to review the working of the Constitution submitted its
report. The report states that the continued plight of the Denotified tribes, semi-nomadic and
nomadic tribes who are distributed in the list of Scheduled Castes, Scheduled Tribes and Backward
class is an eloquent illustration of the failure of the machinery of planning, financial resources
allocating budgeting and administration in the country to seriously follow the mandate of Art. 46.
The report further states that Art 16(4) and 16(4)(A) respectively permit reservation of
appointments or posts and in matters of promotions in favour of backward classes not adequately
represented in the services under the State. The report further states that the adequate
representation of backward classes is, however, still a far cry and special efforts need to be made for
effectively enforcing reservation of backward classes to achieve their adequate representation. On
12/10/2002, Writ Petition Nos. 319/2002, 255/2002 and 234/2002 under Art 32 were filed in the
Supreme Court challenging the Constitutional validity of the said amendment Act of 2001. The
Supreme court did not grant stay to the Amendment Act.
     dgm                             73   wp-2797-15 judgment-25-7-16.sxw
    The specific case of OBC 
    52              On   11/10/2004,       The   Constitutional   Validity   of   The 
Reservation Act and the Promotion Circular are challenged in WP no 8542 of 2004 and prayed also
that in the alternative it may be made applicable only to SC & ST subject to compliance with
guidelines laid down in M. Nagaraj Case. On 7/2/2005, the Division Bench of the Bombay HighBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

Court directed the parties to maintain status quo. On 20/2/2005, Respondent no 7 filed reply
stating that the corporation is not at all concerned as they don't recruit/promote and the
government department alone is concerned with the same. On 21/2/2005, Respondent no 8 filed
reply stating that it is a matter of public knowledge as to what all posts are super specialized posts.
That the corporation has no role to play in regulating the service conditions of the employees. The
state replied as to how and why the VJNT are treated as Backward Classes. That a committee was set
up in 1928 to inquire into the educational, economic and social conditions of the depressed classes
and the term depressed classes included the Untouchables, Tribes, Criminal Tribes and wandering
and other backward classes. The Criminal Tribes Act of 1924 identified large sections of the
Nomadic Tribes as criminals. Although the act was dgm 74 wp-2797-15 judgment-25-7-16.sxw
repealed the stigma attached to these groups still continues and are looked at with suspicion by the
administration and subject to harassment at the hand of the police and the State machinery. That
Thade Commission was appointed for unification of the lists of Vimukta Jaties and Nomadic Tribes
and Semi Nomadic Tribes of the entire state. Shri. Thade after an intensive survey throughout the
state and studying their living conditions, health needs etc and on the basis of survey recommended
for adopting uniform list. His report was accepted and on 21.11.1961 the State declared the Schedule
of VJNT.
Later B. D. Deshmukh committee was appointed for the reservation of backward classes in the
services. The committee after discussions with various departments and officers and after obtaining
statistical data of the actual position from 1950 submitted its report on 11/1/1964has recommended
that the percentage of reservation should be linked to population statistics and the backward classes
grouped into SC, ST, VJNT and OBC.
53 The reservation in promotions was provided from 1974 by GR dated 23/5/1974. In 1990,
Dhangar and Vanjari communities were added to the list of VJNT. On 7/12/1994certain
communities dgm 75 wp-2797-15 judgment-25-7-16.sxw such as Govari, Mana, Koshti, Koli and
Munnarwar were declared as Special Backward Class. The reservation of SBC is challenged in WP
(OS) 2027 of 1997 (Anil R. Joshi Vs. State of Maharashtra) and is still pending before the High
Court. As per the Judgment of Supreme Court in Indira Sawhney a committee of experts was
converted into the State Backward Class Commission on 19.05.1995 under the Chairmanship of
Shri. S. N. Khatri, retired judge of the Bombay High Court. The committee after considering various
claims and the judgment applied its mind to the situation prevailing and formulated a practical test
to determine backwardness of a class. The surveyors were trained .The committee carried
exhaustive enquiry. The recommendations were placed before the Cabinet on 12/11/1998 and the
lists of VJNT and OBCs was modified on the basis of these recommendations. That on the basis of
these recommendations, the state has noted that the classes recommended by the committee are not
adequately represented on the basis of a comparative statement prepared about the vacancies in
direct recruitments as well as promotions of each category. Thus the satisfaction of the state was
established.
     dgm                             76   wp-2797-15 judgment-25-7-16.sxw
    54              On the basis of this data not to provide the benefits of the Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

Act to VJNT and SBC would be harsh and violative of Art. 14. That given the extent of backwardness
of VJNT groups and the Social exclusion that they have historically faced their situation is similar to
that of the erstwhile untouchables.
55 On 28/3/2008, SLP (C) No 18534-18537/2007, SLP (C)No. 18538/2007, SLP (C)No.
18539-42/2007 were heard. The Supreme Court was pleased modify the impugned order dated
9/3/2007 to the extent that the state government may also fill the posts in respect of the 13% from
VJNT & SBC candidates subject to the final decision of the pending writ petition before the High
Court.
On 27/12/2010, The State filed additional reply stating that Art 14 is a generic Article. Art 15 and 16
are some facets of the said Art. That 2% marginal increase in the maximum percent does not affect
efficiency of administration and such marginal excess is permitted in terms by the judgment in
Indira Sawhney's case. That when the state is satisfied that certain tribes in the state, though not
listed as STs in the Presidential order are comparable in all respects to the listed Scheduled Tribes of
the State and in the adjoining States, the State dgm 77 wp-2797-15 judgment-25-7-16.sxw cannot
forsake its Constitutional duty to promote the economic interest and advancement of the weaker
sections mandated by Art 46.
It is now well settled that the fundamental right have to be interpreted in the light of the Directive
Principles of State Policy. That Art 14 permits the State to make classification even beyond the scope
of the classification visualized in Art 15 and Art 16. The law declared in State of Kerala V N M
Thomas (1976) 2 SCC 310 (7 Judges) and approved by a larger bench of 9 Judges in Indira Sawhney
makes this position very clear. That Castes and Tribes listed in the Presidential order and unlisted
castes and tribes which suffer from the same degree of social, economic and educational
backwardness cannot be treated differently only on the irrational ground that they were not listed in
the Presidential order. Such technical view would defeat the object of the Constitution. That after
analysis of available data and reports of various committees and after subjectively satisfying that
there is inadequacy of representation of SC, ST, VJNT and SBC classes it is just legal and necessary
to provide the reservation in Promotion at all stages. That if there would be no reservation there
would be almost no representation of backward classes. That it is one of the ways of achieving
economic advancement. That the opinion is dgm 78 wp-2797-15 judgment-25-7-16.sxw formed on
the basis of data. That the Supreme Court has permitted to fill the 13% seats reserved for VJNT in
promotions. That the Supreme Court has upheld the Constitutional amendments giving reservation
in Promotions. That in light of M. Nagaraj Judgment State had already filed detailed reply dated
30.3.2005 pointing out that the backwardness has been identified. That various committees have
identified backward classes and recommended sub classification.
That the State has Special Backward Class Cell in General Administration Department which looks
after the collection of Statistical data that this cell had collected the data from all departments and
then the State Government has reached conclusion and decided to provide reservation at all stages
of promotion. That the State has been treating VJNTs on Par with Sc and ST in State.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

That the State Government is of the opinion that SC, ST and VJNT & SBC continue to be backward
and they are inadequately represented and it was necessary to reserve post at all stages of
Reservation. The State has annexed the Chart Showing inadequacy of representation.
56 On 1/2/2011, The State filed their reply contending that the demand of reservations was made
way back in the year 1891 and dgm 79 wp-2797-15 judgment-25-7-16.sxw provision of reservations
were made in Maharashtra by Shahu Maharaj in 1901. That in 1942 communities was classified into
advanced, intermediate and backward classes. That during the debates of the constituent assembly
some members have stated that protection of reservations for backward classes is needed even at the
stage of promotions. That Nomadic Tribes were included in depressed classes. That the VJNT
communities are similar to that of Scheduled Tribes and they are included in the list of Scheduled
Tribes in surrounding states. That some communities like Dhangar claim to be scheduled tribes but
the State has deprived them of the status of Scheduled Tribes. That the classification and
Sub-Classification of VJNT communities is done as per the recommendations of various committee
like Thade Committee, B. G. Deshmukh Committee, Wadhwa Committee, Khatri Committee, Edate
Committee after ascertaining the backwardness, occupational disadvantages and stigma of
criminality. That as per the report of National Commission to review the working of Constitution the
continued plight of these communities is an eloquent illustration of failure of state machinery and
that special efforts need to be made for effectively enforcing reservation to achieve adequate
representation. That there is still dgm 80 wp-2797-15 judgment-25-7-16.sxw backlog of VJNT
communities. That the VJNT & SBC are equally placed with SC & ST and have also suffered similar
deprivation and disadvantages and hence the action taken by the state is in pursuance of the rights
conferred under Art 14, 16, 46 and 335 of the Constitution of India. That their backwardness and
inadequacy of representation is based on the various reports of the commissions including the state
backward class commission and on the exercise conducted by the State to ascertain adequacy of
representation considering all the cadres of the State. That on the basis of proper research and
investigations and after collection of data with material in support thereof, the backwardness, and
inadequacy of representation of VJNT & SBC is established beyond doubt. That they are not less
efficient that the general category of the SC and ST. That adequate representation to backward class
in the service under the state includes adequate representation in all cadres and considering the
cadre strength. That the adequate representation to backward class cannot be ensured without
reservations if the entire cadre is filled only by promotions and not by direct recruitment. That the
reservation in promotions is permissible if the ratio of direct recruits is not more that 50%. That
there is nothing to presume that direct dgm 81 wp-2797-15 judgment-25-7-16.sxw recruits are more
efficient and also the state too has not provided direct recruitment at all stages.
57 It is the case that all these communities namely SC, ST, VJNT, SBC are socially, educationally and
economically backward and there was inadequacy of representation at all level and cadres. It was
also evident from the past record that administrative efficiency has not suffered as after each
promotion the criteria for every person in that cadre for measuring his competency and efficiency
was the same and the administrative efficiency has not affected adversely in any manner since 1974.
The state as also relied in the Census Data. That VJNT communities are as backward as SC and St
and are treated on par with SC and ST since 1965 in all schemes. That it is not denied that these
communities are equally backward like that of SC and ST. Hence this was not challenged in anyBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

court earlier. Now this history cannot be changed hurriedly to stop such the reservation benefits
including to VJNTs. On 12/12/12,the State has filed the Sur- Rejoinder stating that the burden is on
the original Petitioner. The original petitioner has failed to discharge his burden. There is no specific
denial, with contra material to those affidavits and data placed on record by the dgm 82 wp-2797-15
judgment-25-7-16.sxw State and the affidavit of Other Backward Class/VJ/NT/SBC.
The averments against the Reservation Act 58 On 21.06.2012, Respondent nos 1 to 4 has filed an
affidavit in rejoinder to the affidavit in reply of the state dated 27.12.2010: the action of the State is
ultra vires Art 16(4)(A) of the Constitution, the separate quota for VJNT was unconstitutional and
sub classification was not based on backwardness, the representation of reserve category candidates
was much more than required, the date provided by respondent no 1 was misleading and
incomplete.
That the petitioner has no objection for providing reservation to VJNT in direct recruitment but
extending the scope of reservation for promotion by ignoring criterion laid down by the Supreme
Court and ignoring the legitimate claim of open category candidates is not correct. (para 26), the
confidential report and gradation should not be the only criteria for maintaining efficiency in
administration, the respondent has not places any report to satisfy the above test, Art 16(4)(A)
provides reservation in Promotion only for SC and ST and not for other categories, Khatri
Committee was appointed to identify various castes to be included in OBC and the committee has
solely done the job of identification of castes to be included in the OBC. The dgm 83 wp-2797-15
judgment-25-7-16.sxw committee has not ascertained the backwardness, inadequacy and overall
efficiency. There was no objection from any group so far as implementation of Art 16 (4) is
concerned but when the same is extended to promotions it leads to reverse discrimination and
affects administrative efficiency. It is stated that the words equally backward has no relevance, had
the VJNT been equally backward they would have been included in SC/ST.
The case proceedings in High Court 59 On 28 November 2014,the MAT has struck down the
Reservation Act and the Promotion Circular. The Judgment has been stayed by MAT itself for a
period of 1 year. On 13 March 2015, Writ Petition No. 2797 of 2015 filed by the State in this Court
challenging the impugned Judgment and Order. On 20 March 2015, this Court has granted interim
stay to the execution and implementation of the Judgment and order of MAT. On 13 August 2015,
Civil Application No. 2531 of 2015 filed by the Respondent to modify or vacate the interim order.
60 The parties have filed their respective Additional Affidavits and written submissions . On 29
April 2016, additional documents dgm 84 wp-2797-15 judgment-25-7-16.sxw have been tendered by
the State stating it to be the part of the original Writ Petition and the record before MAT except
Compilation part No. III, Districtwise caste census 1931. Part-I and Part-II consist of various
Commission/Expert Committee Reports/Recommendations of all the caste in question. All these
documents and materials have been placed on record by the State as to justify their reasons for
enactment of the Reservation Act and the implementation of the reservation/promotion circulars.
Both the learned counsel read and referred and made the additional submissions revolving around
the same. Various orders have been passed, from time to time, which are part of court proceedings
in record of these Writ Petitions, including of issuance of notices to all.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

13 August 2015-
"Stand over to 3.09.2015 FOB for final hearing.
2 The Registry is directed to keep all connected matters along with these matters,
whether ready or unready.
3 The Registrar (Judicial-I) is directed to call for record and proceedings of Transfer
Application Nos. 1 and 2 of 2014, in W.P. No.8452/2004 and WP/470/2005, from
Maharashtra Administrative Tribunal if not already called for. He shall ensure that
the record and proceedings reaches this Court on 26.08.2015.
     dgm                             85   wp-2797-15 judgment-25-7-16.sxw
                4     Stand   over   to   3.9.2015   First   on   Board   in   the  
                caption of Final hearing."
                3 September 2015-
"By consent, stand over to 30 September 2015 at 1.00 p. m. for final hearing along
with all other connected matters. List of connected matters be re- submitted by the
respective advocates, and specifically by the learned AGP for the State, as all other
matters are not listed by the office, inspite of earlier orders.
2 It is made clear that the notices be given accordingly and circulated to the Principal
Bench, as well as, other Benches of this Court at Nagpur, Aurangabad and Goa, about
these matters, which are relating to the Constitutional validity of the Maharashtra
State Public Services (Reservation for Scheduled Castes, Scheduled Tribes,
De-notified Tribes (Vimukta Jatis) and Nomadic Tribes, Special Backward Classes
and Other Backward Classes) Act 2001 (Maharashtra Act No. VIII of 2004), (for
short, "the Act") and connected Government Resolutions. The Registry is directed to
take steps and circulate the notices accordingly.
3 In the meantime, the parties to file their respective synopsis and circulate a
common compilation of Judgments, if any."
61 The Court heard the counsel for the parties only these matters by consent of the parties to avoid
further delay in dealing with the validity of the act, from 30 September 2015 to 4 May 2016.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

The other matters to be heard, once the decision of the impugned dgm 86 wp-2797-15
judgment-25-7-16.sxw MAT is concluded. Other individual/association challenge of the Act would
be considered on fact based writ petition, separately, after the conclusion of these matters in view of
the urgency expressed.
16 April 2016-
"1] The learned counsel appearing for the parties have concluded their respective
arguments/rejoinder in Writ Petition Nos.2797 of 2015, 3009 of 2015, 1590 of 2015
and 3287 of 2004.
2] The learned counsel appearing for the parties seek time to file revised written
submissions and connected chart.
3] At the request of the learned counsel, stand over to 29 April 2016. To be listed
under the caption "for directions"."
29 APRIL 2016-
"Mr. Yadav, the learned AGP has tendered on record
(i) the compilation of contents (ii) notes on methodology adopted for deciding the
backwardness and (iii) District-
wise Caste Census-1931. The copies of the same are provided to the concerned parties.
2 So far as the District-wise Caste Census-1931 is concerned, it is stated that though reference to the
same is made before the Maharashtra Administrative Tribunal (MAT), the State Government is
filing the relevant pages of Districtwise Caste Census 1931, for first time in this Court.
3 The Respondents are also permitted to file affidavits/counter affidavits to these documents, if so
advised. The parties to file revised written submissions, if dgm 87 wp-2797-15
judgment-25-7-16.sxw not already filed, by the next date.
4 Matters be kept on 4 May 2016 (HOB)."
4 May 2016-
"1. Arguments heard today and concluded.
2. Matters are closed for Judgment.
3. Parties to file revised submission, if not already filed and also to give it on pen
drive."Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

All the interim orders and the promotions so made are in force till this date, as being subject to final
order of these Petitions.
Specific Issues before the Tribunal.(MAT) 62 The learned Tribunal considering the rival contentions
so raised, in Paragraph 19 recorded the issues in the following terms
(i) Reservation in promotion has been challenged on two grounds.
(a) Under Article 16(4-A), no reservation in promotion can be provided to any backward class except
S.C. and S.T. The Reservation Act provides for reservation in promotion to DT/NT and SBC also,
which is in contravention of express provision of this Article.
                     (b)     Even for S.C./S.T., there is no quantifiable data 
     dgm                             88   wp-2797-15 judgment-25-7-16.sxw
available with the State to indicate that they are inadequately represented in the services under the
Government.
(ii) The Reservation Act has been challenged on the following grounds :
(a) The State does not have quantifiable data on the backwardness and adequacy of
representation in respect of any of the backward classes. The Act does not disclose
the basis on which percentage of reservation for different backward classes have been
provided. The decision of the Government is arbitrary.
(b) Though the State is empowered to provide reservation in Government service, the
law is so made as to include practically every service provided in the Private sector,
thus violating Articles 13 and 16 of the Constitution.
(c) The State does not have any data regarding impact of reservation on overall
administrative efficiency.
(d) The law should provide for Creamy Layer, even in promotion.
(e) Even though some part of the Reservation Act may not be ultra virus, but if some
other part is so found, the whole law will have to be struck down.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

(iii) The Applicants have also challenged the validity of G.R. dated 25.5.2004, which
is termed arbitrary and also dgm 89 wp-2797-15 judgment-25-7-16.sxw challenged
the concept of 'presumed merit' introduced in this G.R., which goes much beyond the
provision of Article 16(4- A) regarding consequential seniority.
Essential reasons for the conclusions of the matters 63 Keeping in mind the issues and the
provisions of law, we are proceeding, point by point, referring to the respective titles, which are
interlinked and interconnected for our final conclusion and order.
Reservations on the base of 1931 census and the natural growth of populations 64 Both the parties
have read and referred B.D. Deshmukh Committee Report 1964, Thade Committee Report 1961
Edate Committee Report 1999, the State Backward Class Commission Reports, Census Reports and
SBC Documents. The State has submitted and referred quantifiable data regarding inadequacy of
representation and overall administrative efficiency. The reservation in promotion as provided is
only 33% hence there is no violation of ceiling limit of 50%. The concept of creamy layer has been
elaborated and discussed. Based upon R.K. Sabarwal and other Judgments, 100 point Roster and its
adoption from 18 October 1997, the procedure of dgm 90 wp-2797-15 judgment-25-7-16.sxw
post-based roster to avoid excess reservation is also elaborated. The basis of percentage for
reservation of every caste in question referring to the Committee/Commission Reports, so referred
above, has been elaborated, with the supporting material placed on record.
65 It is relevant to note that on the basis of 1931 Census and, after taking into consideration the
normal rate of natural growth and increase in the population of all sorts, the Government of India
and most of the States have been adopting the "population" as the source for to give adequate,
proper and fair representation in seats or services. Therefore, apart from the constitutional
provisions, by Resolution dated 13 September 1950, the Government of India has decided to accept
the population, as the basis for fixing the percentage of the reservation in public services. In the year
1961, the population Census had taken place.
66 In the year 1971, considering the general rise in the population during the Census for the period
from 1961 to 1971, the percentage of population of each backward class category was made available
by the Social Welfare Department. As per 1971 Census, only dgm 91 wp-2797-15
judgment-25-7-16.sxw the population of SC and ST was available and not of other categories, VJNT
and OBC. The figures in respect of VJNT and OBC categories have been also collected only in 1931.
There was no such Census took place. Therefore, the State has been following the method of normal
rate of increase of total population. The basic percentage of SC and ST converts to Buddhism was
fixed 13%. ST, living outside the specified areas 7%, DTNT 4%, OBC 10%, therefore, total 33% has
been recorded.
67 The percentage of reservation in VJNT was increased to 6% in the year 1992, as per the report of
Wadhawa Commission. It was decided to increase 2% only thereby, the total reservation was
increased from 33% to 36%. This percentage was again reviewed in view of decision of Indra
Sawhney (Supra) (Mandal Commission).Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

The State, in view of the Judgment has accepted 27% reservation for OBC on the basis of 1931
Census. This basis of Census was considered and permitted even by the Supreme Court in Indra
Sawhney (Supra). It seems that the last such Caste Census has been the basis for fixing the
reservation and/or providing reservation to the Sections of the backward classes as recorded above,
throughout the dgm 92 wp-2797-15 judgment-25-7-16.sxw India and followed by the respective
States also. After 1991 general Census, the review of percentage of reservation, without crossing 50%
ceiling limit, has been followed and accordingly the percentage of reservation was fixed at 49.5% (SC
13, ST 7, VJ 3, NTB 3 NTC and NTD 4 and OBC 19.5=49.5%). The percentage of VJNT was revised to
11% from 6% in the year 1994 and accordingly fixed 50% as follows. SC 13%, ST 7%, DTVJ 3%, NTB
2.5%, NTC 3.5%, NTD 2%, OBC 19% Total 50%. ig The category of Special Backward Class/SBC was
prepared in the year 1995 and based upon their estimated population added 2%, thereby, total
percentage of reservation increased from 50 to 52%.
68 This assessment is ongoing procedure, as all the concerned Commissions and the departments
have been proceeding to regularize and fix the percentage of reservation to struck a balance between
the reserve categories and open categories in every areas. On the basis of representation and the
information so collected by the State, many communities have been added to the list of VJNT and
OBC. This was also on the recommendations of the State Backward Classes Commission. However,
the percentage of reservation of these dgm 93 wp-2797-15 judgment-25-7-16.sxw categories has not
been increased or decreased substantially.
69 In the year 2011, the Government of India has undertaken Caste Census while doing the
Socio-economic Census. However ,as stated ,it was decided not to make the public and would be
used only by the Registrar General of India for statistical purposes. The State, requested to provide
the details of the caste census for the Socio-
economic data and for fixing the backwardness and the percentage of the reservation. There are data
and material on record whereby, the basis of fixing 6% of VJNT was provided and also the data and
the percentage so fixed after 1994 covering the 19% so fixed. These includes 14 Vimukta Jati 3%,
Bhatkya Jamati (Earlier 28 Castes prior to 1990) 2.5%, Bhatkya Jamati (Dhangar etc.) 3.5% and
Bhatkya Jamati (Vanjari) 2%, 70 The Reservation Act, was based upon the Population Census of
2001. The statement is made that last general Census took place in the year 2011 after the Act. In a
given case, the Government of India and/or the respective States required to take note of the new
Census report for deciding the revised percentage, considering the dgm 94 wp-2797-15
judgment-25-7-16.sxw normal rate of increase of the population. There is no case that there is
decrease of general population of any community and caste, including of the backward classes
.These naturally grown data is the only contemporary data available for all such purposes.
The scope and power of Court in the setting up and fixing the percentage of respective caste/tribe 71
To fix or alter the percentage for giving adequate and proper representation to the backward and/or
reserved class categories/communities, is within the realm of the respective States, even when it
comes to the reservation of the other classes, than ST and SC. No decisive factor and plan are fixed
or provided or available to meddle with the fraction of reservation, so fixed by the States. It is not
the scope of the Writ Court under Article 226 of the Constitution of India to have a Judicial ReviewBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

of percentage so fixed and or providing or withdrawing the reservation to the particular class or
category. The learned counsel appearing for the parties unable to point out any Judgments whereby,
any Court has fixed and/or re-
fixed the percentage so decided by the respective States, based upon the material/information/data
they have. to give representation to a dgm 95 wp-2797-15 judgment-25-7-16.sxw particular
community/ caste and/or class.
72 We have noted and as the statement is made that the reservation policy prior to this Act has been
implemented on the foundation of various circulars issued by the State. Those circulars were
remained intact till the Statute in question. All the parties and the respective Departments and the
States and the other State Authorities, had been implementing the same. This is in no way read and
referred to mean that the respective challenges to the promotion and/or related aspects and/or even
appointments are not pending in other High Courts and/or the Courts. All such facts based matters
will be treated separately.
73 Those relevant circulars are already reproduced and referred. Normally, the scope of Judicial
Review under Article 226 is quite limited to test and verify the data, material so placed on record in
support of the reservation policy. The reason behind the percentage of the particular community or
caste, considering the other principles of "backwardness", "adequate representation" as per the
Constitution itself, is the State's domain. It is impermissible to direct any one to dgm 96 wp-2797-15
judgment-25-7-16.sxw collect the data to restructure the reservation policy. The learned Senior
Counsel appearing for the State reiterated their submission, by placing the additional documents on
record which are stated to be the part of the record of the MAT. Those records were seen and noted
as offered for the learned Members to check and/or verify. We have permitted the State to bring
their supporting data on record available with the State at the time of passing of the Reservation Act
or otherwise. We have gone through the same in detail.
74 The District-wise Caste Census of 1931 submitted on behalf of the State for in the High Court.
District-wise Caste Census of 1931 was referred by the Supreme Court in Indra Sawhney's and M.
Nagaraj (supra) and all other Judgments. Whenever there was a question of reservation figures and
data, the last caste Census of 1931 was also noted. The submission and reference is always made to
1931 Census, followed by the of every decade population Census; 1961, 1971, 1991, and 2001. The
point is no latest census available for any State Government to follow or proceed afresh. All have to
wait for new census and it's reports. Thus the natural growing data is the available" contemporary
and quantifiable data" for the purpose of such dgm 97 wp-2797-15 judgment-25-7-16.sxw
Reservation Act/Circulars.
The affirmation of the State to have quantifiable adequate data of S.C., S.T and OBC.
75 The learned Tribunal noted the principles of Nagraj that State is required to collect the
quantifiable data showing backwardness and inadequacy of representation read with compliance of
Article 335 which requires the maintenance of efficiency of administration. The Tribunal has
proceeded to consider the requirement of inadequacy of representation in service even of S.C. andBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

S.T.in the state. The affidavits and material so placed on record, wrongly interpreted to say that
there is no "contemporary and quantifiable data". The Constitution itself provides and gives
enabling power to State to deal with the promotion even for other backward classes apart from S.C.
and S.T. in various posts, subject to Nagraj elements. The validity and/or vires, therefore, cannot be
and ought not to have been decided on presumption and assumption.
76 In view of proviso to Article 335, Section 10(3) of the Reservation Act regarding concession and
relaxation in fee and/or upper age could be considered at appropriate stage as is provide dgm 98
wp-2797-15 judgment-25-7-16.sxw various concession for promotion also. This is because the basis
provisions are applicable only for S.C. and S.T. class. These "concessions and/or relaxations" are
applicable to S.C. and S.T. and not to other classes also required to be considered keeping in mind
the Constitutional provision which empowers the State to grant reservation at recruitment and/or at
promotional stage on the foundation of their backwardness and/or inadequate representation.
State Committees, Commissions reports about "quantifiable data " and Its Merit and Demerit 77 In
paragraph 29, the learned Tribunal though recorded the gist of Committee Reports (B.D.Deshmukh,
Thade, Wadhwa, B.R. Committee and State Backward Class Commission - Khatri
Commisssion,Bapat Commission),wrongly held that the reports nowhere shows figures about the
representation of the communities for inclusion in the list of V.G., N.T. O.B.C. in State Service. This
is by observing further that there is total absence of any quantifiable data in these reports. It is
concluded wrongly that except the B.D.Deshmukh Committee Report, there is hardly any
quantifiable data about representation in Government Service of various backward communities.
The Tribunal has also observed that S.C. are given more dgm 99 wp-2797-15 judgment-25-7-16.sxw
reservations, while S.T. are given less reservations based upon the percentage of the population. The
learned Tribunal noted that there was no explanation for this anomaly. It is wrongly observed that
the figures are based on extrapolation and are not actual figures. It is observed further that the
reservation for S.C. and S.T. more or less is in proportion to their population. However, figures in
D.T. and N.T. are only guesstimates. The learned Tribunal not noted the Deshmukh Committee
Report of the year 1961. The learned Tribunal refused to accept the submission based upon 50 years
old D.B. Deshmukh Committee Report. These observations of learned Tribunal are wrong by
misreading the Constitutional provisions and the Judgments. The Reservation Act itself provides
that "Government may by an order in the Official Gazette provides that percentage of reservation for
S.C. and S.T., D.T., N.T., S.B.C. category and other backward classes, in all posts, shall be on the
basis of the latest census record of population of the State, in the case of State cadre posts, and
concerned District, in case of District cadre posts." Apart from this enabling constitutional provision
empowers the State to provide reservation of posts for various categories in proportion to their
population as per the latest census report. The material has been placed on record even of dgm 100
wp-2797-15 judgment-25-7-16.sxw subsequent years as recorded in paragraph 29. The excessive
reservation in employment, therefore, needs to be decided on the facts of the case of individual or
association and/or respective department's submission .
78 The Judgment of Balaji (supra) cannot be read in isolation. The principle so laid down is also
stated even about the marginal 2% excess of reservation in the present case. There are various States
where reservation is more than 50 per cent. The only requirement is, as per even Nagraj (supra),Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

State has to form its opinion on the foundation of "quantifiable data" and "adequacy of
representation of Backward class". In the same Judgment it is observed that any excessiveness
needs to be decided on the facts of each case.
79 The learned Tribunal, however, wrong in concluding that the State has no quantifiable and
contemporary data about backward classes in the State. It was more than 50 years old. Further
observation that the State has provided reservation for S.C. and S.T., D.T. and N.T. categories in
proportion to their population. However, dgm 101 wp-2797-15 judgment-25-7-16.sxw for the
creditable data of population of D.T./N.T. i.e. VJ(A), N.T.(B), N.T.(C) and N.T.(D) categories are
recorded that the reservation to them was in the population proportion as per the declared Section 4
of the Reservation Act.
Reference is made to the Cabinet Note dated 30/11/1994 about the caste 80 The reference is made
to the Cabinet Note dated 30/11/1994, whereby provision is made to provide employment for five
communities Gowari, Manna, Halba Koshti, Machhimar Koli, Soan Koli and Munnarwar. The State,
therefore, decided in the Cabinet to create a separate category and provide 2% reservation for them.
No challenge was raised at any point of time so far as circular and the order dated 30/11/1994. All
have been acted upon the same since then. Having so noted and decided to give representation to
said communities to say that there is no material to support the claim of S.B.C. to entitle them
reservation in public employment is wrong approach. The data so reflected earlier, cannot be tested
at this stage, at the instance of petitioner on vague averments or pleading.
    The   data   is   recorded   and   provided   for   this   category   also         and 
     dgm                             102 wp-2797-15 judgment-25-7-16.sxw
strikingly, the learned Tribunal not even dealt with the circular so issued from time to time by the
State announcing the criteria for backward class or category from time to time by following the due
procedure of law and through the State scheduled provisions and the Circulars. All State provisions
are intact till today. All the concerned have been acting upon the same. No challenge raised at any
time earlier. Therefore, merely because the State has decided to utilise those earlier provisions and
the circulars, through the Reservation Act, pursuant to the Supreme Court decision, the challenge
even after Nagraj (supra), cannot be the basis to declare the Reservation Act ultra vires, on such
assumption and presumption.
Specific Treatment to Other Backward Class - VJ/NT 81 It has been noted that the Petitioners
challenge to the validity of Article 16(4A) and (4B) of the Constitution is decided in Nagraj (supra).
The challenge was raised at the same time to the Reservation Act and Circular regarding promotionBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

in question. Once the constitutional challenge goes, that itself dilutes the Petitioners' challenge to
the vires of the Reservation Act. Every important aspect of reservation to SC, ST from the stage of
recruitment and/or promotion have been concluded against the Petitioners and in support dgm 103
wp-2797-15 judgment-25-7-16.sxw of all other categories also. No specific challenge was able to
sustain about the reservation provided at the recruitment stage and/or the promotional stage in
view of the amended constitutional provision so referred above. This itself endorsed the earlier
practice and procedure of collecting the data and the material available with the Central/State in
this regard. All the reasons given by the learned Tribunal, with regard to the material, data,
adequate representation, backwardness, based upon 50 years old data, are nothing but infringing
upon the basic constitutional provision and the judgments of Supreme Court including Indra
Sawhney, Nagraj and others.
There was no question of declaring the Reservation Act ultra vires on the wrong ground of no data,
no material, and/or 50 years old data inspite of fulfillment of the principles in Nagraj and other
subsequent judgments by the state. All the original Petitions should have been dismissed on these
grounds itself. The wrong understanding of law and/or interpretation of Supreme Court judgments
resulted into unjust and contrary declaration in question. This would definitely result into
miscarriage of justice and takes away the constitutional rights of the persons, who belong to
scheduled categories and/or groups The promotional circular providing 33% reservation, as dgm
104 wp-2797-15 judgment-25-7-16.sxw stated to be the provision to modify and/or a clarificatory in
nature, based upon the existing promotional policy for Scheduled Caste and Scheduled Tribe and for
OBC, therefore could not have been declared bad in law in such fashion for the same reasons itself.
The State Quantifiable Data and updated contemporary data, though not precise but sufficient is
available 82 The State has placed a comparative data of Social, educational and economic
backwardness of Maharashtra State, SC/ST, VJNT and SBC as per the Census Report of 2001 and
the Maharashtra State VJNT Study and Research Committee and/or Edate Committee Report of
1999. The chart of that data has submitted by the State.
We are reproducing it :
COMPARATIVE DATA OF SOCIAL, EDUCATIONAL AND ECONOMIC
BACKWARDNESS OF MAHARASHTRA STATE Supreme Court, ST, VJNT AND SBC
AS PER THE CENSUS REPORT OF 2001 AND MAHARASHTRA STATE VJNT
STUDY AND RESEARCH COMMITTEE OR THE EDATE COMMITTEE REPORT
1999 Social Econ InaEdu cati omic deq on uac Hou Wat Electri No TV Liter Avg Popu
se er city Latri set acy inco latio per Tap ne me/A n % dgm 105 wp-2797-15
judgment-25-7-16.sxw mit n al 82 02 2 .1 Stat Urb 81. 89. 94.28 41.9 70 85.5 57.5 Rur
40. 45. 65.17 81.7 24 70.4 42.4 Tot 51. 62. 70.44 71.6 37 71.9 10.2 al 35 65 5 .7 SC Urb
71. 85. 89.56 56.1 63 78.3 61.6 Rur 36. 46. 56.93 82.6 19 67.9 38.3 Tot 34. 45. 52.15
79.7 22 55.2 8.85 al 89 24 6 .5 ST Urb 70. 84. 87.76 53.5 59 74.2 12.7 Rur 23. 32.
40.60 88.2 10 52.3 87.2 Tot 13. 18. 48.6 61.9 13 1824 101 ~2.
              al       2        8                        .4          0           3        66
    VJA       Urb      16.      22.       62.5    36.2   22          2140                 45.2Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

              Rur      10.      15.       37.1    83.1   6.          1562                 54.7
        Tot 13.                 19.       51.7    59.8   13          1777        131      ~1.7
        al  0                   1                        .8          7           0        5
    NTB Urb 13.                 20.       60.3    46.1   16          1992                 56.7
     dgm                             106 wp-2797-15 judgment-25-7-16.sxw
             Rur 12.           17.       40.4   77.8    10          1495                 43.2
        Tot           11.      13.       45.5   79.2    8. 23.7 1407            169      ~3.0
        al            4        7                        6       6               22       0
    NTC Urb           17.      15.       60.0   60.0    17 41.5 1058                     15.6
        Rur           10.      13.       42.8   82.8    7. 20.4 1472                     84.3
        Tot           15.      9.1       51.2   86.8    14 41.9 1899            647      ~1.0
        al            7                                 .0      8               9        0
    NTD Urb           100      100 100          1       10 91.7 7542                     3.30Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

        an                          ig                  0       5
        Rur           12.      6.0       49.6   89.7    11 40.0 1706                     96.6
        Tot
        al 
    NTC Urb
        an 
        Rur
        al
As on 30.6.2005 the Backlog/inadequacy of VJNT in direct recruitment and
promotion at various stages was as follows :-
           Category                  Direct             +     Promotion  =
           Inadequacy
            VJA                      840            +   173      =             1,013
           NTB                       993            +   317      =             1,310
           NTC                       13580              +   3342               =
                16,922
           NTD                       5800               +     679              =        6,479
           Total                                                               25,724
     dgm                             107 wp-2797-15 judgment-25-7-16.sxw
Total Backlog/inadequacy of Backward class in direct recruitment and promotions at
various stages was as follows:Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

                    Group                           Backlog
                    A                         4,713
                    B                         4,250
                    C                         51,781
                    D                         18,975
                    Total                     79,719
Scheduled Caste statutes upto date till 31 March 2006, VJNT status upto date till 31
March 2006, including addition of new caste in June 2008 are part of the record of
Writ Petitions. A Central list of OBC (the State of Maharashtra), is also placed on
record, as extracted from the concerned website. Government Resolution dated 25
May 2006 is also part of the record (the State compilations) as submitted even before
the MAT whereby, certain new De-notified Tribes (Vimukta Jatis), Nomadic Tribes,
Special Backward Category and other Backward Classes have been added (SC/ST
order amended 1976, Appendix I part 10 (13%)).
84 The process of collection of data by the State and/or by the Central, normally is for
all the castes/groups/categories, in dgm 108 wp-2797-15 judgment-25-7-16.sxw
question. Every Census so read and referred, covers all these categories, apart from
Central, the Committees/Commission Reports as recorded. It is difficult to dissect
any of these categories as in existence since long - neither intended nor submitted by
the opponent to do so. Having noted even the respective data of concerned
castes/tribes, as recorded, referring to all the committee reports, cover the SC/ST and
OBC also. The data, so used and utilized for all these categories, covers the issues for
the purpose of these challenges.
The percentage for reservation for appointment at the stage of recruitment, or even for promotions
are intact for all these purposes.
The MAT misread historical value of the reservation and the base for such reservation.
85 It is necessary to note that Article 16 (4A) and (4B) have been introduced keeping in mind the
directions given by the Apex Court in Indira Sawhnay's case (supra). Articles 341 and 342 of the
Constitution of India permit the Authority to declare a community as Scheduled Caste or Scheduled
Tribe. This is in the background of the Constitutional (Scheduled Castes) Order, 1950 andBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

Constitutional (Scheduled Tribes) Order, 1950. The learned Members of the Tribunal failed to take
note of the background and the declared policy dgm 109 wp-2797-15 judgment-25-7-16.sxw of the
Bombay State which was in existence prior to above orders.
One of such example is Government Resolution, Political and Services Department dated
23.04.1942. After the constitution of the Bombay State, backward classes were divided into three
categories, Scheduled Caste, Scheduled Tribe and Other Backward Classes which were castes
deemed to be as backward as the Scheduled Caste or the Scheduled Tribe. The reservation in
Government posts were provided to such classes also by Resolution dated 1.11.1950 as per the
prescribed percentage. The learned Tribunal, even not noted the earlier existing Bombay Primary
Education Rules, 1924, whereby the classification of communities as backward and depressed
classes/Tribes had been recognised. In the year 1928 a Committee was set up for such inquiry into
the educational, economic and social conditions of the depressed classes. The recommendations
were accepted and the list of backward class communities were prescribed even under Government
Resolution of 29.05.1933 - which was subsequently revised in 1942. The reservation in Government
posts was prescribed in Government Resolution of 1.11.1950 which was revised again on 24.01.1953.
The modified Scheduled Castes and Scheduled Tribes List (Modification) Order, 1956 throws further
light on the issue. Ultimately by dgm 110 wp-2797-15 judgment-25-7-16.sxw Resolution dated
18.05.1959 major concessions were made available to the OBC category. There was Criminal Tribes
Act, 1871 which was replaced by Criminal Tribes Act, 1924 covering large sections of Nomadic
Tribes. Though the Criminal Tribes Act was repealed in 1952, this group remained unattended. (See
State affidavits).
86 The learned Tribunal failed to consider the background of formation of these
Commissions/Committees and the earlier Government Resolutions, Reservation Policy and the
law/Statute.
The learned Tribunal, however, completely overlooked the main foundation and by misreading the
Nagraj has even disturbed and interfered the percentage at the recruitment as well as promotion
stage so accepted and recognised for the SC, ST classes by the Supreme Court. The learned Tribunal
wrongly interpreted the reservation provided for OBCs by the State being empowered to do so, on
the foundation of lack of data and the material. They have fixed the percentage also. The same has
remained intact. All have been acting accordingly.
    87              We  have  to observed that after Indira Sawhney (supra), 
     dgm                             111 wp-2797-15 judgment-25-7-16.sxwBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

based upon the report of the Mandal Commission, the issue of reservation quotas for the backward
classes in direct recruitment was reconsidered even by the State and decided to increase total
reservation from 33% which was fixed in the year 1965 to 50% by Government Resolution dated
23.03.1994. We have noted that the State had, as per the requirement, need, representation, survey
reports and/or commission reports and/or based upon the information collected and available with
them, not only added but even withdrew the reservation from promotion of VJ, NT., however,
protected their promotion in view of Supreme Court directives for 5 years from 16.11.1992.
88 For the present purpose, we are inclined to observe at this stage itself that in view of Indira
Sawhney (supra), the State had constituted a Standing Committee consists of Experts under the
Chairmanship of Dr. Mutkar on 15.03.1993 and later-on converted into State Backward Class
Commission on 19.05.1995 under the Chairmanship of Justice S. N. Khatri. About 156 caste claims
including OBCS/VJ/NT had been dealt with. The Committee, noting the provisions of Article 16(4)
and the judgments and the observation dgm 112 wp-2797-15 judgment-25-7-16.sxw in Indira
Sawhney (supra) proceeded to inquire and decide the caste claims. The recommendations
accordingly submitted as noted. We are inclined to observe here that there is no prescribed
procedure or method provided under the Constitution and/or under the law for identification of
backward classes. Therefore, ultimately it is the State and/or the concerned Authority, in view of
enabling constitutional provisions, but subject to other provisions of Constitution and the law
required to take steps to determine backwardness and for providing due representation, as
contemplated under Article 16(4). This includes available group, section and classes in society. This
is also by keeping in mind the social, educational, economy and other essential conditions as laid
down in Mandal Commission. The details so provided in this committee reports/commission
reports, the then existing Acts, Statutes, Circulars, Reservation Policies and the percentage so fixed
which now incorporated in the Act ought not to have been disturbed in such fashion at the instance
of Petitioners, based upon the vague pleadings on merit, but general submissions on presumption
and assumption.
    89              We are of the view that the subjective satisfaction of the 
     dgm                             113 wp-2797-15 judgment-25-7-16.sxw
Government is also a prime consideration for implementing such reservation policy, but in
accordance with the law. Therefore, the State, having once treated and noted that these
communities, groups, other than SC/ST, are also required representation and/or benefits being
similarly placed, may not be on strict senses, but within elements of Article 16(4) are satisfied, isBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

empowered to grant the particular percentage and the benefits of reservation to all such categories.
We see there is no illegality in such extension. Therefore, in view of provision of Articles 14, 15 and
16, such express legislation is permissible. There is nothing wrong if the said benefit is continued by
the State based upon the earlier statutes and the Circulars. The reservations already made based
upon the earlier Circulars and the reservation policy even protected in Indira Sawhney's case, at
least for further five years from the date of judgment. The State has to take decision to grant
extension in such reservation. The earlier reservation policy, therefore, ought not to have been
disturbed. All the parties were aware of it. The promotion is always based upon the service
conditions and the State policy , if governed by the same.
The reservation policy is always subject to correction. Therefore, the impugned judgment on this
ground itself of declaring the whole Act dgm 114 wp-2797-15 judgment-25-7-16.sxw ultravires on
such vague pleading and on the basis of assumption and presumption is unsustainable.
90 The decision, based upon the vague pleading of the complainant who are not governed by the
Administrative Tribunal Act, is also impermissible. Any case which is not within the ambit of the
MAT jurisdiction though challenge has been raised to the vires of the Reservation Act and the
Circular, that itself should not have been the reason to declare the Reservation Act and the
Promotion Circular ultra vires. The learned Tribunal could have passed the appropriate order if the
case was not governed by the Administrative Tribunal Act and/or not within the jurisdiction of the
learned Tribunal. (Transfer Application No.2/2014 = Writ petition No.470/2005 - M. V. Gunale).
Enthusiasm of increase and /or decrease of respective reservation percentage 91 The fixed
percentage of granting benefits/concession needs to be respected by all the concerned. Therefore,
unless those percentage are increased and/or lowered by the Central and/or State Government, in
accordance with law, all are bound to grant constitutional benefits to the scheduled community and
castes, for all dgm 115 wp-2797-15 judgment-25-7-16.sxw the purposes and also in public
employment. And if it is in excess, it is required to be tested individual caste or community wise .
Any increase or decrease in percentage in any class or category would affect the command of within
or beyond 50% reservation, though certain degree of excess, in a given case, is permissible. The
State, therefore, if quantifiable material available, want to add and/or grant such concession/benefit
to certain other new categories, the State required to reassess the percentage aspects within the
umbrella of "quantitative limit" so referred above. There is no issue that the State required to keep
in mind the constitutional provision including the merits of the general citizen/categories.
92 This is also in the background that once the class or tribe and community is included in
Presidential List (Central and/or State), even any further division of any classes would be a matter
of confront, as it amounts to playing with the Presidential List published - so would be the case, if
the fixed percentage is tinkered with. Any addition in the class of community and/or increase or
decrease and/or addition and/or deletion of it in the list, required due process to be followed by the
State. The Reservation Act and the Circular, dgm 116 wp-2797-15 judgment-25-7-16.sxw therefore,
in our view, is well within the umbrella of law and the record. Any contra decision of the State would
have cause great injustice and hardship to all the concerned. The constitutional protection and
umbrella to the persons being in the list, therefore, ought not to have been disturbed, as done in theBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

present case in spite of there being no competing material on record.
No special challenge to the inclusion and exclusion in State Caste/Tribe Lists.
93 So far as State of Maharashtra is concerned, there is a list of Special Backward Category (SBC),
which is amended and modified from time to time. There is a list of De-notified Tribes (Vimukta
Jati) amended and modified from time to time. There is list of Nomadic Tribes also. Above
observations are applicable to these lists of S.B.C, DT/VJ/NT.
94 The caste and community list, Central or State, covering all the categories in question for which
reservation under the Act and Circular as provided, have never been challenged and or tested by the
original petitioners even on the stated formula of Nagraj. There is dgm 117 wp-2797-15
judgment-25-7-16.sxw no specific challenge raised even in this petition to the inclusion of those
entries in the respective constitutionally recognized lists. The central and respective States, keeping
in mind the Supreme Court Judgments, have been collecting the data, information even prior to
inclusion and/or exclusion of the entries in the list, before granting the constitutional
benefits/protection. Having once recognized particular community and included their names into
the castes in the list, based upon the data and material available, and for want of any contra material
from the other side or otherwise, the respective State is empowered to grant the benefits in
accordance with law. The State has, therefore, taken the impugned decision. The detailed individual
challenges on merits, if any, would be considered and/or required to be considered if the affected
petitioners are able to place the sustaining material to affect their actual promotion, departmental
and/or otherwise. There was no such case apart from no pleading or material to sustain the same.
The State is empowered to make reservation in State employment- recruitment and/or promotion.
Mandamus to order Reservation OR De reservation ?
    95              The Apex  Court in various judgments has reinforced that 
     dgm                             118 wp-2797-15 judgment-25-7-16.sxw
no mandamus would lie to order reservation and/or de reservation and/or to collect data/material
for the same. The extract of those paragraphs of respective judgments are as under :
1) Chairman and Managing Director,Central Bank of India vs. Central Bank of India
SC/ST Employees Welfare Association (2015) 1 SCALE 169 :Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

"24. In the first instance, we make it clear that there is no dispute about the
constitutional position envisaged in Articles and , insofar as these provisions
empower the State to take affirmative action in favour of SC/ST category persons by
making reservations for them in the employment in the Union or the State (or for
that matter, public sector/authorities which are treated as State Under Article 12 of
the Constitution) .
Insofar as making of provisions for reservation in matters of promotion to any class
or classes of post is concerned, such a provision can be made in favour of SC/ST
category employees if, in the opinion of the State, they are not adequately
represented in services under the State. Thus, no doubt, power lies with the State to
make a provision, but, at the same time, courts cannot issue any mandamus to the
State to necessarily make such a provision. It is for the State to act, in dgm 119
wp-2797-15 judgment-25-7-16.sxw a given situation, and to take such an affirmative
action. of course, whenever there exists such a provision for reservation in the
matters of recruitment or the promotion, it would bestow an enforceable right in
favour of persons belonging to SC/ST category and on failure on the part of any
authority to reserve the posts, while making selections/promotions, the beneficiaries
of these provisions can approach the Court to get their rights enforced. What is to be
highlighted is that existence of provision for reservation in the matter of selection or
promotion, as the case may be, is the sine qua non for seeking mandamus as it is only
when such a provision is made by the State, a right shall accrue in favour of SC/ST
candidates and not otherwise." (emphasis added) The judgments cited by the parties
in present case have been noted in this judgment.
96 It is relevant to note here that Supreme Court in Suresh Chand Gautam v. State of Uttar Pradesh
and ors.,23, after dealing with Articles 16(4A) and (4B) and 226 and all other judgments including
the basic elements of Nagraj has observed as follows :
23 AIR 2016 (Supreme Court) 1321 dgm 120 wp-2797-15 judgment-25-7-16.sxw "43
They are in different sphere than what is envisaged in Article 16(4-A) and 16(4-B)
whose constitutional validity have been upheld by the Constitution Bench with
certain qualifiers. They have been regarded as enabling constitutional provisions.
Additionally it has been postulated that the State is not bound to make reservation for Scheduled
Castes and Scheduled Tribes in matter of promotions. Therefore, there is no duty. In such a
situation, to issue a mandamus to collect the data would tantamount to asking the authorities
whether there is ample data to frame a rule or Regulation. This will be in a way, entering into the
domain of legislation, for it is a step towards commanding to frame a legislation or a delegated
legislation for reservation.
44 Recently in Census Commissioner and Ors. v.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

R. Krishnamurthy, (2015) 2 SCC 796 a three-Judge Bench while dealing with the correctness of the
judgment of the high court wherein the High court had directed that the Census Department of
Government of India shall take such measures towards conducting the caste-wise census in the
country at the earliest and in a time-bound manner, so as to achieve the goal of social justice in its
true sense, which is the need of the hour, the court analyzing the context opined thus:
".....It is not within the domain of the court to legislate. The courts do interpret the
law and in such interpretation certain creative process is involved. The courts have
the jurisdiction to declare the law as unconstitutional. That too, where it is called for.
The court may also fill up the gaps in certain spheres applying the doctrine of
constitutional silence or abeyance. But, the courts are not to plunge into
policymaking by adding something to the policy by ways of issuing a writ of
mandamus."
We have referred to the said authority as the court has dgm 121 wp-2797-15 judgment-25-7-16.sxw
clearly held that it neither legislates nor does it issue a mandamus to legislate. The relief in the
present case, when appositely appreciated, tantamounts to a prayer for issue of a mandamus to take
a step towards framing of a rule or a Regulation for the purpose of reservation for Scheduled Castes
and Scheduled Tribes in matter of promotions. In our considered opinion a writ of mandamus of
such a nature cannot be issued."
The basis of State's collecting information and data and the reservation policy decision, in question,
based upon the available data, ought to have been respected. No Court, in view of above judgments,
including Suresh Chand (supra), could not have issued directions to collect the data. The State, on
the contrary, to provide the promotion, to SC and ST and other backward classes, based upon the
last caste census and the "population census" read with caste/categories, included in the Central, as
well as, the State List to achieve the constitutional goal and has proceeded to use and utilise the
quantifiable data available with them, in our view, is well within the law and the record. The
beneficiaries are entitled to claim it. The declaration of the tribunal affects the rights of these
beneficiaries.
Provisions for Promotion 97 Furthermore, it is relevant to note the observations of the Apex Court
in Suresh Chand in paragraph 42 as under :
     dgm                             122 wp-2797-15 judgment-25-7-16.sxw
             "42           ............ Insofar as making of provisions for 
reservation in matters of promotion to any class or classes of post is concerned, such a provision can
be made in favour of SC/ST Civil Appeal No. of 2015 and Ors. (arising out of SLP (C) No. 4385 of
2010 and Ors.) category employees if, in the opinion of the State, they are not adequately
represented in services under the State. Thus, no doubt, power lies with the State to make a
provision, but, at the same time, courts cannot issue any mandamus to the State to necessarily make
such a provision............What is to be highlighted is that existence of provision for reservation in the
matter of selection or promotion, as the case may be, is the sine qua non for seeking mandamus as itBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

is only when such a provision is made by the State, a right shall accrue in favour of SC/ST candidates
and not otherwise."
(emphasis added) It is also noted in Suresh Chand (supra) as under :
"In Rajesh Kumar's (AIR 2012 SC 2728) case, after culling out the principles stated in
M. Nagaraj (supra) the Court has graphically stated that a fresh exercise in accord
with the law laid down in M. Nagaraj (supra) is a categorical imperative. It has been
held that the State can make provisions for reservation in promotion with
consequential seniority on certain basis or foundation and conditions precedents
have to be satisfied. ......"
The State has made the reservation considering the scheme of the constitutional provisions and the
law and so also the promotion circulars.
dgm 123 wp-2797-15 judgment-25-7-16.sxw Wisdom of State Legislation = to continue the existing
reservation policy - for both stages for all.
98 Any legislation, includes statutes and the circulars is nothing but an intention of the State. The
earlier Circulars were in force for similar benefits for all the categories. Those circulars and the
reservation policy had been incorporated under the Reservation Act.
The concerned/person belonging to these categories, therefore, are entitled for the reservation
benefits including the promotion as already provided since long The subsequent Nagraj elements,
even if any, pending the census direction in time bound programme, as recorded in Census
Commission and others (supra) or even otherwise, the State's decision to achieve the constitutional
goal, the social justice, ought not to have been disturbed and/or interfered with.
Once the fresh census, caste-wise data, available with the State as noted are available, the State is
bound to take steps to revise the reservation policy, at all levels. The reasonable and sufficient time
should have been granted.
Existing recognised Constitutional Reservation for SC/ST at the recruitment level and or at
promotional level is settled.
99 Even during the course of arguments, there was no much argument made so far as of these
reservations of SC and ST of both dgm 124 wp-2797-15 judgment-25-7-16.sxw the levels,
recruitment, as well as, promotion. There was, even no issue discussed and/or decided and the
percentage so fixed and prescribed by the Central and the State for so many years. We have noted
that since the inception and/or grant of such percentage, irrespective increase of population, no
such percentage is lowered and/or increased. There is no challenge and/or issue raised with regard
to the extension from time to time as per Article 335. In view of this clear provisions of
constitutional rights and protection granted to SC and ST class or group and/or related group,
cannot be thrown away by declaring the Reservation Act unconstitutional. The effect is, theBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

Reservation Act as declared ultra virus the reservation circulars which were in existence prior to the
Reservation Act, are also not in the field now. There is no provisions pointed out whereby, those
earlier circulars can be stated to be revived. The percentage so fixed, even in the circulars for the
classes of SC and ST, were never challenged and/or were in the field since long. The Supreme Court
Judgment in M. Nagaraj (supra), basically revolved around the issue and/or providing reservation
and promotion for other backward classes. It is settled that if the case of "perversity",
"non-application of mind" and "illegal reasons" are made out, Article 226 of the dgm 125
wp-2797-15 judgment-25-7-16.sxw Constitution of India, needs to be invoked in the interest of
justice.
Last Caste Census 1931 and natural growth binds all until new similar Caste Census is published and
made effective for all the communities.
100 Admittedly, no Census has been undertaken after 1931 to determine the population of
Denotified Tribes (A) (DNT), Nomadic Tribes (B) (NT-B), Nomadic Tribes (C) (NT-C), Nomadic
Tribes (D) (NT-D), Special Backward Category (SBC) and Other Backward Classes (OBC) in the
State. The State came to be constituted in the year 1960, by including parts of Bombay Presidency,
Central Province and Berar and the State of Hyderabad, which existed during the British time. In
the year 1931, the State was not in existence. The Supreme Court, has, in no case, declared that all
the laws of reservation policy and/or circulars based upon 1931 Census, are bad and/or ultra virus to
the Constitution. It is to be noted that even, in Indra Sawhney and M. Nagaraj (supra), though the
Constitutional Bench declare the provisions ultra virus, in the year 1992, but still granted the
continuation of those protections for further 5 years.
There was no direction issued, even in those matters to collect the data and/or information to
determine the population of respective dgm 126 wp-2797-15 judgment-25-7-16.sxw group or class to
provide the reservation. The directions to update and to collect the information and to proceed to
make the concerned reservation and/or determine the population based reservation and/or to
provide adequate representation to other backward classes, are different facets altogether.
No prescribed method to identify Backward Class - Other Backward Class.
101 Even in Indra Sawhney (supra) (Mandal's Case), the Supreme Court has summarized answers to
the questions in paragraph
860. Some of the answers are-
"(2) The expression 'backward class' in Article 16(4) takes in 'Other Backward
Classes', SCs, STs and may be some other backward classes as well. The accent in
Article 16(4) is upon social backwardness. Social backwardness leads to educational
backwardness and economic backwardness. They are mutually contributory to each
other and are intertwined with low occupations in the Indian society. A caste can be
and quite often is a social class in India. Economic criterion cannot be the sole basis
for determining the backward class of citizens contemplated by Article 16(4). TheBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

weaker sections referred to Article 46 do include SBCs referred to in Article 340 and
covered by Article 16(4)."
"(4) ......
For applying this rule, the reservations should not exceed 50% of the appointments in a grade, cadre
or service in any given year. Reservation can be made in a service or category only when the State is
satisfied that representation of backward class of citizens therein is not adequate."
     dgm                             127 wp-2797-15 judgment-25-7-16.sxw
          (5)           There   is   no   constitutional   bar   to   classification   of  
backward classes into more backward and backward classes for the purposes of Article 16(4). The
distinction should be on the basis of degrees of social backwardness. In case of such classification,
however, it would be advisable - nay, necessary - to ensure equitable distribution amongst the
various backward classes to avoid lumping so that one or two such classes do not eat away the entire
quota leaving the other backward classes high and dry.
For excluding 'creamy layer', an economic criterion can be adopted as an indicium or measure of
social advancement."
(6) A 'provision' under Article 16(4) can be made by an executive order. It is not necessary that it
should be made by Parliament/Legislature.
(7) No special standard of judicial scrutiny can be predicated in matters arising under Article 16 (4).
It is not possible or necessary to say more than this under this question.
(8) Reservation of appointments or posts under Article 16(4) is confined to initial appointment only
and cannot extend to providing reservation in the matter of promotion. We direct that our decision
on this question shall operate only prospectively and shall not affect promotions already made,
whether on temporary, officiating or regular/permanent basis. It is further directed that wherever
reservations are already provided in the matter of promotion - be it Central Services or State
Services, or for that matter services under any Corporation, authority or body falling under the
definition of 'State' in Article 12 - such reservations may continue in operation for a period of five
years from this day. Within this period, it would be open to the appropriate authorities to revise,
modify or re-issue the relevant rules to ensure the achievement of the objective of Article 16(4). If
any authority thinks that for ensuring adequate representation of 'backward class of citizens' in any
service, class or category, it dgm 128 wp-2797-15 judgment-25-7-16.sxw is necessary to provide for
direct recruitment therein, it shall be open to it to do so." (emphasis added) 102 It is specifically
observed in paragraph Nos. 796 and 797, to answer No.3 (a) is as under:-
"796-797. We may now summarise our discussion under Question No. 3. (a) A caste
can be and quite often is a social class in India. If it is backward socially, it would be a
backward class for the purposes of Article 16(4). Among non-Hindus, there areBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

several occupational groups, sects and denominations, which for historical reasons
are socially backward. They too represent backward social collectivities for the
purposes of Article 16(4). (b) Neither the constitution nor the law prescribe the
procedure or method of identification of backward classes. Nor is it possible or
advisable for the court to lay down any such procedure or method. It must be left to
the authority appointed to identify. It can adopt such method/procedure as it thinks
convenient and so long as its survey covers the entire populace, no objection can be
taken to it. If it does --
what emerges is a "backward class of citizens" within the meaning of and for the
purposes of Article 16(4). Similar process can be adopted in the case of other
occupational groups, communities and classes, so as to cover the entire populace. The
central idea and overall objective should be to consider all available groups, sections
and classes in society. Since caste represents an existing, identifiable social
group/class encompassing an overwhelming majority of the country's population,
one can well begin with it and then go to other groups, sections and classes. (c) It is
not necessary for a class to be designated as a backward class that it is situated
similarly to the Scheduled Castes/Scheduled Tribes. (d) 'Creamy layer' can be, and
must be, excluded. (e) It is not correct to say that the backward class contemplated by
Article 16(4) is limited to the socially and educationally backward classes referred to
dgm 129 wp-2797-15 judgment-25-7-16.sxw in Article 15(4) and Article 340. It is
much wider. The test or requirement of social and educational backwardness cannot
be applied to Scheduled Castes and Scheduled Tribes, who indubitably fall within the
expression "backward class of citizens". The accent in Article 16(4) appears to be on
social backwardness. Of course, social, educational and economic backwardness are
closely intertwined in the Indian context. The classes contemplated by Article 16(4)
may be wider than those contemplated by Article 15(4). (emphasis added)
(f) Adequacy of Representation in the Services under the State (emphasis added)
798. ---. This opinion can be formed by the State on its own, i.e., on the basis of the
material it has in its possession already or it may gather such material through a
Commission/Committee, person or authority. All that is required is, there must be
some material upon which the opinion is formed. Indeed, in this matter the court
should show due deference to the opinion of the State, which in the present context
means the executive. The executive is supposed to know the existing conditions in the
society, drawn as it is from among the representatives of the people in
Parliament/Legislature. It does not, however, mean that the opinion formed is
beyond judicial scrutiny altogether.
The scope and reach of judicial scrutiny in matters within subjective satisfaction of the executive are
well and extensively stated in Barium Chemicals v. Company Law Board which need not be repeated
here. Suffice it to mention that the said principles apply equally in the case of a constitutional
provision like Article 16(4) which expressly places the particular fact (inadequate representation)Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

within the subjective judgment of the State/executive."
There is no bar to provide reservation to Other Backward Class even as per above observation. It is
permissible subject to data.
     dgm                             130 wp-2797-15 judgment-25-7-16.sxw
                                         Quantitative limit 50% 
"810. While 50% shall be the rule, it is necessary not to put out of consideration certain
extraordinary situations inherent in the great diversity of this country and the people. It might
happen that in far flung and remote areas the population inhabiting those areas might, on account
of their being out of the mainstream of national life and in view of conditions peculiar to and
characteristically to them, need to be treated in a different way, some relaxation in this strict rule
may become imperative. In doing so, extreme caution is to be exercised and a special case made
out."
"860(4).
The reservations contemplated in clause (4) of Article 16 should not exceed 50%.
While 50% shall be the rule, it is necessary not to put out of consideration certain
extraordinary situations inherent in the great diversity of this country and the people.
It might happen that in far- flung and remote areas the population inhabiting those
areas might, on account of their being out of the mainstream of national life and in
view of the conditions peculiar to and characteristic of them need to be treated in a
different way, some relaxation in this strict rule may become imperative. In doing so,
extreme caution is to be exercised and a special case made out.
For applying this rule, the reservations should not exceed 50% of the appointments in
a grade, cadre or service in any given year. Reservation can be made in a service or
category only when the State is satisfied that representation of backward class of
citizens therein is not adequate."
(emphasis added) 103 In K. Krishna Murthy (Supra), the Supreme Court while dgm 131 wp-2797-15
judgment-25-7-16.sxw dealing with the aspect of excess reservation, observed in the following
words:-
"66 Admittedly, reservations in excess of 50% do exist in some exceptional cases,
when it comes to the domain of political representation. For instance, the LegislativeBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

Assemblies of the States of Arunachal Pradesh, Nagaland, Meghalaya, Mizoram and
Sikkim have reservations that are far in excess of the 50% limit. However, such a
position is the outcome of exceptional considerations in relation to these areas.
Similarly, vertical reservations in excess of 50% are permissible in the composition of
local self-government institutions located in the Fifth Schedule Areas.
67 In the recent decision reported as Union of India v. Rakesh Kumar this Court has
explained why it may be necessary to provide reservations in favour of the Scheduled
Tribes that exceed 50% of the seats in panchayats located in the Scheduled Areas.
However, such exceptional considerations cannot be invoked when we are examining
the quantum of reservations in favour of backward classes for the purpose of local
bodies located in general areas. In such circumstances, the vertical reservations in
favour of SCs/STs/OBCs cannot exceed the upper limit of 50% when taken together.
It is obvious that in order to adhere to this upper ceiling, some of the States may have
to modify their legislations so as to reduce the quantum of the existing quotas in
favour of OBCs."
(emphasis added) The Backward Class Commission was established on 29.01.1953 (Kelkar
Commission). The caste-wise population was reported in 1961. The Mandal Commission has also
dealt with it further. The dgm 132 wp-2797-15 judgment-25-7-16.sxw 1931 Census is the base factor
for determining the population for reservation including of other classes, but is not final as updated
the natural growth or estimation as available utilised to determine the reservation policy from time
to time.
104 In Union of India Vs. Rakesh Kumar (Supra), in paragraph No.43, it is further observed that:-
"43 For the sake of argument, even if an analogy between Article 243-D and Article
16(4) was viable, a close reading of Indra Sawhney decision will reveal that even
though an upper limit of 50% was prescribed for reservations in public employment,
the said decision did recognise the need for exceptional treatment in some
circumstances."
(emphasis added) 105 The Apex Court in S.V. Joshi (Supra), has recorded that the "State
Government" shall be at liberty to make reservations in terms of the law laid down by this Court in
Indra Sawhney's case (supra). The reservation upto 50% is inclusive of SC/ST and other backward
classes.
106 The Apex Court in State of Kerala supra a It is stated that Article 16(4) needs to be read as a part
and parcel of Article 16(1)(2).
This is also keeping in mind the doctrine of equality of opportunity to dgm 133 wp-2797-15
judgment-25-7-16.sxw all the citizens and not only to some and inequality to others. The State
power to make a relaxation regarding the age in case of backward classes of citizens is also
reiterated. It is also clarified by giving illustration that any reservation, exceeding 50% required toBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

consider from the point of view of the State depending upon the large number of backward classes of
citizens and therefore, in order to give them proper representation, percentage of reservation
beyond permissible limits, may not be stated to be bad in law. It is made clear that the dominant
object of this provision is to take steps to make inadequate representation, adequate.
107 In Akhil Bharatiya Soshit Karmachari Sangh (Railway) (Supra), the Apex Court observed that:-
"335. The claims of the members of the Scheduled Castes and the Scheduled Tribes
shall be taken into consideration, consistently with the maintenance of efficiency of
administration, in the making of appointments to services and posts in connection
with the affairs of the Union or of a State."
108 In Suraj Bhan Meena (Supra), while dealing with the concepts of "Catch-up" rule and
"consequential seniority" and and after considering the decision in M.Nagaraj (Supra), it is observed
dgm 134 wp-2797-15 judgment-25-7-16.sxw that:-
"65. In effect, what has been decided in M. Nagaraj case is part recognition of the
views expressed in Virpal Singh Chauhan case, but at the same time upholding the
validity of the Seventy-seventh, Eighty-first, Eighty-second and Eighty-fifth
Amendments on the ground that the concepts of "catch-up" rule and "consequential
seniority" are judicially evolved concepts and could not be elevated to the status of a
constitutional principle so as to place them beyond the amending power of
Parliament. Accordingly, while upholding the validity of the said amendments, the
Constitution Bench added that, in any event, the requirement of Articles 16(4-A) and
16(4-B) would have to be maintained and that in order to provide for reservation, if at
all, the tests indicated in Articles 16(4-A) and 16(4-B) would have to be satisfied,
which could only be achieved after an inquiry as to identity .
109 The strong reliance was placed upon the U.P. Power Corporation Limited (supra), by the
learned counsel against the Reservation Act. It was a case based upon the facts and the then law
under challenge. The Supreme Court Judgment in Suraj Bhan, M. Nagaraj and others has been duly
noted. This covers and includes the point of ceiling limit of 50%. This also should be based upon the
identity and measure quantifiable data. This Judgment has also recognized, depends upon the
numerous factors and the compelling reservation claims, to be achieved by the State. In Suraj Bhan
dgm 135 wp-2797-15 judgment-25-7-16.sxw (Supra) case, the State had not undertaken any exercise.
It is reiterated that, the State is required to take steps as directed in M. Nagaraj (Supra), before
providing for reservation for promotion with consequential seniority.
"Proper Representation" as contemplated under Article 16(1)(4) for Other Backward
class permissible :
110 The term "proper representation" as contemplated under these Articles need to be read in the
context of the State Government enabling power to provide reservation to the backward class/group.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

Having once noted and found, based upon the data, that particular group and/or class is backward
and/or socially backward and are not duly represented as not belonging to Scheduled
Caste/Scheduled Tribe class/group though they are equally situated, the State is empowered to
extent and/or grant and/or provide such reservation permitting their representation in the State
Government service and/or to grant equal benefits concession to such other community/class. The
importance of granting such representation and reservation with intent to uplift the people
belonging to disadvantageous group or class and all related provisions are in the dgm 136
wp-2797-15 judgment-25-7-16.sxw Constitution since its inception and prior to the same. The
Parliament, considering the requirement, from time to time, has been extending and/or granting the
span as noted under Article 325 of the Constitution. The said protection/reservation has been
continuing for any one of the purposes, then the State is also under obligation to read and refer and
consider the same till the situation is restricted by appropriate constitutional provisions. The
representation and/or reservation conceptually means and includes the extended benefits to
similarly situated backward class/group once data is collected and sufficient to act accordingly. The
Court needs to consider the object and the purpose of the reservation policy. In Ram Kumar Gijroya
v.
Delhi Subordinate Services Selection Board and anr.24, the Supreme Court held that the object of
providing reservation to the STs/STs and educationally and socially backward classes of the society
is to remove inequality in public employment, as candidates belonging to these categories are unable
to compete with the candidates belonging to the general category as a result of facing centuries of
oppression and deprivation of opportunity.
    24  (2016) 4 SCC 754 
     dgm                             137 wp-2797-15 judgment-25-7-16.sxw
    Judicial   Review   of   the   Listing   &     the   quantum   of   "Quantifiable   & 
    Qualitative  Data of specific Class/Group". 
    111             It   is   impossible   for   the   Court   to   "list   or   de-list   and/or Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

specify backward class/community/group caste" even for the purpose of Article 16(4) for State or
Region, or otherwise. It is the specified work of an expert body/commission or authority of the
Central and/or the respective States, specifically for want of designed "straight jacket formula" for
the same, except the court decisions. Such Authorities/experts need to follow the Constitutional
provisions and the guidelines, issues, through the law and the Judgments announced, from time to
time, to achieve the constitutional aims and objects. We have noted that the practice and procedure
and the mechanism and the source so adopted by the Authorities/Commission are fair, adequate, by
applying its mind, the data/information for identifying and deciding the backward class/group.
There is no contra material placed on record. We have noted that no case is made out to interfere
with the decision/opinion/action taken of the State in this regard.
The State and the Authorities have applied it's mind to the material/data/information, submitted by
the expert body personnel, through the Commission, Reports with recommendations. They have
been acting fairly within the frame of law, and listed the dgm 138 wp-2797-15 judgment-25-7-16.sxw
"caste"/"group"/'classes", including OBC, in the respective Scheduled Lists for the constitutional
benefits/concession. There is no challenge to the criterion so fixed and acted upon by the
State/Authority to collect and gather information, since so many years. There is no
averment/submission that the benefits were wrongly or illegally given to the concerned
caste/groups. There is no such counter challenge even by other such groups/caste. There is no
perversity, illegality or malafide of any kind and even allegation of non-application of mind and
breach of any constitutional provisions. The whole challenge is unsustainable. The State's
Reservation Act/Circulars are valid and well within the frame work of law and the record.
The Court cannot direct or restrict the collection of upgrowing data.
112 It is correct that the Census of 1961 was restricted for SC and ST only. There is nothing on record
to point out any fixed procedure or mode of identification of backward classes to determine the
population based representation and/or reservation or fixed percentage. There is no declared
guidelines or formulae issued, how to identify and/or collect the data and to give representation to
such class and/or group and/or fix the percentage for reservation. The process of collecting
material/data is on, based upon the Supreme dgm 139 wp-2797-15 judgment-25-7-16.sxw Court
judgments . Definitely, those data and/or information are of 50 years old, but it has dealt with and is
a quantifiable data about the reservation in Government service of various backward communities.
This is in addition to the fact that the State has also separate backward class cell, which has data for
deciding the issue of adequacy of representation of backward classes. Those material and
information were also part of the record, and read and referred by the respective Committees. The
chart is placed on record as ordered by the Court, through the separate four volumes, in High Court
also, with clear submission that except Volume I, all other data reports, comparative chart in respect
of OBC and VJNT classes were part of record of the MAT. The backlog can also be of open category
and it cannot be only of backward class candidates. The constitutional rights of others are also
required to be protected.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

The excess 2% (above 50%) reservation for recruitment stage is permissible if the data is available
113 The excess of 2%, at the stage of appointment/post and/or initial recruitment permissible, if the
quantifiable data is available with the State.OBC covers SBC. The State's power is based upon the
irrefutable data to justify the reservation upto 52%. The reservation dgm 140 wp-2797-15
judgment-25-7-16.sxw beyond 50%, if any, as noted, even from the Supreme Court Judgments so
cited is not totally prohibited. Additional 2%, even if any, in the present case and in view of
Reservation Act and the circulars, the scope is very limited, as it is data based decision.
114 The learned Tribunal without referring to same reasons, accepted the case of original petitioners
though admittedly the Circular of promotion of 2004 in question had provided reservation only 33
per cent and certainly not exceeded 50% as contended. The learned Tribunal has wrongly accepted
the case that allowing reservation and carry over a promotional process for classes other than S.C. &
S.T. is in direct contravention of provisions of Article 16(4- A) and 16(4-B). It is wrongly accepted
that it permits disproportionate carry over and re-fixing of quota without any basis-
no such factual based case is made out. These affidavits and data having placed on record to show
the recommendations made by the respective Commissions and the Committee and the various
position of backlog and details which provide information and material for the State to extend
reservation to these category or the groups/classes including O.B.C., V.G./N.T. dgm 141 wp-2797-15
judgment-25-7-16.sxw 115 The recommendations of these Committees/Reports including Kaka
Kalekar Commission of the year 1955, B.D.Deshmukh Report (1961) have recommended
sub-classification of Backward Classes into S.C. & S.T., V.G., N.T. and O.B.C. The learned Tribunal
erred by holding that these reports of Committees, before 1978, before Mandal Commission Report,
and therefore, are not relevant.
The learned Tribunal is wrong in holding against the State by observing that "the State Government
has not been able to convince the Central Government to include D.T., N.T. and O.B.C. in
Maharashtra in the Schedule of S.Cs. and S.Ts". The Tribunal's approach was wrong. There was no
question of specific inclusion of these castes in the Scheduled List of SC/ST. The point is that they
are equal in "backwardness" and their "adequate representation" is required in the State. The State
enactments and earlier Circulars support their decisions. The issue is about treating all equals
equally . The Tribunal, in this background wrongly held that Section 5(I) of the Reservation Act
violates Article 16(4-A) for reservation in promotion, at all stages of promotion. This is also in the
background on admitted position on dgm 142 wp-2797-15 judgment-25-7-16.sxw record that the
State has exercised its power to provide reservation for O.B.C. as defined in the Reservation Act .
Section 5(2) empowers the State to do so. The Constitutional validity of any Act or provision cannot
be decided on presumption and assumption. The Circular/Resolution Clause 3A provides for
reservation in promotion for backward classes other than S.C. and S.T. and so also reservation for
members in VJ(A), NT and SBC .It is well within the law and the record.
No data of effecting efficiency in administration 117 Prior to the insertion of Clause (4A) to Article
16, i.e. prior to the constitution (Seventy Seventh Amendment) Act, 1995 w.e.f.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

June 17 1995, as per Indra Sawhney (supra), the reservation of appointment of posts under Article
16(4) was confined to initial appointments only. It is observed that such reservation cannot be
provided further in the matter of promotion and/or further promotion. This was also on the
foundation, that the reservation in promotion "might impair efficiency". In M. Nagaraj (supra), the
constitutional validity of amended clauses (4A) and (4B) have been upheld. It has been declared that
the State has to dgm 143 wp-2797-15 judgment-25-7-16.sxw identify and collect quantifiable data
showing backwardness of the particular class and group and inadequacy of representation of that
class/group in public employment. It is further declare that this is also by keeping in mind the
maintenance of efficiency in administration. This is again a subject to dealing with the facts and
circumstances of the case in question. The constitutional provisions and these judgments itself
empower and recognize the enabling power of the State Government to take effective steps to collect
data, information after identifying the backwardness of the class with a view to provide them proper
representation.
118 The Supreme Court in M. Nagaraj (supra), has even otherwise, never directed to initiate and/or
mandate that all the pending matters, reservation policy based upon the existing data be rechecked,
re-opened and re-identified and declared first bad in law and then framed the fresh reservation
policy, by creating blankness and commotion in the society. Timely action is required but after
giving reasonable time to all the concerned based upon contemporary data/material . The recent
judgements support the same. Apex Court in dgm 144 wp-2797-15 judgment-25-7-16.sxw Ashok
Kumar Gupta and Anr. vs. State of U.P. and Ors 25 has reinforced the concept of administrative
efficiency in this background.
The State's bonafide action 119 This is also in the background that the basic reservation policy is in
existence in the State since 1901. The State had been acted accordingly, in view of the various earlier
judgments, initially in view of General Manager, Southern Railway Vs. Rangachari Gurbux Das .
The subsequent reservation was restricted to 50% in Indra Sawhney (supra), until as recorded, the
reservation in promotion was not accepted. However, by the subsequent constitutional amendment,
such reservation in promotion, in fact, has been accepted and maintained in M. Nagaraj (supra),
except on a condition as recorded above. Therefore, the important requirements, which the Court
need to see are; (a) Whether there is a material in support of the backward classes of population? (b)
and/or adequate representation in various posts? (c) Whether such reservation had affected
adversely to the administrative efficiency? We have noted that all these elements are in favour of the
State and the Reservation Act/Circular.
    25  (1997) 5 SCC 201
    26AIR 1962 SC 36
     dgm                             145 wp-2797-15 judgment-25-7-16.sxwBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

    120             The State, cannot be stated to have no data whatsoever to 
grant such reservation, as already granted and implemented since long. The reservation in
promotion was provided in the year 1974, though upto Class-I level - had been intended to be
implemented by the Reservation Act. Under Section 5, the reservation extended to all the employees
at all the stage of promotions also. Section 4 of the Reservation Act, itself further added that the
percentage of reservation should be on the basis of latest Census record of population. The State has
established the Backward Class Commission for the same. The State had relied upon various
reports, commissions and their recommendations, as recorded above: Thade Committee Report of
1961; B.D. Deshmukh Committee Report 1964; Edate Committee Report 1988; the State Backward
Class Commission Report; Census Report and SBC Files. We have already dealt with same in earlier
paragraphs. These reports are relevant for all concerned, unless specifically challenged.
A preliminary objecti on by the State 121 The learned Members of the MAT have decided the issues
in pursuance to the remand order/order passed by the High Court, as dgm 146 wp-2797-15
judgment-25-7-16.sxw recorded in earlier backgrounds, history/notes. The facts need to be tested
after considering the provisions of the Administrative Tribunals Act, and specifically Section 15.
Initially, there were objections raised before the High Court, that the related issues were required to
be adjudicated by the MAT, being the Court of first instance. but by keeping the objection open.
122 The submission, therefore, by the learned Senior Counsel appearing for the State is that the
MAT has exceeded its jurisdiction in deciding the constitutional virus of the Reservation Act.
123 It is submitted by the other side that there is no bar and/or any Section of provisions pointed
out, which debar and/or prohibit and/or restrict the MAT in dealing with virus and/or validity of
any Act and/or related circulars. Therefore, "the doctrine of appropriate and reprobate" is cited, in
view of the conduct of the State and R.L. Gosin Vs. Yashpal Dhir , and Rajasthan State Industrial
Development and Investment Corporation and Anr. Vs. Diamond and Gem Development
Corporation Ltd. & Anr. .
    27AIR 1993 SC 352
    28AIR 2013 SC 1241Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

     dgm                             147 wp-2797-15 judgment-25-7-16.sxw
    124             So   far   as   the   jurisdiction   and   power   of   the   MAT,   the 
                            .   Sampathkumar   Vs.   Union   of   India    
    Supreme   Court   in  S.P                                               has 
elaborated that the Tribunal is the substitute of the High Court and is entitled to exercise the power
thereof, (para 31, 19, 93 and 99). In J.B. Chopra Vs. Union of India , the Apex Court clarified that the
MAT, being a substitute of High Court, has power and authority to adjudicate upon all the disputes
relating to the service matters, including the power to deal with questions, pursuance to the
constitutional validity or otherwise of such laws which violates Articles 14 and 16 of the
Constitution.
125 However, the Tribunal need to act within the scope and jurisdiction as provided under the
tribunal Act. There are Writ Petitions whereby, the constitutional validity of the Reservation Act
itself are challenged directly in the High Court by other similarly affected persons. Those will be
heard separately.
The Power a nd Jurisdiction of the tribunal-- MAT 29AIR 1987 SC 386 301987 SC 357 dgm 148
wp-2797-15 judgment-25-7-16.sxw 126 The Supreme Court in L. Chandra Kumar vs. Union of
India31 has specifically dealt with the power and jurisdiction of MAT.
In paragraph 91, the Supreme Court has emphasized that the power of judicial review is with High
Court under Articles 226 and 227 where vires of the legislation is questioned. It is observed that the
Tribunal should restrict themselves to deal with the matters where constitutional issues are raised.
This is no way to read and mean that in service matters, the MAT cannot deal with Articles 14, 15
and 16 of the Constitution. What is contemplated is, therefore, the power of Tribunal to decide and
adjudicate the issue on merits. In the present case, merely because the High Court has directed the
matters to the Tribunal that itself ought not to have the reason for the Tribunal to decide the
constitutional validity of the Reservation Act, based upon no pleading and/or material with regard
to the merits of the promotional issues. The Tribunal ought to have acted upon as the Court of first
instance in respect of the areas of the law for which they have been constituted, to decide the merits
of the service matter based on facts if any, keeping in mind Article 14 to 16.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

    31     AIR 1997 SC 1125 
     dgm                             149 wp-2797-15 judgment-25-7-16.sxw
    Locus standi of the contesting Respondents
    127             The issue of locus-standee of the original complainant, in 
view of above background, even if raised, but having ordered by the Division Bench after
transferring the group of Writ Petitions , and as both the parties have participated before the MAT,
and as the validity of the Reservation Act itself has been declared ultra virus, we are inclined to deal
with the matters on validity of The Reservation act, as the confusion and non- plus situation has
been created in all state reservation issues .This required to be adjudicated and decided at the
earliest. Therefore heard finally these restricted matters .
128 The Apex Court in State of Maharashtra Vs. Jalgaon Municipal Council & Anr. rejected the case
and submission that the citizen and/or voter has no locus standee to challenge the constitutional
virus of the Act or the ordinance. In S.P. Gupta Vs President of India & Ors. , and , Dr. D.C. Wadhwa
Vs. State of Bihar Chairman Railway Board Vs. Chandrima Das and Mohd. Aslam Vs. 32 AIR 2003
SC 1659 33 AIR 1982 SC 149 34 AIR 1987 SC 579 35 (2002) 2 SCC 465 dgm 150 wp-2797-15
judgment-25-7-16.sxw Union of India . These judgments need no further discussion, as we have
proceeded to decide the issues so decided by the Tribunal Judgement/order.
The tribunal jurisdiction to declare Reservation Act ultra vires 129 The learned Members of the MAT
have cautiously proceeded with the matter while dealing with the validity of the provisions in view of
the submissions so raised and made by the parties, including noting the basic principle of
presumption in favour of the constitutionality of such statute and noting that the forum has to
proceed within the limitation of judicial review while examining the virus of the statute.
130 It is settled that the presumption is always in favour of validity of enactment brought by theBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

legislatures. The scope of Judicial Review against the presumption is very limited. In view of power
and scope of Article 226 of the Constitution of India and its principle to interfere, is also restricted
and limited. The scope and power of MAT of "judicial review" to interfere with validly enacted 36
(2003) 4 SCC 1 dgm 151 wp-2797-15 judgment-25-7-16.sxw the Reservation Act, and circular, is
further limited and restricted, than High Court. The Judgment and order passed by the MAT is
always subject to the writ jurisdiction of the High Court. The purpose and object of the Tribunal in
the Central, and the State service matters, is limited. The MAT may pass order and/or deal with the
subject, which falls within the purview of the State Tribunal. Most of the service matters are on facts
and respective service conditions and rules made therein. The jurisdiction of MAT therefore,
required to be within the ambit of facts and respective service conditions, rules and regulations or
circulars or its interpretation.
131 The prayers and reliefs were contested by the respective Departments. The MAT, being a first
instance court, that itself mean and/or empower firstly to look the basic principles of law of pleading
and law of burden of proof, specifically in view of settled position of law in favour of validity to any
enactment. The scope of MAT to go into the factual details and data in question in case the disputed
facts are involved is limited. Any enactment always has the foundation of prior and pre-collected
information/data/material by the State agencies, before the cabinet, and before the legislation.
     dgm                             152 wp-2797-15 judgment-25-7-16.sxw
                              The Impugned Judgment of  MAT
    132             The   learned   Tribunal   Members   have,   on   the   Transfer 
Applications Nos. 1 and 2 of 2004 (Writ Petition No.8452 of 2002 and Writ Petition No.470 of
2005) without dealing with the facts and the merits of the respective applications/writ petitions,
dealt with the Reservation Act and the promotion Circular. No pleadings, affidavits and facts have
been specifically dealt with to hold the foundation on merit to decide the validity. The learned
Members have also, though noted the issue of incomplete and inadequate pleadings, proceeded to
decide the vires and the validity of the Reservation Act merely because the original
applicants/petitioners are State Servants. The learned Members have proceeded on the foundation
that an adverse inference should be drawn if important documents were withhold. The learned
Members thereby accepted the case of original petitioners/applicants that inadequate pleading or
averments should not be the reason to dismiss the challenges so raised about the validity of the
Reservation Act. This is on the unsupportive foundation that even if the burden of proof did lie on
the original Petitioner, but as the State had withhold the important documents, the adverse
inference should be drawn.
(Gopal Krishnaji Ketkar v. Mohamed Haji Latif, AIR 1968 SC 1413) dgm 153 wp-2797-15
judgment-25-7-16.sxw The Tribunal, therefore, ultimately proceeded wrongly by observing that it isBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

for the State to produce material to support their claim, though quantifiable data is available with
them to support the same, that the various backward classes are not adequately represented in the
Government service. This is in the background of no specific order to produce any particular data or
material. The requisite data/material in fact were part of the record as noted earlier.
Furthermore, there was no specific sustainable challenge raised for want of specific pleading with
regard to the vires of the Reservation Act at the stage of recruitment on the aspect of reservations of
posts for all the specified categories up to 50%. We have noted that a challenge is raised also about
reservation beyond 50% - excess 2% in the present case.
Abrupt discontinuation of Earlier Circular's and existing reser vation policy incorporated in the
Reservation Act and the Circulars.
134 By Maharashtra Government Resolution dated 9 April 1965, a provision was made for
reservation in Government Service for members of backward classes SC-including converted to
Buddhism, ST-living out side the specified area, De-notified Tribes and Nomadic dgm 154
wp-2797-15 judgment-25-7-16.sxw Tribes and other backward communities. In modifying the
existing reservation, percentage was fixed for SC 13%, ST 7% DTNT 4%, and other backward
communities 10%= Total 34%. These Government circulars applicable through out the State to the
Department and accordingly all requisite benefits have been provided to them. The directions were
issued to comply with the same also.
135 Government Resolution of 23 May 1974, even the stage of promotion was considered. Noting
50% limitation, for SC 13%, ST 7% and De notified Tribes 4%, total 24% was fixed for reservation of
these classes, at the stage of promotion. That was on the basis of seniority, subject to fitness and
increase to all classes,- Class-I, Class-
III and Class-IV posts/ grade in service. The model roster was accordingly prepared and the
concerned department and parties have acted upon the same.
136 As per the State, the reservation policy has been extended to the local bodies in the year 1995
and 1996 . The same has been implemented without specific challenge by such organizations with
regard to the reservation to SC/ST and OBC. In totality, we have also dgm 155 wp-2797-15
judgment-25-7-16.sxw noted that the Reservation Act has not made any new changes and/or
brought any new provisions for the first time, based upon the data and the material so placed on
record and the then existing reservation policy through the circulars so recorded above, brought into
force the Reservation Act 2001 w.e.f. 2004. There is no material placed on record to show that such
circulars have been declared bad and/or illegal for want of quantifiable data. The State in its wisdom
and in view of enabling power, decides to extent the same benefits to such class/group through these
Statues. This is in addition to the earlier state data.
Nagraj's Principle discussed by the Tribunal 137 The learned Tribunal members, though recorded
and noted the synopsis of reports of various Committees so recorded above and its
recommendations as reproduced in paragraph 27 and so also note on behalf of State, providingBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

information about various reports with page numbers, yet by sitting as Appellate Court and/or
Forum, have expressed their opinion contrary to and/or against the opinion and the reasoned
decision given by the State and it's expert bodies.
The Apex Court in Indira Swahney in paragraph 842 itself recorded and restricted the scope of
Court's scrutiny in such matters. This is dgm 156 wp-2797-15 judgment-25-7-16.sxw not the case of
no material whatsoever on the contrary as per the Constitutional requirement. The State being
empowered to take care of the problems and difficulties of respective communities, tribes and
groups. It is under obligation to provide them representation in service and/or adequate
representation in service, if case is made out.
What should be the level and degree of sufficiency and/or adequacy and as there is no strict jacket
formula for assessing and for arriving at a conclusion to fix and grant reservation at recruitment
and/or at promotion stage, therefore, it is in State's domain. The findings and the submissions that
no attempt was made by the State to conduct and exercise as done in State of Bihar in August 2012,
is wrong and should not have been the basis in the facts of the case.
The State under continuous obligation to collect data for modification of Reservation Policy.
138 This, nowhere led to mean that the State is restricted and/or prohibited from continuing to
collect timely data for timely correction and/or amendments to the reservation policy, as per the
requirement of the society in the State. This may include addition and/or lowering of percentage
and/or category at appropriate stage but in accordance with law. Mere allegation that the
reservation has dgm 157 wp-2797-15 judgment-25-7-16.sxw adversely impacted on over all
administrative efficiency is not sufficient. There ought to have on record the material to justify the
same. The burden cannot be put upon the State to prove negative.
139 This also means, all these clauses independently or otherwise are required to be read and
referred while dealing with the subjects of providing reservation even in promotion to SC/ST and
other backward classes, but subject to the other constitutional provisions, including Articles 14, 15,
16 and 335. The State Government and/or appropriate Government is also required to restrict the
duration, based upon the facts situation in so far as the ceiling limit on to carry over all the unfilled
vacancies. This also means that there is no bar and/or restriction or any restriction is imposed upon
the State and/or appropriate Government to enact the law providing for reservation for all. The 50%
ceiling itself means and it covers not only SC and ST class and/or group but other backward class
also as constitutionally fixed and as recognized and have been in existence since inception. This
constitutional percentages covering all class and protection so granted in the year 1931, 1961, 1965,
1971 etc. have been followed by the most of the dgm 158 wp-2797-15 judgment-25-7-16.sxw States.
The decision therefore, so taken by the State, initially through the circulars and subsequently
through the Reservation Act in the matter of employment, was well within the frame work of law
and the record.
The state Promotion policy as per the law and service rules only.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

140 If the contesting Respondents or any employee not eligible for promotion unless promotions are
actually given effect to and/or there is no actual threat of any kind in any particular cadre or
department, there is no question to decide the case on merits. The promotion, on merit, will be
tested based upon the factual data and the relevant principles of law. The promotion policy is also
subject to change. The promotion policy is also not a matter of judicial review as it is the prerogative
of Executive including fixation of quota and ratio. However, it is required to be within the frame
work of law and the record so declared. [Rohtas Bhankhar v. Union of India(supra) ].
141 Promotion is a part of recruitment if service rules provide but subject to eligibility criteria;
seniority cum merit or vise versa, ACR and other conditions. It is stated to be a mechanism of
further appointment to the higher grade or category of post. The promotion dgm 159 wp-2797-15
judgment-25-7-16.sxw is not a right, but it's entitlement if otherwise fit within the promotion policy.
The State is empowered to provide for promotions but subject to criterion and need or it may not
provide promotion.
The Court cannot direct the State/Authority to provide for promotion, if there are no such rules. The
various restrictions, eligibility criteria are normally fixed by the State at the time of recruitment
itself. The employees are aware of such policy of promotion at the time of "appointment" to the
"post" itself. The recruitment once made on reserved category basis, at entry level that itself may not
improve their overall development even for promotion. Every employee needs to work hard and to
get promotion as per the conditions, apart from regular CR/ACR (Confidential Record/Annual
Confidential Record).
The law of appointment/promotion is settled, so also the doctrine of "creamy layer" even at the stage
of promotion. [ In Ashok Kumar Gupta v. State of U. P., (1997) 5 SCC 201 "efficiency of
administration"
is also reinforced. ] Ajit Singh v. State of Punjab (1997) 7 SCC 209 -
"Roster point" is also a point for discussion in such circumstances.
The State, therefore, is entitled to make promotion rules or modify the promotion
rules, for any of the category or the group. The appointment at initial stage on
reservation itself may not make them dgm 160 wp-2797-15 judgment-25-7-16.sxw
equal with general category. The selection rules or eligibility criteria, even for
promotions are made by the State. The new generation, disadvantage class, even if
belongs to reserved category, having exposed to new technology, in school, college or
higher education, themselves surprise the State or the employer by their
performances, even in public employment, because of their merits. The State,
therefore, definitely need to change it 's approach and so also to such reservation
policy. The social, economic, education improvement itself, in a given case, entitled
them to participate, at all level, with the general category. The aspects of "creamy
layer", improved economic condition and education condition, itself grant and/or
filter their entitlement in future promotion even for other backward class/category.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

The political dynamic spectrum itself cannot be the reason to give guidelines or to do
list even by the Court. Let respective wings act within their declared sphere. The
disadvantaged person/class cannot be treated as general category merely because
they are appointed to the post because ofthe concession given at the time of
recruitment itself. For further promotion or up-gradation, subject to filtration, the
State is empowered to provide reservation policy if facts and circumstances permits.
     dgm                             161 wp-2797-15 judgment-25-7-16.sxw
    142             The Tribunal's one member  has not decided issue raised in 
para 19(ii)(b) about the definition of "Public Service and Posts" and "establishment".
The Court will consider the same in appropriate case. We have to deal with the
"Public Employment" and not the "Private Employment". Even otherwise, it is the
State, in view of the constitutional provisions, to decide and/or extend the
reservation policy within framework of law . Therefore, if there is specific challenge
the Court would decide the same The issue raised in para 19(ii)(c) is covered in para
19(ii)(a) so also for the above reasons.
The State has always power to extend the reservation policy if required. The Court
cannot restrict or direct the State to bring in or out extension of reservation policy to
any "State institution" or "establishment".
The Reservation in Promotion through Circular since long 143 The whole argument as recorded and
agitated even before the MAT and/or otherwise by the Respondents was on the State's power of
providing even 33% reservation in promotion. There was no serious dispute in the matter of basic
recruitment which can be seen from the issues so raised by the Tribunal. There was no specific dgm
162 wp-2797-15 judgment-25-7-16.sxw challenge or issue raised about and on recruitment process.
The challenge and the percentage so prescribed, based upon the circulars since long which has
remained intact till this date and now converted into the Reservation Act.
The Statute need not be declared ultra-vires for the Academic purposes.
144 On going through even the affidavits, including Para 26 to 41 and the counter-affidavit filed by
the parties, read with the documents, charts, statements and the various reports, so recorded above,
and as those are sufficient to consider the case of the State about the existence of data, vacancy and
the representation requirement for the particular community. This is also in view of the fact that
there is no specific contra material, except simple denial. We have noted, apart from the backlog andBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

the vacancies and the requirement for providing the promotions to all the categories, further
material for the years 2004 to 2011 are updated upto 31 March 2013, are also placed on record
through the exhibits and charts. It is necessary to know that the reservation in promotion are made
subject to various orders passed by the Supreme Court and the High Courts. .
No actual affected list and/or special seniority list and/or action are dgm 163 wp-2797-15
judgment-25-7-16.sxw placed on record by the contesting party. The Constitutional validity,
therefore, in our view, ought not to have been decided only for the academic purposes.
i) Naresh Shridhar Mirajkar & Ors. Vs. State of Maharashtra & Ors.37 (Para 16).
ii) State of Karnataka Vs. Registrar General, High Court of Karnataka38
iii) The State of Bihar Vs. Rai Bahadur Hurdut Roy Moti Lall Jute Mills & Anr.39 Furthermore, the
promotion rules itself required to complete many steps and stages, including availability of
vacancies/posts before implementing the reservation in promotion. The promotion circular itself
provides only fluctuating reservation. Even otherwise, such reservation policy is also subject to
change and/or modification from time to time. Cadre-wise and/or class-wise and/or
sub-distribution, even if any, of vacancies/posts would be decided on factual basis and as and when
the particular department crosses the limitation of all kinds.
    37AIR 1967 SC 1
    38(2000) 7 SCC 333
    39AIR 1960 SC 378
     dgm                             164 wp-2797-15 judgment-25-7-16.sxw
    145             There   is   no   issue   that   the   reservation   in   promotion   is 
second stage/concession to the person/caste or community who have been provided concession
and/or benefits at the time of recruitment/appointment to the posts. In the present case, Act
provides 52% reservation, for the basic entry points are concerned, favoring all the categories
subject to the set percentage. The promotional circular grants the similar benefit only to certain
categories up to 33%. Therefore, apparently in promotion, there is no case of doctrine of Reservation
beyond 50%. The tribunal, therefore, ought not to have intermixed the same reasons of quantifiable
data and/or material as there is no specific pleading or contra material before declaring the
Reservation Act and the circular bad in law. The excess promotion and/or no case of benefits to beBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

given to the concerned caste or community in promotion, for want of quantifiable data, required to
be considered only if actual and factual data and or material are placed on record. The concerned
Tribunal/Authority would consider the same by assessing the merits if case is made out.
This is in the background that there is no bar and/or any prohibition and on the contrary, the
Supreme Court Judgments , itself provide and permit the State to extend benefit to ST and SC, even
in promotion dgm 165 wp-2797-15 judgment-25-7-16.sxw subject to the data, which in the present
case, is available. So far as other communities are concerned, the same doctrine/principles are
applicable, if they are equally situated and/or placed in their backwardness and for providing
reservation based upon the material and the representation so made, including the grant of similar
benefit, even for the promotion. The actual uncertainty and/or complications, if any, including
excess of reservation and/or representation, would be considered at the relevant stage in
appropriate fact based case.
"Catch UP Rules" vis-a-vis "interse seniority" & "Roster Point"
146 The concept of "catch up rule" is well recognised while dealing with the reservation in
promotion. The Supreme Court, in many judgments, has elaborated the principle referring to Article
16(4-A) read with 335 of the Constitution. "Catch Up Rule vis-a-vis Interse seniority"; "inadequacy
of representation of ST and SC";
"consequential seniority"; "State's obligation to collect data"; "Roster point" - all
these principles are required to be noted by the State and/or the Authority while
considering the reservation in promotion.
[S. Panner Selvam (supra). It is always necessary for the State to keep in mind "no
reverse discrimination against the general category".
     dgm                             166 wp-2797-15 judgment-25-7-16.sxw
    "Creamy layer" applies to OBC & others
    147             The concept of "creamy layer" has been elaborated from 
the point of view of OBCs and not referring to the SC and ST categories in Ashok
Kumar Thakur v. Union of India 40 (Five Judges-
Constitution Bench). The said principle has been followed and referred in subsequent
judgments also including Rajesh Kumar (supra). The Constitution Bench of Supreme
Court in Rohtas Bhankhar v. Union of India41 has also dealt with the aspect of
"creamy layer" along with the excessiveness of ceiling of 50% and the extension ofBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

reservation indefinitely, thereby maintained the Supreme Court judgement of
Superintending Engineer, Public Health, U. T. Chandigarh vs. Kuldeep Singh & ors,
1997(9) SCC 199. This decision of Supreme Court, therefore, need to be followed by
all while applying the reservation in promotion for OBCs. That squarely is the case of
the State in the case in hand.
148 The concept of doctrine of "creamy layer" create a class among the reserved category itself.
Though belongs to reserved category yet, if reached to level and/or fall within the ambit of
40(2008)6 SCC 1 41 (2014) 8 SCC 872 dgm 167 wp-2797-15 judgment-25-7-16.sxw umbrella of
"creamy layer",all the future benefits are restricted. But still their caste/class remains the same. The
alike reserved category batch or group or class or individual if are not under the umbrella of creamy
layer are entitle for "equal opportunity"" protection" even in promotion. Time will take care if all are
within the umbrella of "creamy layer". The constitutional extension for further 10 years reflects the
whole intention of the people at large. In Democracy set up, there should be constitutional decision
on these reservation policy first. The scope and power of judiciary are restricted. The judicial review
or decision follows later. The interpretation of law is the judicial power and not the making of law.
MAT's finding about the Creamy Layer 149 One of the learned Tribunal, so far as the creamy layer
for promotion to the O.B.C. is concerned ,has refused to decide the issue as it is held that the
reservation for promotion in category other than S.C. and S.T. is invalid. However the rule of
Creamy Layer would not be applicable at the time of entry and/or at the time of granting of
promotion to S.C. and S.T. The other tribunal member has dealt with it.
     dgm                             168 wp-2797-15 judgment-25-7-16.sxw
    150             The   observations   are   made   that   the   concept   of   Creamy 
Layer should not be applied to S.C. and S.T. both for initial appointment and for promotion in the
referred Supreme Court judgments.
151 In view of above, the one learned Tribunal has not dealt with the aspect of applicability of
Creamy Layer to the O.B.C. category.
Lastly, we came to the conclusion that a reservation in promotion for the categories other than S.C.
and S.T. is valid. The aspect of Creamy Layer to promotion of O.B.C. does survive. However, it would
be subject to the existing law and the State Circulars.
152 It has been noted that Section 4(2)of the reservation act itself provides that the concept of
"Creamy Layer" shall be applicable to all the categories mentioned in Section, except SC and ST. The
said concept has been elaborated in the Government Resolution and is amended from time to time.
The State Resolution, therefore, would be applicable to all the concerned, at the respective stages.
Wrong use of the Doctrine of Severability 153 The stage of appointment/recruitment by the
State/Authority always governed by the constitutional reservation of dgm 169 wp-2797-15Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

judgment-25-7-16.sxw particular caste and community and the percentage so fixed from time to
time. In view of constitutional provision even for promotion, so far as Scheduled Tribes and
Scheduled Castes are concerned, and in view of Supreme Court Judgments so referred above, the
State is empowered to extend the benefit and concession. Therefore, if case is made out with the
quantifiable data, the parallel benefits to the similarly situated person being backward and not
adequately represented, the State is empowered, in view of the enabling constitutional provision, to
widen the similar benefits at the time of recruitment and also at the time of promotion. Aspects of
Article 14,15 and 16 and other provisions need to be read together when it comes to granting such
benefits to the equally placed castes and communities. The learned Tribunal, therefore, wrongly
approached the matters. The reservation act has foundation of earlier enactments and the circulars.
All historical facts and those necessities are interlinked and unjust to break down. All the
reservation provisions are legitimate so also the Circulars. The severability tenet was invoke
imperfectly.
                                 The wrong shifting of Burden 
    154             The law is settled so far as the constitutional validity of 
     dgm                             170 wp-2797-15 judgment-25-7-16.sxw
any Act/Statute are concerned. The presumption is always in favour of constitutionality of statute.
In the present case various material have been placed on record including the existing data, which
were noted and placed even before the Cabinet and further before the State Legislature, which
ultimately had passed the Reservation Act, in the 2004 based upon 2001 census and the material so
collected. The original petitioners have not placed on record any contra material to challenge the
provisions, The Tribunal, though noted the measurable material placed on record in support of the
said action but overlooked the same and declared the Act ultra vires, on presumption and
assumption. There are persons other than the petitioners, who would be benefited by this Act and
the policy, are not before the Court.
Though in Transfer Petition No.2the Tribunal has no jurisdiction to deal with certain matters of
such corporation and the order of transfer, even if any, passed by the High Court, that itself is not
sufficient to accept the case that the Tribunal has jurisdiction to decide the constitutional validity of
the act which is beyond their jurisdiction in view of specific provisions of Administrative Tribunal
Act and the Judgments of Supreme Court in relation to it. This was also by putting whole burden
upon the State, in spite of quantifiable data dgm 171 wp-2797-15 judgment-25-7-16.sxw placed on
record.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

155 This is again in the background where the State if case is made out, is entitled to provide
representation to such community in every field including the State service. There is nothing
pointed out that once the reservation is declared to the particular community including the
percentage so fixed and prescribed, the same are not extended and/or cannot be extended for the
said community/group for any other purposes. We have noted even from the judgements so cited by
the parties that once the reservation/representation is granted and/or extended by the State, those
are applicable to the group and/or category for all the purposes. Such reservation based upon
Statutes/Circulars, cannot be taken away in such fashion even in promotion matters. [ Chairman
and Managing Director, Central Bank of India and ors v. Central Bank of India SC/ST Employees
Welfare Association and ors.42, on the contrary enforceable constitutional rights has been created
by such statutes.
     The Tribunal's  wrong findings 
    156              The   learned   Tribunal   failed   to   consider   the   Apex   Court 
    42      (2015) 12 SCC 308
     dgm                             172 wp-2797-15 judgment-25-7-16.sxw
judgment in Commissioner of Commercial Taxes, A.P. Hyderabad and anr vs. G. Sethumadhava Rao
and ors.,43 whereby Rangachari's principles have been upheld so also Thomas (supra) and Akhil
Bharatiya Soshit Karmachari Sangh (Railway) v. Union of India and ors. (1981) 1 SCC 246, whereby
even the rule of reservation in promotion was considered even for backward class. The learned
Tribunal also failed to consider the UP Corporation and Suraj Bhan Meena Case (supra) wherein
following M. Nagraj (supra), the reservation based in promotion, as stated to be permissible, subject
to Nagraj's principles. Even various Committee reports with regard to the inadequacy of
representation and population percentage was not duly considered. There was no challenge to the
source of information and the backwardness of the backward classes and even of S.B.C. The learned
Tribunal failed to note that the Supreme Court has permitted the reservation in promotion for
VJ/NT category but subject to final decision. This is in the background also that the challenge was
restricted to reservation in promotion and not about the reservation in direct recruitment. The other
cases cited by the State were also not discussed. The learned Tribunal was wrong in relying on the
43 (1996) 7 SCC 512 dgm 173 wp-2797-15 judgment-25-7-16.sxw principle of "best evidence rule" by
overlooking the basic principle of burden of proof in the matter of constitutional validity. The
reliance on the Maratha Reservation Case was wrong, being issue after the Reservation Act and the
Promotion Circular. The difference and the different percentage of all the categories itself speaks for
the State's decision to grant reservation, based upon the data and the material with them.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

The concept "any backward class of citizens" covers and includes the OBC/NT and those are socially
and educationally backward classes. The learned Tribunal has misread and misinterpreted Articles
15(4), 16(4), 340 and other constitutional provisions. The learned Tribunal, though recorded that
the validity of impugned Reservation Act in relation to SC and ST need to be upheld, but declared
the whole Reservation Act and the Circular bad in law.
The principle and protection so available to SC and ST, therefore, required to be extended to other
backward classes, and/or categories, if they are similarly and equally situated and requisite data is
available. The Tribunal further failed to appreciate that Barium Chemical's case (supra) required to
be followed in the matter of dgm 174 wp-2797-15 judgment-25-7-16.sxw subjective satisfaction of
the State. The issue of deemed State is fact based. The principles of Industrial Disputes Act ought
not to have been extended in the matter of reservation. The observation regarding the cooperative
society was also without any data and material including the finding revolving the definition of
"establishment". There was nothing to show that the reservation in promotion was as announced in
excess of prescribed limit. The provisions of direct recruitment and that of promotion was wrongly
interlinked and intermixed. The SBC is a part of OBC, but the Tribunal has overlooked the same. No
discussion, even made about the purpose and object of Articles 338, 338-A and 340 of the
Constitution including Backward Class Commission's role. The Tribunal, as noted, except declaring
the Reservation Act bad in law, not even discussed the State's action of giving promotion to the
reserved candidates pursuant to the order passed by the High Court and the Supreme Court. The
learned Tribunal, even failed to note that the State action was based on record of 34 reports of
various Commissions ,ranging from the period 1964 to 2008. The reservation in promotion, though
upto class I, was recognised by the Full Bench of High Court in G. R. Chavan's case 44 which was
confirmed by the 44 1988 (Supp) BCR 923 (FB) dgm 175 wp-2797-15 judgment-25-7-16.sxw
Supreme Court in G.R. Chavan v. State of Maharashtra 45. There are cases even after Nagraj,
specifically U. P. Power Corporation and Suraj Bhan Meena (supra), where reservation in promotion
to the VJ/NT and/or others, has been recognised. The learned Tribunal wrongly interpreted the
term "backward class of citizens" by overlooking the Indira Sawhney's specific findings on other
backward classes. [ Ram Krishna Dalmiya v. Justice Tendolkar, AIR 1958 SC 538, M. Rathinaswami
v. State of Tamil Nadu 2009(5) SCC 628 and Heena Kausar v. Competent Authority 2008(14) SCC
724.
Subject to the data, any such reservation i s permissible for all the classes - No total bar.
158 In R.B. Rai Vs. State of Madhya Pradesh (Writ Petition No. 1942 of 2011) and other matters , a
Division Bench Judgment of Madhya Pradesh, at Jabalpur, for the reasons and the background,
apart from the constitutional Provisions dealt with the Rules around the Madhya Pradesh Public
Services (Promotion) Rules, 2002 based upon the Nagaraj (supra) is distinguishable on facts
itself.The reservation act based upon update available data distinguishes the case.
    45  AIR 1999 SC 1530Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

     dgm                             176 wp-2797-15 judgment-25-7-16.sxw
                                                             46 47
                    The Judgment of Sushil Kumar Singh & Ors            are of no 
assistance to the clamant to pursue us to differ from the view which we have taken. Additionally,
impugned resolution dated 21 August 2012, was after the Nagaraj (supra) essentials, with no extra
material.
The Reservation Act and the Promotion circular in question, are based upon the earlier statutes,
circulars and historical background so reflected and the on hand proven records, This case is totally
distinguishable on facts, as well as, on law. No such data was available is the findings. The
chronological background of State including the earlier statute and circulars were not discussed
including the essentials of Nagaraj (supra). We have noted in the case in hand the factual data
revolving around the Nagaraj (supra) elements.
160 In Full Bench Judgment of Tripura, Agartala High Court, in Shri Jayanta Chakraborty & Ors.
Vs. The State of Tripura & Ors. (WP(c) 189 of 2011), there was no such data placed on record to
justify the reservation. Even otherwise, considering the reasons so recorded in 46(2015) 2 PLJR 844
47(2015) 3 PLJR 593 dgm 177 wp-2797-15 judgment-25-7-16.sxw this Judgment, Tripura Judgment
based upon the facts of the Tripura State, cannot be made applicable to the State of Maharashtra.
In Ram Singh & Ors. Vs. Union of India 48 , the claim of Jat Community was involved, to be
included in the Central Scheduled List. The role of National Commission for Backward Classes,
(NCBC) is reiterated in Ram Singh & Ors.(supra), including its guideline, criteria for inclusion in the
list of Other Backward Class (OBC). The challenge was to the Jat Community inclusion in the
Central list of Backward Class for various States, inspite of rejection of such claim by the NCBC. In
the Apex Court, the challenge was to the notification of the inclusion. This was a different and
distinguishable case of no material, no data, no earlier Act/Circular but new inclusion therefore the
challenge. In case in hand, the central/ State caste list entries were never challenged. We are
concerned with the additional State action of providing them reservation in the State employment.
The Nagaraj (supra) issue was not for discussion in this case.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

    162             The Apex Court in U. P. Power Corporation Ltd v. Rajesh 
    48(2015) 4 SCC 697
     dgm                             178 wp-2797-15 judgment-25-7-16.sxw
Kumar49 referring to the earlier judgments has crystallized the points which are further noted by
the Supreme Court in other judgments. In Rajesh Kumar, Section 3(7) of the concerned Act and the
Third Amendment to the Rules of 2007, as brought into force in 2007, were declared invalid, ultra
vires and unconstitutional for want of data.
This judgment/decision on facts, therefore, is distinguishable, but so far as the law and the points as
culled out definitely govern the field.
It binds all. The State is also bound to follow it. Therefore, in the case in hand, there is enough data
available which is appropriate as per the requirement of the Nagraj elements, though may not be
arithmetically accurate, but enough to continue the reservation policy.
The promotion circular providing only 33% reservation itself distinguishes the present case . The
factual clear-cut grievances are not on record.
163 In S. Panner Selvam and ors. v. State of Tamil Nadu 50, the Apex Court has observed as under :
20 While considering the validity of Section of Uttar Pradesh Public Services
(Reservation for Scheduled 49 (2012) 7 SCC 1 50(2015) 10 SCC 292 dgm 179
wp-2797-15 judgment-25-7-16.sxw Castes, Scheduled Tribes and Other Backward
Classes) Act, 1994, and Rule 8A of U.P. Government Servants Seniority Rules, 1991
which provided for consequential seniority in promotions given to SCs/STs by virtue
of rule of reservation/roster and holding that Section of the 1994 Act and Rule 8A of
1991 Rules are ultra vires as they run counter to the dictum in M. Nagaraj's case in
Uttar Pradesh Power Corporation Limited v. Rajesh Kumar and Ors. (2012) 7 SCC 1,
in paragraph (81), this Court summarized the principles as under:
(i) Vesting of the power by an enabling provision may be constitutionally valid and
yet "exercise of power" by the State in a given case may be arbitrary, particularly, if
the State fails to identify and measure the backwardness and inadequacy keeping in
mind the efficiency of service as required Under Article 335.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

(ii) Article 16(4) which protects the interests of certain sections of the society has to
be balanced against Article 16(1) which protects the interests of every citizen of the
entire society. They should be harmonized because they are restatements of the
principle of equality Under Article 14.
(iii) Each post gets marked for the particular category of candidates to be appointed
against it and any subsequent vacancy has to be filled by that category candidate.
(iv) The appropriate Government has to apply the cadre strength as a unit in the
operation of the roster in order to ascertain whether a given class/group is adequately
represented in the service. The cadre strength as a unit also ensures that the upper
ceiling limit of 50% is not violated.
Further, roster has to be post-specific and not vacancy based.
(v) The State has to form its opinion on the quantifiable data regarding adequacy of representation.
Clause (4-A) of Article 16 is an enabling provision. It gives freedom to the State to provide for
reservation in matters of promotion. Clause (4-A) of Article 16 applies only to SCs and STs. The dgm
180 wp-2797-15 judgment-25-7-16.sxw said clause is carved out of Article 16(4-A). Therefore, Clause
(4-A) will be governed by the two compelling reasons-"backwardness" and "inadequacy of
representation", as mentioned in Article 16(4). If the said two reasons do not exist, then the enabling
provision cannot be enforced.
(vi) If the ceiling limit on the carry over of unfilled vacancies is removed, the other alternative time
factor comes in and in that event, the timescale has to be imposed in the interest of efficiency in
administration as mandated by Article 335. If the timescale is not kept, then posts will continue to
remain vacant for years which would be detrimental to the administration. Therefore, in each case,
the appropriate Government will now have to introduce the duration depending upon the fact
situation.
(vii) If the appropriate Government enacts a law providing for reservation without keeping in mind
the parameters in Article 16(4) and Article 335, then this Court will certainly set aside and strike
down such legislation.
(viii) The constitutional limitation Under Article 335 is relaxed and not obliterated. As stated above,
be it reservation or evaluation, excessiveness in either would result in violation of the constitutional
mandate. This exercise, however, will depend on the facts of each case.
(ix) The concepts of efficiency, backwardness and inadequacy of representation are required to be
identified and measured. That exercise depends on the availability of data. That exercise depends on
numerous factors. It is for this reason that the enabling provisions are required to be made because
each competing claim seeks to achieve certain goals. How best one should optimize these conflicting
claims can only be done by the administration in the context of local prevailing conditions in public
employment.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

(x) Article 16(4), therefore, creates a field which enables a State to provide for reservation provided
there exists backwardness of a class and inadequacy of representation in dgm 181 wp-2797-15
judgment-25-7-16.sxw employment. These are compelling reasons. They do not exist in Article 16(1).
It is only when these reasons are satisfied that a State gets the power to provide for reservation in
the matter of employment.
21 In the light of the above, we shall consider the factual matrix and the rival contentions urged and
the purport of Rule 12 of Tamil Nadu Highways Engineering Service Rules.
37 In the result, the impugned judgment is set aside and these appeals are allowed. State
Government-Respondent Nos. 1 and 2 are directed to revise the seniority list of Assistant Divisional
Engineers applying the 'catch up rule' within four months. Pursuant to the impugned judgment of
the Division Bench of Madras High Court, if any further promotion had been granted to the
Assistant Divisional Engineers promoted from the rank of Junior Engineers following rule of
reservation with consequential seniority, the same shall be reversed. Further promotion of Assistant
Divisional Engineers shall be as per the revised seniority list.
The parties shall bear their own costs.
164 The Supreme Court judgments have also recognised the importance of reservation to Other
Backward Class but subject to the data. There is no total bar for the State to use and utilise it's
enabling power to provide Reservation to all the similarly placed class/group.
165 Most of the judgments cited by the contesting Respondents have been taken note of in this
decision. The point required to be noted is that the conclusion and the reason so given in all
Supreme dgm 182 wp-2797-15 judgment-25-7-16.sxw Court judgments are based upon the peculiar
factual matrix and the service rules. It is necessary for the Court to consider the factual matrix which
in the case in hand is missing. The Apex Court in S. Panner Selvam(supra), directed to revise the
seniority list and to apply 'catch up rule'. The principles/points which are reproduced in paragraph
20 are also reflected in Rajesh Kumar (supra).
The Tribunal has no jurisdiction to direct to frame rule/circular to change the service condition or
any policy and also bound by law of precedent ought not to have declared the Reservation
Act/Circular, bad in law. The Judicial decision to be taken when point for consideration on merit
arises before the Tribunal in service matters. In above cases, there was no order passed by the State
Tribunal under the Reservation Act. The Special Leave Petition against all above recent High Court's
Judgments are pending in Supreme Court .All above reasons culminated into following sequitur.
The appointments and promotions pending the issues need protection:
167 The learned Tribunal though declared the Reservation Act and the Circular bad in
law, its operation, however, postponed for one dgm 183 wp-2797-15
judgment-25-7-16.sxw year. This Court granted the stay of the judgment on
20/03/2015. It has been continuing till this date. Pending the issues/writ petitions,Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

the Supreme Court and this Court have granted interim reliefs, thereby permitted the
State/Department to proceed with the respective promotions even to the objected
classes. However, those are made subject to the final decision of these Petitions. The
appointments and promotions prior to the Tribunal's judgment and even thereafter
in view of above order passed by this Court as well as Supreme Court have been acted
upon by all concerned. As I am upholding the Reservation Act and the Promotion
Circular, the appointments and promotions made prior to the impugned Act and in
view of interim protection, based upon the interim reliefs, need to be regularised in
accordance with law. The promotions cannot be disturbed, it need to be protected.
This is also on the foundation of "Doctrine of Prospective Overruling" as the same is
also applicable to "service jurisprudence". [ B. A. Linga Reddy v. Karnataka State
Transport Authority, (2015) 4 SCC 514 and P. V. George v. State of Kerala, (2007) 3
SCC 557 ].
     dgm                             184 wp-2797-15 judgment-25-7-16.sxw
    CONCLUSIONS : 
    168             The   learned   Tribunal   has   exceeded   its   jurisdiction   by 
    holding   that     no   reservation   in   promotion   can   be   provided   to   any 
    backward   class   except   SC   and   ST.     It   is   wrong   to   hold   that   the 
reservation in DT/NT and SBC is in contravention of express constitutional
provisions. The reasoning by the learned Tribunal that even for SC, ST, there is no
quantifiable data available with the State to indicate that they are inadequately
represented in the services reflects the non-application of mind to the law as well as
the facts on record. There is ample material on record to justify action of State.
169 The Tribunal is wrong in holding that the Reservation Act is bad for want of
quantifiable data on the backwardness and adequacy of representation in respect of
any of the backward classes.Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

The Tribunal erred in law in holding that the Reservation Act does not disclose the basis on which
the percentage of reservation for different backward classes have been provided and further that the
decision of the State is arbitrary. These reasons and findings further disclose the wrong approach of
the Tribunal in view of the specific constitutional provisions and the percentage of reservation so
fixed and declared dgm 185 wp-2797-15 judgment-25-7-16.sxw from time to time even through the
then existing Circulars and Statutes, apart from the judgments of the Supreme Court. This is in the
background that earlier Circulars and Statues were never challenged including the percentage so
fixed and announced by the State since many years. The Tribunal has recognised the State's power
to provide reservation in Government service, but erred in law by holding that the law so made
includes every service provided even in the private sector and thereby violating Articles 13 and 16 of
the Constitution of India. This was again based upon the wrong reading of the law and no data or
material and/or specific challenge from such private service provider. In this process, the learned
Tribunal, wrong in holding that the State does not have any data regarding impact of reservation on
overall administrative efficiency. The burden was wrongly put upon the State on every points,
though the data and material have been placed on record, by misreading the provision of Evidence
Act and the law, . The learned Tribunal further overlooked the principle of creamy layer and the
specific protection so made including the circular of the State in this regard.
    170             Importantly, the Tribunal has exceeded its jurisdiction and 
     dgm                             186 wp-2797-15 judgment-25-7-16.sxw
erred in law, though by recording that the part of the Reservation Act may not be bad but declared
the whole Reservation Act and the Circular ultra vires. The Tribunal, in this process and for the
same reasons, declared the promotion circular bad in law, by misreading the same and by stating
that it is beyond the provision of Article 16(4- A). The Tribunal ought to have considered that every
caste percentage so fixed since so many years, based upon the material available with the State. The
constitutional provisions, if permit, apart from the recruitment, reservation in promotion to SC and
ST category at least those clauses ought not to have been declared bad in law. Similarly placed OBC
category and/or other backward category and its percentage so fixed again based upon the data and
the material ought not to have been declared bad in law for the same reason.
171 All the persons equally situated and as permissible, entitled the reservation in promotion also
based upon the data available. There was no reason to declare the Reservation Act and the Circular
bad in law. The excess reservation and/or percentage of particular category out of those already
declared could have been dgm 187 wp-2797-15 judgment-25-7-16.sxw tested on the fact basedBest Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

matter. The Tribunal's approach and the reasons to decide the validity of the Reservation Act and
the Circular without contra material and data, in our view, was contrary to the Constitutional
provisions, illegal and unsustainable in law. It is contrary to various Supreme Court Judgments so
referred earlier.
172 All the elements as discussed under the respective heading in this judgment left with no option
but to maintain the validity of the Reservation Act and Promotion Circular. All these State actions
are well within the constitutional frame work based upon the record and law. It's foundation is
based upon the unchallenged Statutes and Circular, at this stage, cannot be disturbed, unless and
until new reservation policy is announced and implemented. There is no total bar not to provide
such reservation at initial appointment/post or promotion stage, however, it is subject to the riders
and conditions as announced. No reservation policy in State itself is against the Constitution and the
law. The individual challenge may be tested on facts and circumstances. But there cannot be total
ban or bar to the State to provide such reservation. The Constitution itself empowers the State to do
so on the foundation of declared law.
dgm 188 wp-2797-15 judgment-25-7-16.sxw For one constitutional reservation policy, the political
spectrum may have different shades to follow. The importance of such facets need to be taken care
by the respective States, being the part of it's constitutional obligations, but within the constitutional
shades and sphere.
173 The Reservation policy and related issues have been seething since long. All the concerned need
to work wholeheartedly to settle it. The "Backwardness" and "the adequate representations"
are required to be taken into consideration first. Then comes the actual and physical
distribution of posts/seats cadre-wise or caste-
wise, or the department-wise of the concerned organisation and its requirement,
based upon the actual figures. The source of information and/or data is not in
challenge. There is even no special challenge to the "backwardness" and
"independent representation" so declared to the categories in question. The statute
need not be declared ultra virus for the Academic purposes. In the Democratic system
any reservation policy should have an egalitarian future.
174 The Reservation Act is valid and so also the Promotion dgm 189 wp-2797-15
judgment-25-7-16.sxw Circular. However, it is always subject to timely revision as and when
required, based upon the quantifiable data so collected.
175 The data with the State as available is determinable, surveyable, significant, quantitative and
measurable. It is unacceptable that it is non-quantifiable and non-contemporary. In Indra Sawhney
(supra) the issues were about reservation promotion and not about the reservation at recruitment
stage. The data so available of population as per the reservation policy includes the fixed percentage
since so many years. No-one has challenged the said reservation policy and/or percentage for want
of data at recruitment stage. In Nagraj (supra), the issue was of promotion in view of Articles 16(4A)Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

and (4B) read with other constitutional provisions. In the present case, the reservation in promotion
is only 33%. Therefore, on such self-destructive submission also no Reservation Act to be declared
bad in law.
176 Once the various doctrines of service jurisprudence are made applicable to the reservation in
promotion for "Other Backward Class", the equally placed person, being backward with no due dgm
190 wp-2797-15 judgment-25-7-16.sxw representation cannot be denied the reservation promotion
in service.
Once the creamy layer principle is extended to "OBC" or such related classes then only deserving
employee will get reservation promotion and not all, though they were initially appointed on
reservation basis.
177 The reservation for ST and SC even in promotion is permissible subject to rider of availability of
"contemporary and quantifiable data". The "contemporary and quantifiable data", in the present
case, as available, therefore, the Reservation Act and the Promotion Circular are valid.
178 The reservation for "Other Backward Classes" in recruitment and/or appointment stage is also
permissible. There is no specific challenge raised in this regard. The "contemporary and quantifiable
data" so placed on record are sufficient to maintain the State action, as such promotion was with
rider of "creamy layer" only for OBC classes.
179 To grant two percent more reservation at recruitment stage is the decision based on the
"contemporary and quantifiable dgm 191 wp-2797-15 judgment-25-7-16.sxw data" to provide
representation to the "declared backward classes"
with the rider of "creamy layer" is within the State's permissible power. The already
declared fifty percentage (50%) restriction, unless reduced, the State has no option,
but to increase such two percent without disturbing the existing reservation
percentage. In the present case, there is no excess percentage in promotion Circular
as total percentage is thirty three percent (33%). Therefore also, such reservation in
the promotion, in the present case, is within the legal frame work.
180 The cadre and/or department-wise promotion challenge may be considered separately, based
upon the actual facts and information placed by the aggrieved person, because of such reservation
policy. In these cases basic facts are missing.
181 Once the reservation is provided under the Statute/Circular, it cannot be taken away, including
the reservation in promotion. All the actions based upon the orders of the Supreme Court & the
High Court's are liable to be protected. The promotions so made are liable to be continued.
     dgm                             192 wp-2797-15 judgment-25-7-16.sxw
    182             The State to act in accordance with the law to collect fresh Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

data and revise the state reservation policy regularly.
183 In the result, the following order :
ORDER (1) Impugned judgment and order dated 28 November 2014 in Transfer
Application Nos. 1 & 2 of 2014, (transferred Writ Petition Nos. 8452/2004 &
470/2005 on 18 June 2013) by The Maharashtra Administrative Tribunal (MAT) is
quashed and set aside.
(2) The Reservation Act is valid. However, subject to timely revision.
(3) The Promotion Circulars are valid. However, subject to timely revision.
(4) The appointments and promotions so made prior to the Reservation Act and the
Promotion Circular and pending the Writ Petitions, based upon the interim orders
passed by the Supreme Court as well as this Court be finalised/regularised in
accordance with law.
(5) Appellate Side Writ Petition Nos. 2797/2015, 3009/2015 and Original Side Writ
Petition No.1590/2015 are allowed accordingly.
(6) In view of above, Writ Petition No. 3287/2004 is disposed of as the validity of the
Reservation Act and the Promotion Circulars is upheld and all so actions dgm 193
wp-2797-15 judgment-25-7-16.sxw arising out of it. However, the fact based challenge
to the Promotion/seniority List would be considered along with other
Corporation/Undertaking matters independently on and updated averments, if such
fact based fresh challenge is made.
(7) In view of disposal of Writ Petitions, Civil Application Nos. 161/2016,
CAW/2301/15 and CAW/2531/2015 in Writ Petition No.2797/2015 stand disposed
accordingly.
(8) There shall be no order as to costs.
(A. A. SAYED, J.) (ANOOP V. MOHTA, J.) Inasmuch as A. A. Sayed, J. is unable to
agree with some of the views and the findings in the aforesaid judgment, he will be
writing a separate judgment.
       (A. A. SAYED, J.)                               (ANOOP V. MOHTA, J.)Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

Best Officers Association vs The State Of Maharashtra And Ors on 26 July, 2016

