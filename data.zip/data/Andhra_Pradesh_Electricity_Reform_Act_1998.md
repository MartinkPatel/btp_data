Andhra Pradesh Electricity Reform Act, 1998
ANDHRA PRADESH
India
Andhra Pradesh Electricity Reform Act, 1998
Act 30 of 1998
Published on 19 May 1998• 
Not commenced• 
[This is the version of this document from 19 May 1998.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
An act to Provide for the Constitution of an Electricity Regulatory Commission, Restructuring of the
Electricity Industry, Rationalisation of the Generation, Transmission, Distribution and Supply of
Electricity Avenues for Participation of Private Sector in the Electricity Industry and Generally for
Taking Measures Conducive to the Development and Management of the Electricity Industry in an
Efficient, Economic.And Competitive Manner and Formatters connected therewith or incidental
thereto.Be it enacted by the Legislative Assembly of the State of Andhra Pradesh in the Forty-ninth
Year of the Republic of India, as follows:PART-I PRELIMINARY
1. Short title extent and commencement
(1)This Act may be called the Andhra Pradesh Electricity Reform Act, 1998.(2)It extends to the
whole of the State of Andhra Pradesh(3)It shall come into force on such date as the State
Government may, by notification, appoint.
2. Definitions
In this Act, unless the context otherwise requires,(a)area of transmission means the area within
which the holder of a transmission licence is for the time being authorised by licence to transmit
energy in accordance with the conditions prescribed;(b)APTRRHSCO means the Transmission
Corporation of Andhra Pradesh Limited incorporated as a transmission company under the
Companies Act, 1956 (Central Act 1 of 1956) and as referred to in section 13 of this
Act.(c)Commission means the Andhra Pradesh Electricity Regulatory Commission constituted
under sub-section (1) of section 3:(d)licence means a licence granted under section 15 of this
Act;(e)licensee or licence holder means a, person licensed under section 14 of the Act to transmit or
supply energy including APTRAHSCO;.(f)member or members means the members of the
Commission and shall include the Chairman of the Commission;(g)notification means a notification
published in the Andhra Pradesh Gazette and the word notified shall be construed
accordingly.(h)prescribed means prescribed by the rules or regulations made under thisAndhra Pradesh Electricity Reform Act, 1998

Act;(i)regulations means regulations made by the Commission under this Act;(j)rules means rules
made by the State Government under this Act;(k)selection committee means the selection
committee constituted under section 4 of this Act;(l)State means the State of Andhra
Pradesh;(m)State Government means the Government of the State;(n)supply licence means a
licence under sub-section (1)(b) of section 15;(o)transmission licence means a licence under
sub-section (1)(a) of section 15;(p)transmit in relation to electricity, means the transportation of
transmission of electricity by means of a system operated or controlled by a licensee, which consists,
wholly or mainly, of extra high voltage and extra high tension lines and electrical plant and is used
for transforming and for conveying and/or transferring electricity from a generating station to a
sub-station, from one generating station to another or from one sub-station to another or otherwise
from one place to another;(q)words and expressions used but not defined in this Act and defined in
the Electricity (Supply) Act, 1948 (Central Act 54 of 1948) have the meanings respectively assigned
to them in that Act.(r)words and expressions used but not defined either in this Act or in the
Electricity (Supply) Act, 1948 (Act No. 54 of 1948) and defined in the Indian Electricity Act, 1910
(Act No. IX of 1910) have the meanings respectively assigned to them in that Act.PART-II
ANDHRA PRADESH ELECTRICITY REGULATORY COMMISSION
3. Establishment and constitution of the Commission
(1)For the purposes of this Act, within three months of the Act coming into force, the State
Government shall establish by notification a Commission to be known as the Andhra Pradesh
Electricity Regulatory Commission, which shall be a body corporate with perpetual succession and a
common seal with power to acquire and hold property, movable and immovable, and shall, by the
said name, be entitled to sue and be sued.(2)The Commission shall consist of a Chairman and two
members to be appointed by the State Government from persons selected by the selection
committee constituted for the purpose, in the manner provided in section 4 of this Act. The State
Government shall specifically designate one of the three members as the Chairman. The
inter-se-seniority of the other two members shall be indicated in the orders of
appointment.(3)When the Chairman of the Commission is unable to discharge the functions owing
to absence, illness or any other cause, the next senior member of the Commission shall discharge the
functions of the Chairman, until the day on which the Chairman assumes office.
4. Constitution of the selection committee to select members
(1)The State Government shall expeditiously constitute a selection committee, as often as may be
required to select persons for appointment as members of the commission, which shall consist of the
following, namely;(i)a retired Chief Justice of any High Court or a retired judge of the Supreme
Court. Chairman(ii)Chief Secretary to the Government of Andhra Pradesh. Member(iii)the
Chairman of the Central Electricity Authority. Member(2)The Secretary in-charge of the Energy
Department, Government of Andhra Pradesh shall be the Convenor for the above Selection
Committee(3)The selection committee shall call for nominations from general public and from
professional bodies, consumer organisations by giving wide publicity, so as to act expeditiousloy and
shall generally finalise the selection within a period of three months to enable the State Government
to make the final selection and appointment in time for the new member to take charge at the expiryAndhra Pradesh Electricity Reform Act, 1998

of the term of the retiring member:Provided that the selection of the members shall not be restricted
to the nominations received.(4)The selection committee shall submit the panel of two suitable
persons for each vacancy in the Commission who have such qualification and experience as
provided in the Act, to the State Government in alphabetical order from among whom the State
Government shall appoint one of the two as a member of the Commission.(5)All decisions of the
selection committee shall be by majority(6)The method and manner of the selection and
appointment of members and designation of one of the members as Chairman of the Commission
shall be as prescribed by the State Government.
5. Conditions for appointment as member of the commission
(1)The members of the Commission shall be persons of ability, integrity and standing who have
adequate knowledge or experience of, or have shown capacity in dealing with problems relating to
engineering, economics, commerce, finance, accountancy, law or administration and that at all
times the selection and appointment shall be made in accordance with the qualifications and
experience specified below:(i)one member shall be a graduate electrical engineer with adequate
experience in generation or transmission or distribution of electricity;(ii)two members shall have
graduate qualification with specialisation and adequate experience in any of the disciplines like law,
economics, commerce, finance, accountancy or administration:Provided that at any point of time
the Commission shall not consist of more than one member from the same discipline:Provided
further that persons below the age of fifty five years shall not be eligible for appointment as
chairman or member, as the case may be.(2)A person shall be disqualified from being appointed a
member of the Commission if he is a member of Parliament or of any State Legislative Assembly or
any local authority or holds any post in a political party or if he has any financial or other interest,
directly or indirectly, in any private company or undertaking dealing with any of the business
referred to in clause (a) of sub-section (3) subject to the conditions specified in sub-section
(5).(3)The persons who are considered for appointment as members of the Commission shall
intimate the convenor of the selection committee,(a)of any office, employment or consultancy
agreement or arrangement which he has in his own name or in any firm, association of persons or
body corporate, or in the names of any relative, carrying on any of the following businesses
namely:(i)generation, transmission, distribution or supply of electricity;(ii)manufacture, sale or
supply of any fuel for generation of electricity;(iii)manufacture, sale, lease, hire or otherwise; supply
of or dealing in machinery, plant, equipment, apparatus or fittings for the generation, transmission,
distribution, supply or use of electricity; and(iv)any entity providing professional services to any of
the businesses referred to in sub-clauses (i), (ii) and (iii) above;(b)such other details and
information as may be prescribed in the rules.Explanation: For the purpose of this section the term
relative shall have the same meaning as defined under section 6 of the Companies Act, 1956.
(Central Act 1 of 1956)(4)The details received from the persons shall be placed for consideration of
the selection committee at the time of selection and recommendation of the person for appointment
as member.(5)Each member of the Commission shall, before taking charge of the office as member
or within such time not exceeding three months after taking charge as may be allowed by the State
Government on the recommendation of the section committee, divest himself from the interest in
the businesses mentioned in sub-section (3) of this section as a condition of his appointment.(6)If a
person to be appointed as a member of the Commission holds any office under the State or CentralAndhra Pradesh Electricity Reform Act, 1998

Government or any public sector corporation or any Government body, he shall submit his
resignation or take voluntary retirement from that service and shall not seek reappointment in the
service of the Stat Government or any Government corporation or body dealing with the power
sector in Andhra Pradesh at any time within a period of two years after he ceases to be a member of
the Commission.(7)So long as the person holds the office of the member and for a period of two
years after he ceases to be a member for any reason whatsoever, he shall not acquire hold or
maintain, directly or indirectly any office, employment or consultancy arrangement or businesses
mentioned in sub-section (3) of this section within or outside the State and if he acquires any such
interest involuntarily or by way of succession or testamentary disposition he will divest himself from
such interest within a period of three months of such interest being acquired.(8)Before
recommending any person as a member of the Commission, the selection committee shall satisfy
itself that the person does not have any financial or other interest as referred to in sub-section (3) or
otherwise which is likely to affect prejudicially his functions as a member.
6. Term of office, conditions of service, etc., of members
(1)Every member shall hold office for a period of five years from the date of his appointment as
member or until the age of sixty-five years, whichever is earlier and he shall not be eligible for
re-appointment at any time after the expiry of his term of appointment:Provided that a member
shall be eligible for appointment as Chairman subject to his combined tenure in the Commission as
Member and Chairman shall not exceed five years:Provided further that the first three members
shall be appointed for varying periods of three years, four years and five years respectively so as to
avoid the retirement of all the members at the same time and ensure continuity in the functioning of
the Commission;Provided also that no person shall be appointed as member after he has attained
the age of sixty two years so that he has a minimum tenure of three years as member.(2)The
Chairman of the Commission and other members shall receive such remuneration and other
allowances as may be prescribed from time to time under the rules:Provided that the terms shall not
be varied to their disadvantage during the tenure of the appointment.(3)The Chairman of the
Commission and every other member shall before entering upon his office, make and subscribe to
an oath of office and of secrecy in such form, in such manner and before such authority as may be
prescribed.
7. Removal of Member
(1)The Stats Government may remove from office any member of the Commission in accordance
with sub-section (2), who,(a)has been adjudged as un-discharged insolvent; or(b)has been convicted
of an offence involving moral turpitude; or(c)has become physically or mentally incapable of acting
as such member; or(d)has without reasonable cause refused or failed to discharge his functions for a
period of at least three months; or(e)ceases to fulfil any of the conditions of his appointment as
member; or(f)has acquired such financial or other interest that can affect prejudicially his functions
as a member; or(g)has conducted himself in a manner or had so abused his position as to render his
continuance in office prejudicial to the public interest or to the objects and purpose of the
Act.(2)Except where a member admits the charge, in writing, no member of the Commission shall
be removed from his office on the grounds specified in clauses (c), (d), (e), (f) and (g) of sub-sectionAndhra Pradesh Electricity Reform Act, 1998

(1) until a sitting judge of the High Court of Andhra Pradesh, as recommended by the Chief Justice
of the High Court at the relevant time, has carried out an enquiry and has forwarded a report to the
State Government.(3)The State Government shall act in accordance with the recommendation in the
final report under sub-section (2) and the State Government shall communicate its decision to the
member concerned within a period of two months of the receipt of such report.(4)A member who
has been removed shall not be eligible for re-appointment as a member or in any other capacity in
the Commission or in the State Government or in any state Government undertakings.(5)If the
member removed under this section is the Chairman of the Commission, he shall cease to be the
Chairman of the Commission.(6)The vacancy, caused by the removal of the member shall be filled in
the same manner as provided for the appointment of a member or designation of the Chairman of
the Commission.
8. Appointment of the Secretary, Staff and Consultants of the Commission
(1)The Commission shall appoint a person as Secretary of the Commission to assist the Commission
to discharge its functions(2)The Commission shall, in consultation with the State Government
determine the number, nature and categories of other officers and employees required to assist the
Commission in the discharge of its functions.(3)The salaries and allowances payable to the members
and the administrative expenses, including, salaries, allowances and pensions payable to or in
respect of the Secretary, officers and other employees of the Commission, shall be charged to the
Consolidated Fund of the State;(4)The method and manner of selection of the Secretary, officers and
other employees and the terms and conditions of their service may be prescribed by the Commission
by regulations with prior approval of State Government.(5)The Commission shall be entitled to
appoint, from time to time consultants required to assist the Commission in the discharge of its
functions on terms and conditions to be decided by the Commission.PART-III PROCEEDINGS,
POWERS AND FUNCTIONS OF THE COMMISSION
9. Proceedings, powers and functions of the Commission
(1)The headquarters of the Commission shall be at Hyderabad in the State, but the Commission
shall be entitled to conduct its proceedings, consultations and hearings at any place in the
State.(2)The Commission shall alone have the exclusive power to make regulations for the conduct
of its proceedings and discharge of its functions and all such regulations framed shall be published
in the Official Gazette.(3)All decisions of the Commission shall be on the basis of majority of the
Members present and voting.(4)The quorum for the meeting of the Commission shall be two and
each member shall have, one vote and in case of equality of votes on any issue or resolution, the
Chairman or as the case may be the next senior member of the Commission discharging the
functions of the Chairman under sub-section (3) of section 3 presiding over the meeting shall, in
addition, have a casting vote:Provided that for a meeting of the Commission to review any previous
decision taken, by the Commission, the quorum shall be that all members shall be present.(5)The
Chairman of the Commission may instruct the Secretary;to call for a meeting of the Commission to
be held at such time and at such place as the Chairman may direct. In addition, any member of the
Commission may request a meeting of the Commission at any time by sending a notice in writing to
the other members under intimation of such notice to the Secretary. The notice of all meetings shallAndhra Pradesh Electricity Reform Act, 1998

be given to the members in writing, unless all the members waive the notice in writing.(6)The
Commission shall be entitled to decide urgent matters by circulation of the papers to
members.(7)All decisions, directions and orders of the Commission shall be in writing and shall be
supported by reasons. The decisions, directions and orders of the Commission shall be available for
inspection by any person and copies of the same shall also be made available in a manner the
Commission may prescribe.(8)No act or proceeding of the commission shall be deemed invalid by
reason only of some defect in the constitution of the Commission or by reason of the existence of a
vacancy or vacancies among its members.
10. Powers of the Commission
(1)The Commission shall, for the purposes of any inquiry or proceedings under this Act shall have
the powers as are vested in a Civil Court under the Code of Civil Procedure, 1908, (Central Act 5 of
1908) while trying a suit in respect of the following matters, namely:(a)the summoning and
enforcing of attendance of any witness and examining on oath;(b)the discovery and production of
any document or other material object producible as evidence;(c)the reception of evidence on
affidavits;(d)the requisition of any public record from any court or office;(e)the issue of commission
for examination of witnesses;(f)the appearance of parties and consequences of
non-appearance;(g)the grant of adjournments at the hearing.(2)The Commission shall have the
power to require any person,(a)to produce before, and allowed to be examined and kept by an
officer of the Commission specified in this behalf, such books, accounts, or other documents in the
custody or under the control of the person so required as may be specified or described in the
requisition, being documents relating to any matter concerning the generation, transmission,
distribution and supply or use of electricity, the functioning of any undertaking involved in the
above areas and other matters, the examination of which the Commission considers necessary or
relevant for the purposes of this Act or the discharge of the functions by the Commission under this
Act; and(b)to furnish to an officer so specified such information as cay be required for the purposes
of this Act or such other information as may be in his possession in relation to any activity carried
on by any other person.(3)For the purpose of enforcing the attendance of witnesses the local limits
of the jurisdiction of the Commission shall be the limits of the territory of India.(4)The Commission
shall have the powers to review its decisions, directions and orders.(5)Where, during any inquiry or
proceedings under this Act, the Commission has any grounds to believe that any books or papers or
documents of, or relating to any unit or person in relation to which such inquiry is being made or
which the owner of such unit may be reguired to produce in such inquiry, are being, or may be
destroyed, mutilated, altered, falsified or secreted, it may, by a written order authorise any officer of
the Commission to exercise the powers of entry, search and seizure as may be exercised by an
Inspector appointed for inspection under sections 240 and 240-A of the Companies Act, 1956.
(Central Act 1 of 1956)(6)Notwithstanding anything contained in any other law for the time being in
force, the Commission may, by a general or special order, call upon any person including the
generating companies or the licensees to furnish to the Commission periodically or as and when
required any information concerning the activities carried on by such person related to generation,
transmission, distribution and supply or use of electricity, the connection between such person and
any other person or undertaking including such other information relating to the organisation,
business, cost of production and other requirements as may be prescribed to enable the CommissionAndhra Pradesh Electricity Reform Act, 1998

to carry out its functions under this Act.(7)In the discharge of its function the Commission shall be
entitled to and shall consult to the extent the Commission considers appropriate from time to time
such persons or group of persons who may be affected or are likely to be affected by the decisions of
the Commission.(8)To exercise the powers conferred under this section to call for information,
details, books, accounts and other documents from any person and make inquiry for the purposes of
providing the same to the Central Electricity Authority, the Central Government, the State
Government or other persons. The Central Electricity Authority, the Central Government and the
State Government shall be entitled to ask the Commission to make such inquiry and provide the
information, details and documents to them.(9)All persons to whom notices may be issued shall
have a statutory obligation under this Act to duly, faithfully and effectively furnish the information,
details, books, accounts and other documents, which the Commission considers relevant in
connection with its functions under this Act or which may be required to be obtained at the instance
of the Central Electricity Authority, the Central Government or the State Government as the case
may be and shall be proceeded with and punishable for any failure or delay to comply with such
requirements and the directions and orders issued by the Commission.(10)Notwithstanding
anything contained in sections 12 to 16 and sections 18 and 19 of the Indian Electricity Act, 1910,
(Act No. IX of 1910) for the placing of the electric supply lines, appliances and apparatus for
transmission, distribution and supply of energy, the Commission may, by order in writing confer
upon licensees or any other person engaged in the business of transmission, distribution or supply
of energy to the public under the Act, subject to such conditions and restrictions as the Commission
may provide, any of the powers which the telegraph authority possess under the Indian Telegraph
Act, 1885 (Act XIII of 1885) with respect to placing of telegraph lines and posts.
11. Functions of the Commission
(1)Subject to the provisions of this Act, the Commission shall be responsible to discharge amongst
others, the following functions, namely:(a)to aid and advise, in matters concerning electricity
generation, transmission, distribution and supply in the State;(b)to regulate the working of the
licensees and to promote their working in an efficient, economical and equitable manner including
laying down standards of performance for the licensees in regard to services to consumers;(c)to
issue licences in accordance with the provisions of this Act and determine the conditions to be
included in the licences;.(d)to promote efficiency, economy and safety in the use of the electricity in
the State including and in particular in regard to quality, continuity and reliability of service and
enable to meet all such reasonable demands for electricity;(e)to regulate the purchase, distribution,
supply and utilisation of electricity, the quality of service, the tariff and charges payable keeping in
view both the interest of the consumer as well as the consideration that the supply and distribution
cannot be maintained unless the charges for the electricity supplied are adequately levied and duly
collected;(f)to promote competitiveness and progressively involve the participation of private sector,
while ensuring fair deal to the customers;(g)to collect data and forecast on the demand and use of
electricity and to require the licensees to collect such data and forecast;(h)to require licensees to
formulate perspective plans and schemes in co-ordination with others for the promotion of
generation, transmission, distribution and supply of electricity;(i)to regulate the assets, properties
and interest in properties concerning or related to the electricity industry in the State;(j)to lay down
a uniform system of accounts among the licensees;(k)to regulate working of licensees and promoteAndhra Pradesh Electricity Reform Act, 1998

their working in an efficient economical and equitable manner; and(1)to undertake all incidental or
ancillary things.(2)The Commission shall always act consistent with the objectives and purposes for
which the Commission has been established as an independent statutory body Corporate and all
acts, decisions and orders of the Commission shall be pursuant to and shall seek to achieve such
objectives and purposes.(3)Notwithstanding the provisions, of section 52 of the Indian Electricity
Act, 1910 (Central Act IX of 1910) or the provisions of section 3(1)(ii) and section 76 of the
Electricity (supply) Act, 1948, (Central Act 54 of 1948) the Commission shall have the power to act
as arbitrator or nominate arbitrator or arbitrators to adjudicate and settle the disputes arising
between the licenses in accordance with the regulations to be prescribed and this shall be a
condition precedent of the grant of licences.PART-IV POWERS OF THE STATE
GOVERNMENT
12. General powers of the State Government
(1)The State Government shall have the power to issue policy directions on matters concerning
electricity in the State including the overall planning and co-ordination. All policy directions shall be
issued by the State Government consistent with the objects sought to be achieved by this Act and
accordingly shall not adversely affect or interfere with the functions and powers of the Commission
including but not limited to determination of the structure of tariffs for supply of electricity to
various classes of consumers:(2)If any dispute arises between the Commission and the State
Government as to whether or not a question is a matter of policy or whether a policy direction issued
by the State Government adversely, affects or interferes with the exercise of the functions of the
Commission, the same shall be referred by the State Government to a retired judge of the Supreme
Court in consolation with the Chief Justice of the Supreme Court whose decision thereon shall be
final and binding.(3)The State Government shall be entitled to issue policy directions concerning the
subsidies to be allowed for supply of electricity to any class or classes of persons or in respect of any
area in addition to the subsidies permitted by the Commission while regulating and approving the
tariff structure provided that the State Government shall contribute the amount to compensate such
concerned body or unit affected by the grant of the subsidies by the State Government to the extent
of the subsidies granted. The Commission shall determine the amounts and the terms and
conditions and time frame on which such amounts are to be paid by the State Government.(4)The
State Government shall consult the Commission in relation to any proposed legislation or rules
concerning any policy direction and shall duly take into account the recommendation by the
Commission on all such matters.PART-V APTRANSCO
13. Constitution and functions of the APTRANSCO
(1)Not later than sixty days of the Act coming into force the State Government shall constitute
APTRANSCO to be incorporated and organised under the provisions of the Companies Act, 1956
(Central Act 1 of 1956) as the Transmission Corporation of Andhra Pradesh Limited, with the
principal objects of engaging in the business of procurement, transmission and supply of electric
energy.(2)Subject to the powers of the State Government under section 12, the APTRANSCO
established by the State Government in terms of sub-section (1) shall be the principal company to
undertake all planning and co-ordination in regard to transmission; undertaking the worksAndhra Pradesh Electricity Reform Act, 1998

connected with transmission, determining the electricity requirements in the State in co-ordination
with the Generating companies. State Government, the Commission, the Regional Electricity
Boards, and the Central Electricity Authority; the operation of the power system.(3)APTRANSCO
shall own the extra high voltage transmission system, shall be responsible for the transmission
system operation and shall operate the power system in an efficient manner.(4)APTRANSCO shall
undertake the functions specified in this section and such other functions as may be assigned to it by
the licence to be panted to it by the Commission under this Act.(5)Upon the grant of licence to the
APTRANSCO under clause (a) of sub-section (1) of section 15 of this Act, the APTRANSCO shall
discharge such powers and perform such duties and functions of the Andhra Pradesh State
Electricity Board including those under the Indian Electricity Act, 1910 and the Electricity (Supply)
Act, 1948 or the rules framed thereunder as the Commission may specify in the licence and it shall
be the statutory obligation of the APTRANSCO to undertake and duly discharge the powers, duties
and functions so assigned.(6)Subject to the provisions of sub-sections (1) and (2) and to the overall
supervision and control of the APTRANSCO a number of subsidiary or associated transmission
companies may be established in the State and the Commission may grant licences under the terms
of this Act to such transmission companies, in consultation with the APTRANSCO.PART-VI
LICENSING OF TRANSMISSION AND SUPPLY
14. Licensing
(1)No person, other than those authorised to do so by licence or by virtue of exemption under this
Act or authorised to or exempted by any other authority under the Electricity (Supply) Act, 1948,
shall engage in the State in the business of(a)transmitting electricity; or(b)supplying
electricity,(2)Where any difference of dispute arises as to whether any person is engaged or is not
engaged or about to engage in the business of transmitting or supplying electricity as specified in
sub-section (1), the matter shall be referred to the Commission and the decision of the Commission
shall be final.(3)The Commission shall have the power to order any unlicensed person to cease
operating and disconnect its apparatus.(4)Notwithstanding anything contained in any other
provisions of this Act and until the establishment of the Commission in terms of section 3, the State
Government shall have the power to grant provisional licences under this section having a duration
not exceeding twelve months to any person or persons to engage in the state in the business of
transmission or supply of electricity on such terms and conditions as the State Government may
determine consistent with the provisions of this Act, subject to the following conditions,
namely:(a)upon the establishment of the Commission, each of the provisional licences granted by
the State Government shall be placed before the Commission and shall be deemed to constitute an
application for grant of a licence by the Commission under the provisions of this Act; and(b)each
provisional licence granted under this section shall cease to be valid from the date notified by the
Commission.(5)The State Government, shall be entitled to confer on the provisional licensees under
sub-section (4) such powers, rights and authorisation as the Commission is entitled to grant to the
licensees under this Act.Andhra Pradesh Electricity Reform Act, 1998

15. Grant of licences by the Commission
(1)The Commission may on an application made in such form and on payment of such fee, as may
be prescribed, grant a licence authorising any person to,(a)transmit electricity in a specified area of
transmission; or(b)supply electricity in a specified area of supply including bulk supply to licensees
or any person.(2)In respect of the grant of any such licence the following procedure shall be followed
namely:(a)any person applying for a licence shall publish a notice of his application in such manner,
and with such particulars as may be prescribed by the Commission within 14 days after waking the
application;(b)the commission shall not grant a licence until,(i)all objections received relating to the
application for the licence have been considered by the Commission; provided that no objection
shall be considered by the Commission unless it is received within three months of the date of the
first publication of the notice under clause (a) above; and(ii)in the case of an application for a
licence to supply or transmit in an area which includes, the whole or part of any cantonment,
aerodrome, fortress, arsenal, dockyard or camp or of any building or place in the occupation of the
Central Government for defence purposes, the Commission shall ascertain whether there is any
objection to the grant of the licence on the part of the Central Government;(c)where an objection is
received from any local authority concerned, the Commission shall, if in its opinion the objection is
insufficient, record in writing and communicate to such local authority its reasons for such opinion;
and(d)no application for a licence shall be made by any local authority except pursuant to a
resolution passed at a meeting of such authority held after one month's previous notice of the same
specifying the purpose thereof has been given in the manner in which notices of meetings of such
local authority are usually given.(3)A licence shall prescribe the duration, extent to which and the
terms and conditions under which the transmission or supply of energy is to be made and contain
such other conditions as the Commission may consider appropriate for achieving the purposes of
the Act.(4)Without prejudice to the generality of sub-section (3), the conditions included in a licence
by virtue of that sub-section may require the licensee to,(a)enter into agreements on specified terms
with other persons for the use of any electric lines, electrical plant or plants and associated
equipment operated by the licensee;(b)comply with any direction given by the Commission;(c)act in
accordance with the terms of the licence;(d)refer all disputes arising under the licence for
determination by the Commission;(e)furnish information, documents and details which the
Commission may require for its own purpose or for the purposes of the Central or State Government
or Central Electricity Authority;(f)comply with the requirements of the India Electricity Act, 1910
and the Electricity (Supply) Act, 1948 or rules framed thereunder in so far as they are
applicable;(g)undertake such functions and obligations of the Andhra Pradesh State Electricity
Board under the provisions of the Indian Electricity Act, 1910 and the Electricity, (Supply) Act, 1948
as the Commission may prescribe;(h)obtain the approval of the Commission of such things that are
required under the licence conditions or for deviation from the same;(i)notify the Commission of
any schene that he is proposing to undertake including the schemes in terms of the provisions of the
Electricity (Supply) Act, 1948;(j)purchase power in an economical manner and under a transparent
power purchase process; and(k)supply in bulk to other licensees or to customers.(5)Without
prejudice to the generality of sub-section (3), the conditions included in a licence granted by the
Commission may require the holder of such a licence to establish a tariff or to calculate its charges
from tine to time in accordance with the requirements prescribed by the Commission.(6)The
provisions contained in the Schedule to the Indian Electricity Act, 1910 shall be deemed to beAndhra Pradesh Electricity Reform Act, 1998

incorporated with, and to form part of every supply licence granted under this Part save in so far as
they are expressly varied or excepted by the supply licence and shall, subject to any such additions,
variations or exceptions which the Commission is empowered to make having regard to the
purposes of the Act, apply to the undertaking authorised by the licence in relation to its activities in
the State;Provided that where a supply licence is granted by the Commission for the supply of
energy to other licensees for distribution by them, then in so far as such licence relates to such
supply, the provisions of clauses IV, V, VI, VII, VIII and XII of the said Schedule shall not be
deemed to be incorporated within the supply licence.(7)The conditions included in a licence may
contain provision for the conditions to cease to have effect or be modified at such tines, in such
manner and in such circumstances as may be specified in or determined by or under the
conditions.(8)Any provisions included by virtue of sub-section (7) above in a licence shall have effect
in addition to the provision made by sub-section (5) of section 18 and section 19 with respect to the
amendment of the conditions of a licence.(9)Unless indicated in the terms of a licence, the grant of a
licence under this section to a person shall not in any way hinder or restrict the grant of a licence to
another person within the same area of supply for a like purpose and accordingly the licensee shall
not claim any exclusivity.(10)The licence granted by the Commission in terms of this Act may
provide that the licensee shall have the powers and authority to take appropriate actions for revenue
realisation prosecution for theft, meter tampering, diversion of electricity, and all such and similar
matters affecting the distribution and supply of electricity to the consumer.(11)The Commission
shall be entitled to authorise the licensees and persons to exercise such power and authority as the
licensees and persons could be given under the provisions of the Indian Electricity Act, 1910 and the
Electricity (Supply) Act, 1948.
16. Exemptions from the requirement to have a licence
(1)The Commission may make regulations to grant exemption from the requirement to have a
supply licence, but subject to compliance with such conditions if any, as may be specified in the
order;Provided that the Commission shall not, under any such regulation grant any exemption
except with the consent,(i)of the local authority, if any, constituted in the area where energy is to be
supplied;(ii)in any case where energy is to be supplied in any area forming part of any cantonment,
aerodrome, fortress, arsenal, dockyard or camp or any building or place in the occupation of the
Central Government for defence purposes, of the Central Government;(iii)in any area falling within
the area of supply of a licensee, of that licensee:Provided that, except in a case falling under clause
(ii) no such consent shall be necessary if the Commission is satisfied that such consent has been
unreasonably withheld.(2)An exemption may be granted,(a)to persons of a particular, category;
or(b)to a particular person; or(c)for a particular period;and an exemption to persons of a particular
category or to a particular person shall be published in such manner as the Commission considers
appropriate for bringing it to the attention of that person or persons of that category and of the
public in general.(3)The exemption granted may be revoked by the Commission at any time for
reasons to be recorded in writing.(4)An exemption, unless previously revoked, shall continue in
force for such period as may be specified in or determined by or under the exemption.(5)Every
regulation or exemption made by the Commission under this Act shall be published in the Official
Gazette.Andhra Pradesh Electricity Reform Act, 1998

17. General Duties and Powers of the licensces
(1)It shall be the duty of the holder of a supply licence or a transmission licence in respect of a
particular area to develop, maintain and provide to the consumers or the licensees as the case may
be or any other person an efficient, co-ordinated and economical system of electricity supply or
transmission in the area of transmission or area of supply, as the case may be.(2)Each licensee and
Generating Company in discharge of its duties shall comply with the provisions of the regulations
framed from time to time governing the terms and conditions for the operation and maintenance of
power system and electric supply lines.(3)Subject to sub-section (4) of section 12 and sections 13 to
19 of the Indian Electricity Act, 1910 (Which relate, to the carrying out of works) shall have effect in
relation to a person authorised by a licence under this Act to transmit or supply electricity as if he is
a licensee in that Act.(4)Where any of the sections mentioned in sub-section (3) above is applied to a
licence holder by his licence, it shall have effect subject to such restrictions, exceptions and
conditions as may be included in the licence.
18. Revocation of licences
(1)The Commission may inquire into the conduct or functioning of any licensee in carrying out the
obligations under the Act or rules or regulations framed thereunder or the terms and conditions of
its licence,(a)upon receiving a complaint from any consumer or consumer association or any trade
association; or(b)upon a reference made to it by the State Government or by the Central
Government or the Central Electricity Authority; or(c)upon receiving a complaint from any
company or person involved in the generation, transmission, distribution or supply of electricity;
or(d)upon its own knowledge or information derived front any source.(2)Upon making such inquiry
the Commission may, if in its opinion the public interest so requires, revoke a licence in any of the
following cases, namely:(a)where the licensee, in the opinion of the Commission, has committed a
wilful or unreasonable default in doing anything required of him by or under this Act, the Indian
Electricity Act, 1910, or the Electricity (Supply) Act, 1948, or rules made thereunder to the extent
applicable in the State read with the provisions of this Act;(b)where the licensee commits a breach of
any of the terms and conditions of his licence the breach of which is expressly declared by such
licence to render it liable to revocation.(c)where the licensee fails within the period specified in his
licence or any longer period which the Commission may allow by order,(i)to show, to the satisfaction
of the Commission, that he is in a position to fully and efficiently discharge the duties and
obligations imposed on him by his licence; and(ii)to make the deposit or furnish the security
required by his licence; and(d)where in the opinion of the Commission the financial position of the
licensee is such that he is unable to fully and efficiently discharge the duties and obligations imposed
on him by his licence.(3)Notwithstanding the provisions of sub-sections (1) and (2) where in its
opinion the public interest so requires, the Commission nay, on the application or with the consent
of the licensee, and if the licensee is not a local authority, after consulting the local authority
concerned, if any, revoke a transmission or supply licence as to the whole or any part of the area of
transmission or supply upon such terms and conditions as it thinks fit.(4)No licence shall be
revoked under sub-section (2) or (3) unless the Commission has given to the licensee not less than
three months notice in writing stating the grounds on which it is proposed to revoke the licence and
has considered any cause shown by the licensee within the period of that notice, against theAndhra Pradesh Electricity Reform Act, 1998

proposed revocation and has given reasons for such revocation.(5)The Commission may, instead of
revoking the licence, permit it to remain in force subject to such further terms and conditions as it
thinks fit to impose and any further terms or conditions so imposed shall be binding upon, and be
observed by, the licensee, and be of like force and effect as if they were contained in the licence.
19. Amendment of licences
(1)The Commission may, where in its opinion the public interest so permits or requires, on the
application of the licensee and if the licensee is not a local authority on the application of the local
authority concerned or otherwise on its own may make such alterations and amendments to the
terms and conditions of a licence as it thinks fit taking into account the objects and purposes of the
Act:Provided that no such alterations or amendments, other than an alteration or amendment
pursuant to a licence condition referred to in sub-section (7) of section 15 or sub-section (5) of
section 18 shall be made except with the consent of the licensee.(2)Where the licensee has made an
application under sub-section (1) proposing any alterations or amendments in his licence, the
following provisions shall apply,(a)the licensee shall publish a notice of the application in the
manner and with the particulars as may be prescribed by the Commission;(b)the Commission shall
not make any alterations or amendments until all objections received by it with reference to the
application within three months from the date of the first publication of the notice have been
considered; and(c)in the case of an application proposing alterations or amendments in an area of
supply comprising the whole or any part of the cantonment, aerodrome, fortress, arsenal, dockyard
or camp or of any building or place in the occupation of the Central Government for defence
purposes the Commission shall not make any alterations or amendments except with the consent of
the Central Government.(3)Before making any alterations or amendments in a licence otherwise
than on the application of the licensee, the Commission shall publish the proposed alterations, or
amendments and consider all objections received by it with reference to the proposed alterations or
amendments within three months from the date of the first publication of the notice.
20. Provisions where licence is revoked
(1)Notwithstanding the provisions of sections 6, and 7 of the Indian Electricity Act, 1910 where the
Commission revokes a licence, under sub-section (2) of section 18, the following provisions shall
apply:(a)the Commission shall serve a notice of revocation upon the licensee and shall fix a date on
which the revocation shall take effect with effect from that date or with effect from the earlier date
on which the undertaking of the licensee is sold to a purchaser in pursuance of any of the provisions
of this Act, all the rights, duties, obligations and liabilities of the licensee under this Act shall
absolutely cease and determine except for any liabilities that have accrued to that date;(b)the
Commission shall invite applications for acquiring the undertaking of the licensee whose licence has
been revoked and determine terms and conditions of the sale of the undertaking;(c)the Commission
may, by notice in writing, require the licensee to sell, and thereupon the licensee shall sell the
undertaking to the person whose application has been accepted by the Commission. Such person is
referred to in this section as the purchaser ; and(d)the Commission may make such interim
arrangement in regard to the undertaking of the licensee for maintaining the electricity transmission
and supply as may be considered appropriate including the appointment of administrators andAndhra Pradesh Electricity Reform Act, 1998

special directors for the undertaking.(2)Where an undertaking is sold under sub-section (1), the
purchaser shall pay to the licensee the purchase price of the undertaking determined in accordance
with the application submitted by the purchaser.(3)Where the Commission issues any notice under
sub-section (1) requiring the licensee to sell the undertaking, it may by such notice require the
licensee to deliver, rand thereupon the licensee shall deliver on a date specified in the notice, the
undertaking to the designated purchaser pending the payment of the purchase price of the
undertaking. Any pending fines and charges shall be deducted from the amounts payable to the
licensee:Provided that in any such case, the purchaser shall pay to the licensee interest at such rate
not less than the Reserve Bank lending rate ruling at the time of delivery of the undertaking as the
Commission may decide, on the purchase price of the undertaking for the period from the date of
delivery of the undertaking to the date of payment of the purchase price.(4)Where before the date
fixed in the notice issued under clause (a) of sub-section (1) as the date on which the revocation of
the licence shall, take effect, no notice has been issued to the licensee requiring his to sell the
undertaking or where for any reason no sale of the undertaking has been effected under that
sub-section, the State Government shall acquire the undertaking in the date of revocation of the
licence and shall pay to the licensee an amount determined in accordance with sub-sections (1) and
(2) of section 7-A of the Indian Electricity Act, 1910, as amended in the State and shall perform all
the obligations of the licensee until such time as the State Government is able to sell the undertaking
to a new licensee which it shall endeavour to do expeditiously without undue delay.(5)The Licensee
shall duly implement the orders of the Commission, notwithstanding that the licensee any be
aggrieved by the order of the Commission and intends to take legal action challenging the orders of
the Commission.
21. Restriction on licensees and Generating Companies
(1)No licensee or Generating Company shall at any time, without the previous consent in writing of
the Commission, acquire by purchase or otherwise the licence or the undertaking of, or associate
himself with, so far as the business of generating, transmitting distribution or supply of energy is
concerned, any other licensee or person generating, transmitting, supplying or intending to
generate, transmit, or supply electricity:Provided that before granting the consent the Commission
shall hear such person or authority as the Commission shall consider appropriate.(2)The licensee
shall not, at any time, assign his licence or transfer his undertaking, or any part thereof, by sale
mortgage, lease, exchange or otherwise without the previous consent in writing of the
Commission.(3)The provisions of section 44 of the Electricity (Supply) Act, 1948 shall apply except
that the persons to whom the section applies shall be required to obtain the sanctions and consents
from the Commission, instead of such sanctions and consents to be obtained from the Board as
provided under that section.(4)A holder of a supply or transmission licence may, unless expressly,
prohibited by the terms of its licence, enter into arrangements for the purchase of electricity
from,(a)the holder of a supply licence which permits the holder of such licence to supply energy to
other licensees for distribution by them; and(b)any person or Generating Company with the consent
of the Commission.(5)Any agreement relating to any transaction of the nature described in
sub-sections (1), (2), (3) or (4) unless made with or subject to such consent as aforesaid, shall be
void.Andhra Pradesh Electricity Reform Act, 1998

22. Annual Accounts of licensee
Every licensee shall, unless expressly exempted by the licence, prepare and render to the
Commission every year on or before the date specified in the licence, an annual statement or
statements of accounts of its undertaking and of each separate business unit as specified in the
licence made up to such date, in such form and containing such particulars, as may be set out in the
licence. It shall be a term of the licence that such statements shall be published in manner
prescribed in the regulations.PART-VII REORGANISATION OF THE ELECTRICITY
INDUSTRY
23. Reorganisation of State Electricity Board
(1)With effect from the date on which a transfer scheme prepared fay the State Government to give
effect to the objects and, purposes of this Act is published or such further date as may be prescribed
by the State Government (hereinafter referred to as the effective date), any property, interest in
property, rights and liabilities which immediately before the effective date belong to the Board shall
vest in the State Government on such terms as may be agreed between the State Government and
the Board.(2)Any property, interest in property, rights and liabilities vested in the State Government
under sub-section (1) shall be revested by the State Government in the APTRANSCO and generating
company or companies, in accordance with the transfer scheme so-published along with such other
property, interest in property, rights and liabilities of State Government as may be specified in such
scheme, on such terms and conditions as may be agreed between the State Government and the
APTRAHSCO or generating company or companies, as the case may be.Explanation: For the
purposes of this Part generating company or companies, shall mean the company or companies to
be incorporated to implement the reorganisation of the Electricity Industry in the State.(3)Such of
the rights and powers exercisable by the Board under the Electricity (Supply) Act, 1948 as the State
Government may, by notification specify, shall be exercisable by the APTRANSCO or generating
company or companies, as the case may be, for the purpose of discharging the functions and duties
with which it is charged.(4)Notwithstanding any thing in this section, where,(a)the transfer scheme
involves the transfer of any property or rights to any person or undertaking not wholly owned by the
State Government, the scheme shall give effect to the transfer only for fair value to be paid by the
transferee to the State Government.(b)a transaction of any description is effected in pursuance of a
transfer scheme, it shall be binding on all persons including third parties and even if such persons,
third parties have not consented to it.(5)The State Government may, after consulting the
APTRANSCO (the transferor licensee ), or generating company or companies, as the case may be,
require them to draw up a transfer scheme to vest in a further licensee (the transferee licensee ) or
any generating companies, any of the functions including distribution function, property, interest in
property, rights and liabilities which have been vested in the transferor licensee or generating
companies, as the case may be under this section and publish the same as Statutory Transfer
Scheme under this Act. The Transfer Scheme to be notified under this sub-section shall have the
same effect as the Transfer Scheme under sub-section (2).(6)A transfer scheme may,(a)provide for
the formation of subsidiaries, joint venture companies or other schemes of division, amalgamation,
merger, reconstruction or arrangements;(b)define the property, interest in property, rights and
liabilities to be allocated:(i)by specifying or describing the property, rights and liabilities inAndhra Pradesh Electricity Reform Act, 1998

question;(ii)by referring to all the property interest in property, rights and liabilities comprised in a
specified part of the transferor's undertaking; or(iii)partly in the one way and partly in the
other;(c)provide that any rights or liabilities specified or described in the scheme shall be
enforceable by or against the transferor or the transferee;(d)impose on the licensee an obligation to
enter into such written agreements with or execute such other instruments in favour of, any other
subsequent licensee as may be specified in the scheme;(e)make such supplemental, incidental and
consequential provisions as the transferor licensee considers appropriate including provision
specifying the order in which any transfer or transaction is to be regarded as taking effect;
and(f)provide that the transfer shall be provisional for a specified period.(7)All debts and
obligations incurred, all contracts entered into and all natters and things engaged to be done by the
Board, with the Board or for the Board, or the APTRANSCO or generating company or companies
before a transfer scheme becomes effective shall, to the extent specified in the relevant transfer
scheme, be deemed to have been incurred, entered into or done by the Board, with the Board or for
the State Government or the transferee and all suits or other legal proceedings instituted by or
against the Board or transferor, as the case may be, may be continued or instituted by or against the
State Government or concerned transferee, as the case may be.(8)In the event that a licensee is
required to vest any part of its undertaking in another licensee pursuant to sub-section (5), the
Commission shall amend the transferee's licence in accordance with section 19 or revoke its licence
in accordance with section 18.(9)The Board shall cease to be charged with, and shall not perform,
the functions and duties specified in sub-section (3) with regard to transfers made on and after the
effective date.(10)The exercise by a licensee of any of the Board's rights and powers may be made on
such conditions as may be specified in the transfer scheme including a condition that they shall be
exercised by the licensee only with the approval of the Commission.
24. Provisions relating to Personnel
(1)The State Government, may by a transfer scheme provide for the transfer of the personnel to
APTRANSCO, generating company or companies, distribution or other companies hereinafter
referred to as the transferee company or companies; on the vesting of properties, rights and
liabilities in such transferee companies as provided under section 23.(2)Upon such transfer scheme
the personnel, shall hold office or service under the transferee company on terms and conditions
that may be determined in accordance with the transfer scheme;Provided that such terms and
conditions on the transfer shall not in any way be less favourable than those which would have been
applicable to them if there had been no such vesting.Provided further that any such scheme under
sub-sections (1) and (2) shall be consistent with the tripartite agreements entered into between the
Government, A.P.S.E.B. and the employees.Explanation: For the purposes of this section as well as
the transfer scheme the term personnel shall mean all persons who on the effective date are the
employees of the Board.
25. Payment of compensation or damages on transfer
Notwithstanding anything contained in the Industrial Disputes Act, 1947, or any other law as is
applicable, and except for the provisions made in this Act, the transfer of the employment of the
personnel referred to in sub-section (1) of section 24 shall not entitle such employees to anyAndhra Pradesh Electricity Reform Act, 1998

compensation or damages under this Act, or any other Central or State law or under the general law,
save as provided in the transfer scheme.PART-VIII TARIFFS
26. Licensee revenues and tariff
(1)The holder of each licence granted under this Act shall observe the methodologies and procedures
specified by the Commission from time to time in calculating the expected revenue from charges
which it is permitted to recover pursuant to the terms of its licence and in designing tariffs to collect
those revenues.(2)The Commission shall subject to the provisions of sub-section (3) be entitled to
prescribe the terms and conditions for the determination of the licensee's revenue and tariffs by
regulations duly published in the Official Gazette and in such other manner as the Commission
considers appropriate:Provided that in doing so the Commission shall be bound by the following
parameters:(a)the financial principles and their applications provided in the Sixth Schedule to the
Electricity (Supply) Act, 1948 read with sections 57 and 57-A of the said Act;(b)the factors which
would encourage, efficiency, economic use of the resources, good performance, optimum
investments performance of licence conditions and other matters which the Commission considers
appropriate keeping in view the salient objects and purposes of the provisions of this Act; and(c)the
interest of the consumers.(3)Where the Commission, departs from factors specified in the Sixth
Schedule of the Electricity (Supply) Act, 1948 while determining the licensees revenues and tariffs it
shall record the reasons therefor in writing:(4)Any methodology or procedure specified by the
Commission under sub-sections (1), (2), and (3) above shall be to ensure that the objectives and
purposes of the Act are duly achieved.(5)Every licensee shall provide to the Commission in a format
as specified by the Commission at least 3 months before the ensuing financial year full details of its
calculation for that financial year of the expected aggregate revenue from charges which it believes it
is permitted to recover pursuant to the terms of its licence and thereafter it shall furnish such
further inf formation as the Commission may reasonably require to assess the licensee's calculation.
Within 90 days of the date on which the licensee has furnished all the information that the
Commission requires, the Commission shall notify the licensee either(a)that it accepts the licensee's
tariff proposals and revenue calculations, or,(b)that it does not consider the licensee's tariff
proposals and revenue calculations to be in accordance with the methodology or procedure in its
licence, and such notice to the licensee shall,(i)specify fully the reasons why the Commission
considers that the licensee's calculation does not comply with the methodology or procedures
specified in its licence or is in any way incorrect, and(ii)propose a modification or an alternative
calculation of the expected revenue from charges, which the licensee shall accept.(6)Each holder of a
supply licence shall publish in the daily newspaper having circulation in the area of supply and make
available to the public on request the tariff or tariffs for the supply of electricity within its licensed
area and such tariff or tariffs shall take effect only after seven days from the date of such
publication.(7)Any tariff implemented under this section,(a)shall not show undue preference to any
consumer of electricity, but may differentiate according to the consumer's load factor or power
factor, the consumer's total consumption of energy during any specified period, or the time at which
supply is required; or paying capacity of category of consumers and need for
cross-subsidization;(b)shall be just and reasonable, and be such as to promote economic efficiency
in the supply and consumption of electricity; and(c)shall satisfy all other relevant provisions of this
Act and the conditions of the relevant licence.(8)The Commission also shall endeavour to fix tariff inAndhra Pradesh Electricity Reform Act, 1998

such a manner that, as far as possible, similarly placed consumers in different areas pay similar
tariff.(9)No tariff or part of any tariff required by sub-section (6) may be amended more frequently
than once in any financial year ordinarily except in respect of any changes expressly permitted
under the terms of any fuel surcharge formula prescribed by regulations. At least three months
before the proposed date for implementation of any tariff or an amendment to a tariff the licensee
shall provide details of the proposed tariff or amendment to a tariff to the Commission, together
with such further information as the Commission may require to determine whether the tariff or
amended tariff would satisfy the provisions of sub-section (7). If the Commission considers that the
proposed tariff or amended tariff of a licensee does not satisfy any of the provisions of sub-section
(7), it shall, within 60 days of receipt of all the information which it required, and after consultation
with the Commission Advisory Committee and the licensee, notify the licensee that the proposed
tariff or amended tariff is unacceptable to the Commission and it shall provide to the licensee an
alternative tariff or amended tariff which shall be implemented by the licensee. The licensee shall
not amend any tariff unless the amendment has been approved by the
Commission.(10)Notwithstanding anything contained in sections 57-A and 57-B of the Electricity
(Supply) Act, 1948, no Rating Committee shall be constituted after the date of this enactment and
the Commission shall secure that licensees comply with the provisions of their licences regarding
their charges for the sale of electricity (both wholesale and retail) and for the connection to and use
of their assets or systems in accordance with the provisions of this Act.Explanation:In this
section,(a)the expected revenue from charges means the total revenue which a licensee is expected
to recover from charges for the level of forecast supply used in the determination under sub-section
(5) above in any financial year in respect of goods or services supplied to customers pursuant to a
licensed activity; and(b)tariff means a schedule of standard prices or charges for specified services
which are applicable to all such specified services provided to the type or types of customers
specified in the tariff notification.
27. Finances of licensees
(1)The State Government may from time to time make subventions to any licensee for the purpose of
sub-section (3) of section 12 of this Act or the Electricity (Supply) Act, 1948 for such amounts as may
be recommended by the Commission and on such terms and conditions as the State Government
may determine.(2)The State Government may from time to time advance loans to any licensee or
Generating Company which for the time being is wholly or partly owned by the State Government
on such terms and conditions, not inconsistent with the provisions of this Act or the Electricity
(Supply) Act, 1948, as the State Government may determine.(3)The State Government may
guarantee in such manner as it thinks fit the repayment of the principal on the payment of interest
(or both) or any loan proposed to be raised by any licensee or Generating Company which is for the
time being wholly or partly owned by the State Government or the discharge of any other financial
obligation of any such licensee or Generating Company.(4)The State Government shall be entitled to
inspect and verify the accounts of every licensee or generating company obtaining the benefits under
sub-sections (1), (2) and (3) of this section.PART-IX COMMISSION's POWER TO PASS
ORDERS AND ENFORCE DECISIONSAndhra Pradesh Electricity Reform Act, 1998

28. Interim orders for securing compliance
(1)Where the Commission is satisfied that a licensee is contravening, or is likely to contravene any
relevant condition or requirement of its licence, it shall by final order under section 29 and, if it
thinks it appropriate, in accordance with sub-section (2) by interim order under this section, issue
such directions as it deems proper for securing compliance.(2)In determining whether it is
appropriate that an interim order be made, the Commission shall have regard, in particular to,(a)the
extent to which the contravention or likely contravention by the licensee will affect the achievement
of the objects and purposes of this Act;(b)the extent to which any person is likely to sustain loss or
damage in consequence of anything which, is likely to be done, or omitted to be done, in
contravention of the relevant condition or requirement, before a final order can be made; and(c)the
extent to which (having regard to the following provisions of this section) there is any other
available remedy in respect of the alleged contravention of a relevant condition or requirement.(3)If
the Commission proposes to make an interim order, it shall give notice to the licensee(a)stating that
it proposes to make the order;(b)setting out,(i)the relevant conditions or requirements which the
proposed order is intended to secure compliance;(ii)the acts or omissions which, in its opinion
constitute contravention of that condition or requirement;(iii)the other facts which in its opinion,
justify the making of the proposed order; and(iv)the effects of the proposed order.(c)specifying the
period (being not less than 5 days from the date of notice) within which the licensee may make
representations or objections to the proposed order.(4)Subject to sub-section (5), having considered
any representations or objections from the licensee pursuant to clause (c) of sub-section (3) the
Commission may make an interim order at any time after expiry of the period referred to in
sub-section (3)(c), if,(a)the Commission has reason to believe that the licensee to whom the order
relates has contravened or is contravening or is likely to contravene any relevant condition or
requirement; and(b)the provisions mace by the order are requisite for the purpose, of securing
compliance with that condition or requirement.(5)The Commission may not make an interim order
if it is satisfied that the licensee has agreed to take and is taking all such steps as the Commission
considers that the licensee should take to secure compliance with the condition or requirement in
question.(6)an interim order.(a)shall require the licensee to whom it relates (according to the
circumstances of the case) to do, or not to do, such things as are specified, in the order or are of a
description so specified;(b)shall take effect from such time, being the earliest practicable time, as is
determined by the order; and(c)may be revoked, modified or rescinded at any time by the
Commission, but in any event shall cease to have effect at the end of such period as is stated in the
order unless the Commission is at that time following the procedure set out in section 29 to declare
the interim order to be a final order.(7)As soon as practicable after making an interim order, the
Commission shall(a)serve a copy of the order on the licensee to whom the order relates;(b)publish
the order in such manner as it considers appropriate for the purpose of bringing it to the attention of
persons likely to be affected by it; and(c)commence proceedings to declare the interim orders to be a
final order in accordance with section 29.
29. Final orders for securing Compliance
If the Commission proposes to make a final order or to declare an interim order to be a final order,
the Commission shall give notice,(a)stating that it proposes to make the final order or to declare theAndhra Pradesh Electricity Reform Act, 1998

interim order to be a final order;(b)setting out the information referred to in clause (b) of
sub-section (3) of section 28 in respect of the proposed final order; and(c)specifying the period
(being not less than 60 days from the date of publication of the notice) within which representations
or objections to the proposed order may be made; and shall consider any representations or
objections that are duly made and not withdrawn. The Commission shall publish notice of such
representations of objections and specify a period (being not less than 30 days from the date of
publication of the notice) within which further representations or objections may be made.(2)A
notice under sub-section, (1), above shall be given,(a)by publishing the notice in such manner as the
Commission considers appropriate for the purpose of bringing the matters to which the notice
relates to the attention of persons likely to be affected by them; and(b)by serving a copy of the
notice, and a copy of the proposed final order on the licensee to whom the order relates.(3)The
Commission shall not modify the proposed final order as a result of any representations or
objections received following publication of the notice referred to in sub-section (1), except(a)with
the consent to the modification of the licensee to whom the proposed final order relates; and(b)after
complying with the requirements of sub-section (4) below,(4)The requirements mentioned in
Sub-section (3) above are that the Commission shall,(a)serve on the licensee to whom the proposed
final order relates such notice as appears to the Commission requisite of its proposal to modify the
proposed final order, together with details of such modifications;(b)in that notice specify the period
(being not less than 30 days from the date of the service of the notice) within which representations
or objections to the proposed modifications can be made; and(c)consider any representations or
objections which are duly made and not withdrawn within 10 days of the receipt thereof.(5)The
provisions of clauses (a) and (b) of sub-section (6) of section 28 shall apply to final orders.(6)As
soon as practicable after making a final order, the Commission shall with respect to the final order,
follow the procedure set but in clauses, (a) and (b) of sub-section (7) of section 28.(7)The
Commission may revoke a final order at any time, but before revoking a final order the Commission
shall give notice,(a)stating that it proposes to revoke the order and setting out its effect;
and(b)specifying the period being not less than 30 days from the date of delivery of the notice within
which representations or objections to the proposed publication may be made, and shall consider
any representations or objections which, are duly made and not withdrawn within 16, days of the
receipt thereof.(8)If, after giving a notice under sub-section (7) above, the Commission decides not
to revoke the final order to which the notice relates, it shall give notice of its decision to the
concerned persons.(9)A notice under sub-section (7) or (8) above shall be given by the procedure set
out in clauses (a) and (b) of sub-section (7) of section 28.
30. Effect and enforcement of Interim and Final Orders and emergency
provision
(1)Without prejudice to section 46 of this Act, all orders and directions, interim or final, passed by
the Commission shall be enforceable in lati as if it were a decree passed by a Civil Court.(2)The
Commission shall be entitled to take such assistance of the police and other authorities in the State
required to effectively enforce the orders and directions given by the Commission.(3)The
Commission shall be entitled to give directions for vesting of the management and control of any
undertaking of the licensee with the assets, interests and rights of the undertaking, with any other
persons or authority pending any inquiry and passing of interim or final orders in the matter, if theAndhra Pradesh Electricity Reform Act, 1998

Commission considers taking into account the objects and purposes of this Act and the need to
maintain continued supply of electricity in an efficient and safe manner to the consumer, it is
necessary and expedient to pass such orders or directions. Such directions or orders shall not be
questioned on the ground that no prior notice of or hearing on the intention to pass the order or
direction was given to the licensee. The Commission shall however give opportunity to the licensee
and hear the licensee before passing further orders in terms of sections 28 and 29 of this Act.
31. Fines and Charges
(1)The Commission shall be entitled to impose such fines and charges as may be prescribed by the
Commission in the regulations for non compliance or violation on the part of the Generating
Companies, licensees or other persons, of the provisions or requirements of this Act or, rules and
regulations framed thereunder and directions or orders of the Commission made from time to time.
The fines which the Commission shall be entitled, to impose may extend up to Rs. 5,00,000 (Five
lakhs) for an act of non-compliance or violation and a further amount not exceeding Rs. 20,000
(Twenty thousand) for every day during which the non-compliance or violation continues.(2)The
Commission shall, while making an interim or final orders under this Part, shall be entitled to direct
compensation to be paid by the person guilty of violation or non-compliance as provided in
sub-section (1) to the person or persons affected by such violation or non-compliance.(3)The fines,
charges and compensation which may be imposed by the Commission under this section shall be in
addition to and not in derogation of any other liability, which the person guilty of violation or
non-compliance, may have incurred.
31. A. General control of the Commission.
The generating company(ies) shall comply with the regulations that may be framed by the
Commission concerning the operation and maintenance of the power system and electric supply
lines in an efficient and economical manner.PART-X ADVISORY COMMITTEE, CONSUMER
CONSULTATION
32. Commission Advisory Committee
(1)The Commission shall constitute a committee to be known as the Commission Advisory
Committee, in consultation with the State Government which shall consist of such number of
persons being not less than 15 and not more than 21 as the Commission may appoint after
consultation with such representatives or bodies representative of the following interests as the
Commission thinks fit, that is to say, holders of supply licences in the State, holders of transmission
licences in the State, generating companies operating in the State, Commerce, Industry, Transport,
Agriculture, Labour employed in the electricity supply industry and consumers of electricity.(2)The
Chairman and members of the Commission shall be ex-officio Chairman and Members of the
Commission Advisory Committee.(3)The term of the members of advisory Committe shall be for a
period of three years and one third of the members shall retire annually.(4)The Commission
Advisory Committee shall meet at least once in every three months.(5)The functions of the.
Commission Advisory Committee shall be as follows:(a)to advise the Commission on majorAndhra Pradesh Electricity Reform Act, 1998

questions of policy, relating to the electricity industry in the State; and(b)to advise the Commission
on any matters which the Commission may put before it, including matters relating to the quality,
continuity and extent of service, provided by licensees and compliance by licensees with the
conditions and requirements of their licences.
33. Consumer protection standards of performance
(1)The Commission may, after consultation with (a) holders of supply licences, (b) other persons or
bodies appearing to the Commission to be representative of persons and categories of persons likely
to be affected and (c) the Commission Advisory Committee, frame regulations prescribing(a)the
circumstances in which such licensees are to inform consumers of their rights;(b)the standards of
performance in relation to any duty arising under sub-section (a) above or otherwise in connection
with the electricity supply to the consumers; and(c)the circumstances a which licensees are to be
exempted from any requirements of the regulations or this section and may make different
provision for different licensees.(2)Nothing in this section or other provisions of this Act shall in any
way prejudice or effect the rights and privileges of the Consumers under other laws including but
not limited to the Consumer Protection Act, 1986.
34. Electricity supply; overall performance standards
(1)The Commission may, after consultation with the licensees, the Commission Advisory
Committee, and with persons or bodies appearing to it to be representative of persons likely to be
affected, from time to time,(a)determine such standards of overall performance in connection with
the provision of electricity supply services and in connection with the promotion of the efficient use
of electricity by consumers as, in its opinion, is economic and ought to be achieved by such
licensees; and(b)arrange for the publications, in such form and in such manner as it considers
appropriate, of the standards so determined.(2)Different standards may be determined under this
section for different licensees.
35. Information with respect to Levels of Performance
(1)The Commission shall from time to time collect information, with respect to,(a)the fines or
penalties levied on licensees under this Act;(b)the levels of overall performance achieved by such
licensees in connection with the transmission and provision of electricity supply services; and(c)the
levels of performance achieved by such licensees in connection with the promotion of the efficient
use of electricity by consumers.(2)On or before such date in each year as may be specified in a
direction given by the Commission, each licensee shall furnish to the Commission the following
information,(a)with respect to each standard prescribed the number of cases in which a penalty was
levied and the aggregate amount of value of those penalties; and(b)with respect to each standard
determined such information with respect to the level of performance achieved by the licensee as
may be so specified.(3)The Commission shall, at least once in every year, arrange for the
publication, in such form and in such manner as it considers appropriate, of such of the information
collected by or furnished to it under this section as may appear, to the Commission to be so
required.Andhra Pradesh Electricity Reform Act, 1998

36. Restriction on disclosure of information
(1)Subject to the provisions of this Act, no information with respect to any particular business which
in the opinion of the Commission is confidential; and(a)has been obtained by the Commision under
or by virtue of any of the provisions of this Act; and(b)relates to the affairs of any individual or to
any particular business.shall during the lifetime of that individual or for so long as that particular
business continues to be carried on, be disclosed by the Commission without the consent of that
individual or the person for the time being carrying on that business.(2)The restriction contained in
sub-section (1) above shall not apply to any disclosure of information which is made:(a)for the
purpose of facilitating the carrying out by the State Government of any of its functions under a
statute;(b)for the purpose of facilitating the carrying out by the Central Government of any of its
duties or functions under this Act or any Central legislation;(c)for the purpose of facilitating the
Accountant General, Andhra Pradesh to carry out his duties and functions under this Act;(d)for the
purpose of enabling or assisting any competent person to carryout functions under the enactment
relating to insolvency;(e)in connection with the investigation of any criminal offence or for the
purposes of any criminal proceedings; or(f)for the purposes of any civil proceedings, brought under
or by virtue of this Act or any other State or Central legislation to which the information is directly
relevant.(3)The restrictions contained in sub-section (1) above do not apply to the disclosure of any
information relating to tariff.PART-XI ARBITRATION AND APPEALS
37. Arbitration by the Commission
(1)Notwithstanding anything contained in the Arbitration and Conciliation Act, 1996, (Central Act
26 of 1996) any dispute arising between licensees shall be referred to the Commission. The
Commission may proceed to act as arbitrator or nominate arbitrator or arbitrators to adjudicate and
settle such dispute. The practice or procedure to be followed in connection with any such
adjudication and settlement shall be such as may be prescribed by regulations.(2)Where the award
is made by the arbitrator appointed by the Commission it shall be filed before the Commission and
the Commission shall be entitled to pass appropriate orders on the award including orders
to,(a)confirm and enforce the award;(b)set aside or modify the award; or(c)remit the award for
reconsideration by the arbitrator.(3)The award given by the Commission under sub-section (1) or
the order passed by the Commission under sub-section (2) shall be a decision or order of the
Commission and shall be appealable as provided in this Act.(4)An award made or an order passed
by the Commission under sub-section (2) Shall be enforceable as if it were a decree of the Civil
Court.
38. Appeals from decisions of Electrical Inspectors
Notwithstanding the provisions of sub-section (2) of section 36 of the Indian Electricity Act, 1910 in
the absence of any express provision to the contrary in the Indian Electricity Act, 1910 or the
Electricity (Supply) Act, 1948, or any rule made thereunder, an appeal shall lie from the decision of
an Electrical Inspector (other than an Inspector of the Central Government or the Central Electricity
Authority) to the Commission or to an arbitrator to be appointed by the commission in terms of
section 37.Andhra Pradesh Electricity Reform Act, 1998

39. Appeals against the orders of the Commission
A person aggrieved by any decision or order of the Commission, passed under this Act may file an
appeal to the High Court of Andhra Pradesh within sixty days from the date of communication of the
decision or order of the Commission to him, on questions of law arising out of such order:Provided
that the High Court may, if it is satisfied that the appellant was prevented by sufficient cause from
the filing the appeal within the said period allow it to be filed within a further period not exceeding
thirty days.PART-XII OFFENCES AND PENALTIES
40. Penalty for contravention of section 14
Whoever in contravention of the provisions of this Act or the regulations framed under this Act or
the provisions of the Indian Electricity Act, 1910 or the Electricity (Supply) Act, 1948 or the rules
framed under the said Acts, engages in the business of Transmission or supply or use of energy,
shall be punishable with imprisonment which may extend to one year or with penalty by way of fine
which may extend to Rs. 5,00,000. (Five lakhs) or both and further penalty which may extend to Rs.
20,000 (Twenty thousands) for each day after the first during which the offence continues.
41. Penalties for contravention of other provisions
If any licensee or other person refuses or fails without reasonable excuse to comply with or give
effect to, any direction, order or requirement made under any of the provisions of this Act he shall
be punishable with imprisonment which may extend to six months or with penalty by way of fine
which may extend to Rs. 5,00,000 (Five lakhs) or both and a further penalty which may extend to
Rs. 20,000 (Twenty thousand) for each day after the first during which the offence continues.
42. Offences by companies
(1)Where an offence under this Act has been committed by a company every person, who, at the
time the offence was committed, was in charge of, and was responsible to the company for the
conduct of the business of the company, as well as the company, shall be deemed to be guilty of the
offence and shall be liable to be proceeded against and punished accordingly:Provided that nothing
contained in this sub-section shall render any such person liable to any punishment if he proves that
the offence was committed without his knowledge of that he had exercised all due diligence to
prevent the commission of such offence.(2)Notwithstanding anything contained in sub-section (1),
where an offence under this Act, has been committed by a company and it is proved that the offence
has been committed with the consent or connivance of, or is attributable to any neglect on the part
of, any director, manager, secretary or other officer of the company, such director, manager,
secretary or other officer shall also be deemed to be guilty of that offence and shall be liable to be
proceeded against and punished accordingly.For the purposes of this section.(a)Company means a
body corporate and includes a firm, or other association of individuals; and(b)director in relation to
a firm, means a partner in the firm.Andhra Pradesh Electricity Reform Act, 1998

43. Power to compound offences
The Commission may for reasons to be recorded in writing either before or after the institution of
proceedings compound any offence relating to contravention of any order made by it.
44. Cognizance of offences
(1)No Court shall take cognizance of any offence punishable under this Act except upon a complaint
in writing made by an officer of the Commission, generally or specially authorised in this behalf by
the Commission and no Court other than that of a Metropolitan Magistrate or a Judicial Magistrate
of First Class or a Court superior thereto shall try any such offence.(2)Notwithstanding anything in
the Code of Criminal procedure, 1973 (Central Act 2 of 1974) the Court may if it sees reason so to do,
dispense with the personal attendance of the officer of the Commission filing the complaint.
45. Penalties and proceedings not to prejudice other actions
The proceedings, and actions under this Act against a person contravening the provisions of the Act
or orders passed by the Commission shall be in addition to and without prejudice to actions that
may be initiated under other Acts including and in particular under the Indian Electricity Act, 1910
and the Electricity (Supply) Act, 1948.PART-XIII MISCELLANEOUS
46. Recovery of fees, fines and charges
The Commission shall be entitled to recover all sums due to it under this Act, whether by way of
licence, fees or fines and charges, in accordance with the provisions of the Andhra Pradesh Revenue
Recovery Act, 1864 (A.P. Act II of 1864) as if any such sum were a public demand as defined in that
Act and hand over the amount due to the person or authority concerned.
47. Application of fine and charges
The Commission or Court imposing the fine and charges under this Act may direct that the whole or
any part thereof shall be applied in or towards payment of the costs of the proceedings.
48. No part of the fines or penalties imposed to be passed on
The licensee, Generating Companies and others on whom the fines, charges, penalties are imposed
under this Act shall not, directly or indirectly, pass the sane to the consumers in the form of tariff or
charges payable.
49. Protection of action taken in good faith
No suit or legal proceedings shall lie against the Commission or the Chairman or other members of
the Commission or the staff or representatives of the Commission in respect of anything which is inAndhra Pradesh Electricity Reform Act, 1998

good faith done or intended to be done under this Act or any rule or regulations or order made
thereunder.
50. Bar of Jurisdiction
No order or proceeding made under this Act or rules or regulations framed under the Act shall be
appealable except as provided in the Act and no Civil Court including under the Arbitration and
Conciliation Act, 1996 shall have jurisdiction in respect of any matter which the Commision or the
Appellate Authority under the Act is empowered by or under, this Act.
51. Power to remove difficulties
(1)If any difficulty arises in giving effect to the provisions of this Act or the rules regulations, scheme
or orders made thereunder, the State Government may by order published in the Official Gazette,
make such provision, not inconsistent with the provisions of this Act as appears to it to be necessary
or expedient for removing the difficulty.(2)Every order made under this section shall as soon as may
be after it is made, be laid before the State Legislative Assembly.
52. Proceedings before the Commission to be Judicial Proceedings
All proceedings before the Commission shall be deemed to be judicial proceedings within the
meaning of sections 193, 219 and 228 of the Indian Penal Code and the Commission shall be
deemed to be a Civil Court for the purposes of section 195 and Chapter XXVI of the Code of Criminal
Procedure, 1973.
53. Members and staff of Commission to be public servants
The Chairman, other members and officers and other employees of the Commission appointed for
carrying out the objects and purposes of this Act shall be deemed to be public servants within the
meaning of section 21 of the Indian Penal Code.Section 54. Power to make regulations(1)The
Commission may make regulations by notification in the Official Gazette for the proper performance
of its functions under this Act.(2)In particular and without prejudice to the generality of the
foregoing provisions and matters specifically provided for in this Act, such regulations may provide
for all or any of the following matters, namely,(a)the administration of the affairs of the
Commission, including the exercise of its administrative, quasi-judicial and judicial powers
including arbitration and procedure for summoning and holding of the meetings of the Commission
the times and places at which such meetings shall be held the conduct of the business thereof.(b)the
duties of the Secretary, officers and employees of the Commission, their salaries, allowances and
conditions of service;(c)determination of the functions to be assigned to licensees and others
involved in the generation, purchase, transmission, distribution and supply of electricity, the
manner in which such functions shall be discharged and the procedure and code to be adopted in
regard to power system and electric supply lines;(d)the procedure far licensing of transmission and
supply, the conditions for the grant of licenses and particulars, details and documents to be madeAndhra Pradesh Electricity Reform Act, 1998

available by the persons applying for the licence the standard and general conditions subject to
which the licence shall be granted, the exemption from grant of licence, revocation and amendment
and effect thereof, of the licence and all matters related to the above;(e)the duties, powers, rights
and obligations of the licensee;(f)the particulars to be furnished, the collection of information
details, particulars, documents, accounts, books and other records from or of the persons involved
in the generation, transmission distribution, supply and use of electricity the form and manner in
which the same are to be furnished and enforcing and compelling the production of the
same;(g)method and manner of determination of licensee's revenues, tariff fixation, the matters to
be considered in such determination and fixation;(h)the constitution of the Commission Advisory
Committee;(i)the determination of the standard of performance of the persons involved in the
generation transmission distribution and supply of electricity in the State;(j)the amount of fines and
penalties to be imposed for violation of provisions of this Act including the method and manner of
imposition of fines and penalties and collection of the same;(k)the regulation of the properties,
assets and interest in the properties used for or in connection with the electricity industry in the
State;(l)any other matter which is required to be or may be prescribed by regulations.
55. Power to make Rules
(1)The State Government may by notification make rules to carry out its functions under the
provisions of the Act.(2)In particular and without prejudice to the generality of the foregoing power
and matters specifically provided for in this Act, such rules may provide for all or any of the
following matters, namely,(a)the procedure to be adopted by the selection committee for discharge
of functions under the Act,(b)the preparation and implementation of the transfer scheme, the
transfer of assets, liabilities and personnel to Generating Companies licensees and others in the
State;(c)the financing, funding, giving of guarantee to the persons involved in the generation,
transmission, distribution and supply of electricity in the State; and(d)any other natter required to
be or may be prescribed by rules.(3)Every rule made under this section shall immediately after it is
made be laid before the Legislative Asembly of the State if it is in session and if it is not in session in
the session immediately following for a total period of fourteen days which may be comprised in one
session or in two successive sessions and if before the expiration of the session in which it is so laid
or the session immediately following the Legislative Assembly agrees in making any modification in
the rule or in the annulment of the rule the rule shall from the date on which the modification or
annulment is notified have effect only in such modified form or shall stand annulled as the case may
be so however that any such modification or annulment shall be without prejudice to the validity of
anything previously done under that rule.PART-XIV EFFECT ON EXISTING CENTRAL
LEGISLATION
56. Effect of the Act on the Indian Electricity Act, 1910 and the Electricity
(Supply) Act, 1948
(1)Except as provided in section 57 of this Act, the provisions of this Act, notwithstanding that the
same are inconsistent with or contrary to the provisions of the Indian Electricity Act, 1910 or the
Electricity (Supply) Act, 1948 shall prevail in the manner and to the extent provided in sub-section
(3).(2)Subject to sub-section (1) in respect of all matters in the Indian Electricity Act, 1910 and theAndhra Pradesh Electricity Reform Act, 1998

Electricity (Supply) Act, 1948 with which Andhra Pradesh State Electricity Board has been
concerned or dealing, with, upon the constitution of the Commission, the functions of the Board
shall be discharged by the Commission and the APTRANSCO:Provided that,(a)the State
Government shall be entitled to issue all policy directives and undertake overall planning and
co-ordination as specified in section 12 of this Act and to this extent the powers and functions of the
Andhra Pradesh State Electricity Board as per the provisions of the Indian Electricity Act, 1910 and
the Electricity (Supply) Act, 1948 or rules thereunder shall vest in the State Government and the
State Government shall co-ordinate and deal with the Central Government and the Central
Electricity Authority;(b)in respect of such matters which the Commission directs in terms of a
general or special order or in the regulations or in the licence as the case may be the Generating
Company or Companies the licensees or other body corporate as may be designated by the
Commission shall discharge the functions of the Board under the Indian Electricity Act, 1910 and
the Electricity (Supply) Act, 1948 to the extent directed by the Commission or specified in
licences.(3)Subject to sub-section (1) and (2) of this section upon the establishment of the
Commission the provisions-of the Indian Electricity Act, 1910 and the Electricity (Supply) Act, 1948
shall in so far as the State is concerned, shall be read subject to the following modifications and
reservations.INDIAN ELECTRICITY ACT, 1910(i)All references to State Electricity Board in the
Indian Electricity Act, 1910 in so far as the State is concerned shall be read as references to the
Andhra Pradesh Electricity Regulatory Commission or APTRANSCO or other licensees or wherever
it relates to general policy matters to the State Government;(ii)In respect of matters provided in
sections 3 to 11, 28, 36(2), 49-A, and 50 & 51 of the Indian Electricity Act, 1910, to the extent this Act
has made Specific provisions, the provisions, of the Indian Electricity Act, 1910 shall not apply in the
State;(iii)The provisions of all other-sections of the Indian Electricity Act, 1910 shall apply except
that,(a)the term licence , licensee , license holder shall have the meaning as defined under this Act
and the licences shall be construed as having been issued under this Act;(b)the reference to the
sections of the Indian Electricity Act, 1910 and the Electricity (Supply) Act, 1948 in the provisions of
the Indian Electricity Act, 1910 shall be taken as reference to the corresponding provisions of this
Act to the extent modified by the said Act;(c)the reference to arbitration in these provisions except
where it is by the Central Electricity Authority shall be taken as reference to the proceedings under
section 37 of this Act and the arbitration procedure prescribed under the Indian Electricity Act, 1910
shall not apply.(iv)The Schedule to the Indian Electricity Act, 1910 shall be applicable only with
reference to the provisions in this Act wherein the applications of the Schedule are specified and not
otherwise;ELECTRICITY (SUPPLY) ACT, 1948(v)All references to State Electricity Board in the
Electricity (Supply) Act; 1948 in so far as the State of Andhra Pradesh is concerned shall be read as
reference to the Andhra Pradesh Electricity Regulatory Commission or APTRANSCO or other
licensees or where it relates to general policy matters the State Government;(vi)In respect of matters
provided in sections 5 to 18, 19, 20, 23 to 27, 37, 40 to 45, 46 to 54, 56 to 69, 72 and 75 to 83 of the
Electricity (Supply) Act, 1948, to the extent this Act has made specific provisions? the provisions of
the Electricity (Supply) Act, 1948 shall not apply in the State;(vii)The provisions of all other sections
of the Electricity (Supply) Act, 1948 shall apply except that(a)the term licence licensee license holder
shall have the meaning as defined under this Act and the licences shall be construed as having been
issued under this Act;(b)the reference to the sections of the Indian Electricity Act, 1910 and the
Electricity (Supply) Act, 1948 in the provisions of the Electricity (Supply) Act, 1948 shall be taken as
reference to the corresponding provisions of this Act to the extent modified by this Act;(c)theAndhra Pradesh Electricity Reform Act, 1998

reference to arbitration in these provisions except where it is by the Central Electricity Authority
shall be taken as reference to the proceedings under section 37 of this Act and the arbitration
procedure prescribed under the Electricity (Supply) Act, 1948 shall not apply;(viii)The provisions of
sections 72, 73 of the Electricity (Supply) Act, 1948 shall be restricted to Generating Companies and
reference to the State Electricity Board in these sections shall stand deleted;(ix)The Schedules to the
Electricity (Supply) Act, 1948 shall be applicable only with reference to the provisions in this Act
wherein the applications of the Schedules are specified and not otherwise.
57. Savings
(1)Notwithstanding anything contained in this Act the powers, rights and functions of Regional
Electricity Authority, the Central Electricity Authority, the Central Government and authorities
other than the State Electricity Board and the State Government under the Indian Electricity Act,
1910 or the Electricity (Supply) Act, 1948 or rules framed thereunder shall remain unaffected and
shall continue to be in force.(2)Nothing contained in this Act shall apply to the Power Grid
Corporation of India Limited or other bodies or licensees in relation to the interstate transmission of
the electricity or generating companies owned or controlled by Central. Government or undertaking
owned by the Central Government.The Andhra Pradesh Electricity Regulatory Commission
Regulatory CommissionPART-I The Commission's Finance, Accounts and AuditI Annual
Financial Statement.(1)In December of each year the Commission shall submit to the State
Government a Statement of its estimated expenditure for the ensuing financial year.(2)The State
Government shall as soon as possible after the receipt of the said statement cause it to be laid on the
Table of the State Legislative Assembly.(3)The Commission may at any time during the year in
respect of which a statement under sub-paragraph (1) has been submitted submit to the State
Government a supplementary statement and all the provisions of this section shall apply, to such
statement as they apply to the statement under the said sub-section.II Accounts and Audit(1)The
Commission shall cause proper accounts and other records in relation thereto to be kept, including a
proper system of internal check and shall prepare an annual statement of accounts in such form as
may be prescribed by regulations made by the Commission in consultation with the
Accountant-General, Andhra Pradesh.(2)This accounts of the Commission shall be audited by the
Accountant General Andhra Pradesh or by such person as he may authorise on his behalf and any
expenditure incurred by him in connection, with such audit shall be payable by the State
Government.(3)The Accountant General, Andhra Pradesh or any person authorised by him in
connection with the audit of the accounts of the Commission shall have the right to demand the
production of books, accounts, connected vouchers and other documents and papers of the
Commission.(4)The accounts of the Commission as certified by the Accountant General, Andhra
Pradesh or any other person authorised by him on his behalf together with the audit report thereon
shall be forwarded to the State Government within six months of the close of the year to which the
accounts audit report relates and the Commission shall cause the said accounts of the Commission
to be published and make available copies thereof on sale at a reasonable price. The audit report
shall contain full details of any discrepancies or irregularities in the accounts of the Commission. At
the same time, the Commission shall publish an annual statement of its activities in relation to the
functions carried out by it under this Act during the year to which the said accounts relate and make
available copies thereof on sale at a reasonable price.(5)The State Government shall cause theAndhra Pradesh Electricity Reform Act, 1998

accounts of the Commission, together with, the audit report thereof forwarded to it under
sub-paragraph (4) to be laid annually before the State Legislative Assebmly.PART-II
GENERALIII Remuneration etc.(1)The Chairman and the Members of the Commission shall be
paid from the funds of the Commission such remuneration and such travelling and other expenses
and allowances, as the State Government may determine provided that the same shall at no time be
inferior to pay and allowances paid to the Judges of Andhra Pradesh High Court.(2)The State
Government may cause to be paid as an expense of the Commission to or in respect of any person
holding, the office of Chairman or a Member of the Commission such pension, allowance or gratuity
of such contributions or payments towards provision of such a pension, allowance or gratuity.IV.
Official Seal. The Commission shall have an offcial seal for the authentication of documents required
for the purposes of its functions.V. Performance of Functions. Anything authorised or required by or
under this Act or any other enactment to be done by the Commission may be done by any member
of the staff of the Commission who is authorised generally or specially in that behalf by the
Commission.
1. Received the assent of the Governor on the 19-05-1998 and assent of the
President received on 29-10-1998. For statement of objects and reasons
please see the Andhra Pradesh Gazette Part IV-A, Extraordinary dated
27-04-1998 at Page 87-88.Andhra Pradesh Electricity Reform Act, 1998

