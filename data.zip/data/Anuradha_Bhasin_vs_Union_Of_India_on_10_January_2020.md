Anuradha Bhasin vs Union Of India on 10 January, 2020
Equivalent citations: AIR 2020 SUPREME COURT 1308, (2020) 1 MAD LJ 574,
(2020) 1 SCALE 691, (2020) 77 OCR 784, AIRONLINE 2020 SC 17
Author: N. V. Ramana
Bench: B. R. Gavai, R. Subhash Reddy, N.V. Ramana
                                                                         REPORTABLE
                                      IN THE SUPREME COURT OF INDIA
                                        CIVIL ORIGINAL JURISDICTION
                                WRIT PETITION (CIVIL) NO. 1031   OF   2019
          ANURADHA BHASIN                                             …PETITIONER
                                                  VERSUS
          UNION            OF INDIA AND   ORS.                        …RESPONDENT(S)
                                                   And
                                WRIT PETITION (CIVIL) NO. 1164   OF   2019
          GHULAM NABI AZAD                                             …PETITIONER
                                                  VERSUS
          UNION            OF INDIA AND   ANR.                        …RESPONDENT(S)
                                                 JUDGMENT
TABLE                 OF   CONTENTS
 Introduction                                                                 A
 Contentions                                                                  B
 Issues                                                                       C
 Production of Orders                                                         D
 Fundamental Rights under Part III and restrictions                           E
 thereofAnuradha Bhasin vs Union Of India on 10 January, 2020

 Internet Shutdown                                                            F
 Restrictions under Section 144, Cr.P.C.                                      G
 Freedom of the Press                                        H
 Conclusion                                                  I
N. V. RAMANA, J.
    A. INTRODUCTION
               “It was the best of times, it was the worst
              of times,
              it was the age of wisdom, it was the age of
              foolishness,
it was the epoch of belief, it was the epoch of incredulity, it was the season of Light, it was the season
of Darkness, it was the spring of hope, it was the winter of despair, we had everything before us, we
had nothing before us, we were all going direct to Heaven, we were all going direct the other way− in
short, the period was so far like the present period, that some of its noisiest authorities insisted on
its being received, for good or for evil, in the superlative degree of comparison only.” −Charles
Dickens in A Tale of Two Cities
1. Although cherished in our heart as a “Paradise on Earth”, the history of this beautiful land is
etched with violence and militancy. While the mountains of Himalayas spell tranquillity, yet blood is
shed every day. In this land of inherent contradictions, these petitions add to the list, wherein two
sides have shown two different pictures which are diametrically opposite and factually
irreconcilable. In this context, this Court’s job is compounded by the magnitude of the task before it.
It goes without saying that this Court will not delve into the political propriety of the decision taken
herein, which is best left for democratic forces to act on. Our limited scope is to strike a balance
between the liberty and security concerns so that the right to life is secured and enjoyed in the best
possible manner.
2. Liberty and security have always been at loggerheads. The question before us, simply put, is what
do we need more, liberty or security? Although the choice is seemingly challenging, we need to clear
ourselves from the platitude of rhetoric and provide a meaningful answer so that every citizen has
adequate security and sufficient liberty. The pendulum of preference should not swing in eitherAnuradha Bhasin vs Union Of India on 10 January, 2020

extreme direction so that one preference compromises the other. It is not our forte to answer
whether it is better to be free than secure or be secure rather than free. However, we are here only to
ensure that citizens are provided all the rights and liberty to the highest extent in a given situation
while ensuring security at the same time.
3. The genesis of the issue starts with the Security Advisory issued by the Civil Secretariat, Home
Department, Government of Jammu and Kashmir, advising the tourists and the Amarnath Yatris to
curtail their stay and make arrangements for their return in the interest of safety and security.
Subsequently, educational institutions and offices were ordered to remain shut until further orders.
On 04.08.2019, mobile phone networks, internet services, landline connectivity were all
discontinued in the valley, with restrictions on movement also being imposed in some areas.
4. On 05.08.2019, Constitutional Order 272 was issued by the President, applying all provisions of
the Constitution of India to the State of Jammu and Kashmir, and modifying Article 367
(Interpretation) in its application to the State of Jammu and Kashmir. In light of the prevailing
circumstances, on the same day, the District Magistrates, apprehending breach of peace and
tranquillity, imposed restrictions on movement and public gatherings by virtue of powers vested
under Section 144, Cr.P.C. Due to the aforesaid restrictions, the Petitioner in W.P. (C) No. 1031 of
2019 claims that the movement of journalists was severely restricted and on 05.08.2019, the
Kashmir Times Srinagar Edition could not be distributed. The Petitioner has submitted that since
06.08.2019, she has been unable to publish the Srinagar edition of Kashmir Times pursuant to the
aforesaid restrictions.
5. Aggrieved by the same, the Petitioners (Ms. Anuradha Bhasin and Mr. Ghulam Nabi Azad)
approached this Court under Article 32 of the Constitution seeking issuance of an appropriate writ
for setting aside or quashing any and all order(s), notification(s), direction(s) and/or circular(s)
issued by the Respondents under which any/all modes of communication including internet, mobile
and fixed line telecommunication services have been shut down or suspended or in any way made
inaccessible or unavailable in any locality. Further, the Petitioners sought the issuance of an
appropriate writ or direction directing Respondents to immediately restore all modes of
communication including mobile, internet and landline services throughout Jammu and Kashmir in
order to provide an enabling environment for the media to practice its profession. Moreover, the
Petitioner in W.P. (C) No. 1031 of 2019 also pleaded to pass any appropriate writ or direction
directing the Respondents to take necessary steps for ensuring free and safe movement of reporters
and journalists and other media personnel. Lastly, she also pleaded for the framing of guidelines
ensuring that the rights and means of media personnel to report and publish news is not
unreasonably curtailed.
6. Moreover, Mr. Ghulam Nabi Azad (Petitioner in W.P. (C) No. 1164 of 2019), alleges that he was
stopped from travelling to his constituency in Jammu and Kashmir. In this context, he alleges that
due to the aforesaid restrictions, he is not able to communicate with the people of his constituency.
7. When W.P. (C) No. 1164 of 2019 (by Mr. Ghulam Nabi Azad), was listed before a Co−ordinate
Bench of this Court on 16.09.2019, the following order was passed:Anuradha Bhasin vs Union Of India on 10 January, 2020

“Issue notice.
We permit the petitioner to go to Srinagar and visit the following districts, subject to
restrictions, if any:−
(i) Srinagar, (ii) Anantnag, (iii) Baramulla and
(iv) Jammu.
The petitioner has undertaken before the Court on his own volition that he will not indulge in any
political rally or political activity during his visit. The visit will solely be concerned with making an
assessment of the impact of the present situation on the life of the daily wage earners, if any.
So far as prayers (2) and (3) of the writ petition are concerned, the State as well as, the Union of
India will respond within two weeks hence.”
8. When W.P. (C) No. 1031 of 2019, was listed on 16.08.2019, the matter was ordered to be tagged
along with W.P. (C) No. 1013 of 2019 (five−Judge Bench) and was later de−tagged. On 16.09.2019, a
Co−ordinate Bench of this Court ordered the following:
“The State of Jammu & Kashmir, keeping in mind the national interest and internal
security, shall make all endeavours to ensure that normal life is restored in Kashmir;
people have access to healthcare facilities and schools, colleges and other educational
institutions and public transport functions and operates normally. All forms of
communication, subject to overriding consideration of national security, shall be
normalized, if required on a selective basis, particularly for healthcare facilities.”
When the said writ petition was listed before this Bench on 01.10.2019, in light of
expediency, this Bench directed that no further intervention applications shall be
entertained. However, liberty was granted to file additional documents in support of
applications for intervention. When the matter came up for hearing on the next date
on 16.10.2019, the following order was passed:
“When these matters came up for hearing today, learned Solicitor General appearing
for the Union of India made a submission that after filing the counter affidavit in
these matters, certain further developments have taken place and some of the
restrictions imposed have been relaxed, particularly with reference to mobile
connectivity as well as the landlines services etc. and, therefore, he wants to file
another additional affidavit indicating the steps taken by the Government about
relaxation of some restrictions. He also made a request to accommodate him for a
week only. During the course of hearing, we are informed by the learned Senior
counsel appearing for the petitioners that the orders which are issued by the
authorities relating to the restrictions imposed have not been provided to them so far.Anuradha Bhasin vs Union Of India on 10 January, 2020

When we asked the learned Solicitor General about the non− supply of orders issued
by the authorities relating to the restrictions imposed, particularly with respect to the
cell phone services as well as Section 144 proceedings, he claims privilege over those
orders. He, however, states that those orders can be produced before this Court.
However, if for any reason, learned Solicitor General does not want to give a copy of
those orders to the petitioners, we request him to file an affidavit indicating the
reasons for claiming such privilege.” On 24.10.2019, after the aforesaid orders were
placed on record and pleadings were complete, the matter was listed for final disposal
on 05.11.2019. Taking into account the concerns expressed by the parties, we
extensively heard the counsel for both sides, as well as all the Intervenors on
05.11.2019, 06.11.2019, 07.11.2019, 14.11.2019, 19.11.2019, 21.11.2019, 26.11.2019 and
27.11.2019, and considered all the submissions made and documents placed before
us.
B. CONTENTIONS Ms. Vrinda Grover, Counsel for the Petitioner in W.P. (C) No. 1031 of 2019  It
was contended that the petitioner, being executive editor of one of the major newspapers, was not
able to function post 05.08.2019, due to various restrictions imposed on the press.
 Print media came to a grinding halt due to non−availability of internet services, which in her view,
is absolutely essential for the modern press.
 Curtailment of the internet, is a restriction on the right to free speech, should be tested on the
basis of reasonableness and proportionality.
 The procedure that is to be followed for restricting Internet services is provided under the
Temporary Suspension of Telecom Services (Public Emergency or Public Service) Rules, 2017
[hereinafter “Suspension Rules”], which were notified under the Telegraph Act. The Suspension
Rules indicate that the restriction imposed was contemplated to be of a temporary nature.
 The orders passed under the Suspension Rules placed on record by the State of Jammu and
Kashmir, regarding the restrictions pertaining to the Internet and phones (either mobile or
telephone were ex facie perverse and suffered from non−application of mind.
 Learned counsel submitted that the orders were not in compliance with the procedure prescribed
under the Suspension Rules. Further, the orders did not provide any reasoning as to the necessity of
the restrictions, as is required under the Suspension Rules.
 Lastly, the learned counsel contended that the orders are based on an apprehension of likelihood
that there would be danger to a law and order situation. Public order is not the same as law and
order, and the situation at the time when the orders were passed did not warrant the passing of the
orders resulting in restrictions.Anuradha Bhasin vs Union Of India on 10 January, 2020

Mr. Kapil Sibal, Senior Counsel for the Petitioner in W.P. (C)  Learned senior counsel submitted
that the orders of the authorities had to be produced before the Court, and cannot be the subject of
privilege, as claimed by the State.  It was submitted that the conduct of the State, in producing
documents and status reports during argumentation, was improper, as it did not allow the
Petitioners with sufficient opportunity to rebut the same.
 Learned senior counsel submitted that the Union of India can declare an emergency only in
certain limited situations. Neither any ‘internal disturbance’ nor any ‘external aggression’ has been
shown in the present case for the imposition of restrictions which are akin to the declaration of
Emergency.
 With respect to the orders restricting movement passed under Section 144, Cr.P.C., the learned
senior counsel contended that such an order is made to deal with a ‘law and order’ situation, but the
orders do not indicate any existing law and order issue, or apprehension thereof.  Learned senior
counsel pointed out that the order of the Magistrate under Section 144, Cr.P.C. cannot be passed to
the public generally, and must be specifically against the people or the group which is apprehended
to disturb the peace. It is necessary for the State to identify the persons causing the problem, and an
entire State cannot be brought to a halt. Moreover, he has contended that there was no application
of mind before passing those orders.  While submitting that it could be assumed that there was
some material available for the purpose of passing the orders under Section 144, Cr.P.C., the
question which then arises is how the State balances the rights of individuals.  The learned senior
counsel, with respect to the communications’ restrictions, submitted that the State had not indicated
as to the necessity to block landline services. He further submitted that the
communications/Internet restrictions which were imposed under the Indian Telegraph Act, 1885
[hereinafter “Telegraph Act”] needs to follow the provisions of Section 5 of the Telegraph Act, in line
with Article 19 of the Constitution. While there can be some restrictions, there can be no blanket
orders, as it would amount to a complete ban. Instead, a distinction should be drawn while imposing
restrictions on social media/mass communication and the general internet. The least restrictive
option must be put in place, and the State should have taken preventive or protective measures.
Ultimately, the State needs to balance the safety of the people with their lawful exercise of their
fundamental rights.  On internet restrictions, the learned senior counsel submitted that such
restrictions not only impact the right to free speech of individuals but also impinges on their right to
trade. Therefore, a less restrictive measure, such as restricting only social media websites like
Facebook and Whatsapp, should and could have been passed, as has been done in India while
prohibiting human trafficking and child pornography websites. The learned senior counsel pointed
to orders passed in Bihar, and in Jammu and Kashmir in 2017, restricting only social media
websites, and submitted that the same could have been followed in this case as well.  Indicating
that the State can impose restrictions, the learned senior counsel focussed on the question of the
“least restrictive measure” that can be passed. The learned senior counsel submitted that while
imposing restrictions, the rights of individuals need to be balanced against the duty of the State to
ensure security. The State must ensure that measures are in place that allows people to continue
with their life, such as public transportation for work and schools, to facilitate business, etc. Mr.
Huzefa Ahmadi, Senior Counsel for Intervenor in I.A. No. 139141 of 2019 in W.P. (C) No. 1031 of
2019  The learned senior counsel emphasized on the term “reasonable”, as used in Article 19(2) ofAnuradha Bhasin vs Union Of India on 10 January, 2020

the Constitution, and submitted that the restrictions on the freedom of speech should be reasonable
as mandated under Article 19 of the Constitution. These restrictions need to be tested on the anvil of
the test of proportionality.
 Learned senior counsel submitted that Section 144, Cr.P.C. orders should be based on some
objective material and not merely on conjectures.
Mr. Dushyant Dave, Senior Counsel for the Intervenor in I.A. No. 139555 in W.P. (C) No. 1031 of
2019  Learned senior counsel attempted to highlight that the issue of balancing the measures
necessary for ensuring national security or curbing terrorism, with the rights of the citizens, is an
endeavour that is not unique, and has been undertaken by Courts in various jurisdictions. Learned
senior counsel relied on the judgment of the Supreme Court of Israel concerning the Legality of the
General Security Service's Interrogation Methods in Public Committee Against Torture in Israel v.
Israel, 38 I.L.M. 1471 (1999) relating to the question of whether torture during interrogation of an
alleged terrorist was permissible. In that case, the Israeli Supreme Court held that such acts were
unconstitutional, and could not be justified in light of the freedoms and liberties afforded to the
citizens of Israel.  Learned senior counsel drew parallels between the situation faced by the Israeli
Supreme Court in the abovementioned case, and that before this Court, wherein, according to the
learned senior counsel, the State is attempting to justify the restrictions due to the circumstances
prevailing in the State of Jammu and Kashmir. The learned senior counsel submitted that such a
justification merits rejection as it would amount to granting too much power to the State to impose
broad restrictions on fundamental rights in varied situations. It would amount to individual liberty
being subsumed by social control.
 The learned senior counsel emphasized on the seriousness of the present matter, stating that such
restrictions on the fundamental rights is the reason for the placement of Article 32 of the
Constitution in Part III, as a fundamental right which allows for the enforcement of the other
fundamental rights. He referred to the Constituent Assembly debates to highlight the import of
Article 32, as contemplated by the Members of the Constituent Assembly.
 The learned senior counsel also placed before this Court the Government of India National
Telecom Policy, 2012, and submitted that the wide restrictions imposed by the State are in
contravention of the aforementioned policy. He submitted that the freedom of speech and
expression is meant to allow people to discuss the burning topic of the day, including the abrogation
of Article 370 of the Constitution.
 Lastly, the learned senior counsel emphasized that the restrictions that were imposed are meant to
be temporary in nature, have lasted for more than 100 days, which fact should be taken into account
by this Court while deciding the matter.
Ms. Meenakshi Arora, Senior Counsel for the Intervenor in I.A. No. 140276 in W.P. (C) No. 1031 of
2019  Learned senior counsel submitted that Articles 19 and 21 of the Constitution require that any
action of the State must demonstrate five essential features: (a) backing of a ‘law’, (b) legitimacy of
purpose, (c) rational connection of the act and object, (d) necessity of the action, and (e) when theAnuradha Bhasin vs Union Of India on 10 January, 2020

above four are established, then the test of proportionality.  At the outset, learned senior counsel
submitted that it is necessary to test the validity of the orders by reference to the facts and
circumstances prevailing on the date of passing of the said orders, i.e., 04.08.2019.  Learned senior
counsel submitted that the orders that have not been published cannot be accorded the force of law.
The necessity of publication of law is a part of the rule of natural justice. Not only must the orders be
published, it is also necessary that these orders be made available and accessible to the public. The
State cannot refuse to produce the orders before the Court or claim any privilege.  The learned
senior counsel further submitted that, notwithstanding the expediency of the situation, the necessity
of a measure must be shown by the State. The people have a right to speak their view, whether good,
bad or ugly, and the State must prove that it was necessary to restrict the same.
 On the point of proportionality, the learned senior counsel submitted that the test of
proportionality was upheld by this Court in the case of K. S. Puttaswamy v. Union of India, (2017) 10
SCC 1 (hereinafter “K. S. Puttaswamy (Privacy− 9J.)”) and therefore the proportionality of a
measure must be determined while looking at the restrictions being imposed by the State on the
fundamental rights of citizens. The learned senior counsel pointed out that it is not just the legal and
physical restrictions that must be looked at, but also the fear that these sorts of restrictions engender
in the minds of the populace, while looking at the proportionality of measures.
Mr. Sanjay Hegde, Senior Counsel for the Petitioner in W.P.  Although this Writ Petition was
withdrawn during arguments, the learned senior counsel wished to make certain submissions
regarding the issue at hand. The learned senior counsel submitted on behalf of the Petitioner that
although he and his family were law abiding citizens, yet they are suffering the effects of the
restrictions. Citing the House of Lords judgment of Liversidge v. Anderson, (1941) 3 All ER 338 the
learned senior counsel submitted that it was the dissent by Lord Atkin, upholding the fundamental
rights of the citizens of the United Kingdom, which is now the law of the land.
Mr. K. K. Venugopal, Learned Attorney General for the Union of India  The learned Attorney
General supported the submissions made by the Solicitor General. He submitted that the
background of terrorism in the State of Jammu and Kashmir needs to be taken into account. Relying
on National Investigation Agency v. Zahoor Ahmad Shah Watali, 2019 (5) SCC 1, the learned
Attorney General submitted that this Court while deciding the aforementioned case, has taken
cognizance of the problem of terrorism in the State before.
 According to the learned Attorney General, keeping in mind the facts regarding cross border
terrorism and internal militancy, it would have been foolish to have not taken any preventive
measures in the circumstances. The necessity of the orders under Section 144, Cr.P.C. are apparent
from the background facts and circumstances, when there can be huge violence if the Government
did not take these kinds of measures. In fact, similar steps were taken earlier by the Government in
2016 when a terrorist was killed in the State.
Mr. Tushar Mehta, Solicitor General for the State of Jammu and Kashmir  The learned Solicitor
General submitted that the first and foremost duty of the State is to ensure security and protect the
citizens− their lives, limbs and property. He further submitted that the facts relied on by theAnuradha Bhasin vs Union Of India on 10 January, 2020

Petitioners and the Intervenors were incorrect, as they did not have the correct information about
the factual position on the ground in the State of Jammu and Kashmir.
 The learned Solicitor General submitted that the historical background of the State of Jammu and
Kashmir is necessary to be looked at to understand the measures taken by the State. The State has
been a victim of both physical and digital cross border terrorism.
 The abrogation of Article 370 of the Constitution on 05.08.2019 was a historic step, which resulted
not in the taking away of the rights of the citizens of Jammu and Kashmir, but conferment of rights
upon them which they never had. Now, with the abrogation, 106 people friendly laws have become
applicable to the State of Jammu and Kashmir.
 The learned Solicitor General submitted that the Petitioners were incorrect to state that public
movement was restricted. In fact, individual movement had never been restricted. Additionally,
while schools were closed initially, they have now been reopened. Depending on the facts,
circumstances and requirements of an area, restrictions were put in place which are now being
relaxed gradually.
 On the orders passed by the Magistrates under Section 144, Cr.P.C., in their respective
jurisdictional areas, the learned Solicitor General submitted that they were best placed to know the
situation on the ground, and then took their respective decisions accordingly. Currently, there is
nearly hundred percent relaxation of restrictions. Restrictions were being relaxed on the basis of the
threat perception. Restrictions were never imposed in the Ladakh region. This fact shows that there
was application of mind while passing the orders by the officers on the ground, and that there was
no general clampdown, as is being suggested by the Petitioners.
 Further, the learned Solicitor General pointed to various figures to indicate that people were
leading their ordinary lives in the State. He submitted that all newspapers, television and radio
channels are functioning, including from Srinagar, where the Petitioner in W.P. (C) No. 1031 of 2019
is situated. The learned Solicitor General further indicated that the Government had taken certain
measures to ensure that essential facilities would be available to the populace.
 The learned Solicitor General submitted that orders passed under Section 144, Cr.P.C. can be
preventive in nature, in order to prevent danger to public safety. The Magistrate can pass the order
even on the basis of personal knowledge, and the same is supposed to be a speedy mechanism. The
orders passed must be considered keeping in mind the history and the background of the State.
 Relying on Babulal Parate v. State of Bombay, AIR 1960 SC 51, and Madhu Limaye v. Sub−
Divisional Magistrate, Monghgyr, (1970) 3 SCC 746, the learned Solicitor General submitted that the
situation in the State of Jammu and Kashmir was such that the orders could be justified in view of
maintenance of the “security of the State”. Regarding the Petitioners’ submission that the
restrictions could have been imposed on specific individuals, the learned Solicitor General
submitted that it was impossible to segregate, and control, the troublemakers from the ordinary
citizens.  The learned Solicitor General submitted that there were enough facts in the knowledge ofAnuradha Bhasin vs Union Of India on 10 January, 2020

the Magistrate to pass the orders under Section 144, Cr.P.C. There was sufficient speculation on the
ground to suggest that there might be a move to abrogate Article 370 of the Constitution, and they
were aware of the situation on the ground. Provocative speeches and messages were being
transmitted. This information is all available in the public domain.  It was further submitted that
the Court does not sit in appeal of the decision to impose restrictions under Section 144, Cr.P.C. and
has limited jurisdiction to interfere, particularly when there are no allegations of mala fide made
against the officers and when the question involved is of national security. The level of restriction
required is best left to the officers who are on the ground with the requisite information and
knowledge, and the same is not to be replaced by the opinion of the Courts.
 With respect to the communications and internet shutdown, the learned Solicitor General
submitted that internet was never restricted in the Jammu and Ladakh regions. Further, he
submitted that social media, which allowed people to send messages and communicate with a
number of people at the same time, could be used as a means to incite violence. The purpose of the
limited and restricted use of internet is to ensure that the situation on the ground would not be
aggravated by targeted messages from outside the country. Further, the internet allows for the
transmission of false news or fake images, which are then used to spread violence. The dark web
allows individuals to purchase weapons and illegal substances easily.
 The learned Solicitor General submitted that the jurisprudence on free speech relating to
newspapers cannot be applied to the internet, as both the media are different. While newspapers
only allowed one−way communication, the internet makes two−way communication by which
spreading of messages are very easy. The different context should be kept in mind by the Court while
dealing with the restrictions with respect to the two media.
 While referring to various photographs, tweets and messages of political leaders of Kashmir, he
stated that these statements are highly misleading, abrasive and detrimental to the integrity and
sovereignty of India.  Further, it is not possible to ban only certain websites/parts of the Internet
while allowing access to other parts. Such a measure was earlier attempted in 2017, but it was not
successful.
 Lastly, the learned Solicitor General submitted that the orders passed under the Suspension Rules
were passed in compliance with the procedure in the Suspension Rules, and are being reviewed
strictly in terms of the same.
9. Some of the intervenors have supported the submissions made by the learned Attorney General
and the Solicitor General, and indicated that the restrictions were necessary and in compliance with
the law. They have also submitted that normalcy is returning in the State of Jammu and Kashmir,
and that the present petitions are not maintainable.
C. ISSUES
10. In line with aforesaid facts and arguments, the following questions of law arise for our
consideration:Anuradha Bhasin vs Union Of India on 10 January, 2020

I. Whether the Government can claim exemption from producing all the orders
passed under Section 144, Cr.P.C.
and other orders under the Suspension Rules? II. Whether the freedom of speech and
expression and freedom to practise any profession, or to carry on any occupation,
trade or business over the Internet is a part of the fundamental rights under Part III
of the Constitution? III. Whether the Government’s action of prohibiting internet
access is valid?
IV. Whether the imposition of restrictions under Section 144, Cr.P.C. were valid?
V. Whether the freedom of press of the Petitioner in W.P. (C) No. 1031 of 2019 was
violated due to the restrictions?
D. PRODUCTION OF ORDERS
11. The present petitions, their context and conduct of the parties, have placed this Court in a
peculiar situation. We have been asked to go into the question of the validity of orders, restricting
movement and communication, passed in the State of Jammu and Kashmir by various authorities,
however, the orders are not before us. The Petitioners and Intervenors claim that the orders were
not available, which is why they could not place them on record.
12. At the same time, while the non−availability of orders was not denied by the Respondent−State,
they did not produce the said orders. In fact, when this Court by order dated 16.10.2019 asked them
to produce the orders, the Respondent−State placed on record only sample orders, citing difficulty
in producing the numerous orders which were being withdrawn and modified on a day−to−day
basis. The Respondent−State also claimed that the plea to produce orders by the Petitioners was an
expansion of the scope of the present petitions.
13. At the outset, a perusal of the prayers in the Writ Petitions before us should be sufficient to reject
the aforementioned contention of the Respondent−State. In W.P. (C) No. 1164 of 2019 and I.A no.
157139 in I.A. no. 139555 of 2019 in W.P. (C) No. 1031 of 2019, a prayer has been made to issue a
writ of mandamus or any other writ directing Respondent Nos. 1 and 2 to produce all orders by
which movement of all persons has been restricted since 04.08.2019. Further, production of all
orders by way of which communication has been blocked in State of Jammu and Kashmir has also
been sought.
14. On the obligation of the State to disclose information, particularly in a writ proceeding, this
Court in Ram Jethmalani v. Union of India, (2011) 8 SCC 1, observed as follows:
“75. In order that the right guaranteed by clause (1) of Article 32 be meaningful, and
particularly because such petitions seek the protection of fundamental rights, it is
imperative that in such proceedings the petitioners are not denied the information
necessary for them to properly articulate the case and be heard, especially where suchAnuradha Bhasin vs Union Of India on 10 January, 2020

information is in the possession of the State.” (emphasis supplied)
15. We may note that there are two separate types of reasoning that mandates us to order
production of the orders passed by the authorities in this case. First, Article 19 of the Constitution
has been interpreted to mandate right to information as an important facet of the right to freedom
of speech and expression. A democracy, which is sworn to transparency and accountability,
necessarily mandates the production of orders as it is the right of an individual to know. Moreover,
fundamental rights itself connote a qualitative requirement wherein the State has to act in a
responsible manner to uphold Part III of the Constitution and not to take away these rights in an
implied fashion or in casual and cavalier manner.
16. Second, there is no dispute that democracy entails free flow of information. There is not only a
normative expectation under the Constitution, but also a requirement under natural law, that no law
should be passed in a clandestine manner. As Lon L. Fuller suggests in his celebrated article “there
can be no greater legal monstrosity than a secret statute”.1 In this regard, Jeremy Bentham spoke
about open justice as the “keenest spur to exertion”. In the same context, James Madison stated “a
popular government, without popular information, or the means of acquiring it, is but a prologue to
a farce or a tragedy; or perhaps both. Knowledge will forever govern the ignorance and a people
1Lon L. Fuller, Positivism and Fidelity to Law: A Reply to Professor Hart, The Harvard Law Review,
71(4), 630, 651 [February, 1958].
who mean to be their own Governors must arm themselves with the power which knowledge gives”.
17. As a general principle, on a challenge being made regarding the curtailment of fundamental
rights as a result of any order passed or action taken by the State which is not easily available, the
State should take a proactive approach in ensuring that all the relevant orders are placed before the
Court, unless there is some specific ground of privilege or countervailing public interest to be
balanced, which must be specifically claimed by the State on affidavit. In such cases, the Court could
determine whether, in the facts and circumstances, the privilege or public interest claim of the State
overrides the interests of the Petitioner. Such portion of the order can be redacted or such material
can be claimed as privileged, if the State justifies such redaction on the grounds, as allowed under
the law.
18. In the present case, while the State initially claimed privilege, it subsequently dropped the claim
and produced certain sample orders, citing difficulty in producing all the orders before this Court. In
our opinion, this is not a valid ground to refuse production of orders before the Court.
E. FUNDAMENTAL RIGHTS UNDER PART III AND RESTRICTIONS THEREOF
19. The petitioners have contended that the impugned restrictions have affected the freedom of
movement, freedom of speech and expression and right to free trade and avocation. In this context,
we have to first examine the nature of the fundamental rights provided under the Constitution.Anuradha Bhasin vs Union Of India on 10 January, 2020

20. The nature of fundamental rights under Part III of the Constitution is well settled. The
fundamental rights are prescribed as a negative list, so that “no person could be denied such right
until the Constitution itself prescribes such limitations”. The only exception to the aforesaid
formulation is Article 21A of the Constitution, which is a positive right that requires an active effort
by the concerned government to ensure that the right to education is provided to all children up to
the age of 16 years.
21. The positive prescription of freedom of expression will result in different consequences which
our own Constitution has not entered into. Having different social and economic backgrounds and
existing on a different scale of development, the human rights enshrined therein have taken a
different role and purpose. The framers of the Indian Constitution were aware of the situation of
India, including the socio−economic costs of such proactive duty, and thereafter took an informed
decision to restrict the application of fundamental rights in a negative manner. This crucial
formulation is required to be respected by this Court, which has to uphold the constitutional
morality behind utilization of such negative prescriptions.
22. Now, we need to concern ourselves about the freedom of expression over the medium of
internet. There is no gainsaying that in today’s world the internet stands as the most utilized and
accessible medium for exchange of information. The revolution within the cyberspace has been
phenomenal in the past decade, wherein the limitation of storage space and accessibility of print
medium has been remedied by the usage of internet.
23. At this point it is important to note the argument of Mr. Vinton G. Cerf, one of the ‘fathers of the
internet’. He argued that while the internet is very important, however, it cannot be elevated to the
status of a human right.2 Technology, in his view, is an enabler of rights and not a right in and of
itself. He distinguishes 2 Vinton G. Cerf, Internet Access is not a Human Right, The New York Times
(January 04, 2012).
between placing technology among the exalted category of other human rights, such as the freedom
of conscience, equality etc. With great respect to his opinion, the prevalence and extent of internet
proliferation cannot be undermined in one’s life.
24. Law and technology seldom mix like oil and water. There is a consistent criticism that the
development of technology is not met by equivalent movement in the law. In this context, we need
to note that the law should imbibe the technological development and accordingly mould its rules so
as to cater to the needs of society. Non recognition of technology within the sphere of law is only a
disservice to the inevitable. In this light, the importance of internet cannot be underestimated, as
from morning to night we are encapsulated within the cyberspace and our most basic activities are
enabled by the use of internet.
25. We need to distinguish between the internet as a tool and the freedom of expression through the
internet. There is no dispute that freedom of speech and expression includes the right to
disseminate information to as wide a section of the population as is possible. The wider range of
circulation of information or its greater impact cannot restrict the content of the right nor can itAnuradha Bhasin vs Union Of India on 10 January, 2020

justify its denial. [refer to Secretary, Ministry of Information & Broadcasting Government of India v.
Cricket Association of Bengal, (1995) 2 SCC 161; Shreya Singhal v. Union of India, (2015) 5 SCC 1].
26. The development of the jurisprudence in protecting the medium for expression can be traced to
the case of Indian Express v. Union of India, (1985) 1 SCC 641, wherein this Court had declared that
the freedom of print medium is covered under the freedom of speech and expression. In Odyssey
Communications Pvt. Ltd. v. Lokvidayan Sanghatana, (1988) 3 SCC 410, it was held that the right of
citizens to exhibit films on Doordarshan, subject to the terms and conditions to be imposed by the
Doordarshan, is a part of the fundamental right of freedom of expression guaranteed under Article
19(1)(a), which can be curtailed only under circumstances set out under Article 19(2). Further, this
Court expanded this protection to the use of airwaves in the case of Secretary, Ministry of
Information & Broadcasting, Government of India (supra). In this context, we may note that this
Court, in a catena of judgments, has recognized free speech as a fundamental right, and, as
technology has evolved, has recognized the freedom of speech and expression over different media
of expression. Expression through the internet has gained contemporary relevance and is one of the
major means of information diffusion. Therefore, the freedom of speech and expression through the
medium of internet is an integral part of Article 19(1)(a) and accordingly, any restriction on the
same must be in accordance with Article 19(2) of the Constitution.
27. In this context, we need to note that the internet is also a very important tool for trade and
commerce. The globalization of the Indian economy and the rapid advances in information and
technology have opened up vast business avenues and transformed India as a global IT hub. There is
no doubt that there are certain trades which are completely dependent on the internet. Such a right
of trade through internet also fosters consumerism and availability of choice. Therefore, the freedom
of trade and commerce through the medium of the internet is also constitutionally protected under
Article 19(1)(g), subject to the restrictions provided under Article 19(6).
28. None of the counsels have argued for declaring the right to access the internet as a fundamental
right and therefore we are not expressing any view on the same. We are confining ourselves to
declaring that the right to freedom of speech and expression under Article 19(1)(a), and the right to
carry on any trade or business under 19(1)(g), using the medium of internet is constitutionally
protected.
29. Having explained the nature of fundamental rights and the utility of internet under Article 19 of
the Constitution, we need to concern ourselves with respect to limitations provided under the
Constitution on these rights. With respect to the freedom of speech and expression, restrictions are
provided under Article 19(2) of the Constitution, which reads as under:
“(2) Nothing in sub clause (a) of clause (1) shall affect the operation of any existing
law, or prevent the State from making any law, in so far as such law imposes
reasonable restrictions on the exercise of the right conferred by the said sub−clause
in the interests of the sovereignty and integrity of India, the security of the State,
friendly relations with foreign States, public order, decency or morality or in relation
to contempt of court, defamation or incitement to an offence.”Anuradha Bhasin vs Union Of India on 10 January, 2020

30. The right provided under Article 19(1) has certain exceptions, which empowers the State to
impose reasonable restrictions in appropriate cases. The ingredients of Article 19(2) of the
Constitution are that:
a. The action must be sanctioned by law;
b. The proposed action must be a reasonable restriction;
c. Such restriction must be in furtherance of interests of the sovereignty and integrity
of India, the security of the State, friendly relations with foreign States, public order,
decency or morality or in relation to contempt of court, defamation or incitement to
an offence.
31. At the outset, the imposition of restriction is qualified by the term ‘reasonable’ and is limited to
situations such as interests of the sovereignty, integrity, security, friendly relations with the foreign
States, public order, decency or morality or contempt of Court, defamation or incitement to an
offence. Reasonability of a restriction is used in a qualitative, quantitative and relative sense.
32. It has been argued by the counsel for the Petitioners that the restrictions under Article 19 of the
Constitution cannot mean complete prohibition. In this context we may note that the aforesaid
contention cannot be sustained in light of a number of judgments of this Court wherein the
restriction has also been held to include complete prohibition in appropriate cases. [Madhya Bharat
Cotton Association Ltd. v. Union of India, AIR 1954 SC 634, Narendra Kumar v. Union of India,
(1960) 2 SCR 375, State of Maharashtra v. Himmatbhai Narbheram Rao, (1969) 2 SCR 392, Sushila
Saw Mill v. State of Orissa, (1995) 5 SCC 615, Pratap Pharma (Pvt.) Ltd. v. Union of India, (1997) 5
SCC 87 and Dharam Dutt v. Union of India, (2004) 1 SCC 712]
33. The study of aforesaid case law points to three propositions which emerge with respect to Article
19(2) of the Constitution. (i) Restriction on free speech and expression may include cases of
prohibition. (ii) There should not be excessive burden on free speech even if a complete prohibition
is imposed, and the government has to justify imposition of such prohibition and explain as to why
lesser alternatives would be inadequate. (iii) Whether a restriction amounts to a complete
prohibition is a question of fact, which is required to be determined by the Court with regard to the
facts and circumstances of each case. [refer to State of Gujarat v. Mirzapur Moti Kureshi Kassab
Jamat, (2005) 8 SCC 534].
34. The second prong of the test, wherein this Court is required to find whether the imposed
restriction/prohibition was least intrusive, brings us to the question of balancing and
proportionality. These concepts are not a new formulation under the Constitution. In various parts
of the Constitution, this Court has taken a balancing approach to harmonize two competing rights.
In the case of Minerva Mills Ltd. v. Union of India, (1980) 2 SCC 591 and Sanjeev Coke
Manufacturing Company v. M/s Bharat Coking Coal Ltd., (1983) 1 SCC 147, this Court has already
applied the balancing approach with respect to fundamental rights and the directive principles of
State Policy.Anuradha Bhasin vs Union Of India on 10 January, 2020

35. Before, we delve into the nuances of ‘restriction’ as occurring under Article 19(2) of the
Constitution, we need to observe certain facts and circumstances in this case. There is no doubt that
Jammu and Kashmir has been a hot bed of terrorist insurgencies for many years. In this light, we
may note the State’s submission that since 1990 to 2019 there have been 71,038 recorded incidents
of terrorist violence, 14,038 civilians have died, 5292 security personnel were martyred, 22,536
terrorists were killed. The geopolitical struggle cannot be played down or ignored. In line with the
aforesaid requirement, we may note that even the broadest guarantee of free speech would not
protect the entire gamut of speech. The question which begs to be answered is whether there exists a
clear and present danger in restricting such expression.
36. Modern terrorism heavily relies on the internet. Operations on the internet do not require
substantial expenditure and are not traceable easily. The internet is being used to support fallacious
proxy wars by raising money, recruiting and spreading propaganda/ideologies. The prevalence of
the internet provides an easy inroad to young impressionable minds. In this regard, Gregory S.
McNeal,3 Professor of Law and Public Policy, Pepperdine University, states in his article about
propaganda and the use of internet in the following manner:
“Terrorist organisations have also begun to employ websites as a form of information
warfare. Their websites can disperse inaccurate information that has far−reaching 3
Gregory S. McNeal, Cyber Embargo: Countering the Internet Jihad, 39 Case W. Res.
J. Int’l L. 789 (2007).
consequences. Because internet postings are not regulated sources of news, they can reflect any
viewpoint, truthful or not. Thus, readers tend to consider internet items to be fact, and stories can
go unchecked for some time.
Furthermore, streaming video and pictures of frightening scenes can support and magnify these
news stories. As a result, the internet is a powerful and effective tool for spreading propaganda.”
37. Susan W. Brenner,4 NCR Distinguished Professor of Law and Technology, University of Dayton
School of Law, also notes that the traditional approach has not worked satisfactorily on terrorism
due to the proliferation of the internet. It is the contention of the respondents that the restriction on
the freedom of speech was imposed due to the fact that there were national security issues over and
above a law and order situation, wherein there were problems of infiltration and support from the
other side of the border to instigate violence and terrorism. The learned Solicitor General pointed
out that the ‘war on terrorism’ requires imposition of such restriction so as to nip the problem of
terrorism in the bud. He submitted that in earlier times, sovereignty and integrity of a State was
challenged only on occurrence of war. In some cases, there have been instances 4 Susan W. Brenner,
Why the Law Enforcement Model is a Problematic Strategy for Dealing with Terrorist Activity
Online, 99 Am. Soc’y Int’l. L. Proc. 108 (2005). where the integrity of the State has been challenged
by secessionists. However, the traditional conceptions of warfare have undergone an immense
change and now it has been replaced by a new term called ‘war on terror’. This war, unlike the
earlier ones, is not limited to territorial fights, rather, it transgresses into other forms affecting
normal life. The fight against terror cannot be equated to a law and order situation as well. In thisAnuradha Bhasin vs Union Of India on 10 January, 2020

light, we observe that this confusion of characterising terrorism as a war stricto sensu or a normal
law and order situation has plagued the submission of the respondent Government and we need to
carefully consider such submissions.
38. Before analysing the restrictions imposed on the freedom of speech and expression in the Indian
context, we need to have a broad analysis of the state of affairs in the United States of America
(hereinafter ‘US’) where freedom of expression under the First Amendment is treated to be very
significant with the US being perceived to be one of the liberal constituencies with respect to free
speech jurisprudence. However, we need to refer to the context and state of law in the US, before we
can understand such an assertion.
39. During the US civil war, a dramatic confrontation over free speech arose with respect to the
speech of Clement L. Vallandigham, who gave a speech calling the civil war ‘wicked, cruel and
unnecessary’. He urged the citizens to use ballot boxes to hurl ‘President Lincoln’ from his throne.
As a reaction, Union soldiers arrested Mr. Vallandigham and he had to face a five− member military
commission which charged him with ‘declaring disloyal sentiments and opinions with the object and
purpose of weakening the power of the government in its efforts to suppress an unlawful rebellion’.
[Ex parte Vallandigham, 28 F. Cas. 874 (1863)] The commission found Mr. Vallandigham guilty and
imposed imprisonment during the war. The aforesaid imprisonment was met with demonstrations
and publications calling such imprisonment as a crime against the US Constitution. President
Lincoln, having regard to the US Constitution, commuted the imprisonment and converted the same
to banishment. He justified the aforesaid act by stating that banishment was more humane and a
less disagreeable means of securing least restrictive measures.
40. During World War I, many within the US had strong feelings against the war and the draft
imposed by the administration of President Woodrow Wilson. During this period, the US enacted
the Espionage Act, 1917 which penalised any person who wilfully caused or attempted to cause
insubordination, disloyalty, mutiny by refusal from duty or naval services. In any case, in Abraham
v. United States, 250 U.S. 616 (1919), Justice Holmes even in his dissent observed as under:
“I do not doubt for a moment that, by the same reasoning that would justify
punishing persuasion to murder, the United States constitutionally may punish
speech that produces or is intended to produce a clear and imminent danger that it
will bring about forthwith certain substantive evils that the United States
constitutionally may seek to prevent. The power undoubtedly is greater in time of war
than in time of peace, because war opens dangers that do not exist at other times.”
(emphasis supplied)
41. The Second World War was also riddled with instances of tussle between the First Amendment
and national security issues. An instance of the same was the conviction of William Dudley Pelley,
under the Espionage Act, 1917, which the Supreme Court of United States refused to review.
42. During the Cold War, the attention of the American Congress was on the increase of
communism. In 1954, Congress even enacted the Communist Control Act, which stripped theAnuradha Bhasin vs Union Of India on 10 January, 2020

Communist party of all rights, privileges and immunities. During this time, Dennis v. United States,
341 US 494 (1951), is an important precedent. Sections 2(a)(1), 2(a)(3) and 3 of the Alien
Registration Act, 1940 made it unlawful for any person to knowingly or wilfully advocate with the
intent of the overthrowing or destroying the Government of the United States by force or violence, to
organize or help to organize any group which does so, or to conspire to do so. The Petitioner in the
aforementioned case challenged the aforesaid provision on the ground that these provisions violated
the First Amendment. The US Supreme Court held:
“An analysis of the leading cases in this Court which have involved direct limitations
on speech, however, will demonstrate that both the majority of the Court and the
dissenters in particular cases have recognized that this is not an unlimited,
unqualified right, but that the societal value of speech must, on occasion, be
subordinated to other values and considerations.”
43. During the Vietnam war, the US Supreme Court had to deal with the case of Brandenburg v.
Ohio, 395 US 444 (1969), wherein the Court over−ruled Dennis (supra) and held that the State
cannot punish advocacy of unlawful conduct, unless it is intended to incite and is likely to incite
‘imminent lawless action’.
44. There is no doubt that the events of September 2011 brought new challenges to the US in the
name of ‘war on terror’. In this context, Attorney General John Ashcroft stated that “To those… who
scare peace−loving people with phantoms of lost liberty, my message is this: Your tactics only aid
terrorists, for they erode our national unity and diminish our resolve. They give ammunition to
America’s enemies…’.5 However, Bruce Ackerman, in his article, 6 states that:
“The “war on terrorism” has paid enormous political dividends .... but that does not
make it a compelling legal concept. War is traditionally defined as a state of
belligerency between sovereigns .... The selective adaptation of doctrines dealing with
war predictably leads to sweeping incursions on fundamental liberties.” 5 Senate
Judiciary Committee Hearing on Anti−Terrorism Policy, 106th Cong. (Dec. 6, 2001)
(testimony of Attorney General John Ashcroft) 6 Ackerman, Bruce, "The Emergency
Constitution", Faculty Scholarship Series, 113 (2004).
45. From the aforesaid study of the precedents and facts, we may note that the law in the US has
undergone lot of changes concerning dissent during war. The position that emerges is that any
speech which incites imminent violence does not enjoy constitutional protection.
46. It goes without saying that the Government is entitled to restrict the freedom of speech and
expression guaranteed under Article 19(1)(a) if the need be so, in compliance with the requirements
under Article 19(2). It is in this context, while the nation is facing such adversity, an abrasive
statement with imminent threat may be restricted, if the same impinges upon sovereignty and
integrity of India. The question is one of extent rather than the existence of the power to restrict.Anuradha Bhasin vs Union Of India on 10 January, 2020

47. The requirement of balancing various considerations brings us to the principle of
proportionality. In the case of K. S. Puttaswamy (Privacy−9J.) (supra), this Court observed:
“310…Proportionality is an essential facet of the guarantee against arbitrary State
action because it ensures that the nature and quality of the encroachment on the right
is not disproportionate to the purpose of the law...”
48. Further, in the case of CPIO v Subhash Chandra Aggarwal, (2019) SCC OnLine SC 1459, the
meaning of proportionality was explained as:
“225…It is also crucial for the standard of proportionality to be applied to ensure that
neither right is restricted to a greater extent than necessary to fulfil the legitimate
interest of the countervailing interest in question…”
49. At the same time, we need to note that when it comes to balancing national security with liberty,
we need to be cautious. In the words of Lucia Zedner7:
“Typically, conflicting interests are said to be ‘balanced’ as if there were a self−evident
weighting of or priority among them. Yet rarely are the particular interests spelt out,
priorities made explicitly, or the process by which a weight is achieved made clear.
Balancing is presented as a zero−sum game in which more of one necessarily means
less of the other … Although beloved of constitutional lawyers and political theorists,
the experience of criminal justice is that balancing is a politically dangerous
metaphor unless careful regard is given to what is at stake.”
50. The proportionality principle, can be easily summarized by Lord Diplock’s aphorism ‘you must
not use a steam hammer to crack a nut, if a nutcracker would do?’ [refer to R v. Goldsmith, [1983] 1
7Lucia Zedner, Securing Liberty in the Face of Terror: Reflections from Criminal Justice, (2005) 32
Journal of Law and Society 510.
WLR 151, 155 (Diplock J)]. In other words, proportionality is all about means and ends.
51. The suitability of proportionality analysis under Part III, needs to be observed herein. The nature
of fundamental rights has been extensively commented upon. One view is that the fundamental
rights apply as ‘rules’, wherein they apply in an ‘all−or−nothing fashion’. This view is furthered by
Ronald Dworkin, who argued in his theory that concept of a right implies its ability to trump over a
public good.8 Dworkin’s view necessarily means that the rights themselves are the end, which
cannot be derogated as they represent the highest norm under the Constitution. This would imply
that if the legislature or executive act in a particular manner, in derogation of the right, with an
object of achieving public good, they shall be prohibited from doing so if the aforesaid action
requires restriction of a right. However, while such an approach is often taken by American Courts,
the same may not be completely suitable in the Indian context, having regard to the structure of Part
III which comes with inbuilt restrictions.Anuradha Bhasin vs Union Of India on 10 January, 2020

8Ronald Dworkin, “Rights as Trumps” in Jeremy Waldron (ed.), Theories of Rights (1984) 153
(hereinafter Dworkin, “Rights as is trumps”).
52. However, there is an alternative view, held by Robert Alexy, wherein the ‘fundamental rights’ are
viewed as ‘principles’, 9 wherein the rights are portrayed in a normative manner. Rules are norms
that are always either fulfilled or not; whereas principles are norms which require that something be
realized to the greatest extent possible given the legal and factual possibilities.10 This
characterisation of principles has implications for how to deal with conflicts between them: it means
that where they conflict, one principle has to be weighed against the other and a determination has
to be made as to which has greater weight in this context.11 Therefore, he argues that nature of
principles implies the principle of proportionality. 12
53. The doctrine of proportionality is not foreign to the Indian Constitution, considering the use of
the word ‘reasonable’ under Article 19 of the Constitution. In a catena of judgments, this Court has
held “reasonable restrictions” are indispensable for the realisation of freedoms enshrined under
Article 19, as they are what ensure that enjoyment of rights is not arbitrary or excessive, so as to
affect public interest. This Court, while sitting 9R. Alexy, A Theory of Constitutional Rights (Oxford,
Oxford University Press, 2002). 10Ibid at page 47.
11Ibid, page 50.
12Ibid, page 66.
in a Constitution Bench in one of its earliest judgments in Chintaman Rao v. State of Madhya
Pradesh, AIR 1951 SC 118 interpreted limitations on personal liberty, and the balancing thereof, as
follows:
“7. The phrase “reasonable restriction” connotes that the limitation imposed on a
person in enjoyment of the right should not be arbitrary or of an excessive nature,
beyond what is required in the interests of the public. The word “reasonable” implies
intelligent care and deliberation, that is, the choice of a course which reason dictates.
Legislation which arbitrarily or excessively invades the right cannot be said to contain
the quality of reasonableness and unless it strikes a proper balance between the
freedom guaranteed in Article 19(1)(g) and the social control permitted by clause (6)
of Article 19, it must be held to be wanting in that quality.” (emphasis supplied) This
Court, in State of Madras v. V.G. Row, AIR 1952 SC 196, while laying down the test of
reasonableness, held that:
15. … It is important in this context to bear in mind that the test of reasonableness,
wherever prescribed, should be applied to each individual statute impugned, and no
abstract standard or general pattern, of reasonableness can be laid down as
applicable to all cases.Anuradha Bhasin vs Union Of India on 10 January, 2020

The nature of the right alleged to have been infringed, the underlying purpose of the restrictions
imposed, the extent and urgency of the evil sought to be remedied thereby, the disproportion of the
imposition, the prevailing conditions at the time, should all enter into the judicial verdict….
(emphasis supplied) A Constitution Bench of this Court in Mohammed Faruk v. State of Madhya
Pradesh, (1969) 1 SCC 853 while determining rights under Article 19(1)(g) of the Constitution,
discussed the doctrine of proportionality in the aforesaid terms:
“10. … The Court must in considering the validity of the impugned law imposing a
prohibition on the carrying on of a business or profession, attempt an evaluation of
its direct and immediate impact upon the fundamental rights of the citizens affected
thereby and the larger public interest sought to be ensured in the light of the object
sought to be achieved, the necessity to restrict the citizen's freedom … the possibility
of achieving the object by imposing a less drastic restraint … or that a less drastic
restriction may ensure the object intended to be achieved.” (emphasis supplied) In
the case of Om Kumar v. Union of India, (2001) 2 SCC 386 the principle of
proportionality, in light of administrative orders, was explained as follows:
28. By “proportionality”, we mean the question whether, while regulating exercise of
fundamental rights, the appropriate or least−restrictive choice of measures has been
made by the legislature or the administrator so as to achieve the object of the
legislation or the purpose of the administrative order, as the case maybe.
Under the principle, the court will see that the legislature and the administrative authority
“maintain a proper balance between the adverse effects which the legislation or the administrative
order may have on the rights, liberties or interests of persons keeping in mind the purpose which
they were intended to serve”. The legislature and the administrative authority are, however, given an
area of discretion or a range of choices but as to whether the choice made infringes the rights
excessively or not is for the court. That is what is meant by proportionality.
(emphasis supplied) [See also State of Bihar v. Kamla Kant Misra, (1969) 3 SCC 337; Bishambhar
Dayal Chandra Mohan v. State of Uttar Pradesh, (1982) 1 SCC 39]
54. Recently, this Court in Modern Dental College & Research Centre v. State of Madhya Pradesh,
(2016) 7 SCC 353 has held that no constitutional right can be claimed to be absolute in a realm
where rights are interconnected to each other, and limiting some rights in public interest might
therefore be justified. The Court held as follows:
“62. It is now almost accepted that there are no absolute constitutional rights.
[Though, debate on this vexed issue still continues and some constitutional experts
claim that there are certain rights, albeit very few, which can still be treated as
“absolute”. Examples given are:(a) Right to human dignity which is inviolable, (b)
Right not to be subjected to torture or to inhuman or degrading treatment or
punishment. Even in respect of such rights, there is a thinking that in larger publicAnuradha Bhasin vs Union Of India on 10 January, 2020

interest, the extent of their protection can be diminished. However, so far such
attempts of the States have been thwarted by the judiciary.] … In fact, such a
provision in Article 19 itself on the one hand guarantees some certain freedoms in
clause (1) of Article 19 and at the same time empowers the State to impose reasonable
restrictions on those freedoms in public interest. This notion accepts the modern
constitutional theory that the constitutional rights are related. This relativity means
that a constitutional licence to limit those rights is granted where such a limitation
will be justified to protect public interest or the rights of others. This
phenomenon—of both the right and its limitation in the Constitution— exemplifies
the inherent tension between democracy’s two fundamental elements...” (emphasis
supplied)
55. In the aforesaid case, this Court was posed with a dilemma as to how to treat competing rights.
The Court attempted to resolve the conflict by holding that rights and limitations must be
interpreted harmoniously so as to facilitate coexistence. This Court observed therein:
“62… On the one hand is the right’s element, which constitutes a fundamental
component of substantive democracy; on the other hand is the people element,
limiting those very rights through their representatives. These two constitute a
fundamental component of the notion of democracy, though this time in its formal
aspect. How can this tension be resolved? The answer is that this tension is not
resolved by eliminating the “losing” facet from the Constitution. Rather, the tension
is resolved by way of a proper balancing of the competing principles. This is one of
the expressions of the multi−faceted nature of democracy. Indeed, the inherent
tension between democracy’s different facets is a “constructive tension”. It enables
each facet to develop while harmoniously coexisting with the others. The best way to
achieve this peaceful coexistence is through balancing between the competing
interests. Such balancing enables each facet to develop alongside the other facets, not
in their place. This tension between the two fundamental aspects—rights on the one
hand and its limitation on the other hand—is to be resolved by balancing the two so
that they harmoniously coexist with each other. This balancing is to be done keeping
in mind the relative social values of each competitive aspects when considered in
proper context.” (emphasis supplied)
56. The next conundrum faced by the Court was in achieving the requisite balance, the solution for
which was derived from the principle of proportionality. The eminent constitutional jurist, Kai
Möller states that the proportionality principle is the doctrinal tool which guides Judges through the
process of resolving these conflicts.13 One of the theories of proportionality widely relied upon by
most theorists is the version developed by the German Federal Constitutional Court. The aforesaid
doctrine lays down a four pronged test wherein, first, it has to be analysed as to whether the
measure restricting the rights serves a legitimate goal (also called as legitimate goal test), then it has
to be analysed whether the measure is a suitable means of furthering this goal (the rational
connection stage), next it has to be assessed whether there existed an equally effective but lesser
restrictive alternative remedy (the necessity test) and at last, it should be analysed if such a measureAnuradha Bhasin vs Union Of India on 10 January, 2020

had a disproportionate impact on the right−holder (balancing stage). One important 13Kai Möller,
The Global Model of Constitutional Rights (Oxford, Oxford University Press, 2012).
feature of German test is the last stage of balancing, which determines the outcome as most of the
important issues are pushed to the balancing stage and the same thereby dominates the legal
analysis. Under this approach, any goal which is legitimate will be accepted; as usually a lesser
restrictive measure might have the disadvantage of being less effective and even marginal
contribution to the goal will suffice the rational connection test.14
57. The aforesaid test needs to be contrasted with its Canadian counterpart also known as the Oakes
test. According to the said doctrine, the object of the measure must be compelling enough to warrant
overriding of the constitutionally guaranteed freedom; a rational nexus must exist between such a
measure and the object sought to be achieved; the means must be least restrictive; and lastly, there
must be proportionality between the effects of such measure and the object sought to be achieved.
This doctrine of proportionality is elaborately propounded by Dickson, C.J., of the Supreme Court of
Canada in R. v. Oakes, (1986) 1 SCR 103 (Can) SC, in the following words (at p. 138):
14Kai Möller, Constructing the Proportionality Test: An Emerging Global
Conversation, Reasoning Rights Comparative Judicial Engagement (Hart Publishing,
2014).
“To establish that a limit is reasonable and demonstrably justified in a free and
democratic society, two central criteria must be satisfied. First, the objective, which
the measures, responsible for a limit on a Charter right or freedom are designed to
serve, must be “of sufficient importance to warrant overriding a constitutionally
protected right or freedom” … Second … the party invoking Section 1 must show that
the means chosen are reasonable and demonstrably justified. This involves “a form of
proportionality test”… Although the nature of the proportionality test will vary
depending on the circumstances, in each case courts will be required to balance the
interests of society with those of individuals and groups. There are, in my view, three
important components of a proportionality test. First, the measures adopted must be
… rationally connected to the objective. Second, the means … should impair “as little
as possible” the right or freedom in question … Third, there must be a proportionality
between the effects of the measures which are responsible for limiting the Charter
right or freedom, and the objective which has been identified as of “sufficient
importance”... The more severe the deleterious effects of a measure, the more
important the objective must be if the measure is to be reasonable and demonstrably
justified in a free and democratic society.” (emphasis supplied)
58. As can be seen, there exists substantial difference in both approaches, as the Oakes test, instead
of requiring “any” legitimate goal, demands the same to be compelling enough to warrant the
limitation of constitutional rights. Additionally, while the German necessity test calls for a lesser
restrictive measure which is equivalently effective, the need for effectiveness has been done away
with in the Oakes test wherein the requirement of least infringing measure has been stipulated.Anuradha Bhasin vs Union Of India on 10 January, 2020

59. It is also imperative for us to place reliance on Aharon Barak’s seminal book15 on
proportionality upon which Dr A.K. Sikri, J. placed reliance while expounding the doctrine of
proportionality in Modern Dental College case (supra) as follows:
“60. … a limitation of a constitutional right will be constitutionally permissible if:
(i) it is designated for a proper purpose;
(ii) the measures undertaken to effectuate such a limitation are rationally connected
to the fulfilment of that purpose;
(iii) the measures undertaken are necessary in that there are no alternative measures
that may similarly achieve that same purpose with a lesser degree of limitation; and
finally
(iv) there needs to be a proper relation (“proportionality stricto sensu” or
“balancing”) between the importance of achieving the proper purpose and the social
importance of preventing the limitation on the constitutional right.” (emphasis
supplied) 15Aharon Barak, Proportionality: Constitutional Rights and Their
Limitation (Cambridge University Press, 2012)
60. In Modern Dental College case (supra), this Court also went on to analyse that the principle of
proportionality is inherently embedded in Indian Constitution under the realm of the doctrine of
reasonable restrictions and that the same can be traced under Article 19. The relevant extracts are
placed below:
“65. We may unhesitatingly remark that this doctrine of proportionality, explained
hereinabove in brief, is enshrined in Article 19 itself when we read clause (1) along
with clause (6) thereof. While defining as to what constitutes a reasonable restriction,
this Court in a plethora of judgments has held that the expression “reasonable
restriction” seeks to strike a balance between the freedom guaranteed by any of the
sub−clauses of clause (1) of Article 19 and the social control permitted by any of the
clauses (2) to (6). It is held that the expression “reasonable” connotes that the
limitation imposed on a person in the enjoyment of the right should not be arbitrary
or of an excessive nature beyond what is required in the interests of public. Further,
in order to be reasonable, the restriction must have a reasonable relation to the object
which the legislation seeks to achieve, and must not go in excess of that object (see
P.P. Enterprises v. Union of India, (1982) 2 SCC 33). At the same time,
reasonableness of a restriction has to be determined in an objective manner and from
the standpoint of the interests of the general public and not from the point of view of
the persons upon whom the restrictions are imposed or upon abstract considerations
(see Mohd. Hanif Quareshi v. State of Bihar, AIR 1958 SC 731).” (emphasis supplied)Anuradha Bhasin vs Union Of India on 10 January, 2020

61. Thereafter, a comprehensive doctrine of proportionality in line with the German approach was
propounded by this Court in the Modern Dental College case (supra) wherein the Court held that:
“63. In this direction, the next question that arises is as to what criteria is to be
adopted for a proper balance between the two facets viz. the rights and limitations
imposed upon it by a statute. Here comes the concept of “proportionality”, which is a
proper criterion. To put it pithily, when a law limits a constitutional right, such a
limitation is constitutional if it is proportional. The law imposing restrictions will be
treated as proportional if it is meant to achieve a proper purpose, and if the measures
taken to achieve such a purpose are rationally connected to the purpose, and such
measures are necessary...
64. The exercise which, therefore, is to be taken is to find out as to whether the
limitation of constitutional rights is for a purpose that is reasonable and necessary in
a democratic society and such an exercise involves the weighing up of competitive
values, and ultimately an assessment based on proportionality i.e. balancing of
different interests.” (emphasis supplied)
62. While some scholars such as Robert Alexy 16 call for a strong interpretation of the necessity
stage as it has direct impact upon the realisation and optimisation of constitutional rights while
others such as David Bilchitz 17 found significant problems with this approach.
63. First, Bilchitz focuses on the issues arising out of both the German test and the Oakes test,
wherein the former treats all policies to be necessary by justifying that the available alternatives may
not be equally effective, while the latter applies the “minimal impairment test” narrowing the
constitutionally permissible policies and places a strong burden on the Government to justify its
policies. Therefore, Bilchitz argues that if the necessity stage is interpreted strictly, legislations and
policies no matter how well intended will fail to pass the proportionality inquiry if any other slightly
less drastic measure exists. Bilchitz, therefore, indicates that Alexy’s conclusion may be too quick.
16Robert Alexy, A Theory of Constitutional Rights (Oxford, Oxford University Press, 2002)
47. 17David Bilchitz, Necessity and Proportionality: Towards A Balanced Approach? in L. Lazarus,
C. McCrudden and N. Bowles (eds.), Reasoning Rights, 41 (2014).
64. Moreover, this also leads to the issue regarding the doctrine of separation of power, as Courts
would often substitute the views of the legislature in deciding what is the “least restrictive measure”.
Taking the aforesaid issues into consideration, Bilchitz proposed a moderate interpretation of the
necessity test wherein Courts may no longer be required to assess policies and measures against
impractical and unreasonable standards. He states that “[n]ecessity involves a process of reasoning
designed to ensure that only measures with a strong relationship to the objective they seek to
achieve can justify an invasion of fundamental rights. That process thus requires courts to reason
through the various stages of the moderate interpretation of necessity.”18 He therefore recommends
a four−step inquiry which is listed below:19 (MN1) All feasible alternatives need to be identified,Anuradha Bhasin vs Union Of India on 10 January, 2020

with courts being explicit as to criteria of feasibility;
(MN2) The relationship between the government measure under consideration, the alternatives
identified in MN1 and the objective sought to be achieved must be determined. An attempt must be
made to retain only those alternatives to the measure that realise the objective in a real and
substantial manner;
18 Ibid, page 61.
19Ibid, page 61.
(MN3) The differing impact of the measure and the alternatives (identified in MN2) upon
fundamental rights must be determined, with it being recognised that this requires a recognition of
approximate impact; and (MN4) Given the findings in MN2 and MN3, an overall comparison (and
balancing exercise) must be undertaken between the measure and the alternatives. A judgement
must be made whether the government measure is the best of all feasible alternatives, considering
both the degree to which it realises the government objective and the degree of impact upon
fundamental rights (‘the comparative component’).
65. Admittedly, fundamental rights may not be absolute, however, they require strong protection,
thereby mandating a sensible necessity test as the same will prevent the fundamental right from
becoming either absolute or to be diminished. Bilchitz, describes the aforesaid test to be neither
factual nor mechanical, but rather normative and qualitative. He states that “[t]he key purpose of
the necessity enquiry is to offer an explicit consideration of the relationship between means,
objectives and rights… Failure to conduct the necessity enquiry with diligence, however, means that
a government measure can escape close scrutiny in relation to both the realisation of the objective
and its impact upon fundamental rights.”20
66. Taking into consideration the aforesaid analysis, Dr. Sikri, J., in K.S. Puttaswamy (Retired) v.
Union of India, (2019) 1 SCC 1 (hereinafter “K.S. Puttaswamy (Aadhaar 5J.)”) reassessed the test
laid down in Modern Dental College Case (supra) which was based on the German Test and
modulated the same as against the tests laid down by Bilchitz. Therein this Court held that:
“157. In Modern Dental College & Research Centre [Modern Dental College &
Research Centre v. State of M.P., (2016) 7 SCC 353], four sub−components of
proportionality which need to be satisfied were taken note of. These are:
(a) A measure restricting a right must have a legitimate goal (legitimate goal stage).
(b) It must be a suitable means of furthering this goal (suitability or rational
connection stage).
(c) There must not be any less restrictive but equally effective alternative (necessity
stage).Anuradha Bhasin vs Union Of India on 10 January, 2020

(d) The measure must not have a disproportionate impact on the right−holder
(balancing stage).
158.This has been approved in K.S. Puttaswamy [K.S. Puttaswamy v. Union of India, (2017) 10 SCC
1] as well. Therefore, the aforesaid stages of proportionality can be looked into and discussed. Of
course, while undertaking this exercise it has also to be 20Ibid, 62 seen that the legitimate goal must
be of sufficient importance to warrant overriding a constitutionally protected right or freedom and
also that such a right impairs freedom as little as possible. This Court, in its earlier judgments,
applied German approach while applying proportionality test to the case at hand. We would like to
proceed on that very basis which, however, is tempered with more nuanced approach as suggested
by Bilchitz. This, in fact, is the amalgam of German and Canadian approach. We feel that the stages,
as mentioned in Modern Dental College & Research Centre [Modern Dental College & Research
Centre v. State of M.P., (2016) 7 SCC 353] and recapitulated above, would be the safe method in
undertaking this exercise, with focus on the parameters as suggested by Bilchitz, as this projects an
ideal approach that need to be adopted.” (emphasis supplied)
67. Dr. Chandrachud, J., in K.S. Puttaswamy (Aadhaar−5J.) (supra), made observations on the test
of proportionality that needs to be satisfied under our Constitution for a violation of the right to
privacy to be justified, in the following words:
“1288. In K.S. Puttaswamy v. Union of India [K.S. Puttaswamy v. Union of India, (2017) 10 SCC 1],
one of us (Chandrachud, J.), speaking for four Judges, laid down the tests that would need to be
satisfied under our Constitution for violations of privacy to be justified. This included the test of
proportionality: (SCC p. 509, para 325) “325. … A law which encroaches upon privacy will have to
withstand the touchstone of permissible restrictions on fundamental rights.
In the context of Article 21 an invasion of privacy must be justified on the basis of a law which
stipulates a procedure which is fair, just and reasonable. The law must also be valid with reference
to the encroachment on life and personal liberty under Article 21. An invasion of life or personal
liberty must meet the threefold requirement of (i) legality, which postulates the existence of law;
(ii) need, defined in terms of a legitimate State aim; and (iii) proportionality which ensures a
rational nexus between the objects and the means adopted to achieve them.” The third principle
[(iii) above] adopts the test of proportionality to ensure a rational nexus between the objects and the
means adopted to achieve them. The essential role of the test of proportionality is to enable the
court to determine whether a legislative measure is disproportionate in its interference with the
fundamental right. In determining this, the court will have regard to whether a less intrusive
measure could have been adopted consistent with the object of the law and whether the impact of
the encroachment on a fundamental right is disproportionate to the benefit which is likely to ensue.
The proportionality standard must be met by the procedural and substantive aspects of the law.
Sanjay Kishan Kaul, J., in his concurring opinion, suggested a four−pronged test as follows: (SCC p.
632, para 638) “(i) The action must be sanctioned by law;
(ii) The proposed action must be necessary in a democratic society for a legitimate aim;Anuradha Bhasin vs Union Of India on 10 January, 2020

                     (iii) The      extent      of     such
                           interference        must      be
                           proportionate to the need for
                           such interference;
                     (iv) There must be procedural
                           guarantees against abuse of
                           such interference.”
                                                     (emphasis supplied)
68. After   applying    the   aforesaid   doctrine   in   deciding   the
constitutional validity of the Aadhaar scheme, Dr. Chandrachud, J., in the K.S. Puttaswamy
(Aadhaar−5J.) case (supra), reiterated the fundamental precepts of doctrine of proportionality in
relation to protection of privacy interests while dealing with personal data:
“1324. The fundamental precepts of proportionality, as they emerge from decided cases can be
formulated thus:
1324.1. A law interfering with fundamental rights must be in pursuance of a
legitimate State aim;
1324.2. The justification for rights−infringing measures that interfere with or limit
the exercise of fundamental rights and liberties must be based on the existence of a
rational connection between those measures, the situation in fact and the object
sought to be achieved;
1324.3. The measures must be necessary to achieve the object and must not infringe
rights to an extent greater than is necessary to fulfil the aim; 1324.4. Restrictions
must not only serve legitimate purposes; they must also be necessary to protect them;
and 1324.5. The State must provide sufficient safeguards relating to the storing and
protection of centrally stored data. In order to prevent arbitrary or abusive
interference with privacy, the State must guarantee that the collection and use of
personal information is based on the consent of the individual; that it is authorised
by law and that sufficient safeguards exist to ensure that the data is only used for the
purpose specified at the time of collection. Ownership of the data must at all times
vest in the individual whose data is collected. The individual must have a right of
access to the data collected and the discretion to opt out.” (emphasis supplied)
69. This is the current state of the doctrine of proportionality as it exists in India,
wherein proportionality is the key tool to achieve judicial balance. But many scholars
are not agreeable to recognize proportionality equivalent to that of balancing.21
70. In view of the aforesaid discussion, we may summarize the requirements of the
doctrine of proportionality which must be followed by the authorities before passing
any order intending on restricting fundamental rights of individuals. In the first stageAnuradha Bhasin vs Union Of India on 10 January, 2020

itself, the possible goal of such a measure intended at imposing restrictions must be
determined. It ought to be noted that such goal must be legitimate. However, before
settling on the aforesaid measure, the authorities must assess the existence of any
alternative mechanism in furtherance of the aforesaid goal. The appropriateness of
such a measure depends on its implication upon the fundamental rights and the
necessity of such measure.
It is undeniable from the aforesaid holding that only the least restrictive measure can be resorted to
by the State, taking into consideration the facts and circumstances. Lastly, since the order has
serious implications on the fundamental rights of the 21Julian Rivers, Proportionality and Variable
Intensity of Review, (2006) 65 C.L.J. 174 (hereinafter Rivers, “Proportionality”); Martin Luteran,
Towards Proportionality as a Proportion Between Means and Ends in Cian C. Murphy and Penny
Green (eds.), Law and Outsiders: Norms, Processes and “Othering” in the 21st Century (2011)
(hereinafter Luteran, “Towards Proportionality”); see also the contribution of Alison L. Young in
Chapter 3 of this volume.
affected parties, the same should be supported by sufficient material and should be amenable to
judicial review.
71. The degree of restriction and the scope of the same, both territorially and temporally, must stand
in relation to what is actually necessary to combat an emergent situation.
72. To consider the immediate impact of restrictions upon the realization of the fundamental rights,
the decision maker must prioritize the various factors at stake. Such attribution of relative
importance is what constitutes proportionality. It ought to be noted that a decision which curtails
fundamental rights without appropriate justification will be classified as disproportionate. The
concept of proportionality requires a restriction to be tailored in accordance with the territorial
extent of the restriction, the stage of emergency, nature of urgency, duration of such restrictive
measure and nature of such restriction. The triangulation of a restriction requires the consideration
of appropriateness, necessity and the least restrictive measure before being imposed.
73. In this context, we need to note that the Petitioners have relied on a recent judgment of the High
Court of Hong Kong, in Kwok Wing Hang and Ors. v. Chief Executive in Council, [2019] HKCFI
2820 to state that the Hong Kong High Court has utilised the principle to declare the “anti−mask”
law as unconstitutional. In any case, we need not comment on the law laid down therein, as this
Court has independently propounded the test of proportionality as applicable in the Indian context.
However, we may just point out that the proportionality test needs to be applied in the context of
facts and circumstances, which are very different in the case at hand.
74. Having observed the law on proportionality and reasonable restrictions, we need to come back to
the application of restrictions on the freedom of speech over the internet.
75. The respondent−State has vehemently opposed selective access to internet services based on lack
of technology to do the same. If such a contention is accepted, then the Government would have aAnuradha Bhasin vs Union Of India on 10 January, 2020

free pass to put a complete internet blockage every time. Such complete blocking/prohibition
perpetually cannot be accepted by this Court.
76. However, there is ample merit in the contention of the Government that the internet could be
used to propagate terrorism thereby challenging the sovereignty and integrity of India. This Court
would only observe that achievement of peace and tranquillity within the erstwhile State of Jammu
and Kashmir requires a multifaceted approach without excessively burdening the freedom of
speech. In this regard the Government is required to consider various options under Article 19(2) of
the Constitution, so that the brunt of exigencies is decimated in a manner which burdens freedom of
speech in a minimalist manner.
77. Having discussed the general constitutional ambit of the fundamental rights, proportionality and
reasonable restrictions, and a specific discussion on freedom of expression through the internet and
its restriction under Article 19(2), we now need to analyse the application of the same in the present
case. F. INTERNET SHUTDOWN
78. Having observed the substantive law concerning the right to internet and the restrictions that
can be imposed on the same, we need to turn our attention to the procedural aspect.
79. It must be noted that although substantive justice under the fundamental rights analysis is
important, procedural justice cannot be sacrificed on the altar of substantive justice. There is a need
for procedural justice in cases relating to restrictions which impact individuals’ fundamental rights
as was recognized by this Court in the case of Maneka Gandhi v. Union of India, (1978) 1 SCC 248
and the K. S. Puttaswamy (Privacy−9J.) case (supra).
80. The procedural mechanism contemplated for restrictions on the Internet, is twofold: first is
contractual, relating to the contract signed between Internet Service Providers and the Government,
and the second is statutory, under the Information Technology Act, 2000, the Criminal Procedure
Code, 1973 and the Telegraph Act. In the present case, we are concerned only with the statutory
scheme available, particularly under the Telegraph Act, and we will therefore confine our discussion
mostly to the same. However, as it would be apposite to distinguish between the different statutory
mechanisms, we would touch upon these cursorily.
81. Section 69A of the Information Technology Act, 2000 read with the Information Technology
(Procedures and Safeguards for Blocking for Access of Information by Public) Rules, 2009 allows
blocking of access to information. This Court, in the Shreya Singhal case (supra), upheld the
constitutional validity of this Section and the Rules made thereunder. It is to be noted however, that
the field of operation of this section is limited in scope. The aim of the section is not to restrict/block
the internet as a whole, but only to block access to particular websites on the internet. Recourse
cannot, therefore, be made by the Government to restrict the internet generally under this section.
82. Prior to 2017, any measure restricting the internet generally or even shutting down the internet
was passed under Section 144, Cr.P.C., a general provision granting wide powers to the Magistrates
specified therein to pass orders in cases of apprehended danger. In 2015, the High Court of Gujarat,Anuradha Bhasin vs Union Of India on 10 January, 2020

in the case of Gaurav Sureshbhai Vyas v. State of Gujarat, in Writ Petition (PIL) No. 191 of 2015,
considered a challenge to an order under Section 144, Cr.P.C. blocking access to mobile internet
services in the State of Gujarat. The High Court of Gujarat, vide order dated 15.09.2015, upheld the
restriction imposed by the Magistrate under Section 144, Cr.P.C. While the Court did not undertake
a full−fledged discussion of the power of the Magistrate to issue such restrictions under Section 144,
Cr.P.C., the Court observed as follows:
“9.…[U]nder Section 144 of the Code, directions may be issued to certain persons
who may be the source for extending the facility of internet access. Under the
circumstances, we do not find that the contention raised on behalf of the petitioner
that the resort to only Section 69A was available and exercise of power under Section
144 of the Code was unavailable, can be accepted.” (emphasis supplied) A Special
Leave Petition was filed against the above judgment of the Gujarat High Court, being
SLP (C) No. 601 of 2016, which was dismissed by this Court in limine on 11.02.2016.
83. The position has changed since 2017, with the passage of the Suspension Rules under Section 7
of the Telegraph Act. With the promulgation of the Suspension Rules, the States are using the
aforesaid Rules to restrict telecom services including access to the internet.
84. The Suspension Rules lay down certain safeguards, keeping in mind the fact that an action
under the same has a large effect on the fundamental rights of citizens. It may be mentioned here
that we are not concerned with the constitutionality of the Suspension Rules, and arguments on the
same were not canvassed by either side. As such, we are limiting our discussion to the procedure laid
down therein. Rule 2 lays down the procedure to be followed for the suspension of telecom services,
and merits reproduction in its entirety:
“2.(1) Directions to suspend the telecom services shall not be issued except by an
order made by the Secretary to the Government of India in the Ministry of Home
Affairs in the case of Government of India or by the Secretary to the State
Government in−charge of the Home Department in the case of a State Government
(hereinafter referred to as the competent authority), and in unavoidable
circumstances, where obtaining of prior direction is not feasible, such order may be
issued by an officer, not below the rank of a Joint Secretary to the Government of
India, who has been duly authorised by the Union Home Secretary or the State Home
Secretary, as the case may be:
Provided that the order for suspension of telecom services, issued by the officer
authorised by the Union Home Secretary or the State Home Secretary, shall be
subject to the confirmation from the competent authority within 24 hours of issuing
such order:
Provided further that the order of suspension of telecom services shall cease to exist
in case of failure of receipt of confirmation from the competent authority within the
said period of 24 hours.Anuradha Bhasin vs Union Of India on 10 January, 2020

(2) Any order issued by the competent authority under sub−rule (1) shall contain
reasons for such direction and a copy of such order shall be forwarded to the
concerned Review Committee latest by next working day.
(3) The directions for suspension issued under sub−rule (1) shall be conveyed to
designated officers of the telegraph authority or to the designated officers of the
service providers, who have been granted licenses under section 4 of the said Act, in
writing or by secure electronic communication by an officer not below the rank of
Superintendent of Police or of the equivalent rank and mode of secure electronic
communication and its implementation shall be determined by the telegraph
authority.
(4) The telegraph authority and service providers shall designate officers in every licensed service
area or State or Union territory, as the case may be, as the nodal officers to receive and handle such
requisitions for suspension of telecom services.
(5) The Central Government or the State Government, as the case may be, shall constitute a Review
Committee.
(i) The Review Committee to be constituted by the Central Government shall consist of the
following, namely:−
(a) Cabinet Secretary−Chairman;
(b) Secretary to the Government of India In−charge, Legal Affairs−Member;
(c)   Secretary    to    the    Government,
      Department of Telecommunications
      −Member.
(ii) The Review Committee to be constituted by the State Government shall consist of the following,
namely:−
(a) Chief Secretary−Chairman;
(b)Secretary Law or Legal Remembrancer In−Charge, Legal Affairs−Member;
(c)Secretary to the State Government (other than the Home Secretary) −Member.
(6) The Review Committee shall meet within five working days of issue of directions for suspension
of services due to public emergency or public safety and record its findings whether the directions
issued under sub−rule (1) are in accordance with the provisions of sub−section (2) of section 5 of the
said Act.”Anuradha Bhasin vs Union Of India on 10 January, 2020

85. Rule 2(1) specifies the competent authority to issue an order under the Suspension Rules, who in
ordinary circumstances would be the Secretary to the Ministry of Home Affairs, Government of
India, or in the case of the State Government, the Secretary to the Home Department of the State
Government. The sub−rule also provides that in certain “unavoidable” circumstances an officer, who
is duly authorised, not below the rank of a Joint Secretary, may pass an order suspending services.
The two provisos to Rule 2(1) are extremely relevant herein, creating an internal check as to orders
which are passed by an authorised officer in “unavoidable” circumstances, as opposed to the
ordinary mechanism envisaged, which is the issuing of the order by the competent authority. The
provisos together provide that the orders passed by duly authorised officers in “unavoidable”
circumstances need to be confirmed by the competent authority within twenty−four hours, failing
which, as per the second proviso, the order of suspension will cease to exist. The confirmation of the
order by the competent authority is therefore essential, failing which the order passed by a duly
authorised officer will automatically lapse by operation of law.
86. Rule 2(2) is also extremely important, as it lays down twin requirements for orders passed under
Rule 2(1). First, it requires that every order passed by a competent authority under Rule 2(1) must
be a reasoned order. This requirement must be read to extend not only to orders passed by a
competent authority, but also to those orders passed by an authorised officer which is to be sent for
subsequent confirmation to the competent authority. The reasoning of the authorised officer should
not only indicate the necessity of the measure but also what the “unavoidable” circumstance was
which necessitated his passing the order. The purpose of the aforesaid rule is to integrate the
proportionality analysis within the framework of the Rules.
87. Only in such an event would the requirement of confirmation by the competent authority have
any meaning, as it would allow the competent authority to properly consider the action taken by the
authorised officer. Further, the confirmation must not be a mere formality, but must indicate
independent application of mind by the competent authority to the order passed by the authorised
officer, who must also take into account changed circumstances if any, etc. After all, it is the
competent authority who has been given the power under the Suspension Rules to suspend telecom
services, with the authorised officer acting under the Suspension Rules only due to some exigent
circumstances.
88. The second requirement under Rule 2(2) is the forwarding of the reasoned order of the
competent authority to a Review Committee which has been set up under the Suspension Rules,
within one working day. The composition of the Review Committee is provided under Rule 2(5),
with two distinct review committees contemplated for the Union and the State, depending on the
competent authority which issued the order under Rule 2(1). Rule 2(6) is the final internal check
under the Suspension Rules with respect to the orders issued thereunder. Rule 2(6) requires the
concerned Review Committee to meet within five working days of issuance of the order suspending
telecom services, and record its findings about whether the order issued under the Suspension Rules
is in accordance with the provisions of the main statute, viz., Section 5(2) of the Telegraph Act.
89. This last requirement, of the orders issued under the Rules being in accordance with Section
5(2), Telegraph Act, is very relevant to understand the circumstances in which the suspensionAnuradha Bhasin vs Union Of India on 10 January, 2020

orders may be passed. Section 5(2), Telegraph Act is as follows:
“5. Power for Government to take possession of licensed telegraphs and to order
interception of messages xxx (2) On the occurrence of any public emergency, or in the
interest of the public safety, the Central Government or a State Government or any
officer specially authorised in this behalf by the Central Government or a State
Government may, if satisfied that it is necessary or expedient so to do in the interests
of the sovereignty and integrity of India, the security of the State, friendly relations
with foreign states or public order or for preventing incitement to the commission of
an offence, for reasons to be recorded in writing, by order, direct that any message or
class of messages to or from any person or class of persons, or relating to any
particular subject, brought for transmission by or transmitted or received by any
telegraph, shall not be transmitted, or shall be intercepted or detained, or shall be
disclosed to the Government making the order or an officer thereof mentioned in the
order:
Provided that the press messages intended to be published in India of correspondents
accredited to the Central Government or a State Government shall not be intercepted
or detained, unless their transmission has been prohibited under this sub−section.”
90. This Court has had prior occasion to interpret Section 5 of the Telegraph Act. In the case of
Hukam Chand Shyam Lal v. Union of India, (1976) 2 SCC 128, a Four−Judge Bench of this Court
interpreted Section 5 of the Telegraph Act and observed as follows:
“13. Section 5(1) if properly construed, does not confer unguided and unbridled
power on the Central Government/State Government/ specially authorised officer to
take possession of any telegraphs. Firstly, the occurrence of a “public emergency” is
the sine qua non for the exercise of power under this section. As a preliminary step to
the exercise of further jurisdiction under this section the Government or the
authority concerned must record its satisfaction as to the existence of such an
emergency. Further, the existence of the emergency which is a pre−requisite for the
exercise of power under this section, must be a “public emergency” and not any other
kind of emergency. The expression public emergency has not been defined in the
statute, but contours broadly delineating its scope and features are discernible from
the section which has to be read as a whole. In sub−section (1) the phrase ‘occurrence
of any public emergency’ is connected with and is immediately followed by the phrase
“or in the interests of the public safety”. These two phrases appear to take colour
from each other. In the first part of sub−section (2) those two phrases again occur in
association with each other, and the context further clarifies with amplification that a
“public emergency” within the contemplation of this section is one which raises
problems concerning the interest of the public safety, the sovereignty and integrity of
India, the security of the State, friendly relations with foreign States or public order
or the prevention of incitement to the commission of an offence. It is in the context of
these matters that the appropriate authority has to form an opinion with regard toAnuradha Bhasin vs Union Of India on 10 January, 2020

the occurrence of a public emergency with a view to taking further action under this
section...” (emphasis supplied)
91. The aforementioned case was followed in People’s Union for Civil Liberties (PUCL) v. Union of
India, (1997) 1 SCC 301, in the context of phone−tapping orders passed under Section 5(2) of the
Telegraph Act, wherein this Court observed as follows:
“29. The first step under Section 5(2) of the Act, therefore, is the occurrence of any
public emergency or the existence of a public safety interest. Thereafter the
competent authority under Section 5(2) of the Act is empowered to pass an order of
interception after recording its satisfaction that it is necessary or expedient so to do
in the interest of (i) sovereignty and integrity of India, (ii) the security of the State,
(iii) friendly relations with foreign States, (iv) public order or (v) for preventing
incitement to the commission of an offence. When any of the five situations
mentioned above to the satisfaction of the competent authority require then the said
authority may pass the order for interception of messages by recording reasons in
writing for doing so.”
92. Keeping in mind the wordings of the section, and the above two pronouncements of this Court,
what emerges is that the pre− requisite for an order to be passed under this sub−section, and
therefore the Suspension Rules, is the occurrence of a “public emergency” or for it to be “in the
interest of public safety”. Although the phrase “public emergency” has not been defined under the
Telegraph Act, it has been clarified that the meaning of the phrase can be inferred from its usage in
conjunction with the phrase “in the interest of public safety” following it. The Hukam Chand Shyam
Lal case (supra) further clarifies that the scope of “public emergency” relates to the situations
contemplated under the sub−section pertaining to “sovereignty and integrity of India, the security of
the State, friendly relations with foreign states or public order or for preventing incitement to the
commission of an offence”.
93. The word ‘emergency’ has various connotations. Everyday emergency, needs to be distinguished
from the type of emergency wherein events which involve, or might involve, serious and sometimes
widespread risk of injury or harm to members of the public or the destruction of, or serious damage
to, property. Article 4 of the International Covenant on Civil and Political Rights, notes that ‘[I]n
time of public emergency which threatens the life of the nation and the existence of which is
officially proclaimed...’. Comparable language has also been used in Article 15 of the European
Convention on Human Rights which says− "In time of war or other public emergency threatening
the life of the nation". We may only point out that the ‘public emergency’ is required to be of serious
nature, and needs to be determined on a case to case basis.
94. The second requirement of Section 5(2) of the Telegraph Act is for the authority to be satisfied
that it is necessary or expedient to pass the orders in the interest of the sovereignty and integrity of
India, the security of the State, friendly relations with foreign states or public order or for preventing
incitement to the commission of an offence, and must record reasons thereupon. The termAnuradha Bhasin vs Union Of India on 10 January, 2020

‘necessity’ and ‘expediency’ brings along the stages an emergency is going to pass through usually. A
public emergency usually would involve different stages and the authorities are required to have
regards to the stage, before the power can be utilized under the aforesaid rules. The appropriate
balancing of the factors differs, when considering the stages of emergency and accordingly, the
authorities are required to triangulate the necessity of imposition of such restriction after satisfying
the proportionality requirement.
95. A point canvassed by the learned counsel for the Petitioner, Ms. Vrinda Grover, with regard to
the interpretation of the proviso to Section 5(2) of the Telegraph Act. The proviso to the section
specifies that a class of messages, i.e., press messages intended to be published in India of
correspondents accredited to the Central Government or a State Government, will be treated
differently from other classes of messages. The learned counsel contended that this separate
classification necessitates that an order interfering with the press would be in compliance with
Section 5(2) of the Telegraph Act only if it specifically states that the press is also to be restricted.
However, the aforesaid interpretation could not be supported by the petitioner with any judgments
of this Court.
96. It must be noted that although the Suspension Rules does not provide for publication or
notification of the orders, a settled principle of law, and of natural justice, is that an order,
particularly one that affects lives, liberty and property of people, must be made available. Any law
which demands compliance of the people requires to be notified directly and reliably. This is the
case regardless of whether the parent statute or rule prescribes the same or not. We are therefore
required to read in the requirement of ensuring that all the orders passed under the Suspension
Rules are made freely available, through some suitable mechanism. [See B.K. Srinivasan v. State of
Karnataka, (1987) 1 SCC 658]
97. The above requirement would further the rights of an affected party to challenge the orders, if
aggrieved. Judicial review of the orders issued under the Suspension Rules is always available,
although no appellate mechanism has been provided, and the same cannot be taken away or made
ineffective. An aggrieved person has the constitutional right to challenge the orders made under the
Suspension Rules, before the High Court under Article 226 of the Constitution or other appropriate
forum.
98. We also direct that all the above procedural safeguards, as elucidated by us, need to be
mandatorily followed. In this context, this Court in the Hukam Chand Shyam Lal case (supra),
observed as follows:
“18. It is well−settled that where a power is required to be exercised by a certain
authority in a certain way, it should be exercised in that manner or not at all, and all
other amodes (sic) of performance are necessarily forbidden. It is all the more
necessary to observe this rule where power is of a drastic nature...” (emphasis
supplied) This applies with even more force considering the large public impact on
the right to freedom of speech and expression that such a broad−based restriction
would have.Anuradha Bhasin vs Union Of India on 10 January, 2020

99. Lastly, we think it necessary to reiterate that complete broad suspension of telecom services, be
it the Internet or otherwise, being a drastic measure, must be considered by the State only if
‘necessary’ and ‘unavoidable’. In furtherance of the same, the State must assess the existence of an
alternate less intrusive remedy. Having said so, we may note that the aforesaid Suspension Rules
have certain gaps, which are required to be considered by the legislature.
100. One of the gaps which must be highlighted relates to the usage of the word “temporary” in the
title of the Suspension Rules. Despite the above, there is no indication of the maximum duration for
which a suspension order can be in operation. Keeping in mind the requirements of proportionality
expounded in the earlier section of the judgment, we are of the opinion that an order suspending the
aforesaid services indefinitely is impermissible. In this context, it is necessary to lay down some
procedural safeguard till the aforesaid deficiency is cured by the legislature to ensure that the
exercise of power under the Suspension Rules is not disproportionate. We therefore direct that the
Review Committee constituted under Rule 2(5) of the Suspension Rules must conduct a periodic
review within seven working days of the previous review, in terms of the requirements under Rule
2(6). The Review Committee must therefore not only look into the question of whether the
restrictions are still in compliance with the requirements of Section 5(2) of the Telegraph Act, but
must also look into the question of whether the orders are still proportionate, keeping in mind the
constitutional consequences of the same. We clarify that looking to the fact that the restrictions
contemplated under the Suspension Rules are temporary in nature, the same must not be allowed to
extend beyond that time period which is necessary.
101. Coming to the orders placed before us regarding restrictions on communication and Internet,
there are eight orders that are placed before us. Four orders have been passed by the Inspector
General of Police, of the respective zone, while the other four orders are confirmation orders passed
by the Principal Secretary to the Government of Jammu and Kashmir, Home Department,
confirming the four orders passed by the Inspector General of Police.
102. The learned Solicitor General has apprised the Bench that the authorities are considering
relaxation of the restrictions and in some places the restrictions have already been removed. He also
pointed that the authorities are constantly reviewing the same. In this case, the submission of the
Solicitor General that there is still possibility of danger to public safety cannot be ignored, as this
Court has not been completely apprised about the ground situation by the State. We believe that the
authorities have to pass their orders based on the guidelines provided in this case afresh. The
learned Solicitor General had submitted, on a query being put to him regarding the feasibility of a
measure blocking only social media services, that the same could not be done. However, the State
should have attempted to determine the feasibility of such a measure. As all the orders have not
been placed before this Court and there is no clarity as to which orders are in operation and which
have already been withdrawn, as well as the apprehension raised in relation to the possibility of
public order situations, we have accordingly moulded the relief in the operative portion.
G. RESTRICTIONS UNDER SECTION 144 OF CRPC.Anuradha Bhasin vs Union Of India on 10 January, 2020

“As emergency does not shield the actions of Government completely; disagreement does not justify
destabilisation;
the beacon of rule of law shines always.”
103. The Petitioners have asserted that there were no disturbing facts which warranted the
imposition of restrictions under Section 144, Cr.P.C. on 04.08.2019. They strenuously argued that
there had to be a circumstance on 04.08.2019 showing that there would be an action which will
likely create obstruction, annoyance or injury to any person or will likely cause disturbance of the
public tranquillity, and the Government could not have passed such orders in anticipation or on the
basis of a mere apprehension.
104. In response, the learned Solicitor General, on behalf of the Respondent, argued that the volatile
history, overwhelming material available even in the public domain about external aggressions,
nefarious secessionist activities and the provocative statements given by political leaders, created a
compelling situation which mandated passing of orders under Section 144, Cr.P.C.
105. These contentions require us to examine the scope of Section 144, Cr.P.C, which reads as
follows:
“144. Power to issue order in urgent cases of nuisance or apprehended danger.—(1) In
cases where, in the opinion of a District Magistrate, a Sub−divisional Magistrate or
any other Executive Magistrate specially empowered by the State Government in this
behalf, there is sufficient ground for proceeding under this section and immediate
prevention or speedy remedy is desirable, such Magistrate may, by a written order
stating the material facts of the case and served in the manner provided by Section
134, direct any person to abstain from a certain act or to take certain order with
respect to certain property in his possession or under his management, if such
Magistrate considers that such direction is likely to prevent, or tends to prevent,
obstruction, annoyance or injury to any person lawfully employed, or danger to
human life, health or safety, or a disturbance of the public tranquillity, or a riot, or an
affray. (2) An order under this section may, in cases of emergency or in cases where
the circumstances do not admit of the serving in due time of a notice upon the person
against whom the order is directed, be passed ex parte. (3) An order under this
section may be directed to a particular individual, or to persons residing in a
particular place or area, or to the public generally when frequenting or visiting a
particular place or area.
(4) No order under this section shall remain in force for more than two months from
the making thereof:
Provided that, if the State Government considers it necessary so to do for preventing
danger to human life, health or safety or for preventing a riot or any affray, it may, by
notification, direct that an order made by a Magistrate under this section shallAnuradha Bhasin vs Union Of India on 10 January, 2020

remain in force for such further period not exceeding six months from the date on
which the order made by the Magistrate would have, but for such order, expired, as it
may specify in the said notification.
(5) Any Magistrate may, either on his own motion or on the application of any person
aggrieved, rescind or alter any order made under this section, by himself or any
Magistrate subordinate to him or by his predecessor−in−office.
(6) The State Government may, either on its own motion or on the application of any
person aggrieved, rescind or alter any order made by it under the proviso to sub−
section (4). (7) Where an application under sub−section (5) or sub−section (6) is
received, the Magistrate, or the State Government, as the case may be, shall afford to
the applicant an early opportunity of appearing before him or it, either in person or
by pleader and showing cause against the order; and if the Magistrate or the State
Government, as the case may be, rejects the application wholly or in part, he or it
shall record in writing the reasons for so doing.
106. Section 144, Cr.P.C. is one of the mechanisms that enable the State to maintain public peace. It
forms part of the Chapter in the Criminal Procedure Code dealing with “Maintenance of Public
Order and Tranquillity” and is contained in the sub−chapter on “urgent cases of nuisance or
apprehended danger”. The structure of the provision shows that this power can only be invoked in
“urgent cases of nuisance or apprehended danger”.
107. Section 144, Cr.P.C. enables the State to take preventive measures to deal with imminent
threats to public peace. It enables the Magistrate to issue a mandatory order requiring certain
actions to be undertaken, or a prohibitory order restraining citizens from doing certain things. But it
also provides for several safeguards to ensure that the power is not abused, viz.− prior inquiry before
exercising this power, setting out material facts for exercising this power and modifying/rescinding
the order when the situation so warrants.
108. The aforesaid safeguards in Section 144, Cr.P.C. are discussed below and deserve close scrutiny.
(a) Prior Inquiry before issuing Order: Before issuing an order under Section 144, Cr.P.C., the
District Magistrate (or any authorised Magistrate) must be of the opinion that:
i. There is a sufficient ground for proceeding under this provision i.e. the order is
likely to prevent obstruction, annoyance or injury to any person lawfully employed or
danger to human life, health or safety or disturbance to the public tranquillity; and ii.
Immediate prevention or speedy remedy is desirable.
The phrase “opinion” suggests that it must be arrived at after a careful inquiry by the
Magistrate about the need to exercise the extraordinary power conferred under this
provision.Anuradha Bhasin vs Union Of India on 10 January, 2020

(b) Content of the Order: Once a Magistrate arrives at an opinion, he may issue a
written order either prohibiting a person from doing something or a mandatory order
requiring a person to take action with respect to property in his possession or under
his management. But the order cannot be a blanket order. It must set out the
“material facts” of the case. The “material facts” must indicate the reasons which
weighed with the Magistrate to issue an order under Section 144, Cr.P.C.
(c) Communication of the Order: The Order must be served in the manner provided
under Section 134, Cr.P.C., i.e., served on the person against whom it is made. If such
a course of action is not practicable, it must be notified by proclamation and
publication so as to convey the information to persons affected by the order. Only in
case of an emergency or where the circumstances are such that notice cannot be
served on such a person, can the order be passed ex parte.
(d) Duration of the Order: As this power can only be exercised in urgent cases, the
statute has incorporated temporal restrictions—the order cannot be in force for more
than two months. However, the State Government can extend an order issued under
Section 144, Cr.P.C. by a Magistrate for a further period up to six months if the State
Government considers it necessary for preventing danger to human life, health or
safety or preventing a riot.
Although, a two−month period outer limit for the Magistrate, and a six−month limit for the State
Government, has been provided under Section 144, Cr.P.C. but the concerned Magistrate and the
State Government must take all steps to ensure that the restrictions are imposed for a limited
duration.
(e) Act Judicially while Rescinding or Modification of the Order: The Magistrate can rescind or alter
any order made by him on his own or on an application by any aggrieved person. Similarly, the State
Government may also on its own motion rescind or alter any order passed by it, extending an order
passed under Section 144, Cr.P.C. While considering any application for modification or alteration,
the Magistrate or the State Government is required to act judicially, i.e., give a personal hearing and
give reasons if it rejects the application. Care should be taken to dispose of such applications
expeditiously.
109. Section 144, Cr.P.C. has been the subject matter of several Constitution Bench rulings and we
will briefly examine them. The constitutional validity of Section 144, Cr.P.C. under the predecessor
of the 1898 Act came up for the first time before the Constitution Bench of this Court in Babulal
Parate case (supra). Repelling the contention that it is an infringement of the fundamental right of
assembly, this Court upheld the provision due to the various safeguards inbuilt under Section 144,
Cr.P.C. This Court opined that:
a. Section 144, Cr.P.C does not confer arbitrary power on the Magistrate, since it
must be preceded by an inquiry. b. Although Section 144, Cr.P.C confers wide powers,
it can only be exercised in an emergency, and for the purpose of preventingAnuradha Bhasin vs Union Of India on 10 January, 2020

obstruction and annoyance or injury to any person lawfully employed. Section 144,
Cr.P.C is not an unlimited power.
c. The Magistrate, while issuing an order, has to state the material facts upon which it
is based. Since the order states the relevant facts, the High Court will have relevant
material to consider whether such material is adequate to issue Section 144, Cr.P.C
order. While considering such reasons, due weight must be given to the opinion of
the District Magistrate who is responsible for the maintenance of public peace in the
district. d. This power can be exercised even when the Magistrate apprehends danger.
It is not just mere “likelihood” or a “tendency”, but immediate prevention of
particular acts to counteract danger.
e. Even if certain sections of people residing in the particular area are disturbing
public order, the Magistrate can pass an order for the entire area as it is difficult for
the Magistrate to distinguish between members of the public and the people engaging
in unlawful activity. However, any affected person can always apply to the Magistrate
under Section 144(4), Cr.P.C. seeking exemption or modification of the order to
permit them to carry out any lawful activity. f. If any person makes an application for
modification or alteration of the order, the Magistrate has to conduct a judicial
proceeding by giving a hearing, and give the reasons for the decision arrived at. g.
The order of the Magistrate under Section 144, Cr.P.C is subject to challenge before
the High Court. The High Court’s revisionary powers are wide enough to quash an
order which cannot be supported by the materials upon which the order is supposed
to be based. h. If any prosecution is launched for non−compliance of an order issued
under Section 144, Cr.P.C., the validity of such an order under Section 144, Cr.P.C.
can be challenged even at that stage.
110. The validity of the Section 144(6) under the 1898 Act again came up for consideration before a
Bench of five Judges in State of Bihar v. Kamla Kant Misra, (1969) 3 SCC 337. The majority
judgment declared the latter part of Section 144(6), Cr.P.C as it then existed, which enabled the
State Government to extend an order passed under Section 144, Cr.P.C. indefinitely, as
unconstitutional, since it did not provide limitations on the duration of the order and no mechanism
was provided therein to make a representation against the duration of the order. Under the 1973
Act, a time limit has been prescribed on the maximum duration of the order.
111. A Bench of seven Judges in the Madhu Limaye case (supra) was constituted to re−consider the
law laid down in Babulal Parate (supra) and the constitutional validity of Section 144, Cr.P.C. This
Court, while affirming the constitutional validity of Section 144, Cr.P.C. reiterated the safeguards
while exercising the power under Section 144, Cr.P.C. The Court highlighted that the power under
Section 144, Cr.P.C. must be:
(a) exercised in urgent situations to prevent harmful occurrences. Since this power
can be exercised absolutely and even ex parte, “the emergency must be sudden and
the consequences sufficiently grave”Anuradha Bhasin vs Union Of India on 10 January, 2020

(b)exercised in a judicial manner which can withstand judicial scrutiny.
This Court observed that:
“24. The gist of action under Section 144 is the urgency of the situation, its efficacy in
the likelihood of being able to prevent some harmful occurrences. As it is possible to
act absolutely and even ex parte. it is obvious that the emergency must be sudden and
the consequences sufficiently grave. Without it the exercise of power would have no
justification. It is not an ordinary power flowing from administration but a power
used in a judicial manner and which can stand further judicial scrutiny in the need
for the exercise of the power, in its efficacy and in the extent of its application. There
is no general proposition that an order under Section 144, Criminal Procedure Code
cannot be passed without taking evidence: … These fundamental facts emerge from
the way the occasions for the exercise of the power are mentioned. Disturbances of
public tranquillity, riots and affray lead to subversion of public order unless they are
prevented in time. Nuisances dangerous to human life, health or safety have no doubt
to be abated and prevented. …..In so far as the other parts of the section are
concerned the key−note of the power is to free society from menace of serious
disturbances of a grave character. The section is directed against those who attempt
to prevent the exercise of legal rights by others or imperil the public safety and
health. If that be so the matter must fall within the restrictions which the
Constitution itself visualizes as permissible in the interest of public order, or in the
interest of the general public. We may say, however, that annoyance must assume
sufficiently grave proportions to bring the matter within interests of public order.”
(emphasis supplied)
112. Again, in Mohd. Gulam Abbas v. Mohd. Ibrahim, (1978) 1 SCC 226, this Court, in deciding a
review petition, elaborated on the circumstances in which the power under Section 144, Cr.P.C. can
be exercised. This Court held as under:
“3. ...It is only where it is not practicable to allow them to do something which is quite
legal, having regard to the state of excited feelings of persons living in an area or
frequenting a locality, that any action may be taken under Section 144 of the Criminal
Procedure Code which may interfere with what are, otherwise, completely legal and
permissible conduct and speech.
4.….It may however be noted that the Magistrate is not concerned with individual
rights in performing his duty under Section 144 but he has to determine what may be
reasonably necessary or expedient in a situation of which he is the best judge.
5.… If public peace and tranquillity or other objects mentioned there are not in
danger the Magistrate concerned cannot act under SectionAnuradha Bhasin vs Union Of India on 10 January, 2020

144. He could only direct parties to go to the proper forum. On the other hand, if the
public safety, peace, or tranquillity are in danger, it is left to the Magistrate concerned
to take proper action under Section 144, Cr.P.C.” (emphasis supplied)
113. In Gulam Abbas v. State of Uttar Pradesh, (1982) 1 SCC 71, this Court held that an order passed
under Section 144, Cr.P.C. is an executive order which can be questioned in exercise of writ
jurisdiction under Article 226 of the Constitution. The Court reiterated the circumstances in which
the power can be exercised. The Court observed as under:
“27. The entire basis of action under Section 144 is provided by the urgency of the
situation and the power thereunder is intended to be availed of for preventing
disorders, obstructions and annoyances with a view to secure the public weal by
maintaining public peace and tranquillity.
Preservation of the public peace and tranquillity is the primary function of the Government and the
aforesaid power is conferred on the executive magistracy enabling it to perform that function
effectively during emergent situations and as such it may become necessary for the Executive
Magistrate to override temporarily private rights and in a given situation the power must extend to
restraining individuals from doing acts perfectly lawful in themselves, for, it is obvious that when
there is a conflict between the public interest and private rights the former must prevail. …. In other
words, the Magistrate’s action should be directed against the wrong−doer rather than the wronged.
Furthermore, it would not be a proper exercise of discretion on the part of the Executive Magistrate
to interfere with the lawful exercise of the right by a party on a consideration that those who
threaten to interfere constitute a large majority and it would be more convenient for the
administration to impose restrictions which would affect only a minor section of the community
rather than prevent a larger section more vociferous and militant.
33. ...It is only in an extremely extraordinary situation, when other measures are bound to fail, that
a total prohibition or suspension of their rights may be resorted to as a last measure.” (emphasis
supplied)
114. Again, in Acharya Jagdishwaranand Avadhuta v. Commr. of Police, Calcutta, (1983) 4 SCC 522,
a Bench of three Judges expressed doubts about the dicta in the Gulam Abbas case (supra) on the
nature of the order under Section 144, Cr.P.C. but reiterated that repetitive orders under Section
144, Cr.P.C. would be an abuse of power. This Court observed as follows:
“16…. The scheme of that section does not contemplate repetitive orders and in case
the situation so warrants steps have to be taken under other provisions of the law
such as Section 107 or Section 145 of the Code when individual disputes are raised
and to meet a situation such as here, there are provisions to be found in the Police
Act. If repetitive orders are made it would clearly amount to abuse of the power
conferred by Section 144 of the Code.” (emphasis supplied)Anuradha Bhasin vs Union Of India on 10 January, 2020

115. In Ramlila Maidan Incident, In re, (2012) 5 SCC 1, this Court emphasised the safeguards under
Section 144, Cr.P.C. and the circumstances under which such an order can be issued.
116. The learned counsel on behalf of the Petitioners vehemently contested the power of the
Magistrate to pass the aforesaid orders under Section 144, Cr.P.C. as there existed no incumbent
situation of emergency. It was argued that such orders passed in mere anticipation or apprehension
cannot be sustained in the eyes of law. As explained above, the power under Section 144, Cr.P.C. is a
preventive power to preserve public order. In Babulal Parate case (supra), this Court expressly
clarified that this power can be exercised even where there exists an apprehension of danger. This
Court observed as under:
“25. The language of Section 144 is somewhat different. The test laid down in the
section is not merely “likelihood” or “tendency”. The section says that the Magistrate
must be satisfied that immediate prevention of particular acts is necessary to
counteract danger to public safety etc. The power conferred by the section is
exercisable not only where present danger exists but is exercisable also when there is
an apprehension of danger.” (emphasis supplied)
117. In view of the language of the provision and settled law, we are unable to accept the aforesaid
contention.
118. Further, learned senior counsel Mr. Kapil Sibal expressed his concern that in the future any
State could pass such type of blanket restrictions, for example, to prevent opposition parties from
contesting or participating in elections. In this context, it is sufficient to note that the power under
Section 144, Cr.P.C. cannot be used as a tool to prevent the legitimate expression of opinion or
grievance or exercise of any democratic rights. Our Constitution protects the expression of divergent
views, legitimate expressions and disapproval, and this cannot be the basis for invocation of Section
144, Cr.P.C. unless there is sufficient material to show that there is likely to be an incitement to
violence or threat to public safety or danger. It ought to be noted that provisions of Section 144,
Cr.P.C. will only be applicable in a situation of emergency and for the purpose of preventing
obstruction and annoyance or injury to any person lawfully employed [refer to Babulal Parate case
(supra)]. It is enough to note that sufficient safeguards exist in Section 144, Cr.P.C., including the
presence of judicial review challenging any abuse of power under the Section, to allay the
apprehensions of the petitioner.
119. The Petitioners have also contended that ‘law and order’ is of a narrower ambit than ‘public
order’ and the invocation of ‘law and order’ would justify a narrower set of restrictions under Section
144, Cr.P.C.
120. In this context, it is pertinent for us to emphasize the holding rendered by a five−Judge Bench
of this court in Ram Manohar Lohia v. State of Bihar, AIR 1966 SC 740, wherein this Court
emphasised the difference between “public order” and “law and order” situation. This Court
observed as under:Anuradha Bhasin vs Union Of India on 10 January, 2020

“55. It will thus appear that just as “public order” in the rulings of this Court (earlier
cited) was said to comprehend disorders of less gravity than those affecting “security
of State”, “law and order” also comprehends disorders of less gravity than those
affecting “public order”. One has to imagine three concentric circles. Law and order
represents the largest circle within which is the next circle representing public order
and the smallest circle represents security of State. It is then easy to see that an act
may affect law and order but not public order just as an act may affect public order
but not security of the State. By using the expression “maintenance of law and order”
the District Magistrate was widening his own field of action and was adding a clause
to the Defence of India Rules.” (emphasis supplied)
121. This Court therein held that a mere disturbance of law and order leading to disorder may not
necessarily lead to a breach of public order. Similarly, the seven−Judge Bench in Madhu Limaye
case (supra) further elucidated as to when and against whom the power under Section 144, Cr.P.C.
can be exercised by the Magistrate. This Court held therein, as under:
“24. The gist of action under Section 144 is the urgency of the situation, its efficacy in
the likelihood of being able to prevent some harmful occurrences. As it is possible to
act absolutely and even ex parte it is obvious that the emergency must be sudden and
the consequences sufficiently grave. Without it the exercise of power would have no
justification. It is not an ordinary power flowing from administration but a power
used in a judicial manner and which can stand further judicial scrutiny in the need
for the exercise of the power, in its efficacy and in the extent of its application….
Disturbances of public tranquillity, riots and affray lead to subversion of public order
unless they are prevented in time. Nuisances dangerous to human life, health or
safety have no doubt to be abated and prevented. We are, however, not concerned
with this part of the section and the validity of this part need not be decided here. In
so far as the other parts of the section are concerned the key−note of the power is to
free society from menace of serious disturbances of a grave character. The section is
directed against those who attempt to prevent the exercise of legal rights by others or
imperil the public safety and health. If that be so the matter must fall within the
restrictions which the Constitution itself visualizes as permissible in the interest of
public order, or in the interest of the general public. We may say, however, that
annoyance must assume sufficiently grave proportions to bring the matter within
interests of public order.” (emphasis supplied)
122. This Court in Ramlila Maidan Incident, In re case (supra) further enunciated upon the
aforesaid distinction between a “public order” and “law and order” situation:
“44. The distinction between “public order” and “law and order” is a fine one, but
nevertheless clear. A restriction imposed with “law and order” in mind would be least
intruding into the guaranteed freedom while “public order” may qualify for a greater
degree of restriction since public order is a matter of even greater social concern.Anuradha Bhasin vs Union Of India on 10 January, 2020

…
45. It is keeping this distinction in mind, the legislature, under Section 144 CrPC, has
empowered the District Magistrate, Sub− Divisional Magistrate or any other
Executive Magistrate, specially empowered in this behalf, to direct any person to
abstain from doing a certain act or to take action as directed, where sufficient ground
for proceeding under this section exists and immediate prevention and/or speedy
remedy is desirable. By virtue of Section 144−A CrPC, which itself was introduced by
Act 25 of 2005 [Ed.: The Code of Criminal Procedure (Amendment) Act, 2005.] , the
District Magistrate has been empowered to pass an order prohibiting, in any area
within the local limits of his jurisdiction, the carrying of arms in any procession or
the organising or holding of any mass drill or mass training with arms in any public
place, where it is necessary for him to do so for the preservation of public peace,
public safety or maintenance of public order. …” (emphasis supplied)
123. In view of the above, ‘law and order’, ‘public order’ and ‘security of State’ are distinct legal
standards and the Magistrate must tailor the restrictions depending on the nature of the situation. If
two families quarrel over irrigation water, it might breach law and order, but in a situation where
two communities fight over the same, the situation might transcend into a public order situation.
However, it has to be noted that a similar approach cannot be taken to remedy the aforesaid two
distinct situations. The Magistrate cannot apply a straitjacket formula without assessing the gravity
of the prevailing circumstances; the restrictions must be proportionate to the situation concerned.
124. Learned senior counsel, Mr. Kapil Sibal also contended that an order under Section 144, Cr.P.C.
cannot be issued against the public generally and must be specifically intended against the people or
the group which is apprehended to disturb the peace and tranquillity. This Court in the Madhu
Limaye case (supra), has clarified that such an order can be passed against either a particular
individual or the public in general. This Court was aware that, at times, it may not be possible to
distinguish between the subject of protection under these orders and the individuals against whom
these prohibitory orders are required to be passed:
“27.… Ordinarily the order would be directed against a person found acting or likely
to act in a particular way. A general order may be necessary when the number of
persons is so large that distinction between them and the general public cannot be
made without the risks mentioned in the section. A general order is thus justified but
if the action is too general, the order may be questioned by appropriate remedies for
which there is ample provision in the law.” (emphasis supplied)
125. The counsel on behalf of the Petitioners have argued that the validity of the aforesaid
restrictions has to be tested on its reasonableness. The restrictions imposed must be proportionate
to the proposed/perceived threat. In the context of restrictions imposed by way of orders passed
under Section 144, Cr.P.C., this Court, in Ramlila Maidan Incident case (supra), held that an
onerous duty is cast upon the concerned Magistrate to first assess the perceived threat and impose
the least invasive restriction possible. The concerned Magistrate is duty bound to ensure that theAnuradha Bhasin vs Union Of India on 10 January, 2020

restrictions should never be allowed to be excessive either in nature or in time. The relevant portion
is extracted below:
“39. There has to be a balance and proportionality between the right and restriction
on the one hand, and the right and duty, on the other. It will create an imbalance, if
undue or disproportionate emphasis is placed upon the right of a citizen without
considering the significance of the duty. The true source of right is duty...
…
58. Out of the aforestated requirements, the requirements of existence of sufficient
ground and need for immediate prevention or speedy remedy is of prime
significance. In this context, the perception of the officer recording the
desired/contemplated satisfaction has to be reasonable, least invasive and bona fide.
The restraint has to be reasonable and further must be minimal.
Such restraint should not be allowed to exceed the constraints of the particular situation either in
nature or in duration.
The most onerous duty that is cast upon the empowered officer by the legislature is that the
perception of threat to public peace and tranquillity should be real and not quandary, imaginary or a
mere likely possibility.” (emphasis supplied)
126. As discussed above, the decisions of this Court in the Modern Dental College case (supra) and
K.S. Puttaswamy (Aadhaar− 5J.) case (supra), which brought the concept of proportionality into the
fold, equally apply to an order passed under Section 144, Cr.P.C.
127. The Petitioners also contended that orders passed under Section 144, Cr.P.C., imposing
restrictions, cannot be a subject matter of privilege. Moreover, material facts must be recorded in
the order itself. On the other hand, the learned Solicitor General argued that the empowered officers
were in the best position to know the situation on the ground and accordingly the aforesaid orders
were passed. There existed sufficient speculation on the ground to suggest abrogation of Article 370,
and the respective Magistrates, being aware of the circumstances, imposed the aforesaid restrictions
in a periodic manner, indicating due application of mind. The learned Solicitor General further
argued that this Court cannot sit in appeal over the order passed by the magistrate, particularly
when there is no imputation of mala fide.
128. To put a quietus to the aforesaid issue it is pertinent to reproduce and rely on a relevant extract
from the Ramlila Maidan Incident, In re case (supra):
“56. Moreover, an order under Section 144 CrPC being an order which has a direct
consequence of placing a restriction on the right to freedom of speech and expression
and right to assemble peaceably, should be an order in writing and based upon
material facts of the case. This would be the requirement of law for more than oneAnuradha Bhasin vs Union Of India on 10 January, 2020

reason. Firstly, it is an order placing a restriction upon the fundamental rights of a
citizen and, thus, may adversely affect the interests of the parties, and secondly,
under the provisions of CrPC, such an order is revisable and is subject to judicial
review. Therefore, it will be appropriate that it must be an order in writing, referring
to the facts and stating the reasons for imposition of such restriction. In Praveen Bhai
Thogadia [(2004) 4 SCC 684: 2004 SCC (Cri) 1387], this Court took the view that the
Court, while dealing with such orders, does not act like an appellate authority over
the decision of the official concerned. It would interfere only where the order is
patently illegal and without jurisdiction or with ulterior motive and on extraneous
consideration of political victimisation by those in power. Normally, interference
should be the exception and not the rule.” (emphasis supplied)
129. We may note that orders passed under Section 144, Cr.P.C. have direct consequences upon the
fundamental rights of the public in general. Such a power, if used in a casual and cavalier manner,
would result in severe illegality. This power should be used responsibly, only as a measure to
preserve law and order. The order is open to judicial review, so that any person aggrieved by such an
action can always approach the appropriate forum and challenge the same. But, the aforesaid means
of judicial review will stand crippled if the order itself is unreasoned or un−notified. This Court, in
the case of Babulal Parate (supra), also stressed upon the requirement of having the order in
writing, wherein it is clearly indicated that opinion formed by the Magistrate was based upon the
material facts of the case. This Court held as under:
“9. Sub−section (1) confers powers not on the executive but on certain
Magistrates…Under sub−section (1) the Magistrate himself has to form an opinion
that there is sufficient ground for proceeding under this section and immediate
prevention or speedy remedy is desirable. Again the sub−section requires the
Magistrate to make an order in writing and state therein the material facts by reason
of which he is making the order thereunder. The sub−section further enumerates the
particular activities with regard to which the Magistrate is entitled to place
restraints.” (emphasis supplied)
130. While passing orders under Section 144, Cr.P.C., it is imperative to indicate the material facts
necessitating passing of such orders. Normally, it should be invoked and confined to a particular
area or some particular issues. However, in the present case, it is contended by the Petitioners that
the majority of the geographical area of the erstwhile State of Jammu and Kashmir was placed under
orders passed under Section 144, Cr.P.C. and the passing of these orders need to be looked at in this
perspective. In response, it is the case of the Respondent, although it has not been stated in clear
terms, that it is an issue of national security and cross border terrorism. Before we part, we need to
caution against the excessive utility of the proportionality doctrine in the matters of national
security, sovereignty and integrity.
131. Although, the Respondents submitted that this Court cannot sit in appeal or review the orders
passed by the executive, particularly those pertaining to law and order situation, the scope of judicial
review with respect to law and order issues has been settled by this Court. In State of Karnataka v.Anuradha Bhasin vs Union Of India on 10 January, 2020

Dr. Praveen Bhai Thogadia, (2004) 4 SCC 684, this Court observed, specifically in the context of
Section 144, Cr.P.C., as follows:
“6. Courts should not normally interfere with matters relating to law and order which
is primarily the domain of the administrative authorities concerned. They are by and
large the best to assess and to handle the situation depending upon the peculiar
needs and necessities within their special knowledge. …… Therefore, whenever the
authorities concerned in charge of law and order find that a person’s speeches or
actions are likely to trigger communal antagonism and hatred resulting in fissiparous
tendencies gaining foothold, undermining and affecting communal harmony,
prohibitory orders need necessarily to be passed, to effectively avert such untoward
happenings.
7... If they feel that the presence or participation of any person in the meeting or
congregation would be objectionable, for some patent or latent reasons as well as the
past track record of such happenings in other places involving such participants,
necessary prohibitory orders can be passed. Quick decisions and swift as well as
effective action necessitated in such cases may not justify or permit the authorities to
give prior opportunity or consideration at length of the pros and cons. The imminent
need to intervene instantly, having regard to the sensitivity and perniciously perilous
consequences it may result in if not prevented forthwith, cannot be lost sight of. The
valuable and cherished right of freedom of expression and speech may at times have
to be subjected to reasonable subordination to social interests, needs and necessities
to preserve the very core of democratic life − preservation of public order and rule of
law.
At some such grave situation at least the decision as to the need and necessity to take prohibitory
actions must be left to the discretion of those entrusted with the duty of maintaining law and order,
and interposition of courts unless a concrete case of abuse or exercise of such sweeping powers for
extraneous considerations by the authority concerned or that such authority was shown to act at the
behest of those in power, and interference as a matter of course and as though adjudicating an
appeal, will defeat the very purpose of legislation and legislative intent…” (emphasis supplied)
132. It is true that we do not sit in appeal, however, the existence of the power of judicial review is
undeniable. We are of the opinion that it is for the Magistrate and the State to make an informed
judgement about the likely threat to public peace and law and order. The State is best placed to
make an assessment of threat to public peace and tranquillity or law and order. However, the law
requires them to state the material facts for invoking this power. This will enable judicial scrutiny
and a verification of whether there are sufficient facts to justify the invocation of this power.
133. In a situation where fundamental rights of the citizens are being curtailed, the same cannot be
done through an arbitrary exercise of power; rather it should be based on objective facts. The
preventive/remedial measures under Section 144, Cr.P.C. should be based on the type of exigency,
extent of territoriality, nature of restriction and the duration of the same. In a situation of urgency,Anuradha Bhasin vs Union Of India on 10 January, 2020

the authority is required to satisfy itself of such material to base its opinion on for the immediate
imposition of restrictions or measures which are preventive/remedial. However, if the authority is to
consider imposition of restrictions over a larger territorial area or for a longer duration, the
threshold requirement is relatively higher.
134. An order passed under Section 144, Cr.P.C. should be indicative of proper application of mind,
which should be based on the material facts and the remedy directed. Proper reasoning links the
application of mind of the officer concerned, to the controversy involved and the conclusion
reached. Orders passed mechanically or in a cryptic manner cannot be said to be orders passed in
accordance with law.
135. During the course of hearing, on 26.11.2019, the learned Solicitor General sought the
permission of this Court to produce certain confidential documents to be perused by this Court.
However, he objected to revealing certain documents to the Petitioners, claiming sensitivity and
confidentiality. Learned senior counsel Mr. Kapil Sibal stated that the Court could assume the
existence of such intelligence inputs and materials. In view of such stand, we have not gone into the
adequacy of the material placed before this Court; rather, we have presumed existence of the same.
136. One of the important criteria to test the reasonableness of such a measure is to see if the
aggrieved person has the right to make a representation against such a restriction. It is a
fundamental principle of law that no party can be deprived of his liberty without being afforded a
fair, adequate and reasonable opportunity of hearing. Therefore, in a situation where the order is
silent on the material facts, the person aggrieved cannot effectively challenge the same. Resultantly,
there exists no effective mechanism to judicially review the same. [See State of Bihar v. Kamla Kant
Misra, (1969) 3 SCC 337]. In light of the same, it is imperative for the State to make such orders
public so as to make the right available under Section 144(5), Cr.P.C. a practical reality.
137. One thing to remember is that no mala fide has been alleged by the Petitioners. It was not
denied by the Petitioners that the State has the power to pass such restrictive order. Additionally,
the Respondents contended that the historical background of the State− cross border terrorism,
infiltration of militants, security issues, etc., cannot be forgotten and must be kept in mind while
testing the legality of the orders. Further, the Respondent submitted that the orders were passed in
the aforementioned context and in the anticipated threat to law and order, to prevent any loss of life,
limb and property. However, these orders do not explain the aforesaid aspects.
138. Although the restrictions have been allegedly removed on 27.09.2019, thereby rendering the
present exercise into a virtually academic one, we cannot ignore non−compliance of law by the State.
As learned senior counsel Mr. Kapil Sibal submitted, this case is not just about the past or what has
happened in the erstwhile State of Jammu and Kashmir, but also about the future, where this Court
has to caution the Government. Hence, we direct that the authorities must follow the principles laid
down by this Court and uphold the rule of law.
139. It is contended by the Petitioners that while the Respondents stated that there are no
prohibitory orders during the day and there are certain restrictions in certain areas during the night,Anuradha Bhasin vs Union Of India on 10 January, 2020

on the ground, the situation is different as the police is still restricting the movement of the people
even during the day. If that is so, it is not proper and correct for the State to resort to such type of
acts. A Government, if it thinks that there is a threat to the law and order situation or any other such
requirement, must follow the procedure laid down by law, taking into consideration the rights of the
citizens, and pass appropriate need−based orders. In view of the same, appropriate directions are
provided in the operative part of this judgment.
140. Before parting we summarise the legal position on Section 144, Cr.P.C as follows:
i. The power under Section 144, Cr.P.C., being remedial as well as preventive, is
exercisable not only where there exists present danger, but also when there is an
apprehension of danger. However, the danger contemplated should be in the nature
of an “emergency” and for the purpose of preventing obstruction and annoyance or
injury to any person lawfully employed. ii. The power under Section 144, Cr.P.C
cannot be used to suppress legitimate expression of opinion or grievance or exercise
of any democratic rights. iii. An order passed under Section 144, Cr.P.C. should state
the material facts to enable judicial review of the same.
The power should be exercised in a bona fide and reasonable manner, and the same
should be passed by relying on the material facts, indicative of application of mind.
This will enable judicial scrutiny of the aforesaid order.
iv. While exercising the power under Section 144, Cr.P.C.
the Magistrate is duty bound to balance the rights and restrictions based on the
principles of proportionality and thereafter apply the least intrusive measure.
v. Repetitive orders under Section 144, Cr.P.C. would be an abuse of power.
H. FREEDOM OF THE PRESS
141. The Petitioner in W.P. (C) No. 1031 of 2019 has filed the petition basing her contention on the
following factual premise, as averred:
13. Writ Petition (Civil) No. 1031 of 2019 was filed on 10−08−2019 under Article 32 of
the Constitution of India by the Executive Editor of the newspaper “Kashmir Times”,
which publishes two editions daily, one from Jammu and another from Srinagar. The
English newspaper, Kashmir Times, was founded in 1954 as a news weekly. It was
later converted to a daily newspaper in 1962 and has regularly been in print and
circulation ever since.
Kashmir Times is a widely read English newspaper in Jammu and Kashmir, and also has significant
readership in the neighbouring States of Punjab, Delhi and Himachal Pradesh.Anuradha Bhasin vs Union Of India on 10 January, 2020

14. On 04−08−2019, sometime during the day, mobile phone networks, internet services, and
landline phones were all discontinued in the Kashmir valley and in some districts of Jammu and
Ladakh. No formal orders under which such action was taken by the Respondents were
communicated to the affected population, including the residents of the Kashmir Valley. This meant
that the people of Kashmir were plunged into a communication blackhole and an information
blackout. The actions of the respondents have had a debilitating and crippling effect on
newsgathering, reporting, publication, circulation and information dissemination, and have also
resulted in freezing of web portals and news websites.
15. From the morning of 05−08−2019, with a heavy military presence, barricades and severance of
all communication links, the state of Jammu and Kashmir was placed under de facto curfew. At the
same time, on 05−08− 2019, the Constitution (Application to Jammu and Kashmir) order, 2019,
C.O. 272 was published in The Gazette of India, vide which under the powers vested by Article
370(1) of the Constitution of India, Article 367(4) was added to the Constitution. Also on 05−08−
2019, the Jammu and Kashmir Reorganisation Bill, 2019, was introduced in the Rajya Sabha, and
passed. On 06−08−2019, the said Bill was passed by the Lok Sabha. The President’s assent was
given to the Bill on 09−08−2019.
The Gazette Notification, dt. 09−08−2019 states that the Jammu and Kashmir Reorganisation Act,
2019, will come into effect from 31 st October, 2019, and that there shall be a new Union Territory of
Jammu and Kashmir. All of this was carried out while the State of Jammu and Kashmir was in a
lockdown and silenced through a communication shutdown.
16. In such Circumstances the Kashmir Times’ Srinagar edition could not be distributed on 05−08−
2019 and it could not be published thereafter from 06−08−2019 to 11−10−2019, as newspaper
publication necessarily requires news gathering by reporters traveling across the Valley and
unhindered interaction with public and officials. Due to the indiscriminate lockdown−including
communication and internet blackout− and severe curbs on movement enforced by the respondents,
the Petitioner was prevented and hindered from carrying out her profession and work. Even after
11−10−2019 only a truncated copy of the newspaper is being published because of the severe
restrictions in place even today (internet services and SMS services are completely shut down even
after 115 days). The new portal/website is frozen till date.
142. There is no doubt that the importance of the press is well established under Indian Law. The
freedom of the press is a requirement in any democratic society for its effective functioning. The first
case which dealt with the freedom of the press can be traced back to Channing Arnold v. The
Emperor, (1914) 16 Bom LR 544, wherein the Privy Council stated that:
“36. The freedom of the journalist is an ordinary part of the freedom of the subject
and to whatever length, the subject in general may go, so also may the journalist, but
apart from the statute law his privilege is no other and no higher. The range of his
assertions, his criticisms or his comments is as wide as, and no wider than that of any
other subject.”Anuradha Bhasin vs Union Of India on 10 January, 2020

143. During the drafting of our Constitution, B. N. Rau, while commenting on the amendments by
Jaya Prakash Narayan, who had proposed a separate freedom of press, had commented in the
following manner:
“It is hardly necessary to provide specifically for the freedom of the press as freedom
of expression provided in sub−clause (a) of clause (1) of article 13 will include
freedom of the press...”
144. Thereafter, many judgments of this Court including Bennett Coleman v. Union of India, (1972)
2 SCC 788, Indian Express (supra), Sakal Papers (P) Ltd. v. Union of India, [1962] 3 SCR 842 have
expounded on the right of freedom of press and have clearly enunciated the importance of the
aforesaid rights in modern society. In view of the same, there is no doubt that freedom of the press
needs to be considered herein while dealing with the issue of the case at hand.
145. From the aforesaid factual averment, we may note that the Petitioner in W.P. (C) No. 1031 of
2019, with respect to the present issue, does not impugn any specific order of the government
restricting the freedom of the press or restricting the content of the press. The allegation of the
aforementioned Petitioner is that the cumulative effect of various other restrictions, such as the
imposition of Section 144, Cr.P.C. and restriction on internet and communication, has indirectly
affected the freedom of the press in the valley.
146. There is no doubt that the freedom of the press is a valuable and sacred right enshrined under
Article 19(1)(a) of the Constitution. This right is required in any modern democracy without which
there cannot be transfer of information or requisite discussion for a democratic society. Squarely
however, the contention of the Petitioner rests on the chilling effects alleged to be produced by the
imposition of restrictions as discussed above.
147. Chilling effect has been utilized in Indian Jurisprudence as a fairly recent concept. Its presence
in the United States of America can be traced to the decision in Weiman v. Updgraff, 344 U.S.
183. We may note that the argument of chilling effect has been utilized in various contexts, from
being purely an emotive argument to a substantive component under the free speech adjudication.
The usage of the aforesaid principle is chiefly adopted for impugning an action of the State, which
may be constitutional, but which imposes a great burden on the free speech. We may note that the
argument of chilling effect, if not tempered judicially, would result in a “self−proclaiming
instrument”.
148. The principle of chilling effect was utilized initially in a limited context, that a person could be
restricted from exercising his protected right due to the ambiguous nature of an overbroad statute.
In this regard, the chilling effect was restricted to the analysis of the First Amendment right. The
work of Frederick Schauer provides a detailed analysis in his seminal work on the First
Amendment.22 This analysis was replicated in the context of privacy and internet usage in a
regulatory set up by Daniel J. Solove. These panopticon concerns have been accepted in the case of
K.S. Puttaswamy (Privacy−9J.) (supra).Anuradha Bhasin vs Union Of India on 10 January, 2020

149. We need to concern ourselves herein as to theoretical question of drawing lines as to when a
regulation stops short of impinging upon free speech. A regulatory legislation will have a direct or
indirect impact on various rights of different degrees. Individual rights cannot be viewed as silos,
rather they should be viewed in a cumulative manner which may be affected in different ways. The
technical rule of causal link cannot be made applicable in the case of human rights. Human rights
are an inherent feature of every human and there is no question of the State not 22 Frederick
Schauer, Fear, Risk and the First Amendment: Unraveling the Chilling Effect (1978).
providing for these rights. In one sense, the restrictions provided under Article 19(2) of the
Constitution follow a utilitarian approach wherein individualism gives way for commonality of
benefit, if such restrictions are required and demanded by law. In this context, the test of ‘direct
impact’ as laid down in A.K Gopalan v. State of Madras, AIR 1950 SC 27, has been subsequently
widened in Rustom Cavasjee Cooper v. Union of India, 1970 (1) SCC 248, wherein the test of ‘direct
and inevitable consequence’ was propounded. As this is not a case wherein a detailed analysis of
chilling effect is required for the reasons given below, we leave the question of law open as to the
appropriate standard for establishing causal link in a challenge based on chilling effect.
150. The widening of the ‘chilling effect doctrine’ has always been viewed with judicial scepticism. At
this juncture, we may note the decision in Laird v. Tantum, 408 U.S. 1 (1972), wherein the
respondent brought an action against the authorities to injunct them from conducting surveillance
of lawful and peaceful civilian political activity, based on the chilling effect doctrine. The United
States Supreme Court, in its majority decision, dismissed the plea of the respondent on the ground
of lack of evidence to establish such a claim. The Court observed that:
“Allegations of a subjective "chill" are not an adequate substitute for a claim of
specific present objective harm or a threat of specific future harm.” Therefore, to say
that the aforesaid restrictions were unconstitutional because it has a chilling effect on
the freedom of press generally is to say virtually nothing at all or is saying something
that is purely speculative, unless evidence is brought before the Court to enable it to
give a clear finding, which has not been placed on record in the present case. [refer to
Clapper v Amnesty Int’l, USA, 568 U.S. 113 (2013)]
151. In this context, one possible test of chilling effect is comparative harm. In this frame−work, the
Court is required to see whether the impugned restrictions, due to their broad−based nature, have
had a restrictive effect on similarly placed individuals during the period. It is the contention of the
Petitioner that she was not able to publish her newspaper from 06−08−2019 to 11−10−2019.
However, no evidence was put forth to establish that such other individuals were also restricted in
publishing newspapers in the area. Without such evidence having been placed on record, it would be
impossible to distinguish a legitimate claim of chilling effect from a mere emotive argument for a
self−serving purpose. On the other hand, the learned Solicitor General has submitted that there
were other newspapers which were running during the aforesaid time period. In view of these facts,
and considering that the aforesaid Petitioner has now resumed publication, we do not deem it fit to
indulge more in the issue than to state that responsible Governments are required to respect the
freedom of the press at all times. Journalists are to be accommodated in reporting and there is noAnuradha Bhasin vs Union Of India on 10 January, 2020

justification for allowing a sword of Damocles to hang over the press indefinitely.
I. CONCLUSION
152. In this view, we issue the following directions:
a. The Respondent State/competent authorities are directed to publish all orders in
force and any future orders under Section 144, Cr.P.C and for suspension of telecom
services, including internet, to enable the affected persons to challenge it before the
High Court or appropriate forum. b. We declare that the freedom of speech and
expression and the freedom to practice any profession or carry on any trade, business
or occupation over the medium of internet enjoys constitutional protection under
Article 19(1)(a) and Article 19(1)(g). The restriction upon such fundamental rights
should be in consonance with the mandate under Article 19 (2) and (6) of the
Constitution, inclusive of the test of proportionality.
c. An order suspending internet services indefinitely is impermissible under the
Temporary Suspension of Telecom Services (Public Emergency or Public Service)
Rules, 2017. Suspension can be utilized for temporary duration only. d. Any order
suspending internet issued under the Suspension Rules, must adhere to the principle
of proportionality and must not extend beyond necessary duration. e. Any order
suspending internet under the Suspension Rules is subject to judicial review based on
the parameters set out herein.
f. The existing Suspension Rules neither provide for a periodic review nor a time
limitation for an order issued under the Suspension Rules. Till this gap is filled, we
direct that the Review Committee constituted under Rule 2(5) of the Suspension
Rules must conduct a periodic review within seven working days of the previous
review, in terms of the requirements under Rule 2(6).
g. We direct the respondent State/competent authorities to review all orders
suspending internet services forthwith. h. Orders not in accordance with the law laid
down above, must be revoked. Further, in future, if there is a necessity to pass fresh
orders, the law laid down herein must be followed.
i. In any case, the State/concerned authorities are directed to consider forthwith
allowing government websites, localized/limited e−banking facilities, hospitals
services and other essential services, in those regions, wherein the internet services
are not likely to be restored immediately. j. The power under Section 144, Cr.P.C.,
being remedial as well as preventive, is exercisable not only where there exists
present danger, but also when there is an apprehension of danger. However, the
danger contemplated should be in the nature of an “emergency” and for the purpose
of preventing obstruction and annoyance or injury to any person lawfully employed.Anuradha Bhasin vs Union Of India on 10 January, 2020

k. The power under Section 144, Cr.P.C cannot be used to suppress legitimate
expression of opinion or grievance or exercise of any democratic rights. l. An order
passed under Section 144, Cr.P.C. should state the material facts to enable judicial
review of the same. The power should be exercised in a bona fide and reasonable
manner, and the same should be passed by relying on the material facts, indicative of
application of mind. This will enable judicial scrutiny of the aforesaid order. m.While
exercising the power under Section 144, Cr.P.C., the Magistrate is duty bound to
balance the rights and restrictions based on the principles of proportionality and
thereafter, apply the least intrusive measure. n. Repetitive orders under Section 144,
Cr.P.C. would be an abuse of power.
o. The Respondent State/competent authorities are directed to review forthwith the
need for continuance of any existing orders passed under Section 144, Cr.P.C in
accordance with law laid down above.
153. The Writ Petitions are disposed of in the afore−stated terms. All pending applications are also
accordingly disposed of.
..............................................J. (N.V. RAMANA) ..............................................J. (R. SUBHASH
REDDY) ..............................................J. (B. R. GAVAI) NEW DELHI;
JANUARY 10, 2020Anuradha Bhasin vs Union Of India on 10 January, 2020

