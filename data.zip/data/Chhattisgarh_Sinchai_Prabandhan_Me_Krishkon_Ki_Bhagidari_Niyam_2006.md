Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari
Niyam, 2006
CHHATTISGARH
India
Chhattisgarh Sinchai Prabandhan Me Krishkon Ki
Bhagidari Niyam, 2006
Rule
CHHATTISGARH-SINCHAI-PRABANDHAN-ME-KRISHKON-KI-BHAGIDARI-NIYAM-2006
of 2006
Published on 18 October 2006• 
Commenced on 18 October 2006• 
[This is the version of this document from 18 October 2006.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006Published vide
Notification dated 18th October, 2006, C.G. Rajpatra, Part 1, dated 24-11-2006, at pp. 2301-2377In
exercise of the powers conferred by Section 55 of the Chhattisgarh Sinchai Prabandhan Me Krishkon
Ki Bhagidari Adhiniyam, 2006 (Act 7 of 2006), the State Government hereby makes the following
rules :-
1. Shorl title and commencement.
(1)These rules may be called the Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari
Niyam, 2006.(2)They shall come into force with effect from the date of its publication in the "official
Gazette".
2. Definitions.
- In these rules, unless the context otherwise requires-(a)"Act" means the Chhattisgarh Sinchai
Prabandhan Me Krishkon Ki Bhagidari Adhiniyam, 2006;(b)"Authorised Officer" means an officer
authorised by the District Collector not below the rank of Naib Tehsildar;(c)"Form" means a form
appended to these rules;(d)"Fanners' Organisation" means Water Users' Association at the primary
level, Distributory Committee at the secondary level and Project Committee at the project
level;(e)"Notice" means notice appended to these rules;(f)The words and expressions used but not
defined in these rules shall have the respective meanings assigned to them in the Chhattisgarh
Sinchai Prabandhan Me Krishkon Ki Bhagidari Adhiniyam, 2006 (No. 7 of 2006) and theChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Nirvachan Niyam, 2006.
3. Delineation of Command Area of an Irrigation System.
(1)The District Collector, may by notification delineate the command area under each of the
irrigation system within his district on a hydraulic basis which may be administratively viable; and
declare it to be a water users' area for the purpose of the Act and publish a notification in Form A.
The Farmers' Organisation shall have distinct name; in accordance with the notification published
under this sub-rule.(2)Detailed ayacut maps of individual Water Users' Association identified within
the declared Water Users' Association are of each irrigation system as per sub-sections (1) and (2) of
Section 3 of the Act shall be prepared in order to facilities final delineation by the District Collector
based on hydraulic boundaries, clearly indicating the boundaries of the Territorial
Constituencies.(3)For the purpose of this rule, every Water Users' Association shall have the name
of a village as its distinct name in which the major extent of the command is situated. If there is
more than one association in such village, then such association shall be called by adding numerals
to the distinct name.(4)For each of the irrigation system, the Collector shall cause to be prepared the
maps or sketches, indicating the distribution system like majors, minors and outlets along with the
related structures in the command areas. In the map or sketch, the village boundaries, the drains
ayacut roads and all structures shall be marked.(5)The areas irrigated or planned to be irrigated
under each of the distributory minor, survey number wise shall be prepared.(6)The command area
for each water user area shall be delineated on hydraulic basis, each to be served, by a distinct
segment of the irrigation system and with a control structure or a mechanism at its head for supply
of allocated or designed quantity of water for that command area.(7)The delineated area may have
one or more distributories or minors or sub-minors or direct pipes or outlets or a combination of
two or more thereof, serving its command. It shall also have a distinctly demarcated boundary
which could be a drain, or a bund or an uncommandable land.(8)In case of minor irrigation system,
including tanks, diversion channels, lift irrigation schemes, wells, and such other smaller irrigation
systems each shall form into one water user area.(9)In case major and medium irrigation system
such water user areas shall be more than one.(10)To ensure administrative viability, the area of
operation of each of the Water Users' Area shall be the limits of a village or contiguous villages
situated within a Revenue Circle, as far as possible. In exceptional cases, the Water Users'
Association area may be extended to more than one taluk or district.(11)A Canal Officer not below
the rank of an Executive Engineer, duly empowered by the Appropriate Authority in this behalf
shall, by notification in the Official Gazette command areas of Lift or Tube Well Irrigation Waters
Users' Associations, separately based on the prescribed guidelines and subject to Section 23 of the
Act and declare those areas to be the areas of operation of respective Life or Tube Well Irrigation
Water Users' Associations :Provided that there shall be one Lift Irrigation Water Users' Association
for each Lift Irrigation Scheme :Provided also that there shall be more than one Lift Irrigation Water
Users' Association for any Life Irrigation Project with a command area of more than 2000 hectares
:Provided further that there shall be one Tube Well Water Users' Association for a cluster of Tube
wells subject to the condition that the aggregate command area or areas of operation of such Tube
Well Water Users' Association shall be, to the extent possible, between forty to three hundred
hectares and that one Tube Well Unit should not be separated from other such unit within the area
of operation of such Tube Well Water Users Association by a physical distance of more than tenChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

kilometers :Provided also that there shall be one territorial constituency for each of the Tube Well
Units within the area of operation of a Tube Well Water Users' Association.(12)Subject to sub-rule
(11) the provisions made for Water Users' Association for Minor Irrigation Systems under the Act
shall, mutatis mutandis, apply to the delineation and functioning of Lift or Tube Well Waters Users'
Association.(13)In the area delineated as an area of operation of the Lift or Tube Well Irrigation
Water Users' Associations under sub-rule (11), Lift or Tube Well Irrigation Water Users' Association
shall be constituted by the landlords that is, the owner and or tenant recorded as such in the record
of rights under the Chhattisgarh Land Revenue Code, 1959 (No. 20 of 1959).(14)While delineating
the Territorial Constituencies of Water Users' Association based on a hydraulic basis, they "shall be
demarcated as the Territorial Constituencies in the Head, Middle and Tail Reaches, based on their
proximity to the water source.(15)The delineated area shall be notified by the Collector and all
modifications proposed for delineation would be based on recommendations made by the Canal
Officer in Charge of irrigation project and such Canal Officer shall arrive at the recommendation
made in this regard only after consultation with the farmers who are proposed beneficiaries under
such Schemes.(16)The District Collector shall divide each of the water user area in Major or Medium
Irrigation Project, as far as possible equally into not more than twelve territorial constituencies as
specified below:-
Upto 1000 hectares :minimum 4 Territorial Constituencies
From 1001 to 1500 hectares :upto 9 Territorial Constituencies
From 1501 to 2000 hectares :upto 12 Territorial Constituencies.
(17)The District Collector shall divide each of the water user area in Minor Irrigation Projects, as far
as possible equally into not more than ten territorial constituencies as specified below :-
Upto 200 hectares :minimum 4 Territorial Constituencies
From 201 to 600 hectares :upto 6 Territorial Constituencies
From 601 to 1000 hectares :upto 8 Territorial Constituencies
From 1001 to 2000 hectares :upto 10 Territorial Constituencies.
Note. - The command area under a direct pipe outlet shall not be bifurcated while dividing
territorial constituencies.(18)The draft command area map or sketch of the Water Users' Area
demarcating the boundaries of territorial constituencies in the area of operation shall be prepared.
The particulars containing the survey numbers of the lands situated in each of such territorial
constituency in Form "A" shall be displayed together with such map or sketch on the notice board of
the Gram Panchayat at and the Janpad Panchayat, for information of the land
holders.(19)Objections or suggestions against the delineation of water user area or the division of
territorial constituencies, if any, may be filed, by the landholders in the area of operation, before the
District Collector within a period of seven days excluding the date of display.(20)Within two days of
the receipt of the objections or suggestions, the District Collector shall after conducting a summary
enquiry' made such changes or modifications wherever considered necessary in the maps or
sketches duly recording reasons thereof, whose decision thereon shall be final.(21)A final map or
sketch in pursuance of sub-rule (13) shall immediately be displayed in the office of the Gram
Panchayat and Janpad Panchayat in Form "B" by the District Collector.(22)Wherever the area of
operation of a Water Users' Association falls in more than one district, a Secretary of the State
Government may direct the Collector of one district to exercise the powers and perform theChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

functions of the Collector in such areas.(23)For new and on going Scheme, the delineation of
command area for determining the area of operation for Water Users' Association shall be carried
out in the manner prescribed under this rule.
4. Preparation of landholders list, Voters list and other Water Users' List.
(1)The District Collect shall prepared or cause to be prepared by the authorized officer, the list of
landholders on the basis of record of rights, in Form "C". The list shall also include wife of such land
holder, who themselves do not hold land, as they arc deemed to be the landholders under the Act.
On the basis of the list as so prepared he shall prepare or cause to be prepared territorial
constitucncywise voters list in Form "D", consisting of those landholders who have completed
eighteen years of age including wife of such landholder, who themselves do not hold land and who
have completed eighteen years of age as on the date of issue of notification for conducting elections
in a water users' area for electing the President and members of the Managing Committee of the
Water Users' Association.(2)The lists prepared under sub-rule (1) shall be displayed on the notice
board of the office of the concerned Gram Panchayat and the Janpad Panchayat.(3)Before finalising
the lists mentioned in sub-rule (1), the District Collector shall invite objections in Form "E" against
inclusion of any name or names in Form "F" and for deletion of any name or names in Form "G"
within a week of display under sub-rule (2). After receiving the objections, if any, the District
Collector shall consider all such objections within a week and finalise such lists, by appending the
names to be deleted or incorporated, at the end of each list and a final notice thereof shall be
published in Form "H" for verification.(4)Each landholder in the water users' area shall have one
vote only irrespective of his land holdings in the said area.(5)(i)In case, a landholder has land in
more than one Territorial Constituency of a water users' area the landholder shall opt for one
constituency by giving a declaration as specified in Form "I" to the Authorised Officer.(ii)In case, no
such option is exercised by the landholder, the Authorised Officer shall allot his vote to the
constituency in which the landholder holds the maximum extent of land; where such land held is the
same in two constituencies any of the constituency may be allotted.(6)The lists prepared under
sub-rule (1) shall be revised six months before, the commencement of the subsequent elections in
accordance with the provisions of the Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari
Nirvachan Niyam, 2006.
5. Delineation of distributory areas.
(1)The Government, keeping in view the operational viability and in eonsultation with the District
Collector, for the purpose of constituting Distributory Committees, delineate the command area by a
notification in Form "J", under a major project into such number of distributory areas as they
consider proper.(2)The delineation in sub-rule (1) shall be based on the recommendations made
jointly by the Canal Officer in Charge of the concerned irrigation projects and the concerned Water
Users' Association.(3)A distributory area may contain three or more contiguous water users'
areas.(4)In delineating a distributory area, no water user area shall be divided or bifurcated into
parts.Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

6. Delineation of project areas.
(1)The Government, keeping in view the operational viability and in consultation with the District
Collector, delineate, the command area by a notification in Form "K" under a major irrigation
project into one or more project areas for the purpose of constituting a Project Committee or
Committees.(2)The delineation in sub-rule (1) shall be based on the recommendations made jointly
by the Canal Officer in Charge of the concerned irrigation projects and the Presidents of the
Distributory Committee in the Project area.(3)The entire command area under a medium irrigation
project shall be treated as a single unit and notified by the Government as a Project Area.
7. Procedure for conducting elections.
(1)The election to the office of the President and the members of a Farmers' Organisation shall be
conducted in accordance with the provisions of the Chhattisgarh Sinchai Prabandhan Me Krishkon
Ki Bhagidari Nirvachan Niyam, 2006.(2)No Member shall hold more than one elective office in a
Water Users' Association. If a person is elected as President of Water Users' Association and also as
a Member of the Managing Committee, he shall resign one of such offices within 15 (fifteen) days of
the declaration of the results, by a letter addressed to the concerned Competent Authority. If he fails
to do so, he shall cease to be a Member of the Managing Committee of the Water Users' Association.
The Competent Authority then shall immediately inform the fact of resignation or cessation of such
office to the District Election Officer and the President of the Distributory Committee where such
committee exists. Such casual vacancy shall be filled in accordance with the provisions of Section 20
of the Act.
8. Recall.
(1)The Competent Authority for receiving the recall notice in respect of a President or a Member of
the Managing Committee by any Farmers' Organisation shall be the District Collector or an officer
nominated by him.(2)The recall notice in Form "L" shall be signed by one-third of the total voters in
respect of the President or a Member of the Managing Committee of a Water Users' Association, and
one-third of the total members of the General Body in respect of the President or a Member of a
Managing Committee or a Distributory Committee or the Project Committee :Provided that, no such
motion of recall against any office bearers shall be allowed within one year from the date of
resumption of office of such office bearer :Provided further that the members who are defaulters in
respect of water charges shall not be allowed to sign the recall motion.(3)On receipt of such notice,
the Competent Authority shall verify the notice in Form "M".(4)The officer nominated" by the
District Collector shall call for a meeting of the voters or the members of the General Body, as the
case may be, of the respective Farmers' Organisation within seven days after verification of the
notice.(5)Two-third majority of the total voters present and voting and half, of the total number of
members of the association voting at a General Body meeting specially convened for this purpose
have voted in favour of the motion for recall, the motion shall be deemed to have been
passed.(6)After the motion passed under sub-rule (5), the Competent Authority shall issue the
proceedings of motion to the concerned President or the Member of the respective Farmers'
Organisation immediately stating that the recall became effective from the date of the resolution;Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

and accordingly he shall cease to hold such office.
9. Rights of Farmers' Organisation.
- The rights of the Farmers' Organisation shall be as follows :-(i)to obtain information in time about
water availability, opening/ closing of main canal, periods of supply and quantity of supply closure
of canals etc.;(ii)to receive water in bulk from the irrigation department for distribution among the
water users on agreed terms of equity and social justice;(iii)to receive water according to an
approved time schedule;(iv)to allocate water to non-members;(v)to levy' separate fees for
maintenance of the system;(vi)to levy any other fee or service charges, to meet management costs
and any other expenses;(vii)to utilize the canal bunds - as long as such use is not obstructive, or
destructive to hydraulic structure - by planting timber, fuel, or fruit trees or grass tor augmenting
the income of the farmers' organisation;(viii)to obtain the latest information about new crop
varieties, and their pattern, package of practices, weed control etc. for agriculture extension service
and purchase inputs such as seeds, fertilizers and pesticides; for use of its members;(ix)to have full
freedom to grow any crop other than those expressly prohibited by a law and adjust crop area within
the total water allocated without causing injury to neighbouring lands;(x)to participate in planning,
and designing, and designing of micro irrigation system;(xi)to suggest improvements/modifications
in the layout of Field Channels/Field Drains to supply water to all the farmers in the command;
and(xii)to plan and promote use of the ground water;(xiii)to carry out other agro based activities for
economic upliftment of its members;(xiv)to engage into any activity of common interest of members
in the command area related to irrigation and agriculture and supplementary business for self
sufficiency and sustainability of the Organisation;(xv)to receive funds and support from various
development programmes of the Central and State Government and other national and
international development agencies.
10. Responsibility of the Farmers' Organisation.
- The responsibility of Farmers' Organization shall be as follows :-(i)to prepare the schedules of
water deliveries and communicate to the concerned;(ii)to organize preparation of crop plan to
match water deliveries with crop requirements;(iii)to supply water to all members in the command
areas as per the approved terms;(iv)to carry out timely maintenance and repairs to the distributory
system including drains and other properties;(v)to organize repairs of the systems by the farmers
free of cost or on payment;(vi)to avoid and prevent misuse and waste of water;(vii)to use water
economically and judiciously and furnish data, to the Water Resources Department on water use,
irrigated area, all round irrigation efficiency, and crop yields;(viii)to inspect water utilization by the
farmers in the command; assess irrigated crop area and collect data on crop yields;(ix)to impose and
recover penalties of fines for misuse and wastage of water and tampering or damaging with the
irrigation network controls, sluices, outlets etc., as per the provision of the Act;(x)to educate farmers
on preparing fields and adopting modern methods of field irrigation, such as borders, furrows,
graded bonding for all round efficiency;(xi)to educate farmers on new crop varieties, package of
modern practices, pesticides, weedicides etc.;(xii)to procure and hire implements and gadgets for
agricultural operation where feasible and needed;(xiii)to improve the system for efficient and
economical use of available/allocated water, for efficient production of crops; and(xiv)to minimizeChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

conveyance and operational losses of water.
11. Rights of Members.
- The rights of the member users shall be as follows :-(i)to suggest improvements/modifications in
water deliveries;(ii)to get information relating to water availabilities, allocations, opening/closing of
canals and outlets, period of supply, frequency, etc.;(iii)to receive water as per specified quota for
use;(iv)to have the freedom of growing any crop, other than those prohibited by law or by a
resolution by the farmers' organisation, adjusting the areas within the water allocated;(v)to sell or
transfer the water share to any other water user within the operational area of Water Users'
Association with the permission of the concerned Water Users' Association and without affecting the
rights of the other members of the Association.(vi)to participate in the General Body meeting and
receive annual reports; and(vii)to receive equitable benefits from the activities of the organisation.
12. Responsibility of Individual water users.
- The responsibilities of the individual water users shall be as follows :-(i)to maintain the micro-level
irrigation system particularly the turn outs, field channels, structures, and field drains;(ii)to he
aware of the rules of operation of water supply framed by the farmers' organization for each
season;(iii)to adhere to the water delivery schedules;(iv)to not to interfere/tamper with the system
by breaching, cross bunding, damaging the structure in the minor, sub-minor or field distribution
system;(v)to close the turnout fully after the allotted turn or time is over;(vi)to conserve water and
make judicious use of the irrigation supply;(vii)to divert water if not required, during the turn or
time allotted, so as not to damage other member farmers;(viii)to get the lands levelled/shaped for
efficient utilization of land and water and to prevent deep percolations leading to water logging and
salinity in the downstream area;(ix)to pay the water charges fees and other charges regularly and in
time;(x)to avoid misuse/wastage of water, taking water out of turn, taking more lime than
allotted;(xi)to maintain Field Channels/Field Drains in the reaches specified by the Water Users'
Association, or contribute to labour/cost for maintenance, whenever required;(xii)to permit
inspection by the Competent Authority or the Farmers' Organization of-(a)irrigated
area;(b)measurement of irrigated area;(c)observation of water levels in dug
wells/bores/tubewells;(d)crop-cutting experiments of assessing productivity/production; and(xiii)to
respect eascmenlary rights and other customary practices in vogue in the system.
13. General Body.
(1)The General Body of a Farmers' Organisation shall comprise all members as specified in
sub-section (3) of Section 4, sub-section (2) of Section 7 and sub-section (2) and sub-section (3) of
Section 10 of the Act in respect of the Water Users' Association, Distributory Committee and Project
Committee respectively.(2)The General Body shall be assisted by the Competent Authority
appointed under Section 28 of the Act. The Competent Authority shall have the right to attend the
meeting and record his views, but shall have no right to vote.Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

14. The General Body Meetings.
(1)The meetings of the General Bodies shall be held at least twice in a year, once before `the kharif
and once before the `the rabi' season. The meetings shall be presided over by the President and in
his absence the members present shall elect one person from amongst themselves to preside/chair
the meeting.(2)The meeting of the General Body may also be called at any time by the President or
Managing Committee members through a majority resolution or by members of the organisation
through a requisition signed by not less than one-third of the members who have voting
right.(3)General Body meeting shall also be held on receipt of a direction from the Government or
from the Commissioner, Ayacut or by the next higher Committee or the Farmers' Organisation in
respect of matters relating to urgent public importance.
15. Notice of meeting.
(1)On receipt of a notice either under sub-rule (2) or (3) of Rule 14, the Managing Committee of the
Farmers' Organization shall convene a General Body Meeting within twenty days by giving seven
days prior notice specifying the place, dale, time and agenda items for the meeting :Provided that in
cases of emergency a meeting may be called at three days advance notice.(2)The notice may be sent
by hand or post or publication or by beat of drum and shall be pasted on the notice board of the
concerning organisation.
16. Quorum for the General Body.
(1)The quorum for a meeting shall be not less than one-third of the total members of the concerning
organisation.(2)If there is no quorum for the meeting it shall stand adjourned and be convened on
such date and time as the Managing Committee may determine. At such adjourned meeting, no
quorum shall be necessary and the members present may transact the business for which the
meeting was called.(3)in a General Body meeting, the items specified in the agenda alone will be
discussed. No other subjects will be discussed without the express permission of the
Chairperson/President or the majority decision of the members present in the meeting.
17. Minutes of the Meeting.
- Every proceeding of the General Body shall be recorded in the minutes book maintained for the
purpose and authenticated by the President or the person who has presided over the meeting, as the
case may be. A copy of the minutes shall be sent to the authority at the next higher Committee.
18. Powers of the General Body.
- The General Body shall have the following powers, namely :-(1)to approve the operational plan for
each crop season and review its implementation in the area of operation;(2)to make
recommendations to the Managing Committee for allocation for water in the distribution system
according to the operational plan approved;(3)to decide on the manner of regulation andChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

distribution of water;(4)to recommend the preparation and consequently approval of annual and
long-term financial and works plan and to priority works for maintenance/repairs/upkeep,
rehabilitation of the irrigation system;(5)to approve annual financial budget and review of the
performance of previous years' budget;(6)to approve the appointment of auditors for the annual
audit and/or concurrent audit and to fix fees for the same;(7)to approve the setting up of
Sub-Committees of members for various activities and functions of the Organisation;(8)to create or
set up such fund as may be required for different activities/works;(9)to entertain and dispose
appeals against orders of the Managing Committee between water users;(10)to authorize the
President to enter into agreement between the Water Users' Association and the Upper Level
Committee or the Canal Officer as per sub-section (3) of Section 25 of the Act;(11)to approve the levy
of fees as defined under Section 32 of the Act;(12)to take decisions on raising of resources under
Section 31 of the Act for the benefit of the organisations;(13)to carry out the recall proceedings as
per Section 14 of the Act.
19. Meetings of the Managing Committee.
(1)The meetings of the Managing Committee shall be held at least once in every month at the office
of the Organisation. Special meetings may, however, be held if it is so required. A meeting
requisitioned shall be held within seven days of the receipt of requisition for such a meeting by the
President.(2)The General Body of the Farmers' Organisation shall also convene a meeting of the
Managing Committee before each irrigation season to guide and help the members
regarding;(i)canal operation schedule and water distribution programme;(ii)maintenance of canal
system before commencement of season;(iii)the information about the latest decisions taken by the
Upper Level Committees.(3)Notice for the meeting shall be sent by hand/post/delivery or published
on the Notice Board and beat of drum.(4)The President shall preside over the meetings of the
Managing Committee. In his absence, the Managing Committee may, nominate a member from
amongst themselves to preside over the meeting.(5)Every proceedings of the Managing Committee
shall be recorded in minutes book maintained for the purpose by the member of the Managing
Committee. A copy of the minutes shall be sent to the authority of the next higher tier wherever they
exist.(6)The quorum of the meeting shall be one-third of the members. All resolutions shall be
carried out by majority of the members present and voting.(7)If there is no quorum for the meeting,
the meeting shall be adjourned for that day and be convened again. For an adjourned meeting, no
quorum is required.
20. Constitution and functions of Sub-Committee.
(1)Managing Committee of the Farmers' Organisation may constitute specified Sub-Committees to
carry out specific functions as assigned by the Managing Committee. The Constitution of the
Sub-Committees shall be approved by the General Body of the Farmers' Organisation.(2)The
following Sub-Committees may be constituted-(i)Finance and Resources Sub-Committee;(ii)Works
Sub-Committee;(iii)Water Management Sub-Committee;(iv)Training and Capacity Building
Sub-Committee;(v)Social Audit and Monitoring and Evaluation Sub-Committee;(vi)Dispute
Resolution Sub-Committee.(3)Each Sub-Committee shall consist of a Convener and five other
members with each such member being nominating from different territorial constituencies andChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

having a reputation for honesty, integrity, understanding or experience in the specified
field.(4)(a)The Convenor of the Sub-Committee shall be a member of the Managing Committee
other than the President.(b)In case of a Project Committee not more than five members shall be
selected for each Sub-Committee from the general body of the Project Committee in that Project and
at least two members amongst these shall be women.(c)In case of Distributory Committee not more
than five members shall be selected for each Sub-Committee from the General Body of the
Distributory Committee and at least two members amongst these shall be women.(d)In case of
Water Users' Association, not more than five members shall be drawn from the General Body of the
Water Users' Association and at least two members amongst these shall be women.(5)No member
shall represent more than one Sub-Committee.(6)If the strength available from the above
arrangement is short of the requirement, the President of the respective Managing Committee may
co-opt members of the Territorial Constituencies :Provided that not more than one member of the
Territorial Constituency of Water Users' Association can be co-opted in the Sub-Committee.(7)The
functions of the Sub-Committees shall be as follows ;-(i)Finance and Resources Sub-Committee
:(a)to plan, mobilise and collect resources;(b)to ensure collection of dues from members and
non-members as levied under Section 32 of the Act;(c)to recommend to Managing Committee the
use and deployment of resources and Budget; and(d)to maintain records relating to financial
matters.(ii)Works Sub-Committee :(a)to recommend estimates of works for administrative
approval;(b)to supervise works and ensure completion of works in time and quality control;
and(c)to approve payments for the works.(iii)Water Management Sub-Committee :(a)to carry out
the decisions of the Managing Committee and the General Body on Water Regulation, schedule of
water release;(b)to organise patrolling of the canal, channels and regulate the use of water;(c)to
check the irrigation and drainage system regularly;(d)to record the water deliveries;(e)to report to
the Managing Committee any violations in the use of water;(f)to maintain records of landowners
and water users; and(g)to educate in optimum use of water.(iv)Training and Capacity Building
Sub-Committee :(a)to identity training needs of the members;(b)to organize and conduct training
for the members; and(c)to provide information, education and awareness on activities relating to
the growth of the farmers' organisation to the members.(v)Social Audit and Monitoring and
Evaluation Sub-Committee :(a)to conduct social audit as mentioned in Rule 23;(b)to monitor and
evaluate all activities of the farmers' organization as authorised by the Managing
Committee.(vi)Dispute Resolution Sub-Committee :(a)In case of Sub-Committee of the Managing
Committee of Water Users' Association, to resolve the disputes between members and water users in
its area of operation;(b)In case of Sub-Committee of the Managing Committee of Distributor}'
Committee, to resolve the disputes among the Water Users' Associations in its area of operation;
and(c)In case of Sub-Committee of the Managing Committee of Project Committee, to resolve' the
disputes amongst the Distributory Committees in its area of operation.(8)The Sub-Committee shall
meet as frequently as necessary. The convener of the Sub-Committee will preside over the meetings
and maintain the record of discussions and decisions thereof and place the record to the Managing
Committee for further action.(9)The Farmers' Organisation in addition to the Sub-Committee
mentioned in this rule may constitute any other Sub-Committee/s in accordance with the procedure
in this rule.(10)The Sub-Committee shall function under the general superintendence, control and
direction of the President of the respective Managing Committee of the organisation.Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

21. Procedure for taking up works.
- For the purposes of taking up works under clauses (b) and (u) of Section 25, clauses (b) and (j) of
Section 26 and clauses (b) and (i) of Section 27 of the Act, the Farmers' Organisation shall adopt the
following procedure ;-(1)System Diagnosis for Maintenance Works :(i)Prior to the commencement
of every crops season (kharif & rabi) the Managing Committees and Competent Authority of every
Farmers' Organisation shall undertake to assess the condition of the system (system diagnosis)
through a participatory walk through exercise.(ii)The Farmers' Organisation shall inspect each and
every' hydraulic structure and record its status.(2)All works shall be categorised as follows(i)Normal
operation and maintenance works, which includes ordinary repairs, such as :-(a)Desilting;(b)Weed
removal;(c)Embankment repairs;(d)Revetment;(e)Repairs to shutters;(f)Repairs to masonry and
lining;(g)Cleaning & Oiling of screw gearing shutters;(h)Painting of hoists and gates
etc.:(i)Emergent breach closing works; and(j)Maintenance of inspection paths.(ii)Scheduled
Maintenance Works (Rehabilitation Works) :-(a)Reconstruction of
sluices;(b)Reconstruction/repairs to drops regulators;(c)Reconstruction of measuring
devices;(d)Rehabilitation of the system; and(iii)Original Works :-(a)Modernisation of the System;
and(b)Any other construction works in the irrigation system.The above works shall be executed by
the Farmers' Organisation, or by any especially hired personnel of the Farmers' Organisation with
the approval of its General Body under the supervision of the Water Resources Department at the
rates not exceeding estimated rates.(3)Identification of normal operation and maintenance
works-participatory walk-through. - The Chairperson/President along with the Managing
Committee members shall organise a participatory walk-through with the Competent Authority or
his engineer representative within the area of operation of the Farmers' Organisation and identify all
the critical reaches, which need immediate repair as listed out above. The Competent Authority shall
assist the Farmers' Organisation in preparation of detailed list of works to be
undertaken.(4)Prioritising Works. - The Managing Committee of the Farmers' Organisation shall
discuss the list so prepared and fix up priority or works to be taken up immediately.(5)Preparation
of estimates. - The Competent Authority shall prepare estimates within a fortnight for the works so
prioritised according to the hydraulic particulars as maintained by the Water Resources Department
at the prevailing schedule of rates.(6)Administrative approval. - The Managing Committee of the
Farmers' Organisation shall accord administrative approval for the estimates prepared subject to
availability of funds. Each administrative approval shall be recorded in the register of administrative
approvals in Form "N".(7)Technical Clearance. - (a) The powers for giving technical clearance by the
Competent Authority shall be as follows :-(i)Special Repairs :(a)Executive Engineer : Upto Rs.
2,00,000/-(b)Superintending Engineer : Upto Rs. 5,00,000/-(c)Chief Engineer : Above Rs.
5,00,000/-(ii)Ordinary Repairs :(a)Sub-Divisional Officer Rs. 50,000/- (Competent Authority). -
Upto(b)Executive Engineer. - Full powers within the funds provided to Farmers' Organisation;(c)a
Competent Authority may accord technical clearance vested in an authority lower than him;(d)the
Competent Authority, shall record all the technical clearance in the register of technical clearance in
Form I appended to the rules;(e)the technical clearance shall not exceed the Administrative
approval; and(f)in respect of a Distributory Committee, the Project Committee, the Competent
Authority may cause the technical clearance to be given by an appropriate officer under his control
as per the financial powers mentioned in clause (a).(8)Managing of taking up works. - (a) Works as
approved by the Managing Committee of the Farmers' Organisation shall be taken up for executionChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

by the Farmers' Organisation itself;(b)Under no circumstances Chairperson/President or Managing
Committee Member of the Farmers' Organisation executes a work directly in his individual
capacity;(c)The cost of works executed shall not exceed the estimated costs; and(d)The Competent
Authority shall record the initial measurements and final measurements for quantifying the work
done for making payments by the Farmers' Organisation.(9)Maintenance and Adherence to the
Designed Hydraulic Particulars. - The Competent Authority shall be responsible for the
maintenance and adherence to the approved hydraulic particulars. He shall ensure that the designed
hydraulic particulars of an irrigation system are not altered with. He shall guide the Farmers'
Organization in supervising works.(10)Limitations on Works. - No Farmers' Organisation shall have
the power to interfere with the designed hydraulic particulars of an Irrigation system. Any violation
will invite the penal provisions under Section 39 of the Act; and the rules made
thereunder.(11)Publication of List of Works to be taken up. - (a) The lists of works to be taken up
should be given wide publicity by means of display in the office of the Farmers' Organisation and
other public places and institutions within the area.(b)Alongwith the lists other particulars of works,
estimates, values, and mode of execution should be given wide publicity; and(c)If any member
wishes to have access to any oi the records relating to works to be taken up, he may do so on
payment of the fee as fixed by the Farmers' Organisation.(12)Freedom to add Other Funds or Extra
Contributions. - The members are free to contribute resources cither in cash or by way of material or
labour.(13)Proof of Works Done. - The Competent Authority shall maintain. Level Field Book, and
Measurement Book for recording the work done by the Farmers' Organisation.(14)Payment for the
Works Done. - All payments lor works done above Rs. 1000/- shall be paid by cheque. The Farmers'
Organisation shall maintain a record of all payments made in the Cash Book date-wise.(15)Original
Works. - A Farmers' Organisation may take up any original work within its area of operations
subject to the following conditions; namely :-(a)Specific approval shall be obtained from the
authority vested with such powers to do so.(b)The estimates for works shall be prepared by the
Water Resources Department and works shall be lot out to the Farmers' Organisation wherever they
come forward for execution of such works at the estimated rates.(c)If the Farmers' Organisation
agrees to take up any work, an agreement shall be entered into with the Water Resources
Department.(d)Payments shall be made to the Farmers' Organisation based on the out turn of work
on fortnightly basis or even earlier as may be mutually decided.(e)Where the Farmers' Organisation
does not come forward the procedure as prescribed under the "Works Department Manual" shall be
followed or as per any direction given by the Government from time to lime.
22. Removal of Encroachments.
- In accordance with sub-section (2) of Section 25 of the Act, a Water Users' Association may remove
encroachments from property attached to the canal system within its area of operation and shall
take the following steps therefor-(i)Discuss about the encroachment in the meeting of the Managing
Committee;(ii)Pass a Resolution in the Managing Committee by majority of members present and
voting that such an encroachment constitutes an offence under Section 39 of the Act;(iii)As per
Resolution passed by the Managing Committee, the Water Users' Association shall make efforts to
remove the encroachment including by taking all possible measures under Rule 36 of these
rules;(iv)In case of failure to remove the encroachment, inform the concerned Canal Officer in
writing about (i), (ii) and (iii) above;(v)Help the concerned Canal Officer in carrying out the surveyChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

and preparing official report about the encroachment;(vi)Assist the concerned Canal Officer in
removing the encroachment as per the Government procedure.
23. Social Audit of Farmers' Organisation.
(1)At the end of each crop season, the Farmers' Organisation through its Social Audit and
Monitoring and Evaluation Sub-Committee shall conduct Social Audit as detailed below :-(i)Social
Audit shall be done for water utilization against the water budgeting and expenditure incurred for
maintenance of the system with reference to the funds available to each of the Farmers'
Organisation and shall also cover;(ii)Social audit shall be for following :-(a)Equity in water
distribution;(b)Increase in production;(c)Increase in productivity;(d)Crop
diversification;(e)Multiple cropping;(f)Water use efficiency;(g)Utilisation of resources for execution
of works;(h)Improvement in the cultivated areas of the Farmers' Organisation compared to previous
season;(i)Quality of works undertaken; and(j)All other activities as mentioned under the Act and in
the Rules.(2)The Social Audit so conducted shall be made known to all the beneficiaries under the
Farmers' Organisation by way of displaying a list-containing the benefits accrued with reference to
funds spent on the notice board of the office of each of the Farmers' Organisation.(3)Whenever a
work is taken up, the estimated cost of the work, item of work proposed to be executed, details of the
executors of the work etc., are to be exhibited on a board at the place of the work; so that every'
beneficiary under the Farmers' Organisation is aware of the details of the work being executed and
expenditures to be incurred.(4)The Social Audit so conducted shall be recorded and a copy thereof
be sent to the Distributory Committee in the case of Water Users' Association, to the Project
Committee in the case of Distributory Committee; and to the State Level Policy Committee in the
case of Project Committee.(5)The auditor appointed under Rule 29 shall incorporate the Social
Audit Report in his annual audit report together with his specific observations on rectification of
defects, if any, noticed in the social audit.
24. Operational Plan and Water Budgeting.
- The Managing Committee of the respective Farmers' Organisation shall, along with the assistance
of the Competent Authority, prepare a water budget for the area of operation under its control as
detailed below :-(i)One month before the onset of the Kharif season, the Project Committee shall,
subject to such directions as may be given by Government from time to time, work out the
anticipated inflows and existing availability in the reservoir and work out the water allocation to all
the Distributory Committees, the Distributory Committees in turn shall allocate the water made
available to Water Users' Association in its jurisdiction :Provided that in the case of medium
irrigation projects not having Distributory Committees, the Project Committee shall allocate water
to the Water Users' Associations.(ii)A Farmers' Organisation in distributing water to its member
constituents shall have regard to allocations meant for drinking water, or for any specified purpose
as may be decided by Government from time to time.(iii)For the Rabi Season, the Project
Committee will determine the area to be thrown open for irrigation based upon the actual
availability of water and the cropping pattern agreed by the farmers at the beginning of Rabi Season.
The water so available shall be allocated equitably among the Distributory Committees and Water
Users' Associations. In the case of medium or minor irrigation system, equitable distribution shallChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

be achieved by adopting circular rotation over a period.(iv)Each of the Farmers' Organisations shall
draw up an operational plan, which shall specify the quantity of water to be drawn on a specified
periodical basis.(v)The drawals of water shall be, monitored each day at specified gauge points as
decided by the Farmers' Organisation.(vi)Review of the drawals and distribution shall be done by
each of the Farmers' Organisation at the end of each fortnight and corrective measures taken.(vii)At
the end of season the respective Farmers' Organisation shall prepare a report of water received and
utilised along with the area irrigated, quality of water supply and extent of crops.(viii)The Farmers'
Organisation shall analyse the shortcoming and deviations in water budget and report to the next
higher tier.(ix)In respect of a minor irrigation system, the Water Users' Association shall decide the
operational plan, date of release of water, which are to be thrown open for irrigation depending
upon the storage/inflows into the tank.
25. Water Regulation.
- After water budget is prepared, the Farmers' Organisation shall draw up a plan of water regulation
as follows :-(a)The dates of release and closer shall be informed to all members well in
advance;(b)Equitable distribution of water amongst all users shall be the main principle in water
regulation;(c)A Farmers' Organisation shall draw water and monitor flows based on the operational
plan prepared;(d)A Warabandi Schedule (Turn-Schedule) shall be prepared for each outlet in a
Farmers' Organisation;(e)The Farmers' Organisation shall record the crop-wise area in the
command area with the assistance of the Competent Authority; and(f)A Farmers' Organisation may,
for the purpose of monitoring install such devices as may be required within its jurisdiction.
26. Accounts/Finance.
(1)The Farmers' Organisation shall open an account in a nationalised bank or co-operative bank
namely; the District Co-operative Central Bank or the Chhattisgarh State Apex Co-operative Bank in
its name. The account shall be operated jointly by the President and one of the Managing Committee
members as nominated by the Managing Committee. The Farmers' Organisation shall maintain the
cashbook and accounts of expenditure with appropriate vouchers and receipts.(2)Every expenditure
should be supported by a receipt, or voucher which shall be duly passed for payment by the
President(3)All expenditure has to be approved by the finance Sub-Committee, at least once a
month.(4)Every Farmers' Organisation shall maintain accounts register. Each of the following
record shall bear the name, address and the seal of the Farmers' Organisation and shall be machine
numbered; namely :-(a)Cash book;(b)Bill registers;(c)Contingent registers;(d)Receipts books;
and(e)Cheque register.
27. Records to be maintained.
- Each of the Farmers' Organisations shall maintain the following records, other than the records
specifically mentioned in the Act in these rules. An up-to-date copy of the Act/Rules/ Directions
and. orders of Commissioner/Government :-(a)The following maps shall be maintained by each
Water Users' Association; namely :-(i)Map showing the boundaries and jurisdiction of the
association, water conveyance system, within the boundaries of the association;(ii)Map showing theChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

notified command area with serial numbers as prescribed in sub-rule (6) of Rule 3 of the Farmers'
Organisation Constitution Rules, 2006.(b)The following registers shall be maintained; namely
:-(1)Property Register and Records. - These records shall contain the details of properties, assets and
liabilities vested in a Farmers' Organisation like lands, buildings, canal banks etc.(i)Inventory
Register (Component Register). - An inventory register in Form "O" shall contain particulars of
hydraulic particulars of structures, including details of canals and with their hydraulic
particulars.(ii)Register of Vacant Land and Buildings in Forms "p"(iii)Miscellaneous Properly
Register. - Other minor properties such as trees grass etc. in Form "Q"; and(iv)Register of Machines.
- shall contain the list of machines working and condemned in Form "R".(2)Membership Register
and Records. - Registers relating to memberships as specified in sub-rules (1), (2) and (3) of Rule
4.(3)Water Flows Register and Records. - Every Farmers' Organisation shall be supplied with water,
based on the operational prepared plan. These flows need to be monitored daily at specified
locations as decided by Farmers' Organisation-(i)A Reservoir Gauge Register in Form-"S".(ii)A
Canal Gauge Register in Form-"T".(4)Area Crops Register and Records.-(i)Command Area Register
in Form-"U".(ii)Farmerwise Demand Register in Form-"V".(5)Works Register and
Records.-(i)Register of Administrative Sanctions in Form-"N".(ii)Register of Technical Clearance in
Form-"N".(6)Cash Register and Records.-(i)Cash Book in Form-"W".(ii)Receipts Book in Forms "X",
"X-1", "X-2" and "X-3".(iii)Register of Issue of Receipt Book in Form "X-4".(iv)Bill Register in
Form-"Y".(v)Cheque Memo Register in Form-"Z".(vi)Special Fee Register in Form "Z-1".(7)Minutes
Register and Records. - Every proceeding of a General Body meeting, a Managing Committee
meeting, a Sub-Committee meeting shall be recorded separately in a minutes book.
28. Levy & Collection of Fees.
(1)The Farmers' Organisation may by resolution passed by the General Body of the concerning
committee levy' a fee.(2)A fee under sub-rule (1) shall be levied for the following purposes for the
Farmers' Organisation :-(a)to provide facilities;(b)to provide specific services;(c)to meet any urgent
needs of the Farmers' Organisation;(d)to build up assets of the Farmers' Organisation; and(e)to
improve the system.(3)After passing the resolution by the General Body, the Competent Authority
shall prepare the estimate for the purpose as specified in sub-rule (2) and the Managing Committee,
shall decide a levy of fee proportionate to the land holding or to the number of members. The
Managing Committee after its decision shall serve the demand notice to the concerned.(4)All fees
collected shall be duly accounted for and the receipt thereof be given to the concerning person.(5)A
fee collected for a specific purpose shall be used only for that purpose.(6)(a)In default of payment of
fee by any member, the Managing Committee shall prepare a list of defaulters along with amounts
due.(b)The defaulters list so prepared in clause (a) shall be sent to the Sub-Engineer, Water
Resources Department, of the area in whose jurisdiction the area of operation of a Farmers'
Organisation lies for recovery.(7)The water charges collected by the Water Users' Association shall
be deposited with the treasury of the State Government and on such deposit a minimum of twenty
five percent of the deposited amount shall be assigned to the said Water Users' Association in
accordance with sub-section (3) of Section 31 of the Act in the manner as follows :-(i)The President
of Water Users' Association shall issue a receipt book to each of the elected territorial constituency
members and each of these elected members or any person appointed by them, with such appointee
having the approval of the Managing Committee, shall collect the water charges in their ownChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

constituency and shall in turn issue the receipt to the members of the General Body making the
payment in Form "X-1";(ii)The amount collected by the elected territorial constituency members or
their appointees under (i) shall be deposited by them within seven days with the President of the
concerned Water Users' Association and the President shall issue a receipt to the elected territorial
constituency members or their appointees in Form "X-2";(iii)The President of the concerned Water
Users' Association shall deposit the amount collected under (ii) with the Competent Authority
within seven days of receipt from the elected territorial constituency members and obtain a receipt
for the same in Form "X-3". The Competent Authority shall then ensure that the amount collected is
deposited with the treasury/bank of the State Government within seven days of receipt from the
President of the concerned Water Users' Association in the prescribed manner and he shall inform
the concerned Executive Engineer of such deposit within seven days with the requisite proof of
deposit;(iv)On deposit of amount under (iii) a minimum of twenty five percent of the deposited
amount shall be assigned to the Water Users' Associations by the concerned Executive Engineer
from the funds made available to him by the State Government;(v)On the amount deposited under
(iii) with the treasury/bank of the State Government within one financial year, the assignment of
minimum of twenty five percent of the deposited amount to the Water Users' Association under (iv)
shall be carried out within the next financial year;(vi)The President of the Water Users' Association
and the Elected territorial constituency members or their appointees shall, in lieu of services
rendered by them for collection of water charges under this sub-rule, be provided adequate
monetary compensation as decided by the Managing Committee and approved by the General Body
of the Water Users' Association and from the amount assigned in (iv) to the said Water Users'
Association;(vii)In situations where there is State Government Programme, Scheme or Initiative for
remission of water charges for the water users, the Water Users' Associations shall be free to adopt
such Programme, Scheme or Initiative in its area of operation and upon such adoption the
Programme, Scheme or Initiative, for the extent specified therein, shall apply to all the concerned
water users;(viii)In addition to the amount assigned to Water Users' Association under this
sub-rule, the Water Users' Association shall not be entitled to any other amount or funds from State
Government for normal operation and maintenance works within its area of Operation.
29. Financial Audit.
- At the end of each financial year, and not later than three months after the commencement of the
new financial year, each of the Farmers' Organisation shall cause its accounts to be audited as
follows :-(i)The Managing Committee shall appoint an Auditor who has minimum B. Com.
qualification and having adequate experience in normal auditing work;(ii)The Auditor so appointed
shall be a person of repute in the area of operation of the Farmers' Organisation, who has reasonable
knowledge in accounts;(iii)The appointment of the Auditor shall be approved by the Managing
Committee of the Farmers' Organisation;(iv)The Auditor so appointed shall take all steps necessary
to scrutinise the accounts of receipts and expenditure, within thirty days from the dale of his
appointment and furnish the audit report along with the statement of accounts and balance-sheet to
the President of the concerned Farmers' Organisation;(v)The audit report including the social audit
report as mentioned in Rule 33 sub-rule (5) shall be submitted to the General Body in its meeting
for its approval;(vi)The managing Committee of a Farmers' Organisation shall provide the audit
report to the General Body; and(vii)If the overall transactions exceed Rs. 10 lakhs per annum, theChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

Farmers' Organisation shall engage a Chartered Accountant for audit of accounts.
30. Powers of Auditor.
(1)Every auditor appointed under Rule 29 shall have the right of access at all times to books and
accounts, vouchers, returns, correspondence, notes or other documents and records shall be entitled
to require from any of the office bearers of the Farmers' Organisation Sabha such information and
explanations as the auditor may think necessary for the performance of his duties as auditor.(2)If
the required information and records are not provided to the auditor within a reasonable time not
exceeding three days, the fact shall be brought to the notice of the Competent Authority for further
appropriate action in the matter. The Competent Authority shall pass an order as he/she may deem
fit.
31. Auditor not to remove any document without permission.
- The auditor shall not remove from the office of the Farmers' Organisation any books, vouchers or
documents of any kind whatsoever. The auditor may however obtain photocopies or certified copies
of such documents and records as may he considered necessary by him for the process of audit
report.
32. Notice of commencement of audit.
- The auditor shall give to the President of the Farmers' Organisation not less than one week's notice
in writing of the date on which he proposes to commence the audit :Provided that the auditor may,
for special reasons to be recorded in writing, give notice of less than seven days for the audit or
commence audit without any notice, on the authority of the Competent Authority.
33. Certification of accounts and Statements.
- The auditors shall verify and certify the correctness of the Balance sheet, Receipt and Payment
Account, Income and Expenditure Account and all other statements and Returns required to be
submitted or attached with the final accounts as per relevant accounting rules and other rules.
34. Auditor's Report.
(1)As soon as practicable after completion of the audit, the Auditor shall prepare and send a report
in Form Z-2 to the Farmers' Organisation and to the Competent Authority under the Act.(2)The
report shall be concise but shall contain all relevant facts and shall include inter alia the following
points :-(a)Every' sum paid or payable which is contrary to the Act, Rules or Orders and directives
given by the State Government from time to time;(b)The amount of any deficiency or loss, which
appears to have been caused by the negligence or misconduct of any person;(c)The amount of any
sum received which ought to have been but is not brought into account by any person;(d)The
discrepancies noticed, if any, on physical verification of cash securities, stocks and other assets;Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

and(e)any other material impropriety or irregularity which may have been observed in the accounts
other than those mentioned in sub-clauses (a), (b), (c) and (d).(3)The auditor's report shall also
state,-(a)whether he has obtained all the information and explanations which to the best of his
knowledge and belief, were necessary for the purposes of his audit;(b)whether, in his opinion,
proper books of accounts as required by the Act and Rules made thereunder, have been kept by the
Farmers' Organisation;(c)whether the Farmers' Organisation's balance-sheet, income and
expenditure account and the receipt and payment account dealt with by the report are in agreement
with the books of accounts and other relevant records.(4)The auditor's report shall be made in the
Form "Z-2" and in such other forms as may be determined by the State Government from time to
time.
35. Dissolution of Managing Committee.
(1)In accordance with Section 40 of the Act before dissolution of a Managing Committee the
following steps shall be taken by the Appropriate Authority as mentioned in sub-rule (3) :-(i)Issue of
show-cause notice indicating commission of a gross misappropriation of Government
funds;(ii)Receipt and consideration of the reply from the Managing Committee to the notice so
served :Provided that where the Management Committee fails to reply to the notice issued upon it
within forty five days of issuance of such notice, the Appropriate Authority may proceed to take
further action without waiting for the receipt of reply from such Committee;(iii)Conduct appropriate
investigation and enquiry including consultation with the next upper level Farmers' Organisation or
the Canal Officer as the case may be, before proceeding to dissolve the Managing Committee.(2)On
dissolution of the Managing Committee under sub-rule (1), the Managing Committee shall be
re-constituted within a period of three months from the date of dissolution.(3)For the purpose of
dissolution of Managing Committee, the Appropriate Authority shall be as under :-(i)For Managing
Committee of the Project Committee : State Government on recommendation of Chief
Engineer;(ii)For Managing Committee of the Distributory Committee : Chief Engineer on
recommendation of Superintending Engineer;(iii)For Managing Committee of the Water Users'
Association : Superintending Engineer on recommendation of the Executive Engineer.
36. Offences and Penalties.
(1)The Farmers' Organisation shall have a right to take action on any of the offence specified under
Section 39 of the Act.(2)The President of Farmers' Organisation or his nominees shall give a notice
of the offence to the individual.(3)The individual who has committed the offence shall be given
reasonable opportunity, to explain his point of view.(4)The Managing Committee after examining
the material as indicated at sub-rules (2) and (3) shall decide, by a majority, the nature and gravity
of the offence.(5)If the offence is proved beyond doubt, the Managing Committee may fix an amount
as fine, as specified under Section 42 of the Act and recover it.(6)The fine amount shall be adequate
enough to rectify the tampering or damage in the system, and injury caused to others.(7)The money
recovered as per sub-rule (5) above shall be duly acknowledged and accounted for.(8)In all cases
where the damage due to the offence is estimated to be more than Rs. 1,000/- a complaint shall be
lodged by the President of the Farmers' Organisation or his nominee with the concerned authority
as per Section 20 of the Code of Criminal Procedure, 1973 (Cr.PC, 1973) for legal action.Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

37. Appointment of Competent Authority.
(1)In accordance with Section 28 (1) of the Act, the following officers of the Water Resources
Department shall be the Competent Authority for the Farmers' Organisation at all levels :-
(i) All Water User's Associations. -Sub-Divisional Officer.
(ii) Distributory Committee in medium and major irrigationsystem -Executive Engineer,
(iii) Project Committee in medium irrigation system -Executive Engineer.
(iv) Project Committee in major irrigation system -Superintending Engineer.
(2)In accordance with the sub-rule (1), the concerned Chief Engineer of the Water Resources
Department shall notify the names of the Competent Authorities for each level of the Farmers'
Organisation for each scheme :Provided that nothing contained in this rule will affect the powers of
the Chief Engineer of the Water Resources Department to accord technical clearance under sub-rule
(7) of Rule 21.
38. Functions of Competent Authority.
- In the functioning of the Managing Committee of the Farmers' Organisation, the Competent
Authority, appointed under sub-section (1) of Section 28 of the Act, shall-(a)attend the meeting
convened by the Managing Committee, and participate in the discussions but he has no voting
right;(b)assist in the preparation of maintenance plan;(c)prepare estimates for works identified for
execution; the estimate shall be prepared as per the norms and the rules prescribed by the Water
Resources Department in this regard;(d)accord technical clearance to the maintenance works, as per
the powers delegated. The technical clearance shall be limited to the administrative sanctions for the
work;(e)ensure that no alteration or change is made in the irrigation system, with reference to the
approved hydraulic particulars;(f)bring to the notice of Water Resources Department any tampering
or changes made in the system, by any Farmers' Organisation in contravention of the hydraulic
particulars. He shall ensure that action is taken in accordance with the Act;(g)provide technical
details of the system to the member of the Managing Committee;(h)assist the Managing Committee
in the preparation and approval of operational plan;(i)advise and assist on water regulation, based
on the water supplies and seasonal condition;(j)assist in preparing water budgeting for the Farmers'
Organisation;(k)provide overall help and assistance in areas irrigated;(l)help in training any helper
appointed by the Farmers' Organisation in discharging their duties;(m)guide the Farmers'
Organisation in maintaining various registers; sand(n)record measurement for the work done and
pass the bills for payments by Farmers' Organisation based on the approval of the Work
Sub-Committee.Form ANotification[See sub-rule (1) of Rule 3]Whereas, it has been decided to
delineate the entire command area into Water Users' Areas on hydraulic basis and which are found
to be administratively viable;And whereas, the Water Users' Areas as so divided shall be further
divided equally as far as possible into such number of territorial constituencies for the purpose of
forming the Water Users' Associations;Now. therefore, under sub-rule ................... I........................
the Collector and District Magistrate of .................................... District Authorised Officer hereby
delineate...........................Water Users' Area into.......................territorial constituencies, and direct
that the maps and sketches indicating the various Water Users' Areas and the territorialChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

constituencies shall be displayed on the notice board of the ........................Gram Panchayat and on
the notice board of the office of the Janpad Panchayat.Any objections or claims against the
delineation details below may be filed before the Authorised Officer within seven days excluding the
date of display on the notice board of the Office of Gram Panchayat or the Janpad Panchayat.
....................................... Irrigation System........................
Name of Water Users' Association Total Nos. of Territorial
....................................... Constituencies...........................
Type of the Scheme (Major/Med/Minor) Name of the Tehsil..........................
....................................... Name of Scheme...........................
Total Command Area in Ha.......... Territorial Constituency No..........
Sl.No. Location of Off-Take Sluice Command Area Name of Village
Survey No. Extent in Ha
(1) (2) (3) (4) (5)
     
Collector and District Magistrate/Authorised OfficerDistrict..............Form B[See sub-rule (20) of
Rule 3]Whereas, the objections received against Form "A" displayed on : (date) have been
considered and thoroughly examined.And whereas, it is considered that the amendments of Form
"A" are considered necessary; and accordingly they are hereby made and revised in the table
hereunder :-
....................................... Irrigation System........................
Name of Water Users' Association Total Nos. of Territorial
....................................... Constituencies...........................
Type of the Scheme (Major/Med/Minor) Name of the Tehsil..........................
....................................... Name of Scheme...........................
Total Command Area in Ha.......... Territorial Constituency No..........
Sl.No. Location of Off-Take Sluice Command Area Name of Village
Survey No. Extent in Ha
(1) (2) (3) (4) (5)
     
Collector and District Magistrate/Authorised OfficerDistrict..............Form C[See sub-rule (1) of Rule
4]Under sub-rule (1) of Rule 4 of the Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari
Adhiniyam, 2006 (Act 7 of 2006), I..................... the Tehsildar of the................Tehsil being the
Authorised Officer hereby publish the land holders list as in the table below. Any objections or
claims against the above list may be filed before me within a week from the date of display of this
list.Name of Water Users' Association.........................................Water Users' Association (Is it LIS
and Tubewell or Not)Name of the village.....................Name of the Tehsil...........Territorial
Constituency No....................(Part No.)..............Total Territorial
Constituencies.........................................Type of Scheme
(Major/Medium/Minor)......................................Name of theChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

Scheme.......................................................District.....................Total Command Area (In
Ha)................ Territorial constituency's position (Head/Middle/Tail reach)Land Holders List
SI.
No.Name of the land holder & father's
nameAge SexSpouse's
NameCategory (ST/SC/OBC/
General)
(1) (2) (3) (4) (5) (6)
      
Extent of Holding
(Ha.)Khasra
No.Name of the
VillageWhether Landholder or Water User in other TC?
Ifyes, specify the TC (s)
(7) (8) (9) (10)
    
Collector & District Magistrate/Authorised Officer District..........Water Users' Association.Form
D[See sub-rule (1) of Rule 4]Under sub-rule (1) of Rule 4 of the Chhattisgarh Sinchai Prabandhan
Me Krishkon Ki Bhagidari Adhiniyam, 2006 (Act 7 of 2006), I.................... the
Tehsildar....................Tehsil being the Authorised Officer hereby display in this form the list of all
the voters who are the land holders (owner and/or tenant recorded as such in the record of rights
under the Chhattisgarh Land Revenue Code, 1959) and have completed eighteen years of age on the
date of issue of Notification prepared territorial constituencywise, for electing the President and
members of the Managing Committee of the Water Users' Association specified below.Any objection
against the list may be filed before the undersigned within a week for consideration and
finalisation.Name of the Water Users' Association.....................................Water Users' Association
(Is it LIS and Tubewell or Not)Name of the village....................Name of the Tehsil.......Territorial
Constituency No....................(Part No.)........Total Territorial Constituencies.................................Type
of Scheme (Major/Medium/Minor)..............................Name of the
Scheme...............................................District......................Total Command Area (In
Ha.).......Territorial constituency's position (Head/Middle/Tail reach).....List of all other Water
UsersTerritorial Constituency Serial No.
SI. No. Name of the voter Father's Name Age Sex Spouse's Name Category (ST/SC/OBC/ General)
(1) (2) (3) (4) (5) (6) (7)
       
Land Holder (Land
Owner/Tenant)Name of
villageLand
HoldingWhether Landholder or Water User in
other TC ? Ifyes. specify the TC (s)
Khasra No. Extent
(8) (9) (10) (11) (12)
     
Collector & District Magistrate/Authorised Officer District.........Water Users' AssociationForm
E[See sub-rule (3) of Rule 4]Objection to Inclusion of NameTo,The Authorised
Officer,....................Water Users' Association.Sir,I object to the inclusion of the name
of..........................at Serial No................ in Water Users' Association electoral roll for the following
reason(s).I hereby declare that the facts mentioned above are true to the best of my knowledge and
belief.My name has been included in the electoral roll for this Water Users' Association as follows
:-Name (in full).............................................................Father's/Mother's/Husband's
name...........................................Caste (SC/ST/OBC/General)..................................................SerialChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

No..................................................................Date....................................Signature/Thumb Impression
of Objector(Full Postal Address)I am an elector included in the same electoral roll in which the
name objected to appear, my serial number therein is ............................... I support this objection
and countersign it.Signature of the ElectorName (in full)...............Note. - Any person who makes a
statement or declaration which he either knows or believes to be false or does not believe to be true
is punishable under provisions of Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari
Adhiniyam, 2006 (Act 7 of 2006).Form F[See sub-rule (3) of Rule 4]To,The Authorised
Officer,.....................Water Users' Association.Sir,I request that my name be included in the electoral
roll for the above Water Users' Association.(1)Name (in
full).........................................................(2)Father's/Mothcr's/Husband's
name.......................................(3)Caste
(SC/ST/OBC/Gencral)..............................................(4)Particulars of my place of residence
are...............................(a)House
No........................................................(b)Street/Mohalla..................................................(c)Town/Village....................................................(d)Post
Office.....................................................(e)Police
Station/Tehsil...........................................(f)District........................................................(5)Particulars
and holding.............................................(a)Survey
No.......................................................(b)Extent..........................................................(c)Name of the
village.............................................(d)Name of the Irrigation System...................................I hereby
declare that to the best of my knowledge and bcliel :-(i)that I am a citizen of India;(ii)that my age on
the first day of January 1st/July 1st was(iii)that I am water user of this Water Users' Association at
the address given below.Place.Date.Signature or thumb impression of claimantForm G[See sub-rule
(3) of Rule 4]Application for Deletion of Entry in Electoral RollToThe Authorised
Officer,...............Water Users' Association.Sir,I submit that the entry at Serial No .............. of the
electoral roll for the Water Users' Association relating to* Shri/Smt................*son/wife
daughter.................................of requires to be deleted as the `said person is' *dead/is not a water
user in this Water Users' Association/his name is already included in the voters list at Serial
No............................as such he is not entitled to be registered in the electoral roll for the following
reasons:-.................................................................................................................................................................................................................I
hereby declare that the facts mentioned above are true to the best of my knowledge and belief.I
declare that I am an elector of this Water Users' Association being enrolled at Serial No................of
the roll.Place........................Date.........................Signature/Thumb Impression of Objector(Full
Postal Address)Note. - Any person who makes a statement or declaration which is false or which he
either knows or believes to be false or does not believe to be true is punishable under provisions of
Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Adhiniyam, 2006 (Act 7 of 2006).*
Strike out the inappropriate words.I am an elector.........................included in the electoral roll of the
same Water Users' Association in which the claimant has applied for deletion. My serial No. therein
is ............................ I support this claim and countersign it.Signature of the ElectorName (in
full)...........................Note : - Any person who makes a statement or declaration which is false and
which he either knows or believes to be false or does not believe to be true is punishable under
provisions of Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Adhiniyam, 2006 (Act 7
of 2006).Form H[See sub-rule (3) of Rule 4]Notice of Final Publication of Electoral RollIt is hereby
notified for public information that the list of amendments to the draft landholders list, voters list
and other water users' list of the Water Users' Association have been prepared in accordance withChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

the Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Adhiniyam, 2006 (Act 7 of 2006),
and a copy of the said lists together with the lists of amendments have been published and will be
available for inspection at my office.Place........................Date..........................Authorised
OfficerDesignationDistrict.Form I[See sub-rule (5) (i) of Rule 4]DeclarationI.........................son of
Shri............................ resident at Door No................. of village.....................aged about.........years,
Caste (SC/ST/OBC/General).......................hold lands as follows :-
Survey No. Extent in Ha. Village Territorial Constituency No.
(1) (2) (3) (4)
    
I declare that I intended to vote in Territorial Constituency
No..................Place.....................Date......................Signature......................To,The Authorised
Officer,.................Water Users' Area.................Tehsil.................DistrictI, the Authorised Officer for
the..........................WUA do hereby allot .................Territorial Constituency to
Shri.................................. for the following reasons :-(1)Based on the applicants request(2)Based on
the extent of land held(3)Others.Authorised Officer......................AcknowledgmentReceived an
Application Form for exercise of option to Territorial Constituency in WUA from Shri
.................................Authorised Officer........................Form J[See sub-rule (1) of Rule 5]*In exercise
of the powers conferred by sub-section (1) of Section 6 of the Chhattisgarh Sinchai Prabandhan Me
Krishkon Ki Bhagidari Adhiniyam, 2006 (Act 7 of 2006) the Government hereby delineate the
Distributory Areas.................Irrigation System, for the purpose of constituting Project Committees
as specified in the table below :-Table
SI.
No.Name of the Distributory
CommitteeLocation of the
Off-take SluiceName of the
WUAsNames of the
TehsilName of the
District
(1) (2) (3) (4) (5) (6)
      
Form K[See sub-rule (1) of Rule 6]*In exercise of the powers conferred by sub-section (1) of Section
6 of the Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Adhiniyam, 2006 (Act 7 of
2006) the Government hereby delineates the project areas for.................Irrigation System, for the
purpose of constituting Project Committees as specified in the table below...................Irrigation
System..............................DistrictTable
SI.
No.Name of the Distributory
CommitteeLocation of the
Off-take SluiceName of the
WUAsNames of the
TehsilName of the
District
(1) (2) (3) (4) (5) (6)
      
Form L[See sub-rule (2) of Rule 8]Recall NoticeThe undersigned persons constitute one-third of the
total number of voters/members of General Body of the Water Users' Association/Distributory
Committee/Project Committee situated in.......................Tehsil/Tehsils ..................... District. We
have lost confidence in the President/Member, Managing Committee/Chairperson of the said Water
Users' Association Distributory Committee/Project Committee. We propose to recall
him.Accordingly it is requested to call for a meeting of the following voters/Members of the General
Body of the said ....................... Water Users' Association/Distributory Committee/Project
Committee under sub-rule (4) of Rule 8 of the Chhattisgarh Sinchai Prabandhan Me Krishkon Ki
Bhagidari Adhiniyam, 2006 (Act 7 of 2006) rules and to move the motion for recall and conductChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

voting for the purpose of passing a resolution thereat date.
Sl.No. Name Village Sl.No. in voters list Signature
(1) (2) (3) (4) (5)
     
To,The Authorised/Nominated OfficerTchsil/Office of the Collector andDistrict
Magistrate.....................DistrictForm M[See sub-rule (3) of Rule 8]VerificationI being the authorised
Officer/Nominated Officer has received the Recall notice for the purpose of recalling the
President/Member of the Managing Committee/Chairperson of the............................ Water Users'
Association/Distributory Committee/Project Committee situated in ................... Tehsil/Tehsils
District has verified the signature of the persons subscribe to the recall notice with the concerned
voters list/lists of the concerned General Bodies and found their names given therein to be correct
and genuine. Accordingly, I proceed to take-further action in the matter.Authorised Nominated
OfficerStation.........................District........................Form N[See sub-rule (6) of Rule 21 and sub-rule
(5) of Rule 27]Register of Technical Sanction (T.S.)/Administrative Sanction (A.S.)Name of the
WUA/FO.............
WAS/DAS/PAS/
WTS/DTS/PTS Sanction No.
and yearSanctioned
byHead of
AccountName of
workAmount of
EstimateDate of
SanctionInitial
(1) (2) (3) (4) (5) (6) (7)
       
Note. - WAS. - WUA's Administrative Sanction.WTS. - WUA's Technical Sanction by Competent
Authority (Technical).DAS. - Distributory Committee's Administrative Sanction. DTS. - Distributory
Committee'sTechnical Sanction by Competent Technical Authority.PAS. - Project Committee
Administrative Sanction.PTS. - Project Committee Technical Sanction by Competent Technical
Authority.Form O[See sub-rule (1) (i) of Rule 27]Register of Component WorksName of the
Scheme......................Name of the WUA/FO..............
Sl.
No.Distance
form
headPosition
Right
(R),
Left (L),
Across
(X)Name and
description
of workReduced
levels
(m) or
ft.Dimensions
(m) or ft.Slopes of bank
number of vents
openingsAreas
chargeable
catchment or
drainage
ha/km.2Discharge
capacity
[million
cum of
(mcft)]Remarks
(1) (2) (3) (4) (5) (6) (7) (8) (9) (10) (11) (12) (13) (14)
   Canals
channels,
aqueducts
or super
passagesBed(a)
canal(b)
drain(a) FSL of
canal(b)
MFL of
drain(a) Top of
lining(b)
Bank/parapet(c)
Flood bank(a) Canal
BW/Bed
fall(b) drain
BW/bed fallDepth or
height(a)
canal(b)
flood
bankTop
width of
bank
R/L(a)
canal(b)
flood
bnakFront
Rear &
slopes(a)
canal(b)
flood
bankAyacut
below (b)
drainage
areaAt(a)
FSC of
canal(b)
MFL of
drain1. In case of
regulators
&bridges
the
dimension
undercolumn
(a) should
be up to
bottom of
grider.Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

(1) (2) (3) (4) (5) (6) (7) (8) (9) (10) (11) (12) (13) (14)
   Drops and
canal fallsSill or
floorFront(a)
bed(b) FSLRear(a) bed(b)
FSLLength(a) at
sill(b) at topHeight of
opening
vent or
notchOverall
lengthNumber
of
opening
of ventsAyacut
belowAt FSL
of canal2. The
allbrivation
toiloring
FSC Full
supply
Level MFL
   Sluices of
syphonesSill or
floor(a) Canal
bed from
rear(b)
Drain bed(a) Canal FSL
from rear(b)
Drain MFLwidth at stillHeight of
ventOverall
length of
pipe or
barrelNumber
of vents(a)
Ayacut(i)
parent
canal(ii)
off-take
canal(a) At
FSL(i)
parent
canal(ii)
off-take
canal(b)At
MFL of
drainMaximum
flood level
B/W Bed
width R/L
Right Left
   Inlets
outlets
escape,
sluicesCrest or
sillMFL(A)
above(b)
belowTop(a) Canal
bank(b) Canal
bank operationWidth of
wall
(top/bottom
of vent)Height of
wall or
ventOverall
lengthNumber
of ventsDrainage
area(a) At
MFL(b)
At FSL-
   Regulators
and bridgesCrest or
sillFSL(a)
above(b)
below(a) Platform (b)
RoadWidth of(a)
vent(b) road
wayHeight
of(a)
vent(b)
parapetOverall
length(a) No. of
vents(b)
type of
gatesVillages
connectedAt FSL -
From P[See sub-rule (1) (ii) of Rule 27]Register of Buildings & LandName of the WUA/FO.............
SI. No.Village & S.No.
LocationBuilding
Type
Name
DescriptionWalls Floor RoofPlinth in
sft.LandStandard
Rent
(1) (2) (3) (4) (5) (6) (7) (8)(9)
         
  Lands   RemarksRent/Auction
Amounts
Realised
Canal
DrainReach S.No. ExtentType Wet/Dry waste
Barren1997 1998 2006
(10) (11) (12) (13) (14) (15) (16) (17) (18)
         
Form Q[See sub-rule (1) (iii) of Rule 27]Register of Trees-Grass-Other Miscellaneous
PropertiesName of the WUA/FO...........
Sl.No. M.P. Item No. Tank Bund Canal Bank RF-LF Reach From - To
(1) (2) (3)Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

   
Details of M.P.,
Items
LocationNo. of
TreeName of
TreeGirth & Rft. of
TrunkGrass or
luliefloraFish Born OthersMin. Rent/Bid
fixed
(4) (5) (6) (7) (8) (9) (10) (11) (12)
         
 Year-wise collection  
1997 1998 2006
(13) (14) (15)
   
Form R[See sub-rule (1) (iv) of Rule 27]Register of MachinesName of the WUA...............
Sl.No. Name of Machine Make Model H.P. of Machine Year of Purchase
(1) (2) (3) (4) (5)
     
Original Book Value Hire Charges per km. Hour Working Condition Remarks
(6) (7) (8) (9)
    
Form S[See sub-rule (3) (i) of Rule 27]Reservoir Gauge-Discharge RegisterName of
Reservoir/Tank..............ETL..................MWL.................TBL.................... Name of the WUA/FO
...........
Date Reservoir level to 8 A.M. Capacity in Mcft. Front Gauge Rear Gauge
(1) (2) (3) (4) (5)
     
 Head Sluice (1) Sluice (2) Head over crest
Vent way & opening Head Discharge  
Cusecs Mcft
(6) (7) (8) (9)(10)
     
Spilway/surplus weir Evaporation  Total
out flow
Mcft.
Vent way & opening Discharge In ft. in Mcft.
Cusecs Mcft.
(11) (12) (13) (14) (15) (16)
      
RainfallRise/fall of Res. Level
in ft.Net Impounding Depletion
Mcft.Total Inflow
Mcft.Net
Utilisation
Mcft.RemarksChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

(17) (18) (19) (20) (21) (22)
      
Form T[See sub-rule (3) (ii) of Rule 27]Canal Gauge-Discharge Register
Name of parent canal/Distributory..........  Name of the WUA/FO.
  At Start  
  Bed width............
  Fully Supply Depth
  Gauge................
  Discharge............
Date Time Gauge @ Start of F.O. Discharge in Cusecs
(1) (2) (3) (4)
    
  At End
  Bed width.......................
  Fully Supply Depth.............
  Gauge...........................
  Discharge......................
  Discharge in Discharge cusecs
Gauge @ end of F.O. Discharge in cusesc Discharge
  In cusecs In Mcft.
(5) (6) (7) (8)
    
Form U[See sub-rule (4) (i) of Rule 27]Command Area RegisterName of Source................. Name of
the WUA/FO
S. No. Name of the Land Holder/Father's Name Name of Village
(1) (2) (3)
   
Survey Number Extent of Command Area Total Remarks
(4) (5) (6) (7)
    
Form V[See sub-rule (4) (ii) of Rule 27]Register of Irrigated Areas and DemandsName of
Source................. Name of the WUA/
Sl.No. Name of the Land Holder/Father's Name Survey No. Extent of holding
(1) (2) (3) (4)
    
Actual Area Irrigated Type of Crop Nos. of Watering Water Charge Rate Assessment Amout
(5) (6) (7) (8) (9)
     Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

Form W[See sub-rule (6) (i) of Rule 27]Cash BookName of the WUA/FO ..................
Date of
ReceiptNo. of Temporary Receipt if any
with dateNo. of Vouchers
receivedFrom whom
receivedAmount
(1) (2) (3) (4) (5)
     
Head Account Details of Receipt Dated Initials Date of Payment Voucher No.
(6) (7) (8) (9) (10)
     
To whom paid Cash Cheque Head of Account Details of Payment Dated Initials
(11) (12) (13) (14) (15) (16)
      
Form X[See sub-rule (6) (ii) of Rule 27]OriginalTemporary Receipt(Stamp of Farmers
Association)Book No............................Receipt
No.........................Date............................................Received
Rupees.....................................................................From
Shri...........................................................................S/o.................................................................................Towards
the.........................................................................Place...................Date........................Signature
AuthorisedAuthority of the Farmers' AssociationDuplicateTemporary Receipt(Stamp of Farmers'
Association)Book No........................Receipt
No............................................Date...............................Received
Rupees.............................................From Shri...................................................S/o...........Towards
the...........................................Place..............Date...............Signature AuthorisedAuthority of the
Farmers' AssociationForm X-1[See sub-rule (7) of Rule 28]OriginalTemporary Receipt(Stamp of
Water Users' Association)Book No....................................Receipt
No.......................Date...................Received Rupees.....................................From
Shri................................. S/o ....................................Towards the
.............................Place...........................Date............................SignatureMember of Managing
Committee ofWater Users' Association with StampDuplicateTemporary Receipt(Stamp of Water
Users' Association)Book No................Receipt No...........................Date....................Received
Rupees.......................From Shri............................. S/o ..................Towards
the..........................Place.......................Date.......................SignatureMember of Managing Committee
ofWater Users' Association with StampForm X-2[See sub-rule (7) of Rule 28]OriginalReceipt(Stamp
of Water Users' Association)Book No...........................Receipt
No..............................................Date................Received
Rupees..............................................................From
Shri....................................................................(Name of the Member of Managing Committee of
Water Users' Association)
S/o..........................................................................R/o..........................................................................Towards
the..................................................................Place...........................Date...............................SignaturePresident
of the Water Users' Association with stampDuplicateReceipt(Stamp of Water Users'
Association)Book No...........................Receipt No..............................................Date................Received
Rupees.........................................................................From
Shri...............................................................................(Name of the Member of Managing CommitteeChhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

of Water Users'
Association)S/o.....................................................................................R/o.....................................................................................Towards
the..................................................................Place............................Date................................SignaturePresident
of the Water Users' Associationwith stampForm X-3[See sub-rule (7) of Rule
28]OriginalReceipt(Stamp of Competent Authority/Sub-Divisional Officer)Book
No......................Receipt No..............................................Date................Received
Rupees......................................................From Shri............................................................(Name of
the President of Water Users'
Association)S/o..................................................................R/o..................................................................Towards
the..........................................................Place........................Date.........................SignatureCompetent
Authority/Sub-Divisional Officer with StampDuplicateReceipt(Stamp of Competent
Authority/Sub-Divisional Officer)Book No.....................Receipt
No..............................................Date................Received
Rupees.......................................................................From
Shri.............................................................................(Name of the President of Water Users'
Association)S/o...................................................R/o...................................................Towards
the...................................................................Place..........................Date...........................SignatureCompetent
Authority/Sub-Divisional Officer with StampForm X-4[See sub-rule (6) (iii) of Rule 27)Issue of
Receipt BooksName of WUA .......................
Sl.No. Receipt Issued to Acknowledgment
Book No. Pages Name of T.C. member Name of T.C.
(1) (2) (3) (4) (5)
      
Form Y[See sub-rule (6) (iii) of Rule 27]Bill RegisterName of WUA/FO................
Sl. No. Date of Submission and Despatch No. Name of the Work Amount of Estimate
(1) (2) (3) (4)
    
Ref. to sanction Amount of Bill M.B. No. and Page Name of the Agency Initial
(5) (6) (7) (8) (9)
     
Form Z[See sub-rule (6) (iv) of Rule 27)Register of Cheque Memo RegisterName of
WUA/FO..............
Sl. No. To whom the Cheque issued Name of the work Cheque No. & Date
(1) (2) (3) (4)
    
Amount of Cheque Cheque Book No. Amount of Budget Balance Amount Signature
(5) (6) (7) (8) (9)
     
Form Z-l[See sub-rule (6) (v) of Rule 27]Special Fee RegisterName of WUA/FO....................
Sl.No. Date Description of Special Fee Period
(1) (2) (3) (4)Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

    
From whom collected Amount Temp. Receipt No. Remarks
(5) (6) (7) (8)
    
Form Z-2[See sub-rule (1) of Rule 34]Auditor's Report of the Accounts of Farmers'
Organisation........................for the year ended on....................Auditors have audited the attached
Balance Sheets of.....................Farmers' Organisation as at 31st March ............. the Income and
Expenditure Account and Payment Account for period on that date, annexed thereto :Report as
follows :-(1)I have obtained all the information and explanation which to the best of my knowledge
and belief, were necessary for the purpose of audit.(2)In my opinion, proper books of accounts and
other records required by Act and rules have been kept by the Farmers' Organisation so far as
appears from my examination of such books and records.(3)The Balance Sheet, Income and
Expenditure Account and the Receipt and.................................................... Farmers' Organisation
Account referred to in this report are in agreement with the Books of Account referred to in this
report.(4)All the payments made by the ........................... Farmers' Organisation are in accordance
with the law and within the authority of the..................Farmers' Organisation except
.....................(report contrary payments if any).(5)No deficiency or loss appears to have been caused
by the negligence or misconduct of any person except.................... (report if deficiency/fraud, loss,
etc. detected).(6)All the sums ought to have been received by ...................... Farmers' Organisation
have been brought into account; except .....................(report accounted receipts, if any).(7)No
material impropriety or irregularity was observed except, those reported as above.(8)All the grants
received by.......................Farmers' Organisation have been utilised and applied in accordance with
the terms of sanction and attached conditions except .............................(report
misutilisation/un-authorised diversions, etc.)(9)I have discussed the irregularities, discrepancies
and other objections with the President of the ................................ Farmers' Organisation and settled
all possible objections except (report in brief main unsettled objections).(10)In my opinion and to
the best of my information and according to the explanations given and subject to the detailed
report, annexed hereto the said accounts gives a true and fair view :-(i)In the case of Balance Sheet,
of the state of affairs of the .............. Farmers' Organisation as at 31st March(ii)In the case of Income
and Expenditure Account of the Surplus/Deficit of Income over Expenditure for the period ended on
that date; and(iii)In the case of Receipt and Payment Account of all the receipts and payments of the
Gram Sabha for the period ended on that date.Place...................Date....................Signature of
AuditorNameDesignationPlace of PostingSeal.Chhattisgarh Sinchai Prabandhan Me Krishkon Ki Bhagidari Niyam, 2006

