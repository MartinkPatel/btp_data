63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30
April, 2019
Equivalent citations: AIRONLINE 2019 SC 249
Author: R.F. Nariman
Bench: Vineet Saran, R.F. Nariman
                                                                            REPORTABLE
                                       IN THE SUPREME COURT OF INDIA
                                         CIVIL APPELLATE JURISDICTION
                                         CIVIL APPEAL NO. 4476 OF 2019
                          (Arising out of Special Leave Petition (Civil) No. 4210 of 2018)
                         63 MOONS TECHNOLOGIES LTD.
                         (FORMERLY KNOWN AS FINANCIAL
                         TECHNOLOGIES INDIA LTD.) & ORS.               … APPELLANT
                                                      VERSUS
                         UNION OF INDIA & ORS.                         … RESPONDENT
                                                       WITH
                                          CIVIL APPEAL NO. 4478 OF 2019
                           (Arising out of Special Leave Petition (Civil) No.4652 of 2018)
                                                       WITH
                                          CIVIL APPEAL NO. 4477 OF 2019
                           (Arising out of Special Leave Petition (Civil) No.4239 of 2018)
                                                       WITH
                                          CIVIL APPEAL NO. 4479 OF 2019
                           (Arising out of Special Leave Petition (Civil) No.4659 of 2018)
                                                       WITH
                                          CIVIL APPEAL NO. 4481 OF 2019
                           (Arising out of Special Leave Petition (Civil) No.4816 of 2018)
                                                      WITH
                                         CIVIL APPEAL NO. 4480 OF 2019
                          (Arising out of Special Leave Petition (Civil) No. 4720 of 2018)
                                                    WITH
Signature Not Verified
                                     WRIT PETITION (CIVIL) NO.368 OF 2019
Digitally signed by63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

NIDHI AHUJA
Date: 2019.04.30
14:34:05 IST
Reason:
                                                                                             1
                             JUDGMENT
R.F. NARIMAN, J.
1. Leave granted.
2. This batch of appeals and writ petition raises questions as to the applicability and construction of
Section 396 of the Companies Act, 1956, which deals with compulsory amalgamation of companies
by a Central Government order when this becomes essential in the public interest. The appellant, 63
Moons Technologies Ltd. (hereinafter referred to as “FTIL”, which name was changed to 63 Moons
Technologies Ltd. on 27.05.2016), is a 99.99% shareholder of the National Spot Exchange Ltd.
(hereinafter referred to as “NSEL”), and is a listed company. About 45% of the shareholding of FTIL
is held by Shri Jignesh Shah and family, and about 43% of the shareholding is held by members of
the Indian public. Approximately 5% of the shareholding is held by institutional investors. FTIL is a
profitable company, having a positive net worth of over INR 2500 crore, and is in the business of
providing software which is used for trading by brokers and exchanges across the country. FTIL has
about 900 employees, and a Board of Directors which is different from the Board of Directors of its
wholly owned subsidiary, i.e., NSEL. On the other hand, NSEL was incorporated in 2005 by Multi
Commodities Exchanges [“MCX”] and its nominees. NSEL provided an electronic platform for
trading of commodities between willing buyers and sellers through brokers representing them. On
05.06.2007, the Union of India issued an exemption notification under Section 27 of the Forward
Contracts (Regulation) Act, 1952 [“FCRA”] exempting forward contracts of one- day duration for
sale and purchase of commodities traded on NSEL from operation of the provisions of the FCRA.
NSEL commenced operations in October 2008. On 27.04.2012, the Department of Consumer
Affairs [“DCA”] issued a show cause notice to NSEL as to why action should not be initiated against
it for permitting transactions in alleged violation of the exemption granted to it under the FCRA.
NSEL replied to the show cause notice on 29.05.2012 stating that it had not violated the exemption
granted to it. Without adjudicating upon the show cause notice, on 12.07.2013, the DCA directed
NSEL to give an undertaking that no further contracts shall be launched until further instructions,
and that all existing contracts will be settled on due dates. This was effectively a “freezing” order. On
22.07.2013, NSEL gave an undertaking to the DCA.
3. Earlier, in January 2013, representatives of MMTC Ltd., a Government of India undertaking,
which was one of the trading members of NSEL, visited some of the warehouses which were at
different locations in order to verify stocks therein and reported existence of full commodity stock in
the said warehouses. Sometime in July 2013, 13,000 persons who traded on the platform of NSEL
claimed to have been duped by other trading members (being 24 in number), who defaulted in63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

payment of obligations amounting to approximately INR 5600 crore. Due to the sudden and abrupt
stoppage of fresh contracts, and media reports about the same, market participation on NSEL’s
platform reduced considerably, forcing NSEL to suspend trading and close its spot exchange
operations w.e.f. 31.07.2013. The Forward Markets Commission [“FMC”] recommended to the DCA
on 12.08.2013 that steps be taken to verify quantity and quality of commodities at various
warehouses; financial status of buyers and trading members be ascertained, and the liability be fixed
on promoters of NSEL, i.e., FTIL. On 14.08.2013, NSEL issued a press release in which Shri Sinha,
its CEO/MD, made a statement that he and his management team were responsible for all
operations at NSEL. On 27.08.2013, the FMC directed a forensic audit of NSEL by Grant Thornton
LLP, and the Union of India, on 30.09.2013, ordered inspection of the books of accounts of NSEL
and FTIL under Section 209A of the Companies Act. On the same day, the Economic Offences Wing
[“EOW”] registered cases against Directors and key management personnel of the NSEL and FTIL,
trading members of NSEL, and brokers of NSEL under various provisions of the Indian Penal Code
and the Maharashtra Protection of Interest of Depositors Act, 1999 [“MPID Act”]. Several suits were
filed by the traders who allegedly have been duped, the most important of which is Suit No.173 of
2014 pending in the Bombay High Court, which is a representative suit filed under Order I Rule 8 of
the Code of Civil Procedure, 1908 [“CPC”]. NSEL also filed third-party notices in the said suit for
recovery of INR 5600 crore against 24 defaulter traders. It has also filed various arbitration
proceedings against them, and is in the process of recovery of INR 3365 crore out of INR 5600
crore, which are in the form of court decrees and arbitration awards.
4. On 17.12.2013, based on the Grant Thornton report dated 21.09.2013, the FMC passed an order
declaring that FTIL was not “fit and proper” to hold equity in any commodity exchanges, and must
dilute its shareholding to not more than 2% of the paid-up equity capital of MCX. The said order is
under challenge in Writ Petition No. 337 of 2014 before the Bombay High Court. On 28.02.2014, the
Division Bench of the Bombay High Court refused a prayer for stay of the aforesaid order, stating
that findings of fact of a serious nature have been recorded against the appellant, and the fraud
perpetrated is to the tune of INR 5500 crore.
5. On 06.01.2014, the Economic Offences Wing, Mumbai, filed chargesheets against the Managing
Director and CEO of NSEL, Shri Sinha, the Head of Warehousing of NSEL, Shri Babu Kanvi, and
two other defaulters. In the chargesheet, it was revealed that the aforesaid three employees of NSEL,
in exchange for monetary kickbacks, had colluded with the defaulters to enable them to trade on
NSEL’s platform without depositing adequate goods in the warehouses, in breach of rules and
byelaws of NSEL.
6. On 18.08.2014, the FMC, vide a letter to the Union of India, suggested that FTIL and NSEL be
merged. Meanwhile, in the representative Suit No. 173 of 2014, vide order dated 02.09.2014, the
Bombay High Court appointed a three-member committee consisting of Mr. Justice V.C. Daga, Mr.
J. Solomon, and Mr. Yogesh Thar for ascertaining and crystallising the liability of the defaulters and
to assist in recovery of debts from the defaulters. This committee continues to function even on date.
Thus, in addition to INR 3365 crore, i.e., the total of decrees and arbitration awards against the
defaulters, this high-level committee has also crystallised a further sum of INR 835.88 crore to be
recovered from the defaulters, which is pending before the Bombay High Court.63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

7. On 19.09.2014, the Ministry of Finance, Government of India, issued a notification withdrawing
the exemption granted to NSEL vide notification dated 05.06.2007. Exemptions granted to the
National Commodity and Derivatives Exchange Ltd. (NCDEX) Spot Exchange and the National
Agricultural Produce Market Committee (APMC) were also withdrawn as the Government was of
the view that ready delivery or spot delivery contracts in commodities ought not to be traded on
commodities exchanges at all. On 15.10.2014, Dr. K.P Krishnan, Additional Secretary, Department
of Economic Affairs, wrote a letter to the Ministry of Corporate Affairs stating that FTIL and NSEL
appear to be maintaining separate identities for a fraudulent purpose, i.e., to deprive investors of
their money. As a result, there is a need to lift the corporate veil in order to unearth the fraud, as a
result of which, amalgamation of two companies, where one has defrauded market participants and
the other company is cash-rich and capable of addressing the payment crisis more effectively. It was
therefore proposed to merge FTIL and NSEL under Section 396 of the Companies Act. On
21.10.2014, a draft order of amalgamation, made in accordance with Section 396(3) of the
Companies Act, was circulated to the relevant stakeholders. As a result, FTIL filed Writ Petition No.
2743 of 2014 on 10.11.2014, in which it challenged the impugned draft order. On 27.11.2014, the
Bombay High Court directed the parties to maintain status quo. On 16.12.2014, the Union of India
filed an affidavit in reply, categorically confirming that the impugned draft order has been made by
the Central Government on the basis of the FMC’s proposal dated 18.08.2014. On 04.02.2015, the
Bombay High Court vacated the status quo order, and passed an order allowing FTIL, NSEL, and
their shareholders to file their objections to the draft amalgamation order. Meanwhile, under
Section 396(3), a compensation order was made on 01.04.2015, which involved compensation only
to a particular shareholder of NSEL. On 28.08.2015, the Central Government issued a notification to
merge the functions of the FMC with the Securities and Exchange Board of India [“SEBI”] w.e.f.
28.09.2015. On the same day, the FCRA was also repealed. Thus, SEBI was now vested with the
powers of the FMC which is to be governed by the Securities and Exchange Board of India Act, 1992
[“SEBI Act”].
8. FTIL and NSEL were granted a hearing on their objections to the impugned draft amalgamation
order by a committee consisting of Shri Pritam Singh, Additional Secretary to the Government of
India, and Shri H.P. Chaturvedi, Joint Secretary and Legal Advisor, Ministry of Law and Justice in
October 2015, pursuant to a Bombay High Court order in the Writ Petition 2743 of 2014 pending
before it.
9. On 12.02.2016, a final amalgamation order was passed in terms of Section 396(3), thereby
merging FTIL and NSEL, wherein all assets and liabilities of NSEL would become assets and
liabilities of FTIL. The writ petition already filed was amended on 28.03.2016 to include a challenge
to this order. On 04.12.2017, the impugned judgment of the Bombay High Court was passed in
which the said writ petition was dismissed.
10. We have heard Shri Mukul Rohatgi, Shri Vikas Singh, Dr. A.M. Singhvi, and Shri Kavin Gulati,
learned Senior Advocates, and Shri Arvind Lakhawat, learned Advocate, on behalf of the appellants.
According to learned counsel, the first important point to be noted is that in company law, the
holding company, viz. FTIL, is distinct and separate from its subsidiary, viz., NSEL. It was pointed
out to us that there are separate and independent Boards of Directors for managing the day-to-day63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

affairs of both companies, which deal in completely different businesses. It was pointed out that
FTIL has never participated in the profits of NSEL, and except for receiving annual maintenance
charges for providing technology-related services by way of fees, FTIL has not derived any revenue
from NSEL. In fact, over a long period of nine years, FTIL has received only a sum of INR 84 crore
from NSEL which, in any case, is deposited by FTIL in the Bombay High Court pursuant to an order
dated 12.06.2015 in Writ Petition No. 2187 of 2015. Learned counsel were also at pains to point out
that NSEL has not defrauded anybody since it is only a platform. Currently, the business of NSEL is
closed, whereas, on the other hand, the business of FTIL is flourishing. A compulsory amalgamation
order would be ultra vires Section 396 if the only object is to foist unadjudicated liability of NSEL on
FTIL. It was also pointed out that the basis of the amalgamation order was a letter by the FMC,
which in turn was based on a “forensic” audit report of 2013 by Grant Thornton. The so-called
report itself stated that there is no independent verification of information provided, and
consequently, would not constitute an audit, let alone a forensic audit. It also stated that should
additional information become available, which impacts upon conclusions reached in the report,
Grant Thornton reserved the right to amend their findings, which are not intended to be interpreted
to be either legal advice or opinion; in short, that the findings themselves were inconclusive.
11. Learned counsel have argued that the impugned order is ultra vires Section 396 for many
reasons. First and foremost, the condition precedent to passing an amalgamation order is that
compensation be assessed under Section 396(3) of the Act. Compensation has to be assessed qua
both the transferor and transferee company. In the present case, compensation has been assessed
only for NSEL or its shareholders, without any compensation being awarded to FTIL or its
shareholders. Secondly, a member or creditor is required to be placed in the same position “as
nearly as possible”. In the present case, the amalgamated company would become a company of
negative net worth upon amalgamation, having had a positive net worth of almost INR 2800 crore
pre-amalgamation. This being so, the very basis for application of Section 396 would disappear as
the amalgamated company, i.e., the transferee company would have to pay the compensation that is
assessed. This obviously cannot be done when the amalgamated company itself becomes a negative
net worth company. It was then argued that the amalgamation order interfered with the judicial
process in that decrees and arbitral awards obtained by NSEL against defaulters are wholly ignored.
Further, the process of adjudication, which will determine whether there are defaults and whether
they need to be paid back, has been short-circuited by amalgamating NSEL with FTIL. Thus, the
learned counsel have all argued that various conditions precedent for applicability of Section 396 are
wholly absent. Also, in the present case, the Central Government has not applied its mind to
whether such an order is, first of all, “essential”. Secondly, unadjudicated so-called liabilities to
persons who are members of one particular exchange can hardly be said to be something which
requires the Central Government to amalgamate both companies in the “public interest”. The public
interest consists of the interests of the general public which would include, inter alia, the interest of
the 63,000 shareholders of FTIL, who are now going to be mulcted with a huge liability which would
reduce the market value of their shares to nil. They have cited several judgments to buttress these
submissions.
12. Thus, the amalgamation order oversteps recognised separation of powers’ limits, and is
therefore, ultra vires both Section 396 of the Companies Act and the Constitution of India. It was63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

then argued that there are three grounds in support of the order of amalgamation, which are to be
found in the impugned judgment, namely:
A. Restoring / safeguarding public confidence in forward contracts and exchanges
which are an integral and essential part of the Indian economy and financial system,
by consolidating the businesses of NSEL and FTIL;
B. Giving effect to the business realities of the case by consolidating the businesses of
FTIL and NSEL and preventing FTIL from distancing itself from NSEL, which is even
otherwise its alter ego; and C. Facilitating NSEL in recovering dues from the
defaulters by pooling human and financial resources of FTIL and NSEL Admittedly,
reasons A and B are not in the draft order. This being so, obviously, no objections or
suggestions could be made qua reasons A and B, as a result of which the final order
would, therefore, be ultra vires Section 396(3) of the Companies Act.
13. All the stated objectives at page 1 of the amalgamation order itself – (a) to leverage combined
assets, capital and reserves; (b) to achieve economy of scale; (c) efficient administration; (d) gainful
settlement of rights and liabilities of stakeholders and creditors; (e) to consolidate businesses; and
(f) to ensure coordination and policy – are totally vague and do not lead to any application of mind
to such amalgamation order being essential in public interest. Article 31A of the Constitution of
India was relied upon, and it was argued that amalgamation under Article 31A(1)(c) of two or more
corporations can only be made in public interest or in order to secure proper management of any of
the corporations, which is wholly missing in the present case. It was also argued that only Shri
Pritam Singh had signed the order which dismissed the objections, even though the objections were
heard by a two-member committee. They also made submissions that even otherwise, the impugned
order was violative of natural justice and of Articles 14, 19, and 300A of the Constitution of India.
Also, since the amalgamation order is based upon an order of the FMC, which in turn is based upon
the Grant Thornton report, which was delivered in a great hurry, and with such disclaimers that it
could never be relied upon to render final findings, as has been done by the amalgamation order, the
amalgamation order itself would be without application of mind, excessive and arbitrary, and
violative of Article 14 of the Constitution of India on this score alone.
14. When it came to the impugned judgment, the learned counsel for the appellants were at pains to
point out that when the impugned judgment held that no compensation need be paid to FTIL as the
number of shares in the amalgamated company of shareholders remain the same, economic value or
market value of the shares was totally ignored. Thus, in ignoring economic value, a totally artificial,
formal, and non-substantial test has been applied by the Bombay High Court, which says that there
is no necessity to compensate the shareholders of FTIL, even though once they become members of
the amalgamated company, their shares would be worth nil on the date of amalgamation. And, in
the event of winding up, they would get back nothing. It was also pointed out that the three grounds
of the amalgamation order, being reasons for the amalgamation order, which were accepted by the
Bombay High Court, are grounds which do not exist. In ground A, for example, restoring /
safeguarding public confidence in forward contracts and exchanges which are an integral and
essential part of the Indian economy, does not obtain as there were only three commodity exchanges63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

in the country, all of which were shut down w.e.f. September 2014. No similar exchanges have been
created subsequently. In any case, the business done at such exchanges cannot be said to be an
integral and essential part of the Indian economy. Reason B, which is that NSEL is an alter ego of
FTIL, is pending adjudication in the suits filed in the Bombay High Court. To come to a conclusion
that one is the alter ego of the other is not only contrary to the facts pointed out hereinabove,
namely, that the businesses of the two companies are entirely different and the management of both
companies is by completely different and distinct Boards of Directors. Thus, to arrive at the
conclusion that one company is the alter ego of the other, without adjudication, would itself be
arbitrary and violative of Article 14 of the Constitution of India. The only reason which would
remain, therefore, would be reason C, which is that the real object of the entire exercise to recover
alleged dues from alleged defaulters pre-adjudication and pending adjudication, which would be
looking at the problem in a wholly one-sided way, and would be an excessive invasion of the rights
of the shareholders and creditors of FTIL, all of whom have overwhelmingly voted against
amalgamation. In fact, it is pointed out that there is no question of “public interest” and Section 396
is actually used in order to penalise “Ram”, namely, NSEL and FTIL, for the default of “Shyam”,
namely, the 24 alleged defaulters, when not even a single default or any civil or criminal wrong can
be attributed either to FTIL or to NSEL. The impugned order would therefore also fail on the ground
of proportionality, which is a facet of Article 14. For all these reasons, in addition, the impugned
order ought to be struck down as ultra vires Article 31A of the Constitution of India and Section 396
of the Companies Act, and be declared to be violative of Article 14, Article 19 and Article 300A of the
Constitution of India.
15. Shri Shyam Divan, learned Senior Advocate appearing on behalf of Respondent No. 4, NSEL
Investors Action Group, supported the impugned judgment in its entirety. According to the learned
Senior Advocate, it must never be forgotten that FTIL held 99.9998% of NSEL’s shares, and that
NSEL was promoted by and is part of the FTIL group. The Board of Directors of NSEL is entirely
under the control of FTIL. NSEL’s exchange was treated, held out, and represented by FTIL to be its
own, and was part of its “exchange verticals”. Shri Jignesh Shah is the common linchpin of both the
companies. He holds 45% shares of FTIL and is its Chairman-cum- Managing Director. He is also
Vice Chairman on the Board of NSEL, being one of the “key managerial personnel” of the aforesaid
company. He also was a member of the Audit Committee of NSEL. All the minutes of the Board
meetings of NSEL were regularly tabled at the Board meetings of FTIL, showing therefore, that FTIL
has full knowledge of the goings-on in NSEL. NSEL’s outward emails were routed through an
outbox called “FT outbox” through which all emails of all FTIL-group companies were routed. What
is clear, therefore, is that on a reading of the Grant Thornton report, NSEL has, at least from 2009,
promoted what are called “paired contracts” in commodities which were, in fact, financing
transactions, which were totally distinct from sale and purchase transactions in commodities. In
fact, by April to July, 2013, 99% of the turnover of NSEL was made up of such paired contracts. This
mechanism was in breach of the conditions of exemption granted to NSEL dated 05.06.2007, and in
breach of the provisions of the FCRA. Contrary to what was actually going on in NSEL, NSEL kept
inducing persons to come to its platform by reiterating that they deal only with commodities and
spot delivery of the same. It is only in 2012 that the FMC, being apprised of the real activities of
NSEL, wrote to the DCA, indicating that its business was in complete breach of the FCRA. What is
extremely important is that Shri Jignesh Shah made representations to the DCA and the FMC on63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

10.07.2013, in which he stated that NSEL had full stock of commodities as collateral and had
10-20% of open position as margin money. He also stated that the stock currently held in NSEL’s
120 warehouses was valued at around INR 6000 crore. It is in July, 2013 that the payment crisis of
INR 5600 crore arose on NSEL, FTIL admitting that this was the result of a fraud. On 14.08.2013,
NSEL wrote to the FMC, setting out a detailed settlement plan. The plan indicated the period within
which the entire dues would be paid, with simple interest at 8% to 16% per annum. This plan was an
abject failure. As a result, a forensic audit was conducted by Grant Thornton, which in its report
dated 21.09.2013, came out with damning facts and figures as to the real operations of NSEL,
namely, that they are not a commodity exchange, but a finance exchange, and that no commodities
were really in stock. As a result, the FMC issued show cause notices and then passed its order dated
17.12.2013 based on the aforesaid report, in which it found NSEL guilty of severe malpractice. Based
on this order, the draft order and final order of amalgamation were then made. Shri Divan was at
pains to point out that as early as on 18.08.2014, the FMC had written a detailed letter to the
Secretary, Ministry of Corporate Affairs, in which it indicated that as NSEL was financially incapable
of repaying all those investors/traders who allegedly got duped, it would be expedient in public
interest to amalgamate NSEL with its parent, FTIL, so that its parent’s resources could be used to
repay these debts. He then argued that the reason for the amalgamation order was not merely the
repayment of debts of the allegedly duped investors/traders, but to instil confidence in commodity
markets, for it is only when their debts are immediately paid would persons come forward to
platforms like NSEL to trade in commodities. According to the learned Senior Advocate, there was
no breach of natural justice in passing the final amalgamation order as FTIL and NSEL were both
heard pursuant to a Bombay High Court order, even though Section 396 of the Companies Act does
not require any hearing. He also argued that the order of amalgamation is of the nature of delegated
legislation and is not an administrative order, as a result of which, the immunity granted by Article
31A to “all laws” dealing with such amalgamation from challenge on the ground of Articles 14 and 19
would come into full play. This being so, none of the grounds taken up by the appellants could be
gone into as they all pertained to infractions of Articles 14 and 19 of the Constitution of India.
According to the learned Senior Advocate, the order was passed after being satisfied on the objective
facts set out hereinabove that it was essential in public interest to pass such order and could not,
therefore, be held to be ultra vires. He also supported the judgment of the High Court when it stated
that the economic value of shares of FTIL is not the subject matter of Section 396, and that,
therefore, it was not necessary to provide FTIL’s shareholders any compensation under Section
396(3).
16. Shri Rakesh Dwivedi, learned Senior Advocate also appearing on behalf of Respondent No.4,
supplemented the submissions of Shri Divan. According to him, nowhere does the Central
Government order direct any payment to be made by the amalgamated company. The amalgamation
is only so that the finances of FTIL can be used to pursue on-going litigation as NSEL does not have
the wherewithal to do so. Thus, it is wholly incorrect for the appellants to say that FTIL will become
mulcted with the liabilities of NSEL, as a result of which the shareholders of FTIL will suffer. He
added that the overwhelming majority of shares in FTIL are owned by Shri Jignesh Shah and his
family (45%) and by Shri Ravi Sheth and Shri Bharat Sheth (8%). Thus, the majority shares held in
FTIL are by two masterminds of the scam. That apart, after the scam, 24% of the shares have been
purchased by speculators, taking advantage of the low price at which such shares were offered. Such63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

persons, therefore, are purely speculative investors who do not need to be compensated under
Section 396 of the Act. Also, the economic value of shares, if at all it is to be taken into account, is an
uncertain and fluctuating phenomenon. As examples, he stated that the book value of a share of
FTIL, after the scam broke out, was only INR 2/-, whereas the listed value actually went up after the
FMC order of 17.12.2013. All this, therefore, is dependent on market forces, and share price varies
according to market forces and not as a result of any amalgamation that is effected. He also added
that it is incorrect to state that one of the conditions precedent for applicability of Section 396 was
absent. Even if a compensation order was made awarding nil compensation to shareholders and
creditors of FTIL, they could have appealed against the same. Not having done so, it cannot be said
that the Central Government order was passed without adhering to the provisions of Section 396(3)
and (4) of the Act. When it came to the three grounds of public interest stated by the High Court, the
learned Senior Advocate argued that grounds (a) and (b) are only inferences to be drawn from facts
which are all stated in the order, and therefore, need not have been in the draft order. There is thus
no infirmity or breach of principles of natural justice as provided in Section 396(3) and (4). He was
at pains to analyse Article 31A, and stated that the expression “public interest” contained in Article
31A will have to be construed broadly. Equally, the word “essential” in Section 396 is essentiality
according to the Central Government, and thus, very wide latitude needs to be extended to the
Government when it exercises its discretion, stating that it is essential in public interest to
amalgamate two companies. He laid great emphasis on the judgment in Ganesh Bank of Kurundwad
Ltd. v. Union of India, (2006) 10 SCC 645 [“Ganesh Bank”], stressing that amalgamations that are
made under Section 45 of the Banking Regulation Act, like amalgamations made under Section 396,
can be made so that a weak entity merge with a strong entity in the interest of the depositors of the
weak entity. He also cited various judgments to show that stock exchanges are intimately linked with
the economy of the country, and therefore, if anything goes wrong with them, there is a direct link
with public interest. He emphasized the fact that in Section 396(3), the shareholders of FTIL only
need to be compensated “as nearly as may be” and that mathematical precision is not necessary. He
then distinguished the judgment in Mohinder Singh Gill v. Chief Election Commissioner, (1978) 1
SCC 405 [“Mohinder Singh Gill”], cited by the appellants, stating that where larger public interest is
involved, the ratio of that judgment will not apply. He cited two judgments in support of this
proposition. He also went on to cite certain judgments which distinguished K.I. Shephard v. Union
of India, (1987) 4 SCC 431 [“K.I. Shephard”], and therefore, argued that the Central Government
order passed under Section 396 is really in the nature of delegated legislation and need not conform
to any natural justice outside what is provided for in the Section itself. He then cited certain
judgments on lifting of the corporate veil, and ended by saying that as was held in J.K. (Bombay) (P)
Ltd. v. New Kaiser-i-Hind Spinning and Weaving Co. Ltd., [1969] 2 SCR 866 [“J.K. (Bombay) (P)
Ltd.”], the Central Government order would have statutory force, and therefore, cannot be said to be
a mere administrative order.
17. Shri Arvind Datar, learned Senior Advocate appearing on behalf of SEBI, fully supported the
impugned judgment and took us through various portions of it. He was at pains to point out that the
Grant Thornton report was a report of a forensic auditor chosen by NSEL itself, though required to
do so by the FMC. He took us through the FMC order dated 17.12.2013 meticulously, and said that
none of the findings therein could be assailed by either FTIL or NSEL. He then referred to the
Central Government order and supported the High Court judgment’s upholding of it. He then relied63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

upon the Director’s Report of NSEL dated 20.07.2015, and balance sheet as on 31.03.2015 to show
that no potential liability of INR 5600 crore is at all referred to in the Director’s Report or in the
balance sheet. He was at pains to point out, therefore, that NSEL itself was an exchange which made
it clear that it would not be responsible for any liabilities incurred by its members except to the
extent of the SG fund created out of the members’ contribution. He then argued that given the
magnitude of the scam that broke out in July 2013, the Government had to act. It could have chosen
one of many ways in which to act, but since it had bona fide chosen the amalgamation route
provided by Section 396 of the Companies Act, it is obvious that in dealing with a scam of this
magnitude, the Government has acted in public interest.
18. Ms. Pinky Anand, learned Additional Solicitor General appearing on behalf of the Union of
India, meticulously took us through a long list of dates and events which showed that NSEL had
flouted the conditions of its exemption order and had never really carried out ready delivery or spot
delivery contracts in goods. Indeed, according to her, NSEL never had a single registered warehouse
in its name as the Warehousing Development and Regulatory Authority had rejected NSEL’s
application for registration of its warehouses as far back as on 16.05.2011. Therefore, NSEL stating
that it had 120 warehouses owned by itself was a misrepresentation made to the public from the
very beginning. It is also clear, that when the scam broke out, Grant Thornton, as forensic auditor,
went into the affairs of NSEL and came out with a number of key findings, which she referred to and
took us through portions of the Grant Thornton report. The FMC order dated 17.12.2013 was also
referred to and relied upon by her. She also referred to the fact that the exemption order dated
05.06.2007 granted to NSEL was withdrawn on 19.09.2014 as commodities markets which were
supposed to be markets where spot delivery of goods took place, had never in fact taken place and
therefore, exemption granted to all spot exchanges dealing in commodities, including two other spot
exchanges that existed, were withdrawn. However, the Bombay Stock Exchange Ltd. (BSE), the
National Stock Exchange of India Ltd. (NSE), and MCX continued with commodity trading, but not
on a spot basis. She also referred us to a subsequent event, that is an event subsequent even to the
impugned judgment, namely, to a serious fraud investigation report dated 31.08.2018 which,
according to her, corroborated all the findings made by Grant Thornton, the FMC, and the Central
Government by its final order. She then argued that Section 396 of the Companies Act is a special,
self-contained, standalone code by itself and must be read as such, and that all procedural aspects of
Section 396 have been complied with on the facts of the present case. The satisfaction of the Central
Government that it is essential in public interest to act under Section 396 is purely subjective
satisfaction. She referred to and relied upon Bacha F. Guzdar v. Commissioner of Income Tax,
[1955] 1 SCR 876 [“Bacha F. Guzdar”], to support the reasoning of the High Court on the
compensation order. She also referred to and relied upon the share market prices to show that
market fluctuations took place on their own, and that share prices plummeted only as a result of the
scam which came to light in July, 2013. She also stated that since neither FTIL nor its shareholders
and creditors filed any appeal against the compensation order, they waived their right to do so. She
then supported the final amalgamation order and stated that it was manifest that it was made in
“public interest”. For this, she relied upon a number of judgments to support her contention that
“public interest” has to be given a broad connotation. She also countered the submission of Shri
Rohatgi that of the two persons who heard the objections, only one person signed, and therefore,
their report would be non-est. She stated that this technical objection cannot stand in the way of the63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

final government order which took into account all objections and suggestions made, and answered
all of them. She also referred to the role of stock markets in the national economy and stated that to
prop up stock and commodities exchanges is certainly in public interest. The three distinct grounds
on public interest, found by the High Court, are more than sufficient to sustain the impugned
Central Government order. Finally, in her last written argument, she relied upon two judgments of
this Court, namely, Union of India v. G. Ganayutham, (1997) 7 SCC 463 and Om Kumar v. Union of
India, (2001) 2 SCC 386, stating the current position of the doctrine of proportionality in
administrative law.
19. Shri Tushar Mehta, learned Solicitor General for India, who also appeared on behalf of the Union
of India, re-emphasised the facts which led to the final amalgamation order. According to him, the
impugned order dated 12.02.2016 is based on public interest as it reflects the Government’s reaction
to a large scam which broke in the year 2013, and which effected the commodities market generally.
He dwelt at some length on subjective satisfaction and judicial review, and referred to Barium
Chemicals Ltd. v. Company Law Board, [1966] Supp SCR 311 [“Barium Chemicals”], Rohtas
Industries Ltd. v. S.D. Agarwal, [1969] 3 SCR 108 [“Rohtas Industries”], and other judgments to
emphasise that it was not for the Court to sit in judgment over the sufficiency of the reasons for
which the Central Government passed its order in public interest. He also stated that the right to
choose between different courses of action is a right inherent in a responsive government, and it is
only when such choice is so unfair or unreasonable that no reasonable person would have taken
such action, that the Court can intervene. For this purpose, he cited Haryana Financial Corporation
v. Jagdamba Oil Mills, (2002) 3 SCC 496. According to him, essentiality is not reviewable except by
the Wednesbury test, and the Court should ask itself the question as to whether no reasonable
person could have concluded that the impugned order was essential in the public interest. He
reiterated that the order dated 12.02.2016 is not ultra vires Section 396 as several findings which
show that amalgamation is essential in public interest has been arrived at on the basis of undisputed
facts, and that therefore, the said order should be upheld. He also argued that such order, if passed,
is in the nature of delegated legislation, and therefore, does not have to satisfy any rules of natural
justice outside what is prescribed by Section 396 itself which, according to him, has been
procedurally and substantively complied with, as reflected in the order dated 12.02.2016.
20. Shri Neeraj Kishan Kaul, learned Senior Advocate, also appearing on behalf of some of the
alleged duped investors/traders, referred to the Maharashtra Protection of Interest of Depositors (in
Financial Establishments) Act, 1999, and stated that the persons who had invested monies in the
commodities exchange of NSEL have been held to be “depositors” by a judgment dated 01.10.2015 of
the High Court of Bombay, from which an SLP has been dismissed by this Court. He also brought to
our notice another judgment dated 01.11.2018, also of the Bombay High Court, in which NSEL and
FTIL had breached an injunction order, and had to apologise and pay back monies in order to avoid
being held guilty of contempt of court. He also stressed that “economic value” of shares is a stranger
to Section 396(3) of the Companies Act. He then relied upon two reports of the RBI, both of which
say that the modern trend in corporate law worldwide is that if losses are borne by a corporation, it
is the shareholders who should bear the brunt.63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

21. Having heard learned counsel for all the parties, it is necessary at this juncture to first set out
Article 31A of the Constitution of India, which states:
“31A. Saving of laws providing for acquisition of estates, etc.—(1) Notwithstanding
anything contained in Article 13, no law providing for— xxx xxx xxx
(c) the amalgamation of two or more corporations either in the public interest or in
order to secure the proper management of any of the corporations, or xxx xxx xxx
shall be deemed to be void on the ground that it is inconsistent with, or takes away or
abridges any of the rights conferred by article 14 or article 19.
xxx xxx xxx” “Law” has been defined in Article 13(3) as follows:
“13. Laws inconsistent with or in derogation of the fundamental rights.— xxx xxx xxx
(3) In this article, unless the context otherwise requires, —
(a) “law” includes any Ordinance, order, bye-
law, rule, regulation, notification, custom or usage having in the territory of India the force of law;
xxx xxx xxx” It will thus be seen that any “law” providing for the amalgamation of two or more
corporations in public interest is immune from challenge on grounds relatable to Article 14 or
Article 19 of the Constitution of India. It is not disputed that Section 396 of the Companies Act is
such a law.
22. Section 396 of the Companies Act, 1956, reads as under:
“396. Power of Central Government to provide for amalgamation of companies in
public interest.—(1) Where the Central Government is satisfied that it is essential in
the public interest that two or more companies should amalgamate, then,
notwithstanding anything contained in Sections 394 and 395 but subject to the
provisions of this section, the Central Government may, by order notified in the
Official Gazette, provide for the amalgamation of those companies into a single
company with such constitution; with such property, powers, rights, interests,
authorities and privileges; and with such liabilities, duties, and obligations; as may be
specified in the order.
(2) The order aforesaid may provide for the continuation by or against the transferee
company of any legal proceedings pending by or against any transferor company and
may also contain such consequential, incidental and supplemental provisions as may,
in the opinion of the Central Government, be necessary to give effect to the
amalgamation.63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

(3) Every member or creditor (including a debenture holder) of each of the
companies before the amalgamation shall have, as nearly as may be, the same
interest in or rights against the company resulting from the amalgamation as he had
in the company of which he was originally a member or creditor; and to the extent to
which the interest or rights of such member or creditor in or against the company
resulting from the amalgamation are less than his interest in or rights against the
original company, he shall be entitled to compensation which shall be assessed by
such authority as may be prescribed and every such assessment shall be published in
the Official Gazette.
The compensation so assessed shall be paid to the member or creditor concerned by the company
resulting from the amalgamation.
(3A) Any person aggrieved by any assessment of compensation made by the prescribed authority
under sub-section (3) may, within thirty days from the date of publication of such assessment in the
Official Gazette, prefer an appeal to the Tribunal and thereupon the assessment of the compensation
shall be made by the Tribunal.
(4) No order shall be made under this section, unless:
(a) a copy of the proposed order has been sent in draft to each of the companies
concerned; (aa) the time for preferring an appeal under sub-section (3A) has expired,
or where any such appeal has been preferred, the appeal has been finally disposed of;
and
(b) the Central Government has considered, and made such modifications, if any, in
the draft order as may seem to it desirable in the light of any suggestions and
objections which may be received by it from any such company within such period as
the Central Government may fix in that behalf, not being less than two months from
the date on which the copy aforesaid is received by that company, or from any class of
shareholders therein, or from any creditors or any class of creditors thereof.
(5) Copies of every order made under this section shall, as soon as may be after it has
been made, be laid before both Houses of Parliament.” It will be seen that Section
396 provides for compulsory amalgamation of companies in public interest. The said
Section occurs in Chapter V of the Companies Act which reads, “arbitrations,
compromises, arrangements and reconstructions”. Sections 391 to 394 deal with
voluntary compromises and arrangements, including amalgamation of two or more
companies. By way of contrast, Section 396 deals with compulsory amalgamation of
companies.
INTERPRETATION OF SECTION 39663 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

23. There is no doubt whatsoever that Section 396 cannot be challenged on the ground of Article 14
or Article 19, given Article 31A of the Constitution of India. However, this does not mean that
Section 396 must be construed in such a fashion that it would lead to arbitrary or unreasonable
results. In Prem Nath Raina v. State of Jammu & Kashmir and Ors., (1983) 4 SCC 616, this Court, in
dealing with a challenge to the J&K Agrarian Reforms Act, 1976, which was protected by Article 31A,
held:
“9. ……The exclusion of a constitutional challenge under Articles 14, 19 and 31 which
is provided for by Article 31A does not justify in equity the irrational violation of
these articles. This Court did observe in Waman Rao [Waman Rao v. Union of India,
(1981) 2 SCC 362 :
AIR 1981 SC 271 : (1981) 2 SCR 1] that: “It may happen that while existing
inequalities are being removed, new inequalities may arise marginally and
incidentally” but the legislature has to take care to see that even marginal and
incidental inequalities are not created without rhyme or reason. The Government of
J&K would do well to give fresh consideration to the provisions contained in Section
7(2) and modify the provisions regarding residence in order that they may accord
with reason and commonsense. Article 31A does not frown upon reason and
commonsense.” Equally, in Budhan Singh and Anr. v. Nabi Bux and Anr., [1970] 2
SCR 10, this Court, while construing Section 90 of the U.P. Zamindari Abolition and
Land Reforms Act, 1950, held:
“Before considering the meaning of the word “held” in Section 9, it is necessary to
mention that it is proper to assume that the law-makers who are the representatives
of the people enact laws which the society considers as honest, fair and equitable. The
object of every legislation is to advance public welfare. In other words as observed by
Crawford in his book on Statutory Constructions that the entire legislative process is
influenced by considerations of justice and reason. Justice and reason constitute the
great general legislative intent in every piece of legislation. Consequently where the
suggested construction operates harshly, ridiculously or in any other manner
contrary to prevailing conceptions of justice and reason, in most instances, it would
seem that the apparent or suggested meaning of the statute, was not the one intended
by the law-makers. In the absence of some other indication that the harsh or
ridiculous effect was actually intended by the legislature, there is little reason to
believe that it represents the legislative intent.” (at pp. 15-16) DERIVATIVE
IMMUNITY OF THE CENTRAL GOVERNMENT ORDER
24. The next question is whether the Central Government’s order made under Section
396 would also receive the protective umbrella of Article 31A, given the fact that
Section 396 is undoubtedly protected by Article 31A.
25. A similar question was raised and considered with respect to an order passed
under the Essential Commodities Act, 1955. In Prag Ice & Oil Mills v. Union of India,63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

(1978) 3 SCC 459 [“Prag Ice & Oil Mills”], by a majority judgment, it was held that the
Mustard Oil (Price Control) Order, 1977, passed under Section 3 of the Essential
Commodities Act, 1955 did not receive the immunity of Article 31B.
This Court held:
“46. Article 31A of the Constitution saves laws which provide for matters mentioned
in clauses (a) to (e) thereof from a challenge under Articles 14, 19 or 31
notwithstanding anything contained in Article 13 of the Constitution. Article 31B
which was introduced by the Constitution (First Amendment) Act, 1951, validates
certain Acts and Regulations by providing that without prejudice to the generality of
the provisions contained in Article 31A, “none of the Acts and Regulations specified
in the Ninth Schedule nor any of the provisions thereof” shall be deemed to be void,
or ever to have become void, on the ground that such Act, Regulation or provision is
inconsistent with, or takes away or abridges any of the rights conferred by, any
provisions of Part III. On a plain reading of this article it seems to us impossible to
accept that the protective umbrella of the Ninth Schedule takes in its everwidening
wings not only the Acts and Regulations specified therein but also Orders and
Notifications issued under those Acts and Regulations. Article 31B constitutes a grave
encroachment on fundamental rights and doubtless as it may seem that it is inspired
by a radiant social philosophy, it must be construed as strictly as one may, for the
simple reason that the guarantee of fundamental rights cannot be permitted to be
diluted by implications and inferences. An express provision of the Constitution
which prescribes the extent to which a challenge to the constitutionality of a law is
excluded, must be construed as demarcating the farthest limit of exclusion.
Considering the nature of the subject-matter which Article 31B deals with, there is, in
our opinion, no justification for contending by judicial interpretation the provisions
of the field which is declared by that article to be immune from challenge on the
ground of violation or abridgement of fundamental rights. The article affords
protection to Acts and Regulations specified in the Ninth Schedule. Therefore,
whenever a challenge to the constitutionality of a provision of law on the ground that
it violates any of the fundamental rights conferred by Part III is sought to be repelled
by the State on the plea that the law is placed in the Ninth Schedule, the narrow
question to which one must address oneself is whether the impugned law is specified
in that Schedule. If it is, the provisions of Article 31B would be attracted and the
challenge would fail without any further inquiry. On the other hand, if the law is not
specified in the Ninth Schedule, the validity of the challenge has to be examined in
order to determine whether the provisions thereof invade in any manner any of the
fundamental rights conferred by Part III. It is thus no answer to say that though the
particular law, as for example a Control Order, is not specified in the Ninth Schedule,
the parent Act under which the Order is issued is specified in that Schedule.”
26. In the present case, this judgment has no direct application except to say that
Article 31A also constitutes a grave encroachment on fundamental rights, and must63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

be construed strictly. The expression used in Article 31A is “law”, for which, one is to
see the definition contained in Article 13(3). “Law” in Article 13(3) certainly includes
“order”. The only question is whether this would include an administrative order as
well.
27. It is clear, on a reading of Article 13(3), that the expression “law”, as defined in
Article 13(3)(a), includes an Ordinance, rule, regulation, notification, and custom or
usage having in the territory of India the force of law. Obviously, therefore, when the
expression “order” is used, it would take colour from Ordinance, rule, regulation,
notification, which are all legislative in nature, and not administrative. Even custom
or usage having the force of law refers to general rules of conduct, as opposed to
administrative orders passed on the facts of a given case.
Construing Article 31A in the light of Article 13(3)(a), it is clear that the “order” referred to, can
therefore, only be a legislative order. Examples of legislative orders are of the kind dealt with in Prag
Ice & Oil Mills (supra) and Union of India and Anr. v. Cynamide India Ltd. and Anr., (1987) 2 SCC
720 [“Cynamide India”], namely, orders passed under statutes which are in the nature of
subordinate legislation, which deal generally with a whole class of persons who are governed by the
same in which general rules of conduct are laid down. WHETHER THE CENTRAL GOVERNMENT
ORDER IS ADMINISTRATIVE IN NATURE
28. This brings us to what is the nature of the order of the Central Government that is passed under
Section 396. It has been argued on behalf of the Union of India, relying upon a number of
judgments, that the nature of the order passed under Section 396 is that of delegated legislation.
This being the case, it would, therefore, get immunity from challenge on the ground of Articles 14
and 19 of the Constitution of India, as it would then amount to a “law” within the meaning of Article
31A read with Article 13(3)(b).
29. The difference between an order which is legislative in nature and that which is administrative in
nature has been discussed in some of our judgments. Thus, in Cynamide India (supra), this Court
drew a distinction between administrative and legislative orders thus:
“7. …… Any attempt to draw a distinct line between legislative and administrative
functions, it has been said, is ‘difficult in theory and impossible in practice’. Though
difficult, it is necessary that the line must sometimes be drawn as different legal
rights and consequences may ensue. The distinction between the two has usually
been expressed as ‘one between the general and the particular’. ‘A legislative act is the
creation and promulgation of a general rule of conduct without reference to
particular cases; an administrative act is the making and issue of a specific direction
or the application of a general rule to a particular case in accordance with the
requirements of policy’. ‘Legislation is the process of formulating a general rule of
conduct without reference to particular cases and usually operating in future;
administration is the process of performing particular acts, of issuing particular
orders or of making decisions which apply general rules to particular cases.’ It has63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

also been said: ‘Rule-making is normally directed toward the formulation of
requirements having a general application to all members of a broadly identifiable
class’ while, ‘an adjudication, on the other hand, applies to specific individuals or
situations’. But, this is only a broad distinction, not necessarily always true.
Administration and administrative adjudication may also be of general application
and there may be legislation of particular application only. That is not ruled out.
Again, adjudication determines past and present facts and declares rights and
liabilities while legislation indicates the future course of action. Adjudication is
determinative of the past and the present while legislation is indicative of the
future.……” In K.I. Shephard (supra), this Court dealt with a scheme for
amalgamation of three private banks with Punjab National Bank, Canara Bank, and
State Bank of India, in terms of separate schemes drawn, merging each private bank
with state banks under Section 45 of the Banking Regulation Act. It was urged that
the order passed by the Reserve Bank of India amalgamating these banks was
legislative in nature, as a result of which the principle of natural justice will not apply.
In turning down this contention, this Court held:
“9. …… Learned counsel for RBI and the transferee banks have taken the stand that
the scheme-making process under Section 45 is legislative in character and,
therefore, outside the purview of the ambit of natural justice under the protective
umbrella whereof the need to put the excluded employees to notice or enquiry arose.
It is well settled that natural justice will not be employed in the exercise of legislative
power and Mr Salve has rightly relied upon a recent decision of this Court being
Union of India v. Cynamide India Ltd. [(1987) 2 SCC 720] in support of such a
position. But is the scheme-making process legislative? Power has been conferred on
the RBI in certain situations to take steps for applying to the Central Government for
an order of moratorium and during the period of moratorium to propose either
reconstruction or amalgamation of the banking company. A scheme for the purposes
contemplated has to be framed by RBI and placed before the Central Government for
sanction. Power has been vested in the Central Government in terms of what is
ordinarily known as a Henry VIII clause for making orders for removal of difficulties.
Section 45(11) requires that copies of the schemes as also such orders made by the
Central Government are to be placed before both Houses of Parliament. We do not
think this requirement makes the exercise in regard to schemes a legislative process.
It is not necessary to go to any other authority as the very decision relied upon by Mr
Salve in the case of Cynamide India Ltd. [(1987) 2 SCC 720] lays down the test. In
para 7 of the judgment it has been indicated: (SCC pp. 735-36) “Any attempt to draw
a distinct line between legislative and administrative functions, it has been said, is
‘difficult in theory and impossible in practice’. Though difficult, it is necessary that
the line must sometimes be drawn as different legal rights and consequences may
ensue. The distinction between the two has usually been expressed as ‘one between
the general and the particular’. ‘A legislative act is the creation and promulgation of a
general rule of conduct without reference to particular cases; an administrative act is
the making and issue of a specific direction or the application of a general rule to a63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

particular case in accordance with the requirements of policy’. ‘Legislation is the
process of formulating a general rule of conduct without reference to particular cases
and usually operating in future; administration is the process of performing
particular acts, of issuing particular orders or of making decisions which apply
general rules to particular cases.’ It has also been said: ‘Rule-making is normally
directed towards the formulation of requirements having a general application to all
members of a broadly identifiable class’ while, ‘an adjudication, on the other hand,
applies to specific individuals or situations’. But, this is only a broad distinction, not
necessarily always true.” Applying these tests it is difficult to accept Mr Salve’s
contention that the framing of the scheme under Section 45 involves a legislative
process. There are similar statutory provisions which require placing of material
before the two Houses of Parliament yet not involving any legislative activity. The fact
that orders made by the Central Government for removing difficulties as
contemplated under sub-clause (10) are also to be placed before the two Houses of
Parliament makes it abundantly clear that the placing of the scheme before the two
Houses is not a relevant test for making the scheme-framing process legislative. We
accordingly hold that there is no force in the contention of Mr Salve that the process
being legislative, rules of natural justice were not applicable.” The fact that, under
Section 396(5), the Central Government order has to be laid before the Houses of
Parliament also does not detract from the fact that this order is administrative and
not legislative in character.
Applying these judgments to the Central Government’s order passed under Section 396, it is clear
that the order directly impacts the rights and liabilities of the companies, their shareholders and
creditors, sought to be amalgamated under the order. Such order is not an order in general which
applies to all such companies, but only to the particular companies sought to be amalgamated.
There is no general rule of conduct, without reference to the particular case that is laid down by such
an order. The Central Government order, ultimately, makes a specific direction qua two specific
companies which are to be amalgamated. It is clear that such an order is not in the nature of
legislation or delegated legislation.
30. Learned counsel appearing on behalf of the respondents have cited New Bank of India
Employees’ Union and Anr. v. Union of India and Ors., (1996) 8 SCC 407 [“New Bank of India
Employees’ Union”], which is a judgment which has distinguished K.I. Shephard (supra). This
judgment was concerned with Section 9 of the Banking Companies (Acquisition and Transfer of
Undertakings) Act, 1980 [“Acquisition Act”], which requires schemes that have been framed under
the said Act to be laid before each House of Parliament for a total period of thirty days, in which,
Parliament is then given the power to make any modification therein. Given the difference in
language between the provisions, namely, Section 45 of the Banking Regulation Act and Section 9 of
the Acquisition Act, this Court distinguished the judgment of K.I. Shephard (supra) thus:
“32. The only other question which remains for consideration is whether the
conclusion of the High Court that the scheme-making process under Section 9 of the
Acquisition Act is not legislative is correct in law. In view of our conclusions on the63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

four questions formulated, this question is not of much relevance but since the High
Court has recorded a conclusion and the learned Additional Solicitor General and
Shri Salve advanced the argument we think it appropriate to answer this question
also. The High Court relied upon the decision in Shephard case [(1987) 4 SCC 431 :
1987 SCC (L&S) 438 : (1988) 1 SCR 188] and came to hold that the provisions of
Section 45 of the Banking Regulation Act being in pari materia with Section 9 of the
Banking Companies (Acquisition and Transfer of Undertakings) Act, 1980, and the
scheme framed under Section 45 of the Banking Regulation Act, 1949 having been
held by this Court to be not legislative, the scheme framed under the Acquisition Act
as in the present case, must also be held to be not a legislative one. It is undisputed
that in Shephard case [(1987) 4 SCC 431 :
1987 SCC (L&S) 438 : (1988) 1 SCR 188] the amalgamation was of a private bank
with a nationalised bank and the provisions of the Banking Regulation Act, 1949
applied. This Court in Shephard case [(1987) 4 SCC 431 : 1987 SCC (L&S) 438 :
(1988) 1 SCR 188] on examining Section 45(11) of the Banking Regulation Act, 1949
came to hold that merely because a scheme framed is required to be laid before both
the Houses of Parliament after the same has been sanctioned by the Central
Government the scheme cannot be held to be legislative in nature. But in our
considered opinion the High Court has failed to notice the fundamental distinction
between the provisions of Section 45 of the Banking Regulation Act, 1949 and Section
9 of the Acquisition Act. Under Section 9 of the Acquisition Act under which Act the
impugned scheme has been framed, every scheme framed by the Central Government
has to be laid before each House of Parliament for a total period of 30 days and
Parliament has the power to agree to the scheme and making any modification or in
giving to a decision that the scheme should not be made and it is only thereafter the
scheme has the effect either in the modified form or does not agree (sic). The
essential distinction between the two provisions therefore, is that whereas under the
Banking Regulation Act, 1949 the scheme framed has merely to be placed before
Parliament and nothing further but under the Acquisition Act the scheme becomes
effective only after the same is placed before both the Houses of Parliament and after
Parliament makes such modification and agrees to the scheme. In this view of the
matter the decision of this Court in Shephard case [(1987) 4 SCC 431 : 1987 SCC
(L&S) 438 : (1988) 1 SCR 188] has no application to a scheme framed under the
provisions of the Acquisition Act and in our considered opinion, a scheme framed
under Section 9 of the Banking Companies Acquisition and Transfer of Undertakings
Act, 1980, is a legislative one. The High Court was in error in holding the scheme not
to be a legislative one.” Since Section 396(5) of the Companies Act is a provision akin
to the provision considered in the case of K.I. Shephard (supra), the ratio of K.I.
Shephard (supra) squarely applies. The judgment in New Bank of India Employees’
Union (supra), therefore, is of no assistance, given the statutory provision in the
present case.63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

31. Learned Senior Advocates on behalf of the respondents then cited the judgment in Quarry
Owners’ Association v. State of Bihar and Ors., (2000) 8 SCC 655. This judgment, in paragraphs 45
and 55, held that even a simple laying of an order before Parliament is a mandatory condition to be
observed, and ordered that the particular order in that case be laid before the legislature as it had
not so been laid earlier. This judgment again has nothing to do with whether, on account of laying
before the legislature, an order is administrative or legislative in nature. This judgment also,
therefore, does not carry us very much further.
32. Learned Senior Advocates on behalf of the respondents then cited a passage from J.K. (Bombay)
(P) Ltd. (supra), and paragraph 23 in particular, in which this Court observed that an order made
under Section 391 of the Companies Act has statutory force. The fact that a similar order made
under Section 396 may also have statutory force again does not answer the precise question before
us, namely, as to whether such orders having statutory force are administrative or legislative in
nature. This observation again does not carry the matter very much further.
33. The order passed under Section 396 is qua particular companies and does not lay down any
general rule of conduct by itself, but in fact, follows the general rule of conduct laid down by Section
396. Thus, the Central Government order, made under Section 396, must conform to the
fundamental rights guaranteed by Articles 14 and 19(1)(g) of the Constitution of India. This Court
has held in a catena of decisions that it is the substance of what is effected that counts when it comes
to infraction of a fundamental right, and not the form. Thus, in Thomas Dana v. State of Punjab,
[1959] Supp (1) SCR 274, Subba Rao, J., in his dissenting opinion, stated:
“A fundamental right is transcendental in nature and it controls both the legislative
and the executive acts. Article 13 explicitly prohibits the State from making any law
which takes away or abridges any fundamental right and declares the law to the
extent of the contravention as void. The law therefore must be carefully scrutinized to
ascertain whether a fundamental right is infringed. It is not the form but the
substance that matters. If the legislature in effect constitutes a judicial tribunal, but
calls it an authority, the tribunal does not become any the less a judicial tribunal.
Therefore, the correct approach is first to ascertain with exactitude the content and
scope of the fundamental right and then to scrutinize the provisions of the Act to
decide whether in effect and substance, though not in form, the said right is violated
or curtailed. Otherwise the fundamental right will be lost or unduly restricted in our
adherence to the form to the exclusion of the content.” (at p. 303) Likewise, in
Hamdard Dawakhana (Wakf) Lal Kuan, Delhi and Anr.
v. Union of India and Ors., [1960] 2 SCR 671, it was held as under:
“In the present case therefore (1) the advertisements affected by the Act do not fall
within the words freedom of speech within Article 19(1)(a); (2) the scope and object
of the Act, its true nature and character is not interference with the right of freedom
of speech but it deals with trade or business; and (3) there is no direct abridgement of
the right of free speech and a mere incidental interference with such right would not63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

alter the character of the law; Ram Singh v. State of Delhi [(1951) SCR 451-455];
Express Newspapers (Private) Ltd. v. Union of India [(1959) SCR 12, 123-133] It is
not the form or incidental infringement that determines the constitutionality of a
statute in reference to the rights guaranteed in Art. 19(1), but the reality and
substance. The Act read as a whole does not merely prohibit advertisements relating
to drugs and medicines connected with diseases expressly mentioned in s. 3 of the
Act but they cover all advertisements which are objectionable or unethical and are
used to promote self- medication or self-treatment. This is the content of the Act.
Viewed in this way, it does not select any of the elements or attributes of freedom of
speech falling within Art. 19(1)(a) of the Constitution.” (at pp. 690-691) Likewise, in
Sakal Papers (P) Ltd. and Ors. v. Union of India, [1962] 3 SCR 842, this Court held:
“It must be borne in mind that the Constitution must be interpreted in a broad way
and not in a narrow and pedantic sense. Certain rights have been enshrined in our
Constitution as fundamental and, therefore, while considering the nature and content
of those rights the Court must not be too astute to interpret the language of the
Constitution in so literal a sense as to whittle them down. On the other hand the
Court must interpret the Constitution in a manner which would enable the citizen to
enjoy the rights guaranteed by it in the fullest measure subject, of course, to
permissible restrictions. Bearing this principle in mind it would be clear that the right
to freedom of speech and expression carries with it the right to publish and circulate
one’s ideas, opinions and views with complete freedom and by resorting to any
available means of publication, subject again to such restrictions as could be
legitimately imposed under clause (2) of Article 19. ……… In Dwarkadas Shrinivas v.
Sholapur Spinning & Weaving Co. Ltd. [(1954) SCR 674] this Court has pointed out
that in construing the Constitution it is the substance and the practical result of the
act of the State that should be considered rather than its purely legal aspect. The
correct approach in such cases should be to enquire as to what in substance is the loss
or injury caused to the citizen and not merely what manner and method has been
adopted by the State in placing the restriction.” (at pp. 857-858) A Constitution
Bench in Ajay Hasia and Ors. v. Khalid Mujib Sehravardi and Ors., (1981) 1 SCC 722
also stated:
“7. While considering this question it is necessary to bear in mind that an authority
falling within the expression “other authorities” is, by reason of its inclusion within
the definition of ‘State’ in Article 12, subject to the same constitutional limitations as
the government and is equally bound by the basic obligation to obey the
constitutional mandate of the Fundamental Rights enshrined in Part III of the
Constitution. We must therefore give such an interpretation to the expression “other
authorities” as will not stultify the operation and reach of the fundamental rights by
enabling the government to its obligation in relation to the Fundamental Rights by
setting up an authority to act as its instrumentality or agency for carrying out its
functions. Where constitutional fundamentals vital to the maintenance of human
rights are at stake, functional realism and not facial cosmetics must be the diagnostic63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

tool, for constitutional law must seek the substance and not the form. Now it is
obvious that the Government may act through the instrumentality or agency of
natural persons or it may employ the instrumentality or agency of juridical persons to
carry out its functions. In the early days when the Government had limited functions,
it could operate effectively through natural persons constituting its civil service and
they were found adequate to discharge governmental functions which were of
traditional vintage. But as the tasks of the government multiplied with the advent of
the welfare State, it began to be increasingly felt that the framework of civil service
was not sufficient to handle the new tasks which were often specialised and highly
technical in character and which called for flexibility of approach and quick decision
making. The inadequacy of the civil service to deal with these new problems came to
be realised and it became necessary to forge a new instrumentality or administrative
device for handling these new problems. It was in these circumstances and with a
view to supplying this administrative need that the corporation came into being as
the third arm of the government and over the years it has been increasingly utilised
by the government for setting up and running public enterprises and carrying out
other public functions. ……” Also, in M.C. Mehta and Anr. v. Union of India and Ors.
(Shriram – Oleum Gas), (1987) 1 SCC 395, this Court held:
“2. Mr Divan, learned counsel appearing on behalf of Shriram raised a preliminary
objection that the court should not proceed to decide these constitutional issues since
there was no claim for compensation originally made in the writ petition and these
issues could not be said to arise on the writ petition. Mr Divan conceded that the
escape of oleum gas took place subsequent to the filing of the writ petition but his
argument was that the petitioner could have applied for amendment of the writ
petition so as to include a claim for compensation for the victims of oleum gas but no
such application for amendment was made and hence on the writ petition as it stood,
these constitutional issues did not arise for consideration. We do not think this
preliminary objection raised by Mr Divan is sustainable. It is undoubtedly true that
the petitioner could have applied for amendment of the writ petition so as to include
a claim for compensation but merely because he did not do so, the applications for
compensation made by the Delhi Legal Aid and Advice Board and the Delhi Bar
Association cannot be thrown out. These applications for compensation are for
enforcement of the fundamental right to life enshrined in Article 21 of the
Constitution and while dealing with such applications, we cannot adopt a
hyper-technical approach which would defeat the ends of justice. This Court has on
numerous occasions pointed out that where there is a violation of a fundamental or
other legal right of a person or class of persons who by reason of poverty or disability
or socially or economically disadvantaged position cannot approach a court of law for
justice, it would be open to any public spirited individual or social action group to
bring an action for vindication of the fundamental or other legal right of such
individual or class of individuals and this can be done not only by filing a regular writ
petition but also by addressing a letter to the court. If this Court is prepared to accept
a letter complaining of violation of the fundamental right of an individual or a class of63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

individuals who cannot approach the court for justice, there is no reason why these
applications for compensation which have been made for enforcement of the
fundamental right of the persons affected by the oleum gas leak under Article 21
should not be entertained. The court while dealing with an application for
enforcement of a fundamental right must look at the substance and not the form. We
cannot therefore sustain the preliminary objection raised by Mr Divan.”
34. Various pre-requisites contained in the said Section must first be satisfied before the Section can
be said to operate. First and foremost, the Central Government has to be “satisfied”, meaning
thereby, that it must, on certain objective facts, come to a conclusion that amalgamation between
two or more companies is necessary. This can only be done if the Central Government finds it
“essential”, i.e., necessary to do so. Also, this can only be done in “public interest” (the Section
originally contained the expression “national interest”. By Amendment Act 65 of 1960, “national
interest” was substituted by “public interest”).
35. The Notes on Clauses relating to the original Section 396 reads as follows:
“Clause 366—This is a new provision and it is intended to provide, at the instance of
the Government, for the amalgamation of two or more companies in the national
interest. Occasionally, cases arise where such an amalgamation in the national
interest is clearly a necessity. The observance of the usual procedure prescribed by
the existing Act in such cases will lead to prolonged delays which will be detrimental
to the national interest. It has been made clear that any order made by the
Government should provide for the old shareholders, and the old debenture holders
and other creditors, having the same interest in the company resulting from the
amalgamation as they had in the original companies. Any order made by the
Government under this clause will be laid on the table of both Houses of Parliament
and will therefore be subject to the Parliamentary scrutiny.” What is important from
the Notes on Clauses is the fact that it is only “occasionally” that cases arise where an
amalgamation in national interest is “clearly a necessity”. It is made clear that the
reason for Section 396 is that the observance of the usual procedure prescribed by the
existing Act (namely, that contained in Sections 391 to 394) in such cases will lead to
prolonged delays, which will be detrimental to national interest. The fact that the
procedure contained in Sections 394 and 395 need not be carried out is made clear in
the non-obstante clause contained in Section 396(1).
36. Section 396(3), (3A), and (4) are also important. A condition precedent to the passing of an
order by the Central Government under this Section is that every member or creditor of each of the
companies before amalgamation shall have, as nearly as may be, the same interest in or rights
against the company resulting from the amalgamation as he had in the erstwhile company either as
a member or a creditor, and if this is not so, such member or creditor shall be entitled to
compensation which is to be assessed by such authority as may be prescribed. From the order of
such assessment, an appeal is provided by sub-section (3A). What is important is the mandatory
language contained in sub-section (4), which states that no order shall be made under the Section63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

unless the time for preferring an appeal under sub-section (3A) has expired, or where any such
appeal has been preferred, the appeal has been finally disposed of. This makes it clear that unless an
order of compensation is first made under sub- section (3), and an appeal therefrom has either not
been filed or has been disposed of, no order of amalgamation can be made. Another condition
precedent is an inbuilt provision for natural justice, namely, that a proposed draft order has first
been sent to each of the companies concerned. The companies may then send suggestions or
objections to the Central Government, which the Central Government must first consider before
passing the final order. Such objections and suggestions can also be sent from any class of
shareholders of either of the companies, or from any creditors or class of creditors of either of the
companies.
“WHERE THE CENTRAL GOVERNMENT IS SATISFIED”
37. With regard to similar language that is contained in Section 237(b) of the Companies Act, 1956,
this Court, in Barium Chemicals (supra), contained separate opinions as to what the phrase “in the
opinion of” contained in Section 237(b) meant. In Rohtas Industries (supra), this Court adopted the
test laid down by Hidayatullah, J. (as he then was) and Shelat, J. as follows:
“Before taking action under Section 237(b)(i) and (ii), the Central Government has to
form an opinion that there are circumstances suggesting that the business of the
company is being conducted with intent to defraud its creditors, members or any
other persons, or otherwise for a fraudulent or unlawful purpose or in a manner
oppressive to any member or that the company was formed for any fraudulent or
unlawful purpose or that the persons concerned in the formation or the management
of its affairs have in connection therewith been guilty of fraud, misfeasance or other
misconduct towards the company or towards any of its members.
From the facts placed before us, it is clear that the Government had not bestowed
sufficient attention to the material before it before passing the impugned order. It
seems to have been oppressed by the opinion that it had formed about Shri S.P. Jain.
From the arguments advanced by Mr Attorney, it is clear that but for the association
of Mr S.P. Jain with the appellant-company, the investigation in question, in all
probabilities would not have been ordered. Hence, it is clear that in making the
impugned order irrelevant considerations have played an important part.
The power under Sections 235 to 237 has been conferred on the Central Government
on the faith that it will be exercised in a reasonable manner. The department of the
Central Government which deals with companies is presumed to be an expert body in
company law matters. Therefore, the standard that is prescribed under Section
237(b) is not the standard required of an ordinary citizen but that of an expert. The
learned Attorney did not dispute the position that if we come to the conclusion that
no reasonable authority would have passed the impugned order on the material
before it, then the same is liable to be struck down. This position is also clear from
the decision of this Court in Barium Chemicals and Anr. v. Company Law Board and63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

Anr. [(1966) Supp SCR 311].
(at p. 119) xxx xxx xxx The decision of this Court in Barium Chemicals case which
considered the scope of Section 237(b) illustrates that difficulty. In that case
Hidayatullah, J. (our present Chief Justice) and Shelat, J. came to the conclusion that
though the power under Section 237(b) is a discretionary power the first requirement
for its exercise is the honest formation of an opinion that the investigation is
necessary and the further requirement is that “there are circumstances suggesting”
the inference set out in the section; an action not based on circumstances suggesting
an inference of the enumerated kind will not be valid; the formation of the opinion is
subjective but the existence of the circumstances relevant to the inference as the sine
qua non for action must be demonstratable; if their existence is questioned, it has to
be proved at least prime facie; it is not sufficient to assert that those circumstances
exist and give no clue to what they are, because the circumstances must be such as to
lead to conclusions of certain definiteness; the conclusions must relate to an intent to
defraud, a fraudulent or unlawful purpose, fraud or misconduct. In other words they
held that although the formation of opinion by the Central Government is a purely
subjective process and such an opinion cannot be challenged in a court on the ground
of propriety, reasonableness or sufficiency, the authority concerned is nevertheless
required to arrive at such an opinion from circumstances suggesting the conclusion
set out in sub-clauses (i), (ii) and (iii) of Section 237(b) and the expression
“circumstances suggesting” cannot support the construction that even the existence
of circumstances is a matter of subjective opinion. Shelat, J. further observed that it
is hard to contemplate that the Legislature could have left to the subjective process
both the formation of opinion and also the existence of circumstances on which it is
to be founded; it is also not reasonable to say that the clause permitted the Authority
to say that it has formed the opinion on circumstances which in its opinion exist and
which in its opinion suggest an intent to defraud or a fraudulent or unlawful purpose.
On the other hand Sarkar, C.J. and Mudholkar, J. held that the power conferred on
the Central Government under Section 237(b) is a discretionary power and no facet
of that power is open to judicial review. Our Brother Bachawat, J., the other learned
Judge in that Bench did not express any opinion on this aspect of the case. Under
these circumstances it has become necessary for us to sort out the requirements of
Section 237(b) and to see which of the two contradictory conclusions reached in
Barium Chemicals case is in our judgment, according to law. But before proceeding to
analyse Section 237(b) we should like to refer to certain decisions cited at the bar
bearing on the question under consideration.
(at pp. 120-121) xxx xxx xxx “Coming back to Section 237(b), in finding out its true
scope we have to bear in mind that that section is a part of the scheme referred to
earlier and therefore the said provision takes its colour from Sections 235 and 236. In
finding out the legislative intent we cannot ignore the requirements of those sections.
In interpreting Section 237(b) we cannot ignore the adverse effect of the investigation
on the company. Finally we must also remember that the section in question is an63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

inroad on the powers of the company to carry on its trade or business and thereby an
infraction of the fundamental right guaranteed to its shareholders under Article 19(1)
(g) and its validity cannot be upheld unless it is considered that the power in question
is a reasonable restriction in the interest of the general public. In fact the vires of that
provision was upheld by majority of the Judges constituting the Bench in Barium
Chemicals case principally on the ground that the power conferred on the Central
Government is not an arbitrary power and the same has to be exercised in accordance
with the restraints imposed by law. For the reasons stated earlier we agree with the
conclusion reached by Hidayatullah, J.
and Shelat, JJ. in Barium Chemicals case that the existence of circumstances suggesting that the
company’s business was being conducted as laid down in sub-clause(1) or the persons mentioned in
sub-clause (2) were guilty of fraud or misfeasance or other misconduct towards the company or
towards any of its members is a condition precedent for the Government to form the required
opinion and if the existence of those conditions is challenged, the courts are entitled to examine
whether those circumstances were existing when the order was made. In other words, the existence
of the circumstances in question are open to judicial review though the opinion formed by the
Government is not amenable to review by the courts. As held earlier the required circumstances did
not exist in this case.” (at pp. 128-129)
38. In Western U.P. Electric Power & Supply Co. Ltd. v. State of U.P. and Anr., (1969) 1 SCC 817, this
Court dealt with a situation where the Indian Electricity Act, 1910 was amended by the U.P. Act 30
of 1961, by which, Section 3(2)(e)(ii) provided that the grant of a licence shall not, in any way, hinder
or restrict the supply of energy by the State Government or the State Electricity Board within the
same area where the State Government deems such supply “necessary in public interest”. In that
case, the High Court had observed that the State Government was the sole judge of whether the
direct supply of energy was or was not in public interest, the nature of the power being subjective.
This Court, in upsetting the High Court’s view, held:
“11. We are unable to agree with that view. By Section 3(2)(e) as amended by the U.P.
Act 30 of 1961, the Government is authorised to supply energy to consumers within
the area of the licensee in certain conditions: exercise of the power is conditioned by
the Government deeming it necessary in public interest to make such supply. If
challenged, the Government must show that exercise of the power was necessary in
public interest. The Court is thereby not intended to sit in appeal over the satisfaction
of the Government. If there be prima facie evidence on which a reasonable body of
persons may hold that it is in the public interest to supply energy directly to the
consumers, the requirements of the statute are fulfilled. Normally a licensee of
electrical energy, though he has no monopoly, is the person through whom electrical
energy would be distributed within the area of supply, since the licensee has to lay
down electric supply-lines for transmission of energy and to maintain its
establishment. An inroad may be made in that right in the conditions which are
statutorily prescribed. In our judgment, the satisfaction of the Government that the63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

supply is necessary in the public interest is in appropriate cases not excluded from
judicial review.”
39. Close upon the heels of these judgments, this Court, after considering Barium Chemicals (supra)
and Rohtas Industries (supra), restated the test as to judicial review of administrative action in
Rampur Distillery Co. Ltd. v. Company Law Board, [1970] 2 SCR 177 as follows:
“The scheme of the section implies investigation and a decision on the matters set out
therein. Section 326 lays down conditions by sub-section (1)(a) in which the Central
Government may override the resolution of the general body of share-holders in
certain specified conditions. Upon the Central Government is imposed a duty not to
accord approval to the appointment or re- appointment of a proposed managing
agent in the light of clauses (a), (b) and (c) of sub-section (2). Though the sub-section
is enacted in form negative, in substance it confers power upon the Government
subject to the restrictions imposed by clauses (a), (b) and (c), to refuse to accord
approval. Sub-section (2) imposes upon the Central Government the duty not to
accord approval to appointment or re-appointment of a proposed managing agent
unless the Government is satisfied that the managing agent is a fit and proper person
to be appointed, that the conditions of the managing agency agreement are fair and
reasonable and that the managing agent has fulfilled the conditions which the Central
Government required him to fulfil. Thereby the Central Government is not made the
final arbiter of the existence of the grounds on which the satisfaction may be founded.
The satisfaction of the Government which is determinative is satisfaction as to the
existence of certain objective facts. The recital about satisfaction may be displaced by
showing that the conditions did not exist, or that no reasonable body of persons
properly versed in law could have reached the decision that they did. The Courts,
however, are not concerned with the sufficiency of the grounds on which the
satisfaction is reached. What is relevant is the satisfaction of the Central Government
about the existence of the conditions in clauses (a), (b) and (c) of sub-section (2) of
Section 326. The enquiry before the Court, therefore, is whether the Central
Government was satisfied as to the existence of the conditions. The existence of the
satisfaction cannot be challenged except probably on the ground that the authority
acted mala fide. But if in reaching its satisfaction the Central Government
misapprehended the nature of the conditions, or proceeded upon irrelevant
materials, or ignores relevant materials, the jurisdiction of the Courts to examine the
satisfaction is not excluded. ……” (at p. 183) In M.A. Rasheed and Ors. v. State of
Kerala, [1975] 2 SCR 93, after following Rohtas Industries (supra), the test for
judicial review of administrative decisions was stated most felicitously by Ray, C.J.
thus:
“Administrative decisions in exercise of powers even if conferred in subjective terms
are to be made in good faith on relevant consideration. The courts inquire whether a
reasonable man could have come to the decision in question without misdirecting
himself on the law or the facts in a material respect. The standard of reasonableness63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

to which the administrative body is required to conform may range from the courts’
own opinion of what is reasonable to the criterion of what a reasonable body might
have decided. The courts will find out whether conditions precedent to the formation
of the opinion have a factual basis.” (at p. 99) In Khudiram Das v. State of West
Bengal, (1975) 2 SCC 81, this Court exhaustively set out parameters for judicial
review of the subjective satisfaction of the detaining authority in a preventive
detention case. This Court held:
“9. But that does not mean that the subjective satisfaction of the detaining authority
is wholly immune from judicial reviewability. The courts have by judicial decisions
carved out an area, limited though it be, within which the validity of the subjective
satisfaction can yet be subjected to judicial scrutiny. The basic postulate on which the
courts have proceeded is that the subjective satisfaction being a condition precedent
for the exercise of the power conferred on the Executive, the Court can always
examine whether the requisite satisfaction is arrived at by the authority : if it is not,
the condition precedent to the exercise of the power would not be fulfilled and the
exercise of the power would be bad. There are several grounds evolved by judicial
decisions for saying that no subjective satisfaction is arrived at by the authority as
required under the statute. The simplest case is whether the authority has not applied
its mind at all; in such a case the authority could not possibly be satisfied as regards
the fact in respect of which it is required to be satisfied. Emperor v. Shibnath
Bannerji [AIR 1943 FC 75 : 1944 FCR 1 : 45 Cri LJ 341] is a case in point. Then there
may be a case where the power is exercised dishonestly or for an improper purpose :
such a case would also negative the existence of satisfaction on the part of the
authority. The existence of “improper purpose”, that is, a purpose not contemplated
by the statute, has been recognised as an independent ground of control in several
decided cases. The satisfaction, moreover, must be a satisfaction of the authority
itself, and therefore, if, in exercising the power, the authority has acted under the
dictation of another body as the Commissioner of Police did in Commissioner of
Police v. Gordhandas Bhanji [AIR 1952 SC 16 : 1952 SCR 135] and the officer of the
Ministry of Labour and National Service did in Simms Motor Units Ltd. v. Minister of
Labour and National Service [(1946) 2 All ER 201] the exercise of the power would be
bad and so also would the exercise of the power be vitiated where the authority has
disabled itself from applying its mind to the facts of each individual case by
self-created rules of policy or in any other manner. The satisfaction said to have been
arrived at by the authority would also be bad where it is based on the application of a
wrong test or the misconstruction of a statute. Where this happens, the satisfaction of
the authority would not be in respect of the thing in regard to which it is required to
be satisfied. Then again, the satisfaction must be grounded “on materials which are of
rationally probative value”. Machindar v. King [AIR 1950 FC 129 : 51 Cri LJ 1480 :
1949 FCR 827]. The grounds on which the satisfaction is based must be such as a
rational human being can consider connected with the fact in respect of which the
satisfaction is to be reached. They must be relevant to the subject-matter of the
inquiry and must not be extraneous to the scope and purpose of the statute. If the63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

authority has taken into account, it may even be with the best of intention, as a
relevant factor something which it could not properly take into account in deciding
whether or not to exercise the power or the manner or extent to which it should be
exercised, the exercise of the power would be bad. Pratap Singh v. State of Punjab
[AIR 1964 SC 72 : (1964) 4 SCR 733]. If there are to be found in the statute expressly
or by implication matters which the authority ought to have regard to, then, in
exercising the power, the authority must have regard to those matters. The authority
must call its attention to the matters which it is bound to consider.” In Tata Cellular
v. Union of India (1994) 6 SCC 651, after an exhaustive review of the latest English
judgments, this Court held:
“77. The duty of the court is to confine itself to the question of legality. Its concern
should be:
1. Whether a decision-making authority exceeded its powers?
2. committed an error of law,
3. committed a breach of the rules of natural justice,
4. reached a decision which no reasonable tribunal would have reached or,
5. abused its powers.
Therefore, it is not for the court to determine whether a particular policy or particular decision taken
in the fulfilment of that policy is fair. It is only concerned with the manner in which those decisions
have been taken. The extent of the duty to act fairly will vary from case to case. Shortly put, the
grounds upon which an administrative action is subject to control by judicial review can be classified
as under:
(i) Illegality: This means the decision-maker must understand correctly the law that
regulates his decision-making power and must give effect to it.
            (ii) Irrationality,    namely,        Wednesbury
                 unreasonableness.
           (iii) Procedural impropriety.
The above are only the broad grounds but it does not rule out addition of further
grounds in course of time.
As a matter of fact, in R. v. Secretary of State for the Home Department, ex Brind [(1991) 1 AC 696],
Lord Diplock refers specifically to one development, namely, the possible recognition of the
principle of proportionality. In all these cases the test to be adopted is that the court should,
“consider whether something has gone wrong of a nature and degree which requires its
intervention”.”63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

40. In Bhikhubhai Vithlabhai Patel v. State of Gujarat, (2008) 4 SCC 144, this Court, in an elaborate
judgment, referred to and followed several judgments, including Barium Chemicals (supra), in the
context of Section 17 of the Gujarat Town Planning and Urban Development Act, 1976, by which, if
the State Government is of opinion that substantial modifications in the draft development plan are
necessary, it may publish such modifications. This Court held:
“20. The State Government is entitled to publish the modifications provided it is of
opinion that substantial modifications in the draft development plan are necessary.
The expression “‘is of opinion’ that substantial modifications in the draft
development plan are necessary” is of crucial importance. Is there any material
available on record which enabled the State Government to form its opinion that
substantial modifications in the draft development plan were necessary? The State
Government’s jurisdiction to make substantial modifications in the draft
development plan is intertwined with the formation of its opinion that such
substantial modifications are necessary in the draft development plan. The State
Government without forming any such opinion cannot publish the modifications
considered necessary along with notice inviting suggestions or objections. We have
already noticed that as on the day when the Minister concerned took the decision
proposing to designate the land for educational use the material available on record
were:
(a) the opinion of the Chief Town Planner;
(b) note dated 23-4-2004 prepared on the basis of the record providing the entire
background of the previous litigation together with the suggestion that the land
should no more be reserved for the purpose of South Gujarat University and after
releasing the lands from reservation, the same should be placed under the residential
zone.
21. It is true that the State Government is not bound by such opinion and is entitled to take its own
decision in the matter provided there is material available on record to form opinion that substantial
modifications in the draft development plan were necessary. Formation of opinion is a condition
precedent for setting the law in motion proposing substantial modifications in the draft
development plan.
22. Any opinion of the Government to be formed is not subject to objective test. The language leaves
no room for the relevance of a judicial examination as to the sufficiency of the grounds on which the
Government acted in forming its opinion. But there must be material based on which alone the State
Government could form its opinion that it has become necessary to make substantial modification in
the draft development plan.
23. The power conferred by Section 17(1)(a)(ii) read with proviso is a conditional power. It is not an
absolute power to be exercised in the discretion of the State Government. The condition is formation
of opinion— subjective, no doubt—that it had become necessary to make substantial modifications63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

in the draft development plan. This opinion may be formed on the basis of material sent along with
the draft development plan or on the basis of relevant information that may be available with the
State Government. The existence of relevant material is a precondition to the formation of opinion.
The use of word “may” indicates not only a discretion but an obligation to consider that a necessity
has arisen to make substantial modifications in the draft development plan. It also involves an
obligation to consider which of the several steps specified in sub-clauses (i), (ii) and (iii) should be
taken.
24. The proviso opens with the words “where the State Government is of opinion that substantial
modifications in the draft development plan and regulations are necessary, …”. These words are
indicative of the satisfaction being subjective one but there must exist circumstances stated in the
proviso which are conditions precedent for the formation of the opinion. Opinion to be formed by
the State Government cannot be on imaginary grounds, wishful thinking, however laudable that
may be. Such a course is impermissible in law. The formation of the opinion, though subjective,
must be based on the material disclosing that a necessity had arisen to make substantial
modifications in the draft development plan.
25. The formation of the opinion by the State Government is with reference to the necessity that may
have had arisen to make substantial modifications in the draft development plan. The expression:
“as considered necessary” is again of crucial importance. The term “consider” means to think over; it
connotes that there should be active application of the mind. In other words, the term “consider”
postulates consideration of all the relevant aspects of the matter. A plain reading of the relevant
provision suggests that the State Government may publish the modifications only after
consideration that such modifications have become necessary. The word “necessary” means
indispensable, requisite, indispensably requisite, useful, incidental or conducive, essential,
unavoidable, impossible to be otherwise, not to be avoided, inevitable. The word “necessary” must
be construed in the connection in which it is used. (See Advanced Law Lexicon, P. Ramanatha Aiyar,
3rd Edn., 2005.)
26. The formation of the opinion by the State Government should reflect intense application of mind
with reference to the material available on record that it had become necessary to propose
substantial modifications to the draft development plan.”
41. However, Shri Tushar Mehta, learned Solicitor General for India, relied upon M. Jhangir
Bhatusha and Ors. v. Union of India and Ors., 1989 Supp (2) SCC 201, in particular, the passage at
page 208 which reads as follows:
“13. …… Now it is the Central Government which has to be satisfied, as the authority
appointed by Parliament under Section 25(2), that it is necessary in the public
interest to make the special orders of exemption. It has set out the reasons which
prompted it to pass the orders. In our opinion, the circumstances mentioned in those
notifications cannot be said to be irrelevant or unreasonable. It is not for this Court to
sit in judgment on the sufficiency of those reasons. The limitations on the jurisdiction
of the court in cases where the satisfaction has been entrusted to executive authority63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

to judge the necessity for passing orders is well defined and has been long accepted.”
These observations were made in the context of an argument that differential
treatment was accorded to the State Trading Corporation vis-à-vis private importers
in that the customs duty for the State Trading Corporation had been reduced by
notification under Section 25(2) of the Customs Act, 1962. What is important to note
is that judicial review consisted of examining whether the reasons which prompted
the Government to pass the exemption orders could be said to be irrelevant or
unreasonable. If so, the orders would be struck down in exercise of judicial review.
42. Thus, at the very least, it is clear that the Central Government’s satisfaction must be as to the
conditions precedent mentioned in the Section as correctly understood in law, and must be based on
facts that have been gathered by the Central Government to show that the conditions precedent exist
when the order of the Central Government is made. There must be facts on which a reasonable body
of persons properly instructed in law may hold that it is essential in public interest to amalgamate
two or more companies. The formation of satisfaction cannot be on irrelevant or imaginary grounds,
as that would vitiate the exercise of power.
“ESSENTIAL”
43. The expression “essential” has been defined in P. Ramanath Aiyer’s Law Lexicon (4th Edn.) as
follows:
“Essential. Indispensably necessary; important in the highest degree: requisite that
which is required for the continued existence of a thing.” Black’s Law Dictionary
(10th Edn.) defines “essential” as follows:
“essential, adj. (14c) 1. Of, relating to, or involving the essence or intrinsic nature of
something. 2. Of the utmost importance; basic and necessary. 3. Having real
existence; actual.”
44. In J. Jayalalitha v. Union of India, (1999) 5 SCC 138, this Court dealt with an argument that
there is no guideline contained in Section 3(1) of the Prevention of Corruption Act, 1988, when the
Section empowers the Government to appoint as many Special Judges “as may be necessary”. It was
stated that this word has a precise meaning and means “what is indispensable, needful or essential”
[see paragraph 14]. It is thus clear that the Central Government’s mind has to be applied to whether
a compulsory amalgamation under Section 396 is indispensably necessary, important in the highest
degree, and whether such amalgamation is both basic and necessary. “PUBLIC INTEREST”
45. The third pre-requisite of Section 396 is that the Central Government must apply its mind when
compulsorily amalgamating two or more companies in the public interest. “Public interest” is an
expression which is wide and amorphous and takes colour from the context in which it is used.
However, like the expression “public purpose”, what is important to be noted is that public interest
is the general interest of the community, as distinguished from the private interest of an individual
[see State of Bihar v. Maharajadhiraja Sir Kameshwar Singh of Darbhanga and Ors., [1952] 3 SCR63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

889 at pp. 1073-1075].
46. This is echoed in Manimegalai v. Special Tehsildar (Land Acquisition Officer) Adi Dravidar
Welfare, (2018) 13 SCC 491 as follows:
“14. Similarly, public purpose is not capable of precise definition. Each case has to be
considered in the light of the purpose for which acquisition is sought for. It is to serve
the general interest of the community as opposed to the particular interest of the
individual. Public purpose broadly speaking would include the purpose in which the
general interest of the society as opposed to the particular interest of the individual is
directly and vitally concerned. Generally, the executive would be the best judge to
determine whether or not the impugned purpose is a public purpose. Yet it is not
beyond the purview of judicial scrutiny. The interest of a section of the society may be
public purpose when it is benefitted by the acquisition. The acquisition in question
must indicate that it was towards the welfare of the people and not to benefit a
private individual or group of individuals joined collectively. Therefore, acquisition
for anything which is not for a public purpose cannot be done compulsorily.”
(emphasis supplied)
47. In the context of the Motor Vehicles Act, 1939, in Rameshwar Prasad and Ors. v. State of U.P.
and Ors., (1983) 2 SCC 195, this Court held:
“19. ……… What does Section 43-A(1) after all say? It says that the State Government
may issue such directions of a general character as it may consider necessary in the
public interest. What is the meaning of the term “public interest”? In the context of
the Act, it takes within its fold several factors such as, the maximum number of
permits that may be issued on a route or in any area having regard to the needs and
convenience of the travelling public, the non-availability of sufficient number of stage
carriage services in other routes or areas which may be in need of running of
additional services, the problems of law and order, availability of fuel, problems
arising out of atmospheric pollution caused by a large number of motor vehicles
operating in any route or area, the condition of roads and bridges on the routes,
uneconomic running of stage carriage services leading to elimination of small
operators and employment of more capital than necessary in any sector leading to
starvation of capital investment in other sectors etc. Public interest under the Act
does not mean the interest of the operators or of the passengers only. We have to
bear in mind that like every other economic activity the running of stage carriage
service is an activity which involves use of scarce or limited productive resources.
Motor transport involves a huge capital investment on motor vehicles, training of
competent drivers and mechanics, establishment of workshops, construction of safe
roads and bridges, deployment of sufficient number of policemen to preserve law and
order and several other matters. To say that larger the number of stage carriages in
any route or area more convenient it would be to the members of the public is an
oversimplification of a problem with myriad facets affecting the general public. If we63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

run through the various provisions of the Act it becomes clear how much attention is
given by it to various matters affecting public interest. There are provisions relating
to licensing of drivers on the basis of their competence, licensing of conductors,
specifications to which the motor vehicles should conform, coordination of road and
rail transport, prevention of deterioration of the road system, prevention of
uneconomic competition among motor vehicles, fixation of reasonable fare,
compliance by motor vehicles with the prescribed timetable, construction of bus
stands with necessary amenities, maintenance of standards of comfort and
cleanliness in the vehicles, development of inter-state tourist traffic and several other
matters with the object of making available adequate and efficient transport facilities
to all parts of the country. Any direction given by the State Government under
Section 43-A of the Act should, therefore, be in conformity with all matters regarding
which the statute has made provision. In this situation to say that any number of
permits can be issued to any eligible operator without any upper limit is to overstep
the limits of delegation of statutory power and to make a mockery of an important
economic activity like the motor transport.” (emphasis supplied)
48. In Janata Dal v. H.S. Chowdhary and Ors., (1992) 4 SCC 305, this Court referred to Stroud’s
Judicial Dictionary, which defines “public interest” thus:
“51. In Stroud’s Judicial Dictionary, Vol. IV (4th edn.) ‘public interest’ is defined thus:
“Public interest — 1. A matter of public or general interest does not mean that which
is interesting as gratifying curiosity or a love of information or amusement; but that
in which a class of the community have a pecuniary interest, or some interest by
which their legal rights or liabilities are affected.” (Per Cambel C.J., in R. v.
Bedfordshire [24 LJ QB 84] ).
52. In Black’s Law Dictionary (6th edn.), ‘public interest’ is defined as follows:
“Public Interest — Something in which the public, the community at large, has some
pecuniary interest, or some interest by which their legal rights or liabilities are
affected. It does not mean anything so narrow as mere curiosity, or as the interests of
the particular localities, which may be affected by the matters in question. Interest
shared by citizens generally in affairs of local, state or national government ……”
49. In Municipal Corporation of the City of Ahmedabad and Ors. v. Jan Mohd. Usmanbhai and Anr.,
(1986) 3 SCC 20, this Court stated that the expression “in the interest of the general public” is of
wide import comprehending public order, public health, public security, morals, economic welfare
of the community, and the objects mentioned in Part IV of the Constitution of India [see paragraph
19].
50. Likewise, in B.P. Sharma v. Union of India and Ors., (2003) 7 SCC 309, this Court held:63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

“15. …… The phrase “in the interest of the general public” has come to be considered
in several decisions and it has been held that it would comprise within its ambit
interests like public health and morals (refer to State of Maharashtra v. Himmatbhai
Narbheram Rao [AIR 1970 SC 1157 : (1969) 2 SCR 392]), economic stability (State of
Assam v. Sristikar Dowerah [AIR 1957 SC 414]), stability of the country, equitable
distribution of essential commodities at fair prices (Union of India v. Bhanamal
Gulzarimal Ltd. [AIR 1960 SC 475 : 1960 Cri LJ 664]) for maintenance of purity in
public life, prevention of fraud and similar considerations. ……”
51. Coming nearer home, Hindustan Lever Employees’ Union v. Hindustan Lever Ltd. and Ors.,
1995 Supp (1) SCC 499, Sahai, J., in a concurring judgment, referred to “public interest” in Section
394 of the Companies Act as follows:
“5. What requires, however, a thoughtful consideration is whether the company court
has applied its mind to the public interest involved in the merger. In this regard the
Indian law is a departure from the English law and it enjoins a duty on the court to
examine objectively and carefully if the merger was not violative of public interest.
No such provision exists in the English law. What would be public interest cannot be
put in a strait-jacket. It is a dynamic concept which keeps on changing. It has been
explained in Black’s Law Dictionary as:
“Something in which the public, the community at large, has some pecuniary interest,
or some interest by which their legal rights or liabilities are affected. It does not mean
anything so narrow as mere curiosity, or as the interests of the particular locality
which may be affected by the matters in question. Interest shared by citizens
generally in affairs of local, State or national Government.” It is an expression of wide
amplitude. It may have different connotation and understanding when used in
service law and a yet different meaning in criminal law than civil law and its shade
may be entirely different in company law. Its perspective may change when merger is
of two Indian companies. But when it is with subsidiary of foreign company the
consideration may be entirely different. It is not the interest of shareholders or the
employees only but the interest of society which may have to be examined. And a
scheme valid and good may yet be bad if it is against public interest.
6. Section 394 casts an obligation on the court to be satisfied that the scheme for
amalgamation or merger was not contrary to public interest. The basic principle of
such satisfaction is none other than the broad and general principles inherent in any
compromise or settlement entered between parties that it should not be unfair or
contrary to public policy or unconscionable. In amalgamation of companies, the
courts have evolved, the principle of “prudent business management test” or that the
scheme should not be a device to evade law.
But when the court is concerned with a scheme of merger with a subsidiary of a foreign company
then the test is not only whether the scheme shall result in maximising profits of the shareholders or63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

whether the interest of employees was protected but it has to ensure that merger shall not result in
impeding promotion of industry or shall obstruct growth of national economy. Liberalised economic
policy is to achieve this goal. The merger, therefore, should not be contrary to this objective.
Reliance on English decisions Hoare & Co. Ltd., Re [1933 All ER Rep 105, Ch D] and Bugle Press
Ltd., Re [1961 Ch 270 : (1960) 1 All ER 768 : (1960) 2 WLR 658] that the power of the court is to be
satisfied only whether the provisions of the Act have been complied with or that the class or classes
were fully represented and the arrangement was such as a man of business would reasonably
approve between two private companies may be correct and may normally be adhered to but when
the merger is with a subsidiary of a foreign company then economic interest of the country may have
to be given precedence. The jurisdiction of the court in this regard is comprehensive.” (emphasis
supplied)
52. In Bihar Public Service Commission v. Saiyed Hussain Abbas Rizwi and Anr., (2012) 13 SCC 61,
this Court referred to “public interest” in the context of service law as follows:
“22. The expression “public interest” has to be understood in its true connotation so
as to give complete meaning to the relevant provisions of the Act. The expression
“public interest” must be viewed in its strict sense with all its exceptions so as to
justify denial of a statutory exemption in terms of the Act. In its common parlance,
the expression “public interest”, like “public purpose”, is not capable of any precise
definition. It does not have a rigid meaning, is elastic and takes its colour from the
statute in which it occurs, the concept varying with time and state of society and its
needs (State of Bihar v. Kameshwar Singh [AIR 1952 SC 252]). It also means the
general welfare of the public that warrants recognition and protection; something in
which the public as a whole has a stake [Black’s Law Dictionary (8th Edn.)].”
53. In R.R. Tripathi v. Union of India, (2010) 1 Bom CR 513, the Bombay High Court referred to the
Business Dictionary, which defines “public interest” as follows:
“welfare of the general public (in contrast to the selfish interest of a person, group, or
firm) in which the whole society has a stake and which warrants recognition,
promotion, and protection by the government and its agencies. Despite the vagueness
of the term, public interest is claimed generally by governments in matters of state
secrecy and confidentiality. It is approximated by comparing expected gains and
potential costs or losses associated with a decision, policy, program, or project.”
(emphasis supplied)
54. In the context of compulsory amalgamation of two or more companies, the expression “public
interest” would mean the welfare of the public or the interest of society as a whole, as contrasted
with the “selfish” interest of a group of private individuals. Thus, “public interest” may have regard
to the interest of production of goods or services essential to the nation so that they may contribute
to the nation’s welfare and progress, and in so doing, may also provide much needed employment.
“Public interest” in this context would, therefore, mean the combining of resources of two or more
companies so as to impact production and consumption of goods and services and employment of63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

persons relatable thereto for the general benefit of the community. Conversely, any action that
impedes promotion of industry or obstructs growth which is in national or public interest would run
counter to public interest as mentioned in this Section.
55. At this juncture, we must first see whether each of the conditions precedent to the applicability
of Section 396 applies to the facts of the present case. Insofar as the Central Government being
“satisfied” is concerned, the following facts which the Central Government has taken into account,
based upon the Grant Thornton report and the FMC order dated 17.12.2013, are as follows:
55.1. The Grant Thornton report does indeed begin with a disclaimer, which reads as
follows:
“4. Limitations 4.1. Our findings are based upon the information made available to us
and we have not independently verified or validated the information.
4.2. Our work did not constitute an audit under any accounting standards and the
scope of our work was significantly different from that of a statutory audit.
Hence it cannot be relied upon to provide the same level of assurance as a statutory audit.
4.3. Work done by us was as considered necessary at that point of time to reflect the scope of work
and rigour required.
5. Restrictions 5.1. Our reports and comments are confidential in nature and not intended for
general circulation or publication, nor are they to be quoted or referred to in whole or in part,
without our prior consent in each specific instance. Such consent shall not be unreasonably
withheld. NSEL and FMC shall have no authority or ability to modify our findings in any manner.
We disclaim all responsibility or liability for any costs, damages, losses, liabilities, expenses incurred
by anyone as a result of circulation, publication, reproduction or use of our reports contrary to the
provisions of this paragraph. Should additional information or documentation become available
which impacts upon conclusions reached in our reports, we reserve the right to amend our findings
and reporting accordingly. Further, comments in our reports are not intended, nor should they be
interpreted to be, legal advice or opinion.” However, the said report in the executive summary
states:
“B. Executive Summary This executive summary is to be read in conjunction with the
whole report and should not be treated as a standalone document.
Financing Business 1.1 The NSEL exchange platform was being used to conduct a
financing business.
Indian Bullion Market Association (‘IBMA’) enabled large volumes of trading by a related party on
FTIL group exchanges (NSEL and Multi-Commodity Exchange of India Limited (‘MCX’).) This is
illustrated as per the diagram below:— 1.2 Grant Thornton observed that a large volume of NSEL63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

exchange trades were carried out with paired back-to-back contracts. Investors simultaneously
entered into a short term buy contract (e.g. T+2 – i.e. 2- day settlement) and a long-term sell
contract (e.g. T+25- i.e. 25 day settlement). The contracts were taken by the same parties at a
pre-determined price and always registering a profit on the long-term positions as illustrated below:
Trad Dea Buy Membe Name of Member Contract Sub Termin Trade Trade e l /Sell r
ID Code Broker al ID Price Value Date No No.
02 87 S 13790 PD DLF002 PDY1121 474 13791 2400.00 360,000 April AGROPROCESSOR HR2
2012 S PVT. LTD.
02 87 B     10570 ANAND RATHI       HNR320 PDY1121 232     10575 2400.00 360,000
April             COMMODITIES              HR2
2012              LTD.
02 88 S     10570 ANAND RATHI       HNR320 PY1121H 232     10575 2450.70 367,605
April             COMMODITIES              R25
2012              LTD.
02 88 B     13790 PD                DLC001 PY1121H 474     13791 2450.70 367,605
April             AGROPROCESSOR            R25
2012              S PVT. LTD.
1.3 These long-term contracts (e.g. T+25) were first traded on the NSEL exchange in September
2009. The Board of NSEL ratified the circulars introducing such long-term contracts over a period
beginning November 2009.
1.4 Further evidence was obtained with regards the existence of a financing business, such as
presentations which stated that a fixed rate of return was guaranteed on investing in certain
products on the NSEL exchange. Several internal (NSEL) presentations were found, upon a review
of e-mail databases, setting out a yield (e.g. 16%) as an opportunity for investors for trading in
certain products on the NSEL exchange.
An external presentation was also obtained which had been made by a brokerage house (Geojit
Comtrade Ltd.) for their clients claiming a fixed return on investments made on the NSEL exchange.
Further, this presentation, declared that actual delivery of stocks in such transactions would not be
required.
1.5 Grant Thornton also obtained evidence of repeated contraventions of NSEL exchange rules and
bye-laws which facilitated such financing transactions to continue and grow in size as below:
Repeated Defaults: As per the NSEL exchange rules a member who does not have
sufficient collateral/monies etc. to discharge his obligations would not be allowed to
trade further. This rule was overridden on a recurring basis. Further despite repeated
defaults members were allowed to trade and increase their expenses. For example,
Lotus Refineries had defaulted, as per the Rules of the Exchange, on 198 days63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

between the fifteen- month period of 1 April 2012 and 30 July 2013. Exemptions
from Margin Requirements: Members who were in a default position or whom had
exhausted their margin limits on trading were granted an exemption from margin
requirements and thus allowed them to increase their exposure by engaging in new
trades. More than 1,800 margin limit exemptions were granted between 2009
through to 2013.
Inadequate monitoring of member collateral: NSEL did not carry out any diligence to
establish the existence of stock at member managed warehouses, upon which trades
were being executed. Grant Thornton carried out a stock verification exercise and
found significant shortages vis-à-vis expected collateral. Related Party Transactions
1.6 IBMA is registered as a client with Karvy Comtrade limited for executing trades
on futures commodity exchange like MCX and NCDEX.
SNP Designs Private Limited (SNP) is a client of IBMA and the managing director of SNP is Mrs.
Shalini Sinha, the wife of Mr. Anjani Sinha (CEO and MD of NSEL as well as IBMA).
Grant Thornton found evidence of a large volume of trades executed on the MCX exchange on behalf
of SNP, through Karvy Comtrade Limited. Since April 2012 the total nominal value/volume traded
on MCX is approximately Rs. 40,000 crore.
In spite of heavy losses over the period, trading on behalf of SNP was allowed to continue. No
margin money was ever taken from SNP. As at 20 September 2013, IBMA is due to receive Rs. 77
crore on account of losses arising from trades executed on behalf of SNP. No monies have been
received from SNP despite substantial amounts due.
Further, evidence was obtained that Rs. 10 crore was received from Mohan India which was credited
to an IBMA Bank account. This was to be adjusted against the SNP receivable balance as per an
instruction made by Mr. Anjani Sinha.
1.7. IBMA is a subsidiary of NSEL and has received funding for operational needs on several
occasions (including a loan of Rs. 5 crore on 5 August 2013). IBMA is also a member on the NSEL
exchange and executes trades on behalf of clients. Margin limit exemptions have been granted to
IBMA on a daily basis since February 2010.
Corporate Governance & Risk Management 1.8 While the Bye-laws and Rules of the Exchange
mandated the formation of various Committees to effectively manage the operations of the
Exchange; the Board failed to constitute 9 out of the 10 such committees. Further, there is no
documentary evidence to demonstrate whether the only committee formed (Membership
Committee) was ever convened and hence, met its objectives.
1.9 The Board Meeting minutes regularly (eg. 11 June 2008, 15 June 2009, 25 May 2011) stated that
the Audit Committee had detailed discussions on the Annual Financial Statements, the Internal
Control Systems, reviewing the scope of Internal Audit functions, the performance of the statutory63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

and internal auditors, the scope of work for the internal auditors, the planning of the statutory audit
for the current financial year, the payment of audit fees, the observations by the auditors in the draft
Auditor Report etc. Upon review of the corresponding Audit Committee minutes we noted no
reference to discussions on Internal Control Systems, reviewing the scope of Internal Audit
functions, performance of internal auditors and scope of work for the internal auditors.
Common members of the Board and the Audit Committee were:
Mr. Jignesh Shah Mr. Joseph Massey Mr. V. Hariharan Mr. Shreekant Javalgekar
1.10 The Board Meeting minutes of 31 March 2010 and 11 August 2010 stated that the
Company (NSEL) approached Karvy Financial Services Limited (KFSL) to extend
credit facilities to a member, specifically N.K. Proteins. Further the Board granted
and approved for issue of a guarantee to KFSL, to the extent of Rs. 14 crores, in
respect of credit facilities extended to N.K. Proteins.
1.11 Our review of the Information technology identified several independent
standalone systems wherein the flow of business transactions and related
information between different systems required manual intervention.
Given the complexity and nature of trading transaction such systems including warehouse
(eWDMS), CNS, Delivery System (EMI) and trading should have been integrated.
Further, these systems did not produce/have any form of MIS operational. All reporting and
analysis was done on manual worksheets. Our review of the Board minutes did not indicate any
form of MIS reporting or review. These points collectively indicate significant gaps in IT, Risk &
Corporate Governance.
Misutilisation of client monies 1.12 Misutilisation of client monies/settlement fund: As per the rules
and bye-laws of the NSEL exchange “Margin deposits received by clearing members from their
constituent members and clients in any forms shall be accounted for and maintained separately in
segregated accounts and shall be used solely for the benefit of the respective constituent members’
and client position.” Grant Thornton found evidence (including e-mails) that client
monies/settlement fund, was used regularly for fulfilling the obligations of defaulting members.
Further, NSEL utilised client monies/settlement fund for its own business purposes on a regular
basis. For example, on 28 March, 2013, Rs. 236.5 crore was withdrawn from the Settlement Fund in
order to fund NSEL’s own business overdraft account.
There was a running deficit in the client monies/settlement fund balance from April 2012 to June
2013. The finance team of FTIL had raised this as an area of concern on several occasions.
Misrepresentations to the Regulator 1.13 Regulatory Contraventions:
As per a Gazette Notification issued on 5 June 2007 by the Ministry of Consumer
Affairs, the Government of India under Section 27 of the Forward Contracts63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

(Regulation) Act, 1952 (“FCRA”) exempted all forward contracts of one day duration
for the sale and purchase of commodities traded on NSEL from the operations of the
said Act. Grant Thornton’s review of the type of trades executed on the NSEL
exchange indicates contravention to the exemption conditions granted. During the
period January 2011 to July 2013, FMC sought several clarifications from NSEL on a
number of complaints received from the public alleging forward trading and running
a financing scheme. All these allegations were refuted by NSEL. Our analysis of such
trades indicates misrepresentation by NSEL to FMC on several occasions.” The
report then goes on to say that there was no documentation in relation to warehouse
activities for long term trades indicating that such contracts were not secured by
warehouse stocks. The warehouses were customer managed warehouses and the
underlying collateral were not in custody of NSEL. NSEL did not have control over
these warehouses and Grant Thornton was denied access to number of warehouses.
The Warehouse Development and Regulatory Authority had in fact rejected NSEL’s
application for registration of its warehouses way back on 16.05.2011.
Notwithstanding such rejection, NSEL’s website represented that its warehouses
were registered with the Authority. No verification or due diligence was ever
undertaken by NSEL to ensure compliance by its members of the conditions outlined
in its rules and byelaws even though in terms of NSEL byelaws, warehouse receipt
issued by NSEL were meant to evidence a commodity being held in an approved
warehouse. NSEL did not insist upon deposit of commodities in the warehouses prior
to executing sale transactions. Instead NSEL resorted to issuing Delivery Allocation
Reports (DAR) representing to genuine investors that each transaction was delivery
based and backed at the time of sale by the required quantity of commodities in its
warehouses.
55.2. The observations and conclusions of the FMC order dated 17.12.2013, based
largely on this expert report, read as follows:
“15. Summary Observations and Conclusion:- After having accorded due
consideration to all the objections and arguments raised by the noticees vide their
written submission as well as oral presentations through their counsel, we now
proceed to conclude our observations by taking a final view on the status of the four
noticees as ‘fit and proper persons’ in the succeeding paragraphs. 15.1. Noticee No. 1:-
Financial Technologies (India) Limited (FTIL): We have discussed the equity
structure of NSEL, which is wholly owned by FTIL. We have also pointed out that
Shri Jignesh Shah, Chairman-cum-
Managing Director of FTIL has been a Director on the Board and also functioning as Vice-Chairman
and a key management person of NSEL since its inception. Similarly, Shri Joseph Massey and Shri
Shreekant Javalgekar have been Directors of the said company from its very beginning till the
settlement crisis at NSEL first came to light in July, 2013. The facts establishing the fraud involving
a settlement default over Rs. 5,500 crores at NSEL have been discussed at length in the SCNs issued
to the noticees as well as reiterated, albeit illustratively by us at Para No. 14.7 of this Order. The63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

responsibility of FTIL as the holding company possessing absolute control over the governance of
NSEL has also been highlighted. The control of FTIL over NSEL becomes further crystallized from
the responses given by M/s. Grant Thornton before the Commission on 03.12.2013 stating that Shri
Jignesh Shah, Mr. Joseph Massey and a host of other officials of FTIL reviewed the forensic audit
report and it was only after obtaining their clearance, the forensic auditor finalised its report.
15.1.1. The violation of conditions prescribed in the exemption notification, trading in paired
contracts to generate assured financial returns under the garb of commodity trading, admission of
members who were thinly capitalised having poor net worth and giving margin exemptions to those
who were repeatedly defaulting in settling their dues, poor warehousing facilities with no or
inadequate stocks, no risk management practices followed, non-provision of funds in SGF,
consciously appointing Shri Mukesh P. Shah as statutory auditors for F.Y. 2012-13 who was related
to Shri Jignesh Shah, and apparent complicity with the defaulters to defraud the investors, etc., lead
to an inescapable conclusion that a huge fraud was perpetrated by NSEL while having the presence
of two Board members of FTIL on the Board of NSEL, one of whom was the Vice-Chairman of the
company.
15.1.2. The facts of the case and the manner in which the business affairs of NSEL were conducted
leaves no doubt in our minds that FTIL, notwithstanding its contentions that it was ignorant of the
affairs and conduct of NSEL, exerted a dominant influence on the management, and directed,
controlled and supervised the governance of NSEL. In the face of a fraud of such a magnitude
involving settlement crises of Rs. 5,500 crores owed to over 13,000 sellers/investors on the trading
platform of NSEL, FTIL, cannot seek to take refuge behind the corporate veil so as to unjustifiably
isolate itself from the fraudulent actions that took place at NSEL resulting in such a huge payment
crisis. 15.1.3. FTIL has its principal business of development of software which has become the
technology platform for almost the entire industry engaged in broking in shares and securities,
commodities, foreign exchange etc. As has been demonstrated by FTIL in their written submission,
FTIL has floated a number of regulated exchanges – both for securities and commodities derivatives
– in India as well as abroad. NSEL was incorporated to provide a trading platform of commodity
spot exchange on a pan-India basis for the purpose of which apparently it sought and was granted
exemption from the operation of the FCRA, 1952. Since the objective of the NSEL was promoting
spot trading in commodities on an electronic platform, its business model did not contemplate
venturing into trading in forward contracts. FTIL had already promoted MCX, a regulated exchange
under FCRA, 1952, for the purpose of trading in forward contracts. Therefore, having secured an
exemption from the purview of FCRA, 1952 on the ground that it was intended to promote spot
trading, NSEL was not authorised to allow trading in forward contracts through the scheme of
paired contracts, thereby defying conditions stipulated in the exemption notification granted to it.
The motive behind allowing trading in forward contracts on the NSEL platform in a circuitous
manner on NSEL which was neither recognized nor registered under FCRA, 1952 indicates mala fide
intention on the part of the promoter of FTIL to use the trading platform of its subsidiary company
for illicit gains away from the eyes of Regulator. The fact that FTIL promoted NSEL sought
exemption from FCRA, 1952 provisions even before they had started any trading or operation,
points to their intention from the outset. In this manner, it misinterpreted the conditions stipulated
in the exemption notification in collusion with a handful of members, which ultimately culminated63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

in a massive fraud involving Rs. 5,500 crores, which has the potential effect of eroding trust and
confidence in exchanges and financial markets. 15.1.4. Keeping in view the foregoing observations
and the facts which reveal misconduct, lack of integrity and unfair practices on the part of FTIL in
planning, directing and controlling the activities of its subsidiary company, NSEL, we conclude that
FTIL, as the anchor investor in the Multi-Commodity Exchange Ltd. (MCX) does not carry a good
reputation and character, record of fairness, integrity or honesty to continue to be a shareholder of
the aforesaid regulated exchange. Therefore, in the public interest and in the interest of the
Commodities Derivatives Market which is regulated under FCRA, 1952, the Commission holds that
Financial Technologies (India) Ltd. (FTIL) is not a ‘fit and proper person’ to continue to be a
shareholder of 2% or more of the paid-up equity capital of MCX as prescribed under the guidelines
issued by the Government of India for capital structure of commodity exchanges post 5-years of
operation. It is further ordered that neither FTIL, nor any company/entity controlled by it, either
directly or indirectly, shall hold any shares in any association/Exchange recognised by the
Government or registered by the FMC in excess of the threshold limit of the total paid-up equity
capital of such Association/Exchange as prescribed under the commodity exchange guidelines and
post 5-year guidelines.” (emphasis in original) Based on the Grant Thornton report and the FMC
order, the draft amalgamation order dated 21.10.2014 then relied on the same facts, as did the final
assessment order. The final amalgamation order also refers to an investigation under Section 209A
into the affairs of NSEL which led to infractions of Sections 211, 217 and 292A of the Companies Act.
These are compoundable offences which have, in fact, been compounded by orders dated
03.03.2016 and 31.05.2016 by the concerned authority.
55.3. We have seen that neither FTIL nor NSEL has denied the fact that paired contracts in
commodities were going on, and by April to July, 2013, 99% (and excluding E-series contracts), at
least 46% of the turnover of NSEL was made up of such paired contracts. There is no doubt that
such paired contracts were, in fact, financing transactions which were distinct from sale and
purchase transactions in commodities and were, thus, in breach of both the exemptions granted to
NSEL, and the FCRA. We have also seen that NSEL throughout kept representing that it was, in fact,
a commodity exchange dealing with spot deliveries. Apart from the Grant Thornton report and the
FMC order, we have also seen that Shri Jignesh Shah, on 10.07.2013, made representations to the
DCA and the FMC, in which he stated that NSEL had full stock as collateral; 10-20% of open
position as margin money; and that the stock currently held in NSEL’s 120 warehouses was valued
at INR 6000 crore, all of which turned out to be incorrect. Further, there is no doubt whatsoever
that in July, 2013, as a result of NSEL stopping trading on its exchange, a payment crisis of
approximately INR 5600 crore arose. The further question that remains is whether, given these
facts, the conditions precedent for the applicability of Section 396 were followed.
56. When it comes to whether the Central Government’s satisfaction as to whether it was “essential”
to amalgamate the aforesaid companies, what must be borne in mind is that NSEL had itself offered
a settlement scheme to pay back the persons who have allegedly been duped. It was found that this
scheme could not really take off, as a result of which, large amounts continued to be owed to such
persons. That this was the real concern of the FMC is clear from a letter dated 18.08.2014 addressed
by the FMC to the Secretary, Ministry of Corporate Affairs. This letter states:63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

“xxx xxx xxx
2. As apprised earlier, consequent to the suspension of trading and a huge settlement
default that took place at NSEL on 31.07.2007, the Government of India, Ministry of
Consumer Affairs, Food & Public Distribution, Department of Consumer Affairs
(DCA) vide its notification dated 6th August, 2013 (copy enclosed as Annexure II)
inter-alia provided that settlement of all outstanding one day forward contract at
NSEL shall be done under the supervision of FMC. In exercise of this supervisory
role, the Commission has been continuously taking all possible steps and has been
regularly pursuing with NSEL to expedite the recovery proceedings against the
defaulters at its platform. To ensure better monitoring of NSEL’s compliance the
Commission had vide No. 8/1/2013 (1)-MD-1(1)(C)/Settlement (Vol.-IV) dated 29 th
November, 2013 (copy enclosed as Annexure III) constituted a Monitoring & Auction
Committee (MAC) comprising the representatives of various members associations
and investors bodies to assist and advise the Commission on matters pertaining to
the Commission’s supervisory role over the settlement of outstanding contracts at
NSEL.
3. It is observed that even after one year’s incessant efforts and in spite of FMC’s
active role in supervising the settlement of contracts, the settlement plan could not
result in making any substantial payment to the investors as the process of recovery
of dues by NSEL from the defaulting members is very slow. It is submitted that, it is
only the NSEL, which has the responsibility to take all possible coercive measures as
per their rules/bye-laws and other laws of the land, to ensure that the outstanding
dues of all investors are settled. However as on date, NSEL has been able to make a
payment of only Rs. 538.56 crores to its members as against the payment dues of
approximately Rs. 5500 crores. This amount also includes an amount of Rs. 179.26
crores borrowed by NSEL from its holding company, FTIL which was distributed to
small participants. The representatives of members associations and investor bodies
on the MAC in their meeting with the Commission have represented the NSEL has
lost its credibility as an institution. Further the employee attrition in NSEL in the
recent months has been extremely high and it is learnt that the staff strength of NSEL
has come down considerably, adversely affecting the recovery process.
As per the information received from NSEL, the total employee count on NSEL rolls was 193 as on
31.07.2013 (when NSEL had suspended trading in one day forward contracts) which came down to
33 on 31.07.2014. The morale of the employees at NSEL is also very low. NSEL is also confronted
with a number of cases against it, which are pending in the High Courts and MPID Court relating to
its failure to make payment to the investors. The company is hardly left with any financial resources
to meet even legal expenses apart from meeting staff salaries and other expenses related to recovery
process. The members of the Monitoring & Auction Committee have expressed their views that with
the loss of credibility, weak Organizational structure, depletion of man-power strength and lack of
financial resources, NSEL has become totally ineffective in pursuing the recovery of the defaulted
amounts from the defaulter members.63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

4. It may be noted that NSEL is a subsidiary of Financial Technologies India Ltd. (FTIL) which holds
99.99% of the shares of NSEL. Hence, for all practical purposes NSEL is a wholly owned subsidiary
of FTIL and therefore it is the primary responsibility of the parent company, i.e. FTIL to own
complete responsibility for the affairs of its subsidiary company. In this regard attention is drawn to
the order of the Commission No. 4/5/2013- MKT-I/B dated 17th December, 2013 (copy enclosed as
Annexure IV) in the matter of “Fit and Proper Person” status of M/s FTIL (another shareholder and
promoter of MCX) and in the matter of Shri Jignesh Shah & Shri Joseph Massey ex-Directors & Shri
Shreekant Javalgekar ex-MD and CEO of MCX. Some of the important highlights of the said order
pertaining to FTIL are as below:
(i) In para 14.2.1 of the order it is inter-alia mentioned that NSEL by virtue of being a
separate legal entity cannot be said to be independent from the control of the
holding/parent company i.e. FTIL which holds 99.99% of its share capital.
(ii) In para 14.5.2 it is inter-alia mentioned that since FTIL is effectively the only shareholder of
NSEL, the constitution of the Board of Directors of NSEL is entirely under its control. FTIL through
the Board of Directors of NSEL constituted by it possesses effectual and absolute control over its
subsidiary company i.e. NSEL. Such control is further amplified and accomplished by the fact that
Shri Jignesh Shah, the promoter and Chairman-cum-
Managing Director of FTIL has been on the Board of NSEL and functioning as Vice-
Chairman of the Company since its inception.
Shri Joseph Massey was also a common Director both on the Board of FTIL and NSEL, while Shri
Shreekant Javalgekar continued to be a Director of NSEL till he resigned from the post in July 2013;
(iii) In para 14.5.3 of the order it is inter-alia mentioned that it is on record that all the minutes of
Board meetings of NSEL were regularly tabled at the Board meetings of FTIL. FTIL kept itself
apprised about the affairs of NSEL and also approved/ratified the actions of NSEL in its Board
meetings on a regular basis;
(iv) In para 14.9.1 of the order it is inter-alia mentioned that it is undisputed that NSEL was an
Exchange in which FTIL had ownership interest to the extent of 99.9998% leaving a negligible
0.0002% stake to NAFED. The Articles of Association of NSEL confers authority to its shareholders
to appoint Directors. As the single largest shareholder, it is FTIL which has nominated all the
directors on the NSEL board. As a wholly-owned subsidiary, NSEL is completely under the control
of FTIL, including financial control over the affairs of NSEL. FTIL, which had the responsibility of
managing the affairs of NSEL, cannot claim to be unaware of the wrong-doing and fraud committed
by the management of NSEL.
(v) In para 14.10.06 of the order it is inter-63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

alia mentioned that FTIL cannot shy away from its role and duty as a parent company to take
reasonable care and exercise prudence in management and governance of the subsidiary company.
(vi) In para 14.10.8 of the order it is inter-alia mentioned that FTIL has not furnished any
explanation as to what steps have been taken by NSEL or by it as a parent company to honour the
commitment of assuring safety and risk-free trading to the members and clients who have traded on
their platform purely on the basis of an explicit assurance that the Exchange shall step into the shoes
of counter parties should there be any default by any participant.
(vii) In para 15.1.3 of the order it is inter-alia mentioned that FTIL has its principal business of
development of software which has become the technology platform for almost the entire industry
engaged in broking in shares and securities, commodities, foreign exchange etc. The motive behind
allowing trading in forward contracts on the NSEL platform in a circuitous manner on NSEL which
was neither recognized nor registered under FCRA, 1952 indicates mala fide intention on the part of
the promoter of FTIL to use the trading platform of its subsidiary company for illicit gains away
from the eyes of Regulator.
5. The aforesaid facts would clearly establish that the Board of FTIL and its promoters under the
leadership of Shri Jignesh Shah have been actively controlling and directing the affairs of NSEL and
it is due to the poor governance and irregularities perpetrated in to the affairs of NSEL by FTIL and
its promoters that the defaulting members defrauded the exchange to the extent of Rs. 5,500 crores
thereby causing huge financial loss to more than 13,000 investors. It is submitted that the aforesaid
order dated 17th December, 2013 passed by the Commission is based on tangible facts on the role of
FTIL in the affairs of NSEL, mustered by the Commission on its own and also the facts revealed by
the forensic auditor M/s. Grant Thornton who were engaged by NSEL to conduct a forensic audit
into the affairs of NSEL post the settlement crisis. It may be noted the Hon’ble Bombay High Court
has also refused to grant any interim relief to FTIL and three other individuals in respect of the
aforesaid order dated 17 th December, 2013 passed by the Commission declaring FTIL, Shri Jignesh
Shah, Shri Joseph Massey and Shri Shreekant Javalgekar as not fit and proper persons to be
shareholders or a Director in any of the recognized commodity exchanges. FTIL and other three
individuals have so far not challenged the above interim order of the Hon’ble High Court.
6. It is also submitted that the Working Group constituted by the Central Government under the
Chairmanship of Deputy Governor, Reserve Bank of India to examine into the systematic risk
arising in consequence of the NSEL settlement debacle, have inter alia recommended that the
ownership, governance and management structure at FTIL and the exchanges promoted by FTIL
need to be assessed and the possibility of bringing in an institutionalized framework and approach
to these aspects explored.
7. It may also be noted here that pursuant to the criminal proceedings and arrest of Shri Jignesh
Shah, Chairman-cum-Managing Director of FTIL who was also the Vice-Chairman of NSEL, the
EOW of Mumbai Police, has since filed a chargesheet against Shri Jignesh Shah under various
sections of Indian Penal Code and also the Maharashtra Protection of Interest of Depositors (MPID)
Act, 1999, before the Hon’ble Sessions Judge, Special Court under MPID Act, Mumbai which63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

vindicates the stand already taken by the Commission in its order dated 17th December, 2013
pertaining to the role and responsibility of FTIL as a parent company in the affairs of its wholly
owned subsidiary i.e. NSEL.
8. The aforesaid submissions would make it clear that NSEL as a corporate entity has now been
rendered bereft of any credibility and now seems financially and physically incapable of effecting
any substantial recovery from the defaulting members, notwithstanding all the legal and other
measures taken by it against them under the instructions/supervision of the Commission. Similarly,
the Board and management of FTIL, by their very conduct in managing the affairs of NSEL and
continuous effort to distance themselves from their responsibility towards NSEL after the
settlement default, have lost their credibility as a responsive and responsible holding company.
9. Keeping the aforesaid emergency situation in view, the Commission is of the view that time has
come for the Ministry of Corporate Affairs to consider:
(i) merging/amalgamating NSEL with FTIL in public interest so that the human/financial resources
of FTIL are also directed towards facilitating speedy recovery of dues from the defaulters at NSEL
and FTIL takes responsibility to resolve the payment crisis at NSEL at the earliest.
(ii) Further, it is suggested that together with merger/amalgamation of NSEL with FTIL, taking over
of the management of FTIL may also be considered so that the affairs of FTIL can be managed in a
professional way by bringing in an institutionalized framework as recommended by Working Group
appointed by Government of India.
xxx xxx xxx” (emphasis supplied) This letter would show that the immediate reason for
amalgamation, according to the FMC, and which was faithfully carried out by Government, is that
NSEL, as a corporate entity, seems financially and physically incapable of effecting any substantial
recovery from defaulting members. This was the “emergency situation” according to the FMC, which
should lead to an order of amalgamation of the holding and subsidiary companies so that the
holding company’s financial resources could be used to pursue proceedings by which monies owed
to the alleged duped investors/traders could be recovered.
56.1. What is important to note is that by the time the final order of amalgamation was passed, i.e.,
on 12.02.2016, the final order itself records:
“8.1. Economic Offences Wing, Mumbai:
 Total amount due and recoverable from 24 defaulters is Rs. 5689.95 crores.
 Injunctions against assets of defaulters worth Rs. 4400.10 crore have been
obtained.
 Decrees worth Rs. 1233.02 crore have been obtained against 5 defaulters.63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

 Assets worth Rs. 5444.31 crore belonging to the defaulters have been attached of
which assets worth Rs. 4654.62 crore have been published in Gazette under the
MPID Act for liquidation under the supervision of MPID Court and balance assets
worth Rs. 789.69 crore have been attached/secured for attachment by the EOW:
 Assets worth Rs. 885.32 crore belonging to the directors and employees of NSEL
have been attached out of which assets worth Rs. 882.32 crores have already been
published in Gazette under MPID Act for liquidation under the supervision of MPID
Court and balance assets worth Rs. 3 crore have been attached/secured for
attachment by the EOW;
 MPID Court has already issued notices u/s 4 & 5 of the MPID Act to the persons whose assets have
been attached as above. Thus, the process of liquidation of the attached assets has started.
 Bombay High Court has appointed a 3- member committee headed by Mr. Justice (Retd.) V.C.
Daga and 2 experts in finance and law to recover and monetize the assets of the defaulters.
 Rs.558.83 crores have been recovered so far, out of which Rs. 379.83 crore have been
received/recovered from the defaulters and Rs. 179 crore were disbursed by NSEL to small
traders/investors.
8.2. Enforcement Directorate:
 ED has traced proceeds of crime amounting to Rs. 3973.83 crore to the 25
defaulters;
 ED has attached assets worth Rs. 837.01 crore belonging to 12 defaulters;
 As per the recent amendment in the PMLA, the assets attached by ED can be used
for restitution to the victims.
8.3. The above status indicates that the said enforcement agencies are working as per
their mandate…….” 56.2. What concerned the FMC in August 2014 has, by the date of
the final amalgamation order, been largely redressed without amalgamation. The
“emergency situation” of 2013 which, even according to the Central Government,
required the emergent step of compulsory amalgamation has, by the time of the
passing of the Central Government order, disappeared. Thus, the raison d’être for
applying Section 396 of the Companies Act has, by the passage of time, itself
disappeared. In fact, as on today, decrees/awards worth INR 3365 crore have been
obtained against the defaulters, with INR 835.88 crore crystallised by the committee
set up by the High Court, pending acceptance by the High Court, even without using
the financial resources of FTIL as an amalgamated company. What is, therefore,
important to note is that what was emergent, and therefore, essential, even according
to the FMC and the Government in 2013-63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

2014, has been largely redressed in 2016, by the time the amalgamation order was made. Also, the
Central Government order does not apply its mind to the essentiality aspect of Section 396 at all. In
fact, in several places, it refers to “essential public interest” as if “essential” goes with “public
interest” instead of being a separate and distinct condition precedent to the exercise of power under
Section
396. On facts, therefore, it is clear that the essentiality test, which is the condition precedent to the
applicable to Section 396, cannot be said to have been satisfied.
57. During the course of proceedings before the Division Bench of the Bombay High Court, FTIL
tendered an affidavit dated 04.07.2017, to place on record its resolution dated 28.03.2016 to infuse
a sum of upto INR 50 crore for each of the financial years 2016-2017 to 2018- 2019 to support NSEL
to recover dues from defaulters, defend various cases, and continue taking necessary legal action
against various parties to recover amounts from defaulters. The Division Bench refers to this
affidavit as follows:
“293] At the stage, when the final hearing in these petitions had considerably
advanced, FTIL, tendered an affidavit dated 4th July 2017 to place on record its
resolution dated 28th March 2016 to infuse a sum up to Rs. 50 crores for each of the
financial years, i.e., FY 2016-17 to FY 2018-19, to support NSEL to recover dues from
defaulters; to defend various legal cases; to continue taking necessary legal actions
against various parties to recover amounts from defaulters; and for working capital.
The affidavit states that such resolution was passed and such finances are proposed
to be infused at the request of NSEL.
294] The affidavit dated 4th July 2017 also confirms that the activities of NSEL have
come to a grinding halt, though, the affidavit purports to blame the FMC for such a
situation. The affidavit also states that up to now FTIL has infused approximately Rs.
109 crores with NSEL, mainly to prosecute and defend legal proceedings. There is
reference to NSEL having obtained decrees worth more than Rs. 1200 crores and
injunctions against assets of defaulters valued at Rs. 5444.31 crores. The affidavit
further states that FTIL is committed to funding NSEL for purposes of recovery from
defaulters since the occurrence of payment crisis on the exchange platform of NSEL.
295] If the contention of Mr. Chinoy to the effect that there is absolutely no problem
in the functioning of NSEL or that NSEL has the necessary wherewithal, both
financial as well as infrastructural, to effect recoveries from the defaulters, is to be
accepted, then, there was no reason to rely upon contribution from FTIL, made or
proposed to be made at a belated stage. The FTIL resolution dated 28th March 2016,
far from affording any cause to interfere with the impugned order, in fact, lends
support to the reasoning in the impugned order that the NSEL, on its own, lacks
financial as well as infrastructural capacity to affect any recoveries from the
defaulters. The affidavit dated 4th July 2017 and the resolution dated 28th March
2016 is also indicative of the business realities of the situation, which is incidentally63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

yet another ground in the impugned order.” (emphasis in original)
58. The High Court comment on the aforesaid affidavit is not correct. The affidavit proceeds on the
footing that since the activities of NSEL have come to a grinding halt, FTIL would help NSEL to
effect recoveries from defaulters. The affidavit nowhere states that there is no problem in the
functioning of NSEL, or that NSEL has or does not have the necessary wherewithal to effect recovery
from defaulters. Even in the hearing before us, FTIL has submitted an affidavit-cum- undertaking
dated 11.04.2019, stating that it will continue to infuse funds into NSEL so that recovery of dues
from defaulters does not, in any manner, get stymied. We take this affidavit and undertaking on
record, and hold FTIL to this undertaking made before this Court.
59. When it comes to “public interest” as opposed to the “private interest” of investors/traders, who
have not been paid, the amalgamation order dated 12.02.2016 makes interesting reading. The
satisfaction as to public interest is stated in the very beginning of the order as follows:
“Whereas the Central Government is satisfied that to leverage combined assets,
capital and reserves, achieve economy of scale, efficient administration, gainful
settlement of rights and liabilities of stakeholders and creditors and to consolidate
businesses, ensure coordination in policy, it is essential in the public interest…….”
What is stated in the opening is repeated in paragraph 2.14.2 as follows:
“2.14.2 The Central Government also carefully considered the proposal received from
FMC and DEA and was of the considered opinion that to leverage combined assets,
capital and reserves for efficient administration and satisfactory settlement of rights
and liabilities of stakeholders and creditors of NSEL, it would be in essential public
interest to amalgamate NSEL with FTIL.” It will be seen that all the expressions used
in relation to “public interest” have relation only to the businesses of the two
companies that are sought to be amalgamated. What is important to note is that there
is no interest of the general public as opposed to the businesses of the two companies
that are referred to. It is important to notice that the leveraging of combined assets,
capital, and reserves is only to settle liabilities of certain stakeholders and creditors
when the order is read as a whole, and given the fact that the businesses of the two
companies were completely different. So far as achieving economy of scale and
efficient administration is concerned, it is difficult to see how this would apply to the
fact situation in this case where NSEL is admittedly a company which has stopped
functioning as a commodities exchange at least with effect from July, 2013 with no
hope of any revival. Thus, the consolidation of businesses spoken about does not exist
as a matter of fact, as NSEL’s business has come to a grinding halt, as has been
observed by the FMC and the Central Government itself. Each one of these
expressions, when read with the rest of the order, therefore, only shows that the sole
object of the amalgamation order is very far from the high-sounding phrases used in
the opening, and is really only to effect speedy recovery of dues of INR 5600 crore,
which has been referred to in the letter of the FMC to the Secretary, Ministry of
Corporate Affairs, dated 18.08.2014. This would be clear from a reading, in63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

particular, of two paragraphs of the order, namely, paragraphs 2.13.2 and 2.13.3,
which read as follows:
“2.13.2. Thus, it would be observed from above that NSEL is not having the resources,
financial or human, or the organizational capability to successfully recover the dues
to the investors pending for over a year. Further, NSEL is not left with any viable,
sustainable business while FTIL has the necessary resources to facilitate speedy
recovery of dues.
2.13.3. In the above background, a proposal had been received from FMC, vide letter
dated 18-08-
2014, proposing the merger of NSEL with FTIL by the Central Government under the provisions of
Section 396 of the Companies Act, 1956. The proposal has been supported by the Department of
Economic Affairs (DEA), Ministry of Finance, FMC has proposed the merger/amalgamation of
NSEL with FTIL in essential public interest so that the human/financial resources of FTIL are also
directed towards facilitating speedy recovery of dues from the defaulters at NSEL and the FTIL takes
responsibility to resolve the payment crisis at NSEL at the earliest.” 59.1. However, the Central
Government supported this order on the ground that it is made in public interest essentially on
three grounds, which are repeatedly referred to by the impugned judgment. The three grounds as
stated by the impugned judgment are as follows:
“269. …… (a) Restoring/safeguarding public confidence in forward contracts and
exchanges which are an integral and essential part of Indian economy and financial
system, by consolidating the businesses of NSEL and FTIL; (b) Giving effect to
business realities of the case by consolidating the businesses of FTIL and NSEL and
preventing FTIL from distancing itself from NSEL, which is, even otherwise, its alter
ego; and (c) Facilitating NSEL in recovering dues from defaulters by pooling human
and financial resources of FTIL and NSEL. Further, we are also satisfied that each of
these three grounds constitute a facet of public interest in the context of the
provisions in Section 396. ……” 59.2. It is important to note that the first and second
grounds mentioned by the High Court are not contained in the draft order of
amalgamation. Had they been so contained, objections and suggestions would have
been made by all stakeholders, which the Central Government would then have been
bound to consider before passing the final order. However, it was argued on behalf of
the respondents that the first and second grounds are, in reality, inferences drawn
from facts which are already stated in the order and these inferences do not need to
be stated in the draft order. We are afraid that this argument is incorrect inasmuch as
grounds contained in reasons (a) and (b) are important grounds which have a vital
bearing on the amalgamation in question. If these grounds were contained in the
draft order, there is no doubt that the shareholders and creditors of FTIL, and FTIL
itself would have had an opportunity to comment on the same. For example, the
“business realities” of the case are facts known to FTIL; and NSEL, being FTIL’s alter
ego, is the subject matter of dispute in various suits that have been filed and are63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

pending adjudication. FTIL could have responded giving reasons as to why NSEL is
not its alter ego. Also, whether the amalgamation is, in fact, to restore or safeguard
public confidence in forward contracts and exchanges is a subject matter on which
FTIL, its shareholders and creditors, could have commented. Equally, whether
NSEL’s exchange was an essential and integral part of the Indian economy and
financial system, and whether this defunct business could be consolidated so as to
impact the economy are all matters for comment by FTIL and its shareholders and
creditors. For all these reasons, we cannot accede to the respondents’ arguments on
this score. On this ground alone, even assuming that these two grounds obtained and
can be culled out from the final order, not being contained in the draft order, the said
grounds would be in breach of Section 396(3) and (4), and therefore, cannot be
looked at to support the order.
59.3. It is important to note that grounds (a) and (b) are both culled out in answer to
objections raised by FTIL. The precise objection raised and the answer given are
quoted hereinbelow:
“7.2.1. FTIL has challenged the background and reasons for the amalgamation as the
power under section 396 of the Act has been used only in case of Government
companies alone. This argument does not derogate from the scope of the statutory
provisions. The statutory provisions of section 396 of the Act are being invoked in
essential public interest to safeguard the interest of all stakeholders in the captioned
company. The present status and composition of the Boards of FTIL and NSEL have
been noted. However, the fact that the Boards had not acted with an independent
mind to collect information and put the system under a robust technology is borne
out of the simple fact that the Show Cause Notice dated 27-04-2012 issued by the
Department of Consumer Affairs based on analysis of trade data by the then Forward
Market Commission had given an alarming picture of the state of affairs of NSEL.
The public interest driving the merger are set out in the business realities of the case,
it is noted from the facts of the case and the recommendations of FMC as well as its
order dated 17-12-2013 which throw ample light to the grave shattering of the public
confidence and the purpose of establishing commodity exchange has been defeated.”
xxx xxx xxx “7.2.6. FTIL and NSEL have distinct and separate objects and nature of
operations and completely disparate and unconnected objects, and hence there is no
synergy, efficient administration, consolidation of business or co-ordination in policy
to be gained by the forced amalgamation; the argument runs contrary to the concept
of merger which essentially means that two or more separate entities are getting
merged to achieve the objectives of amalgamation. In the instant case, amalgamation
is targeted to achieve its stated objects, essentially in public interest. By all intents
and purposes, the way both the companies were being managed, owned and
controlled, NSEL is the alter ego of FTIL and thus, the two companies have been
practically one entity. All stakeholders were also looking at them as one entity. The
amalgamation u/s. 396 of the Act only formalizes this practical reality in essential
public interest.” xxx xxx xxx “7.2.8. The FTIL has questioned the jurisdiction of the63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

Central Government to decide on the question of fraud and claimed that it has to be
proved beyond reasonable doubt by adducing necessary particulars; the Central
Government is invoking section 396 of the Act in essential public interest for the
merger of NSEL, which is an almost wholly-owned subsidiary of FTIL. The merger is
not an adjudication on the alleged fraud. The merger is targeted to achieve its stated
objectives for long term sustainability in the best interest of the stakeholders.”
(emphasis in original) It will be noticed that the objection raised in paragraph 7.2.1 is
that Section 396 can be used in the case of Government companies alone, whereas
the answer given is that this cannot be so, given the business realities of the case and
the FMC order of 17.12.2013 “which throw ample light to the grave shattering of
public confidence and the purpose of establishing Commodity Exchange has been
defeated”.
First and foremost, what is important to notice is that the “business realities” of the case are what is
contained in “the recommendations of the FMC”. We have seen that these recommendations are in
the form of a letter dated 18.08.2014, in which the “business reality” is the fact that dues of INR
5600 crore have to be paid, and that NSEL does not have the wherewithal to do so. Thus, its parent
company’s financial resources ought to be used to effect such payment. This “business reality”,
therefore, speaks only of the private interest of the investors/traders who have been allegedly duped
(which fact will only be established in suits filed by them in 2014), and nothing beyond (which
would show some vestige of public interest). Equally, the grave shattering of public confidence and
purpose of establishing commodity exchanges having been defeated, according to the Central
Government, is a gloss on the FMC order dated 17.12.2013. If this were so, one would have expected
a resuscitation or revival of the commodities exchange of NSEL, which could have been achieved by
takeover of its management. It is difficult to imagine that grave shattering of public confidence by
the permanent shutting down of the commodities exchange of the NSEL would be remedied only by
facilitating the paying of dues to certain allegedly duped investors/traders, which fact will be proved
or disproved in suits filed by them which are pending adjudication in the Bombay High Court. In
any case, this reason is wholly irrelevant as an answer to the objection raised by FTIL which, as we
have seen, is an objection stating that the Section applies to Government companies alone. Also, had
FTIL made no such objection, no such answer would have been forthcoming. As far as paragraphs
7.2.6 and 7.2.8 of the order are concerned, what is admitted in the order itself, is that there is no
“adjudication” on the “fraud” in the facts of the present case, and thus, not an exercise of lifting of
the corporate veil of the pre-amalgamation companies. The amalgamation order contradicts itself by
then stating that NSEL is the alter ego of FTIL, and thus, the two companies are practically one
entity. In any event, these paragraphs do not indicate as to how the ‘alter ego’ argument impacts
public interest. For all these reasons, therefore, neither reason (a) nor reason (b) ought to detain us
any further. Reason (c) is, therefore, the only reason that really remains, as is contained in the letter
of 18.08.2014 by the FMC to the Central Government. We have already seen that this reason, by
itself, is the protection of the private interest of a group of investors/traders, as distinct from public
interest.
59.4. It is important to note that under Section 396(4)(b), the Central Government may, after
considering suggestions and objections from the stakeholders mentioned, make modifications in the63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

draft order as may seem to it desirable in the light of such suggestions and objections. No
modification has been made in the body of the Central Government order as finally made. If the
Central Government had actually considered that each of these three reasons impact public interest,
it would have explicitly said so after suggestions and objections were made by the various
stakeholders. The fact that the Central Government has not amended the body of the final order is of
great significance – it is only the original reasons given in the draft order that continue as such in
the final order which, as we have seen, are not in furtherance of public interest at all. Reasons (a)
and (b), part of which is culled out from answers to objections and suggestions given in the final
order, is only given separately by the Central Government after the amalgamation order to show that
the principles of natural justice as laid down by sub-section (4) of Section 396 have, in fact, been
followed. This becomes clear from paragraphs 6.3 and 7 of the final order, which read as follows:
“6.3. The Central Government received in writing and through email various
objections / suggestions from various classes of stakeholders including the
shareholders, creditors, and all other interested parties claiming that monies are
recoverable from the proceedings arising out of the business of the dissolved
company.
7. Dealing with objections, suggestions and submissions of FTIL, NSEL and other
parties – The Parties herein have made various objections, suggestions and
submissions on the proposed amalgamation u/s. 396 of the Act on the order dated
21-
10-2014 in Draft form issued by the Central Government. The said objections, suggestions and
submissions were made during the course of hearing and written submissions (physically and
electronically) received by the Central Government on various dates. The said objections,
suggestions and submissions made by each of the parties are dealt in the manner herein under.”
59.5. So far, we have gone by the Central Government order as it stands. The Bombay High Court, in
stating reasons (a), (b), and (c) as grounds of public interest, has gone much further than even the
answer given to the objections that are contained in the order itself. “Restoring/safeguarding public
confidence in forward contracts and exchanges, which are an integral and essential part of the
Indian economy and financial system, by consolidating the businesses of NSEL and FTIL,” is not
contained in the answer given to objections in the order. First and foremost, restoring public
confidence is no part of the order. What is mentioned is only the fact that public confidence has
been shattered, as is reflected by the FMC order dated 17.12.2013. Secondly, the entire expression,
“which are an integral and essential part of Indian economy and financial system, by consolidating
the businesses of NSEL and FTIL” is no part even of this answer given, but a gloss given by the High
Court itself relatable to this answer. Similarly, when it comes to reason (b), “giving effect to business
realities of the case” contained in the answer to objections does not contain “by consolidating the
businesses of FTIL and NSEL”, nor does it contain “and preventing FTIL from distancing itself from
NSEL, which is, even otherwise, its alter ego”. On the contrary, the High Court itself mentions, in
paragraph 355, that “this is also not a case where the Central Government has, in fact, lifted the
corporate veil, despite the alleged non-existence of the circumstances justifying lifting of such
corporate veil”, and further, “this is not a case where the Central Government has lifted the63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

corporate veil and sought to apportion any liability upon either NSEL or FTIL”. For all these
reasons, we find that no reasonable body of persons properly instructed in law could possibly arrive
at the conclusion that the impugned order has been made in public interest.
60. The learned Senior Advocates appearing on behalf of the respondents has placed great reliance
on the judgment in Ganesh Bank (supra). In this judgment, the Appellant Bank was amalgamated
with Federal Bank under Section 45 of the Banking Regulation Act, 1949. Federal Bank was selected
from out of several other banks by the Reserve Bank of India as its offer to amalgamate with the
Appellant Bank was unconditional, Federal Bank undertaking to make full payment to depositors.
61. The judgment in Ganesh Bank (supra) was faced with the amalgamation of the Appellant Bank
after a moratorium had been imposed on it as it was found that its position was very weak, having
incurred huge losses in the financial year 2004-05. Section 45 of the Banking Regulation Act reads
as follows:
“45. Power of Reserve Bank to apply to Central Government for suspension of
business by a banking company and to prepare scheme of reconstitution or
amalgamation.—(1) Notwithstanding anything contained in the foregoing provisions
of this Part or in any other law or any agreement or other instrument, for the time
being in force, where it appears to the Reserve Bank that there is good reason so to
do, the Reserve Bank may apply to the Central Government for an order of
moratorium in respect of a banking company.
xxx xxx xxx (4) During the period of moratorium, if the Reserve Bank is satisfied
that—
(a) in the public interest; or
(b) in the interests of the depositors; or
(c) in order to secure the proper management of the banking company; or
(d) in the interests of the banking system of the country as a whole,— it is necessary
so to do, the Reserve Bank may prepare a scheme—
(i) for the reconstruction of the banking company, or
(ii) for the amalgamation of the banking company with any other banking institution
(in this section referred to as “the transferee bank”).
xxx xxx xxx” It is important to note that unlike Section 396 of the Companies Act, the satisfaction of
the Reserve Bank of India can be on any one of four grounds. Such satisfaction may be in the public
interest or in the interest of depositors. This point is, in fact, highlighted in paragraph 34 of the
judgment as follows:63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

“34. The phrase “good reasons” in sub-section (1) of Section 45 is a term of wide
amplitude and it will not be correct to restrict it only to the actions mentioned under
sub-section (2) of Section 45 of the Act as is contended by the appellants. The
provision is concerned with preparing a scheme of reconstruction or amalgamation
which would become necessary where RBI is satisfied about the existence of any of
the four grounds mentioned in Section 45(4). Apart from public interest and the
interest of the banking system, which are provided in clauses (a) and (d) thereof,
Section 45(4) provides for the necessary action in the interest of the depositors or
with a view to secure proper management of the Bank which are clauses (b) and (c) in
that sub- section. Precursor to the framing of the scheme is the imposition of the
moratorium which is provided in sub- sections (1) and (2) of Section 45. Existence of
court proceedings, mentioned in Section 45(2), would certainly be one of the good
reasons to impose moratorium, but that certainly cannot be the only one.
Considering that object of the Act is protection of the interest of the depositors, such
an interpretation of the concept of “good reasons” will have to be adopted, and not a
narrow one.” The judgment then goes on to state:
“39. Now, as far as the first two questions of non- consideration of reconstruction and
proposing merger with Federal Bank are concerned, RBI has noted that the Bank was
in difficulties from 1990 and particularly from December 2003 when it was placed
under monthly monitoring. RBI in its application for moratorium to the Central
Government dated 4-1-2006 had clearly stated that during the discussion with the
appellant Bank, major shareholders and Directors had shown total reluctance to
merge into the stronger bank. In view thereof, it was imperative that immediate
arrangement to protect the interest of the depositors was to be made through its
merger with a bank under Section 45 of the Act. RBI had, therefore, made an effort
and called upon the appellant Bank, that if possible, to explore the possibility of
merger with another stronger bank. It had also made an effort to impress that there
should be infusion of fresh capital. That was not coming. There could be a
reconstruction by bringing in more money or by narrowing the size of the appellant
Bank which did not appear to be feasible. The only option left was that of
amalgamation.” Thus, two features of Ganesh Bank (supra) distinguish the said case
from the facts of the present case. First, that under Section 45 of the Banking
Regulation Act, the interest of the depositors is to be looked at; and it was this reason
that led to the amalgamation. Secondly, this Court found that after exploring other
options, the only option left was that of amalgamation.
62. In point of fact, the contrast between Section 45(4) of the Banking Regulation Act and Section
396 of the Companies Act becomes important. Under Section 45(4)(b) and (c) of the Banking
Regulation Act, the satisfaction of the Reserve Bank of India for preparing a scheme of
amalgamation can be in the interest of the depositors of a particular bank or in order to secure the
proper management of a particular banking company. This must be contrasted with clauses (a) and
(d) of Section 45(4), which speak of public interest and the interest of the banking system of the
country as a whole. This judgment, on facts, merged a financially weak bank with a financially63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

strong bank in the interest of the depositors of the financially weak bank. It is important to note that
the business of the two merged entities is the same, as also Federal Bank’s (i.e., the strong bank’s)
willingness to merge, being an unconditional offer to merge because it felt that post merger, it could
have a significant presence in western Maharashtra and the Belgaum area of Karnataka, and could
augment its credit disbursal to the agricultural sector. Also, since the interest of depositors is a
separate head, based upon which the Reserve Bank of India may amalgamate two banking
companies, it is clear that this reason alone will not go to public interest, which is a separate head
contained in Section 45(4). It is in this context that the observation contained in paragraph 44 is
made, namely:
“44. Under Section 45 of the Act, the primary consideration is public interest. There
is an underlying object of acting swiftly and decisively to protect the interests of
depositors and ensure public confidence in the banking system. The emergent
situation which warrants action with expedition cannot be lost sight of while deciding
the legality of the action.” As we have already seen, the “emergent situation” which
obtained in 2013 was no longer there in 2016 when the final order of amalgamation
was passed in the present case.
63. Valiant attempts have been made by counsel in the High Court as well as counsel in this Court to
support the order on grounds which are outside the order, stating that such grounds make it clear
that in any case, the Government order has been made in public interest. The celebrated passage in
Mohinder Singh Gill (supra) states that:
“8. The second equally relevant matter is that when a statutory functionary makes an
order based on certain grounds, its validity must be judged by the reasons so
mentioned and cannot be supplemented by fresh reasons in the shape of affidavit or
otherwise. Otherwise, an order bad in the beginning may, by the time it comes to
Court on account of a challenge, get validated by additional grounds later brought
out. We may here draw attention to the observations of Bose, J. in Gordhandas
Bhanji [Commr. of Police, Bombay v. Gordhandas Bhanji, AIR 1952 SC 16] :
“Public orders, publicly made, in exercise of a statutory authority cannot be
construed in the light of explanations subsequently given by the officer making the
order of what he meant, or of what was in his mind, or what he intended to do. Public
orders made by public authorities are meant to have public effect and are intended to
affect the actings and conduct of those to whom they are addressed and must be
construed objectively with reference to the language used in the order itself.” Orders
are not like old wine becoming better as they grow older.” We are of the view that it is
the Central Government that has to be “satisfied” that its order is in public interest
and such “satisfaction” must, therefore, be of the Central Government itself and
must, therefore, appear from the order itself. All these valiant attempts made to
sustain such order must be rejected.63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

64. However, learned Senior Advocates on behalf of the respondents have cited Chairman, All India
Railway Recruitment Board and Anr. v. K. Shyam Kumar and Ors., (2010) 6 SCC 614, which,
according to them, renders the judgment in Mohinder Singh Gill (supra) inapplicable where larger
public interest is involved. In this judgment, Mohinder Singh Gill (supra) was distinguished thus:
“44. We are also of the view that the High Court has committed a grave error in
taking the view that the order of the Board could be judged only on the basis of the
reasons stated in the impugned order based on the report of Vigilance and not on the
subsequent materials furnished by CBI. Possibly, the High Court had in mind the
Constitution Bench judgment of this Court in Mohinder Singh Gill v. Chief Election
Commr. [(1978) 1 SCC 405]
45. We are of the view that the decision-maker can always rely upon subsequent
materials to support the decision already taken when larger public interest is
involved. This Court in Madhyamic Shiksha Mandal, M.P. v. Abhilash Shiksha Prasar
Samiti [(1998) 9 SCC 236] found no irregularity in placing reliance on a subsequent
report to sustain the cancellation of the examination conducted where there were
serious allegations of mass copying. The principle laid down in Mohinder Singh Gill
case [(1978) 1 SCC 405] is not applicable where larger public interest is involved and
in such situations, additional grounds can be looked into to examine the validity of an
order. The finding recorded by the High Court that the report of CBI cannot be
looked into to examine the validity of the order dated 4-6-2004, cannot be
sustained.” It will be seen that there is no broad proposition that the case of
Mohinder Singh Gill (supra) will not apply where larger public interest is involved. It
is only subsequent materials, i.e., materials in the form of facts that have taken place
after the order in question is passed, that can be looked at in the larger public
interest, in order to support an administrative order. To the same effect is the
judgment in PRP Exports and Ors. v. Chief Secretary, Government of Tamil Nadu
and Ors., (2014) 13 SCC 692 [at paragraph 8]. It is nobody’s case that there are any
materials or facts subsequent to the passing of the final order of the Central
Government that have impacted the public interest, and which, therefore, need to be
looked at. On facts, therefore, the two judgments cited on behalf of the respondents
have no application. Thus, it is clear that no reasonable body of persons properly
instructed in law could possibly hold, on the facts of this case, that compulsory
amalgamation between FTIL and NSEL would be in public interest.
65. Section 396(3) speaks of a shareholder’s or a creditor’s interest in or rights against the company
resulting from an amalgamation order. Such “interest in” or “rights against” obviously refers to real
and substantive rights, as opposed to rights that are only in form. A shareholder or creditor gets
effected by an amalgamation order if the value of his share gets depleted as a result of the
amalgamation and if dividends that have been paid to him are likely to come down as a result of the
amalgamation. Likewise, a creditor of a solvent company is directly effected by an amalgamation by
which the amount loaned by such creditor becomes, as a result of the amalgamation, less likely to be
paid back in time, than if the amalgamation did not take place. Such rights and interests of members63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

and creditors are substantive rights which, when effected by the amalgamation, lead to
compensation having to be paid. Every shareholder of a company and indeed, every creditor of a
company, is concerned only with the “economic value” of his share or the loan granted to a
company, as the case may be. The moment the share value, in real terms, is likely to dip, and/or
loans granted are likely not to be repaid in time or at all as a result of an amalgamation, such
members or creditors of the amalgamating company are equally entitled to be compensated for this
economic loss as are the members and creditors of the amalgamated company, depending on the
facts of each case. A reasonable construction must be given to Section 396. Also, the suggested
construction by the respondents, as has been accepted by the impugned judgment, operates harshly
and ridiculously, and being opposed to justice and reason, cannot possibly be adopted by this Court.
It is clear that Section 396(3) refers to the economic loss that is to be borne by shareholders and
members of both companies.
66. Thus, it is clear from a reading of Section 396(3), (3A), and (4) (aa) that every member or
creditor of each of the companies before amalgamation shall have, as nearly as may be, the same
interest in or rights against the company resulting from the amalgamation as he had in the original
company. To the extent to which the interest or rights of such member or creditor are less than his
interest or rights against the original company, post amalgamation, he shall be entitled to
compensation which is to be assessed. Post assessment, if such member or creditor is aggrieved, he
may prefer an appeal to the appellate authority under sub-section (3A). Under sub-section (4)(aa),
no order of amalgamation can be made unless the time for preferring an appeal under sub-section
(3A) has expired, or where any such appeal has been preferred, the appeal has been finally disposed
of.
67. The learned counsel on behalf of the appellant has argued that the assessment order dated
01.04.2015, passed by the Joint Director (Accounts), does not reflect any compensation in favour of
the shareholders or creditors of FTIL. According to the learned counsel, it is clear that if a company
with low net worth (NSEL) is amalgamated with a company with high positive net worth (FTIL),
both the shareholders and the creditors of FTIL will be directly impacted as the economic value of
the shares will plummet, and the creditors of FTIL, which is a positive net worth company, may have
to wait for a long time before recovery of debts owed to them once the company is amalgamated
with the negative net worth company. In short, the creditors of FTIL will be put on par with the
creditors of NSEL, which will result in the creditors of FTIL either being paid back their debts much
later in point of time, or not at all. To this argument, the answer of the Union of India, which has
found favour with the Division Bench of the Bombay High Court, is that “economic value” forms no
part of Section 396. So long as the shareholders of FTIL continued to have the same number of
shares, it matters not whether their share values plummet post amalgamation.
68. In Bacha F. Guzdar (supra), this Court held that though a shareholder acquires no right in the
assets of a company as the company itself is the owner of such assets, yet a shareholder certainly has
the right to dividends and the right to participate in the assets of the company which would be left
over after winding up. The Court held:63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

“The true position of a shareholder is that on buying shares an investor becomes
entitled to participate in the profits of the company in which he holds the shares if
and when the company declares, subject to the Articles of Association, that the profits
or any portion thereof should be distributed by way of dividends among the
shareholders. He has undoubtedly a further right to participate in the assets of the
company which would be left over after winding up but not in the assets as a whole as
Lord Anderson puts it.” (at p. 882) (emphasis in original)
69. In Life Insurance Corporation of India v. Escorts Ltd. and Ors., (1986) 1 SCC 264, this Court
dealt generally with the rights of shareholders as follows:
“84. On an overall view of the several statutory provisions and judicial precedents to
which we have referred we find that a shareholder has an undoubted interest in a
company, an interest which is represented by his shareholding. Share is movable
property, with all the attributes of such property. The rights of a shareholder are (i) to
elect directors and thus to participate in the management through them; (ii) to vote
on resolutions at meetings of the company; (iii) to enjoy the profits of the company in
the shape of dividends; (iv) to apply to the court for relief in the case of oppression;
(v) to apply to the court for relief in the case of mismanagement; (vi) to apply to the
court for winding up of the company; (vii) to share in the surplus on winding up. ……”
On the facts of the present case, we are directly concerned with points
(iii) and (vii). It has been argued that the profits of the company post-
amalgamation will obviously come down, and dividends payable to shareholders will consequently
either come down or be wiped out if the low net worth of NSEL is taken into account post
amalgamation, together with potential liabilities of the amalgamated company, which may have to
be paid in the near future. Secondly, if the amalgamated company is wound up, the amount that is
payable to the shareholders post-amalgamation will be much less, if at all anything is to be paid,
than pre-amalgamation.
70. In fact, in Commissioner of Income Tax (Central) Calcutta v. Standard Vacuum Oil Co., [1966] 2
SCR 367, this Court held:
“ …… A share is not a sum of money: it represents an interest measured by a sum of
money and made up of diverse rights contained in the contract evidenced by the
articles of association of the Company. ……” (at p. 374)
71. In Miheer H. Mafatlal v. Mafatlal Industries Ltd., (1997) 1 SCC 579, in the context of a voluntary
amalgamation made under Sections 391 to 394 of the Companies Act, this Court went into share
valuation. This Court held:63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

“40. …… It must at once be stated that valuation of shares is a technical and complex
problem which can be appropriately left to the consideration of experts in the field of
accountancy. Pennington in his Principles of Company Law mentions four factors
which had to be kept in mind in the valuation of shares:
“(1) Capital Cover, (2) Yield, (3) Earning Capacity, and (4) Marketability.
For arriving at the fair value of share, three well-known methods are applied:
(1) The manageable profit-basis method (the Earning Per Share Method) (2) The
networth method or the break value method, and (3) The market value method.”
What is clear from the various methods of valuation of shares, when it comes to such
valuation qua the transferor and transferee company, is that the market value
method is one method in which shares can be valued so that their equivalent can then
be provided for in the amalgamated company. This would be nothing other than what
those shares were worth in the market on a particular day or an average taken within
a certain period. What is important to note is that the market value of shares is
market value of shares reflective of their economic value, being an interest measured
by a sum of money, is not something that is completely alien to determining the
rights of or interest of a shareholder in the transferor or transferee company, as the
case may be.
72. In fact, the Government order dated 12.02.2016 itself reflects the net worth of NSEL as INR 8.86
crore from its balance sheet dated 31.03.2015, despite its capital being INR 60 crore, inasmuch as
the total reserve and surplus is a negative figure of INR 51.54 crore. As against this, FTIL’s balance
sheet, as on 31.03.2015, discloses that for the same year, FTIL’s net worth is INR 2779.94 crore.
Also, FTIL has been paying dividends to its shareholders ranging from 1000% to 250% for the years
2007-2008 till 2015-2016. On the other hand, NSEL has never paid a single dividend ever since its
inception. Post amalgamation, therefore, dividend payable to the shareholders of FTIL is bound to
come down. Correspondingly, the ‘marketable value’ of such shares will also fall.
73. The impugned Division Bench judgment has incorrectly held that the economic value of shares
cannot be taken into account. In fact, from the Director’s Report of NSEL dated 20.07.2015, it is
specifically stated under the caption, “(vi) civil suits / complaints / writs / public interest litigation”
that:
“xxx xxx xxx
c) The Company received a legal opinion to the effect that the Company is not liable
for payment under the provisions of SGF in the bye-laws. Further in case of e-Series
contract related transactions, no major infirmity in underlying physical stock was
observed.63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

Therefore, at this stage and in the opinion of the Management of the Company, relying upon the
legal advices, and as per the provisions of bye-laws of the exchange there are no direct ascertainable
financial claims against the company. The Company may be exposed to liabilities in case of any
adverse outcome of these investigations / enquiries or legal cases or any other investigations /
enquires or suits which may arise at a later date.” This is further clarified in the consolidated
financial statement made for the financial year 2014-2015 as follows:
“Risk of un-identified financial irregularities In view of the specific scope of the
forensic audits and the limitations in the forensic audits and investigations, there is
inherent a risk that material errors, fraud and other illegal acts may exist that could
remain undetected.
Risk of adverse outcome of investigation/enquiry by law enforcement agencies
Several agencies such as the Police (EOW), Ministry of Corporate Affairs (MCrA),
Enforcement Directorate (ED), CBI and the Income Tax Department etc. are
currently investigating / enquiring the extent of alleged irregularities and any breach
of law. The matters are also sub judice before various forums including the Hon’ble
Mumbai High Court. The Company may be exposed to liabilities in case of any
adverse outcome of these investigations or any other investigations which may arise
at a later date.” From the Director’s Report and consolidated financial statements of
NSEL, it becomes clear that the company may be exposed to liabilities in case of any
adverse outcome in any of the proceedings that may be pending, as a result of which,
it may have to pay back the whole or some part of the INR 5600 crore owed to the
alleged investors/traders by the 24 defaulters who are members of NSEL. This would
certainly impact the ‘economic value’ of shares held in FTIL as this is one factor that
would, post amalgamation, depress the market value of shares held by such
shareholder, and would also impact the dividend payable on such shares post
amalgamation.
74. The impugned judgment has also held that no material was produced before the Court to show
that share prices would in fact plummet post-amalgamation. This is despite the fact that the
impugned judgment itself refers to the fact that since the publication of the draft order on
21.10.2014, the share value which was INR 211.10, dropped to INR 174.55 ten days later. The
Division Bench then goes on to state that it is not possible to hold that any case of serious erosion in
economic value has at all been made out, inasmuch as by 21.10.2014, when the draft order of
amalgamation was made available to companies, the news of collapse of NSEL’s exchange was
already in public domain. This is wholly incorrect for the reason that the news of collapse took place
in July, 2014, i.e., over two months before the publication of the draft order. It is well known that
the stock market is extremely sensitive to the slightest event that may render a company less
profitable. Over two months is too long a period to relate a share value of INR 211.10 drastically
falling to INR 174.55. On the other hand, it is obvious that the publication of the draft order on
21.10.2014 had the impact of the share price reducing by a substantial amount, ten days later. In
fact, a reference to the share prices of NSEL furnished by the learned Additional Solicitor General
makes it clear that the moment the final amalgamation order dated 12.02.2016 was publicised, the63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

share price fell from INR 89.90 on 12.02.2016 to INR 73.90 on 24.02.2016 and further to INR 73.10
on 29.02.2016. Incidentally, the High Court realised this, and finally incorrectly concludes, “there is
thus substantial compliance with the provisions of Section 396(3).” Given the fact that the
assessment order dated 01.04.2015 did not provide any compensation to either the shareholders or
creditors of FTIL for the economic loss caused by the amalgamation in breach of Section 396(3), it is
clear that an important condition precedent to the passing of the final amalgamation order was not
met. On this ground also, therefore, the final amalgamation order has to be held to be ultra vires
Section 396 of the Companies Act, and, being arbitrary and unreasonable, violative of Article 14 of
the Constitution of India.
75. However, the learned Senior Advocates for the respondents have argued that an order of nil
compensation is equally an order that is passed under Section 396(3) which could have been
appealed against but was not appealed against. For this reason, therefore, it is not correct to state
that the condition precedent mentioned in Section 396(4)(aa) has not been fulfilled. It will be
noticed that the language used in the appeal provision, i.e. Section 396(3A), is “any person aggrieved
by any assessment of compensation made by the prescribed authority under sub-section (3) may……
appeal to the Tribunal, and thereupon the assessment of the compensation shall be made by the
Tribunal.” The pre-requisites for the application of sub- section (3A) are that a person first be
aggrieved by an “assessment of compensation” “made” by the prescribed authority. Where no
assessment of compensation whatsoever is made by the prescribed authority (and on the facts here,
the prescribed authority has not, in fact, stated that for the reasons given by it, compensation
awarded to FTIL, its shareholders and creditors is nil), no person can be aggrieved by an order
which does not assess any compensation, which may be interfered with by the Appellate Tribunal
which must then assess the compensation for itself. The statute clearly entitles such shareholders
and creditors to have compensation assessed first by the prescribed authority and then by the
appellate authority. This Court, in Institute of Chartered Accountants of India v. L.K. Ratna and
Ors., [1986] 3 SCR 1049, held that the defect in observing the rules of natural justice in the trial
administrative body cannot be cured by observing such rules of natural justice in the appellate body.
It was held:
“It is then urged by learned counsel for the appellant that the provision of an appeal
under Section 22-A of the Act is a complete safeguard against any insufficiency in the
original proceeding before the Council, and it is not mandatory that the member
should be heard by the Council before it proceeds to record its finding. Section 22-A
of the Act entitles a member to prefer an appeal to the High Court against an order of
the Council imposing a penalty under Section 21(4) of the Act. It is pointed out that
no limitation has been imposed on the scope of the appeal, and that an appellant is
entitled to urge before the High Court every ground which was available to him
before the Council. Any insufficiency, it is said, can be cured by resort to such appeal.
Learned counsel apparently has in mind the view taken in some cases that an appeal
provides an adequate remedy for a defect in procedure during the original
proceeding. Some of those cases as mentioned in Sir William Wade’s erudite and
classic work on “Administrative Law” (5th Edn.). But as that learned author observes
(at p. 487), “in principle there ought to be an observance of natural justice equally at63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

both stages”, and “if natural justice is violated at the first stage, the right of appeal is
not so much a true right of appeal as a corrected initial hearing:
instead of fair trial followed by appeal, the procedure is reduced to unfair trial
followed by fair trial.” And he makes reference to the observations of Megarry, J. in
Leary v. National Union of Vehicle Builders [(1971) 1 Ch. 34, 49]. Treating with
another aspect of the point, that learned Judge said:
“If one accepts the contention that a defect of natural justice in the trial body can be
cured by the presence of natural justice in the appellate body, this has the result of
depriving the member of his right of appeal from the expelling body. If the rules and
the law combine to give the member the right to a fair trial and the right of appeal,
why should he be told that he ought to be satisfied with an unjust trial and a fair
appeal? Even if the appeal is treated as a hearing de novo, the member is being
stripped of his right to appeal to another body from the effective decision to expel
him. I cannot think that natural justice is satisfied by a process whereby an unfair
trial, though not resulting in a valid expulsion, will nevertheless have the effect of
depriving the member of his right of appeal when a valid decision to expel him is
subsequently made. Such a deprivation would be a powerful result to be achieved by
what in law is a mere nullity; and it is no mere triviality that might be justified on the
ground that natural justice does not mean perfect justice. As a general rule, at all
events, I hold that a failure of natural justice in the trial body cannot be cured by a
sufficiency of natural justice in an appellate body.” The view taken by Megarry, J. was
followed by the Ontario High Court in Canada in Re Cardinal and Board of
Commissioners of Police of City of Cornwall, [(1974) 42 D.L.R. (3d) 323]. The
Supreme Court of New Zealand was similarly inclined in Wislang v.
Medical Practitioners Disciplinary Committee, [(1974) 1 N.Z.L.R. 29] and so was the
Court of Appeal of New Zealand in Reid v. Rowley [(1977) 2 N.Z.L.R. 472].” (at pp.
1065-1066) This judgment was the subject matter of comment in Union Carbide
Corporation v. Union of India, [1991] Supp (1) SCR 251, where this Court held,
following the judgment in Charan Lal Sahu v. Union of India, (1990) 1 SCC 613, that
non-compliance with the obligation to issue notices to persons effected by the Bhopal
gas leak did not, for this reason alone, vitiate the settlement that was entered into
with Union Carbide by the Government on their behalf. This Court, in passing,
commented that the principle laid down in Leary v. National Union of Vehicle
Builders, [1971] Ch. 34 might perhaps be too broad a generalisation, except in cases
involving public interest. This was an observation made in answer to an argument by
Shri Shanti Bhushan, stating that a defect of natural justice always goes to the root of
the matter. Ultimately, given the fact that the settlement fund was held to be
sufficient to meet the needs of just compensation to the victims of the Bhopal gas leak
tragedy, it was held that the grievance on the score of not hearing the victims first
would not really survive. However, what is of fundamental importance is the fact that
in the present situation, a clear statutory right is given to every member or creditor63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

who shall be entitled to an assessment of compensation, first by the prescribed
authority and then, a right of appeal to the Appellate Tribunal. In such cases,
therefore, the orders of “non-assessment” by the prescribed authority can more
appropriately be challenged in judicial review proceedings, in which the High Court,
acting under Article 226 of the Constitution of India can, if an infraction of Section
396(3) is found, send the matter back to the prescribed authority to determine
compensation after which the right of appeal under sub-
section (3A) of Section 396 would then follow. In fact, in Writ Petition 2743 of 2014,
which challenged both the draft order and the final order of amalgamation, the
appellant took out a chamber summons for amendment of its writ petition to
challenge the order of assessment of compensation, dated 01.04.2015, which
amendment was allowed vide order dated 16.02.2016. The order of “non-assessment”
of compensation has thus been challenged by FTIL in proceedings under Article 226
of the Constitution of India. Even otherwise, this is a case where there is complete
non-application of mind by the authority assessing compensation to the rights and
interests which the shareholders and creditors of FTIL have and which are referred to
in Section 396(3) of the Act. This being the case, it is clear that Section 396(3) has not
been followed either in letter or in spirit.
76. In conclusion, though other wide-ranging arguments were made with respect to the validity of
the Central Government amalgamation order, we have not addressed the same as we have held that
the order dated 12.02.2016 is ultra vires Section 396 of the Companies Act, and violative of Article
14 of the Constitution of India for the reasons stated by us hereinabove. The appeals are accordingly
allowed, and the impugned judgment of the Bombay High Court is set aside. The writ petition is
disposed of in light of this judgment.
                                                     …………………………J.
                                                     (R.F. Nariman)
                                                 …………………………J.
New Delhi                                        (Vineet Saran)
April 30, 2019.63 Moons Technologies Ltd (Formerly ... vs Union Of India on 30 April, 2019

