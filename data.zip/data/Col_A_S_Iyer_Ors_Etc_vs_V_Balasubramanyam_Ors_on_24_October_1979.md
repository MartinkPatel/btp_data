Col. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24
October, 1979
Equivalent citations: 1980 AIR 452, 1980 SCR (1)1036, AIR 1980 SUPREME
COURT 452, 1980 (1) SCC 634, 1980 LAB. I. C. 231, 1980 (1) SCR 1036, (1980)
SCR 1 (SC), 1980 (1) SCC 654, 1980 SCC (L&S) 145, (1980) 2 LAB LN 1, (1980)
1 SERVLR 89, (1980) 1 LABLJ 441, (1980) 2 SCJ 54
Author: V.R. Krishnaiyer
Bench: V.R. Krishnaiyer, Y.V. Chandrachud, N.L. Untwalia, P.N. Shingal, A.D.
Koshal
           PETITIONER:
COL. A. S. IYER & ORS. ETC.
        Vs.
RESPONDENT:
V. BALASUBRAMANYAM & ORS.
DATE OF JUDGMENT24/10/1979
BENCH:
KRISHNAIYER, V.R.
BENCH:
KRISHNAIYER, V.R.
CHANDRACHUD, Y.V. ((CJ)
UNTWALIA, N.L.
SHINGAL, P.N.
KOSHAL, A.D.
CITATION:
 1980 AIR  452            1980 SCR  (1)1036
 1980 SCC  (1) 634
 CITATOR INFO :
 E          1987 SC2359  (6,16)
 D          1989 SC1624  (11)
ACT:
     Survey of  India (Recruitment  from Corps  of  Engineer
Officers) Rules 1950 -Service consisted of Army and Civilian
Officers-Seniority and  promotional opportunities  for  Army
Officers different  from Civilian Officers-Rule if violative
of Articles 14 and 16 of the Constitution.Col. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

HEADNOTE:
     Rule 5  of the  Survey of India (Recruitment from Corps
of Engineer  Officers) Rules  1950 provided  that  on  first
appointment an  officer would  be in  the  grade  of  Deputy
Superintending Surveyor  in Class I Service of the Survey of
India and  that seniority of military officers inter se will
remain the  same as  in the  Army. Sub-rule  5 of  this rule
provided  that  among  those  allotted  to  the  same  year,
military officers  would rank  senior to  directly recruited
civilian officers. Rule 11 of the Rules which dealt with the
method of  recruitment to  Survey of  India Class  I Service
provided that  all recruitments  to the  Cadre would  be 50%
from the Corps of Engineer Officers, 25% from promoted Class
II  civilian  officers  and  25%  from  direct  recruits  by
competitive examination  through the  Union  Public  Service
Commission. These  Rules were  amended in  1960 and 1970 but
the provision  relating to  military engineers  remained the
same as in the 1950 Rules.
     In a  writ  petition  filed  in  the  High  Court,  the
civilian  officers  of  the  service  consisting  of  direct
recruits and Class II promotees impugned the validity of the
1950 Rules  on the  ground that seniority prescriptions were
based on  irrelevant criteria  and that  discrimination  was
writ large in the impugned provisions.
     The  High  Court,  accepting  the  contentions  of  the
civilian officers,  struck down  certain rules  of the  1950
Rules  as   violative  of   Articles  14   and  16   of  the
Constitution. The  High Court  did not accept the contention
of the  Government that the nature and character of the work
done by  the Survey  of India was essentially connected with
defence purposes because the work done by the Department for
the Army  was done along with several other services carried
on by it, namely, with the development projects, preparation
of maps  for various  Ministries of  the Central  and  State
Governments, public  sector undertakings and other agencies;
assuming that  the work  was related  to  defence  purposes,
civilian officers  were employed by the Department to do the
same work  and during  emergencies, civilian  officers  were
called upon  to serve  in border  areas. The  Department had
civilian budget.  For these  reasons the  High Court came to
the  conclusion   that  there   was  no  ground  to  justify
classification made  under the  impugned Rules  between  the
Army officers  and civilian  officers because  the  recruits
from the  army could not be said to be better qualified than
the  civilian   direct  recruits   and  that  there  was  no
justification for  adopting any  discrimination in favour of
the Army  officers. The  impugned rules  were struck down on
the ground  that there  was no  reasonable  nexus  with  the
object sought to be achieved.
1037
     In appeal  to this  Court it was contended on behalf of
the State that the constitutional mandate of equal treatmentCol. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

applies only to equals and in the case of recruitment to the
service the  sources of  recruitment of  Army personnel  and
civilian  entrants   are  different  and  remain  different;
weightage is  given only at the time of entry and thereafter
officers are treated as equals for all purposes of promotion
and the advantage gained by the militarymen is a consequence
of the initial advantage of the commissioned service for the
purposes of  seniority. Assuming  that there  is  a  unified
cadre, since  there exists a rational relation to the object
sought to be achieved Article 16 cannot be said to have been
violated.
     Allowing the appeals,
^
     HELD: The  1950 Rules  are valid  in that  they have  a
prominent  feature   which  is  basic  namely  the  military
nominees do not shed their army service and merge into a new
service  to   undergo  partial  absorption  but  preserve  a
substantial separateness. [1054 B-C]
     1. Without  the military  engineers the Survey of India
would  become   a  functional  failure  in  discharging  its
paramount duties in times of war and peace. The work done by
the army wing of the Survey of India is far too important to
be played  with and such work is best done by that wing. The
military recruits  are commissioned  officers with  three to
six years  of service  with certain salary scales and period
of service.  Giving due  weight to these factors rule 5 lays
down the  criteria for  seniority as  between  the  military
sector and  the civilian  sector. For the very efficiency of
the Survey of India a substantial Army element is essential.
Army engineers  are invited  into this  service not  because
this department  historically belonged to the defence forces
but because  in hours of crises it cannot minister to one of
the major  objectives of  its creation  if it  does not have
engineers with  military training,  courage and so on. It is
fairly  intelligible   and  basically   equitable  to  allow
military  engineers  credit  for  commissioned  service  and
protection of already earned higher salaries. [1059 E-H 1060
A-B]
     2. To  attract engineers  into the  Survey of  India by
assuring them  all that they were enjoying in their existing
service, namely,  credit for  the years  under commission in
reckoning seniority  and fitment  of their  salary and other
benefits is  not discrimination  or favoured  treatment  but
justice to  those whom,  of necessity,  the  service  wants.
[1060 C-D]
     3. Once  it is  agreed that  at the  entrance point the
Army engineers  are justly given credit for the commissioned
service which  they carry  with them  there  is  no  further
discrimination while  in service on the score that they come
from the  Corps  of  Engineer  Officers.  All  that  happens
thereafter is  merely the manifestation of initial advantage
of credit for commissioned service. [1061 D-E]
     Mohammad Shujat  Ali &  Ors. v.  Union of  India & Ors.Col. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

[1975] 1  SCR 449  at 481; Ram Lal Wadwa & Anr. v. The State
of Haryana  & Ors.  [1973] 1 SCR 608 at 635; State of Punjab
v. Joginder  Singh [1963]  Supp. 2  SCR 169  at 189;  S.  G.
Jaisinghani v. Union of India & Ors. [1967] 2 SCR 703; Ganga
Ram &  Ors. v. Union of India & Ors. [1970] 3 SCR 481 at 488
referred to.
     4. The  1950  Rules  bring  out  certain  incidents  of
service boldly.  Notwithstanding the  fact that they entered
the Survey of India service. the Army
1038
officers continue  to wear  Army uniforms, they get notional
promotions in the Army provided they pass the requisite Army
tests when  they earn corresponding promotions in the Survey
of India. They can be recalled by the Army and they continue
to be  under the  control of  the  Commander-in-Chief.  When
inefficiency is  noticed they can be called back to the Army
for being  dealt with  appropriately. A  conspectus  of  the
facts and circumstances governing the service makes it clear
that there  is no integration of the Army personnel into the
Survey Service.  Without such  complete integration Articles
14 and 16 cannot be invoked. [1064 E-G, 1065 A-B]
     5. Whether 25% or 50% induction from military engineers
is enough  is a matter of policy for which the judiciary has
no genius  and the  administration has  a reach of materials
and range  of expertise, so that Courts must keep out except
where rational  criteria, or  irrelevant factors  mala  fide
motives or  gross folly  enter the  verdict. In  the instant
case reservation of 50% of Class I service for Army Officers
cannot be  called irrational,  impertinent  or  improvident.
[1065 F-H]
JUDGMENT:
CIVIL APPELLATE JURISDICTION: Civil Appeal Nos. 1745- 1755 of 1975.
From the Judgment and Order dated 5-9-1975 of the Andhra Pradesh High Court in Writ Petition
No. 1269/75 L. N. Sinha, Attorney General for India, E. C. Agarwala and Girish Chandra for the
Appellants (In CA 1755/75).
P.P. Rao, M.S. Ganesh, A.K. Ganguli and T.V. S. Narasimhachari for the Appellants in Ca 1754/75.
P. Govindan Nair, A. K. Sen, Bishambar Lal, Miss Munisha Gupta and Mrs. Baby Krishnan for RR
1-2 in CA 1754/75 and CA 1755/75.
The Judgment of the Court was delivered by KRISHNA IYER, J. These two sister appeals have
gained access to this Court by certificate under Article 133 and project a 'service dispute' between
the Army and civilian wings (both engineers) of the Survey of India. The constitutional missiles
used, with success, in the encounter in the High Court by the 'civilians' to shoot down the 'militaryCol. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

men's' preferential claims under the relevant service rules, are Articles 14 and 16. And here, in this
Court, the Army Wing is fighting back to repulse the civilian wing by defusing the war-head of these
two fundamental rights. Military imagery vivifies the litigative havoc when sectors of our public
services go to battle against each other, though there is so much else to wage war against in the
service of the people.
A narration of facts falling within a short compass will unfold the real issue, revolving round the
salary, seniority and de facto promo-
tional disparity inter se, which has sparked off the forensic war. The Union of India, one of the
appellants, supports the stand of the military sector of the Survey Service, if we may so designate it.
A survey of the story of this conflict suggests the sombre thought that unending litigation, affecting
the public services with inevitable impact on morale and efficiency, is becoming an epidemic in
courts even among strategic cadres and sensitive sectors-a matter almost for consternation which
surely must kindle a search for constitutional alternatives for resolution of service questions without
large numbers of civil servants being locked in long-drawn-out legal struggles. Does the experience
of 30 years under the Constitution indicate that, save where fundamental constitutional issues arise,
Whitley councils, Service Tribunals and other specialised adjudicatory agencies, with the
imprimatur of finality, are a more pragmatic mechanism of Service Justice ?
The factual setting, sufficient to unravel the constitutional contention, may now be delineated. Both
the appeals against the judgment of the High Court of Andhra Pradesh cover the same subject
matter, although one of them is by the Central Government and the other by the members of the
Survey of India from among the Defence personnel, and both have been resisted on the same basis
by the civilian recruits to the Service. A common judgment will dispose of both the cases but we
must begin from the very beginning to get a hang of the controversy.
The genesis of the Survey of India, its life before birth, its genetic composition and hereditary
characteristics, mould the structural engineering of the Service and, therefore, have a bearing on the
issues debated before us both sides. While the High Court has, to some extent, slurred over the
chronicle, both sides have heavily stressed before us the saga of the Survey of India, each to lend
strength to its point of view. So, a peep into the bicentennial biography of the Survey of India is a
necessary exercise as a starting point. To blink at history is to lose the living link with the Past and to
stumble in the Present. Yet strangely, none such, i.e. history of the Service to serve as a lucid
background is given in their statement by either party, save incidentally. Unfortunately, the fine and
fruitful art of presenting a luscent written brief is still in the long Indian Year of the Infant and we
have to cull out and piece together materials which should have been set out as a scenario of
meaningful development. If the High Court has gone wrong the blame must fall in part on the
Central Government which could and should have projected the story of the Survey of India, its
functional complexion and recruitment rationale instead of leaving judges to run around the
corridors of padded paper books or launch on speculative surmises. The State, the largest and
resourceful and most affected public litigant, leaves much to be desired in the written presentation
of its cases. The other parties fare no better, though. And instalments of additional information
during the progress of the hearing has had to make-do for a comprehensive unfoldment. Better lateCol. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

than never ! The story of the Survey of India has been narrated in its brief autobiography, 'Our
Department', produced on the eve of its bicentennial in 1967. This department was born during the
days of Lord Clive under happy Army stars, had a military upbringing and, in its brilliant career,
achieved lustorous exploits. Starting from an accident of history-the request of a historian, Robert
Orme, to an East India Company administrator, Lord Clive, for a map of Bengal-the Survey of India
sprang to life in embryonic form when Major Rennel was appointed to execute this survey and,
thereafter, was cradled by the Army but spread out to become a dynamic department and
development instrument in the decades ahead. In war and in peace, in building the nation and
defending its security, in 'civilian' ventures and military operations the Survey of India has become a
National Service in the role of adviser on survey data and kindred adventures. Indeed, almost all
ministries of the Central Government and many States have used the services of the Survey of India
during the several Five-Year Plans. Look before you leap' becomes in development terms, survey
before you start, and so it is that in 1967 this great department of strategic importance is able to
write its story and conclude:
"25. In short, in its ever increasing sphere of vast, diverse and widely scattered work,
Survey of India has built up a unique reputation both within the country and outside
as a sound, distinguished, and great Survey Organisation of the world, progressively
marching forward. expanding, adapting and modernising itself and continuing its
contributions to science, security and development.
The personnel of Survey of India can legitimately take pride in the fact that they
belong to this ancient and great organisation, to whom a noble, rich and priceless
heritage has been bequeathed-inspiring and beckoning them to greater heights of
achievement, honour and glory."
When the history of Free India comes to be written the proud contribution of the Survey of India
may be printed in bold and bright characters because almost every Department of governmental
activity with welfare potential has the imprint of the Survey of India at some stage or the other, as
disclosed in the various materials which have come into our hands, through counsel, in the course of
their submissions. The flattering fact that the tallest peak in the World, Mount Everest, was named
after the eminent Surveyor General Sir George Everest shows that even in the geological discovery of
India, this Department has had a hand. The different dimensions and directions in which the Survey
of India has served the nation and science as a whole are perhaps a fall- out of its adventurous
alliance with military activity.
During British days, it was not an accident that the Survey of India was under the Army. It was an
inalienable companion of conquest and consolidation of defence and development-a versatile genius
which was put to greater good in the era of Freedom and After.
"12. It is perhaps not so well known that the work of the Survey of India has special
significance in matters of country's defence. The Survey of India has to organise
surveys and work well ahead to provide maps at the right time and of the right places
where campaigns might be fought in war.Col. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

The Chinese threat along the northern borders of the country since 1959 necessitated
diverting immediately a very large potential of the Department to carry out the work
of special topographical surveys for defence purposes in one of the most inhospitable
and rugged terrains of the world-an assignment which cost the Department many
precious lives and many years of hard work.
The bulk of military survey and mapping requirements are met by Survey of India.
Though the military survey service exists, it is small and has insufficient personnel,
who carry out limited technical work and such staff duties as army requires in peace
time.
13. There have, thus, been many occasions for the Survey of India to be commended
for its work for defence and development in war and peace, and for providing the
basic knowledge of the land for all its users."
The Surveyor General, for reasons of functional importance, is also the Director of Military Survey.
Topographical Mapping states:
"When corrections and additions to maps of military importance are suggested by the
Director, Military Survey, they should, as a general rule, be accepted by the Survey of
India."
It is necessary to notice the role of the Survey Department under the Director of Military Survey who
is also the Surveyor General thus bringing out the interlacing of activity. Obviously, there is not
merely sensitivity and confidentiality but also a high degree of skill which cannot be relaxed and an
instant sense of discipline, which cannot be liberalised, in view of the fact that military operations of
national significance depend, in part, on the Survey of India and its service. While it is fair to
emphasise that considerable peace-time developmental work is rendered by this Department, its
adventurous spirit of climbing mountains, penetrating wilderness and entering into forbidden
regions cannot be minimised. Lt. Col. Sandes writing on 'The Military Engineer in India' states:
"History has shown that there is something in the training which the Survey of India,
imparts to its officers which makes them peculiarly valuable in war. Their work
develops not only self-reliance and initiative, but a sense of responsibility. Everything
centres on the example set by the leader of an isolated party. As a rule, he is the only
European in the small country. He must have powers of organisation and
observation: courage, determination and endurance. In the ordinary course, he must
be precise to the point of pedantry, never satisfied with unchecked work and
abhorring the smallest error; yet at other times he must fling theory and practice to
the winds to improvise means of rapid reconnaissance when danger threatens."
The Military history which has moulded the character of this Department has relevance and so we
quote again Lt. Col. Sandes:Col. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

"As the war spread, the survey officers from India were scattered over the face of the
earth; some on military duty with engineer units other flash-spotting, sound-ranging
and triangulating in France and Belgium:
and others again reconnoitering and surveying in any or all of three continents. They
worked in Salonika, North and South Russia, Italy Gallipoli, East Africa,
Mesopotamia, Egypt, Syria, Persia, and on the shores of the Caspian. One
commanded a brigade in North Russia, another led a Persian army. Ten officers of
the Survey of India were killed in Action, or died on service, during the Great War,
and thirteen were wounded. Many casualties occurred in the lower ranks. Such were
the contributions of the Department towards victory in the greatest struggle of all
time. They form a fitting climax to its record in the frontier wars of India."
If we may sketch a few lines to indicate the trait of the Corps of Indian Engineers with a view to
illumine the points canvassed before us, we have to refer to the book by Major Verma and Major
Anand. The authors state:
"Before the war, Military Survey as such did not exist; though for generations past,
Survey of India had provided detachments for practically every military campaign or
expedition. But these parties were considered to be civilian, including their military
officers-in-command, and they were only attached to the Army for supplies and
transport. Even in the First World War (1914-18), Survey of India detachments went
out and worked in Macedonia, Mesopotamia and Persia. But at no time before 1940
did India have any military units like the Field Survey Companies or Battalions.
Between the wars, survey and mapping for the Army was done by the Survey of India,
which except for the Artillery Survey Section, Royal Artillery, was the sole military
survey agency. It had a semi-military tradition, the Surveyor General held the rank of
a Brigadier and his principal officers were Royal Engineers with specialist survey
qualifications. There was no survey representation at GHQ."
Again "For the Department, the military responsibilities in 1938-39 were:-
(a) Liaison with the Armed Forces on survey and mapping.
(b) Provision of maps required by the Defence Services, covering India, Burma,
Afghanistan and Iran.
(c) In the event of a war, to provide and equip firstly two Fd Survey Companies and
two Survey HQs for service in the NWFP, and secondly one Survey Report (admn.)
(d) To carry out annually a small amount of training in military survey."
In many Circles, Directors of the Survey of India have been Office Advisers to the
'Commander-in-Chief" and the work done by this Department has had in many cases militaryCol. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

meaning. This was reflected in the past in the officer situation and personnel complexion. Class I
Officers were all military men while Class II men were civilian graduates. Brig. Wheeler, writing of
the officer situation in British India, summed up thus:
"Perhaps the greatest single factor affecting military organisation was that whereas
there were nearly 60 military officers in 1925, there were only 30 in 1939; to train a
civilian to be sound and efficient soldier takes a considerable time, to train a non-
survey soldier to become an efficient surveyor, much longer, very much longer."
The military commitments of the Survey of India in the World War II made it a strategic instrument
invisible to the lay but invaluable to the esoteric.
We have pressed this part of the career of the Survey of India to knock out the impression that its
military component is purely a concession to the historical staffing pattern and the lack of avenues
for promotion to Army engineers. It is an in-built necessity of the department in national interest.
We agree with counsel for the respondents, Sri Govindan Nair, that the early history of the Survey of
India as a child of the Army cannot become an obsession to distort or debunk the enormity of its
purely developmental undertakings. It is a Civil Service which serves in national reconstruction all
the time, but, at the call of the country, is ready to switch to Defence, risk anywhere and do surveys
as commanded. We must set our sights right about the civil and military range of the versatile
department and not swallow the brash version that it is all 'brass'. Its bearing on the conclusions in
the case is that the court should not blindly accept all the preferences to the Army recruits as against
their civilian brethren under the impression that everything in the Survey of India is Defence
operation and civilian must therefore accept the crumbs as shudras of the Service. No! Most of its
work is peace-time activity of a fundamental, though invi-
sible character to promote development in its multitude and magnitude and, indeed, in its
panoramic magnificence.
But we cannot get away from the historic fact-not merely the fact of history-that the Survey of India
is, first and foremost, an instrument of military strategy for the defence of the country although its
talents are not allowed to grow into thistles but to serve wherever needed. If competing demands
come, it opts for and is therefore geared to Defence goals. That is its first charge and, in that sense, it
is Defence-oriented, has an Army bias and cannot afford to ignore the indispensability of a military
component. The history of a nation is never written by the military but its history ceases to be, if its
reserves of military manpower cannot be mobilised for active duty at an instant's notice. The Survey
of India, with its signal service to the planned progress of the people, has a tryst with national
security and an everyday commitment to the country's defence requirements. This may look
over-drawn but embeds a core of truth cardinal to the issue in the case-why weightage to the
'uniformed' recruits as against their counterparts in 'mufti'?
Let us thus place accent on what is essential but not miss what exists as a reality. From this angle, a
legal raconteur may re-tell the story slightly differently.Col. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

The Army in British India had, as one of its strategic operations, to undertake the survey of the
interior and frontier of the country and had, therefore, under it a department wholly manned by
military personnel. After Independence and the enactment of the Constitution, this military limb
separated from the Defence Forces, was constituted into a Civil Service with the Surveyor General at
the apex and a hierarchy below of triple components together making up the Class I service. The
Service, in its new dimensions, was manned by civilian and military personnel due to functional
imperatives. The entry into the service was at the point of Deputy Superintending Surveyors, save
for a category of promotees from Class II, with provision for spiralling up to higher positions. The
posts were filled according to Rules framed under the proviso to Art. 309 on a 50: 50 basis, as
between Army engineering personnel dovetailed into the Survey of India and civilians recruited or
promoted or otherwise appointed.
We miss the service perspective if we do not take a functional glimpse at the operational scale and
range of the Survey of India. What was a wholly military department previously reincarnated as the
Survey of India, with a civilian inter-mix, retained its meta-military personality, functionally and
personnel-wise. In budgetary classifica-
tion and administrative charge, the Survey of India was a member of the Agriculture Ministry, of the
Education Ministry and currently, perhaps, correctly belongs to the Ministry of Science and
Technology which is pervasive enough to embrace Defence and Development. It is not right to
regard this Service as a 'uniformed' service, for it is ambidextrous. But that is not really decisive of
the issue before us. What we have to understand is not so much its genetic transmigration as such or
pedigree table but the nature of the service the Survey of India is expected to render, its basic
functional characteristics, operational capabilities, futuristic uses and, consequentially, its
meaningful personnel policy and the conditions of service dictated by the compelling necessities of
these demands on the Service. In brief, the emphasis is not on the administrative pigeonhole in
which the Survey is placed for secretariat or budgetary purposes, nor on its lineage, nor, indeed on
the label 'civil' or 'Defence' but on the nature of its duties and the relevant pattern of manpower and,
most importantly, the concrete conditions of recruitment and principal career requirements while in
service, having regard to the strategic essence of the goals the Service must sub-serve. So viewed, the
Survey of India is army oriented. Not merely because of heredity but markedly because of the
nation's potential demands and perennial expectations from this specialised Service, not merely in
emergency but to be always on the qui vive. We gather from the affidavit of the Senior Director, on
behalf of the Union of India, that the army component is an inalienable requirement of the Survey of
India if it is to fulfil its role. He swears:
"Some of the reasons for corps of Engineers being one of the sources of recruitment
are as follows:
(a) Survey of India may need mobilisation in the event of any emergency of war.
(b) The Corps of Engineer Officers in Survey of India form the nucleus around which
mobilisation can take place quickly.Col. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

(c) The small element in the Army cannot cater for training and experience, and
hence Corps of Engineer Officers are kept in Survey of India which provides the ideal
ground for training and experience of these officers during peace so as to keep them
fully competent technically in the event of a war or emergency.
In order to maintain an adequate balance between military and civilian officers, and to attract the
higher type of Corps of Engineer Officers to the Survey of India, 50% of the total number of posts in
the Class I Cadre were earmarked for the Corps of Engineer Officers." What, then, is the raison d'
etre of this department ? War means advance into or withdrawal from territory. Operations involve
identification of topography, climatology, environmentology, location of defence positions, marking
of marching and retreating positions and artillery targets and paratroop landing positions, keeping
secret strategic centres and sealing them off as out of bounds-and a host of other surveys invaluably
informational and immediately available for national defence. It is obvious that if this be the
functional relevance of the Survey of India, some divisions of it have to be fighting fit, always on the
alert, ready to rush to the risk zones and technically capable of teaming with the ground forces in
seasons of emergency and occasions of external aggression, before and after. The Survey of India
must be geared to the goal of national security if it is to justify itself in a large country of extensive
mountain frontiers, border disputes, history of hot war, interior defence lines and military routes. Of
course, our imperial masters could afford, at the expense of people's welfare, to keep such a
department as a section of the Armed Forces, idle for long stretches of time but keeping their tools
sharp for eventualities. Free India could not. Naturally, the country's leaders, entrusted with
gubernatorial responsibilities in this behalf, hit upon a golden mean of forming a separate Survey of
India, no more a wing of Army. The object was understandable. A permanent yet considerable
number of technical personnel virtually idle during peace time was a luxury. Nevertheless, an
instrument was forged which preserved the military mood of active duty but expanded and
expended its sophisticated expertise during years of peace on national needs of other Ministries or
States' requirements. It reflected the duo-dexterous roles and mosaic of manpower in its
recruitment policy. Unique functional imperatives demand unique service anatomy as an
administrative experiment in the Darwinian art of survival of the fittest. We see nothing strange in
this unorthodox composition, although attempts to interpret the new scheme by familiar Service
moulds may mislead, as has happened in the High Court.
The Senior Director with reference to current conditions, deposes as affiant of the Central
Government:
"Reasons for seniority and pay protection for the Corps of Engineer Officers are as
follows:-
(a) They suffer due to lack of higher opportunities of promotion to Brig. Major
General, Lt. General and General by their volunteering for the Survey of India.
(b) They can utmost expect to get military pension as a Colonel but not as Brig. and
higher which are substantially higher.Col. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

(c) They lose other perquisites like house rent, concessional electricity and furniture
facilities, concessional Form 'D' facilities, and many other concessions.
Unless therefore, they are given protection of seniority and pay in order to partly compensate their
losses, no Corps of Engineer Officer would ever volunteer for the Survey of India. These were the
considerations for the seniority and pay protection for Corps of Engineer Officers.
Even if, for argument's sake, it is admitted that preferential treatment is given to Corps of Engineer
Officers (which it is not), it is done under the rules which have been framed based on the differences
between the various sources of recruitment, and the said differences have a reasonable relation to
the nature of the office to which recruitment is made. Thus, the appointment, and terms and
conditions of the Corps of Engineer Officers can legitimately be substantiated on the basis of valid
classification."
At this point we must eye at close quarters the Survey of India (Recruitment from Corps of Engineer
Offices) Rules, 1950. Primarily, it relates to the recruitment from the Corps of Engineer Officers. The
relevant part of Rule 2 runs thus:
"2. Recruitment: A Corps of Engineer Officer for appointment to the Survey of India
should at the time of appointment normally have not less than three and not more
than six years commissioned service, but this rule may be relaxed in exceptional
cases. Corps of Engineer Officers shall apply for appointment to the Survey of India
to the Military Secretary, through the Engineer-in-Chief, who will transmit the
applications to the Surveyor General. The Surveyor General will maintain a list of
such applicants, as, after making the due enquiries, he considers to be suitable for
appointment. When a military post falls vacant and the Military quota has not been
filled the Surveyor General shall nominate an Officer or Officers from the above list."
This Rule postulates a military quota which takes us straight to Rule 11:
"11. Method of recruitment to Survey of India Class I Service.
All future recruitment to the Survey of India Class I Cadre will be as follows:
1. From Corps of Engineer Officers 50%
2. From promoted Class II Civilian Officers 25%
3. From direct recruits by competitive exami-
nation through the U.P.S.C. 25% The military recruits to Class I Service enter the
Deputy Superintending Surveyor's (hereinafter referred to as D.S.S.) position in the
Service from where they rise on promotion as Superintending Surveyors (hereafter
referred to as SS) Deputy Directors and Director, the top post being of SurveyorCol. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

General. These promotion posts are available for all categories of entrants as has
been clarified in the later set of Rules called 'The Survey of India (Class I
Recruitment) Rules, 1960.' Before we part with the 1950 Rules, it is necessary to
place accent on some aspects of the military officers and their career in the Survey of
India. Their sojourn in this new Department is not an exit from the Army but a long
furlough, as it were. For all practical purposes, they retain their military position and
remain under military control and are liable to be called back for regular army
service. It is a kind of provisional adoption into a different family but with the ties in
the natural family kept in-tact.
A Corps of Engineer Officer will be qualified for recruitment only if he is in commissioned service
for between three and six years. Then he is to go through a two- year period of probation during
which he is to pass tests. If he is not good, he gets back to military duty and even if he makes good,
he has an option to revert to military employment. Even after confirmation, the officer may revert
during the first 20 years of commissioned service on his own request. Even thereafter, with the
approval of the Government he may revert permanently to military duty, save in the case of those
who fall under Rule 4(c). If an officer retires from the army that will involve retirement from the
Survey of India too, save in the case of those who are Colonels or Lt. Colonels, covered by Rule 4(c),
and retires from the army only for the reason that they have attained the requisite age limit. Such
persons under Rule 4(d) may continue in the Survey of India until the age of superannuation from
civil employment. It is important to note that an officer may be reverted permanently to military
duty if he is no longer needed in the Survey of India on account of reduction in strength or
unsatisfactory work. He may also be reverted temporarily to military duty for grounds given in Rule
4(f).
Another remarkable rule is Rule 8 which speaks of wearing military uniform while in civil
employment if the incumbent is willing to observe the courtesies due to military officers of superior
ranks. Rule 9 is extremely significant and reads thus:
9. Military Promotion: A military officer in the Survey of India is expected to keep
himself efficient as an army officer and will have to pass such promotion
examinations, etc. as may be laid down for other military officers of his rank and
corps; such military confidential reports will be submitted on him as may be required
by the military authorities. Military Confidential Reports will be initiated and
submitted in accordance with the procedure laid down in Special Army Order
24/S/51 as amended from time to time.
Military officer in the Survey of India will be considered for military substantive promotion in turn
with others in their corps and their fitness for such promotion will be judged by their confidential
reports. After completing his normal period as a Lt.
Colonel an officer will be eligible for promotion to full Colonel and above provided that:
(i) he is a substantive Director or above in the Survey of India;Col. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

(ii) there is a vacancy in the number of posts for full Colonel and above reserved for
military officers in the Survey of India.
Rule 10 is also meaningful because the army officers in the Survey of India when they rise to higher
positions get equivalent rise in the Army. There are a few more aspects which perhaps may complete
the story but the thrust of the submissions made by the learned Attorney General on the strength of
these rules is that the Army Engineers are not integrated with or incorporated into the Survey of
India Class I Service in toto. There is a partial assimilation but a substantial separation persists.
Once an Army Engineer, always an Army Engineer, is the gist. Absent integration, Art. 14 is out of
bounds-such is the cumulative effect of the Service Rules, 1950 according to the learned Attorney
General. We will presently examine his claim which has been rejected by the High Court.
Indeed, the pivotal point of this case is perhaps the nature of the Service with special reference to
Articles 14 and 16, viz., the integration of the two sources into a common pool and the impermissible
de facto bifurcation of the two strands in promotional streams in the years ahead. Also, the myth of
Defence needs and consequent preferences for military recruits. The High Court rightly formulated
the crucial question when it stated:
Thus, the bone of contention of the respondents is that the very nature of the work
undertaken and done by the Survey of India is related to Defence purposes and the
officers recruited from the army engineering corps are specially trained for this
purpose. This, according to the respondents, is the reasonable connection between
the classification and the object that is sought to be served in recruitment to Class I
service of the Survey of India.
The conclusions reached by the High Court also deserve to be set down at this place
to facilitate a clear understanding of our approach and the basic finding of fact
reached by the High Court. The respondents have heavily relied upon this finding and
have legitimately lashed the appellants' plea as unpresentable in the face of this
finding of fact. The learned Judges observed:
This claim, however, is not made out before us. We have already referred to the
various affidavits filed by the parties. In the original counter affidavits filed by
respondents, the stand taken is that because the rules provide for special privileges,
they are being given to the army personnel and so the equality concept is not violated.
That is really begging the question. When the petitioners complain that the rules
made in this behalf violate the equality concept as enunciated in Articles 14 and 16, it
would be futile to reply to that argument by saying that the rules so provide. In the
later affidavits some attempt is sought to be made to point out that the nature of the
work carried on by the Survey of India department is essentially connected with
Defence of India and that the officers recruited from the Army Corps of Engineers are
specially trained for this purpose. On the basis of the material placed before us, we
are not inclined to accept that the work done by the Survey of India department is
essentially of the nature and character required for defence purposes. It may be thatCol. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

along with several other surveys carried on by this Department, it does survey work
which is useful to the Defence department. From the affidavits and the other material
placed before us, it could be seen that the survey work done by the department is
mostly concerned with the development projects and preparation of maps for various
Ministries, State Governments, public sector projects and other civilian agencies. The
annexure filed along with the additional reply affidavit filed by the petitioners show
that the Survey of India is a national survey organisation. It appears to have surveyed
quite a large number of development projects during the three plan periods. The
department might have prepared some maps useful for the Defence purposes. But
that is only part of the work and incidental to the nature of the survey it carries on. Its
work does not appear to be Defence oriented. The survey done by the department is
utilised by several departments of the Central and State Governments, public sector
projects and other civilian agencies. It is, therefore, making a tall claim to say that the
survey is essentially of Defence nature. Further, there is nothing to show that even if
the work related to Defence purposes the civilian officers are not employed or
engaged. Thus, the Survey of India appears to be a civilian department with a civilian
budget. Further, whenever there is an emergency there is nothing which prevents or
bars the Government of India from calling upon the civilian officers also to serve on
the border. It is the stand of the petitioners that if 25 army personnel belonging to the
Survey of India were called to the border area in 1962 war, as many as 70 civilian
officers belonging to Class I and Class II categories were called to work in the same
area. They also assert that just like the Defence department uses some maps prepared
by the Survey of India, the Forest Department, G.S.I., P.W.D. etc., also use the maps.
So we are not inclined to hold that the nature of the survey and work carried on by
the Survey of India department is largely defence oriented.
Even at this stage, we may refer to the High Court's view about the historical
background of this Service: It is, further, stated by the respondents that the historical
background also supports recruitment of as much as 50% of Class I officers from the
army engineering corps. Some reports are sought to be relied on in this connection.
This argument overlooks the fact that we are not concerned with the situation as it
obtains in Independent India and not in British India. It is true that some attempts
have been made after attainment of Independence to attract officers from the army
engineering corps into Survey of India department. But as in 1950, 1960, 1962 and
1974 Rules generally show, the work done by the department is essentially civilian in
character. The impugned rules will have to be examined in the light of the
circumstances that are now prevailing ever since Independence and not on the
so-called historical background which has, in any case, become archaic.
In regard to the special training given to the army personnel which is said to justify
the classification, it appears to us that this claim is not tenable. If the army personnel
are given training in field engineering for 9 months and for 3 years in the Military
Engineering College, Kirki, the qualifications required for direct recruitment of
civilians are no less valuable. Largely, only engineering graduates are recruitedCol. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

directly. They have equal engineering experiences. Further, it does not appear that
the army officers had been given any survey training when they were in the army
services. It is not, therefore, possible to say that the recruits from the army are better
qualified than the civilian direct recruits. The promotees from Class II have, behind
them a very long experience of not less than one decade in the work undertaken by
the Survey of India department. With this long experience of survey work,
particularly belonging to this department behind them, we do not see any
justification for their being discriminated against in favour of army officers. We are
not, therefore, prepared to accept that the army personnel in the Survey of India
department have had any longer or better training required for Survey of India than
either the direct recruits or promotees from Class II service to Class I service. The
latter two categories appear to be as qualified and as experienced as the army officers
to carry out the work of Survey of India. The only conclusion that is possible from the
above discussion is that this classification made under the impugned rules between
the army personnel and the civilian personnel has no reasonable connection with the
object that is sought to be served.
We demur. Why ? The 1950 Rules, in our view, have two prominent features which
are basic. The first one which we have already emphasised is that the military
nominees do not shed their army service and merge into a new Service but undergo a
partial absorption and preserve a substantial separateness. The second feature, which
is perhaps more hurtful to the civilian sector, turns on Rule 5 which provides for
seniority. The rule runs thus:
5. Seniority.-(1) On first appointment an officer will be in the grade of Deputy
Superintending Surveyor (Formerly Assistant Superintendent) in Class I Service of
the Survey of India.
(2) The seniority of military officers inter se will remain the same as in the Army.
(3) The seniority of military officers vis-a-vis directly recruited civilian officers will be determined by
the year of allotment which will depend:
(i) in the case of military officers, on the date of first commission including ante-date,
if any; and
(ii) in the case of directly recruited civilian officers, on the date of appointment ante-
dated by two years.
(4) Civilian officers directly recruited on the results of any one examination will be
junior to those recruited on the results of earlier examinations and senior to those
recruited on the results of later examinations, the seniority inter se of those recruited
in any one year being determined according to the order of merit in which they are
placed by the Union Public Service Commission in the qualifying examination. (5)Col. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

Among those allotted to the same year, military officers will rank senior to directly
recruited civilian officers.
Rule 5A deals with promotion-officiating and substantive. A qualifying two-year probation and a
further three years' service are a sine qua non for substantive promotion. But officiating promotions
are open to all the officers, preference being given to those who have done more years of actual
survey work, regardless of seniority. Even officiating posting needs the qualifying service of two
years and three years, earlier referred to. In this regard, the Class II officers who are directly
promoted as S.S. have a definite advantage over the military men. But when it comes to
confirmation in substantive promotion posts, the military personnel opting into the Survey of India
get the advantage of Rule 5 which bestows on them the added benefit of the period of service from
the date of first commission in the Army which may be anything between three to six years as
against two years of ante-dated service which the civilian officers are entitled to tack on.
The 1960 Rules also require to be examined before we proceed to a discussion. Rule 3 speaks of the
sources of recruitment or appointment Direct recruitment of qualified candidates, promotion or
transfer from another service, appointment from the Corps of Engineer Officers of the Ministry of
Defence and, rarely, admission of other qualified persons-these are the methods of entry into the
service. A direct recruit must be a graduate with Mathematics or the holder of an Engineering
Degree (there are other alternatives which are of minor significance). Rule 20A, which was an
amendment made in 1965, insists that every person in the Service, appointed after the 1965
amendment, "shall be liable to serve in any defence service or post connected with the defence of
India, for a period of not less than four years", including the training period. This, incidentally,
emphasises the military adaptability expected of the Service. Rule 22 is important:
22. Seniority-(a) On the first appointment an officer will be in the grade of Deputy
Superintending Surveyor (formerly Assistant Superintendent) in class I Service of the
Survey of India.
(b) The seniority of military officers inter-se will remain the same as in the Army.
(c) The seniority of military officers vis-a-vis directly recruited civilian officers will be determined by
the year of allotment which will depend :
(i) in the case of military officers, on the date of first commission including
ante-dated if any; and
(ii) in the case of directly recruited civilian officers, on the date of appointment ante-
dated by two years.
(d) The relative seniority of all direct recruits shall be determined by the order of
merit in which they are selected for such appointment on the recommendations of
the Union Public Service Commission, persons appointed as a result of an earlier
selection being senior to those appointed as a result of a subsequent selection.Col. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

(e) Among those allotted to the same year, military officers will rank senior to directly
recruited civil officers.
Another rule which must be mentioned for a complete understanding is to the effect that Class II
officers, when promoted to Class I, are directly appointed as S.S. and, therefore, can skip the lower
position of D.S.S. In 1970, the promotional scheme was slightly modified, but the thrust of the
argument that military engineers enjoyed an advantage remained.
The attack made by the civilian wing, consisting of two groups, namely, direct recruits and Class II
promotees, is against three key rules of the 1950 Scheme, viz., Rules 5, 5A and 11 and, of course,
their corresponding 1970 provisions based on Arts. 14 and 16 and the High Court has substantially
acceded on the basis that seniority prescriptions are based on irrelevant criteria and arbitrariness is
writ large in some of the impugned provisions. The Court has struck down Rules 22B, 22E of the
1960 Rules and Rules 5(2), 5(3), 5(5), 7 and 11 of the 1950 rules. However, the Court has
circumspectly declined to open the Pandora's box and restricted the refixation of seniority and
review of promotions "only from the date of the filing of the writ petition viz. 5-3-1974, because if we
do it from a back date, it would be unsettling the promotions that had already been given before a
challenge is made by the petitioners."
This comprehensive narration is sufficient to inaugurate a discussion on the merits of the
contentions after a formulation of the critical issues.
The points urged by the learned Attorney General are two fold. Neither Art. 14 nor Art. 16 is violated
because the Army recruits and the civilian entrants do not march into a common pool within the
service of the Survey of India. There are two sources or streams which flow into the Service but
remain immiscible layers. Since the Constitutional mandate of equal treatment applies only to
equals, it cannot apply to the given situation. Secondly, assuming there is a united cadre, even then
Art. 16 cannot invalidate the weightage for seniority assigned to the military recruits, since sensible
supportive discremen, having a rational relation to the object of the Service exists and that is
sufficient panacea to cure the infirmity of differential treatment. He further pressed that it was
perfectly permissible, having regard to the different sources, to prescribe a weightage at the time of
the entry into the Service. And, in the present case, the weightage is only at the time of entry into the
Service. Thereafter, they are treated as equal for all purposes of promotion and what manifest
advantage is derived by the military men in their career is a consequence of the initial addition of
the commissioned service for the purposes of seniority.
These positions have been contested by Sri Govindan Nair, for the respondents, who has further
argued that it is not proper for this Court to upset a finding of fact by the High Court unless there be
something palpably erroneous on the face of the judgment. This is true and we should not slightly
interfere save where there is grave error. Before we discuss these points, we must clear the ground
regarding the necessity of the military presence in the survey Service. We have already quoted from
the affidavit on behalf of the Union of India, which gives condensed reasons for induction of army
engineers into the Survey of India. That terse statement crystallizes all that we have stated at some
length earlier in this judgment.Col. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

An S.O.S. and the Survey of India must go into action maybe in the war-torn area, maybe for
post-truce measurements. More military survey literature was placed in our hands by the learned
Attorney General, making up for earlier defaults, to drive home the point that multifarious though
the Survey's operations are, it does discharge duties secret, sensitive and strategic for Defence
requirements which necessitate the maintenance of an Army Engineering component willy-nilly.
This backdrop serves to highlight the issues on which we may turn the focus. We may now enter the
area of encounter. What was a thoroughbred Military Engineering Corps suffered a metamorphosis
by 1950 when a new set of rules of recruitment, composition and conditions of service, consistent
with the new vision, rainbow of responsibilities and switch over to civilian departmentalisation, was
brought about.
A critical dissection of the present set-up yields the result: While army engineers are definitely
needed and are not expendable, the civilian accent on developmental work and the like justifies
opening up the Service to recruits and promotees, non-military in source. Guided by this flexible
realism and acting under the proviso to Art. 309 of the Constitution, the President of India has made
Rules in 1950 to regulate the recruitment and conditions of service of the army personnel coming
into the Survey of India. The anatomy of the 1950 Rules is important. It reserves 50% for the
military Engineers by way of entitlement quota out of the total number to be recruited over a year as
D.S.S. The other 50% was to have been divided equally between civilian recruits from the open
market and the Class II officers. But, by an amendment of 1965, a modification was made to the
effect that the promotees from Class II would enter the Class I Service directly as S.S. and not as
D.S.S. Thus, the total number of vacancies each year at the D.S.S. level has to be filled by
recruitment in the proportion of 50 and 25. To illustrate for clarity, if there are 75 DSS vacancies in a
given year, 50 of them are reserved for military nominees and the remaining 25 are filled up by
direct recruitment from the civilians. The expression 'recruitment' definitely means enlisting anew
into a Service and so it may be taken that the army engineering quota is 50 out of the 75 and the
remaining 25 belong to the civilian recruits.
By way of contrast, the members of the Class II Service have a quota of 25% but that proportion is to
be worked out, in terms of the extant rule, not based on the number of vacancies at the S.S. level but
by a calculation of the total number of posts at the S.S. and higher levels in the Service. The total
number of S.S., Deputy Directors and Directors will be added up and 25% thereof will be recruited
by promotion from Class II Service. The recruitment is only to the posts of Superintending
Surveyors although the number to be so promoted is based upon totalling up the various posts at
and above the S.S. level.
The total number of vacancies at the DSS level for each year shall be divided in the ratio of 2: 1 (50%
for the Army Corps and 25% for direct recruits). The 50% reserved for the army corps shall be
available to be filled by those candidates. The 25% seats to be filled by direct recruits shall be filled
only by such recruits. Even if enough direct recruits are not available they will not be filled by the
army nominees but shall be kept vacant to be carried forward and filled in later years by such direct
recruits. A reasonable period for the carry forward scheme will be 3 years, not more. Likewise,
military vacancies at the DSS level each year shall be filled only by such nominees. If enough suchCol. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

hands are not available, a similar procedure of carry forward will govern. For the SS posts 25%
belongs to promotees from Class II officers. The total number will be worked out by adding all the
posts of SS, Deputy Directors and Directors and Surveyor General and allotting one-fourth of it as
the quota for Class II promotees for appointment as SS. Such is the reasonable interpretation of the
rule.
Now we come to the bitter bone of contention between the parties. Why should the 50% of military
recruits be given a special weightage ? Should not all entrants into the DSS be treated alike without
being afforded a handicap in the race? We see no difficulty in upholding this weightage, once we
accept the reality that the military portion of the Survey is a compelling factor for national defence.
We hold, on a study of the materials already adverted to, that sans they army engineers the Survey
of India will become a functional failure in discharging its paramount duties in times of war and in
spells of peace, defence spreads beyond hot war or cold war and sustains the sense of security by a
state of ever readiness. There is enough literature to establish that the work done by the army wing
of the Survey is far too important to be played with and such work is best done by that wing.
The military recruits, as has been already observed, are commissioned officers with 3 to 6 years of
service. They have a certain salary scale and period of service when they are baptised into the Survey
of India. Giving due weight to these factors, Rule 5 lays down the criteria for seniority as between
the military sector of recruits and the civilian counter-parts. What needs to be appreciated is that for
the very efficiency of the Survey of India, a substantial army element is structurally essential. Army
engineers are invited into this Service not because this department historically belonged to the
Defence Forces but because it cannot minister to one of the major objectives of its creation if it does
not have engineers with military training, aptitude, courage, discipline and dare-devilry in hours of
crisis. The necessity of the Survey, not opportunity to the armymen, has determined the need to
attract and, therefore, to allot a quota in the upper echelons, viz., Class I, for military engineers.
This, in turn, has desiderated the offer of reasonable terms and conditions for army men to join the
Survey of India. The military engineers belong to the Corps of Engineer Officers. They are
commissioned officers with service of 3 to 6 years before coming into the Survey which needs, not
raw engineers, but men with some experience. They have prospects and scales of pay in the Defence
Department. Why should they look at the Survey if on entry they are to lose their commissioned
service and begin the rat race with civilian freshers? Why should they suffer pay cut by walking into
the Survey of India? It is, therefore, fairly intelligible and basically equitable to allow military
engineers credit for commissioned service and protection of already earned higher salaries.
The reasoning is simple. The functional compulsions of the Survey of India require army engineers
to be inducted, say half its Class I strength. These engineering officers have to possess some years of
experience. How, then, can they be attracted into the Survey except by assuring them what they
were enjoying in their existing service, viz., credit for the years under commission in reckoning
seniority and fitment of their salary at a point in the scale of Class I officers so that, by way of
personal pay or otherwise, a cut may be obviated. This is not discrimination or favoured treatment
but justice to those whom, of necessity, you want and must, therefore, pay what they were being
paid in the Army and give service credit for the years on commission because you need men with
specified years of commissioned service. To equate them with unequal civilian freshers is preciselyCol. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

the Procrustean exercise which is unconstitutional equality anathematised by Article 14.
Let us eye the issue from the egalitarian angle of Articles 14 and 16. It is trite law that equals shall be
treated as equals and, in its application to public service, this simply means that once several
persons have become members of one service they stand as equals and cannot, thereafter, be
invidiously differentiated for purposes of salary, seniority, promotion or otherwise, based on the
source of recruitment or other adventitious factor. Birth- marks of public servants are obliterated on
entry into a common pool and our country does not believe in official casteism or blue blood as
assuring preferential treatment in the future career. The basic assumption for the application of this
principle is that the various members or groups of recruits have fused into or integrated as one
common service. Merely because the sources of recruitment are different, there cannot be
apartheidisation within the common service.
The case of the Army engineers is not that they should be given 'ethnic' preference in official life
because of military superiority. They merely plead that unequals should not be forced into equality
without regard to their rights. They are unequal because their 3 to 6 years of commissioned service
cannot be wished away when brought into the service shoulder to shoulder with raw recruits.
Secondly, their salaries are higher and that should not be forfeited as punishment for entering the
Survey Service. Not that the salary difference must be perpetuated but that at the point of entry into
service their commissioned service and personal pay should be protected. The Service Rules
safeguard both these-a just gesture without which many army engineers may not care to respond
and the 'efficiency' factor of the Survey Service will fail in their absence.
The learned Attorney General also adopted the precedentially sanctified route of escape from the
magnetic field of Articles 14 and 16, that if the two sources of entry never really flowed into a
homogenised sangam but remained the Ganga and the Jamuna, no question of equality arose. A
common pool where the plurality meets is a necessary postulate for the application of the equalist
mandate. Here the army engineers, it is apparent from the rules, essentially continue to be army
men but wear pro tempore Survey apparel, to be doffed any time specified in the rules themselves.
Resultantly, the military and civilian members remain immiscible layers save for some purposes.
The condition of integration of men from the divergent sources being absent, rulings have held Art.
16 is out of the way. Once it is agreed or found that at the entrance point the army engineers are
justly given credit for the commissioned service which they carry with them, there is no further
discrimination while in service on the score that they come from the Corps of Engineer Officers. All
that happens thereafter is merely a manifestation of initial advantage of credit for commissioned
service. For this reason, we negative the case of discrimination.
The relevant rulings not to burden but to brighten the points urged, may be referred to. In B. S.
Gupta's case(1) where Art. 16 was agitated in a battle between promotees and direct recruits, one
facet of Service Jurisprudence was illumined. We excerpt:
When considering this point it must be clearly understood that this Court is not
concerned with Govt.'s policy in recruiting officers to any service. Government runs
the service and it is presumed that it knows what is best in the public interest.Col. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

Government knows the calibre of candidates available and it is for the Government to
determine how a particular service is to be manned-whether by direct recruits or by
promotees or both and, if by both, what should be the ratio between the two sources
having regard to the age factor, experience and other exigencies of service.
Commissions and Committees appointed by the Government may indeed give useful
advice but ultimately it is for the Government to decide for itself.
In the next place we have to remember that it would be wrong to pronounce
adversely upon the new seniority rule merely because of its impact on the fortunes of
any particular individual officer. Nor will it be correct to point that an individual
officer 'A' would have fared better if the old quota rule and weightage rule had been
restored.(1) We have to take an overall view to determine whether the rule now
framed by the Government to determine seniority is just and fair.(2) A total
conspectus does not persuade us that anything grossly unfair has been perpetrated.
Absent fusion into one integrated service, Art. 16 is not attracted, in a proposition
entrenched by precedents. In Shujat Ali's case,(3) this Court pithily put it:
The two categories of Supervisors were thus never fused into one class and no
question of unconstitutional discrimination could arise by reason of differential
treatment being given to them. We have read Shelat, J's observations in Wadhwa's
case(4) to reinforce our view:
The principles on which discrimination and breach of Arts. 14 and 16 can be said to
result have been by now so well settled that we do not think it necessary to repeat
them here once again.
To sum up the position, the two services were from as early as 1937 and before
separate. At no stage, even after provincialisation was decided upon and the
principles of its implementation were drawn up there was any integration of the two.
In fact, after considering the alternatives which the Government had before it, it
opted, on consideration of difficulties of integration, for the alternative of keeping the
two separate.(5) No principle under Art. 14 or Art. 16 is involved if such an
integration was not brought about, for, considering the past history of the two
services and the differences existing between them, Government could not be
required to fuse them into one upon any principle emanating from the two
Articles.(1) Going backwards still further, we find Ayyangar, J. in Joginder Singh(2)
emphatically enunciating the same proposition:
If, as we hold, there was no integration (and integration has no meaning unless it is
complete, for there is no such thing as partial integration) either expressly or by
necessary implication, it would follow that it was not the impugned rules that created
the two distinct cadres but that they existed independently of the rules and the only
charge that could be laid against the rules in this respect was that they failed to effectCol. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

an integration.
If the government order of September 27, 1957, did not integrate them into a single
service, it would follow that the two remained as they started as two distinct services.
If they were distinct services, there was no question of inter se seniority between
members of the two services, nor of any comparison between the two in the matter of
promotion for founding an argument based upon Art. 14 or Art. 16(1). They started
dissimilarly and they continued dissimilarly and any dissimilarity in their treatment
would not be a denial of equal opportunity, for it is common ground that within each
group there is no denial of that freedom guaranteed by the two articles.(3) Likewise,
in Jaisinghani,(4) the same note has been struck. To pursue precedents beyond a
point is a tiring adventure which reaches a point of no return. It is too late to upset
settled law save where the point of extravaganza is reached. Here such a situation is
yet to come.
Again, Sri Govindan Nair's submission suffers damage from the following
observations in Ganga Ram's(5) case.
The direct recruits and the promotees like the petitioners in our opinion, clearly
constitute different classes and this classification is sustainable on intelligible
differentia which has a reasonable connection with the object of efficiency sought to
be achieved.
The distinction between direct recruits and promotees as two sources of recruitment
being a recognised difference, nor obnoxious to the equality clauses, the provisions
which concern us cannot be struck down on the ratio of this decision.(1) Let us
examine the facts briefly to see whether the fundamentals of constitutional equality
are followed in the Service scheme. The army engineers remain in 'uniform' as it were
but wear a Survey of India overcoat. They do not merge or fuse into a single
integrated service with the civilian recruits but remain as an immiscible layer of the
Class I Service, the other layer being the civilians. The two wings remain close but
separate, not one homogenised family, as the various rules eloquently proclaim.
The Army engineers are formally part of the Survey of India but factually retain the
vital pattern of life of the army and close nexus with their official prospects,
conditions and control as if they had continued in the Army. The 1950 Rules bring
out the following incidents of service boldly. Notwithstanding their having left the
Corps Engineer Officers Service and entering the Survey Service, they continue to
wear uniforms, they get notional promotions in the Army when they earn
corresponding promotions in the Survey of India. More significantly, they secure
Army promotions only if they pass the requisite army tests ab extra. They can be
recalled by the Army and, for a certain period, they themselves may opt back to the
army. They continue to be broadly under the control of the Commander- in-Chief and
when inefficiency is noticed, they can be called back to the army for being dealt withCol. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

appropriately. They have to undergo the regular periodical drills in the army and
their disciplinary control is not divested from the Army Chiefs. There are many other
such details, the cumulative impact of which is that they have two masters, as it were;
they are in two Services, as it were; they are under two parents-natural and adopted.
This is a unique pattern where the Army members remain with one foot in the Army
and the other in the Survey of India. A conspectus of the facts and circumstances
governing the service convinces us that there is no total integration of the Army
personnel into the Survey Service. They are in it and yet out of it. This is what we may
call a sui generis Service and indubitably it can be asserted that they have not fully
fused into a common pool. Absent such complete integration, Article 14 or 16 cannot
be invoked.
The present case plainly falls in the hands-off zone and so the court must leave the
injustice, if any, to be corrected, if needed, by other processes. Our exploration has
revealed that the Survey of India is a civilian department rendering varied services to
non-Defence spheres of the Central Government and to State Governments. So its
composition cannot be reasonably confined to military personnel only. But critical
Defence-oriented work is also done, not only in seasons of national emergency but
also during peace spans. The border line between national security by the Defence
forces and developmental projects by civil services is becoming obsolete. Defence is
not only on the battle front but also in the strategic rear, in the farms and factories, in
efficient supplies and essential services, in mapping second lines of defence and
routes of troop movements, all of them having to be executed on a war footing. Wings
which can be mobilised at instant's notice, forces which will build with blitz speed,
have to be in the sheath to be drawn out like a sword on an alarm signal. More than
all, as earlier elaborated, the tasks of the Survey for the Defence are in times of
Emergency top priority items. So a sizeable section of men with army background,
and military aptitude, with quick reflexes and familiar with Defence team work, must
be kept in reserve all the time. It follows that a good proportion of Army engineers
are a 'must' for the Survey. It is enough to have 25% or 50% from military engineers a
matter of fine-tuning of policy for which the judiciary has no genius and the
Administration has a reach of materials and range of expertise so that Courts must
keep out, save where irrational criteria, irrelevant factors, mala fide motives or gross
folly enter the verdict.
Have any such invalidatory infirmities been established by the challengers here ? If
the induction of the army engineers has a nexus with the raison d'etre of the Survey
of India, the exact dosage needed to be drawn from that source for functional
adequacy is not susceptible of judicial measurement. If gross exaggeration is indulged
in to boost the military component or non-existent or illusory requirements are
invented for the same purpose, taking for granted judicial gullibility or jurisdictional
exile, the Court will call the bluff. But here 50% of Class I services, from a historical
need-based or other approach, cannot be called irrational, impertinent or
improvident.Col. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

Likewise, the award of the length of commissioned services in the Army as service in
the Survey of India cannot be dismissed as arbitrary or irrelevant. The necessity to
attract such officers is a factor. The reality of their engineering experience on
commission cannot be wished away. The value of such experience for the Survey of
India with Defence commitments argues itself. Whether such services should be
given credit wholly or at all in the new Service is more a matter of pragmatic wisdom
beyond the bounds of irrationality, arbitrary fancy or departmental quasi-nepotism.
It is difficult to dislodge the rules, fixing the quota and grafting of service while on
Army Commission on to the Survey of India service, as favoured treatment devoid of
rational foundation. If you need such army commissioned engineers-and the Survey
for its success wants them-you have to pay the fair price, not ransom. That is all there
is to it.
Sri Govindan Nair, with assertive argument, gave us anxious moments when he
pleaded for minimum justice to the civilian elements. He said that the impugned
rules were so designed, or did so result in the working, that all civilians, recruit or
promotee, who came in with equal expectations like his military analogue, would be
so outwitted at all higher levels that promotions, even in long official careers would
be hopes that sour into dupes and promises that wither away as teasing illusions. In
effect, even if not in intent, if a rule produces indefensible disparities, whatever the
specious reasons for engrafting service weightage for the army recruits, we may have
had to diagnose the malady of such frustrating inequality. After all, civilian entrants
are not expendable commodities, especially when considerable civil developmental
undertakings sustain the size of the service. And their contentment through
promotional avenues is a relevant factor. The Survey of India is not a civil service
'sold' to the military, stampeded by war psychosis. Nor does the philosophy of Art. 14
or Art. 16 contemplate de jure classification and de facto casteification in public
services based on some meretricious or plausible differentiation. Constitutional
legalistics can never drown the fundamental theses that, as the thrust of Thomas's
case(1) and the tail-piece of Triloki Nath Khosa's case(2) bring out, equality clauses in
our constitutional ethic have an equalising message and egalitarian meaning which
cannot be subverted by discovering classification between groups and perpetuating
the inferior-superior complex by a neo- doctrine. Judges may interpret, even make
viable, but not whittle down or undo the essence of the Article.
This tendency, in an elitist society with a dischard caste mentality, is a disservice to
our founding faith, even if judicially sanctified. Subba Rao J. hit the nail on the head
when he cautioned in Lachhman Das v. State of Punjab:(1) The doctrine of
classification is only a subsidiary rule evolved by courts to give a practical content to
the said doctrine. Overemphasis on the doctrine of classification or an anxious and
sustained attempt to discover some basic for classification may gradually and
imperceptibly deprive the article of its glorious content. That process would
inevitably end in substituting the doctrine of classification for the doctrine of
equality; the fundamental right to equality before the law and the equal protection ofCol. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

the laws may be replaced by the doctrine of classification. The quintessence of the
constitutional code of equality is brought out also by Bose, J. in Bidi Supply Co.
case(2) The truth is that it is impossible to be precise, for we are dealing with
intangibles and though the results are clear it is impossible to pin the thought down
to any precise analysis. Article 14 sets out, to my mind, an attitude of mind, a way of
life, rather than a precise rule of law. It embodies a general awareness in the
consciousness of the people at large of something that exists and which is very real
but which cannot be pinned down to any precise analysis of fact save to say in a given
case that it falls this side of the line or that, and because of that decisions on the same
point will vary as conditions vary, one conclusion in one part of the country and
another somewhere else; one decision today and another tomorrow when the basis of
society has altered and the structure of current social thinking is different. It is not
the law that alters but the changing conditions of the times and article 14 narrows
down to a question of fact which must be determined by the highest Judges in the
land as each case arises.
The constitutional goal is to break down inequalities steadily between man and man,
whether based on status or talent. Masses of men have suffered so long from social
suppressions and environmental inhibitions and to deliver them out of such
stratification and petrification came the message of social justice, blowing like winds
of change, with an accent on distributive justice ensured by the rule of real equal
opportunity. This basic mandate of equality cannot be subverted by the pragmatic
plea of classified equality without robbing Arts. 14 to 16 of their spiritual kernel in the
process of decoding. Status to values must wither away in the march to the
constitutional goals. Every Article of Part III is an article of faith of our nation and is
the formal expression of a moral-spiritual mandate, not a string of words whose
meaning of meanings can be played with by intellectual exercises favouring the
Establishment. The paramount law is value-loaded. Our freedom is in peril if equality
is by judicial reconstruction, a refined validation of inequality. Princes shall be
treated equally but pariahs will continue where they are-Why? because Art. 14 means
only equality among equals, a self-evident statement without solemn
pronouncement. Mr. Justice Subba Rao in Lachhman Das's case(1) warned against
this pernicious potential. We pollute our cultural stream if we narrow the flow of
constitutional equality to the little trickle of equals being made equals. The dynamic
demand of levelling up unequals to the level of the higher brackets is non- negotiable
albeit gradual.
This caveat is sounded in the last paragraph of the majority judgment in Triloki
Nath(2) and is writ large in the whole of the concurring minority judgment. It binds.
But we hope that this judgment will not be construed as a charter for making minute
and microcosmic classifications. Excellence is, or ought to be, the goal of all good
government and excellence and equality are not friendly bed- fellows. A pragmatic
approach has therefore to be adopted in order to harmonize the requirements ofCol. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

public services with the aspirations of public servants. But let us not evolve, through
imperceptible extensions, a theory of classification which may subvert, perhaps
submerge, the precious guarantee of equality. The eminent spirit of an ideal society is
equality and so we must not be left to ask in wonderment. What after all is the
operational residue of equality and equal opportunity?
The point Sri Govindan Nair made from Triloki Nath(3) is, on principle, well taken
but on facts, fallacious. The learned Attorney General, in the last instalment of
information furnished in the course of his reply, did convince us that no such disaster
as was painted did or would befall unless we take a myopic view.
If we had been satisfied that the end-product of the provision (Rule 5) was a
manipulation of continued seniority, beyond allowance for some differences, a
perpetual suppression of the civilian wing and a back-door entry into and occupancy
of all higher positions by the military men, it might have been a mockery of equality.
But the story is that some advantage is secured by the military recruits which is
intended and justified. Certainly, in the promotional scale this will be reflected. But
no monopoly of all promotions vests in the commissioned recruits. It is a case of
fluctuating fortunes, inevitable in interlacing two sets of people coming from two
sources with different backgrounds and assets. As expressed earlier, rigid or
relentless equalisation of divergent categories who have been brought into one
Service is the Procrustean bed process, contrary to democratic social dynamics.
In the first few years, the army wing had a better deal but in the next spell the civilian
wing more than made up. In the next span some change occurs and a projection into
the decade ahead shows that the civilians will outnumber the army men at the next
two tiers. Maybe, the Surveyor General may continue to be a 'uniformed' engineer.
We do not see the pathetic picture held out by counsel and the differences we do
notice are distances away from the creation of class legislation. We do not strike
down the rule as constitutionally obnoxious.
Sri Govindan Nair drew our attention to Pay Commission Reports which had strongly
recommended fair treatment to the civilian wing by making the higher positions
realistically accessible to them. Prima facie, there is some grievance if promotions at
the top are totally sealed off, not in law but in fact. And simmering discontent of a
whole wing is no small matter. Maybe, when the apex is occupied always by a 'brass'
boss the working of the rules and of the department may be tilted. We do consider
that recommendations of the Pay Commission deserve Central Government's early
attention. Flexible provisions for promotion to higher positions which will not make
the department lop-sided, or vertical division of the civilian and military wings
without injury to integrity and efficiency may meet the needs of equality. Policy is for
the Executive, not the Judicative wing. We find no unconstitutionality but discontent
should not be neglected in good government.Col. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

A measure of agreement, with marginal differences in the interpretation of the rules,
emerged in the course of the debate. We may as well set it down to avoid future
doubt. The learned Attorney General stated, with a view to silence the grievance of
the respondents, that for promotions beyond Superintending Surveyor, even
officiating S.S. are considered. It is not right to contend, he said, that only on
confirmation they are considered for promotion as Deputy Directors. Indeed, the
learned Attorney General pointed out that many Deputy Directors have been only
officiating SSs. We accept this as correct. If the officiating SSs are also included for
higher promotion based on merit the wind of inequity is, pro tanto, taken out of the
civilian sails.
Likewise, it is useful to clarify, in the light of the 1965 amendment to the Rules
providing for Class II officers being promoted straight as SS (not DSS), that the
recruitment to the DSS vacancies each year and to the SS by promotion from Class II
each year shall be as explained earlier.
Sri Govindan Nair, apprehending adverse winds in reversal of the High Court's
conclusion, raised fresh contentions which he was not permitted to put forward
because they were new and urged only in the Supreme Court. Creative thinking is
good, if it dawns in good time; for, according to our processual law, arguments
unborne on the record in the High Court have no chance as a post-script in the
Supreme Court. For instance, he urged that commissioned officers governed by the
Army Act could not be governed by any other Service Rules. So much so, the 1950
Rules, being a deviation from the Army Rules, were invalid. We illustrate but not
exhaust and, in any case, do not investigate.
The social philosophy of our fundamental law is a perennial flow, rising and falling,
rushing to push out obstructing rocks and slowing to erode a doctrinal distortion, the
power being geared to the good of the people in terms of Justice, social economic and
political. From this futuristic standpoint, every decision of the Supreme Court is the
focal point of the battle of the tenses, of social change versus social stability. We leave
these seminal issues for future consideration when they more directly demand
decision. Enough unto the day is the evil thereof.
We allow the appeals but intricate constitutional questions when decided by this
Court to declare the law under Art. 141 should be an exception to the conventional
rule of costs following the event, unless other circumstances warrant. So no costs.
P.B.R.                                      Appeals allowed.Col. A. S. Iyer & Ors. Etc vs V. Balasubramanyam & Ors on 24 October, 1979

