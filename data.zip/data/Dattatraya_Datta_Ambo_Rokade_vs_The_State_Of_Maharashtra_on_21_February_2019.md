Dattatraya @ Datta Ambo Rokade vs The State Of Maharashtra
on 21 February, 2019
Equivalent citations: AIR 2019 SUPREME COURT 4589, AIRONLINE 2019 SC
1015, 2020 CRI LJ 215, (2019) 13 SCALE 187, (2019) 4 ALLCRILR 218, 2020 (1)
ABR(CRI) 15, (2020) 1 ALD(CRL) 96, AIR 2020 SC( CRI) 98
Author: Indira Banerjee
Bench: Indira Banerjee, Deepak Gupta, N. V. Ramana
                                                                                           1
                                                                             REPORTABLE
                                      IN THE SUPREME COURT OF INDIA
                                     CRIMINAL APPELLATE JURISDICTION
                                    CRIMINAL APPEAL NOS. 1110-1111 OF 2015
                         Dattatraya @ Datta Ambo Rokade                         …Appellant
                                                        VERSUS
                         The State of Maharashtra                             …Respondent
                                                JUDGMENT
INDIRA BANERJEE, J.
1. These appeals are against the final judgment and order dated 21/24/25-3-2014 of the High Court
of Judicature at Bombay in Criminal Appeal No. 1202 of 2013/Criminal Confirmation Case No.6 of
2013 whereby the High Court has confirmed the conviction of the appellant under Sections 302,
376(2)(f), 377, 363, 364, 367 and 201 of the Indian Penal Code, as also under Sections 3, 4, 5(i) (l)
and (m) of the Protection of Children from Sexual Offences Act, 2012 (hereinafter referred to as
‘POCSO’) and, inter alia, affirmed SATISH KUMAR YADAV Date: 2019.10.24 17:07:01 IST Reason:Dattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

the sentence of death imposed on the appellant.
2. The facts giving rise to these appeals are abhorrent. The Complainant and his wife
being the second Prosecution Witness (PW) resided at Room No.3 in the ground floor
of Om Sai building, near the Shivsena Office in Koparigaon, with their son aged 10
years and two daughters aged 7 years and 5 years respectively.
3. It is the case of the complainant that he and his wife (PW 2), used to go to work,
leaving the three children at home. On 22.1.2013, PW 2 had to go to her paternal
home to visit her father.
When PW 2 returned home around 2.00 p.m. she found that her youngest daughter, being the
victim, was not at home. Assuming that the victim might be playing somewhere nearby, PW 2 left
for work at around 2.15 p.m. At around 4.30 to 5.00 p.m. PW 2 received a call on her mobile phone
from one Avaghade Mama, informing her that the victim was not at home. PW 2 thereafter returned
home, and started searching for the victim. She contacted the complainant as also her own parents
on mobile.
4. Thereafter the complainant, PW 2, her mother and brother all started looking for the victim in
Koparigaon, Vashi and Sanpada areas. As the victim could not be found, a missing report was lodged
with the APMC Police Station.
5. When the complainant and his wife (PW 2) reached home at around 2.30 a.m. after frantic efforts
to trace the victim, they found the victim lying nude and still in front of the door of their tenement,
with no movement.
6. The complainant contacted the police from his mobile and told the police that his daughter (the
victim) had been found lying still, without any movement. The complainant and PW 2 took the
victim to the Navi Mumbai Municipal Corporation Hospital, where the Medical Officer examined
the victim and declared her ‘brought dead’.
7. In the hospital the complainant noticed injuries on the body of victim. There was redness on both
shoulders and both thighs of the victim, and laceration in the vagina and anus of the victim.
Accompanied by the Inspector of APMC Police Station, who had come to the hospital for
investigation, the complainant went to the APMC Police Station and lodged a First Information
Report, on the basis of which Crime No.120/2013 was registered by the APMC Police Station.
8. An inquest of the body of the victim was conducted and photographs of the body were taken.
There were injuries. The vagina and the anus of the deceased victim was lacerated and blood was
oozing out. On 23.1.2013, Dr. Bhushan Jain, assisted by Dr. Prerna Thakur, conducted post mortem
examination of the deceased victim. Dr. Bhushan Jain also noticed injuries on the private part, anus,
below the eye lid and above the upper lip. He collected the blood of the deceased victim for DNA
mapping and grouping and also collected her vaginal and anal swab for detection of sperms. The
samples were kept for chemical analysis.Dattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

9. Dr. Bhushan Jain who prepared the post mortem report (Exhibit 48) opined that the cause of
death of the victim was asphyxia due to smothering, associated with head injuries and sexual
assault. Dr. Bhusan Jain deposed that all the five injuries were possible by repeated sexual acts and
forceful penetration. He opined that all these injuries were sufficient to cause instant death in the
ordinary course.
10. In the meanwhile, on 23.1.2013 investigation commenced. PW 26 was the Investigating Officer.
on 23.1.2013 at about 7.15 p.m., Panchnama (Ex.30) of the place where the deceased victim was
found, was recorded in the presence of one Parashuram Mahadu Thakur, who deposed as the tenth
prosecution witness (PW
10). A plastic bag of Surf Excel with plastic and two pieces of CDs were found on the spot. These
were separately seized and packed and sealed under Panchnama (Ex.30).
11. The accused-appellant along with his wife Asha (PW 18) two sons Rupesh and Mahendra (PW
19), two daughters, Manisha and Nisha (PW 20) and a grandson Omkar used to reside in Room No.
8 of the same building, adjacent to the tenement of the complainant.
12. The accused-appellant had been unemployed for four years, and sat idle at home. Omkar the
grandson of the accused- appellant used to be at school from 12.00 noon to 6.00 p.m. All other
family members of the accused-appellant used to leave for work during the day. The
accused-appellant used to stay at home alone.
13. It is the case of the prosecution that on 22.01.2013, in the afternoon, the accused-appellant took
the victim to his house, raped her, had unnatural sexual intercourse with her causing her head
injury and smothering her, as a result of which she died. On the same night at around 2.00 a.m., the
accused-appellant had gone outside the house and on 23.01.2013, the accused-appellant went to the
house of his brother at Kamothe without informing his wife, Asha (PW 18). On 24.01.2013 at about
07.30 p.m., PW 18 i.e., wife of the accused-appellant found the accused-appellant was in tension and
asked him to go to their family doctor.
14. On 24.01.2013 at about 7.30/8.00 p.m., PW 7 being the Family Doctor, examined the
accused-appellant and found that the accused-appellant was tensed and his blood pressure was
high. The Head Constable, Gejage, (PW 15) who had been making inquiries from the residents of
Om Sai Building, had left his mobile number with the residents of the building including Mahendra
(PW 19), the son of the accused-appellant so that they could contact him if they got any information
with regard to the incident.
15. It was the case of the prosecution that the accused-appellant used to force himself on his wife
and have sexual intercourse with her without her consent two to four times a week. Furthermore, in
2004, when the accused-appellant and his family members were residing at Village Dudhanoli, the
accused-appellant had outraged the modesty of a lady, Suvarna (PW 6) while she was attending to
the call of nature. It is alleged that the accused-appellant was assaulted by villagers because of the
aforesaid incident. The accused-appellant and his entire family, therefore, had to leave VillageDattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

Dudhanoli forever.
16. The prosecution has alleged that considering the antecedents of the accused-appellant and his
conduct after the incident, PW 19 suspected that the accused-appellant might be the culprit who had
committed the ghastly crime.
17. On 24.01.2013, PW 19 contacted the Head Constable, Gejage (PW 15) and told him that he
suspected the accused-appellant of being guilty. Thereafter, on the night of 24.01.2013, the said
Head Constable, Gejage, (PW 15) and Senior Police Inspector, Kambale took the accused-appellant
to the office of Crime Branch for inquiry. On 25.01.2013, the accused-appellant was arrested and the
clothes on his person, i.e, blue coloured full pants, Bermuda pants and a yellow shirt were seized
under panchnama, which is marked Ex. (Exhibit) 28. On 25.01.2013, the Investigating Officer,
Police Inspector, Bhong, being the 26th Prosecution Witness (PW 26), went to the house of the
accused-appellant along with a team from Forensic Science Laboratory and searched the house in
the presence of panchas, the Forensic Laboratory team and daughter of the accused-appellant,
Nisha (PW 20).
18. Three cushion covers from the Sofa, a cloth for cleaning the floor and a sari used as a bed-sheet,
all stained with blood, were seized. On 25.01.2013 itself, the accused-appellant was examined by Dr.
Tambe (PW 8), who found that the accused-appellant was in sound physical and mental condition.
On 26.01.2013, the accused- appellant made a statement in the presence of Panchas on the basis of
which which blood stained white coloured plastic gunny bag, blood stained orange coloured shirt
and black pants of the deceased were recovered from the debris near Om Sai Building.
19. The complainant and his wife being the parents of the victim, identified her clothes. It is alleged
that on 27.01.2013, Vinod and Sanjay being the 4th and 5th Prosecution Witnesses approached the
Investigating Officer, Bhong (PW 26) and told him that on 22.01.2013, they had a meeting in the
office of 10 th Prosecution Witness (PW 10), Parshuram, which was situated in a building about 15
feet away from Om Sai Building. These witnesses told the police that after they came out of the office
at about 4.30 p.m they were standing under a parking shed and talking. At that time, they saw a
short old man carrying a white bag coming from the side of the staircase and going into a lane. The
man kept the bag in the lane which was in front of the parking shed.
20. PW 4 and PW 5 identified the accused-appellant, as the same person, who had kept the bag in
the lane, in a test identification parade conducted by the Executive Magistrate, Ratnanjali (PW 21).
This very bag was recovered at the instance of the accused- appellant under Panchnama and packed
in a packet (Ex.35 and Ex.36). Both PW 4 and PW 5 identified the bag as the same bag which had
been carried by the accused-appellant and dumped in the lane.
21. It is stated that on 29.01.2013, the accused-appellant was produced before Dr. Thakur, the
Casualty Medical Officer in Navi Mumbai Municipal Corporation Hospital (PW 16). Dr. Thakur
collected blood of the accused-appellant in two plastic containers provided by the Forensic Science
Laboratory, sealed the packet containing the plastic containers, filled in the identification form,
attested the photograph of the accused-appellant and obtained thumb impression of theDattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

accused-appellant on identification form
22. The clothes of the accused-appellant, the white plastic bag, the clothes of the deceased, sealed
bottle containing blood of the accused-appellant and his semen, hair and nail were sent to the
Forensic Science Laboratory. The blood, hair, nail, vaginal swab and anal swab of the victim were
also sent to the Forensic Science Laboratory. The reports received by the Investigating Officer,
Bhong (PW 26) from the Forensic Science Laboratory showed that D.N.A. profile of blood detected
on the plastic bag, orange shirt of the deceased and sari cum bed-sheet seized from the house of the
accused-appellant was identical with D.N.A. profile of the deceased victim. The reports also showed
that D.N.A. profile test of semen conducted on underwear (Bermuda pants) of the
accused-appellant, and the vaginal swab and anal swab of the victim matched the D.N.A. profile of
the accused-appellant.
23. Charges were framed against the accused-appellant under Sections 363, 364, 367, 377, 302, 201
and 376 or alternatively 376(2)(f) of the Indian Penal Code. Charges were also framed under
Sections 3, 4 and 5 of the Prevention of Children from Sexual Offences Act (hereinafter referred to
as ‘POCSO). The accused- appellant pleaded not guilty and claimed to be tried. His defence was of
denial and false implication.
24. The prosecution examined 27 witnesses. No witnesses were examined on behalf of the
accused-appellant. Shorn of unnecessary details, the first prosecution witness, being the
complainant (PW 1), deposed that when he returned home at around 3.20 a.m. on 23.1.2013, after
frantically searching for his daughter, he found his daughter lying naked in front of the door of his
house. She was still and there was no movement. He informed the police. The victim was taken to
Navi Mumbai Corporation Hospital where she was declared dead. PW 1 described the injuries on the
victim i.e. redness on both shoulders and both thighs. He said there was blood in the private part of
the victim and there was a laceration in the vagina. The anus was swollen. He identified the
complaint and stated that its contents were correct. PW-1 identified the following articles: -
a. A sealed packet which contained a black thread worn by the victim (Marked as
Articles 1 and 1A).
b. A sealed packet containing a plastic bag of surf excel powder of 1.5 kg (Marked as
Article 2 and 2A).
c. A packet containing two pieces of CD (Marked as Articles 3 and 3A.
d. One sealed packet containing an orange coloured shirt, which he identified as shirt
of the victim. (Marked as Articles 25 and 25A) e. Another sealed packet containing
black half pants which the witness identified as pants of the victim. (Marked as
Articles 24 and 24A)
25. PW-1 deposed that his daughter, the victim, had been raped and murdered. In his
cross-examination, he admitted that he had in course of his examination expressedDattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

suspicion against one Arun Pawar. Records reveal that the said Arun Pawar, a worker
of the Shiv Sena Party had been arrested, but later released and charges against him
dropped after investigation.
26. The 2nd Prosecution Witness (PW 2), being the wife of the complainant, and
mother of the victim, in essence, reiterated what her husband had said. She also
identified the black thread and the clothes worn by the victim. She also reiterated
that initially she and her husband being the complainant had suspected that Arun
Pawar was the culprit. She, however, denied that there had been any compromise
between the complainant and his wife (PW 2) and the said Arun Pawar.
27. The 3rd Prosecution Witness (PW 3) is a pancha, who signed on a panchnama at
the hospital. She only put her signature on the packets containing the thread and the
clothes of the victim.
She also described the injuries on the victim. None of the first three witnesses have said anything to
even suggest who could be the culprit.
28. The 4th Prosecution Witness (PW 4) who claims to run a construction business, stated that he
had business dealings with persons residing at Koprigaon. On 22.1.2013 he had gone to meet
Parshuram Thakur at the Shiv Sena Office at Koprigaon. His friends Sanjay Govari and Devidas
Dalavi, a resident of Airoli were also there at the office. This witness deposed that after coming out
of the Shiv Sena Office, he, Sanjay Govari and Devidas Dalavi were standing below a shed in front of
a building near the said Office. While they were standing below the shed, they saw an old man come
from the side of the staircase, holding a white bag, which he kept in the lane which was in front of
the parking shed. The old man was short and except for Bermuda pants that he had been wearing,
he was bare bodied. According to this witness, he along with Devidas Dalavi and Sanjay Govari once
again went to the office of Parshuram Thakur after a few days, when Parshuram Thakur told them
about the rape and murder of a girl in a building in front of his office, which had taken place on
22.1.2013.
29. This witness stated that on hearing of the incident, he told Parshuram Thakur that on 22.1.2013
that he had seen an old man going into the lane in front of the shed under which they were standing,
with a bag. Parshuram Thakur then told this witness to inform this to the police. On 27.1.2013, this
witness along with Sanjay Govari who has also deposed as the fifth witness, went to the police
station, met the police officer and disclosed what he had seen, which was recorded by the police.
30. Thereafter on 7.2.2013, this witness received a letter informing him that he should meet the
Tehsildar. On 8.2.2013, this witness along with Sanjay Govari and Devidas Dalavi went to the
Tehsildar, and thereafter, along with another lady, went to Taloja jail where he identified the
accused-appellant as the person who had kept the bag in the lane.
31. This witness identified a white colour plastic bag taken out from a bag, marked Articles 23 A and
23. He also identified the Bermuda pants as the same pants worn by the accused-appellant. InDattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

cross-examination, he said that the old man with the bag did not arouse his suspicion. If his
suspicion had been aroused, he would have gone to the police station the same day.
32. The 5th Prosecution Witness Sanjay Kamlakar Govari (PW 5) reiterated what had been stated by
PW 4. He also identified the plastic bag as the same one which had been dumped in the lane by the
accused-appellant. He read out the description printed in the inner side of the plastic bag “crystal
white sugar sulphiton Jawahar sugar hupari Kolhapur (Maharashtra State) India S-30 sucrose 50
kgs. 2009-2010 best before 3 years”. In cross examination this witness stated that he had not seen
any identification mark on the white bag on that day and he also stated that when he saw the white
bag, he did not have any suspicion. He reiterated that he had seen the old man dropping the white
plastic bag in the lane.
33. The 6th Prosecution Witness (PW 6), a teacher and a resident of Dudhanoli, Taluka Murbad,
District Thane deposed that the accused-appellant had tried to outrage her modesty when she had
gone to relieve herself in the open field in the year 1998 i.e. about 15 years before the present
incident. She said that she and her husband had beaten up the accused-appellant and that night, the
accused-appellant left the village permanently. The aforesaid incident has no connection with the
rape and murder of the victim. In cross examination she admitted that she had not lodged any
complaint against the accused-appellant.
34. The 7th Prosecution Witness (PW 7), a Homeopathic Doctor, deposed that on 24.1.2013 at about
7 p.m. the accused- appellant had visited her complaining of uneasiness. She said she noticed that
the accused-appellant was suffering from tension and his blood pressure was slightly high. She
thought that the accused- appellant might be suffering from acidity and accordingly prescribed
medicines. The evidence of this witness does not by any stretch of imagination, establish the guilt of
the accused-appellant for the offence alleged.
35. The 8th Prosecution Witness (PW 8) an Associate Professor in Terana Medical College, Surgery
Department deposed that on 25 th January, 2013 he was on call duty at Navi Mumbai Municipal
Corporation General Hospital. On that day he examined the accused-appellant who had been
brought by the police. On examination, the accused-appellant appeared to be in sound physical and
mental condition. On examination of private part that is genital, no external injury was found but
“bilateral scrotal enlargement was seen”. Apart from that there was no external injury. Genital size
was normal. There was no external deformity in genital. Testicular reflex was normal. Penis was
uncircumcised, Smegma was absent. There were no signs of sexually transmitted disease. There
were no Injuries on glans penis.
36. This witness deposed that glance and sulcus was washed and washed material was collected in a
glass bulb for examination. Blood was collected for blood grouping and examination. Samples of
pubic hair and scalp hair were also collected. There was nothing to suggest that the patient was
impotent. However, the witness volunteered that on physical examination it was not possible to
draw 100% conclusion about potency. The evidence of this witness also does not contain anything
material, that points to the guilt of the accused-appellant , for the offence alleged.Dattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

37. The 9th Prosecution Witness (PW 9), a driver by occupation, is the Panch for the yellow shirt,
blue pants and blue Bermudas under the pants of the accused-appellant which had been seized by
the police. His evidence reveals that these clothes were found on the body of the accused-appellant
on 25th January, 2013 at about 1.45 P.M., that is, almost 48 hours after the incident.
38. The 10th Prosecution Witness (PW 10), Parshuram Mahadu Thakur, a Builder in the business of
construction, owned an apartment in a building in the ground floor of which there was a Shivsena
office. He said that on 23rd January, 2013 at about 7.15 a.m., police officer Dighe called him near
Om Sai Niwas. PW 10 stated that he had shown the police officer the spot where the dead body of
the victim had been found. By that time, the dead body had been removed. He also deposed that at
the spot, a bag of Surf Excel and two pieces of CDs were found. On the bag of Surf Excel there were
some blood stains. The bag of surf excel and pieces of CDs were separately packed by the police. The
police recorded spot panchnama. PW-10 identified his signature in the panchnama and deposed its
contents were correct.
39. This witness deposed that PW Nos. 4, 5 and an agent Dalavi, used to come to his office during
the period between 19 th January, 2013 and 22nd January, 2013. On 22nd January, 2013, they had
come to his office at around 2/2.30 P.M. and they were there in his office till 4.30 p.m.
40. This witness said that on 26th January, 2013 the aforesaid persons again came to his office for
discussion in relation to a plot. While talking to them, this witness told them that on 22 nd January,
2013 there had been rape and murder of a five year old girl. The police were inspecting a bag. On
hearing this, PWs 4 and 5 and Dalavi mentioned that they had seen a man who seemed frightened,
drop a bag. This witness deposed that he had advised the aforesaid persons to go and inform the
police. Thereafter, the three persons left.
41. This witness stated that, on 27th January, 2013 he was called by A.P.M.C. police station and his
statement was recorded. This witness also deposed that he knew the accused-appellant, who had
been residing in Room No.8 of Om Sai Niwas building as a tenant. The family members of the victim
were residing in Room No. 3 in the same building. The tenement of the accused-appellant and as
well as the deceased victim are in the ground floor of Om Sai Niwas building.
42. Significantly there are inconsistencies between the statement of this witness and the statements
made by PW 4 and PW 5, who did not say that the man dropping the bag seemed frightened. On the
other hand they said that the man did not arouse their suspicion.
43. The 11th Prosecution Witness (PW 11), Arvind Madhavji Gajara is the Panch in whose presence,
the tenement of the accused-appellant was searched. He deposed that on 25 th January, 2013 he had
gone to Koparigaon in connection with his business. He saw that many persons had gathered near
the Om Sai building. It was about 5.00 p.m. The police constable Rane called this witness. At that
time the accused-appellant, a photographer and a panch by the name of Patil were was also present.
At the request of the police he agreed to act and acted as Panch. The police took him to room No.8 of
Om Sai apartment. A police officer rang the bell at the door. It was opened by a lady, who said that
her name was Nisha. The police officer told Nisha that they wanted to search the house and askedDattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

whether she had any objection. Nisha replied that she had no objection.
44. This witness said there was one room which was partitioned and there was a kitchen. There was
a sofa on which a bed sheet was lying. They noticed blood stains on the bedsheet. There were also
blood stains below the sofa set.
45. This witness deposed that one of the persons in the search team scratched the blood stains to
collect the dried blood. In the presence of this witness, the blood stained sheet on the sofa set, a
cloth for cleaning the floor tiles lying on the window, a saree used on the bed as a bed sheet were
also packed. In all six articles were seized and six labels were prepared. A bag in which the articles
were packed was separately marked. The evidence of this witness only establishes that the tenement
of the accused-appellant was searched with the consent of the accused-appellant’s daughter and
some articles seized. During the search blood stains were noticed, which were scraped for
examination.
46. The 12th Prosecution Witness (PW 12), named Mustaqali Asgarali Ansari, a Carpenter by
profession stated that on 26 th January, 2013, he went to fill petrol in his motor-cycle at a petrol
pump near APMC police station at about 3.00 p.m. At that time, a police constable, by name
Mandole, called him and told him to come to APMC Police Station. He went to the APMC police
station along with the constable. In the police station, one police officer by name Bhong and another
panch More, one lady police and three police constables were present. The accused-appellant, whom
this witness identified in Court, was also present in the police station.
47. According to PW 12, in the police station, the accused appellant made a statement that he had
kept the dead body of the girl in a bag and kept the said bag behind the staircase.
48. PW 12 deposed that the accused-appellant was taken to the building and from inside he took out
clothes from the white bag, the capacity of which might be 50 to 60 kgs. He identified the clothes
namely the black half pants and an orange shirt. PW 12 deposed that the clothes were taken out
from the bag.
49. Significantly even though this witness (PW12) was a panch to the seizure of the white bag, the
printing inside the bag which the PW claims to have seen, were not noticed by him.
50. The 13th Prosecution Witness Dr. Bhushan Vilasrao Jain (PW 13) conducted the post mortem
examination on the body of the victim. He noticed the following injuries:
“(1) Lacerated wound seen over posterior vaginal wall with width 0.5 c.m. muscle
deem hymen torn at 6 O’ clock position reddish blood oozes out.
(2) Lacerated wound over right lateral vaginal wall 1 x 0.2 c.m. muscle deep reddish,
blood oozes out.Dattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

(3) Two lacerated wounds seen over anal region at 12 O’clock and 3 O’clock position
of size 2 x 1 c.m.
mucosa deep and 1 x 0.5 c.m. mucosa deep respectively reddish.
(4) Two tiny abrasions seen over left maxillary region below eyelid laterally 0.5 x 0.3 c.m. each
reddish.
(5) Aberated contusion over upper lip mucosal aspect in a middle region 2.5 x 1.5.”
51. He deposed that all the injuries were ante-mortem in nature and he further deposed of internal
examination.
“2. On internal examination I noticed haemorrhage under scalp over occipital region 5 x 3 c.m.
reddish and meninges were congested. Brain matter congested and
-oedmatous. On cut section petechial haemorrhages seen over white matter. Both lungs were
congested and oedematous with petechial haemorrhages.
3. Thoracic cavity contained dark fluid blood. Stomach contained 200 cc. semi digested rice, dal
sabu like food material.
All visceral organs were congested.”
52. This witness deposed that they kept blood for DNA mapping. Blood for grouping, nail clipping of
both hands and plucked scalp hair for grouping and detection of foreign body. They also kept
vaginal and anal swab for detection of sperms as also blood for chemical analysis. He opined that the
cause of death is asphyxial death due to smothering associated with head injury and sexual assault.
53. This witness deposed that the injuries mentioned in column 17 of the postmortem report were
possible by repeated sexual acts and forcible penetration of the penis in the vagina. The victim may
have suffered some of the injuries while she was trying to rescue herself from the clutches of the
culprit. The injuries referred to as injury Nos. 4 and 5 in the postmortem report may have been
caused by the culprit by pressing the mouth of the victim with his hands. The injury described in the
Report as injury No.4 may have been caused by finger nails.
54. This witness deposed that the injury shown in the postmortem report as injury No.19 over the
head and under the scalp could have been suffered if the head had hit any hard object while the act
of rape was committed.
55. PW-13 deposed that the injuries shown as injury Nos. 1 to 5 were sufficient to cause instant
death. The injuries shown as injury Nos. 4 and 5 could also cause death. The Cyanosis in finger nails,
petechial over brain and lungs and dark fluid blood were cardinal signs of asphyxia.Dattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

56. In cross-examination, PW 13 said that there was no injury to the brain substance. However,
death was possible by reason of the injuries that were seen. He, however, said in his
cross-examination that there was hemorrhage. This witness deposed that pressing of mouth and
nostril causes smothering which leads to asphyxia and consequential death. In cross-examination,
this witness said that he had not taken blood sample of accused-appellant for the purpose of DNA as
blood sample was not produced before him. The evidence of this witness clearly establishes that the
victim was raped and killed. There is nothing in his evidence that implicates the accused-appellant .
57 The 14th Prosecution Witness (PW 14), a neighbour of the complainant and the
accused-appellant deposed that the accused- appellant had two daughters, two sons and one grand
son, none of whom stayed at home between 12 and 6 p.m. She deposed that the accused-appellant
used to stare at her by opening the door slightly or by looking into the mirror and when she told this
to another neighbour, that neighbour told her that the accused-appellant was in the habit of staring
at women. She said that she did not say anything to the accused-appellant, considering his old age.
In cross examination, this witness deposed that the accused-appellant did not whistle at women nor
did he tease the women of the building. He used to keep his door open and look into a mirror. Her
evidence in cross-examination reveals that the accused-appellant was arrested on 25th January,
2013 and on 26th January, 2013, one Arun Pawar was arrested. This witness’s evidence, at best
raises doubts about the character of the accused-appellant.
58. The 15th Prosecution Witness (PW 15) a Head Constable of the Crime Branch deposed that the
Senior Police Inspector called him and his colleagues for the purpose of investigation in relation to
the murder of the victim. He deposed that he reached Koparigaon on 23rd January, 2013. He visited
each room in Om Sai Building and interrogated the residents. He had also given his mobile number
to the residents so that he could be contacted in case any information was forthcoming.
59. This witness deposed that on 24 th January, 2013, PW 19 Mahendra Rokade, son of the
accused-appellant called him up and told him that he was suspecting the involvement of his father,
the accused-appellant, in the rape and murder of the victim.
60. The PW-19 allegedly told this constable that on the night of 22nd January, 2013 his father was
stressed up. He also said that on an earlier occasion his father had tried to outrage the modesty of a
woman at his native place Dudhanoli. This witness further stated that on the night of 24th January,
2013 this witness and another police constable alongwith senior police inspector went to the Om Sai
Building on receiving secret information that the accused- appellant had come home. According to
this witness the wife, daughters and grandson of the accused-appellant and the accused- appellant
were at home at that time. The accused-appellant was found in stress. The wife of the
accused-appellant said that the accused-appellant had outraged the modesty of a woman at
Dudhanoli. The accused-appellant was taken to the office of the crime branch. On 25th January,
2013, the accused-appellant confessed that he had committed the crime. From the evidence of the
witness it can only be deduced that PW-19 had called him up and expressed suspicion of
involvement of the his father in the rape and murder of the victim.Dattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

61. The 16th Prosecution Witness (PW 16), Dr. Prerana Anant Thakur deposed that she had
personally collected the blood of accused-appellant and handed over the sealed container along with
the prescribed identification form which she had filled in herself, to the police. She handed over the
prescribed form and sealed packet containing blood sample to police Naik B. No.1761 who took that
sample to Kalina Forensic Science Laboratory.
62. The 17th Prosecution Witness (PW 17), the owner of a photo studio named Balaji Photo Studio
deposed that he went along with the police to take photographs of Room No.8 of Om Sai Niwas. On
25th January 2013, he took photographs of the sofa and pillow lying on the sofa on which there were
blood stains. He took photographs of the bed and the floor under the sofa where there were blood
stains. His camera was a digital camera. He got the photographs printed and he handed over the
photographs along with memory card to the Investigating officer of the police station. He said that
he was paid Rs.350/- for the photographs. The PW-16 and PW 17 have also not implicated the
accused-appellant.
63. The 18th Prosecution Witness (PW 18), Asha Dattatraya Rokade, wife of the accused-appellant
said that she was residing in Room No.8 of Om Sai Building along with the accused-appellant, their
two sons, two daughters and a grand son (son of younger daughter, whose husband had expired).
She deposed that the accused-appellant was unemployed and stayed at home alone, while the other
members of the family went out to work and the grand child went to school. She said that on 22 nd
January, 2013 when she came back from work at around 7.30 p.m. she heard that the victim was
missing. She had dinner at about 1.00 a.m. after all the family members returned, after which they
went to sleep. She deposed that after 2.00 a.m., her husband went out of the house. On 23rd
January, 2013 at about 7.00 a.m. police knocked at the door of the house and inquired about the
victim. On 23 rd January, 2013 she left for work. When she left, her husband i.e., the accused-
appellant and their daughter Nisha (PW 20) were at home but when she came back home at about
7.30 p.m. she did not find her husband. On inquiry, her daughter Nisha (PW 20) told her that the
accused-appellant had gone to his brother’s house. She further deposed that on 23rd January, 2013
she had dinner and went to sleep. On 24th January, 2013 when she went out to work her husband
i.e. the accused-appellant came back. After returning at about 7.30 p.m., she made tea and served
tea to the accused- appellant. While serving tea she asked the accused-appellant why he was tensed
up. He replied that he was not feeling well. Thereafter she told him to go to hospital. The
accused-appellant went to Dr. Nilima Pawar.
64. This witness deposed that after her husband, the accused- appellant came back from the doctor,
he told her that he had raped and killed the victim. Thereafter at about 8.00 p.m. police took the
accused-appellant for inquiry. On 25th January, 2013, she was informed by her son Mahendra that
police had arrested her husband. He said that the accused-appellant had confessed to the crime
before the police. The evidence of this witness is of importance since she has deposed that the
accused-appellant confessed to her that he had raped and killed the victim.
65. Nothing much of substance has transpired from the evidence of the 19th Prosecution Witness
(PW 19), Mahendra, son of the accused-appellant, except that he had called up the police and
informed the police that he suspected the involvement of his father, the accused-appellant, in theDattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

rape and murder of the victim.
66. This witness reiterated the work schedule of the members of the family and school hours of his
nephew. He said that he had heard that the victim had gone missing and had later heard that the
victim had been raped and murdered. The police came to the building to make inquiries. This
witness further deposed that when he had heard that his father had suddenly gone to Kamothe he
became suspicious, in view of the past history of his father involving an incident at Dudhanoli
village. He further said that on 25 th January, 2013, the police contacted him and informed him that
his father had confessed to the crime. He also identified the articles seized as Articles Nos.18-A, 19-A
and 20-A. In cross examination, this deponent deposed that on 23rd January, 2013 he was sleeping
on the bed of the inner room having partition. At that time he did not find or see any stain on the
bedsheet. The bedsheet used to be changed every 4 or 5 days and covers of sofa set and cushion after
every two to three months. He also deposed that the flooring of the house is washed and cleaned
daily.
67. The 20th Prosecution Witness (PW 20), Nisha, daughter of the accused-appellant deposed that
on 25th January, 2013, in the evening, police came to their house with experts from the Forensic
Laboratory and a photographer. After taking her permission, the police seized sofa cover, cushion
cover, bedsheet and duster cloth. The expert found blood stains in the gap between the tiles on the
floor and on the sofa cover. The sofa cover, cushion cover and bedsheet were stained with blood. All
these articles were seized and the police obtained her signature and the signature of her father. She
identified the sofaset cover, cushion cover, bed sheet and the duster cloth for cleaning the floor. She
also identified the Bermudas of her father. She stated that when she was a young child she came to
know that her father had caught the hand of a woman and therefore, the family had to leave the
village Dudhanoli. In cross examination, this witness said that her father never spoke to her
unnecessarily. She said that she cleans utensils and cleans floor on every alternate day. She said that
she had not noticed anything abnormal on sofa, cushion or on the bed. Nothing significant has
transpired from the evidence of this witness except that the tenement of the accused-appellant had
been searched in the presence of forensic experts and a photographer. Photographs of the tenement
were taken, some articles seized and samples of blood scrapings collected for examination.
68. The 21st Prosecution Witness (PW 21), Ratnanjali Ravindra Sarnobat, deposed that he had
conducted the Test Identification Parade (TIP) and the witnesses Bhagat, Govari and Dalavi (PW-4
& PW-5) had identified the accused-appellant.
69. The 22nd Prosecution Witness (PW 22), the Sub-Inspector of police at AMFC police station
deposed that on 22nd January, 2013 he was on night duty from 9.00 p.m. onwards till 9.00 a.m. At
about 9.15 a.m. the complainant and his wife gave a missing complaint in respect of the victim. At
about 2.30 a.m. when he was patrolling out of the police station, he received a telephone call from
the APMC police station that the missing girl had been found but with no movement. She was being
taken to the Vashi Navi Mumbai Municipal Corporation Hospital (NMMC). The doctor declared the
girl was dead after which the complainant filed an FIR. There is nothing in the deposition of this
witness which establishes or points at the guilt of the accused-appellant. He only narrated the facts
leading to the missing report and the first information report, the condition of the dead body of theDattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

victim, the seizure of articles taking of photographs etc.
70. The 23rd Prosecution Witness (PW 23) deposed that he had carried blood samples of
accused-appellant to the Forensic Science Laboratory, Kalina for DNA profiling along with
identification.
71. The 24th Prosecution Witness (PW 24) attached to APMC police station as Police Naik deposed
that he brought back the DNA kit from the Forensic Science Laboratory, Kalina.
72. The 25th Prosecution Witness (PW 25), is the Assistant Investigating Officer in the case. She
deposed that as Assistant Police Inspector she had investigated the case. On 23rd January, 2013 at
about 5.00 a.m. she visited the spot and started making inquiries. She recorded the statement of the
mother of the deceased victim (PW 2).
73. On 26th January, 2013 she recorded the statements of some witnesses and recorded the
supplementary statement of the mother of the deceased. She also recorded the statements of the
wife of the accused-appellant, two daughters of the accused-appellant and other witnesses. Nothing
significant, which points to the guilt of the accused-appellant has transpired from the evidence of
PW-23, PW- 24 and PW-25.
74. The 26th Prosecution Witness (PW 26), the Senior Police Inspector and Investigating Officer
deposed that he reached Navi Mumbai Municipal Corporation Hospital at about 3.00 a.m. after
which he took the complainant to the police station and recorded the FIR. He deposed that on the
basis of the FIR, Crime No.20 of 2013 was registered. PW-26 deposed that on 23 rd January, 2013,
he sent Police Inspector Lavand to the spot and he recorded the spot panchnama (Exh.30). He
deposed that initially, the parents of the victim had expressed suspicion against one Pawar who was
taken in custody. On investigation nothing was found against him and accordingly report under
Section 169 of the Criminal Procedure Code was filed. On 24th January, 2013 this witness recorded
the statements of some witnesses. On 25 th January, 2013, staff of the crime branch produced the
accused-appellant before this witness. This witness interrogated the accused-appellant and arrested
him under panchnama. The clothes he was wearing at the time of his arrest was seized under
panchnama. The accused-appellant was wearing blue full pants, Bermuda pants and a yellow shirt.
This witness further deposed that on 25th January, 2013 he called a team from the Forensic Science
Laboratory who seized six articles from the house of the accused-appellant that is Article Nos.17-A,
18-A, 19-A, 20-A, and 21-A.
75. The seized articles were cushion covers, a cloth for cleaning the floor, a saree used as a bed sheet
which were sealed in six packets. He deposed that experts from the Forensic Science Laboratory
collected dried blood from the floor tiles beneath the sofa. The photographs of the sofa and other
articles were taken at the time of recording the spot panchnama. PW-26 further stated that on 25th
January, 2013 he got the accused-appellant medically examined and he also recorded the statements
of witnesses. On 26th January, 2013 the accused-appellant offered in the presence of two panchas to
show the place where he had put the clothes of the victim in a bag, which was the debris was by the
side of staircase of the Om Sai Building. The statement of the accused-appellant was recorded byDattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

this witness. The statement so recorded was signed by Panchas and the accused-appellant affixed his
thumb impression thereon. After that the accused-appellant took the Investigating Officer (PW 26)
and others to the side of the staircase of the said building where debris were lying and he took out a
plastic bag in which an orange shirt and black pants were found. The accused- appellant told the
Investigating Officer that the shirt and the pants were the clothes of the victim. This witness
deposed that the parents of the victim were called and they identified the clothes of the victim. There
were blood stains on the shirt, pants and the plastic bag. The articles were seized and sealed in the
presence of Panchas, whose signatures were obtained on the panchanama recorded on the spot.
76. This witness deposed that on 27th January, 2013 three witnesses Devidas, Vinod Bhagat and
Govari came to the APMC police station and got their statements recorded. Thereafter a test
identification parade was arranged. On 27 th January, 2013 he seized the memory card produced by
the photographer Rajesh Joshi (PW 17). From the evidence of this witness, it transpires that blood
samples collected for DNA profile were duly sent to the forensic laboratory. This witness deposed
that during the investigation, it transpired that the accused-appellant had raped the victim and
murdered her. After completion of investigation, this witness filed chargesheet.
77. The 27th Prosecution Witness (PW 27), an Assistant Chemical Analyzer in the Forensic
Laboratory, Kalina deposed that he went to APMC Police Station along with his team consisting of
four persons. The team went to Om Sai Building at Koparigaon. The accused-appellant was also
present along with the Police. In the tenement of the accused-appellant there was one hall and
kitchen and in the said hall there was a partition. When the door was opened they saw a sofa on the
right. On careful inspection, they found there were three cushions on the sofa and on the cushion
covers there were blood stains of the diameter 1 cm. to 2 cm. approximately. This witness deposed
that he tested the blood stains with the help of phenolphthalein and confirmed that the stains were
bloodstains. He deposed that three cushion covers which were bloodstained were removed from the
cushion and handed over to the Investigating Officer. This witness deposed that he saw that there
were blood stains on the floor near the middle leg of the sofa. He tested those stains with
Phenolphthalein and confirmed that they were blood stains. Dry blood was scraped and collected
with the help of cotton cloth and that cotton cloth was put into an envelope which was packed in a
polythene bag and handed over to the Investigating Officer. This witness has deposed that the team
saw bloodstained cloth on the window which was also tested and given to the Investigating Officer.
There was one cot in the inner side of the partition. The bed was covered with a saree. He collected
the scrapings of the blood stains on the saree for testing. It was confirmed that those were blood
stains but as the test of the semen identification consumes much time, the saree cover was handed
over to the IO with the instructions to properly seal each article and send the same to the Forensic
Science Laboratory. This witness also identified the articles.
78. As observed above, the oral evidence of PW-1 and PW-2 being the parents of the deceased victim
do not even suggest culpability of the accused-appellant. The 3 rd Prosecution Witness only a
Pancha who put her signatures on bag containing thread and clothes of the victim. The 4 th and the
5th Prosecution Witnesses have claimed that they had gone to visit Parshuram Thakur at the Shiv
Sena Office at Koprigaon on the day of the incident. After they came out of the office, they were
standing below a shed and talking, when they saw an old man come from the side of the staircase ofDattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

the building, holding a white bag which he kept in the lane in front of the parking shed. These
witnesses identified the accused-appellant as the man carrying the bag. They also identified the bag
as the bag which the accused-appellant had been carrying.
79. There are, however, serious loopholes in the evidence of these two witnesses. First of all, these
witnesses as per their own statement saw a man carrying a white bag. They did not go near the bag.
No reliance can be placed on the purported identification by the witnesses of the bag produced by
the police, as the very same bag which these witnesses had seen the accused-appellant carrying.
Furthermore, one of the witnesses stated in cross- examination that they did not suspect anything
when they saw the man carrying the bag. If the body of an eight year old child were being carried in
a bag that would have aroused some suspicion.
80. In any case, these witnesses deposed that the bag was left in the lane opposite the parking shed,
after they came out of the Shiv Sena Office building, which was around 4.30 p.m. The naked body of
the deceased victim was first discovered in front of the door of the tenement of the complainant at
around 2.00 a.m. at night. If the body had been dumped outside the door in the early evening, the
body would surely have been noticed earlier.
81. The evidence of PW 6 that the accused-appellant had tried to outrage her modesty about 15 years
ago, has no bearing to the incident of rape and murder of the deceased victim. Admittedly this
witness had not lodged any police complaint against the accused-appellant.
82. The evidence of PW7 is also of no relevance. This witness, a Homeopathic Doctor, deposed that
on examining the accused- appellant, she found him suffering from tension and his blood pressure
was slightly high. As per her own evidence she thought that he might be suffering from acidity.
83. Similarly the evidence of PW 8, a doctor who had examined the accused-appellant, does not
contain anything material to establish the guilt of the accused-appellant for the offence alleged.
84. The 9th Prosecution Witness is only a Panch in whose presence the clothing of the
accused-appellant was seized. He stated that these were the clothes which the accused-appellant had
been wearing about 2 days after the incident. The 10th Prosecution Witness only corroborated that
the 4th and 5th witnesses had come to his office and they had later told him what they had seen on
22 nd January, 2013.
85. Even though, as observed above, there is nothing in the evidence of any of the witnesses, except
the evidence of PW-12 and PW-18 and the weak evidence of the PW Nos. 4 and 5 purported to be
corroborated by the PW-10, to prove the accused-appellant guilty of the offences alleged, the
forensic reports along with the extra-judicial confession made by the accused-appellant to his wife
PW-18, clearly establishes the guilt of the accused-appellant.
86. The examination of the reports of the Directorate of Forensic Laboratories, State of
Maharashtra, Home Department, Vidyanagari, Kalina, Santa Cruz (East) Mumbai being Ex. No. 22
to 25 and in particular the examination report in Ex.25 indicates that DNA profile of the bloodDattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

detected on the plastic bag and the clothes and those obtained from the nails of the victim are
identical and are from one and the same source of female origin. The DNA profile of semen detected
on the underwear (Bermudas), the bedsheet, vaginal swab and anal swab of the victim are identical
and from one and the same source of male origin. The DNA analysis establishes beyond reasonable
doubt that the victim was raped by the accused- appellant.
87. By a judgment and order delivered on 6 th and 7th June, 2013, the learned Special Judge
(Protection of Children from Sexual Offences Act), Thane convicted the accused-appellant of
offences under Sections 363, 364, 367, 302, 201, 376, 376(2)(f) and 377 of the Indian Penal Code
read with Sections 4 and 6 of the Protection of Children from Sexual Offences Act, 2012.
88. On 7th June, 2013, the accused-appellant was produced in Court and heard on the question of
sentence after which the Trial Court ordered as follows:
“1. Accused Dattatray @ Datta Ambo Rokde is hereby convicted of the offences
punishable under Sections 363, 364, 367, 302, 201 of the Indian Penal Code and
under Sections 376, 376(2)(f), 377 of the Indian Penal Code r/w Section 3 punishable
under Section 4 of the Protection of Children from Sexual Offences Act and under
Sections 5(h)(i), 5(k), (I) (m) punishable under Section 6 of the Protection of
Children from Sexual Offences Act.
2. Accused is sentenced to death for an offence punishable under Section 302 of the
Indian Penal Code and he be hanged by the neck till he is dead, subject to
confirmation by Hon’ble High Court of Judicature at Bombay.
3. Accused is sentenced to suffer imprisonment for life for offences under Sections
376, 376(2)(f), 377 of the Indian Penal Code and offence u/s 3 punishable u/s 4 and
5(h)(i), 5(k), (I) (m) punishable under Section 6 of the Protection of Children from
Sexual Offences Act.
4. No separate sentence is awarded for offences under Sections 363, 364, 367 and 201
of the Indian Penal Code.
5. Accused is undertrial prisoner since 25.01.2013.
6. The Muddemal property be preserved till further orders in reference from Hon’ble
High Court.
7. The copy of this judgment be furnished to accused free of cost forthwith.
8. The Registrar is directed to send the record and proceedings of this Special Case
No.1/2013 to Hon’ble High Court for confirmation of death sentence.”Dattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

89. The Registrar was directed to send the records and proceedings of the case to the High Court for
confirmation of the death sentence. The accused-appellant also filed an appeal against the
conviction and sentence being Criminal Appeal No.1202 of 2013.
90. The said Criminal Appeal No.1202 of 2013 was heard by a Division Bench of Bombay High Court
alongwith the death sentence reference being Crl. Confirmation case No.6 of 2013 in Special Case
No.1 of 2013.
91. By a judgment and order dated 21st, 24th, 25th March, 2014, the Division Bench of Bombay
High Court confirmed the conviction and sentence of death imposed under Section 302 of the
Indian Penal Code on the accused-appellant. The appeal of the accused- appellant was partly
allowed only to the extent that the conviction of the accused-appellant under Section 376 simplicitor
was set aside. The State has not filed any appeal against the judgment and order of the Division
Bench.
92. We have considered the evidence on record in detail and we find absolutely no ground to
interfere with the conviction of the accused-appellant, as confirmed by the First Appellate Court.
93. As argued on behalf of the accused-appellant there may have been embellishment of the
evidence against the accused-appellant. The evidence of the PWs 4 and 5 supported by PW-10 can
never be the basis of any conviction and is fraught with inherent inconsistencies.
94. Even assuming that PWs 4 and 5 actually noticed the accused-appellant carrying a bag and
dumping it in the lane opposite the car shed, this was in the evening of 22.1.2013 whereas the body
of the victim was first seen by her parents outside the door of their tenement, well past midnight, at
around 2.00 a.m.
95. Admittedly, these two witnesses had not noticed anything suspicious. A bag with the body of the
child would, in all likelihood, have aroused suspicion. No other material was found to suggest that
the body might have been concealed and/or wrapped and then put in the bag identified by PW-4
and PW-5. Admittedly, these two witnesses did not examine the bag carried by the
accused-appellant (if at all) closely. No credence can be placed on identification by the PW 4 and 5,
of the bag seized and produced by the Police, as the same bag carried by the accused-appellant. The
identification is preposterous.
96. It is equally true that none of the witnesses except PW-18, Asha, wife of the accused-appellant to
whom the accused-appellant confessed his guilt and the PW-12, a Pancha, in whose presence the
accused-appellant made extra judicial confession to the Police, is relevant to the guilt of the
accused-appellant. However, it is reiterated at the cost of repetition that the forensic evidence
supported by the evidence of PW-18 establishes the guilt of the appellant beyond reasonable doubt.
We, thus, confirm the conviction of the accused-appellant for the offences under Sections 302,
376(2)(f), 377 of the IPC read with Sections 3, 4 and 5 of the POCSO.Dattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

97. The question is, whether death sentence imposed on the accused-appellant for offences under
Section 302 should be confirmed or be commuted to life sentence, as argued on behalf of the
accused-appellant.
98. Counsel appearing on behalf of the accused-appellant submitted that (i) the case did not fall
under the category of the rarest of rare cases; (ii) the accused-appellant was not effectively defended
before the Trial Court and the First Appellate Court; (iii) the hearing given to the appellant under
Section 235(2) of the Code of Criminal Procedure on the quantum of sentence was not an effective
hearing; (iv) Counsel appearing on behalf of the accused- appellant before the Trial Court only
submitted that there were no eye witnesses to the crime, and a lesser punishment should be
imposed having regard to the age of the accused-appellant; (v) the attention of the Court was not
drawn to mitigating circumstances for imposition of a lesser sentence and mitigating circumstances
were never considered; (vi) the accused-appellant was not given the opportunity to file an affidavit
placing on record mitigating circumstances; (vii) Trial court did not make any effort to elicit facts
which could be mitigating circumstances against imposition of the extreme penalty of death
sentence; (viii) there was no finding recorded either by Trial or the Appellate Court that there was
no alternative to the imposition of death sentence and (ix) the Trial Court did not consider the
possibility of reformation or rehabilitation of the accused-appellant. Counsel argued that there was
no reason to suppose that the accused-appellant would be a continuing threat to society unless
hanged.
99. In Bachan Singh v. State of Punjab 1, this Court, while upholding the validity of death sentence
held, that imprisonment for life was the rule and death sentence an exception, to be 1 (1980) 2 SCC
684 imposed in the “rarest of rare” cases, recording special reasons. In Bachan Singh (supra), this
Court in effect held that before exercising discretion to impose the extreme penalty of death
sentence, aggravating and mitigating circumstances are required to be considered. Some of the
mitigating factors would be the extreme mental or emotional disturbance in which the offence might
have been committed, the possibility that the accused- appellant would not be a continuing threat to
society, the possibility of reformation and rehabilitation of the accused, mental defect or disorder of
the accused etc.
100. In Rajesh Kumar vs. State (through Govt. of NCT of Delhi)2, this Court observed:-
“83. The ratio in Bachan Singh has received approval by the international legal
community and has been very favourably referred to by David Pannick in Judicial
Review of the Death Penalty:
Duckworth (see pp. 104-05). Roger Hood and Carolyn Hoyle in their treatise on The
Death Penalty, 4th Edn. (Oxford) have also very much appreciated the Bachan Singh
ratio (see p. 285). The concept of “rarest of rare” which has been evolved in Bachan
Singh by this Court is also the internationally accepted standard in cases of death
penalty.Dattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

84. Reference in this connection may also be made to the right based approach in
exercising discretion in death penalty as suggested by Edward Fitzgerald, the British
Barrister. [Edward Fitzgerald: The Mitigating Exercise in Capital Cases in Death
Penalty Conference (3-5 June), Barbados:
Conference Papers and Recommendations.] It has been suggested therein that right
approach towards exercising discretion in capital cases is to start from a strong
presumption against the death penalty. It is argued that “the presence of any 2 (2011)
13 SCC 706 significant mitigating factor justifies exemption from the death penalty
even in the most gruesome cases” and Fitzgerald argues:
“Such a restrictive approach can be summarised as follows: The normal sentence
should be life imprisonment. The death sentence should only be imposed instead of
the life sentence in the ‘rarest of rare’ cases where the crime or crimes are of
exceptional heinousness and the individual has no significant mitigation and is
considered beyond reformation.” (Quoted in The Death Penalty, Roger Hood and
Hoyle, 4th Edn., Oxford, p. 285.)
86. Taking an overall view of the facts in these appeals and for the reasons discussed
above, we hold that death sentence cannot be inflicted on the appellant since the
dictum of the Constitution Bench in Bachan Singh is that the legislative policy in
Section 354(3) of the 1973 Code is that for a person convicted of murder, life
imprisonment is the rule and death sentence, an exception, and the mitigating
circumstances must be given due consideration. Bachan Singh further mandates that
in considering the question of sentence the court must show a real and abiding
concern for the dignity of human life which must postulate resistance to taking life
through law’s instrumentality. Except in the “rarest of rare cases” and for “special
reasons” death sentence cannot be imposed as an alternative option to the imposition
of life sentence”.
101. In Rajesh Kumar (supra), the accused was convicted of assault and murder of two helpless
children in the most gruesome manner. This Court held that death sentence could not be inflicted,
reiterating that life imprisonment was the rule and death sentence an exception only to be imposed
in the “rarest of rare cases” and for “special reasons” when there were no mitigating circumstances.
102. Section 235 of the Criminal Procedure Code (Cr.P.C.), reads as follows:-
“235. Judgment of acquittal or conviction.—(1) After hearing arguments and points of
law (if any), the Judge shall give a judgment in the case.
(2) If the accused is convicted, the Judge shall, unless he proceeds in accordance with
the provisions of Section 360, hear the accused on the question of sentence, and then
pass sentence on him according to law.”Dattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

103. Section 235 (2) of the CrPC is not a mere formality. It is obligatory on the part of the learned
trial Judge to hear the accused on the question of sentence and deal with it. To quote Bhagwati J. in
Santa Singh vs. State of Punjab3.
“2. …...This provision is clear and explicit and does not admit of any doubt. It requires that in every
trial before a court of sessions, there must first be a decision as to the guilt of the accused. The court
must, in the first instance, deliver a judgment convicting or acquitting the accused. If the accused is
acquitted, no further question arises. But if he is convicted, then the court has to “hear the accused
on the question of sentence, and then pass sentence on him according to law”. When a judgment is
rendered convicting the accused, he is, at that stage, to be given an opportunity to be heard in regard
to the sentence and it is only after hearing him that the court can proceed to pass the sentence.
3. This new provision in Section 235(2) is in consonance with the modern trends in penology and
sentencing procedures. There was no such provision in the old Code. Under the old Code, whatever
the accused wished to submit in regard to the sentence had to be stated by him before the
argumentss concluded and the judgment was delivered. There was no separate stage for being heard
in regard to sentence. The accused had to produce material and make his submissions in regard to
sentence on the assumption that he was ultimately going to be convicted. This was most
unsatisfactory. The legislature, therefore, decided that it is only when the accused is 3 (1976) 4 SCC
190 convicted that the question of sentence should come up for consideration and at that stage, an
opportunity should be given to the accused to be heard in regard to the sentence. Moreover, it was
realised that sentencing is an important stage in the process of administration of criminal justice- as
important as the adjudication of guilt-and it should not be consigned to a subsidiary position as if it
were a matter of not much consequence.
It should be a matter of some anxiety to the court to impose an appropriate punishment on the
criminal and sentencing should, therefore, receive serious attention of the court.
…..The reason is that a proper sentence is the amalgam of many factors such as the nature of the
offence, the circumstances-extenuating or aggravating- of the offence, the prior criminal record, if
any, of the offender, the age of the offender, the record of the offender as to employment, the
background of the offender with reference to education, home life, sobreity and social adjustment,
the emotional and mental condition of ‘the offender, the prospects for the rehabilitation of the
offender, the possibility of treatment or training of the offender, the possibility that the sentence
may serve as a deterrent to crime by the offender or by others and the current community need, if
any, for such a deterrent in respect to the particular type of offence. These are factors which have to
be taken into account by the court in deciding upon the appropriate sentence, and, therefore, the
legislature felt that, for this purpose, a separate stage should be provided after conviction when the
court can hear the accused in regard to these factors bearing on sentence and then pass proper
sentence on the accused.
4. ….The hearing on the question of sentence, would be rendered devoid of all meaning and content
and it would become an idle formality, if it were confined merely to hearing oral submissions
without any opportunity being given to the parties and particularly to the accused, to produceDattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

material in regard to various factors bearing on the question of sentence, and if necessary, to lead
evidence for the purpose of placing such material before the court.
104. In Santa Singh (supra), Bhagwati, J. set aside the sentence of death and remanded the case to
the Sessions Court with a direction to pass appropriate sentence after giving an opportunity to the
petitioner in the aforesaid case of being heard with regard to the question of sentence, in accordance
with the provisions of Section 235(2) CrPC.
105. In Dagdu and Others v. State of Maharashtra 4, a three- Judge Bench of this Court referred to
Santa Singh (supra) and held that the mandate of Section 235(2) CrPC had to be obeyed in letter
and spirit. Chandrachud, J. held:-
“79. … The Court, on convicting an accused, must unquestionably hear him on the
question of sentence. But if, for any reason, it omits to do so and the accused makes a
grievance of it in the higher court, it would be open to that Court to remedy the
breach by giving a hearing to the accused on the question of sentence. That
opportunity has to be real and effective, which means that the accused must be
permitted to adduce before the Court all the data which he desires to adduce on the
question of sentence. The accused may exercise that right either by instructing his
counsel to make oral submissions to the Court or he may, on affidavit or otherwise,
place in writing before the Court whatever he desires to place before it on the
question of sentence. The Court may, in appropriate cases, have to adjourn the
matter in order to give to the accused sufficient time to produce the necessary data
and to make his contentions on the question of sentence. That, perhaps, must
inevitably happen where the conviction is recorded for the first time by a higher
court.” 4 (1977) 3 SCC 68
106. In Machhi Singh & Others v. State of Punjab 5, this Court held:-
“38. … (iv) A balance sheet of aggravating and mitigating circumstances has to be
drawn up and in doing so the mitigating circumstances have to be accorded full
weightage and a just balance has to be struck between the aggravating and the
mitigating circumstances before the option is exercised.”
107. In Santosh Kumar Satishbhushan Bariyar v. State of Maharashtra6, this Court observed and
held:-
“157. The doctrine of proportionality, which appears to be the premise whereupon the
learned trial Judge as also the High Court laid its foundation for awarding death
penalty on the appellant herein, provides for justifiable reasoning for awarding death
penalty. However, while imposing any sentence on the accused the court must also
keep in mind the doctrine of rehabilitation. This, considering Section 354(3) of the
Code, is especially so in the cases where the court is to determine whether the case at
hand falls within the rarest of the rare case.Dattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

158. The reasons assigned by the courts below, in our opinion, do not satisfy Bachan
Singh test.
Section 354(3) of the Code provides for an exception. General rule of doctrine of proportionality,
therefore, would not apply. We must read the said provision in the light of Article 21 of the
Constitution of India. Law laid down by Bachan Singh and Machhi Singh interpreting Section
354(3) of the Code should be taken to be a part of our constitutional scheme.
159. Although the Constitutional Bench judgment of the Supreme Court in Bachan Singh did not lay
down any guidelines on determining which cases fall within the “rarest of rare” category, yet the
mitigating circumstances listed in and endorsed by the judgment give reform and 5 (1983) 3 SCC
470 6 (2009) 6 SCC 498 rehabilitation great importance, even requiring the State to prove that this
would not be possible, as a precondition before the court awarded a death sentence. We cannot
therefore determine punishment on grounds of proportionality alone. There is nothing before us
that shows that the appellant cannot reform and be rehabilitated.
162. Further indisputably, the manner and method of disposal of the dead body of the deceased was
abhorrent and goes a long way in making the present case a most foul and despicable case of
murder. However, we are of the opinion, that the mere mode of disposal of a dead body may not by
itself be made the ground for inclusion of a case in the “rarest of rare” category for the purpose of
imposition of the death sentence. It may have to be considered with several other factors.
108. In Ajay Pandit and Another v. State of Maharashtra 7, this Court held:-
“47. Awarding death sentence is an exception, not the rule, and only in the rarest of
rare cases, the court could award death sentence. The state of mind of a person
awaiting death sentence and the state of mind of a person who has been awarded life
sentence may not be the same mentally and psychologically. The court has got a duty
and obligation to elicit relevant facts even if the accused has kept totally silent in such
situations. In the instant case, the High Court has not addressed the issue in the
correct perspective bearing in mind those relevant factors, while questioning the
accused and, therefore, committed a gross error of procedure in not properly
assimilating and understanding the purpose and object behind Section 235(2) CrPC.”
109. In Mohinder Singh v. State of Punjab8, this Court held:-
“22. The doctrine of “rarest of rare” confines two aspects and when both the aspects
are satisfied 7 (2012) 8 SCC 43 8 (2013) 3 SCC 294 only then the death penalty can be
imposed.
Firstly, the case must clearly fall within the ambit of “rarest of rare” and secondly, when the
alternative option is unquestionably foreclosed. Bachan Singh suggested selection of death
punishment as the penalty of last resort when, alternative punishment of life imprisonment will be
futile and serves no purpose.Dattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

23. In life sentence, there is a possibility of achieving deterrence, rehabilitation and retribution in
different degrees. But the same does not hold true for the death penalty. It is unique in its absolute
rejection of the potential of convict to rehabilitate and reform. It extinguishes life and thereby
terminates the being, therefore, puts an end to anything to do with life. This is the big difference
between two punishments. Thus, before imposing death penalty, it is imperative to consider the
same. The “rarest of rare” dictum, as discussed above, hints at this difference between death
punishment and the alternative punishment of life imprisonment. The relevant question here would
be to determine whether life imprisonment as a punishment would be pointless and completely
devoid of any reason in the facts and circumstances of the case. As discussed above, life
imprisonment can be said to be completely futile, only when the sentencing aim of reformation can
be said to be unachievable. Therefore, for satisfying the second aspect to the “rarest of rare”
doctrine, the court will have to provide clear evidence as to why the convict is not fit for any kind of
reformatory and rehabilitation scheme”.
110. In Panchhi and Others v. State of U.P. 9, this Court observed:-
“20. … No doubt brutality looms large in the murders in this case particularly of the
old and also the tender-aged child. It may be that the manner in which the killings
were perpetrated may not by itself show any lighter side but that is not very peculiar
or very special in these killings. Brutality of the manner in which a murder was
perpetrated may be a ground but not the sole criterion for judging whether the case is
one of 9 (1998) 7 SCC 177 the ‘rarest of rare cases’ as indicated in Bachan Singh case.”
111. In Bantu v. State of M.P.10 this Court found that there was nothing on record to indicate that
the appellant had any criminal antecedents nor could it be said that he would be a grave danger to
the society at large despite the fact that the crime committed by him was heinous. This Court held:-
“8. However, the learned counsel for the appellant submitted that in any set of
circumstances, this is not the rarest of the rare case where the accused is to be
sentenced to death. He submitted that age of the accused on the relevant day was less
than 22 years. It is his submission that even though the act is heinous, considering
the fact that no injuries were found on the deceased, it is probable that death might
have occurred because of gagging her mouth and nosetrix [nostril] by the accused at
the time of incident so that she may not raise a hue and cry. The death, according to
him, was accidental and an unintentional one. In the present case, there is nothing on
record to indicate that the appellant was having any criminal record nor can it be said
that he will be a grave danger to the society at large. It is true that his act is heinous
and requires to be condemned but at the same time it cannot be said that it is the
rarest of the rare case where the accused requires to be eliminated from the society.
Hence, there is no justifiable reason to impose the death sentence.” (Emphasis
supplied by us).
112. In Amit v. State of Maharashtra 11 this Court took into consideration, the prior history of the
appellant and noted that there was no record of any previous heinous crime and also there was noDattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

evidence that he would be a danger to society if the death 10 (2001) 9 SCC 615 11 (2003) 8 SCC 93
penalty was not awarded to him. The relevant finding (Paragraph
10) is extracted hereinbelow:-
“10. The next question is of the sentence. Considering that the appellant is a young
man, at the time of the incident his age was about 20 years; he was a student; there is
no record of any previous heinous crime and also there is no evidence that he will be
a danger to the society, if the death penalty is not awarded. Though the offence
committed by the appellant deserves severe condemnation and is a most heinous
crime, but on cumulative facts and circumstances of the case, we do not think that the
case falls in the category of rarest of the rare cases…….”
113. In the case of Rahul v. State of Maharashtra12 this Court noted that there was no
adverse report about the conduct of the appellant therein either by the jail authorities
or by the probationary officer and that he had no previous criminal record or at least
nothing was brought to the notice of the Court. This Court observed as follows:-
“4. We have considered all the relevant aspects of the case. It is true that the
appellant committed a serious crime in a very ghastly manner but the fact that he was
aged 24 years at the time of the crime, has to be taken note of. Even though, the
appellant had been in custody since 27-11-1999 we are not furnished with any report
regarding the appellant either by any probationary officer or by the jail authorities.
The appellant had no previous criminal record, and nothing was brought to the notice
of the Court. It cannot be said that he would be a menace to the society in future.
Considering the age of the appellant and other circumstances, we do not think that
the penalty of death be imposed on him.”
114. Similarly, in Surendra Pal Shivbalakpal v. State of
12 (2005) 10 SCC 322 Gujarat13 the absence of any involvement in any previous criminal case was
considered to be a factor to be taken into consideration for the purposes of awarding the sentence to
the appellant therein. This Court held :
“13. The next question that arises for consideration is whether this is a “rarest of rare
case”; we do not think that this is a “rarest of rare case” in which death penalty
should be imposed on the appellant. The appellant was aged 36 years at the time of
the occurrence and there is no evidence that the appellant had been involved in any
other criminal case previously and the appellant was a migrant labourer from U.P.
and was living in impecunious circumstances and it cannot be said that he would be a
menace to society in future and no materials are placed before us to draw such a
conclusion. We do not think that the death penalty was warranted in this case. We
confirm conviction of the appellant on all the counts, but the sentence of death
penalty imposed on him for the offence under Section 302 IPC is commuted to lifeDattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

imprisonment.”
115. In Mukesh and Another v. State (NCT of Delhi) and Others14, a three-Judge
Bench of this Court considered the earlier judgments of this Court referred to above
and deemed it appropriate to give opportunity to the accused to file affidavits to bring
on record mitigating circumstances for reduction of the sentence.
116. The accused-appellant was produced before the Trial court for hearing under
Section 235(2) of the Code of Criminal Procedure the day after the judgment and
order of his conviction was passed. The accused-appellant, it appears, did not make
any submission on the point of sentence. This is recorded by the Trial Court. The
13 (2005) 3 SCC 127 14 (2017) 3 SCC 717 accused-appellant only pleaded ‘not guilty’ submitting that
there was no eye witness to the crime. The Trial Court has recorded that Advocate Waghachadu, the
learned Advocate appearing for the accused-appellant submitted that “considering the fact that
accused is 53 years old leniency be shown to accused” in awarding death sentence.
117. The Trial Court has accepted the submission of the learned Special Public Prosecutor that there
were no mitigating circumstances to award life imprisonment instead of death sentence. The Special
Public Prosecutor submitted that the offences had been committed with extreme depravity.
118. It may be pertinent to note that in awarding death sentence, the trial court referred to and
relied upon two judgments of this Court of affirmation of death sentence, that is, Rajendra
Prahladrao Wasnik v. State of Maharashtra 15 and Mohd. Manan @ Abdul Mannan v. State of Bihar
16. On review of both the judgments, death sentence has been commuted to imprisonment for life.
119. In Haru Ghosh vs. State of West Bengal 17, this Court commuted death sentence to life
imprisonment in the case of a dastardly murder of two helpless persons for no fault of theirs. This
Court, however, in commuting death sentence took into consideration the following factors:-
16 Case NO. R.P (Crl) No. 308 of 2011 in Crl. A. No. 379 of 2009 17 (2009) 15 SCC
551 “i. There was no pre-meditation on the part of the accused;
ii. The act was on the spur of the moment;
iii. The accused was not armed with any weapon; iv. It was unknown under what circumstances the
accused had entered the house of the deceased and what prompted him to assault the boy; and v.
The cruel manner in which the murder was committed could not be the guiding factor and the
accused himself had two minor children.”
120. In Haru Ghosh (supra), this Court observed, “….the cruel manner in which the murder was
committed and the subsequent action on the part of the accused in severing the parts of the body of
the deceased, do not by themselves become the guiding factor in favour of death sentence.”Dattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

121. In Lehna vs. State of Haryana18, even though three lives had been lost by reason of the crime,
this Court modified the punishment by commuting death sentence to life imprisonment, observing
that there was no evidence of any diabolic planning to commit the crime, though the act was cruel.
122. In this case too there is no evidence at all of any diabolic planning to commit the crime though
the crime was undoubtedly cruel and heinous. The circumstances in which the victim entered the
tenement of the accused-appellant are not known. There is no evidence to show that the
accused-appellant took the victim to his tenement. Though unlikely, she might even have gone to his
tenement on her own.
18 (2002) 3 SCC 76
123. Under the Indian Penal Code and, in particular, Section 299 thereof, whoever causes death by
doing an act either with the intention of causing death or with the intention of causing such bodily
injury as is likely to cause death or with the knowledge that he is likely, by such act, to cause death,
commits the offence of culpable homicide.
124. As per the definition of Section 300 of the IPC, except in cases excepted thereafter, culpable
homicide is murder if the act by which the death is caused (i) is done with the intention of causing
death or (ii) if it is done with the intention of causing such bodily harm as the offender knows to be
likely to cause the death of the person to whom the harm is caused or (iii) if the act is done with the
intention of causing bodily injury to any person and the bodily injury intended to be inflicted is
sufficient in the ordinary course of nature to cause death or (iv) if the person committing the act
knows that it is so imminently dangerous that it must, in all probabily, cause death or such bodily
injury as is likely to cause death and commits such act without any excuse for incurring the risk of
causing death or such injury as aforesaid.
125. As a mature man, over fifty years of age, the accused- appellant should have known that the
rape of a five year old child by an adult was dangerous and could lead to such injuries, as was in all
probability likely to cause death.
126. The death of the deceased victim was not caused under any provocation, not to speak of sudden
provocation. No such defence has been taken by the accused-appellant. Nor is it anybody’s case that
the death was caused in legitimate exercise in good faith of any right of the accused-appellant,
whether of private defence or otherwise. The death has been caused without any provocation.
127. The totality of the injuries support the finding of the Trial Court and the First Appellate Court
that the accused-appellant murdered the deceased victim. Though the act of the accused squarely
amounts to rape and murder, there is not a scrap of material to show that the intention of the
accused-appellant was to kill the minor child.
128. The PW-1, Dr. Bhusan Jain who had prepared the post mortem report opined that the cause of
death was asphyxia due to smothering, associated with head injuries and sexual assault. Dr. Bhusan
Jain deposed that all the 5 injuries were possible by repeated sexual acts and forceful penetration.Dattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

He opined that all the injuries were sufficient to cause instant death in the ordinary course.
129. Being a man of about 50 years of age, the accused-appellant should have known that repeated
sexual assault could have led to the death of the victim and in fact did lead to the death of the victim,
only five years of age. The accused-appellant has rightly been convicted of murder apart from child
rape. However, there is no evidence at all direct or circumstantial which establishes that the
intention of the accused-appellant was to kill the deceased victim.
130. Considering the totality of the evidence before us, we uphold the conviction of the
accused-appellant. However, in view of the evidence of the post mortem report of Dr. Bhusan Jain,
we deem it appropriate to modify the sentence by reducing the same to imprisonment for life.
131. There can be no doubt that rape and murder of a 5 years old girl shocks the conscience. It is
barbaric. There is, however, no evidence to support the finding that the murder was pre-meditated.
The petitioner did not carry any weapon. The possibility that the accused-appellant might not have
realized that his act could lead to death cannot altogether be ruled out. Moreover, the Trial Court
has apparently not considered the question of whether the crime is the rarest of rare crimes as
mandated by the Supreme Court in Bachan Singh (supra).
132. In Review Petition (Crl.) No.306-307 of 2013 ( Rajendra Prahladrao Wasnik v. State of
Maharashtra) the Court commuted the death sentence, in a case of rape and murder of a three year
old child to life imprisonment, inter alia, observing that the case did not fall in the category of the
rarest of the rare.
133. As argued by learned counsel appearing on behalf of the petitioner, the High Court found the
offence to be in the category of the rarest of rare cases, having regard to the nature of the offence
and the age of the victim.
134. Counsel for the accused-appellant submitted that the brutality of the crime and age of the
victim was not ground enough to inflict death sentence. Learned counsel submitted that the
petitioner had been convicted on circumstantial evidence, based on faulty investigation.
135. However, as observed above, the forensic evidence construed in the light of the evidence of
PW-18, Asha, wife of the accused-appellant, that the accused-appellant had confessed to the crime
to her, establishes the guilt of the accused-appellant and death sentence can be imposed even where
conviction is based on circumstantial evidence, provided the case falls in the category of the rarest of
rare and there are no mitigating circumstances and no possibility of reform or rehabilitation of the
convict.
136. On analogy of the reasoning in Review Petition (Crl) No. 306- 307 of 2013 in the case of
Rajendra Prahladrao Wasnik v. State of Maharashtra, this Court is constrained to hold that this case
does not fall in the category of the rarest of rare cases. Moreover, the accused-appellant was not
defended effectively. The lawyer representing the accused-appellant only pleaded not guilty,
emphasizing that there was no eye witness to the incident and sought leniency only on the ground ofDattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

the age of the accused- appellant which was 53 years.
137. The accused-appellant neither sought nor was given the opportunity to file any affidavit placing
on record relevant mitigating circumstances. The legal assistance availed by the accused-appellant
was patently not satisfactory and he was not accompanied by a social worker. No attempt was made
to place on record mitigating circumstances. No argument was advanced to the effect that there was
no similar case against the accused- appellant. In the absence of any arguments, the Trial Court did
not consider the question of whether the accused-appellant could be reformed.
138. Considering the nature of the crime against a five year old child, the Trial Court imposed the
extreme penalty of death without deciding the question of whether there was no alternative to
imposing death sentence on the accused-appellant. There is no finding that in the absence of death
sentence, the accused- appellant would continue to be a threat to the society. The question of
whether the accused-appellant could be reformed, had not at all been considered.
139. As held in Dagdu (supra) irrespective of whether these issues were raised on behalf of the
accused, the Court is obliged on its own to elicit facts relevant to the question of existence of
mitigating circumstances. The Court made no attempt to elicit any facts relevant to the sentence.
140. For effective hearing under Section 235(2) of the Code of Criminal Procedure, the suggestion
that the court intends to impose death penalty should specifically be made to the accused, to enable
the accused to make an effective representation against death sentence, by placing mitigating
circumstances before the Court. This has not been done. The Trial Court made no attempt to elicit
relevant facts, nor did the Trial Court give any opportunity to the petitioner to file an affidavit
placing on record mitigating factors. As such the petitioner has been denied an effective hearing.
141. Contrary to the dictum of this Court, inter alia, in Dagdu (supra) and Santa Singh (supra) the
petitioner was not given a real, effective and meaningful hearing on the question of sentence under
Section 235(2) of the Cr.P.C. The death sentence imposed on the petitioner is liable to be commuted
to life imprisonment on this ground.
142. There can be no doubt that the rape and murder of a five years old child is absolutely heinous
and barbaric, but as observed above, it cannot be said to be in the category of rarest of rare cases.
143. In Mulla and Another v. State of U.P. 19, this Court has affirmed that it is open to the Court to
prescribe the length of incarceration. This is especially true in cases where death sentence has been
replaced by the life imprisonment. This Court observed, “the court should be free to determine the
length of imprisonment which will suffice the offence committed.”
144. Even though life imprisonment means imprisonment for entire life, convicts are often granted
reprieve and/or remission of sentence after imprisonment of not less than 14 years. In this case,
considering the heinous, revolting, abhorrent and despicable nature of the crime committed by the
appellant, we feel that the appellant should undergo imprisonment for life, till his natural death and
no remission of sentence be granted to him.Dattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

19 (2010) 3 SCC 508
145. For the above reasons, we are of the view that the present appeals are one of such cases where
we would be justified in holding that confinement till natural life of the accused-appellant shall fulfil
the requisite criteria of punishment considering the peculiar facts and circumstances of the present
case. Accordingly, the death sentence awarded by the trial court is hereby modified to “life
imprisonment” i.e., imprisonment for the natural life of the appellant herein. The appeals are
allowed accordingly to the extent indicated above.
.……………................................J. (N. V. RAMANA) .…………...................................J. (DEEPAK GUPTA)
…………….................................J. (INDIRA BANERJEE) FEBRUARY 21, 2019 NEW DELHIDattatraya @ Datta Ambo Rokade vs The State Of Maharashtra on 21 February, 2019

