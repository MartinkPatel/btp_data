Common Cause, A Registered Society vs Union Of India & Ors
on 3 August, 1999
Equivalent citations: AIR 1999 SUPREME COURT 2979, 1999 AIR SCW 2899,
(1999) 5 ANDHLD 657, (2000) 2 KER LT 44, 1999 CRILR(SC MAH GUJ) 522,
(1999) 3 KER LT 27, 1999 CRILR(SC&MP) 522, (1999) 5 JT 237 (SC), (1998) 4
SCALE 1.1, 1999 (4) COM LJ 208 SC, 1999 (4) SCALE 354, 1999 (6) SCC 667,
1999 (8) SRJ 323, 1999 (6) ADSC 653, 1999 (4) LRI 12, 1999 SCC(CRI) 1196,
(1999) 6 SUPREME 425, (2000) 1 GUJ LR 748, (1999) 4 SCALE 354, (1999) 3
ANDHWR 1, (1999) SC CR R 697, (2000) 3 BOM CR 538
Author: S.Saghir Ahmad
Bench: S.Saghir Ahmad, S.R.Babu
           PETITIONER:
COMMON CAUSE, A REGISTERED SOCIETY
        Vs.
RESPONDENT:
UNION OF INDIA & ORS.
DATE OF JUDGMENT:       03/08/1999
BENCH:
S.Saghir Ahmad, K.Venkataswan, S.R.Babu
JUDGMENT:
S.SAGHIR AHMAD, J.
This is a Review Petition in Writ Petition No. 26 of 1995 which was filed by Mr. H.D. Shourie for the
following reliefs:-
"(i) Pass an appropriate writ, order or orders directing the Respondents 1 to 3 to
specifically declare as to when the Union of India will now bring before the
Parliament an appropriately drafted Bill for enactment of legislation for the
establishment of the institution of Lokpal, or a suitable alternative system of the
nature of Ombudsman which is operating in a number of other countries, for
checking and controlling corruption in public offices, inter alia, at the political andCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

bureaucratic levels, and whether in the enactment of such legislation they will take
into consideration the suggestions that have emanated from the Colloquium recently
organised under the auspices of Indian Institute of Public Administration with the
participation of foreign and Indian experts for examining various aspects of the
matter relating to establishment of Ombudsman institution in this country;
(ii) Pass an appropriate writ, order or orders directing that the institutions and
organisations of the Comptroller and Auditor General of India, Chief Vigilance
Commissioner, and the Central Bureau of Investigation should indicate to the
Hon'ble Court the specific steps which they will take for effectively overcoming any
inadequacies and weaknesses in the operations of these important institutions which
presently hamper effective and efficacious check on prevalence of corrupt practices in
the country and to curb corruption at all political and bureaucratic levels;
(iii) Pass an appropriate writ, order or orders appointing a Commission or
Commissioner to urgently undertake comprehensive study of the present
inadequacies in the Prevention of Corruption Act 1947 for making specific
recommendations to strengthen this enactment for achieving the objective of curbing
and checking corruption at the political and bureaucratic levels in the country.
(iv) Pass an appropriate writ, order or orders directing the State Governments
Respondents to indicate to the Hon'ble Court as to when they propose implementing
the specific suggestions which have been made for strengthening and improvement of
the functioning of the system of Lokayukta, including inter alia, the following :
a) To ensure expeditious establishment of the institution of Lokayukta and
Upa-Lokayukta in every State;
b) To achieve uniformity in the provisions of various Lokayukta and Upa-Lokayukta
Acts; and
c) To confer Constitutional status on the institution of Lokayukta."
The petition was taken up by this Court on 10.2.95 when the following Order was passed:-
"After hearing Mr. Shourie, appearing in-person, we give him liberty to amend the
petition by making broad base on the subject of curbing corruption in the country. To
come up on 24.2.95."
On 10.5.95, the following Order was passed:-
"We request the Supreme Court Legal Aid Society to depute a counsel to assist us in
this case alongwith Mr. Shourie, Adv. The Legal Aid Society shall also serve the
unserved respondents by depositing the necessary process fee and other expenses. ToCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

be listed on 11th August, 1995. All affidavits and counter affidavits may be tendered in
the Registry."
On 11.8.95, the Court passed the following Order:-
"Mr. Shourie, the petitioner appearing in-person, states that it is of utmost
importance to have a Lok Pal to curb corruption in the country. Mr. Gupta, learned
Solicitor General states that efforts have been made more than once to have
consensus regarding the terms and conditions of the proposed bill. According to him
efforts are still being made. It is a matter which concerns the parliament and the
Court cannot do anything substantial in this matter. Short of that, learned Solicitor
General states that he would apply his mind to the various aspects raised in this
petition and make some useful suggestions. Mr. Muralidhar, appearing as amicus
curiae to assist us, also states that he would examine the various reports submitted by
Comptroller and Auditor General from time to time and in consultation with the
Solicitor General and Mr. Shourie make some suggestions for the consideration of
this Court.
Mr. Shourie has invited our attention to a news item in the front page of Indian
Express of Friday August 11, 1995 under the caption "In Satish Sharma's reign, petrol
and patronage flow together". It is not possible for us to take any action on the press
report. On our suggestion the Solicitor General takes notice of this news item and
states that he would have the matter examined in the Ministry concerned and shall
file an affidavit of the Secretary concerned in the Ministry reacting to this news item.
He may file the affidavit within the period of eight weeks.
The Writ Petition is adjourned to 13.10.95."
The petition, thus, was diverted towards Captain Satish Sharma who was, at that time, Minister of
State for Petroleum and Natural Gas in the Central Government. By Judgment dated September 25,
1996, [(1996) 6 SCC 530] all the 15 petrol outlets, allotted by the Minister to various persons out of
his discretionary quota, were cancelled and the following directions were issued to Captain Satish
Sharma (petitioner) :-
"Capt. Satish Sharma shall show-cause within two weeks why a direction be not
issued to the appropriate police authority to register a case and initiate prosecution
against him for criminal breach of trust or any other offence under law. He shall
further show-cause within the said period why he should not, in addition, be made
liable to pay damages for his mala fide action in allotting petrol pumps to the above
mentioned fifteen persons."
The petitioner submitted the reply to the show-cause notice which was disposed of by Judgment
dated November 4, 1996 [(1996) 6 SCC 593]. The following operative Order was passed :-Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

"We are of the view that the legal position that exemplary damages can be awarded in
a case where the action of a public servant is oppressive, arbitrary or unconstitutional
is unexceptionable. The question for consideration, however, is whether the action of
Capt. Satish Sharma makes him liable to pay exemplary damages. In view of the
findings of this Court in Common Cause Case - quoted above - the answer has to be in
the affirmative. Satish Sharma's actions were wholly arbitrary, mala fide and
unconstitutional. This Court has given clear findings to this effect in the Common
Cause case. We, therefore, hold that Capt. Satish Sharma is liable to pay exemplary
damages.
We have heard Mr. HN Salve on the question of quantum. Mr. Salve has vehemently
contended that Capt. Sharma was a part of the system which was operating before his
joining as a Minister. According to him the types of wrongs were being committed
even earlier on the assumption that the Minister's discretion was to be exercised on
his subjective satisfaction. He has further contended that since the concept of
absolute liability of public servants for misfeasance has been of recent origin in this
country even while awarding exemplary damages leniency should be shown. There is
some plausibility in the contentions raised by Mr. Salve. After examining all the facts
and circumstances of this case and giving thoughtful consideration to this aspect, we
direct Capt. Satish Sharma to pay a sum of Rs. 50 lacs as exemplary damages to the
Government Exchequer. Since the property with which Capt. Sharma was dealing
was public property, the government which is "by the people" has to be compensated.
We further direct Capt. Sharma to deposit the amount with the Secretary, Ministry of
Finance, Government of India within nine months from today. The amount if not
paid, shall be recoverable as arrears of land revenue."
The present Review Petition relates to these two Judgments.
The Review Petition was put up before the Bench comprising of Hon. Bharucha and Faizan Uddin,
JJ. on 28.1.1997 when the Court directed "Issue notice on the Review Petition."
On notice being served on Mr. H.D. Shourie, he filed his reply to the Review Petition on 21.2.1997.
The office report dated 30th June, 1997 is to the following effect :
"In the matter above-mentioned, this Court on 28th January, 1997 directed to issue
notice of the Review Petition.
Accordingly, notice was issued to both the respondents and hence the service of
notice is complete as both the respondents are represented by Mr. H.D. Shourie,
Respondent in person and Ms. Anil Katiyar, Advocate for Respondent No.2.
Mr. Ashok K. Mahajan, Advocate has filed Application for impleadment on behalf of
Mr. Arun K.Gupta resident of Kothi No. 68, Sector VIIIA, Chandigarh and alsoCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

seeking stay of further investigation by CBI during pendency of Review Petition.
Since the said Application was not served on other side, a letter dated 4th March,
1997 and another letter dated 30th June, 1997 was issued to Mr. Ashok K. Mahajan to
serve it on Mr. H.D. Shourie, Respondent No. 1 and Mrs. Anil Katiyar representing
Respondent No. 2 and Mr. P.H. Parekh, Advocate. He was also requested to furnish
proof of service but he has not furnished the same so far.
Further, Mrs. Sandhya Goswami, Advocate has also filed four separate Applications
for impleadment on behalf of M/s Shiv Balak Pasi, Syed Hassan Saukat Abidi,
Dharmesh Kumar and Pradeep Kumar without serving its copies on the other sides.
She was asked to serve the same on all the parties and furnish proof of service but the
same has not been furnished by her so far. All the Applications for impleadment as
party are being circulated to Hon'ble Judges with this office report.
It is further submitted that Mrs. Anil Katiyar, Advocate has filed an Application for
Clarification and modification of order dated 25th September, 1996 which has been
registered as I.A. No. 6. Further she has also filed counter affidavit on behalf of Union
of India deposed by Director, Ministry of Petroleum and Natural Gas, Government of
India. The said Application and counter affidavit are being circulated with this office
report for orders."
Thereafter, the matter came up before the Bench comprising of Hon. SC Sen and Sujata Manohar,
JJ., on 8.7.1997. Mr. H.D. Shourie, who had filed the Writ Petition (C) No. 26 of 1995, was present
in person, but the case was adjourned to 25th of July, 1997. On 25.7.1997, the case was shown in the
cause-list, but the following notice was also published in that cause list:
"TAKE NOTICE THAT the above mentioned matters listed in Court No. 8 before a
Special Bench of Hon. Mr. Justice S.C. Sen and Hon. Mrs. Justice Sujata V. Manohar,
as Item Nos. "C" and "D" in the Daily List for 25th July, 1997 issued on 19th July,
1997 will not be taken up for hearing and the same stand adjourned to 22nd August,
1997.
BY ORDER DATED this the 25th day of July, 1997."
The case was thus adjourned to 22.8.1997 and on that date the Bench comprising of Hon. SC Sen
and Sujata Manohar, JJ., adjourned the case to 9.9.1997. Mr. K. Parasaran, Senior Counsel
appearing for the petitioner, was directed to give his written arguments. On 1.9.1997, Mr. Gopal
Subramaniam, Senior Counsel, was appointed as amicus curiae. When the case came up before the
Bench of Hon. SC Sen and Sujata Manohar, JJ., Their Lordships released the case with the further
direction that it would not be treated as part-heard with them. On 27.3.1998, the case came up
before the Bench of Hon. SC Agrawal and Sujata Manohar, JJ. when the following order was passed
:Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

"Since the argument on this petition is likely to take some time it is directed that the
matter may be listed on a non- miscellaneous day. The Registrar Judicial will take
appropriate directions from Hon'ble the Chief Justice for listing the matter before an
appropriate bench."
It was thereafter that the matter was placed before this Bench. We have heard learned counsel for
the parties. We have also heard Mr.Gopal Subramaniam, Senior Counsel, (Amicus Curiae).
Mr. K.Parasaran, learned Senior Counsel for the applicant, has contended that since the applicant
was Minister of State for Petroleum in the Central Government and it was in his capacity as an
essential component of the Central Government, that he had made allotment of Petrol Pumps out of
his discretionary quota, his act in making the allotments shall be treated to be the act of the Central
Government with the result that even if such allotments were cancelled on the ground of arbitrary
exercise of power, the Court could not have legally directed exemplary damages to be paid by the
Government to itself. He also contended that the jurisdiction of this Court under Article 32 was
limited, unlike the vast jurisdiction of the High Courts under Article 226 of the Constitution and,
therefore, in exercise of the limited jurisdiction, the Court cannot award exemplary damages for the
"tort of misfeasance in office", as in the proceedings under this Article, which constitute Public Law
proceedings, damages can be awarded only for the violation of the Fundamental Rights of citizens
either by the Government or its officers, specially the Right to Life, but not for "Tort" for which
action should have been initiated under the Private Law by filing a suit in a Court of competent
jurisdiction.
Learned counsel for the petitioner contended that the petitioner being a Minister of State in the
Union Cabinet was a part of the Government and his act being the act of the President, as the
petitioner was in the Central Cabinet, the same could not be made the basis of action for damages
under the Law of Torts and, therefore, under Public Law as well, the petitioner could not be held
liable for damages or, for that matter, exemplary damages.
Relying upon the decision of this Court in Samsher Singh & Anr. vs. State of Punjab, 1975 (1) SCR
814 = AIR 1974 SC 2192, which specifically dealt with the business rules of the Union Cabinet and
laid down that the act of a Minister would be treated as the act of the President or the Governor, as
the case may be, learned counsel for the petitioner contended that if the petitioner, in exercise of his
discretionary power, had allocated or allotted petroleum outlets to needy persons, he would be
treated to have acted only on behalf of the President and his act could not be questioned in any
court, including this Court, nor could the act of allotment of petrol outlets to various persons
constitute a basis for damages. The contention further is that the petitioner having acted as Minister
of State, his act would be treated to be the act of the entire Cabinet which, on the principle of
`collective responsibility', would be treated to have endorsed the act of the petitioner in making the
allotments of Petrol outlets and since the Cabinet is answerable to the Parliament, where the
allotments were not questioned, the same cannot be questioned here in this Court.
We have seriously considered the contention of Mr. Parasaran, as set out above, but we are unable
to agree with him on the broad proposition placed before us.Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

The Executive power of the Union is vested in the President under Article 53 of the Constitution.
The extent of the Executive power is indicated in Article 73. The next Article, namely, Article 74
provides for a Council of Ministers to aid and advise the President. Article 75(3) speaks of the
collective responsibility of the Cabinet which provides that the Cabinet shall be responsible to
Parliament. Article 77 provides for the conduct of business of the Government of India and clause
(3) thereof empowers the President to make rules for the convenient transaction of its business and
for allocation amongst Ministers of the said business. It is in exercise of this power that rules for
allocation of business have been framed under which various divisions of work to different
Ministries have been indicated. Distribution of petroleum products, including petroleum outlets, is
also one of the subjects which has been allocated to the Ministry of Petroleum.
The functions of the Govt. are carried out in the name of the President by Ministers appointed by
him on the advice of the Prime Minister. The Executive consists of :
(a) Prime Minister and Ministers who are members of the Cabinet; (b) Ministers who
are not of Cabinet rank;
(c) The Civil Service.
Since the functions of the Govt. are carried on by the Executive in the name of the President on the
advice of Ministers, they (Ministers) alone are answerable to the Parliament. The Civil Service as
such has no Constitutional personality or responsibility separate from the duly constituted Govt.
Article 77(1) and (2) provide that whatever executive action is taken by the Government of India, the
same shall be expressed to have been taken in the name of the President.
Executive power is not defined in the Constitution. Article 73 relating to the Union of India and
Article 163 relating to the State deal primarily with the extent of executive power. In Rai Sahib Ram
Jawaya Kapur vs. State of Punjab, 1955 (2) SCR 225 = AIR 1955 SC 549, the then Chief Justice
Mukherjea pointed out:-
"It may not be possible to frame an exhaustive definition of what executive function
means and implies. Ordinarily the executive power connotes the residue of
governmental functions that remain after legislative and judicial functions are taken
away."
This Judgment also deals with the concept of Cabinet, the Council of Ministers, its collective
responsibility and how the Executive functions subject to the control of the Legislature. It is laid
down that although the President is the head of the Executive, he acts on the aid and advice of the
Council of Ministers, headed by the Prime Minister, who are all members of the Legislature and
since the President has to act upon the advice of the Council of Ministers, the Legislature indirectly
controls the functioning of the Executive. The relevant portions are extracted below:-Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

"Our Constitution, though federal in its structure, is modelled on the British
Parliamentary system where the executive is deemed to have the primary
responsibility for the formulation of governmental policy and its transmission into
law though the condition precedent to the exercise of this responsibility is its
retaining the confidence of the legislative branch of the State..... In India, as in
England, the executive has to act subject to the control of the legislature; but in what
way is this control exercised by the legislature? Under Article 53(1)..., the executive
power of the Union is vested in the President but under Article 75 there is to be a
Council of Ministers with the Prime Minister at the head to aid and advise the
President in the exercise of his functions. The President has thus been made a formal
or constitutional head of the executive and the real executive powers are vested in the
Ministers or the Cabinet. The same provisions obtain in regard to the Govt. of States;
the Governor ... occupies the position of the head of the executive in the State but it is
virtually the council of Ministers in each State that carries on the executive Govt. In
the Indian Constitution, therefore, we have the same system of parliamentary
executive as in England and the Council of Ministers consisting, as it does, of the
members of the legislature is, like the British Cabinet, `a hyphen which joins, a
buckle which fastens the legislative part of the State to the executive part'. The
Cabinet enjoying, as it does, a majority in the legislature concentrates in itself the
virtual control of both legislative and executive functions; and as the Ministers
constituting the Cabinet are presumably agreed on fundamentals and act on the
principle of collective responsibility, the most important questions of policy are all
formulated by them."
This decision was referred to in State of M.P. vs. Thakur Bharat Singh, 1967 (2) SCR 454 = AIR 1967
SC 1170, wherein it was held that if the executive action of the Government affected prejudicially the
rights of any citizen, such action could be justified only if it was supported by the authority of law.
The concept and the extent of executive action was also examined by this Court in Naraindas
Indurkhya vs. State of M.P., 1974 (3) SCR 624 = (1974) 4 SCC 788 = AIR 1974 SC 1232, in which the
decision in Rai Saheb Ram Jawaya Kapur's case (supra) was followed and it was laid down that the
State Government could prescribe textbooks in the exercise of its executive power so long as it did
not infringe the rights of anyone. This decision was reiterated in Jayantilal Amratlal Shodhan vs.
F.N. Rana, 1964 (5) SCR 294 = AIR 1964 SC 648 and again in Bishambhar Dayal Chandra Mohan
vs. State of U.P., (1982) 1 SCC 39 = 1982 (1) SCR 1137 = AIR 1982 SC 33. The whole constitutional
position was reconsidered by a Seven-Judge Bench of this Court in Samsher Singh & Anr. vs. State
of Punjab, 1975 (1) SCR 814 = (1974) 2 SCC 832 = AIR 1974 SC 2192, in which the decision in B.K.
Sardari Lal vs. Union of India (1970) 1 SCC 411 = (1971) 3 SCR 461 = AIR 1971 SC 1547 was
specifically overruled and it was held that under Article 74(1), it is the function of the Council of
Ministers to advise the President over the whole of the Central field and nothing is excepted from
that field by this Article. It was also pointed out that the Constitution of India has adopted the
parliamentary or the Cabinet form of Government on the British model. The principle of English
Constitutional Law that the King does not act on his own, but on the advice of Council of Ministers is
embodied in the Indian Constitution as may be evident from the following words of Justice Krishna
Iyer in that case:-Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

"Not the Potomac, but the Thames, fertilises the flow of the Yamuna, if we may adopt
a riverine imagery. In this thesis, we are fortified by precedents of this Court,
strengthened by Constituent Assembly proceedings and reinforced by the actual
working of the organs involved for about a `silver jubilee' span of time."
It was also pointed out in this case that the words "business of the Government of India" and "the
business of the Government of the State", as used in Articles 77(3) and 166(3), include "all executive
business". Seervai in his treatise "Constitutional Law of India", Silver Jubilee Edition, Fourth
Edition, on page 2037 has, after a critical analysis of the Judgment, extracted the following
principles on the "business of the Government of India and allocation of business among Ministers"
:-
"(i) The expressions "business of the Government of India" and "the business of the
Government of the State" in Arts. 77(3) and 166(3) includes "all executive business".
(j) "Where the Constitution required the satisfaction of the President or the Governor for the
exercise of any power or function by the President or the Governor as the case may be ... the
satifaction required by the Constitution is not the personal satisfaction of the President or the
Governor but is the satisfaction of the President or of the Governor in the constitutional sense under
the Cabinet system of government .... It is the satisfaction of the Council of Ministers on whose aid
and advice the President or the Governor generally exercises all his powers and functions...." Arts.
77(3) and 166(3) provide that the President or the Governor shall make rules for the more
convenient transaction of the business of government and the allocation of functions among
Ministers. Rules of business and the allocation of functions to Ministers indicate that the
satisfaction of the Minister or the officer is the satisfaction of the President or the Governor.
(k) Rules of business and allocation of business among Ministers are relatable to Arts. 53 and 154
which provide that executive power shall be exercised by the President and by the Governor either
directly or through subordinate officers. The provisions made in Arts. 74 and 163 for a Council of
Ministers to aid and advise the President and the Governor "are sources of the business."
(l) Where the functions entrusted to a Minister are performed by an officer employed in the
Minister's department, there is in law no delegation to that officer because the act or decision of the
officer is that of the Minister: Halsbury, Vol. 1, 4th ed. para 748."
In view of the discussion held above, it will be seen that though an order is issued in the name of the
President, it does not become an order of the President passed by him personally, but remains,
basically and essentially, the order of the Minister on whose advice the President had acted and
passed that order. Moreover, as required by Article 77 (1), all executive actions of the Govt. of India
have to be expressed in the name of the President; but this would not make that order an order
passed by the President personally. That being so, the order carries with it no immunity. Being
essentially an order of the Govt. of India, passed in exercise of its Executive functions, it would be
amenable to judicial scrutiny and, therefore, can constitute a valid basis for exercise of power of
judicial review by this Court. The authenticity, validity and correctness of such an order can beCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

examined by this Court in spite of the order having been expressed in the name of the President. The
immunity available to the President under Article 361 of the Constitution cannot be extended to the
orders passed in the name of the President under Article 77 (1) or Article 77 (2) of the Constitution.
The related question as to the liability of the Minister to pay damages to the Govt. will be considered
by us while dealing with the "Tort of Misfeasance in Public Office" and payment of exemplary
damages to the Govt.
The other aspect of the matter as argued by Mr. K. Parasaran as to the "collective responsibility" of
the Cabinet with regard to the allotment of petrol outlets made by the petitioner in exercise of his
discretionary quota may now be considered. It is contended by Mr. K. Parasaran that under the
scheme of the Constitution, any order passed by the Minister shall be treated to be an order passed
by the Cabinet which is collectively answerable to the House of the People under Article 75 (3). It is
contended that an order passed by the Minister individually in favour of various persons to whom
petrol outlets were allotted cannot be questioned as it was not raised before the House of the People
to whom the Cabinet, as a whole, was answerable. The whole series of allotments made by the
petitioner could then have been debated before the House and since this was not done, it is not open
to question those allotments in this Court by a writ petition and the proceedings were meant only to
embarrass and harass the Cabinet. It is also contended that the petitioner had the jurisdiction to
make allotments of petrol outlets and the discretionary quota allowed to him was utilised for that
purpose. Since it is not the case that the jurisdiction was, in any way, exceeded or that allotments
were made in excess of the quota or for monetary consideration, the same need not have been
scrutinised by this Court nor could such allotments be made the basis for awarding exemplary
damages or investigation by C.B.I. Let us examine the viability of these submissions.
Our Constitution provides for a Parliamentary form of Govt. Article 79 provides that there shall be a
Parliament for the Union which shall consist of the President and two Houses known respectively as
Council of States and the House of the People. Article 80 provides for the composition of the Council
of States while Article 81 provides for the composition of the House of the People. Article 81 further
provides that the House of the People shall consist of :
(a) not more than 530 members chosen by direct election from territorial
constituencies in the States; and (b) not more than 20 members to represent the
Union Territories chosen in such manner as Parliament may by law provide. Article
83 provides for the duration of Houses of Parliament while Article 85 provides for the
Sessions of Parliament, prorogation of the Houses or either House and dissolution of
the House of the People. Article 86 speaks of the right of the President to address and
send messages to Houses while Article 87 provides for Special Address by the
President after each General Election to the House of the People and at the
commencement of the first session of each year. Once the election to the House of the
People is complete, comes the stage for the appointment of Prime Minister and
Council of Ministers to aid and advise the President as provided by Article 74. Since
the elections are contested principally by the political parties who set up their
candidates at the election, there is tacit understanding in keeping with the BritishCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

convention, that the party which has secured the majority in the House of the People
would govern while the parties which are in the minority would sit in the Parliament
as members of the "Opposition." It is on account of this convention that the President
invites the leader of the political party which has obtained majority, to form the Govt.
The President appoints the Prime Minister and then the Ministers are appointed on
the advice of the Prime Minister, who constitute the Council of Ministers. Article
75(3) provides that the Council of Ministers shall be collectively responsible to the
House of the People.
The concept of "collective responsibility" is essentially a political concept. The country is governed
by the party in power on the basis of the policies adopted and laid down by it in the Cabinet
Meeting. "Collective Responsibility" has two meanings: The first meaning which can legitimately be
ascribed to it is that all members of a Govt. are unanimous in supprot of its policies and would
exhibit that unanimity on public occasions although while formulating the policies, they might have
expressed a different view in the meeting of the Cabinet. The other meaning is that Ministers, who
had an opportunity to speak for or against the policies in the Cabinet are thereby personally and
morally responsible for its success and failure.
In the British Constitution & Politics 5th Edition by J. Harvey and L. Bather, it is said as under :
"Except when a minister explains the reasons for his resignation, parliament hears
nothing of the Cabinet's current deliberations. These remain secret, and only
decisions as a whole are reported to the House when policy is announced. Any
leakage of divergent views held by ministers would, as during Queen Victoria's reign,
seriously weaken the Government. In its decisions, 'the Cabinet is a unity to the
House'. While a minister can speak against any proposal in a Cabinet meeting, he
must either support the policy decided upon or resign. Recent resignations of this
nature are Frank Cousins (Prices and and Incomes Bill, 1966) and Lord Longford
(education cuts, 1968). But such resignations are infrequent. Ministers come from
the same party and, at least initially, are fairly homogeneous in their political views.
In any case, a former minister is unlikely to cross the floor of the House and join the
Opposition. His disagreement with the Government is usually over only one issue,
and his basic political outlook remains unchanged.
Thus the Cabinet stands or falls together. Where the policy of a particular minister is
under attack, it is the government as whole which is being attacked. Thus the defeat
of a minister on any major issue represents a defeat for the Government. However,
today, unlike the nineteenth century, such defeats do not occur. The use of rigid party
discipline ensures that the Government can always obtain a majority vote.
Nevertheless, criticism may be so severe and widespread that the Government may
modify its policy. If the minister identified with it feels that his prestige with the party
has been badly damaged, he may resign, e.g. Sir Samuel Hoare (1935) over the
proposals to partition Abyssinia.Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

In practice, therefore, all that collective responsibility means today is that every
member of the Government must be prepared to support all Cabinet decisions both
inside and outside the House."
It is further provided as under :
"The doctrine of collective responsibility has practical advantages. First, it
counteracts departmental separation for each minister has to be concerned with
policies of other departments. Second, it prevents the policy of one department being
determined unilaterally. Since it is the Cabinet as a whole which decides, ministers
are less likely to be over-influenced by their civil servants. Third, it ensures that
Cabinet decisions are based on principles and not on personalities.
Collective responsibility does not apply to a minister's responsibility for his
permanent officials or for his personal mistakes."
In this connection, an extract from "The British Cabinet" by John P. Mackintosh, 1962 Edn., is set
out below as it is also extremely relevant for this case.
"Much has been said and written about the responsibility of ministers. The discussion
can easily become confused because of the different meanings that are attached to the
word "responsible". Collective responsibility will be discussed below, and the first
task is to consider whether there is any separate element of individual responsibility.
The most common political meaning is that a certain minister will answer
parliamentary questions on a given subject. A second sense arises when those in
political circles appreciate that a particular policy is largely the idea of the minister,
rather than the traditional policy of the party in power, and they may single out the
minister for attack. For instance, in 1903-05 Wyndham was purusing his land
purchase schemes for Ireland in a manner which alarmed many Conservatives and
would certainly have been unlikely under any other Chief Secretary. A third sense is
simply that a minister is responsible even if a policy is the work of the Cabinet as a
whole but his colleagues choose to place the burden upon him. Thus Sir Samuel
Hoare thought he was acting in accordance with the views of the ministry in
concluding the Hoare-Lavel Pact and his decisions were subsequently endorsed by
the Cabinet till opposition became acute. He was then asked to disavow and
denounce his actions but preferred, "accepting his responsibility," to resign. There is,
in addition, the normal moral sense of the word meaning "culpable" and a minister
may, like a private individual, feel responsible if he could by greater wisdom or
exertion have prevented some unfortunate occurrence.
The one aspect that remains is the alleged obligation on a minister to resign when he
or one of his subordinates has blundered. The origin of this notion is fairly clear. It
dates from the 1850s and 1860s when it was reasonable to assume that a minister
could watch over every significant action of his department. Even then, there wouldCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

have been no need to acknowledge errors in this way but for the power of the House
of Commons to move and carry a motion censuring the individual in question
without necessarily dislodging the government."
From the above, it will be seen that in spite of the fact that the Council of Ministers is collectively
responsible to the House of the People, there may be an occasion where the conduct of a Minister
may be censured if he or his subordinates have blundered and have acted contrary to law.
No doubt it was open to the House of the People (Lok Sabha) to take up the issue of the abuse of
discretionary quota by the petitioner in his capacity as the Minister of State for Petroleum, and his
conduct could have been debated and scrutinised on the floor of the House, but the mere fact that
this was not done would not mean that the allotments of petroleum outlets by him were immune
from judicial scrutiny by this Court under Article 32 of the Constitution. Therefore, even if the
matter was not raised on the floor of the Lok Sabha, it would be amenable to the jurisdiction of this
Court under Article 32 of the Constitution.
Even in England, all ministers and servants of the Crown are accountable to the courts for the
legality of their actions, and may be held civilly and criminally liable, in their individual capacities,
for tortious or criminal acts. This liability may be enforced either by means of ordinary criminal or
civil proceedings or by means of impeachment, a remedy which is probably obsolete. They are also
subject to the judicial review jurisdiction of the courts. [See: Halsbury's Laws of England - Fourth
Edition (Re-issue), Volume 8(2), Para 422].
Learned counsel for the petitioner contended that neither could the Court award exemplary
damages against the petitioner nor could it order any C.B.I. investigation as the petitioner in making
the allotment of petrol outlets had not committed any offence, much less an offence of breach of
trust. It is also contended that the petitioner while making allotments out of his discretionary quota
available to him as Minister of State for Petroleum, had not committed the tort of misfeasance in
public office and, therefore, he was not liable to pay any damages. Mr. K.Parasaran also argued that
exemplary damages under law can be awarded in addition to the damages for the "tort" alleged to
have been committed but where not even damages have been awarded, there is no question of
awarding exemplary damages. It is also contended that action for tort could have been initiated only
in the field of private law by instituting a suit in a proper Civil Court and not under the public law,
namely, in proceedings initiated under Article 32 of the Constitution particularly as intricate
questions of fact were involved.
Since the question whether the action could have been initiated under the public law and whether
exemplary damages could have been awarded in those proceedings relates to the question of
jurisdiction, we would take up this question first.
Under Article 226 of the Constitution, the High Court has been given the power and jurisdiction to
issue appropriate Writs in the nature of Mandamus, Certiorari, Prohibition, Quo-warranto and
Habeas Corpus for the enforcement of Fundamental Rights or for any other purpose. Thus, the High
Court has jurisdiction not only to grant relief for the enforcement of Fundamental Rights but alsoCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

for "any other purpose" which would include the enforcement of public duties by public bodies. So
also, the Supreme Court under Article 32 has the jurisdiction to issue prerogative Writs for the
enforcement of Fundamental Rights guaranteed to a citizen under the Constitution.
Essentially, under public law, it is the dispute between the citizen or a group of citizens on the one
hand and the State or other public bodies on the other, which is resolved. This is done to maintain
the rule of law and to prevent the State or the public bodies from acting in an arbitrary manner or in
violation of that rule. The exercise of constitutional powers by the High Court and the Supreme
Court under Article 226 and 32 has been categorised as power of "judicial review". Every executive
or administrative action of the State or other statutory or public bodies is open to judicial scrutiny
and the High Court or the Supreme Court can, in exercise of the power of judicial review under the
Constitution, quash the executive action or decision which is contrary to law or is violative of
Fundamental Rights guaranteed by the Constitution. With the expanding horizon of Article 14 read
with other Articles dealing with Fundamental Rights, every executive action of the Govt. or other
public bodies, including Instrumentalities of the Govt., or those which can be legally treated as
"Authority" within the meaning of Article 12, if arbitrary, unreasonable or contrary to law, is now
amenable to the writ jurisdiction of this Court under Article 32 or the High Courts under Article 226
and can be validly scrutinised on the touchstone of the Constitutional mandates.
In a broad sense, therefore, it may be said that those branches of law which deal with the
rights/duties and privileges of the public authorities and their relationship with the individual
citizens of the State, pertain to "public law", such as Constitutional and Administrative Law, in
contradistinction to "private law" fields which are those branches of law which deal with the rights
and liabilities of private individuals in relation to one another.
The distinction between private law and public law was noticed by this Court in Life Insurance
Corporation of India vs. Escorts Limited & Ors., 1985 Supp. (3) SCR 909 = (1986) 1 SCC 264 = AIR
1986 SC 1370, in which the Court observed as under:-
"Broadly speaking, the Court will examine actions of State if they pertain to the public
law domain and refrain from examining them if they pertain to the private law field.
The difficulty will lie in demarcating the frontier between the public law domain and
the private law field. It is impossible to draw the line with precision and we do not
want to attempt it. The question must be decided in each case with reference to the
particular action, the activity in which the State or the instrumentality of the State is
engaged when performing the action, the public law or private law character of the
action and a host of other relevant circumstances."
Public Law field, since its emergence, is ever expanding in operational dimension. Its expanse covers
even contractual matters. (See: Union of India vs. A.L. Rallia Ram, 1964 (3) SCR 164 = AIR 1963 SC
1685; Mulamchand vs. State of Madhya Pradesh, 1968 (3) SCR 214 = AIR 1968 SC 1218, wherein the
principles of restitution and unjust- enrichment were applied). (See also: State of West Bengal vs.
B.K. Mondal & Sons, 1962 Supp. (1) SCR 876 = AIR 1962 SC 779 and New Marine Coal Company
Limited vs. Union of India, 1964 (2) SCR 859 = AIR 1964 SC 152).Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

Government decisions regarding award of contracts are also open to judicial review and if the
decision making process is shown to be vitiated by arbitrariness, unfairness, illegality and
irrationality, then the Court can strike down the decision making process as also the award of
contract based on such decision. This was so laid down by this Court in Tata Cellular vs. Union of
India, (1994) 6 SCC 651 = AIR 1996 SC 11. Initially the Supreme Court was of the opinion that while
the decision making process for award of a contract would be amenable to judicial review under
Article 226 or 32 of the Constitution, a breach of a contractual obligation arising out of a contract
already executed would not be so enforceable under such jurisdiction and the remedy in such cases
would lie by way of a civil suit for damages. (See: Radhakrishna Agarwal vs. State of Bihar, (1977) 3
SCC 457 = 1977 (3) SCR 249 = AIR 1977 SC 1496). But the Court changed its opinion in subsequent
decisions and held that even arbitrary and unreasonable decisions of the Government authorities
while acting in pursuance of a contract would also be amenable to writ jurisdiction. This principle
was laid down in Gujarat State Financial Corporation vs. Lotus Hotels Pvt. Ltd., (1983) 3 SCC 379 =
AIR 1983 SC 848. This Court even went to the extent of saying that the terms of contract cannot be
altered in the garb of the duty to act fairly. (See: Assistant Excise Commissioner vs. Issac Peter,
(1994) 4 SCC 104 = 1994 (2) SCR 67). Duty to act fairly in respect of contracts was also the core
question in Mahabir Auto Stores vs. Indian Oil Corporation, 1990 (1) SCR 818 = (1990) 3 SCC 752 =
AIR 1990 SC 1031, in which this Court relied upon its earlier decisions in E.P.Royappa vs. State of
Tamil Nadu, 1974 (2) SCR 348 = (1974) 4 SCC 3 = AIR 1974 SC 555; Menka Gandhi vs. Union of
India, (1978) 1 SCC 248 = 1978 (2) SCR 621 = AIR 1978 SC 597; Ajay Hasia vs. Khalid Mujib
Sehravardi, (1981) 1 SCC 722 = 1981 (2) SCR 79 = AIR 1981 SC 487; R.D. Shetty vs. The
International Airport Authority of India, 1979 (3) SCR 1014 = (1979) 3 SCC 489 = AIR 1979 SC 1628,
as also Dwarka Das Marfatia & Sons vs. Board of Trustees of the Port of Bombay , (1989) 3 SCC 293
= 1989 (2) SCR 751 = AIR 1989 SC 1642.
Public law remedies have also been extended by this Court to the realm of tort.
In exercise of jurisdiction under Article 32 of the Constitution, this Court has awarded
compensation to the petitioners who suffered personal injuries at the hands of the officers of the
Government and the causing of injuries which amounted to tortious act was compensated by this
Court. In Rudul Sah vs. State of Bihar, 1983 (3) SCR 508 = (1983) 4 SCC 141 = AIR 1983 SC 1086, a
Three-Judge Bench of this Court awarded compensation (Rs.30,000/-) for illegal detention. In
Bhim Singh vs. State of Jammu & Kashmir, (1985) 4 SCC 677 = AIR 1986 SC 494, a sum of
Rs.50,000/- was awarded to the petitioner for the illegal detention of the petitioner by the State
authorities. The compensation which was directed to be paid on account of police atrocities was the
subject matter of several cases before this Court. A few of them are People's Union for Democratic
Rights vs. State of Bihar, 1987 (1) SCR 631 = (1987) 1 SCC 265 = AIR 1987 SC 355; People's Union
for Democratic Rights Thru.Its Secy. vs. Police Commissioner, Delhi Police Headquarters, (1989) 4
SCC 730 = 1989 (1) Scale 599; SAHELI, a Woman's Resources Centre vs. Commissioner of Police,
Delhi, (1990) 1 SCC 422 = 1989 (Supp.) SCR 488 = AIR 1990 SC 513; Arvinder Singh Bagga vs. State
of U.P., (1994) 6 SCC 565 = AIR 1995 SC 117; P.Rathinam vs. Union of India, (1989) Supp. 2 SCC
716; In Re: Death of Sawinder Singh Grower, (1995) Supp. (4) SCC 450 = JT 1992 (6) SC 271 = 1992
(3) Scale 34; Inder Singh vs. State of Punjab, (1995) 3 SCC 702 = AIR 1995 SC 1949; D.K. Basu vs.
State of West Bengal, (1997) 1 SCC 416 = AIR 1997 SC 610; Mrs. Pritam Kaur Baryar vs. State ofCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

Punjab, (1996) 7 Scale (SP) 11 and Paramjit Kaur vs.State of Punjab, (1996) 8 Scale (SP) 6.
In cases relating to custodial deaths, this Court has awarded compensation in Nilabati Behera vs.
State of Orissa, (1993) 2 SCC 746 = 1993 (2) SCR 581 = AIR 1993 SC 1960; State of M.P. vs. Shyam
Sunder Trivedi, (1995) 4 SCC 262 = 1995 (3) Scale 343; People's Union for Civil Liberties vs. Union
of India, (1997) 3 SCC 433 = AIR 1997 SC 1203 and Kaushalya vs. State of Punjab, (1996) 7 Scale
(SP) 13.
For medical negligence, compensation was awarded by this Court in Supreme Court Legal Aid
Committee vs. State of Bihar, (1991) 3 SCC 482; Dr. Jacob George vs. State of Kerala, (1994) 3 SCC
430 = 1994 (2) Scale 563 and Paschim Banga Khet Mazdoor Samity vs. State of West Bengal & Ors.,
(1996) 4 SCC 37 = AIR 1996 SC 2426.
Damages were also awarded by this Court in Mrs. Manju Bhatia vs. N.D.M.C., (1997) 6 SCC 370 =
AIR 1998 SC 223 = (1997) 4 Scale 350.
In N.Nagendra Rao & Co. vs. State of Andhra Pradesh, (1994) 6 SCC 205 = AIR 1994 SC 2663, this
Court observed as under:-
"Therefore, barring functions such as administration of justice, maintenance of law
and order and repression of crime etc. which are among the primary and inalienable
functions of a Constitutional Government, the State cannot claim any immunity. The
determination of vicarious liability of the State being linked with negligence of its
officers, if they can be sued personally for which there is no dearth of authority and
the law of misfeasance in discharge of public duty having marched ahead, there is no
rationale for the proposition that even if the officer is liable the State cannot be sued.
The liability of the officer personally was not doubted even in Viscount Canterbury.
But the Crown was held immune on doctrine of sovereign immunity. Since the
doctrine has become outdated and sovereignty now vests in the people, the State
cannot claim any immunity and if a suit is maintainable against the officer
personally, then there is no reason to hold that it would not be maintainable against
the State."
The difference between public and private law was again examined by this Court in Nilabati Behera
vs. State of Orissa (supra). Dr. Anand, J. (as His Lordship then was) in his separate concurring
Judgment laid down as under:-.lm15 "34. The public law proceedings serve a different purpose than
the private law proceedings. The relief of monetary compensation, as exemplary damages, in
proceedings under Article 32 by this Court or under Article 226 by the High Courts, for established
infringement of the indefeasible right guaranteed under Article 21 of the Constitution is a remedy
available in public law and is based on the strict liability for contravention of the guaranteed basic
and indeafeasible rights of the citizen. The purpose of public law is not only to civilize public power
but also to assure the citizen that they live under a legal system which aims to protect their interests
and preserve their rights. Therefore, when the court moulds the relief by granting "compensation" in
proceedings under Article 32 or 226 of the Constitution seeking enforcement or protection ofCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

fundamental rights, it does so under the public law by way of penalising the wrongdoer and fixing
the liability for the public wrong on the State which has failed in its public duty to protect the
fundamental rights of the citizen. The payment of compensation in such cases is not to be
understood, as it is generally understood in a civil action for damages under the private law but in
the broader sense of providing relief by an order of making `monetary amends' under the public law
for the wrong done due to breach of public duty, of not protecting the fundamental rights of the
citizen. The compensation is in the nature of `exemplary damages' awarded against the wrongdoer
for the breach of its public law duty and is independent of the rights available to the aggrieved party
to claim compensation under the private law in an action based on tort, through a suit instituted in a
court of competent jurisdiction or/and prosecute the offender under the penal law.
35. This Court and the High Courts, being the protectors of the civil liberties of the citizen, have not
only the power and jurisdiction but also an obligation to grant relief in exercise of its jurisdiction
under Articles 32 and 226 of the Constitution to the victim or the heir of the victim whose
fundamental rights under Article 21 of the Constitution of India are established to have been
flagrantly infringed by calling upon the State to repair the damage done by its officers to the
fundamental rights of the citizen, notwithstanding the right of the citizen to the remedy by way of a
civil suit or criminal proceedings. The State, of course has the right to be indemnified by and take
such action as may be available to it against the wrongdoer in accordance with law - through
appropriate proceedings. Of course, relief in exercise of the power under Article 32 or 226 would be
granted only once it is established that there has been an infringement of the fundamental rights of
the citizen and no other form of appropriate redressal by the court in the facts and circumstances of
the case, is possible. The decisions of this Court in the line of cases starting with Rudul Sah vs. State
of Bihar granted monetary relief to the victims for deprivation of their fundamental rights in
proceedings through petitions filed under Article 32 or 226 of the Constitution of India,
notwithstanding the rights available under the civil law to the aggrieved party where the courts
found that grant of such relief was warranted. It is a sound policy to punish the wrongdoer and it is
in that spirit that the courts have moulded the relief by granting compensation to the victims in
exercise of their writ jurisdiction. In doing so the courts take into account not only the interest of the
applicant and the respondent but also the interests of the public as a whole with a view to ensure
that public bodies or officials do not act unlawfully and do perform their public duties properly
particularly where the fundamental right of a citizen under Article 21 is concerned. Law is in the
process of development and the process necessitates developing separate public law procedures as
also public law principles. It may be necessary to identify the situations to which separate
proceedings and principles apply and the courts have to act firmly but with certain amount of
circumspection and self- restraint, lest proceedings under Article 32 or 226 are misused as a
disguised substitute for civil action in private law."
This is a classic exposition of the realm of Public Law by (Dr.) Justice Anand (as His Lordship then
was), who has added a note of caution that while exercising this jurisdiction, the Courts have to act
firmly but with self- restraint lest the jurisdiction is abused as a disguise for civil action under
Private Law.Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

Mr. K.Parasaran then contended that in all the cases referred to earlier, this Court had granted
damages to the petitioner as the Fundamental Right to life under Article 21 of the Constitution was
found to have been violated. To that extent, the Court, according to him, can grant damages even in
proceedings under Article 32 of the Constitution but where Right to Life is not involved, the
petitioner would have to file a suit for damages in the Civil Court under private law jurisdiction and
cannot take recourse to proceedings under public law either in the High Court under Article 226 or
in this Court under Article 32. He contended that interim compensation may be granted by the
Court under Article 32 as immediate relief and the whole matter may be referred to the Civil Court
for determination of the amount of compensation or damages payable to the petitioner or the
petitioner may be directed to approach the Civil Court. This proposition cannot be accepted.
In M.C. Mehta & Anr. vs. Union of India & Ors., (1987) 1 SCC 395, this Court observed as under:-
"7. We are also of the view that this Court under Article 32(1) is free to devise any
procedure appropriate for the particular purpose of the proceeding, namely,
enforcement of a fundamental right and under Article 32(2) of the court has the
implicit power to issue whatever direction, order or writ is necessary in a given case,
including all incidental or ancillary power necessary to secure enforcement of the
fundamental right. The power of the court is not only injunctive in ambit, that is,
preventing the infringement of a fundamental right, but it is also remedial in scope
and provides relief against a breach of the fundamental right already committed vide
Bandhua Mukti Morcha case. If the court were powerless to issue any direction, order
or writ in cases where a fundamental right has already been violated, Article 32
would be robbed of all its efficacy, because then the situatiuon would be that if a
fundamental right is threatened to be violated, the court can injunct such violation
but if the violator is quick enough to take action infringing the fundamental right, he
would escape from the net of Article 32. That would, to a large extent, emasculate the
fundamental right guaranteed under Article 32 and render it impotent and futile. We
must, therefore, hold that Article 32 is not powerless to assist a person when he finds
that his fundamental right has been violated. He can in that event seek remedial
assistance under Article 32. The power of the court to grant such remedial relief may
include the power to award compensation in appropriate cases. We are deliberately
using the words "in appropriate cases" because we must make it clear that it is not in
every case where there is a breach of a fundamental right committed by the violator
that compensation would be awarded by the court in a petition under Article 32. The
infringement of the fundamental right must be gross and patent, that is,
incontrovertible and ex facie glaring and either such infringement should be on a
large scale affecting the fundamental rights of a large number of persons, or it should
appear unjust or unduly harsh or oppressive on account of their poverty or disability
or socially or economically disadvantaged position to require the person or persons
affected by such infringement to initiate and pursue action in the civil courts.
Ordinarily, of course, a petition under Article 32 should not be used as a substitute
for enforcement of the right to claim compensation for infringement of a
fundamental right through the ordinary process of civil court. It is only in exceptionalCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

cases of the nature indicated by us above, that compensation may be awarded in a
petition under Article 32. This is the principle on which this Court awarded
compensation in Rudul Shah v. State of Bihar. So also, this Court awarded
compensation to Bhim Singh, whose fundamental right to personal liberty was
grossly violated by the State of Jammu and Kashmir. If we make a fact analysis of the
cases where compensation has been awarded by this Court, we will find that in all the
cases, the fact of infringement was patent and inconvertible, the violation was gross
and its magnitude was such as to shock the conscience of the court and it would have
been gravely unjust to the person whose fundamental right was violated, to require
him to go to the civil court for claiming compensation."
Thus, where public functionaries are involved and matter relates to the violation of Fundamental
Rights or the enforcement of public duties etc., the remedy would lie, at the option of the petitioner,
under the public law notwithstanding that damages are also claimed in those proceedings.
The decisions relied upon by Mr. Parasaran, namely, P. Rathinam vs. Union of India & Ors.(1989)
Supp. 2 SCC 716 and In Re: Death of Sawinder Singh Grover (1995) Supp. 4 SCC 450, cannot be
pressed in aid as in the earlier case, criminal trial was pending while in the latter case the matter had
not been finally investigated.
In view of the natural affinity with the British legal system, particularly as both the learned counsel
have referred to and relied upon the cases relating to public law decided by the Courts in England,
we may consider the question from that angle and in that light.
In England, the position is not much different. In 1977, when certain procedural changes were
brought about on the recommendations of the Law Commission and Order 53 was introduced, it
became possible for a litigant to make an application for judicial review and claim, in such
application, damages also against public bodies. Under the remedy of judicial review, it is possible to
review not only the merits of the decision in respect of which the application for judicial review is
made, but the whole decision-making process also. A decision of inferior court or a public authority
could be quashed by an order of Certiorari made on an application for judicial review where that
court or authority acted without jurisdiction or exceeded its jurisdiction or failed to comply with the
rules of natural justice or where there was an error of law apparent on the face of the record or the
decision was unreasonable in the Wednesbury sense (that is, no reasonable person could have come
to the conclusion to which the public authority had arrived at). In view of the Supreme Court Act,
1981, read with Order 53, it became possible for the High Courts to grant prerogative orders for
mandamus or Prohibition and Certiorari in those classes of cases in which it had power to do so
immediately before the passing of that Act and by virtue of Order 53, the court also got a power even
in judicial review proceedings, to grant declaration and injunctions and to award damages.
If the proceedings were directed to challenge the decision of a public law nature, and were not
initiated for enforcement of private rights, an application for judicial review was the only
permissible course. It may be pointed out that one of the restrictions on the making of an
application for judicial review is that the person has to disclose "sufficient interest" and obtain leaveCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

of the court. The Supreme Court Act, 1981, read with Order 53, Rule 3, indicates that no application
for judicial review can be made (either in a civil or criminal case) unless the leave to apply for
judicial review has been obtained. The purpose of this requirement is to eliminate frivolous,
vexatious or hopeless application for judicial review and to ensure that an applicant is allowed
substantive hearing only if the court is satisfied that there is a case fit for further investigation. As
pointed out earlier, the person applying for judicial review has to disclose that he has a "sufficient
interest" in the matter to which the application relates. This is what is provided by Section 31(3) of
the Supreme Court Act, 1981 and Order 53 Rule 3(7).
In R. v. Horsham Justices 1982 QB 762 = 1982 (2) All ERs 269, a newspaper reporter and the
National Union of Journalists were held to have locus standi to apply for judicial review to quash the
order of Magistrate made under the Contempt of Courts Act, 1961 prohibiting the publication of any
report of committal proceedings until the commencement of the trial.
At some stage, particularly between the 1920s and 1960s, it was thought that prerogative orders of
Certiorari, Prohibition and Mandamus only lay against persons or bodies with judicial or quasi
judicial functions and did not apply to an Authority exercising administrative powers. But this
distinction between judicial and administrative activities was obliterated by the decision of the
House of Lords in Ridge v. Baldwin 1964 AC 40 = 1963 (2) All ERs 66. The effect of this decision is
that the judicial review lies not only against an inferior court or tribunal, but also against persons or
bodies which perform public duties or functions.
Thus, judicial review would lie against persons and bodies carrying out public functions. But it
would not lie against a person or body carrying out private law and not public law functions. In such
cases, the proper remedy is by way of action for a declaration and, if necessary, an injunction.
There is also a self-imposed restriction on the exercise of power of judicial review which is to the
effect that the courts would not normally grant judicial review where there is available another
avenue of appeal or remedy. In R. v. Epping & Harlow General Commissioners 1983 (3) All ERs 257,
the court observed :
"It is a cardinal principle that, save in the most exceptional circumstances, the
jurisdiction to grant judicial review will not be exercised where other remedies are
available and have not been used."
On an application for judicial review, the Court has power to award damages to the applicant
provided the claim for damages has been included in the statement made in support of the
application for leave to apply for judicial review. But the relief for damages can be granted only
when the court is satisfied that if the claim had been made in an action initiated by the applicant, he
could have been awarded damages. [Rule 7(1) of Order 53]. The application for judicial review, if not
made at the earliest, is liable to be dismissed for delay and laches.
There is, therefore, not much of a difference between the powers of the court exercised here in this
country under Article 32 or 226 and those exercised in England for judicial Review. Public lawCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

remedies are available in both the countries and the courts can award damages against public
authorities to compensate for the loss or injury caused to the plaintiff/petitioner, provided the case
involves, in this country, the violation of fundamental rights by the Govt. or other public authorities
or that their action was wholly arbitrary or oppressive in violation of Article 14 or in breach of
statutory duty and is not a purely private matter directed against a private individual.
Mr. Parasaran next contended that allotment of Petrol outlets by the petitioner would, in law, be
treated as "act of the State" or "Sovereign act" and, therefore, it would be immune from civil or
criminal action including action in Tort. This submission is also liable to be rejected.
The liability of the King under the British Law for tortious acts of the servants can be assessed from
a passage from Rattan Lal's "Law of Torts", 23rd Edition, as under:-
"He (The King) is not liable to be sued civilly or criminally for a supposed wrong.
That which the sovereign does personally, the law presumes will not be wrong; that
which the sovereign does by command to his servants, cannot be a wrong in the
sovereign because, if the command is unlawful, it is in law no command, and the
servant is responsible for the unlawful act, the same as if there had been no
command. (See: Tobin v. The Queen (1864) 16 CB [N.S.] 310). So the Crown was not
liable in tort at common law for wrongs committed by its servants in the course of
employment not even for wrongs expressly authorised by it. (See: Canterbury
(Viscount) A.H. General (1842) 1 Ph 306; High Commr. for India & Pakistan v. Lall,
(1948) 40 Bom LR 649 = AIR 1948 PC 121 = 75 IA 225). Even the heads of the
department or superior officers could not be sued for torts committed by their
subordinates unless expressly authorised by them (See: Raleigh v. Goschen (1898) 1
Ch.73); only the actual wrongdoer could be sued in his personal capacity. In practice,
the action against the officer concerned was defended by the Treasury Solicitor and
the judgment was satisfied by the Treasury as a matter of grace. Difficulty was,
however, felt when the wrongdoer was not identifiable. (See: Royster v. Cavey (1947)
KB 204). The increased activities of the Crown have now made it the largest employer
of men and the largest occupier of property. The above system was, therefore,
proving wholly inadequate and the law needed a change which was brought about by
the Crown Proceedings Act, 1947. (See: Home Office v. Dorset Yacht Co. (1970) AC
1004 = (1970) 2 All ER 294 [HL]). Nothing in the Act authorises proceedings in tort
against the Crown in its private capacity (s.40), or affects powers or authorities
exercisable by virtue of the prerogative of the Crown or conferred upon the Crown by
statute (s.11[1]). Subject to this, the Act provides that the Crown shall be subject to all
those liabilities in tort to which, if it were a person of full age and capacity, it would
be subject (1) in respect of torts committed by its servants or agents, provided that
the act or omission of the servant or agent would, apart from the Act, have given rise
to a cause of action in tort against that servant or agent or against his estate; (2) in
respect of any breach of those duties which a person owes to his servants or agents at
common law by reason of being their employer; (3) in respect of any breach of the
duties attaching at common law to the ownership, occupation, possession or controlCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

of property.
Liability in tort also extends to breach by the Crown of a statutory duty. It is also no defence for the
Crown that the tort was committed by its servants in the course of performing or purporting to
perform functions entrusted to them by any rule of the common law or by statute. The law as to
indemnity and contribution as between joint tort-feasors shall be enforceable by or against the
Crown and the Law Reform (Contributory Negligence) Act, 1945 binds the Crown. Although the
Crown Proceedings Act preserves the immunity of the Sovereign in person and contains savings in
respect of the Crown's prerogative and statutory powers, the effect of the Act in other respects,
speaking generally, is to abolish the immunity of the Crown in tort and to equate the Crown with a
private citizen in matters of tortious liability."
From the above, it would be seen that the Crown in England does not enjoy absolute immunity and
may be held vicariously liable for the tortious acts of his officers and servants.
The maxim that the "King can do no wrong" on the basis of which Common Law rule that "Crown
was not answerable for the torts committed by its servants" was generated, has not been applied
here in this country.
India at one time was under the Sovereignty of East India Company which had two-fold character.
They had powers to carry on trade as merchants. This was their basic character. They had an
additional character. They had been delegated by the British Crown powers to acquire, retain and
govern territories, to raise and maintain armies and to make peace and war with native States. East
India Company was subsequently taken over by the Crown and Govt. of India Act, 1858 was passed
by the British Parliament. Section 68 of the Act allowed the Secretary of the State in Council to sue
or be sued marking a departure from the common law rule that no proceedings, civil or criminal,
could be filed against the Crown.
In spite of the above provision, the Supreme Court of Calcutta in The Peninsular & Oriental
Steamship Navigation Co. vs. The Secretary of State for India 1868-69 Bombay H.C. Reports Vol. V.
Appendix-A P.1 held that the rule of immunity was applied by drawing a distinction by the acts done
by the public servants in the delegated exercise of sovereign powers and acts done by them in the
conduct of other activities. Peacock, CJ, who delivered the judgment observed :
"It is clear that the East India Company would not have been liable for any act done
by any of its officers or soldiers in carrying on hostilities, or for the act of any of its
naval officers in seizing as prize property of a subject, under the supposition that it
was the property of an enemey, nor for any act done by a military or naval officer or
by any soldier or sailor, whilst engaged in military or naval duty, nor for any acts of
any of its officers or servants in the exercise of judicial functions."
This decision was followed by the Calcutta High Court in Nobin Chunder Dey v. Secretary of State
for India ILR (1875-76) 1 Cal. 11, but the Madras High Court in Secretary of State for Indian Council
vs. Hari Bhanji & Anr. ILR (1882) 5 Mad. 273 and the Bombay High Court in P.V. Rao vs.Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

Khushaldas S. Advani (1949) 51 Bombay Law Reporter 342 = AIR 1949 Bombay 277 did not follow
the decision. The decision of the Bombay High Court was subsequently approved by this Court in
Province of Bombay vs. K.S. Advani 1950 SCR 621 = AIR 1950 SC 222 and it was clearly laid down
that the Govt. would also be liable for Torts committed in exercise of Sovereign powers except when
the act complained of amounted to an act of State.
Govt. of India Act, 1858 was replaced by the Govt. of India Act, 1915 and the provisions contained in
Section 65 of 1858 Act were retained in Section 32 of the 1915 Act. This Act was subsequently
replaced by the Govt. of India Act, 1935 and in this Act the corresponding provision was made in
Section 176(1). This provision was continued in the Constitution by Article 300 (1) which reads as
under :
"The Government of India may sue or be sued by the name of the Union of India and
the Government of a State may sue or be sued by the name of the State and may,
subject to any provisions which may be made by an Act of Parliament or of the
legislature of such State enacted by virtue of powers conferred by this Constitution,
sue or be sued in relation to their respective affairs in the like cases as the Dominion
of India and the corresponding Provinces or the corresponding Indian States might
have sued or been sued if this Constitution had not been enacted."
The decision of this Court in Province of Bombay vs. K.S. Advani (supra) was followed by the First
Report of the Law Commission of India in 1956 which accepted the view of this Court and
recommended as under :
"In the context of a welfare State it is necessary to establish a just relation between
the rights of the individual and the responsibilities of the State. While the
responsibilities of the State have increased, the increase in its activities has led to a
greater impact on the citizen. For the estabishment of a just economic order
industries are nationalised. Public utilities are taken over by the State. The State has
launched huge irrigation and flood control schemes. The production of electricity has
practically become a Government concern. The State has established and intends to
establish big factories and manage them. The State carries on works departmentally.
The doctrine of laissez faire - which leaves every one to look after himself to his best
advantage has yielded place to the ideal of a welfare State - which implies that the
State takes care of those who are unable to help themselves."
The Commission after referring to various provisions in the legislation of other countries also
observed:
"The old distinction between sovereign and non-sovereign functions or governmental
and non-governmental functions should no longer be invoked to determine the
liability of the State. As Professor Friendman observes:Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

'It is now increasingly necessary to abandon the lingering fiction of a legally
indivisible State, and of a feudal conception of the Crown, and to substitute for it the
principle of legal liability where the State, either directly or through incorporated
public authorities engages in activities of a commercial, industrial or managerial
character. The proper test is not an impracticable distinction between governmental
and non-governmental functions, but the nature and form of the activitiy in
question.' In State of Rajasthan vs. Mst. Vidhyawati AIR 1962 SC 933, a claim for
damages was made by the dependants of a person who died in an accident caused by
the negligence of the driver of a jeep maintained by the Govt. for official use of the
Collector of Udaipur while it was being brought back from the workshop after repairs.
The Rajasthan High Court held that the State was liable. This view was upheld by this
Court with the observation that :
"The immunity of the Crown in the United Kingdom was based on the old feudalistic
notions of justice, namely, that the King was incapable of doing a wrong, and,
therefore, of authorising or instigating one, and that he could not be sued in his own
courts. In India, ever since the time of the East India Company, the Sovereign has
been held liable to be sued in tort or in contract and the common law immunity never
operated in India. Now that we have, by our Constitution, established a Republican
form of Government, and one of the objectives is to establish a socialistic State with
its varied industrial and other activities, employing a large army of servants, there is
no justification, in principle or in public interest, that the State should not be held
liable vicariously for the tortious act of its servant."
The course of justice, insofar as the tortious liability of the State is concerned, was disturbed by the
decision of this Court in Kasturi Lal Ralia Ram Jain vs. State of U.P. AIR 1965 SC 1039 = 1965 (1)
SCR 375, in which a partner of Kasturilal Ralia Ram Jain, a firm of jewellers of Amritsar, had gone
to Meerut for selling gold and silver, but was taken into custody by the police on the suspicion of
possessing stolen property. He was released the next day, but the property which was recovered
from his possession could not be returned to him in its entirity inasmuch as the silver was returned
but the gold could not be returned as the Head Constable in charge of the Malkhana
misappropriated it and fled to Pakistan. The firm filed a suit against the State of U.P. for the return
of the ornaments and in the alternative for compensation. This Court, speaking through
Gajendragadkar, CJ, observed as under :
"The act of negligence was committed by police officers while dealing with the
property of Ralia Ram which they had seized in the exercise of their statutory powers.
Now, the power to arrest a person, to search him, and to seize property found with
him, are powers conferred on the specified officers by statute and in the last analysis,
they are powers which can be properly characterised as sovereign powers, and so,
there is no difficulty in holding that the act which gave rise to the present claim for
damages has been committed by the employees of the respondent during the course
of their employment; but the employment in question being of the category which
can claim the special characteristic of sovereign power, the claim cannot beCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

sustained."
The earlier decision of this Court in Mst.
Vidyavati's case (supra) was distinguished on the ground that it was based on a tortious liability not
arising from the exercise of Sovereign power. The decision in Kasturilal's case (supra), has, apart
from being criticised (See: Constitutional Law of India by Seervai), not been followed by this Court
in subsequent decisions and, therefore, much of its efficacy as a binding precedent has been eroded.
Reference in this connection may be made to the decisions of this Court in State of Gujarat vs.
Memon Mahomed Haji Hasan AIR 1967 SC 1885 and Smt. Basava Kom Dyamogouda Patil vs. State
of Mysore AIR 1977 SC 1749 and a number of other cases, including those dealt with under Article
32 of the Constitution by this Court in all of which compensation and damages were awarded to the
petitioner for tortious liability of the servants of the State. These cases, namely, Rudul Shah vs. State
of Bihar (supra); Bhim Singh vs. State of J&K (supra), SAHELI, a Woman's Resources Centre vs.
Commr. of Police, Delhi (supra); People's Union of Democratic Rights vs. Police Commissioner,
Delhi (supra) and Sebastin M. Hongray vs. Union of India (1984) 3 SCC 82 = AIR 1984 SC 1026, do
not refer to the decision of this Court in Kasturilal's case (supra). It may be mentioned that in
Kasturilal's case, the Court did not consider the State liability for violation of Fundamental Rights of
a citizen relating to Life and Personal Liberty. It will be seen that where on account of tortious act of
the servant of a State, a person's Fundamental Right to Life and Liberty was violated, the Court
granted damages and compensation to that person. The liability is based on the provisions of the
Constitution and is a new liability which is not hedged in by any limitations including the doctrine of
`Soverign immunity'. Reference may also be made to the decision of Privy Council in Maharaj vs.
Attorney General of Trinidad & Tobago (No.2) (1978) 2 All ER 670 in which the appellant, who was
a Barrister, was sentenced to 7 days' imprisonment by a Judge of the High Court, which was set
aside by the Privy Council in appeal. The appellant, in the meantime, applied for redress under
Section 6 of the Constitution of Trinidad & Tobago on the ground that he was deprived of his liberty
without due process of law as guaranteed to him under Section 1 of that Constitution. The claim was
dismissed by the High Court, but was upheld by the Privy Council in appeal. The Privy Council held
that Section 6 of the Constitution impliedly allowed the High Court to award compensation as
compensation may be the only practicable form of redress in some cases.
The entire case law was reviewed by R.M. Sahai, J. in his illuminating judgment in N. Nagendra Rao
& Co. vs. State of A.P. AIR 1994 SC 2663 = (1994) 6 SCC 205 in which the case of Neelabati Behera
(supra) was followed and it was observed, inter alia, as under :
"But there the immunity ends. No civilised system can permit an executive to play
with the people of its country and claim that it is entitled to act in any manner as it is
sovereign. The concept of public interest has changed with structural change in the
society. No legal or political system today can place the State above law as it is unjust
and unfair for a citizen to be deprived of his property illegally by negligent act of
officers of the State without any remedy. From sincerity, efficiency and dignity of
State as a juristic person, propounded in Nineteenth Century as sound sociological
basis for State immunity the circle has gone round and the emphasis now is more onCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

liberty, equality and the rule of law. The modern social thinking of progressive
societies and the judicial approach is to do away with archaic State protection and
place the State or the Government at par with any other juristic legal entity. Any
watertight compartmentalisation of the functions of the State as "sovereign and
non-sovereign or "governmental or non-governmental" is not sound. It is contrary to
modern jurisprudential thinking. The need of the State to have extraordinary powers
cannot be doubted. But with the conceptual change of statutory power being
statutory duty for sake of society and the people the claim of a common man or
ordinary citizen cannot be thrown out merely because it was done by an officer of the
State even though it was against law and negligently. Needs of the State, duty of its
officials and right of the citizens are required to be reconciled so that the rule of law
in a welfare State is not shaken. Even in America where this doctrine of sovereignty
found it place either because of the 'financial instability of the infant American States
rather than to the stability of the doctrine theoretical foundation,' or because of
'logical and practical ground,' or that 'there could be no legal right as against the State
which made the law' gradually gave way to the movement from, 'State irresponsibility
to State responsibility.' In welfare State, functions of the state are not only defence of
the country or administration of justice or maintaining law and order but it extends
to regulating and controlling the activities of people in almost every sphere,
educational, commercial, social, economic, political and even marital. The
demarcating line between sovereign and non-sovereign powers for which no rational
basis survives, has largely disappeared. Therefore, barring functions such as
administration of justice, maintenance of law and order and repression of crime etc.
which are among the primary and inalienable functions of a constitutional
Government, the State cannot claim any immunity."
Reference may also be made to the decision of this Court in Shyam Sunder vs. State of Rajasthan
(1974) 1 SCC 690 = AIR 1974 SC 890 in which a truck belonging to Public Works Department was
engaged in famine relief work when an accident occurred because of the negligence of the driver.
When the State was sued for compensation, the defence raised was of immunity on account of
Sovereign function of the State. The plea was rejected by this Court which observed that famine
relief work was not a Sovereign function of the State as traditionally understood. What are
traditional Sovereign functions of the State was considered by this Court in State of Bombay vs.
Hospital Mazdoor Sabha AIR 1960 SC 610 and Corporation of the City of Nagpur vs. Employees
Fulsing Mistry N.H. Majumdar AIR 1960 SC 675 = (1960) 2 SCR 942 and in both these decisions,
observations of Lord Watson in Richard Coomber vs. The Justices of the County Berks (1883-84) 9
AC 61 that traditional Sovereign functions were the making of laws, the administration of justice, the
maintenance of order, the repression of crime, carrying on of war, the making of treaties of peace
and other consequential functions, were approved.
For the reasons stated above, we are of the view that the allotment of petrol outlets by the petitioner
cannot be treated as "act of the State" and the rule of immunity invoked by Mr. Parasaran cannot be
accepted. The next submission of Mr. Parasaran relates to the tort of misfeasance in public office
which has been held to have been committed by the petitioner and for which he has been directed toCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

pay Rs.50 lakhs as exemplary damages. It is contended by Mr.Parasaran that the ingredients of the
tort of misfeasance in public office were not made out; the rule of exemplary damages was not
properly invoked; and in any case, the amount of Rs.50 lakhs was arbitrarily fixed without there
being any rational basis on which it was computed. It was also contended that the persons who
suffered injury on account of tort of misfeasance are neither identifiable nor have they been
specified and in the absence of this vital factor, no finding could have been recorded about the
commission of tort of misfeasance. With regard to award of exemplary damages of Rs.50 lakhs, it is
contended that in public law proceedings, namely, in proceedings under Article 32 of the
Constitution, compensation and damages are awardable only against the State for violation of
Fundamental Rights of a citizen or person by the servant of the State or for the tortious acts of the
servant of the State resulting in violation of Fundamental Rights, but compensation or damages
cannot be allowed in favour of the State. It is also contended that the petitioner at the relevant time
was the Minister of State for Petroleum in the Central Cabinet and, therefore, the order, directing
him to pay Rs.50 lakhs as exemplary damages to the State is an order to the Govt. to pay exemplary
damages to itself which is not possible under any system of law and, therefore, wholly erroneous.
It is contended that the error being apparent on the face of the record, the judgment requires to be
reviewed.
We would first consider the meaning and contents of the Tort of Misfeasance in the public office.
`Tort' has been derived from the Latin word "tortus" which means "twisted" or "crooked". In its
original and most general sense, "tort" is a wrong. Jowitt's Dictionary of English Law defines Tort as
under :
"Tort signifies an act which gives rise to a right of action, being a wrongful act or
injury consisting in the infringement of a right created otherwise than by a contract.
Torts are divisible into three classes, according as they consist in the infringement of
a jus in rem, or in the breach of a duty imposed by law on a person towards another
person, or in the breach of a duty imposed by law on a person towards the public.
The first class includes (a) torts to the body of a person, such as assault, or to his
reputation, such as libel, or to his liberty, such as false imprisonment; (b) torts to real
property, such as ouster, trespass, nuisance, waste, subtraction, disturbance; (c) torts
to personal property, consisting (i) in the unlawful taking or detaining of or damage
to corporeal personal property or chattels; or
(ii) in the infringement of a patent, trade mark, copyright, etc.; (d) slander of title; (e)
deprivation of service and consortium.
The second class includes deceit and negligence in the discharge of a private duty.
The third class includes those cases in which special damage is caused to an individual by the breach
of a duty to the public." Winfield's classic definition provides as under:-Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

"Tortious liability arises from the breach of a duty primarily fixed by the law; such
duty is towards persons generally and its breach is redressible by an action for
unliquidated damages."
Apart from tort which may be committed by a private individual, the officers of the Govt. would also
be liable in damages for their wrongful acts provided the act does not fall within the purview of "act
of the State." So also, the administrative bodies or authorities, which deal in administrative matters
and take decisions specially for the implementation of the Govt. policies, have to act fairly and
objectively and may in some cases also be required to follow the principles of natural justice. It is the
basic principle of Administrative Law that if the authorities are conferred certain power, then that
power must be exercised in good faith and the administrative decision must be made after taking
into account all matters relevant for the exercise of that power. The authority must not be influenced
by irrelevant matters and if the order is likely to prejudicially affect the rights, or, even the
reasonable expectation of a person, the principles of natural justice must be followed and the person
likely to be affected must be given an opportunity of hearing. Thus, the decision of an administrative
authority can be challenged on the grounds, inter alia, of illegality, irrationality and procedural
impropriety.
In Administrative Law by Sir William Wade, 7th Edn., "misfeasasnce in public office" has been
defined as malicious abuse of power, deliberate mal-administration and unlawful acts causing
injury. It is further provided in the same book that "misfeasance in public office" is the name now
given to the tort of deliberate abuse of power. After considering various decided cases, Prof. Wade
proceeds to say :
"This and other authorities, including the last-mentioned decision of the House of
Lords, were held to establish that the tort of misfeasance in public office goes at least
to the length of imposing liability on a public officer who does an act which to his
knowledge amounts to an abuse of his office and which causes damage."
(Emphasis supplied) Prof. Wade further proceeds to say as under:
"There are now clear indications that the courts will not award damages against
public authorities merely because they have made some order which turns out to be
ultra vires, unless there is malice or conscious abuse. Where an Australian local
authority had passed resolutions restricting building on a particular site without
giving notice and fair hearing to the landowner and also in conflict with the planning
ordinance, the Privy Council rejected the owner's claim for damages for depreciation
of his land in the interval before the resolutions were held to be invalid. The
well-established tort of misfeasance by a public officer, it was held, required as a
necessary element either malice or knowledge by the council of the invalidity of its
resolutions. In New Zealand, also a company failed in a claim for damages resulting
from a minister's refusal of permission for it to obtain finance from a Japanese
concern. The minister's refusal was quashed as ultra vires, but it was held that this
alone was not a cause of action. Nor does it appear that claims of this kind can beCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

strengthened by pleading breach of statutory duty.
The Court of Appeal reinforced these decisions in a case of importance, but since
shown to be of doubtful authority, under European Community law. A ministerial
revocation order had prohibited the import of turkey meat from France and was held
unlawful by the European Court as being in breach of Article 30 of the Treaty of
Rome, which is binding in British law under the European Communities Act 1972.
French traders who had suffered losses under the ban then sued the ministry for
damages. On preliminary issues it was held that they had no cause of action merely
for breach of statutory duty, as already related. Likewise there was no cause of action
merely because the minister's order was unlawful: it could be quashed or declared
unlawful on judicial review, but there was no remedy in damages. There would be
such a remedy, however, if it could be shown that the minister had abused his power,
well knowing that his order was a breach of Article 30 and would injure the plaintiffs'
business. It was alleged that his conscious purpose was to protect English turkey
producers rather than to prevent the spread of disease, and that he knew that this
made his order unlawful. The element of bad faith, or malic as judges have often
called it, seems now to be established as the decisive factor."
(Emphasis supplied) Thereafter, after discussing a number of authorities, Prof. Wade further says as
under :
"But the main principles of liability seem now to be emerging clearly. It can be said
that administrative action which is ultra vires but not actionable merely as a breach
of duty will found an action for damages in any of the following situations:
1. if it involves the commission of a recognised tort such as trespass, false
imprisonment or negligence;
2. if it is actuated by malice, e.g. personal spite or a desire to injure for improper
reasons;
3. if the authority knows that it does not possess the power to take the action in
question.
The decisions suggest that there is unlikely to be liability in the absence of all these elements, for
example where a licensing authority cancels a licence in good faith but invalidly, perhaps in breach
of natural justice or for irrelevant reasons. Since loss of livelihood by cancellation of a licence is just
as serious an injury as many forms of trespass or other torts, it may seem illogical and unjust that it
should not be equally actionable; and in obiter dicta in a dissenting judgment Denning LJ once
suggested that it was. Some cases of this kind may involve breach of statutory duty, where there is
the broad principle of liability discussed above. But where there is no such breach it seems probable
that public authorities and their officers will be held to be free from liability so long as they exercise
their discretionary powers in good faith and with reasonable care. Losses caused by bona fide butCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

mistaken acts of government may have to be suffered just as much when they are invalid as when
they are valid."
Halsbury's Laws of England, Vol I(I) 4th Edn. (Reissue), (para 203) provides as under :
"Deliberate abuse of public office or authority. Bad faith on the part of a public officer
or authority will result in civil liability where the act would constitute a tort but for
the presence of statutory authorisation, as Parliament intends statutory powers to be
exercised in good faith and for the purpose for which they were conferred. Proof of
improper motive is necessary in respect of certain torts and may negative a defence of
qualified privilege in respect of defamation, but this is not peculiar to public
authorities. There exists an independent tort of misfeasance by a public officer or
authority which consists in the infliction of loss by the deliberate abuse of a statutory
power, or by the usurpation of a power which the officer or authority knows he does
not possess, for example by procuring the making of a compulsory purchase order, or
by refusing, or cancelling or procuring the cancellation of a licence, from improper
motives. However, where there has been no misfeasance, the fact that a public officer
or authority makes an ultra vires order or invalidly exercises statutory powers will not
of itself found an action for damages."
de Smith in Judicial Review of Administrative Action, while speaking of tort of misfeasance in public
office, says as under :
"A public authority or person holding a public office may be liable for the tort of
misfeasance in public office where :
(1) there is an exercise or non-exercise of public power, whether common law,
statutory or from some other source;
(2) which is either (a) affected by malice towards the plaintiff or (b) the decision
maker knows is unlawful; and (3) the plaintiff is in consequence deprived of a benefit
or suffers other loss."
de Smith further says as under :
"A power is exercised maliciously if its repository is motivated by personal animosity
towards those who are directly affected by its exercise. Where misfeasance is alleged
against a decision-making body, it is sufficient to show that a majority of its members
present had made the decision with the object of damaging the plaintiff. Often there
may be no direct evidence of the existence of malice, and in these circumstances the
court may make adverse inferences, e.g. from the fact that a decision was
unreasonable that it could only be explained by the presence of such a motive. A
court will not entertain allegation of bad faith or malice made against the repositry of
a power unless it has been expressly pleaded and properly particularised."Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

Reference may also be made to the decision of the High Court of Australia in Northern Territory vs.
Mengel, (69) The Australian Law Journal 527, in which it was observed as under:-
"A number of elements must combine to make a purported exercise of administrative
power wrongful. The first is that the purported exercise of power must be invalid,
either because there is no power to be exercised or because a purported exercise of
the power has miscarried by reason of some matter which warrants judicial review
and a setting aside of the administrative action. There can be no tortious liability for
an act or omission which is done or made in valid exercise of a power. A valid exercise
of power by a public officer may inflict on another an unintended but foreseeable loss
- or even an intended loss - but, if the exercise of the power is valid, the other's loss is
authorised by the law creating the power. In that case, the conduct of the public
officer does not infringe an interest which the common law protects. However, a
purported exercise of power is not necessarily wrongful because it is ultra vires. The
history of the tort shows that a public officer whose action has caused loss and who
has acted without power is not liable for the loss merely by reason of an error in
appreciating the power available. Something further is required to render wrongful
an act done in purported exercise of power when the act is ultra vires."
With regard to the MENTAL ELEMENT, the High Court of Australia stated as under:-
"The further requirement relates to the state of mind of the public officer when the
relevant act is done or the omission is made. An early case is Ashby v. White, in which
Ashby complained that the constables of the borough in which an election was held
had refused to permit him to vote "fraudulently and maliciously intending to damnify
him".
Lord Holt CJ, whose judgment ultimately prevailed in the House of Lords, held that malice was
essential to the action. Malice has been understood to mean an intention to injure. In this context,
the "injury" intended must be something which the plaintiff would not or might not have suffered if
the power available to the public officer had been validly exercised. (It is in that sense that I use the
term "injury" hereafter.) In more recent times, the scope of the tort has not been limited to cases in
which a public officer has acted maliciously. It has now been accepted that if a public officer engages
in conduct in purported exercise of a power but with actual knowledge that there is no power to
engage in that conduct, the conduct may amount to an abuse of office."
The High Court further observed as under:-
"I respectfully agree that the mental element is satisfied either by malice (in the sense
stated) or by knowledge. That is to say, the mental element is satisfied when the
public officer engages in the impugned conduct with the intention of inflicting injury
or with knowledge that there is no power to engage in that conduct and that that
conduct is calculated to produce injury. These are states of mind which are
inconsistent with an honest attempt by a public officer to perform the functions of theCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

office. Another state of mind which is inconsistent with an honest attempt to perform
the functions of a public office is reckless indifference as to the availability of power
to support the impugned conduct and as to the injury which the impugned conduct is
calculated to produce. The state of mind relates to the character of the conduct in
which the public officer is engaged - whether it is within power and whether it is
calculated (that is, naturally adapted in the circumstances) to produce injury. In my
opinion, there is no additional element which requires the identification of the
plaintiff as a member of a class to whom the public officer owes a particular duty
though the position of the plaintiff may be relevant to the validity of the public
officer's conduct. For example, the officer's administrative act may be invalid because
he or she did not treat the plaintiff with procedural fairness. It is the absence of an
honest attempt to perform the functions of the office that constitutes the abuse of the
office. Misfeasance in public office consists of a purported exercise of some power or
authority by a public officer otherwise than in an honest attempt to perform the
functions of his or her office whereby loss is caused to a plaintiff. Malice, knowledge
and reckless indifference are states of mind that stamp on a purported but invalid
exercise of power the character of abuse of or misfeasance in public office. If the
impugned conduct then causes injury, the cause of action is complete."
In Dunlop v. Woollahra Municipal Council (1981) 1 All ER 1202 (PC), it was held that mere
invalidity of the order would not give rise to any liability for payment of damages in an action in tort
to the aggrieved party. It was, however, held in the same case that if the action of the authority is
actuated by malice, it would amount to "tort of misfeasance by a public officer." In Asoka Kumar
David v. M.A.M.M.Abdul Cader (1963) 1 WLR 834 (PC), it was held that the tort of misfeasance will
also be committed even in the absence of malice if the public officer knew both that what he was
doing was invalid and that it will injure the plaintiff. (See also : Bourgoin SA & Ors. vs. Ministry of
Agriculture Fisheries & Food (1985) 3 All ER 585 (CA). In Jones v. Swansea City Council (1989) 3
All ER 162 (CA), it was held that if the public officer acts with malice, i.e., with an intent to injure
and thereby damage results, the liability would arise and the officer could be sued for the tort of
misfeasance in public office. The legal propositions in that case were not dissented from by the
House of Lords, though the Court of Appeal's decision was reversed on facts (See: Jones vs. Swansea
City Council (1990) 3 All ER 737 (HL).
In Three Rivers District Council and Ors. v. Bank of England (No.3), (1996) 3 All ER 558, it was held
that the tort of "misfeasance in public office" was concerned with a deliberate and dishonest
wrongful abuse of the powers given to a public officer and the purpose of the tort was to provide
compensation for those who suffered loss as a result of improper abuse of power. The conclusions
reached in that case were:-
"Issue No.1 Misfeasance in public office (1) The tort of misfeasance in public office is
concerned with a deliberate and dishonest wrongful abuse of the powers given to a
public officer. It is not to be equated with torts based on an intention to injure,
although, as suggested by the majority in Northern Territory v Mengel (1995) 69
ALJR 527, it has some similarities to them.Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

(2) Malice, in the sense of an intention to injure the plaintiff or a person is a class of
which the plaintiff is a member, and knowledge by the officer both that he has no
power to do the act complained of and that the act will probably injure the plaintiff or
a person in a class of which the plaintiff is a member are alternative, nor cumulative,
ingredients of the tort. To act with such knowledge is to act in a sufficent sense
maliciously: see Mengel 69 ALJR 527 at 554 per Deane J.
(3) For the purposes of the requirement that the officer knows that he has no power
to do the act complained of, it is sufficient that the officer has actual knowledge that
the act was unlawful or, in circumstances in which he believes or suspects that the act
is beyond his powers, that he does not ascertain whether or not that is so or fails to
take such steps as would be taken by an honest and reasonable man to ascertain the
true position.
(4) For the purposes of the requirement that the officer knows that his act will
probably injure the plaintiff or a person in a class of which the plaintiff is a member it
is sufficient if the officer has actual knowledge that his act will probably damage the
plaintiff or such a person or, in circumstance in which he believes or suspects that his
act will probably damage the plaintiff or such a person, if he does not ascertain
whether that is so or not or if he fails to make such inquiries as an honest and
reasonable man would make as to the probability of such damage.
(5) If the states of mind in (3) and (4) do not amount to actual knowledge, they
amount to recklessness which is sufficent to support liability under the second limb
of the tort.
(6) Where a plaintiff establishes (i) that the defendant intended to injure the plaintiff
or a person in a class of which the plaintiff is a member (limb one) or that the
defendant knew that he had no power to do what he did and that the plaintiff or a
person in a class of which the plaintiff is a member would probably suffer loss or
damage (limb two) and (ii) that the plaintiff has suffered loss as a result, the plaintif
has a sufficient right or interest to maintain an action for misfeasance in public office
at common law. The plaintiff must of course also show that the defendant was a
public officer or entity and that his loss was caused by the wrongful act."
So far as malice is concerned, while actual malice, if proved, would render the defendant's action
both ultra vires and tortious, it would not be necessary to establish actual malice in every claim for
misfeasance in public office. In Bourgoin SA vs. Ministry of Agriculture, Fisheries & Food, (1985) 3
All ER 585 (CA) to which a reference has already been made above, the plaintiffs were French turkey
farmers who had been banned by the Ministry from exporting turkeys to England on the ground that
they would spread disease. The Ministry, however, subsequently conceded that the true ground was
to protect British turkey farmers and that they had committed breach of Article 30 of the EEC Treaty
which prohibited unjustifiable import restrictions. The defendants denied their liability for
misfeasance claiming that they were not actuated by any intent to injure the plaintiffs but by a needCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

to protect British interest. It was held by Mann, J., which was upheld by the Court of Appeal, that
proof of actual malice, ill-will or specific intent to injure is not essential to the tort. It was enough if
the plaintiff established that the defendant acted unlawfully in a manner foreseeably injurious to the
plaintiff. In another decision in Bennett v. Commr. of Police of the Metropolis and others 1995 (2)
All ER 1 (at pages 13 & 14), which was considered in Three Rivers' case (supra), it was held that the
tort of misfeasance in public office required express intent to injure.
Tort of misfeasance in public office was also considered by this Court in Lucknow Development
Authority vs. M.K. Gupta (1994) 1 SCC 243. Relying upon the Administrative Law by Prof. Wade,
exemplary damages were allowed to a consumer who had initiated proceedings under the Consumer
Protection Act, 1986. The Court held that the officers of the Lucknow Development Authority were
not immune from tortious liability and then proceeded to say that the National Consumer Disputes
Redressal Commission was not only entitled to award value of the goods or services but also to
compensate a consumer for injustice suffered by him. The Court, therefore, upheld the award of
Rs.10,000/- as compensation allowed by the Commission on the ground that the action of the
appellant amounted to harassment, mental torture and agony of the respondent. The Court then
proceeded to observe as under:-
"But when the sufferance is due to mala fide or oppressive or capricious acts etc. of a
public servant, then the nature of liability changes. The Commission under the Act
could determine such amount if in its opinion the consumer suffered injury due to
what is called misfeasance of the officers by the English Courts. Even in England
where award of exemplary or aggravated damages for insult etc. to a person has now
been held to be punitive, exception has been carved out if the injury is due to
`oppressive, arbitrary or unconstitutional action by servants of the Government'
(Salmond and Heuston on the Law of Torts). Misfeasance in public office is explained
by Wade in his book on Administrative Law thus :
"Even where there is no ministerial duty as above, and even where no recognised tort
such as trespass, nuisance, or negligence is committed, public authorities or officers
may be liable in damages for malicious, deliberate or injurious wrong-doing. There is
thus a tort which has been called misfeasance in public office, and which includes
malicious abuse of power, deliberate maladministration, and perhaps also other
unlawful acts causing injury."
(Emphasis supplied) After quoting from Wade, the Court proceeded to consider the question of
award of exemplary damages in the light of the decision in Cassell & Co. Ltd. v. Broome & Anr. 1972
(1) All ER 801 as also the earlier decision in Rookes v. Barnard 1964 (1) All ER 367 and other
English decision including Ashby v. White (1703)2 Ld Raym 938, and held that exemplary damages
could be awarded against the officers of the Lucknow Development Authority.
The decision in the Lucknow Development Authority's case (supra) has been followed by this Court
in the Judgment under Review and a notice was issued to the petitioner to show cause why should
he not be made liable to pay damages for his mala fide action in allotting petrol pumps to theCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

persons concerned. This notice was issued because the Court was of the opinion:
"Public servants may be liable in damages for malicious, deliberate or injurious
wrongdoing. According to Wade :
`There is, thus, a tort which has been called misfeasance in public office and which
includes malicious abuse of power, deliberate maladministration, and perhaps also
other unlawful acts causing injury.' With the change in socio-economic outlook, the
public servants are being entrusted with more and more discretionary powers even in
the field of distribution of government wealth in various forms. We take it to be
perfectly clear, that if a public servant abuses his office either by an act of omission or
commission, and the consequence of that is injury to an individual or loss of public
property, an action may be maintained against such public servant. No public servant
can say "you may set aside an order on the ground of mala fide but you cannot hold
me personally liable." No public servant can arrogate to himself the power to act in a
manner which is arbitrary."
The order regarding notice to the petitioner was preceded by the finding that :
"He made allotments in favour of relations of his personal staff under the influence of
the staff on wholly extraneous considerations. The allotments to the sons of the
Ministers were only to oblige the Ministers. The allotments to the members of the Oil
Selection Boards and their/chairmen's relations have been done to influence them
and to have favours from them. All these allotments are wholly arbitrary, nepotistic
and are motivated by extraneous considerations."
The further finding is to the following effect :
"A Minister who is the executive head of the department concerned distributes these
benefits and largesses. He is elected by the people and is elevated to a position where
he holds a trust on behalf of the people. He has to deal with the people's property in a
fair and just manner. He cannot commit breach of the trust reposed in him by the
people. We have no hesitation in holding that Capt. Satish Sharma in his capacity as a
Minister for Petroleum and Natural Gas deliberately acted in a wholly arbitrary and
unjust manner. We have no doubt in our mind that Capt. Satish Sharma knew that
the allottees were relations of his personal staff, sons of Ministers, sons/relations of
Chairmen and members of the Oil Selection Boards and the members of the Oil
Selection Boards themselves. The allotments made by him were wholly mala fide and
as such cannot be sustained."
The Court further found as under :
"We are further of the view that Capt. Satish Sharma acted in a wholly biased manner
inasmuch as he unfairly regarded with favour the cases of 15 allottees before him. TheCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

relevant circumstances available from record and discussed by us leave no manner of
doubt in our mind that Capt. Satish Sharma deliberately acted in a biased manner to
favour these allottees and as such the allotment orders are wholly vitiated and are
liable to be set aside."
The Court also found :
"The orders of the Minister reproduced above read:
"the applicant has no regular income to support herself and her family", "the
applicant is an educated lady and belongs to Scheduled Tribe community", "the
applicant is unemployed and has no regular source of income", "the applicant is an
uneducated, unemployed Scheduled Tribe youth without regular source of
livelihood", "the applicant is a housewife whose family is facing difficult financial
circumstances" etc.etc. There would be literally millions of people in the country
having these circumstances or worse. There is no justification whatsoever to pick up
these persons except that they happen to have won the favour of the Minister on mala
fide considerations. None of these cases fall within the categories placed before this
Court in Centre for Public Interest Litigation v. Union of India but even if we assume
for argument sake that these cases fall in some of those or similar guidelines the
exercise of discretion was wholly arbitrary. Such a discretionary power which is
capable of being exercised arbitrarily is not permitted by Article 14 of the
Constitution of India. While Article 14 permits a reasonable classification having a
rational nexus to the objective sought to be achieved, it does not permit the power to
pick and choose arbitrarily out of several persons falling in the same category."
In response to the notice issued by the Court, the petitioner filed his reply in which he, inter alia,
stated as under :
"1. Captain Satish Sharma was Minister of State for Petroleum from January 8,1993
to May 16, 1996. The allotments of petrol pumps by the Minister from his
discretionary quota (that ultimately came to be challenged in Writ Petition (Civil) No.
26 of 1995 on the basis of the August 11, 1995 news item in the Indian Express)
related to the period 1993 to 1995.
2. It is submitted with utmost respect that the finding of the malafides have been
recorded in proceeding to which I was not a party. These proceedings were defended
by the Central Government. In a non-adversarial manner by placing all the facts
before this Hon'ble Court and leaving it to this Hon'ble Court to adjudicate on the
validity of the said actions. It is true that an opportunity to file an affidavit was given
to me, if I so desired. It is, however, submitted that that opportunity was given in the
context of deciding the Writ Petition which challenged the validity and correctness of
the allotments. There was no prayer in the Writ Petition making any personal claim
against me either civil or criminal and the entire record of the case was placed beforeCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

this Hon'ble Court. In addition, affidavits were filed by responsible officers of the
Department, therefore, I did not avail the option to file any affidavit. The respondent
was ready and willing to leave the question of validity of the allotments made by him
to be determined by this Hon'ble Court on the basis of the entire record. At that stage,
I had no notice that any relief was claimed against me personally by any one or that I
would be called upon to face civil or criminal proceedings.
I respctfully state that in the matter of discretionary allotments based on
Compassionate grounds, individual assessment and perception are bound to differ
from person to person. There is no material to suggest that I made any allotments for
any pecuniary advantage or illegal gain. Thus, I submit that before deciding on my
personal liability to pay compensation or face criminal trial, I should be permitted to
place my version of the facts and circumstances.
The legal issue of the personal liability of Ministers arising out of abuse of executive
powers under the Rules of Business in contradistinction to statutory powers
conferred upon designated functionaries involves important questions impinging on
the interpretation of the constitution. I respectfully state that this matter should be
dealt with by this Hon'ble Court under Article 145 (3).
3. The principal flaw found in all these allotments is that the procedure of receiving
such applications for discretionary quota was an institutionalised one and lacked
transparency. The lack of institutionalisation of procedures for discretionary quotas
has been in existence since 1982 and I state that it is not suggested that I flouted any
criteria or guideline. I merely followed the existing established practice in dealing
with the applications for discretionary quota following the precedents set by a host of
my predecessors belonging to different political parties. I state that while the Hon'ble
Court may have found this manner of working incompatible with Article 14 it cannot
be suggested that I wilfully and deliberately evolved a procedure which was found to
be illegal. Thus I submit that I did not personally violate any law, rule or guideline in
the manner so as to expose me to a personal liability, civil or criminal. The
substantial question of law as to interpretation of the Constitution was and continues
to be whether arbitrariness or even malice in law in the exercise of power on a
long-standing policy handled by the administrative team can be fastened on to the
elected person appointed as Minister by the President on the advice of the Prime
Minister.
4. The judgment relies on observations in Lucknow Development Authority vs. M.K.
Gupta [(1994) 1 SCC 243] for holding that misfeasance in public offices is a part of
the law of tort. It is submitted that the Lucknow Development Authority case arose
under the Consumer Protection Act wherein there was a specific aggrieved/injured
party, who claimed of injury/loss caused to him. In the instant case, the question of
damages does not arise at all, since there is no finding that I acted to the prejudice or
detriment of any specific person in derogation of my statutory (or constitutional)Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

rights or in violation of any law, rule or even guideline.
5. As far as the proposed direction to the police authorities is concerned, it is
respectfully submitted that :
(a) No offence u/s 405 or 406 of the IPC has been made out.
(b) Any direction, based on these facts, and expressing a prime-facie satisfaction of
this Hon'ble Court that any criminal offence has been committed would be violative
of Article 21 of the constitution, and
(c) Any adjudication, even in to the existence of a prima- facie case by this Hon'ble
Court would necessarily introduce disclosure by the answering deponent of defence
he may have in the trial which may ensue - which procedure would be violative of
Article 21."
The Court by its judgment dated 4.11.1996 disposed of the matter as follows:
"3. Pursuant to the above-quoted direction, a show- cause notice was issued to Capt.
Satish Sharma. He has filed affidavit in reply to the show-cause notice.
4. We have heard Mr. Salve, learned counsel appearing for Capt. Satish Sharma.
There are two parts of the directions quoted above. This Court has called upon Capt.
Satish Sharma to show cause why a direction be not issued to the appropriate police
authority to register a case and initiate prosecution against him for criminal breach of
trust or any other offence under law.
5. The findings of this Court, quoted above, and the conclusions reached in the
Common Cause case, leave no manner of doubt that an investigation by an
independent authority is called for in this case. We, therefore, direct the Central
Bureau of Investigation (CBI) to register a case against Capt. Satish Sharma in
respect of the allegation dealt with and the findings reached by this Court in the
Common Cause case. The CBI shall hold investigation and proceed in accordance
with law. There shall be no limit on the power, scope and sphere of investigation by
the CBI. We, however, make it clear that the CBI shall not be influenced by any
observations made by this Court or the findings reached in Common Cause case, for
reaching the conclusion as to whether any prima facie case for prosecution/trial is
made out against Capt. Satish Sharma. It shall have to be decided on the basis of the
material collected and made available with the CBI as a result of the investigation.
We direct the CBI to complete the investigation within three months of the receipt of
this order. The CBI shall file interim report to indicate the compliance of this order.
This shall be done by 20-1-1997 and this matter shall be listed on 22-1-1997 before a
Bench of which Mr. Justice Faizan Uddin is a member."Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

Thereafter the Court proceeded to hear Mr. Harish N. Salve on the question of damages and after
considering certain English decisions on the question of exemplary damages and also the decision of
this Court in Neelabati Behera vs. State of Orissa (1993) 2 SCC 746, in which it was laid down that
the damages can be awarded by this Court in a proceeding under Article 32 of the Constitution, the
Court directed the petitioner to pay a sum of Rs.50 lakhs as exemplary damages to the Govt.
Exchequer, with the observation that since the property with which the petitioner was dealing was
Govt. property, the Govt., which is "By the people", has to be compensated. The Court further
directed the petitioner to deposit the amount with the Secretary, Ministry of Finance, Govt. of India
within nine months. It was further provided that the amount, if not paid, would be recoverable as
arrears of land revenue.
As Minister of State for Petroleum, the petitioner had made allotments from out of his discretionary
quota. The discretionary quota is available to almost all Ministers of the Govt. of India. This
obviously is based on a policy decision to allow discretionary quota not only to the Prime Minister
but also to other Ministers so that serious difficulties, problems of disabilities or unemployment
may be overcome at the earliest by providing immediate help.
The Constitution through its various provisions, including Directive Principles of State Policy has
laid down the basic principles of governance. Socio-economic growth, aid to the poor, upliftment of
the down trodden, the Backward masses and Weaker sections of the society are some of the rules of
governance embodied in the Constitution. The philosophy behind the "discretionary quota"
available to the Prime Minister and other Minister or Members of Parliament appears to be to
provide immediate relief in a case of acute personal hardship.
The list of discretionary quotas available with the Prime Minister and other Ministers has been
placed before us and is set out below:
"DETAILS OF DISCRETIONARY ALLOTMENTS BEING EXERCISED BY VARIOUS
MINISTERS IN GOVERNMENT OF INDIA UNION MINISTERS
1. Prime Minister :
Directives being sent to various Ministries for deserving cases of Discretionary
allotments, for out of turn House/DDA Flat/Shops/Petrol Pump/Gas Agencies/Rly
Station Stalls/Free Air Tickets/out of turn Maruti Car, STD/ISD Booth/Out of Turn
Telephone Connections/Gas Connections etc. PM exercises discretion to sanction
funds from PM's Relief Fund.
2. Minister for Communications Discretionary Allotments of :
1. Telephone connections. 2. Small Telephone Exchanges. 3. ISD/STD Booths.
3. Minister for Civil Aviation & Tourism Discretionary Allotment of :Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

1. Free or Discounted International Air Tickets. 2.
GSAs for AI or Indian Airlines 3. Out of Turn seats in IA/AI flights. 4. Shops/Stalls in ITDC Hotels.
4. Minister for Chemical & Fertilizers Discretionary Allotment of :
1. Agencies of IPCL/Public Sector Drug Units. 2.
Agencies for Fertilizer Public Sector Undertakings.
5. Minister for Coal Discretionary Allotment of :
1. Premium quality coal rakes. 2. PSU Coal Dumps 3.
Premium quality coal in thousand tons.
6. Minister for Defence Discretionary Allotments of :
1. Fire Arms, Rifles & Revolvers. 2. Old Army Vehicles meant for disposal.
7. Ministry of HRD Discretionary Powers of :
1. Admissions in Medical/Engg. Colleges/Central Schools. 2. Scholarships for study
in India & Abroad.
8. Minister for Health & Family Welfare Discretionary Powers of :
1. Treatment of Patients abroad. 2. Private wards in AIIMS/Premier Govt. Hospitals.
3. Admission in Medical Colleges in India/Abroad.
9. Minister for Information & Broadcasting Discretionary Powers of :
1. Selection of DD Serials/other programmes. 2.
Nomination to film censor boards etc.
10. Minister for Industry Discretionary Allotments of :
1. Maruti Cars/other cars
11. Minister for Food & Civil Supplies/Food Processing Discretionary Allotments of :
1. Ration shops. 2. SKO/LDO Agencies. 3.Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

Allotment of FCI wheat/Rice/Sugar to Pvt. Industries. 4. Beer Licences.
12. Minister for Petroleum & Natural Gas Discretionary Allotments of :
1. Gas Connections. 2. Petrol Pumps & Gas Agencies.
13. Minister for Railways Discretionary Allotments of :
1. Kiosks/Stalls at Railway Stations. 2. Free or discounted Railway passes/ Tickets for
1 year or more years.
3. Berths in all trains. 4. Railway Rakes.
14. Minister for Surface Transport Discretionary Powers of :
1. Out of turn Berthing of National & International Ships at all Ports across country.
2. Permits for Buses etc.
15. Minister for Urban Developments Discretionary Allotment of :
1. DDA Flats/Houses. 2. Shops in DDA/NDMC 3. Plots in DDA.
MEMBERS OF PARLIAMENT
1. 100 Gas Connections for Discretionary Allotments.
2. 15 Telephone Connections for Discretionary Allotments."
The above list will show that not only to the Minister of Petroleum, but beginning from the Prime
Minister, down to other Ministers, including Members of Parliament, a discretionary quota has been
made available to them.
So far as the Minister of Petroluem is concerned, the allotments made by the petitioner were
challenged in this Court in Centre for Public Interest Litigation vs. Union of India & Ors. (Writ
Petition (C) No. 886 of 1993, decided on March 31, 1995) [since reported in 1995 Supp.(3) SCC 382],
but the Court did not set aside or quash any of the allotments and instead framed guidelines for the
exercise of discretionary allotment of petroleum products' agencies. These guidelines were settled
with the assistance of the Attorney General who submitted a draft of the proposed guidelnes. After
considering the guidelines, the Court directed as under:
"The following to be inserted in the brochure of guidelines for selection of dealers
through the Oil Selectlon Board:Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

Discretionary Quota A discretionary quota will be earmarked for deserving cases on
genuine compassionate grounds. This quota will be outside the 100 point roster of
marketing plans and outside the purview of the Oil Selection Boards.
Candidates will submit a proper application to the Ministry, giving their complete
bio-data indicating the name of spouse/father, occupation, permanent address,
annual income for the preceding year in respect of self, spouse and parents from all
sources enclosing documentary evidence wherever necessary in support of their
request and an affidavit verifying the given facts.
Discretionary allotment will be made to a candidate only if he is a citizen of India. If
he/she or any of his/her following close relatives (including step relatives) does not
already hold a dealership of petroleum products of any oil company:
(i) spouse (ii) father/mother (iii) brother (iv) son/daughter-in-law."
Then the Court directed as under :
"The above-quoted norms/guidelines etc. shall be followed by the Central
Government in making all such discretionary allotments of retail outlets for
petroleum products, LPG Dealership and SKO Dealership, hereafter. A copy of this
order be provided to every oil company by the Central Government for general
information."
We have not reproduced the general guidelines or general conditions or, for that matter, the
procedure fixed by the Court for allotment of petrol outlets, but have reproduced only that portion
which has been considered necessary by us for disposal of this case as they relate to discretionary
quota.
It is contended that since the allotments made by the petitioner till the filing of the writ petition in
this Court, in spite of a challenge having been raised therein, were not set aside and only guidelines
were settled for future exercise of discretionary quota, tacit stamp of judicial approval shall be
deemed to have been placed on the allotments made by the petitioner and consequently those
allotments could not have been reopened on the principle of constructive res judicata. Normally, we
would have accepted this argument, but in this case we cannot go to that extent. We have already
stated in the beginning that the judgment of the Court, in sofar as it purports to set aside the 15
allotments made by the petitioner, will not be reviewed by us as the review applications filed by the
allottees have already been rejected. We, therefore, cannot entertain any plea which even indirectly
aims at setting aside the judgment under review on that question.
Significantly, it is not even suggested that the guidelines issued by the Court in 1995 Supp. (3) SCC
382 were violated in any subsequent allotment or that allotments were made in excess of the quota
after that judgment.Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

In a case relating to manufacturer's discretionary quota concerning Maruti-800, this Court had to
intervene. The then Attorney General who happened to be none other than Mr. K.Parasaran,
arguing before us as Senior Counsel today, was requested by the Court to provide the draft
guidelines which was done and the guidelines were approved by the Court and the Court fixed the
guidelines for the exercise of manufacturer's five per cent discretionary quota concerning allotment
of `Maruti 800' cars. (See: Ashok K. Mittal vs. Maruti Udyog Ltd.& Anr. (1986) 1 SCR 585). While
conceding discretionary quota to the manufacturers, the Court fixed the guidelines for regulating the
allotments of Maruti cars out of discretionary quota to various customers falling in the category of
Defence Forces, Judiciary, Constitutional Heads, MPs, etc. Mr.Gopal Subramaniam, learned Senior
Counsel, appearing as Amicus Curiae in the case and who, we must record, equally matched the
forensic skill of Mr. K. Parasaran and rendered invaluable assistance to us, contended that it was not
merely a matter of discretionary quota which was the basis of the judgment under review, but the
arbitrary manner, in which the discretion was exercised, which ultimately resulted in the quashing
of all the allotments made by the petitioner who was found to have allotted the petrol pumps not
only to the relatives of his personal staff, but also to the sons of Chairmen of Oil Selection Boards
and even to the members of the Oil Selection Boards and, therefore, the Court had rightly held the
exercise of discretion to be motivated, arbitrary and for extraneous considerations. Since this
question again turns on the merit of the allotments made by the petitioner, we would not look into
it. We have mentioned the philosophy of discretionary quota being made available to the Ministers,
only as a prelude to our decision on the question whether on the facts of this case the petitioner
could be held to have committed the tort of misfeasance in public office. The basis of the finding
recorded in the impugned judgment on this question is the decision of this Court in Lucknow
Development Authority's case (supra) which did not consider even the basic elements which
constitute the tort of misfeasance which we have already discussed above.
The whole proceedings were initiated on the basis of a Press report which was brought to the notice
of the Court by Mr. H.D.Shourie, Director, Common Cause whose Writ Petition was already pending
and it was on that basis in that pending Writ Petition that the Court took cognizance of the matter.
The allotments were made by the petitioner in his capacity as Minister of State for Petroleum and
Natural Gas as and when an application was made by separate and individual persons. There was
none to compete with that person. The individual concerned would approach the petitioner and the
petitioner, perhaps, on being satisfied with the contents of the application, as also the need for a
petrol outlet in the area, make the allotment. Had there been any other applicant for the same petrol
outlet for which an application was made to the Minister, the question that he deliberately made the
allotment in favour of one so as to injure the other person would then have positively arisen. The
petitioner cannot be said to have made the allotment in favour of one out of malice towards the
other as there was none else to contest or compete with the claim of the person who made the
application for allotment. Nor could it be said that the petitioner made the allotment of petrol outlet
in favour of the applicant with the knowledge that such allotment was likely to injure the interest of
any other person.
The petitioner before the Court was "Common Cause". It was a registered Society. It was not one of
the applicants for allotment of petrol outlet. Had the "Common Cause" approached the Civil Court
for damages on account of tort of misfeasance in public office, its suit would have been dismissed onCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

the ground that it was not one of the applicants for a petrol outlet; its own interest was not injured
in any way nor had the petitioner made allotment in favour of one of the applicants maliciously or
with the knowledge that the allotment would ultimately harm the "Common Cause". How could then
a finding of commission of misfeasance in public office by the petitioner be recorded in proceedings
under Article 32 and that too, at the instance of "Common Cause" on the basis of a Press report? Mr.
Gopal Subramaniam contended that "Common Cause" was justified in filing the petition under
Article 32 in Public Interest to expose the wanton way in which allotments were made by the
petitioner. To that extent, Mr.Gopal Subramaniam is right. The Court has already quashed the
fifteen allotments made by the petitioner in view of the arbitrary exercise of power by him. But the
Court went a step further and held that petitioner had committed the Tort of Misfeasance in Public
Office and awarded exemplary damages. It is this aspect which we are examining and it is in this
context that we say that "Common Cause" not being an applicant for allotment of a Petrol outlet
could not have obtained a finding in the Civil Suit that the petitioner had committed the Tort of
Misfeasance in Public Office.
Having regard to the definition of tort of misfeasance in public office as discussed above and having
regard to the ingredients of that tort, it is obvious that there has to be an identifiable plaintiff or
claimant whose interest was damaged by the public officer maliciously or with the knowledge that
the impugned action was likely to injure the interest of that person. It is in favour of that specific
identifiable plaintiff or claimant that the relief could have been granted and damages awarded to
him as the whole gamut of the Law of Tort is compensatory in nature and damages are awarded to
compensate the losses caused on account of violation of the interest of one person by another. In
other words, obtaining compensation for a tortiously inflicted loss is generally perceived as the aim
of the law of tort by the plaintiff. Judgment in favour of the plaintiff can be given and the loss
suffered by him can be redressed only when a finding of a breach of an obligation by the tort-feasor
is recorded. It is the compensatory function of tort which is invoked by the plaintiff in a Court and
unless there is an identifiable plaintiff, there cannot be any order for compensation or damages to
redress the loss caused to that plaintiff.
Mere allotment of Petrol outlets would not constitute "Misfeasance" unless other essential elements
were present. These allotments have already been quashed as having been arbitrarily made and we
appreciate the efforts of "Common Cause" for having caused this exposure. But the matter must end
here.
It cannot be ignored that the allotments made by the petitioner under the discretionary quota were
challenged in this Court but the Court did not interfere with those allotments and instead settled the
guidelines for future allotments. It is not alleged nor has it been found that any allotment was made
in violation of the guidelines. It cannot also be ignored that the petitioner is not alleged to have
intereferred with any allotment made through the Oil Selection Boards or the process of selection
carried out by the Boards.
At this stage, Mr. Gopal Subramaniam drew our attention to the following passage from the
judgment under review :Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

"The orders of the Minister reproduced above read:
"the applicant has no regular income to support herself and her family", "the
applicant is an educated lady and belongs to Scheduled Tribe community", "the
applicant is an uneducated, unemployed Scheduled Tribe youth without regular
source of livelihood", "the applicant is a housewife whose family is facing difficult
financial circumstances" etc. etc. There would be literally millions of people in the
country having these circumstances or worse. There is no justification whatsoever to
pick up these persons except that they happen to have won the favour of the Minister
on mala fide considerations. None of these cases fall within the categories placed
before this Court in Centre for Public Interest Litigation v. Union of India but even if
we assume for argument sake that these cases fall in some of those or similar
guidelines the exercise of discretion was wholly arbitrary. Such a discretionary power
which is capable of being exercised arbitrarily is not permitted by Article 14 of the
Constitution of India. While Article 14 permits a reasonable classification having a
rational nexus to the objective sought to be achieved, it does not permit the power to
pick and choose arbitrarily out of several persons falling in the same category."
and contended that the Court itself had in mind that there were others equally eligible to whom the
Petrol outlets could have been allotted. He specially drew our attention to the portion underlined
above. It is true that there are millions of poor, unemployed, educated or uneducated young men,
who might have deserved preferential treatment, but all of them had not approached the petitioner
nor the petitioner was expected to know all of them personally. If an advertisement were to be
issued and applications were to be invited for allotment of Petrol outlets on the basis of auction, it
would still not have been possible for the millions of poor or unemployed persons to have applied
for allotment or to participate in the bid. Auction is usually held to augment the revenue. Physically
handicapped, poor, unemployed, illiterate youth cannot be expected to participate in the auction
and offer their bids. Moreover, this would be contrary to the concept of discretionary quota, the
main purpose of which is to provide immediate relief to the most needy. Even the guidelines settled
by this Court do not provide for allotment being made by public auction.
In view of the above, the conduct of the petitioner in making allotments of petrol outlets was
atrocious, specially those made in favour of the Members, Oil Selection Board or their son, etc., and
reflects a wanton exercise of power by the petitioner. This Court has already used judicial
vituperatives in respect of such allotments and we need not strain our vocabulary any further in that
regard. Suffice it to say that though the conduct of the petitioner was wholly unjustified, it falls short
of "misfeasance in public office" which is a specific tort and the ingredients of that tort are not
wholly met in the case. That being so, there was no occasion to award exemplary damages.
Since exemplary damages have been awarded, we would, in spite of our finding that the petitioner
had not committed the tort of misfeasance in public office, consider the question relating to
"Exemplary Damages" on its own merit.Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

"Damages", as defined by Mcgregor "are the pecuniary compensation, obtainable by
success in an action, for a wrong which is either a tort or a breach of contract, the
compensation being in the form of a lump sum which is awarded unconditionally."
This definition was adopted by Lord Hailsham L.C. in Broome v. Cassell & Co. (1971)
2 All ER 187. The definition in Halsbury's Laws of England (4th Edition), Volume 12,
Para 1102, is similar to the definition set out above.
The object of an award of damages is to give the plaintiff compensation for damage,
loss or injury he has suffered. The elements of damage recognised by law are divisible
into two main groups : pecuniary and non- pecuniary. While the pecuniary loss is
capable of being arithmetically worked out, the non-pecuniary loss is not so
calculable. Non-pecuniary loss is compensated in terms of money, not as a substitute
or replacement for other money, but as a substitute, what Mcgregor says, is generally
more important than money: it is the best that a court can do. In Re: The Medianna
(1900) A.C. 1300, Lord Halsbury L.C. observed as under:
"How is anybody to measure pain and suffering in moneys counted? Nobody can
suggest that you can by arithmetical calculation establish what is the exact sum of
money which would represent such a thing as the pain and suffering which a person
has undergone by reason of an accident...But nevertheless the law recognises that as
a topic upon which damages may be given."
This principle was applied in Fletcher v. Autocar and Transporters (1968) 2 Q.B. 322 and Parry v.
Cleaner (1970) A.C. 1.
In a suit for damages under the Law of Tort, the court awards pecuniary compensation after it is
proved that the defendant committed a wrongful act. In such cases, the court usually has to decide
three questions:-
1. Was the damage alleged caused by the defendant's wrongful act? 2. Was it remote?
3. What is the monetary compensation for the damage?
These elements imply that there has to be always a plaintiff who had suffered loss on account of
wrongful act of the defendant. If the damage caused to the plaintiff is directly referable to the
wrongful act of the defendant, the plaintiff becomes entitled to damages. How the damages would be
calculated, what factors would be taken into consideration and what arithmetical process would be
adopted would depend upon the facts and circumstances of each case.
Now, the damages which can be awarded in an action based on Tort may be Contemptuous,
Nominal, Ordinary or, for that matter, Exemplary. In the instant case, we are concerned with the
"Exemplary Damages" awarded by this Court by Judgment under review.
As pointed out earlier, the primary object of award of damages is to compensate the plaintiff for the
harm done to him, while the secondary object is to punish the defendant for his conduct in inflictingCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

the harm. The secondary object can also be achieved in awarding, in addition to normal
compensatory damages, damages which are variously called as exemplary damages, punitive
damages, vindictive damages or retributory damages. They are awarded whenever the defendant's
conduct is found to be sufficiently outrageous to merit punishment, for example, where the conduct
discloses malice, cruelty, insolence or the like.
It will thus be seen that in awarding punitive or exemplary damages, the emphasis is not on the
plaintiff and the injury caused to him, but on the defendant and his conduct.
Exemplary Damages made their appearance on the English legal scene in 1760s when in two cases,
namely Huckle vs. Money and John Wilkes vs. Wood, (1763) 2 Wils. KB 205 and (1763) Lofft 1
respectively, exemplary damages were awarded. These cases were followed by two other cases,
namely, Benson v. Fredrick (1766) 3 Burr. 1845 relating to the tort of assault and Tullidge vs. Wade
(1769) 3 Wils. KB 18 relating to the tort of seduction, and in both the cases, exemplary damages
were allowed. Exemplary damages, therefore, became a familiar feature of the Law of Tort and were
even awarded in cases relating to trespass to land and trespass to goods.
The whole legal position was reviewed in Rookes v. Barnard (1964) AC 1129 and the House of Lords
laid down that except in few exceptional cases, it would not be permissible to award exemplary
damages against the defendant howsoever outrageous his conduct might be. The question of
damages was thoroughly canvassed in the judgment of Lord Devlin and after tracing the history of
such awards of exemplary damages from their origin in 1763, he observed :
"These authorities convince me of two things. First, that your lordships could not
without a complete disregard of precedent, and indeed of statute, now arrive at a
determination that refused altogether to recognise the exemplary principle. Secondly,
that there are certain categories of cases in which an award of exemplary damages
can serve a useful purpose in vindicating the strength of the law, and thus affording a
practical justification for admitting into the civil law a principle which ought logically
to belong to the criminal.....I am well aware that what I am about to say will, if
accepted, impose limits not hitherto expressed on such awards and that there is
powerful, though not compelling authority for allowing them a wider range."
Lord Devlin then set out the categories in which, in his view, exemplary damages could be awarded,
as under :
"(1) where there has been oppressive, arbitrary or unconstitutional action by the
servants of the government;
(2) where the defendant's conduct has been calculated by him to make a profit which
may well exceed the compensation payable to the plaintiff; and (3) where such
damages are expressly authorised by statute."Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

The principles laid down in Rookes v. Barnard (supra) were followed in five other cases in England
out of which four were libel actions, including McCarey v. Associated Newspapers Limited (1965) 2
QB 86 = (1964) 3 All ER 947 and Broadway Approvals Limited v. Odhams Press Limited (1965) 2 All
ER 523.
In 1971, came the decision in Broome v. Cassell & Co. Ltd. (1971) 2 All ER 187. The facts of the case
may be briefly stated :
"(a) John Egerton Broome was a commander in the Royal Navy. In July 1942 he was
in command of the naval escort for a merchant convoy of war materials en route to
the Soviet Union. Acting on orders received from the Admiralty, which had
mistakenly formed the impression that the convoy was about to be attacked, Broome
directed the ships to scatter in every direction. The result was calamitious.
Left unprotected from attack, large numbers of ships and men and vast quantities of material were
lost. Broome's action was vindicated; the error was the Admiralty's not his. Many persons wrote
about the catastrophe, including Sir Winston Churchill and the war's official historian, but none
faulted Broome for it until Cassell & Co. Ltd. published "The Destruction of P.Q. 17".
(b) The book, advertised as "the true story of biggest- ever Russian convoy that the Royal Navy left
to annihilation", blamed Broome for the disaster, accusing him of disobeying orders and deserting
the convoy. The book had earlier been rejected by its author's regular publisher, who had said :
'As written, the book is a continuous witch hunt of the plaintiff, filled with
exaggerated criticisms of what he did or did not do... We could not possibly publish
the book as it is unless you took out insurance against any writs for libel, and I don't
think that any insurance company would underwrite you.' The author then submitted
the book for publication to Cassell & Co. Ltd., which praised the book for its "very
robust view of libel dangers". Cassell thought that the amount of profit which he
would earn by publishing the book would far exceed the amount of damages which he
would be required to pay in an action for libel. As anticipated, action for libel was
instituted against Cassell & Company. At the trial, neither the author nor the
publisher gave evidence. Every witness who was called supported the plaintiff. The
jury awarded compensatory damages of Pound 1,000 in respect of the proof copies
and Pound 14,000 in respect of the hardback edition, and exemplary damages of
Pound 25,000.
The defendants appealed. In dismissing the appeal, the Court of Appeal considered
the judgment in Rookes v. Barnard and speaking through Lord Denning, M.R. said
that Lord Devlin, 'threw over all that we ever knew about exemplary damages. He
knocked down the common law as it had existed for centuries. He laid down a new
doctrine about exemplary damages.' Lord Denning pointed out that, although Rookes
v. Barnard had been followed in England, it had not been acepted in Australia,
Canada or New Zealand and the day had arrived when it should no longer be followedCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

in England:
'This wholesale condemnation justifies us. I think, in examining this new doctrine for
ourselves: and I make so bold as to say that it should not be followed any longer in
this country.' He gave four reasons :
(a) the common law on the subject had been so well settled before 1964 that it was
not open to the House of Lords to overthrow it;
(b) counsel who had appeared in Rookes v. Barnard had not argued the point, and
indeed had accepted the common law as it was then understood;
(c) contrary to what Lord Devlin had said, there were two previous decisions of the
House of Lords approving awards of exemplary damages; and
(d) the doctrine laid down by Rookes v. Barnard was "hopelessly illogical and
inconsistent". .lm10 Lord Denning further observed:-
"All this leads me to the conclusion that, if ever there was a decision of the House of
Lords given per incuriam, this was it. The explanation is that the House, as a matter
of legal theory, thought that exemplary damages had no place in the civil code, and
ought to be eliminated from it; but, as they could not be eliminated altogether, they
ought to be confined within the strictest possible limits, no matter how illogical those
limits were..... I think the difficulties presented by Rookes v. Barnard are so great the
judges should direct the juries in accordance with the law as it was understood before
Rookes v. Barnard. Any attempt to follow Rookes v. Barnard is bound to lead to
confusion."
Matter went up in appeal before the House of Lords. (Cassell & Co. Ltd. vs. Broome & Anr. (1972) 1
All ER 801 = 1972 A.C. 1027 ). Lord Hailsham L.C. did not agree with the Court of Appeal and held
that Rookes vs. Barnard (supra) was correctly decided. All the observations of Lord Denning
including that Rookes v. Barnard was decided per incuriam were diluted, rather overruled.
It is in this background that category (2) set out by Lord Devlin was specified. Cassell & Company
had published the book in spite of the knowledge that an action for libel was likely to be instituted
against them. They were fully conscious that damages were likely to be awarded against them for
publishing that book. But they published the book as they thought that the book would bring them
much more money than what they would be required to pay as damages. If it is with this motive that
a tort is purposely committed, it would be a fit case for award of exemplary damages.
In spite of this decision, the controversy whether punitive or exemplary damages should be allowed,
still rages almost internationally and remains unresolved. It continues to be debated even in
England, whether Exemplary Damages should be allowed in the pre-Rookes v. Barnard manner or
only in those exceptional cases which have been indicated in Rookes v. Barnard.Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

In an action for tort where the plaintiff is found entitled to damages, the matter should not be
stretched too far to punish the defendant by awarding exemplary damages except when their
conduct, specially those of the Govt. and its officers, is found to be oppressive, obnoxious and
arbitrary and is, sometimes, coupled with malice. While dealing with this category, namely, the
Govt. officers, it was observed in Rookes v. Barnard (supra):
".....where one man is more powerful than another, it is inevitable that he will try to
use his power to gain his ends; and if his power is much greater than the other's, he
might, perhaps, be said to be using it oppressively. If he uses his power illegally, he
must of course pay for his illegality in the ordinary way; but he is not to be punished
simply because he is the more powerful. In the case of the government it is different,
for the servants of the government are also the servants of the people and the use of
their power must always be subordinate to their duty of service."
If we were to apply the rule in Rookes v. Barnard as upheld in Cassell & Co. Ltd. vs. Broome (supra)
invariably and unhesitatingly and were to award exemplary damages in every case involving Govt.
officers or Govt. servants, the result would be appalling.
Executive, under the Constitution, consists of Prime Minister, Cabinet Ministers, Ministers of State
and Civil Services comprising of high administrative officers on the top down to the clerical level.
They have as important a role to play in the governance of the country as the Judiciary or
Legislature. The Executive, in running the administration of the country, should not be cowed down
and should be allowed to have full confidence in its own existence so that its decision-making
process is not, in any way, affected. They must feel independent and keep themselves in an excellent
frame of mind so that the administrative files are cleared in time and the Officers dealing with those
files are not hesitant even in taking bold decisions which have sometimes to be taken in the interest
of administration. It is true that the fear of being proceeded against in a court of law for tort of
misfeasance in public office may keep them on the right path and they may not falter, but there is
already the fear of departmental action or proceedings being initiated against them departmentally
which itself is a safeguard for proper administration. Departmentally, they are answerable for their
lapses; Ministers, or, for that matter, even the Government is answerable to Parliament. If they were
constantly under the fear or threat of being proceeded against in a court of law for even slightest of
lapse or under constant fear of exemplary damages being awarded against them, they will develop a
defensive attitude which would not be in the interest of administration.
In Yuen Kun Yev & Ors. v. Attorney General of Hong Kong (1987) 2 All ER 705, Lord Keith observed
as under :
"...the prospect of claims would have a seriously inhibiting effect on the work of his
department. A sound judgment would be less likely to be exercised if the
Commissioner were to be constantly looking over his shoulder at the prospect of
claims against him, and his activities would be likely to be conducted in a
detrimentally defensive frame of mind.. Consciousness of potential liability could
lead to distortions of judgment....".Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

If the power has been exercised bona fide and honestly, there cannot be any occasion for exemplary
damages being awarded notwithstanding that unintended injury was caused to someone. These, as
also a few other elements, which we shall presently discuss, have to be kept in mind before awarding
exemplary damages.
Mr. Parasaran next made his submission on the quantum of damages and contended that the
amount of Rs.50 lakhs has been fixed in an arbitrary manner without there being any rational basis
for arriving at that figure. It is contended that the only reason given by the Court was that "all the
facts and circumstances of the case have been examined." The observation of this Court in this
regard may be reproduced :
"After examining all the facts and circumstances of this case and giving thoughtful
consideration to this aspect, we direct Capt. Satish Sharma to pay a sum of Rs.50
lakhs as exemplary damages to the Government Exchequer. Since the property with
which Capt. Sharma was dealing was public property, the Government which is "by
the people" has to be compensated. We further direct Capt. Sharma to deposit the
amount with the Secretary, Ministry of Finance, Government of India within nine
months from today. The amount if not paid, shall be recoverable as arrears of land
revenue."
It is contended by Mr. Parasaran that the above reasons are not enough for awarding punitive
damages in the sum of Rs.50 lakhs against the petitioner. He contended that the proceedings in
which this order has been passed were proceedings under Article 32 of the Constitution and not a
suit for recovery of damages under law of Tort and, therefore, an order for exemplary damages
should not have been passed.
Right to access to this Court under Article 32 of the Constitution is a fundamental right. The Court
has been given the power to issue directions or orders or writs, including writs in the nature of
habeas corpus, mandamus, prohibition, quo-warranto and certiorari, whichever may be
appropriate, for the enforcement of the fundamental rights. Obviously, the fundamental rights
would be enforced against the Govt. or its executive or administrative officers or other public bodies.
It is in the matter of enforcement of fundamental rights that the Court has the right to award
damages to compensate the loss caused to a person on account of violation of his fundamental
rights. The decisions in which orders have been passed by this Court for damages under Article 32 of
the Constitution for violation of fundamental right coupled with, in some cases, tortious liability,
have already been specified above. The State itself cannot claim the right of being compensated in
damages against its officers on the ground that they had contravened or violated the fundamental
rights of a citizen.
Petitioner, as Minister of State for Petroleum and Natural Gas, was part of the Central Govt. By
directing petitioner to pay a sum of Rs.50 lakhs to the Govt., the Court has awarded damages in
favour of the Govt. of India in proceedings under Article 32 of the Constitution which is not
permissible as the Court cannot direct the Govt. to pay the exemplary damages to itself. Mr.Gopal
Subramaniam asserted that it was a direction made to the petitioner personally and the Court hadCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

treated him as a separate and distinct entity than the Govt. He contended that since tort is a
wrongful act, it cannot be treated as an act of the State and has always to be treated as referring to
the person who has committed it and, therefore, the petitioner could be rightly directed by the Court
to pay Rs.50 lakhs as exemplary damages.
This cannot be accepted. The whole thing has to be examined in the context of Article 32 of the
Constitution under which relief to a person or citizen can be granted only against Union of India or
the State or their Instrumentalities but the State cannot legally claim that since one of its Ministers
or Officers had violated the fundamental rights of a citizen or had acted arbitrarily, it should be
compensated by awarding exemplary damages against that officer or Minister.
In Rookes v. Barnard (supra), it was pointed out by Lord Devlin that a plaintiff cannot recover
exemplary damages unless he is the victim of punishable behaviour. We have already pointed out
that in the instant case, there was no plaintiff. The petitioner, Common Cause, cannot be said to be a
plaintiff nor can it claim to have suffered any damage or loss on account of the conduct of the
petitioner.
Lord Devlin further pointed out that award of exemplary damages should be moderate. Some of the
awards that the jury had made in the past, seemed to him, to amount to a greater punishment than
the punishment which was likely to be incurred if the conduct were criminal. It would be a
punishment imposed without the safeguard which the criminal law gives to an offender. Lord Devlin
had a third consideration also in mind which related to the means of the party. Obviously, a small
exemplary award would go unnoticed by a rich defendant, while even a moderate award might
cripple a poor defendant. The conduct of the parties throughout the proceedings would also be a
relevant consideration in assessing exemplary damages.
In our opinion, these elements or considerations are extremely relevant in determining the amount
of exemplary damages but, unfortunately, none of these factors has been taken into consideration
and after recording a finding that the conduct of the petitioner was oppressive and that he had made
allotments in favour of various persons for extraneous considerations, the Court awarded an amount
of Rs.50 lakhs as punitive damages. How did the Court arrive at this figure is not clear. Why it could
not Forty nine lacs fifty thousand?
Let us now examine the direction for investigation by the C.B.I. into the offence of "criminal breach
of trust"
or "any other offence."
This direction obviously consists of two parts : (a) Investigation by the C.B.I. into the offence of
criminal breach of trust; and (b) Investigation by the C.B.I. into any other offence. We will take up
the first part first.
The basis for the direction relating to investigation into the offence of "criminal breach of trust" are
the following observations of the Court :Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

(a) "A Minister who is the executive head of the department concerned distributes
these benefits and largesses. He is elected by the people and is elevated to a position
where he holds a trust on behalf of the people. He has to deal with the people's
property in a fair and just manner. He cannot commit breach of the trust reposed in
him by the people.
(b) The allotments have been made in a cloistered manner. The petrol pumps --
public property -- have been doled out in a wholly arbitrary manner."
These observations indicate that the Court was of the opinion that a person on being elected by the
people and on becoming a Minister holds a sacred trust on behalf of the people. This, we may
venture to say, is a philosophical concept and reflects the image of virtue in its highest conceivable
perfection. This philosophy cannot be employed for determination of the offence of "criminal breach
of trust" which is defined in the Indian Penal Code. Whether the offence of "criminal breach of trust"
has been committed by a person has to be determined strictly on the basis of the definition of that
offence set out in the Penal Code to which we would advert a little later.
The Court also appears to have invoked the 'Doctrine of Public Trust' which is a doctrine of
environmental law under which the natural resources such as air, water, forest, lakes, rivers and
wild life are public properties "entrusted" to the Government for their safe and proper use and
proper protection. Public Trust Law recognises that some types of natural resources are held in trust
by the Government for the benefit of the public. The 'Doctrine of Public Trust' has been evolved so
as to prevent unfair dealing with or dissipation of all natural resources. This Doctrine is an ancient
and somewhat obscure creation of Roman and British law which has been discovered recently by
environmental lawyers in search of a theory broadly applicable to environmental litigation.
This doctrine was considered by this Court in its judgment in M.C. Mehta vs. Kamal Nath (1997) 1
SCC 388 to which one of us (S.Saghir Ahmad, J.) was a party. Justice Kuldip Singh, who authored
the erudite judgment and has also otherwise contributed immensely to the development of
environmental law, relying upon ancient Roman "Doctrine of Public Trust", as also the work of
Joseph L. Sax, Professor of Law, University of Michigan and other foreign decisions, wrote out that
all natural resources are held in 'trust' by the Govt. The Doctrine enjoins upon the Govt. to protect
the resources for the enjoyment of the general public rather than to permit their use for private
ownership or commercial purposes. But this Doctrine cannot be invoked in fixing the criminal
liability and the whole matter will have to be decided on the principles of criminal jurisprudence,
one of which is that the criminal liability has to be strictly construed and offence can be said to have
been committed only when all the ingredients of that offence as defined in the Statute are found to
have been satisfied.
The matter may be examined from another angle.
Election to the State Legislature or the House of the People are held under the Constitution on the
basis of adult suffrage. On being elected as a Member of the Parliament, the petitioner was inducted
as Minister of State. The Department of Petroleum and Natural Gas was allocated to him. Under theCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

allocation of business rules, made by the President of India, the distribution of petroleum products,
inter alia, came to be allocated to the petitioner. This allocation of business under the Constitution is
done for smooth and better administration and for more convenient transaction of business of
Government of India. In this way, neither a "trust", as ordinarily understood or as defined under the
Trust Act, was created in favour of the petitioner nor did he become a "trustee" in that sense.
In Tito vs. Waddell (No.2), 1977 (3) All ER 129, the question of Crown's status as a trustee was
considered and it was laid down:-
"I propose to turn at once to the position of the Crown as trustee, leaving on one side
any question of what is meant by the Crown for this purpose; and I must also
consider what is meant by `trust'. The word is in common use in the English
language, and whatever may be the position in this court, it must be recognised that
the word is often used in a sense different from that of an equitable obligation
enforceable as such by the courts. Many a man may be in a position of trust without
being a trustee in the equitable sense; and terms such as `brains trust', `anti-trust',
and `trust territories', though commonly used, are not understood as relating to a
trust as enforced in a court of equity. At the same time, it can hardly be disputed that
a trust may be created without using the word `trust'. In every case, one has to look
to see whether in the circumstances of the case, and on the true construction of what
was said and written, a sufficient intention to create a true trust has been manifested.
When it is alleged that the Crown is a trustee, an element which is of special
importance consists of the governmental powers and obligations of the Crown; for
these readily provide an explanation which is an alternative to a trust. If money or
other property is vested in the Crown and is used for the benefit of others, one
explantion can be that the Crown holds on a true trust for those others. Another
explantion can be that, without holding the property on a true trust, the Crown is
nevertheless administering that property in the exercise of the Crown's governmental
functions. This latter possible explanation, which does not exist in the case of an
ordinary individual, makes it necessary to scrutinise with greater care the words and
circumstances which are alleged to impose a trust."
Many earlier decisions were relied upon and with reference to an earlier decision reported in (1880)
15 Ch D 1, it was observed as under:-.lm15 "In the Court of Appeal, this decision was unanimously
reversed. The court held that no trust, `in the sense of a trust enforceable and cognizable in a Court
of Law', has been created, despite the use of the word `trust' in the royal warrant: see per James LJ.
Furthermore, the Secretary of State for India in Council, though by statute made capable of suing
and being sued in that name, had not been made a body corporate. All that had been done had been
to provide that the Secretary of State for the time being should be the agent of the Crown for the
distribution of the property. James LJ regarded the consequences of holding that there was a trust
enforceable in the courts as `so monstrous that persons would probably be startled at the idea'. He
referred to matters such as the right of every beneficiary to sue for the administration of the trust
and have the accounts taken, and `imposing upon the officer of State all the obligations which inCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

this country are imposed upon a person who chooses to accept a trust'. He also emphasised the
words at the end of the Royal Warrant as showing clearly that questions were to be determined, not
by the courts, but by the Secretary of State, with an ultimate appeal to the Treasury, as advising the
Queen. Baggallay and Bramwell LJJ delivered concurring judgments, with the latter emphasising
the `monstrous inconvenience' and `enormous expense of litigation' if there were a trust
enforceable by the courts, so that `one should be reluctant, even if the words were much stronger
than they are, to hold that there is a trust'.
The House of Lords [(1882) 7 App Cas 619] unanimously affirmed the Court of Appeal. In the
leading speech, Lord Selborne LC attahced some weight to the words in the Royal Warrant being
`the Secretary of State for India in Council', and `for the time being', instead of his being described
by his personal name, as indicating that he was not intended to be a trustee in the ordinary sense,
but was intended to act as a high officer of State. After discussing the Order in council, Lord
Selbourne LC quoted the part of the Royal Warrant which contained the words `in trust for the use
of', and said:
`Now the words "in trust for" are quite consistent with, and indeed are the proper
manner of expressing, every species of trust-a trust not only as regards those matters
which are the proper subjects for an equitable jurisdiction to administer, but as
respects higher matters, such as might take place between the Crown and public
officers discharging, under the directions of the Crown, duties or functions belonging
to the prerogative and to the authority of the Crown. In the lower sense they are
matters within the jurisdiction of, and to be administered by, the ordinary Courts of
Equiry; in the higher sense they are not. What their sense is here, is the question to
be determined, looking at the whole instrument and at its nature and effect."
Applying the principles laid down above, the petitioner does not, on becoming the
Minister of State for Petroleum and Natural Gas, assume the role of a "trustee" in the
real sense nor does a "trust" come into existence in respect of the Government
properties.
This brings us to the definition of the offence of "Criminal Breach of Trust" as defined
in Section 405 of the Indian Penal Code which, minus the Explanation, provides as
under:
"405. Criminal breach of trust.
Whoever, being in any manner entrusted with property, or with any dominion over
property, dishonestly misappropriates or converts to his own use that property, or
dishonestly uses or disposes of that property in violation of any direction of law
prescribing the mode in which such trust is to be discharged, or of any legal contract,
express or implied, which he has made touching the discharge of such trust, or
wilfully suffers any other person so to do, commits 'criminal breach of trust'."Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

A trust contemplated by Section 405 would arise only when there is an entrustment of property or
dominion over property. There has, therefore, to be a property belonging to someone which is
entrusted to the person accused of the offence under Section 405. The entrustment of property
creates a trust which is only an obligation annexed to the ownership of the property and arises out of
a confidence reposed and accepted by the owner. This is what has been laid in The State of Gujarat
v. Jaswant Lal Nathalal AIR 1968 SC 700. In Rashmi Kumar vs. Mahesh Kumar Bhada (1997) 2 SCC
397, the essential ingredients for establishing the offence of criminal breach of trust, as defined in
Section 405, have been spelt out as follows:
"(i) entrusting any person with property or with any dominion over property;
(ii) the person entrusted dishonestly misappropriating or converting to his own use
that property; or dishonestly using or disposing of that property or wilfully suffering
any other person so to do in violation of any direction of law prescribing the mode in
which such trust is to be discharged, or of any legal contract made touching the
discharge of such trust."
In this case, the earlier decision in Pratibha Rani vs. Suraj Kumar (1985) 2 SCC 370 was affirmed.
The case essentially related to the entrustment of `Stridhan', but nevertheless, it is important, in the
sense that the ingredients of the offence are set out and discussed. In Chellor Mankkal Narayan
Ittiravi Nambudiri vs. State of Travancore-Cochin AIR 1953 SC 478 = 1954 Crl.LJ 102, it was laid
down that every breach of trust in the absence of mens rea or dishonest intention cannot legally
justify a criminal prosecution.
The expressions "entrusted with property" and "with any dominion over property" used in Section
405 came to be considered by this Court in C.B.I. vs. Duncans Agro Industries Ltd., Calcutta (1996)
5 SCC 591 = AIR 1996 SC 2452 and the view earlier expressed was reiterated. It was held that the
expression "entrusted" has wide and different implication in different contexts and the expression
"trust" has been used to denote various kinds of relationships like trustee and beneficiary, bailor and
bailee, master and servant, pledger and pledgee.
Mr. K. Parasaran contended that "power to allot petrol pumps", and that too under discretionary
quota, cannot be treated as "property" within the meaning of Section 405 of the Indian Penal Code.
It is pointed out by him that the Minister merely makes an order of allotment. Subsequently, the
Indian Oil Corporation or the Bharat Petroleum Corporation enters into a dealership agreement
with that person and the business is regulated by the agreement between the allottee and the
Corporation (Indian Oil Corporation or Bharat Petroleum Corporation). It is also pointed out that in
pursuance of the agreement, the allottee invests money, constructs the building and sets up the
petrol pump. Mere exercise of "power to allot", it is rightly contended, cannot, therefore, be treated
as "property", within the meaning of Section 405, capable of being mis-utilised or mis-appropriated.
The word "property", used in Section 409, IPC means the property which can be entrusted or over
which dominion may be exercised. This Court in R.K. Dalmia vs. Delhi Administration, 1963 (1) SCR
253 = AIR 1962 SC 1821, held that the word "property", used in Section 405 IPC, has to beCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

interpreted in wider sense as it is not restricted by any qualification under Section 405. It was held
that whether an offence defined in that Section could be said to have been committed would depend
not on the interpretation of the word "property" but on the fact whether that particular kind of
property could be subject to the acts covered by that Section. That is to say, the word "property"
would cover that kind of property with respect to which the offence contemplated in that Section
could be committed.
Having regard to the facts of the case discussed above and the ingredients of the offence constituting
criminal breach of trust, as defined in Section 405, or the offence as set out in Section 409 IPC, we
are of the opinion that there was no case made out against the petitioner for any case being
registered against him on the basis of the Judgment passed by this Court nor was there any occasion
to direct an investigation by the CBI in that case.
The other direction, namely, the direction to the C.B.I. to investigate "any other offence" is wholly
erroneous and cannot be sustained. Obviously, direction for investigation can be given only if an
offence is, prima facie, found to have been committed or a person's involvement is prima facie
established, but a direction to the C.B.I. to investigate whether any person has committed an offence
or not cannot be legally given. Such a direction would be contrary to the concept and philosophy of
"LIFE" and "LIBERTY" guaranteed to a person under Article 21 of the Constitution. This direction is
in complete negation of various decisions of this Court in which the concept of "LIFE" has been
explained in a manner which has infused "LIFE" into the letters of Article 21.
"Right to Life", set out in Article 21, means something more than mere survival or
animal existence. (See: State of Maharashtra vs. Chandrabhan Tale, AIR 1983 SC 803
= (1983) 3 SCC 387 = 1983 (3) SCR 327). This Right also includes the right to live
with human dignity and all that goes along with it, namely, the bare necessities of life
such as adequate nutrition, clothing and shelter over the head and facilities for
reading, writing and expressing oneself in differ forms, freely moving about and
mixing and commingling with fellow human beings. [See: Francis Coralie Mullin vs.
Administrator Union Territory of Delhi, AIR 1981 SC 746 = (1981) 1 SCC 608 = 1981
(2) SCR 516; Olga Tellis & Ors. vs. Bombay Municipal Corporation & Ors., AIR 1986
SC 180 (paras 33 and 34) = (1985) 3 SCC 545 = 1985 Supp. (2) SCR 51; Delhi
Transport Corporation vs. D.T.C. Mazdoor Congress & Ors., AIR 1991 SC 101 (paras
223, 234 and
259) = (1991) Supp. 1 SCC 600 = 1990 Supp. (1) SCR 142]. In Kharak Singh vs. State
of U.P., AIR 1963 SC 1295 = 1964 (1) SCR 332, domiciliary visit by the Police was held
to be violative of Article 21.
A man has, therefore, to be left alone to enjoy "LIFE" without fetters. He cannot be hounded out by
the Police or C.B.I. merely to find out whether he has committed any offence or is living as a
law-abiding citizen. Even under Article 142 of the Constitution, such a direction cannot be issued.
While passing an order under Article 142 of the Constitution, this Court cannot ignore the
substantive provision of law much less the constitutional rights available to a person. (See : SupremeCommon Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

Court Bar Association vs. Union of India & Ors. (1998) 4 SCC 409 = AIR 1998 SC 1895).
Mr. Gopal Subramaniam contended that the Court has itself taken care to say that the C.B.I. in the
matter of investigation, would not be influenced by any observation made in the Judgment and that
it would independently hold the investigation into the offence of criminal breach of trust or any
other offence. To this, there is a vehement reply from Mr. Parasaran and we think he is right. It is
contended by him that this Court having recorded a finding that the petitioner on being appointed
as a Minister in the Central Cabinet, held a trust on behalf of the people and further that he cannot
be permitted to commit breach of the trust reposed in him by the people and still further that the
petitioner had deliberately acted in a wholly arbitrary and unjust manner and that the allotments
made by him were wholly mala fide and for extraneous consideration, the direction to the CBI not to
be influenced by any observations made by this Court in the Judgment, is in the nature of palliative.
The CBI has been directed to register a case against the petitioner in respect of the allegations dealt
with and findings reached by this Court in the Judgment under review. Once the findings are
directed to be treated as part of the First Information Report, the further direction that the CBI shall
not be influenced by any observations made by this Court or the findings recorded by it, is mere
lullaby.
We may say that we maintain the rule of accountability and liability of the Executive including
public servants in administrative matters and confirm that there should be transparency in all what
they do, specially where grant of largesse is concerned. But, the present case is being decided on its
own peculiar facts and features in which, the finding as to the commission of tort of misfeasance
recorded by this Court or the award of exemplary damages as also direction for investigation by the
C.B.I., cannot be sustained on account of errors apparent on the face of the record.
We may also point out that the powers of this Court under Article 32 and that of the High Court
under Article 226 are plenary powers and are not fettered by any legal constraints. If the Court, in
exercise of these powers has itself committed a mistake, it has the plenary power to correct its own
mistake as pointed out by this Court in S. Nagaraja & Ors. vs. State of Karnataka & Anr. 1993 Supp.
(4) SCC 595, in which it was observed as under :
"Justice is a virtue which transcends all barriers. Neither the rules of procedure nor
technicalities of law can stand in its way. The order of the Court should not be
prejudicial to anyone. Rule of stare decisis is adhered for consistency but it is not as
inflexible in Administrative Law as in Public Law. Even the law bends before justice.
Entire concept of writ jurisdiction exercised by the higher courts is founded on equity
and fairness. If the Court finds that the order was passed under a mistake and it
would not have exercised the jurisdiction but for the erroneous assumption which in
fact did not exist and its perpetration shall result in miscarriage of justice then it
cannot on any principle be precluded from rectifying the error. Mistake is accepted as
valid reason to recall an order."
The Court also observed:Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

"Review literally and even judicially means re-examination or re-consideration. Basic
philosophy inherent in it is the universal acceptance of human fallibility. Yet in the
realm of law the courts and even the statutes lean strongly in favour of finality of
decision legally and properly made. Exceptions both statutorily and judicially have
been carved out to correct accidental mistakes or miscarriage of justice. Even when
there was no statutory provision and no rules were framed by the highest court
indicating the circumstances in which it could rectify its order the courts culled out
such power to avoid abuse of process or miscarriage of justice."
The Court further observed :
"Rectification of an order thus stems from the fundamental principle that justice is
above all. It is exercised to remove the error and not for disturbing finality."
We have already held above that in the judgment under review, there are errors apparent on the face
of the record, which has resulted in serious miscarriage of justice. It is for this reason only that we
have proceeded to exercise the power of review.
For the reasons stated above, the application for Review is allowed. The direction for payment of
Rs.50 lakhs as exemplary damages as also the direction for a case being registered by the C.B.I.
against the petitioner for Criminal Breach of Trust and investigation by them into that offence and
the further direction to investigate whether petitioner has committed any other offence are recalled.
The amount of Rs.50 lakhs, if paid or deposited by the petitioner with the Union of India, shall be
refunded to him. All applications for impleadment or intervention filed on behalf of allottees are
rejected.Common Cause, A Registered Society vs Union Of India & Ors on 3 August, 1999

