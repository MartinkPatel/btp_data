Assistant G.M. State Bank Of India & Ors vs Radhey Shyam
Pandey on 26 February, 2015
Author: Dipak Misra
Bench: Dipak Misra, V. Gopala Gowda
                                    IN THE SUPREME COURT OF INDIA
                        CIVIL APPELLATE JURISDICTION
                        CIVIL APPEAL NO.2463 OF 2015
              [Arising out of S.L.P. (Civil) No. 3686 OF 2007]
Assistant General Manager, State Bank of
India & Others                                     ... Appellants
                                   Versus
Radhey Shyam Pandey                           ... Respondent
                                    WITH
                     CIVIL APPEAL NOS. 2287-2288 OF 2010
                     CIVIL APPEAL NOS. 5035-5037 OF 2012
                       CIVIL APPEAL NO. 10813 OF 2013
                               J U D G M E N T
Dipak Misra, J.
Leave granted in S.L.P. (Civil) No. 3686 of 2007.
Having regard to the commonality of controversy in this batch of appeals it was heard together and
is disposed of by a singular judgment. For the sake of clarity and convenience, I shall adumbrate the
facts from Civil Appeal Nos. 2287-2288 of 2010 and at the appropriate stage refer to the views
expressed in other appeals. The 1st respondent, M.P. Hallan, an ex- serviceman joined as a clerk on
18.5.1981 in the appellant-Bank which has been constituted under the State Bank of India Act, 1955
(for brevity 'the Act'). The Indian Banks Association (I.B.A.), after obtaining approval from the
Government of India evolved a Voluntary Retirement Scheme (V.R.S.) and the appellant-Bank
adopted the Scheme with certain modifications, despite it having its own Voluntary Retirement
Scheme in the existing service conditions meant for its employees to seek voluntary
retirement/premature retirement/resignation. The Scheme, namely, S.B.I. Voluntary Retirement
Scheme (for short 'the Scheme') was adopted by the State Bank of India on 29.12.2000. The Scheme
was to remain open during the period 15.1.2001 to 31.1.2001 with the option either to close it earlyAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

or extend the period, without assigning any reason.
After adoption of the Scheme, the Deputy Managing Director, the competent authority, issued a
Circular No. HRD/CDO/ VRS/1 on 29.12.2000 clarifying certain aspects of the Scheme. Another
Circular being No. HRD/CDO/VRS/5 was issued on 10.1.2001. On 11.01.2001, the said Circular was
brought to the notice of all the Branches/offices of all the Circles, including Chandigarh Circle.
As per the Scheme, the applications for voluntary retirement under the Scheme were to be
submitted during the period i.e. 15.1.2001 to 31.1.2001. The 1st respondent submitted his
application seeking voluntary retirement and it was accepted on 17.3.2001 with effect from
31.3.2001. On 27.3.2001, the respondent No. 1 submitted an application to withdraw his request for
voluntary retirement. The said application was declined by the Bank on 18.4.2001 stating that the
date for withdrawal of application had already expired on 15.2.2001. It is apt to note that here the
respondent wrote a letter on 12.4.2001 claiming pension under the Pension Fund Rules, 1995 in
terms of State Bank of India Employees Pension Rules (for short 'the Rules'). The claim of the 1st
respondent for withdrawal of his application for voluntary retirement and grant of pension and
leave encashment was refused by the Bank on 4.7.2001. Being grieved by the aforesaid refusal and
declination of the prayer, the 1st respondent preferred writ petition being CWP No. 14325 of 2001.
The Writ Court took note of the fact there was acceptance of the voluntary retirement on 17.3.2001
with a stipulation that the employee would be relieved from his duties at the close of business hours
on 31.3.2001. The Division Bench referred to the decision in Mohinder Pal Singh v. Punjab and Sind
Bank and others[1] and the decision of this Court in Bank of India and others v. O.P. Swarankar
etc.[2] and after reproducing the directions of from Swarankar's case came to hold as follows:-
"In view of the aforesaid finding, the moment a decision is taken by the Bank, the
jural relationship of employer and employee stood terminated. The petitioner has
admittedly sought to withdraw his offer to seek voluntary retirement after the
acceptance was conveyed to the petitioner. Mere fact that the date of voluntary
retirement was fixed as 31.03.2001, is wholly inconsequential as employer and
employee relationship has already come to an end with the communication of
acceptance. It was only the procedural part under which the petitioner continued to
work till 31.03.2001."
In the ultimate analysis, the High Court did not find any merit with regard to refusal by the Bank in
not accepting the application for withdrawal submitted by the employee. Determination on the said
score is not under assail in any of the appeals before this court.
The next question that emerged for consideration before the High Court was whether the employee
was entitled to pension in terms of the rules, including computed value of pension. It was contended
by the 1st respondent in the writ court that the pension rules were amended on 9.3.2001 and the
said rules were in vogue when the petitioner had submitted his application for voluntary retirement,
and hence, he was entitled to get the pensionary benefits. It was also urged that in terms of the
amended Rule 22 of the pension rules, he was entitled to pension. The said submission was resistedAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

by the Bank that Rule 22 did not cover the cases like that of the petitioner. In justification of the said
submission, reliance was placed on the Division Bench judgment of the High Court of Delhi in Vipin
Kalia and Ors. v. State Bank of India and Ors. decided on 28.2.2007 in L.P.A. No. 410 of 2002 and
also on a decision rendered by the High Court of Andhra Pradesh in C.W.P. No. 2098 of 2006. The
Division Bench referred to the anatomy of Rule 22 and after analyzing the scope of the rule
distinguished the decision of the High Court of Delhi as well as that of Andhra Pradesh and came to
hold that it was apparent from the record that the writ petitioner was in service of the Bank on
01.11.1993 and had completed 10 years of pensionable service and further had attained the age of 58
years. Therefore, in terms of Rule 22 of the Pension Rules, he was entitled to pension. Dealing with
the claim for leave encashment which is based upon the circular of the Bank dated 23.09.1986, it
opined that the leave encashment was payable to an employee of the Bank, who had been discharged
if he was eligible for pension and as it had been found that the petitioner was entitled to pension in
terms of the Pension Rules he would be entitled to leave encashment as well. In this batch of
appeals, the question that emanates for consideration whether the respondent-employees are
entitled to get pension. There can be no cavil over the fact that their right to seek withdrawal from
the scheme of voluntary retirement has been negatived by the impugned judgments passed by
various High Courts and, therefore, I am not required to address the said issue. It is essential to
advert to the issue whether the employee would be entitled to pension under the four corners of the
Rules. Rule 22 which squarely falls for consideration is as follows:-
"22. (i) A member shall be entitled to a pension under these rules on retiring from the
Bank's service -
After having completed twenty years' pensionable service provided that he has
attained the age of fifty years or if he is in the service of the Bank on or after 1.11.93,
after having completed ten years pensionable service provided that he has attained
the age of fifty eight years or if he is in the service of the Bank on or after 22.5.1998,
after having completed ten years pensionable service provided that he has attained
the age of sixty years;
After having completed twenty years' pensionable service, irrespective of the age he
shall have attained, if he shall satisfy the authority competent to sanction his
retirement by approved medical certificate or otherwise that he is incapacitated for
further active service;
After having completed twenty years pensionable service, irrespective of the age he
shall have attained at his request in writing.
After twenty five years' pensionable service.
A member who has attained the age of fifty-five years or who shall be proved to the
satisfaction of the authority empowered to sanction his retirement to be permanently
incapacitated by bodily or mental infirmity from further active service (such infirmity
not being the result of irregular or intemperate habits) may, at the discretion of theAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

trustees, be granted a proportionate pension.
A member who has been permitted to retire under Clause 1(c) above shall be entitled
to proportionate pension."
Keeping the aforesaid Rule in view, it is obligatory to scrutinize the analysis made by the High Court
in the backdrop of the facts. The High Court has taken note of the fact that the 1st respondent had
completed more than 19 years and 10 months of service as on 31.3.2001 and, therefore, the first part
of Clause (a) is not applicable to him. The High Court has also opined that the third part of Clause
(a) is not applicable to him as he had completed more than 19 years of service but not attained the
age of 60 years. The case of the 1st respondent was that his case was covered under second part of
Clause (a) which enables an employee to get pension if he was in service of the Bank as on 1.11.1993
and had completed ten years' of service and attained the age of 58 years. The High Court took note
of the fact that the counter-affidavit was silent regarding the claim of the 1st respondent under
second part of Clause (a). Analysing further in this regard, the High Court opined as follows:-
"The petitioner has submitted his offer for voluntary retirement in terms of the
Pension Rules existing in the month of January, 2001. On the said date a member of
the Pension Funds was entitled to pension on completion of 20 years of pensionable
service provided he has attained the age of 50 years. Alternatively, if a member is in
service of the Bank on or after 01.11.1993 and has completed 10 years of pensionable
service and has attained the age of 58 years, he shall be entitled to the pension. The
petitioner fulfils the second part of Clause (a) of Rule 22 which was in existence on
the day when the petitioner submitted his request for voluntary retirement. Even
after the amendment on 09.03.2001, another clause has been added i.e. 3rd part of
Clause (a) as mentioned above, which does not affect the claim of the petitioner for
pension as he is entitled to pension in the second part of Rule 22(1)(a)."
The High Court referred to the voluntary Retirement Scheme floated on 29.12.2000, and
reproduced the relevant part of the said Scheme which is as follows:-
"5. Amount of Ex-Gratia:
The staff member whose request for retirement under SBIVRS has been accepted by
Competent Authority will be paid an amount of ex-gratia of 60 days' salary (pay plus
stagnation increments plus special pay plus dearness allowance) for each completed
year of service (for this purpose fraction of service of six months and above will be
taken as one year and accordingly service of less than six months will be counted) or
salary for the number of months service is left, whichever is less, fraction of a month,
if any, will be ignored. 'Relevant Date' means the date on which the employee ceases
to be in service of the Bank as a consequence of the acceptance of the request for
voluntary retirement under the scheme.Assistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

For the purpose of calculation of ex-gratia, 60 days salary mentioned in the Scheme is
to be taken as equivalent to 2 months salary (with reference to salary for the month in
which employee is relieved from service on (Voluntary Retirement).
Income Tax shall be deducted at source in respect of ex-gratia exceeding Rs.5.00
lakhs or such other ceiling as may be prescribed under the Income Tax Act as on the
relevant date.
Other benefits:
Gratuity as payable under the extent instructions on the relevant date.
Provident Fund Contribution as per State Bank of India Employees Provident Fund
Rules as on relevant date.
Pension in terms of State Bank of India Employees' Pension Fund Rules on the
relevant date (including commuted value of pension).
Encashment of balance of privilege Leave, as applicable on the relevant date.
Respective facilities extended to officers/others such as retention of accommodation,
telephone, car, continuation of housing loan etc., will be extended to officers/others
retiring under SBIVRS as per present dispensations, at the discretion of Competent
Authority. However, in such cases of retention of physical facilities, 50% of the
amount of ex-gratia payable will be released only after the employee surrenders the
facilities. No interest, however, will be paid for the amount so withheld. All other
outstanding loans/advances will have to be repaid before date of retirement under
SBIVRS, failing which the amount of ex-gratia and other terminal benefits payable to
the employee will be appropriate towards the outstanding loans/advances and the
balance amount only will be payable to the employee."
The High Court opined that the said paragraphs, when properly appreciated, convey that the
amount of ex-gratia is to be paid and what are the other benefits to be paid have also been
enumerated. Referring to Clause 6 it ruled that it deals with gratuity, provident fund contribution,
pension in terms of the Rules on the relevant date (including commuted value of pension),
encashment of balance of privilege leave and certain other benefits. The Court also took note of the
clarificatory circular issued by the Bank on 10.1.2001. While answering the question, whether or not,
the employee completing 15 years of pensionable service as on relevant date the Court held he would
be entitled for pension benefit.
Presently I shall refer to the relevant part of Clarificatory circular:-
"In this connection, we invite a reference to para 6(c) of the Scheme forwarded under
the cover of Circular No. CIR.DO/PER & HRD/99 dated 29.12.2000. The payment ofAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

pension to the employee retiring under SBIVRS would be governed by State Bank of
India Employees Pension Fund Rules on the relevant date (including commuted
value of pension). However, as per existing rules, employees who have not completed
20 years of Pensionable Service are not eligible for pension."
Having noted the rule relating to pension on which the case is founded and the scheme on which
reliance has been placed by the High Court, it is necessary to notice how various High Courts have
approached this problem. I have already stated that the High Court of Punjab and Haryana has
opined that the employee who had opted for voluntary retirement is entitled to pension in the
second part of Rule 22 (1) (a). Now, I shall advert to the analysis made by the High Court of Calcutta
which is the subject matter of C.A. No. 5035-37 of 2002. The learned Single Judge of the High Court
of Calcutta took note of the contention that when an offer of acceptance had become a concluded
contract any subsequent change of the pension fund rules could not have adversely affected his
rights, for the explanatory memorandum issued by the bank on 9th March 2001 stipulated to the
effect that no employee/pensioner of the State Bank of India is likely to be effected adversely by the
notification being given retrospective effect. He repelled the contention of the bank that the
voluntary retirement scheme itself provided that payment of pension was dependent upon the rules
prevalent on the date on which the employee would cease to be in service of the bank and admittedly
the writ petitioner therein had ceased to be an employee on 31st March 2001 and, thereafter, the
amendment of the pension rules effecting from that day was binding upon him and as such he was
not liable to get any pension. The learned Single Judge formulated two issues namely, (i) whether
the right of the petitioner to receive pension as per the existing rules could have been taken away by
the amended rules which became effective on 31st March, 2001? and (ii) was the writ petitioner
estopped from espousing his cause of action due to delay, laches and acquiescence and answered
both the issues in the negative against the bank and in favour of the writ petitioner.
On an appeal being preferred the division bench referred to Section 17 and 19 of the Contract Act
and came to hold as follows:-
"In the case before us, on the date of acceptance of the contract, it was known to the
bank that it had already decided to amend its pension rules by which the appellant
would be deprived of his right to get pension although on the date of acceptance if he
retired he would be entitled to get pension. The employee ad no means of knowledge
of such change of pension rules at the time of agreement. In such a situation, the
relation between the parties being that of employer and employee, it was the duty of
the employer to inform the employee about the future amendment of the pension
rules which would deprive the employee of his right to get pension by entering into
the voluntary retirement scheme. If he had known this fact, he would not definitely
enter into the scheme because if he had retired in due course without opting for
voluntary retirement, he would be entitled to get pension even under the amended
rules. Therefore, the silence maintained by the employer in such a situation
amounted to fraud on its part. As pointed out in illustration (b) to S. 17 of the
Contract Act, if it becomes a duty of a father to disclose the defect of the horse
proposed to be sold to his just grown up daughter, in the same manner, it is also theAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

duty of the employer to inform his employee about the future amendment of the
pension rules causing prejudice to his employee at the last stage of his service life
before accepting the terms of the voluntary retirement scheme declared by it when
such source of prejudice is know to the employer and the employee had no manner of
knowledge of such perilous condition."
Thereafter, the Bench referred to Food Corporation of India v. Kamdhenu Cattle Feed Industries[3]
and opined thus:-
"Therefore, on that ground also the writ petitioner is entitled to get the pensionary
benefit which was available to him on the date of declaration of the scheme and also
on the date of acceptance of the offer of the employee under voluntary retirement
scheme. If the proposed amendment was disclosed to the writ petitioner in advance,
he would not have accepted such prejudicial terms of voluntary retirement scheme
and offered for the scheme. We do no for a moment dispute the submission of Mr.
Gupta, the Ld. Sr. Advocated appearing on behalf of the appellant that the contract
was competed by acceptance of the offer of the employee under the scheme as laid
down in the case of Bank of India v. O.P. Swarnanakar but the appellant having
committed fraud upon the writ petitioner by adopting silence in the matter of
proposed amendment of the pension rules on the last date of the service of the
employee, the writ petitioner is entitled to the relief claimed by taking aid of Article
14 of the Constitution of India."
Be it stated, as the Single Judge had not granted interest, the division bench thought it appropriate
to grant interest at the rate 12% per annum on arrears amount of pension.
As far as the High Court of Allahabad is concerned, the learned Single Judge had remitted the
matter to the bank to consider the case of the writ petitioner for his entitlement for grant of pension.
In the intra-court appeal, the Division Bench addressed to the lis on merits, referred to clause 6 (c)
of the scheme which provides that pension shall be granted in terms of State Bank of India
Employees' Pension Fund Rules on the relevant date (including commuted value pension) and
opined that the said clause was a binding contract between the writ petitioner and on 18.3.2001 the
bank accepted the offer of retirement made by the writ petitioner, though the employee did in fact
retire on 31.3.2001. The High Court took note of the fact although the amendments were sufficiently
formulated before 31.03.2001 yet the trustees of the pension fund accepted the amended rules only
on the 30.10.2001. The High Court referred to the existing rules and the amended rules which I shall
refer to at a later stage. It was contended by the writ petitioner before the Division Bench that he
was covered under second part of the Rule 22 (i) (a) inasmuch as he was in the service of the Bank
on and after 1.11.1993 and he had completed 10 years of pensionable service, and attained the age of
58 years before the date he retired. The bank resisting the said stand contended that the clarificatory
circular issued by the bank and contended that the employee was not entitled to get pensionary
benefits. The High Court observed that the clarification had no greater status in law than the reading
and understanding the terms of the contract according to one party. It opined that the pension rules
should apply to the writ petitioner not by any force of special statutory law but only by force ofAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

agreement. Eventually the Court ruled thus:-
"The second important point raised by the Bank was that under 22(1)(c) of the
Pension Fund Rules, when an employee retires upon a request in writing being made
by him, he has to complete 20 years of service. Thus the voluntary retirement being a
retirement pursuant to the employees' request, it is this clause which will be
applicable to him and it will not be proper to give him pension because he comes
under another clause i.e. Clause (a), which was merely introduced to accommodate
late entrants into service when the retirement age was raise to 58 on 1.11.1993 and
then to 60 on 22.5.1998. Clause (a) was inserted so as to give employees benefit of
pension after 10 years of pensionable service even if they had joined late. According
to the Bank the writ petitioner is seeking to take advantage of this clause although
this clause was never intended to cover it.
It is also said that if in cases of retirement on request in writing clause (a) is made
applicable then clause (c) will have no field of operation at all. Everybody will be
entitled to pension after 10 years and, therefore, the 20 years' requirement of Clause
(c) will lose all meaning."
Thereafter the division bench referred to Clause 15 of the Bank Fund Rules which permits
retirement on request by the bank employee provided a sanction is made by the competent
authority. After referring to the said clause the court held thus:-
"In our opinion, the voluntary retirement under the scheme should not be equated to
a retirement to clause 15 of the Pension Fund Rules. It might be that Clause 22(c)
made to cover pension aspects for Clause 15 retirements and Clause 22(i)(a) was
made to cover normal superannuation retirements, but voluntary retirement was a
special contract made available for special purpose, and that too for a very small
period of time which was practically one moment or just one short fleeting period
during an employee's service career. For this scheme and this contract the pension
rules did not apply as rules. The rules apply only as words in the contract. Therefore,
if a contracting party is entitled to take benefit of a permissive clause, then that
cannot be denied to him on the basis of purpose if construction of a statutory rule.
This type of purposive construction is far less, if at all, applied to contracts. Contacts
are, generally speaking, strictly interpreted on the basis of the language agreed upon
by the parties. The Court does not make out the parties' contract, they make their
own contact.
On this basis of strict interpretation, the writ petitioner clearly comes within Rule
22(i)(a) although this is better put as Clause 22(i)(a) of the Pension Fund Rules in
reference to the contract.
Regarding the other aspect of Clause 22(i)(c) having no field of operation at all, one
bare look will show that the said clause will operate in all cases where the retiringAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

employee has not even attained the age of 58 years. If the pensionable period of 20
years has been completed before that, and the competent authority grants sanction to
retire under Rule 15, then and in that event one would get pension although one
would not under the second or third parts of Clause 22(i)(a). Thus each part of the
contractual document is left with a meaning even if the interpretation in favour of the
writ petitioner is wholly accepted."
At this juncture, it is apt to appreciate the decision rendered in case of Vipin Kalia (supra) by the
division bench of Delhi High Court. In the said case the division bench dealing with the State Bank
of India Voluntary Retirement Scheme whereunder the option exercised by the employees was
accepted by the respondent bank on 31.3.2001. All the appellants therein had either completed 15
years of service or were of 40 years of age as on 31.12.2000 and accordingly, as per the provision of
the State Bank of India Employees Pension and Provident Fund Rules they had claimed pension as
per the rules. The court referred to Indian Bank's Association letter dated 11.12.2000 which was the
fulcrum of the scheme to get the pension. The division bench reproduced the said letter which I
think it appropriate to reproduce.
"Indian Bank's Association Stadium House 6th Floor, Block 2 Veer Nariman Road
Mumbai-400020 PD/CIR/76/G2/G4/ December 11,2000 Designated officers of all
Public Sector Banks.
Dear Sirs, Voluntary Retirement Scheme in Public Sector Banks-Amendments To
Bank, (Employees') Pension Regulations, 1995.
Please refer to our circular letter No. PD/CIR/76/G4/933 dated 31st August 2000
convening the 'No Objection' of the Government in banks adopting and
implementing a voluntary retirement scheme for employees on the lines of what was
contained in the Annexure to the circular.
As per the scheme, an employee who is eligible and applies for voluntary retirement
is entitled for the benefit of CPF, Pension, Gratuity and encashment of accumulated
privilege leave, as per rules.
Bank (Employees') Pension Regulations, 1955 do not have provisions enabling
payment of pension to an employee who retires before attaining the age of super
annuation except under circumstances as in Regulations 29, 30, 32 and
33. We had, therefore, taken up with the Government the need to incorporate
necessary provisions in the Pension Regulations by way of amendments to
Regulation 28 so that employees who retire as above under special/ad hoc schemes
formulated by the banks, after serving for a prescribed minimum period would be
eligible for pro rata pension.Assistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

Government of India has after examining the proposal conveyed its approval and
desired that IBA advise banks to make necessary amendments to their Pension
Regulations as in the Annexure. We request banks to take note accordingly.
Please note that with the above amendments, employees who apply for voluntary
retirement after having rendered a minimum of 15 years of service under a special/ad
hoc scheme formulated with the specific approval of the Government and the Board
of Directors will be eligible for pro rata pension for the period of service rendered as
they are to retire on attaining the age of superannuation on that date.
Yours faithfully, sd/-
(Allen C A Pereira) PERSONNEL ADVISER"
It was contended before the High Court that under the said recommendation the bank was obliged
to pay pension to them but the said contention was not accepted by the Single Judge on the ground
the said letter is not a binding circular under Section 18 of the State Bank of India Act, 1955. The
learned Single Judge had also opined that voluntary retirement scheme was a package by itself and
it was not open to the employees to ask for modification of the scheme and if the employees wanted
to avail of the benefit of pension, they should not have opted under the scheme and after completing
requisite years of service, would have been entitled to pension. The Court examined the SBIVRS
dated 30.12.2000 and opined that it was an invitation to the employees to make an offer and opt for
voluntary retirement. The scheme, as analysed by the Division Bench, specifically stipulated that the
employees who were eligible and the period during which an offer for voluntary retirement could be
made. Reference was made to Clause 5 and 6 of the scheme that provides for ex-gratia payment to
the officers who had opted for voluntary retirement. The court referring to the letter dated 11.1.2001
opined that the payment of pension to an employee retiring under the voluntary retirement scheme
are to be governed by the relevant pension rules, and as per the existing rules, an employee who had
not completed 20 years of pensionable service would not be eligible for pension. Thereafter the
Division Bench observed that the employee who has opted under voluntary retirement scheme was
fully conscious and aware of the fact that he would not be entitled to pension under the scheme as
he had not completed 20 years of pensionable service and pension was payable only to those
employees who were eligible for pension under the rules as applicable o the relevant date. Reference
was made to Bank of India O.P. Swarankar (supra) and accordingly it was held as follows:-
"The appellants, therefore, cannot be allowed to wriggle out of the terms and
conditions accepted and agreed upon by the two parties viz. the appellants and the
respondent-bank. The appellants had entered into the said contract with open eyes
and fully conscious and aware of what benefits they would be entitled to by opting
under the Voluntary Retirement Scheme. They were conscious and aware and in fact
specifically informed by way of clarification by the respondent that the employees
who had not completed 20 years of service, would not be eligible for pension under
the relevant rules. The appellants by way of appeal are seeking modification of the
terms of the concluded contract which in equity is not just and fair."Assistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

Eventually concurring with the Single Judge the Division Bench ruled:-
"13. The State Bank of India, as already stated, has its own pension regulations. The
employees of the State Bank of India are bound by the same. Letter/circular dated
11th December, 2000 refers to amendment to Bank (Employees') Pension
Regulations, 1995. The said regulations are not applicable to the employees of State
Bank of India. The Pension regulations applicable to the State Bank of India
employees are different. As far as employees of State Bank of India are concerned, the
Bank Employees' Pension Regulations, 1995 are not applicable. The amendment
suggested by letter/circular dated 11th December, 2000 by Indian Bank's Association
was not applicable to the appellants and the employees of the State Bank of India. We
may also point out here that State Bank of India in the counter affidavit has explained
that its Voluntary Retirement Scheme was a special and a distinct scheme offering a
handsome package for the employees who were ready and willing to opt for
retirement. It is also pointed out that the State Bank of India's employees unlike
employees belonging to other public sector banks were entitled to both contributory
provident fund and membership of a pension fund. It is stated that employees of
other public sector bank are eligible either for contributory provident fund or
membership of pension fund.
14. Learned Counsel for the appellants, however, also relied on the judgment of a
single Judge of this Court in the case of Punjab and Sind Bank Officers Association
and Ors. v. Union of India and Anr. on 11th May, 2006. In the said case, learned
single Judge was examining regulations 28 and 29 of the Bank (Employees') Pension
Regulations, 1995. The issue was which of the two regulations would apply. It was
held that Regulation 29 would apply to employees who had taken voluntary
retirement whether under normal circumstances or under a special scheme. It was
further held that the scheme or package cannot be altered unilaterally. The said
decision does not support the contention of the appellants. The terms and conditions
of the Voluntary Retirement Scheme were clear and specific. The terms were not
ambiguous. The employees including the appellants were fully conscious of the
decision taken by them and the benefits they would be entitled to. The appellants
voluntarily, with open eyes entered into an agreement and after having retired and
enjoyed the benefits, they cannot go behind the concluded contract and claim further
benefits. It must be remembered that a Voluntary Retirement Scheme is formulated
and conceived in public interest. Interest of the respondent bank is also to be taken
into consideration."
Having stated the various views taken by the High Courts I may now refer to certain authorities
dealing with these kind of schemes. In Arikaravula Sanyasi Raju v. Branch Manager, State Bank of
India, Visakhapatnam (A.P.) and others[4] the question arose whether an officer who is removed
from service on finding of misconduct would be entitled to get the relief of pension under Rule 22 of
the State Bank of India Service Rules. In the said case the High Court had directed the payment of
provident fund in terms of rules but denied the relief of pension. The Court referred to Rule 22 ofAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

the rules and opined had the officer sought retirement on that basis and allowed the retirement from
service he would have been entitled to pension on completion of 20 years of pensionable service but
removal would not entitle him to get pension. Interpreting Clause 22(i)(c) the two-Judge observed
thus:-
"Clause 22(i)(c) envisage only that after completing 20 years of pensionable service, if
an incumbent retired at his request in writing and was permitted to retire, he would
be entitled to pension. In other words, for voluntary retirement, on completion of 20
years of pensionable service, clause (c) of Rule 22(1) gets attracted"
In V. Kasturi v. Managing Director, State Bank of India, Bombay and another[5] though the Court
was dealing with eligibility to be entitled for pension under Rule 22(i)(c) yet it reproduced the rule,
referred to the contentions and came to hold as follows:-
"12. On a close look at the relevant provisions of the Rules, it is not possible to agree with this
contention. The appellant, in order to earn pension under Rule 22(1) clause (c) as amended in 1986
has to satisfy the following twin conditions:
(i) at the time when the amended clause (c) applied, i.e., from 22-9-1986, he should
be a member of the pension fund;
(ii) he should have by then completed 20 years of pensionable service, and should
have put forward his requisition in writing for availing the benefit of the said
provision.
Unless both these conditions are satisfied the amended clause (c) of Rule 22(1) cannot apply in his
case."
The afore-referred two decisions show how the Court had perceived the rule position.
In Vice-Chairman and Managing Director, A.P. SIDC Ltd. and another v R. Varaprasad and
others[6] while dealing with the concept of voluntary retirement schemes the Court has ruled that:-
"All employees who accepted VRS could be relieved at a time or batch by batch
depending on availability of funds. Further funds may be made available early or late.
If the argument of the respondents that relieving date should be taken as effective
date for calculating terminal benefits and financial package under VRS, the dates may
be fluctuating depending on availability of funds. Hence it is not possible to accept
this argument. When the employees have opted for VRS on their own without any
compulsion knowing fully well about the Scheme, guidelines and circulars governing
the same, it is not open to them to make any claim contrary to the terms accepted. It
is a matter of contract between the Corporation and the employees. It is not for the
courts to rewrite the terms of the contract, which were clear to the contracting
parties, as indicated in the guidelines and circulars governing them under whichAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

Voluntary Retirement Schemes floated."
In O.P. Swarnakar (supra) the question arose whether an employee who opts for voluntary
retirement pursuant or in furtherance of scheme floated by the Nationalised Banks and the State
Bank of India would be precluded from withdrawing the said offer. The court dealing with the
concept of voluntary retirement held as follows:-
"59. The request of employees seeking voluntary retirement was not to take effect
until and unless it was accepted in writing by the competent authority. The
competent authority had the absolute discretion whether to accept or reject the
request of the employee seeking voluntary retirement under the Scheme. A procedure
has been laid down for considering the provisions of the said Scheme to the effect
that an employee who intends to seek voluntary retirement would submit duly
completed application in duplicate in the prescribed form marked "offer to seek
voluntary retirement" and the application so received would be considered by the
competent authority on first-come-first-serve basis. The procedure laid down
therefor suggests that the applications of the employee would be an offer which could
be considered by the bank in terms of the procedure laid down therefor. There is no
assurance that such an application would be accepted without any consideration.
60. Acceptance or otherwise of the request of an employee seeking voluntary
retirement is required to be communicated to him in writing. This clause is crucial in
view of the fact that therein the acceptance or rejection of such request has been
provided. The decision of the authority rejecting the request is appealable to the
Appellate Authority. The application made by an employee as an offer as well as the
decision of the bank thereupon would be communicated to the respective General
Managers. The decision-making process shall take place at various levels of the
banks."
Eventually analyzing the stand of various banks the court expressed thus:-
"90. The basic concept of the Scheme, therefore, underwent a change which also goes
to show that the banks had sought to invoke their power of amending the Scheme.
Once the Scheme is amended and/or an apprehension is created in the mind of the
employees that they would not even receive the entire benefits as envisaged under the
Scheme, they were entitled to revoke their offers. Their action in our considered
opinion is reasonable. It may be that some of the employees only opted for the
provident fund benefit which did not undergo any amendment but the same would
not change the attitude on the part of the banks."
In HEC Voluntary Retd. Employees Welfare Society and Another v. Heavy Engineering Corpn. Ltd.
and others[7] the Court referring to concept of voluntary retirement opined that an offer for
voluntary retirement in terms of a scheme, when accepted, leads to a concluded contract between
the employer and the employee. In terms of such a scheme, an employee has an option either toAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

accept or not to opt therefor. The scheme is purely voluntary, in terms whereof the tenure of service
is curtailed, which is permissible in law. Such a scheme is ordinarily floated with a purpose of
downsizing the employees. It is beneficial both to the employees as well as to the employer. Such a
scheme is issued for effective functioning of the industrial undertakings. The court further observed
that although the Company is a "State" within the meaning of Article 12 of the Constitution, the
terms and conditions of service would be governed by the contract of employment. Thus, unless the
terms and conditions of such a contract are governed by a statute or statutory rules, the provisions
of the Contract Act would be applicable both at the formulation of the contract as also the
determination thereof. By reason of such a scheme, it only is an invitation of offer floated. When
pursuant to or in furtherance of such a Voluntary Retirement Scheme an employee opts therefor, he
makes an offer which upon acceptance by the employer gives rise to a contract. Thus, as the matter
relating to voluntary retirement is not governed by any statute, the provisions of the Contract Act,
1872, therefore, would be applicable too. In this context reliance was placed on O.P. Swarankar's
case (supra). After so stating, the Court ruled:
"We have noticed that admittedly thousands of employees had opted for voluntary
retirement during the period in question. They indisputably form a distinct and
different class. Having given our anxious consideration thereto, we are of the opinion
that neither are they discharged employees nor are they superannuated employees.
The expression "superannuation"
connotes a distinct meaning. It ordinarily means, unless otherwise provided for in the statute, that
not only he reaches the age of superannuation prescribed therefor, but also becomes entitled to the
retiral benefits thereof including pension. "Voluntary retirement" could have fallen within the
aforementioned expression, provided it was so stated expressly in the Scheme.
Financial considerations are, thus, a relevant factor both for floating a scheme of voluntary
retirement as well as for revision of pay. Those employees who opted for voluntary retirement, make
a planning for the future. At the time of giving option, they know where they stand. At that point of
time they did not anticipate that they would get the benefit of revision in the scales of pay. They
prepared themselves to contract out of the jural relationship by resorting to "golden handshake".
They are bound by their own act. The parties are bound by the terms of contract of voluntary
retirement. We have noticed hereinbefore that unless a statute or statutory provision interdicts, the
relationship between the parties to act pursuant to or in furtherance of the Voluntary Retirement
Scheme is governed by contract. By such contract, they can opt out of such other terms and
conditions as may be agreed upon. In this case the terms and conditions of the contract are not
governed by a statute or statutory rules."
In the said case the court referred to V. Kasturi Case (supra) and understood it in the following
manner:-
"It has not been suggested that voluntary retirement, in the absence of any express
statutory rule governing the field, would bring about a case of superannuation. In V.
Kasturi, a new rule was introduced providing for pension of an employee afterAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

retirement on completion of 20 years of service, provided he requested in writing
therefor. The questions which fell for consideration therein were that if a person was
eligible for pension at the time of his retirement and if he survives till the time of
subsequent amendment of the relevant Pension Scheme, whether he would become
entitled to enhanced pension or would become eligible to get more pension as per the
new formula of computation of pension. In the fact situation obtaining therein, it was
held that employees could be divided in two [pic]categories i.e. those who were
eligible for pension at the time of their retirement and those who were not. Whereas
in the case of first category the benefit of the amended provisions would be
applicable, but in the second it would not. V. Kasturi also, thus, in our opinion, is not
applicable to the fact of the present case."
In this backdrop, I am required to scan the anatomy of Rule 22 and the appropriate interpretation is
required to be placed on the same. Rule 22(i) (a) postulates that members shall be entitled to
pension under the said rule on retiring from the bank's service. Thus, the key word is retiring from
bank's service. The said rule when understood in proper perspective, covers cases of normal
retirement/superannuation. There are various compartments and each compartment has different
criterion. An employee, who has completed 20 years of pensionable service and has attained the age
of 50 years, would be entitled to get the pension under the rules. This is one compartment. Second
one, as is envisaged, carves out an exception to the first part, which stipulates that when an
employee who is working in the bank on or after 01.11.1993 and has completed 10 years of
pensionable service, shall be entitled for pension provided he has attained the age of 58 years. The
third part of the rule stipulates that all employees who are in service of the bank or after 22.05.1998
and have put in 10 years of pensionable service, to be eligible for pension provided they have
attained the age of 60 years i.e. age of superannuation. As the facts would demonstrate, in the
instant case, the employees/respondents, before attaining the age of superannuation, sought
voluntary retirement under the Scheme.
At this juncture, it is relevant to state Rule 22(i)(b) which provides that an employee who has
completed 20 years of pensionable service, irrespective of age, if he satisfies the authority competent
to sanction retirement by appropriate medical certificate or otherwise that he is incapacitated for
further active service, he would be entitled to pension. This clause does not cover the present
respondents. Clause 22(i)(c) deals with entitlement of pension by an employee if he has completed
20 years of pensionable service irrespective of age, if he seeks retirement at his own request in
writing. It is the stand of the Bank that Rule 22(i)(c) was added on 20.09.1986 for the specific
purpose of granting pension to those who have voluntary retired. As is evident from the factual score
under the SBI VRS, the employees were required to submit written applications seeking voluntary
retirement under the Scheme. When the scheme was in operation, the competent authority i.e.
Deputy Managing Director had issued a circular dated 10/15.1.2001 clarifying the position that the
employees could withdraw their applications made under SBI VRS by 15.2.2001 and those
employees who have not completed 20 years of pensionable service, are not eligible for pension.
There can be no doubt, by abundant caution, the bank issued a clarificatory circular. The said
circular cannot be given any type of nomenclature other than a clarificatory circular, despite treated
as such. It is graphically clear from the same that an employee who has completed 20 years ofAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

pensionable service would be entitled to pension, even if they seek voluntary retirement under SBI
VRS. It was open to the employees to withdraw their applications under SBI VRS by 15.2.2001. The
respondent-employees, as is manifest, chose not to withdraw. In these circumstances, the question
arises whether any part of Rule 22 would apply to the respondent for extension of benefit of
pension. As has been elaborated earlier, Clause 22(i)(a) and 22(i)(b) are not applicable to them.
Mr. Rohtagi, learned Attorney General, has submitted that on 30.1.2001, the SBI Employees
Pension Fund Rules was amended by the Central Board of SBI. The SBI VRS was in operation from
15.1.2001 to 31.1.2001. The employees were at liberty, as has been stated earlier, to withdraw by
15.2.2001. Admittedly, the Rule was in force on 30.1.2001. The employees were very well aware
about the amended Rule. There can be no scintilla of doubt that the Rule existed as on 31.1.2001. If
an employee wanted to withdraw, he could have withdrawn prior to 15.2.2001 but as is the admitted
position, none of the employees withdrew. There is no cavil over the fact that the employees had
accepted all the benefits of the VRS. The crux of the matter is whether the respondents can get the
benefit, despite the amendment brought to the Rules.
In Arikaavula Sanyasi Raju (supra), it has been clearly held, for voluntary retirement on completion
of 20 years of pensionable service, clause (c) of Rule 22(i) gets attracted. Another aspect needs to be
noted. The SBI Pension Rules have been framed under Section 50 of the SBI Act, 1955. The Rules
have statutory force. The concept of any kind of promissory estoppel, if any, could not be applicable
to promote or condone the breach of law.
In Bangalore Development Authority & Ors. Vs. R. Hanumaiah & Ors.[8] it has been held that rule
of promissory estoppel cannot be availed to permit or condone a breach of law. It cannot be invoked
to compel the Government to do an act prohibited by law, for such a direction would be against the
statute. To arrive at the said conclusion, the two-Judge Bench placed reliance on TISCO Ltd. V. State
of Jharkhand[9], Hira Tikkoo V. Union Territory, Chandigarh[10] and Savitaben Somabai Bhatiya
V. State of Gujarat[11].
The High Court, to sustain its conclusion, has referred to Clause 6(c) of the Scheme which postulates
that the benefits shall be granted to the employee which include the pension and the said pension
shall be granted in terms of the State Bank of India Employees Pension Fund Rules on the relevant
date. The High Court referred to Rule 22(i) prior to the amendment i.e. 09.03.2001. The
unamended portion of the Rule reads as follows:
"After having completed 20 years' pensionable service provided that he has attained
the age of 50 years or if he is in service of the Bank on or after 01.11.1993, after having
completed 10 years pensionable service provided that he has attained the age of 58
years."
After the amendment that was incorporated on 9.3.2001, the Rule reads as under:
"After having completed 20 years' pensionable service provided that he has attained
the age of 50 years or if he is in service of the Bank on or after 01.11.1993, after havingAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

completed 10 years pensionable service provided that he has attained the age of 58
years or if he is in the service of the Bank on or after 22.05.1998, after having
completed 10 years pensionable service provided that he has attained the age of 60
years".
Analysing the said Rule, the High Court opined that the employees would be covered under second
part of clause (a) of Rule 22(i) which was in existence on the date when the petitioner submitted his
request for voluntary retirement. That apart, the High Court has also held even after amendment on
09.03.2001, by which another clause has been added, that is, third part of clause (a), would not
affect the claim of the employees for pension as he is entitled to pension in the second part of Rule
22(i) (a). Here, as I find, the High Court has opined as the respondent was in service of Bank on
1.11.1993 and had completed 10 years of pensionable service and attained the age of 58 years, he
would be entitled to pension. There is no doubt that the Government of India, on 22.5.98, advised
all the banks that the age of retirement would be 60 years. Accordingly, the Board of SBI, on
22.5.1998 itself, passed a resolution whereby it fixed the age of retirement 60 years w.e.f. that date.
As a consequence of re-fixation of age of retirement, the rules were amended and third part of Rule
22(i)(a) was added for all employees who were in service of the bank on or before 22.5.98 and had
put in 10 years of pensionable service to be eligible for pension benefit provided that they have
attained the age of 60 years. As has been stated earlier, the respondents had not retired on attaining
the age of superannuation but sought voluntary retirement under the SBI VRS. The Bank has placed
reliance on the clarificatory circular issued by the Deputy Managing Director on 10/15.1.2001, which
lays a postulate that employees who have not completed 20 years of pensionable service are not
eligible for pension.
In this context, reference may be made to a decision in Bank of Baroda & Others V. Ganpat Singh
Deora[12], wherein the Court was interpreting Bank of Baroda (Employees) Pension Regulations
1995. In the said case, the Bank of Baroda had introduced "Bank of Baroda Employees Voluntary
Retirement Scheme 2001" and under the Scheme along with terminal benefits pension in terms of
1995 Regulations was to be provided to the employees who opted for the VRS Scheme. The
respondent-employee therein, after accepting voluntary retirement, filed an application for claiming
pension which was opposed by the Bank in terms of Regulations 14, 28 and 29 of the Pension
Regulations 1995. Eventually, the matter travelled to the Tribunal, who, by its award, allowed the
respondent's claim and directed the Bank to pay to the respondent pension according to the Pension
Regulations. Against the award passed by the Industrial Disputes Tribunal, the Bank preferred a
writ petition before the High Court but the said challenge did not meet with any success. This Court
referred to the language of the Scheme and opined as follows:
"27. The conditions relating to completing 15 years of service for being eligible to
apply for BOBEVRS, 2001 are special to the Scheme as also to the case of those
employees who wished to apply for voluntary retirement under the aforesaid Scheme,
if they had completed or would be completing 40 years of age. The latter condition
appears to have been incorporated in view of the provisions of Regulations 14 and 32
of the Pension Regulations, 1995, [pic]to enable employees who had completed 10
years of service to also become eligible to apply for premature retirement under theAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

Pension Regulations, 1995.
28. However, we are inclined to agree with Ms Bhati that Regulation 29 does not
contemplate voluntary retirement under the Voluntary Retirement Scheme and
applies only to such employees who themselves wish to retire dehors any scheme of
voluntary retirement, after having completed 15 years of qualifying service for the
said purpose. There is a distinct difference between the two situations and Regulation
29 would not cover the case of an employee opting to retire on the basis of a
voluntary retirement scheme.
29. Furthermore, Regulation 2 of the Voluntary Retirement Scheme, 2001 of the
appellant Bank merely prescribes a period of qualifying service for an employee to be
eligible to apply for voluntary retirement.
30. On the other hand, Regulations 14 and 29 of the Pension Regulations, 1995, relate
to the period of qualifying service for pension under the said Regulations, in two
different situations. While Regulation 14 provides that in order to be eligible for
pension an employee would have to render a minimum of 10 years' service,
Regulation 29 is applicable to the employees choosing to retire from service
prematurely, and in their case the period of qualifying service would be 15 years".
After so stating, the Court further opined thus:
"31. The facts of the present case, however, do not attract the provisions of Regulation
29 since the respondent accepted the offer of voluntary retirement under the Scheme
framed by the Bank and not on his own volition dehors any scheme of voluntary
retirement. In such a case, Regulation 14 read with Regulation 32 providing for
premature retirement would not also apply to the case of the respondent. While
Regulation 2 of the BOBEVRS, 2001 speaks of eligibility for applying under the
Scheme, Regulation 14 of the Pension Regulations, 1995, contemplates a situation
whereunder an employee would be eligible for premature pension. The two
provisions are for two different purposes and for two different situations. However,
Regulation 28 of the Pension Regulations, 1995, after amendment made provision for
situations similar to the one in the instant case.
32. In the absence of any particular provision for payment of pension to those who
opted for BOBEVRS, 2001 other than Regulation 11(ii) of the Scheme, we are once
again left to fall back on the Pension Regulations, 1995, and the amended provisions
of Regulation 28 which bring within the scope of superannuation pension employees
who opted for the Voluntary Retirement Scheme, which will be clear from the
explanatory memorandum. However, the period of qualifying service has been
retained as 15 years for those opting for BOBEVRS, 2001 and is treated differently
from premature retirement where the minimum period of qualifying service has been
fixed at 10 years in keeping with Regulation 14 of the Pension Regulations, 1995.Assistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

33. We are, therefore, of the view that not having completed the required length of
qualifying service as provided under Regulation 28 of the 1995 Regulations, the
respondent was not eligible for pension under the Pension Regulations, 1995 of the
appellant Bank."
Being of this view, the Court allowed the appeal preferred by the Bank.
In Bank of India and Another V. K. Mohandas and Others[13], the Court referred to Regulation 28
of the Employees' Pension Regulations 1995, which had provided superannuation pension and
Regulation 29 provided pension on voluntary retirement. After referring to series of decisions, the
Court held thus:
"31. It is also a well-recognised principle of construction of a contract that it must be
read as a whole in order to ascertain the true meaning of its several clauses and the
words of each clause should be interpreted so as to bring them into harmony with the
other provisions if that interpretation does no violence to the meaning of which they
are naturally susceptible. (North Eastern Railway Co. v. Lord Hastings[14])
32. The fundamental position is that it is the banks who were responsible for
formulation of the terms in the contractual Scheme that the optees of voluntary
retirement under that Scheme will be eligible to pension under the Pension
Regulations, 1995, and, therefore, they bear the risk of lack of clarity, if any. It is a
well-known principle of construction of a contract that if [pic]the terms applied by
one party are unclear, an interpretation against that party is preferred (verba
chartarum fortius accipiuntur contra proferentem)".
Thereafter, the Court adverted to intention of the Banks at the time of bringing out VRS 2000. The
Court observed that if the intention was not to give pension as provided under Regulation 29 and
particularly sub- Regulation (5) thereof, they could have said so in the Scheme itself. The Court also
reproduced the communication dated 5.9.2000 sent by the Government of India, Ministry of
Finance, Department of Economic Affairs, Banking Division to the Personnel Advisor, Indian Banks
Association and came to hold as follows:
"39. Two things immediately become noticeable from the said communication. One is
that as per Regulation 29 of the Pension Regulations, 1995, an employee can take
voluntary retirement after 20 years of qualifying service and become eligible for
pension. The other thing is that the Scheme provides that the employees with 15
years of service or 40 years of age shall be eligible to take voluntary retirement under
the Scheme and under Regulation 29, the employees having rendered 15 years of
service or completed 40 years of age but not completed 20 years of service shall not
be [pic]eligible for pensionary benefits on taking voluntary retirement under the
Scheme.Assistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

40. The use of the words "such employees" in the communication is referable to
employees having rendered 15 years of service but not completed 20 years of service
and, therefore, it was decided to bring an amendment in the Regulations so that the
employees having not completed 20 years' service do not lose the benefit of pension.
The amendment in Regulation 28, as is reflected from the afore referred
communication, was intended to cover the employees who had rendered 15 years'
service but not completed 20 years' service. It was not intended to cover the optees
who had already completed 20 years' service as the provisions contained in
Regulation 29 met that contingency.
xxx xxx xxx
43. It was submitted that by such construction a class within the class would be
created which is impermissible. We do not agree. If a special benefit under
Regulation 29(5) is available to the employees who had completed 20 years of service
or more, by no stretch of imagination, can it be said that it is discriminatory to those
employees who had completed 15 years of service but not completed 20 years. In view
of the provision contained in Regulation 29(5), if the optees who have not completed
20 years get excluded from the weightage of five years which has been given to the
optees who have completed 20 years of service or more, it is no discrimination. Such
provision can neither be said to be arbitrary nor can be held to be violative of any
constitutional or statutory provisions. The weightage of five years under Regulation
29(5) is applicable to the optees having service of 20 years or more. There is, thus,
basis for additional benefit. Merely because the [pic]employees who have completed
15 years of service but not completed 20 years of service are not entitled to weightage
of five years for qualifying service under Regulation 29(5), the employees who have
completed 20 years of service or more cannot be denied such benefit.
xxx xxx xxx
46. The precise effect of the Pension Regulations, for the purposes of pension, having
been made part of the Scheme, is that the Pension Regulations, to the extent, these
are applicable, must be read into the Scheme. It is pertinent to bear in mind that
interpretation clause of VRS 2000 states that the words and expressions used in the
Scheme but not defined and defined in the rules/regulations shall have the same
meaning respectively assigned to them under the rules/regulations. The Scheme does
not define the expression "retirement" or "voluntary retirement". We have, therefore,
to fall back on the definition of "retirement" given in Regulation 2(y) whereunder
voluntary retirement under Regulation 29 is considered to be retirement. Regulation
29 uses the expression "voluntary retirement under these Regulations". Obviously,
for the purposes of the Scheme, it has to be understood to mean with necessary
changes in points of details. Section 23 of the Contract Act has no application to the
present fact situation.Assistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

xxx xxx xxx
50. It is true that VRS 2000 is a complete package in itself and contractual in nature.
However, in that package, it has been provided that the optees, in addition to ex
gratia payment, will also be eligible to other benefits inter alia pension under the
Pension Regulations. The only provision in the Pension Regulations at the relevant
time during the operation of VRS 2000 concerning voluntary retirement was
Regulation 29 and sub-regulation (5) thereof provides for weightage of addition of
five years to qualifying service for pension to those optees who had completed 20
years' service. It, therefore, cannot be accepted that VRS 2000 did not envisage grant
of pension benefits under Regulation 29(5) of the Pension Regulations, 1995, to the
optees of 20 years' service along with payment of ex gratia.
51. The whole idea in bringing out VRS 2000 was to right size workforce which the
banks had not been able to achieve despite the fact that the statutory Regulations
provided for voluntary retirement to the employees having completed 20 years'
service. It was for this reason that VRS 2000 was made more attractive. VRS 2000,
accordingly, was an attractive package for the employees to go in for as they were
getting special benefits in the form of ex gratia and in addition thereto, inter alia,
pension under the Pension Regulations which also provided for weightage of five
years of qualifying service for the purposes of pension to the employees who had
completed 20 years' service".
In the said case, the decision rendered in Bank of Baroda (supra) was distinguished by stating thus:
"63. The decision of this Court in Bank of Baroda is, thus, clearly distinguishable as
the employee therein had not completed qualifying service much less 20 years of
service for being eligible to the weightage under Regulation 29(5) and cannot be
applied to the present controversy nor does that matter decide the question here to
be decided in the present group of matters".
Eventually, the Court concluded thus:
"66. We hold, as it must be, that the employees who had completed 20 years of
service and were pension optees and offered voluntary retirement under VRS 2000
and whose offers were accepted by the banks are entitled to addition of five years of
notional service in calculating the length of service for the purposes of that Scheme as
per Regulation 29(5) of the Pension Regulations, 1995. The contrary views expressed
by some of the High Courts do not lay down the correct legal position."
Recently, in State Bank of Patiala V. Pritam Singh Bedi & Others[15], the Court was dealing with the
State of Bank of Patiala Voluntary Retirement Scheme, 2000, introduced by a circular dated
20.1.2001. The Court quoted in extenso from K. Mohandas & Others (supra). Thereafter the Court
referred to Clause 3 and 7. Clause 7 thereof dealt with other benefits including pension or Bank'sAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

contribution to provident fund as the case maybe as per rules applicable on the relevant date on the
basis of actual years of service rendered. The Court also took note of Regulation 2(w) and 2(y) of
State Bank of Patiala (Employees) Pension Regulations, 1995. Regulation 2(w) defined "qualifying
service" and 2(y) defined "retirement". Regulation 2(y)(b) referred to voluntary retirement in
accordance with provisions contained in Regulation 29 of the Regulations. Reference was also made
to Regulation 14 that defined "qualifying service" which stipulates that employee who has rendered
a minimum of ten years in the bank from the date of his retirement or on the date on which he is
deemed to have retired shall qualify for pension. Reference was also made to Regulation 18 which
prescribes how the broken period of service of less than one year has to be computed. Regulation 28
thereof dealt with superannuation pension and Regulation 29 related to pension on voluntary
retirement. Scanning the various provisions of the Regulations, the Court held thus:
"22. The Respondents completed more than 10 years of service in the Bank on the
date of retirement; therefore, they fulfill the requirement of qualifying service as per
Regulation 14.
23. It has not been disputed by Appellant-Bank that the Respondents in all the
appeals have completed much more than 19 years 6 months of service in the Bank.
For example, Respondent No. 1-Prakash Chand in C.A. No. 173 of 2010 had joined
the Bank on 4th May, 1981 and relieved on 31st March, 2001. Thus, he had completed
19 years, 10 months and 28 days of qualifying service on the date of relieving from
service.
24. Regulation 18 of the Pension Regulations, 1995 provides that if broken period is
more than six months, it shall be treated as one year. Therefore, all the
Respondents-writ Petitioners having completed more than 19 years and 6 months of
service in the Bank, they are to be treated to have completed 20 years of service. The
aforesaid question was neither raised nor decided in the case of 'Bank of Baroda' or
'Bank of India'.
25. In view of the aforesaid fact, the Appellant-Bank cannot derive the benefit of the
decision of this Court in Bank of Baroda as the employees who were parties before
the Court in the said case had not completed 20 years of service. As per the decision
of this Court in Bank of India, the Respondents-writ Petitioners having completed 20
years of service are entitled to the benefit of Regulation 29."
Keeping in view the aforesaid pronouncements, I shall advert to the Regulations and the Scheme in
question. From the aforesaid two decisions, it is graphically clear that the Court has read into the
scheme, Regulations governing the pension. In the case at hand, as I find, the Regulation 22(i)(a)
refers to three categories; twenty years of pensionable service and attaining age of fifty years, or as
on 1.11.1993 an employee in service has completed ten years of pensionable service provided he has
attained the age of fifty-eight years, or an employee to be in service of the Bank on or after
22.05.1998 and has completed ten years of pensionable service provided that he has attained the age
of sixty years. The High Court has held that the employees would be covered under second part ofAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

Clause (a). I have already dealt with clause (b). Mr. Rohtagi has heavily relied on Clause 22(i)(c). It
really requires close scrutiny. It stipulates that a member shall be entitled to pension on completion
of 20 years of pensionable service irrespective of the age he has attained if the retirement is at his
own request in writing. Thus, there is a distinction between a normal retirement and a voluntary
retirement. A voluntary retirement stands in a distinction to retirement and also retirement which
comes under Clause 22(i)(b) which dwells on sanction of competent authority and member being
incapacitated. A scheme has come into existence because of certain objectives. The objectives of the
scheme were to have a balanced age-profile providing for mobility, training, development of skills
and succession plans for higher-level positions, to provide for an exit for employees who have an
honest feeling that they should now retire and take rest or that there are better opportunities
elsewhere, to have overall reduction in the existing strength of the employees and to increase
productivity and profitability. Clause 3 of the Scheme provides eligibility criterion. It reads as
follows:
"The Scheme will be open to all permanent employees of the Bank except those
specifically mentioned as 'ineligible', who have put in 15 years of service or have
completed 40 years of age as on 31st December 2000. Age will be reckoned on the
basis of the date of birth as entered in the service record."
Clause 4 deals with ineligibility which need not be referred to. Clause 5 deals with amount of
ex-gratia. Clause 6 deals with other benefits which I have already referred to. Clause 6(c) clearly
stipulates that an employee seeking voluntary retirement would have the benefit of pension in terms
of State Bank of India Employees' Pension Fund Rules on the relevant date.
40. In this context, what I have noticed in the case of K. Mohandas (supra) that the Court has
referred to the Scheme to understand the true meaning of several clauses; formulation of the
contractual scheme where reference has been made to Pension Regulations 1995 of the Banks which
were in appeal before this Court and the special salient features of the scheme which stipulated that
an employee whose application for voluntary retirement is accepted and relieved from the Bank
shall be eligible for contributory provident fund or own contribution of provident fund and pension
in terms of the employees Pension Regulations 1995, in case of those who have opted for pension
and have put in 20 completed years of service in the Bank. The Court also referred to Regulations 28
and 29, which deals with superannuation pension and the pension on voluntary retirement
respectively. The Court also took note of the fact that all employees who have completed 20 years of
service and the amendment in Regulation 28, which was carried out in 2002 with retrospective
effect from 1.9.2000 and the amendment inserted a proviso which provided that pension shall also
be granted to an employee who opts to retire before attaining the age of superannuation but after
having served for a minimum period of 13 years in terms of any scheme that may be framed for the
purpose by the Bank's Board with the concurrence of the Government. The Court took note of the
fact that the benefits provided under Regulation 29 were not found to be attractive by the employees
and, therefore, the necessity arose for floating a special scheme i.e. VRS-2000. The grievance of the
optees in the case was that they were given the retiral benefits by the respondent- Bank under
VRS-2000 save and except the benefit of pension under Regulation 29(5). Regulation 29(5) in the
case of those banks is as follows:Assistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

"The qualifying service of an employee retiring voluntarily under this Regulation
shall be increased by a period not exceeding five years, subject to the condition that
the total qualifying service rendered by such employee shall not in any case exceed
thirty-three years and it does not take him beyond the date of superannuation".
One of the contentions canvassed by the Bank was that the Regulation 29 does not cover the persons
retired under VRS-2000 which is dehors the statutory scheme for voluntary retirement. The counter
submission on behalf of the employees was that by making provisions in the scheme that the optees
would be eligible for the benefits in addition to the ex-gratia amount, inter alia, pension as per the
Pension Regulations, 1995, the employees understood that what was contemplated was pension
under Regulation 29 and, therefore, any ambiguity in VRS 2000 ought to have been construed and
harmonized with the intention of the parties; Regulation 29 was the only regulation under the
Pension Regulations, 1995, applicable to the voluntary retirement and, therefore, Regulation 29,
ipso facto, became the terms of the contract; and that each and every paragraph of Regulation 29
can be made applicable to an optee of more than 20 years of service without coming into conflict
with any provision of the scheme; the notice period of three months in Regulation 29(3) can be
waived at the discretion of the banks. The Court posed the questions as follows:
"The principal question that falls for our determination is: whether the employees
(having completed 20 years of service) of these banks (Bank of India, Punjab
National Bank, Punjab and Sind Bank, Union Bank of India and United Bank of
India) who had opted for voluntary retirement under VRS 2000 are entitled to
addition of five years of notional service in calculating the length of service for the
purpose of the said Scheme as per Regulation 29(5) of the Pension Regulations,
1995?"
To examine the question posed, the Court thought it appropriate to examine the contract and the
circumstances in which it was made in order to see whether or not from the nature of it, the parties
must have made their bargain on the footing that a particular thing or state of things would continue
to exist.
I have already referred to Clause 6 of the Scheme, which deals with 'other benefits'. Sub-clause (3) of
Clause 6 stipulates that an employee would be entitled to get pension in terms of the State Bank of
India Employees Pension Fund Rules on the relevant date. The High Courts have placed reliance on
the second part of Rule 22(i)(a). Similar contention has been advanced before us. Per contra, Mr.
Rohtagi would submit that it is Rule 22(i)(c) which would be applicable. I find force in the said
submission, for Rule 22(i)(a) deals with the concept of retirement and 22(i)(c) deals with the
concept of retirement on request. In K. Mohandas (supra), the Rule was read into the Scheme in the
absence of any other postulate. Same is the case here and, therefore, I read the Rule to the Scheme.
Interpreting the 1995 Regulations, this Court had said that it will apply in entirety and, therefore,
benefit was extended in Rule 29(5). Be it noted, in the said Regulation, it was categorically provided
that pensionary benefits should be available to a person seeking voluntary retirement if he has put
in 20 years of service. Same is the provision here, that is, 20 years of service irrespective of the age.
As some doubts had arose, a clarificatory circular was issued on 10.1.2001. Relevant part has alreadyAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

been reproduced earlier. It has been clearly clarified that as per existing Rules, employees who have
not completed 20 years of Pensionable Service are not eligible for pension. This clarification is in
consonance with the Rules. The amendment facet which has come into existence afterwards is
absolutely inconsequential as it deals with different facets of Rule 22(i)(a). In this context, reference
to circular dated 11.1.2001 is absolutely necessitous. The relevant part reads as follows:
"In this connection, queries have been raised whether an employee who submits his
application for retirement under SBIVRS can withdraw such an application
subsequently. Corporate Centre have examined the issue and have advised that the
scheme is purely voluntary. The role of the employee is active. It is his conscious
decision and there will be no reason for his withdrawal of application at a later date.
However, there could be few, yet genuine cases where the employees would like to
withdraw the application submitted under the scheme for various reasons. It has,
therefore, been decided that the employee who has submitted an application for
retirement under SBIVRS may be permitted to withdraw the application on or before
15th February, 2001. For this purpose, the employee will have to make a written
request which must reach the Branch Manager/head of the Department/ Head of the
Unit i.e. authority to whom the application for retirement under SBIVRS has been
submitted, on or before 15.02.2001. The authority receiving the applications for
withdrawal must forward it to the competent authority immediately but not later
than the following day and obtain a confirmation to that effect from the competent
authority."
Both the circulars were almost simultaneous and both were within the knowledge of the employees
and if an employee desired to withdraw, he could have done so as time was there till 15.2.2001.
None of the respondents chose to withdraw. In the absence of withdrawal, there cannot be any trace
of doubt that the employees would be governed by the rules existing at the time of floating of the
Scheme which has to be read into the Scheme, for the Scheme clearly stipulates that the employees
availing the benefit of the Scheme would be entitled to pension as per the Pension Rules. I have
already scanned the anatomy of the Rules and I notice that there is a categorical distinction between
'retirement' and 'voluntary retirement'. In all the impugned judgments, as I find, the High Courts
have not appreciated the said distinction and applied the Rule pertaining to normal retirement. If
the decisions in K. Mohandas (supra) and Ganpat Singh Deora (supra) are read carefully, it will go a
long way to show that a voluntary retirement and retirement are distinguishable, if the
Rule/Regulations/Scheme distinguishes. In the case at hand, it is clear as day that the Rule carves
out two categories of retirement, one, normal retirement on superannuation and second, retirement
on request i.e. voluntary retirement, ordinarily called the golden handshake and, therefore, the
scheme was floated. In the instant case, as I perceive, the Scheme which is more beneficial was
provided. It had the pension and the ex-gratia. However, it had a condition as enumerated in the
Rule that if an employee had not completed 20 years of service, as per Rule 22(i)(c), he would not
get pension. In K. Mohandas (supra), if an employee has completed 20 years of service, apart from
pensionary benefits, he would also get the benefit under Regulation 29(5) as stipulated therein. To
elaborate, unless one is not entitled to pension, the other additional benefits pertaining to pension
do not arise. I may hasten to add that I am only concerned with the concept of voluntary retirementAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

under the Rules and the Scheme and as I find, the Rule cannot be interpreted as employees would
be entitled to pension. That is neither the intention nor the spirit of the Rule, which has to be read
into the Scheme as a part of it. I have been apprised with regard to the relevant details of the
respondents herein. It is as follows:
|NAME OF THE |LENGTH OF |AGE AS OF |EX-GRATIA AMOUNT PAID |
|RESPONDENT |SERVICE |31.03.2001 |(Apart from other | | | | |benefits like PF & |
| | | |Gratuity) | |Radhey Shyam |19 yrs. 8 months|59 yrs. 3 |Ex-Gratia-Rs.6,20,014/|
|Pandey |18 days |months |- | |SLP No. | | | | |3686/07 | | | | |Mihir Kumar |12 yrs. 3
months|58 yrs. |Ex-Gratia-Rs.2,46,576/| |Nandi C.A.No. |24 days |1 month |- |
|5035-5037/12 | | | | |M.P. Hallan |19 yrs. 4 months|58 yrs. 11
|Ex-Gratia-Rs.5,55,108/| |C.A. Nos. | |months 25 |- | |2287-88/10 | |days | | |R.P.
Nigam |16 yrs 6 months |56 yrs. 11 |Ex-Gratia-Rs.4,40,037/| |C.A. No. | |months 29
|- | |10813/13 | |days | | In the case at hand, unlike the decision of Ganpat Singh
Deora (supra), there is no provision for computation of broken period and, therefore,
unless an employee has completed 20 years of service, he would not be entitled to
pension. Therefore, I have no hesitation in holding that the impugned judgments and
orders passed by various High Courts, namely, High Court of Judicature at
Allahabad, Punjab & Haryana High Court at Chandigarh and High Court of Calcutta
are unsustainable in law and accordingly I set aside the same.
Consequently, the appeals are allowed and the impugned judgments and orders are
set aside. In the facts and circumstances of the case, there shall be no order as to
costs.
.............................J. [Dipak Misra] New Delhi;
February 26, 2015 IN THE SUPREME COURT OF INDIA CIVIL APPELLATE
JURISDICTION CIVIL APPEAL NO.2463 OF 2015 (ARISING OUT OF S.L.P. (C) NO.
3686 of 2007) ASSISTANT GENERAL MANAGER, STATE BANK OF INDIA & ORS.
.........APPELLANTS VERSUS RADHEY SHYAM PANDEY ....RESPONDENT WITH
C.A. NOS.2287-2288 of 2010 State Bank of India & Ors . ....... APPELLANTS
VERSUS M.P. HALLAN & ANR. ......... RESPONDENTS C.A. NOS.5035-5037 of 2012
CHAIRMAN, State Bank of India & Ors. ....... APPELLANTS VERSUS MIHIR
KUMAR NANDI & ANR. ......... RESPONDENTS AND C.A. NO. 10813 of 2013 STATE
BANK OF INDIA & ORS. ......APPELLANTS VERSUS RAMESH PRASAD NIGAM
.......RESPONDENT J U D G M E N T V. GOPALA GOWDA, J.
I had the opportunity to read the opinion of my brother Judge, Justice Dipak Misra
and I am in respectful disagreement with the opinion rendered by him in the present
appeals.
2. Leave granted in SLP (C) No. 3686 of 2007. The appellant Bank-the State Bank of
India, on the recommendation of the Indian Banks Association (in short "IBA"),Assistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

introduced a scheme titled 'SBI Voluntary Retirement Scheme, 2000 (in short
'SBI-VRS'). This scheme was introduced by SBI despite there being provisions in the
State Bank of India Employees' Provident Fund Rules, for its employees to avail
premature retirement/resignation/voluntary retirement. SBI-VRS was in operation
for a limited period and was introduced by the appellant Bank with package for the
purpose specified in the scheme.
3. It is the claim of the appellant Bank that clause 6(c) of the SBI-VRS provided for
"other benefits" which is, "Pension in terms of the SBI Employees' Pension Fund
Rules on the relevant date (including the commuted value of pension).
4. It is the further claim of the appellant Bank that the employees who applied for
retirement under SBI-VRS will be bound by the circular dated 11.01.01, issued by the
competent authority viz., Dy. Managing Director of the Bank clarifying that:-
".... However, as per existing rules employees who have not completed 20 years of
pensionable service are not eligible for pension."
The respondents, who were employees of the State Bank of India, applied for voluntary retirement
under SBI-VRS on different dates between 15.1.2001 and 31.1.2001. Their applications got accepted
and they stood retired from the bank service with effect from 31.3.2001.
5. In the meanwhile, a parallel development had taken place in the appellant Bank with respect to its
employees' Pension Fund Rules. On 31.1.2001, the age of normal retirement of the employees
working in the appellant Bank was extended from 58 years to 60 years. Accordingly, the Service
Rule as well as Rule 22(i)(a) of the SBI Pension Fund Rules was amended wherein it was added that
a member would be entitled to pension :
"..... if he is in the service of the bank on or after 22.5.1998, after having completed 10
years pensionable service provided that he has attained the age of 60 years."
6. The respondents made representations where they sought pension under Rule 22(i)(a) and were
advised by the bank that they were not eligible for pension under Rule 22(i)(a). The respondents
filed Writ Petitions before respective High Courts of their jurisdictions namely, the High Court of
Judicature at Allahabad, High Court of Judicature at Kolkata and the High Court of Punjab and
Haryana, which were allowed by both the Single Bench and the Division Bench of the High Court.
Hence, the appeals are filed by the appellant Bank before this Court.
7. I am in respectful disagreement with the opinion rendered by my brother Judge in the present
appeals. However, I intend to assign my reasons for the same, based on certain relevant
considerations. The issues arising for deliberation in this case are as under:
Whether the respondents in the present appeals are to be considered for pension
benefits under the provisions of Rule 22(i)(c) of the State Bank of India Employee'sAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

Pension Fund Rules alone, as claimed by the appellant Bank?
Whether the State Bank of India is entitled to retain its own employment Rules which
is not in consonance with the subsequent amendments made in the Employee's
Pension Regulations, 1995 in all the public sector undertaking Banks in the light of
the correspondence between the Finance Ministry and Indian Banks Association?
Under what legal provisions will the respondent employees be entitled to make their
claims for pension?
Answer to Point no. 1
8. Pension benefits accrue upon an employee on retirement from his employment. Therefore, we
first need to assess the definition of 'retirement' before answering the question on pension benefits
for the respondents herein. Neither the State Bank of India Act, 1955 nor the State Bank of India
Employees' Pension Fund Rules defines retirement. Therefore, I am inclined to read the definition
of retirement as has been mentioned in the State Bank of Patiala Employee's Pension Regulation
1995 which provides for the definition of retirement from employment since the same is pari
materia to the Employees' Pension Regulation 1995. Section 2(y) of the Regulation reads thus:
"2(y) "retirement" means cessation from the Bank's service-
On attaining the age of superannuation specified in Service Regulations or
Settlements;
On voluntary retirement in accordance with provisions contained in regulation 29 of
these regulations;
On premature retirement by the Bank before attaining the age of superannuation
specified in Service Regulations or Settlements."
In the present case, however, clause (b) of the definition will also be read in the light of the amended
Regulation 28 which was intended to provide relief to the employees seeking voluntary retirement
under the VRS 2000, after providing 15 years of pensionable service. Thus, from the above
definition, one is left with no doubt that the employees who availed VRS 2000 have 'retired' from
the Bank as per the definitions.
It is pertinent now to highlight the object and purpose of the SBI-VRS. At a meeting conducted on
13.6.2000 between the Finance Minister and the Chief Executives of the Public Sector Banks, the
human resource and manpower planning in Public Sector Banks was reviewed. A committee was
constituted to examine the issues confronting the Public Sector Banks in this regard and to suggest
suitable remedial measures. The committee had observed that high establishment costs and low
productivity in Public Sector Banks affect their profitability. It was hence, necessary to convert their
human resources into assets compatible with business strategies through a variety of measuresAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

including constant upgradation of skills, achieving proper age and skill profile, creating
opportunities for lateral as well as vertical career progression and including fresh skilled personnel
with technical and professional skills for new business opportunities.
9. The data available with IBA indicated that 43% of employees in Public Sector Banks are in the
46+ age group and only 12% are in the 25-35 years age group. This pattern of jobs in the public
sector Banks, according to the committee, had serious implications for the Banks with reference to
mobility, training, development of skills and succession plans for high level positions. This, coupled
with excess manpower wherever it exists, would come in the way of induction of new skills and
proper career progression.
The Committee had therefore recommended introduction of a Voluntary Retirement Scheme that
would assist the Bank in their effort to optimize their human resources and achieve a balanced age
skills profile in keeping in mind with the business strategies. The Banks were further advised by the
IBA to implement the scheme in right earnest.
10. From the memorandum of the Voluntary Retirement Scheme presented by the appellant Bank
itself, it is clear that the SBI-VRS scheme was introduced for the purpose of business enhancement
and profitability of the Bank itself and not for the benefits of the employees per se. The intention of
the Public Sector Banks including the appellant Bank, in introducing the VRS 2000, is rightfully
highlighted in the decision of this Court in Bank of India v. K. Mohandas & Ors.[16] which read as
under:
"36. ...........The banks decided to shed surplus manpower. By formulation of the
special scheme (VRS 2000), the banks intended to achieve their objective of
rationalizing their force as they were overstaffed. The special Scheme was, thus,
oriented to lure the employees to go in for voluntary retirement. In this background,
the consideration that was to pass between the parties assumes significance and a
harmonious construction to the Scheme and the Pension Regulations, therefore, has
to be given".
(emphasis supplied) In ordinary situation, an employee who retires either on reaching the age of
superannuation, or by request in writing after completing the prescribed number of years, become
eligible to pension under the State Bank of India Employee's Pension Rules. The pertinent
provisions under the SBI Employees Pension Rules relating to pension of employees, read as under:
"22. (i). A member shall be entitled to a pension under these rules on retiring from
the Banks service-
a). After having completed twenty years' pensionable service provided that he has
attained the age of fifty years or if he is in the service of the Bank on or after 1.11.93,
after having completed ten years pensionable service provided that he has attained
fifty eight years or if he is in the service of the Bank on or after 22.05.1998, after
having completed ten years pensionable service provided that he has attained the ageAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

of sixty years.
XXX XXX XXX
c). After having completed twenty years pensionable service, irrespective of the age
he shall have attained at his request in writing. "
11. This situation is altered temporarily by the introduction of the SBI- VRS. Therefore, it is also
important to understand the framework of SBI- VRS. In the absence of the SBI-VRS, the
respondents had the option of seeking voluntary retirement under Rule 22(i)(c) which in fact, the
respondents did not avail. Instead they availed the SBI-VRS. It is therefore pertinent to see how the
SBI-VRS was functioning and what the respondents seeking SBI-VRS might have reasonably
foreseen while availing the scheme. When the application of voluntary retirement of respondent
Radhey Shyam Pandey was accepted by the appellant Bank on 18.3.2001, he still had about 9
months services left and he was 59 years and 3 months old.
As on 31st March, 2001, when his voluntary retirement from service became effective, he had been
on pensionable service for 19 years, 9 months and 18 days.
12. If the respondent had chosen to retire by superannuation after attaining 60 years of age which
was the normal age of retirement, he would have put in a little more than 20 years of pensionable
service. He consequently, would have become eligible to pension. However, when he retired on
31.3.2001, he still had 2 and months short to complete 20 years of service. It is pertinent to
understand what prompted him to opt for the SBI-VRS at this stage.
13. In clause 5 of the scheme, the incentive of the Voluntary Retirement Scheme is mentioned. It is
an ex-gratia payment of 60 days salary for every year of completed service. Since, the respondent
had finished 20 years of service approximately, he would have been entitled to 40 months of salary
as ex-gratia.
Pension on the other hand, is calculated as half month's salary per month. Therefore, by utilizing the
SBI-VRS, although the respondent had given up 9 months service still left, he would have gained 40
months incentive. To add to this, he becomes eligible for pension, then he in addition to ex-gratia,
will get half month's salary as his pension from the time he retires. This can be considered as a good
bargain from availing the SBI- VRS. On reasonable presumption, it can be ascertained that it is this
benefit provided by the SBI-VRS through ex-gratia payment along with pension which prompted the
employees in availing the benefits of the scheme rather than retiring on superannuation under the
Rules.
14. On the other hand, if he is not entitled to pension, then availing SBI- VRS is unwise since the
respondent has given up his half month's salary worth pension for his working period in return of
40 months' salary.Assistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

SBI-VRS is admittedly a contract between the Bank and its employees as has been recognized in the
case of Bank of India v. K. Mohandas case mentioned supra. The application of the Voluntary
Retirement Scheme meant that the Bank employees agreed with the Bank that it would be bound by
the scheme thereby entering into a contract. However, clause 6(c) of SBI-VRS states:
"6. Other Benefits :
    XXX          XXX      XXX
    XXX          XXX      XXX
(c) Pension in terms of State Bank of India Employees' Pension Fund Rules on the
relevant date (including commuted value pension)."
15. Considering that the incentives of SBI-VRS are distinct from the benefits provided under Rule
22(i)(c) of the State Bank Employees Pension Fund Rules and also, that Clause 6(c) of SBI-VRS does
not specifically state that the pension benefits are to be provided under rule 22(i)(c) of SBI
Employees Pension Fund Rules, the claim for pension by the respondents cannot be decided solely
on the basis of the provision of Rule 22(1)(c) of the State Bank of India Employees' Pension Rules.
Answer to Point no. 2
16. It has been claimed by the appellant Bank that State Bank of India has its own Pension Rules
that are different from the Employees' Pension Regulations 1995 which operate in the other Public
Sector Banks. The claim made by the appellant Bank that it is not bound by the Pension Regulations
1995, is premised on the assumption that the employees of the State Bank of India form a distinct
class of employment from the employees of the other Public Sector Banks on the ground of
reasonable and intelligible differentia.
This conclusion by the appellant Bank is not warranted since all the employees of Public Sector
Bank forms one homogenous class since all the fourteen Public Sector Banks which were formed
under the Banking Companies (Acquisition and Transfer of Undertakings) Act, 1970 and the six
banks under the Banking Companies (Acquisition and Transfer of Undertakings) Act, 1980, are
subject to the control of the Central Government. It is pertinent to note that Section 19 of both- The
Banking Companies (Acquisition and Transfer of Undertakings) Acts of 1970 and 1980 and Section
50 of the State Bank of India Act, 1955, vest the power on the Central Government to make
consistent rules for all the Public Sector Banks.
Section 50(2)(o) of State Bank of India Act, 1955 reads thus:
"50. Power of Central Government to make regulations: (1) The Central Board may,
after consultation with the Reserve Bank and with the previous sanction of the
Central Government [by notification in the Official Gazette] make regulations, notAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

inconsistent with this Act and the rules made thereunder, to provide for all matters
for which provision is expedient for the purpose of giving effect to the provisions of
this Act.
(2) In particular and without prejudice to the generality of the foregoing power, such
regulation may provide for-
XXX XXX XXX
(o) The establishment and maintenance of superannuation, pension, provident or
other funds for the benefit of the employees of the State Bank or of the dependent of
such employees or for the purposes of the State Bank, and the granting of
superannuation allowances, annuities and pensions payable out of any such fund;]"
17. The Central Government through a letter dated 5.9.2000 directed the Indian Banks Association
to formulate a uniform norm for pensions for employees voluntarily retiring under SBI-VRS 2000
and the same was formulated by the Indian Banks Association on 11.12.2000. Therefore, the State
Bank of India is bound by the directions issued in this regard by the Indian Banks Association under
Section 50(2)(o) of the State Bank of India Act, 1955.
18. The appellant Bank, State Bank of India is an instrumentality of the State as has been held by
this Court in the case of Bank of India & Ors. v. O.P. Swarnakar & Ors.[17] which reads as under:
"48...But the State Bank of India as also the nationalized banks are "States" within
the meaning of Article 12 of the Constitution of India. The services of the workman
are also governed by several standing orders and bipartite settlements which have the
force of law. The banks, therefore, cannot take recourse to "hire and fire" for the
purpose of terminating the services of the employees. The banks are required to act
fairly and strictly in terms of the norms laid down therefor. Their actions in this
behalf must satisfy the test of Articles 14 and 21 of the Constitution of India.
Therefore, the appellant Bank cannot engage in acts which are antithetical to
equality. In the case of E.P. Royappa v. State of Tamil Nadu[18], the constitution
Bench of this Court held as under:
"Equality is a dynamic concept with many aspects and dimensions and it cannot be
"cribbed cabined and confined" within traditional and doctrinaire limits. From a
positivistic point of view, equality is antithetic to arbitrariness. In fact equality and
arbitrariness are sworn enemies; one belongs to the rule of law in a republic while the
other, to the whim and caprice of an absolute monarch. Where an act is arbitrary it is
implicit in it that it is unequal both according to political logic and constitutional law
and is therefore violative of Art. 14, and if it affects any matter relating to public
employment, it is also violative of Art. 16. Arts. 14 and 16 strike at arbitrariness in
State action an( ensure fairness and equality of treatment. They require that StateAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

action must be based on valent relevant principles applicable alike to all similarly
situate and it must not be guided by any extraneous or irrelevant considerations
because that would be denial of equality. Where the operative reason for State action,
as distinguished from motive inducing from the antechamber of the mind, is not
legitimate and relevant but is extraneous and outside the area of permissible
considerations, it would :amount to mala fide exercise of power and that is hit by
Arts. 14 and 16."
19. Even though the SBI-VRS is in the nature of contract, it has to be interpreted under the scanner
of Article 14 of the Constitution of India. In the process of implementation of the Voluntary
Retirement Scheme on its own terms, the appellant Bank being an associate Bank of the Indian
Banks Organization, it cannot set rules and procedures which deviates from the standard and
safeguards set by the Central Government in consensus with the Indian Banks Association.
20. It is the claim of the appellant Bank that the SBI-VRS provides the optees with handsome
ex-gratia amount on retirement. It does not however mean that the appellant is entitled to deprive
the respondent of his pension on the ground that he has been given handsome ex-gratia amount
under the scheme. Pension received by an employee upon his retirement is not a bounty as has been
held in the case of Deokinandan Prasad v. State of Bihar[19] as under:
"Pension is not a bounty payable on the sweet will and pleasure of the Government
and that, on the other hand, the right to pension is a valuable right..."
21. The same proposition of law was reiterated by the Constitution Bench of this Court in the case of
D.S. Nakara v. Union of India[20] wherein this Court held as under:
"20. The antiquated notion of pension being a bounty, a gratuitous payment
depending upon the sweet will or grace of the employer not claimable as a right and,
therefore, no right to pension can be enforced through court has been swept under
the carpet by the decision of the Constitutional Bench in Deokinandan Prasad v. State
of Bihar wherein this court authoritatively ruled that pension is a right and the
payment of it does not depend upon the discretion of the Government but is
governed by the rules and a government servant coming within rules is entitled to
claim pension. It was further held that the grant of pension does not depend upon
anyone's discretion. It is only for the purpose of quantifying the amount having
regard to service and other allied matters that it may be necessary for the authority to
pass an order to that effect but the right to receive pension flows to the officer not
because of the order but by the virtue of rules. This view was reaffirmed in State of
Punjab v. Iqbal Singh."
(emphasis supplied) Therefore, depriving the respondents seeking SBI-VRS of their right to pension
solely on the ground that they have availed voluntary retirement under a scheme while providing
less than 20 years of service and also on the ground that they have been provided with handsome
ex-gratia amount on their retirement, is arbitrary and attracts the wrath of Article 14 of theAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

Constitution of India. This is particularly so, because SBI-VRS was introduced for the benefit of the
Public Sector Banks which included the appellant Bank. It was not a welfare scheme which provided
the respondents with multiple offers to choose from. Therefore, the appellant Bank at this stage,
cannot absolve itself from the responsibility of granting the respondents what is due to them by
virtue of providing pensionable services, on the pretext of having provided ex-gratia amount.
22. In another case of Roop Chand Adlakha v. Delhi Development Authority[21], this Court held as
under:
"To overdo classifications is to undo equality. The idea of similarity or dissimilarity of
situations of persons, to justify classifications, cannot rest on merely differentia
which may, by themselves be rational or logical, but depends on whether the
differences are relevant to the goals sought to be reached by the law which seeks to
classify. The justification of the classification must needs, therefore, to be sought
beyond the classification. All marks of distinction do not necessarily justify
classification irrespective of the relevance or nexus of objects sought to be achieved
by the law imposing the classification."
(emphasis supplied)
23. In the case on hand, the classification between employees who have voluntarily retired under the
SBI-VRS and those who have retired under the same scheme introduced by the other Public Sector
Banks, is not rational since they constitute the employees of the appellant Bank into a distinct class
on the basis of the VRS 2000 scheme introduced by the appellant Bank and the same scheme
introduced by other Public Sector Banks, with no intelligible differentia. The payment of ex-gratia
cannot be held against the employees since it cannot be expected of a person to give up his service
before superannuation without reasonable incentives. What the appellant Bank intends to show as
the benefit of the employees seeking VRS under the scheme, is actually meant for the benefit of the
appellant Bank itself.
24. In setting up schemes such as the SBI-VRS, the appellant Bank, which is the instrumentality of
the State under Article 12 of the Constituion, cannot deviate from its constitutional duties as has
been held in the case of D.S. Nakara v. Union of India (supra) :
"36. Having set out clearly the society which we propose to set up, the direction in
which the State action must move, the welfare State which we propose to build up,
the constitutional goal of setting up a socialist State and the assurance in the
Directive Principles of State Policy especially of security in old age at least to those
who have rendered useful service during their active years, it is indisputable, nor was
it questioned, that pension as a retirement benefit is in consonance with and in
furtherance of the goals of the Constitution. The goals for which pension is paid
themselves give a fillip and push [pic]to the policy of setting up a welfare State
because by pension the socialist goal of security of cradle to grave is assured at least
when it is mostly needed and least available, namely, in the fall of life.Assistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

25. Moreover, this decision of the appellant Bank to distinguish between two sets of employees, goes
against Article 39 of the Constitution of India which directs the State to make policies to ensure
equal pay for equal work. The appellant Bank being an instrumentality of the State, is not permitted
to make such discriminations. Hence, the appellant Bank is liable to implement the amendments
made by the Indian Banks Association to accommodate the grant of pension to those employees who
sought voluntary retirement through SBI-VRS.
Answer to point no. 3
26. Under Rule 22 of the State Bank of India Employees' Pension Rules, an employee's entitlement
to pension accrues on retiring from the Bank service on one of the following conditions:
Under Rule 22(1)(a):
After having completed 20 years pensionable services provided that he has attained
the age of 50 years OR If he was in the service on or after 1.11.93, then after having
completed 10 years of service provided that he has attained the age of 58 years, OR If
he was in the service on or after 22.5.98, then after having completed 10 years
pensionable service provided, that he has attained the age of 60 years.
Under Rule 22(1)(c):
After 20 years of pensionable service, at his request in writing (where the entitlement
is to proportionate pension).
On the other hand, the un-amended Employee's Pension Regulations, 1995 provide
for pension under the following condition:
Regulation 28 reads as under:
"28. Superannuation Pensions:-
Superannuation pension shall be granted to an employee who has retired on his
attaining the age of superannuation specified in the Service Regulations and
Settlements."
Regulation 29 reads as under:
"29. Pension on Voluntary Retirement:
On or after the 1st day of November, 1993 at any time, after an employee has
completed twenty years of qualifying service he may, by giving notice of not less than
three months in writing to the appointing authority retire from service; ......"Assistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

27. It can be observed that the State Bank of India Employees' Pension Rules and the un-amended
Employee's Pension Regulation, 1995 are consistent in so far as both Rules set the eligibility of
pension on voluntary retirement service only after 20 years of pensionable service. However, it is
imperative to understand the amendment which the correspondence between the Finance Ministry
and Indian Banks Association, following the introduction of the SBI-VRS, brought about.
28. By a letter (F.no.4/8/4/2000-IR), dated 5.9.2000, written by the Finance Ministry to the Indian
Banks Association, the Ministry recommended to the IBA to suggest amendments to Regulation 29
of the Pension Regulations in the following terms:
"I am directed to refer to this Division's Letter no. 11/1/99 IR dated 29-8- 2000
conveying the Government's no objection for circulation of Voluntary Retirement
Scheme in public sector banks. The Scheme, inter alia, provides that employees with
15 year of service or 40 years of age shall be eligible to take voluntary retirement
under the Scheme. As per the provisions contained in Regulation 29 of the Pension
Regulations, an employee can take voluntary retirement after 20 years of qualifying
service and thereafter becomes eligible for pension. Thus employees having rendered
15 years of service or completing 40 years of age, but not having completed 20 years
of service shall not be eligible for pensionary benefits on taking voluntary retirement
under the Scheme.
In order to ensure that such employees do not lose the benefits of pension, IBA may
work out modalities and suggest amendments, if any, required to be made in the
Pension Regulations to ensure that these employees also get the benefits of pension".
Pursuant to this correspondence, the Indian Banks Association suggested an amendment to the
Regulations in the following terms:
"INDIAN BANKS ASSOCIATION STADIUM HOUSE, 6th FLOOR BLOCK 2 VEER
NARIMAN ROAD MUMBAI- 400020 PD/CIR/76/G2/G4/ December 11, 2000
VOLUNTARY RETIRMENT SCHEME IN PUBLIC SECTOR BANKS AMENDMENTS
TO BANK (EMPLOYEES') PENSION REGULATIONS, 1995 Designated officers of all
Public Sector Banks.
Dear Sirs, Please refer to our circular letter no. PD/CIR/76/G4/993 dated 31st
August 2000 convening the 'No Objection' of the Government in banks adopting and
implementing a voluntary retirement scheme for employees on the lines of what was
contained in the Annexure to the circular. As per the scheme, an employee who is
eligible and applies for voluntary retirement is entitled for the benefits of CPF,
Pension, Gratuity and encashment of accumulates privilege leaves, as per rules. Bank
(Employees') Pension Regulations, 1955 do not have provisions enabling payment of
pension to an employee who retires before attaining the age of superannuation except
under circumstances as in Regulations 29, 30, 32 andAssistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

33. We had, therefore, taken up with the Government the need to incorporate
necessary provisions in the Pension Regulations by way of amendments to
Regulation 28 so that employees who retire as above under special/ ad hoc schemes
formulated by the banks, after serving for a prescribed minimum period would be
eligible for pro rata pension. Government of India has after examining the proposal
conveyed its approval and desired that IBA advise banks to make necessary
amendments to their Pension Regulations as in the Annexure. We request banks to
take note accordingly.
Please note that with the above amendments, employees who apply for voluntary
retirement after having rendered minimum 15 years of service under a special/ ad
hoc scheme formulated with the specific approval of the Government and the Board
of Directors will be eligible for pro rata pension for the period of service rendered as
they are to retire on attaining the age of superannuation on that date.
Yours Faithfully, Sd/-
(Allen C A Pareira) PERSONNEL ADVISER"
Pursuant to this suggestion, Regulation 28 of Employees Pension Regulations, 1995 was amended to
include the proviso with retrospective effect from 1.9.2000 as under:
"Provided that pension shall also be granted to an employee who opts to retire before
attaining the age of superannuation, but after having served for a minimum period of
15 years in terms of any scheme that may be framed for the purpose by the Bank's
Board with the concurrence of the Government."
This Court, in the case of Bank of India v. K. Mohandas (supra) further clarified the intention
behind amendment of Regulation 28 and its retrospective application. The relevant paragraphs read
as under:
"40.........The amendment in Regulation 28, as is reflected from the afore referred
communication, was intended to cover the employees who had rendered 15 years'
service but not completed 20 years' service. ....
41. Even if it be assumed that by insertion of the proviso in Regulation 28 (in the year
2002 with effect from 1-9-2000), all classes of employees under VRS, 2002 were
intended to be covered, such amendment in Regulation 28, needs to be harmonized
with Regulation 29......"
29. While answering Point no, 2 in favour of the respondents, I held that the State Bank of India
should implement the amendment made to Rule 28 of the Employees Pension Regulation in
granting pension to the employees seeking voluntary retirement under SBI-VRS.Assistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

I therefore, answer point no 3 in favour of the respondents and direct the appellant Bank to grant
pension to the employees seeking voluntary retirement under the SBI-VRS after completing 15 years
of pensionable service. Therefore, the respondent Radhey Shyam Pandey, having completed 19 years
8 months and 18 days of service, respondent M.P. Hallan, having completed 19 years and 4 months
of service and the respondent R.P. Nigam, having completed 16 years and 6 months of service,
become eligible for pension as per the amended Regulation 28 of Employees Pension Rules, 1995.
By virtue of power vested in this Court under Article 142 Constitution of India, I hold that the
pension relief is also extended to all the other employees who have availed SBI-VRS 2000 after
having completed 15 years of pensionable service. Thus, C.A. No.@ SLP (C) No.3686 of 2007, C.A.
Nos.2287- 2288 of 2010 and C.A. No. 10813 of 2013 are dismissed.
30. The C.A. Nos.5035-5037 of 2012 of the appellant Bank succeed in that respondent Mihir Kumar
Nandi, having completed 12 years 3 months and 4 days of service, becomes ineligible for pension
benefits.
31. All the appeals are disposed of accordingly. No costs.
......................................................... J.
[V. GOPALA GOWDA] New Delhi, February 26, 2015
-----------------------
[1]    2002 (2) SLR 716
[2]    (2003) 2 SCC 721
[3]    AIR 1993 SC 1601
[4]    (1997) 1 SCC 256
[5]    (1998) 8 SCC 30
[6]    (2003) 11 SCC 572
[7]    (2006) 3 SCC 708
[8]    (2005) 12 SCC 508
[9]    (2005) 4 SCC 272
[10]   (2004) 6 SCC 765
[11]   (2005) 3 SCC 636
[12]    (2009) 3 SCC 217
[13]    (2009) 5 SCC 313
[14]    (1900) AC 260
[15]    2014 (8) SCALE 397
[16]   (2009) 5 SCC 313
[17]   (2003) 2 SCC 721
[18]   AIR 1974 SC 555
[19]   1971 SCR 634
[20]   (1983) 1 SCC 305
[21]   1988 (Supp 3) SCR 253
-----------------------Assistant G.M. State Bank Of India & Ors vs Radhey Shyam Pandey on 26 February, 2015

