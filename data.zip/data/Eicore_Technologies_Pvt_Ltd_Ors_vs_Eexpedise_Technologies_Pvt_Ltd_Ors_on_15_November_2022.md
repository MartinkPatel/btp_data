Eicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies
Pvt. Ltd. & Ors. on 15 November, 2022
Author: Jyoti Singh
Bench: Jyoti Singh
                                       Neutral Citation Number: 2022/DHC/004831
                          $~
                          *     IN THE HIGH COURT OF DELHI AT NEW DELHI
                          %                                  Date of decision: 15th November, 2022
                          +     CS(COMM) 1146/2018
                                EICORE TECHNOLOGIES PVT. LTD.
                                & ORS.                               ..... Plaintiffs
                                             Through: Mr. Jayant Mehta, Senior
                                             Advocate with Mr. J. Sai Deepak,
                                             Mr. Debarshi Dutta, Ms. Manvi Adlakha and
                                             Mr. Amrit Singh, Advocates.
                                                    versus
                                EEXPEDISE TECHNOLOGIES PVT. LTD.
                                & ORS.                                ..... Defendants
                                             Through: Mr.       Anil       Sapra,   Senior
                                             Advocate, with Ms. Bitika Sharma,
                                             Ms. Vrinda Pathak and Mr. Vikram Singh
                                             Dalai, Advocates for D-1 to D-7 and D-12 to
                                             D-19.
                                             Mr. Divyakant Lahoti and Mr. Parikshit
                                             Ahuja, Advocates for D-8 and D-9.
                                             Mr. R.R. Jangu, Advocate for D-10 and
                                             D-11.
                                CORAM:
                                HON'BLE MS. JUSTICE JYOTI SINGH
                                                         JUDGEMENT
JYOTI SINGH, J.
I.A. 16454/2021 (for filing additional documents, by Plaintiffs)
1. Present application has been preferred on behalf of the Plaintiffs under Order XI Rule 1(5) read
with Section 151 of the CPC, 1908 as amended by the Commercial Courts, Commercial Division and
Commercial Appellate Division of High Courts Act, 2015 (hereinafter referred to as the 'Act') seeking
leave of this Court to file additional documents.Eicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies Pvt. Ltd. & Ors. on 15 November, 2022

Neutral Citation Number: 2022/DHC/004831
2. Plaintiffs have filed the present suit seeking injunction restraining the Defendants from infringing
Plaintiffs No. 1 and 5' copyright in their original literary work 'HealthBuzz', Plaintiffs' confidential
data, information and trade secrets and from printing, publishing, reproducing, etc. or dealing, in
any manner, with the literary work, amongst other reliefs.
3. Summons were issued in the suit on 28.09.2018. Upon being served, Defendants filed their
written statements and subsequent thereto replications have been filed by the Plaintiffs. Most of the
parties have filed their affidavits of admission and denial of documents. Issues are yet to be framed
in the suit.
4. It is Plaintiffs' case that Defendants No. 4, 6, 8, 10, 12 and 14 to 19 are ex-employees of Plaintiffs
No. 1 to 4 and during the course of their employment, they had access to and acquired significant
knowledge of Plaintiffs' proprietary software 'HealthBuzz', its source code and all other confidential
data and trade secrets. Misusing confidential information, source code, trade secrets etc.,
Defendants clandestinely set up competing business entities in March, 2016, while they were
employed with the Plaintiffs. Taking undue advantage of their association with the Plaintiffs,
Defendants also resorted to diverting clients and business of the Plaintiffs to Defendants No. 1 to 3
and created a counterfeit software of 'HealthBuzz'.
5. By the present application, Plaintiffs seek to place on record the following additional documents
which have been bifurcated for the ease of reference by the Plaintiffs in Section 'A' and Section 'B':
Section 'A' I. Documents available in public domain which would lend support to the
Plaintiffs' averments that the Defendants are dealing with either HealthBuzz or
HealthIns.
(a) Audited financial statements of the Defendant No. 1 for the financial Neutral
Citation Number: 2022/DHC/004831 entirely generated from IT support services
provided by the Defendant No. 1.
(b) Similarly, audited financial statements of the Defendant No. 1 for the financial
year ending on 31 March 2020 which showcases that its revenue was entirely
generated once again from IT support services provided by the Defendant No. 1.
(c) Screenshots of the website of the Defendant No. 1 regarding the health insurance
software as on 16 August 2021.
II. Correspondence/documents in respect of parallel companies incorporated by the Defendants,
namely Exure Technologies Pvt Ltd in India (formerly known as Exaosis Technologies Pvt Ltd) and
Enoviq Technologies Pte Ltd in Singapore (formerly known as Exaosis Technologies Pte Ltd).Eicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies Pvt. Ltd. & Ors. on 15 November, 2022

(d) In early 2020, the Plaintiffs received a whistle blower complaint that the Defendants discretely
set up yet another company in the names of Exaosis India and Exaosis Singapore.
(e) Screenshots disclosing the domain names of Exure Technologies Pvt. Ltd. (hereinafter referred
to as "Exaosis India") and Enoviq Technologies Pte. Ltd. (hereinafter referred to as "Exaosis
Singapore").
(f) Documents disclosing the details of the owner of the domain name www.exaosis.com (being
Defendant No. 13, Ms. Himani Sharma) as well as that of the Defendant Nos. 1 and 2.
(g) Documents evidencing the initial and subsequent proprietor of the trademark "Ayushmat".
(h) Audited financial statement of Exaosis India for the year ending 31 March 2019 which reflected
trade payables of INR 1,12,500 to Defendant No. 10, Mr. Sunil Kumar.
(i) LinkedIn profiles and profiles uploaded on recruitment websites such as www.naukri.com of
various employees of the Defendant No. 1 which were transferred to payroll of Exaosis India or
having worked on HealthBuzz.
(j) Audited financial statement of Exaosis India for the year ending 31 March 2020 which showed
that the total revenue was generated from IT support services provided by Exaosis India in respect
of Plaintiffs' HealthBuzz or a counterfeit of HealthBuzz along with the Director's Report which
confirmed that 100% of the turnover of Exaosis India was on account of software support services
and software development services.
(k) Screenshots from www.exaosis.com regarding the health insurance solution of Exaosis India and
Exaosis Singapore.
(l) Plaintiffs' legal notices dated 9 February 2021 to Exaosis Singapore and eBaoTech Corporation
for seeking information and documents which would enable the Plaintiffs to determine the extent to
which Exaosis Singapore was misusing the Plaintiffs' software HealthBuzz either through eBaoTech
Corporation (Singapore) or on its own.
Neutral Citation Number: 2022/DHC/004831
(m) Reply of Exaosis Singapore dated 5 March 2021 denying the Plaintiffs' allegations without
providing any information/documents as requested for.
(n) Cease-and-desist notice dated 6 July 2021 issued by the Plaintiff No. 1 to Exaosis India regarding
infringement of the intellectual property rights in HealthBuzz and its source code and other
infringing material.
(o) Second notice dated 13 July 2021 issued by the Plaintiff No. 1 to Exaosis India requesting for
certain information and documents.Eicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies Pvt. Ltd. & Ors. on 15 November, 2022

(p) Reply dated 28 July 2021 sent by Exaosis India to the cease-and-desist notice dated 6 July 2021
issued by the Plaintiff No. 1.
(q) Reply dated 28 July 2021 sent by Exaosis India to the legal notice dated 13 July 2021 issued by
the Plaintiff No. 1.
III. Plaintiffs' notices to the Defendants highlighting breach of the Interim Order dated 28
September 2018 and the Defendants' notices alleging defamation and breach of Ad-Hoc Agreement
(r) Cease-and-desist notice issued by the Plaintiffs to the Defendants on 13 July 2019 in order to
restrain from (a) marketing HealthIns; (b) dealing with HealthBuzz; (c) representing themselves as
agents of the Plaintiffs; and (d) dealing with the present clients of the Plaintiffs.
(s) Defendants' reply dated 15 July 2019 to the cease-and-desist notice issued by the Plaintiffs
denying all allegations.
(t) Plaintiffs' notice for discovery and production of documents to the Defendants dated 1 August
2019.
(u) Defendants' reply to the Plaintiffs' notice for discovery and production of documents to the
Defendants.
(v) Notice issued by the Defendants to the Plaintiffs on 2 September 2019 alleging that the Plaintiffs
were writing frivolous e-mails to Defendants' several customers.
(w) Notice issued by the Defendants to the Plaintiffs on 2 September 2019, alleging breaches under
the Ad-Hoc Agreement.
(x) Notice issued by the Defendants to the Plaintiffs on 9 September 2019 alleging that the Plaintiffs
were writing frivolous e-mails to Defendants' several customers.
(y) Notice of rescission issued by the Plaintiff No. 1 (through its advocates) to some of the
Defendants on 11 September 2019, notifying them that the Ad-Hoc Agreement (and connected
agreements) were vitiated by fraud and misrepresentation.
(z) Defendants' reply dated 28 September 2019 to the notice of rescission issued by the Plaintiff No.
1 objecting to the rescission of the Ad-Hoc Agreement (and connected agreements).
Neutral Citation Number: 2022/DHC/004831 (aa) Notice issued by the Defendants to the Plaintiffs
on 10 October 2019 alleging that the Plaintiffs were writing frivolous e-mails to Defendants' several
customers.
(bb) Plaintiffs' reply dated 16 October 2019 to the Defendants' second notice of 2 September 2019
regarding the purported breaches of the Ad- Hoc Agreement wherein it was reiterated that theEicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies Pvt. Ltd. & Ors. on 15 November, 2022

Ad-Hoc Agreement (and connected agreements) stood vitiated due to fraud and misrepresentation.
(cc) Plaintiffs' reply dated 16 October 2019 to the Defendants' defamation notice, inter- alia pointing
out that the notice was bereft of particulars and calling upon the Defendants to share copies of the
allegedly defamatory communications.
(dd) Plaintiffs' letter dated 7 January 2020 issued to the Defendants, refuting the Defendants'
contentions.
(ee) Defendants' letter dated 21 February 2020 issued to the Plaintiffs, refusing the Plaintiffs' offer
to return the monies already received under the Ad-Hoc Agreement.
IV. Correspondence exchanged with Aditya Birla Health Insurance Co Ltd ("ABHI") in respect of the
Defendants' engagement with them. (ff) Annual Report on Health Insurance published by ABHI on
its website for the financial year 2019-20 wherein at page 75, ABHI refers to HealthBuzz as one of
the IT systems used by it.
(gg) E-mails dated 16 September 2019, 7 October 2019 and 25 October 2019 exchanged between the
Plaintiffs and ABHI which confirmed that the Defendants continued to provide services in respect of
HealthBuzz to ABHI.
(hh) Notice dated 29 April 2020 issued by the Plaintiffs to ABHI for invocation of arbitration
agreement in order to settle all disputes.
(ii) ABHI's reply dated 28 May 2020 to the Plaintiffs denying its engagement with the Defendants in
respect of HealthBuzz. (jj) Plaintiffs' reply dated 31 May 2020 to ABHI's reply dated 28 May 2020.
V. Documents in respect of the HealthBuzz-Claims System supplied by the Defendants to Liberty
General Insurance Co Ltd ("Liberty") (kk) Software License and Support Agreement dated 16
December 2014 executed between Plaintiff No 1 and Liberty wherein Liberty's business
requirements for implementing HealthBuzz in four different phases was captured.
(ll) Addendum Agreement executed between Plaintiff No 1 and Liberty demonstrating the
resumption of services by the Plaintiffs. (mm) Screenshots of the TPA claims system that was
initially provided by the Plaintiffs to Liberty.
(nn) Screenshots of the HealthBuzz - Claims System supplied by the Defendants to Liberty, which
the Plaintiffs accessed while providing Neutral Citation Number: 2022/DHC/004831 (oo)
Screenshots of the source code of HealthBuzz software disclosing references to Defendant No 1,
which the Plaintiffs accessed while providing services to Liberty.
VI. Other Documents (pp) Indicative list of the different services at each level (L0 to L3) to
demonstrate the provision of services, both with and without the use of source code.
Section BEicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies Pvt. Ltd. & Ors. on 15 November, 2022

(a) Draft confidentiality agreement shared by the Defendant No. 14 with ABHI on 31 August 2016
for providing implementation and support services in relation to the Plaintiffs' proprietary software,
HealthBuzz.
(b) Defendant No. 1's proposal dated 21 October 2016 in respect of maintenance services for
HealthBuzz to ABHI.
(c) Purchase Order of INR 79,20,000 issued by ABHI in favor of the Defendant No. 1 dated 2
November 2016 following the proposal for providing L2 and L3 support services for HealthBuzz
while being employed with the Plaintiffs.
(d) E-mail dated 31 January 2017 sent by the Defendant No. 14 (while being employed with the
Plaintiffs) to ABHI wherein the source code of HealthBuzz was unauthorizedly shared.
(e) E-mail dated 17 February 2017 sent by ABHI to the Defendant Nos. 4 and 14 enclosing a
document setting out ABHI's business requirements in respect of Group EW coverage for the
purpose of seeking fee estimation/timelines for delivery.
(f) Commercial proposals for module customizations and implementation of multiple change
requests submitted by the Defendants to ABHI between 9 February 2017 to 20 February 2017.
(g) Several other proposals such as proposals for development of Idea Payment Bank module dated
6 February 2017, proposal for web API development and customization for Policy Bazar dated 6
February 2017, etc. were shared by the Defendant No. 1 with ABHI.
(h) Purchase Orders issued by ABHI in favour of the Defendant No 1.
(i) Purchase order for INR 5,50,000 towards Policy Bazaar integration services dated 2 February
2017.
(ii) Purchase order for INR 8,50,000 towards Idea Payment banking services dated 2 February
2017.
(iii) Purchase order for INR 40,000 towards cheque reconciliation process for Seller portal and App
dated 3 February 2017.
(iv) Purchase order for INR 15,07,954 towards revised member ID logic, product configuration for
affinity group, discontinuation of FF combinations below 1 lac, discontinuation of OPD and
Maternity, retail product - hospital cash development dated 16 March 2017 and its corresponding
invoice dated 3 April 2017.
Neutral Citation Number: 2022/DHC/004831Eicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies Pvt. Ltd. & Ors. on 15 November, 2022

(i) Independent Master Services Agreement executed between the Defendants (while being
employed with the Plaintiffs) and ABHI post discussions in March 2017.
(j) E-mails exchanged between ABHI and the Defendants Nos. 4, 14 and 18 on 24 May 2017 by
which ABHI shared a document setting out its business requirements on the basis of which the
Defendant No. 1 was to offer support services in relation to HealthBuzz.
(k) E-mail sent by Mr Prabhdeep Lamba (who is currently working with Contingent (Hong Kong)
and has been in close collaboration with the Defendants before) to the Defendant No. 4 on 15 April
2017 which contained references to the ownership of the Plaintiff 5 in HealthBuzz and the modus
operandi of the Defendants for providing services in respect of HealthBuzz to the Plaintiffs' clients.
6. Arguing in support of the application, learned Senior Counsel appearing on behalf of the Plaintiffs
submitted that there is no legal bar in taking on record the documents in Section 'A' which fall in 3
broad categories viz: (a) relate to events or incidences which have occurred subsequent to the filing
of the suit; (b) have been discovered by the Plaintiffs after the suit was filed; and (c) existed prior to
the filing of the suit, but were not in Plaintiffs' power, possession, control or custody at the time of
filing and were not related to the infringing activities of or breaches by the Defendants, when the
suit was filed.
7. Elaborating and dilating on the nature of additional documents, it was stated that the first 4
categories of documents from (a) to (jj) have come into existence only after the filing of the suit and
Plaintiffs are not required to disclose 'reasonable cause' under Order XI Rule 1(5) CPC, for non-filing
the said documents with the plaint. The 5th category of documents (kk) to (oo) relate to infringing
activities of the Defendants pertaining to their transactions with Liberty General Insurance Co. Ltd.
(Liberty), discovered by the Plaintiffs subsequent to the suit and thus the Software License and
Support Agreement with Liberty, albeit pre-dates the suit, becomes relevant and reasonable cause
for non-disclosure with the plaint, need not be established.
Neutral Citation Number: 2022/DHC/004831 Plaintiffs have broadly referred to the infringing
activities of the Defendants, recently discovered by the Plaintiffs, in paras 44 to 93 of the plaint and
it is neither necessary nor was feasible or even possible to have pleaded in the plaint about the
infringing activities of the Defendants relating to every Insurance company, with whom they have
been or are dealing and using 'HealthBuzz'. These documents have also become relevant on account
of the averments in the written statements, where Defendants have denied having any access to
data, documents, source code or confidential information of the Plaintiffs. Defendants have also
denied that they had abused the faith reposed in them or cheated the Plaintiffs or siphoned of
Plaintiffs' business while being employed with them and have instead stated that they were free to
enter into a contract for managing the Plaintiffs software 'HealthBuzz'. The additional documents
sought to be placed on record will evidence that contrary to the stand in the written statements,
Defendants have continued to infringe, by supplying the HealthBuzz- Claims System to one of
Plaintiffs' clients, which was impossible without accessing Plaintiffs' proprietary software and
copyrighted source code.Eicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies Pvt. Ltd. & Ors. on 15 November, 2022

8. It was submitted that the 6th category of document (pp) is in aid of the Plaintiffs' pleaded case in
the plaint. The document is an indicative list of services that can or cannot be undertaken without
modification of source code and pleadings to this effect are in paragraphs 3, 4, 5, 29, 32, 119, 152 and
156 of the plaint. Defendants have, however, failed to demonstrate that the document is irrelevant or
immaterial in any manner and/or that the indicated list of services could be rendered without use of
Plaintiffs' source code. Importantly, Defendants have admitted that once any client acquires the
software from the Plaintiffs, it can subsequently engage any Neutral Citation Number:
2022/DHC/004831 Company for managing the software, which would necessarily entail use of the
source code.
9. Insofar as documents under 'Section B' are concerned, contention was that although these
documents date back to a period prior to the filing of the suit, but existence of these documents was
unknown to the Plaintiffs, when the suit was filed. These documents have been recently discovered,
during arbitration proceedings, against Aditya Birla Health Insurance Co. Ltd. (ABHI), post the
filing of the suit from the backup of the laptop that was being used by one of the ex-employees of the
Plaintiffs. The documents demonstrate the extent of Defendants' involvement in dealing with
Plaintiffs' software HealthBuzz, while providing services to ABHI, during their employment with the
Plaintiffs, in breach of contractual terms and confidentiality obligations therein. It was canvassed
that it has been a challenge for the Plaintiffs to retrieve and collate these documents, including those
filed along with the plaint, on account of sudden resignation of the Defendant employees, who while
leaving took away all confidential data and information, to which they were privy. Most of these
documents, it was urged, have been already filed along with two applications, one under Order
XXXIX Rule 2A CPC being I.A. 6886/2021 and another under Order XXXIX Rules 1 and 2 CPC
being I.A. 16424/2021.
10. It was further submitted that there is no delay in filing the additional documents as the same
were filed soon after the last set of documents were discovered on 29.10.2021. Assuming without
admitting there is a delay in filing of the documents, that cannot be a ground for not taking them on
record, once they are otherwise relevant and material to adjudication of the disputes arising in the
present suit.
Neutral Citation Number: 2022/DHC/004831
11. Learned Senior Counsel contended that it is a settled law that the mandate of Order XI Rule 1(5)
CPC to establish a 'reasonable cause' for non-disclosure of the documents along with the plaint shall
not apply if it is averred that documents were discovered subsequent to filing of the suit and were
not in power, possession, control or custody of the Plaintiffs, when the plaint was filed. [Ref.: Sudhir
Kumar @ S. Baliyan v. Vinay Kumar G.B., 2021 SCC OnLine SC 734]. Even where the provisions of
Order XI Rule 1(5) CPC require disclosure of a reasonable cause, the said expression requires a
lower degree of proof as compared to 'good cause' or 'sufficient cause'.
12. Learned Senior Counsel further contended that Plaintiffs have shown reasonable cause for filing
the documents as mentioned in 'Section B' and a liberal approach is required to be taken in the
matter, particularly, when suit is at a stage where issues have not been framed. [Ref.: Hassad FoodEicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies Pvt. Ltd. & Ors. on 15 November, 2022

Company Q.S.C. and Another v. Bank of India and Others, 2019 SCC OnLine Del 10647]. The Court,
at this stage, is not required to determine the authenticity, admissibility or relevancy of the
documents of a threshold required at the stage of trial and final arguments and therefore, the
argument of the Defendants with respect to relevancy of the documents to the dispute ought to be
rejected. Certainly, the Court is entitled to see that the documents sought to be brought on record
under Order XI Rule 1 CPC are not totally alien to the subject matter of the suit.
13. Arguing in rebuttal, learned Senior Counsel appearing on behalf of Defendants No. 1 to 7 and 12
to 19, opposed the application on many-fold grounds. It was canvassed with vehemence that the
pleadings in the application are vague and baseless and do not disclose any cogent reason for filing
the additional documents. In order to place the additional documents on record, Applicant is
required to Neutral Citation Number: 2022/DHC/004831 show that: (a) documents could not be
filed with the plaint by reason of their not being in the power, possession, control or custody of the
Plaintiff; and (b) the documents have a critical bearing on the matter and are necessary for effective
adjudication of the issues involved. As far as documents that have purportedly come into existence
after filing of the suit, the only ground pleaded in the application is that they have come into
existence post the filing of the suit. No reason is forthcoming as to how the documents are relevant
and necessary for effective adjudication of the issues involved in the suit. A bare averment that the
additional documents are relevant and material to meet the case set up by the Defendants in the
written statement is not enough and it is not stated as to why no steps were taken to file the
documents when the replication was filed.
14. The application lacks pleadings as to when the documents in Section 'A' came into power and
possession of the Plaintiffs. Some of the documents date back to the year 2019 and no reason is
forthcoming for their non-filing for 2 years. Plaintiffs cannot be permitted to take advantage of their
lackadaisical conduct in a commercial suit. Some of the documents now sought to be brought on
record were filed by the Plaintiffs with the contempt application being I.A. 6886/2021. The
application was dismissed by the Court by a reasoned order, holding that the application had no
merit. No reasons have been given as to why these documents have now become relevant for just
adjudication of the suit.
15. Documents (a) to (c) in Section 'A' do not mention whether the alleged revenue is generated from
HealthIns or HealthBuzz or servicing of 'HealthBuzz' and/or any other related activity. Mere
generation of revenue by Defendants has no bearing on the present dispute and is completely
irrelevant. With respect to Neutral Citation Number: 2022/DHC/004831 documents (d) to (q), not
a single averment is made in the plaint that Defendants have made parallel companies abroad.
Moreover, these third parties have denied any association with the Defendants for which supporting
documents are on record. Documents from (r) to (ee) have been filed to show breach of the interim
order and have no part to play in the adjudication of the suit. These documents were in fact filed
with the contempt application, which was dismissed and thus the documents cannot be brought on
record, at this stage. Documents (ff) to (oo) cannot be permitted as none of them have any genesis in
the pleadings. Insofar as documents relating to Liberty are concerned, the ground for filing
additional documents is that the 'Claim System Module' has been added by the Defendants. What is
the Claim System Module, how many modules does 'HealthBuzz' contain and how the Claim SystemEicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies Pvt. Ltd. & Ors. on 15 November, 2022

Module is installed is not pleaded either in the plaint or replication or even in the present
application and that the Defendants have installed 'HealthBuzz' in Liberty's computers is not even
the cause of action on which the suit is premised. Document (pp) cannot be termed as a 'document'
and is a self-serving list prepared by the Plaintiff, only to improve and broaden the case of the
Plaintiffs and assert a cause of action, not asserted in the plaint.
16. The additional documents enumerated under 'Section B' admittedly existed prior to filing of the
suit. Plaintiffs are now taking a position that the documents have been recently discovered from a
laptop used by one of the ex-employees, during arbitration proceedings against ABHI. Plaintiff is
required to a reasonable cause for non-disclosure of the documents with the plaint as also the
relevancy of the documents and Plaintiff has failed on both counts. It is stated in the plaint that the
laptops used by the Defendants were handed over to the Plaintiffs on which Forensic investigation
was Neutral Citation Number: 2022/DHC/004831 conducted and some documents were filed with
the plaint. There is no mention that some documents at that stage could not be retrieved on account
of technical issues or lack of passwords etc. and/or how the difficulties faced at that time, if any,
were subsequently resolved. Being unsuccessful in obtaining an injunction as well establishing
contempt on the part of the Defendants, on these very documents, Plaintiffs cannot be permitted to
rely on them again. Perusal of para 5 of the application would show that the application completely
lacks in pleadings on whether the ex-employee is one of the Defendants in the present suit or any
other employee or what occasioned and triggered the retrieval of these documents during
arbitration. Therefore, Plaintiffs have failed to show reasonable cause as required under Order XI
Rule 1(5) CPC and the documents cannot be brought on record.
17. I have heard learned Senior Counsels for the parties and examined their respective contentions.
Since this is an application preferred on behalf of the Plaintiffs for bringing on record additional
documents, the grounds have to be tested on the anvil of provisions of Order XI Rule 1(5) CPC, as
amended by the Act, which is extracted for ready reference as under:
"XI. DISCLOSURE, DISCOVERY AND INSPECTION OF DOCUMENTS IN SUITS
BEFORE THE COMMERCIAL DIVISION OF A HIGH COURT OR A COMMERCIAL
COURT
1. Disclosure and discovery of documents.--........ (5) The plaintiff shall not be allowed
to rely on documents, which were in the plaintiff's power, possession, control or
custody and not disclosed along with plaint or within the extended period set out
above, save and except by leave of Court and such leave shall be granted only upon
the plaintiff establishing reasonable cause for non-disclosure along with the plaint."
18. Order XI Rule 1(5) CPC, as applicable to the commercial suits, mandates the Plaintiff to file a
List of Documents and photocopies of Neutral Citation Number: 2022/DHC/004831 the documents
in its power, possession, control or custody, pertaining to the suit, along with the plaint. Under
Sub-Rule (5) of Rule 1 of Order XI of CPC, there is a statutory proscription on the Plaintiff to rely on
documents which were not disclosed at the time of filing of the plaint, if the same were in its power,
possession, control or custody. The proscription equally applies to the Court from granting leave,Eicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies Pvt. Ltd. & Ors. on 15 November, 2022

save and except, when the Plaintiff is able to demonstrate a reasonable cause for not filing the said
documents with the plaint. This position of law clearly emerges from the exposition of law by the
Supreme Court in Sudhir Kumar @ S. Baliyan (supra). Relevant para reads as follows:
"31. Therefore a further thirty days time is provided to the plaintiff to place on record
or file such additional documents in court and a declaration on oath is required to be
filed by the plaintiff as was required as per Order XI Rule 1(3) if for any reasonable
cause for non disclosure along with the plaint, the documents, which were in the
plaintiff's power, possession, control or custody and not disclosed along with plaint.
Therefore plaintiff has to satisfy and establish a reasonable cause for non disclosure
along with plaint. However, at the same time, the requirement of establishing the
reasonable cause for non disclosure of the documents along with the plaint shall not
be applicable if it is averred and it is the case of the plaintiff that those documents
have been found subsequently and in fact were not in the plaintiff's power,
possession, control or custody at the time when the plaint was filed. Therefore Order
XI Rule 1(4) and Order XI Rule 1(5) applicable to the commercial suit shall be
applicable only with respect to the documents which were in plaintiff's power,
possession, control or custody and not disclosed along with plaint. Therefore, the
rigour of establishing the reasonable cause in non disclosure along with plaint may
not arise in the case where the additional documents sought to be produced/relied
upon are discovered subsequent to the filing of the plaint."
19. From a reading of the aforementioned passage, two principles of law pronouncedly emanate: (a)
the documents which were in Plaintiff's power, possession, control and custody, but were not
disclosed along with the plaint, shall not be allowed to be relied upon, unless a reasonable cause is
set out for non-disclosure and the Court By:KAMAL KUMAR Signing Date:22.11.2022 19:10:19
Neutral Citation Number: 2022/DHC/004831 grants leave to rely on the additional documents,
satisfied with the reasonable cause; and (b) requirement of establishing reasonable cause shall not
come in the way, if it is averred that the documents were discovered subsequently and were not in
Plaintiff's power, possession, control or custody when the plaint was filed. A corollary to the said
principles is that the documents which come into existence subsequent to the filing of the suit i.e.
are post-dated, are saved from the rigours of showing 'reasonable cause' for non-disclosure,
envisaged in Rule 1(5) of Order XI CPC.
20. Tested on the anvil of the affirmation of law by the Supreme Court, the documents at serial nos.
(a), (b) and (c) in Section 'A' of the application, as aforementioned, can be taken on record as: (i)
they have come into existence subsequent to the filing of the suit [Ref.:
Sudhir Kumar (supra)]; and (ii) these are Audited Financial Statements or
screenshots of the website of Defendant No. 1 and are in public domain [Ref.:
CS(COMM) 1611/2016 titled as Columbia Sportswear Company v. Harish Footwear &
Anr.].Eicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies Pvt. Ltd. & Ors. on 15 November, 2022

21. Insofar as documents at serial nos. (d) to (q) in Section 'A' are concerned, these relate to
correspondence/other documents in respect of parallel companies allegedly incorporated by the
Defendants in India and in Singapore. It is well settled that at this stage of granting leave to place on
record additional documents, Court is not required to determine the authenticity, admissibility or
relevancy of the documents and these are considerations which would arise at the time of trial
and/or even at the stage of deciding an application under Order XXXIX Rules 1 and 2 CPC, for
arriving at a prima facie view, as held by the Supreme Court in Sudhir Kumar (supra). This is,
however, not to be understood to mean that the Court would accept the documents only on the
asking of the Plaintiff. Court will examine whether there is Neutral Citation Number:
2022/DHC/004831 some connection to the suit and that the documents are not wholly alien or
extraneous to the disputes arising between the parties to the lis and needless to say this has to be
judged from the averments in the pleadings. [Ref.: K. Mallesh v. K. Narender and Others, (2016) 1
SCC 670; Khurmi Associates (P) Ltd. v. Maharishi Dayanand Co-operative Group Housing Society,
2022 SCC OnLine Del 1011; and Hemendra Rasiklal Ghia v. Subodh Mody, 2008 SCC OnLine Bom
1017].
22. Following the afore-stated position of law and applying the same to the present set of facts, it
can be clearly seen that documents from (d) to (q), were not in existence when the suit was filed.
Documents apparently relate to a whistle blower's complaint and parallel companies incorporated
by the Defendants, including their Audited Financial Statements and recruitment websites as well as
cease and desist notices, issued by Plaintiff No. 1 and replies received thereto. Having perused the
pleadings in the plaint, the contention of the Defendants that these documents do not have a genesis
or a foundation in the plaint, cannot be accepted. Plaintiffs have in the plaint averred that
Defendants No. 4, 6, 8, 10, 12 and 14 have on several occasions misrepresented to the existing and
prospective clients of the Plaintiffs and have induced several of their customers to enter into
contracts with Defendants No. 1 to 3 causing loss to the Plaintiffs and wrongly benefiting
themselves. It is also averred that Defendants' employees are continuing to infringe the copyright of
the Plaintiffs unabated and their illegitimate activities are multiplying, with each passing day. It is
also stated that Defendants' employees have purposely and with a dishonest intent siphoned off
Plaintiffs' business to Defendants No. 1 to 3 and are continuing to unlawfully access and use the
proprietary/confidential information/intellectual Neutral Citation Number: 2022/DHC/004831
property of the Plaintiffs, in breach of the confidence and trust reposed in them. The contention that
Defendants' employees are misusing the opportunity offered by their employment with the Plaintiffs
as a spring board to set up competing business by stealing the business of the Plaintiffs, is also
averred. Averments also include allegations that on several occasions, the said Defendants have
misrepresented to the existing and prospective clients of the Plaintiffs and have induced several
customers of the Plaintiffs to enter into contracts with Defendants No. 1 to 3. In para 169 of the
plaint, it is averred that the confidential information of the Plaintiffs is of a character that if
monetised by Defendants No. 4, 6, 8, 10, 12 and 14, it can cause irreparable loss and injury to the
Plaintiffs and that Plaintiffs apprehend that the said Defendants along with Defendants No. 1 to 3
are likely to further misuse and abuse the confidential data, etc. to the detriment of the business
prospects of the Plaintiffs. In para 171, it is pleaded that there is a major threat that these
Defendants will disclose the information and other related materials to third parties. Para 176
contains averments that Defendants have diverted legitimate business of the Plaintiffs to the extentEicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies Pvt. Ltd. & Ors. on 15 November, 2022

of at least Rs. 5 crores from 2017 till the date of the filing of the present suit and as on the date of the
suit, Plaintiffs do not have further details of the monies unlawfully obtained by the Defendants as
they do not have access to the bank accounts or account books of the Defendants. Thus, right is
reserved to amend the plaint to claim additional amounts, as and when further information comes
to Plaintiffs' knowledge. Therefore, in view of these pleadings, in my view, no new case is being set
up by the Plaintiffs by filing the aforementioned documents, as the same do have a foundation in the
plaint and the documents can be taken on record.
Neutral Citation Number: 2022/DHC/004831
23. Documents from (r) to (ee) in Section 'A' are Plaintiffs' notices to the Defendants, alleging
breach of the interim order dated 28.09.2018 and the Defendants' notices alleging defamation and
breach of ad-hoc agreement. The documents are apparently post the filing of the suit and they relate
to breach of the interim order dated 28.09.2018. The only objection raised by the Defendants to
these additional documents is that they were filed as part of the contempt application and once the
Court has found that no contempt is made out and the application has been dismissed, the
documents cannot be taken on record. While it is a matter of record that Plaintiffs did not succeed in
proving that the acts of the Defendants were contemptuous, however, it cannot be said that the
documents are wholly extraneous or irrelevant to the inter-se disputes between the parties to the
present suit. The relevancy or admissibility of the documents will be seen at the stage of trial and
final arguments. Moreover, no prejudice can be caused to the Defendants as the suit is at a stage
where issues have not been framed and secondly, most of the documents relate to the
responses/replies sent by the Defendants to the notices sent by the Plaintiffs or vice-versa and are in
possession of the Defendants. The documents, therefore, can be taken on record, subject to their
relevancy being decided at later stage.
24. Documents in Section 'A' from (ff) to (jj) relate to correspondence exchanged with Aditya Birla
Health Insurance Company Ltd. (ABHI) in respect of Defendants' engagement with them. Each of
these documents are post the filing of the plaint and do not suffer from the rigour of showing
reasonable cause under Order XI Rule 1(5) CPC. Document at (ff) relates to Annual Financial Report
which is available on the website and is in public domain. The remaining documents, according to
the Plaintiffs, are correspondence Neutral Citation Number: 2022/DHC/004831 with ABHI which
would show the continuing infringing activities of the Defendants and the stand of ABHI in support
of the Plaintiffs. The necessary averments in support of the documents find genesis in the plaint and
moreover, the case of the Plaintiffs is premised on Defendants' own admission in the written
statement that they entered into contracts with third-parties to manage Plaintiffs' software
HealthBuzz, licensed to Plaintiffs' clients, more particularly, Aditya Birla. In this view, the
documents can be taken on record.
25. Documents (kk) to (oo) relate to the HealthBuzz-Claims System supplied by the Defendants to
Liberty. It is the stand of the Plaintiffs that the infringing activities of the Defendants are continuing,
contrary to the stand in the written statements that they have no access to data, documents, source
code etc. of the Plaintiffs. Additionally, Defendants have also stated that they are free to enter into a
contract for managing the Plaintiffs' software HealthBuzz. These documents would demonstrateEicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies Pvt. Ltd. & Ors. on 15 November, 2022

that Defendants have supplied the HealthBuzz-Claims System to one of Plaintiffs' clients i.e. Liberty,
after the filing of the suit, which could not have been done without having Plaintiffs' proprietary
software and copyrighted source code and in this context the Software License and Support
Agreement dated 16.12.2014 entered between the Plaintiffs and Liberty becomes relevant.
Documents are not to make out a fresh cause of action, as alleged by the Defendants and there are
substantial pleadings in the plaint that Defendants are continuing to infringe.
26. Having examined the documents (kk) to (oo), it is palpably clear to the Court that barring the
document (kk), the remaining documents are post the filing of the plaint and do not fall under the
rigours of establishing a reasonable cause for non-disclosure with the plaint and are in aid to show
the alleged dealings of the concerned Neutral Citation Number: 2022/DHC/004831 Defendants
with Liberty. The document (kk), i.e. Software Licence and Support Agreement dated 16.12.2014 is,
no doubt, prior to the filing of the suit, however, as aforementioned, viewed in light of the
contention of the Plaintiffs that it has become relevant post the filing, once it was discovered that
contrary to the stand of the Defendants in the written statement, they are continuing to indulge in
infringing activities and have entered into transactions with Liberty, Plaintiffs cannot be deprived of
placing these documents on record, subject however to their relevancy and admissibility being
examined at the appropriate stage of the suit. In any event, Rule 1(c)(ii) of Order XI begins with a
non-obstante clause and provides that nothing in sub-Rule (1) shall apply to documents produced by
the Plaintiff and relevant only in answer to any case set-up by the Defendant subsequent to the filing
of the plaint, and the aforementioned documents are being sought to be brought on record to meet
the stand of the Defendants in the written statement. Defendants are not correct in their submission
that there is lack of pleading with respect to the said documents. Paras 148, 150, 152, 171 and 172, to
illustrate a few, contain averments that Plaintiffs have learnt that Defendants are continuing with
their illegitimate acts of using counterfeit software i.e., HealthIns in the market and examples to
that effect have also been mentioned.
27. With respect to Document (pp) in Section 'A', the opposition on behalf of the Defendants is that
Plaintiffs are trying to enlarge the scope of the suit as there is no averment in the plaint to the effect
that some services can be undertaken without source code modification and some cannot. It was
also contended that the said document is, in fact, not even a document but only a list of services
prepared by the Neutral Citation Number: 2022/DHC/004831 Plaintiffs, placed merely as an
annexure to the application and is unsupported by any pleadings even in the present application.
28. I have perused the document (pp) and find merit in the contention raised by the Defendants that
the same cannot be taken on record. A bare perusal of document (pp) shows that it is a typed list
prepared by the Plaintiffs enumerating the services allegedly which can or cannot be performed
without modification of the source code. The list cannot be termed as a document and as rightly
pointed out by the Defendants, has no genesis in the pleadings in the plaint or even the present
application.
29. With respect to the documents in Section 'B', it is averred in the application by the Plaintiffs that
the existence of these documents was not within their knowledge at the time of filing the plaint and
these have been recently discovered during arbitration proceedings against ABHI from the laptopEicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies Pvt. Ltd. & Ors. on 15 November, 2022

that was being used by one of the ex-employees of the Plaintiffs at the relevant time. It is
categorically averred that these documents are crucial as they would demonstrate the extent of
Defendants' involvement in dealing with Plaintiffs' proprietary software HealthBuzz and provision
of services to ABHI in breach of employment contracts and confidentiality obligations. It is also
stated that the documents could not be filed earlier on account of the sudden resignation of some of
the employees from the services of the Plaintiffs and their taking away all confidential data and
relevant information. The opposition by the Defendants to the present set of documents is that the
laptop has been in possession of the Plaintiffs prior to the filing of the suit and no reasonable cause
is forthcoming as to why these could not be filed with the plaint. It is not explained how some
documents were retrieved from the laptop earlier and filed with Neutral Citation Number:
2022/DHC/004831 the plaint, while the present set of documents could not be taken and filed for
two years.
30. Having heard the learned Senior counsels for the respective parties, in my view, documents in
Section 'B' cannot be taken on record, at this stage. Plaintiffs have averred that these documents
were recently discovered during the arbitration proceedings, which was invoked on 29.04.2020
against ABHI. Be it noted that in the plaint, it is stated in para 107 that Plaintiffs engaged M/s
Pinkerton Consulting & Investigation Inc. for purposes of Cyber Forensic Examination of the
various computer systems, laptops and other devices, allocated to Defendants No.4, 6, 8, 10, 12 and
14 at the time they were working for Plaintiffs No.1 to 4. Defendants are right in their objection that
if these documents are purportedly discovered from the backup of the laptop of Defendant(s), then
they were in possession and custody of the Plaintiffs when the plaint was filed, since admittedly, the
laptop was in possession of the Plaintiffs at that stage and they had access to the data contained
therein, which is fortified by the fact that many documents retrieved from the laptop were indeed
filed along with the plaint. Significantly, even when the application being I.A. 6886/2021 was filed,
although there is reference to these documents in the context of contempt alleged to be committed
by the Defendants, but there is not even a whisper as to how and why these additional documents
were discovered and/or came into possession of the Plaintiffs, subsequently. Plaintiffs have thus
failed to disclose reasonable cause for non- disclosure of the additional documents, which were in
their custody when the suit was filed. There is nothing on record which even remotely gives credence
to the stand of the Plaintiffs that the documents came into their possession subsequently and in my
view, Neutral Citation Number: 2022/DHC/004831 the position now adopted is belied by the
admitted fact that the laptop in question was in their custody throughout.
31. In Societe DES Produits Nestle S.A. & Anr. v. Essar Industries & Ors., 2016 SCC OnLine Del
4279, this Court observed that undoubtedly, Courts have been liberal in the past in allowing
documents to be filed, even at a late stage, i.e. beyond the stage prescribed in law for filing thereof,
but the said view needs to change in light of the Commercial Courts Act, 2015, the whole purport
whereof is to expedite the disposal of suits, and commercial suits are to be treated differently,
forming a distinct class.
32. In Zee Entertainment Enterprises Ltd. v. Saregama India Ltd., 2019 SCC OnLine 10215, the
Court held that if the Courts, inspite of the legislative mandate and change, continue to overlook the
deficiencies in prosecution of the suits, in the name of justice, litigants of commercial suits willEicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies Pvt. Ltd. & Ors. on 15 November, 2022

never wake up to the change required to be brought about in the conduct of such suits.
33. Applying the aforesaid judgments, in my view, it would be antithetical to the legislative mandate
of the Act if the Plaintiffs were permitted to bring on record the documents in Section 'B', keeping in
view that: (a) they pertain to a period prior to filing of the suit;
(b) no reasonable cause as mandated under Order XI Rule 1(5) CPC is shown, persuading the Court
to grant leave to bring them on record; and (c) Plaintiffs have been unable to make out a case that
the documents were discovered post the filing of the suit.
34. Accordingly, the application is partially allowed in the aforesaid terms and the documents in
Section 'A', save and except, document (pp) are taken on record, subject to payment of cost of
Rs.25,000/- to Neutral Citation Number: 2022/DHC/004831 the Delhi High Court Bar Clerks'
Association within three weeks from today. Documents enumerated in Section 'B' are disallowed.
35. Application is disposed of in the above terms.
                                                                             JYOTI SINGH, J
                          NOVEMBER             15 , 2022/rk/shivamEicore Technologies Pvt. Ltd. & Ors. vs Eexpedise Technologies Pvt. Ltd. & Ors. on 15 November, 2022

