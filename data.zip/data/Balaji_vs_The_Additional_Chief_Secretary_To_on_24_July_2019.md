Balaji vs The Additional Chief Secretary To ... on 24 July, 2019
Author: M.Sathyanarayanan
Bench: M.Sathyanarayanan, B.Pugalendhi
                                                                        H.C.P(MD)No.173 of 2019
                          BEFORE THE MADURAI BENCH OF MADRAS HIGH COURT
                                              DATED : 24.07.2019
                                                   CORAM:
                          THE HONOURABLE MR.JUSTICE M.SATHYANARAYANAN
                                              and
                             THE HONOURABLE MR.JUSTICE B.PUGALENDHI
                                        H.C.P(MD)No.173 of 2019
                Balaji                                                        ... Petitioner
                                                      Vs.
                1.The Additional Chief Secretary to Government,
                  State of Tamil Nadu,
                  Home, Prohibition and Excise Department,
                  Secretariat, Chennai – 600 009.
                2.The District Collector and District Magistrate,
                  Office of the District Collector and District Magistrate,
                  Madurai.
                3.The Superintendent of Prison,
                  Madurai Central Prison,
                  Madurai District.                                           ... Respondents
                Prayer: Habeas Corpus Petition filed under Article 226 of the Constitution
                of India praying for the issuance of a Writ of Habeas Corpus, to call for the
                entire records, connected with the detention order of the Respondent No.2
                in B.C.D.F.G.I.S.S.S.V.No. 03/2009, dated 31.01.2019 and quash the same
                and direct the respondents to produce the body or person of the detenu by
                name Balaji, son of Nethaji, aged about 26 years, now confined at Madurai
                Central Prison before this Court and set him at liberty forthwith.
                            For Petitioner             : Mr.R.Alagumani
                            For Respondents            : Mr.K.Dinesh Babu,
                                                         Additional Public Prosecutor
http://www.judis.nic.inBalaji vs The Additional Chief Secretary To ... on 24 July, 2019

                1/11
                                                                        H.C.P(MD)No.173 of 2019
                                                   ORDER
(Order of the Court was made by M.SATHYANARAYANAN, J.) The detenu himself is the petitioner
herein and challenging the impugned order of detention dated 31.01.2019 passed by the second
respondent, branding him as a Goonda under the provisions of Section 3[1] of the Tamil Nadu
Prevention of Dangerous Activities of Boot leggers, Cyber Law Offenders, Drug Offenders, Forest
Offenders, Goondas, Immoral Traffic Offenders, Sand Offenders, Sexual Offenders, Slum Grabbers
and Video Pirates Act, 1982 (Tamil Nadu Act 14/1982), he has filed the present habeas corpus
petition.
2.A perusal of the grounds of detention would disclose that the detention order came to be passed,
based on a solitary case registered by Karuppayurani Police Station in Crime No.186 of 2018, for the
commission of offence under Sections 147, 148 and 302 IPC. According to the defacto complainant
namely Nagendiran, a resident of Sethupathi Nagar, Panangadi, Madurai, he became aware of the
cock fight programme and therefore, he and his younger brother went in a two wheeler and while
they were returning, some persons came in a dark green colour car and intercepted them and a
white car also dashed against the two wheeler of Aravind and he had fallen down and seven persons
had stepped down and indiscriminately attacked him and as a consequence, he died on the spot.
http://www.judis.nic.in
3.The detenu and other co- accused had surrendered on 12.11.2018 before the Court of Judicial
Magistrate No.II, Madurai and they were ordered to be remanded to judicial custody till 07.12.2018
and the remand was periodically extended till 01.02.2019. The Detaining Authority, on a perusal
and consideration of the materials, has derived the subjective satisfaction that the activities of the
detenu were prejudicial to the maintenance of the public peace and order and as such, branded them
as Goondas and detained them under the provisions of the Tamil Nadu Act 14 of 1982, by clamping
the impugned order of detention and challenging the legality of the same, the present Habeas
Corpus Petition is filed.
4.The learned Counsel for the petitioner has drawn the attention of this Court to the typed set of
documents and would submit that the detenu has submitted identical representations dated
04.02.2019 to the second respondent / the detaining authority, the Chairman of the Advisory Board
as well as the first respondent for revocation of the order of detention.
5. It is the submission of the learned Counsel for the petitioner that though the said representation
has been considered and rejected on 05.02.2019 by the detaining authority, rest of the two
representations submitted to the Advisory Board as well as the Government, have not
http://www.judis.nic.in been forwarded and on account of the non-forwarding of the
representations, the detenu has lost his opportunity for consideration of his representations for
revocation of the order of detention and the right guaranteed under Article 22(5) of the Constitution
of India is also deprived of and challenging the impugned order of detention, the petitioner has
come forward to file the present Habeas Corpus Petition.Balaji vs The Additional Chief Secretary To ... on 24 July, 2019

6.Per contra, learned Additional Public Prosecutor appearing for the State would submit that since
the representation dated 04.02.2019 submitted to the detaining authority, has been considered and
rejected within a period of twelve days, it is not necessary to forward the representation / the
contents, which are identical, to the Government as well as to the Advisory Board and the attention
of this Court was also invited to the letter of the first respondent in No.26950/H.P & E (XVI)/2018,
dated 14.11.2018, wherein it has been stated that if the representation received form the detenue
within a period of twelve days has been considered by the detaining authority, the representation
addressed to the Government as well as the Advisory board need not be forwarded.
7.In sum and substance, it is the submission of the learned Additional Public Prosecutor appearing
for the State that since the http://www.judis.nic.in detaining authority has already considered and
rejected the representation without any loss of time, in the light of above cited letter dated
14.11.2018 of the first respondent, it is not necessary to forward the representation submitted to the
Advisory Board and to the Government and therefore, prays for dismissal of this habeas corpus
petition.
8. This Court has considered the rival submissions and also perused the entire materials placed
before it.
9. In Agalya Bhai Vs. The State of Tamil Nadu, reported in 1997 (III) CTC 486 (DB), the order of
detention came to be passed under the provisions of the Conservation of Foreign Exchange and
Prevention of Smuggling Activities Act, 1974 [COFEPOSA Act] and one of the grounds urged was
that the failure of the Jail Superintendent to forward the detenu's representation to the Central
Government, amounts to deprivation of the right of the detenue to have his detention revoked and
in the said decision, it is also held that since the grounds of detention themselves would indicate
that the detenu can represent to the Central Government and keeping in view of the right involved,
the Jail Superintendent ought to have exhibited more alert in transmitting the said representation
and the Division Bench, having found that it was not done, quashed the impugned order of
detention passed under COFEPOSA Act. http://www.judis.nic.in
10.The Hon'ble Supreme Court in Kamleshkumar Ishwardas Patel Vs Union of India and Others,
reported in [1995] 4 SCC 51, which also pertains to the order of detention passed under COFEPOSA
Act, has held in paragraph Nos.30 and 31 that under Article 22(5) of the Constitution of India, the
right of the person detained to make the representation against the order of detention comprehends
the right to make such a representation to the Authority, which can grant such relief, ie., that
authority which can revoke the order of the detention and set him at liberty and since the officer,
who has made the order of detention is competent to revoke it, the person detained has the right to
make a representation to the officer who made the order of detention.
11.The Hon'ble Supreme Court in State of Punjab Vs Sukhpal Singh, reported in [1990] 1 SCC 35,
which pertains to the order of detention passed under the National Security Act, 1980, in paragraph
Nos. 15, 16 and 19, has held that “the clear instructions in the grounds of detention that the detenue
should address the representation to the State Government through the Superintendent of Jail,
where he was detained should have been followed”.Balaji vs The Additional Chief Secretary To ... on 24 July, 2019

12.Keeping in mind the principles enunciated in the above cited judgments, this Court has scanned
and analysed the materials placed on record.
http://www.judis.nic.in
13.It is not in dispute that the detenu, apart from submitting the representation dated 04.02.2019 to
the second respondent / the detaining authority, he has also submitted representations dated
04.02.2019 to the first respondent as well as to the Chairman, Advisory Board.
14.It is pertinent to extract the relevant portion of paragraph No. 6 of the order of the detention
dated 31.01.2019, which reads as follows:
“6. ... ... ... he has a right to make, representation in writing against the said detention
order to the State Government and if he wishes to make any representation to the
State Government, he should address it to the Additional Chief Secretary to
Government, Home, Prohibition and Excise Department, Secretariat, Chennai – 9
through the Superintendent of Central Prison, Madurai in which he is detained, as
expeditiously as possible. Further it is informed that he has a right to make
representation to the Chairman, Advisory Board, 32, Rajaji Salai, Singaravelar
Maligai, Ground Floor (Backside entrance) Chennai Collectorate, Chennai – 600 001
through the Superintendent of Central Prison, Madurai. Any representation made by
him to the Government, will be duly considered by the Government and will also be
placed before the Advisory Board along with his case details, for consideration under
Section 10 of the Tamil Nadu Prevention of Dangerous Activities of Bootleggers,
Cyber Law Offenders, Sexual Offenders, Slum Grabbers and Video Pirates, 1982. He
is informed that he is entitled to be heard in person by the Advisory Board. He is
requested to intimate to the Additional http://www.judis.nic.in Chief Secretary to
Government, Home, Prohibition and Excise Department, Secretariat, Chennai -9,
Specifically in writing as expeditiously as possible, whether, he desires to be heard in
person by the Advisory Board or not.”
15.The primordial submission made by the learned Additional Public Prosecutor is
that since the representation submitted by the detenu has been considered and
rejected by the detaining authority within a period of twelve days, the forwarding of
the representation to the Advisory Board as well as the State Government is only an
empty formality for the reason that the contents of the representation are one and the
same and the said Authorities may not also take a very different view from that of the
detaining authority. In the considered opinion of this Court, such a submission lacks
merit and substance, for the reason that paragraph No.6 of the grounds of detention
also made it clear that apart from submitting a representation to the detaining
authority within twelve days from the date of detention order, the detenu was also
informed that he can make representations to the first respondent as well as to the
Chairman, Advisory Board.Balaji vs The Additional Chief Secretary To ... on 24 July, 2019

16.Admittedly, the detenu had submitted such representations to the Superintendent,
Central Prison, in which the detenue is confined and http://www.judis.nic.in it
appears that the said representations addressed to the first respondent as well as to
the Advisory Board, have not been forwarded.
17. In Agalya Bhai's case reported in 1997 (III) CTC 486 (DB), cited supra, in
paragraph No.14, it is observed that “the failure of the Jail Superintendent to forward
the detenu's representation to the Central Government amounts to deprivation of the
right of the detenue to have his detention revoked.”
18.The instructions issued by the first respondent vide letter dated 14.11.2018 are not
in consonance with the settled position of law. In the considered opinion of this
Court, the non forwarding of the representations submitted by the detenu, through
Superintendent of Prison, to the first respondent / Government as well as to the
Chairman, Advisory Board, would definitely vitiate the order of detention. Therefore,
the impugned order is liable to be quashed.
19.In the result, the Habeas Corpus Petition is allowed by setting aside the Order of Detention
passed by the second respondent herein, namely, the District Collector and District Magistrate,
Madurai District, Madurai in B.C.D.F.G.I.S.S.S.V.No. 03/2009, dated 31.01.2019. Consequently, the
detenu, namely, Balaji, aged about 26 years, who is http://www.judis.nic.in now detained at Central
Prison, Madurai is directed to be released forthwith unless his presence [or] custody [or] detention
is required in connection with any other case/proceedings.
                                                          [M.S.N., J.]   [B.P., J.]
                                                                  24.07.2019
                Index    : Yes / No
                Internet : Yes / No
                dsk/gk
                To
1.The Additional Chief Secretary to Government, State of Tamil Nadu, Home, Prohibition and Excise
Department, Secretariat, Chennai – 600 009.
2.The District Collector and District Magistrate, Office of the District Collector and District
Magistrate, Madurai.
3.The Superintendent of Prison, Madurai Central Prison, Madurai District.
4.The Additional Public Prosecutor, Madurai Bench of Madras High Court, Madurai.
http://www.judis.nic.in M.SATHYANARAYANAN, J.Balaji vs The Additional Chief Secretary To ... on 24 July, 2019

and B.PUGALENDHI, J.
dsk/gk 24.07.2019 http://www.judis.nic.inBalaji vs The Additional Chief Secretary To ... on 24 July, 2019

