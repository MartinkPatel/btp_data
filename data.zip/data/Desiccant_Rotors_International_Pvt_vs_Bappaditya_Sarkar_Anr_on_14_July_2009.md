Desiccant Rotors International Pvt. ... vs Bappaditya Sarkar &
Anr on 14 July, 2009
Author: Manmohan Singh
Bench: Manmohan Singh
*             HIGH COURT OF DELHI : NEW DELHI
+      I.A. No.5455/2008, I.A. No.5454/2008 & I.A. No.5453/2008 in
       CS(OS) No.337/2008
%                       Judgment reserved on : 6th March, 2009
                              Judgment pronounced on :   14th July, 2009
     DESICCANT ROTORS INTERNATIONAL PVT LTD .... Plaintiff
                   Through  Mr. J.P. Sengh, Sr. Adv. with
                            Ms. Anuradha Mukherjee and
                            Mr. Abhilash Pillai, Advs.
                     versus
   BAPPADITYA SARKAR & ANR                  ..... Defendants
                 Through  Mr. Rajiv Nayyar, Sr. Adv. with
                          Mr. Ajoy Roy and Mr. Sulabh
                          Rewari, Advs.
Coram:
HON'BLE MR. JUSTICE MANMOHAN SINGH
1. Whether the Reporters of local papers may
   be allowed to see the judgment?                                     Yes
2. To be referred to Reporter or not?                                  Yes
3. Whether the judgment should be reported                             Yes
   in the Digest?
MANMOHAN SINGH, J.
1. By this order, I shall dispose of three applications being I.A No. 5453/2008, I.A No. 5454/2008
and I.A No. 5455/2008 in CS (OS) No. 337/2008. I.A No. 5453/2008 and I.A No. 5454/2008 have
been filed by Defendant No. 1 under Order 39 Rule 4 of the CPC, 1908 for setting aside the ex-parte
order dated February 20, 2008 and under Section 8 of the Arbitration and Conciliation Act, 1996 for
reference of the dispute between parties to arbitration respectively, and I.A No. 5455/2008 has been
filed by Defendant No. 2 under Order I Rule 13 of CPC, 1908 for its deletion from the array of
parties.Desiccant Rotors International Pvt. ... vs Bappaditya Sarkar & Anr on 14 July, 2009

CS(OS) No.337/2008 1 of 16
2. Briefly, the facts of the suit filed by the plaintiff are the following. Both the plaintiff and
Defendant No. 2 deal in the sale and marketing of similar products i.e. evaporative cooling
components, products and systems. The plaintiff submits that Defendant No. 1 joined M/s Artic
India Sales as Area Sales Manager in 1998. The said company was a proprietary concern of Mr.
Deepak Pahwa. In 2000, Defendant No. 1 was transferred to Arctic India Engineering Pvt. Ltd. with
length of service counted from 1998. This company is one of the group companies owned by Mr.
Deepak Pahwa and his family. In 2006, Arctic India Engineering Pvt. Ltd.s name was changed to
Desiccant Rotors International Pvt. Ltd. Meanwhile, Arctic India Sales was merged with Bry Air
(Asia) (P) Ltd. in 2004, which is also a group company held by Mr. Deepak Pahwa.
3. The Defendant No. 1 on his transfer to the Plaintiff Company entered into a Confidentiality
Agreement with the latter on December 22, 2000 wherein he acknowledged that he was dealing with
certain confidential material of the Plaintiff such as know how, technology, trade secrets, methods
and processes, markets, sales, list of customers, accounting methods, competitive data, financial
plans etc and stated that he would not divulge the same to third parties. On July 18, 2007 defendant
no. 1 resigned from the plaintiff company and signed an Obligation Agreement on June 12, 2007
which basically provided that (i) for two years after termination of employment, he would not
compete with the plaintiffs business and would not advise, consult, serve or assist any party whose
business competes with that of the plaintiff and its group companies; (ii) for two years he would not
interfere with the relationship of the plaintiff with its customers, suppliers and employees; that he
would not disclose the confidential information to CS(OS) No.337/2008 2 of 16 which he was privy
as employee of plaintiff to any third party; (iii) that he would deliver back all properties (tapes,
notes, discs, manuals, advertising material etc) of the plaintiff which were in his possession and (iv)
he would not retain copies of the above-mentioned properties of the plaintiff. In addition to the
Obligation Agreement, Defendant No. 1 signed two declarations on the same day declaring that if he
failed to adhere to the declarations it would amount to breach of trust and that he would take full
liability and responsibility of the same.
4. The plaintiff alleges that within three months of leaving it, Defendant No. 1 joined Defendant No.
2 as its Country Manager and became in charge of marketing its products. As mentioned earlier,
Defendant No. 2 deals with HumiCool products, which is in direct competition with the plaintiffs
EcoCool pads in the market. In view of this, the plaintiff has made allegations of breach of trust
against the Defendant No. 1 who has, as per the plaintiff, violated the declaration as well as the
Obligation Agreement and the terms of confidentiality and non-compete.
5. The Plaintiff also alleges that Defendant No. 1 had made a backup of the entire data contained in
his laptop, taking the said backup with him when he left the plaintiff. The information therein is
averred to be confidential as it is said to include trade secrets, supplier and customer lists, business
plans, strategies of trade and marketing etc. It is alleged that Defendant No. 1 has even contacted the
suppliers and customers of the plaintiff on behalf of his new employer Defendant No. 2.Desiccant Rotors International Pvt. ... vs Bappaditya Sarkar & Anr on 14 July, 2009

6. The plaintiff further submits that the above-mentioned acts of both the defendants are causing it
irreparable harm as the disclosing of confidential information by its prior employee to a direct
competitor is an illegal and CS(OS) No.337/2008 3 of 16 mala fide breach of its intellectual property
rights and is harmful to its goodwill and reputation. In lieu of this, the plaintiff has prayed for
mandatory injunction and for delivery up and rendition of accounts.
7. Defendant No. 1 has filed I.A No. 5453/2008 for setting aside the ex- parte order passed on
February 20, 2008 restraining the Defendant No. 1 from approaching the plaintiffs suppliers and
customers for soliciting business which is in direct competition with the business of the plaintiff.
Defendant No. 1 submits that the said order virtually grants a monopoly to the plaintiff in its area of
work and the restriction imposed on the former is contrary to Section 27 of the Indian Contract Act,
1872 and therefore ought to be set aside.
8. The Defendant No. 1 submits that he did not have any confidential information during his
employment with the plaintiff as he was only a sales manager and had neither technical
understanding nor capacity to appropriate any confidential technical know-how. The Defendant No.
1 raises two points as regards the two signed declarations dated June 12, 2006 on which the plaintiff
is relying, (i) that the said declarations were standard declarations which were generic and not at all
specific in stating what type of confidential information the Defendant No. 1 had access to and (ii)
that the Defendant No. 1 signed the same at the time of his resignation as it was a precondition to
the release of his dues by the plaintiff. Further, he has submitted that the agreements on which the
plaintiff is relying can have no operation in light of Section 27 of the Indian Contract Act, 1872.
9. The Defendant No. 1 has also submitted that the plaintiff has no prima facie case, that the balance
of convenience in fact is on the applicants side as the injunction order is restraining him from
utilizing the skills he has CS(OS) No.337/2008 4 of 16 perfected in 8-9 years in this industry and if
the same is not vacated, irreparable injury shall be caused to him as he will remain jobless. In its
reply, the plaintiff has submitted that as Defendant No. 1 was employed with it as an „Area Sales
Manager and has expertise in the area of marketing, he can carry on his employment at companies
which are not engaged in competitive business with the plaintiff and thus he need not remain
jobless. The Defendant No. 1 has himself stated that he cannot get employment, as per the plaintiff,
belies the fact that he wants to work only in a place where he can utilize the confidential agreement
obtained by him. As regards the bar on restraint of trade under Section 27, the plaintiff states that
all that the agreements it has relied upon seek to do is to protect its confidential and proprietary
information to which the Defendant No. 1 was privy.
10. Following judgments have been cited by Defendant No. 1 as regards his contention that the two
signed declarations were non-specific with regard to the confidential information that he was
allegedly privy to. The judgments discuss the requirements of breach of confidence and what
constitutes trade secrets and confidential information:
(i) Zee Telefilms Ltd. and Film and Shot & Anr. V. Sundial Communications Pvt. Ltd.
& Ors., 2003 (27) PTC 457 (Bom). Reference was made herein to CMI Centres for
Medical Innovation GmbH & Anr. V. Phytopharm Plc (1999) Fleet Street Reports 235Desiccant Rotors International Pvt. ... vs Bappaditya Sarkar & Anr on 14 July, 2009

wherein it was held that to prove breach of confidence, four things must be shown.
(a) the information relied upon must be clearly identified; (b) the handing over of
such information must have been in the circumstance of confidence; (c) the said
information must be of CS(OS) No.337/2008 5 of 16 a type which can be treated as
confidential; (d) it must have been used without license or there must be threat of the
same. It was held that it need not be proved at an interlocutory stage.
(ii) American Express Bank Ltd. v. Ms. Priya Malik, (2006) IIILLJ 540 DEL : In this
case it was held as under:
"Rights of an employee to seek and search for better employment are not to be curbed
by an injunction even on the ground that she has confidential data in the present
facts and circumstances. Such an injunction will facilitate the plaintiff to create a
situation such as „Once a customer of American Express, always a customer of
American Express. In the garb of confidentiality the plaintiff can not be allowed to
perpetuate forced employment with American Express. Freedom of changing
employment for improving service conditions is a vital and important right of an
employee which cannot be restricted or curtailed on the ground that the employee
has employers data and confidential information of customers which is capable of
ascertainment on behalf of defendant or any one else, by an independent canvass at a
small expense and in a very limited period of time. Such a restriction will be hit by
Section 27 of the Contract Act."
(iii) Ambiance India Pvt. Ltd. v. Shri Naveen Jain, 122 (2005) DLT 421. It was held as under :
It was recognized in this case that "a trade secret is some protected and confidential
information which the employee has acquired in the course of his employment and
which should not reach others in the interest of the employer. However, routine
day-to-day affairs of employer which are in the knowledge of many and are
commonly known to others cannot be called trade secrets. A trade secret can be a
formulae, technical know-how or a peculiar mode or method of business adopted by
an employer which is unknown to others.
7. In the present case, nothing has been indicated even as to what trade secrets or
technical know-how was revealed to the defendant which CS(OS) No.337/2008 6 of
16 should not be divulged to others. In a business house, the employees discharging
their duties come across so many matters, but all these matters are not trade secrets
or confidential matters or formulae, the divulgence of which may be injurious to the
employer. If the defendant on account of his employment with the plaintiff has learnt
some business acumen or ways of dealing with the customers or clients, the same do
not constitute trade secrets or confidential informations, the divulgence or use of
which should be prohibited."Desiccant Rotors International Pvt. ... vs Bappaditya Sarkar & Anr on 14 July, 2009

11. It seems to me that as an Area Sales Manager of the plaintiff, Defendant No. 1 could not have
been privy to trade secrets and other confidential information of the plaintiff company as alleged.
However, being in the position that he was, that Defendant No. 1 could have had knowledge about
the customers of the plaintiff is more plausible as his job profile would entail managing sales as
regards the aforesaid customers.
12. As regards Defendant No. 1s contention that the order dated February 20, 2008 is hit by
Section 27 of the Indian Contract Act, 1872, the leading judgments on this aspect are the following:
(i) Niranjan Golikar v. Century Spinning & Manufacturing Co. Ltd. 1967 (2) SC 1098 :
"13. what constitutes restraint of trade is summarised in Halsbury's Laws of England (3rd edition),
Volume 38, at page 15 and onwards. It is a general principle of the Common Law that a person is
entitled to exercise his lawful trade or calling as and when he wills and the law has always regarded
jealously any interference with trade, even at the risk of interference with freedom of contract as it is
public policy to oppose all restraints upon liberty of individual action which are injurious to the
interests of the State. The Court takes a far stricter view of covenants between master and servant
than it does of similar covenants between vendor and purchaser or in partnership agreements. An
employer, for instance, is not entitled to protect himself against CS(OS) No.337/2008 7 of 16
competition on the part of an employee after the employment has ceased but a purchaser of a
business is entitled to protect himself against competition per se on the part of the vendor. This
principle is based on the footing that an employer has no legitimate interest in preventing an
employee after he leaves his service from entering the service of a competitor merely on the ground
that he is a competitor. (Kores Manufacturing Co., Ltd. v. Kolak Manufacturing Co., Ltd. [1959] Ch.
20. The result of the above discussion is that considerations against restrictive covenants are
different in cases where the restriction is to apply during the period after the termination of the
contract than those in cases where it is to operate during the period of the contract. Negative
covenants operative during the period of the contract of employment when the employee is bound to
serve his employer exclusively are generally not regarded as restraint of trade and therefore do not
fall under section 27 of the Contract Act."
(ii) Superintendence Co. of India (P) Ltd. v. Krishan Murgai (1981) 2 SC 246 :
"28. A contract, which has for its object a restraint of trade, is prima facie, void.
Section 27 of the Contract Act is general in terms and unless a particular contract can
be distinctly brought within Exception 1 there is no escape from the prohibition. We
have nothing to do with the policy of such a law. All we have to do is to take the words
of the Contract Act and put upon the meaning which they appear plainly to bear. This
view of the Section was expressed by Sir Richard Couch C.J. in celebrated judgment
in Madkub Chunder v. Rajcoomar Doss [1874] Beng L.R. 76 laying down that
whether the restraint was general or partial, unqualified or qualified, if it was in the
nature of a restraint of trade, it was void.Desiccant Rotors International Pvt. ... vs Bappaditya Sarkar & Anr on 14 July, 2009

34. A contract in restraint of trade is one by which a party restricts his future liberty
to carry on his trade, business or profession in such manner and with such persons as
he chooses. A contract of this class is prima facie void, but is becomes binding upon
proof that the) restriction is justifiable in the circumstances as being reasonable from
the point CS(OS) No.337/2008 8 of 16 of view of the parties themselves and also of
the community.
61. The Courts, therefore, view with disfavour a restrictive covenant by an employee
not to engage in a business similar to or competitive with that of the employer after
the termination of his contract of employment."
(iii) Percept D' Mark (India) (P) Ltd. v. Zaheer Khan & Anr. (2006) 4 SCC 227 :
"31. the interpretation of restraint of trade during the post-contractual period, which
interpretation has been uniform, consistent and unchanged for the past several years
since the judgment of Sir RichardCouch, C.J. in Madhup Chunder v. Rajcoomar Doss
(1874) 14 Beng. L.R. 76. The interpretation of Section 27 of the Contract Act which
found prima facie favour with the Division Bench is one which has been uniformly
and consistently followed Page 1430 from 1874 till 2006 by all High Courts in India,
and which has expressly been approved by this Court in Niranjan Shankar Golikari
(supra), Superintendence Company of India (supra) and Gujarat Bottling (supra).
Even if there were a case for reconsideration of this 132-year old interpretation,
though none is made out by the appellant, such an exercise ought not to be
undertaken in the present interlocutory proceedings.
37. On the pleadings contained in the Arbitration Petition, there can be no escape from the
conclusion that what the appellant sought to enforce was a negative covenant which, according to
the appellant, survived the expiry of the agreement. This, the High Court has rightly held is
impermissible as such a clause which is sought to be enforced after the term of the contract is prima
facie void under Section 27 of the Contract Act.
Page 1432 It was contended by learned senior counsel for the appellant that Clause 31(b) is not
prima facie void as (i) it allegedly does not travel beyond the term because it is an independent
contract; (ii) the term of agreement was itself extendable and never came to an end; (iii) the words
"initial term" denote that Clause 31(b) itself resulted in an automatic extension of the term; and
CS(OS) No.337/2008 9 of 16
(iv) the "full term" contemplated was beyond the "initial term" of 3 years."
13. Defendant No. 1 has submitted two judgments besides those that are above-mentioned. These
are as follows :
(i) Pepsi Foods Ltd. & Ors. V. Bharat Coca-Cola Holdings Pvt.Desiccant Rotors International Pvt. ... vs Bappaditya Sarkar & Anr on 14 July, 2009

Ltd. & Ors. 81 (1991) DLT 122 wherein it has been held that post termination restraint on an
employee is in violation of Section 27 of the Indian Contract Act, 1872. A contract containing such a
clause is unenforceable, void and against public policy and since it is prohibited by law it cannot be
allowed by the Courts injunction. If such injunction was to be granted, it would directly curtail the
freedom of employees for improving their future prospects by changing their employment and such
a right cannot be restricted by an injunction. It would almost be a situation of „economic terrorism
creating a situation alike to that of bonded labour.
(ii) Wipro Ltd. v. Beckman Coulter International S.A 2006 (3) ARBLR 118 (Delhi) wherein it has
been held that negative covenants between employer and employee contracts pertaining to the
period post termination and restricting an employees right to seek employment and/or to do
business in the same field as the employer would be a restraint of trade and therefore, a stipulation
to this effect in the contract would be void. No employee can be confronted with a situation where he
has to either work for the present employer or be forced to idleness. Also, in such a contract the
employer has advantage over the CS(OS) No.337/2008 10 of 16 employee and it is quite often the
case that employees have to sign standard form contracts or not be employed at all.
14. The stance of Indian courts on the question of restraint on trade is unmistakably clear. There are
no two ways about the fact that the approach towards a negative covenant subsisting during the
course of employment is completely different from the approach which would be taken towards the
applicability of a negative covenant post-employment duration. The Obligation Agreement dated
June 12, 2007, amongst other things, provides that (i) for two years after termination of
employment, Defendant No. 1 would not compete with the plaintiffs business and would not
advise, consult, serve or assist any party whose business competes with that of the plaintiff and its
group companies; (ii) for two years he would not interfere with the relationship of the plaintiff and
its customers, suppliers and employees; that he would not disclose the confidential information to
which he was privy as employee of plaintiff to any third party. The plaintiff has stated that the
agreements it has relied upon (including the above-mentioned obligation agreement) are not in the
form of restraint on trade but are only instruments through which it attempting to protect its
confidential and proprietary information to which the Defendant No. 1 was privy. The plaintiff at
present is unable to produce any cogent evidence to prove its allegations against Defendant No. 1.
Rather the said defendant had, prior to the filing of the suit, sent a letter to the plaintiff asking it to
remit his dues towards his employment.
15. I have no doubt that such was the intention of the plaintiff, but with equal conviction I believe
that such is the intention of all employers who rely on like negative covenants in employment
contracts with their CS(OS) No.337/2008 11 of 16 employees. It is this attempt to protect themselves
from competition which clashes with the right of the employees to seek employment where so ever
they choose and in a clash like this, it is clear that the right of livelihood of the latter must prevail.
Clearly, in part at least, the Obligation Agreement sought to restrain Defendant No. 1 from seeking
employment with an employer dealing in competitive business with the plaintiff after he had ceased
to be an employee of the plaintiff, and that too for a period of two years. Such an act cannot be
allowed in view of the crystal clear law laid on this issue. However, in the impugned order dated
February 20, 2008 the injunction restraining Defendant No. 1 is limited in scope, in the sense that itDesiccant Rotors International Pvt. ... vs Bappaditya Sarkar & Anr on 14 July, 2009

does not restrain the Defendant No. 1 from working with Defendant No. 2 or any other
person/company, thereby steering clear of impinging the formers freedom to choose his own work
place. The injunction only restrains Defendant No. 1 from approaching the plaintiffs suppliers and
customers for soliciting business which is in direct competition with the business of the plaintiff.
Hence, the injunction which has already been granted by order dated February 20, 2008 is made
absolute. The interim application is disposed of accordingly.
16. Defendant No. 1 has filed I.A No. 5454/2008 for reference of the parties dispute to arbitration
based on the Confidentiality Agreement dated October 22, 2000 which contains an arbitration
clause that reads, "in case of any dispute, the matter will be settled under the Indian Arbitration
Act." In keeping with the said arbitration clause, Defendant No. 1 prays that the dispute between the
parties be referred to arbitration for settlement.
17. The plaintiff has referred the following judgments in support of its contention which can be seen
vis-à-vis the following :
CS(OS) No.337/2008                                                  12 of 16
   (i)         In Union of India v. Kishorilal Gupta and Bros. AIR
1959 Supreme Court 1362 it was held that "(1) An arbitration clause is a collateral term of a contract
as distinguished from its substantive terms; but none the less it is an integral part of it; (2) however
comprehensive the terms of an arbitration clause may be, the existence of the contract is a necessary
condition for its operation, it perishes with the contract; (3) the contract may be non est in the sense
that it never came legally into existence or it was void ab initio; (4) though the contract was validly
executed , the parties may put an end to it as if it had never existed and substitute a new contract for
it solely governing their rights and liabilities thereunder; (5) in the former case, if the contract had
no legal existence, the arbitration clause also cannot operate, for along with the original contract, it
is also void; in the latter case, as the original contact is extinguished with the substituted one, the
arbitration clause of the original contract perishes with it; and (6) between the two fall many
categories of disputes in connection with a contract, such as the question of repudiation, frustration,
breach etc. In those cases it is the performance of the contract that has to come to an end, but the
contract is still in existence for certain purposes in respect of disputes arising under it or in
connection with it. As the contract subsists for certain purposes, the arbitration clause operates in
respect of these purposes."
(ii) In Damodar Valley Corporation v. K.K Kar (1974) 1 Supreme Court Cases 141 it was held that "it
may also be open to parties to terminate the previous contract and substitute in its place CS(OS)
No.337/2008 13 of 16 a new contract or alter the original contract in such a way that it cannot
subsist. In all these cases, since the contract is put an end to, the arbitration clause, which is a part
of it, also perished along with it. Section 62 of the Contract Act incorporates this principle when it
provides that if the parties to a contract agree to substitute a new contract or to rescind or alter it,
the original contract need not be performed."Desiccant Rotors International Pvt. ... vs Bappaditya Sarkar & Anr on 14 July, 2009

18. The Plaintiffs contention is that the arbitration clause is not applicable as the Confidentiality
Agreement has been superseded by the Employment Agreement as well as the Obligation
Agreement, and both these subsequent documents contain no arbitration clause. As per the Plaintiff,
due to these subsequent agreements the Confidentiality Agreement was mutually terminated and
hence the arbitration clause does not apply to the parties thereto.
19. I accept the contentions of the plaintiff in view of settled law. The arbitration clause in the
present circumstances is not applicable as the Confidentiality Agreement has been superseded by
the Employment Agreement and Obligation Agreement, both of which contain no arbitration clause.
Hence I.A. No. 5454/2008 is dismissed being not maintainable.
20. The third application is filed by Defendant No. 2 with regard to its deletion from the array of
parties. The applicant herein submits that it has no legal or contractual relationship with the
plaintiff. It also submits that it far exceeds the enterprise and experience of the plaintiff in their
similar line of work, and therefore it has no requirement of any confidential information which
emits from the plaintiff or anyone else. It also iterates that it has received no such confidential
information as alleged.
CS(OS) No.337/2008 14 of 16
21. Defendant No. 2 also submits that no cause of action has been disclosed against it and avers that
the true intent of the plaintiff is to restrain Defendant No. 2 from entering the Indian market as
Defendant No. 2 is a global leader of these products and the plaintiff has a virtual monopoly over the
same in India. Defendant No. 2 further submits that it has been the market leader in the industry
and had launched the product that the plaintiff distributes in India over 30 years back. Accordingly,
there is no factual basis for an apprehension that the Defendant No. 2 would be requiring and using
the technical know-how of the plaintiff. Irrespective of that, it is submitted that the Defendant No. 2
has not received confidential information of any nature from the plaintiff or Defendant No. 1 at any
point in time and that the plaintiff has only made vague allegations as to the same without placing
anything on record to support its allegations.
22. In its reply, the plaintiff has stated that Defendant No. 2 is a necessary party as it is in possession
of confidential information of the plaintiff which it has obtained from Defendant No. 1 with mala
fide intention. In fact, the plaintiff submits that the Defendant No. 1 has been engaged in its services
by Defendant No. 2 with mala fide intention. The Defendant No. 2 is allegedly using the said
information for illegal gains in the market. The plaintiff submits that it has valid grievances and
claims against Defendant No. 2 and if the latter is deleted from the array of parties, effective
adjudication of the dispute will not be possible. Also, Defendant No. 1 has allegedly contacted
suppliers and customers of the plaintiff on behalf of Defendant No. 2 who is enjoying illegal gains
with the same to the detriment of the plaintiff.
CS(OS) No.337/2008 15 of 16Desiccant Rotors International Pvt. ... vs Bappaditya Sarkar & Anr on 14 July, 2009

23. Defendant No. 2 has submitted that its impleadment in the present suit is motivated and is an
abuse of the courts process. The sole intention behind Defendant No. 2s impleadment is to stall
its progress as it is a new entrant in the Indian market. In view of all of the above-stated, I am of the
view that the plaintiff has failed to show any cause of action against Defendant No. 2. The present
application is allowed and Defendant No. 2 is deleted from the array of parties as it is not connected
with the present suit by virtue of the fact that there exists no contractual relationship between the
plaintiff and Defendant No. 2. However, if the plaintiff has any evidence that any act of Defendant
No. 2 amounts to infringement of its legal and valid rights, including technical know-how or
information of other such nature of which the plaintiff is the rightful owner, then he is at liberty to
initiate legal action in accordance with law. On the mere basis of apprehension, a party cannot be
sued. The present application filed by Defendant No. 2 is therefore allowed.
List the matter on 14th September, 2009 before the Joint Registrar.
JULY 14, 2009                                   MANMOHAN SINGH, J.
nn
      CS(OS) No.337/2008                                                    16 of 16Desiccant Rotors International Pvt. ... vs Bappaditya Sarkar & Anr on 14 July, 2009

