B.Thenmozhi vs The Secretary To Government on 1 February,
2023
Bench: M.Sundar, M.Nirmal Kumar
                                                                                HCP No.1615 of 2022
                                      IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                    DATED: 01.02.2023
                                                          Coram
                                            The Hon'ble Mr. Justice M.SUNDAR
                                                             and
                                         The Hon'ble Mr. Justice M.NIRMAL KUMAR
                                                 H.C.P.No.1615 of 2022
                     B.Thenmozhi                                                   .. Petitioner
                                                           -vs-
                     1.The Secretary to Government,
                       Home, Prohibition and Excise Department,
                       Fort St. George, Chennai – 9.
                     2.The Commissioner of Police,
                       Greater Chennai, Egmore, Chennai.
                     3.The Superintendent,
                       Central Prison – 1,
                       Puzhal, Chennai – 600 006.
                     4.The Inspector of Police (L&O),
                       D3, Icehouse Police Station,
                       Chennai.                                                 .. Respondents
                                  Petition filed under Article 226 of the Constitution of India
                     praying to issue a Writ of Habeas Corpus directing the respondents to
                     produce the petitioner's son B.Balaji, S/o.Balu, male, aged about 28
                     years, and now confined at Central Prison, Puzhal, Chennai before this
                     Court and set him at liberty forthwith by setting aside the order of
                     detention bearing BCDFGISSSV No.133/2022 dated 02.06.2022 on the
                     file of the second respondent.
                     Page 1 of 11
https://www.mhc.tn.gov.in/judis
                                                                                            HCP No.1615 of 2022B.Thenmozhi vs The Secretary To Government on 1 February, 2023

                                        For Petitioner     :         Mr.A.Thirumaran
                                        For Respondents :            Mr.R.Muniyapparaj
                                                                     Additional Public Prosecutor
                                                               ORDER
[Order of the Court was made by M.SUNDAR, J.] Captioned 'habeas corpus petition' (hereinafter
'HCP' for the sake of convenience and clarity) has filed in this Court on 17.08.2022 assailing a
'detention order dated 02.06.2022 bearing reference BCDFGISSSV No.133/2022' (hereinafter
'impugned detention order' for the sake of convenience and clarity) made by the 'second
respondent/jurisdictional Commissioner of Police' (hereinafter 'detaining authority' for the sake of
convenience and clarity).
2. Mother of the detenu is the petitioner before us in the captioned HCP. The impugned detention
order has been made on the premise that the detenu is a 'Goonda' within the meaning of definition
of Goonda under Section 2(f) of 'The Tamil Nadu Prevention of Dangerous Activities of Bootleggers,
Cyber law offenders, Drug- Offenders, Forest Offenders, Goondas, Immoral Traffic Offenders,
https://www.mhc.tn.gov.in/judis Sand-Offenders, Sexual offenders, Slum-Grabbers and Video
Pirates Act, 1982 (Tamil Nadu Act 14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake of
convenience and clarity].
3. Mr.A.Thirumaran, learned counsel for petitioner and Mr.R.Muniyapparaj, learned State
Additional Public Prosecutor for all the respondents (instructed by the fourth respondent) are
before us. To be noted, fourth respondent is the sponsoring authority.
4. As regards the substratum of the impugned detention order, there are two adverse cases and a
ground case. The ground case is Crime No.167 of 2022 for the alleged offence under Sections 294(b),
336, 427, 324, 307, 392, 397 and 506(ii) of Indian Penal Code, 1860 on the file of the fourth
respondent.
5. It is not necessary to dilate much on facts owing to the short point on which captioned HCP turns.
6. Learned counsel for petitioner, notwithstanding very many grounds in the support affidavit,
projected two points in the hearing and the two points are as follows:
https://www.mhc.tn.gov.in/judis
(i) The detention order has been made on 02.06.2022 and that is the day on which
bail petition of the detenu being Crl.M.P.No.8406 of 2022 was dismissed by the
learned Principal Sessions Judge, Chennai. It was digitally signed at 17.37 hours andB.Thenmozhi vs The Secretary To Government on 1 February, 2023

it was uploaded later.
The impugned detention order together with translation and a Section 161 Cr.P.C. statement from
sister of detenu could not have been prepared on the same day. This turns on non-application of
mind is learned counsel's say.
(ii) The live and proximate link between the grounds of detention and the purpose of detention has
snapped as the occurrence qua ground case was on 10.04.2022, detenu surrendered on 20.04.2022
and the impugned detention order has been made only on 02.06.2022.
7. In response to the aforesaid two points, learned State Additional Public Prosecutor made
submissions which are as follows:
https://www.mhc.tn.gov.in/judis On a demurer, even if the dismissal order qua
aforementioned bail petition had been uploaded at 7 p.m. there was still 5 hours left
on 02.06.2022 and therefore there is no difficulty in making the impugned detention
order on the same day and detaining authority cannot be faulted for the same. This
therefore cannot be urged as a ground by the petitioner to dislodge the impugned
detention order is his say. On the available records, it is possible to make a detention
order between 7 p.m. and 12 midnight on a given day by making translation of two
pages of bail dismissal order together with half page 161 statement from the detenu's
sister.
We find the submission of learned Additional Public Prosecutor acceptable and
therefore we are not inclined to accept this first ground. To be noted we find the
submission of learned Additional Public Prosecutor acceptable as the above exercise
is clearly doable in five hours.
8. This takes us to the second ground. As regards the argument of live and proximate link snapping
i.e., live and proximate https://www.mhc.tn.gov.in/judis link between the grounds of detention and
purpose of detention, we draw inspiration from Banik case i.e., Sushanta Kumar Banik Vs. State of
Tripura & others reported in 2022 LiveLaw (SC) 813 :
2022 SCC Online SC 1333. In Banik case, the matter arose under 'PIT NDPS Act'
('Prevention of Illicit Traffic in Narcotic Drugs and Psychotropic Substances Act,
1988') and the Honourable Supreme Court has held that this point has to be
considered on a case to case basis. The Honourable Supreme Court also held that this
point has two facets. One facet is unreasonable delay and the other facet is
unexplained delay. In the case on hand, this delay between the date of occurrence i.e.,
10.04.2022 (to be noted the detenu voluntarily surrendered on 20.04.2022) and the
detention order (dated 02.06.2022) has been raised in the affidavit in sub-paragraph
(xii) of paragraph 9 captioned GROUNDS and the same reads as follows:B.Thenmozhi vs The Secretary To Government on 1 February, 2023

'9 (xii) That the time lapse from 10.04.2022 and 02.06.2022 has not been explained
by the fourth respondent herein and this aspect has not even been gone through by
the second respondent while passing the impugned order.'
9. The aforementioned ground has been met by the State in the counter affidavit in paragraph 18,
which reads as follows:
https://www.mhc.tn.gov.in/judis '18. I respectfully submit that the averment made
in Paragraph Ground (xii) of the affidavit is not correct. The sponsoring authority has
already initiated a proposal for the detention of the detenu as Goonda under the
Tamil Nadu Act 14 of 1982, stating that the activities of the detenu in the adverse
cases and in the ground case (Attempt to murder case) are prejudicial to the
maintenance of public order and peace. After perusal of the proposal of the
sponsoring authority, the detaining authority called for further details. In the special
report of the sponsoring authority has furnished additional particulars for the
consideration of the detaining authority. After careful consideration, the detaining
authority has passed the order of detention of the detenu as Goonda under the Tamil
Nadu Act 14 of 1982 on 02.06.2021 (sic.02.06.2022) in accordance with law.'
10. From the aforementioned i.e., the point as articulated by the petitioner in the affidavit and the
manner in which it has been met by the State, leaves us with the considered view that the case on
hand will fall under the latter facet i.e., unexplained delay as the explanation qua delay lacks
specificity. To be noted this view is on the facts and circumstances of the case on hand.
https://www.mhc.tn.gov.in/judis
11. To be noted, relevant paragraph in Banik case is paragraph 20 in the Live Law report and
paragraph 21 in the SCC Online report, which reads as follows:
'20. It is manifestly clear from a conspectus of the above decisions of this Court, that
the underlying principle is that if there is unreasonable delay between the date of the
order of detention & actual arrest of the detenu and in the same manner from the
date of the proposal and passing of the order of detention, such delay unless
satisfactorily explained throws a considerable doubt on the genuineness of the
requisite subjective satisfaction of the detaining authority in passing the detention
order and consequently render the detention order bad and invalid because the “live
and proximate link” between the grounds of detention and the purpose of detention
is snapped in arresting the detenu. A question whether the delay is unreasonable and
stands unexplained depends on the facts and circumstances of each case.'
12. We considered the live and proximate link between the grounds of detention and
purpose of detention snapped plea on the facts/circumstances of the case on hand,
we find that the argument that the link has in fact snapped is sustainable inter alia as
explanation of the State is vague and it lacks specificity as already alluded toB.Thenmozhi vs The Secretary To Government on 1 February, 2023

https://www.mhc.tn.gov.in/judis supra.
13. As the detenu succeeds on the 'live and proximate link' snapping point, the
sequitur is, captioned HCP is allowed.
14. Ergo, the further sequitur is, the impugned detention order dated 02.06.2022
bearing BCDFGISSSV No.133/2022 is set aside and detenu Balaji, male, aged 28
years, S/o.Balu, is directed to be set at liberty forthwith, if not required in connection
with any other case.
(M.S., J.) (M.N.K., J.) 01.02.2023 Index:Yes/No Neutral Citation : Yes/No mmi P.S:
Registry to forthwith communicate this order to Jail authorities in Central Prison,
Puzhal, Chennai.
To
1.The Secretary to Government, Home, Prohibition and Excise Department, Fort St. George,
Chennai – 9.
2.The Commissioner of Police, Greater Chennai, Egmore, Chennai.
3.The Superintendent, Central Prison – 1, Puzhal, Chennai – 600 006.
https://www.mhc.tn.gov.in/judis
4.The Inspector of Police (L&O), D3, Icehouse Police Station, Chennai.
5.The Public Prosecutor, High Court, Madras.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J.
and M.NIRMAL KUMAR, J.
mmi 01.02.2023 https://www.mhc.tn.gov.in/judisB.Thenmozhi vs The Secretary To Government on 1 February, 2023

