Arjun Gopal vs Union Of India . on 23 October, 2018
Equivalent citations: AIR 2018 SUPREME COURT 5731, 2019 (13) SCC 523,
AIRONLINE 2018 SC 291, (2018) 14 SCALE 209, (2019) 1 ALL WC 455, 2019 (1)
KCCR SN 9 (SC), (2019) 73 OCR 427, AIR 2019 SC (CIV) 722
Author: A.K. Sikri
Bench: Ashok Bhushan, A.K. Sikri
                                                                                        REPORTABLE
                                                IN THE SUPREME COURT OF INDIA
                                                   CIVIL ORIGINAL JURISDICTION
                                              IA NOS. 6 AND 8 OF 2016
                         IA NOS. 10, 11, 80176, 96202, 109668, 109720 AND 122778 OF 2017
                                          IA NOS. 68888 AND 68897 OF 2018
                                                         IN
                                      WRIT PETITION (CIVIL) NO. 728 OF 2015
                         ARJUN GOPAL AND OTHERS                                  .....APPELLANT(S)
                                                        VERSUS
                         UNION OF INDIA AND OTHERS                             .....RESPONDENT(S)
                                                                     WITH
                                            WRIT PETITION (CIVIL) NO. 891 OF 2016
                                            WRIT PETITION (CIVIL) NO. 895 OF 2016
                                            WRIT PETITION (CIVIL) NO. 899 OF 2016
                                                                      AND
                                            WRIT PETITION (CIVIL) NO. 213 OF 2017
                                                           JUDGMENT
A.K. SIKRI, J.
Writ Petition (Civil) No. 728 of 2015 was filed on September 24, 2015 on behalf of three infants, whoArjun Gopal vs Union Of India . on 23 October, 2018

are made petitioners in this writ petition. Petitioner No.1 and 2, on the date of filing of this writ
petition, were six months old and petitioner No.3 was fourteen months old. This petition has been
filed through their next friends, i.e. their fathers, who are concerned about the health of their
children as they feel that due to the alarming degradation of the air quality, leading to severe air
pollution in the city of Delhi (where these petitioners reside), the petitioners may encounter various
health hazards. Poor, very poor or severe air quality/air pollution affects all citizens, irrespective of
their age. However, claim the petitioners, children are much more vulnerable to air pollutants as
exposure thereto may affect them in various ways, including aggravation of asthma, coughing,
bronchitis, retarded nervous system breakdown and even cognitive impairment. The petition
accepts that there are number of reasons which have contributed to poor air quality in Delhi and
National Capital Region (for short, ‘NCR’). At the same time, it is emphasised that air pollution hits
its nadir during Diwali time because of indiscriminate use of firecrackers, the chemical composition
whereof increases harmful particulate matters such as PM 2.5 or PM10 at alarming level thereby
bringing the situation of ‘emergency’. The petitioners have, thus, prayed for direction to the official
respondents to take possible measures for checking the pollution by stricking at the causes of the
pollution, which includes seasonal crop burning, indiscriminate dumping of dust/malba and other
pollutants, etc. The prayer also includes banning the use, in any form, of firecrackers, sparkles and
minor explosives, in any form, during festivals or otherwise.
2) This petition came up for preliminary hearing on October 08, 2015 when notice was issued and
the matter was directed to be listed on October 16, 2015 at 2:00 p.m. since the petitioners wanted
stay on burning of crackers during Diwali, which was around the corner in that year. When the
matter was taken up on October 16, 2015, certain suggestions were made by the learned counsel
appearing for the petitioners, which were as under:
“1. Restrict licenses to low hazard fireworks.
2. Period of grant of license is too early – need not be from 2 days prior to Dussehra.
3. Restrict window for use of fireworks to be from 7:00 p.m. to 9:00 p.m.
4. RWAs to hold community fireworks for a brief period of 30 minutes on a single day.
5. Government be directed to give wide publicity to the ill effects of fireworks and encourage
restraint on responsible use.
6. Encourage teachers to tell students not to buy and use fireworks.”
3) Suggestion Nos. 5 and 6 were accepted and the relevant portion of the order that was passed
reads as under:
“In our view for the present, if we accept suggestion Nos. 5 and 6 it will not in any
way affect the interest of the respondents.Arjun Gopal vs Union Of India . on 23 October, 2018

Shri Ranjit Kumar, learned Solicitor General appearing for the Union of India states
that the Union Government has already taken enough and effective steps to give wide
publicity to the ill effects of fireworks.
In spite of the submission so made by the learned Solicitor General, we intend to pass
the following order:
“The Union Government and all the State Governments will give wide publicity both
in print and Electronic media to the ill effects of fireworks and advise people
accordingly.
We also direct the Teachers/Lecturers/Assistant Professors/ Professors of the
Schools and Colleges to educate the students about the ill effects of the fireworks.””
4) Thereafter, this petition was taken up along with certain other connected petitions,
including Writ Petition (Civil) No. 13029 of 1985 titled ‘M.C. Mehta v. Union of India’
and orders dated December 16, 2015 were passed issuing several directions with a
view to reducing the levels of air pollution within the NCR, as the issues in those writ
petitions pertained to air pollution in Delhi and NCR as well. It may be mentioned
that the directions issued therein were general in nature though concerning the
problem of air pollution. Thereafter also the instant writ petition, along with the M.C.
Mehta case and other cases, came up for hearing and it is not necessary to take note
of all those orders.
5) Pertinently, during Diwali of 2016, which was celebrated on October 30, 2016, the
air quality in Delhi and NCR worsened alarmingly. In fact, certain reports indicated
that the air quality standards in early November of that year were the worst in the
world. This prompted the Court to take up IA No.4 filed in this writ petition. After
hearing the parties, it passed orders dated November 11, 2016.
6) The petitioners had pressed for interim relief in respect of fireworks, drawing the
attention of this Court to the emergent situation that has resulted in worsening the
air quality standards in Delhi and National Capital Region (NCR) because of
extensive use of fireworks, including firecrackers during Diwali last year. It was
pointed out that onset of winter itself deteriorates air quality in this region and it gets
aggravated because of festival/marriage season that occurs during these very months.
Taking note of the aforesaid factors, particularly impact of fireworks on the ambient
air and unhealthy effects thereof which had created unprecedented situation in Delhi,
with air pollution going up at alarming levels and making it the most polluted city in
the world, the order dated November 11, 2016 was passed. Air pollution had gone up
to 29 times above the World Health Organisation (WHO) standards. In the aforesaid
scenario, this Court deemed it proper to pass certain directions vide its order dated
November 11, 2016 in IA No.4. Snapping the supply chain of fireworks was
considered to be the more practical way of addressing the menace instead of banningArjun Gopal vs Union Of India . on 23 October, 2018

the burning the crackers by individuals as it would have been difficult to monitor and
enforce the burning of the crackers by the citizenry.
7) In paragraph 18 of the Order dated November 11, 2016 it was clarified that much
was left to be heard, discussed and said about the rival claims and contentions.
However, the Court hastened to add that harmful effects of fireworks on the ambient
air and the lungs, eyes and ears of people was also an acknowledged fact, as can be
seen from the following portion of the said paragraph:
“18. We are aware that we are only issuing interim directions, and much is left to be
heard, discussed and said about the rival claims and contentions. What is however
indisputable is that the harmful effects of fireworks on the ambient air and the lungs,
eyes and ears of people. What is also obvious is the extreme nuisance, noise the
fireworks cause to citizens particularly the ailing and the aged. Therefore, though
much can be argued as always about the significance and even joy of bursting
fireworks, but at the same time (sic), prima facie, a just constitutional balance must
overwhelmingly prioritize the harmful effects of this hazardous air on present and
future generations, irreversible and imperceptible as they are, over the immediate
commercial constraints of the manufacturers and suppliers of fireworks…”
8) In the process, this Court also recognised the duty of the State to ensure a healthy
environment in terms of Article 48A of the Constitution of India as well as the duty of
the citizens to ensure the same under Article 51A(g) of the Constitution. The Court
also reminded itself of the “precautionary principle” which mandates that where
there are threats of serious and irreversible damage, lack of scientific certainty should
not be used as a reason for postponing measures to prevent environmental
degradation. In the order the Court had taken note of the deleterious effects of air
pollution on the health of the people, particularly the children.
Going by all these considerations, the Court passed the following directions:
“19. We thus consider it inappropriate that explosives which are used as fireworks
should be available in the market in the NCR till further orders. The mechanism of
the law in this regard is clear. Rule 118 of the Explosive Rules, 2008, framed under
the Explosives Act, 1884, provides for the manner in which licenses issued under the
Explosives Act to store and sell explosives could be suspended or cancelled. Sub-Rule
(5) thereof specifically confers on the Central Government a power to suspend or
cancel a license if it considers that it is in public interest. This provision also makes it
clear that an opportunity to hear the licensee could be dispensed with if the Central
Government considers that in public interest. This Court finds that the grave air
quality situation in NCR is one such case, where this Court, can intervene and
suspend the licenses to store and sell fireworks in the NCR. We direct the Central
Government to:Arjun Gopal vs Union Of India . on 23 October, 2018

(i) Suspend all such licenses as permit sale of fireworks, wholesale and retail within
the territory of NCR.
(ii) The suspension shall remain in force till further orders of this Court.
(iii) No such licenses shall be granted or renewed till further orders.
20. In addition to the above, we direct the CPCB to study and prepare a report on the harmful effects
of the materials which are currently being used in the manufacture of fireworks. The report shall be
submitted within a period of three months to this Court.”
9) Since direction was given to the Central Pollution Control Board (CPCB) to study and prepare a
report of the harmful effects of the materials which are currently being used in the manufacture of
fireworks and submit a report within three months, the matter was taken up for consideration
thereafter from time to time.
10) Thereafter, the manufacturers of firecrackers as well as license holders also filed applications for
modification of the aforesaid interim order. It included IA No. 52448 of 2017. Because of these
applications, the matter was heard by a Bench of this Court and orders dated September 12, 2017
were passed in the aforesaid IA. In this order also, the Court recognised severity of air pollution in
Delhi and NCR. The Court also discussed the manner in which air quality had worsened due to
fireworks during Diwali days in the year 2016. The Court took note of the steps that were taken by
different authorities aiming to reduce air pollution after the passing of orders dated November 11,
2016;
the legal provisions contained in the Explosives Act, 1884 and the Explosive Rules, 2008 framed
thereunder; and further steps which were needed in this behalf to reduce the pollution in Delhi and
NCR. The Court took note of the fact that number of measures were required to be taken for
improving air quality as various factors were contributing to the air pollution. It also specifically
mentioned that one of the reasons was burning of crackers/fireworks during Diwali. On that basis,
the Court also accepted that one of the possible methods for reducing it during Diwali is by
continuing the suspension of licenses for the sale of fireworks, thereby implicitly prohibiting the
bursting of fireworks. However, at the same time, the Court expressed the opinion that continuing
the suspension of licenses might be too radical a step to take for the present. It was deemed
appropriate to adopt a graded and balanced approach, which is necessary, that will reduce and
gradually eliminate air pollution in Delhi and in the NCR caused by the bursting of fireworks. In the
process, the Court took into consideration the interest of those who had already been granted a valid
permanent licence to posses and sell fireworks in Delhi and the NCR. We would like to reproduce
the following paragraphs from the said order:
“67. The right to health coupled with the right to breathe clean air leaves no manner
of doubt that it is important that air pollution deserves to be eliminated and one of
the possible methods of reducing it during Diwali is by continuing the suspension of
licences for the sale of fireworks and therefore implicitly, prohibiting the bursting ofArjun Gopal vs Union Of India . on 23 October, 2018

fireworks.
68. In our considered opinion, continuing the suspension of licences might be too
radical a step to take for the present – a graded and balanced approach is necessary
that will reduce and gradually eliminate air pollution in Delhi and in the NCR caused
by the bursting of fireworks. At the same time it is necessary to ensure that injustice
is not caused to those who have already been granted a valid permanent licence to
possess and sell fireworks in Delhi and the NCR. The graded and balanced approach
is not intended to dilute our primary concern which is and remains the health of
everybody and the human right to breathe good quality air or at least not be
compelled to breathe poor quality air. Generally speaking this must take precedence
over the commercial or other interest of the applicant and those granted a permanent
licence to possess and sell fireworks.
69. But, from the material before us, it cannot be said with any great degree of
certainty that the extremely poor quality of air in Delhi in November and December
2016 was the result only of bursting fireworks around Diwali.
Certainly, there were other causes as well, but even so the contribution of the bursting of fireworks
cannot be glossed over. Unfortunately, neither is it possible to give an accurate or relative
assessment of the contribution of the other identified factors nor the contribution of bursting
fireworks to the poor air quality in Delhi and in the NCR. Consequently, a complete ban on the sale
of fireworks would be an extreme step that might not be fully warranted by the facts available to us.
There is, therefore, some justification for modifying the interim order passed on 11 th November,
2016 and lifting the suspension of the permanent licences.
70. At the same time, it cannot be forgotten that admittedly there is a huge quantity of fireworks in
Delhi and in the NCR and the figure has been provided to us by the applicant. Similarly, there can be
no doubt that the Delhi Police had issued a large number of temporary licences in 2016 and it would
not be unreasonable to assume that around and during Diwali, there would have been some illegal
temporary shops set up, whether known or not known to the police. We do not have the figures with
regard to the NCR, but we assume that like in Delhi, a large number of temporary licences have been
issued for the possession and sale of fireworks. Therefore, there is a need to regulate the availability
and sale of fireworks in Delhi and the NCR.”
11) It was followed by the following directions:
“71. As mentioned above, the health of the people in Delhi and in the NCR must take
precedence over any commercial or other interest of the applicant or any of the
permanent licensees and, therefore, a graded regulation is necessary which would
eventually result in a prohibition. Taking all factors into consideration, we are of the
view that the following orders and directions are required to be issued and we do so:Arjun Gopal vs Union Of India . on 23 October, 2018

(1) The directions issued by this Court in Sadar Bazar Fire Works (Pucca Shop)
Association shall stand partially modified to the extent that they are not in
conformity with the Explosives Rules which shall be implemented in full by the
concerned authorities. Safety from fire hazards is one of our concerns in this regard.
(2) Specifically, Rule 15 relating to marking on explosives and packages and Rule 84
relating to temporary shops for possession and sale of fireworks during festivals of
the Explosives Rules shall be strictly enforced. This should not be construed to mean
that the other Rules need not be enforced – all Rules should be enforced. But if the
fireworks do not conform to the requirements of Rules 15 and 84, they cannot be sold
in the NCR, including Delhi and this prohibition is absolute.
(3) The directions issued and restrictions imposed in the order passed by this Court
on 18th July, 2005 in Noise Pollution (V) shall continue to be in force. (4) The
concerned police authorities and the District Magistrates will ensure that fireworks
are not burst in silence zones that is, an area at least 100 meters away from hospitals,
nursing homes, primary and district health-
care centres, educational institutions, courts, religious places or any other area that may be declared
as a silence zone by the concerned authorities.
(5) The Delhi Police is directed to reduce the grant of temporary licences by about 50% of the
number of licences granted in 2016. The number of temporary licences should be capped at 500.
Similarly, the States in the NCR are restrained from granting more than 50% of the number of
temporary licences granted in 2016. The area of distribution of the temporary licences is entirely for
the authorities to decide.
(6) The Union of India will ensure strict compliance with the Notification GSR No. 64(E) dated 27th
January, 1992 regarding the ban on import of fireworks. The Union of India is at liberty to update
and revise this notification in view of the passage of time and further knowledge gained over the last
25 years and issue a fresh notification, if necessary.
(7) The Department of Education of the Government of NCT of Delhi and the corresponding
Department in other States in the NCR shall immediately formulate a plan of action, in not more
than 15 days, to reach out to children in all the schools through the school staff, volunteers and
NGOs to sensitize and educate school children on the health hazards and ill-effects of breathing
polluted air, including air that is polluted due to fireworks. School children should be encouraged to
reduce, if not eliminate, the bursting of fireworks as a part of any festivities. (8) The Government of
NCT of Delhi and other States in the NCR may consider interacting with established medical
institutions for issuing advisories cautioning people about the health hazards of bursting fireworks.
(9) The interim direction issued by this Court on 31st July, 2017 prohibiting the use of compounds
of antimony, lithium, mercury, arsenic and lead in the manufacture of fireworks is made absolute.
In addition, the use of strontium chromate in the manufacture of fireworks is prohibited.Arjun Gopal vs Union Of India . on 23 October, 2018

(10) Fireworks containing aluminum, sulphur, potassium and barium may be sold in Delhi and in
the NCR, provided the composition already approved by PESO is maintained. It is the responsibility
of PESO to ensure compliance of the standards it has formulated.
(11) Since there are enough fireworks available for sale in Delhi and the NCR, the transport of
fireworks into Delhi and the NCR from outside the region is prohibited and the concerned law
enforcement authorities will ensure that there is no further entry of fireworks into Delhi and the
NCR till further orders. In our opinion, even 50,00,000 kg of fireworks is far more than enough for
Dussehra and Diwali in 2017. The permanent licensees are at liberty to exhaust their existing stock
of fireworks in Delhi and the NCR and, if that is not possible, take measures to transport the stocks
outside Delhi and the NCR.
(12) The suspension of permanent licences as directed by the order dated 11th November, 2016 is
lifted for the time being. This might require a review after Diwali depending on the ambient air
quality post Diwali. However, it is made explicit that the sale of fireworks by the permanent
licensees must conform to the directions given above and must be fully in compliance with the
Explosives Rules. We were informed that the permanent licences were issued by PESO and therefore
the responsibility is on PESO to ensure compliance.
(13) While lifting the suspension on the permanent licences already granted, we put these licensees
on notice for Dussehra and Diwali in 2018 that they will be permitted to possess and sell only 50% of
the quantity permitted in 2017 and that this will substantially reduce over the next couple of years.
The permanent licensees are at liberty to file objections to this proposed direction within 30 days
from today and thereafter the objections if any will be heard and decided. If no objections are filed,
this direction will become absolute without any further reference to any licensee.
(14) Since there is a lack of clarity on the safety limits of various metals and constituents used in
fireworks, a research study must be jointly carried out by the CPCB and the FRDC laying down
appropriate standards for ambient air quality in relation to the bursting of fireworks and the release
of their constituents in the air. While Schedule VII of the Environment (Protection) Rules, 1986
does deal with several metals, but as we have seen there are several other metals or constituents of
fireworks that have not been studied by the CPCB and no standards have been laid down with
regard to the concentration of these metals or constituents in the ambient air. The CPCB has assured
us that it will complete the exercise by 15th September, 2017 but keeping in mind its track record
subsequent to the order dated 11th November, 2016 this does not seem possible. Therefore, we grant
time to the CPCB to come out with definite standards on or before 30th September, 2017.
(15) In any event, a research study also needs to be conducted on the impact of bursting fireworks
during Dussehra and Diwali on the health of the people. We, therefore, appoint a Committee to be
chaired by the Chairperson of the CPCB and consisting of officers at the appropriate level from the
National Physical Laboratory, Delhi, the Defence Institute of Physiology and Allied Sciences,
Timarpur, Delhi, the Indian Institute of Technology-Kanpur, scientists from the State Pollution
Control Boards, the Fire Development and Research Centre, Sivakasi and Nagpur and the National
Environment Engineering Research Institute (NEERI) nominated by the Chairperson of the CPCBArjun Gopal vs Union Of India . on 23 October, 2018

to submit a report in this regard preferably on or before 31st December, 2017.
(16) Keeping in mind the adverse effects of air pollution, the human right to breathe clean air and
the human right to health, the Central Government and other authorities should consider
encouraging display fireworks through community participation rather than individual bursting of
fireworks.”
12) After the aforesaid order was passed, many applications were filed, from both sides, seeking
modification of some of the aforesaid directions. Insofar as the petitioners are concerned, in their
application for modification, they prayed for removal of Directions Nos. 5 and 10 to 13, which was in
essence a prayer for restoration of earlier order dated November 11, 2016. Insofar as fireworks
manufacturers, traders and license holders of the fireworks/firecrackers are concerned, they wanted
that relaxation given in the order dated September 12, 2017 be further liberalised.
13) After hearing both the parties, orders dated October 09, 2017 were passed. The Court accepted
the fact that burning of firecrackers during Diwali was not the only reason for air pollution in Delhi
and NCR and there was a need to tackle those factors as well. However, it was observed that the
immediate impact of use of fireworks and firecrackers bursting during Diwali is an altogether
different aspect. The Court noted that there is direct evidence of deterioration of air quality at
alarming levels, which happens every year. Burning of these firecrackers during Diwali in 2016 had
shot up PM levels by three times, making Delhi the worst city in the world insofar as air pollution is
concerned. Direct and immediate cause thereof was burning of crackers during Diwali. The Court
also remarked that every year before Diwali there are attempts on the part of the Government
(Ministry of Environment, Government of India as well as Delhi Government), Media, NGOs and
various other groups to create awareness in the general public about the ill-effects of bursting of
these crackers. Campaigns are held in the schools wherein children are discouraged to have
fireworks. Thus, there is virtually a consensus in the society that crackers should not be burnt during
Diwali, which can be celebrated with equal fervour by various other means as well. Irony is that
when causes are brought in the Court, there is a resistance from certain quarters. Moreover, there
are adequate statutory provisions, aid whereof can be taken to ban the sale of these crackers.
14) The Court also took into consideration three substantial submissions which were made by the
petitioners, viz.: (a) CPCB had taken a stand, nearly twenty years ago, that Sulphur in fireworks
should not be permitted as Sulphur on combustion produces Sulphur Dioxide and the same is
extremely harmful to health. The CPCB has stated that between 9:00 p.m. to midnight on Diwali day
the levels of Sulphur Dioxide content in the air are dangerously high. Moreover, all the above
authorities were also unanimous in their view that crackers should only be burst in designated
places. Also the CPCB had specifically stated that joined crackers should be banned. Secondly, in the
order dated November 11, 2016, licenses were suspended primarily for the reason that rising in the
PM levels at alarming proportion was because of burning of crackers during Diwali, which had
adverse harmful affect and, therefore, there was no reason to relax this condition. Another
significant argument which was taken note of was that the order dated November 11, 2016 was
passed immediately after the Diwali in the year 2016 and the effect of that order had not been
tested. Going by these considerations, the Court decided to suspend the order dated September 12,Arjun Gopal vs Union Of India . on 23 October, 2018

2017 at least during the Diwali of 2017 with the following directions:
“14...To put it clearly, though we are not tweaking with the various directions
contained in the Orders dated September 12, 2017, the effect of that Order would not
be given during this Diwali and, therefore, we are making it effective only from
November 01, 2017. We are conscious of the fact that after the said order was passed,
the police may have issued temporary licences. Accordingly, those are suspended
forthwith so that there is no further sale of the crackers in Delhi and NCR. Further
orders in this behalf can be passed on assessing the situation that would emerge after
this Diwali season...”
15) As expected, spate of applications have been filed, most of which emanate from
the aforesaid orders dated October 09, 2017. Many parties have intervened. Most of
the interventionists are supporting the petitioners and want permanent ban on the
burning of crackers during Diwali. Some have even prayed that this ban be extended
to the whole country and should not be limited to only Delhi and NCR. IAs were also
filed seeking ban on crop burning. The opposite group consists of manufacturers of
crackers, manufacturers’ association and license holders. The State of Tamil Nadu
has come forward to support this category.
Additionally, one interventionist, namely Indic Collective (applicant in IA No. 105355 of 2017), is
also opposing the ban contending that burning of crackers during Diwali is a religious activity which
is in vogue for time immemorial and, therefore, it should not be banned.
16) It is not necessary to take note of the arguments of each of the counsel appearing on either side.
For the sake of convenience, arguments of the petitioners as well as those who have supported the
petitioners’ cause and the arguments of the other group which is opposing the prayers made by the
petitioners, are collated and we state below these arguments and counter arguments in consolidated
manner:
17)     Petitioners’ Arguments:
       (a)     As far as the petitioners are concerned, they have
proceeded on the premise that undeniable fact is that as a result of burning of crackers during
Diwali PM2.5 reach an alarmingly high level which certainly is injurious to health. It is argued that
the adverse affect thereof on the health of citizens, particularly children, is irreversible. It causes
asthma, coughing, bronchitis, retarded nervous system breakdown and even cognitive impairment.
(b) The official respondents had failed to address the issues and carry out desired studies in spite of
the directions of this Court. Various committees set up are examining the question as to what kind
of metal should be used in the manufacture of crackers. So far no study has been conducted on the
ill-effect caused by PM2.5.Arjun Gopal vs Union Of India . on 23 October, 2018

(c) Studies by CPCB had categorically found that burning of crackers during Diwali was contributing
to air as well as noise pollution in an alarming manner. Copies of these studies showing continuous
ambient air quality during Diwali annexed with IA No. 109720 of 2017 is referred to. Contents of the
affidavit of CPCB dated January 05, 2018 has also been relied upon.
The petitioners also rely upon the report filed by the Union of India, through the Ministry of
Environment, Forest and Climate Change, wherein ill-effects of fireworks are accepted and
measures suggested to tackle the same.
Opinions of prominent doctors mentioning spike in the respiratory problems among children and
patients are also pointed out.
(d) Dealing with the argument of the manufacturers and traders of firecrackers based on Article
19(1)(g) of the Constitution of India, namely, fundamental right to carry on business, the submission
of the petitioners is that going by the ill-effects of the firecrackers, no such right can be claimed as
principle of res extra commercium would apply. In support, additional affidavit filed on July 26,
2017 as well as in July 2018 are referred to wherein the petitioners have sought to highlight the
following aspects:
(i) These manufacturers were employing child labour. At one point of time, almost
one lakh children were employed in this industry. Though it was admitted that this
position does not exist any longer in view of strict measures taken by the
Government.
(ii) The manufacturing of firecrackers generates a lot of waste which adds to pollution
as sufficient measures are not undertaken to deal with this waste.
(iii) Number of deaths as well as injuries to persons are caused every year due to poor
storage which results in occasional accidents. Likewise, the burning of these crackers
also results in injuries.
(iv) Firework also leads to lot of noise and air pollution as well. Judgments of this
Court in Vellore Citizens' Welfare Forum v. Union of India and Others, (1996) 5 SCC
647;
and A.P. Pollution Control Board v. Prof. M.V. Nayudu (Retd.) and Others, (1999) 2 SCC 718, have
been relied upon.
In the alternative, it was argued that even if it is accepted that argument of Article 19(1)(g) of the
Constitution is available to the manufacturers and traders, such a ban on burning crackers during
Diwali would amount to reasonable restriction having regard to the fact that right to health was also
a fundamental right guaranteed under Article 21 of the Constitution. It was also submitted that the
cost in the form of medical expenses which are incurred for treatment of those who suffered as a
result of burning of crackers is equally high or even may be higher.Arjun Gopal vs Union Of India . on 23 October, 2018

(e) One of the arguments of the opposite side was that there were no sufficient studies as to what
extent the burning of crackers is contributing towards air and noise pollution and whether it was
such a serious problem which warrants ban. To this, reply of the petitioners was that in the field of
environmental laws, precautionary principle was also applicable which does not need exact studies
or material.
(f) Insofar as argument of burning of crackers during Diwali, as a part of right of religious practice is
concerned, the refutation of the petitioners is that such an argument has already been rejected by
this Court in Vellore Citizens' Welfare Forum case.
It was further submitted that burning of crackers during Diwali is not a core and essential religious
practice and even if it is so, Article 25 was subject to Article 21 of the Constitution. Judgment in
Noise Pollution (V), in Re, (2005) 5 SCC 733, was relied upon in this regard.
18) Arguments of the opposite side:
The respondents, who are opposing the prayers made in the writ petitions and the IAs, made the
submissions to the following effect:
(i) Burning of crackers during Diwali does not have any significant adverse affect on
the environment. It is argued that there is no study till date which has come to such a
conclusion.
The Deepawali Monitoring Report, 2017 of CPCB is relied upon for this purpose and on that basis it
is contended that the factors which contributed to the problem were not because of crackers burning
during Diwali. Ambient air quality before and after Diwali reflects that there was no spike
immediately after Diwali. It was accepted that situation of air pollution in Delhi and NCR is
'generally' worrying. However, there are multiple causes which lead to polluting air and such a
position existed even before Diwali, which showed that other factors played dominant role.
(ii) Insofar as presence of PM2.5 in the air is concerned, studies of CPCB are relied upon, on the
basis of which attempt is made to show that: (a) spike was not so much during Diwali days; (b)
increase in PM2.5 in the air does not remain for long, i.e. it does not linger for many days; and (c) it
is manageable as well.
Reports of Indian Institute of Technology, Kanpur; National Aeronautics and Space Administration
(NASA), USA; a professor from Harvard University; and an affidavit dated January 05, 2018 filed by
CPCB were referred to in support.
(iii) It is submitted that pursuant to orders dated September 12, 2017 whereby the Court had
directed that a research study needs to be conducted on the impact of bursting fireworks during
Dussehra and Diwali on the health of people, no such empirical data has emerged so far for want of
detailed studies.Arjun Gopal vs Union Of India . on 23 October, 2018

In nutshell, the argument was that in the absence of any definite study attributing the worsening of
air quality to the fireworks during Diwali, the right of the manufacturers and traders under Article
19(1)(g), which is a fundamental right to carry on trade, should not be made to suffer till the time
there is a complete study in this behalf.
(iv) It is also argued that the revenue generated from the manufacturing and sale of fireworks is to
the tune of Rs.6,000 crores per annum. Further, this industry has given employment to five lakh
families. Such a revenue to the State as well as employment to large number of workers on which
five lakh families sustain cannot be put in jeopardy by imposing a total ban. It was emphasised that
there is a necessity to adopt a balanced approach. For this purpose, Status Report and affidavit of
the Ministry of Environment, Forest and Climate Change has been relied upon which suggested
eco-friendly firecrackers. Advisory dated March 07, 2008 issued by the Petroleum and Explosives
Safety Organisation (PESO), which comes under the Department of Industrial Policy and
Promotion, Ministry of Commerce and Industry, Government of India, was also relied upon, as per
which the fireworks manufacturers in India were advised to ensure that the firecrackers
manufactured by them are within the limits prescribed in Annexure-I to the said Advisory dated
March 07, 2008.
(v) The State of Tamil Nadu also supported the cause of the manufacturers and traders of the
firecrackers. It was argued that the study undertaken by CPCB pursuant to the directions issued by
this Court was conducted by the Committee which did not have a representative from the Fireworks
Research and Development Centre (FRDC) which was not even informed about the development of
this case. It was emphasised that any proper study in this behalf should address following aspects:
a) Socio-economic effect of the ban needs to be examined as it may cause extreme
economic hardship,
b) There should be a proper study about the other factors which were leading to air
pollution, like construction activity, etc., which are not banned.
c) Banning of an activity is an extreme measure.
The study should focus on the alternatives available in the present day technology which may be
deployed to ensure that pollution free firecrackers can be manufactured.
(vi) Indic Collective (applicant in IA No. 105355 of 2017) opposed the prayer of banning of fireworks
during Diwali on the ground that it was a religious practice scrupulously followed by the Hindus
from time immemorial and it had become a core and essential religious practice which was
protected under Article 25 of the Constitution as their fundamental right.
19) The arguments of the parties recorded above would show that the submissions for and against
almost remain the same, which were advanced on earlier occasions, though the focus of both the
sides was more nuanced. In the process, the events and developments which have taken place after
passing the order dated October 09, 2017 have also been relied upon by both the parties.Arjun Gopal vs Union Of India . on 23 October, 2018

20) Before proceeding to deal with these submissions, it may be apposite to take note of the study
that has been undertaken by CPCB on the basis of the directions of this Court in its order dated
September 12, 2017.
21) Following the directions of this Court, a Committee was appointed to be chaired by the
Chairperson of the CPCB. This Committee invited Dr. M.K. Daga, Professor Director, Maulana Azad
Medical College (MAMC), as health expert to study the methodology. Dr. Daga suggested that
considering the time available, a short-term study based on questionnaire survey, hospital data
collection and sampling at a few locations can be conducted. This methodology proposed by Dr.
Daga was agreed to by the Committee. The Committee requested MAMC to submit a proposal
accordingly. On submission of project proposal, the Committee awarded the project on 'Health
Impact Assessment on Firecracker Burning During Dussehra And Diwali' to MAMC. The scope
included questionnaire survey for respiratory, skin, air, eye and relevant symptoms during pre and
post Diwali, clinical study on lung function and urine samples of randomly selected subjects, and
data analysis. After conducting this survey, a draft report was prepared and ultimately it was
finalised after incorporating the comments from the Members of the Committee. As per this study
on the afore-mentioned subject, following are the major findings:
"The respiratory system related symptoms and sings were not much different during
pre and post Dussehra and Diwali. Although there was some increase in cough and
breathlessness, but this did not translate into any significant illness requiring
immediate medical attention. Other system related complaints were also not much
different during pre and post Dussehra and Diwali.
There was evidence of increased values of barium and strontium in urine samples of
many subjects. These are some of the metals used in firecracker manufacturing.
Increased levels in urine do reflect a probability of exposure. However, all other
elements are not increased to substantiate the effect of bursting of firecrackers. It is
also possible that the individuals were exposed due to bursting of firecrackers directly
or indirectly in their locality.
Air quality did worsen during Diwali and symptoms of eye, increased coughing,
relatively more hospital visits, increased noise levels and high metal levels in urine do
reflect adverse impact of firecracker bursting. However, it was not significant
statistically. A long term study would be required to assess long term health impacts
of firecracker bursting."
22) Affidavit filed by CPCB also states that in compliance of the orders dated October 09, 2017 of
this Court the Air Quality Monitoring Committee during Dussehra and Diwali was conducted by
CPCB, a report whereof is annexed with its affidavit. As per that report, the salient features are as
under:
“a) That, slight increase in PM10 concentration was observed in two locations i.e.
Pitampura and Siri Fort on Dussehra day.Arjun Gopal vs Union Of India . on 23 October, 2018

b) That, PM2.5 mass concentrations were found lower on post Dussehra day at all
stations and it was highest on pre Dussehra day.
c) That the concentrations of SO2 and NO2 during pre Dussehra, Dussehra and post
Dussehra days remained within limits.
d) That, though the actual PM2.5 mass concentrations were declined on Dussehra
day, certain specific elemental concentration like Aluminum, Potassium and Barium
showed increment on Dussehra day, which indicate some firecracker bursting has
affected air quality.
e) That, on Diwali day both PM10 and PM2.5 increased 2-
3.5 fold of the levels recorded seven days before Diwali and the Diwali peaks of PM2.5 declined in
three days.
f) Both PM10 and PM2.5 were reported higher in post Diwali day compared to pre Diwali at all
stations.
g) SO2 remained within prescribed standard limit with slight increment on Diwali day. NO 2 also
reported within standard limit at all locations on Diwali day.
h) That, the elements like Al, S, K, Cl 2, Ba, Sr all have registered their presence in PM2.5 collected
on Diwali day, and the concentration of Al observed 4 to 6 times higher than that of short-term
standards/critical values of 40 ug/m3 proposed by CPCB.
i) PM2.5 was reduced by 39% compared to 2016 Diwali day.
j) Sulphur got reduced by 20%, Potassium by 30%, Ca, Cu, Zn, Sb by about 35-40%, Fe&Ba by about
50%, Strontium by 64% and Al and Cl2 by 11%."
23) It can be discerned from the above that the air quality had worsened during Diwali. There were
more patients with symptoms of eye, increased coughing and patients with high metal levels in
urine. Even noise level had increased. These are the adverse impacts of firecracker bursting, though
the study mentions that statistically it was not a significant increase.
24) The study has also found that actual PM 2.5 mass concentrations increased due to firecracker
bursting, which had affected air quality. On Diwali day both PM10 and PM2.5 had 2-3.5 fold
increase. Also, PM10 and PM2.5 were reported higher in post- Diwali day compared to pre-Diwali at
all stations. Another significant finding is that PM 2.5 was reduced by 39% compared to 2016
Diwali, presumably due to the ban order on the sale of crackers which was passed on October 09,
2017, which led to lesser quantum of fireworks.Arjun Gopal vs Union Of India . on 23 October, 2018

25) Two significant features emerge from the above. First, due to fireworks on Diwali day, PM2.5
levels go up. Secondly, when there was lesser fireworks in 2017, it had reduced the PM 2.5 levels as
compared to the earlier Diwali in the absence of ban.
26) It is an accepted fact that bursting of firecrackers during Diwali is not the only reason for
deterioration of air quality. There are other factors as well. It calls for necessity to tackle the other
contributory factors for air pollution and making the air quality as 'very poor' and even 'poor'.
Unregulated construction activity which generates lot of dust and crop burning in the neighbouring
States are the two other major reasons, apart from certain other reasons, including vehicular
pollution etc. The moot question in such a scenario is as to whether the menace due to fireworks
during Diwali or other festivals/occasions should be left untouched and the Court should allow the
situation to prevail as it is, only because it is not the sole reason for causing air pollution? Answer
has to be in the negative.
27) Once it is accepted that PM2.5 level goes alarmingly higher on Diwali and post-Diwali, which is
the result of bursting of firecrackers, it is necessary to understand the adverse affect on health of
persons of this particulate in air, even if such a situation remains only for few days. In this behalf,
we may refer to the opinions of some experts/prominent doctors in the field, which have been
placed on record by the petitioners.
28) Dr. Arvind Kumar, who interfered in the matter, filed his affidavit on August 14, 2018, wherein
he has inter alia stated as under:
"7. I have consistently found that in the immediate aftermath of Diwali, there is an
increase in the number of people coming with chest ailments and many of my
operated patients returned with complaints of cough and breathlessness without any
other cause for the same. This has forced me to carry out innumerable chest x-rays
and CT scans to confirm that the complaints are due to the exposure to toxins. For
the sake of relief to the patient and in order to relieve them from bronchospasms, my
colleagues and I are compelled to prescribe inhalers which have brochodilators and
inhaled steroids, apart from cough suppressants and antibiotics. Media reports
suggest that there has been an increase in asthma medicine sales by 43% due to
pollution (Hindustan Times, May 02, 2017). While earlier, it was believed that
children with asthma would outgrow the affliction, in the present circumstances, this
seems challenging.
8. Both at AIIMS and at Sir Ganga Ram Hospital, there has been a significant
increase in the number of patients I would see in my OPD in the days immediately
following Diwali, and I have no doubt that this was on account of sudden exposure to
the deadly cocktail consisting of extremely high levels of toxic gases, particulate
matter and metallic compounds. Each exposure to firework emissions not only leads
to acute disastrous effects but also causes cumulative long-term irreversible damage.
Once the PM 2.5 particle gets deposited in the lungs, it never leaves, thereby affecting
the linking for life and diminishing breathing capacity. This affects not only theArjun Gopal vs Union Of India . on 23 October, 2018

respiratory system, but also the cardio-vascular system (heart attacks and
hypertension), nervous system (strokes and developmental abnormalities in
children), reproductive system and virtually every other health function including the
bladder and kidneys.
9. It would be useful to refer to two studies conducted ten years apart by a team
including Prof. Sundeep Salvi, Director Chest Research Foundation, Pune and
Member of the Government of India's Steering Committee on Air Pollution & Health.
The first one in 2007 was presented at the Annual Congress of the European
Respiratory Society at Stockholm and reveals the harmful health effects of CO, SOx
and NOx from fireworks.
10. The second is a detailed study on the amount of Particulate Matter in various
types of fireworks in India and this was presented at the meeting of the European
Respiratory Society at Milan in 2017. This has since been published in the European
Respiratory Journal, and examines the personal exposure levels of fireworks (as
against a general study of ambient air). In these isolated and controlled
circumstances, the exposure to PM 2.5 was found to be as high as 64,5000 u/m3."
29) From the aforesaid it can be gathered that when PM 2.5 crosses the normal limits, even if it
remains in the air for few days, it becomes severe health hazard thereby causing serious health
problems. Unfortunately such problems are virtually irreversible, which means that a person whose
health gets affected because of this particulate has a long suffering. In view thereof, argument in
opposition that air quality that gets worsened during Diwali remains only for few days would be of
no consequence as even in few days it causes severe harm to the health of the people, that too for
prolonged duration.
30) From the aforesaid discussion, the position can be summed up by stating that though burning of
crackers during Diwali is not the only reason for worsening air quality, at the same time, it definitely
contributes to air pollution in a significant way. Again, even when no studies are undertaken on
long-term impact thereof, the CPCB Committee, which did this exercise taking it as a short-term
project which was assigned to MAMC, has returned a definite finding about deterioration in air
quality during Diwali because of burning of crackers. It has also shown that post-
Diwali air pollution in 2017 was less compared to the 2016 Diwali which was the result of lesser
fireworks in 2017. This again indicates a direct causal connection between burning crackers during
Diwali and air pollution. Another immediate effect of burning of crackers is that it results in
substantial increase in PM2.5 level which is a very serious health hazard. In fact, this results in
severe noise pollution as well which has acute psychological, mental and even physical affect on
animals. In the application seeking intervention and directions (IA No. 68897 of 2018) filed by
Gauri Maulekhi, the applicant has placed on record plethora of literature based on various studies
depicting profound affect of noise/sound on the health of animals, extending to their
neuroendocrine system, reproduction and development, metabolism, cardiovascular health,
cognition and sleep, audition, immune system, DNA integrity and gene expression. FireworksArjun Gopal vs Union Of India . on 23 October, 2018

sometimes results in temporary or permanent hearing impairment in animals. Further, dogs are
also known to display psychological symptoms of stress during this time. So much so, fireworks has
traumatising affect even on birds. Deafening sound which the crackers produce on bursting are
known to disorient birds and responsible for their displacement from their nests. Even the
respiratory system of the birds gets affected. Studies also show that the sound of crackers has affect
on milch cattle. As the cattle is scared, adrenaline is released in its body which inhibits oxytocin, a
hormone which helps the milk cattle to release milk thereby affecting the production of milk.
31) The aforesaid findings are sufficient to negate the arguments of the opposite side that there is
absence of scientific study about the adverse affect of firecrackers during Diwali. In environmental
law, 'precautionary principle' is one of the well recognised principles which is followed to save the
environment. It is rightly argued by the petitioners that this principle does not need exact
studies/material. The very word 'precautionary' indicates that such a measure is taken by way of
precaution which can be resorted to even in the absence of definite studies. In Vellore Citizens'
Welfare Forum, this Court explained the principle in the following manner:
"11. Some of the salient principles of “Sustainable Development”, as culled out from
Brundtland Report and other international documents, are Inter-Generational
Equity, Use and Conservation of Natural Resources, Environmental Protection, the
Precautionary Principle, Polluter Pays Principle, Obligation to Assist and Cooperate,
Eradication of Poverty and Financial Assistance to the developing countries. We are,
however, of the view that “The Precautionary Principle” and “The Polluter Pays
Principle” are essential features of “Sustainable Development”. The “Precautionary
Principle” — in the context of the municipal law — means:
(i) Environmental measures — by the State Government and the statutory authorities
— must anticipate, prevent and attack the causes of environmental degradation.
(ii) Where there are threats of serious and irreversible damage, lack of scientific
certainty should not be used as a reason for postponing measures to prevent
environmental degradation.
(iii) The “onus of proof” is on the actor or the developer/industrialist to show that his
action is environmentally benign.
xx xx xx
14. In view of the above-mentioned constitutional and statutory provisions we have
no hesitation in holding that the Precautionary Principle and the Polluter Pays
Principle are part of the environmental law of the country.
15. Even otherwise once these principles are accepted as part of the Customary
International Law there would be no difficulty in accepting them as part of the
domestic law. It is almost an accepted proposition of law that the rules of CustomaryArjun Gopal vs Union Of India . on 23 October, 2018

International Law which are not contrary to the municipal law shall be deemed to
have been incorporated in the domestic law and shall be followed by the courts of
law. To support we may refer to Justice H.R. Khanna's opinion in A.D.M. v.
Shivakant Shukla, Jolly George Varghese case and Gramophone Co. case.
16. The constitutional and statutory provisions protect a person's right to fresh air,
clean water and pollution-free environment, but the source of the right is the
inalienable common law right of clean environment..."
32) The precautionary principle accepted in the aforesaid judgment was further elaborated in A.P.
Pollution Control Board's case as under:
"31. The “uncertainty” of scientific proof and its changing frontiers from time to time
has led to great changes in environmental concepts during the period between the
Stockholm Conference of 1972 and the Rio Conference of 1992. In Vellore Citizens'
Welfare Forum v. Union of India a three-Judge Bench of this Court referred to these
changes, to the “precautionary principle” and the new concept of “burden of proof” in
environmental matters. Kuldip Singh, J. after referring to the principles evolved in
various international conferences and to the concept of “sustainable development”,
stated that the precautionary principle, the polluter-pays principle and the special
concept of onus of proof have now emerged and govern the law in our country too, as
is clear from Articles 47, 48-A and 51-A(g) of our Constitution and that, in fact, in the
various environmental statutes, such as the Water Act, 1974 and other statutes,
including the Environment (Protection) Act, 1986, these concepts are already
implied. The learned Judge declared that these principles have now become part of
our law. The relevant observations in the Vellore case in this behalf read as follows:
(SCC p. 660, para 14) “14. In view of the above-mentioned constitutional and
statutory provisions we have no hesitation in holding that the precautionary principle
and the polluter-pays principle are part of the environmental law of the country.”
(emphasis supplied) The Court observed that even otherwise, the abovesaid
principles are accepted as part of the customary international law and hence there
should be no difficulty in accepting them as part of our domestic law. In fact, on the
facts of the case before this Court, it was directed that the authority to be appointed
under Section 3(3) of the Environment (Protection) Act, 1986 “shall implement the
‘precautionary principle’ and the ‘polluter-pays principle’”.
The learned Judges also observed that the new concept which places the burden of
proof on the developer or industrialist who is proposing to alter the status quo, has
also become part of our environmental law.
32. The Vellore judgment has referred to these principles briefly but, in our view, it is
necessary to explain their meaning in more detail, so that courts and tribunals or
environmental authorities can properly apply the said principles in the matters which
come before them.Arjun Gopal vs Union Of India . on 23 October, 2018

33. A basic shift in the approach to environmental protection occurred initially
between 1972 and 1982. Earlier, the concept was based on the “assimilative capacity”
rule as revealed from Principle 6 of the Stockholm Declaration of the U.N.
Conference on Human Environment, 1972. The said principle assumed that science
could provide policy-makers with the information and means necessary to avoid
encroaching upon the capacity of the environment to assimilate impacts and it
presumed that relevant technical expertise would be available when environmental
harm was predicted and there would be sufficient time to act in order to avoid such
harm. But in the 11th Principle of the U.N. General Assembly Resolution on World
Charter for Nature, 1982, the emphasis shifted to the “precautionary principle”, and
this was reiterated in the Rio Conference of 1992 in its Principle 15 which reads as
follows:
“Principle 15.—In order to protect the environment, the precautionary approach shall
be widely applied by States according to their capabilities. Where there are threats of
serious or irreversible damage, lack of full scientific certainty shall not be used as a
reason for proposing cost-effective measures to prevent environmental degradation.”
34. In regard to the cause for the emergence of this principle, Charmian Barton, in
the article earlier referred to in Vol. 22, Harv. Envtt. L. Rev. (1998), p. 509 at p. 547
says:
“There is nothing to prevent decision-makers from assessing the record and
concluding that there is inadequate information on which to reach a determination. If
it is not possible to make a decision with ‘some’ confidence, then it makes sense to err
on the side of caution and prevent activities that may cause serious or irreversible
harm. An informed decision can be made at a later stage when additional data is
available or resources permit further research. To ensure that greater caution is taken
in environmental management, implementation of the principle through judicial and
legislative means is necessary.” In other words, the inadequacies of science is the real
basis that has led to the precautionary principle of 1982. It is based on the theory that
it is better to err on the side of caution and prevent environmental harm which may
indeed become irreversible.
35. The principle of precaution involves the anticipation of environmental harm and
taking measures to avoid it or to choose the least environmentally harmful activity. It
is based on scientific uncertainty. Environmental protection should not only aim at
protecting health, property and economic interest but also protect the environment
for its own sake. Precautionary duties must not only be triggered by the suspicion of
concrete danger but also by (justified) concern or risk potential. The precautionary
principle was recommended by the UNEP Governing Council (1989).
The Bomako Convention also lowered the threshold at which scientific evidence might require
action by not referring to “serious” or “irreversible” as adjectives qualifying harm. However,Arjun Gopal vs Union Of India . on 23 October, 2018

summing up the legal status of the precautionary principle, one commentator characterised the
principle as still “evolving” for though it is accepted as part of the international customary law, “the
consequences of its application in any potential situation will be influenced by the circumstances of
each case”. (See First Report of Dr Sreenivasa Rao Pemmaraju — Special Rapporteur, International
Law Commission dated 3-4-1998, paras 61 to 72.)."
33) In such cases which pertain to the protection of environment, thrusting of 'onus of proof' on the
developer/industrialist in Vellore Citizens' Welfare Forum was also elaborated by the Court in the
following manner:
"36. We shall next elaborate the new concept of burden of proof referred to in the
Vellore case at p. 658. In that case, Kuldip Singh, J. stated as follows: (SCC p. 658,
para 11) “(iii) The ‘onus of proof’ is on the actor or the developer/industrialist to show
that his action is environmentally benign.”
37. It is to be noticed that while the inadequacies of science have led to the
“precautionary principle”, the said “precautionary principle” in its turn, has led to the
special principle of burden of proof in environmental cases where burden as to the
absence of injurious effect of the actions proposed, — is placed on those who want to
change the status quo [Wynne, Uncertainty and Environmental Learning, 2 Global
Envtl. Change 111 (1992) at p. 123]. This is often termed as a reversal of the burden of
proof, because otherwise in environmental cases, those opposing the change would
be compelled to shoulder the evidentiary burden, a procedure which is not fair.
Therefore, it is necessary that the party attempting to preserve the status quo by
maintaining a less polluted state should not carry the burden of proof and the party
who wants to alter it, must bear this burden. [See James M. Olson: “Shifting the
Burden of Proof”, 20 Envtl. Law, p. 891 at p. 898 (1990).] [Quoted in Vol. 22 (1998),
Harv. Env. Law Review, p. 509 at pp. 519, 550.]
38. The precautionary principle suggests that where there is an identifiable risk of
serious or irreversible harm, including, for example, extinction of species, widespread
toxic pollution in major threats to essential ecological processes, it may be
appropriate to place the burden of proof on the person or entity proposing the
activity that is potentially harmful to the environment. (See Report of Dr Sreenivasa
Rao Pemmaraju, Special Rapporteur, International Law Commission, dated
3-4-1998, para 61.)"
34) This brings us to the next argument which is predicated on Article 19(1)(g) of the Constitution.
Mr. Shankarnarayanan had submitted that principle of res extra commercium shall apply inasmuch
as firecrackers are a health hazard, the manufacturers and traders thereof cannot claim any
fundamental right to carry on business in this field. Such a plea may not be tenable.
Therefore, it calls for a measure that would amount to a reasonable restriction.Arjun Gopal vs Union Of India . on 23 October, 2018

35) It may be stressed that in Vellore Citizens' Welfare Forum case, this Court had banned the
tanneries when it was found that they were causing immense damage to the environment. Thus,
environment protection, which is a facet of Article 21, was given supremacy over the right to carry
on business enshrined in Article 19(1)(g). We state at the cost of repetition that right of health,
which is recognised as a facet of Article 21 of the Constitution and, therefore, is a fundamental right,
assumes greater importance. It is not only the petitioners and other applicants who have intervened
in support of the petitioners but the issue involves millions of persons living in Delhi and NCR,
whose right to health is at stake. However, for the time being, without going into this debate in
greater details, our endeavour is to strive at balancing of two rights, namely, right of the petitioners
under Article 21 and right of the manufacturers and traders under Article 19(1)(g) of the
Constitution.
36) Almost for the same reasons, argument predicated on Article 25 of the Constitution need not
detain us. We proceed on the assumption that burning of crackers during Diwali is a part of religious
practice. The question is as to whether it should be allowed to be continued in the present form
without any regulatory measures, as a part of religious practice, even if it is proving to be a serious
health hazard. We feel that Article 25 is subject to Article 21 and if a particular religious practice is
threatening the health and lives of people, such practice is not to entitled to protection under Article
25. In any case, balancing can be done here as well by allowing the practice subject to those
conditions which ensure nil or negligible effect on health.
37) We now deal with the argument that banning the sale of firecrackers may lead to extreme
economic hardship, namely, on the one hand loss of substantial revenue and on the other hand
unemployment to lakhs of persons. This brings up the issue of connect or relationship between the
law and economics. This aspect was considered by this Court in Shivashakti Sugars Limited v. Shree
Renuka Sugar Limited and Others, (2017) 7 SCC 729, and the relevant portion whereof is
reproduced below:
"43...Interface between Law and Economics is much more relevant in today's time
when the country has ushered into the era of economic liberalisation, which is also
termed as “globalisation” of economy. India is on the road of economic growth. It has
been a developing economy for number of decades and all efforts are made, at all
levels, to ensure that it becomes a fully developed economy. Various measures are
taken in this behalf by the policy-makers.
The judicial wing, while undertaking the task of performing its judicial function, is
also required to perform its role in this direction. It calls for an economic analysis of
law approach, most commonly referred to as “Law and Economics” [ Richard A.
Posner in his book Frontiers of Legal Theory explains this concept as
follows:“Economic analysis of law has heuristic, descriptive and normative aspects.
As a heuristic, it seeks to display underlying unities in legal doctrines and
institutions; in its descriptive mode, it seeks to identify the economic logic and effects
of doctrines and institutions and the economic causes of legal change; in its
normative aspect it advises Judges and other policy-makers on the most efficientArjun Gopal vs Union Of India . on 23 October, 2018

methods of regulating conduct through law. The range of its subject-matter has
become wide, indeed all-encompassing. Exploiting advances in the economics of
nonmarket behaviour, economic analysis of law has expanded far beyond its original
focus on antitrust, taxation, public utility regulation, corporate finance, and other
areas of explicitly economic regulation. (And within that domain, it has expanded to
include such fields as property and contract law.) The “new” economic analysis of law
embraces such nonmarket, or quasi-nonmarket, fields of law as tort law, family law,
criminal law, free speech, procedure, legislation, public international law, the law of
intellectual property, the rules governing the trial and appellate process,
environmental law, the administrative process, the regulation of health and safety,
the laws forbidding discrimination in employment, and social norms viewed as a
source of, an obstacle to, and a substitute for formal law.”Posner also mentioned that
this interface between Law and Economics might grandly be called “Economic
Theory of Law”, which is built on a pioneering article by Ronald Coase [R.H. Coase,
“The Problem of Social Cost”, 3 Journal of Law and Economics 1 (1960)]:“The “Coase
Theorem” holds that where market transaction costs are zero, the law's initial
assignment of rights is irrelevant to efficiency, since if the assignment is inefficient
the parties will rectify it by a corrective transaction. There are two important
corollaries. The first is that the law, to the extent interested in promoting economic
efficiency, should try to minimize transaction costs, for example by defining property
rights clearly, by making them readily transferable, and by creating cheap and
effective remedies for breach of contract.…The second corollary of the Coase
Theorem is that where, despite the law's best efforts, market transaction costs remain
high, the law should simulate the market's allocation of resources by assigning
property rights to the highest-valued users. An example is the fair-use doctrine of
copyright law, which allows writers to publish short quotations from a copyrighted
work without negotiating with the copyright holder. The costs of such negotiations
would usually be prohibitive; if they were not prohibitive, the usual result would be
an agreement to permit the quotation, and so the doctrine of fair use brings about the
result that the market would bring about if market transactions were feasible.”] . In
fact, in certain branches of Law there is a direct impact of Economics and economic
considerations play predominant role, which are even recognised as legal principles.
Monopoly laws (popularly known as “Antitrust Laws” in USA) have been transformed
by Economics. The issues arising in competition laws (which has replaced monopoly
laws) are decided primarily on economic analysis of various provisions of the
Competition Commission Act. Similar approach is to be necessarily adopted while
interpreting bankruptcy laws or even matters relating to corporate finance, etc. The
impress of Economics is strong while examining various facets of the issues arising
under the aforesaid laws. In fact, economic evidence plays a big role even while
deciding environmental issues. There is a growing role of Economics in contract,
labour, tax, corporate and other laws. Courts are increasingly receptive to economic
arguments while deciding these issues. In such an environment it becomes the
bounden duty of the Court to have the economic analysis and economic impact of its
decisions."Arjun Gopal vs Union Of India . on 23 October, 2018

38) Applying the aforesaid principle, in the first blush it may appear that the aforesaid argument has
substantial force in it. However, that would be only one side of the picture as there are two contra
arguments which are sufficient to take the sheen out of the aforesaid plea. First aspect is that the
argument of economic hardship is pitched against right to health and life. When the Court is called
upon to protect the right to life, economic effect of a particular measure for the protection of such
right to health will have to give way to this fundamental right. Second factor, which is equally
important, is that the economic loss to the State is pitched against the economic loss in the form of
cost of treatment for treating the ailments with which people suffer as a result of burning of these
crackers. Health hazards in the form of various diseases that are the direct result of burning of
crackers have already been noted above. It leads to asthma, coughing, bronchitis, retarded nervous
system breakdown and even cognitive impairment. Some of the diseases continue on a prolonged
basis. Some of these which are caused because of high level of PM2.5 are even irreversible. In such
cases, patients may have to continue to get the medical treatment for much longer period and even
for life. Though there are no statistics as to what would be the cost for treating such diseases which
are as a direct consequence of fireworks on these occasions like Diwali, it can safely be said that this
may also be substantial. It may be more than the revenue which is generated from the
manufacturers of the crackers. However, we say no more for want of precise statistical data in this
behalf.
39) With this, we come to the most important issue, viz. whether there has to be a complete ban on
display of fireworks during Diwali or it can be controlled/regulated in a manner which may not
result into air pollution or may be least intrusive.
40) It would be significant to mention at this stage that there have been lots of efforts for production
of firecrackers which do not contain harmful chemicals and thereby not causing air pollution, which
are even termed as 'Green Crackers'. The Union of India was asked to delve on this aspect. In fact,
during the hearing of this matter, order was passed on August 14, 2018 giving direction to
respondent No.1 to give its complete suggestions to deal with the problems and issues involved
which have been recapitulated above. This order reads as under:
"Further arguments heard in these matters. Arguments have not been concluded.
We are of the opinion that Union of India/Ministry of Environment should come out
with its concrete suggestions to deal with problems and issues which are involved in
these petitions and what short term measures can be adopted to tackle the pollution
problem which occurs due to firecrackers during Diwali. Such affidavit shall be filed
by or before next date of hearing.
List on 21.8.2018."
41) Pursuant to the aforesaid direction, respondent No.1 has filed its affidavit on August 21, 2018.
This affidavit sates that the Ministry consulted : (i) The Council of Scientific & Industrial Research
(CSIR) - National Environment Engineering Research Institute (NEERI), (ii) PESO, and (iii) CPCB
regarding concrete solutions and short-term measures to be adopted to tackle the pollution problemArjun Gopal vs Union Of India . on 23 October, 2018

which occurs due to firecrackers during Diwali. Suggestions are received from the aforesaid bodies
which are annexed as Annexures R-1, R-2 and R-3 respectively. Based on those suggestions, the
Ministry has given the following short-term measures/actions which it proposes to tackle the
pollution problem due to firecrackers during forthcoming Diwali in November 2018:
“I. To address issue of high contents of unburnt material or partially combusted
material due to usage of poor quality of raw material, Raw Material Characterisation
Facilities shall be established to maintain quality of the raw materials in gun powder
and flash powder as per specifications of PESO. Testing of raw materials shall be
initiated at CSIR - Kaliswari Joint Facility or PESO or any of the other manufacturer
with requisite facilities.
II. Use of Reduced Emission firecrackers (Improved crackers) - (a) Avoidance of use
of ash as desiccant or filler materials in crackers for reduction in particulate mater by
15-20%. These can be implemented subject to approval by PESO, and (b) usage of
charcoal meeting specifications of explosives and pyrotechnics as prescribed by
PESO.
III. Use of Reduced Emission firecrackers (Green crackers: Safe water and air
sprinklers (SWAS) - Low emission sound and light emitting functional crackers with
PM reduction by 30-35% and significant reduction in NOx and SO2 due to in-situ
water generation as dust suppressant and low cost due to usage of low cost oxidants.
These can be implemented subject to approval by PESO.
IV. PESO will ensure fireworks with permitted chemicals only to be
purchased/possessed/sold/used during Diwali and shall test and check for the
presence of banned chemicals like lithium/arsenic/antimony/lead/ mercury. PESO
will ensure suspension of the licenses of manufacturers of such fireworks items and
appropriate disposal of such stock.
V. PESO will ensure that only those crackers whose decibel (sound) level are within
the limits are allowed in the market and will ensure to take action by suspending the
licenses of the manufacturers on such violations and disposal of such lots.
VI. Diwali data of 2017 shows that average PM2.5 was 604 ug/m3, whereas,
Aluminum and Barium in PM2.5 were 159 ug/m3 (about 4 times of AAQCVs) wand
35 ug/m3 (about 9 times of AAQCVs) respectively. Iron was well within the
prescribed limits. Aluminum is used as fuel in fireworks in and to give white brilliant
sparkle. Ba is added to give only attractive green colour which is not essential for
pyrotechnics.
Aluminum may cause dermatitis and having bio- accumulation potential in case of long exposure.
Ba salts emit poisonous gas causing respiratory problem in short-term exposure too and may have
other health complications in long-term exposure. Therefore, as immediate measure, baning ofArjun Gopal vs Union Of India . on 23 October, 2018

Barium salts in fireworks may be considered. PESO may be asked to review the chemical
composition of fireworks, particularly reducing Aluminum content.
VII. CPCB and respective State Pollution Control Boards/ Pollution Control Committees
(SPCBs/PCCs) of the States and Union Territories shall carry out short-term monitoring in their
cities for 14 days (commencing from 7 days prior to Diwali and ending 7 days after Diwali) for the
parameters namely, Aluminum, Barium, Iron apart from the regulatory parameters against the
short-term Ambient Air Quality Criteria Values (AAQCVs) proposed by CPCB with regard to
bursting of firecrackers. This will help in generation of data on pollution caused by the bursting of
firecrackers and would be helpful for regulation and control quantity of Aluminum, Barium and Iron
used in the manufacture of firecrackers.
VIII. The manufacture, sale and use of joined firecrackers (series crackers or laris) may be banned as
the same causes huge air, noise and solid waste problems. IX. Major Indian cities may explore the
option of community firecracking with strict time restriction as adopted in some countries. Other
restriction that can be explored include - bursting of firecrackers may be allowed only in the
areas/fields pre-identified and pre- designated by respective State Governments. X. Extensive public
awareness campaigns shall be taken up by the Central Government/State Governments/
Schools/Colleges informing the public about the harmful effects of firecrackers."
42) We are of the opinion that the aforesaid suggestions strive a nice balance between the two
competing interests. We accept the aforesaid measures as suggested by the Union of India and direct
the Union of India and other concerned authorities to implement the same with immediate effect. In
view thereof, following specific directions are issued:
(i) The crackers with reduced emission (improved crackers) and green crackers, as
mentioned in Suggestion Nos. II and III above only would be permitted to be
manufactured and sold.
(ii) As a consequence, production and sale of crackers other than those mentioned in
Suggestion Nos. II and III is hereby banned.
(iii) The manufacture, sale and use of joined firecrackers (series crackers or laris) is
hereby banned as the same causes huge air, noise and solid waste problems.
(iv) The sale shall only be through licensed traders and it shall be ensured that these
licensed traders are selling those firecrackers which are permitted by this order.
(v) No e-commerce websites, including Flipkart, Amazon etc., shall accept any online
orders and effect online sales. Any such e-commerce companies found selling
crackers online will be hauled up for contempt of court and the Court may also pass,
in that eventuality, orders of monetary penalties as well.
(vi) Barium salts in the fireworks is also hereby banned.Arjun Gopal vs Union Of India . on 23 October, 2018

(vii) PESO is directed to review the clinical composition of fireworks, particularly
reducing Aluminum content, and shall submit its report in respect thereof within a
period of two weeks from today. For undertaking this exercise, PESO would also
associate FRDC.
(viii) Even those crackers which have already been produced and they do not fulfill
the conditions mentioned in Suggestion Nos. II and III above will not be allowed to
be sold in Delhi and NCR.
(ix) PESO will ensure fireworks with permitted chemicals only to be
purchased/possessed/sold/used during Diwali and all other religious festivals, of any
religion whatsoever, and other occasions like marriages, etc. It shall test and check
for the presence of banned chemicals like Lithium/Arsenic/
Antimony/Lead/Mercury.
(x) PESO will ensure suspension of the licenses of manufacturers of such fireworks
items and appropriate disposal of such stock.
(xi) PESO will ensure that only those crackers whose decibel (sound) level are within
the limits are allowed in the market and will ensure to take action by suspending the
licenses of the manufacturers on such violations and disposal of such lots. To add to
it, as mentioned in the order dated September 12, 2017, the directions issued and
restrictions imposed in the order passed by this Court on July 18, 2005 in Noise
Pollution (V) shall continue to be in force.
(xii) Direction Nos. 4 to 9 and 11 contained in the order dated September 12, 2017
shall continue to operate and are reiterated again.
(xiii) Extensive public awareness campaigns shall be taken up by the Central
Government/State Governments/Schools/ Colleges informing the public about the
harmful effects of firecrackers.
(xiv) On Diwali days or on any other festivals like Gurpurab etc., when such fireworks
generally take place, it would strictly be from 8:00 p.m. till 10:00 p.m. only. On
Christmas even and New Year eve, when such fireworks start around midnight, i.e.
12:00 a.m., it would be from 11:55 p.m. till 12:30 a.m. only.
(xv) The Union of India, Government of NCT of Delhi and the State Governments of
the NCR would permit community firecracking only (for Diwali and other festivals
etc. as mentioned above), wherever it can be done. For this purpose, particular
area/fields would be pre-identified and predesignated by the concerned authorities.
This exercise shall be completed within a period of one week from today so that the
public at large is informed about the designated places one week before Diwali. The
areas designated now for the purpose of Diwali shall be valid for communityArjun Gopal vs Union Of India . on 23 October, 2018

firecracking on other occasions/festivals as well, as mentioned above. Even for
marriages and other occasions, sale of improved crackers and green crackers is only
permitted.
Insofar as other States are concerned, an endeavour shall be made by them also to explore the
feasibility of community firecracking. However, it is made clear that Direction No. (xiv) pertaining
to the duration within which fireworks can take place on all such occasions would be applicable
throughout India. Similarly, Direction No. (xiii) for extensive public awareness campaigns is also a
pan India direction.
(xvi) All the official respondents, and particularly the Police, shall ensure that fireworks take place
only during the designated time and at designated places, as mentioned above. They shall also
ensure that there is no sale of banned firecrackers. In case any violation is found, the Station House
Officer (SHO) of the concerned Police Station of the area shall be held personally liable for such
violation and this would amount to committing contempt of the Court, for which such SHO(s) would
be proceeded against.
(xvii) CPCB and respective State Pollution Control Boards/ Pollution Control Committees
(SPCBs/PCCs) of the States and Union Territories shall carry out short-term monitoring in their
cities for 14 days (commencing from 7 days prior to Diwali and ending 7 days after Diwali) for the
parameters namely, Aluminum, Barium, Iron apart from the regulatory parameters against the
short-term Ambient Air Quality Criteria Values (AAQCVs) proposed by CPCB with regard to
bursting of firecrackers. This will help in generation of data on pollution caused by the bursting of
firecrackers and would be helpful for regulation and control quantity of Aluminum, Barium and Iron
used in the manufacture of firecrackers.
43) One clarification needs to be given at this stage. Our discussion pertaining to the arguments
based on Article 19(1)(g), Article 25 as well as the argument of loss of substantial revenue and
unemployment, in cases the manufacture and sale of the firecrackers is totally banned, is prima facie
and we have not given our conclusive determination. It is because of want of detailed studies on
various aspects which have been mentioned and taken note of during discussion in this order.
However, we also make it clear that, prima facie, we do not find much merit in these arguments for
which we have given our reasons in brief.
44) Having regard to the overall circumstances, we have decided that, for the time being, a balanced
approach to tackle this problem is needed, which may take care of the concerns of both the parties
and, at the same time, provide a reasonable and adequate solution. When the picture would become
clearer after the requisite studies/research is undertaken, more stringent measures can be adopted
in future if the situation so warrants.
45) All the interlocutory applications seeking impleadment, intervention, directions, modification,
etc. are disposed of in the aforesaid terms.
46) The writ petitions be listed on December 11, 2018.Arjun Gopal vs Union Of India . on 23 October, 2018

.............................................J. (A.K. SIKRI) .............................................J. (ASHOK BHUSHAN)
NEW DELHI;
OCTOBER 23, 2018.Arjun Gopal vs Union Of India . on 23 October, 2018

