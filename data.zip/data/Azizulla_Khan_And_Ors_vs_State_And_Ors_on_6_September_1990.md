Azizulla Khan And Ors. vs State And Ors. on 6 September, 1990
Equivalent citations: AIR1991RAJ101, 1991(1)WLC132
ORDER
 M.R. Calla, J. 
1. The following cases involving common and identical questions with regard to pre-election matters
in relation to the Municipal Boards and Municipal council were heard together and the same are
being decide d by this common judgment. The details of the cases are as under:--
S. No. No. of cases Title of cases Date of presentationl Municipal Board/ Council
1.
SBCWP No. 3286/90 Azizulla Khan v. State & Ors.
31-7-90 Tonk
2. No. 3428/90 Sabir Ahmed Qureshi v. State & Ors.
10-8-90 Jaipur
3. No. 3424/90 Anil Shah v. State & Ors.
10-8-90 Jaipur
4. No. 3473/90 Ram Narain v. State 16-8-90 Kota
5. No. 3448/90 Abdul Zaleel v. State 16-8-90 Kola
6. No. 3431/90 Kamal Kumar v. State of Raj & Ors.
13-8-90 Kota
7. No. 3372/90 Nathu Lal v. State & Ors.
4-8-90 Chhabra (Kota)
8. No. 3452/90 Dharamveer Agrawal v. State 16-8-90 AlwarAzizulla Khan And Ors. vs State And Ors. on 6 September, 1990

9. Chandra Kant 13-8-90 Bharatpur Sharma v. State
10. Dalu Ram v. State & Ors.
13-8-90 Pilani (Khunjhunu)
11. Rafiq Mohd v. State &Ors.
16-8-90 Sunel (Distt. Jhalawar)
12. Jagannath Sharma v. State & Ors.
16-8-90 Narayana (Distt. Jaipur)
13. Rajendra Kumar v. State & Ors.
16-7-90 Gangapur City (Distt. Sawaimadhopur)
2. When these writ petitions came up before the Court, the copies of the petitions were made
available to Shri M.I. Khan, Addl. Advocate General for the State of Rajasthan and for other
respondents who were functionaries of the Government. It was not considered necessary to issue
notice to the respondents other than the State functionaries and the Municipal Boards/ Councils
who had been impleaded as respondents in certain cases and with the consent of both sides, the
matters were finally heard. A detailed reply was filed on behalf of the respondents by Shri M.I. Khan
in one of the cases, namely Azizullah v. State (S.B. Civil Writ Petition No. 3286/1990) and Shri M.I.
Khan was also permitted to make submissions with reference to records to meet the objection
pointed out on behalf of the petitioners and the grievances raised by them in the various petitions.
3. The draft proposals for the demarcation of wards had been issued and published in the month of
April, 1990 and the same had been finalised in the month of June, 1990, for holding elections to
various Municipal Boards/Councils in Rajasthan. It is a dismal fact that while preparing, issuing and
publishing the draft proposals and finalisation of the same, due care and caution was not taken and
in several cases the numbers of wards were changed arbitrarily; due regard was not given to the
strength and density of voters in the councils/boards and wards therein. The grievances in the
formation of wards, the change of numbers of wards in the name of delimitation of wards in an
arbitrary manner even without inclusion or exclusion of areas therein, in certain cases numbering
and reserving particular wards without any rational and lawful justification and the statement made
before a Bench of this Court on 29th November, 1989 on behalf of the Government in S.B. Civil Writ
Petition No. 4841/1988 Ram Saran Antyanuprasi v. State, have given rise to the mushroom growth
of writ petitions before the issue of the notification for election so much so that the cases were filed
even on 17th August, 1990 while all these matters were being heard. The order dated 29th
November, 1989, passed in S.B. Civil Writ Petition No, 4841 / 88 is reproduced as under:--
"Hon'ble Bhargava, J.Azizulla Khan And Ors. vs State And Ors. on 6 September, 1990

Mr. M. C. Jain Kagzi for the petitioner; Mr. K.L. Pareek, for the State; Mr. A.K.
Bhandari, for the Municipal Council.
This writ petition has been filed on 19-12-1988 with the prayer that the State Govt. be
directed to undertake census for the municipal areas and of all wards separately
preparatory to fresh delimitation of municipal wards; to take active steps for
delimitation of the Jaipur Municipal Wards and to give the same proper publicity and
further that the voters list for every ward should be revised before the Municipal
Elections are held.
Notices were issued to show cause as to why the writ petition be not admitted and
disposed of. The respondents have been served but they have not filed any reply.
Learned counsel for the respondents has brought to my notice the Rajasthan
Municipalities (Amendment Ordinance, 1989 (Ordinance No. 9 of 1989) published in
the Rajasthan Gazettee, dated 12-10-89, amending S. 5 of the Rajasthan
Municipalities Act (Act No. 38 of 1959) providing that there shall be a municipal
Corporation for an area having a population of more than 5 lacs and therefore, there
will be no elections for the Municipal Council and now as and when the elections will
be held they will be held for the Jaipur Municipal corporation. Obviously, there will
be a fresh delimitation of wards and the procedure prescribed under the Act and the
Rules will be followed, therefore, no directions need be issued at this stage. It is
expected that the government will expedite fresh delimitation and the procedure
prescribed and hold elections at the earliest.
With these observations, the writ petition is disposed of.
4. The Rajasthan Municipalities (Amendment Ordinance, 1989) (Ordinance No. 9 of 1989)
published in the Rajasthan Gazette dated 12th October, 1989, later on, became an Act as this
Ordinance was passed by the Rajasthan Legislative Assembly and as per this Amending Act of 1990,
the following amendments were made:--
"5. What local area may be declared to be a municipality:-- (1)Any local area which comprises-- !
(a) a city or a town or two or more neighbouring towns with or without any village, suburb or land
adjoining thereto, or
(b)a village or suburb or two or more neighbouring villages and suburbs, or
(c) the whole or any part of a panchayat circle as defined under the Rajasthan Panchayat Act, 1953
may be declared a municipality and classified as follows:--
(i)for an area having a population of twenty thousand or more but not more than one
lakh, a municipal board;Azizulla Khan And Ors. vs State And Ors. on 6 September, 1990

(ii) for an area having a population of more than one lakh but not more than five
lakhs, a municipal council; and
(iii) for an area having a population of more than five lakhs, a municipal corporation.
(2) Notification under Section 4 shall be issued names are constituted to be one
municipality, the name of the municipality shall be determined by the State
Government.
(3) Notwithstanding anything contained in Sub-section (1) and (2), the State
Government may provide for the constitution of--
(i) a nagar-panchayat for a transitional area having a population of less than ten
thousand but not less than five thousand.
(ii) a municipality for an urban area having a population of less than twenty thousand
but not less than ten thousand;
Where such an area is of historical or industrial importance or is important for trade, tourism or
pilgrimage.
9. Composition of boards:-- (1) Subject to the provisions contained in the succeeding Sub-sections,
every board shall consist of such Bumber of seats as may be fixed by the State Government from
time to time by notification in the Official Gazette.
(2) In so fixing the total number of seats for a board, the State Government shall specify the number
respectively of general seats and of seats reserved for members of the scheduled castes or for
members of the scheduled tribes or for both as the State Government may in each case determine.
(3) The number of seats reserved as aforesaid shall, in relation to the total number of seats fixed for
a period, bear the same proportion as the population of the scheduled castes or scheduled tribes in
the municipality bears to the total population thereof and such reservation shall be operative until
the provisions of the Constitution relating to the reservation of seats for scheduled castes and
scheduled tribes in the State Legislative Assembly cease to have effect.
13. Division into wards:-- (1) For purposes of elections to a board; a municipality shall be divided
into such number of wards as is equal to the total number of seats fixed for the board under
Sub-section (2) of section 9.
(2) The representation of each ward shall be on the basis of population of that ward and shall, as far
as possible, be in the same proportion as the total number of seats for the municipality bear to its
population.Azizulla Khan And Ors. vs State And Ors. on 6 September, 1990

(3) Notwithstanding anything contained in this Act, the division of wards for the purposes of
holding election of Municipal Board or Municipal Council, shall be made by the State Government
on the basis of latest Assembly Electoral Rolls, during the year, 1990.
14. Delimitation order:-- (1) The State Government shall by order determine--
(a) the wards in which each municipality shall be divided for purpose of elections to the board;
(b) the extent of each ward;
(c) the number of seats, if any, reserved for members of the Scheduled Castes or Scheduled Tribes,
as the case may be, in any ward.
(d) the wards for women candidates by rotation including, women of Scheduled Castes/ Scheduled
Tribes.
(2) The draft of the order under Sub-section (1) shall be published for filing objections thereto
within a period of not less than twenty-one days and a copy of the same shall be sent to the board
concerned for comments.
(3) The State Government shall consider any objection and the comments received under
Sub-section (2) and the draft order shall, if necessary, be amended, altered or modified accordingly,
and thereupon it shall become final".
5. Notification dated 5th April, 1990, the Rajasthan Municipalities Fixation of Seats (For Women
Belonging to SC/ST and Determining of Wards for Women by Rotation) Rules, 1990 was issued.
Rule 3 thereof is reproduced as under:--
"3. Determination of wards/seats for women by rotation:
As far as allotment of wards for women by rotation, requisite number of wards shall
be determined as per the following manner.
Subject to any directions of the State Govt. every third ward of a Board shall be
reserved for women, subject to maximum of 30% (including the number of seats
reserved for women belonging to SC/ ST) and this process shall rotate in succession.
Provided further that allotment of wards for women belonging to the SC or the ST as
the case may be, shall be determined in the aforesaid manner only out of the seats
reserved under Sub-section (3) of Section 9.
For the purpose of facilitating the implementation of the provisions of these rules, the
State Govt. may by order given such directions as appears to it necessary for the
removal of any difficulty for limited period up to the last date of counting".Azizulla Khan And Ors. vs State And Ors. on 6 September, 1990

6. In view of the aforesaid amendment in the Rules, the Wards had to be reserved for women
belonging to SC/ST and women in general and, as per Rule 3 every third ward was to be reserved for
women subject to a maximum of 30% (including the number of seats reserved for women belonging
to SC/ ST). Rule 3 has been reproduced as above.
7. Briefly stated, the case set up by the petitioners in each of the cases and the case of the
respondents put up before the Court in answer thereto is as under:--
(1) S.B. Civil Writ Petition No. 3286/1990 (Azizullah Khan v. State of Rajasthan)
8. In this case, the petitioner who is a resident of Tonk has come with the grievance that the draft
proposal for demarcation of wards was issued vide notification dated 20th April, 1990 and the same
was published on 20th April, 1990. In this draft proposal, Annexure/1, the wards reserved for
women were 3, 6, 9, 12, 15, 18, 21, 24, 27, 30 and 33 out of 35 wards in all, but in final publication
ward 33, which was reserved for women was dereserved and ward No. 32 was reserved for women;
in draft proposal ward No. 11 was reserved for scheduled caste in addition to other wards so
reserved, but in the final publication Ward No. 11 was dereserved and ward No. 3 was reserved for
Scheduled Caste Women, although the population of Scheduled Castes in Ward No. 11 is more. It
was submitted that in the Municipal Board, Tonk right from the inception till now first and last
wards have always met at their boundaries; but this time, the circle has not been completed;
boundaries of wards Nos. 1 and 35 did not meet at their ends and that wards have been numbered in
an arbitrary manner which is detrimental to minorities. Objections were submitted vide application
dated 16th May, 1990 and personal hearing was also sought to support these objections vide
application dated 26th May, 1990, but the same was not considered and without considering these
objections, final publication was made vide notification dated 1st June, 1990 published on 8th June,
1990. It was also submitted that total number of voters in the Municipal Board, Tonk is 55,631 and
total wards are 35 and, therefore, each ward should have as many as 1589 voters and 10% of the
same comes out to be 159 and, therefore, the number of voters in each ward could be 10%
plus-minus to 1589, but in Wards Nos. 9, 16, 23 and 29 the number of voters are beyond the
permissible limits i.e. 1783, 1759, 1756 and 1780 respectively and likewise in Wards Nos. 24 and 31
number of voters is below the permissible limit i,e. 1366 and 1407. Shri Surendra Vyas, learned
counsel appearing on behalf of the petitioner submitted that besides the case that the principle of
reserving every third ward for women has been violated by reserving Ward No. 32 for women
instead of 33, it is a case of violation of Section 14 of the Rajasthan Municipalities Act inasmuch as
the draft proposals were prepared by the Municipal Boards rather than the Government and such
drafts were not sent to the Municipal Boards for comments; no comments were sought and the
objections were not considered.
9. Shri Khan has submitted that wards have been numbered continuously and there is no law that
the circle should be completed so that the boundaries of the first and the last ward may meet. He has
also submitted that the Rule of reserving every third ward for women has not been violated except
while reserving Ward No. 32 for women and that had to be done because Ward No. 33 had already
been reserved for scheduled caste according to the population strength of scheduled caste voters in
Ward No. 33 and once Ward No. 33 was already reserved for scheduled caste, another ward had toAzizulla Khan And Ors. vs State And Ors. on 6 September, 1990

be reserved for women and, whereas this multiple of three is not available for reservation of women
on account of it being already reserved for scheduled caste the Deptt. had to look for the next ward
on ascending side and since in Ward No. 34 also the population of scheduled caste voters was more,
the Department had to follow the descending order and accordingly, Ward No. 32 was reserved for
women instead of 33. He has further submitted that in view of the proviso under Rule 3 of the
Municipalities Fixation of Seats (for women belonging to SC/ST and Determining the Wards for
Women by Rotation) Rules, 1990, once a ward had been reserved for SC under Sub-section (3) of
Section 9, it was no more available for reservation for women. However, he could not explain as to
why Ward No. 11 was not reserved for scheduled caste, although the population of scheduled caste
voters in Ward No. 11 was more, and, therefore, even if Ward No. 3 had been reserved for scheduled
caste women why Ward No. 11 could not be reserved for SC -- where the population of SC voters was
more. Ward No. 1, which was notified in the draft proposal as reserved for scheduled caste being
kept intact even after could be reserved for SC women instead of Ward No. 3 and, in that case, the
percentage of quota for SC, ST women could be maintained and the principle of reserving every
third ward for women could also be maintained. Shri Khan has also submitted that the wards have
not been demarcated with any idea to cause any prejudice to the minorities and the allegation that
the principle of 10% plus minus with regard to number of voters in each ward keeping in view the
total number of voters in the Municipal Board, Tonk and the total number of wards is as per the
figures given by the petitioner himself, total number of voters in each ward should have been 1589
with 10% plus-minus. 10% of 1589 comes out to be 159 and, therefore, the number of voters could be
1430 to 1748, whereas in Wards Nos. 9, 16, 23 and 29 the number of voters is 1783, 1759, 1756 and
1780, which is in close proximity with 1748 and likewise in Wards Nos. 24 and 31 where the number
of voters 1366 and 1407 -- is again in close proximity with 1430. Shri Khan also produced before me
the relevant file to show that the draft proposal was sent to the Municipal Board, comments were
called for and received and objections had also been considered and, it is absolutely wrong to
suggest that no comments were sought. He has submitted that while preparing the draft, even if the
services of the staff of the Municipal Board were made use of, they had still acted on behalf of the
Government as an agency of the Government and no exception can be taken if the Election
Department has utilised the services of the staff of the Municipal Board, Tonk while preparing the
draft notification.
(2) Shabir Ahmed Khan v. State of Rajasthan (S. B. Civil Writ petition No. 3428/ 1990): Jaipur.
10. The petitioner has come with the case that for Municipal Council, Jaipur, there are 50 wards in
all. In the draft notification Wards Nos. 22 and 23 were reserved for SC and the same were made
general in the final notification and Ward No. 19, which was general, was reserved in the final
notification dated 8th June, 1990 for scheduled caste. It has been further alleged on the basis of the
data submitted through an additional affidavit dated 16th August, 1990 that in Ward No. 38, the
total number of voters is 13, 428, whereas the total number of voters of ST in this ward is only 800
which comes out to be 6% only and yet this ward which in the draft notification was a general ward
has been reserved in the final notification as a ward reserved for ST. He has submitted that the
wards have been reserved and dereserved in a wholly arbitrary manner, no rationale has been
followed and the objections which have been filed by the petitioner have not been considered, and
further that he had also applied for the copy of the objection, if any, filed against keeping Ward No.Azizulla Khan And Ors. vs State And Ors. on 6 September, 1990

19 as a general ward; but the same was not made available to him.
11. Shri Bandhu appearing on behalf of the petitioner invited my attention to the order dated 19th
November, 1989, passed by this Court in S. B. Civil Writ Petition No. 4841/1988 about which
reference has been made in para 11 of the writ petition and submitted that once the Government
itself had made a statement before this Court with reference to the amendment made in Section 5 of
the Rajasthan Municipalities Act, 1955 that there should be a Municipal Corporation for an area
having population of more than 5 lacs and, therefore, there will be no elections for the Municipal
Council and now as and when the elections will be held, they will be held for Jaipur Municipal
Corporation; it was not open for the Government to hold elections for Municipal Council and the
Government cannot be allowed to act contrary to a statement made before this Court and, therefore,
in no case any elections for Municipal Council can be allowed to be held and, the election can be
held for Municipal Corporation only because the population of Jaipur, even as per the census figures
of 1981, is more than 9 lacs and, as such, the elections should be held for Jaipur Municipal
Corporation, rather than for the Municipal Council, and the Government is bound by the statement
made before this Court on the basis of which it obtained the order dated 29th November, 1989 in S.
B. Civil Writ Petition No. 4841 of 1988.
12. Shri Khan submitted that Wards Nos. 22 and 23 had to be dereserved and made general because
of lesser number of voters belonging to SC in Wards Nos. 22 and 23, and, so far as Ward No. 19 is
concerned, he submitted that on account of inclusion of certain area in Ward No. 19, the percentage
of ST voters increased in this Ward from 6% to 9%, which was the maximum and he submitted that
the inclusion of area of Khora Nagoriyan in Ward No. 19 resulted in increase of the number of voters
of Scheduled Tribes in this ward to 9%. This position was contested by Shri Bandhu with the aid of
final notification and, he pointed out that in Ward No. 19 there is no area like Khora Nagoriyan.
Confronted with this situation, Shri Khan submitted that he had wrongly stated about the inclusion
of Khora Nagoriyan in Ward No. 19. In fact, it was some other area which was included in Ward No.
19 resulting into increase in the percentage of ST voters therein. He, however, failed to show any
material in support of his submission as to how the percentage of Scheduled Tribe voters increased
in Ward No. 19. While answering the allegations of the petitioner regarding objections against
keeping Ward No. 19 to be a general ward, it was pointed out by Mr. Khan that the only objection
which was received against Ward No. 19 was from one Shri Atma Ram and on the basis of this
objection, a decision was taken to reserve Ward "No. 19 for ST. Regarding the submission of the
petitioner with reference to the contents of the order dated 29th November, 1989, Shri Khan
submitted that the Government was not bound by the statement made before the Court on 29th
November, 1989 and that in want of corresponding amendment in the Rajasthan Municipalities Act,
there is no question of holding election for Jaipur Municipal Corporation merely because the
amendment in Section 5.
3. Anil Shah v. State of Rajasthan (S. B. Civil Writ Petition No. 3424/1990): Jaipur.
13. In this case, the petitioner has come with the grievance that there was an unequal distribution of
voters and Ward No. 11 was renumbered as Ward No. 12 and Ward No. 22 was renumbered as 21
and instead of reserving at least 5 wards for SC/ST Women, only two wards had been reserved forAzizulla Khan And Ors. vs State And Ors. on 6 September, 1990

Scheduled Caste Women. Thus, the Election Department has acted arbitrarily in the matter of
numbering the wards and changing the number of wards as also in the matter of reserving the wards
and further that the petitioner had filed objections against the draft notification, but the same were
not considered. Shri Khan has submitted that Ward No. 11 had to be renumbered as 12 and 22 as 21
on the principle of contiguity. There is no unequal distribution of voters and Shri Khan has
submitted that there are in all 50 wards and, therefore, not more than 15 wards in all could be
reserved for women including SC/ST women. Since 13 wards had been reserved for women, only
two words could be reserved for SC women and the submission of the petitioner is not tenable.
4. S. B. Civil Writ Petition No. 3473/1990 Ram Narain v. State of Rajasthan: Kota
14. In this case, the petitioner has come with the case that there are 45 wards in the area of
Municipal Council, Kota and while forming the wards there has been a lack of cohesion and these
wards have been framed without application of mind. Objections were filed by the political parties,
yet the same were not considered and the numbers of the wards have been given arbitrarily. It has
been submitted that the numbering of the wards had assumed greater importance because under
the new provisions every third ward was to be the ward reserved for women. It has been stated that
Ward No. 15 had been shown in the draft notification as a ward reserved for women, but the same
was dereserved and was converted into a ward for men. It was also submitted that the area of
Rangwari and Raipura are outside the Municipal limits of Kota and it was so held by the Rajasthan
High Court in the case of Jagannath v. Municipal Board, Kota. Mahaveer Nagar I, II and III are new
colonies developed in Rangwari, yet the same have been shown to be a port of Municipal area while
forming the wards and no colony which does not fall in the Municipal area could be included while
forming the wards, for the purpose of elections in question. It was then submitted that according to
the provisions of Section 5, as per the amended Act of 1990, there was no question of holding the
elections for Municipal Council, Kota because the population of Kota has already exceeded 5 lacs
and the same is about 6 lacs and as per the existing population Kota has to be divided in 65 wards
and, if at all the elections are to be held they should be held for Municipal Corporation rather than
the Municipal Council. While explaining these allegations Shri M. I. Khan produced the plan of the
formation of wards and pointed out that as per the plan the new colonies Mahavir Nagar I, II and III
have been developed in Anandpuri and Kesharpura which are very much in the Municipal limits of
Kota and it is wrong to suggest that these colonies have been developed in Rangwari. Shri Khan
submitted that as per this plan also Rangwari is outside the Municipal limit of Kota. The fact is that
Mahavirpura I, II and III are not in Rangwari and the same are in the Anandpuri and Kesharpura
within the Municipal limits. He further submitted that the wards have been formed on the principle
of contiguity and Ward No. 15 was dereserved because the Ward 16 had been reserved for scheduled
caste women and, it is wrong to suggest that wards have been framed without application of mind
and it is wrong to suggest that the objections were not considered.
5. S.B.Civil Writ Petition No. 3448/ 1990 Abdul Zalil v. State: Kota
15. In this case, the petitioner has come with the allegations that delimitation order is illegal and
arbitrary. Wards have not been named as per law. Previously Ward No. 27 namely Anandpuri was
general ward and now Anandpuri has been included in Ward No. 26 and the same has been reservedAzizulla Khan And Ors. vs State And Ors. on 6 September, 1990

for scheduled tribe and a comprehensive study of ward would show that in Anandpuri there are
hardly 100 persons belonging to Scheduled Tribe. The representation of each ward should be on the
basis of population, but no care has been taken to follow this principle. Ward No. 15 was reserved for
women in the draft notification and Ward No. 16 was for scheduled caste, but numbers of wards
have been changed arbitrarily and now Ward No. 16 which was reserved for scheduled tribe has
been reserved for women and Ward No. 15 has been made a general ward, which is contrary to the
principle that every third ward will be a ward reserved for women. Shri Khan's reply to the
allegations was almost the same as in S. B. Civil Writ Petition No. 3470/1990. He has stressed that
wards have been formed on the principle of contiguity.
6. S. B. Civil Writ Petition No. 3437/1990 (Kamal Kumar v. State of Rajasthan) (Kota)
16. In this case, the allegations are more or less the same as in the case of S. B. Civil Writ Petition
No. 3448/1990 and it has been submitted that change in the number of wards in the final list is
against the principles of Article 14 of the Constitution and that the Ward Nos. 15, 16 and 42 have
been changed for collateral purposes and the list which was finally published is against the
provisions of Article 14. Shri Khan's reply to allegations is the same as in S. B. Civil Writ Petition No.
3448/1990 and S. B. Civil Writ Petition No. 3470/1990.
7. S.B. Civil Writ Petition No. 3372/1990 Nathu Lal v. State (Chhabra) Kota.
17. The petitioner has alleged that after the issue of draft proposal notification dated 5th April, 1990,
the respondents published the area and boundaries of the wards and in this final notification wards
Nos. 3,6,9,12 and 13 were shown as reserved wards for women. The petitioner submitted that Ward
No. 13 could not be reserved for women candidates and yet the same has been reserved for them.
The petitioner has given the details of male and female voters and the percentage of the female
voters in para 7 of the writ petition and on that basis the contention has been raised that those
wards in which the percentage of female voters was maximum ought to have been reserved for
women and, accordingly there was no justification to reserve Ward No. 13 for women because the
percentage of female voters in Wards Nos. 4, 6 and 8, 10 and 12, 3, 9 and 11 being more viz. 52.75,
48.99, 48.97, 48.83, 48.57 per cent. The table is as under:--
Voters Percentage of Ward No. Mate Female Total Female voters
1. 46.92
2. 45.90
3. 48.83
4. 52.75
5. 46.15Azizulla Khan And Ors. vs State And Ors. on 6 September, 1990

6. &g 48.99
7. 47.96 9 &11 48.57 10 & 12 48.97
13. 47.80
18. The first four out of these wards should have been reserved for women and these wards should
have been numbered as wards divisible by three. But this principle has been given a go-bye and the
wards have been reserved in a wholly arbitrary manner. It has also been argued that so far as total
number of voters is concerned, there should not be a difference of 10% plus-minus. But there is
more than 100% difference in the voters of the wards as there were only 562 voters in Ward No. 2
and there are 1330 voters in Wards Nos. 9 and 11, Likewise, there are 1249 voters in Wards Nos. 6
and 8 and 1217 voters in Wards Nos. 10 and 12 and, as such, the difference of voters is much more
than 100%. It has further been argued that in the final publication of demarcation of the municipal
wards of Chhabra, boundry limits of wards had not been changed from those which were notified in
draft proposed in the notification issued in April, 1990 and without any change in the boundary
limits, the wards have been renumbered and renumbering is not explained by any rational criteria
and, thus, the wards which ought to have been reserved have been dereserved and those which
ought not to have been reserved have been reserved. In reply to these allegations all that has been
said by Mr. Khan is the principle of contiguity has been followed and no explanation has been given
with regard to the difference of the total number of voters in certain wards to the extent of much
more than 10% plus minus.
8. S. B. Civil Writ Petition No. 3452/1990 Dharamveer v. State of Rajasthan and others Alwar
19. In this case, it has been alleged that in the draft proposal notification Rule 8(1) of the Rajasthan
Municipalities Registration of Electors Order, 1974 has not been followed and the notice was not
displaced in form No. 2 at any conspicuous place, or two places in each ward; Municipal Council
area has been divided into 40 wards out of which 10 wards have been reserved for women (general)
two for SC women candidates, four wards for scheduled caste and one for scheduled tribe. No
criteria has been followed with regard to population or the number of voters of scheduled caste and
scheduled tribe women. In certain wards number of voters are two to four times more than other
wards as would appear from schedule appended to the writ petition. Total number of voters in Ward
No. 12 is only 1229, while in Ward No. 38, it is 2585, in Ward No. 23, it is 2978 and in Ward No. 32,
it is 3203; in Ward No. 21, it is 3578 and in Ward No. 35, it is 3698, in Ward No. 1 it is 3943 and in
Ward No. 24 it is 4494, in Ward No. 18, it is 4900; whereas in Ward No. 39, it is 1800, and in Ward
No. 40, it is 2292. Thus, no regard has been held to the number of voters while demarcating the
wards. The total number of voters entered in the electoral roll is 1,20,406 and the average voters in
each of the 40 wards come out to be 3010, whereas the total number of voters in the wards ranges
from 1226 to 4900 and the difference varies from 10% to 60% and thus, the principle of
representation of equal number of voters by each of the candidates elected has been flouted and that
the same is violative of Section 13(2) of the Municipalities Act and the allegation is that the same has
been done intentionally to give benefit to the candidates of particular political party. It has been
alleged that the number of wards has been changed to accommodate certain persons and number ofAzizulla Khan And Ors. vs State And Ors. on 6 September, 1990

half of the wards have been changed. The grievance in the matter of inclusion of certain names in
the electoral rolls has also been raised. Shri Khan has replied that the number of voters in certain
wards have increased after the issue of the draft notification on the basis of the objections received
because the boundaries of the wards which had been fixed could not be altered and if certain
persons whose names were not included in the electoral rolls filed objections and on that account
their names had to be included and the same has resulted into increase of total number of voters in
certain wards and, thus, the difference in the total number of voters in certain wards has exceeded
the limit of 10% plus minus, but the same was inevitable. At this juncture, the petitioner,
Dharamveer who himself is a practising advocate at Alwar, pointed out that the submission that the
number of voters which have been included on the basis of their objections after the issue of the
draft notification are very few in number. Shri Khan could not place any material to controvert this
position. Regarding other allegations, his reply is that the principle of continuity has been
maintained.
9. S. B. Civil Writ Petition No. 3432/1990; Chandra Kant v. State of Rajasthan: Bharatpur.
20. The petitioner's case is that the reservation of six wards for scheduled caste, two for scheduled
caste women and 10 for women (general) is against the provisions of Section 9(2). Ward No. 34 has
been divided into two wards as Nos. 31 and 32 and the formation of the ward is not cohesive and no
method of division of wards has been adopted. The grievance has been raised regarding Wards Nos.
22,5,8 etc. Objections were filed, but the same have not been considered. The final notification was
issued on 7th June, 1990. Ward No. 28 which was earlier shown as general ward has been
renumbered as Ward No. 27. The petitioner has given several illustrative instances and it has been
submitted that the procedure in allotting numbers to various wards has been wholly arbitrary,
unreasonable and due regard has not been shown to the principle of uniformity and the formation of
wards is wholly defective. The grievance has also been raised with regard to the entries in the voters'
list etc. Shri Khan, though contested these allegations has not' produced any material to indicate
that the wards had been numbered keeping in view the strength of the population and that principle
of contiguity has been followed.
10. In S. B. Civil Writ Petitions Nos. 3445/ 1990, 3390/1990, 3449/1990, and 3441/1990, the
allegations with regard to change of number of wards in an arbitrary manner and violation of
principle of contiguity and departure from the principle of reserving every third ward for women
candidates etc. and other allegations of general nature have been made and the same were sought to
be explained by Shri Khan on the principle of contiguity and the reservation of certain wards made
in favour of SC/ST candidates.
21, The following contentions have been raised in these cases :-
1. According to the amendment in Section 5, there cannot be any municipal council
for a town having population of more than 5 lacs and in such cases there is no
question of holding election for municipal council and they must be held for the
municipal corporation rather than for municipal council.Azizulla Khan And Ors. vs State And Ors. on 6 September, 1990

2. That the ward numbers have been allotted and altered, reserved and dereserved in
a wholly arbitrary manner for collateral purposes and for the purpose neither
authorised nor permissible under law.
3. Rule 3 of the Rajasthan Municipalities fixation of seats (for women belonging to
SC/ ST and determining of wards for women by rotation) Rules, 1990 has been
violated and the wards having numbers which are not multiple of three or divisible by
three for reservation for women and certain wards which are divisible by three or are
numbered as multiple of three have not been reserved for women.
4. In the matter of reserving the wards for SC/ST no care has been taken to the
percentage of SC/ ST voters and the wards which ought to have been reserved for
SC/ST have been kept as general wards and those which ought to have been kept as
general wards have been reserved for SC/ST.
5. While forming wards, due regard has not been given to the total number of voters
and the total number of wards and in doing so, the principle of 10% plus minus voters
in the wards has been violated.
6. The wards have been formed in violation of Section 14 and the objections filed
were not considered.
22. Regarding the first contention which has been raised for Jaipur and Kota, it may
be straightway observed that as per the amendment in Section 5, it is clear that for an
area having a population of more than 5 lacs there should be a municipal corporation.
The contention raised by Shri Bajrang Lal Sharma, who appeared in support of the
writ petitions in relation to Jaipur, is that after the amendment in Section 5, no
municipal council can be conceived for an area having a population of more than five
lacs. So far as Jaipur is concerned, it was an admitted position that the population of
Jaipur even as per the census of 1981 was more than 5 lacs and hence under the Act,
the Municipal body for Jaipur cannot be classified as Municipal Council; there must
be a Municipal Corporation and the respondent cannot be allowed to continue with
the Municipal Council; the municipal area of Jaipur has to be comprised under a
Municipal Corporation. Once the law has provided and the Legislature has given its
mandate that areas having a population of more than 5 lacs shall be classified as
Municipal Corporation, and Executive cannot be allowed to flout the mandate of the
Legislature. This contention in my opinion carries conviction and force and the same
deserves to be accepted. The people of municipal area with more than 5 lacs
population, cannot be deprived of the amenities and the facilities which are available
under a Municipal Corporation if by law such area deserves to be an area to be
governed by a Municipal Corporation. The maxim is that "Law lags behind", but here
is a case in which law provides for a municipal corporation and has the manifestation
of the concept of advancement but the executive seems to lag behind despite the
Legislative mandate of providing amenities and facilities of municipal corporation ofAzizulla Khan And Ors. vs State And Ors. on 6 September, 1990

the people living in a municipal area having a population of more than 5 lacs and it is
the Executive which seeks to deny the facilities and amenities in an in direct manner
by continuing with the municipal council instead of municipal corporation. It is the
settled principle of law that when the law clearly provides, the particular thing to be
done in a particular manner, that has to be done in that very manner and cannot be
permitted to be done in any manner other than that which has been prescribed under
the law. This principle which was laid down in the case of Taylor v. Taylor, (1876) 1
Ch D 426 was followed and reiterated by the Supreme Court in the case of State of
Uttar Pradesh v. Singhara Singh, AIR 1964 SC 358 : 1964(1) Cri LJ 263(2) and the
relevant observations from para 8 are as under at page 266; 1964(1) Cri LJ :
"The rule adopted in Taylor v. Taylor, (1876) 1 Ch D 426 is well recognised and is
founded on sound principle. Its result is that if a statute has conferred a power to do
an act and has laid down the method in which that power has to be exercised, it
necessarily prohibits the doing of the act in any other manner than that which has
been prescribed. The principle behind the rule is that if this were not so, the statutory
provision might as well not have been enacted."
Accordingly, when the law has provided for municipal corporation, it is not permissible to go on
with the Municipal Council and the Legislative mandate cannot be allowed to be flouted in a direct
or indirect manner. Shri Virendra Bandhu has vehemently submitted that it was with reference to
this very amended Section 5 that a statement was made before this Court on 29th November, 1987,
in a writ petition which was filed with the prayer that the State Government may be directed to
undertake census for the Municipal area and of all the wards separately preparatory to fresh
limitation of municipal wards, that there shall be a municipal corporation for an area having a
population of more than five lacs. The exact words in which the statement was made are quoted as
under:
"Learned counsel for the respondent has brought to my notice the Rajasthan
Municipalities (Amendment Ordinance, 1989) (Ordinance No. 9 of 1989) published
in the Rajasthan Gazette, dated 12-10-89, amending Section 5 of the Rajasthan
Municipalities Act (Act No. 38 of 1939) provides that there shall be a Municipal
Corporation for an area having a population of more than 5 lacs and therefore, there
will be no elections for the Municipal Council and now as and when the elections will
be held, they will be held for Jaipur Municipal Corporation. Obviously, there will be a
fresh delimitation of wards and the procedure prescribed under the Act and the Rules
will be allowed. Therefore, no directions need be issued at this stage. It is expected
that the Government will expedite fresh delimitation and the procedure prescribed,
and hold elections at the earliest."
23. The submission of Shri Bandhu was that having made this statement before the Court, the
Government cannot be allowed to give up the same and it has to respect the statement which was
made before the Court on the basis of which the order dated 29th November, 1989 was obtained.
The submission of Shri Khan that it could not be done for want of corresponding amendment in theAzizulla Khan And Ors. vs State And Ors. on 6 September, 1990

Municipal Act is only a poor apology to disown the above statement made before the Court, and the
same cannot be accepted. In my opinion, the writ petition in which the order dated 29th November,
1989 was passed was essentially a litigation to undertake the proceedings for the Municipal areas
and the order dated 29th November, 1989 was passed after the amendment in Section 5 i.e. after
12th October, 1989. Obviously, the purpose was to ascertain that the municipal areas having
population of more than 5 lacs and this writ petition was particularly in relation to Jaipur so that
Jaipur Municipal Corporation can be formed, and the Government itself was alive to this
amendment while making the above statement. Such a commitment given before a bench of this
Court was a commitment not only to the Court but a commitment to the society and the people of
those municipal areas where the population exceeds five lacs. I do not find any reason for
non-fulfilment of such a commitment made before the Court and the executive cannot be allowed to
take a retreat from a state where it had already been led to by the Legislature. The State Legislature
is a representative body of the people and its members who know the pulse and nerves of masses
enact the law to attain the objects which the people cherish the most. It is the pious duty and
obligation of the executive to implement such enactments with promptitude and the executive
cannot be allowed to be indifferent and it can only illafford to let such enactments to be the
decorative provisions only in the statute books. To have Municipal Corporation for Jaipur became
all the more imperative when it is admitted that the population of Jaipur had exceeded the figure of
five lacs even on the basis of census of 1981 and now it was going to touch or cross even the figure of
10 lacs.
24. Shri K. K. Mehrish submitted with reference to Kota that although the population of Kota on the
basis of census of 1981 was less than 5 lacs, but it has already exceeded the figure of 5,00,000. It is
for the respondents to find out as to what is the actual population of Kota, But in case, the same has
exceeded the figure of five lacs, the people of Kota are also entitled to have a municipal corporation
instead of Municipal Council. I, therefore, hold that any municipal area in Rajasthan where
population exceeds 5 lacs must have a Municipal Corporation and for such areas, the election should
be held for municipal corporation rather than for municipal council.
25. Regarding the second contention that the ward numbers in the various municipal
boards/councils have been allotted and altered, reserved and dereserved in an arbitrary manner, it
may be observed at the very outset that this time the allotment of numbers to wards was not merely
a matter of arithmatic numbering and question of no consequence. It had assumed a great
importance and it had become a matter of concern and a matter of farreaching consequences
because of the provisions of Rule 3 of the Municipalities Fixation of Wards (for Women belonging to
SC/ST and Determining of Wards for Women by Rotation) Rules, 1990. Once it has been provided
by rule that every third ward will be reserved for women in a municipal board/ council, the
numbering of wards had become directly related to the question of reservation and therefore, the
right of a contestant to represent the ward had become dependant upon the number allotted to such
ward. The ward which was to be numbered as a ward divisible by three was to be a ward reserved for
women and, therefore, no male can be a candidate from any of wards. In view of this amendment, it
had become the statutory duty of the election department to first ascertain the wards in which the
percentage of women was more and the numbering should have been done by allotting numbers as
multiple of three to such wards and only thereafter the further exercise was to be done. It hasAzizulla Khan And Ors. vs State And Ors. on 6 September, 1990

become transparently clear in the facts of the present cases that this procedure was not followed and
without following this procedure, the arithmatic numbers were allotted to the wards and, thus, even
those wards were reserved for women in which the percentage of women was less. It is implicit in
the very nature of the language employed in Rule 3 that only those wards were to be numbered as
the wards having numbers multiple of three where the percentage of women was more and it has
become quite clear on the basis of the data produced in these cases that this principle was not
followed and the wards were numbered, allotted and re-allotted, reserved and de-reserved in a
wholly arbitrary manner without giving due regard to the considerations which were germane and
the same has given rise to a serious and legitimate grievance. It is the basic tenet of our constitution
that every citizen is protected against the arbitrary exercise of power and the arbitrariness is
antithesis to the reason. In order to meet the contention of the allotment, numbering and
re-numbering of wards in an arbitrary manner and the arbitrariness in the matter of reserving and
dereserving of wards. Mr. M. I. Khan appearing on behalf of the respondents has argued that the
Election Department has followed the principle of contiguity and he also produced before me the
maps of certain municipal areas and tried to show that numbers had been allotted to the wards on
the principle of continguity. More I looked into the maps more I was convinced that in most of the
cases, the principle of contiguity was the first casualty. The ward numbers had been allotted in a
most haphazard manner not showing any uniformity whatsoever, and obviously this resulted in
making the rights of those persons defeasible who had nourished a particular ward in a municipal
area with their service, who had become popular to the people in a particular ward and were
naturally expectants of being elected from such wards. To put it more precisely, the rights of such
persons could not be made to be defeasible by numbering their wards as a ward multiple of three
and thereby reserving the same notwithstanding the percentage of voters of the category for which it
was reserved. In this regard, the instances which have been pointed out by the petitioners in various
cases, where this principle has been flouted, are only illustrative and not exhaustive. The learned
counsel for the petitioners have placed heavy reliance on a common judgment of a coordinate bench
of this Court, whereby three writ petitions Nos. 2474/90, 2496/90 and 2507/90 i.e. Viidya Banwari
Lal and Ors. were allowed on 8th August, 1990, on the ground of arbitrary allotment and change of
numbers and reservation and dereservation of wards without any rational basis. The operative part
of this judgment is reproduced as under:--
"13. In the result, it is held that the final delimitation of wards done by the
respondent No. 1 in Petition No. 2496/90 by order dated June 2, 1990 (Anx. 6) and
in Petition No. 2474/90 vide final notification dated June 3, 1990 (Anx, 3) & in
Petition No. 2507/90 vide final notification dated June 1, 1990 (Anx. 2), being
arbitrary, illegal, discriminatory and against the provisions of the Act, 1959 & the
Rules, 1990, are quashed. It is, therefore, directed that no election shall be held as per
the delimitation made in the abovementioned three final notifications, which have
been quashed. It is further directed that the delimitation of the wards should be made
at the earliest in accordance with the provisions of the Act, 1959 and the Rules, 1990".
26. I am in full agreement with the reasoning and the conclusion in the above order. Therefore, I
have no hesitation in holding that the Election Department has miserably failed in first undertaking
the elementary exercise to identify the wards with greater percentage of women, SC/ST voters forAzizulla Khan And Ors. vs State And Ors. on 6 September, 1990

the purpose of reservation and has allotted the numbers of various wards without undertaking such
an exercise and the changes which have been made and the numbers which had been allotted and
reallotted even after the issue of draft publication were done in a wholly irrational manner and in
total disregard of the basics which should have been followed in the very beginning. Thus, I find that
in these circumstances, the whole bedrock to call upon the electorate for election was shaky and in
view of serious lapses and lacunae and inherent defects, electorates cannot be called upon to
exercise their valuable right, when the very foundation for holding the election was shaky.
27. The third contention is that according to Rule 3 every third ward should be reserved for women
subject to maximum of 30% including the seats reserved for women belonging to SC/ST. Therefore,
in any Municipal area every third ward should be a ward reserved for women. For example, if there
are 30 wards in all, at the most 9 wards out of 30 could be reserved for women. Now, the question
arises as to which 9 wards out of 30 should be reserved for women. For this purpose, the Election
Department has to first identify those 9 wards in which the percentage of women voters is more and
then number those 9 wards as the wards multiple of 3 and the remaining wards have to be
numbered thereafter. If that is done, no grievance can be raised with regard to the allotment of the
number nor the grievance can be raised with regard to the reservation of such wards for women. In
the instant case, 1 find that the wards with greater percentage of women -voters were not identified
and without such identification, the wards were allotted the numbers and even after the allotment of
such numbers without following the basic criteria in certain cases, the ward numbers which were
neither divisible by 3 nor multiple of 3 were reserved for women and the wards which divisible or
multiple of three were not reserved for women as is clearly illustrated by the reservation of Ward
No. 32 for women in the case of Tonk, where out of 35 wards, in all, in draft proposal, Ward No. 33
was reserved for women, but in the final publication ward No. 32 was reserved for women instead of
Ward No. 33, which was the number divisible by 3. Thus, Ward No. 33 was dereserved in violation
of Rule 3. In this regard, Shri M.I. Khan has given a very curious explanation and the same is that in
view of the proviso under Rule 3 of the Rajasthan Municipalities (Fixation of Seats for Women
Belonging to SC/ST and Determining of Wards for Women by Rotation) Rules, 1990, the allotment
of wards for women belonging to SC/ ST, has to be determined only out of the seats reserved under
Sub-section (3) of Section 9 and, therefore, those wards which had already been reserved for SC/ ST
under Sub-section (3) of Section 9 were no more available for reservation for women. One fails to
understand as to how the number of seats reserved for SC/ST under Sub-section (3) of Section 9 is
relevant to consider and appreciate this contention. Sub-section (3) of Section 9 deals with the total
number of seats fixed by the State Government to be reserved for SC/ ST, but the total number of
such seats has nothing to do with the allotment of number. The idea is that while reserving a ward
for SC/ST women care has to be taken that the total number of wards to be reserved for SC/ST does
not exceed the number of seats reserved under Sub-section (3) of Section 9. But it has nothing to do
with the allotment of arithmatic numbers. In this view of the matter, the only care and caution while
operating Rule 3 is that even if the ward is reserved for SC/ ST women along with women in general,
the total number of seats reserved for SC/ST should not exceed the strength of the seats fixed under
Sub-section (3) of Section 9 and, hence, the proviso under Rule 3 having reference to Sub-section
(3) of Section 9 has no relevance beyond what has been indicated above. In the matter of allotting
the arithmatic number to the wards, as a matter of fact, after identifying the total number of wards
to be reserved for women, such wards have to be first numbered as the wards which are multiple ofAzizulla Khan And Ors. vs State And Ors. on 6 September, 1990

three and out of these wards if any ward is reserved for women SC/ ST such number of wards will be
deducted from the total number of wards fixed for SC/ST under Sub-section (3) of Section 9 and
only ihc remained number of wards have to be reserved for SC/ST. Thus, the statement of Shri Khan
is not tenable and the same is rejected. I further hold that Rule 3 has not been operated on a correct
premises and Rule has been violated in certain cases as already indicated above.
28. While dealing with the fourth contention, it may be observed at the very out-set that first of all,
the Department has to notice the total number fixed for such reservation under Section 9 and
thereafter it has to ascertain and identify those wards where the percentage of SC/ST voters is more.
Such wards are then required to be reserved for SC/ ST on the basis of percentage of voters of SC/ST
therein. This principle has not been followed as is clearly illustrated by the grievance raised in
several cases, including the grievances raised with regard to dereservation of Ward No. 1 in Tonk,
dereservation of Wards Nos. 22 and 23 and reservation of Ward No. 19 and the reservation of Ward
No. 38 for ST in Jaipur, change of Anandpuri in Ward No. 27 to that of Ward No. 26, and then
reserving the same for scheduled tribe, although there were hardly 100 voters belonging to ST in this
area pertaining to Municipal Council, Kota. Thus, 1 find that due regard has not been given to the
strength of total number of voters of SC/ ST, while reserving the wards for them and the wards have
been reserved and dereserved in an arbitrary manner and no definite criteria has been followed and
applied.
29. Regarding the fifth contention, in my opinion, the correct procedure which is required to be
followed is to first notice the total figure in a municipal area under a board or council or corporation
and then to divide this figure by total number of wards in which the area in sought to be
demarcated. The resultant number should be the number in each ward subject to varition of 10%
plus minus. Supposing there is a municipal area having 1,00,000 as the total figure and 25 wards,
then 1,00,000 divided by 25 comes out to be 4000 and, therefore, each ward should have the figure
of 4000 subject to a variation of 10% plus minus i.e. it can be 3600 to 4400, of course, with due
regard to maintaining the compactness of the area. This basis was noticed by this Court in the
decision in the case of Bhagirath v. State of Rajasthan 1983 RLR 805 : (1983, Raj LW 708) para
thereof with reference to the instructions issued by the Election Department of the Government of
Rajasthan vide letter No. F. 2(2)(1)M/Ele/-3509/82 dated September 1982. Para 9 of this judgment
is appropriately quoted as under:
"I have given the considered thought about the submissions made by the learned
counsel for the parties in the matter of the division of municipal council into wards.
The Legislature in its wisdom has rightly used the wards as far as possible in Section
13(2) of the Act. The population of the ward can be one of the main foundation for the
division of the Municipal Board/Council into wards. But at the same time, the
compactness of the area will have to be taken into consideration. The Legislature also
wanted that the area should be compact as well as the representation of each ward
should be on the basis of the population of that ward and every ward should bear as
far as possible the same proportion as the total number of seats for the municipality
bear to its population."Azizulla Khan And Ors. vs State And Ors. on 6 September, 1990

30. Here, 1 find that there is a minor breach of this principle in few cases, but in certain cases there
is grave and shocking breach of this principle; for example in the case relating to Alwar, the data
(with reference to total number of voters, of course, not with reference to population) are as under:--
1. Total number of voters 1,20,406 Average comes to be 3010 Number of voters in
certain wards are as under:-
Ward No. Voters
31. The grievance has been raised with regard to Chhabra (Kota), wherein the complaint about
difference is to the tune of 100%. When Shri Khan was confronted with this position and data the
only reply which he was able to give was that once the area had been demarcated for respective
wards, the Department could not have altered the area and if certain voters came with the grievance
that their names had not been included in the electoral roll and got their names included later on
resulting into the increase in the number of voters in particular wards, the department could not
help this situation. This reply was contested on behalf of the petitioners by submitting that the
increase in the number of voters on aforesaid ground was very little, rather negligible and it is wrong
to say that the number of voters in certain wards have increased because of the aforesaid grounds to
such an exten and it was submitted that from the very beginning there was significant difference in
the number of voters and I find that the grievance raised is a legitimate grievance and the same
deserves to be redressed.
32. The sixth contention raised on behalf of the petitioners is certain cases viz. in the cases of Tonk,
Alwar Pilani (District Jhunjhunu), Chhabra (Kota), Narayana etc. is that the objections had been
filed by them against the draft notification, but the same were not considered and without
considering the objections, the final notification was issued. Of course, no order -- speaking or
otherwise --is required to be passed after considering the objections, but it appears that there was no
active application of mind by the Department to these objections while issuing the final notification.
Had the objections been considered with due and active application of mind with an objective
approach, many of the grievances which have been raised before this Court could be avoided,
33. Mr. Khan, Addl. Advocate General opposing the various cotnentions raised by a battery of
lawyers appearing on behalf of the petitioners invited my attention to Mohinder Singh Gill's case,
reported in AIR 1978 SC 851 and submitted that in view of the law laid down by the Supreme Court
in this judgment, no writ petition can be maintained, in the election matters. There is no quarrel
that the writ petitioners cannot be maintained in election matters, but in the cases at hand, we are
concerned with the grievances raised with regard to pre-election matters before the issue of the
notification calling upon the electorates to return the candidates. Besides this distinction, Mohindra
Singh Gill's case was a case dealing with the Representation of Peoples Act and the whole case
centres round the bar under Article 329 of the Constitution which speaks to push out the remedy
under Article 226 of the Constitution, It is made clear that the matters relating to election and the
matters which are pre-election matters stand on a different footing and so far as the pre-election
matters are concerned, the objection regarding maintainability of the writ petition does not apply
with the same force. In this context, reference may be made to the Full Bench decision of this CourtAzizulla Khan And Ors. vs State And Ors. on 6 September, 1990

in Atma Singh's case, reported in 1967 RLW 275 : (AIR 1967 Raj 239). It was also a case relating to
election under the Rajasthan Municiplities Act, 1959 and, in this case, the Full Bench dealth with the
questions which had been referred by a Division Bench. In para 14, in the case of Atma Singh, it was
observed as under:--
"It will neither be reasonable nor proper to hold that non-compliance of the
provisions of the Act relating to pre-election matters can form the subject matter of
investigation in an election petition. Such matters can hardly be an appropriate
subject for investigation by an election tribunal. As a matter of fact, Section 33 of the
Act has barred the jurisdiction of the Election Tribunal to review the acts of the
concerned authority relating to pre-election matters as provided therein."
It has been further observed in para 16 as under at page 246 Raj; AIR 1967 :
"16. The process of election starts by issuing of a notification calling upon a
constituency to elect a member. Before such a notification can be issued, a number of
preliminary steps have to be taken under the law. We have noticed that the Act makes
provisions for taking such steps. Broadly speaking these provisions relate to :--
(1) Constituting a municipality and defining its limits.
(2) Issuing notification by the State Government declaring the composition of the
Board.
(3) Division of Municipality into various wards and defining the limits, (4)
Preparation of electoral roll.
The law has laid down the manner in which these feelings are to be done. There may arise cases in
which the authorities have failed to perform their functions in accordance with law in doing these
things. Sometimes the transgression of law may be inexcusable and of such a serious nature that a
court may be persuaded to take the view that the bedrock to hold elections is massing. In such
circumstances, a citizen may apply to this Court under Article 226 of the Constitution for issuing of
mandamus or any other appropriate writ directing the State Government to perform these things in
accordance with law and the High Court in an appropriate case may, in its discretion, issue such a
writ or direction restrainting the Government to hold election. Suppose nobody comes forward at
that stage and the elections are held. Even then, a citizen may file a petition under Article 226 of the
Constitution not only for a declaration that the State Government has not acted in accordance with
law in the doing of the aforesaid things and that what has been done is null and void but also for a
further declaration that the elections that had taken place be also held null and void. The High Court
may take into account the circumstances that the petitioner could have come earlier before the
election for relief in this Court under Article 226 of the Constitutions and he has failed to do so, but
it may find that the infirmity in taking these proper steps is of such consequence that no election
could have taken place and it may in its discretion then quash the preliminary steps taken in these
pre-election matters and may as a consequence also set aside the election. The attack of theAzizulla Khan And Ors. vs State And Ors. on 6 September, 1990

petitioner is not to the manner in which elections have been conducted, but to the infirmity to these
pre-election matters. Under such circumstances what the Court could do before the election, it can
also do after the elections. We may no doubt point out that the court would refuse to grant relief
unless it comes to the conclusion that the very foundation for holding the election was lacking.
Setting aside an election is a serious matter and every breach of a provision should not be permitted
to be an excuse for a prayer for setting aside an election."
34. The outcome of the aforesaid discussion and the adjudication of various points raised in these
cases is that the functionaries of the Government have failed to discharge the obligation in
accordancew with the law with regard to the question of having Municipal Corporation instead of
Municipal Council for Municipal areas having a population of more than 5 lacs, with regard to the
formation and demarcation of wards, in the matters of identifying the wards with reference to the
strengrth of voters for whom the wards were to be reserved and they have acted jn a wholly arbitrary
manner in the matter of allotment and numbering/renumbering of wards and, therefore, while
allowing these writ petitions I deem it lawful and proper to direct as under:
(1) The authorities concerned would first of all find out those municipal areas where
the population has exceeded 5 lacs and would create municipal corporation instead of
municipal councils for Jaipur and such other municipal areas in Rajasthan in
accordance with Section 5 of the Act and take necessary steps and appropriate
measures in accordance with law before calling upon the electorates of such areas for
election to the Municipal Corporations rather than Municipal Councils.
2. The wards shall be formed in each municipal area keeping in view the provisions of Section 13 of
the Act with the caution of compactness of the area and the principle of 10% plus minus.
3. The authorities may then identify the wards to be reserved for women (including SC/ST women)
and for SC/ST on the basis of percentage of the voters of the categories for which the ward is to be
reserved.
4. The wards which are identified to be reserved for women (including SC/ST women) shall be
numbered as 3 and the multiple of 3. For such number of seats which are fixed to be reserved for
SC/ST under Section 9 number shall be allotted and these numbers would also include the number
of wards which are reserved for SC/ ST women.
5. While allotting the number the principle of contiguty will be followed and the efforts shall be
made to complete the circle from first ward to the last ward.
6. The objections, if any, which are filed after the publication of the draft notification shall be duly
considered before finalising the the same.
7. The electorate shall be called upon for election for Corporation/'Council/Boards after the
preparatory measures are completed in accordance with law, after complying with the directions as
aforesaid.Azizulla Khan And Ors. vs State And Ors. on 6 September, 1990

8. These directions shall be carried out within three months from the date of this judgment and
notification calling upon the electorate for election shall be issued immediately thereafter latest by
31st December, 1990.
The writ petitions are allowed as indicated above. There shall be no order as to costs.Azizulla Khan And Ors. vs State And Ors. on 6 September, 1990

