Foundation For Media Professionals vs Union Territory Of
Jammu And Kashmir on 11 May, 2020
Equivalent citations: AIRONLINE 2020 SC 963, AIRONLINE 2020 SC 521
Author: N.V. Ramana
Bench: B.R. Gavai, R. Subhash Reddy, N.V. Ramana
                           IN THE SUPREME COURT OF INDIA
                             CIVIL ORIGINAL JURISDICTION
                          WRIT PETITION (CIVIL) ………. OF 2020
                                 (D. No. 10817 OF 2020)
FOUNDATION FOR MEDIA                                    … PETITIONER
PROFESSIONALS
                                        Versus
UNION TERRITORY OF JAMMU                               … RESPONDENTS
AND KASHMIR & ANR.
                                         AND
                          WRIT PETITION (CIVIL) ………. OF 2020
                                 (D. No. 10875 OF 2020)
SOAYIB QURESHI                                          … PETITIONER
                                        Versus
UNION TERRITORY OF JAMMU                               … RESPONDENT
AND KASHMIR
                                         AND
           WRIT PETITION (CIVIL) ………. OF 2020
                  (D. No. 10904 OF 2020)
PRIVATE SCHOOLS ASSOCIATION              … PETITIONER
J AND K
                           VersusFoundation For Media Professionals vs Union Territory Of Jammu And Kashmir on 11 May, 2020

THE UNION TERRITORY OF JAMMU                           … RESPONDENT
AND KASHMIR
                                O R D E R
1. Again, this Court is called upon to address a very important but a sensitive issue on national
security and human rights, wherein we have to ensure that national security and human rights can
be reasonably and defensibly balanced, a responsibility, that this Court takes with utmost
seriousness.
2. This Court, vide its earlier judgment dated 10.01.2020 in Anuradha Bhasin v. Union of India,
(2020) SCC Online SC 25, gave certain directions regarding the imposition of restrictions on the
internet in a proportionate manner. The aforesaid case had, in addition to the procedural rules,
supplemented the requirements of having timely review and the non−permanence of internet
shutdown orders.
3. The three Petitioners before us are aggrieved by the fact that Respondent No. 1 has restricted the
mobile internet speed to 2G and have approached this Court seeking 4G mobile internet, and the
quashing of the impugned orders restricting internet in the Union Territory of Jammu and Kashmir.
4. Broadly, the argument of the Petitioners is premised on the ground that in the existing COVID−19
situation, when there is a national lockdown, the restrictions imposed on the residents of the entire
Union Territory of Jammu and Kashmir impacts their right to health, right to education, right to
business and right to freedom of speech and expression.
5. They submit that access to internet acquires even more importance under the prevailing
circumstances in the country, relating to the pandemic. The Petitioners contended that the
fulfillment of the right to health is dependent on the availability of effective and speedy internet in
order to access medical services and information on containment strategies. The denial of such
critical information not only violates the peoples’ right to receive information, but is also a denial of
their right to health. Furthermore, the Petitioners contend that restrictions on internet speed
directly impacts the students of Jammu and Kashmir to exercise their right to education as they are
unable to access to e−learning services such as online video classes, and other online educational
content. This not only impacts their continuing education, but also disadvantages the students of
Jammu and Kashmir who are preparing for national/competitive exams. Petitioner in W.P. (C) D.
No. 10817 of 2020, has appended the affidavits of a journalist who collected testimonies of doctors,Foundation For Media Professionals vs Union Territory Of Jammu And Kashmir on 11 May, 2020

teachers, students, journalists, lawyers and business persons from the Union Territory, and of a
technical expert narrating importance of 4G internet, to support the above submissions.
6. Moreover, the Petitioners have argued that the actions of Respondent No. 1 are violative of the
directions laid down by this Court in Anuradha Bhasin (supra) as well as the Temporary Suspension
of Telecom Services (Public Emergency or Public Safety) Rules, 2017 [“Telecom Suspension Rules”]
as no Review Committee has been constituted by the Respondent No. 1. Further, the blanket orders
passed by Respondent No. 1, indicates non− application of mind. Lastly, Respondent No. 1 has failed
to provide any rational nexus between the restriction of the internet speed and national security.
The Petitioners submitted that since the introduction of internet in the Union Territory of Jammu
and Kashmir, the number of incidents relating to terrorism in the region have actually reduced.
Lastly, the Petitioners pleaded in the alternative that if the Respondents apprehend the misuse of
data services, then they could consider restricting the internet only in certain problematic areas or
providing 3G/4G internet to certain regions on a trial basis.
7. The learned Attorney General preliminarily contended that Courts should not step into issues of
national security which are best left to those in charge of policy making [refer to Zamora, (1916) 2
AC 77 (PC)]. Further, the learned Attorney General relying on some judicial pronouncements
submitted that the claims of fundamental rights have to be examined against the larger public
interest of protecting the security of the State, wherein, while balancing the aforesaid conflicting
rights, the security of the nation should triumph against the fundamental rights of the citizens.
Moreover, in the prevailing circumstances wherein there is continuing insurgency in the region, the
spreading of fake news to incite violence, etc., it would not be possible to provide full internet
services to the region.
8. Learned Solicitor General vehemently opposed the petitions and argued that the authorities have
strictly complied with the directions passed by this Court on the previous occasion, and that the
relevant authorities are cognizant of not only the changing circumstances but also the ground
realities. The information regarding COVID−19 available on various social media platforms,
government websites, applications developed by Respondent No. 2 for disseminating information
can be easily downloaded over the 2G internet. Moreover, no restrictions exist over fixed line
internet. Advisories and documents relating to COVID−19 have already been accessed by over 1 lakh
health professionals in the Union Territory of Jammu and Kashmir through fixed line internet.
Further, to ensure effective access to right to health, the Respondent No. 2 is broadcasting
information through various radio channels and through satellite TV and local cable networks. 1.6
lakh pamphlets and 90,000 posters in English, Urdu and Hindi are being disseminated to the
public. Wide publicity is also being given to various helpline numbers which have been established
for COVID− 19 related queries through print and electronic media. With respect to the right to
education of the students of Jammu and Kashmir, lessons are being delivered on 16 DD channels at
a national level, and through the radio. The department has also undertaken the distribution and
delivery of textbooks, upto elementary level, to the eligible students at their homes.
9. The learned Solicitor General also highlighted the fact that over 108 terrorist incidents have taken
place in the recent past, between August 05, 2019 to April 25, 2020 in the Union Territory ofFoundation For Media Professionals vs Union Territory Of Jammu And Kashmir on 11 May, 2020

Jammu and Kashmir. In view of the aforesaid fact, the learned Solicitor General submitted that the
current situation in the Union Territory of Jammu and Kashmir is very grave and volatile, even
referring to the recent terrorist activity in Kupwara District. The learned Solicitor General therefore
submitted that the authorities have calibrated the restrictions based on the requirement so as to
reduce the misuse of internet and that the measures adopted by the authorities are reasonable. He
therefore prayed that the present petitions ought to be dismissed.
10. Before parting with the submissions of the parties, it may be stated that Respondent No. 1
submitted an additional note dated May 06, 2020, after the hearing of the matter was concluded,
wherein recent terrorist activities in the region, and the interest shown by the Pakistani military
regarding the political developments in Kashmir, were highlighted. Petitioners in W.P. (C) D. No.
10817 of 2020 and W.P. (C) D. No. 10875 of 2020 filed responses to the same on May 07, 2020 and
May 06, 2020 respectively. Although the Petitioners have objected to the note filed by the
Respondent No. 1, taking into consideration the far−reaching consequences of the issues involved
herein, we have considered the submissions of both parties.
11. Heard both the parties, and perused the documents placed before us.
12. At the outset, we have already laid down that the fundamental rights of citizens need to be
balanced with national security concerns, when the situation so demands. This Court is cognizant of
the importance of these matters for the national security concerns, and takes the same with utmost
seriousness to ensure that citizens enjoy life and liberty to the greatest possible extent. National
security concerns and human rights must be reasonably and defensibly adjusted with one another,
in line with the constitutional principles. There is no doubt that the present situation calls for a
delicate balancing, looking to the peculiar circumstances prevailing in the Union Territory of
Jammu and Kashmir. Before considering the relief sought by the Petitioners, it is necessary to look
at the steps taken by Respondent No. 1 after the pronouncement of the earlier judgment of this
Court in Anuradha Bhasin (supra). For, convenience, the table below indicates the orders which
have been passed since 10.01.2020 (post Anuradha Bhasin (supra) judgment):
     ORDER                            IMPLICATION
Home−03 (TSTS) of    For Kashmir, fixed line connectivity to
     2020            institutions managing essential services like
  14.01.2020         hospitals, after installation of firewalls and
                     whitelisting.
2G mobile internet to post−paid users to access whitelisted sites in Jammu, Samba, Kathua,
Udhampur and Reasi.
No social media or VPNs.
Number of whitelisted sites: Not mentioned Home−04 (TSTS) of Fixed line connectivity to also be
provided to 2020 IT/software companies.Foundation For Media Professionals vs Union Territory Of Jammu And Kashmir on 11 May, 2020

18.01.2020 2G mobile internet for postpaid users in all districts of Jammu and Kupwara and
Bandipora in Kashmir for accessing white listed sites.
Prepaid connections will be provided mobile internet only after verification by TSPs as per
applicable norms Home−05 (TSTS) of Fixed line connectivity with MAC binding.
     2020            Access only to whitelisted sites.
  24.01.2020
2G mobile internet restored in all districts of J&K for postpaid and verified prepaid customers but
only whitelisted sites can be accessed.
                     No social media or VPNs
Home−08 (TSTS) of    Restrictions mentioned in the Order dated
     2020            24.01.2020 will continue.
  31.01.2020
                     Number of whitelisted sites: 329
Home− 09 (TSTS) of   Restrictions mentioned      in   Order   dated
      2020           31.01.2020 will continue.
   07.02.2020
                     Number of whitelisted sites: 481
Home−13 (TSTS) of    Fixed Line connectivity with MAC binding.
     2020            Access only to whitelisted sites.
  15.02.2020
2G mobile internet for postpaid and verified prepaid customers but only whitelisted sites can be
accessed.
No social media or VPNs.
Home−16 (TSTS) of    Restrictions in Order dated 15.02.2020 will
     2020            continue to apply.
  24.02.2020
                     Number of whitelisted sites: 1674
Home−17 (TSTS) of    2G mobile internet for postpaid and verified
     2020            prepaid customers and access allowed to all
  04.03.2020         websites.
Fixed line connectivity with MAC binding to access all sites.
Home−20 (TSTS) of    Restrictions in Order dated 04.03.2020 will
     2020            continue to apply.
  17.03.2020
Home−21 (TSTS) of    2G mobile internet for postpaid & verified
     2020            prepaid customers to access all websites.Foundation For Media Professionals vs Union Territory Of Jammu And Kashmir on 11 May, 2020

  26.03.2020
Fixed line connectivity with MAC binding to access all sites Home−22 (TSTS) of Restrictions in
Order dated 26.03.2020 will 2020 continue to apply.
03.04.2020 Home−28 (TSTS) of 2G mobile internet for postpaid customers & 2020 verified prepaid
customers to access all 15.04.2020 websites.
Fixed line connectivity with MAC binding to access all websites without any speed restrictions.
Home−34 (TSTS) of 2G mobile internet for postpaid customers & 2020 verified prepaid customers
to access all 27.04.2020 websites.
Fixed line connectivity with mac binding to access all websites without any speed restrictions.
13. The above measures taken by the Respondent No. 1 have to be seen in light of the circumstances
already highlighted by the learned Solicitor General regarding the existing law and order and
national security situations in the Union Territory, and the occurrence of incidents that affect the
integrity of the nation. The learned Solicitor General stated that since 05.08.2019, around 108
terrorist related incidents have taken place in Union Territory of Jammu and Kashmir, wherein 99
incidents were reported from the Kashmir province and 09 from Jammu province. In total, 30
civilians have lost their lives and 114 civilians have been injured. Further, more than 20 security
personnel have been martyred and 54 security personnel have been injured. Moreover, 76 terrorists
have been gunned down. These facts have not been rebutted by the Petitioners. This Court will have
to consider the above in its analysis. It may be important to note that after this matter was reserved
for orders, the Union Territory of Jammu and Kashmir has filed another note, indicating that the
militancy has significantly increased in the recent times, in the following manner:
   DATE            INCIDENT           DISTRICT     CONSEQUENCE
26.04.2020   Encounter at             Kulgam   01 person died
            Gudder Kulgam
27.04.2020   Encounter at  Kulgam                03 terrorists killed
             Lower Munda                         02 security force
           Qazigund Kulgam                       personnel injured
28.04.2020   Encounter at  Shopian               03 terrorists killed
               Melhoora                          02 security personnel
               Zainpora                          injured
                                                 01 civilian injured
29.04.2020      Grenade attack        Srinagar   04 CISF personnel
                   on police                     injured
                deployment at                    01 police personnel
                  Nowhatta                       injured
                   Srinagar
02.05.2020       Encounter at         Pulwama 02 terrorists killed
                 Dangarpora
02.05.2020       Encounter at         Kupwara 02 terrorists killed
                Najar Mohalla                 04 army personnel
                 Chanjimulla                  killed including twoFoundation For Media Professionals vs Union Territory Of Jammu And Kashmir on 11 May, 2020

                  Handwara                    senior officers
                                              01 Police SI killed
                                              01 SF personnel
                                              injured
02.05.2020  Grenade attack            Pulwama No damage caused
            upon CRPF at
           Tahab Pulwama
03.05.2020 Grenade attack Srinagar               No damage caused
             upon SFs at
              Nowshera
               Srinagar
04.05.2020 Firing attack on Kupwara              03 CRPF personnel
           CRPF at Wangam                        killed
               Karlgund                          01 Civilian killed
              Handwara                           01 CRPF personnel
               crossing                          injured
     04.05.2020  Grenade attack Srinagar        01 CISF personnel
                   upon CISF                    injured
                 Bunker at Grid
                Station Wagoora
                Nowgam Srinagar
     05.05.2020 Grenade attack Budgam           01 CRPF personnel
                    on police                   injured
                 deployment at                  01 Police personnel
                  Pakharpora                    injured
                    Budgam                      04 civilians injured
Respondent No. 1 has also pointed to certain material, which indicate that cyber terrorism, is on the
rise within the valley. The Respondent No. 1, has brought to the notice of this Court that the
Pakistani Military in its “Green Book 2020” has called for an information warfare on Kashmir, after
the revocation of special status of Jammu and Kashmir.
14. While it might be desirable and convenient to have better internet in the present circumstances,
wherein there is a worldwide pandemic and a national lockdown. However, the fact that outside
forces are trying to infiltrate the borders and destabilize the integrity of the nation, as well as cause
incidents resulting in the death of innocent citizens and security forces every day cannot be ignored.
15. However, the authorities in the Union Territories of Jammu and Kashmir have selected the 2G
speed to restrict the flow of information in order to prevent misuse of data by terrorists and their
supporters to disturb the peace and tranquility of the Union Territory of Jammu and Kashmir.
16. In any case, we may note that the common thread in the impugned orders is that they have been
passed for the entire Union Territory of Jammu and Kashmir. In this regard, our observations in the
Anuradha Bhasin (supra) may be of some relevance:Foundation For Media Professionals vs Union Territory Of Jammu And Kashmir on 11 May, 2020

“The degree of restriction and the scope of the same, both territorially and
temporally, must stand in relation to what is actually necessary to combat an
emergent situation.” Although the present orders indicate that they have been passed
for a limited period of time, the order does not provide any reasons to reflect that all
the districts of the Union Territory of Jammu and Kashmir require the imposition of
such restrictions. At the same time, we do recognize that the Union Territory of
Jammu and Kashmir has been plagued with militancy, which is required to be taken
into consideration. These competing considerations needs to calibrated in terms of
our judgment in Anuradha Bhasin (supra).
17. One of the criteria for testing the proportionality of the orders is the territorial extent of the
restrictions. In view of the observations made in Anuradha Bhasin (supra), for meaningful
enforcement of the spirit of the judgment, inter alia, the authorities are required to pass orders with
respect to only those areas, where there is absolute necessity of such restrictions to be imposed, after
satisfying the directions passed earlier.
18. In this regard, our attention is drawn to the fact that blanket orders have been passed for the
entire territory rather than for specific affected areas.
19. A perusal of the submissions made before us and the material placed on record indicate that the
submissions of the Petitioners, in normal circumstances, merit consideration. However, the
compelling circumstances of cross border terrorism in the Union Territory of Jammu and Kashmir,
at present, cannot be ignored.
20. Additionally, although the Petitioners have argued that the orders passed by Respondent No. 1
reveals non−application of mind, however, at the cost of repetition, it must be noted that the
authorities have been taking steps towards easing of internet restrictions taking into account the
prevailing circumstances. This can be seen from the fact that initially only whitelisted websites were
allowed, before internet access to all websites was provided on broadband, and finally to postpaid
and verified prepaid mobile users as well, although at 2G speeds. Further, the various steps taken by
Respondent No. 1 with respect to ensuring the fundamental rights of the people, in relation to the
existing COVID− 19 pandemic, must also be taken into account.
21. During the course of the arguments, the Respondent No. 2− Union of India has submitted that
continuous infiltration, foreign influence, violent extremism and issues of national integrity are
prevalent in the Union Territory of Jammu and Kashmir, which are serious issues.
22. In Anuradha Bhasin (supra), this Court has alluded to the fact that modern terrorism is being
propagated through the internet and by using technology in the following manner:
“39. Modern terrorism heavily relies on the internet. Operations on the internet do
not require substantial expenditure and are not traceable easily. The internet is being
used to support fallacious proxy wars by raising money, recruiting and spreading
propaganda/ideologies. The prevalence of the internet provides an easy inroad toFoundation For Media Professionals vs Union Territory Of Jammu And Kashmir on 11 May, 2020

young impressionable minds….”
23. At the same time, the Court is also cognizant of the concerns relating to the ongoing pandemic
and the hardships that may be faced by the citizens. It may be noted that in the earlier judgment of
Anuradha Bhasin (supra) this Court had directed that, under the usual course, every order passed
under Rule 2(2) of the Telecom Suspension Rules restricting the internet is to be placed before a
Review Committee which provides for adequate procedural and substantive safeguards to ensure
that the imposed restrictions are narrowly tailored. However, we are of the view that since the issues
involved affect the State, and the nation, the Review Committee which consists of only State level
officers, may not be in a position to satisfactorily address all the issues raised. We, therefore, find it
appropriate to constitute a Special Committee comprising of the following Secretaries at national, as
well as State, level to look into the prevailing circumstances and immediately determine the
necessity of the continuation of the restrictions in the Union Territory of Jammu and Kashmir:
a. The Secretary, Ministry of Home Affairs (Home Secretary), Government of India.
b. The Secretary, Department of Communications, Ministry of Communications,
Government of India.
c. The Chief Secretary, Union Territory of Jammu and Kashmir The aforesaid Special
Committee shall be headed by the Secretary, Ministry of Home Affairs (Home
Secretary), Government of India.
24. The Special Committee is directed to examine the contentions of, and the material placed herein
by, the Petitioners as well as the Respondents. The aforesaid Committee must also examine the
appropriateness of the alternatives suggested by the Petitioners, regarding limiting the restrictions
to those areas where it is necessary and the allowing of faster internet (3G or 4G) on a trial basis
over certain geographical areas and advise the Respondent No. 1 regarding the same, in terms of our
earlier directions.
25. The writ petitions are disposed of in the afore−stated terms. Pending applications, if any, shall
also stand disposed of. The Registry is directed to communicate this order, along with a copy of the
paperbooks of the present petitions, to the aforesaid Special Committee.
...............................J. (N.V. RAMANA) ...............................J. (R. SUBHASH REDDY)
…...........................J. (B.R. GAVAI) NEW DELHI;
MAY 11, 2020.Foundation For Media Professionals vs Union Territory Of Jammu And Kashmir on 11 May, 2020

