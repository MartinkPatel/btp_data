Charno Ram vs Union Of India And Others on 7 January, 2023
Author: Satyen Vaidya
Bench: Satyen Vaidya
IN THE HIGH COURT OF HIMACHAL PRADESH SHIMLA CWP No. 84 of 2019 Reserved on:
15.12.2022 Decided on: 07.01.2023
__________________________________________________________ .
    Charno Ram                                    ...Petitioner
                                Versus
    Union of India and others                  ...Respondents
__________________________________________________________ Coram The
Hon'ble Mr. Justice Satyen Vaidya, Judge 1 Whether approved for reporting? Yes
______________________________________________________ For the petitioner :
Mr. Jeevan Kumar, Advocate.
    For the respondents:                        Mr. Virbahadur Verma, CGC,
                       r                        for respondent No.1.
                                                Mr. Desh Raj Thakur, Addl.
                                                A.G. with Mr. Narinder Thakur,
                                                to 8.
    Satyen Vaidya, Judge
By way of instant petition, petitioner has prayed for following substantive reliefs:Charno Ram vs Union Of India And Others on 7 January, 2023

"(i) That kindly issue the writ, directions, or orders for the enforcement of
fundamental rights of petitioner guaranteed under Articles 14, 17 and 21 of the
Constitution of India.
(ii) That kindly issue the writ, directions, or orders to take the stringent action
against the erring officers of respondents State Whether reporters of Local Papers
may be allowed to see the judgment?
particularly against the respondent No 8 in accordance with laws this Hon'ble Court deems fit and
proper.
(iii) That all the respondents may kindly be made .
answerable to the violation of fundamental rights of the petitioner and they may be condemned as
this Hon'ble Court deems fit and proper.
(iv) That the petitioner may adequately be compensated to the tune of Rs. 50 Lakh for breach of his
fundamental rights initially to be paid by respondent No 1 to 3 and subsequently recoverable from
the respondent No. 8 as this Hon'ble Court deems fit and r proper."
2. The case of the petitioner in nutshell is that he was working as part time Sweeper in Government
Polytechnic, Banikhet, District Chamba, H.P. His appointment was under the scheme of 'Student
Welfare Fund'. Respondent No.8 conducted the examination for its students from 5.12.2017 to
5.1.2018. The examination centre was in the fourth floor of newly constructed building of said
respondent.
No toilet facility was available at fourth floor as the toilets were under construction. Petitioner was
directed by respondent No.8 to arrange a 'drum' (container) to be kept outside examination centre
for enabling the students to urinate in the improvised container. He was further directed to empty
the drum on the first .
floor by carrying the same down from fourth floor.
Petitioner showed his inability to undertake the assigned job, but he was forced to do the same.
Thus, the petitioner was made to perform the inhuman act continuously right from 05.12.2017 to
05.01.2018.
Petitioner further alleged that while performing his duty, as above, he had a fall on the staircase and
had suffered injuries. The incident was published in vernacular newspaper 'Punjab Kesari' (Chamba
Edition) on 30.12.2017. Petitioner represented to Hon'ble the Chief Minister and Hon'ble the Chief
Justice seeking justice, but his grievance was not redressed, forcing him to file the instant petition.
3. In response submitted on behalf of respondents No. 3, 4 and 7, it has been submitted that the
building of Government Polytechnic, Banikhet was inaugurated in July, 2017 and classes wereCharno Ram vs Union Of India And Others on 7 January, 2023

shifted to the new campus w.e.f. August, 2017. The factum of petitioner working as part time
Sweeper in Government Polytechnic, Banikhet during the year 2017 is not denied. Rather, it is
submitted that he was .
engaged on part time basis since 2011 and his services were taken on contract w.e.f. 06.02.2019. An
inquiry was conducted at institutional level and another inquiry was conducted by the Tehsildar,
Dalhousie.
Respondents 5 and 6 have also taken a stand that inquiry was conducted by the Tehsildar and in
their words the allegations of petitioner were found "baseless, meritless, frivolous and far away from
reality".
4. Respondent No.8 filed separate reply. The factum of engagement of petitioner as part time
Sweeper is not denied. It is also mentioned that petitioner belongs to Scheduled Caste category. As
per respondent No.8, the examination hall of the institution was situated on the third floor at the
time when the examinations were held during December 2017. The toilets on the third floor were
not completely ready and, therefore, the arrangement was made to create temporary urinal outside
the examination hall.
As per the stand of respondent No.8, the petitioner was assigned the duty as Sweeper during the
entire tenure .
of examination in lieu of payment of extra remuneration at the rate of Rs.55/- per shift.
Petitioner had voluntarily agreed to perform the duty.
The temporary urinal outside the examination hall was planned in association with the petitioner. It
has also been tried to be explained that to ensure cleanliness of the area, it was decided to provide
for a bigger size of the container to avoid spreading of urine drops on the floor and also to make it
convenient for the petitioner to drag it to the nearest toilet on the same floor. This arrangement has
been justified by respondent No.8 on the ground that in absence of fully installed toilets in the third
floor, valuable examination time of the students would have been wasted and it would also have
been an impediment in fair conduct of the examination. Respondent No.8 further submitted that
there were as many as six toilets on the third floor and were very near to the examination hall with
more than ten fully operational drain pipes through which urine was supposed to be drained. In this
way, the allegation of petitioner that he was made to carry the drum .
containing urine from fourth floor to first floor was contradicted. The conduct of petitioner has been
alleged to be motivated.
5. I have heard learned counsel for the parties and have also gone through the records of the case
carefully. rCharno Ram vs Union Of India And Others on 7 January, 2023

6. As far as factual position with respect to arrangement of improvised toilet, collection of urine in a
container and its disposal at a place other than where it was collected are not denied by the
respondents. Respondent No.8 has tried to explain that the disposal of collected urine was not being
made on the first floor as alleged by the petitioner, but was being done on the third floor in the
toilets which were still not fully operational. It is admitted by the said respondent that the petitioner
was to dispose the urine in the operational drain pipes in the aforesaid incomplete toilets. The fact
remains that the urine was being collected in an improvised container and petitioner was assigned
the duty to dispose it off.
7. The law clearly prohibits manual .
scavenging. Section 5 of the Prohibition of Employment as Manual Scavengers and Their
Rehabilitation Act, 2013 (for short, "2013 Act"), specifically prohibits employment and engagement
of manual scavengers.
Manual scavenger has been defined in Section 2 (g) of the 2013 Act as under:
"(g). "Manual Scavengers" means a person engaged or employed, at the
commencement of this Act or at any time thereafter, by an individual or a local
authority or an agency or a contractor, for manually cleaning, carrying, disposing of,
or otherwise handling in any manner, human excreta in an insanitary latrine or in an
open drain or pit into which the human excreta from the insanitary latrines is
disposed of, or on a railway track or in such other spaces or premises, as the Central
Government or a State Government may notify, before the excreta fully decomposes
in such manner as may be prescribed and the expression "manual scavenging" shall
be construed accordingly.
Explanation. - For the purpose of this clause, -
(a) "engaged or employed" means being engaged or employed on a regular or
contract basis;
(b) a person engaged or employed to clean excreta with the help of such devices and
using such protective gear, as the Central Government may notify in this behalf, shall
not be deemed to be a 'manual scavenger'."
8. Human excreta means fecal and urinary .
discharge and includes any waste that contains this material.
9. The facts of instant case, as noticed above, clearly reveal the violation of the provisions of the 2013
Act. Assuming the stand of respondent No.8 to be correct, the petitioner would still be covered
under the definition of "manual scavenger", as he was assigned the job of discharge/disposal of the
collected urine in the incomplete toilets on the same floor. Though, I have serious reservation inCharno Ram vs Union Of India And Others on 7 January, 2023

considering the version of respondent No.8 as gospel truth for the reason that on one hand, the said
respondent has tried to explain that the purpose of arranging improvised toilet was to avoid the
wastage of valuable time of the students as also to avoid the chances of use of unfair means, on the
other the allegation regarding disposal of collected urine on the first floor has been denied. Both the
stances appear to be mutually contradictory. In case the urine was to be disposed on same floor,
there hardly was any need to create improvised toilet at some other place.
Such arrangement could have been made even in the .
incomplete toilets, which could have saved the deployment of petitioner as manual scavengers. In
this view of the matter, there is no doubt that the petitioner was deployed as manual scavenger by
respondent No.8, that too, for a considerable period of about one month. r
10. The mandate of Constitution is clear as far as the upliftment of the down trodden and
unprivileged sections of the Society is concerned. The fact of the matter is that the 2013 Act has been
enacted with the preamble as under:
"An act to provide for the prohibition of employment as manual scavengers,
rehabilitation of manual scavengers and their families, and for matters connected
therewith or incidental thereto.
WHEREAS promoting among the citizens' fraternity assuring the dignity of the
individual is enshrined as one of the goals in the Preamble to the Constitution;
AND WHEREAS the right to live with dignity is also implicit in the Fundamental
Rights guaranteed in Part III of the Constitution;
AND WHEREAS Article 46 of the Constitution, inter alia, provides that the State
shall protect the weaker sections, and, particularly, the Scheduled Castes and the
Scheduled Tribes from social injustice and .
all forms of exploitation;
AND WHEREAS the dehumanizing practice of manual scavenging, arising from the
continuing existence of insanitary latrines and a highly iniquitous caste system, still
persists in various parts of the country, and the existing laws have not proved
adequate in eliminating the twin evils of insanitary latrines and manual scavenging;
AND WHEREAS it is necessary to correct the historical injustice and indignity
suffered by the manual scavengers, and to rehabilitate them to a life of dignity."
11. It is pertinent to notice that the 2013 Act was preceded by the Employment of Manual Scavengers
and Construction of Dry Latrines (Prohibition) Act, 1993 with the same objective. The 2013 Act
came into being with modifications in order to overcome the shortcomings of 1993 Act.Charno Ram vs Union Of India And Others on 7 January, 2023

12. The well-defined amplitude of Article 21 of the Constitution includes the right to live with human
dignity and to live the life which is free from exploitation. It also includes right to reputation. Article
17 of the Constitution abolished untouchability and further forbids its practice in any form. Equally
important is the right to equality before law enshrined .
in Article 14 of the Constitution.
13. The State is obligated to protect its citizens against violation of their fundamental, legal and
human rights.
14. It is really unfortunate to notice that the respondents, instead of reminding themselves about
their constitutional and legal obligations, have taken an adversarial path just to defeat the claim of
petitioner in the instant case. At this stage I am reminded of the clear enunciation by Hon'ble
Supreme Court in Bandhua Mukti Morcha vs. Union of India and others (1984) 3 SCC 161, as under:
"9. Before we proceed to consider the merits of the controversy between the parties in
all its various aspects it will be convenient at this stage to dispose of a few
preliminary objections urged on behalf of the respondents. The learned Additional
Solicitor-General appearing on behalf of the State of Haryana as also Mr Phadke on
behalf of one of the mine lessees contended that even if what is alleged by the
petitioner in his letter which has been treated as a writ petition, is true, it cannot
support a writ petition under Article 32 of the Constitution, because no fundamental
right of the petitioner or of the workmen on whose behalf the writ petition has been
filed, can be said to have been infringed. This contention is, in our opinion, futile and
it is indeed surprising that the State Government should have raised it in answer to
the writ .
petition. We can appreciate the anxiety of the mine lessees to resist the writ petition
on any ground available to them, be it hyper-technical or even frivolous, but we find
it incomprehensible that the State Government should urge such a preliminary
objection with a view to stifling at the threshold an enquiry by the Court as to
whether the workmen are living in bondage and under inhuman conditions. We
should have thought that if any citizen brings before the Court a complaint that a
large number of peasants or workers are bonded serfs or are being subjected to
exploitation by a few mine lessees or contractors or employers or are being denied
the benefits of social welfare laws, the State Government, which is, under our
constitutional scheme, charged with the mission of bringing about a new
socio-economic order where there will be social and economic justice for everyone
and equality of status and opportunity for all, would welcome an enquiry by the
Court, so that if it is found that there are in fact bonded labourers or even if the
workers are not bonded in the strict sense of the term as defined in the Bonded
Labour System (Abolition) Act, 1976 but they are made to provide forced labour or
are consigned to a life of utter deprivation and degradation, such a situation can be
set right by the State Government. Even if the State Government is on its ownCharno Ram vs Union Of India And Others on 7 January, 2023

enquiry satisfied that the workmen are not bonded and are not compelled to provide
forced labour and are living and working in decent conditions with all the basic
necessities of life provided to them, the State Government should not baulk an
enquiry by the Court when a complaint is brought by a citizen, but it should be
anxious to satisfy the Court and through the Court, the people of the country, that it
is discharging its constitutional obligation fairly and adequately and the workmen are
being ensured social and economic justice. We have on more .
occasions than one said that public interest litigation is not in the nature of adversary
litigation but it is a challenge and an opportunity to the Government and its officers
to make basic human rights meaningful to the deprived and vulnerable sections of
the community and to assure them social and economic justice which is the signature
tune of our Constitution. The Government and its officers must welcome public
interest litigation, because it would provide them an occasion to examine whether the
poor and the downtrodden are getting their social and economic entitlements or
whether they are continuing to remain victims of deception and exploitation at the
hands of strong and powerful sections of the community and whether social and
economic justice has become a meaningful reality for them or it has remained merely
a teasing illusion and a promise of unreality, so that in case the complaint in the
public interest litigation is found to be true, they can in discharge of their
constitutional obligation root out exploitation and injustice and ensure to the weaker
sections their rights and entitlements. When the Court entertains public interest
litigation, it does not do so in a cavilling spirit or in a confrontational mood or with a
view to tilting at executive authority or seeking to usurp it, but its attempt is only to
ensure observance of social and economic rescue programmes, legislative as well as
executive, framed for the benefit of the have-nots and the handicapped and to protect
them against violation of their basic human rights, which is also the constitutional
obligation of the executive.
The Court is thus merely assisting in the realisation of the constitutional objectives.
10. Moreover, when a complaint is made on behalf of workmen that they are held in
bondage and are working .
and living in miserable conditions without any proper or adequate shelter over their
heads, without any protection against sun and rain, without two square meals per day
and with only dirty water from a nullah to drink, it is difficult to appreciate how such
a complaint can be thrown out on the ground that it is not violative of the
fundamental right of the workmen. It is the fundamental right of everyone in this
country, assured under the interpretation given to Article 21 by this Court in Francis
Mullin case [Francis Coralie Mullin v. Administrator, UT of Delhi, (1981) 1 SCC 608 :
1981 SCC (Cri) 212] to live with human dignity, free from exploitation. This right to
live with human dignity enshrined in Article 21 derives its life breath from the
Directive Principles of State Policy and particularly clauses (e) and (f) of Article 39Charno Ram vs Union Of India And Others on 7 January, 2023

and Articles 41 and 42 and at the least, therefore, it must include protection of the
health and strength of workers, men and women, and of the tender age of children
against abuse, opportunities and facilities for children to develop in a healthy manner
and in conditions of freedom and dignity, educational facilities, just and humane
conditions of work and maternity relief. These are the minimum requirements which
must exist in order to enable a person to live with human dignity and no State --
neither the Central Government nor any State Government -- has the right to take
any action which will deprive a person of the enjoyment of these basic essentials.
Since the Directive Principles of State policy contained in clauses (e) and (f) of Article
39, Articles 41 and 42 are not enforceable in a Court of law, it may not be possible to
compel the State through the judicial process to make provision by statutory
enactment or executive fiat for ensuring these basic essentials which go to make up a
life of human dignity but where legislation is already enacted by the State providing
these basic requirements to the workmen and thus investing their right to live with
basic human .
dignity, with concrete reality and content, the State can certainly be obligated to
ensure observance of such legislation for inaction on the part of the State in securing
implementation of such legislation would amount to denial of the right to live with
human dignity enshrined in Article 21, more so in the context of Article 256 which
provides that the executive power of every State shall be so exercised as to ensure
compliance with the laws made by Parliament and any existing laws which apply in
that State. We have already pointed out in Asiad Construction Workers case [People's
Union for Democratic Rights v. Union of India, (1982) 3 SCC 235 : 1982 SCC (L&S)
275 : AIR 1982 SC 1473 : (1983) 1 SCR 456] that the State is under a constitutional
obligation to see that there is no violation of the fundamental right of any person,
particularly when he belongs to the weaker sections of the community and is unable
to wage a legal battle against a strong and powerful opponent who is exploiting him.
The Central Government is therefore bound to ensure observance of various social
welfare and labour laws enacted by Parliament for the purpose of securing to the
workmen a life of basic human dignity in compliance with the Directive Principles of
State Policy. It must also follow as a necessary corollary that the State of Haryana in
which the stone quarries are vested by reason of Haryana Minerals (Vesting of
Rights) Act, 1973 and which is therefore the owner of the mines cannot while giving
its mines for stone quarrying operations, permit workmen to be denied the benefit of
various social welfare and labour laws enacted with a view to enabling them to live a
life of human dignity. The State of Haryana must therefore ensure that the mine
lessees or contractors, to whom it is giving its mines for stone quarrying operations,
observe various social welfare and labour laws enacted for the benefit of the
workmen. This is a constitutional obligation .
which can be enforced against the Central Government and the State of Haryana by a
writ petition under Article 32 of the Constitution."Charno Ram vs Union Of India And Others on 7 January, 2023

15. The grievance of petitioner with respect to violation of his fundamental and legal right is being
contested by raising plea of estoppel or acquiescence against him. Respondent No.8 has come up
with a plea that petitioner had been the consenting party and was being paid extra remuneration for
each shift of examination. Before delving on such an absurd plea, it is necessary to have a glance at
the nature of employment of the petitioner at relevant stage.
Petitioner was employed on part time basis. He was assigned four hours' job daily for a meagre
amount.
Admittedly, the petitioner belongs to that stratum of society, which is kept busy in planning two
ends meet.
In such compelling conditions, the consent becomes totally irrelevant.
16. In Safai Karamchari Andolan and others vs. Union of India and others (2014) 11 SCC 224,
Hon'ble Supreme Court has reiterated the .
Constitutional resolve and has very categorically underlined the importance of 2013 Act as under:
"21. For over a decade, this Court issued various directions and sought for compliance
from all the States and Union Territories. Due to effective intervention and directions
of this Court, the Government of India brought an Act called "The Prohibition of
Employment as Manual Scavengers and their Rehabilitation Act, 2013 for abolition of
this evil and for the welfare of manual scavengers. The Act got the assent of the
President on 18.09.2013. The enactment of the aforesaid Act, in no way, neither
dilutes the constitutional mandate of Article 17 nor does it condone the inaction on
the part of Union and State Governments under the 1993 Act. What the 2013 Act
does in addition is to expressly acknowledge Article 17 and Article 21 rights of the
persons engaged in sewage cleaning and cleaning tanks as well persons cleaning
human excreta on railway tracks.
24. In the light of various provisions of the Act referred to above and the Rules in
addition to various directions issued by this Court, we hereby direct all the State
Governments and the Union Territories to fully implement the same and take
appropriate action for non-implementation as well as violation of the provisions
contained in the 2013 Act. Inasmuch as the Act 2013 occupies the entire field, we are
of the view that no further monitoring is required by this Court. However, we once
again reiterate that the duty is cast on all the States and the Union Territories to fully
implement and to take action against the violators.
.
Henceforth, persons aggrieved are permitted to approach the authorities concerned
at the first instance and thereafter the High Court having jurisdiction."Charno Ram vs Union Of India And Others on 7 January, 2023

17. There is no gainsaying that it is for the State and its instrumentalities to follow and implement
the law in its letter and spirit especially the laws which have been enacted for upliftment of the down
trodden.
18. Petitioner belongs to the Scheduled Caste.
Being an unprivileged member of society none heard his representation. The so called inquiries, be
it the internal inquiry or the inquiry held by Tehsildar of the area, were nothing more than the farce.
The violation of the provisions of 2013 Act was writ large from the available bare facts; still no action
was taken against the wrongdoers, forcing the petitioner to approach this Court.
19. The violation of fundamental right of petitioner is proved in the facts of instant case. There also
is clear violation of provisions of the 2013 Act.
Thus, it is clearly established that petitioner has suffered humiliation, ridicule, disgrace,
mortification .
and consequent embarrassment on account of acts and conduct attributable to the State and its
instrumentalities. Respondents have been instrumental not only in violating the fundamental rights
of the petitioner but also the legal rights available to him under 2013 Act. Even violation of legal
rights has manifestation of violation of fundamental right, if remains un-redressed.
20. It will also be gainful to quote hereafter the following excerpts from Bandhua Mukti Morcha
(supra) highlighting the role of Constitutional Courts in the matters relating to underprivileged:
"14. Now it is obvious that the poor and the disadvantaged cannot possibly produce
relevant material before the court in support of their case and equally where an
action is brought on their behalf by a citizen acting pro bono publico, it would be
almost impossible for him to gather the relevant material and place it before the
court. What is the Supreme Court to do in such a case? Would the Supreme Court not
be failing in discharge of its constitutional duty of enforcing a fundamental right if it
refuses to intervene because the petitioner belonging to the underprivileged segment
of society or a public spirited citizen espousing .
his cause is unable to produce the relevant material before the court. If the Supreme
Court were to adopt a passive approach and decline to intervene in such a case
because relevant material has not been produced before it by the party seeking its
intervention, the fundamental rights would remain merely a teasing illusion so far as
the poor and disadvantaged sections of the community are concerned. It is for this
reason that the Supreme Court has evolved the practice of appointing commissions
for the purpose of gathering facts and data in regard to a complaint of breach of
fundamental right made on behalf of the weaker sections of the society. The Report of
the commissioner would furnish prima facie evidence of the facts and data gathered
by the commissioner and that is why the Supreme Court is careful to appoint aCharno Ram vs Union Of India And Others on 7 January, 2023

responsible person as commissioner to make an inquiry or investigation into the facts
relating to the complaint. It is interesting to note that in the past the Supreme Court
has appointed sometimes a district magistrate, sometimes a district Judge,
sometimes a professor of law, sometimes a journalist, sometimes an officer of the
court and sometimes an advocate practising in the court, for the purpose of carrying
out an inquiry or investigation and making report to the court because the
commissioner appointed by the Court must be a responsible person who enjoys the
confidence, of the court and who is expected to carry out his assignment objectively
and impartially without any predilection or prejudice. Once the report of the
Commissioner is received, copies of it would be supplied to the parties so that either
party, if it wants to dispute any of the facts or data stated in the Report, may do so by
filing an affidavit and the court then consider the report of the .
commissioner and the affidavits which may have been filed and proceed to adjudicate
upon the issue arising in the writ petition. It would be entirely for the Court to
consider what weight to attach to the facts and data stated in the report of the
commissioner and to what extent to act upon such facts and data. But it would not be
correct to say that the report of the commissioner has no evidentiary value at all,
since the statements made in it are not tested by cross-examination. To accept this
contention would be to introduce the adversarial procedure in a proceeding where in
the given situation, it is totally inapposite. The learned Additional Solicitor General
and Mr. Phadke relied on Order XXVI of the Code of Civil Procedure and Order XLVI
of the Supreme Court Rules 1966 for the purpose of contending that a commission
can be appointed by the Supreme Court only for the purpose of examining witnesses,
making legal investigations and examining accounts and the Supreme Court has no
power to appoint a commission for making an inquiry or investigation into facts
relating to a complaint of violation of a fundamental right in a proceeding under
Article 32. Now it is true that Order XLVI of the Supreme Court Rules 1966 makes
the provisions of Order XXVI of the Code of Civil Procedure, except rules 13, 14, 19,
20, 21 and 22 applicable to the Supreme Court and days down the procedure for an
application for issue of a commission, but Order XXVI is not exhaustive and does not
detract from the inherent power of the Supreme Court to appoint a commission, if
the appointment of such commission is found necessary for the purpose of securing
enforcement of a fundamental right in exercise of its constitutional jurisdiction under
Article 32. Order XLVI of the Supreme .
Court Rules 1966 cannot in any way militate against the power of the Supreme Court
under Article 32 and in fact rule 6 of Order XLVII of the Supreme Court Rules 1966
provides that nothing in those Rules "shall be deemed to limit or otherwise affect the
inherent powers of the court to make such orders as may be necessary for the ends of
justice." We cannot therefore accept the contention of the learned Addl. Solicitor
General and Mr. Phadke that the court acted beyond its power in appointing M/s.
Ashok Srivastava and Ashok Panda as commissioners in the first instance and Dr.
Patwardhan as commissioner at a subsequent stage for the purpose of making anCharno Ram vs Union Of India And Others on 7 January, 2023

inquiry into the conditions of workmen employed in the stone quarries. The
petitioner in the writ petition specifically alleged violation of the fundamental rights
of the workmen employed in the stone quarried under Articles 21 and 23 and it was
therefore necessary for the court to appoint these commissioners for the purpose of
inquiring into the facts related to this complaint. The Report of M/s.
Ashok Srivastava and Ashok Panda as also the Report of Dr. Patwardhan were clearly
documents having evidentiary value and they furnished prima facie evidence of the
facts and data stated in those Reports. Of course, as we have stated above, it will be
for us to consider what weight we should attach to the facts and data contained in
these Reports in the light of the various affidavits filed in the proceedings.
15. We may point out that what we have said above in regard to the exercise of
jurisdiction by the Supreme Court under Article 32 must apply equally in relation to
the exercise of jurisdiction by the High Courts .
under Article 226, for the latter jurisdiction is also a new constitutional jurisdiction
and it is conferred in the same wide terms as the jurisdiction under Article 32 and the
same powers can and must therefore be exercised by the High Courts while exercising
jurisdiction under Article 226. In fact, the jurisdiction of the High Courts under
Article 226 is much wider, because the High Courts are required to exercise this
jurisdiction not only for enforcement of a fundamental right but also for enforcement
of any legal right and there are many rights conferred on the poor and the
disadvantaged which are the creation of statute and they need to be enforced as
urgently and vigorously as fundamental rights."
21. Being custodian of the Constitution, this court cannot remain unmindful of its duties. The
respondents have not only violated the rights of petitioner but have also undermined the mandate of
law. The violator must not remain un-punished for it will not only deny justice to the petitioner but
also prove regressive in our progression and quest for achieving the objectives enshrined in the
Constitution.
22. The petitioner has invoked the writ jurisdiction of this Court for the reliefs as noticed above, on
the ground of violation of his fundamental .
and human rights. Petitioner has sought monetary compensation in addition to the various
directions as detailed above. Merely because the petitioner has alternative remedy to claim damages,
he cannot be denied the audience in the instant proceedings, this Court being custodian and
guardian of fundamental rights of the citizen of the country. Support in this regard can be drawn
from the following extracts of the judgment passed by the Hon'ble Supreme Court in Harbans Lal
Sahnia and another vs. Indian Oil Corpn. Ltd. and others (2003) 2 SCC 107:
"7. So far as the view taken by the High Court that the remedy by way of recourse to
arbitration clause was available to the appellants and therefore the writ petition filedCharno Ram vs Union Of India And Others on 7 January, 2023

by the appellants was liable to be dismissed, suffice it to observe that the rule of
exclusion of writ jurisdiction by availability of an alternative remedy is a rule of
discretion and not one of compulsion. In an appropriate case in spite of availability of
the alternative remedy, the High Court may still exercise its writ jurisdiction in at
least three contingencies: (i) where the writ petition seeks enforcement of any of the
Fundamental Rights; (ii) where there is failure of principles of natural justice or, (iii)
where the orders or proceedings are wholly without jurisdiction or the vires of an Act
and is challenged [See Whirlpool Corporation v. Registrar of Trade Marks, Mumbai
and Ors., (1998) 8 SCC 1. The .
present case attracts applicability of first two contingencies. Moreover, as noted, the
petitioners' dealership, which is their bread and butter came to be terminated for an
irrelevant and non-existent cause. In such circumstances, we feel that the appellants
should have been allowed relief by the High Court itself instead of driving them to the
need of initiating arbitration proceedings."
23. On maintainability of the writ petition under Article 32 of the Constitution, the Hon'ble Supreme
Court in Rudal Sah vs. State of Bihar and another (1983) 4 SCC 141, observed as under:
"9. It is true that Article 32 cannot be used as a substitute for the enforcement of
rights and obligations which can be enforced efficaciously through the ordinary
processes of Courts, Civil and Criminal. A money claim has therefore to be agitated in
and adjudicated upon in a suit instituted in a court of lowest grade competent to try
it. But the important question for our consideration is whether in the exercise of its
jurisdiction under Article 32, this Court can pass an order for the payment of money
if such an order is in the nature of compensation consequential upon the deprivation
of a fundamental right. The instant case is illustrative of such cases. The petitioner
was detained illegally in the prison for over fourteen years after his acquittal in a
full-dressed trial.
He filed a Habeas Corpus petition in this Court for his release from illegal detention.
He obtained that relief, our finding being that his detention in the prison- after his
acquittal was wholly unjustified. He contends that he is entitled to be compensated
for his illegal detention and .
that we ought to pass appropriate order for the payment of compensation in this
Habeas Corpus petition itself.
10. We cannot resist this argument. We see no effective answer to it save the stale and
sterile objection that the petitioner may, if so advised, file a suit to recover damages
from the State Government. Happily, the State's Counsel has not raised that
objection. The petitioner could have been relegated to the ordinary remedy of a suit if
his claim to compensation was factually controversial, in the sense that a civil court
may or may not have upheld his claim. But we have no doubt that if the petitionerCharno Ram vs Union Of India And Others on 7 January, 2023

files a suit to recover damages for his illegal detention, a decree for damages would
have to be passed in that suit, though it is not possible to predicate, in the absence of
evidence, the precise amount which would be decreed in his favour. In these
circumstances, the refusal of this Court to pass an order of compensation in favour of
the petitioner will be doing mere lip-service to his fundamental right to liberty which
the State Government has so grossly violated. Article 21 which guarantees the right to
life and liberty will be denuded of its significant content if the power of this Court
were limited to passing orders to release from illegal detention. One of the telling
ways in which the violation of that right can reasonably be prevented and due
compliance with the mandate of Article 21 secured, is to mulct its violators in the
payment of monetary compensation. Administrative sclerosis leading to flagrant
infringements of fundamental rights cannot be corrected by any other method open
to the judiciary to adopt. The right to compensation is some palliative for the
unlawful acts of instrumentalities which act in the name of public interest and which
present for their protection the powers of the State as a shield. If civilization is not to
perish in this country as it has .
perished in some others too well-known to suffer mention, it is necessary to educate
ourselves into accepting that, respect for the rights of individuals is the true bastion
of democracy. Therefore, the State must repair the damage done by its officers to the
petitioner's rights. It may have recourse against those officers."
24. In Delhi Jal Board vs. National Campaign for Dignity and Rights of Sewerage and Allied
Workers and others (2011) 8 SCC 568, the Hon'ble Supreme Court has held as under:
"31. These judgments are complete answer to the appellant's objection to the
maintainability of the writ petition filed by respondent No.1. What the High Court
has done by entertaining the writ petition and issuing directions for protection of the
persons employed to do work relating to sewage operations is part of its obligation to
do justice to the disadvantaged and poor sections of the society. We may add that the
superior Courts will be failing in their constitutional duty if they decline to entertain
petitions filed by genuine social groups, NGOs and social workers for espousing the
cause of those who are deprived of the basic rights available to every human being,
what to say of fundamental rights guaranteed under the Constitution. It is the duty of
the judicial constituent of the State like its political and executive constituents to
protect the rights of every citizen and every individual and ensure that everyone is
able to live with dignity."
25. Keeping in view the entirety of facts and .
circumstances of the case as also the exposition of law discussed above, petition is allowed and
disposed of with directions as under:Charno Ram vs Union Of India And Others on 7 January, 2023

(i) Respondent No.2 is directed to pay a sum of Rs. 2,00,000/- (Rs. Two Lakhs) to
the petitioner as compensation within six weeks from the date of passing of this
judgment.
              (ii)    Respondents No.2 to 4 are directed to
                      initiate          appropriate               action/
                      proceedings in accordance with law
against the official(s)/ person(s) guilty of violating the provisions of "Prohibition of
Employment as Manual Scavengers and their Rehabilitation Act, 2013".
              (iii)   Respondents 1 and 2 are                     further
                      directed    to     fully     implement            the
provisions contained in Prohibition of Employment as Manual Scavengers and their
Rehabilitation Act, 2013 and take appropriate action for non-
.
implementation as well as violation of the same.
26. Pending miscellaneous application(s), if any, also stands disposed of.
    7th January, 2023                           (Satyen Vaidya)
          (GR) r                                       JudgeCharno Ram vs Union Of India And Others on 7 January, 2023

